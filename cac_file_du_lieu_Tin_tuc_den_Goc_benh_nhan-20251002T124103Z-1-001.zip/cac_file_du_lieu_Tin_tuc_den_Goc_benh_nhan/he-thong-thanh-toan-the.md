## BỆNH VIỆN NGUYỄN TRI PHƯƠNG 'CHƯƠNG TRÌNH MỘT THẺ QUỐC GIA'


## Dịch vụ y tế tại BV Nguyễn Tri Phương


## Hướng dẫn đặt xét nghiệm thực hiện tại nhà

Bước 1: truy cập trang web [khamtainha-bvntp.com](http://khamtainha-bvntp.com/?fbclid=IwAR1acGT9VhRW-a6NILOJpHe3kRNpxJCwoQQafAi5rzrfM9iYGYp2fgT3dj4)
Bước 2: chọn thẻ "Đăng ký xét nghiệm"
Bước 3: thực hiện khai báo các trường bắt buộc và chọn lựa các xét nghiệm cần thực hiện
Bước 4: bấm nút gửi (submit) khi đã hoàn thành để gửi toàn bộ các thông tin cho chúng tôi 
Bước 5: vui lòng chờ nhận cuộc gọi xác nhận từ nhân viên y tế bệnh viện Nguyễn Tri Phương
(Bạn cũng có thể nhắn tin trên fanpage của BV thông báo đã đặt lịch để chúng tôi có thể hỗ trợ nhanh hơn!)
Theo dõi các thông tin của BV trên facebook [tại đây](https://www.facebook.com/BVNTP)
Theo dõi các video về y tế của BV tại [kênh truyền thông](https://www.youtube.com/channel/UCRlRfMJl5emGJvWjuoJK7sg)./.

## Những tiến bộ và phát triển của BV trong năm 2020


