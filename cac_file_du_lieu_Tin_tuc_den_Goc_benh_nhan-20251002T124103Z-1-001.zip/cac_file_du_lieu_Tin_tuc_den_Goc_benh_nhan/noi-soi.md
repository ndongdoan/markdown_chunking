## ️ 2 phương pháp nội soi ruột non phổ biến nhất hiện nay

**Nội soi ruột non** là kỹ thuật thăm dò chức năng giúp phát hiện các tổn thương, bệnh lý liên quan đến ruột non. Có 2 phương pháp nội soi được ứng dụng rộng rãi nhất hiện nay là nội soi bằng viên nang và nội soi bằng bóng đơn. Bài viết sau sẽ cung cấp thông tin chi tiết về các đặc điểm cụ thể của từng phương pháp nội soi này.
**1. Nội soi ruột non bằng viên nang**
_**1.1. Định nghĩa**_
Đây là kỹ thuật chẩn đoán hình ảnh không can thiệp, thực hiện bởi viên nang nội soi gắn camera nhỏ có khả năng ghi lại 3 hình/giây trong vòng 11 giờ. Tuy có kích thước nhỏ (11mm x 24mm), camera này có góc quay rộng lên đến 150 độ. Hình ảnh ruột non thu được rất rõ nét với kích thước 102,400 pixels (320×320).
Viên nang thường được dùng để kiểm tra, xác định vị trí chảy máu ẩn và theo dõi trạng thái các khối u trong ruột non. Sau khi người bệnh uống viên nang, nó sẽ di chuyển như một mẫu thức ăn qua thực quản, dạ dày xuống ruột non đến ruột già.
Viên nang nội soi có kích thước nhỏ, gắn camera có góc quay rộng với chất lượng hình ảnh rõ nét
_**1.2. Chỉ định và chống chỉ định**_
Các trường hợp được chỉ định nội soi viêm nang gồm:
– Chẩn đoán, đánh giá tình trạng khối u tại đường tiêu hóa.
– Phát hiện, xác định vị trí xuất huyết tiêu hóa.
– Người bệnh gặp một số vấn đề tiêu hóa khác cần kiểm tra theo chỉ định của bác sĩ.
– Chẩn đoán các bệnh lý ruột non gồm: khối u, viêm loét, nguyên nhân và vị trí chảy máu,…
Nội soi viên nang chống chỉ định cho những trường hợp sau:
– Người nghi ngờ bị hẹp hoặc tắc ống tiêu hóa.
– Người đang bị hoặc có tiền sử bị chảy máu dạ dày.
– Người bị bệnh động kinh.
– Người đang dùng máy khử rung, máy trợ tim và một số thiết bị y tế khác, do các thiết bị này có thể gây nhiễu tín hiệu của camera trong viên nang.
– Phụ nữ đang mang thai và trẻ em dưới 10 tuổi là những đối tượng không được chỉ định uống viên nang nội soi.
_**1.3. Ưu điểm và nhược điểm của nội soi viên nang**_
Ưu điểm
– Quá trình nội soi viên nang không khiến người bệnh có cảm giác khó chịu hay đau đớn.
– Người bệnh có thể ăn uống, sinh hoạt và làm việc bình thường sau khi uống viên nang.
– Hình ảnh 3D vô cùng rõ nét, không chỉ quan sát ruột non mà còn soi rõ toàn bộ thực quản, dạ dày, đại trực tràng.
– An toàn: không cần sử dụng chất gây tê hoặc gây mê; không ảnh hưởng đến cơ quan khác; hầu như không có biến chứng khi nội soi.
– Chặn đứng hoàn toàn nguy cơ lây nhiễm chéo các bệnh truyền nhiễm.
– Là lựa chọn hoàn hảo cho những người bệnh mẫn cảm với các phương pháp nội soi khác.
Nhược điểm
– Viên nang lưu thông thụ động một chiều trong ống tiêu hóa nhờ nhu động ruột. Điều này hạn chế khả năng quan sát của camera ở một số vùng của dạ dày và đại tràng. Chính vì vậy, viên nang hiện nay hầu như chỉ ứng dụng trong chẩn đoán bệnh lý ruột non – nơi mà các phương pháp tiêu chuẩn không thường không quan sát được.
– Hình ảnh thu được từ viên nang có chất lượng kém hơn so với nội soi ống mềm. Theo sự co bóp của ruột, viên nang có thể di chuyển quá nhanh, bỏ sót các vị trí bất thường. Hoặc nó cũng có thể di chuyển quá chậm, dẫn đến bị hết pin khi chưa ghi hình đầy đủ.
– Viên nang có thể bị kẹt lại do bệnh lý gây hẹp ống tiêu hóa bất ngờ ngoài dự đoán như viêm ruột, khối u. Lúc này cần phải phẫu thuật để lấy máy ra, kết hợp giải quyết đoạn ruột bất thường đó.
– Viên nang nội soi không có khả năng sinh thiết ngay cả khi nhìn thấy tổn thương. Do đó, phương pháp này không có được bằng chứng về giải phẫu bệnh học như nội soi ống mềm.
– Viên nang chỉ thuần túy là một thiết bị chẩn đoán, không thể giải quyết các tổn thương ống tiêu hóa. Người bệnh cần thực hiện nội soi tiêu chuẩn hoặc phẫu thuật để điều trị các tổn thương này.
– Nội soi viên nang ứng dụng công nghệ tiên tiến, chỉ sử dụng một lần, gây hạn chế cho việc áp dụng đại trà do có chi phí cao.
**_1.4. Quy trình thực hiện nội soi ruột non bằng viên nang_**
Với phương pháp nội soi này, bác sĩ sẽ hướng dẫn người bệnh nuốt một viên nang có kích thước như một viên thuốc con nhộng. Camera trên thiết bị sẽ phát sáng, ghi lại hình ảnh đường ruột và truyền vô tuyến qua da.
Thông thường, hành trình của viên nang từ miệng xuống thực quản, dạ dày, ruột non, ruột già và hậu môn sẽ kéo dài từ 8 – 10 giờ. Viên nang sẽ được đào thải qua đại tiện và không gây ra bất cứ khó khăn nào. Nhìn chung, tổng thời gian nội soi viên nang thường dao động trong khoảng 11 – 12 giờ tùy thuộc vào hoạt động đào thải của người bệnh.
Toàn bộ hình ảnh thu được sẽ lưu lại và gửi trực tiếp đến phần mềm chuyên dụng của bác sĩ. Người bệnh có thể sinh hoạt bình thường trong suốt thời gian viên nang tồn tại trong cơ thể. Tuy nhiên, người bệnh vẫn cần tuân thủ các lưu ý và hướng dẫn của bác sĩ chuyên khoa.
Nội soi viên nang không gây cảm giác đau hay khó chịu cho người bệnh
**_1.5. Lưu ý khi thực hiện nội soi viên nang_**
Nội soi viên nang được đánh giá là rất an toàn, tỷ lệ tai biến hoặc rủi ro rất thấp (dưới 1%). Tuy nhiên, người bệnh cần báo ngay cho bác sĩ nếu có triệu chứng đau bụng hoặc buồn nôn.
Người bệnh phải đeo dây đai gắn máy ghi dữ liệu trong suốt 12 giờ sau khi uống viên nang. Để quá trình nội soi được thuận lợi, người bệnh có thể uống nước. Sau 4 tiếng từ khi uống viên nang, người bệnh có thể ăn nhẹ, tuy nhiên cần tránh ăn kẹo cao su trong suốt quá trình nội soi.
Trước khi nuốt, viên nang cần được kiểm tra đèn tín hiệu của bộ thu, đèn báo nhận dữ liệu và pin. Điều này đảm bảo viên nang hoạt động ổn định, tránh những vấn đề ảnh hưởng kết quả thăm khám.
Người bệnh không ăn trong khoảng 4 giờ sau khi uống viên nang nhưng có thể uống nước. Viên nang sẽ đi xuống ruột non sau khoảng 8 giờ từ khi được nuốt. Lúc này người bệnh có thể ăn uống bình thường. 4 giờ tiếp theo, viên nang được đào thải khỏi cơ thể, hoàn thành quá trình nội soi.
**2. Nội soi ruột non bóng đơn**
_**2.1. Định nghĩa**_
Nội soi bóng đơn chính thức được ứng dụng trong y khoa từ năm 2007. Nó có cấu tạo gồm một bóng duy nhất gắn vào đầu overtube. Thiết bị đi từ miệng có thể xuống tới góc Treitz và đi sâu đến 80cm. Phương pháp này thậm chí có thể kiểm tra từ dưới lên trên, từ hậu môn qua đại tràng đến phần cuối của hỗng tràng.
Nội soi bóng đơn ra đời nhằm thay thế và khắc phục nhược điểm của kỹ thuật nội soi bóng kép trước đó. Đây là phương pháp có thời gian chuẩn bị ngắn (5 phút), thao tác đơn giản, đảm bảo hiệu quả chẩn đoán tại ruột non mà không nhầm lẫn khi bơm và tháo hơi.
Không chỉ quan sát được tổn thương tại các góc khuất khó nhận biết tại ruột non, kỹ thuật này còn có thể can thiệp khi phát hiện tổn thương đó.
Nội soi bóng đơn là 1 trong những kỹ thuật nội soi tiêu hóa tên tiến hàng đầu thế giới
**_2.2. Chỉ định và chống chỉ định_**
Người bệnh thực hiện **nội soi ruột non** bằng bóng đơn trong trường hợp:
– Sinh thiết tổn thương được phát hiện tại ruột non thông qua nội soi viên nang.
– Xuất huyết tiêu hóa nghi ngờ tổn thương từ ruột non.
– Đánh giá và điều trị các tổn thương gây hẹp ruột non.
– Chẩn đoán các bệnh lý ruột non: khối u, Crohn ruột non.
– Phát hiện nguyên nhân tắc ruột, điều trị lấy dị vật ở ruột non.
– Chẩn đoán và điều trị các tổn thương làm hẹp ruột non
– Thăm khám đại tràng trong các trường hợp khó thực hiện bằng nội soi thông thường.
Trong khi đó, các trường hợp chống chỉ định bao gồm:
– Nghi ngờ thủng tạng rỗng; phình, tách động mạch chủ; nghi ngờ hội chứng mạch vành cấp.
– Người bệnh suy hô hấp, suy tim nặng hoặc tăng huyết áp chưa kiểm soát được.
– Người rối loạn tâm thần không hợp tác cũng là đối tượng chống chỉ định nội soi.
Ngoài ra, chống chỉ định tương đối được áp dụng cho những người tụt huyết áp tâm thu dưới 90mmHg.
**_2.3. Ưu điểm và nhược điểm của nội soi bóng đơn_**
Ưu điểm
– Phạm vi quan sát rộng: Tiếp cận từ miệng xuống gần toàn bộ ruột non. Trong trường hợp cần, bác sĩ có thể soi ngược dòng từ dưới lên qua đại tràng đến ruột non.
– Bác sĩ có thể tiến hành ngay các thủ thuật như: đánh dấu vị trí của tổn thương, sinh thiết, cắt polyp, chích cầm máu,… Đây là điểm vượt trội của nội soi bóng đơn so với nội soi viên nang, không dừng lại ở chẩn đoán đơn thuần.
– Máy soi có thể tiến vào ruột một cách chủ động và hiệu quả nhờ khả năng bơm căng và xả xẹp của bóng đơn giúp kéo rút ruột lại từng đoạn.
Nhược điểm
Điểm hạn chế của kỹ thuật này là quá trình nội soi thường tốn nhiều thời gian. Người bệnh cần phải thực hiện gây mê toàn thân trong suốt quá trình thực hiện.
**_2.4. Quy trình thực hiện nội soi ruột non bằng bóng đơn_**
Người bệnh nằm nghiêng về bên trái, chân phải co, chân trái duỗi và gây mê theo chỉ định của bác sĩ. Ngược bệnh ngậm canuyn, máy nội soi và bóng sẽ được qua đường miệng.
Khi máy soi xuống tới hang vị, kỹ thuật viên bắt đầu luồn overtube vào theo đúng quy chuẩn. Máy soi sau đó tiếp tục đi xuống dạ dày, tá tràng và ruột non. Bác sĩ ra y lệnh chụp ảnh tổn thương và thực hiện các thủ thuật cần thiết.
Nội soi bóng đơn ngược dòng được thực hiện qua đường hậu môn. Máy soi sẽ đi qua đại tràng, van hồi manh tràng đến ruột non để quan sát.
Nội soi bóng đơn qua đường miệng hay đường hậu môn đều cho phép khảo sát toàn bộ niêm mạc ruột non
_**2.5. Lưu ý khi thực hiện nội soi bóng đơn**_
Một tuần trước khi nội soi, người bệnh không nên uống các loại thuốc chứa chất sắt. Người mắc đái tháo đường sẽ được kiểm soát bằng insuline chích theo chỉ định của bác sĩ.
Người bệnh không nên ăn những thực phẩm cứng, rắn, khó tiêu hóa trong vòng 1 ngày trước khi nội soi. Thay vào đó, hãy ăn những thực phẩm mềm và uống nhiều nước lọc. Hai giờ trước khi nội soi bóng đơn, người bệnh không ăn hoặc uống bất cứ thứ gì.
Nếu thực hiện nội soi qua đường hậu môn, người bệnh cần làm sạch ống tiêu hóa. Phương pháp phổ biến hiện nay là uống thuốc nhuận tràng mạnh hoặc thụt tháo qua đường hậu môn.
Sau khi nội soi, người bệnh có thể cảm thấy khó chịu ở cổ họng, tức bụng. Đây là những triệu chứng bình thường và không cần lo lắng. Hãy liên hệ với bác sĩ ngay khi có các triệu chứng bất thường như chảy máu khi lấy bệnh phẩm, mạch chậm hoặc ngừng tim do cường phế vị.
**Nội soi ruột non** là giải pháp hữu hiệu giúp tầm soát, đánh giá và xử trí các tổn thương, bệnh lý tại ruột non. Trên thực tế, cơ quan này ít gặp các bất thường hơn so với dạ dày và đại tràng. Tuy nhiên bạn không nên chủ quan, hãy tiến hành nội soi định kỳ để đảm bảo bộ phận này hoạt động trơn tru và khỏe mạnh.
**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/) **- Đa khoa Hạng I Thành phố Hồ Chí Minh

## ️ Nội soi dạ dày để làm gì? Các phương pháp nội soi

  * [1. Khái niệm nội soi dạ dày](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-da-day-de-lam-gi-cac-phuong-phap-noi-soi#1-khi-nim-ni-soi-d-dy)
  * [2. Nội soi dạ dày để làm gì?](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-da-day-de-lam-gi-cac-phuong-phap-noi-soi#2-ni-soi-d-dy-lm-g)
  * [2.1. Phát hiện bệnh lý đường tiêu hóa trên](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-da-day-de-lam-gi-cac-phuong-phap-noi-soi#21-pht-hin-bnh-l-ng-tiu-ha-trn)
  * [2.2. Nội soi dạ dày chỉ điểm ung thư từ rất sớm](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-da-day-de-lam-gi-cac-phuong-phap-noi-soi#22-ni-soi-d-dy-ch-im-ung-th-t-rt-sm)
  * [2.3. Điều trị bệnh lý thực quản, dạ dày, tá tràng](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-da-day-de-lam-gi-cac-phuong-phap-noi-soi#23-iu-tr-bnh-l-thc-qun-d-dy-t-trng)
  * [3. Đối tượng được khuyến cáo thực hiện nội soi](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-da-day-de-lam-gi-cac-phuong-phap-noi-soi#3-i-tng-c-khuyn-co-thc-hin-ni-soi)
  * [4. Các phương pháp nội soi thực hiện](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-da-day-de-lam-gi-cac-phuong-phap-noi-soi#4-cc-phng-php-ni-soi-thc-hin)
  * [4.1. Nội soi tiêu chuẩn](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-da-day-de-lam-gi-cac-phuong-phap-noi-soi#41-ni-soi-tiu-chun)
  * [4.2. Nội soi dạ dày qua đường mũi](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-da-day-de-lam-gi-cac-phuong-phap-noi-soi#42-ni-soi-d-dy-qua-ng-mi)
  * [4.2. Nội soi không đau](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-da-day-de-lam-gi-cac-phuong-phap-noi-soi#42-ni-soi-khng-au)
  * [5. Những điều cần lưu ý](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-da-day-de-lam-gi-cac-phuong-phap-noi-soi#5-nhng-iu-cn-lu-)
  * [5.1. Trước khi thực hiện nội soi](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-da-day-de-lam-gi-cac-phuong-phap-noi-soi#51-trc-khi-thc-hin-ni-soi)
  * [5.2. Sau khi thực hiện nội soi](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-da-day-de-lam-gi-cac-phuong-phap-noi-soi#52-sau-khi-thc-hin-ni-soi)


Nội soi dạ dày là được ứng dụng phổ biến trong chẩn đoán và điều trị các bệnh lý ống tiêu hóa trên, trong đó có ung thư dạ dày. Nhiều người vẫn luôn thắc mắc về ý nghĩa của kỹ thuật thăm dò chức năng này và các phương pháp thực hiện. Bài viết dưới đây sẽ cung cấp các thông tin về nội soi dạ dày, bao gồm vai trò, phương pháp và điều cần lưu ý.
## **1. Khái niệm nội soi dạ dày**
Nội soi dạ dày còn được gọi là nội soi bao tử, hay nội soi đường tiêu hóa trên. Đây là kỹ thuật dùng để kiểm tra niêm mạch phần trên ống tiêu hóa, gồm thực quản, dạ dày và tá tràng.
Ống nội soi mềm có gắn camera và nguồn sáng sẽ được bác sĩ đưa vào thực quản uống dạ dày thông qua đường mũi hoặc miệng.
**Nội soi bao tử giúp kiểm tra đường tiêu hóa trên, gồm thực quản, dạ dày và tá tràng**
## **2. Nội soi dạ dày để làm gì?**
Kỹ thuật thăm dò chức năng này được chỉ định trong các trường hợp dưới đây:
### **2.1. Phát hiện bệnh lý đường tiêu hóa trên**
Người bệnh được chỉ định nội soi để đánh giá các triệu chứng bất thường như: ợ chua, khó nuốt, đau bụng trên dai dẳng, sụt cân bất thường,… Đây là giải pháp hiệu quả nhất để xác định nguyên nhân chảy máu thực quản, dạ dày, tá tràng.
Nội soi bao tử còn phát hiện tình trạng viêm loét hoặc polyp, khối u tại ống tiêu hóa trên. Khả năng chẩn đoán bệnh lý của nội soi được đánh giá là chính xác hơn chụp X-quang. Bên cạnh đó, nội soi còn giúp chẩn đoán tình trạng nhiễm vi khuẩn Hp thông qua sinh thiết và thực hiện test.
### **2.2. Nội soi dạ dày chỉ điểm ung thư từ rất sớm**
Ung thư đường tiêu hóa trên có thể được phát hiện từ giai đoạn sớm nhờ nội soi. Đặc biệt với công nghệ dải tần ánh sáng hẹp NBI 5P, hiệu quả chẩn đoán còn được nâng cao vượt trội.
Ánh sáng dải tần hẹp NBI giúp quan sát sắc nét lớp niêm mạc và hệ thống mao mạch dưới niêm mạc. Đồng thời công nghệ này còn phóng đại hình ảnh hàng trăm lần, cho hình ảnh chi tiết nhất. Kết hợp với kỹ thuật giả lập nhuộm màu mô, tình trạng lành tính và ác tính sẽ được phân biệt rõ nét. Bác sĩ có thể dễ dàng lấy mẫu sinh thiết để làm xét nghiệm mô bệnh học. Đây là cách duy nhất để xác định tế bào ung thư dạ dày, độ chính xác rất cao.
**Nội soi giúp phát hiện ung thư đường tiêu hóa trên từ giai đoạn sớm**
### **2.3. Điều trị bệnh lý thực quản, dạ dày, tá tràng**
Không dừng lại ở phát hiện và chẩn đoán bệnh, nội soi đường tiêu hóa trên còn có khả năng điều trị nhiều bệnh lý. Trong quá trình nội soi, bác sĩ có thể lấy các dị vật nuốt phải, cầm máu trong xuất huyết tiêu hóa, nong thực quản, loại bỏ polyp hay khối u,…
Các phương pháp can thiệp điều trị qua nội soi đều ít xâm lấn, an toàn và hiệu quả. Người bệnh không cần thực hiện phẫu thuật mở, giảm nhu cầu truyền máu. Nhờ đó, người bệnh nhanh chóng hồi phục sức khỏe và trở lại cuộc sống sinh hoạt bình thường. Đặc biệt, ung thư đường tiêu hóa trên có thể điều trị hiệu quả nhờ phương pháp cắt hớt niêm mạc hiện đại can thiệp qua nội soi.
## **3. Đối tượng được khuyến cáo thực hiện nội soi**
Sau đây là các trường hợp nên thực hiện nội soi bao tử:
– Đau bụng vùng thượng vị (vùng trên rốn), đau bụng không rõ nguyên nhân.
– Sụt cân không rõ lý do.
– Trào ngược thức ăn, nuốt nghẹn, buồn nôn nhất là sau khi ăn.
– Đầy hơi, khó tiêu, ợ chua, ợ nóng.
– Khả năng hấp thu kém kể cả khi ăn uống đầy đủ.
– Có biểu hiện thiếu máu; nôn ra máu; đại tiện phân đen hoặc lẫn máu.
– Đau vùng ngực nhưng không liên quan đến vấn đề tim mạch.
– Đang mắc các bệnh lý tại đường tiêu hóa trên, gồm thực quản, dạ dày, tá tràng.
– Người có nguy cơ mắc polyp có yếu tố gia đình cũng là đối tượng nên chủ động nội soi.
– Đang sử dụng một số loại thuốc ảnh hưởng đến dạ dày như thuốc chống viêm, thuốc giảm đau.
Ngoài ra, những người muốn sàng lọc sớm ung thư đường tiêu hóa trên cũng nên thực hiện nội soi ngay cả khi không có triệu chứng bất thường.
## **4. Các phương pháp nội soi thực hiện**
### **4.1. Nội soi tiêu chuẩn**
Ống nội soi được đưa vào dạ dày qua đường miệng khi người bệnh hoàn toàn tỉnh táo. Phương pháp này có thể gây đau và khó chịu cho người bệnh. Nhiều người e ngại không dám nội soi lần hai vì ám ảnh cảm giác buồn nôn khi ống nội soi chạm vào lưỡi gà – vòm khẩu cái.
Tuy nhiên, người bệnh sẽ cảm thấy dễ chịu hơn nếu thả lỏng, giữ tâm lý thoải mái và tân thủ các chỉ dẫn của nhân viên y tế. Ngoài ra, sự khéo léo và chính xác của bác sĩ và ekip nội soi cũng giúp hạn chế tối đa cảm giác đau hay khó chịu cho người bệnh.
### **4.2. Nội soi dạ dày qua đường mũi**
Ở phương pháp này, ống nội soi được đưa qua lỗ mũi đã được xịt tê để thăm khám đường tiêu hóa trên. Người bệnh vẫn tỉnh táo nhưng lại không hề cảm thấy khó chịu hay đau đớn. Lý do là bởi ống nội soi không chạm vào đáy lưỡi hay vòm họng, không gây cảm giác kích thích nào cho người bệnh.
### **4.2. Nội soi không đau**
Phương pháp này thực hiện đưa ống nội soi vào đường miệng khi người bệnh đã ngủ an thần. Người bệnh được gây mê trong thời gian ngắn với lượng thuốc mê ít nên có thể tỉnh táo ngay khi kết thúc nội soi.
Khi đã được gây mê, người bệnh không hề có cảm giác buồn nôn, khó chịu hay đau đớn. Thay vào đó, người bệnh có trải nghiệm nội soi êm ái, tâm lý rất thoải mái và nhẹ nhàng.
Nội soi không đau đang là lựa chọn được đông đảo người bệnh lựa chọn thực hiện
## **5. Những điều cần lưu ý**
### **5.1. Trước khi thực hiện nội soi**
– Dạ dày cần trống rỗng để đảm bảo hiệu quả và an toàn khi thực hiện thăm dò. Người bệnh cần nhịn ăn ít nhất 6 tiếng, nhịn uống ít nhất 2 tiếng trước nội soi.
– Thông báo cho bác sĩ về các triệu chứng đang gặp phải, các loại thuốc hiện đang sử dụng để điều trị.
– Cung cấp đầy đủ thông tin về tiền sử dị ứng, tiền sử bệnh lý cho bác sĩ.
– Ngừng sử dụng một số loại thuốc như thuốc bọc niêm mạc dạ dày, thuốc chống đông theo chỉ định của bác sĩ.
– Giữ tâm lý thoải mái, thực hiện đúng những điều được nhân viên y tế hướng dẫn. Nhờ đó, quá trình nội soi sẽ thuận lợi và hạn chế trải nghiệm khó chịu.
### **5.2. Sau khi thực hiện nội soi**
– Người bệnh nên ăn các thực phẩm mềm, loãng, để nguội sau khi nội soi để tránh là tổn thương niêm mạc ống tiêu hóa.
– Người bệnh nội soi không đau cần lưu viện nghỉ ngơi và theo dõi đến khi hết tác dụng của thuốc mê.
– Người bệnh có thể cảm thấy hơi đau họng, đầy bụng do không khó đưa vào dạ dày. Những cảm giác này sẽ biến mất rất nhanh nên người bệnh không cần lo lắng.
– Người bệnh nội soi không đau nên đi cùng người nhà để đảm bảo an toàn khi tham gia giao thông.
Bài viết đã nêu rõ vai trò, các phương pháp và những điều cần lưu ý khi nội soi dạ dày. Đây là kỹ thuật thăm dò chức năng có ý nghĩa quan trọng trong chẩn đoán và điều trị các bệnh lý đường tiêu hóa trên. Người bệnh nên thực hiện nội soi ngay khi có dấu hiệu bất thường. Cần chú ý lựa chọn cơ sở y tế uy tín để có kết quả nội soi chính xác nhất.
**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/) **- Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [1. Khái niệm nội soi dạ dày](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-da-day-de-lam-gi-cac-phuong-phap-noi-soi#1-khi-nim-ni-soi-d-dy)
  * [2. Nội soi dạ dày để làm gì?](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-da-day-de-lam-gi-cac-phuong-phap-noi-soi#2-ni-soi-d-dy-lm-g)
  * [2.1. Phát hiện bệnh lý đường tiêu hóa trên](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-da-day-de-lam-gi-cac-phuong-phap-noi-soi#21-pht-hin-bnh-l-ng-tiu-ha-trn)
  * [2.2. Nội soi dạ dày chỉ điểm ung thư từ rất sớm](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-da-day-de-lam-gi-cac-phuong-phap-noi-soi#22-ni-soi-d-dy-ch-im-ung-th-t-rt-sm)
  * [2.3. Điều trị bệnh lý thực quản, dạ dày, tá tràng](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-da-day-de-lam-gi-cac-phuong-phap-noi-soi#23-iu-tr-bnh-l-thc-qun-d-dy-t-trng)
  * [3. Đối tượng được khuyến cáo thực hiện nội soi](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-da-day-de-lam-gi-cac-phuong-phap-noi-soi#3-i-tng-c-khuyn-co-thc-hin-ni-soi)
  * [4. Các phương pháp nội soi thực hiện](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-da-day-de-lam-gi-cac-phuong-phap-noi-soi#4-cc-phng-php-ni-soi-thc-hin)
  * [4.1. Nội soi tiêu chuẩn](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-da-day-de-lam-gi-cac-phuong-phap-noi-soi#41-ni-soi-tiu-chun)
  * [4.2. Nội soi dạ dày qua đường mũi](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-da-day-de-lam-gi-cac-phuong-phap-noi-soi#42-ni-soi-d-dy-qua-ng-mi)
  * [4.2. Nội soi không đau](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-da-day-de-lam-gi-cac-phuong-phap-noi-soi#42-ni-soi-khng-au)
  * [5. Những điều cần lưu ý](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-da-day-de-lam-gi-cac-phuong-phap-noi-soi#5-nhng-iu-cn-lu-)
  * [5.1. Trước khi thực hiện nội soi](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-da-day-de-lam-gi-cac-phuong-phap-noi-soi#51-trc-khi-thc-hin-ni-soi)
  * [5.2. Sau khi thực hiện nội soi](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-da-day-de-lam-gi-cac-phuong-phap-noi-soi#52-sau-khi-thc-hin-ni-soi)



## ️ Nội soi dạ dày đại tràng: Khi nào cần thực hiện?

  * [1. Khái niệm nội soi dạ dày đại tràng](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-da-day-dai-trang-khi-nao-can-thuc-hien#1-khi-nim-ni-soi-d-dy-i-trng)
  * [1.1. Nội soi dạ dày](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-da-day-dai-trang-khi-nao-can-thuc-hien#11-ni-soi-d-dy)
  * [1.2. Nội soi đại tràng](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-da-day-dai-trang-khi-nao-can-thuc-hien#12-ni-soi-i-trng)
  * [2. Các phương pháp nội soi](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-da-day-dai-trang-khi-nao-can-thuc-hien#2-cc-phng-php-ni-soi)
  * [2.1. Nội soi dạ dày đại tràng tiêu chuẩn](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-da-day-dai-trang-khi-nao-can-thuc-hien#21-ni-soi-d-dy-i-trng-tiu-chun)
  * [2.2. Nội soi dạ dày đại tràng không đau, không khó chịu](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-da-day-dai-trang-khi-nao-can-thuc-hien#22-ni-soi-d-dy-i-trng-khng-au-khng-kh-chu)
  * [3. Có thể nội soi dạ dày đại tràng cùng lúc không?](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-da-day-dai-trang-khi-nao-can-thuc-hien#3-c-th-ni-soi-d-dy-i-trng-cng-lc-khng)
  * [4. Trường hợp cần nội soi dạ dày đại tràng?](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-da-day-dai-trang-khi-nao-can-thuc-hien#4-trng-hp-cn-ni-soi-d-dy-i-trng)
  * [4.1. Trường hợp cần nội soi dạ dày](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-da-day-dai-trang-khi-nao-can-thuc-hien#41-trng-hp-cn-ni-soi-d-dy)
  * [4.2. Chỉ định nội soi đại tràng](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-da-day-dai-trang-khi-nao-can-thuc-hien#42-ch-nh-ni-soi-i-trng)


## **1. Khái niệm nội soi dạ dày đại tràng**
### **1.1. Nội soi dạ dày**
Nội soi đại tràng là kỹ thuật thăm dò chức năng kiểm tra ống tiêu hóa trên, gồm thực quản, dạ dày và tá tràng. Ống nội soi nhỏ sẽ được bác sĩ đưa vào trong dạ dày của người bệnh. Ống nội soi có thể đi qua đường miệng hoặc đường mũi. Đầu ống có gắn camera và đèn, trực tiếp thu lại hình ảnh niêm mạc và chiếu lên màn hình.
Nội soi dạ dày giúp xác định nguyên nhân của các triệu chứng bất thường về tiêu hóa, như: đau thượng vị, buồn nôn, ợ hơi, khó nuốt,… Trong quá trình nội soi, bác sĩ có thể sinh thiết mẫu mô để xét nghiệm vi khuẩn HP và tế bào ung thư.
Bên cạnh đó, nội soi còn phát hiện các bệnh lý như viêm, loét, polyp, dị vật,… Đồng thời bác sĩ có thể can thiệp điều trị, gồm nong thực quản, cắt polyp, cầm máu, cắt polyp dạ dày,…
Nội soi dạ dày được ứng dụng trong chẩn đoán và điều trị các bệnh lý đường tiêu hóa trên
### **1.2. Nội soi đại tràng**
Nội soi đại tràng là phương pháp thăm khám phần dưới của ống tiêu hóa, gồm đại trực tràng, manh tràng và phần cuối ruột non. Ống nội soi sẽ được đưa qua hậu môn, vào trực tràng và đại tràng để quan sát.
Đây là phương pháp được ứng dụng để tìm ra nguyên nhân của triệu chứng rối loạn tiêu hóa, đau bụng, rối loạn đại tiện, đi ngoài ra máu,… Nội soi giúp chẩn đoán chính xác nhiều bệnh lý như: viêm loét đại trực tràng, bệnh Crohn, polyp đại tràng,… Tương tự như nội soi dạ dày, nội soi đại tràng cũng phát hiện sớm ung thư tiêu hóa qua hình ảnh nội soi và kết quả sinh thiết.
Khi thực hiện nội soi đại tràng, bác sĩ có thể can thiệp cầm máu trong xuất huyết đường tiêu hóa dưới, cắt polyp, loại bỏ các khối u,…
## **2. Các phương pháp nội soi**
### **2.1. Nội soi dạ dày đại tràng tiêu chuẩn**
Người bệnh sẽ không được gây mê khi thực hiện phương pháp này. Một số trường hợp có thể được gây tê cục bộ tại khu vực nội soi. Người bệnh hoàn toàn tỉnh táo trong suốt thời gian nội soi tiêu hóa.
Nội soi tiêu chuẩn khiến nhiều người e ngại vì trải nghiệm khó chịu. Ống nội soi đi qua đường miệng có thể gây buồn nôn hoặc đau họng. Trong khi đó ống nội soi di chuyển trong đại tràng có thể khiến người bệnh căng tức, đau đớn.
Để hạn chế cảm giác khó chịu, người bệnh cần chuẩn bị tâm lý thoải mái khi nội soi. Đồng thời người bệnh cần tuân thủ hướng dẫn của nhân viên y tế về tư thế nội, trang phục nội soi. Thêm vào đó, hãy thực hiện nội soi tại cơ sở y tê tín với độ ngũ bác sĩ giỏi, thao tác khéo léo và chính xác.
### **2.2. Nội soi dạ dày đại tràng không đau, không khó chịu**
Với phương pháp này, người bệnh không phải trải qua cảm giác đau hay khó chịu. Các phương pháp nội soi tiêu hóa không đau bao gồm: Nội soi dạ dày gây mê (qua đường miệng); nội soi đại tràng gây mê; nội soi dạ dày qua đường mũi.
Với phương pháp nội soi gây mê, người bệnh sẽ ngủ ngon trong suốt quá trình thực hiện. Do đó, người bệnh hoàn toàn không bị kích thích khi ống nội soi di chuyển, thăm dò dạ dày và đại tràng. Với nội soi dạ dày qua đường mũi, người bệnh tỉnh táo nhưng cũng không cảm thấy khó chịu. Ống nội soi lúc này không chạm vào đáy lưỡi hay vòm họng nên không gây buồn nôn.
## **3. Có thể nội soi dạ dày đại tràng cùng lúc không?**
Nội soi dạ dày và nội soi đại tràng có thể thực hiện đồng thời trong một lần thăm khám. Đây đang là xu hướng rất phổ biến ở những người có nhu cầu nội soi tiêu hóa. Thực hiện đồng thời nội soi ống tiêu hóa trên và dưới mang lại nhiều lợi ích cho người bệnh:
– Tiết kiệm thời gian lưu lại viện: Người bệnh chỉ cần làm hồ sơ, khám ban đầu, làm các xét nghiệm,… một lần duy nhất cho cả hai thủ thuật.
– Tiết kiệm chi phí nội soi do việc xét nghiệm, gây mê chỉ cần thực hiện một lần.
– Thuận tiện cho người bệnh: Kiểm tra toàn diện đường tiêu hóa trên và dưới chỉ trong một lần đến bệnh viện thăm khám.
– Không làm gia tăng nguy cơ tai biến của thủ thuật nội soi.
## **4. Trường hợp cần nội soi dạ dày đại tràng?**
### **4.1. Trường hợp cần nội soi dạ dày**
Nội soi đường tiêu hóa trên được chỉ định cho các đối tượng sau đây:
– Đau bụng vùng thượng vị (vùng bụng trên rốn), cơn đau không rõ nguyên nhân, kết hợp buồn nôn sau ăn.
– Giảm cân nhanh bất thường, không rõ nguyên nhân sụt cân.
– Có triệu chứng chướng bụng; ợ chua, ợ hơi; trào ngược thức ăn; nuốt nghẹn.
– Mệt mỏi, suy nhược do hấp thu kém mặc dù ăn uống đầy đủ.
– Người bị thiếu máu, có triệu chứng nôn ra máu, đại tiện ra máu hoặc phân đen.
– Tim mạch bình thường nhưng lại có dấu hiệu đau ngực.
– Người đang mắc các bệnh về đường tiêu hóa trên như nhiễm vi khuẩn HP, viêm loét thực quản/dạ dày/tá tràng,…
– Nguy cơ mắc polyp dạ dày có yếu tố gia đình.
### **4.2. Chỉ định nội soi đại tràng**
Những trường hợp sau đây được chỉ định thực hiện nội soi đường tiêu hóa dưới:
– Đau bụng, cơn đau xuất hiện với các mức độ khác nhau (lâm râm hoặc đau quặn bụng từng cơn).
– Thói quen đại tiện bị thay đổi: Người bệnh khó đại tiện hơn, số lần đại tiện tăng hoặc giảm. Thêm vào đó, người bệnh có cảm giác đại tiện không hết phân, rất khó chịu.
– Sụt cân nhanh bất thường, cùng với thiếu máu không rõ nguyên nhân.
– Các trường hợp đang theo dõi bệnh lý đường tiêu hóa dưới như viêm loét đại tràng/trực tràng, polyp đại tràng,…
**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/) **- Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [1. Khái niệm nội soi dạ dày đại tràng](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-da-day-dai-trang-khi-nao-can-thuc-hien#1-khi-nim-ni-soi-d-dy-i-trng)
  * [1.1. Nội soi dạ dày](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-da-day-dai-trang-khi-nao-can-thuc-hien#11-ni-soi-d-dy)
  * [1.2. Nội soi đại tràng](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-da-day-dai-trang-khi-nao-can-thuc-hien#12-ni-soi-i-trng)
  * [2. Các phương pháp nội soi](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-da-day-dai-trang-khi-nao-can-thuc-hien#2-cc-phng-php-ni-soi)
  * [2.1. Nội soi dạ dày đại tràng tiêu chuẩn](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-da-day-dai-trang-khi-nao-can-thuc-hien#21-ni-soi-d-dy-i-trng-tiu-chun)
  * [2.2. Nội soi dạ dày đại tràng không đau, không khó chịu](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-da-day-dai-trang-khi-nao-can-thuc-hien#22-ni-soi-d-dy-i-trng-khng-au-khng-kh-chu)
  * [3. Có thể nội soi dạ dày đại tràng cùng lúc không?](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-da-day-dai-trang-khi-nao-can-thuc-hien#3-c-th-ni-soi-d-dy-i-trng-cng-lc-khng)
  * [4. Trường hợp cần nội soi dạ dày đại tràng?](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-da-day-dai-trang-khi-nao-can-thuc-hien#4-trng-hp-cn-ni-soi-d-dy-i-trng)
  * [4.1. Trường hợp cần nội soi dạ dày](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-da-day-dai-trang-khi-nao-can-thuc-hien#41-trng-hp-cn-ni-soi-d-dy)
  * [4.2. Chỉ định nội soi đại tràng](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-da-day-dai-trang-khi-nao-can-thuc-hien#42-ch-nh-ni-soi-i-trng)



## ️3 phương pháp nội soi bao tử phổ biến nhất

  * [1. Nội soi bao tử (nội soi dạ dày) là gì?](https://bvnguyentriphuong.com.vn/noi-soi/3-phuong-phap-noi-soi-bao-tu-pho-bien-nhat#1-ni-soi-bao-t-ni-soi-d-dy-l-g)
  * [2. Khi nào cần nội soi bao tử?](https://bvnguyentriphuong.com.vn/noi-soi/3-phuong-phap-noi-soi-bao-tu-pho-bien-nhat#2-khi-no-cn-ni-soi-bao-t)
  * [2.2. Chống chỉ định](https://bvnguyentriphuong.com.vn/noi-soi/3-phuong-phap-noi-soi-bao-tu-pho-bien-nhat#22-chng-ch-nh)
  * [2.3. Khám nội soi bao tử ở đâu?](https://bvnguyentriphuong.com.vn/noi-soi/3-phuong-phap-noi-soi-bao-tu-pho-bien-nhat#23-khm-ni-soi-bao-t-u)
  * [3. Các phương pháp nội soi phổ biến hiện nay](https://bvnguyentriphuong.com.vn/noi-soi/3-phuong-phap-noi-soi-bao-tu-pho-bien-nhat#3-cc-phng-php-ni-soi-ph-bin-hin-nay)
  * [3.1. Nội soi bao tử qua đường miệng tiêu chuẩn](https://bvnguyentriphuong.com.vn/noi-soi/3-phuong-phap-noi-soi-bao-tu-pho-bien-nhat#31-ni-soi-bao-t-qua-ng-ming-tiu-chun)
  * [3.2. Nội soi qua đường mũi](https://bvnguyentriphuong.com.vn/noi-soi/3-phuong-phap-noi-soi-bao-tu-pho-bien-nhat#32-ni-soi-qua-ng-mi)
  * [3.3. Nội soi bao tử không đau (Nội soi gây mê)](https://bvnguyentriphuong.com.vn/noi-soi/3-phuong-phap-noi-soi-bao-tu-pho-bien-nhat#33-ni-soi-bao-t-khng-au-ni-soi-gy-m)


Nội soi bao tử (hay nội soi dạ dày) là giải pháp ưu việt nhất để kiểm tra, chẩn đoán và điều trị các bệnh lý đường tiêu hóa trên. Kỹ thuật thăm dò chức năng này vừa an toàn, hiệu quả, vừa không khó chịu như nhiều người vẫn tưởng. Hiểu rõ về các phương pháp nội soi sẽ giúp người bệnh có sự lựa chọn phù hợp. Đồng thời người bệnh cũng có tâm lý thoải mái và chủ động hơn trong việc tầm soát sức khỏe đường tiêu hóa.
## **1. Nội soi bao tử (nội soi dạ dày) là gì?**
Thủ thuật này đưa ống soi mềm vào bên trong đường tiêu hóa nhằm thăm khám thực quản, dạ dày, hành tá tràng và tá tràng. Đây là chẩn đoán hình ảnh có độ an toàn và hiệu quả cao trong việc nhận định các tổn thương của đường tiêu hóa trên.
Bác sĩ có thể sử dụng các dụng cụ đặc biệt để sinh thiết, cắt polyp, cầm máu, lấy dị vật, thắt tĩnh mạch thực quản, nong những phần bị hẹp,… trong quá trình nội soi.
Các biến chứng trong nội soi dạ dày rất hiếm gặp. Rủi ro chủ yếu do người bệnh không hợp tác hoặc đường tiêu hóa có tình trạng thủng, dọa thủng từ trước. Những người có bệnh lý nền về tim mạch và hô hấp nặng cũng có nguy cơ gặp biến chứng trong nội soi. Một số biến chứng khác có thể kể đến gồm: xây xát niêm mạc, chảy máu, nhiễm trùng,…
**Nội soi dạ dày giúp kiểm tra, chẩn đoán và điều trị các tổn thương, bệnh lý đường tiêu hóa trên.**
## **2. Khi nào cần nội soi bao tử?**
### **2.1. Chỉ định**
Trong đa số trường hợp, người bệnh sẽ thực hiện nội soi theo chỉ định của bác sĩ. Các trường hợp thông thường cần nội soi là:
– Có dấu hiệu, triệu chứng nghi ngờ mắc bệnh lý đường tiêu hóa trên: đau thượng vị (vùng bụng trên rốn), khó nuốt, ợ hơi, ợ chua, khó tiêu, chướng bụng, buồn nôn, chán ăn, đi ngoài phân đen,…
– Cần sinh thiết lấy mẫu mô chẩn đoán hoặc cần điều trị một số tính trạng nhất định như: giãn thực quản, loại bỏ dị vật, cắt polyp,…
– Cần đánh giá hiệu quả của việc điều trị các bệnh lý thực quản, dạ dày và tá tràng.
– Có các yếu tố nguy cơ cao mắc bệnh lý đường tiêu hóa: thừa cân, béo phì, nghiện thuốc lá, bị viêm loét dạ dày mạn tính, có tiền sử gia đình mắc ung thư đường tiêu hóa,…
Bên cạnh đó, người khỏe mạnh không thuộc nhóm nguy cơ cao, không có triệu chứng bất thường vẫn có thể đăng ký nội soi dạ dày. Đây là thói quen tốt giúp phát hiện sớm các bất thường về tiêu hóa.
### **2.2. Chống chỉ định**
Thủ thuật nội soi bao tử thường không có chống chỉ định tuyệt đối. Tuy nhiên bác sĩ có thể không chỉ định thực hiện cho một số trường hợp sau đây:
– Người bị thủng dạ dày hoặc cơ quan khác trong ống tiêu hóa.
– Ống tiêu hóa bị bỏng (do uống acid).
– Người có bệnh lý về tim mạch như: suy tim, thiếu máu cơ tim cấp.
– Người bị suy hô hấp.
– Có túi thừa Zenker, túi phình lớn ở động mạch chủ.
– Người mới ăn no.
### **2.3. Khám nội soi bao tử ở đâu?**
Hiện nay có nhiều cơ sở y tế có dịch vụ nội soi tiêu hóa, trong đó có nội soi dạ dày. Tuy nhiên không phải địa chỉ nào cũng đảm bảo an toàn và chất lượng chẩn đoán, điều trị. Do đó việc tìm cơ sở y tế để nội soi cần được cân nhắc kỹ lưỡng.
Người bệnh cần lựa chọn cơ sở đáp ứng đủ các tiêu chí như: có uy tín, được đông đảo người bệnh tin tưởng; đội ngũ bác sĩ chuyên môn cao; có trang thiết bị hiện đại; quy trình khám chữa bệnh rõ ràng, thuận lợi;…
## **3. Các phương pháp nội soi phổ biến hiện nay**
Nội soi đường tiêu hóa trên có thể được thực hiện qua đường miệng hoặc đường mũi. Khi tiến hành nội soi, người bệnh có thể lựa chọn gây mê hoặc không gây mê.
Mỗi phương pháp được thực hiện khác nhau, cũng như đều có ưu điểm và nhược điểm. Bác sĩ sẽ tư vấn, chỉ định phương pháp phù hợp với từng trường hợp cụ thể.
### **3.1. Nội soi bao tử qua đường miệng tiêu chuẩn**
Đây hiện là phương pháp nội soi dạ dày truyền thống và được ứng dụng rộng rãi nhất. Người bệnh vẫn tỉnh táo khi ống soi mềm được bác sĩ đưa vào miệng xuống thực quản, dạ dày để kiểm tra.
– Ưu điểm: Chi phí thấp, dễ thực hiện, thời gian chuẩn bị và tiến hành nội soi nhanh chóng.
– Nhược điểm: Ống nội soi kích thích lưỡi gà, vòm khẩu cái, đáy lưỡi khiến người bệnh buồn nôn, nôn, đau rát họng. Điều này khiến nhiều người bệnh cảm thấy sợ hãi và e ngại nội soi. Cảm giác khó chịu sẽ giảm đi nếu người bệnh bình tĩnh, hợp tác tốt với bác sĩ.
**Nội soi dạ dày qua đường miệng có thể thực hiện các thủ thuật can thiệp như sinh thiết, lấy dị vật, cầm máu,…**
### **3.2. Nội soi qua đường mũi**
Thủ thuật này luồn ống nội soi qua mũi xuống thực quản, dạ dày và tá tràng để quan sát, phát hiện các tổn thương.
– Ưu điểm: Thực hiện dễ dàng, nội soi nhanh chóng. Ống nội soi mềm nhỏ không chạm vào vùng hầu họng, do đó người bệnh thường không cảm thấy buồn nôn, khó chịu. Người bệnh có thể xịt tê vùng mũi, vẫn tỉnh táo và có thể trao đổi được với bác sĩ khi nội soi.
– Nhược điểm: Không áp dụng được trong một số trường hợp như người mắc các vấn đề vùng mũi, hẹp khe mũi. Nội soi dạ dày qua đường mũi không thể can thiệp lấy dị vật, loại bỏ polyp, cầm máu, nong hẹp ống tiêu hóa,… Chi phí của phương pháp này cao hơn so với nội soi đường miệng tiêu chuẩn.
### **3.3. Nội soi bao tử không đau (Nội soi gây mê)**
Ống nội soi sẽ được qua đường miệng xuống thực quản, dạ dày và tá tràng khi người bệnh đang được gây mê tĩnh mạch. Phương pháp này sở hữu nhiều ưu điểm nổi bật gồm:
– Thực hiện nội soi dễ dàng, người bệnh không có cảm giác buồn nôn hay khó chịu. Người bệnh ngủ ngon, không cảm thấy sợ hãi hoặc ám ảnh sau nội soi.
– Tăng độ ăn toàn trong nội soi do người bệnh nằm yên, không cử động mạnh hay giật ống soi gây tổn thương cho đường tiêu hóa trên.
– Thời gian gây mê ngắn (khoảng 5 – 15 phút) và lượng thuốc mê ít, người bệnh tỉnh lại nhanh chóng sau nội soi và sức khỏe không bị ảnh hưởng.
– Bác sĩ có thể thực hiện các thủ thuật can thiệp (lấy dị vật, cầm máu, cắt polyp, tiêm xơ, nong hẹp, thắt tĩnh mạch thực quản) thuận lợi và an toàn hơn.
Tuy nhiên, phương pháp này cũng có một số nhược điểm như: chi phí cao hơn 2 phương pháp kể trên; đòi hỏi cao về tay nghề và trình độ của bác sĩ cũng như chất lượng thiết bị. Thời gian chuẩn bị thường kéo dài hơn, do người bệnh có thể cần làm thêm các xét nghiệm cần thiết như: xét nghiệm máu, đo điện tim đồ,…
Dạ dày là cơ quan tiêu hóa quan trọng, đối mặt với không ít nguy cơ bệnh lý. Bạn có thể lựa chọn các phương pháp nội soi bao tử trên đây để kiểm tra sức khỏe dạ dày. Chủ động nội soi định kỳ giúp sàng lọc hiệu quả và xử trí sớm các bất thường tại cơ quan này.
**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/) **- Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [1. Nội soi bao tử (nội soi dạ dày) là gì?](https://bvnguyentriphuong.com.vn/noi-soi/3-phuong-phap-noi-soi-bao-tu-pho-bien-nhat#1-ni-soi-bao-t-ni-soi-d-dy-l-g)
  * [2. Khi nào cần nội soi bao tử?](https://bvnguyentriphuong.com.vn/noi-soi/3-phuong-phap-noi-soi-bao-tu-pho-bien-nhat#2-khi-no-cn-ni-soi-bao-t)
  * [2.2. Chống chỉ định](https://bvnguyentriphuong.com.vn/noi-soi/3-phuong-phap-noi-soi-bao-tu-pho-bien-nhat#22-chng-ch-nh)
  * [2.3. Khám nội soi bao tử ở đâu?](https://bvnguyentriphuong.com.vn/noi-soi/3-phuong-phap-noi-soi-bao-tu-pho-bien-nhat#23-khm-ni-soi-bao-t-u)
  * [3. Các phương pháp nội soi phổ biến hiện nay](https://bvnguyentriphuong.com.vn/noi-soi/3-phuong-phap-noi-soi-bao-tu-pho-bien-nhat#3-cc-phng-php-ni-soi-ph-bin-hin-nay)
  * [3.1. Nội soi bao tử qua đường miệng tiêu chuẩn](https://bvnguyentriphuong.com.vn/noi-soi/3-phuong-phap-noi-soi-bao-tu-pho-bien-nhat#31-ni-soi-bao-t-qua-ng-ming-tiu-chun)
  * [3.2. Nội soi qua đường mũi](https://bvnguyentriphuong.com.vn/noi-soi/3-phuong-phap-noi-soi-bao-tu-pho-bien-nhat#32-ni-soi-qua-ng-mi)
  * [3.3. Nội soi bao tử không đau (Nội soi gây mê)](https://bvnguyentriphuong.com.vn/noi-soi/3-phuong-phap-noi-soi-bao-tu-pho-bien-nhat#33-ni-soi-bao-t-khng-au-ni-soi-gy-m)



## ️ Nội soi đại tràng có đau không và những lưu ý quan trọng

  * [1. Nội soi đại tràng là gì?](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-dai-trang-co-dau-khong-va-nhung-luu-y-quan-trong#1-ni-soi-i-trng-l-g)
  * [1.2 Khám nội soi đại tràng có đau không? Quy trình thực hiện](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-dai-trang-co-dau-khong-va-nhung-luu-y-quan-trong#12-khm-ni-soi-i-trng-c-au-khng-quy-trnh-thc-hin)
  * [2. Nội soi đại tràng có đau không?](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-dai-trang-co-dau-khong-va-nhung-luu-y-quan-trong#2-ni-soi-i-trng-c-au-khng)
  * [3. Những điều cần làm để giảm đau khi nội soi](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-dai-trang-co-dau-khong-va-nhung-luu-y-quan-trong#3-nhng-iu-cn-lm-gim-au-khi-ni-soi)
  * [3.1 Khi thực hiện nội soi đại tràng có đau không? Chuẩn bị tâm lý vững vàng sẽ giúp hạn chế đau đớn](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-dai-trang-co-dau-khong-va-nhung-luu-y-quan-trong#31-khi-thc-hin-ni-soi-i-trng-c-au-khng-chun-b-tm-l-vng-vng-s-gip-hn-ch-au-n)
  * [3.2 Thông báo cho bác sĩ về tình trạng sức khỏe](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-dai-trang-co-dau-khong-va-nhung-luu-y-quan-trong#32-thng-bo-cho-bc-s-v-tnh-trng-sc-khe)
  * [3.3 Chuẩn bị sạch đại tràng](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-dai-trang-co-dau-khong-va-nhung-luu-y-quan-trong#33-chun-b-sch-i-trng)
  * [3.4 Thực hiện đúng mọi chỉ dẫn của bác sĩ](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-dai-trang-co-dau-khong-va-nhung-luu-y-quan-trong#34-thc-hin-ng-mi-ch-dn-ca-bc-s)
  * [3.5 Lựa chọn cơ sở y tế uy tín](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-dai-trang-co-dau-khong-va-nhung-luu-y-quan-trong#35-la-chn-c-s-y-t-uy-tn)


Đại tràng là cơ quan dễ bị viêm nhiễm nhất trong hệ tiêu hóa. Một khi đại tràng bị tổn thương sẽ dễ để lại hậu quả nghiêm trọng. Nội soi đại tràng giúp chẩn đoán được các bệnh lý để có phương hướng điều trị sớm. Nhưng nhiều bệnh nhân vẫn lo sợ không biết thực hiện nội soi đại tràng có đau không?
## **1. Nội soi đại tràng là gì?**
Từ trước đến nay có rất nhiều phương pháp để chẩn đoán bệnh lý về đường tiêu hóa như: Chụp cắt lớp, siêu âm, chụp X.Quang,… Tuy nhiên các phương pháp cũ tốn kém nhưng không thể phát hiện được một số bệnh lý khó chẩn đoán.
### **1.1 Khái niệm**
Nội soi đại tràng có nhiều ưu điểm hơn trong việc phát hiện các thương tổn bên trong cơ thể. Nội soi đại tràng có đau không? Nội soi đại tràng bằng cách đưa một ống mềm nhỏ vào trong đại tràng. Trên đầu ống có camera giúp ghi lại những hình ảnh trong lòng đại tràng và truyền lại trên máy quan sát. Nhờ đó bác sỹ dễ dàng quan sát những thay đổi dù là nhỏ nhất. Bên cạnh việc phát hiện bệnh thì nội soi còn giúp can thiệp như: Cắt polyp, sinh thiết, tiêm cầm máu,…Ngày nay nội soi đại tràng chính là phương pháp tầm soát ung thư hiệu quả nhất.
### **1.2 Khám nội soi đại tràng có đau không? Quy trình thực hiện**
Nội soi đại tràng có rất nhiều ý nghĩa trong việc chẩn đoán các bệnh về đại trực tràng. Để quá trình thăm khám thuận lợi bạn cần nắm được quy trình thực hiện để không bị lúng túng. Một ca nội soi đại tràng cần tiến hành qua các bước tiêu chuẩn:
Bước 1: Bác sĩ chuyên khoa sẽ thăm khám và tư vấn về tình trạng bệnh
Bước 2: Thực hiện các chỉ định cận lâm sàng cần thiết (nếu có)
Bước 3: Làm hồ sơ trước nội soi
Bước 4: Nội soi dạ dày, đại tràng
Bước 5: Bác sĩ đọc kết quả và đưa ra phương án điều trị
**Bạn nên hỏi trước bác sĩ về quy trình nội soi đại tràng để khi tới khám không bị lúng túng**
## **2. Nội soi đại tràng có đau không?**
Hiện nay nội soi đại tràng là phương pháp tối ưu nhất giúp phát hiện và chẩn đoán các bệnh lý tại ruột già. Khi thấy bản thân gặp các dấu hiệu về đường tiêu hóa như: Thường đau quặn bụng, sụt cân không rõ nguyên nhân, hình dáng phân bất thường thì cần tới bệnh viện càng sớm càng tốt.
Tuy là phương pháp được sử dụng rộng rãi và phổ biến nhưng không ít người vẫn còn lo sợ không biết nội soi đại tràng có đau không?
Khung đại tràng bắt đầu từ manh tràng tới đại tràng phải, đại tràng ngang, đại tràng trái, kế tiếp là đại tràng Sigma và cuối cùng là trực tràng. Tại đại tràng có nhiều nếp gấp vì vậy khi ống nội soi đi qua sẽ dễ chạm vào các nếp gấp gây cảm giác đau nhói, khó chịu.
Nếu khu vực đại tràng đang bị tổn thương, viêm nhiễm nặng thì việc nội soi sẽ càng gây đau đớn. Nguyên nhân là do sự cọ xát của ống nội soi tới các vị trí đang bị tổn thương. Ngược lại, nếu đại tràng của người bệnh không bị tổn thương và người bệnh hợp tác cùng bác sĩ thì quá trình nội soi sẽ nhẹ nhàng, không gây đau đớn.
Hiện nay ngoài nội soi đại tràng truyền thống có nội soi đại tràng gây mê. Với phương pháp này bệnh nhân hoàn toàn sẽ không cảm thấy đau đớn trong và sau khi thực hiện nội soi.
**Nội soi đại tràng có đau không? Điều này còn phụ thuộc vào nhiều yếu tố**
## **3. Những điều cần làm để giảm đau khi nội soi**
Quy trình khám nội soi đại tràng có đau không? Như đã phân tích ở trên, việc nội soi bị đau hay không còn phụ thuộc vào nhiều yếu tố. Tuy nhiên dù ít hay nhiều thì bệnh nhân cũng sẽ có cảm giác hơi khó chịu, căng tức. Mặc dù vậy thì nội soi đại tràng vẫn là sự lựa chọn tốt nhất giúp phát hiện và chẩn đoán bệnh lý sớm, chính xác.
Để hạn chế sự khó chịu, đau đớn bạn nên thực hiện theo một số lời khuyên dưới đây. Chúng sẽ giúp bạn cảm thấy nhẹ nhàng, thoải mái hơn trong suốt quá trình nội soi.
### **3.1 Khi thực hiện nội soi đại tràng có đau không? Chuẩn bị tâm lý vững vàng sẽ giúp hạn chế đau đớn**
Nếu quá lo lắng và hồi hộp sẽ càng khiến bạn đau hơn khi nội soi. Vì vậy bạn nên chuẩn bị tâm lý trước khi nội soi. Hãy thả lỏng cơ thể để bác sĩ có thể dễ dàng đưa ống nội soi vào quan sát.
### **3.2 Thông báo cho bác sĩ về tình trạng sức khỏe**
Nếu bạn đang có bất cứ vấn đề gì về sức khỏe cần thông báo cho bác sĩ trước khi quyết định tiến hành nội soi. Một số loại thuốc và bệnh lý sẽ ảnh hưởng tới quá trình nội soi. Vì vậy việc tham khảo ý kiến của bác sĩ là điều cần thiết.
### **3.3 Chuẩn bị sạch đại tràng**
Nội soi đại tràng sẽ diễn ra nhanh hơn nếu đại tràng của bạn sạch sẽ. Nếu đại tràng còn phân hoặc dịch phân sẽ cản trở quan sát các tổn thương. Đồng thời các bác sĩ cũng sẽ mất nhiều thời gian hơn để quan sát. Chính vì vậy bạn cần thực hiện đúng theo các yêu cầu của nhân viên y tế.
### **3.4 Thực hiện đúng mọi chỉ dẫn của bác sĩ**
Không nên làm trái các yêu cầu của bác sĩ. Điều này giúp đảm bảo an toàn, giảm đau cho người bệnh. Bên cạnh đó thì việc làm theo hướng dẫn của bác sĩ sẽ giúp mang lại kết quả chính xác khi nội soi.
### **3.5 Lựa chọn cơ sở y tế uy tín**
Chọn đúng nơi khám bệnh cũng là lưu ý vô cùng quan trọng. Hiện nay các cơ sở y tế rất nhiều, tuy nhiên không phải cơ sở nào cũng đủ điều kiện để tiến hành nội soi. Hơn thế nữa, bác sĩ, kỹ thuật viên chuyên môn và kinh nghiệm không cao cũng sẽ dễ gây đau đớn cho bệnh nhân. Nghiêm trọng hơn, nếu các bác sĩ hoặc kỹ thuật viên thực hiện sai kỹ thuật có thể dẫn tới các biến chứng nguy hiểm. Vì vậy bạn nên tìm đến các bệnh viện công hoặc các bệnh viện tư lớn có uy tín.
**Lựa chọn nội soi ở các bệnh viện lớn, uy tín sẽ phần nào giúp bạn tránh những đau đớn và rủi ro không đáng có**
Sau khi hiểu rõ nội soi đại tràng có đau không hẳn các bạn đã không còn lo lắng khi phải đi khám. Vì vậy nếu nghi ngờ đại tràng của mình đang có vấn đề bạn nên tới bệnh viện để thăm khám ngay. Phát hiện ra bệnh càng sớm thì cơ hội chữa khỏi bệnh lại càng cao.
**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/) **- Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [1. Nội soi đại tràng là gì?](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-dai-trang-co-dau-khong-va-nhung-luu-y-quan-trong#1-ni-soi-i-trng-l-g)
  * [1.2 Khám nội soi đại tràng có đau không? Quy trình thực hiện](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-dai-trang-co-dau-khong-va-nhung-luu-y-quan-trong#12-khm-ni-soi-i-trng-c-au-khng-quy-trnh-thc-hin)
  * [2. Nội soi đại tràng có đau không?](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-dai-trang-co-dau-khong-va-nhung-luu-y-quan-trong#2-ni-soi-i-trng-c-au-khng)
  * [3. Những điều cần làm để giảm đau khi nội soi](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-dai-trang-co-dau-khong-va-nhung-luu-y-quan-trong#3-nhng-iu-cn-lm-gim-au-khi-ni-soi)
  * [3.1 Khi thực hiện nội soi đại tràng có đau không? Chuẩn bị tâm lý vững vàng sẽ giúp hạn chế đau đớn](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-dai-trang-co-dau-khong-va-nhung-luu-y-quan-trong#31-khi-thc-hin-ni-soi-i-trng-c-au-khng-chun-b-tm-l-vng-vng-s-gip-hn-ch-au-n)
  * [3.2 Thông báo cho bác sĩ về tình trạng sức khỏe](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-dai-trang-co-dau-khong-va-nhung-luu-y-quan-trong#32-thng-bo-cho-bc-s-v-tnh-trng-sc-khe)
  * [3.3 Chuẩn bị sạch đại tràng](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-dai-trang-co-dau-khong-va-nhung-luu-y-quan-trong#33-chun-b-sch-i-trng)
  * [3.4 Thực hiện đúng mọi chỉ dẫn của bác sĩ](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-dai-trang-co-dau-khong-va-nhung-luu-y-quan-trong#34-thc-hin-ng-mi-ch-dn-ca-bc-s)
  * [3.5 Lựa chọn cơ sở y tế uy tín](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-dai-trang-co-dau-khong-va-nhung-luu-y-quan-trong#35-la-chn-c-s-y-t-uy-tn)



## ️ Bỏ túi kinh nghiệm nội soi dạ dày đại tràng

  * [1. Nội soi dạ dày và nội soi đại tràng là gì?](https://bvnguyentriphuong.com.vn/noi-soi/bo-tui-kinh-nghiem-noi-soi-da-day-dai-trang#1-ni-soi-d-dy-v-ni-soi-i-trng-l-g)
  * [1.1. Nội soi dạ dày](https://bvnguyentriphuong.com.vn/noi-soi/bo-tui-kinh-nghiem-noi-soi-da-day-dai-trang#11-ni-soi-d-dy)
  * [1.2. Nội soi đại tràng](https://bvnguyentriphuong.com.vn/noi-soi/bo-tui-kinh-nghiem-noi-soi-da-day-dai-trang#12-ni-soi-i-trng)
  * [2. Khi nào nên nội soi dạ dày – đại tràng?](https://bvnguyentriphuong.com.vn/noi-soi/bo-tui-kinh-nghiem-noi-soi-da-day-dai-trang#2-khi-no-nn-ni-soi-d-dy-i-trng)
  * [3. Hướng dẫn chuẩn bị nội soi tiêu hóa](https://bvnguyentriphuong.com.vn/noi-soi/bo-tui-kinh-nghiem-noi-soi-da-day-dai-trang#3-hng-dn-chun-b-ni-soi-tiu-ha)
  * [3.1. Trước nội soi](https://bvnguyentriphuong.com.vn/noi-soi/bo-tui-kinh-nghiem-noi-soi-da-day-dai-trang#31-trc-ni-soi)
  * [3.2. Trong quá trình nội soi](https://bvnguyentriphuong.com.vn/noi-soi/bo-tui-kinh-nghiem-noi-soi-da-day-dai-trang#32-trong-qu-trnh-ni-soi)
  * [4. Sau nội soi cần lưu ý gì?](https://bvnguyentriphuong.com.vn/noi-soi/bo-tui-kinh-nghiem-noi-soi-da-day-dai-trang#4-sau-ni-soi-cn-lu-g)
  * [4.1. Sau nội soi không gây mê](https://bvnguyentriphuong.com.vn/noi-soi/bo-tui-kinh-nghiem-noi-soi-da-day-dai-trang#41-sau-ni-soi-khng-gy-m)
  * [4.2. Sau nội soi gây mê](https://bvnguyentriphuong.com.vn/noi-soi/bo-tui-kinh-nghiem-noi-soi-da-day-dai-trang#42-sau-ni-soi-gy-m)
  * [4.3. Chế độ ăn sau nội soi](https://bvnguyentriphuong.com.vn/noi-soi/bo-tui-kinh-nghiem-noi-soi-da-day-dai-trang#43-ch-n-sau-ni-soi)
  * [5. Lợi ích của nội soi dạ dày – đại tràng cùng lúc](https://bvnguyentriphuong.com.vn/noi-soi/bo-tui-kinh-nghiem-noi-soi-da-day-dai-trang#5-li-ch-ca-ni-soi-d-dy-i-trng-cng-lc)
  * [6. Khi nào cần liên hệ lại bác sĩ sau nội soi?](https://bvnguyentriphuong.com.vn/noi-soi/bo-tui-kinh-nghiem-noi-soi-da-day-dai-trang#6-khi-no-cn-lin-h-li-bc-s-sau-ni-soi)


### **1. Nội soi dạ dày và nội soi đại tràng là gì?**
#### **1.1. Nội soi dạ dày**
Là thủ thuật sử dụng ống soi mềm có gắn camera đưa qua đường **miệng hoặc mũi** để quan sát thực quản, dạ dày và tá tràng. Mục tiêu nhằm phát hiện các bất thường như: viêm loét, polyp, nhiễm khuẩn _H. pylori_ , hoặc khối u.
**Nội soi dạ dày và nội soi đại tràng sẽ có những điểm khác nhau**
#### **1.2. Nội soi đại tràng**
Là thủ thuật sử dụng ống nội soi đưa qua **đường hậu môn** , đi qua trực tràng và đại tràng nhằm phát hiện các tổn thương: viêm loét, polyp, u lành – ác tính, hoặc các dấu hiệu viêm ruột mạn tính.
**Nội soi kép (dạ dày và đại tràng cùng lúc)** : được chỉ định khi cần khảo sát toàn bộ đường tiêu hóa, giúp **tiết kiệm thời gian, chi phí và phát hiện sớm bệnh lý tiêu hóa.**
### **2. Khi nào nên nội soi dạ dày – đại tràng?**
  * Đau vùng thượng vị, đầy bụng, khó tiêu, ợ hơi, buồn nôn.
  * Rối loạn tiêu hóa kéo dài, sụt cân không rõ nguyên nhân.
  * Đại tiện phân đen, phân nhầy máu, tiêu chảy hoặc táo bón kéo dài.
  * Có tiền sử gia đình mắc ung thư tiêu hóa hoặc polyp đại tràng.
  * **Tầm soát định kỳ** : người ≥ 40 tuổi, đặc biệt có yếu tố nguy cơ.


**Quá trình nội soi kéo dài nhanh hay chậm còn phụ thuộc vào từng trường hợp**
### **3. Hướng dẫn chuẩn bị nội soi tiêu hóa**
#### **3.1. Trước nội soi**
  * **Thông báo với bác sĩ nếu** :
    * Đang dùng thuốc (kháng đông, chống viêm...).
    * Có dị ứng thuốc gây mê/gây tê.
    * Có tiền sử chảy máu, rối loạn đông máu, tim mạch, thai kỳ…
    * Đã từng nội soi trong thời gian gần đây.
  * **Chế độ ăn** :
    * Tránh ăn thực phẩm khó tiêu (rau sống, thịt đỏ...) ít nhất 2 ngày trước.
    * Trước ngày nội soi: ăn lỏng (cháo, súp), **không dùng nước có màu, cà phê, rượu bia**.
    * Nhịn ăn uống tối thiểu **6 giờ** trước khi nội soi (đối với dạ dày), theo chỉ dẫn.
  * **Đối với nội soi đại tràng** :
    * Cần **dùng thuốc làm sạch đại tràng** theo chỉ định (Polyethylene Glycol hoặc tương đương).
    * Uống đủ lượng nước để đạt hiệu quả làm sạch và tránh mất nước.
    * Có thể thực hiện việc làm sạch tại nhà theo hướng dẫn của bệnh viện.


#### **3.2. Trong quá trình nội soi**
  * **Trang phục** : mặc đồ bệnh viện, tháo phụ kiện kim loại.
  * **Tư thế nội soi** : nằm nghiêng trái, gập gối để thuận lợi cho thao tác nội soi.
  * **Gây mê hay không** : có thể lựa chọn nội soi gây mê để giảm cảm giác khó chịu (buồn nôn, căng tức...).
  * **Kỹ thuật bổ sung** :
    * Sinh thiết mô nghi ngờ, cắt polyp, lấy mẫu vi sinh nếu cần.
    * Thời gian nội soi: thường khoảng **15–30 phút/lần** , tùy tình trạng.


### **4. Sau nội soi cần lưu ý gì?**
#### **4.1. Sau nội soi không gây mê**
  * Có thể ra về sau khoảng 30–60 phút nếu không có bất thường.


#### **4.2. Sau nội soi gây mê**
  * Nên **có người thân đi cùng**.
  * Không tự lái xe hoặc vận hành máy móc trong vòng 12 giờ sau thủ thuật.
  * Có thể cảm thấy **đầy hơi, xì hơi, hoặc đau nhẹ bụng** , sẽ tự khỏi sau vài giờ.


#### **4.3. Chế độ ăn sau nội soi**
  * Ăn nhẹ, dễ tiêu (cháo, súp), chia nhỏ bữa ăn trong ngày đầu.
  * Uống nhiều nước, tránh rượu bia, cà phê, thực phẩm cay nóng hoặc chiên xào.


### **5. Lợi ích của nội soi dạ dày – đại tràng cùng lúc**
  * **Phát hiện sớm các bệnh lý tiêu hóa** như viêm loét, polyp, ung thư.
  * **Tiết kiệm thời gian, chi phí** , đặc biệt khi sử dụng gây mê chung.
  * **Tăng khả năng phát hiện tổn thương đồng thời ở dạ dày và đại tràng.**


**Khuyến nghị tầm soát định kỳ** :
  * 1 năm/lần nếu có tiền sử polyp hoặc bệnh lý đường tiêu hóa.
  * Mỗi 2–3 năm với người ≥ 40 tuổi không có triệu chứng.


**Kinh nghiệm nội soi dạ dày đại tràng là nên thực hiện cùng lúc để giảm sự đau đớn khó chịu cho bệnh nhân**
### **6. Khi nào cần liên hệ lại bác sĩ sau nội soi?**
Liên hệ ngay khi có các dấu hiệu bất thường:
  * Đau bụng tăng dần, không giảm sau 24 giờ.
  * Sốt, ớn lạnh, chảy máu hậu môn hoặc nôn ra máu.
  * Chóng mặt, choáng váng, khó thở.


**Lời khuyên** : Đừng vì cảm giác sợ hãi hoặc ngại ngùng mà trì hoãn nội soi – đây là **phương pháp an toàn, hiệu quả, giúp phát hiện sớm nhiều bệnh lý nguy hiểm.** Hãy chủ động khám và tầm soát định kỳ để bảo vệ sức khỏe hệ tiêu hóa của chính mình.
**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/) **- Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [1. Nội soi dạ dày và nội soi đại tràng là gì?](https://bvnguyentriphuong.com.vn/noi-soi/bo-tui-kinh-nghiem-noi-soi-da-day-dai-trang#1-ni-soi-d-dy-v-ni-soi-i-trng-l-g)
  * [1.1. Nội soi dạ dày](https://bvnguyentriphuong.com.vn/noi-soi/bo-tui-kinh-nghiem-noi-soi-da-day-dai-trang#11-ni-soi-d-dy)
  * [1.2. Nội soi đại tràng](https://bvnguyentriphuong.com.vn/noi-soi/bo-tui-kinh-nghiem-noi-soi-da-day-dai-trang#12-ni-soi-i-trng)
  * [2. Khi nào nên nội soi dạ dày – đại tràng?](https://bvnguyentriphuong.com.vn/noi-soi/bo-tui-kinh-nghiem-noi-soi-da-day-dai-trang#2-khi-no-nn-ni-soi-d-dy-i-trng)
  * [3. Hướng dẫn chuẩn bị nội soi tiêu hóa](https://bvnguyentriphuong.com.vn/noi-soi/bo-tui-kinh-nghiem-noi-soi-da-day-dai-trang#3-hng-dn-chun-b-ni-soi-tiu-ha)
  * [3.1. Trước nội soi](https://bvnguyentriphuong.com.vn/noi-soi/bo-tui-kinh-nghiem-noi-soi-da-day-dai-trang#31-trc-ni-soi)
  * [3.2. Trong quá trình nội soi](https://bvnguyentriphuong.com.vn/noi-soi/bo-tui-kinh-nghiem-noi-soi-da-day-dai-trang#32-trong-qu-trnh-ni-soi)
  * [4. Sau nội soi cần lưu ý gì?](https://bvnguyentriphuong.com.vn/noi-soi/bo-tui-kinh-nghiem-noi-soi-da-day-dai-trang#4-sau-ni-soi-cn-lu-g)
  * [4.1. Sau nội soi không gây mê](https://bvnguyentriphuong.com.vn/noi-soi/bo-tui-kinh-nghiem-noi-soi-da-day-dai-trang#41-sau-ni-soi-khng-gy-m)
  * [4.2. Sau nội soi gây mê](https://bvnguyentriphuong.com.vn/noi-soi/bo-tui-kinh-nghiem-noi-soi-da-day-dai-trang#42-sau-ni-soi-gy-m)
  * [4.3. Chế độ ăn sau nội soi](https://bvnguyentriphuong.com.vn/noi-soi/bo-tui-kinh-nghiem-noi-soi-da-day-dai-trang#43-ch-n-sau-ni-soi)
  * [5. Lợi ích của nội soi dạ dày – đại tràng cùng lúc](https://bvnguyentriphuong.com.vn/noi-soi/bo-tui-kinh-nghiem-noi-soi-da-day-dai-trang#5-li-ch-ca-ni-soi-d-dy-i-trng-cng-lc)
  * [6. Khi nào cần liên hệ lại bác sĩ sau nội soi?](https://bvnguyentriphuong.com.vn/noi-soi/bo-tui-kinh-nghiem-noi-soi-da-day-dai-trang#6-khi-no-cn-lin-h-li-bc-s-sau-ni-soi)



## ️ Giới thiệu Khoa Nội soi tiêu hóa Bệnh viện Nguyễn Tri Phương

  * [I. Lãnh đạo Khoa Nội soi tiêu hóa](https://bvnguyentriphuong.com.vn/noi-soi/gioi-thieu-khoa-noi-soi-tieu-hoa-benh-vien-nguyen-tri-phuong#i-lnh-o-khoa-ni-soi-tiu-ha)
  * [2. Phó trưởng khoa BS CK1 ĐẶNG LÊ BÍCH NGỌC](https://bvnguyentriphuong.com.vn/noi-soi/gioi-thieu-khoa-noi-soi-tieu-hoa-benh-vien-nguyen-tri-phuong#2-ph-trng-khoa-bs-ck1-ng-l-bch-ngc)
  * [3. Điều dưỡng trưởng: ĐD CK1 BIỆN THỊ NGỌC THẢO](https://bvnguyentriphuong.com.vn/noi-soi/gioi-thieu-khoa-noi-soi-tieu-hoa-benh-vien-nguyen-tri-phuong#3-iu-dng-trng-d-ck1-bin-th-ngc-tho)
  * [II. Giới thiệu Khoa Nội soi tiêu hóa](https://bvnguyentriphuong.com.vn/noi-soi/gioi-thieu-khoa-noi-soi-tieu-hoa-benh-vien-nguyen-tri-phuong#ii-gii-thiu-khoa-ni-soi-tiu-ha)
  * [2. Thế mạnh của khoa: ](https://bvnguyentriphuong.com.vn/noi-soi/gioi-thieu-khoa-noi-soi-tieu-hoa-benh-vien-nguyen-tri-phuong#2-th-mnh-ca-khoa)


## **I. Lãnh đạo Khoa Nội soi tiêu hóa**
**1. Trưởng khoa: BS CKII TRẦN NGỌC LƯU PHƯƠNG**
Quá trình học vấn:
  * Tốt nghiệp BS đa khoa: 1996 
  * Chứng chỉ Nội soi Tiêu hóa: 2000 
  * Tốt nghiệp BS nội trú (Nội Tổng quát): 2001 
  * Tốt nghiệp Thạc sĩ y học (Nội khoa): 2005
  * Tốt nghiệp BS chuyên khoa cấp 2 (Nội Tiêu Hóa – Gan Mật) : 2014 
  * Giảng viên - Bộ môn Nội tổng quát – Phân môn tiêu hóa, gan mật - Đại Học Y Khoa Phạm Ngọc Thạch
  * Giảng viên thỉnh giảng – Nội soi tiêu hóa - Đại Học Y Dược TP Hồ Chí Minh
  * Giảng viên thỉnh giảng - Bộ môn Nội tổng quát – Khoa Y - Đại Học Tân Tạo
  * Tu nghiệp tại Singapore (Singapore General Hospital): 2005
  * Tu nghiệp tại Úc (Concord Hospital, University of Sydney): 2010 


Chuyên sâu về :
  * Chẩn đoán và điều trị nội khoa các bệnh lý chuyên sâu về tiêu hóa và gan mật 
  * Nôi soi dạ dày và đại tràng (ruột già) giúp chẩn đoán và can thiêp qua nôi soi các bệnh lý của dạ dày và ruôt già mà không cần phẫu thuật 


Chức vụ hiện tại :
  * Trưởng khoa Nôi soi tiêu hóa, bệnh viện Nguyễn Tri Phương
  * Ủy viên Ban Chấp Hành Hội Tiêu hóa Việt Nam
  * Ủy viên Ban Chấp Hành Liên chi hội Nội soi tiêu hóa Việt Nam


### **2. Phó trưởng khoa BS CK1 ĐẶNG LÊ BÍCH NGỌC**
Quá trình học vấn:
  * Tốt nghiệp BS đa khoa: 2009
  * Tốt nghiệp BS chuyên khoa cấp 1 (Nội Tổng quát): 2018


Số năm làm việc ở BV: 12 năm
### **3. Điều dưỡng trưởng: ĐD CK1 BIỆN THỊ NGỌC THẢO**
Số năm làm việc ở BV: 25 năm
## **II. Giới thiệu Khoa Nội soi tiêu hóa**
### **1. Nhiêm vụ:**
  * **Về chuyên môn:**


Chẩn đoán và điều trị qua **_NỘI SOI CẤP CỨU_** cho các bệnh lý chuyên khoa Tiêu hóa,gan mật như: xuất huyết tiêu hóa trên, xuất huyết tiêu hóa trên dưới, vỡ giãn tĩnh mạch thưc quản-dạ dày, hóc xương, hóc/kẹt dị vật đường tiêu hóa, ….. 
Chẩn đoán và điều trị qua nội soi cho các bệnh lý chuyên khoa Tiêu hóa, gan mật như: viêm loét dạ dày, trào ngược dạ dày thực quản, viêm loét đai tràng,u lành (polyp) thực quản – dạ dày - ruột, ung thư thực quản - dạ dày – ruột, hẹp thưc quản, mở thông dạ dày ra da, đặt giá đỡ ống thông (stent) đường tiêu hóa trong các trương hợp ung thư tiêu hóa, ung thư sớm dạ dày-ruột.
  * **Về đào tạo:**


Là khoa thực hiện mô hình Viện-Trường trở thành nơi đào tạo thực hành cho BS chuyên khoa sau đại học và kỹ thuật viên nội soi của Đại Học Y Khoa Phạm Ngọc Thạch.
  * **Về Nghiên cứu khoa học:**


Sáng kiến, cải tiến, áp dụng, đánh giá hiệu quả của kỹ thuật tiên tiến trên thế giới tại khoa Nội Soi Tiêu Hóa nhằm đem lại cho bệnh nhân những lợi ích cao nhất 
### **2. Thế mạnh của khoa:**
**Về nhân sự:**
100% các BS công tác tại khoa đều có bằng đào tạo sau đại học (BS CK1, BS CKII, Thạc sĩ).
Các điều dưỡng trong khoa đều đươc đào tạo và câp nhật chuyên môn hàng năm và có nhiều kinh nghiệm trong việc phối hợp hỗ trợ BS (làm việc theo ê-kíp)
Khoa đươc dẫn dắt bởi BS Trưởng Khoa đồng thời là giảng viên Đại học y khoa Phạm Ngọc Thạch với nhiều ưu điểm:
  * Nhiều kinh nghiệm(trên 20 năm) trong lãnh vưc điều trị bệnh lý tiêu hóa-gan mât và nội soi tiêu hóa, thường xuyên tham gia các Hội nghị quôc tế nhằm cập nhật các kiến thức mới nhất.
  * Có nhiều đề tài nghiên cứu đã công bố trên các tap chí chuyên ngành y khoa. 
  * Luôn động viên khuyến khích và hướng dẫn, giảng dạy cho các BS trong khoa những kiến thức y khoa mới cập nhật giúp phục vụ bệnh nhân ngày càng tốt hơn.
  * Vui tính, hòa đồng, đam mê, nhiệt tình với các bênh nhân và các BS đàn em.
  * Là một trong những chuyên gia tư vấn sức khỏe khá “hot” trên truyền thông với phong cách tư vấn hóm hỉnh, dễ hiểu và vui tính.


**Về chuyên môn:**
  * Cung cấp “DỊCH VỤ NỘI SOI KHÔNG ĐAU”: êm ái-nhẹ nhàng-chính xác-kế hoạch theo dõi bệnh lý sau nội soi.
  * Tìm- Phân Loại -Theo dõi các bệnh lý tiền ung thư tiêu hóa (tiềm năng ung thư tăng dần theo thời gian) như : Barrett’s thực quản, viêm teo niêm mạc dạ dày, viêm chuyển sản ruột niêm mạc dạ dày, polyp đường tiêu hóa.
  * Tầm soát – Phát hiện các ung thư sớm ở đường tiêu hóa.
  * Dùng kỹ thuật cắt niêm mạc nội soi điều trị ung thư sớm đường tiêu hóa kích thước nhỏ không phải phẫu thuật 
  * Cắt polyp (u lành) to, phức tạp, nhiều polyp ở đường tiêu hóa. 
  * Chẩn đoán- Điều trị-Theo dõi xuất huyết tiêu hóa tái phát nhiều lần.
  * Kỹ thuật mới Đốt Laser Argon điều trị dị dạng mạch máu tiêu hóa hoặc xuất huyêt tiêu hóa rỉ rả.
  * Mở thông dạ dày nuôi ăn qua nội soi trên bệnh nhân nuốt khó, viêm phổi hít sau tai biến mạch máu não, suy kiệt.
  * Nong hẹp thực quản - tâm vị.
  * Phân tích chuyên sâu vi trùng H.P (là loai vi khuẩn gây viêm loét dạ dày và có thể dẫn đến ung thư dạ dày): kháng thuốc, độ nhạy kháng sinh, độc lực của vi trùng, đột biên gen CYP2C19 có thể ảnh hưởng kết quả điều trị.


**Hướng phát triển:**
  * Nội soi mật – tụy (ERCP)
  * Bóc tách ung thư sớm qua nội soi (ESD)
  * Nội soi siêu âm (EUS) 


**Bệnh viện Nguyễn Tri Phương** - Bệnh viện Đa khoa Hạng I Thành phố Hồ Chí Minh
[facebook.com/BVNTP](http://facebook.com/BVNTP)
  * [I. Lãnh đạo Khoa Nội soi tiêu hóa](https://bvnguyentriphuong.com.vn/noi-soi/gioi-thieu-khoa-noi-soi-tieu-hoa-benh-vien-nguyen-tri-phuong#i-lnh-o-khoa-ni-soi-tiu-ha)
  * [2. Phó trưởng khoa BS CK1 ĐẶNG LÊ BÍCH NGỌC](https://bvnguyentriphuong.com.vn/noi-soi/gioi-thieu-khoa-noi-soi-tieu-hoa-benh-vien-nguyen-tri-phuong#2-ph-trng-khoa-bs-ck1-ng-l-bch-ngc)
  * [3. Điều dưỡng trưởng: ĐD CK1 BIỆN THỊ NGỌC THẢO](https://bvnguyentriphuong.com.vn/noi-soi/gioi-thieu-khoa-noi-soi-tieu-hoa-benh-vien-nguyen-tri-phuong#3-iu-dng-trng-d-ck1-bin-th-ngc-tho)
  * [II. Giới thiệu Khoa Nội soi tiêu hóa](https://bvnguyentriphuong.com.vn/noi-soi/gioi-thieu-khoa-noi-soi-tieu-hoa-benh-vien-nguyen-tri-phuong#ii-gii-thiu-khoa-ni-soi-tiu-ha)
  * [2. Thế mạnh của khoa: ](https://bvnguyentriphuong.com.vn/noi-soi/gioi-thieu-khoa-noi-soi-tieu-hoa-benh-vien-nguyen-tri-phuong#2-th-mnh-ca-khoa)



## Xử lý dụng cụ phẫu thuật nội soi

  * [Nguyên tắc xử lý dụng cụ phẫu thuật nội soi ](https://bvnguyentriphuong.com.vn/noi-soi/xu-ly-dung-cu-phau-thuat-noi-soi#nguyn-tc-x-l-dng-c-phu-thut-ni-soi)
  * [Phương tiện để xử lý dụng cụ PT nội soi](https://bvnguyentriphuong.com.vn/noi-soi/xu-ly-dung-cu-phau-thuat-noi-soi#phng-tin-x-l-dng-c-pt-ni-soi)
  * [Quy trình kiểm tra, giám sát chất lượng xử lý dụng cụ PT nội soi](https://bvnguyentriphuong.com.vn/noi-soi/xu-ly-dung-cu-phau-thuat-noi-soi#quy-trnh-kim-tra-gim-st-cht-lng-x-l-dng-c-pt-ni-soi)


## Đại cương
Từ trường hợp cắt túi mật nội soi đầu tiên được Phillipe Mouret thực hiện năm 1987, phẫu thuật (PT) nội soi ngày nay đang được phát triển rộng trong nhiều lĩnh vực ngoại khoa, sản phụ khoa, không những can thiệp các cơ quan trong ổ bụng mà ngay cả các cơ quan trong lồng ngực, các ổ khớp, vùng cổ, tai mũi họng. Ưu điểm của phương pháp PT nội soi như hạn chế chấn thương mô, độ chính xác cao, người bệnh (NB) hồi phục nhanh, rút ngắn thời gian nằm viện, vết mổ thẩm mỹ.
Tại Việt nam, từ lúc bắt đầu những trường hợp mổ nội soi đầu tiên ở các trung tâm lớn tại thành phố Hồ Chí Minh và Hà Nội vào những năm 1992-1993, đến nay hầu hết các bệnh viện (BV) trong cả nước đều đã và đang áp dụng kỹ thuật mổ nội soi trong thực hành điều trị cho người bệnh.
Khác với các dụng cụ sử dụng trong PT hở, các dụng cụ sử dụng trong PT nội soi thường làm bằng vật liệu không chịu nhiệt do đó phải tuần thủ quy trình xử lý dụng cụ không chịu nhiệt. Dụng cụ PT nội soi do đó thường được khuyến cáo tốt nhất nên tiệt khuẩn bằng máy tiệt khuẩn nhiệt độ thấp. Tuy nhiên, tại Việt Nam, số lượng các BV có trang bị máy tiệt khuẩn nhiệt độ thấp không nhiều, số lượng dụng cụ không được trong bị đủ, nên dụng cụ thường được ngâm hóa chất khử khuẩn tại phòng mổ thay vì vận chuyển đi tiệt khuẩn. Khi thực hiện quy trình ngâm hóa chất, nhiều BV thực hiện không đúng quy trình như không kiểm soát hiệu lực diệt khuẩn của hóa chất, ngâm không đủ thời gian, tráng dụng cụ sau ngâm hóa chất bằng nước cất không bảo đảm vô khuẩn.
Quy trình xử lý dụng cụ nội soi không đúng có thể là nguồn gốc gây ra nhiễm khuẩn hoặc những vụ dịch trong BV, gây hậu quả nghiêm trọng làm ảnh hưởng đến chất lượng điều trị NB. Nhiều vụ dịch nhiễm khuẩn vết mổ xảy ra liên quan đến việc xử lý dụng cụ PT nội soi không đúng. Một vụ dịch nhiễm khuẩn vết mổ do Mycobacterium chelonae trên 35 NB liên tiếp sau PT nội soi ổ bụng được báo cáo do dụng cụ khử khuẩn bằng hóa chất, nước tráng sau xử lý hóa chất bị ô nhiễm. Vụ dịch này chỉ giảm khi bệnh viện thay đổi sang quy trình tiệt khuẩn dụng cụ PT nội soi đúng phương pháp. Một vụ dịch 6 trường hợp bệnh bò điên từ 1953-1980 tại Anh, Pháp và Thụy Sĩ cũng liên quan đến xử lý dụng cụ PT nội soi thần kinh không đúng.
Từ thực trạng xử lý dụng cụ PT nội soi như đã nêu trên, Bộ Y tế đã ban hành hướng dẫn thống nhất trong toàn quốc về xử lý dụng cụ PT nội soi để áp dụng trong mọi cơ sở khám bệnh chữa bệnh có tiến hành PT nội soi.
## Nguyên tắc xử lý dụng cụ phẫu thuật nội soi 
– Dụng cụ PT nội soi được phân loại là nhóm dụng cụ thiết yếu theo phân loại của Spaudling (Bảng 1) và phải được tiệt khuẩn.
– Phương pháp hơi nước là phương pháp tiệt khuẩn tốt nhất cho dụng cụ không bị hư hỏng bởi nhiệt, hơi nước, áp lực hoặc độ ẩm. Đối với những dụng cụ không chịu được nhiệt và độ ẩm, cần sử dụng máy tiệt khuẩn nhiệt độ thấp để tiệt khuẩn.
– Trong trường hợp không có máy tiệt khuẩn, sử dụng hóa chất để tiệt khuẩn: Phải sử dụng hóa chất khử khuẩn đã được chứng minh có thể tiệt khuẩn và không có nguy cơ làm hỏng dụng cụ, với nồng độ và thời gian đủ để tiệt khuẩn.
– Tất cả nhân viên có liên quan đến xử lý dụng cụ PT nội soi cần tuân theo những khuyến cáo và quy trình tiệt khuẩn dụng cụ. Nhân viên phụ trách việc xử lý dụng cụ nên tuân theo hướng dẫn và quy trình để bảo đảm làm sạch và tiệt khuẩn đúng cách.
## **Phương tiện để xử lý dụng cụ PT nội soi**
Dụng cụ PT nội soi cần được xử lý tập trung tại đơn vị Tiệt khuẩn. Đơn vị Tiệt khuẩn phải được thiết kế một chiều, có thông khí sạch thích hợp theo quy định, có đầy đủ hệ thống máy tiệt khuẩn: máy autoclave cho dụng cụ PT nội soi chịu nhiệt, máy tiệt khuẩn nhiệt độ thấp cho những dụng cụ PT nội soi không chịu nhiệt. Trong trường hợp phải xử lý ngâm hóa chất để tiệt khuẩn: – Có buồng xử lý dụng cụ bằng hóa chất riêng. – Buồng xử lý dụng cụ phải thoáng khí, với số luồng khí trao đổi khoảng 10-12 ACH (air change per hour – lượng khí thay đổi/giờ). – Có đầy đủ dung dịch làm sạch, hóa chất khử khuẩn. Hóa chất khử khuẩn phải chứng minh có thể tiệt khuẩn, không gây độc hại cho NB, cho nhân viên y tế xử lý dụng cụ, môi trường và không có nguy cơ làm hỏng dụng cụ (Bảng 2). – Có trang bị hệ thống cung cấp nước sạch, tốt nhất là nước RO (Reverse osmosis: thẩm thấu ngược) hoặc nước khử khoáng. – Có trang bị hệ thống cung cấp nước vô khuẩn: Số lượng vi sinh vật sống phải dưới <10 CFU/100ml và không có vi khuẩn gây bệnh. Sử dụng nước đã được xử lý qua màng siêu lọc có kích thước ≤ 0,2 micron hoặc nước vô khuẩn. – Có chậu ngâm hóa chất đúng quy cách, có nắp đậy và được tiệt khuẩn trước mỗi lần sử dụng.
– Có dụng cụ cọ rửa chuyên dụng cho từng loại dụng cụ. – Có test kiểm tra hiệu lực diệt khuẩn của hóa chất khử khuẩn. – Có phương tiện đóng gói, lưu giữ bảo quản sau xử lý tiệt khuẩn.
## Quy trình kiểm tra, giám sát chất lượng xử lý dụng cụ PT nội soi
Phải kiểm tra giám sát chất lượng xử lý dụng cụ theo đúng hướng dẫn, bao gồm giám sát bằng chỉ thị hóa học và sinh học. Kiểm tra, giám sát quy trình thực hành định kỳ theo bảng kiểm. Kiểm tra vi sinh được thực hiện khi nghi ngờ có dịch nhiễm khuẩn bệnh viện liên quan đến xử lý dụng cụ.
Nếu tái xử lý lại dụng cụ được sản xuất dùng một lần, ví dụ trocard nhựa, các ống thông tĩnh mạch, bệnh viện phải bảo đảm chất lượng của các dụng cụ này khi sử dụng lại. Các yêu cầu của JCI (Joint Commision International) quy định về chất lượng của dụng cụ dùng một lần xử lý để dùng lại như sau: – Có danh mục về dụng cụ sử dụng một lần được phép xử lý để dùng lại. – Có quy định số lần được xử lý lại (<5 lần). – Kiểm tra chất lượng dụng cụ và giám sát tiệt khuẩn thực hiện từng lần xử lý và ghi chép lại.
  * [Nguyên tắc xử lý dụng cụ phẫu thuật nội soi ](https://bvnguyentriphuong.com.vn/noi-soi/xu-ly-dung-cu-phau-thuat-noi-soi#nguyn-tc-x-l-dng-c-phu-thut-ni-soi)
  * [Phương tiện để xử lý dụng cụ PT nội soi](https://bvnguyentriphuong.com.vn/noi-soi/xu-ly-dung-cu-phau-thuat-noi-soi#phng-tin-x-l-dng-c-pt-ni-soi)
  * [Quy trình kiểm tra, giám sát chất lượng xử lý dụng cụ PT nội soi](https://bvnguyentriphuong.com.vn/noi-soi/xu-ly-dung-cu-phau-thuat-noi-soi#quy-trnh-kim-tra-gim-st-cht-lng-x-l-dng-c-pt-ni-soi)



## ️ Nội soi trực tràng: Quy trình và các lưu ý khi thực hiện

  * [1. Kỹ thuật nội soi trực tràng](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-truc-trang-quy-trinh-va-cac-luu-y-khi-thuc-hien#1-k-thut-ni-soi-trc-trng)
  * [2. Chỉ định nội soi trực tràng](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-truc-trang-quy-trinh-va-cac-luu-y-khi-thuc-hien#2-ch-nh-ni-soi-trc-trng)
  * [3. Quy trình thực hiện nội soi](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-truc-trang-quy-trinh-va-cac-luu-y-khi-thuc-hien#3-quy-trnh-thc-hin-ni-soi)
  * [3.1. Chuẩn bị nội soi](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-truc-trang-quy-trinh-va-cac-luu-y-khi-thuc-hien#31-chun-b-ni-soi)
  * [3.2. Tiến hành nội soi trực tràng](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-truc-trang-quy-trinh-va-cac-luu-y-khi-thuc-hien#32-tin-hnh-ni-soi-trc-trng)
  * [4. Nội soi trực tràng cần lưu ý những gì](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-truc-trang-quy-trinh-va-cac-luu-y-khi-thuc-hien#4-ni-soi-trc-trng-cn-lu-nhng-g)
  * [4.1. Lưu ý trước khi nội soi](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-truc-trang-quy-trinh-va-cac-luu-y-khi-thuc-hien#41-lu-trc-khi-ni-soi)
  * [4.2. Lưu ý trong quá trình nội soi trực tràng](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-truc-trang-quy-trinh-va-cac-luu-y-khi-thuc-hien#42-lu-trong-qu-trnh-ni-soi-trc-trng)
  * [4.3. Lưu ý sau khi nội soi](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-truc-trang-quy-trinh-va-cac-luu-y-khi-thuc-hien#43-lu-sau-khi-ni-soi)


## **1. Kỹ thuật nội soi trực tràng**
Trực tràng là đoạn cuối của ruột già, nằm trên hậu môn. Cơ quan này có chức năng lưu trữ và đào thải các chất cặn bã ra ngoài cơ thể.
**Nội soi trực tràng** là thủ thuật y học sử dụng ống nội soi gắn camera và đèn soi qua hậu môn vào trực tràng để kiểm tra. Hình ảnh bên trong trực tràng sẽ được thu nhận bởi camera và hiển thị trên màn hình giúp bác sĩ quan sát trực tiếp. Đây là thăm dò chức năng được đánh giá cao trong việc phát hiện chính xác các bệnh lý trực tràng như: viêm loét, polyp, ung thư trực tràng.
Trước đây, nội soi sử dụng ống cứng có đường kính 1 – 2cm, dài từ 25 – 50cm và dụng cụ bơm hơi bằng tay nhằm làm nở lòng ruột. Tuy nhiên, phương pháp này gặp khó khăn khi cắt polyp. Nguyên nhân là do việc mở nắp kính để đưa dụng cụ vào ống cứng sẽ khiến hơi thoát ra ngoài. Lòng trực tràng xẹp lại nên không ghi được hình, khó quan sát và xử lý tổn thương.
Hiện nay phương pháp được sử dụng phổ biến hơn là nội soi ống mềm, đường kính khoảng 1.3cm, dài khoảng 65cm. Đây là phương pháp sở hữu nhiều ưu điểm, gồm: thuận tiện hơn khi quan sát, không gây tổn thương niêm mạc trực tràng, hạn chế tối đa cảm giác khó chịu.
Nội soi là phương pháp chẩn đoán bệnh trực tràng được đánh giá cao nhờ tính chính xác và quy trình thực hiện đơn giản
## **2. Chỉ định nội soi trực tràng**
Kỹ thuật thăm dò chức năng này được chỉ định để chẩn đoán các bệnh lý như viêm loét trực tràng, polyp, ung thư trực tràng, rò hậu môn,… Đồng thời, nó còn được ứng dụng để theo dõi hiệu quả điều trị các trường hợp đã phẫu thuật vùng trực tràng – hậu môn.
Các trường hợp được chỉ định thực hiện nội soi bao gồm:
– Đau bụng không rõ nguyên nhân, diễn ra trong thời gian dài. Vị trí đau cần chú ý là vùng bụng dưới rốn hoặc vùng bụng bên trái.
– Thường xuyên bị táo bón, và tình trạng táo bón kéo dài lâu ngày.
– Đi ngoài ra máu nhiều lần trong ngày (hơn 2 lần/ngày), mức độ nặng lên theo từng ngày.
– Phân có màng giả, có lẫn máu, chất nhầy, đờm nhớt.
– Thường xuyên có cảm giác đau rát, khó chịu vùng hậu môn khi đại tiện.
– Từng mắc các bệnh lý như: viêm loét trực tràng, polyp đại trực tràng, ung thư trực tràng, viêm loét đại tràng mạn tính, bệnh Crohn.
– Đang bị trĩ (trĩ nội hoặc trĩ ngoại); ngứa hậu môn, rò hoặc nứt hậu môn.
– Kết quả chụp X quang không thể xác định được bất thường tại trực tràng.
– Tiền sử gia đình có người mắc polyp có tính chất gia đình, ung thư trực tràng.
## **3. Quy trình thực hiện nội soi**
Người bệnh nội soi theo 2 công đoạn chính là chuẩn bị và thực hiện nội soi.
### **3.1. Chuẩn bị nội soi**
– Người bệnh thăm khám ban đầu với bác sĩ chuyên khoa Tiêu hóa và được chỉ định phương pháp nội soi phù hợp.
– Chuẩn bị phòng nội soi có đủ các thiết bị, dụng cụ, ánh sáng cần thiết cho quá trình nội soi. Kỹ thuật viên sẽ kiểm tra để đảm bảo máy móc nội soi hoạt động bình thường, ổn định.
– Người bệnh làm sạch trực tràng và hậu môn, giúp ống nội soi dễ dàng đi vào và quan sát bề mặt niêm mạc. Thông thường, trực tràng sẽ được thụt rửa bằng dung dịch chuyên dụng đến khi loại bỏ hết phân trong trực tràng.
### **3.2. Tiến hành nội soi trực tràng**
– Bước 1: Người bệnh nằm nghiêng sang bên trái, bác sĩ kiểm tra bên trong hậu môn của người bệnh. Bác sĩ sẽ xử lý ngay các tổn thương (nếu có) để tránh tình trạng viêm nhiễm.
– Bước 2: Người bệnh được gây tê hoặc sử dụng thuốc giãn cơ, thuốc an thần nhằm ổn định tinh thần và tránh cảm giác đau hay khó chịu.
– Bước 3: Ống nội soi được bôi trơn và đưa từ từ vào hậu môn người bệnh. Sau đó, ống soi di chuyển lên trực tràng, quan sát để phát hiện xác bất thường tại cơ quan này. Bác sĩ sẽ đánh giá tình trạng tổn thương bên trong trực tràng qua hình ảnh thu được. Trong quá trình thực hiện bác sĩ có thể sinh thiết mẫu mô trực tràng để làm xét nghiệm tầm soát ung thư.
– Bước 4: Ống soi được rút ra sau khi đã quan sát toàn bộ trực tràng. Người bệnh ổn định sức khỏe, tỉnh táo và nhận kết quả nội soi. Bên cạnh đó, người bệnh sẽ nhận suất ăn nhẹ để giảm cảm giác đói mệt sau thời gian dài nhịn ăn chuẩn bị cho nội soi.
– Bước 5: Người bệnh quay lại phòng khám ban đầu để được bác sĩ chuyên khoa giải thích kết quả nội soi, đưa ra chẩn đoán và hướng điều trị.
## **4. Nội soi trực tràng cần lưu ý những gì**
### **4.1. Lưu ý trước khi nội soi**
– Người bệnh nên sử dụng thực phẩm mềm, dễ tiêu hóa (như súp, cháo) trong vòng 1 ngày trước khi nội soi. Đồng thời, tránh ăn các thực phẩm khó tiêu; thực phẩm giàu chất xơ (ngũ cốc nguyên cám, nấm, các loại hạt); thực phẩm có màu đỏ (củ dền, gấc).
– Nhịn ăn trong vòng ít nhất 6 giờ trước nội soi, uống nhiều nước (nước lọc, các loại nước không màu) để đường ruột được sạch sẽ.
– Không dùng các chất kích thích như rượu bia, thuốc lá trước nội soi vì có thể ảnh hưởng đến kết quả chẩn đoán.
– Vệ sinh hậu môn, làm sạch trực tràng để đảm bảo hiệu quả quan sát tốt nhất.
– Thông báo cho bác sĩ về các loại thuốc đang sử dụng, các bệnh lý đang gặp phải (đặc biệt là bệnh tim mạch, máu khó đông), tiền sử dị ứng (nếu có).
### **4.2. Lưu ý trong quá trình nội soi trực tràng**
– Người bệnh cần báo ngay với bác sĩ hoặc kỹ thuật viên nếu cảm thấy khó chịu và đau nhiều để được dùng thêm thuốc an thần, giảm đau hoặc dừng nội soi.
– Nếu thấy căng thẳng, khó thở, đau bụng dữ dội, hãy báo ngay cho bác sĩ để được hỗ trợ giải quyết kịp thời.
Hãy thông báo cho bác sĩ về các triệu chứng gặp phải, các loại thuốc đang sử dụng, tiền sử bệnh lý
### **4.3. Lưu ý sau khi nội soi**
– Người bệnh có thể đi lại và về nhà trong ngày sau khi thực hiện nội soi. Trước khi ra về, người bệnh nên nghỉ ngơi trong thời gian ngắn, chờ cho đến khi hết cảm giác khó chịu ở bụng và theo dõi sức khỏe phòng các biến chứng sau nội soi như sốt, chóng mặt, đau nhiều,…
– Cảm giác đau âm ỉ ở bụng, chướng bụng, mót nhưng không đại tiện được, đi ngoài ra máu… là những phản ứng tự nhiên sau khi nội soi và có thể kéo dài từ 1 – 2 ngày.
– Liên hệ ngay với bác sĩ nếu triệu chứng đau và chảy máu kéo dài, tránh những biến chứng không mong muốn.
– Ăn thức ăn mềm, lỏng, dễ tiêu vài ngày sau khi nội soi để tránh các khó khăn khi đại tiện.
– Tránh các loại thực phẩm chua, cay, khó tiêu, đồ ăn nhiều dầu mỡ; nước có gas, rượu bia, cà phê; không hút thuốc lá trong những ngày đầu sau khi nội soi.
**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/) **- Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [1. Kỹ thuật nội soi trực tràng](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-truc-trang-quy-trinh-va-cac-luu-y-khi-thuc-hien#1-k-thut-ni-soi-trc-trng)
  * [2. Chỉ định nội soi trực tràng](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-truc-trang-quy-trinh-va-cac-luu-y-khi-thuc-hien#2-ch-nh-ni-soi-trc-trng)
  * [3. Quy trình thực hiện nội soi](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-truc-trang-quy-trinh-va-cac-luu-y-khi-thuc-hien#3-quy-trnh-thc-hin-ni-soi)
  * [3.1. Chuẩn bị nội soi](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-truc-trang-quy-trinh-va-cac-luu-y-khi-thuc-hien#31-chun-b-ni-soi)
  * [3.2. Tiến hành nội soi trực tràng](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-truc-trang-quy-trinh-va-cac-luu-y-khi-thuc-hien#32-tin-hnh-ni-soi-trc-trng)
  * [4. Nội soi trực tràng cần lưu ý những gì](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-truc-trang-quy-trinh-va-cac-luu-y-khi-thuc-hien#4-ni-soi-trc-trng-cn-lu-nhng-g)
  * [4.1. Lưu ý trước khi nội soi](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-truc-trang-quy-trinh-va-cac-luu-y-khi-thuc-hien#41-lu-trc-khi-ni-soi)
  * [4.2. Lưu ý trong quá trình nội soi trực tràng](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-truc-trang-quy-trinh-va-cac-luu-y-khi-thuc-hien#42-lu-trong-qu-trnh-ni-soi-trc-trng)
  * [4.3. Lưu ý sau khi nội soi](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-truc-trang-quy-trinh-va-cac-luu-y-khi-thuc-hien#43-lu-sau-khi-ni-soi)



## ️ Vai trò của nội soi tiêu hóa trong phát hiện sớm ung thư

  * [1. Khái niệm “nội soi tiêu hóa”](https://bvnguyentriphuong.com.vn/noi-soi/vai-tro-cua-noi-soi-tieu-hoa-trong-phat-hien-som-ung-thu#1-khi-nim-ni-soi-tiu-ha)
  * [2. Các phương pháp nội soi phổ biến hiện nay](https://bvnguyentriphuong.com.vn/noi-soi/vai-tro-cua-noi-soi-tieu-hoa-trong-phat-hien-som-ung-thu#2-cc-phng-php-ni-soi-ph-bin-hin-nay)
  * [2.1. Nội soi tiêu hóa tiêu chuẩn](https://bvnguyentriphuong.com.vn/noi-soi/vai-tro-cua-noi-soi-tieu-hoa-trong-phat-hien-som-ung-thu#21-ni-soi-tiu-ha-tiu-chun)
  * [2.2. Nội soi tiêu hóa không đau](https://bvnguyentriphuong.com.vn/noi-soi/vai-tro-cua-noi-soi-tieu-hoa-trong-phat-hien-som-ung-thu#22-ni-soi-tiu-ha-khng-au)
  * [3. Một số điều cần lưu ý khi thực hiện nội soi](https://bvnguyentriphuong.com.vn/noi-soi/vai-tro-cua-noi-soi-tieu-hoa-trong-phat-hien-som-ung-thu#3-mt-s-iu-cn-lu-khi-thc-hin-ni-soi)
  * [4. Vai trò của nội soi tiêu hóa trong phát hiện ung thư sớm](https://bvnguyentriphuong.com.vn/noi-soi/vai-tro-cua-noi-soi-tieu-hoa-trong-phat-hien-som-ung-thu#4-vai-tr-ca-ni-soi-tiu-ha-trong-pht-hin-ung-th-sm)


Ung thư đường tiêu hóa (gồm ung thư thực quản – dạ dày – tá tràng – đại trực tràng) là nhóm bệnh lý ung thư rất phổ biến hiện nay. Sàng lọc ung thư từ giai đoạn sớm chính là chìa khóa giúp tăng hiệu quả điều trị và ngăn chặn các biến chứng nguy hiểm. Hãy tham khảo bài viết sau để tìm hiểu về vai trò của nội soi tiêu hóa (hay nội soi dạ dày – đại tràng) đối với việc sàng lọc phát hiện sớm ung thư đường tiêu hóa.
## **1. Khái niệm “nội soi tiêu hóa”**
Đây là tên gọi chung của thăm dò chức năng nội soi thực quản – dạ dày – tá tràng – đại tràng và trực tràng. Đây là một trong những kỹ thuật hiện đại nhất hiện nay được ứng dụng phổ biến trong chẩn đoán các bệnh lý tại đường tiêu hóa. Đặc biệt nội soi giúp phát hiện chính xác các bệnh lý nguy hiểm từ giai đoạn sớm như ung thư thực quản, ung thư dạ dày, ung thư đại trực tràng,…
Quá trình nội soi thông thường diễn ra trong khoảng 15 phút. Thời gian thực hiện có thể kéo dài hơn trong một số trường hợp đặc biệt. Chẳng hạn như các trường hợp bác sĩ can thiệp lấy dị vật, nong hẹp, cắt polyp, cầm máu,…
Để tiến hành nội soi dạ dày – đại tràng, bác sĩ sẽ sử dụng một ống nội soi mềm được gắn camera và nguồn sáng. Với nội soi dạ dày, ống nội soi sẽ được đưa vào từ mũi hoặc miệng để quan sát thực quản, dạ dày và tá tràng. Trong khi đó, với nội soi đại tràng, ống nội soi lại đi từ hậu môn lên quan sát đại tràng và trực tràng.
Nhờ camera và nguồn sáng đầu ống nội soi, bác sĩ có thể quan sát trực tiếp lớp niêm mạc ống tiêu hóa. Công nghệ nội soi hiện đại hiện nay giúp bác sĩ phát hiện các tổn thương rất nhỏ. Trong quá trình nội soi, bác sĩ có thể sinh thiết tổn thương nghi ngờ để làm xét nghiệm chẩn đoán vi khuẩn HP hoặc tế bào ung thư.
**Nội soi dạ dày – đại tràng có thể can thiệp điều trị nhiều bệnh lý như: lấy dị vật, cầm máu, nong hẹp, cắt polyp,…**
## **2. Các phương pháp nội soi phổ biến hiện nay**
Có thể chia nội soi dạ dày – đại tràng thành 2 phương pháp chính như sau:
### **2.1. Nội soi tiêu hóa tiêu chuẩn**
Kỹ thuật nội soi tiêu chuẩn được thực hiện khi người bệnh hoàn toàn tỉnh táo, không thực hiện gây mê. Ống nội soi sẽ được đưa từ đường mũi/ miệng hoặc qua đường hậu môn để thăm khám. Quá trình ống nội soi di chuyển có thể khiến người bệnh cảm thấy buồn nôn, khó chịu. Tuy nhiên cảm giác khó chịu sẽ được hạn chế đáng kể nhờ thao tác nhẹ nhàng của bác sĩ và sự hợp tác, tâm lý thoải mái của người bệnh.
### **2.2. Nội soi tiêu hóa không đau**
Lúc này, ống nội soi sẽ được đưa vào dạ dày – đại tràng sau khi người bệnh đã ngủ an thần. Kỹ thuật gây mê trong nội soi là gây mê tĩnh mạch với lượng thuốc mê ít và thời gian gây mê ngắn. Người bệnh ngủ ngon trong suốt quá trình thực hiện và có thể tỉnh táo ngay khi hoàn thành nội soi.
Nội soi không đau mang đến cho người bệnh trải nghiệm êm ái, nhẹ nhàng, không hề đau hay khó chịu. Đồng thời, phương pháp này còn đảm bảo an toàn cho người bệnh, hạn chế các tai biến, đặc biệt là trong trường hợp thực hiện các thủ thuật can thiệp.
## **3. Một số điều cần lưu ý khi thực hiện nội soi**
Nội soi dạ dày – đại tràng là thăm dò chức năng được đánh giá có độ an toàn cao. Do đó, người bệnh có thể yên tâm khi được bác sĩ chỉ định thực hiện kỹ thuật này. Tuy nhiên, người bệnh cần lưu ý thực hiện tại cơ sở y tế uy tín, có đội ngũ bác sĩ giỏi, đầu tư trang thiết bị nội soi, đảm bảo kết quả chính xác và an toàn.
Ngoài ra, người bệnh cần lưu ý một số vấn đề sau để quá trình nội soi diễn ra thuận lợi nhất:
– Vài ngày trước khi nội soi đại tràng, người bệnh nên tránh sử dụng những thực phẩm khó tiêu hoặc nhiều chất xơ. 1 ngày trước ngày nội soi dạ dày – đại tràng, người bệnh không nên sử dụng các loại thức ăn hoặc đồ uống có màu đỏ, vì có thể gây nhầm lẫn với tình trạng xuất huyết tiêu hóa.
– Người bệnh cần nhịn ăn từ 6 giờ đến 8 giờ, nhịn uống ít nhất 2 giờ trước khi nội soi.
– Hãy thông báo với bác sĩ tiền sử dị ứng thuốc, tiền sử bệnh lý của bản thân và các loại thuốc đang sử dụng.
– Giữ tinh thần thoải mái, thư giãn, thực hiện đúng theo hướng dẫn của nhân viên y tế.
– Uống thuốc tan bọt dạ dày trước khi nội soi dạ dày, uống thuốc nhuận tràng mạnh (hoặc thực hiện thụt tháo đại tràng) trước khi nội soi đại tràng. Những việc này nhằm giúp làm sạch niêm mạc đường tiêu hóa, thuận tiện cho bác sĩ quan sát phát hiện các bất thường, tổn thương.
– Sau khi nội soi, người bệnh không nên khạc nhổ, không nên ăn uống các thực phẩm nóng, khó tiêu.
## **4. Vai trò của nội soi tiêu hóa trong phát hiện ung thư sớm**
Nội soi được coi là tiêu chuẩn vàng trong chẩn đoán các bệnh lý tại đường tiêu hóa trên (thực quản, dạ dày tá tràng) và đường tiêu hóa dưới (đại trực tràng, hậu môn). Đặc biệt, nội soi giúp phát hiện sớm và rất sớm ung thư tại các cơ quan này, tăng hiệu quả điều trị.
Cụ thể, ý nghĩa của nội soi trong chẩn đoán sớm ung thư đường tiêu hóa gồm:
– Phát hiện các tổn thương nghi ngờ, tiến hành sinh thiết để xác định sự có mặt của tế bào ung thư.
– Công nghệ nội soi hiện đại (như nội soi dải tần ánh sáng hẹp NBI, nội soi nhuộm màu, nội soi siêu âm) giúp phát hiện ung thư từ khi mới khu trú ở hệ thống mao mạch nuôi dưỡng lớp niêm mạc.
– Tăng hiệu quả điều trị ung thư đường tiêu hóa, kéo dài thời gian sống sau khi điều trị.
– Thực hiện đơn giản, nhanh chóng, bác sĩ có thể can thiệp để loại bỏ tổ chức ung thư ngay trong quá trình nội soi. Điều này giúp người bệnh tránh được các biến chứng nguy hiểm, rút ngắn thời gian hồi phục.
– Nội soi phát hiện sớm ung thư giúp tiết kiệm thời gian và chi phí điều trị bệnh.
## **5. Kết luận**
Như vậy, nội soi tiêu hóa là thăm dò chức năng có vai trò quan trọng trong chẩn đoán các bệnh lý đường tiêu hóa, bao gồm cả ung thư. Mỗi người cần chủ động nội soi ngay khi có triệu chứng bất thường. Bên cạnh đó, bạn cũng nên nội soi định kỳ ngay cả khi không có triệu chứng cảnh báo. Thói quen này giúp kiểm soát hiệu quả sức khỏe dạ dày – đại tràng, phát hiện sớm các bệnh lý, ngăn ngừa các biến chứng nguy hiểm.
**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/) **- Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [1. Khái niệm “nội soi tiêu hóa”](https://bvnguyentriphuong.com.vn/noi-soi/vai-tro-cua-noi-soi-tieu-hoa-trong-phat-hien-som-ung-thu#1-khi-nim-ni-soi-tiu-ha)
  * [2. Các phương pháp nội soi phổ biến hiện nay](https://bvnguyentriphuong.com.vn/noi-soi/vai-tro-cua-noi-soi-tieu-hoa-trong-phat-hien-som-ung-thu#2-cc-phng-php-ni-soi-ph-bin-hin-nay)
  * [2.1. Nội soi tiêu hóa tiêu chuẩn](https://bvnguyentriphuong.com.vn/noi-soi/vai-tro-cua-noi-soi-tieu-hoa-trong-phat-hien-som-ung-thu#21-ni-soi-tiu-ha-tiu-chun)
  * [2.2. Nội soi tiêu hóa không đau](https://bvnguyentriphuong.com.vn/noi-soi/vai-tro-cua-noi-soi-tieu-hoa-trong-phat-hien-som-ung-thu#22-ni-soi-tiu-ha-khng-au)
  * [3. Một số điều cần lưu ý khi thực hiện nội soi](https://bvnguyentriphuong.com.vn/noi-soi/vai-tro-cua-noi-soi-tieu-hoa-trong-phat-hien-som-ung-thu#3-mt-s-iu-cn-lu-khi-thc-hin-ni-soi)
  * [4. Vai trò của nội soi tiêu hóa trong phát hiện ung thư sớm](https://bvnguyentriphuong.com.vn/noi-soi/vai-tro-cua-noi-soi-tieu-hoa-trong-phat-hien-som-ung-thu#4-vai-tr-ca-ni-soi-tiu-ha-trong-pht-hin-ung-th-sm)



## ️ 3 bước tiến lớn của nội soi dạ dày đại tràng hiện đại

  * [Sự ra đời của nội soi không đau](https://bvnguyentriphuong.com.vn/noi-soi/3-buoc-tien-lon-cua-noi-soi-da-day-dai-trang-hien-dai#s-ra-i-ca-ni-soi-khng-au)
  * [Nâng yếu tố “sạch” trong nội soi lên tầm cao mới](https://bvnguyentriphuong.com.vn/noi-soi/3-buoc-tien-lon-cua-noi-soi-da-day-dai-trang-hien-dai#nng-yu-t-sch-trong-ni-soi-ln-tm-cao-mi)
  * [Công nghệ NBI 5P- bước đột phá trong việc phát hiện ung thư từ rất sớm](https://bvnguyentriphuong.com.vn/noi-soi/3-buoc-tien-lon-cua-noi-soi-da-day-dai-trang-hien-dai#cng-ngh-nbi-5p-bc-t-ph-trong-vic-pht-hin-ung-th-t-rt-sm)


## **Sự ra đời của nội soi không đau**
Với phương pháp nội soi truyền thống, bác sĩ sẽ tiến hành đưa ống nội soi vào cơ quan tiêu hóa khi người bệnh vẫn đang tỉnh táo. Nhiều người cảm thấy đau đớn, buồn nôn trong suốt quá trình nội soi. Thậm chí cảm giác đau, khó chịu còn kéo dài nhiều ngày sau đó. Việc này khiến người bệnh trở nên e dè sợ sệt và trì hoãn đi nội soi thăm khám. Nội soi gây mê ra đời được xem là “cứu cánh” cho những người sợ đau.
## **Nâng yếu tố “sạch” trong nội soi lên tầm cao mới**
Theo quy định của Bộ Y Tế, các dụng cụ được sử dụng để đưa vào mô, mạch máu và khoang vô khuẩn trong quá trình nội soi như kìm sinh thiết cần được tiệt khuẩn tuyệt đối để loại bỏ mọi vi sinh vật sống. Những dụng cụ tiếp xúc trực tiếp với niêm mạc hoặc khu vực da như canuyn (miếng cố định miệng mở khi soi dạ dày), ống nội soi phải khử khuẩn ở mức độ cao trước khi tái sử dụng. Trong khi đó, danh sách dụng cụ cần khử khuẩn ở mức độ thấp bao gồm: khay hạt đậu, mặt bàn hay bất cứ bề mặt nào tiếp xúc với da lành,…
## **Công nghệ NBI 5P- bước đột phá trong việc phát hiện ung thư từ rất sớm**
Trước đây, nội soi ánh sáng trắng dừng lại ở việc chỉ điểm các bệnh lý dạ dày như: viêm loét, vi khuẩn HP, polyp,… và ung thư khi chúng đã biểu hiện rõ ràng ở niêm mạc.
Hiện nay việc ứng dụng công nghệ NBI 5P tiên tiến trong nội soi đã phá vỡ giới hạn trên. Chế độ ánh sáng dải tần hẹp cùng khả năng phóng đại hình ảnh 100 lần của NBI 5P giúp bác sĩ không bỏ sót bất cứ tổn thương nào dù là nhỏ nhất. Do đó bác sĩ có thể phát hiện ra bệnh ung thư tiêu hóa từ giai đoạn rất sớm. Chưa hết, với NBI 5P bác sĩ có thể loại bỏ các tổ chức loạn sản dị sản bằng phương pháp cắt hớt niêm mạc (EMR) ngăn chặn nguy cơ ung thư.
**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/) **- Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [Sự ra đời của nội soi không đau](https://bvnguyentriphuong.com.vn/noi-soi/3-buoc-tien-lon-cua-noi-soi-da-day-dai-trang-hien-dai#s-ra-i-ca-ni-soi-khng-au)
  * [Nâng yếu tố “sạch” trong nội soi lên tầm cao mới](https://bvnguyentriphuong.com.vn/noi-soi/3-buoc-tien-lon-cua-noi-soi-da-day-dai-trang-hien-dai#nng-yu-t-sch-trong-ni-soi-ln-tm-cao-mi)
  * [Công nghệ NBI 5P- bước đột phá trong việc phát hiện ung thư từ rất sớm](https://bvnguyentriphuong.com.vn/noi-soi/3-buoc-tien-lon-cua-noi-soi-da-day-dai-trang-hien-dai#cng-ngh-nbi-5p-bc-t-ph-trong-vic-pht-hin-ung-th-t-rt-sm)



## ️ 3 nỗi sợ lớn không của riêng ai khi nội soi dạ dày – đại tràng

  * [Sợ lây nhiễm chéo](https://bvnguyentriphuong.com.vn/noi-soi/3-noi-so-lon-khong-cua-rieng-ai-khi-noi-soi-da-day-dai-trang#s-ly-nhim-cho)


Nội soi dạ dày – đại tràng là phương pháp tốt nhất để chẩn đoán các bệnh lý tiêu hóa, phát hiện sớm ung thư. Song không ít người lại không dám thực hiện vì sợ đau, sợ lây nhiễm chéo và mất thời gian. Tuy nhiên nội soi tiêu hóa không đáng sợ như vậy.
## **Sợ đau**
Lý do hàng đầu khiến nhiều người trì hoãn việc nội soi dạ dày – đại tràng chính là e ngại cảm giác đau, buồn nôn, khó chịu. Thậm chí có người còn khẳng định “dù chết cũng không nội soi lần hai”.
**Nội soi tiêu hóa ám ảnh nhiều người vì trải nghiệm không êm ái.**
## **Sợ lây nhiễm chéo**
Nhiều người lo ngại nội soi dạ dày có nguy cơ lây nhiễm chéo các bệnh truyền nhiễm vì dùng chung dây soi. Hơn nữa còn “sợ bẩn” khi nội soi đại tràng vì đây là nơi chứa chất cặn bã của cơ thể, việc sử dụng chung dây soi sẽ rất mất vệ sinh. Tuy nhiên quan điểm đó hoàn toàn sai lầm. Đại tràng luôn được làm sạch trước khi nội soi bằng thuốc nhuận tràng mạnh. Các dụng cụ y tế sử dụng đều được tiệt khuẩn sạch sẽ, nguy cơ lây nhiễm chéo rất hạn chế. 
Với quy trình này các dụng cụ như kìm sinh thiết, canuyn (miếng cố định giúp miệng mở trong suốt quá trình nội soi), kính oxy được cung cấp 1 bộ riêng biệt cho mỗi người bệnh, không dùng chung, dùng lại. Đồ dùng cá nhân bao gồm quần áo nội soi, khăn, chăn ga trải giường, ca – cốc uống thuốc được thay mới hoàn toàn mỗi khi đón tiếp bệnh nhân mới.
## **Sợ lâu**
Sợ mất thời gian cũng là nỗi lo lắng thường gặp, đặc biệt là ở những người có lịch trình bận rộn.
Có thể thấy, nội soi dạ dày – đại tràng không hề đáng sợ như nhiều người vẫn nghĩ. Do đó đừng để những nỗi lo lắng cản bước bạn thăm khám với phương pháp này, bỏ lỡ cơ hội vàng để phát hiện sớm và điều trị các bệnh lý tiêu hóa.
**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/) **- Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [Sợ lây nhiễm chéo](https://bvnguyentriphuong.com.vn/noi-soi/3-noi-so-lon-khong-cua-rieng-ai-khi-noi-soi-da-day-dai-trang#s-ly-nhim-cho)



## ️Hình ảnh nội soi trực tràng

Nội soi trực tràng là một phương pháp thăm khám trực tiếp phần cuối của đại tràng (ruột già) bao gồm hậu môn, trực tràng. Thông qua các hình ảnh nội soi trực tràng thu được qua màn hình vi tính, bác sĩ sẽ giúp chẩn đoán chính xác tình trạng bệnh.
**Nhiều người thắc mắc không biết nội soi trực tràng áp dụng cho trường hợp nào. Theo các chuyên gia y tế, những người nghi ngờ có vấn đề ở đoạn cuối ống tiêu hóa như đi ngoài ra máu hoặc có tiền sử gia đình bị ung thư trực tràng, hậu môn… thì cần nội soi trực tràng sớm.**
**Trước khi tiến hành nội soi trực tràng người bệnh cần làm sạch ruột bằng cách nhịn ăn, và đi đại tiện sạch để bác sĩ dễ dàng quan sát tổn thương bên trong trực tràng.**
Sau khi được làm sạch ruột, người bệnh được đưa vào phòng nội soi nhằm chuẩn bị cho quá trình nội soi. Hiện có 2 phương pháp nội soi trực tràng là nội soi thường và nội soi gây mê. Tùy vào sự lựa chọn của mỗi người mà bác sĩ sẽ thực hiện phương pháp nội soi an toàn và nhanh chóng.
**Bác sĩ sẽ tiến hành nội soi trực tràng bằng một ống nội soi mềm, có gắn nguồn sáng và camera được đưa vào cơ thể qua lỗ hậu môn. Nhờ quan sát hình ảnh trên máy soi, bác sĩ có thể biết được các bất thường đang xảy ra bên trong ruột, phát hiện sớm các bệnh như viêm nhiễm ở hậu môn trực tràng, polyp hoặc ung thư.**
**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/) **- Đa khoa Hạng I Thành phố Hồ Chí Minh

## ️ Nội soi ổ bụng có đau không? tổn thương tại vùng bụng

  * [1. Nội soi ổ bụng là gì?](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-o-bung-co-dau-khong-ton-thuong-tai-vung-bung#1-ni-soi-bng-l-g)
  * [2. Nội soi ổ bụng có đau không?](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-o-bung-co-dau-khong-ton-thuong-tai-vung-bung#2-ni-soi-bng-c-au-khng)
  * [3. Quy trình thực hiện nội soi ổ bụng](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-o-bung-co-dau-khong-ton-thuong-tai-vung-bung#3-quy-trnh-thc-hin-ni-soi-bng)
  * [4. Ưu điểm của nội soi ổ bụng](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-o-bung-co-dau-khong-ton-thuong-tai-vung-bung#4-u-im-ca-ni-soi-bng)


## **1. Nội soi ổ bụng là gì?**
Nội soi ổ bụng là một phương pháp chẩn đoán và điều trị xâm lấn tối thiểu, sử dụng thiết bị nội soi để quan sát trực tiếp các cơ quan trong khoang bụng. Phương pháp này có thể kết hợp với phẫu thuật để điều trị các bệnh lý liên quan đến các tạng trong ổ bụng, đặc biệt là trong lĩnh vực phụ khoa. Nội soi ổ bụng cho phép bác sĩ kiểm tra các cơ quan trong vùng chậu, như tử cung, buồng trứng và các bộ phận lân cận mà không cần phẫu thuật mở lớn.
Quy trình nội soi ổ bụng thực hiện qua một vết rạch nhỏ trên da, qua đó đưa vào một ống nội soi có gắn camera và nguồn sáng. Thiết bị này cho phép bác sĩ quan sát chi tiết bên trong khoang bụng để xác định nguyên nhân gây bệnh. Nội soi ổ bụng thường được chỉ định khi các phương pháp chẩn đoán khác như siêu âm, X-quang không đủ khả năng xác định nguyên nhân gây triệu chứng.
Nội soi ổ bụng có đau không là thắc mắc chung của nhiều bệnh nhân có chỉ định này.
## **2. Nội soi ổ bụng có đau không?**
Phương pháp nội soi ổ bụng thường được thực hiện dưới tác dụng của gây mê toàn thân, do đó trong quá trình thực hiện, bệnh nhân sẽ không cảm thấy đau đớn. Sau khi hết tác dụng của thuốc mê, bệnh nhân có thể cảm thấy một chút khó chịu hoặc đau nhẹ tại vị trí vết rạch, nhưng triệu chứng này thường sẽ giảm dần và nhanh chóng hết. Vết rạch nhỏ giúp giảm thiểu đau đớn và làm lành vết thương nhanh chóng, đồng thời hạn chế nguy cơ viêm nhiễm. Tuy nhiên, để phòng ngừa viêm nhiễm, bệnh nhân cần duy trì vệ sinh đúng cách tại vùng có vết rạch và tránh các thực phẩm có thể gây cản trở quá trình lành vết thương.
Một số bệnh lý chỉ có thể chẩn đoán chính xác khi cơ quan đó được quan sát trực tiếp.
## **3. Quy trình thực hiện nội soi ổ bụng**
Nội soi ổ bụng thường được thực hiện trong một số tình huống sau:
  * **Phẫu thuật nhỏ (như thắt ống dẫn trứng):** Đối với các thủ thuật nhỏ, bệnh nhân có thể được gây mê dưới màng cứng.
  * **Hầu hết các trường hợp:** Thực hiện gây mê toàn thân.


**Quy trình nội soi ổ bụng:**
  1. **Vết rạch nhỏ:** Bác sĩ thực hiện một vết rạch nhỏ, thường dưới rốn để không để lại sẹo rõ rệt.
  2. **Bơm khí CO2:** Khí CO2 được bơm vào khoang bụng để làm phình vùng này, tạo không gian cho bác sĩ quan sát dễ dàng hơn.
  3. **Ống nội soi:** Một ống trocar (dụng cụ có đường kính tương đương cây bút chì) được đưa qua vết rạch để tạo đường cho ống nội soi đi vào khoang bụng.
  4. **Quan sát với camera:** Ống nội soi gắn camera siêu nhỏ giúp truyền hình ảnh trực tiếp lên màn hình ngoài để bác sĩ quan sát các tạng bên trong khoang bụng.
  5. **Phẫu thuật bổ sung (nếu cần):** Nếu phát hiện tổn thương hoặc bệnh lý, bác sĩ có thể sử dụng các dụng cụ phẫu thuật bổ sung để điều trị trực tiếp. Dụng cụ này được đưa vào khoang bụng qua một vết rạch khác (thường ở vùng dưới xương mu).


## **4. Ưu điểm của nội soi ổ bụng**
Nội soi ổ bụng là một phương pháp chẩn đoán và điều trị an toàn với nhiều ưu điểm vượt trội:
  * **Ít đau đớn:** So với các phương pháp phẫu thuật truyền thống, nội soi ổ bụng ít gây đau hơn, mang lại sự thoải mái cho bệnh nhân.
  * **Quan sát chi tiết:** Bác sĩ có thể quan sát các cơ quan bên trong một cách rõ ràng và chi tiết, giúp xác định chính xác nguyên nhân gây bệnh.
  * **Thời gian thực hiện nhanh chóng:** Thủ thuật nội soi ổ bụng thường diễn ra trong khoảng 30-40 phút.
  * **Vết sẹo nhỏ:** Vết rạch chỉ khoảng 1-2 cm, do đó sau khi lành, vết sẹo sẽ rất nhỏ và gần như không thể nhìn thấy.
  * **Xuất viện sớm:** Bệnh nhân có thể xuất viện chỉ sau khoảng 2 giờ sau khi thực hiện nội soi, giúp rút ngắn thời gian điều trị và hồi phục.


Tuy nhiên, bệnh nhân có thể cảm thấy hơi khó chịu do khí CO2 còn tồn tại trong khoang bụng, và có thể có một chút đau nhẹ tại vị trí vết rạch. Tuy nhiên, các triệu chứng này sẽ giảm dần và không kéo dài lâu.
## **5. Kết luận**
Nội soi ổ bụng là một phương pháp chẩn đoán và điều trị xâm lấn tối thiểu hiệu quả, đặc biệt trong các trường hợp bệnh lý phức tạp mà các phương pháp khác không thể phát hiện chính xác. Phương pháp này không chỉ giúp quan sát trực tiếp các tạng trong ổ bụng mà còn có thể kết hợp với phẫu thuật điều trị bệnh lý. Nhờ vào những ưu điểm như ít đau đớn, thời gian thực hiện nhanh chóng và khả năng hồi phục nhanh, nội soi ổ bụng ngày càng trở thành lựa chọn phổ biến trong việc chẩn đoán và điều trị các bệnh lý về bụng và vùng chậu.
**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/) **- Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [1. Nội soi ổ bụng là gì?](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-o-bung-co-dau-khong-ton-thuong-tai-vung-bung#1-ni-soi-bng-l-g)
  * [2. Nội soi ổ bụng có đau không?](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-o-bung-co-dau-khong-ton-thuong-tai-vung-bung#2-ni-soi-bng-c-au-khng)
  * [3. Quy trình thực hiện nội soi ổ bụng](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-o-bung-co-dau-khong-ton-thuong-tai-vung-bung#3-quy-trnh-thc-hin-ni-soi-bng)
  * [4. Ưu điểm của nội soi ổ bụng](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-o-bung-co-dau-khong-ton-thuong-tai-vung-bung#4-u-im-ca-ni-soi-bng)



## ️ Kỹ thuật nội soi với dải tần ánh sáng hẹp (NBI)

Hiện nay rất nhiều người gặp phải các vấn đề về đường tiêu hóa đang quan tâm đến kỹ thuật nội soi với dải tần ánh sáng hẹp (NBI). Đây không chỉ là phương pháp nội soi thông thường giúp phát hiện và đánh giá các thương tổn bên trong ống tiêu hóa mà còn giúp tầm soát phát hiện sớm dấu hiệu bệnh lý ung thư đường tiêu hóa như ung thư thực quản – ung thư dạ dày – ung thư đại tràng – đại trực tràng. Kỹ thuật nội soi này đã góp phần mang lại nhiều lợi ích cho người bệnh chỉ trong một lần nội soi, đồng thời còn tạo ra một sự đột phá mới trong công nghệ nội soi hiện nay.
**Nội soi với dải tần ánh sáng hẹp (NBI) là gì?**     
Nội soi đại tràng dải tần hẹp hiện nay đang được một số đơn vị y tế sử dụng. (ảnh minh họa)
Kỹ thuật nội soi với dải tần ánh sáng hẹp (NBI) tên đầy đủ là (Narrow Banding Imaging – viết tắt NBI) đây là kỹ thuật sử dụng bộ lọc R/G/B filter ứng dụng loại ánh sáng đơn sắc, trong đó nguyên lý là sử dụng hệ thống kính lọc và bộ phân tích xử trí ánh sáng với hai bước sóng 415nm (415 ± 30nm) và 540nm (540 ± 30nm).
Kỹ thuật này cho hình ảnh có khả năng phân biệt rõ hơn về một số đặc điểm – đặc thù cụ thể giữa tổ chức bình thường và tổ chức bệnh lý. Các mức độ khác nhau ở niêm mạc và tăng độ tương phản trên bề mặt biểu mô của mạng mao mạch dưới niêm mạc đường tiêu hóa, từ đó giúp đưa ra hình ảnh chẩn đoán chính xác hơn về các bệnh lý thực quản – dạ dày – đại tràng – đại trực tràng.
**Vì sao nội soi với dải tần ánh sáng hẹp (NBI) lại giúp tầm soát sớm ung thư đường tiêu hóa**
Khác với nội soi thông thường, nội soi dải tần ánh sáng hẹp NBI song hành 2 chế độ:
– Chế độ nội soi với độ phân giải cao thông thường sử dụng ánh sáng tự nhiên với bước sóng dao động trong khoảng 400-700nm.
– Chế độ dải tần ánh sáng hẹp (NBI) sử dụng ánh sáng có bước sóng 415nm và bước sóng 540nm.
Với việc sử dụng hai bước sóng 415nm và 540nm cho phép nội soi NBI tập trung phân tích chi tiết và kỹ hơn các biến đổi ở lớp bề mặt niêm mạc ống tiêu hóa và hệ thống mao mạch nông nuôi dưỡng lớp niêm mạc, từ đó cho kết quả chính xác hơn với nội soi thông thường có độ phân giải cao.     
Kỹ thuật nội soi với dải tần ánh sáng hẹp NBI được áp dụng chẩn đoán các bệnh lý ung thư ống tiêu hóa (ung thư thực quản – dạ dày – đại trực tràng) ở giai đoạn sớm. (ảnh minh họa)
Đặc biệt kỹ thuật nội soi với dải tần ánh sáng hẹp NBI kết hợp nội soi phóng đại sẽ giúp đánh giá mức độ xâm lấn của khối u (nếu có) tại các cơ quan của ống tiêu hóa và dựa trên kết quả này, bác sĩ sẽ định hướng chiến lược điều trị phù hợp: Can thiệp qua nội soi hay phẫu thuật.
Chính vì vậy, nội soi với dải tần ánh sáng hẹp NBI được áp dụng chẩn đoán các bệnh lý ung thư ống tiêu hóa (ung thư thực quản – dạ dày – đại trực tràng) ở giai đoạn sớm hoặc rất sớm. Khi các tế bào ung thư chỉ mới xuất hiện một đám rất nhỏ khu trú ở những vị trí nông trên bề mặt ống tiêu hóa.
Đã có rất nhiều người bệnh áp dụng phương pháp nội soi với dải tần ánh sáng hẹp NBI và đã phát hiện ra các tế bào mầm mống gây ung thư và được can thiệp điều trị, cắt bỏ lớp niêm mạc ống tiêu hóa bị tổn thương, từ đó đã chữa khỏi hoàn toàn ngay từ khi còn rất sớm. Hiệu quả điều trị tốt, thời gian sống sau điều trị dài với chất lượng cuộc sống tốt, giảm tối đa nguy cơ tái phát, giảm gánh nặng về tài chính, rút ngắn thời gian điều trị nội trú là những ưu điểm vượt trội mà nội soi dải tần ánh sáng hẹp NBI có thể đem lại cho bạn.
**Quy trình nội soi với dải tần ánh sáng hẹp (NBI)**
Nội soi NBI giúp đánh giá các thương tổn bên trong niêm mạc đường tiêu hóa của bạn, đặc biệt là giúp phát hiện sớm các dấu hiệu nghi ngờ ung thư dạ dày – đại tràng – đại trực tràng từ sớm và có biện pháp điều trị hiệu quả nhất.
Quy trình nội soi dải tần ánh sáng hẹp (NBI)
  * Bệnh nhân thay đồ rồi nằm lên cáng thủ thuật đúng tư thế, hợp tác với bác sĩ.
  * Bác sĩ sẽ mắc monitor lên người để theo dõi.
  * Bắt đầu nội soi bằng ống mềm quan sát niêm mạc dạ dày, đại tràng để chế độ NBI quan sát kỹ các tổn thương nghi ngờ.
  * Dựa trên các thay đổi mạng lưới mao mạch (CP: capillary pattern) tùy thuộc vào thay đổi cấu mạng lưới mao mạch, kích thước mạch máu mà phân biệt được các tổn thương. Đánh giá theo phân loại CP típ 1, CP típ 2, CP típ 3.
  * Tiếp đó, bác sĩ ra hiệu chụp ảnh minh họa rồi làm các xét nghiệm sinh thiết (nếu cần).
  * Sau khi kết thúc thủ thuật, bác sĩ sẽ đánh giá và in kết quả, bổ sung thêm phiếu xét nghiệm, sinh thiết (nếu cần)
  * Cuối cùng trả kết quả nội soi cho bệnh nhân.


**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/) **- Đa khoa Hạng I Thành phố Hồ Chí Minh

## ️ Các bước quy trình nội soi tiêu hóa bạn cần biết!

  * [1. Nội soi hệ tiêu hóa là gì?](https://bvnguyentriphuong.com.vn/noi-soi/cac-buoc-quy-trinh-noi-soi-tieu-hoa-ban-can-biet#1-ni-soi-h-tiu-ha-l-g)
  * [2. Các phương pháp nội soi hệ tiêu hóa](https://bvnguyentriphuong.com.vn/noi-soi/cac-buoc-quy-trinh-noi-soi-tieu-hoa-ban-can-biet#2-cc-phng-php-ni-soi-h-tiu-ha)
  * [2.1 Nội soi qua đường mũi](https://bvnguyentriphuong.com.vn/noi-soi/cac-buoc-quy-trinh-noi-soi-tieu-hoa-ban-can-biet#21-ni-soi-qua-ng-mi)
  * [2.2 Nội soi qua đường miệng](https://bvnguyentriphuong.com.vn/noi-soi/cac-buoc-quy-trinh-noi-soi-tieu-hoa-ban-can-biet#22-nisoi-qua-ng-ming)
  * [3. Khi nào nên nội soi tiêu hóa?](https://bvnguyentriphuong.com.vn/noi-soi/cac-buoc-quy-trinh-noi-soi-tieu-hoa-ban-can-biet#3-khi-no-nn-ni-soi-tiu-ha)
  * [4. Quy trình nội soi tiêu hóa](https://bvnguyentriphuong.com.vn/noi-soi/cac-buoc-quy-trinh-noi-soi-tieu-hoa-ban-can-biet#4-quy-trnh-ni-soi-tiu-ha)
  * [4.2 Thăm khám và thực hiện các xét nghiệm cần thiết là bước tiếp theo trong quy trình nội soi tiêu hóa](https://bvnguyentriphuong.com.vn/noi-soi/cac-buoc-quy-trinh-noi-soi-tieu-hoa-ban-can-biet#42-thm-khm-v-thc-hin-cc-xt-nghim-cn-thit-l-bc-tip-theo-trong-quy-trnh-ni-soi-tiu-ha)
  * [4.3 Tham khảo các tư vấn từ bác sĩ](https://bvnguyentriphuong.com.vn/noi-soi/cac-buoc-quy-trinh-noi-soi-tieu-hoa-ban-can-biet#43-tham-kho-cc-t-vn-t-bc-s)
  * [4.4 Tiến hành nội soi](https://bvnguyentriphuong.com.vn/noi-soi/cac-buoc-quy-trinh-noi-soi-tieu-hoa-ban-can-biet#44-tin-hnh-ni-soi)
  * [4.5 Trả kết quả là bước cuối cùng trong quy trình nội soi tiêu hóa](https://bvnguyentriphuong.com.vn/noi-soi/cac-buoc-quy-trinh-noi-soi-tieu-hoa-ban-can-biet#45-tr-kt-qu-l-bc-cui-cng-trong-quy-trnh-ni-soi-tiu-ha)
  * [5. Những lưu ý sau khi nội soi hệ tiêu hóa](https://bvnguyentriphuong.com.vn/noi-soi/cac-buoc-quy-trinh-noi-soi-tieu-hoa-ban-can-biet#5-nhng-lu-sau-khi-ni-soi-h-tiu-ha)


Hệ tiêu hóa là một trong những cơ quan dễ bị tổn thương nhất trong cơ thể con người. Nội soi là phương pháp tốt nhất để phát hiện bệnh. Thông thường, quy trình nội soi tiêu hóa sẽ trải qua những bước nào để bác sĩ nắm được tình trạng của bệnh nhân? Bài viết dưới đây sẽ trang bị những kiến thức cơ bản để bạn chuẩn bị cho quá trình nội soi của mình!
## **1. Nội soi hệ tiêu hóa là gì?**
Trước khi tìm hiểu chi tiết quy trình nội soi tiêu hóa, chúng ta cần hiểu sơ qua thế nào là nội soi. Trên thực tế, nội soi là kỹ thuật được sử dụng phổ biến trong thăm khám bệnh về tiêu hóa. Thông thường, bác sĩ sẽ sử dụng ống soi có đường kính nhỏ, đầu gắn camera để thông vào ống tiêu hóa. Các hình ảnh nhận được sẽ hiển thị trên màn hình. Từ đó, bác sĩ sẽ chẩn đoán các bệnh lý có liên quan (nếu có).
Nội soi là phương pháp hiệu quả và nhanh nhất giúp mang lại những thông tin cần thiết cho bác sĩ. Tuy nhiên, kỹ thuật này cũng gây nên một số cảm giác khó chịu hoặc biến chứng nhẹ cho người bệnh. Do đó, bệnh nhân cần tìm hiểu về quy trình nội soi hệ tiêu hóa để tránh cảm giác thụ động.
**Nội soi tiêu hóa giúp các bác sĩ có thể chẩn đoán bệnh chính xác hơn**
## **2. Các phương pháp nội soi hệ tiêu hóa**
Trong kỹ thuật nội soi hiện nay, có 3 cách phổ biến nhất. Với mỗi cách lại tương ứng với những quy trình nội soi hệ tiêu hóa khác nhau.
### **2.1 Nội soi qua đường mũi**
Hiểu đơn giản thì phương pháp này được thực hiện bằng cách thông ống nội soi qua đường mũi. Ống sẽ đi từ khoang mũi đến thực quản và sau đó là dạ dày. Ống được sử dụng trong phương pháp này là ống siêu nhỏ nhằm tránh gây tổn thương cho người bệnh. Ưu điểm của phương pháp này là bệnh nhân không có cảm giác buồn nôn. Tuy nhiên, những bệnh nhân bị bệnh hô hấp trên hoặc có các dị tật thì sẽ không thể thực hiện theo phương pháp này.
### **2.2 Nội soi qua đường miệng**
Tương tự như trên, phương pháp này được thực hiện bằng cách thông ống nội soi qua đường miệng. Ở đây, bệnh nhân sẽ có 2 lựa chọn gồm:
Nội soi thường: Ống nội soi được đưa trực tiếp từ miệng xuống ống tiêu hóa khi bệnh nhân vẫn trong trạng thái tỉnh. Đây là phương pháp thường được nhiều bệnh nhân ưu tiên sử dụng. Tuy nhiên nó lại có nhiều hạn chế như gây buồn nôn, dễ làm tổn thương niêm mạc,… Nếu bạn không phải người có thể chịu đau, tốt hơn bạn không nên chọn cách này.
Nội soi gây mê: Thực hiện khi bệnh nhân ở trong trạng thái được gây mê. Bác sĩ sẽ đặt ống truyền thuốc mê để bạn không còn cảm thấy đau đớn. Phương pháp này mặc dù không gây đau đớn nhưng lại khá tốn kém. Ngoài ra, bạn cũng cần thực hiện một vài kiểm tra để đảm bảo bạn đủ điều kiện để thực hiện phương pháp này.
**Hiện nay có 3 phương pháp nội soi được sử dụng rộng rãi**
## **3. Khi nào nên nội soi tiêu hóa?**
Hãy luôn đảm bảo rằng bạn hiểu cơ thể mình đang muốn nói điều gì. Do đó, việc khám định kỳ thường xuyên là vô cùng cần thiết. Thông thường, bạn nên đi nội soi nếu gặp phải các triệu chứng như đau thượng vị, đầy hơi lâu ngày, đi ngoài ra máu, buồn nôn, sụt cân không rõ nguyên nhân, rối loạn đại tiện,… Nội soi là phương pháp tốt nhất giúp bạn phát hiện ra các vấn đề tại đường tiêu hóa của cơ thể.
## **4. Quy trình nội soi tiêu hóa**
Trang bị những kiến thức về quá trình nội soi tiêu hóa giúp bạn có cảm giác an tâm và tự tin hơn trong quá trình nội soi. Theo đó, quy trình nội soi tiêu hóa chuẩn gồm các bước sau:
### **4.1 Chuẩn bị**
Bệnh nhân sẽ được dặn nên nhịn ăn trước khi nội soi ít nhất 6 giờ để thuận tiện cho quá trình nội soi. Nếu bụng bạn có nhiều thức ăn, có thể dẫn tới hiện tượng trào ngược gây tắc thở.
Bữa cuối trước khi nội soi bạn nên ăn thức ăn mềm, loãng. Tránh ăn thực phẩm rắn, khó tiêu hóa, các hoa quả có hạt như thanh long, dưa hấu,…. Tránh các thức uống có ga, có cồn, có màu,… vì chúng sẽ dễ gây ảnh hưởng đến kết quả nội soi.
### **4.2 Thăm khám và thực hiện các xét nghiệm cần thiết là bước tiếp theo trong quy trình nội soi tiêu hóa**
Điều này giúp đảm bảo bạn đủ sức khỏe để nội soi. Ngoài ra, việc này cũng tăng thêm sự an toàn cho bệnh nhân trong quá trình nội soi. Đặc biệt khi thực hiện một số thủ thuật cũng như sau khi nội soi kết thúc.
Các xét nghiệm bạn có thể cần thực hiện như: xét nghiệm viêm gan A, B, C, HIV, xét nghiệm đông máu (nếu như cắt polyp),….
### **4.3 Tham khảo các tư vấn từ bác sĩ**
Bác sĩ sẽ nói cho bạn biết những nguy cơ có thể xảy ra. Ví dụ trong quá trình nội soi phát hiện polyp hay các khối u có được cắt hay không đều cần sự cam kết từ phía người bệnh.
### **4.4 Tiến hành nội soi**
Ống nội soi sẽ được bác sĩ đưa vào cơ thể thông qua miệng (hoặc mũi). Hình ảnh về hệ tiêu hóa sẽ hiển thị trên màn hình. Bác sĩ sẽ căn cứ vào đó để đưa ra những chẩn đoán cụ thể. Trong một vài trường hợp, bác sĩ sẽ gắn thêm một số dụng cụ lấy mô trên ống nội soi.
### **4.5 Trả kết quả là bước cuối cùng trong quy trình nội soi tiêu hóa**
Dựa trên những hình ảnh nội soi, bác sĩ sẽ có căn cứ để đưa ra kết luận. Sau đó, bác sĩ sẽ đưa ra những tư vấn cũng như phác đồ điều trị tiếp theo.
**Khi hiểu rõ về quy trình nội soi tiêu hóa sẽ phần nào giúp bệnh nhân đỡ lo lắng**
## **5. Những lưu ý sau khi nội soi hệ tiêu hóa**
Sau khi nội soi, bệnh nhân cần được nghỉ ngơi và theo dõi. Nếu có bất kỳ biểu hiện bất thường nào, bạn cần liên hệ với bác sĩ để được tư vấn. Bởi lẽ dù quy trình nội soi hệ tiêu hóa có hoàn hảo đến đâu cũng không thể tránh khỏi những rủi ro. Với những bệnh nhân sử dụng phương pháp nội soi gây mê, tốt hơn là nên có người thân đi cùng. Việc điều khiển xe trong tình trạng vừa được gây mê là rất nguy hiểm.
Bên cạnh đó, bệnh nhân cũng không nên ăn ngay sau khi nội soi kết thúc. Bác sĩ có thể có thêm một vài dặn dò khác để đảm bảo sức khỏe cho người khám. Bệnh nhân cũng chỉ nên ăn những thực phẩm mềm, dễ tiêu như cháo hoặc sữa.
Nếu xuất hiện các biểu hiện bất thường dưới đây, bệnh nhân cần thông báo ngay cho bác sĩ:
– Đau quặn bụng liên tục
– Khó thở
– Đi ngoài ra máu hoặc sậm màu
– Khó nuốt, nôn mửa
– Sốt
**Ngay khi phát hiện các dấu hiệu bất thường cần báo ngay cho bác sĩ để kịp thời xử lý**
Hy vọng rằng với những thông tin trên đây, bạn đã hiểu rõ hơn về quy trình nội soi tiêu hóa. Hãy luôn nhớ rằng nội soi không hề nguy hiểm. Nó chỉ là một phương pháp giúp chẩn đoán bệnh. Điều bạn cần chỉ là tuân thủ những chỉ dẫn của bác sĩ và chuẩn bị tâm lý thật ổn định. Hãy luôn lắng nghe cơ thể mình muốn nói gì, kể cả trước và sau khi nội soi nhé!
**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/) **- Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [1. Nội soi hệ tiêu hóa là gì?](https://bvnguyentriphuong.com.vn/noi-soi/cac-buoc-quy-trinh-noi-soi-tieu-hoa-ban-can-biet#1-ni-soi-h-tiu-ha-l-g)
  * [2. Các phương pháp nội soi hệ tiêu hóa](https://bvnguyentriphuong.com.vn/noi-soi/cac-buoc-quy-trinh-noi-soi-tieu-hoa-ban-can-biet#2-cc-phng-php-ni-soi-h-tiu-ha)
  * [2.1 Nội soi qua đường mũi](https://bvnguyentriphuong.com.vn/noi-soi/cac-buoc-quy-trinh-noi-soi-tieu-hoa-ban-can-biet#21-ni-soi-qua-ng-mi)
  * [2.2 Nội soi qua đường miệng](https://bvnguyentriphuong.com.vn/noi-soi/cac-buoc-quy-trinh-noi-soi-tieu-hoa-ban-can-biet#22-nisoi-qua-ng-ming)
  * [3. Khi nào nên nội soi tiêu hóa?](https://bvnguyentriphuong.com.vn/noi-soi/cac-buoc-quy-trinh-noi-soi-tieu-hoa-ban-can-biet#3-khi-no-nn-ni-soi-tiu-ha)
  * [4. Quy trình nội soi tiêu hóa](https://bvnguyentriphuong.com.vn/noi-soi/cac-buoc-quy-trinh-noi-soi-tieu-hoa-ban-can-biet#4-quy-trnh-ni-soi-tiu-ha)
  * [4.2 Thăm khám và thực hiện các xét nghiệm cần thiết là bước tiếp theo trong quy trình nội soi tiêu hóa](https://bvnguyentriphuong.com.vn/noi-soi/cac-buoc-quy-trinh-noi-soi-tieu-hoa-ban-can-biet#42-thm-khm-v-thc-hin-cc-xt-nghim-cn-thit-l-bc-tip-theo-trong-quy-trnh-ni-soi-tiu-ha)
  * [4.3 Tham khảo các tư vấn từ bác sĩ](https://bvnguyentriphuong.com.vn/noi-soi/cac-buoc-quy-trinh-noi-soi-tieu-hoa-ban-can-biet#43-tham-kho-cc-t-vn-t-bc-s)
  * [4.4 Tiến hành nội soi](https://bvnguyentriphuong.com.vn/noi-soi/cac-buoc-quy-trinh-noi-soi-tieu-hoa-ban-can-biet#44-tin-hnh-ni-soi)
  * [4.5 Trả kết quả là bước cuối cùng trong quy trình nội soi tiêu hóa](https://bvnguyentriphuong.com.vn/noi-soi/cac-buoc-quy-trinh-noi-soi-tieu-hoa-ban-can-biet#45-tr-kt-qu-l-bc-cui-cng-trong-quy-trnh-ni-soi-tiu-ha)
  * [5. Những lưu ý sau khi nội soi hệ tiêu hóa](https://bvnguyentriphuong.com.vn/noi-soi/cac-buoc-quy-trinh-noi-soi-tieu-hoa-ban-can-biet#5-nhng-lu-sau-khi-ni-soi-h-tiu-ha)



## ️ Nội soi dạ dày qua đường mũi có chính xác không?

  * [Nội soi dạ dày qua đường mũi có chính xác không?](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-da-day-qua-duong-mui-co-chinh-xac-khong#ni-soi-d-dy-qua-ng-mi-c-chnh-xc-khng)
  * [Những ai nên nội soi dạ dày qua đường mũi?](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-da-day-qua-duong-mui-co-chinh-xac-khong#nhng-ai-nn-ni-soi-d-dy-qua-ng-mi)


Nội soi dạ dày là phương pháp chẩn đoán có hiệu quả cao và an toàn nhất giúp đánh giá chính xác các bệnh lý đường tiêu hóa. So với nội soi qua đường miệng, nội soi dạ dày qua đường mũi dễ thực hiện và cũng ít gây khó chịu. Tuy nhiên rất nhiều người còn băn khoăn rằng liệu phương pháp nội soi này có chính xác không? Để tìm hiểu kỹ hơn về phương pháp này, bạn đọc có thể tham kham khảo bài viết dưới đây.
## **Nội soi dạ dày qua đường mũi có chính xác không?**
Nội soi dạ dày qua đường mũi là phương pháp sử dụng ống nội soi mềm rất nhỏ qua đường mũi đã được gây tê, đến thực quản rồi xuống dạ dày, hành tá tràng, tá tràng. Theo đường đi của ống nội soi, bác sĩ có thể quan sát được bề mặt niêm mạc các bộ phận mà ống nội soi đi qua, từ đó phát hiện được các tổn thương (nếu có) qua hình ảnh nội soi và lấy mẫu xét nghiệm bệnh phẩm, vi khuẩn HP nếu có.
**Nội soi.**
### **Ưu điểm**
Cho kết quả có độ chính xác cao, dễ thực hiện. Ống nội soi có đường kính rất nhỏ (khoảng 5,9 mm) và được đi qua đường mũi nên không chạm vào vòm khẩu cái và vùng hầu họng nên hạn chế gây buồn nôn, giúp người bệnh cảm thấy dễ chịu hơn.
### **Nhược điểm**
Không được thực hiện nếu bệnh nhân có bệnh lý về mũi, hẹp khe mũi và chi phí thường cao hơn so với nội soi qua đường miệng. Ngoài ra, nếu nội soi mà phát hiện thấy các bệnh lý cần can thiệp như lấy dị vật, cầm máu, cắt polyp, thắt tĩnh mạch thực quản,… thì không thực hiện được ngay bằng đường mũi mà bệnh nhân phải chuyển qua nội soi bằng đường miệng.
## **Những ai nên nội soi dạ dày qua đường mũi?**
Nhiều người bị viêm loét dạ dày, đại tràng không thấy xuất hiện triệu chứng gì cho đến khi có các biến chứng xuất huyết tiêu hóa, thủng dạ dày,… phải nhập viện, hay nguy hiểm hơn là ung thư dạ dày vì không được chẩn đoán và nội soi sớm.
Nội soi giúp phát hiện nhiều bệnh lý dạ dày ngay từ giai đoạn đầu, Chỉ với khoảng 15 phút nội soi, không gây đau, không buồn nôn hay khó chịu, độ chính xác cao, không cần gây mê sẽ giúp phát hiện sớm các tổn thương ác tính liên quan đến ung thư giúp người bệnh giải quyết những lo ngại khi đi khám.
**Bệnh dạ dày ngày càng phổ biến và ra tăng hiện nay.**
Vì vậy nếu bạn có những biểu hiện sau đây, bạn nên đi nội soi sớm để phát hiện các bất thường và có biện pháp can thiệp kịp thời:
  * Giảm cân không rõ nguyên nhân.
  * Đau thượng vị, buồn nôn sau khi ăn.
  * Đau ngực nhưng kiểm tra tim mạch bình thường.
  * Ợ chua, ợ hơi, chậm tiêu.
  * Nôn ra máu, thiếu máu hoặc đi ngoài ra phân đen.
  * Nuốt nghẹn.
  * Tiền sử dùng thuốc chống viêm, giảm đau, gây đau thượng vị.
  * Mắc hội chứng kém hấp thu.
  * Tiền sử gia đình mắc bệnh polyp dạ dày, polyp đại tràng.


**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/) **- Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [Nội soi dạ dày qua đường mũi có chính xác không?](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-da-day-qua-duong-mui-co-chinh-xac-khong#ni-soi-d-dy-qua-ng-mi-c-chnh-xc-khng)
  * [Những ai nên nội soi dạ dày qua đường mũi?](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-da-day-qua-duong-mui-co-chinh-xac-khong#nhng-ai-nn-ni-soi-d-dy-qua-ng-mi)



## ️Nội soi dạ dày xong bị đau bụng có sao không?

  * [Nội soi dạ dày xong bị đau bụng có đáng lo?](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-da-day-xong-bi-dau-bung-co-sao-khong#ni-soi-d-dy-xong-b-au-bng-c-ng-lo)
  * [Vì sao nội soi dạ dày xong bị đau bụng?](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-da-day-xong-bi-dau-bung-co-sao-khong#v-sao-ni-soi-d-dy-xong-b-au-bng)
  * [Cách nào khắc phục vấn đề này?](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-da-day-xong-bi-dau-bung-co-sao-khong#cch-no-khc-phc-vn-ny)
  * [Làm gì để được nội soi dạ dày không đau?](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-da-day-xong-bi-dau-bung-co-sao-khong#lm-g-c-ni-soi-d-dy-khng-au)
  * [Những việc cần tuân thủ trước và sau khi nội soi](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-da-day-xong-bi-dau-bung-co-sao-khong#nhng-vic-cn-tun-th-trc-v-sau-khi-ni-soi)
  * [Trước khi nội soi:](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-da-day-xong-bi-dau-bung-co-sao-khong#trc-khi-ni-soi)
  * [Sau khi nội soi: ](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-da-day-xong-bi-dau-bung-co-sao-khong#sau-khi-ni-soi)


Nội soi dạ dày là hoạt động khám thiết yếu trong nhiều trường hợp thăm khám bệnh lý tiêu hóa. Tuy nhiên, một số người cảm thấy đau bụng sau khi làm nội soi dạ dày. Vậy nội soi dạ dày xong bị đau bụng có phải là vấn đề bất thường? Có cách nào khắc phục vấn đề này?
## **Nội soi dạ dày xong bị đau bụng có đáng lo?**
**Nội soi dạ dày xong bị đau bụng có phải là vấn đề bất thường không là điều khiến nhiều người quan tâm.**
Khi tiến hành làm nội soi cho người bệnh, bác sĩ sẽ sử dụng ống nội soi tiến hành khảo sát bên trong dạ dày – tá tràng thông qua mũi hoặc miệng đến thực quản và dạ dày. Sau ca nội soi, có những trường hợp bệnh nhân cảm thấy bị đau bụng. Vấn đề này thường được xem là bất ổn cần lưu ý kiểm tra và khắc phục.
Nếu kết quả kiểm tra sau đó cho thấy mức độ không nghiêm trọng, các cơn đau không quá đáng ngại nếu được khắc phục đúng cách.
## **Vì sao nội soi dạ dày xong bị đau bụng?**
Thông thường, hiện tượng nội soi dạ dày xong bị đau bụng xảy ra do:
## **Cách nào khắc phục vấn đề này?**
Nếu thấy xuất hiện tình trạng đau bụng sau khi nội soi dạ dày, mọi người nên lưu ý và thực hiện đúng những tư vấn chuyên môn dưới đây:
Nếu sau khi nội soi dạ dày xong bị đau bụng nhưng đó chỉ là những cơn đau nhẹ thoáng qua, người bệnh có thể tạm yên tâm vì có thể chỉ là biểu hiện thường thấy khi nội soi dạ dày. Cảm giác này có thể biến mất vài giờ sau đó, song vẫn nên theo dõi.
Tuy nhiên, nếu cơn đau trở nên dữ dội, quặn từng cơn kéo dài và không có dấu hiệu thuyên giảm, rất có thể đó là dấu hiệu của những biến chứng hiếm gặp. Các biến chứng này bao gồm: thủng dạ dày, xuất huyết dạ dày. Khi đó, người bệnh cần đến ngay bệnh viện uy tín, đặc biệt về nội soi tiêu hóa. Tại đây, bác sĩ chuyên khoa sẽ thăm khám và đưa ra giải pháp phù hợp, kịp thời, không những ngăn chặn cơn đau mà còn giúp tránh nguy hiểm đến tính mạng.
## **Làm gì để được nội soi dạ dày không đau?**
**Hiện tượng nội soi dạ dày xong bị đau bụng xảy ra thường do dùng ống soi cứng, thao tác không khéo gây tổn thương niêm mạc, kĩ thuật bơm hút khí khi soi chưa chuẩn xác.**
Nhằm hạn chế cảm giác đau đớn, khó chịu khi nội soi, cũng như tình trạng đau bụng sau nội soi, người bệnh cần thực hiện một số việc cần thiết. Những việc này cũng đồng thời giúp hạn chế nguy cơ gây tổn thương dạ dày:
**–** Lựa chọn phương pháp nội soi dạ dày bằng ống mềm.
– Tìm kiếm bệnh viện làm nội soi uy tín, với các bác sĩ giỏi, có kinh nghiệm về nội soi.
## **Những việc cần tuân thủ trước và sau khi nội soi**
### **Trước khi nội soi:**
  * Nhịn ăn và uống các loại nước có màu ít nhất trước 6 giờ.
  * Thông báo đến bác sĩ nếu có các bất thường tại tim, phổi, mũi (nội soi đường mũi).
  * Nếu có tiền sử dị ứng với thuốc gây tê, gây mê cần báo bác sĩ để được tư vấn phương pháp nội soi phù hợp.
  * Giữ tâm thế thoải mái, thả lỏng cơ thể, tránh căng thẳng quá mức trước khi soi.


### **Sau khi nội soi:**
  * Sau nội soi khoảng 1 giờ, người khám có thể uống sữa nguội và theo dõi tình trạng dạ dày. Nếu không xuất hiện các dấu hiệu bất thường, sau 2 giờ có thể ăn các thức ăn lỏng, mềm như cháo, súp,…
  * Nên nghỉ ngơi và hạn chế vận động nặng vài ngày sau khi nội soi.
  * Tránh xa các chất kích thích như: rượu, bia, thuốc lá, cà phê,… sau khi nội soi.


**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/) **- Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [Nội soi dạ dày xong bị đau bụng có đáng lo?](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-da-day-xong-bi-dau-bung-co-sao-khong#ni-soi-d-dy-xong-b-au-bng-c-ng-lo)
  * [Vì sao nội soi dạ dày xong bị đau bụng?](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-da-day-xong-bi-dau-bung-co-sao-khong#v-sao-ni-soi-d-dy-xong-b-au-bng)
  * [Cách nào khắc phục vấn đề này?](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-da-day-xong-bi-dau-bung-co-sao-khong#cch-no-khc-phc-vn-ny)
  * [Làm gì để được nội soi dạ dày không đau?](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-da-day-xong-bi-dau-bung-co-sao-khong#lm-g-c-ni-soi-d-dy-khng-au)
  * [Những việc cần tuân thủ trước và sau khi nội soi](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-da-day-xong-bi-dau-bung-co-sao-khong#nhng-vic-cn-tun-th-trc-v-sau-khi-ni-soi)
  * [Trước khi nội soi:](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-da-day-xong-bi-dau-bung-co-sao-khong#trc-khi-ni-soi)
  * [Sau khi nội soi: ](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-da-day-xong-bi-dau-bung-co-sao-khong#sau-khi-ni-soi)



## ️ “Tất tần tật” thông tin về nội soi dạ dày

  * [Nội soi dạ dày là gì?](https://bvnguyentriphuong.com.vn/noi-soi/tat-tan-tat-thong-tin-ve-noi-soi-da-day#ni-soi-d-dy-l-g)
  * [Khi nào cần thực hiện nội soi dạ dày?](https://bvnguyentriphuong.com.vn/noi-soi/tat-tan-tat-thong-tin-ve-noi-soi-da-day#khi-no-cn-thc-hin-ni-soi-d-dy)
  * [Các phương pháp nội soi dạ dày](https://bvnguyentriphuong.com.vn/noi-soi/tat-tan-tat-thong-tin-ve-noi-soi-da-day#cc-phng-php-ni-soi-d-dy)
  * [Vì sao nội soi được đánh giá là tối ưu nhất trong chẩn đoán bệnh dạ dày?](https://bvnguyentriphuong.com.vn/noi-soi/tat-tan-tat-thong-tin-ve-noi-soi-da-day#v-sao-ni-soi-c-nh-gi-l-ti-u-nht-trong-chn-on-bnh-d-dy)
  * [Nội soi dạ dày có nguy hiểm không?](https://bvnguyentriphuong.com.vn/noi-soi/tat-tan-tat-thong-tin-ve-noi-soi-da-day#ni-soi-d-dy-c-nguy-him-khng)
  * [Chuẩn bị trước khi nội soi dạ dày](https://bvnguyentriphuong.com.vn/noi-soi/tat-tan-tat-thong-tin-ve-noi-soi-da-day#chun-b-trc-khi-ni-soi-d-dy)
  * [Chăm sóc sau khi nội soi dạ dày](https://bvnguyentriphuong.com.vn/noi-soi/tat-tan-tat-thong-tin-ve-noi-soi-da-day#chm-sc-sau-khi-ni-soi-d-dy)


Trước thực trạng số lượng người mắc các bệnh lý về dạ dày đang ngày càng tăng như hiện nay thì việc phải thực hiện nội soi dạ dày không còn là “chuyện hiếm”. Vì đây là phương pháp tối ưu nhất giúp phát hiện sớm các tổn thương ở dạ dày, chẩn đoán chính xác các bệnh về dạ dày để có cách điều trị kịp thời. Nội soi dạ dày thường được chỉ định rộng rãi tuy nhiên nên lựa chọn các bệnh viện uy tín có đội ngũ bác sĩ giỏi, trang thiết bị hiện đại để đảm bảo an toàn, hạn chế rủi ro.
**Nội soi dạ dày là một thủ thuật được áp dụng để thăm khám bên trong đường tiêu hóa trên nhờ một camera được gắn ở đầu ống nội soi mềm.**
## **Nội soi dạ dày là gì?**
Nội soi dạ dày là phương pháp thăm khám trực tiếp phần trên của ống tiêu hóa (gồm thực quản, dạ dày, tá tràng) bằng cách đưa một ống nội soi mềm nhỏ qua đường miệng hoặc đường mũi. Ống nội soi này có gắn camera và nguồn sáng, camera sẽ ghi lại hình ảnh chi tiết bên trong dạ dày truyền lên màn hình nội soi bên ngoài. Quan sát những hình ảnh này bác sĩ sẽ nhận biết được các thương tổn hoặc dấu hiệu bất thường đang xảy ra bên trong.
Trong quá trình nội soi dạ dày, bác sĩ cũng có thể sử dụng dụng cụ chuyên biệt để cắt bỏ polyp (nếu có) hoặc lấy mẫu sinh thiết (lấy một mẫu mô nhỏ của dạ dày) chuyển tới phòng thí nghiệm, sau đó làm các xét nghiệm phân tích tìm các dấu hiệu viêm, tế bào ung thư; hoặc tìm tác nhân gây bệnh như vi khuẩn Helicobacter pylori (H.pylori hay Hp), nấm…
## **Khi nào cần thực hiện nội soi dạ dày?**
Bệnh nhân thường được chỉ định nội soi dạ dày để:
Chẩn đoán bệnh lý, xác định nguyên nhân gây ra các triệu chứng bất thường như:
  * Đau thượng vị, buồn nôn sau khi ăn.


  * Giảm cân không rõ nguyên nhân.


  * Nôn ra máu, thiếu máu, đi ngoài phân đen.


  * Ợ chua, ợ hơi, trào ngược thức ăn.


  * Nuốt nghẹn.


  * Đau ngực sau khi đã kiểm tra tim mạch bình thường.


Nếu cần thiết, bác sĩ có thể tiến hành làm một số xét nghiệm trong quá trình nội soi như: lấy mẫu sinh thiết tìm dấu ấn ung thư hoặc làm Clo- test để chẩn đoán nhiễm vi khuẩn Helicobacter Pylori (HP).
## **Điều trị**
Sử dụng những dụng cụ chuyên biệt đưa qua ống nội soi, bác sĩ có thể điều trị các bệnh lý liên quan như xuất huyết đường tiêu hóa, lấy dị vật trong đường tiêu hóa, cắt polyp…
## **Các phương pháp nội soi dạ dày**
**Nội soi thường:** đây là phương pháp nội soi “cổ điển”, người bệnh sẽ được uống một loại thuốc để loại bỏ dịch nhầy trên niêm mạc, sau đó được xịt thuốc tê nhẹ ở miệng để làm giảm cảm giác khó chịu khi đưa ống soi vào. Sau đó bác sĩ sẽ đưa ống nội soi từ hầu họng qua thực quản xuống dạ dày. Hình ảnh từ camera trên đầu thiết bị nội soi sẽ truyền tải về màn hình, bác sĩ dựa vào đó để theo dõi và đưa các chẩn đoán. Bệnh nhân không thể nói được nhưng vẫn thở bình thường. Tuy nhiên phương pháp nội soi này có hạn chế là khiến người bệnh cảm thấy buồn nôn, nghẹn thở hoặc khó chịu.
**Nội soi gây mê:** vì nội soi thường gây khó chịu nên nội soi gây mê đang rất được ưa chuộng hiện nay. Cụ thể trong phương pháp này, người bệnh sẽ được gây mê bằng thuốc an thần có tác dụng ngắn vừa đủ cho 1 cuộc soi, tỉnh sau 15 phút và không ảnh hưởng tới sức khỏe. Vì thế khi người bệnh sẽ không hề có cảm giác khó chịu, tỉnh dậy khi đã hoàn thành thủ thuật. Nội soi dạ dày gây mê cũng được thực hiện qua đường miệng.
**Nội soi qua đường mũi:** thay vì đưa ống nội soi qua đường miệng, thủ thuật mới đưa ống qua đường mũi. Bác sĩ sử dụng loại ống nội soi rất nhỏ, luồn qua đường mũi đã được xịt tê, qua ngả hầu họng xuống đến thực quản, dạ dày, hành tá tràng, tá tràng để quan sát bề mặt niêm mạc. Ưu điểm của phương pháp này là người bệnh không bị kích thích lưỡi gà, vòm khẩu cái và đáy lưỡi nên không có cảm giác khó chịu, nhiều trường hợp vẫn có thể nói chuyện bình thường với bác sĩ trong quá trình nội soi.
## **Vì sao nội soi được đánh giá là tối ưu nhất trong chẩn đoán bệnh dạ dày?**
Ống tiêu hóa là một cơ quan rất khó chẩn đoán bệnh lý. Các phương pháp như siêu âm, chụp CT hay chụp MRI dù rất đắt tiền nhưng lại không có giá trị chẩn đoán bệnh lý ống tiêu hóa. Chụp X quang dạ dày cản quang có thể dùng trong một số trường hợp nhưng không chính xác như nội soi.
Qua nội soi, các bác sĩ phát hiện được cả những tổn thương rất nhỏ, chỉ vài mm bên trong hệ tiêu hóa nhờ ống nội soi có thể đi sâu vào ống tiêu hóa. Không chỉ có vậy, trong quá trình nội soi, bác sĩ đồng thời còn có thể lấy mẫu sinh thiết tìm dấu ấn ung thư, xét nghiệm chẩn đoán vi khuẩn HP hoặc thực hiện cắt polyp, cầm máu xuất huyết đường tiêu hóa trong những trường hợp cần thiết…
## **Nội soi dạ dày có nguy hiểm không?**
Nhìn chung nội soi dạ dày được đánh giá là an toàn, ít biến chứng nên bệnh nhân cũng không cần quá lo lắng. Mặc dù vậy bất cứ thủ thuật xâm lấn nào cũng có những biến chứng có thể xảy ra. Những biến chứng có thể gặp của nội soi dạ dày là: nhiễm trùng, chảy máu, thủng tá tràng, thực quản hoặc dạ dày hoặc shock phản vệ nếu dùng thuốc (rất hiếm).
Để giảm thiểu tối đa những nguy cơ này, người bệnh nên lựa chọn thực hiện tại các bệnh viện uy tín, có đầy đủ trang thiết bị y tế hiện đại. Người bệnh cũng cần nghiêm túc tuân thủ những dặn dò, lưu ý của bác sĩ trước, trong và sau khi thực hiện nội soi.
## **Chuẩn bị trước khi nội soi dạ dày**
Để đảm bảo nội soi dạ dày an toàn, nhanh chóng và thuận lợi, người bệnh lưu ý:
  * Không dùng chất kích thích, không ăn những đồ ăn xơ cứng trước ngày soi.


  * Không uống các loại đồ uống có ga, có màu…


  * Nội soi buổi sáng phải nhịn ăn trước 6 tiếng.


  * Nội soi buổi chiều phải nhịn ăn trưa.


  * Trước nội soi 2 tiếng không được uống nước.


  * Thông báo cho bác sĩ biết nếu đang mang thai hoặc mắc phải các bệnh lý như bệnh tim.


  * Cho bác sĩ biết về loại thuốc đang sử dụng hoặc có bị dị ứng với loại thuốc nào không, bao gồm cả thuốc gây mê.


  * Ăn mặc thoải mái, không nên đeo đồ trang sức.


## **Chăm sóc sau khi nội soi dạ dày**
Người bệnh cần lưu viện để nghỉ ngơi và theo dõi trong vòng một vài giờ sau khi nội soi. Đặc biệt các trường hợp nội soi dạ dày gây mê nên nhờ người đưa về. Bởi vì ảnh hưởng của chất gây mê và thuốc an thần sẽ khiến người bệnh sẽ cảm thấy buồn ngủ, không đủ tỉnh táo để tham gia giao thông.
Khi về nhà, bệnh nhân sẽ có một vài triệu chứng khó chịu như đầy hơi, tức bụng, quặn bụng, đau rát họng…. Những biểu hiện này sẽ nhanh chóng chấm dứt nên bệnh nhân không cần lo lắng quá. Nếu cảm thấy khó chịu hoặc những triệu chứng nêu trên có dấu hiệu nghiêm trọng hơn, hãy gọi ngay cho bác sĩ.
Về vấn đề ăn uống, khoảng 2 giờ sau khi nội soi bệnh nhân có thể dùng các thức ăn mềm, lỏng, dễ tiêu hóa như cháo, sữa nguội… Lưu ý không dùng sữa nóng vì có thể làm dạ dày tổn thương.
**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/) **- Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [Nội soi dạ dày là gì?](https://bvnguyentriphuong.com.vn/noi-soi/tat-tan-tat-thong-tin-ve-noi-soi-da-day#ni-soi-d-dy-l-g)
  * [Khi nào cần thực hiện nội soi dạ dày?](https://bvnguyentriphuong.com.vn/noi-soi/tat-tan-tat-thong-tin-ve-noi-soi-da-day#khi-no-cn-thc-hin-ni-soi-d-dy)
  * [Các phương pháp nội soi dạ dày](https://bvnguyentriphuong.com.vn/noi-soi/tat-tan-tat-thong-tin-ve-noi-soi-da-day#cc-phng-php-ni-soi-d-dy)
  * [Vì sao nội soi được đánh giá là tối ưu nhất trong chẩn đoán bệnh dạ dày?](https://bvnguyentriphuong.com.vn/noi-soi/tat-tan-tat-thong-tin-ve-noi-soi-da-day#v-sao-ni-soi-c-nh-gi-l-ti-u-nht-trong-chn-on-bnh-d-dy)
  * [Nội soi dạ dày có nguy hiểm không?](https://bvnguyentriphuong.com.vn/noi-soi/tat-tan-tat-thong-tin-ve-noi-soi-da-day#ni-soi-d-dy-c-nguy-him-khng)
  * [Chuẩn bị trước khi nội soi dạ dày](https://bvnguyentriphuong.com.vn/noi-soi/tat-tan-tat-thong-tin-ve-noi-soi-da-day#chun-b-trc-khi-ni-soi-d-dy)
  * [Chăm sóc sau khi nội soi dạ dày](https://bvnguyentriphuong.com.vn/noi-soi/tat-tan-tat-thong-tin-ve-noi-soi-da-day#chm-sc-sau-khi-ni-soi-d-dy)



## ️ Phát hiện sớm khối u đại tràng nhờ nội soi đường tiêu hóa

Nội soi đường tiêu hóa là biện pháp tốt nhất được nhiều chuyên gia và các bác sĩ chuyên môn áp dụng nhằm phát hiện sớm các bệnh lý về đường tiêu hóa, trong đó có bệnh về đại tràng. Nội soi đường tiêu hóa, cụ thể là nội soi đại tràng là giải pháp an toàn cho người bệnh, đồng thời cũng là “chìa khóa” giúp phát hiện sớm khối u đại tràng, sàng lọc bệnh ung thư đại trực tràng và các bệnh lý khác về đại tràng.
**Nội soi đường tiêu hóa hay nội soi đại tràng là gì?**     
Nội soi đại tràng là biện pháp tốt nhất giúp phát hiện chính xác các bệnh lý gặp phải ở đại tràng và tầm soát phát hiện sớm các bệnh ung thư đại tràng, ung thư đại trực tràng. (ảnh minh họa)
Nội soi đường tiêu hóa hay còn gọi là nội soi tiêu hóa, đây là một kỹ thuật y học được các bác sĩ sử dụng để chẩn đoán hoặc can thiệp điều trị, phát hiện sớm các bệnh lý thuộc cơ quan tiêu hóa như dạ dày, thực quản, tá tràng, đại tràng,… Nội soi đường tiêu hóa sẽ giúp phát hiện sớm các khối u ở cơ quan tiêu hóa, tầm soát các bệnh lý ung thư hay gặp nhất ở đường tiêu hóa như ung thư dạ dày, ung thư thực quản, ung thư đại trực tràng.
Nội soi đại tràng là một hình thức kiểm tra để phát hiện những thay đổi bất thường trong ruột già (đại tràng) và trực tràng. Bác sĩ sẽ sử dụng một ống mềm đưa từ lỗ hậu môn qua toàn bộ đại tràng đến tận manh tràng. Đầu ống mềm có gắn thiết bị camera và đèn soi, giúp quan sát bên trong niêm mạc đại tràng, hình ảnh thu được sẽ được phóng đại trên màn hình màu có độ nét cao, cho phép các bác sĩ phát hiện những tổn thương, bất thường ở đại tràng như viêm đại tràng, polyp, khối u… từ đó có hướng xử lý và điều trị hiệu quả nhất.
**Tầm quan trọng của nội soi đường tiêu hóa?**     
Nội soi trực tràng là biện pháp an toàn giúp phát hiện và điều trị sớm các bệnh lý đại tràng, ung thư đại tràng gặp dễ gặp phải. (ảnh minh họa)
Nội soi đường tiêu hóa cụ thể là nội soi đại tràng sẽ giúp sẽ giúp bác sĩ phát hiện các bất thường ở đại tràng của người bệnh như viêm loét đại tràng, các polyp, khối u, các tổn thương gây chảy máu đại tràng, các vật lạ hoặc ký sinh trùng. Hiện nay với kỹ thuật nội soi hiện đại giúp cho các bác sĩ phát hiện vùng niêm mạc lành và các khối u nghi ngờ ung thư rõ nét hơn, cho phép phát hiện những tổn thương nhỏ kể cả các tổn thương nhỏ 2mm …
Nội soi đại tràng có thể phát hiện các thương tổn ở đại tràng, đặc biệt là những thương tổn có khả năng phát triển thành ung thư ở giai đoạn sớm mà phương pháp X-quang hay siêu âm bụng dễ bỏ sót. Khi phát hiện các bất thường, bác sĩ có thể tiến hành can thiệp như: sinh thiết lấy mẫu bệnh phẩm chẩn đoán mức độ biến đổi tế bào, chẩn đoán chính xác ung thư, qua nội soi các bác sĩ có thể can thiệp cầm máu (nếu đang chảy máu) hoặc cắt polyp để tránh polyp chảy máu.
Chính vì vậy nội soi đường tiêu hóa nói chung hay nội soi đại tràng nói riêng là “chìa khóa” giúp bạn phát hiện các bệnh lý về đại tràng đang mắc phải, đồng thời giúp phát hiện và tầm soát sớm các khối u bên trong đường tiêu hóa để tránh các bệnh lý ung thư đường tiêu hóa có thể xảy ra.
**Khi nào cần nội soi đường tiêu hóa**
Quá trình nội soi đại tràng chỉ diễn ra khoảng 15-30 phút. Người bệnh sẽ được nội soi gây mê do đó sẽ không có cảm giác đau rát hay khó chịu, đồng thời có thể xuất viện ngay sau khi nội soi khoảng 1h-2h. Chính vì vậy khi có các dấu hiệu sau bạn cần đi kiểm tra sớm để chủ động phát hiện các bệnh lý về đường tiêu hóa, đặc biệt có thể phát hiện và tầm soát sớm các bệnh lý ung thư đường tiêu hóa từ đó có biện pháp can thiệp và điều trị sớm nhất.
Các dấu hiệu bạn nên nội soi đại tràng sớm:
  * Đau bụng, thay đổi thói quen đại tiện, tiêu chảy, táo bón, kéo dài, sụt cân không rõ lý do.
  * Bị thiếu máu thiếu sắt hồng cầu nhỏ mà không rõ nguyên nhân.
  * Có tiền sử polyp hay ung thư đại tràng trước đây.
  * Những người bị viêm loét đại tràng chảy máu hoặc bị bệnh Crohn.
  * Những người có tiền sử gia đình: bố mẹ, anh em ruột và con bị ung thư đại trực tràng cần soi đại tràng để sàng lọc ở tuổi 40 hoặc trước 10 năm so với tuổi của người thân bị ung thư đại trực tràng.
  * Phần lớn ung thư đại trực tràng xuất hiện ở những người từ 40 tuổi. Chính vì vậy cần tiến hành chủ động nội soi đại tràng ngay cả khi không có triệu chứng. Theo thống kê có đến 90% bệnh nhân có thể điều trị và chữa khỏi ung thư đại trực tràng nếu như được tầm soát và phát hiện bệnh sớm.


Để bảo vệ sức khỏe và tầm soát phát hiện sớm các bệnh lý ung thư đường tiêu hóa, bạn nên chủ động nội soi đường tiêu hóa và thăm khám với các bác sỹ chuyên khoa tiêu hóa khi mới phát hiện các dấu hiệu nghi ngờ bệnh lý. Đây là một việc làm rất quan trọng và cần thiết.
**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/) **- Đa khoa Hạng I Thành phố Hồ Chí Minh

## ️ Các phương pháp nội soi đại tràng

  * [Các phương pháp nội soi đại tràng](https://bvnguyentriphuong.com.vn/noi-soi/cac-phuong-phap-noi-soi-dai-trang#cc-phng-php-ni-soi-i-trng)
  * [Nên nội soi đại tràng ở đâu?](https://bvnguyentriphuong.com.vn/noi-soi/cac-phuong-phap-noi-soi-dai-trang#nn-ni-soi-i-trng-u)


## **Các phương pháp nội soi đại tràng**
Hiện nay, có 2 phương pháp nội soi đại tràng đang được áp dụng tại nhiều cơ sở y tế, bệnh viện:
  * Nội soi đại tràng thường


Ở phương pháp này, người bệnh được nội soi trong tình trạng hoàn toàn tỉnh táo, vì thế có thể người bệnh sẽ gặp phải tình trạng khó chịu trong quá trình nội soi.
  * Nội soi đại tràng gây mê


Ở phương pháp này, người bệnh được gây mê ngắn, chỉ như vừa trải qua một giấc ngủ sâu, sau khi tỉnh dậy thì quá trình nội soi đại tràng đã kết thúc.
Có 2 phương pháp nội soi đại tràng là nội soi đại tràng thường và nội soi đại tràng gây mê
Khi nội soi đại tràng gây mê, người bệnh sẽ không có cảm giác khó chịu hay đau đớn gì, hoàn toàn thoải mái, nhẹ nhàng sau khi nội soi.
Đối với nội soi đại tràng gây mê, người bệnh cần nằm lại viện khoảng 1 giờ để thuốc mê hết tác dụng, sau đó có thể ra về và sinh hoạt bình thường.
### **Nên nội soi đại tràng ở đâu?**
Nội soi đại tràng là một phương pháp thăm khám quan trọng nhưng có thể tiềm ẩn nhiều rủi ro. Nếu không nội soi tại địa chỉ uy tín, người bệnh có thể gặp phải một số biến chứng như:
  * Xuất huyết đại tràng
  * Đau, chảy máu hậu môn
  * Viêm nhiễm
  * Lây nhiễm bệnh


**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/) **- Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [Các phương pháp nội soi đại tràng](https://bvnguyentriphuong.com.vn/noi-soi/cac-phuong-phap-noi-soi-dai-trang#cc-phng-php-ni-soi-i-trng)
  * [Nên nội soi đại tràng ở đâu?](https://bvnguyentriphuong.com.vn/noi-soi/cac-phuong-phap-noi-soi-dai-trang#nn-ni-soi-i-trng-u)



## ️ Nội soi đại tràng có ảnh hưởng gì không?

  * [Nội soi đại tràng là gì? ](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-dai-trang-co-anh-huong-gi-khong#ni-soi-i-trng-l-g)
  * [Nội soi đại tràng có ảnh hưởng gì không?](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-dai-trang-co-anh-huong-gi-khong#ni-soi-i-trng-c-nh-hng-g-khng)
  * [Lưu ý sau khi nội soi đại tràng](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-dai-trang-co-anh-huong-gi-khong#lu-sau-khi-ni-soi-i-trng)


## **Nội soi đại tràng là gì?**
Nội soi đại tràng là một phương pháp kiểm tra toàn bộ bên trong đại tràng bằng một ống nội soi mềm, có nguồn sáng và gắn camera. Ống nội soi này được luồn qua lỗ hậu môn vào đại tràng, giúp bác sĩ quan sát toàn bộ các hình ảnh bên trong đại tràng.
Nội soi đại tràng là một phương pháp kiểm tra toàn bộ bên trong đại tràng bằng một ống nội soi mềm
Hiện này, có 2 phương pháp nội soi đại tràng đang được áp dụng là nội soi đại tràng gây mê và nội soi đại tràng thường.
  * Nội soi đại tràng gây mê: Ở phương pháp nội soi đại tràng gây mê, người bệnh sẽ được đưa vào trạng thái tiền mê (gây mê ngắn) như vừa trải qua một giấc ngủ sâu. Khi được gây mê, người bệnh sẽ không có cảm giác khó chịu hay đau trong quá trình nội soi đại tràng, giúp quá trình nội soi diễn ra nhanh chóng hơn.
  * Nội soi đại tràng thường: Ở phương pháp này, người bệnh có thể gặp phải tình trạng đau, khó chịu, vướng khi nội soi đại tràng khiến quá trình nội soi bị gián đoạn.


## **Nội soi đại tràng có ảnh hưởng gì không?**
Một trong những thắc mắc chung được nhiều người quan tâm, tìm hiểu là nội soi đại tràng có ảnh hưởng gì không?
Đây là một phương pháp nội soi tương đối an toàn, không gây ảnh hưởng tới sức khỏe. Tuy nhiên người bệnh cũng có thể gặp phải một số rủi ro như xuất huyết đại tràng hoặc thủng đại tràng nếu nội soi tại những địa chỉ, cơ sở y tế không đảm bảo.
Nếu nội soi đại tràng ở những địa chỉ không uy tín có thể gặp một số rủi ro như xuất huyết đại tràng
## **Lưu ý sau khi nội soi đại tràng**
Người bệnh sau khi nội soi đại tràng cần nghỉ ngơi khoảng 1 giờ sau nội soi để thuốc gây mê hết tác dụng.
Tuân thủ theo đúng chỉ định của bác sĩ về phương pháp điều trị bệnh ở đại tràng.
Cần chú ý tới chế độ ăn uống và sinh hoạt hàng ngày, không vận động, làm việc nặng, quá sức.
Theo dõi tình trạng sức khỏe và tái khám định kỳ theo đúng lịch hẹn của bác sĩ.
**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/) **- Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [Nội soi đại tràng là gì? ](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-dai-trang-co-anh-huong-gi-khong#ni-soi-i-trng-l-g)
  * [Nội soi đại tràng có ảnh hưởng gì không?](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-dai-trang-co-anh-huong-gi-khong#ni-soi-i-trng-c-nh-hng-g-khng)
  * [Lưu ý sau khi nội soi đại tràng](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-dai-trang-co-anh-huong-gi-khong#lu-sau-khi-ni-soi-i-trng)



## ️ Tại sao phải nội soi đại tràng?

Tại sao phải nội soi đại tràng? Nội soi đại tràng như thế nào… là những thắc mắc chung được nhiều người quan tâm, tìm hiểu. Bài viết dưới đây sẽ giúp giải đáp những câu hỏi của độc giả về dịch vụ nội soi đại tràng.
**Tại sao phải nội soi đại tràng?**
Đây là một trong những thắc mắc được nhiều người đặt ra. Nội soi đại tràng là một trong những phương pháp thăm khám phổ biến và tương đối an toàn, hiệu quả. Tuy nhiên không phải ai cũng biết được tầm quan trọng của việc nội soi đại tràng.
Khi có vấn đề ở đại tràng, người bệnh cần tiến hành nội soi đại tràng để chẩn đoán chính xác bệnh
Nội soi đại tràng thường được chỉ định trong những trường hợp:
  * Có vấn đề ở đại tràng: đau bụng không rõ nguyên nhân, đi ngoài ra máu, nôn ra máu…
  * Để chẩn đoán các vấn đề ở đại tràng như viêm loét, polyp hoặc ung thư.
  * Tầm soát ung thư đại trực tràng
  * Hỗ trợ điều trị các bệnh lý ở đại trực tràng như sinh thiết u hoặc cắt polyp.
  * Theo dõi sau điều trị ung thư hoặc polyp.


Nội soi đại tràng được khuyến khích áp dụng cho những người có độ tuổi trên 40 hoặc có tiền sử gia đình mắc ung thư đại trực tràng, polyp gia đình. Những đối tượng này nên nội soi định kỳ 1 năm/ lần nhằm theo dõi tình trạng sức khỏe, phát hiện sớm bất thường tiềm ẩn trong cơ thể.
**Nội soi đại tràng như thế nào?**
Nội soi đại tràng là một thủ thuật thăm khám toàn bộ bên trong đại tràng bằng một ống nội soi mềm, nhỏ có đường kính khoảng 1cm. Bác sĩ sẽ đưa ống nội soi có gắn nguồn sáng và camera vào cơ thể qua lỗ hậu môn. Nhờ quan sát hình ảnh trên máy soi, bác sĩ có thể biết được các bất thường đang xảy ra bên trong ruột. Từ đó, có được chẩn đoán và phương pháp điều trị thích hợp.
Nội soi đại tràng là một thủ thuật thăm khám toàn bộ bên trong đại tràng bằng một ống nội soi mềm, được luồn vào cơ thể qua lỗ hậu môn
Trước khi nội soi, người bệnh cần làm sạch đại tràng để tránh che khuất tầm nhìn trong quá trình thực hiện nội soi.
Trước khi tiến hành nội soi, người bệnh được kiểm tra hậu môn để đánh giá các tổn thương nếu có. Sử dụng thuốc tê tại chỗ làm giảm khó chịu khi đưa ống soi vào đồng thời có tác dụng bôi trơn.
Khi nội soi, bệnh nhân nằm nghiêng bên trái. Ống soi sẽ được đưa vào hậu môn và dần dần đi sâu vào các đoạn ruột. Quá trình nội soi đại tràng thường kéo dài khoảng 20 phút. Trong một số trường hợp, bệnh nhân sẽ được tiêm thuốc an thần hay chống co thắt để bớt cảm giác khó chịu.
Nội soi đại tràng là phương pháp nội soi tương đối an toàn, ít biến chứng. Người bệnh có thể gặp phải một số tác dụng phụ như chướng bụng hoặc buồn xì hơi… Những triệu chứng này sẽ mất dần sau nội soi nên người bệnh không cần quá lo lắng.
**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/) **- Đa khoa Hạng I Thành phố Hồ Chí Minh

## ️Nội soi dạ dày tá tràng

  * [Những ai nên nội soi dạ dày tá tràng](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-da-day-ta-trang#nhng-ai-nn-ni-soi-d-dy-t-trng)
  * [Các phương pháp nội soi dạ dày tá tràng](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-da-day-ta-trang#cc-phng-php-ni-soi-d-dy-t-trng)
  * [Nội soi dạ dày tá tràng thường](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-da-day-ta-trang#ni-soi-d-dy-t-trng-thng)
  * [Nội soi dạ dày tá tràng gây mê](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-da-day-ta-trang#ni-soi-d-dy-t-trng-gy-m)
  * [Nội soi dạ dày tá tràng đường mũi](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-da-day-ta-trang#ni-soi-d-dy-t-trng-ng-mi)


Nội soi dạ dày tá tràng là phương pháp dùng để chẩn đoán các bệnh lý ở đường tiêu hóa trên. Phương pháp này không những phát hiện những tổn thương trong dạ dày – tá tràng mà thông qua nội soi, bác sĩ có thể tầm soát ung thư hoặc theo dõi điều trị bệnh.
## **Những ai nên nội soi dạ dày tá tràng**
Nội soi dạ dày tá tràng là phương pháp thăm khám trực tiếp phần trên của ống tiêu hóa bao gồm thực quản, dạ dày và tá tràng nhờ vào một ống nội soi mềm có gắn nguồn sáng và camera.
Những hình ảnh thu được qua nội soi sẽ giúp bác sĩ phát hiện những bất thường đang xảy ra bên trong ống tiêu hóa. Từ đó chẩn đoán và có phương pháp điều trị phù hợp.
**Nội soi dạ dày tá tràng là phương pháp thăm khám trực tiếp phần trên của ống tiêu hóa bao gồm thực quản, dạ dày và tá tràng.**
Nội soi dạ dày tá tràng thường được chỉ định trong các trường hợp như:
  * Khó nuốt, nuốt nghẹn.
  * Đau thượng vị hoặc đau ngực không phải do bệnh tim.
  * Mắc chứng trào ngược dạ dày thực quản.
  * Bị sút cân nhanh chóng và thường xuyên có cảm giác chán ăn.
  * Thường xuyên buồn nôn và nôn không rõ nguyên nhân.
  * Xuất huyết đường tiêu hóa trên và giãn tĩnh mạch thực quản.
  * Bị viêm lóe dạ dày tá tràng.
  * Dạ dày tá tràng bị tổn thương do nuốt phải chất ăn mòn như chất tẩy rửa, dung dịch kiềm…


Nội soi dạ dày tá tràng có thể gặp phải một số rủi ro như nhiễm trùng, chảy máu hoặc thủng dạ dày tá tràng. Vì thế trước khi tiến hành nội soi dạ dày tá tràng, người bệnh cần lựa chọn những địa chỉ nội soi an toàn, uy tín.
## **Các phương pháp nội soi dạ dày tá tràng**
Hiện nay có nhiều phương pháp nội soi dạ dày tá tràng đang được áp dụng như:
### **Nội soi dạ dày tá tràng thường**
Đây là phương pháp khám nội soi dạ dày truyền thống qua đường miệng. Người bệnh hoàn toàn tỉnh táo khi thực hiện nội soi dạ dày tá tràng. Bác sĩ sẽ thao tác nhẹ nhàng, kỹ thuật tốt sẽ giảm đáng kể cảm giác khó chịu khi nội soi. Tuy nhiên đa phần người bệnh e ngại với phương pháp này vì gây đau và khó chịu, buồn nôn.
### **Nội soi dạ dày tá tràng gây mê**
Ở phương pháp này người bệnh được đưa vào trạng thái tiền mê, tức là gây mê ngắn, rất an toàn, chỉ trong khoảng 15 phút để tiến hành nội soi. Đây là phương pháp được nhiều người bệnh lựa chọn bởi không có cảm giác khó chịu hay buồn nôn hay đau đớn gì.
### **Nội soi dạ dày tá tràng đường mũi**
Đây là phương pháp nội soi hiện đại giúp khắc phục những nhược điểm của phương pháp nội soi thường. Người bệnh được nội soi qua đường mũi, hoàn toàn tỉnh táo và không có bất cứ cảm giác buồn nôn, hoặc nôn. Ở phương pháp này, người bệnh không cần gây mê và có thể ra về ngay sau khi nội soi. Phương pháp này ngày càng được nhiều người bệnh tin tưởng lựa chọn và an tâm hơn trong khi nội soi dạ dày tá tràng.
**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/) **- Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [Những ai nên nội soi dạ dày tá tràng](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-da-day-ta-trang#nhng-ai-nn-ni-soi-d-dy-t-trng)
  * [Các phương pháp nội soi dạ dày tá tràng](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-da-day-ta-trang#cc-phng-php-ni-soi-d-dy-t-trng)
  * [Nội soi dạ dày tá tràng thường](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-da-day-ta-trang#ni-soi-d-dy-t-trng-thng)
  * [Nội soi dạ dày tá tràng gây mê](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-da-day-ta-trang#ni-soi-d-dy-t-trng-gy-m)
  * [Nội soi dạ dày tá tràng đường mũi](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-da-day-ta-trang#ni-soi-d-dy-t-trng-ng-mi)



## ️ Nội soi đại tràng có nguy hiểm không?

  * [1. Nội soi đại tràng có nguy hiểm không?](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-dai-trang-co-nguy-hiem-khong#1-ni-soi-i-trng-c-nguy-him-khng)
  * [2. Cần chuẩn bị gì trước nội soi đại tràng](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-dai-trang-co-nguy-hiem-khong#2-cn-chun-b-g-trc-ni-soi-i-trng)


## **1. Nội soi đại tràng có nguy hiểm không?**
Nội soi đại tràng có nguy hiểm không? Có thể khẳng định rằng nội soi đại tràng không hề nguy hiểm đến tính mạng cũng như sức khỏe của con người. Đây là một quá trình nội soi khá an toàn và không gây nhiều biến chứng cho người bệnh.
Nội soi đại tràng là một phương pháp tiên tiến, được áp dụng ở rất nhiều bệnh viện lớn. Kỹ thuật này được các bác sĩ có trình độ chuyên môn cao áp dụng để điều trị các bệnh liên quan đến đại tràng. Với kỹ thuật điêu luyện, các kết quả của quá trình nội soi thường mang tính chính xác cao. Nhiều bệnh nhân đã được cứu chữa kịp thời, tránh được những nguy cơ ảnh hưởng đến tính mạng.
Nội soi đại tràng giúp chẩn đoán chính xác các bệnh lý đại trực tràng
Quá trình nội soi đại tràng được tiến hành bởi một quy trình chặt chẽ, mang tính khoa học cao. Bác sĩ sẽ sử dụng một ống mềm ở đầu ống có camera. Các hình ảnh trong đại tràng sẽ được chiếu rõ nét thông qua hệ thống camera này. Đây là cách giúp các bác sĩ có thể tìm thấy được những tổn thương nhỏ nhất trong đại tràng.
## **2. Cần chuẩn bị gì trước nội soi đại tràng**
Trước khi nội soi, bệnh nhân được kiểm tra hậu môn để đánh giá các tổn thương nếu có. Sử dụng thuốc tê tại chỗ làm giảm khó chịu khi đưa ống soi vào đồng thời có tác dụng bôi trơn.
Khi nội soi, bệnh nhân nằm nghiêng bên trái. Ống soi sẽ được đưa vào hậu môn và dần dần đi sâu vào các đoạn ruột. Thỉnh thoảng người bệnh được yêu cầu thay đổi tư thế hoặc y tá sẽ ấn nhẹ vào bụng người bệnh. Những biện pháp này giúp ống soi đi dễ dàng và ít gây đau hơn. Quá trình nội soi đại tràng thường kéo dài khoảng 20 phút. Trong một số trường hợp, bệnh nhân sẽ được tiêm thuốc an thần hay chống co thắt để bớt cảm giác khó chịu.
**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/) **- Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [1. Nội soi đại tràng có nguy hiểm không?](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-dai-trang-co-nguy-hiem-khong#1-ni-soi-i-trng-c-nguy-him-khng)
  * [2. Cần chuẩn bị gì trước nội soi đại tràng](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-dai-trang-co-nguy-hiem-khong#2-cn-chun-b-g-trc-ni-soi-i-trng)



## ️ Nội soi dạ dày cần chuẩn bị gì?

  * [Nội soi dạ dày bằng phương pháp nào?](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-da-day-can-chuan-bi-gi#ni-soi-d-dy-bng-phng-php-no)
  * [Những thứ cẩn chuẩn bị trước khi nội soi dạ dày](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-da-day-can-chuan-bi-gi#nhng-th-cn-chun-b-trc-khi-ni-soi-d-dy)


## **Nội soi dạ dày bằng phương pháp nào?**
Nội soi dạ dày là phương pháp thăm khám toàn bộ dạ dày bằng ống nội soi mềm, có gắn camera. Bác sĩ sẽ luồn ống nội soi vào dạ dày thông qua đường miệng hoặc mũi.
Nội soi dạ dày là phương pháp thăm khám toàn bộ dạ dày bằng ống nội soi mềm có gắn camera
Hiện nay, có 3 phương pháp nội soi thường được áp dụng:
  * Nội soi không gây mê: Phương pháp này thường đem lại cảm giác khó chịu, đau đớn, buồn nôn và nôn cho người bệnh.


  * Nội soi gây mê: Người bệnh sẽ được tiêm thuốc mê làm mất cảm giác đau đớn và khó chịu khi nội soi. Người bệnh chỉ như vừa trải qua một giấc ngủ sâu, không ảnh hưởng tới sức khỏe.
  * Nội soi đường mũi: Phương pháp này không cần gây mê, người bệnh hoàn toàn tỉnh táo trong suốt quá trình nội soi. Ở phương pháp này, người bệnh không có cảm giác đau đớn, khó chịu, buồn nôn vì ống nội soi được đưa vào dạ dày qua đường mũi, không gây kích thích vòm họng, khẩu cái.


### **Những thứ cẩn chuẩn bị trước khi nội soi dạ dày**
Trước khi nội soi dạ dày, người bệnh cần nhịn ăn ít nhất 6 giờ
_-Trước khi nội soi dạ dày_
  * Người bệnh cần nhịn ăn khoảng 6 tiếng giúp bác sĩ có thể quan sát rõ hơn các tổn thương trong dạ dày. Việc này cũng giúp làm giảm khả năng nôn và ngăn tình trạng thức ăn trào ngược lên thực quản.
  * Cần tránh những loại đồ uống có màu đỏ hoặc đen như cocacola, rượu vang…
  * Người bệnh có thể uống nước lọc với số lượng vừa phải.
  * Cần thông báo với bác sĩ về các loại thuốc đang sử dụng để điều trị bệnh như thuốc tim mạch, huyết áp… hoặc các loại thuốc gây dị ứng.


**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/) **- Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [Nội soi dạ dày bằng phương pháp nào?](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-da-day-can-chuan-bi-gi#ni-soi-d-dy-bng-phng-php-no)
  * [Những thứ cẩn chuẩn bị trước khi nội soi dạ dày](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-da-day-can-chuan-bi-gi#nhng-th-cn-chun-b-trc-khi-ni-soi-d-dy)



## ️ Quy trình nội soi đại tràng

  * [Vì sao cần nội soi đại tràng?](https://bvnguyentriphuong.com.vn/noi-soi/quy-trinh-noi-soi-dai-trang#v-sao-cn-ni-soi-i-trng)
  * [Quy trình nội soi đại tràng](https://bvnguyentriphuong.com.vn/noi-soi/quy-trinh-noi-soi-dai-trang#quy-trnh-ni-soi-i-trng)
  * [Làm sạch đại tràng:](https://bvnguyentriphuong.com.vn/noi-soi/quy-trinh-noi-soi-dai-trang#lm-sch-i-trng)
  * [Kiểm tra hậu môn](https://bvnguyentriphuong.com.vn/noi-soi/quy-trinh-noi-soi-dai-trang#kim-tra-hu-mn)
  * [Tiến hành nội soi đại tràng](https://bvnguyentriphuong.com.vn/noi-soi/quy-trinh-noi-soi-dai-trang#tin-hnh-ni-soi-i-trng)
  * [Kết thúc quá trình nội soi](https://bvnguyentriphuong.com.vn/noi-soi/quy-trinh-noi-soi-dai-trang#kt-thc-qu-trnh-ni-soi)


## **Vì sao cần nội soi đại tràng?**
Nội soi đại tràng giúp:
  * Xác định nguyên nhân gây ra các triệu chứng đau bụng, chảy máu trực tràng, táo bón, tiêu chảy kéo dài và các vấn đề đường ruột khác.


Nội soi đại tràng giúp phát hiện những bệnh lý tiềm ẩn ở đại tràng
  * Tầm soát ung thư đại tràng
  * Tìm kiếm các polyp trong đại tràng để cắt bỏ chúng.


### **Quy trình nội soi đại tràng**
Khi được thăm khám và chỉ định làm **nội soi đại tràng** , người bệnh cần tuân thủ theo quy trình sau:
  * #### Làm sạch đại tràng:


Đây là bước đầu tiên và quan trọng trước khi bắt đầu nội soi đại tràng. Người bệnh cần làm sạch đại tràng để tránh che khuẩn tầm nhìn trong khi nội soi.
Trước khi nội soi đại tràng người bệnh cần làm sạch đại tràng bằng cách tránh đồ uống có ga
Để làm sạch đại tràng, người bệnh cần: Tránh những thức ăn dạng rắn, thực phẩm quá nhiều chất xơ trước khi tiến hành nội soi đại tràng; Tránh tiêu thụ các loại đồ uống có ga, màu đỏ vì dễ nhầm lẫn với máu. Có thể sử dụng dụng cụ tháo thụt để làm sạch toàn bộ đại tràng.
  * #### Kiểm tra hậu môn


Trước khi nội soi, người bệnh được kiểm tra hậu môn nhằm đánh giá các tổn thương nếu có. Đồng thời được sử dụng thuốc tê tại chỗ để làm giảm khó chịu khi đưa ống nội soi vào.
  * #### Tiến hành nội soi đại tràng


Người bệnh được nằm nghiêng bên trái. Ống soi sẽ được đưa vào hậu môn và dần dần đi sâu vào các đoạn ruột.
Trong quá trình nội soi, người bệnh có thể thay đổi tư thế hoặc y tá sẽ ấn nhẹ vào bụng người bệnh. Biện pháp này giúp ống soi đi dễ dàng và ít gây đau hơn.
Quá trình nội soi đại tràng thường kéo dài khoảng 20 phút. Trong một số trường hợp, bệnh nhân sẽ được tiêm thuốc an thần hay chống co thắt để bớt cảm giác khó chịu.
  * #### Kết thúc quá trình nội soi


Người bệnh được chuyển ra phòng bệnh và nằm nghỉ ngơi trong khoảng 1 giờ để thuốc an thần hết tác dụng, sau đó có thể ra về ngay. Tuy nhiên, người bệnh không nên tự ý lái xe, cần người nhà giúp đỡ.
**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/) **- Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [Vì sao cần nội soi đại tràng?](https://bvnguyentriphuong.com.vn/noi-soi/quy-trinh-noi-soi-dai-trang#v-sao-cn-ni-soi-i-trng)
  * [Quy trình nội soi đại tràng](https://bvnguyentriphuong.com.vn/noi-soi/quy-trinh-noi-soi-dai-trang#quy-trnh-ni-soi-i-trng)
  * [Làm sạch đại tràng:](https://bvnguyentriphuong.com.vn/noi-soi/quy-trinh-noi-soi-dai-trang#lm-sch-i-trng)
  * [Kiểm tra hậu môn](https://bvnguyentriphuong.com.vn/noi-soi/quy-trinh-noi-soi-dai-trang#kim-tra-hu-mn)
  * [Tiến hành nội soi đại tràng](https://bvnguyentriphuong.com.vn/noi-soi/quy-trinh-noi-soi-dai-trang#tin-hnh-ni-soi-i-trng)
  * [Kết thúc quá trình nội soi](https://bvnguyentriphuong.com.vn/noi-soi/quy-trinh-noi-soi-dai-trang#kt-thc-qu-trnh-ni-soi)



## ️ Nội soi đại tràng là như thế nào?

  * [Những ai nên nội soi đại tràng? ](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-dai-trang-la-nhu-the-nao#nhng-ai-nn-ni-soi-i-trng)
  * [Nội soi đại tràng như thế nào? ](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-dai-trang-la-nhu-the-nao#ni-soi-i-trng-nh-th-no)
  * [Nội soi đại tràng có nguy hiểm không?](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-dai-trang-la-nhu-the-nao#ni-soi-i-trng-c-nguy-him-khng)
  * [Nội soi đại tràng có đau không?](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-dai-trang-la-nhu-the-nao#ni-soi-i-trng-c-au-khng)


## **Những ai nên nội soi đại tràng?**
Nội soi đại tràng là phương pháp thăm khám toàn bộ đại tràng, giúp phát hiện những tổn thương dù là nhỏ nhất trong đại tràng để kịp thời phát hiện và điều trị hiệu quả.
Những người khi có các triệu chứng sau nên tiến hành **khám nội soi đại tràng** :
Khi có dấu hiệu bất thường về sức khỏe, người bệnh nên tiến hành nội soi để được chẩn đoán sớm bệnh
  * Xuất huyết tiêu hóa dưới
  * Mắc các bệnh lý viêm, loét, u đường tiêu hóa dưới
  * Các triệu chứng bệnh lý đường tiêu hóa dưới như tiêu chảy kéo dài, đau bụng từng cơn, sụt cân không rõ nguyên nhân, thiếu máu hoặc đi ngoài ra máu.
  * Những trường hợp đang theo dõi bệnh viêm loét đại tràng
  * Tầm soát phát hiện sớm ung thư đại trực tràng
  * Người đang theo dõi các bệnh lý đại tràng.


## **Nội soi đại tràng như thế nào?**
Nội soi đại tràng là một thủ thuật tương đối an toàn. Bác sĩ sẽ sử dụng một ống nội soi mềm với đường kính khoảng 1 ngón tay, có gắn camera và nguồn sáng. Bác sĩ sẽ luồn ống nội soi qua hậu môn vào đại tràng, giúp quan sát toàn bộ đại tràng.
Nội soi đại tràng còn được sử dụng để cắt polyp đại tràng hoặc làm sinh thiết.
Nội soi đại tràng là phương pháp sử dụng một ống nội soi mềm luồn qua hậu môn vào đại tràng, giúp quan sát toàn bộ đại tràng.
Trước khi tiến hành nội soi, người bệnh được kiểm tra hậu môn, đánh giác các tổn thương nếu có. Sau đó, người bệnh được sử dụng thuốc tê tại chỗ làm giảm khó chịu khi đưa ống nội soi vào.
Khi nội soi đại tràng, người bệnh cần nằm nghiêng bên trái. Thỉnh thoảng, người bệnh có thể thay đổi tư thế, bác sĩ sẽ ấn nhẹ vào bụng để ống nội soi được đi vào dễ dàng hơn, ít đau đớn.
Thời gian diễn ra nội soi đại tràng khoảng 20 phút. Sau khi kết thúc quá trình nội soi, người bệnh được chuyển qua phòng bệnh để nghỉ ngơi cho thuốc gây mê hết tác dụng. Sau đó có thể ra về và sinh hoạt bình thường.
## **Nội soi đại tràng có nguy hiểm không?**
Nội soi đại tràng có rất ít rủi ro, tuy nhiên người bệnh có thể gặp một vài biến chứng như:
  * Phản ứng bất lợi của cơ thể với thuốc an thần được sử dụng khi nội soi.
  * Chảy máu từ vị trí lấy mẫu sinh thiết hoặc polyp hay mô bất thường được loại bỏ.
  * Thủng thành đại tràng hoặc trực tràng.


## **Nội soi đại tràng có đau không?**
Nội soi đại tràng là phương pháp thăm khám ít gây đau, khó chịu bởi người bệnh đã được gây mê ngắn. Vì ống nội soi được đưa vào từ hậu môn nên không cảm giác vướng, khó chịu hay gặp khó khăn gì khi đại tiện.
Để hồi phục nhanh chóng tình trạng sức khỏe, người bệnh cần chú ý lựa chọn các thực phẩm ăn uống hàng ngày phù hợp:
  * Nên ăn các thực phẩm mềm, lỏng, dễ nuốt. Tránh các thực phẩm cứng, chiên rán nhiều dầu mỡ hoặc những thực phẩm đã lên men, có vị chua.
  * Hạn chế rượu bia, thuốc lá, cà phê và đồ uống có ga
  * Ăn đúng giờ, tránh ăn quá nhiều một lúc, nên ăn thành nhiều bữa nhỏ.
  * Tăng cường rau xanh giàu chất xơ. Uống nhiều nước trong ngày.


**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/) **- Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [Những ai nên nội soi đại tràng? ](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-dai-trang-la-nhu-the-nao#nhng-ai-nn-ni-soi-i-trng)
  * [Nội soi đại tràng như thế nào? ](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-dai-trang-la-nhu-the-nao#ni-soi-i-trng-nh-th-no)
  * [Nội soi đại tràng có nguy hiểm không?](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-dai-trang-la-nhu-the-nao#ni-soi-i-trng-c-nguy-him-khng)
  * [Nội soi đại tràng có đau không?](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-dai-trang-la-nhu-the-nao#ni-soi-i-trng-c-au-khng)



## ️ Nội soi nhiều lần có tốt không?

  * [Khi nào cần nội soi?](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-nhieu-lan-co-tot-khong#khi-no-cn-ni-soi)
  * [Nội soi nhiều lần có tốt không?](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-nhieu-lan-co-tot-khong#ni-soi-nhiu-ln-c-tt-khng)


## **Nội soi là gì?**
Nội soi là một phương pháp chẩn đoán giúp phát hiện các bệnh lý tiềm ẩn trong cơ thể. Bác sĩ có thể sử dụng một dụng cụ nội soi có một đầu gắn camera, được đưa vào cơ thể qua lỗ tự nhiên của cơ thể nhằm quan sát toàn bộ bên trong cơ thể như dạ dày, đại tràng… nhằm phát hiện những bất thường như viêm loét, polyp hoặc ung thư.
Nội soi là một phương pháp chẩn đoán giúp phát hiện các bệnh lý tiềm ẩn trong cơ thể.
Hiện tại có 2 loại nội soi là nội soi chẩn đoán và nội soi can thiệp.
  * Nội soi chẩn đoán: Bác sĩ thông qua ống nội soi quan sát bên trong cơ thể để phát hiện những tổn thương hoặc bệnh lý tiềm ẩn trong cơ thể. Qua nội soi chẩn đoán, bác sĩ có thể xét nghiệm tìm vi khuẩn trong dạ dày hoặc lấy mẫu mô sinh thiết nhằm chẩn đoán ung thư.
  * Nội soi can thiệp: Là thông qua nội soi, bác sĩ sẽ tiến hành các thủ thuật nhàm điều trị cho bệnh nhân như cắt polyp, cầm máu, gắp dị vật hoặc cắt bỏ các khối u…


### **Khi nào cần nội soi?**
Khi có những triệu chứng nghi ngờ mắc các bệnh lý ở đường tiêu hóa thì người bệnh cần áp dụng biện pháp nội soi để chẩn đoán bệnh.
  * Thường xuyên ợ hơi, ợ chua, đau bụng, rối loạn tiêu hóa
  * Buồn nôn và nôn
  * Giảm cân không rõ nguyên nhân


Khi có những triệu chứng nghi ngờ mắc bệnh cần tiến hành nội soi
  * Có tiền sử gia đình mắc polyp hoặc ung thư
  * Theo dõi và điều trị các bệnh ở đường tiêu hóa


Để nội soi nhanh chóng, an toàn và đạt hiệu quả cao, người bệnh cần tới các cơ sở y tế, bệnh viện có đủ trang thiết bị y tế và đội ngũ bác sĩ chuyên môn giỏi. Có như vậy mới giúp chẩn đoán chính xác tình trạng bệnh.
### **Nội soi nhiều lần có tốt không?**
Nội soi là phương pháp tương đối an toàn tuy nhiên không nên lạm dụng nhiều. Người bệnh có thể gặp phải một số biến chứng sau nội soi như đau bụng hoặc chảy máu.
Lời khuyên của các chuyên gia y tế, người bệnh chỉ nên nội soi 1 năm/ lần nếu triệu chứng bệnh không thuyên giảm hoặc nội soi nhằm theo dõi tình trạng bệnh theo chỉ định cụ thể của bác sĩ.
**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/) **- Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [Khi nào cần nội soi?](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-nhieu-lan-co-tot-khong#khi-no-cn-ni-soi)
  * [Nội soi nhiều lần có tốt không?](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-nhieu-lan-co-tot-khong#ni-soi-nhiu-ln-c-tt-khng)



## ️ Cần làm gì sau khi thực hiện nội soi dạ dày?

Nội soi dạ dày là phương pháp thường được sử dụng để chẩn đoán các bệnh lý ở dạ dày như đau dạ dày, viêm loét dạ dày, ung thư dạ dày… Vậy cần làm gì sau khi thực hiện nội soi dạ dày? Bài viết dưới đây sẽ giúp giải đáp thắc mắc này.
**Cần làm gì sau khi thực hiện nội soi dạ dày?**
_Chú ý ăn uống_
Sau khi nội soi dạ dày, người bệnh nên hạn chế ăn, chỉ uống nước trà nguội hoặc sữa lạnh, không được uống nóng.
Sau 30 phút có thể thể ăn cháo loãng với thức ăn lỏng, mềm, nguội.
Sau khi nội soi dạ dày, người bệnh cần ăn những thực phẩm mềm, lỏng, nguội
Sau 3-4 ngày có thể ăn các thức ăn giàu tinh bột như bánh mì, trứng gà, rau củ quả… Không nên ăn thức ăn chiên rán, nhiều dầu mỡ.
Lưu ý:
Không để bụng quá đói hoặc quá no, nên chia nhỏ bữa ăn thành nhiều bữa trong ngày để giảm gánh nặng cho dạ dày.
Hạn chế các thực phẩm có vị chua như cam, chanh và những thực phẩm lên men như dưa, cà muối.
Tránh rượu bia, thuốc lá, thực phẩm cay, nóng.
_Vệ sinh răng miệng_
Sau khi nội soi dạ dày qua đường miệng thì cần hạn chế khạc nhổ. Cần súc miệng hàng ngày bằng nước muối sinh lý để làm sạch họng, ngăn ngừa tình trạng nhiễm khuẩn, đau rát họng.
Người bệnh cần vệ sinh răng miệng sạch sẽ hàng ngày
_Chú ý nghỉ ngơi_
Sau khi nội soi, người bệnh cần phải nằm nghỉ trong 30 phút (đối với nội soi gây mê). Người bệnh cần được kiểm tra huyết áp, nhịp tim… để chắc chắn sức khỏe đã ổn định sau nội soi.
Cần nghỉ ngơi 1-2 ngày sau khi nội soi mới làm việc trở lại. Người bệnh cần tránh những công việc nặng nhọc hoặc vận động quá mạnh sau khi nội soi dạ dày.
_Tuân thủ theo đúng phương pháp điều trị của bác sĩ_
Nếu sau nội soi dạ dày có phát hiện các bệnh lý ở dạ dày, người bệnh sẽ được kê thuốc điều trị. Người bệnh cần tuân thủ theo đúng đơn thuốc chỉ định của bác sĩ để cải thiện nhanh chóng tình trạng bệnh.
**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/) **- Đa khoa Hạng I Thành phố Hồ Chí Minh

## ️ Hình ảnh nội soi dạ dày

  * [1. Những ai cần thực hiện nội soi dạ dày?](https://bvnguyentriphuong.com.vn/noi-soi/hinh-anh-noi-soi-da-day#1-nhng-ai-cn-thc-hin-ni-soi-d-dy)
  * [2. Một số hình ảnh nội soi dạ dày](https://bvnguyentriphuong.com.vn/noi-soi/hinh-anh-noi-soi-da-day#2-mt-s-hnh-nh-ni-soi-d-dy)


Nội soi dạ dày là một phương pháp giúp phát hiện nhiều bệnh lý khác nhau ở dạ dày như viêm loét hoặc ung thư. Thông qua các hình ảnh nội soi dạ dày, bác sĩ sẽ giúp chẩn đoán chính xác tình trạng bệnh. Từ đó đưa ra phương pháp chữa trị phù hợp.
## **1. Những ai cần thực hiện nội soi dạ dày?**
  * Những người thường có triệu chứng khó tiêu, ợ nóng, đau thượng vị, buồn nôn hoặc nôn, đi ngoài ra máu.
  * Những người cần điều trị những bệnh liên quan đến hệ thống tiêu hóa trên như xuất huyết tiêu hóa, cần cắt bỏ khối u hay polyp ở dạ dày, loại bỏ dị vật…


**Khi thấy xuất hiện những triệu chứng nghi ngờ mắc bệnh lý ở dạ dày, người bệnh cần tiến hành nội soi để xác định bệnh.**
  * Những bệnh nhân sau phẫu thuật dạ dày – tá tràng.
  * Những người có tiền sử gia đình mắc ung thư dạ dày cũng cần tiến hành nội soi dạ dày để phát hiện sớm khối u (nếu có).


## **2. Một số hình ảnh nội soi dạ dày**
Hiện nay, với sự phát triển mạnh mẽ của y học hiện đại, có nhiều phương pháp nội soi dạ dày được áp dụng tại các bệnh viện, cho kết quả chính xác.
**Hình ảnh nội soi dạ dày đường miệng.**
**Hình ảnh nội soi dạ dày phát hiện viêm loét dạ dày.**
**Hình ảnh nội soi dạ dày phát hiện ung thư dạ dày.**
**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/) **- Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [1. Những ai cần thực hiện nội soi dạ dày?](https://bvnguyentriphuong.com.vn/noi-soi/hinh-anh-noi-soi-da-day#1-nhng-ai-cn-thc-hin-ni-soi-d-dy)
  * [2. Một số hình ảnh nội soi dạ dày](https://bvnguyentriphuong.com.vn/noi-soi/hinh-anh-noi-soi-da-day#2-mt-s-hnh-nh-ni-soi-d-dy)



## ️ Những điều cần biết về nội soi đại tràng

  * [Nội soi đại tràng là gì?](https://bvnguyentriphuong.com.vn/noi-soi/nhung-dieu-can-biet-ve-noi-soi-dai-trang#ni-soi-i-trng-l-g)
  * [Tại sao phải nội soi đại tràng?](https://bvnguyentriphuong.com.vn/noi-soi/nhung-dieu-can-biet-ve-noi-soi-dai-trang#ti-sao-phi-ni-soi-i-trng)
  * [Những ai cần nội soi đại tràng?](https://bvnguyentriphuong.com.vn/noi-soi/nhung-dieu-can-biet-ve-noi-soi-dai-trang#nhng-ai-cn-ni-soi-i-trng)
  * [Nội soi đại tràng có nguy hiểm không?](https://bvnguyentriphuong.com.vn/noi-soi/nhung-dieu-can-biet-ve-noi-soi-dai-trang#ni-soi-i-trng-c-nguy-him-khng)
  * [Nội soi đại tràng cần chuẩn bị như thế nào?](https://bvnguyentriphuong.com.vn/noi-soi/nhung-dieu-can-biet-ve-noi-soi-dai-trang#ni-soi-ai-trang-cn-chun-bi-nhu-th-nao)


## **Nội soi đại tràng là gì?**
Nội soi đại tràng là phương pháp thăm khám trực tiếp phần đại tràng nhờ vào một ống soi mềm nhỏ đường kính khoảng 1 cm, đưa vào qua hậu môn. Quan sát hình ảnh trên máy soi, bác sĩ có thể biết được các bất thường đang xảy ra bên trong ruột già. Từ đó, bác sĩ sẽ đưa ra chẩn đoán và phương pháp điều trị thích hợp cho người bệnh.
Nội soi đại tràng là một xét nghiệm can thiệp để kiểm tra, đánh giá những bất thường bên trong của đại tràng (ruột già).
## **Tại sao phải nội soi đại tràng?**
Ống tiêu hóa là một cơ quan rất khó chẩn đoán bệnh lý. Các phương pháp hiện đại như: Siêu âm, chụp cắt lớp điện toán (CT) hay cộng hưởng từ (MRI) dù rất đắt tiền nhưng vẫn không có giá trị chẩn đoán bệnh lý tại ống tiêu hóa. X – quang đại tràng bằng cách bơm baryt có thể dùng trong một số trường hợp nhưng vẫn không chính xác bằng nội soi.
Qua máy nội soi, bác sĩ có thể phát hiện các tổn thương rất nhỏ chỉ vài milimet, có thể sinh thiết để tìm ung thư. Ngoài ra, nội soi đại tràng có thể dùng để cắt polyp (polyp là nguyên nhân rất thường gặp gây ra tiêu ra máu và hóa thành ung thư) hay cắt ung thư sớm.
## **Những ai cần nội soi đại tràng?**
-Hầu hết các bệnh nhân nghi ngờ có vấn đề ở đường tiêu hóa dưới đều được chỉ định soi đại tràng.
Nội soi đại tràng giúp kiểm tra, đánh giá tất cả những bất thường tại đại tràng.
-Tất cả những người trên 45 tuổi đều nên nội soi tầm soát ung thư từ 1-3 năm một lần . -Các bệnh nhân lớn tuổi và kèm yếu tố nguy cơ cao như có tiền căn polyp, tiền sử gia đình bị ung thư đại tràng.
## **Nội soi đại tràng có nguy hiểm không?**
Nội soi đại tràng là một thủ thuật tương đối an toàn, ít tai biến. Do đại tràng dài và gập góc hoặc xoắn, nên khi soi bệnh nhân cảm thấy đau và khó chịu.
## **Nội soi đại tràng cần chuẩn bị như thế nào?**
Việc chuẩn bị nội soi đại tràng là rất quan trọng để đảm bảo cho lòng ruột thật sạch và bác sĩ không bỏ sót tổn thương khi soi.
-Ngày hôm trước khi soi: Ăn nhẹ, ít chất xơ – Đối với bệnh nhân sử dụng Fortran: buổi chiều uống hết 3 gói Fortran pha trong 3 lít nước. – Đối với bệnh nhân sử dụng Fleet Phospho-Soda: Hòa chai thuốc trong 1 ly nước lớn (300ml) và uống. Trong khoảng thời gian 3 giờ tiếp theo phải uống đủ 3 lít nước (có thể dùng các nước giải khát không màu, không uống sữa). -Từ lúc uống thuốc đến khi soi bệnh nhân nhịn ăn hoàn toàn. Chỉ uống nước đường nếu thấy đói. Với cách chuẩn bị như trên, bệnh nhân sẽ đi tiêu nhiều lần ra nước trong cho đến khi ruột hoàn toàn sạch.
**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/) **- Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [Nội soi đại tràng là gì?](https://bvnguyentriphuong.com.vn/noi-soi/nhung-dieu-can-biet-ve-noi-soi-dai-trang#ni-soi-i-trng-l-g)
  * [Tại sao phải nội soi đại tràng?](https://bvnguyentriphuong.com.vn/noi-soi/nhung-dieu-can-biet-ve-noi-soi-dai-trang#ti-sao-phi-ni-soi-i-trng)
  * [Những ai cần nội soi đại tràng?](https://bvnguyentriphuong.com.vn/noi-soi/nhung-dieu-can-biet-ve-noi-soi-dai-trang#nhng-ai-cn-ni-soi-i-trng)
  * [Nội soi đại tràng có nguy hiểm không?](https://bvnguyentriphuong.com.vn/noi-soi/nhung-dieu-can-biet-ve-noi-soi-dai-trang#ni-soi-i-trng-c-nguy-him-khng)
  * [Nội soi đại tràng cần chuẩn bị như thế nào?](https://bvnguyentriphuong.com.vn/noi-soi/nhung-dieu-can-biet-ve-noi-soi-dai-trang#ni-soi-ai-trang-cn-chun-bi-nhu-th-nao)



## ️ Khi nào cần nội soi dạ dày và cần chuẩn bị những gì?

  * [1. Nội soi dạ dày là gì?](https://bvnguyentriphuong.com.vn/noi-soi/khi-nao-can-noi-soi-da-day-va-can-chuan-bi-nhung-gi#1-ni-soi-d-dy-l-g)
  * [2. Khi nào cần nội soi dạ dày?](https://bvnguyentriphuong.com.vn/noi-soi/khi-nao-can-noi-soi-da-day-va-can-chuan-bi-nhung-gi#2-khi-no-cn-ni-soi-d-dy)
  * [3. Chuẩn bị trước khi nội soi dạ dày](https://bvnguyentriphuong.com.vn/noi-soi/khi-nao-can-noi-soi-da-day-va-can-chuan-bi-nhung-gi#3-chun-b-trc-khi-ni-soi-d-dy)
  * [4. Chăm sóc sau nội soi](https://bvnguyentriphuong.com.vn/noi-soi/khi-nao-can-noi-soi-da-day-va-can-chuan-bi-nhung-gi#4-chm-sc-sau-ni-soi)


**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/)** - Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [1. Nội soi dạ dày là gì?](https://bvnguyentriphuong.com.vn/noi-soi/khi-nao-can-noi-soi-da-day-va-can-chuan-bi-nhung-gi#1-ni-soi-d-dy-l-g)
  * [2. Khi nào cần nội soi dạ dày?](https://bvnguyentriphuong.com.vn/noi-soi/khi-nao-can-noi-soi-da-day-va-can-chuan-bi-nhung-gi#2-khi-no-cn-ni-soi-d-dy)
  * [3. Chuẩn bị trước khi nội soi dạ dày](https://bvnguyentriphuong.com.vn/noi-soi/khi-nao-can-noi-soi-da-day-va-can-chuan-bi-nhung-gi#3-chun-b-trc-khi-ni-soi-d-dy)
  * [4. Chăm sóc sau nội soi](https://bvnguyentriphuong.com.vn/noi-soi/khi-nao-can-noi-soi-da-day-va-can-chuan-bi-nhung-gi#4-chm-sc-sau-ni-soi)



## ️ Nội soi đại tràng khi nào cần thực hiện?

Nội soi đại tràng là phương pháp chẩn đoán hình ảnh chính xác giúp chẩn đoán chính xác các bệnh lý về đại tràng. Vậy nội soi đại tràng khi nào cần thực hiện?
Nội soi đại tràng là một xét nghiệm can thiệp cho phép để đánh giá bên trong của đại tràng (ruột già). Dụng cụ nội soi đại tràng là một ống mềm linh hoạt với kích thích đường kính khoảng 1,3cm; dài 1,7m; bên trong có chứa nguồn sáng và đầu camera của máy quay video, dẫn truyền hình ảnh ra ngoài. Ống nội soi được đưa vào hậu môn và sau đó là tiên lên từ từ vào trong trực tràng và thông qua đại tràng có thể tới tận manh tràng- là phần đầu tiên của đại tràng.
**Nội soi đại tràng khi nào cần thực hiện?**
Nội soi giúp chẩn đoán các bệnh lý đại tràng
Nội soi đại tràng được thực hiện khi: người bệnh đi tiêu ra máu nhiều lần (máu tươi hay máu đen); người bệnh bị rối loạn tiêu hóa (tiêu chảy, táo bón), đau bụng mà uống thuốc lâu ngày chưa giảm; tầm soát ung thư đại tràng sớm ở những người có nguy cơ cao, trong gia đình có người bị ung thư đại tràng hoặc bị bệnh đa polyp đại tràng để theo dõi khả năng tái phát sau cắt ung thư đại tràng. Nội soi đại tràng là một thủ thuật không xâm lấn, nhưng vẫn có những tai biến tuy ít gặp.
**Cần chuẩn bị gì trước khi nội soi đại tràng**
Để đảm bảo kết quả nội soi chính xác, không bỏ sót bất kì tổn thương nào trong đại tràng thì ống tiêu hóa của bệnh nhân phải được làm sạch trước khi soi. Do vậy trước ngày nội soi đại tràng bệnh nhân cần thực hiện những điều sau:
Ăn thực phẩm dễ tiêu trước khi nội soi 1 ngày
Thực hiện chế độ ăn nhẹ, ăn các thức ăn dễ tiêu hóa trước khi nội soi 1 ngày. Hạn chế tiêu thụ chất xơ và các thức ăn có màu đỏ như củ dền, thịt bò trong vài ngày trước khi nội soi.
Bệnh nhân cần trao đổi với bác sĩ về các loại thuốc mình đang sử dụng xem có cần ngưng lại 1 thời gian trước khi thực hiện nội soi đại tràng hay không. Thông thường các loại thuốc như aspirin, warfarin, thuốc viêm khớp, insulin, các chế phẩm từ sắt có thể được bác sĩ yêu cầu ngưng uống bởi nó sẽ gây trở ngại cho quá trình nội soi.
Bệnh nhân cũng cần thông báo trước cho bác sĩ biết về tiền sử dị ứng thuốc, các rối loạn đông máu và các bệnh lý đang mắc phải.
Uống đủ 3 lít nước để làm sạch thành đại tràng
Để làm sạch ruột trước khi nội soi đại tràng, bác sẽ hướng dẫn cho người bệnh cụ thể cách thực hiện và thời điểm tiến hành. Người bệnh có thể được chỉ định uống 3 lít nước và thuốc sổ để làm sạch ruột.
**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/) **- Đa khoa Hạng I Thành phố Hồ Chí Minh

## ️ Nội soi đại tràng gây mê

  * [Nội soi đại tràng gây mê là gì?](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-dai-trang-gay-me#ni-soi-i-trng-gy-m-l-g)
  * [Cần chuẩn bị gì trước khi nội soi đại tràng gây mê?](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-dai-trang-gay-me#cn-chun-b-g-trc-khi-ni-soi-i-trng-gy-m)


Nội soi đại tràng gây mê là một giải pháp an toàn cho những người còn lo sợ cảm giác khó chịu khi nội soi đại tràng truyền thống. Với phương pháp này, người bệnh sẽ không còn cảm giác khó chịu, êm ái như vừa trải qua một giấc ngủ sâu.
## **Nội soi đại tràng gây mê là gì?**
Nội soi đại tràng là phương pháp thăm khám trực tiếp đại tràng, trực tràng nhờ ống nội soi mềm có gắn camera được đưa vào từ hậu môn. Hình ảnh thu được qua camera sẽ được chiếu lên màn hình vi tính giúp bác sĩ quan sát kỹ hơn đại tràng, trực tràng, phát hiện những bất thường hoặc tổn thương như viêm nhiễm, polyp, khối u…
**Nội soi đại tràng là phương pháp thăm khám trực tiếp đại tràng, trực tràng nhờ ống nội soi mềm có gắn camera được đưa vào từ hậu môn.**
Với phương pháp nội soi đại tràng thường, người bệnh có thể cảm thấy khó chịu, đau đớn nhưng hiện nay, với sự phát triển mạnh mẽ của y khoa hiện đại, nội soi gây mê đã được áp dụng rộng rãi.
Với nội soi đại tràng gây mê, người bệnh sẽ được sử dụng thuốc an thần giúp người bệnh ngủ thiếp đi và không còn cảm giác khó chịu nữa. Nội soi đại tràng được tiến hành nhanh chóng, người bệnh sẽ không có cảm giác khó chịu khi thực hiện dịch vụ.
## **Cần chuẩn bị gì trước khi nội soi đại tràng gây mê?**
Theo các bác sĩ, trước khi tiến hành nội soi đại tràng, người bệnh cần phải làm sạch ruột và hậu môn. Người bệnh sẽ cần:
Uống Fleet Phosphosoda 45ml với khoảng 1 lít nước, đi cầu nhiều lần tới khi nước tiểu trong.
  * Thụt tháo bằng cách đưa nước vào đại tràng qua hậu môn, đi cầu nhiều lần cho tới khi nước trong.
  * Người bệnh cần nhịn ăn ít nhất 12 tiếng trước khi thực hiện nội soi.
  * Cần thông báo với bác sĩ về loại thuốc đang sử dụng hoặc cho bác sĩ biết mình dị ứng với thuốc nào để bác sĩ có chỉ định cụ thể.
  * Người bệnh cần lựa chọn một địa chỉ nội soi uy tín để được tiến hành nội soi nhanh chóng, an toàn, chính xác.


**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/) **- Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [Nội soi đại tràng gây mê là gì?](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-dai-trang-gay-me#ni-soi-i-trng-gy-m-l-g)
  * [Cần chuẩn bị gì trước khi nội soi đại tràng gây mê?](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-dai-trang-gay-me#cn-chun-b-g-trc-khi-ni-soi-i-trng-gy-m)



## ️ Nội soi gây mê là gì?

  * [Nội soi gây mê là gì?](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-gay-me-la-gi#ni-soi-gy-m-l-g)
  * [Nội soi gây mê an toàn thế nào?](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-gay-me-la-gi#ni-soi-gy-man-ton-th-no)


Trước đây, khi thực hiện phương pháp nội soi dạ dày kiểu truyền thống, không ít bệnh nhân đã phải ói ra cả mật xanh, mật vàng. Nhiều người không dám đi tái khám chỉ vì sợ phải trải qua nội soi lần thứ hai. Để khắc phục tình trạng đó, nội soi gây mê – một trong số các phương pháp nội soi không đau đã được nghiên cứu và đưa vào thực hiện.
## **Nội soi gây mê là gì?**
Nội soi gây mê được sử dụng để thăm khám đường tiêu hóa bao gồm thực quản, dạ dày – tá tràng và đại tràng, giúp phát hiện sớm và điều trị kịp thời các tổn thương và bệnh lý tại đây.
Đây là một trong hai phương pháp nội soi không đau đang được các bệnh nhân lựa chọn nhiều. Nội soi gây mê thường được áp dụng với dạ dày, thực quản, tá tràng và đại trực tràng. Phương pháp này được đánh giá là an toàn và ít biến chứng. Thuốc an thần dùng trong gây mê được tiêm tĩnh mạch theo một lượng đã được tính toàn phù hợp. Người bệnh tỉnh ngay sau khi kết thúc nội soi. Thời gian gây mê ngắn, lượng thuốc mê ít nên không gây hại cho sức khỏe.
Những cảm giác khó chịu, buồn nôn hoàn toàn biến mất trong và sau quá trình nội soi gây mê. Bởi trong quá trình nội soi, người bệnh sẽ được gây mê bằng thuốc an thần có tác dụng ngắn, tỉnh sau 15 phút và không ảnh hưởng tới sức khỏe. Vì thế, người bệnh sẽ không hề có cảm giác khó chịu, tỉnh dậy như sau một giấc ngủ say khi đã hoàn thành thủ thuật.
Việc gây mê đối với từng người cần theo chỉ định của bác sĩ. Một số người có tiền sử bệnh kèm theo không có chỉ định gây mê có thể áp dụng phương pháp nội soi qua đường mũi. Phương pháp này cũng không gây khó chịu hay kích thích cho người bệnh.
**Nội soi gây mê thường được áp dụng với dạ dày, thực quản, tá tràng và đại trực tràng**
### **Nội soi gây mê an toàn thế nào?**
Phương pháp nội soi gây mê được đánh giá là an toàn và ít biến chứng. Thuốc an thần dùng trong gây mê được tiêm tĩnh mạch theo một lượng đã được tính toàn phù hợp. Người bệnh tỉnh ngay sau khi kết thúc nội soi. Thời gian gây mê ngắn, lượng thuốc mê ít nên không gây hại cho sức khỏe.
Hơn nữa theo một số thống kê, các biến chứng liên quan đến thuốc mê rất hiếm gặp. Tuy nhiên để hạn chế tối đa những nguy cơ này, trong một số trường hợp cụ thể (người bệnh tiểu đường, tim mạch…) cần được thăm khám kỹ càng và làm xét nghiệm cần thiết trước khi tiến hành nội soi gây mê.
**Các bệnh nhân bị viêm loét dạ dày hiện nay thường chọn làm nội soi gây mê**
**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/) **- Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [Nội soi gây mê là gì?](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-gay-me-la-gi#ni-soi-gy-m-l-g)
  * [Nội soi gây mê an toàn thế nào?](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-gay-me-la-gi#ni-soi-gy-man-ton-th-no)



## ️ Nội soi đại tràng: Phương pháp chẩn đoán hiệu quả các bệnh lý đại tràng và mức độ khó chịu khi thực hiện

**1. Khái niệm nội soi đại tràng**
Nội soi đại tràng (colonoscopy) là một kỹ thuật chẩn đoán hình ảnh được thực hiện bằng cách đưa một ống soi mềm, dài, có gắn camera và nguồn sáng ở đầu qua đường hậu môn để quan sát toàn bộ đại tràng, từ trực tràng đến manh tràng – đoạn tiếp giáp với ruột non. Hình ảnh nội soi được truyền trực tiếp lên màn hình độ phân giải cao, cho phép bác sĩ phát hiện các tổn thương, bất thường niêm mạc (viêm loét, polyp, khối u...) và thực hiện sinh thiết mô nếu cần thiết.
**Nội soi đại tràng là một thủ thuật cho phép bác sĩ quan sát và đánh giá tình trạng bên trong của đại tràng nhờ sử dụng một ống dài linh động có gắn camera và đèn sáng ở đầu**
**2. Chuẩn bị trước khi nội soi đại tràng**
Để đảm bảo chất lượng hình ảnh và độ chính xác trong chẩn đoán, người bệnh cần được chuẩn bị đầy đủ trước khi tiến hành thủ thuật:
  * **Trao đổi với bác sĩ điều trị** về các thuốc đang sử dụng (đặc biệt là thuốc chống đông máu, thuốc tim mạch, thuốc điều trị đái tháo đường...), tiền sử dị ứng thuốc và các bệnh lý nội khoa kèm theo.
  * **Làm sạch đại tràng hoàn toàn** là bước bắt buộc, thường được thực hiện bằng:
    * Chế độ ăn lỏng (cháo loãng, súp...) vào ngày trước nội soi.
    * Nhịn ăn hoàn toàn ít nhất 6 giờ trước thủ thuật.
    * Uống thuốc tẩy ruột theo chỉ định hoặc thực hiện thụt tháo.
  * Nếu **nội soi gây mê hoặc tiền mê** , người bệnh cần nhịn ăn 12 giờ trước thủ thuật và có người thân đi cùng để hỗ trợ sau khi kết thúc.


**Nội soi đại tràng có đau không là quan tâm của rất nhiều người đặc biệt là những người đang có ý định đi nội soi đại tràn**
**3. Nội soi đại tràng có gây đau không?**
Mối quan tâm phổ biến của nhiều bệnh nhân là **liệu nội soi đại tràng có gây đau hay không**. Trong phần lớn các trường hợp:
  * Người bệnh chỉ cảm thấy **căng tức nhẹ hoặc khó chịu vùng bụng** do hơi được bơm vào đại tràng để giúp làm căng và quan sát rõ hơn.
  * Cảm giác khó chịu sẽ nhanh chóng biến mất sau khi kết thúc thủ thuật và lượng hơi được hút ra ngoài.
  * Một số ít trường hợp có thể cảm thấy đau do **căng mạc treo đại tràng** , đặc biệt ở những đoạn cong gập hoặc có dính ruột; khi đó, bác sĩ sẽ điều chỉnh lượng hơi hoặc tư thế nằm để giảm khó chịu cho người bệnh.


Đối với người bệnh có ngưỡng chịu đau thấp hoặc có tiền sử thủ thuật khó, có thể được chỉ định **nội soi gây mê hoặc tiền mê** , giúp đảm bảo thoải mái trong suốt quá trình thực hiện.
**4. An toàn và lưu ý sau nội soi đại tràng**
Nội soi đại tràng là thủ thuật **tương đối an toàn** , ít biến chứng nếu được thực hiện bởi bác sĩ có chuyên môn và tuân thủ đầy đủ quy trình kiểm soát nhiễm khuẩn.
Sau nội soi, người bệnh cần lưu ý:
  * Không nên uống rượu, lái xe hoặc vận hành máy móc trong vòng **24 giờ** nếu có sử dụng thuốc an thần/gây mê.
  * Nên **nghỉ ngơi** , ăn các loại thực phẩm **mềm, dễ tiêu hóa** , uống nhiều nước và theo dõi các dấu hiệu bất thường như đau bụng dữ dội, chảy máu hậu môn...


**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/) **- Đa khoa Hạng I Thành phố Hồ Chí Minh

## ️ Nội soi đại tràng như thế nào?

  * [Những ai cần nội soi đại tràng?](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-dai-trang-nhu-the-nao#nhng-ai-cn-ni-soi-i-trng)
  * [Nội soi đại tràng như thế nào?](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-dai-trang-nhu-the-nao#ni-soi-i-trng-nh-th-no)


Những ai cần nội soi đại tràng và nội soi đại tràng như thế nào là thắc mắc chung được nhiều người đặt ra. Bài viết dưới đây sẽ giúp giải đáp những thắc mắc của độc giả về phương pháp nội soi đại tràng.
## **Những ai cần nội soi đại tràng?**
Nội soi đại tràng thường được chỉ định cho những tường hợp nghi ngờ có vấn đề ở đường tiêu hóa dưới như:
  * Nôn ra máu dạng cục, sẫm màu, có lẫn cả dịch thức ăn hoặc đi ngoài ra máu.


**Khi có các triệu chứng nghi ngờ mắc bệnh ở đường tiêu hóa, người bệnh nên tiến hành nội soi đại tràng.**
  * Tiêu chảy kéo dài, đau bụng không rõ nguyên nhân, có thể đau quặn từng cơn hoặc đau râm ran.
  * Mắc bệnh lý viêm, loét, u đường tiêu hóa dưới.
  * Có tiền sử gia đình mắc ung thư đường tiêu hóa, đa polyp đại tràng.
  * Sụt cân không rõ nguyên nhân


Ngoài ra, nội soi đại tràng còn được chỉ đinh để lấy mẫu xét nghiệm tìm vi trùng hoặc ung thư như sinh thiết.
## **Nội soi đại tràng như thế nào?**
Nội soi đại tràng là cách thăm khám trực tiếp phần đại tràng nhờ vào một ống nội soi mềm nhỏ có gắn camera, đưa vào cơ thể qua hậu môn. Nhờ các hình ảnh quan sát được trên máy nội soi, bác sĩ sẽ phát hiện những bất thường trong đại tràng. Từ đó chẩn đoán chính xác bệnh và đưa ra phương pháp điều trị phù hợp.
Trước khi nội soi, người bệnh được kiểm tra hậu môn để đánh giá tổn thương. Sau đó được sử dụng thuốc tê tại chỗ nhằm làm giảm khó chịu khi đưa ống nội soi vào.
Bệnh nhân cần nằm nghiêng sang trái khi nội soi. Ống nội soi sẽ đưa vào hậu môn và sần đi sâu vào các đoạn ruột. Quá trình nội soi thường diễn ra khoảng 20 phút. Người bệnh có thể được tiêm thuốc an thần hoặc thuốc chống co thắt để giảm bớt cảm giác khó chịu.
Sau nội soi người bệnh cần nghỉ ngơi khoảng 1 giờ để thuốc an thần hết tác dụng. Sau đó có thể về nhà.
Một vài tác dụng phụ sau nội soi đại tràng như chóng mặt, chướng bụng, xì hơi liên tục… Những triệu chứng này sẽ mất dần nên người bệnh không cần quá lo lắng.
Để quá trình nội soi đại tràng diễn ra thuận lợi, an toàn, người bệnh cần lưu ý:
  * Lựa chọn địa chỉ nội soi uy tín: Bệnh viện có đầy đủ các trang thiết bị, máy móc phục vụ quá trình nội soi. Bác sĩ chuyên môn cao, tay nghề giỏi.
  * Tuân thủ theo đúng chỉ định của bác sĩ trước, trong và sau khi tiến hành nội soi.
  * Bổ sung đầy đủ dinh dưỡng trong bữa ăn hàng ngày nhằm cải thiện tình trạng sức khỏe.


Trường hợp nội soi để cắt bỏ polyp hoặc sinh thiết thì cần theo dõi tình trạng bệnh. Tái khám ngay khi có các dấu hiệu đau bụng dữ dội, trướng bụng, đi tiểu ra máu.
**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/) **- Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [Những ai cần nội soi đại tràng?](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-dai-trang-nhu-the-nao#nhng-ai-cn-ni-soi-i-trng)
  * [Nội soi đại tràng như thế nào?](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-dai-trang-nhu-the-nao#ni-soi-i-trng-nh-th-no)



## ️ Nội soi có đau không?

  * [Nội soi có đau không?](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-co-dau-khong#ni-soi-c-au-khng)
  * [Các phương pháp nội soi không đau](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-co-dau-khong#cc-phng-php-ni-soi-khng-au)


Khi có vấn đề ở đường tiêu hóa, nhiều người muốn thực hiện nội soi nhưng lại lo lắng không biết nội soi có đau không? Hiện nay, với sự phát triển của y học hiện đại, có nhiều phương pháp nội soi đã ra đời, an toàn, không đau, không khó chịu.
## **Nội soi có đau không?**
Nội soi nói chung và nội soi tiêu hóa nói riêng là một phương pháp thăm khám quan trọng, giúp bác sĩ phát hiện sớm các bệnh lý tiềm ẩn trong cơ thể. Với nội soi tiêu hóa, nội soi giúp bác sĩ quan sát toàn bộ hệ thống tiêu hóa, phát hiện bệnh viêm nhiễm, polyp, thậm chí ung thư.
**Nội soi có đau không là thắc mắc chung của nhiều người.**
Nội soi có đau không? Đây là thắc mắc được nhiều người đặt ra. Với phương pháp nội soi truyền thống, nội soi dạ dày hoặc đại tràng không gây mê, người bệnh sẽ phải đối mặt với tình trạng đau, buồn nôn và nôn, khó chịu. Chính vì điều này mà khi nói tới nội soi, nhiều người bệnh còn e ngại không đi khám và nội soi.
## **Các phương pháp nội soi không đau**
Nội soi không đau gồm 2 phương pháp: nội soi gây mê và nội soi đường mũi.
Phương pháp nội soi gây mê: Người bệnh sẽ được tiêm thuốc gây mê trong thời gian ngăn, rất an toàn và không gây tác dụng phụ. Người bệnh chỉ như trải qua một giấc ngủ sâu và tỉnh giấc khi quá trình nội soi đã diễn ra thuận lợi. Ở phương pháp này, người bệnh không có cảm giác khó chịu hay đau đớn.
Phương pháp nội soi đường mũi: Một ống nội soi siêu nhỏ được đưa qua lỗ mũi thông xuống họng và xuống ống tiêu hóa mà không qua đường miệng nên không chạm vào vòm khẩu cái, lưỡi gà. Ở phương pháp này người bệnh không có cảm giác buồn nôn, hoặc nôn. Người bệnh hoàn toàn tỉnh táo và có thể nói chuyện với bác sĩ.
**Lưu ý sau khi nội soi:**
  * Người bệnh sau khi tiến hành nội soi cần chú ý ăn uống đủ chất, đảm bảo dinh dưỡng, nên ăn thực phẩm mềm, lỏng, dễ nuốt. Tránh các thực phẩm cứng, rắn, đồ chua, đồ cay nóng…


**Sau nội soi người bệnh nên ăn các thực phẩm mềm, dễ tiêu hóa.**
  * Cần hạn chế rượu bia, thuốc lá.
  * Nếu có vấn đề ở đường tiêu hóa cần tuân thủ theo đúng phương pháp điều trị của bác sĩ để cải thiện sớm tình trạng sức khỏe.


**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/) **- Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [Nội soi có đau không?](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-co-dau-khong#ni-soi-c-au-khng)
  * [Các phương pháp nội soi không đau](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-co-dau-khong#cc-phng-php-ni-soi-khng-au)



## ️Tìm hiểu về phương pháp nội soi dạ dày không đau

  * [Các phương pháp nội soi dạ dày không đau](https://bvnguyentriphuong.com.vn/noi-soi/tim-hieu-ve-phuong-phap-noi-soi-da-day-khong-dau#cc-phng-php-ni-soi-d-dy-khng-au)
  * [Khi nào nên nội soi dạ dày?](https://bvnguyentriphuong.com.vn/noi-soi/tim-hieu-ve-phuong-phap-noi-soi-da-day-khong-dau#khi-no-nn-ni-soi-d-dy)


Khi nói đến nội soi dạ dày, nhiều người vẫn còn lo sợ cảm giác đau, khó chịu, buồn nôn và nôn. Hiện nay, với sự phát triển mạnh mẽ của y khoa hiện đại, có nhiều phương pháp nội soi đã ra đời. Bài viết dưới đây sẽ giúp độc giả tìm hiểu về phương pháp nội soi dạ dày không đau.
## **Các phương pháp nội soi dạ dày không đau**
Theo các chuyên gia y tế, so với biện pháp nội soi thường thì các phương pháp nội soi không đau có nhiều ưu điểm vượt trội: không khó chịu, không đau đớn, thoải mái, dễ chịu, không có cảm giác buồn nôn hoặc nôn.
Nội soi dạ dày không đau gồm 2 phương pháp:
  * Nội soi gây mê: Ở phương pháp này người bệnh được đưa vào trạng thái tiền mê, tức là gây mê ngắn, rất an toàn, chỉ trong khoảng 15 phút để tiến hành nội soi. Quá trình thực hiện nhẹ nhàng, nhanh chóng chỉ như vừa trải qua 1 giấc ngủ sâu, khi tỉnh dậy thì mọi việc đã thực hiện xong. Ở phương pháp này, người bệnh không có cảm giác khó chịu hay đau đớn gì.
  * Nội soi đường mũi: Đây là phương pháp nội soi mới, ống nội soi được trang bị siêu nhỏ, đưa qua lỗ mũi thông xuống họng và xuống ống tiêu hóa mà không qua đường miệng nên không chạm vào vòm khẩu cái, lưỡi gà. Vì thế người bệnh không có cảm giác buồn nôn, hoặc nôn. Người bệnh oàn toàn tỉnh táo và có thể nói chuyện với bác sĩ. Đặc biệt, phương pháp này người bệnh không cần gây mê, có thể ra về ngay sau khi nội soi.


## **Khi nào nên nội soi dạ dày?**
Khi thấy xuất hiện các triệu chứng sau đây, người bệnh nên đến bệnh viện để tiến hành khám nội soi dạ dày:
  * Đau thượng vị và có cảm giác buồn nôn sau khi ăn.


Khi thấy xuất hiện các triệu chứng nghi mắc bệnh ở dạ dày cần tiến hành nội soi để chẩn đoán chính xác bệnh
  * Thường xuyên ợ hơi, ợ chua, trào ngược thức ăn, chậm tiêu, nuốt nghẹn.
  * Đau ngực, nôn ra máu hoặc đi ngoài phân đen.
  * Giảm cân đột ngột và không rõ nguyên nhân.
  * Sử dụng thuốc chống viêm, giảm đau trong thời gian dài, gây đau thượng vị.
  * Những người mắc các bệnh lý ở dạ dày.
  * Người có bệnh polyp có yếu tố gia đình.
  * Người mắc hội chứng kém hấp thu.
  * Tầm soát phát hiện sớm ung thư dạ dày.


**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/) **- Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [Các phương pháp nội soi dạ dày không đau](https://bvnguyentriphuong.com.vn/noi-soi/tim-hieu-ve-phuong-phap-noi-soi-da-day-khong-dau#cc-phng-php-ni-soi-d-dy-khng-au)
  * [Khi nào nên nội soi dạ dày?](https://bvnguyentriphuong.com.vn/noi-soi/tim-hieu-ve-phuong-phap-noi-soi-da-day-khong-dau#khi-no-nn-ni-soi-d-dy)



## ️ Nguyên nhân gây đau cổ hỗ trợ điều trị sớm

Đau cổ là tình trạng đau nhức, khó chịu, xảy ra trong bất cứ cấu trúc nào của cổ, bao gồm các cơ, dây thần kinh, đốt sống cổ và đĩa đệm giữa các đốt sống. Đau ở vai, xương hàm, đầu và phần trên cánh tay cũng có thể dẫn đến đau cổ. Nhìn chung đau cổ xuất phát từ nhiều nguyên nhân khác nhau. Bài viết sau sẽ liệt kê những nguyên nhân thường gặp nhất là “thủ phạm” gây ra đau cổ trong đời sống thường ngày.
**Đau cơ ở cổ**
Các hoạt động hàng ngày như ngồi trên bàn làm việc trong nhiều giờ liền hoặc ngồi sai tư thế hay nâng vật nặng quá mức có thể gây căng hoặc co thắt cơ, khiến nhiều người cảm mệt cổ
Đây là một trong những nguyên nhân phổ biến dẫn tới tình trạng đau mỏi cổ. Theo nghiên cứu của MayoClinic.com, các hoạt động hàng ngày như ngồi trên bàn làm việc trong nhiều giờ liền hoặc ngồi sai tư thế hay nâng vật nặng quá mức có thể gây căng hoặc co thắt cơ, khiến nhiều người cảm thấy mỏi cổ. Nếu vẫn tiếp diễn các hoạt động nêu trên, người bệnh có thể bị đau cổ mạn tính.
**Khớp cổ bị mòn**
Các nhà nghiên cứu cho rằng khớp mòn cũng là một nguyên nhân gây ra đau cổ. Giống như các khớp khác của cơ thể, khớp cổ cũng bị hao mòn theo tuổi tác. Điều này có thể gây ra viêm xương khớp ở cổ dẫn tới đau ở vùng cổ.
**Áp lực ở đĩa đệm**
Khi không gian giữa các đốt sống của cổ bị giảm, các dây thần kinh phân nhánh ra từ tủy sống sẽ bị chèn ép, dẫn tới những cơn đau cổ. Có một loại nguyên nhân gây ra tình trạng làm giảm không gian này, bao gồm cả đĩa đệm bị mất nước, khô cứng, thu hẹp khoảng cách. Thoát vị đĩa đệm cũng có thể gây đau cổ. Đây là tình trạng nhân nhầy đĩa đệm cột sống thoát ra khỏi vị trí bình thường. Những người bị viêm xương khớp ở cổ, gai xương hoặc tăng trưởng xương có thể ảnh hưởng tới dây thần kinh và gây ra đau khổ.
**Chấn thương và các bệnh lý**
Tai nạn và ngã có thể gây ra chấn thương ở cổ như gãy xương, chấn thương mạch máu… Đây cũng là một trong những nguyên nhân gây đau cổ. Các bệnh như viêm khớp dạng thấp cũng có thể ảnh hưởng đến các khớp cổ gây đau. Viêm màng não, bệnh ảnh hưởng đến niêm mạc của não và tủy sống, cũng có thể gây đau và cứng khớp ở cổ. Đau cổ cũng có thể là do khối u ác tính hình thành trong xương sống.
**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/) **- Đa khoa Hạng I Thành phố Hồ Chí Minh

## ️ Nội soi đại tràng gây mê: quy trình và ưu nhược điểm

  * [Thế nào là nội soi đại tràng gây mê?](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-dai-trang-gay-me-quy-trinh-va-uu-nhuoc-diem#th-no-l-ni-soi-i-trng-gy-m)
  * [Ưu điểm của phương pháp nội soi đại tràng gây mê](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-dai-trang-gay-me-quy-trinh-va-uu-nhuoc-diem#u-im-ca-phng-php-ni-soi-i-trng-gy-m)
  * [Thuốc gây mê được sử dụng khi nội soi](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-dai-trang-gay-me-quy-trinh-va-uu-nhuoc-diem#thuc-gy-m-c-s-dng-khi-ni-soi)
  * [Kinh nghiệm gây mê đối với bệnh nhân nội soi](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-dai-trang-gay-me-quy-trinh-va-uu-nhuoc-diem#kinh-nghim-gy-m-i-vi-bnh-nhn-ni-soi)
  * [Đối tượng không nên nội soi đại tràng gây mê](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-dai-trang-gay-me-quy-trinh-va-uu-nhuoc-diem#i-tng-khng-nn-ni-soi-i-trng-gy-m)
  * [Quy trình và lưu ý khi tiến hành nội soi gây mê](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-dai-trang-gay-me-quy-trinh-va-uu-nhuoc-diem#quy-trnh-v-lu-khi-tin-hnh-ni-soi-gy-m)


## **Thế nào là nội soi đại tràng gây mê?**
Đây là phương pháp người bệnh được chỉ định sử dụng thuốc gây mê trong quá trình nội soi đại tràng. Quá trình này diễn ra trong giấc ngủ, khoảng tầm 30 – 45 phút. Bác sĩ sẽ dùng ống nội soi mềm, nhỏ bằng ngón tay trỏ, chiều dài khoảng 130 cm với camera gắn ở đầu ống nội soi đi qua đường hậu môn, vào trực tràng, đại tràng.
Phương pháp này giúp quan sát, ghi hình, chẩn đoán chính xác những tổn thương ở đại tràng, từ đó có thể tầm soát tiền ung thư hay điều trị hiệu quả những bệnh lý đại tràng
## **Ưu điểm của phương pháp nội soi đại tràng gây mê**
  * Không đau, không khó chịu, không mất sức, phục hồi nhanh sau khi nội soi.
  * Giảm áp lực tâm lý, bớt lo lắng, sợ hãi, tạo tinh thần thoải mái cho người bệnh.
  * An toàn, không ảnh hưởng đến sức khỏe, trí nhớ của người bệnh.
  * Sử dụng ống nội soi mềm nên không gây tổn thương niêm mạc đại tràng.
  * Bệnh nhân nằm im trong quá trình nội soi, giúp cho hình ảnh chính xác hơn, hiệu quả chẩn đoán cao hơn. Nếu có phải thực hiện các thủ thuật khác như: cắt polyp, sinh thiết…. cũng sẽ dễ dàng và hiệu quả cao hơn.


_Nội soi đại tràng gây mê_
## **Thuốc gây mê được sử dụng khi nội soi**
Propofol là thuốc gây mê được chỉ định dùng trong quá trình nội soi đại tràng gây mê. Đây là thuốc gây mê có tác dụng ngắn, có ưu điểm là tương đối nhanh, rất phù hợp với thời gian để nội soi xong đại tràng. Thuốc được truyền qua đường tĩnh mạch của người bệnh, sau 5 phút, bệnh nhân sẽ chìm vào giấc ngủ và thủ thuật nội soi đại tràng được tiến hành.
Việc sử dụng thuốc như thế nào, liều lượng ra sao phải hoàn toàn tuân thủ theo chỉ định của bác sĩ gây mê. Sau khi nội soi xong chỉ mất 10-15 phút bệnh nhân sẽ tỉnh lại bình thường. Theo thống kê của trung tâm y tế Yale thuộc đại học Yale Mỹ thì 95% số lượng bệnh nhân dung nạp Propofol tốt, chỉ còn 5% còn lại rơi vào những bệnh nhân có tiền sử huyết áp, tim mạch, hô hấp sẽ được khuyến cáo, tư vấn cụ thể.
## **Kinh nghiệm gây mê đối với bệnh nhân nội soi**
Vì mục đích an toàn cho bệnh nhân trong quá trình gây mê, bác sĩ sẽ có những yêu cầu nghiêm ngặt, bệnh nhân phải tuân thủ theo:
  * Thực phẩm ăn uống: Trước khi nội soi đại tràng, người bệnh được hướng dẫn ăn thức ăn lỏng như cháo, súp, tránh chất xơ. Nhịn ăn ít nhất 6 -8 tiếng trước khi tiến hành nội soi, ngừng uống nước trước 2 tiếng trước khi nội soi để tránh tình trạng sặc nước lên phổi, gây nguy hiểm.
  * Thăm khám tiền mê với bác sĩ gây mê để lường trước những biến chứng có thể gặp phải trong quá trình gây mê. Nếu người bệnh có tiền sử bệnh lý, đang dùng thuốc… thì bác sĩ sẽ điều chỉnh phương pháp và thời gian gây mê
  * Sau quá trình xét nghiệm, thăm khám ban đầu, người bệnh có đủ sức khỏe tốt, tim mạch và huyết áp ổn định thì bác sĩ sẽ tiến hành gây mê để nội soi. Thuốc gây mê được truyền vào tĩnh mạch, sau đó người bệnh sẽ mê toàn thân và quá trình nội soi được diễn ra.
  * Tình trạng hô hấp, huyết áp, nồng độ oxy, chức năng thận và các dấu hiệu quan trọng khác sẽ được theo dõi chặt chẽ bởi bác sĩ gây mê.


_Bệnh nhân nên thăm khám và nhận tư vấn của bác sĩ trước khi tiến hành nội soi_
## **Đối tượng không nên nội soi đại tràng gây mê**
  * Người có bệnh lý tim mạch, hô hấp, chức năng tim phổi không bình thường.
  * Người cao huyết áp, thiếu máu não, có bệnh động mạch vành.
  * Người bị bệnh trĩ ở giai đoạn nặng
  * Người có bệnh viêm màng bụng, viêm đường tiêu hóa do trúng độc cấp tính (kiết lị), viêm loét kết tràng do trúng độc
  * Xuất huyết cấp tính phía dưới đường tiêu hóa, tụ huyết quá nhiều ở đường ruột gây trở ngại cho việc quan sát.
  * Người mới qua phẫu thuật đường ruột trong thời kỳ gần đây hoặc người mới sử dụng phóng xạ vùng ổ bụng và vùng khoang chậu trong thời gian gần đây.
  * Người đã phẫu thuật hoặc bị viêm do phẫu thuật và chứng viêm làm dính niêm mạch ruột có chỗ bị cứng
  * Trong ruột có chỗ bị co thắt thì không nên cố luồn ống nội soi qua đoạn co thắt để quan sát. Người bị hẹp hậu môn và xung quanh hậu môn bị viêm cấp tính cũng không nên nội soi 1 cách miễn cưỡng
  * Người có bệnh động kinh, thần kinh, không đồng ý nội soi


## **Quy trình và lưu ý khi tiến hành nội soi gây mê**
**Quy trình nội soi đại tràng gây mê**
Bước 1: Thăm khám cơ bản, đánh giá bệnh lý, chỉ định nội soi và yêu cầu thực hiện các xét nghiệm cần thiết trước nội soi. Để đảm bảo an toàn tối đa, người bệnh nên nên thông báo với bác sỹ những loại thuốc mình đang dùng, tiền sử bệnh lý có cao huyết áp, tim mạch hay đang có thai hay không?
Bước 2: Xét nghiệm công thức máu, đông máu cơ bản, HIV, beta HCG (đối với nữ)
Bước 3: Khám tiền mê, giải thích thủ thuật nội soi. Ký cam kết gây mê và làm thủ thuật
Bước 4: Uống thuốc làm sạch đại trực tràng.
Bước 5: Chuẩn bị gây mê và gây mê
Bước 6: Tiến hành nội soi đại tràng. Trong quá trình nội soi, những hình ảnh tổn thương của đại tràng được thu lại qua camera ở đầu ống nội soi, giúp bác sỹ quan sát, chẩn đoán chính xác bệnh lý về đại tràng, đặc biệt là ung thư đại tràng.
Bước 7: Nghỉ ngơi, hồi phục sau nội soi
Bước 8: Tư vấn kết quả và hướng điều trị bệnh lý
**Lưu ý khi tiến hành nội soi gây mê**
Trước khi nội soi đại tràng, người bệnh được hướng dẫn ăn thức ăn lỏng như cháo, súp, tránh chất xơ. Nhịn ăn ít nhất 6 -8 tiếng trước khi tiến hành nội soi, ngừng uống nước trước 2 tiếng trước khi nội soi để tránh tình trạng sặc nước lên phổi, gây nguy hiểm
Sau khi nội soi xong tránh lái xe, điều khiển máy móc trong vài giờ đầu tiên
Nội soi xong bệnh nhân có cảm giác đầy hơi, quặn bụng do hơi. Trong trường hợp có lấy mẫu sinh thiết hay cắt bỏ polyp thì có thể thấy những dải máu nhỏ trong phân.
**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/) **- Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [Thế nào là nội soi đại tràng gây mê?](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-dai-trang-gay-me-quy-trinh-va-uu-nhuoc-diem#th-no-l-ni-soi-i-trng-gy-m)
  * [Ưu điểm của phương pháp nội soi đại tràng gây mê](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-dai-trang-gay-me-quy-trinh-va-uu-nhuoc-diem#u-im-ca-phng-php-ni-soi-i-trng-gy-m)
  * [Thuốc gây mê được sử dụng khi nội soi](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-dai-trang-gay-me-quy-trinh-va-uu-nhuoc-diem#thuc-gy-m-c-s-dng-khi-ni-soi)
  * [Kinh nghiệm gây mê đối với bệnh nhân nội soi](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-dai-trang-gay-me-quy-trinh-va-uu-nhuoc-diem#kinh-nghim-gy-m-i-vi-bnh-nhn-ni-soi)
  * [Đối tượng không nên nội soi đại tràng gây mê](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-dai-trang-gay-me-quy-trinh-va-uu-nhuoc-diem#i-tng-khng-nn-ni-soi-i-trng-gy-m)
  * [Quy trình và lưu ý khi tiến hành nội soi gây mê](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-dai-trang-gay-me-quy-trinh-va-uu-nhuoc-diem#quy-trnh-v-lu-khi-tin-hnh-ni-soi-gy-m)



## ️ Nội soi tiêu hóa – giải pháp vàng giúp phát hiện ung thư tiêu hóa sớm

**Nội soi tiêu hóa là gì?**
Nội soi tiêu hóa là phương pháp thăm khám trực tiếp hệ tiêu hóa (dạ dày – tá tràng – đại tràng – trực tràng) thông qua một ống nội soi mềm có gắn đầu camera nhằm quan sát trực tiếp lớp niêm mạc ống tiêu hóa từ đó phát hiện ra các tổn thương, để chẩn đoán và can thiệp điều trị .
Nội soi tiêu hóa được chia thành 2 dạng: nội soi đường tiêu hóa trên (thông qua mũi hoặc họng) và nội soi đường tiêu hóa dưới (thông qua hậu môn). Tùy vào mục đích và vị trí cần kiểm tra mà các bác sĩ sẽ chỉ định cho bệnh nhân loại nội soi cho phù hợp.
**Tại sao phải nội soi tiêu hóa?**
Hiện nay, nội soi tiêu hóa được sử dụng phổ biến trong thăm khám và chẩn đoán các bệnh lý của ống tiêu hóa. Thông qua ống soi gắn camera, bác sĩ có thể quan sát dễ dàng mọi ngóc ngách của hệ thống tiêu hóa cũng như phát hiện các tổn thương, bất thường dù là nhỏ nhất. Từ đó thực hiện các sinh thiết để chẩn đoán các viêm nhiễm, ung thư…, thực hiện cầm máu, cắt bỏ polyp, nong hẹp… trong khi các phương pháp thăm khám khác không làm được.
**Khi nào cần nội soi tiêu hóa?**
Bệnh nhân cần nội soi tiêu hóa khi có bất kỳ dấu hiệu nào dưới đây:
  * Mệt mỏi, chán ăn
  * Chướng bụng, đầy hơi, cảm giác khó tiêu sau ăn
  * Ợ chua, ợ nóng kéo dài và ngày càng nặng,
  * Buồn nôn, nôn ói kéo dài mà không rõ nguyên nhân,
  * Đau bụng vùng trên rốn dai dẳng, thậm chí dữ dội
  * Sụt cân đột ngột
  * Xuất huyết tiêu hóa: Đi ngoài phân đen, nôn ra máu…
  * Khi có các yếu tố nguy cơ gây ung thư dạ dày, đại tràng: Tiền sử bản thân và gia đình mắc các bệnh lý liên quan đến dạ dày/ đại tràng/ Đa polyp tuyến hoặc ung thư dạ dày/ đại tràng; nhiễm vi khuẩn HP; chế độ ăn không lành mạnh (nhiều mỡ và Cholesterol, nhiều rượu, bia,..); béo phì…..


_Khi thấy các dấu hiệu đau bụng, chướng bụng, chán ăn, buồn nôn… kéo dài có thể sẽ cần phải nội soi tiêu hóa_
**Nội soi tiêu hóa – giải pháp vàng giúp phát hiện ung thư tiêu hóa sớm**
Hiện nay, nội soi tiêu hóa là phương pháp an toàn và chính xác nhất giúp bác sĩ có thể thăm khám trực tiếp toàn bộ hệ thống tiêu hóa, gồm: phần trên đường tiêu hóa (dạ dày, thực quản, tá tràng), phần dưới của đường tiêu hóa (trực tràng, đại tràng, hậu môn), do đó giúp chẩn đoán chính xác, không bỏ sót tổn thương hay bất thường, dù rất nhỏ, chỉ vài milimet và thậm chí ngay cả khi người bệnh chưa có bất kỳ dấu hiệu nào.
Thông qua phát hiện vùng niêm mạc lành và bất thường rõ nét hơn, bác sĩ có thể sinh thiết an toàn, hiệu quả và chính xác vào vùng có tế bào nghi ung thư, chẩn đoán ở mức độ biến đổi tế bào từ đó chẩn đoán chính xác ung thư; can thiệp cầm máu, cắt polyp tránh polyp chảy máu, ung thư hóa….
Nội soi ống tiêu hóa để chẩn đoán ung thư sớm sẽ giúp rút ngắn thời gian điều trị bệnh, tiết kiệm chi phí, tránh được các biến chứng nguy hiểm/ di căn ung thư, kéo dài sự sống cho bệnh nhân.
**Những phương pháp nội soi tiêu hóa phổ biến hiện nay**
Hiện nay, nội soi đường tiêu hóa có hai loại kỹ thuật cơ bản:
_**Nội soi tiêu hóa thường**_
Đây là phương pháp sử dụng ống nội soi đưa vào từ đường mũi/họng (nội soi tiêu hóa trên) hoặc qua đường hậu môn (nội soi tiêu hóa dưới) khi bệnh nhân hoàn toàn tỉnh táo. Bác sĩ sẽ chỉ dùng thuốc gây tê để gây tê tại một vị trí nhất định. Do đó, bệnh nhân thường cảm giác khó chịu, đau đớn, thậm chí ám ảnh sau nội soi.
_**Nội soi tiêu hóa không đau**_
Về bản chất, đây cũng là nội soi tiêu hóa sử dụng ống mềm để kiểm tra hệ thống tiêu hóa thông qua đường mũi/ họng hoặc hậu môn, song bệnh nhân sẽ được sử dụng thuốc an thần. Vì thế quá trình nội soi diễn ra rất nhẹ nhàng, thoải mái và nhanh chóng nên bệnh nhân không hề bị khó chịu, tránh được các tổn thương không mong muốn trong khi nội soi (do người bệnh giãy giụa, giật ống soi…)
_Nội soi tiêu hóa là phương pháp an toàn và hiệu quả để thăm khám toàn bộ hệ thống tiêu hóa_
**Nội soi đường tiêu hóa được thực hiện như thế nào?**
Trước khi nội soi, bác sĩ sẽ thăm khám sơ bộ cho bệnh nhân. Bạn cần cung cấp đầy đủ các thông tin về tiền sử bệnh và dị ứng (nếu có), các thuốc đang sử dụng và tình trạng sức khỏe. Tùy thuộc vào loại nội soi (đường tiêu hóa trên hay dưới) và phương pháp nội soi (nội soi thường hay nội soi gây mê) mà bệnh nhân sẽ được hướng dẫn các bước chuẩn bị cụ thể (nhịn ăn, làm sạch dạ dày hoặc xúc rửa trực tràng và hậu môn trước soi…).
Tiến hành nội soi: Bệnh nhân nằm nghiêng trái và được xịt thuốc gây tê cục bộ vào cổ họng/ mũi hoặc hậu môn (đối với nội soi thông thường), tiêm thuốc an thần (đối với nội soi không đau). Bác sĩ sẽ từ từ đưa ống nội soi vào miệng/ mũi (đối với nội soi tiêu hóa trên) hoặc vào hậu môn (trong trường hợp nội soi tiêu hóa dưới).
Thông qua hình ảnh được ghi lại trên camera của ống soi, bác sĩ sẽ tìm các bất thường đường tiêu hóa và sử dụng các dụng cụ chuyên biệt để lấy sinh thiết cũng như thực hiện các thủ thuật điều trị cần thiết như cắt polyp, cầm máu, nong thực quản…
Quá trình nội soi thường kéo dài khoảng 20 phút và có thể lâu hơn tùy thuộc vào bệnh lý được phát hiện khi nội soi.
**Cần chuẩn bị gì trước khi tiến hành nội soi?**
Để việc nội soi đường tiêu hóa được hiệu quả, bạn cần tuân thủ chính xác các hướng dẫn của bác sĩ, đặc biệt phải thông báo tình trạng sức khỏe, tình trạng bệnh lý hay các loại thuốc đang sử dụng với bác sĩ thực hiện. Với các bệnh nhân có bệnh mãn tính như tiểu đường, tim mạch, huyết áp, nên hỏi kỹ tư vấn của bác sỹ gây mê trước khi thực hiện thủ thuật.
24h trước khi nội soi, bạn nên uống thật nhiều nước hoặc ăn nhiều đồ ăn lỏng, nhằm hạn chế tình trạng mất nước của dạ dày, đại tràng khi nội soi.
Tránh các loại nước uống và thực phẩm có màu đậm, đặc biệt là màu đỏ, cam vì dễ nhầm lẫn với tình trạng chảy máu đường tiêu hóa, làm ảnh hưởng tới kết quả nội soi.
Nhịn ăn tối thiểu từ 6 – 8 tiếng trước khi nội soi
Không dùng thuốc băng niêm mạc dạ dày như: Gastropulgit, Phosphalugel… trước khi nội soi đường tiêu hóa trên.
Thụt tháo, làm sạch phân trong lòng đại tràng trước khi nội soi đường tiêu hóa dưới.
_Nên nhịn ăn tổi thiểu từ 6-8 tiếng trước khi nội soi_
**Lưu ý sau khi thực hiện nội soi tiêu hóa**
Chỉ nên ăn hoặc uống các đồ có dạng lỏng, nguội, dễ tiêu hóa sau 2 giờ sau khi nội soi để hạn chế tổn thương đường tiêu hóa
Nên nghỉ ngơi tại bệnh viện một thời gian ngắn trước khi ra về và có người thân đi cùng khi nội soi, không nên tự lái xe về
Với các trường hợp nội soi gây mê, không nên có những quyết định quan trọng liên quan đến các vấn đề cá nhân hay tài chính trong vòng 24 giờ sau khi nội soi.
Uống thuốc theo đơn, tuân thủ chế độ ăn uống và tái khám đúng lịch hẹn của bác sĩ
Lưu ý theo dõi sức khỏe sau khi nội soi, nếu thấy bất kỳ triệu chứng bất thường nên gọi ngay cho bác sĩ hoặc đến bệnh viện để kiểm tra.
**Bệnh viện – nơi hội tụ các bác sĩ nội soi tiêu hóa đầu ngành**
Bệnh viện được đánh giá là địa chỉ khám chữa bệnh về tiêu hóa uy tín hàng đầu hiện nay.
Đội ngũ bác sĩ tiêu hóa đang làm việc tại Bệnh viện đều được tuyển chọn từ các bác sĩ giỏi có nhiều năm kinh nghiệm làm việc trong lĩnh vực tiêu hóa – gan mật, ngoại tiêu hóa tại bệnh viện Bạch Mai, Đại học Y Hà Nội, Viện 198… Bên cạnh đó là đội ngũ bác sĩ kế cận đã qua đào tạo tại Nhật Bản không chỉ nắm vững chuyên môn, tay nghề thành thạo mà còn được tiếp nhận những kỹ thuật tiên tiến nhất trong chẩn đoán và điều trị bệnh lý tiêu hóa.
Nhờ sở hữu hệ thống trang thiết bị hiện đại cùng đội ngũ y bác sĩ giỏi, Bệnh viện đã và đang mang lại cho khách hàng trải nghiệm về dịch vụ chất lượng cao trong thăm khám tiêu hóa, bao gồm cả nội soi không gây mê và gây mê cùng các ca tiểu phẫu như nội soi cắt trĩ; cắt polyp dạ dày, đại tràng, trực tràng; nội soi điều trị sỏi mật, u túi mật; lấy dị vật đường tiêu hóa hay những ca đại phẫu như khâu lỗ thủng dạ dày, ruột non; cắt ruột thừa, túi mật; mở ống mật chủ lấy sỏi; cắt nang ống mật chủ; phẫu thuật nối mật ruột…
**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/) **- Đa khoa Hạng I Thành phố Hồ Chí Minh

## ️ Nội soi thoát vị đĩa đệm cột sống thắt lưng cần lưu ý

Nội soi thoát vị đĩa đệm cột sống thắt lưng là phương pháp phẫu thuật ít xâm lấn, sử dụng những dụng cụ đặc biệt và những máy móc hiện đại để lấy khối thoát vị nhưng ít làm ảnh hưởng đến cấu trúc của cột sống. Thoát vị đĩa đệm là nguyên nhân hàng đầu gây đau lưng. Đó là tình trạng cấu trúc đĩa đệm phình ra gây chèn ép vào các cấu trúc lân cận, biểu hiện là đau vùng thắt lưng có thể lan xuống mông hoặc chân khiến bệnh nhân đi lại khó khăn.
_Thoát vị đĩa đệm là tình trạng cấu trúc đĩa đệm phình ra gây chèn ép vào các cấu trúc lân cận, biểu hiện là đau vùng thắt lưng_
Hiện nay, để chẩn đoán thoát vị đĩa đệm cột sống thắt lưng cần có sự hỗ trợ của các phương tiện chẩn đoán hiện đại như chụp cắt lớp vi tính, chụp cộng hưởng từ. Nếu không kịp thời xử lý tình trạng bệnh có thể gây biến chứng nguy hiểm.
## **Nội soi thoát vị đĩa đệm cột sống thắt lưng**
Đối với hầu hết người bệnh, việc lựa chọn phương pháp điều trị nội khoa hay phẫu thuật là vấn đề rất khó khăn, đặc biệt khi bác sĩ đề nghị phẫu thuật. Phương pháp điều trị nội khoa là phương pháp chủ yếu và cơ bản điều trị thoát vị đĩa đệm cột sống lưng, bao gồm nghỉ ngơi, dùng thuốc, tiêm ngoài màng cứng, kéo giãn cột sống. Các phương pháp can thiệp tối thiểu như dùng laser, đốt sóng radio làm giảm áp đĩa đệm mang lại hiệu quả nhất định cho những trường hợp ở giai đoạn sớm, chưa rách bao xơ đĩa đệm. Trong nhiều trường hợp vẫn cần phải sử dụng đến phương pháp điều trị bằng phẫu thuật. Điều trị phẫu thuật chiếm khoảng 10-20% số bệnh nhân thoát vị đĩa đệm và chỉ được xem xét khi đã điều trị nội khoa trong thời gian 6 tuần mà không có kết quả hoặc triệu chứng tái phát nhiều lần. Có 2 phương pháp phẫu thuật thường được áp dụng là phẫu thuật mở và phẫu thuật ít xâm lấn (nội soi).
_Nội soi thoát vị đĩa đệm là một phương pháp điều trị ít xâm lấn, được sử dụng rộng rãi hiện nay_
Nội soi thoát vị đĩa đệm cột sống thắt lưng ít xâm lấn với vết mổ nhỏ. Bác sĩ sẽ sử dụng những dụng cụ đặc biệt và những máy móc hiện đại để lấy khối thoát vị nhưng ít làm ảnh hưởng đến cấu trúc của cột sống. Một ống nội soi có đường kính 8mm được đưa vào vị trí đĩa đệm thoát vị, các thao tác kỹ thuật lấy khối thoát vị được thực hiện qua ống này, các bác sĩ quan sát trên màn hình qua hệ thống camera có độ nét cao để phẫu thuật, các cấu trúc đĩa đệm, rễ thần kinh, màng tủy, mạch máu được nhìn thấy rõ nên ít xảy ra tai biến. Do không phải cắt các cấu trúc của cột sống nên lượng máu mất trong phẫu thuật rất ít, hơn nữa không làm hư tổn đến các tổ chức xung quanh nên sau phẫu thuật không cần hoặc dùng rất ít thuốc giảm đau. Khoảng vài giờ sau phẫu thuật người bệnh có thể ngồi dậy đi lại nhẹ nhàng, tự làm những công việc thông thường như ăn uống, tắm rửa, đi vệ sinh. Đặc biệt hơn, vết rạch da chỉ khoảng 7mm nên không cần khâu, sẹo nhỏ có tính thẩm mỹ cao. Bệnh nhân có thể xuất viện ngay ngày hôm sau và trở lại công việc sớm.
_Bệnh viện là địa chỉ áp dụng phương pháp phẫu thuật nội soi an toàn, hiệu quả_
Ưu điểm của kỹ thuật nội soi thoát vị đĩa đệm cột sống thắt lưng là ít làm tổn thương đến cấu trúc của cột sống, giúp bệnh nhân vận động sớm sau mổ, ít phải dùng thuốc giảm đau, sẹo mổ nhỏ và đặc biệt giảm tỷ lệ biến chứng so với mổ mở.
**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/) **- Đa khoa Hạng I Thành phố Hồ Chí Minh

## ️ Nội soi dạ dày, tá tràng: 7 điều quan trọng cần biết

**Nội soi dạ dày, tá tràng là gì?**
**Nội soi dạ dày tá tràng** là kỹ thuật thăm khám bên trong đường tiêu hóa nhờ vào camera gắn ở đầu ống nội soi mềm có đường kính khoảng 1cm đưa vào cơ thể qua miệng bệnh nhân. Từ việc quan sát hình ảnh mà camera ở ống nội soi đưa lại trên màn hình, giúp bác sĩ phát hiện những tổn thương ở thực quản, dạ dày, hành tá tràng. Trong quá trình nội soi, có thể đưa các dụng cụ can thiệp qua ổng nội soi để thực hiện:
– Làm các thủ thuật điều trị như: Cầm máu khi bệnh nhân bị xuất huyết tiêu hóa; cắt polyp; lấy dị vật đường tiêu hóa, nong thực quản…
– Lấy mẫu sinh thiết: lấy một lượng mô rất nhỏ (khoảng 1mm) để thực hiện sinh thiết nhằm phát hiện các các bệnh lý như chảy máu, tiêu chảy hoặc chẩn đoán ung thư dạ dày.
Máy với chức năng nội soi dải tần hẹp NBI (Narrow Band Imaging), cho phép quan sát sắc nét và phân tích kỹ lưỡng lớp niêm mạc ống tiêu hóa, khả năng phóng đại hình ảnh giúp mang lại hiệu quả chẩn đoán các tổn thương, ung thư ở giai đoạn rất sớm mà các máy nội soi thông thường khó làm được.
_Nội soi dạ dày là phương pháp tiên tiến giúp phát hiện bệnh lý chính xác_
**Đối tượng cần nội soi dạ dày, tá tràng**
Với thực trạng thực phẩm thiếu an toàn và chế độ ăn uống thiếu khoa học ngày nay, các bệnh về dạ dày, tá tràng xảy ra rất phổ biến. Nếu phát hiện bệnh sớm thì việc điều trị bệnh sẽ đơn giản, hiệu quả. Ngược lại, nếu chủ quan để bệnh tiến triển nặng mới đi khám thì thường điều trị rất tốn kém thời gian và tiền bạc, thậm chí để lâu ngày có thể trở thành ung thư.
Vậy nên, ngoài việc nên đi kiểm tra **nội soi dạ dày tá tràng** định kỳ theo lời khuyên của bác sĩ, thì những trường hợp sau đây phải đến gặp bác sĩ để được khám, tư vấn nội soi càng sớm càng tốt:
+ Đau thượng vị, buồn nôn sau ăn, đau bụng không rõ nguyên nhân
+ Giảm cân không rõ nguyên nhân
+ Ợ chua, ợ hơi, chậm tiêu, trào ngược thức ăn, nuốt nghẹn
+ Kém hấp thu, ăn uống đủ nhưng không hấp thu
+ Nôn ra máu, thiếu máu, đi ngoài ra phân đen
+ Đau ngực nhưng kiểm tra tim mạch bình thường
+ Dùng thuốc chống viêm, giảm đau, gây đau thượng vị
+ Người đang theo dõi bệnh lý dạ dày
+ Người có nguy cơ mắc polyp có yếu tố gia đình
**Các phương pháp nội soi dạ dày tá tràng**
**Nội soi dạ dày, tá tràng** hiện nay được thực hiện phố biến ở hầu hết các bệnh viện với 2 phương pháp sau:
  * _**Nội soi dạ dày qua đường miệng**_


Đây là phương pháp nội soi dạ dày- tá trạng được áp dụng phổ biến hiện nay cho hầu hết các trường hợp. Với phương pháp này, ống nội soi được đưa vào để thăm khám thực quản, dạ dày, tá tràng thông qua đường miệng. Tùy vào đặc điểm của bệnh nhân, bác sĩ sẽ chỉ định thực hiện một trong hai hình thức nội soi qua đường miệng sau:
_Nội soi dạ dày, tá tràng qua đường miệng_
_– Nội soi thường_ : Phương pháp này không dùng thuốc gây mê. Bệnh nhân sẽ thực hiện nội soi trong trạng thái hoàn toàn tỉnh táo. Hình thức này tiết kiệm chi phí, tuy nhiên có một nhược điểm là do soi trong lúc tỉnh táo, ống nội soi to khi đi qua cổ họng sẽ tạo cảm giác buồn nôn, khó chịu, khiến bệnh nhân không nằm im mà có thể cựa quậy, không hợp tác, gây cản trở quá trình nội soi của Bác sĩ.
_-Nội soi gây mê (hay còn gọi là nội soi không đau)_**:** Với nội soi gây mê, quá trình nội soi giờ chỉ là một giấc ngủ đối với bệnh nhân, xua tan mọi ám ảnh trước đây như khó chịu, nôn.
+ Ưu điểm của hình thức này là hoàn toàn không đau, không gây kích thích, không khó chịu., bác sĩ thực hiện có thể thăm dò hầu hết các bộ phận của đường tiêu hóa, giảm thiểu tối đa các tai biến, biến chứng.
+ Nhược điểm của hình thức này là chi phí đắt hơn. Sau nội soi một số người có thể thấy mệt mỏi, buồn ngủ do tác dụng của thuốc gây mệ chưa hết, cần phải nghỉ ngơi khoảng 30p phút đến 1 giờ để đảm bảo hoàn toàn tỉnh táo.
  * _**Nội soi dạ dày, tá tràng qua đường mũi**_


Vài năm trở lại đây, bên cạnh nội soi dày, tá tràng qua đường miệng, phương pháp nội soi qua đường mũi cũng được đưa vào sử dụng ở một số bệnh viện. Ở phương pháp này, bác sĩ sẽ dùng ống nội soi với kích thước rất nhỏ (chỉ khoảng 5.9mm) đưa vào thăm khám dạ dày, tá tràng qua đường mũi của bệnh nhân.
Ưu điểm của phương pháp là bệnh nhân có thể tình táo và nói chuyện, trao đổi với bác sĩ trong quá trình nội soi. Do ống nội soi đi qua mũi nên không gây cảm giác khó chịu, buồn nôn, bệnh nhân thoải mái nằm im giúp bác sĩ dễ dàng thực hiện nội soi.
Tuy nhiên phương pháp này vẫn có nhược điểm lớn đó là không thể đồng thời thực hiện các thủ thuật can thiệp (cắt polyp, cầm máu dạ dày, nong thực quản…) trong quá trình nội soi. Nếu muốn thực hiện các thủ thuật này bắt buộc phải chuyển sang hình thức nội soi đường miệng.
Bên cạnh đó những người đang mắc các bệnh về mũi hoặc những người hẹp khe mũi sẽ không thực hiện được phương pháp này.
**Quy trình thực hiện nội soi dạ dày, tá tràng**
Sau đây là đầy đủ các bước của phương pháp nội soi dạ dày, tá tràng phổ biến nhất hiện nay- nội soi gây mê qua đường miệng:
_Người bệnh được thăm khám trước khi nội soi_
Bước 1: Bác sĩ nội tiêu hóa thăm khám, đánh giá tình trạng bệnh sử, bệnh lý, chỉ định nội soi và những xét nghiệm nếu cần trước nội soi.
Bước 2: Sau khi đi làm các xét nghiệm được chỉ định, bệnh nhân gặp bác sĩ gây mê để được tư vấn, giải thích về thủ thuật và gây mê trước khi nội soi.
Bước 3: Trước khi vào nội soi từ 10-30 phút bệnh nhân sẽ được cho uống dung dịch làm sạch bọt và nhày trong dạ dày, để giúp cho quan sát và đánh giá tổn thương được tốt nhất.
Bước 4: Thay đồ và vào phòng nội soi thực hiện gây mê.
Bước 5: Thực hiện đưa ống nội soi vào qua miệng bệnh nhân để thực hiện quá trình nội soi dạ dày, tá tràng.
Bước 6: Kết thúc quá trình nội soi và ghi kết quả. Chờ bệnh nhân tỉnh táo, bác sĩ đọc kết quả nội soi.
Bước 7: Bệnh nhân thay đồ và quay trở về phòng khám ban đầu để bác sĩ tư vấn và kê toa thuốc điều trị nếu cần thiết.
Tổng thời gian cho một quá trình **nội soi dạ dày tá tràng** như trên kéo dài khoảng 2,5 giờ.
**Cần chuẩn bị gì trước khi tiến hành nội soi**
Để đảm bảo buổi thăm khám và **nội soi dạ dày, tá tràng** diễn ra thuận lợi và nhanh chóng, bạn cần chú ý những điều sau:
– Cần nhịn ăn ít nhất 6 tiếng trước khi nội soi để đảm bảo dạ dày sạch, bác sĩ có thể quan sát được rõ niêm mạc dạ dày. Nhịn uống ít nhất 2 tiếng trước khi nội soi, không sử dụng thức uống có màu (cà phê, nước dâu,….). Do đó, thời điểm tốt nhất đến bệnh viện để thực hiện nội soi là vào buổi sáng, thuận tiện cho việc nhịn ăn uống.
– Với các bệnh nhân bị hẹp môn vị, cần nhịn ăn ít nhất từ 12-24 giờ, cũng có trường hợp phải rửa dạ dày trước khi nội soi.
– Thông tin đầy đủ cho bác sĩ nếu bạn có tiền sử mắc bệnh tim mạch, hô hấp, huyết áp… hoặc tiền sử dị ứng với bất kỳ một loại thuốc nào.
– Nếu bạn đang sử dụng thuốc điều trị bệnh hoặc các loại thực phẩm chức năng cũng cần thông báo cho bác sĩ.
– Nên tìm hiểu trước những bệnh viện uy tín với đội ngũ bác sĩ và máy móc nội soi tốt, để đảm bảo nội soi an toàn- hiệu quả.
**Sau khi nội soi cần lưu ý gì?**
– Sau khi nội soi, để đảm bảo an toàn, bệnh nhân nên ngồi nghỉ tại chỗ ít nhất 30 phút để cơ thể hoàn toàn hồi tỉnh thoải mái rồi mới ra về. Với người lớn tuổi nên có người nhà đi cùng để chăm sóc tốt nhất sau nội soi.
– Không nên ăn ngay sau khi nội soi, mà chờ ít nhất khoảng 2 tiếng. Nên ăn những đồ ăn mềm, dễ tiêu hóa, đặc biệt không ăn đồ cay nóng để không làm tổn tương niêm mạc dạ dày sau nội soi.
_Sau nội soi dạ dày người bệnh nên ăn thực phẩm mềm, dễ tiêu hóa_
– Sau nội soi bệnh nhân có thể cảm thấy chướng bụng nhẹ hoặc đau rát cổ họng. Không cần quá lo lắng vì đây là hiện tượng bình thường, sẽ giảm dần và kết thúc trong vòng vài ngày sau nội soi.
**Một số biến chứng khi nội soi dạ dày, tá tràng**
Mặc dù nội soi dạ dày, tá tràng là thủ thuật đơn giản và được áp dụng phổ biến ở hầu hết các bệnh viện, tuiy nhiên sau nội soi, một số ít trường hợp vẫn có thể gặp một số dạng biến chứng sau:
– Đau và chảy máu.
– Nhiễm trùng sau nội soi.
– Sốc phản vệ sau nội soi.
– Thủng thực quản, dạ dày, tá tràng do trong ống nội soi cọ phải trong quá trình nội soi.
– Tụt huyết áp, khó thở đối với bệnh nhân thực hiện nội soi gây mê).
Biểu hiện của những biến chứng trên là sau nội soi bạn có các triệu chứng: Sốt, đau ngực, khó thở, đi ngoài phân đen hoặc sẫm màu, đau bụng liên tục, nôn mửa… Nếu thấy các hiện tượng trên cần gọi điện ngay cho bác sĩ nội soi để được tư vấn hướng xử lý kịp thời.
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh

## ️ Khám nội soi thực quản phát hiện trào ngược dạ dày

  * [Chứng trào ngược dạ dày xảy ra như thế nào](https://bvnguyentriphuong.com.vn/noi-soi/kham-noi-soi-thuc-quan-phat-hien-trao-nguoc-da-day#chng-tro-ngc-d-dy-xy-ra-nh-th-no)
  * [Nguyên nhân gây trào ngược dạ dày – thực quản](https://bvnguyentriphuong.com.vn/noi-soi/kham-noi-soi-thuc-quan-phat-hien-trao-nguoc-da-day#nguyn-nhn-gy-tro-ngc-d-dy-thc-qun)
  * [Khám nội soi thực quản chẩn đoán bệnh trào ngược dạ dày](https://bvnguyentriphuong.com.vn/noi-soi/kham-noi-soi-thuc-quan-phat-hien-trao-nguoc-da-day#khm-ni-soi-thc-qun-chn-on-bnh-trao-ngc-da-day)


Trào ngược dạ dày là tình trạng axit từ dạ dày thường xuyên trào ngược lên trên thực quản. Trong các thủ tục chẩn đoán bệnh hiện nay, khám nội soi thực quản là phương pháp giúp phát hiện bệnh trào ngược dạ dày hiệu quả.
### **Chứng trào ngược dạ dày xảy ra như thế nào**
Cơ vòng thự quản (vòng cơ ở dưới cùng của thực quản) có vai trò đóng lại để ngăn axit từ dạ dày trào lên trên thực quản sau khi ăn. Ở người bệnh trào ngược dạ dày, cơ vòng này tường không đóng lại hoặc đóng lại không đúng cách, khiến dạ dày bị tổn thương, viêm tấy do tiếp xúc với axit thường xuyên. Hiện tượng này phổ biến ở cả người lớn và trẻ em, gây ra các triệu chứng khó nuốt, tức ngực, buồn nôn và nôn…
### **Nguyên nhân gây trào ngược dạ dày – thực quản**
Có một số yếu tố có thể làm yếu hoặc giãn cơ vòng thực quản dưới gây hiện tượng trào ngược như:
Thói quen dùng rượu bia, thuốc lá, đi khom lưng.
Chế độ ăn nhiều chất béo, đồ ăn chiên xào, hành, tỏi, thức ăn có gia vị đậm…
Ăn uống không điều độ, ăn quá no, ăn trước khi đi ngủ…
Một số yếu tố khác như thoát vị hoành, phụ nữ mang thai, bệnh tiểu đường, béo phì…
### **Khám nội soi thực quản chẩn đoán bệnh trào ngược dạ dày**
Khi xuất hiện những dấu hiệu của trào ngược dạ dày, người bệnh cần đến bệnh viện để được kiểm tra và chẩn đoán chính xác bệnh, từ đó có phương án điều trị phù hợp. Một trong các phương pháp chẩn đoán trào ngược dạ dày đem lại kết quả chính xác là nội soi thực quản.
Nội soi thực quản là phương pháp dùng ống nội soi có gắn camerađưa qua miệng vào thực quản để quan sát bên trong thực quản, giúp phát hiện các tổn thương niêm mạc thực quản, các biến chứng của bệnh trào ngược dạ dày như viêm thực quản, loét, hẹp thực quản…
Bên cạnh nội soi thực quản, một số phương pháp khác có thể phát hiện trào ngược dạ dày là chụp X-quang thực quản hay đo pH thực quản. Chụp X-quang thực quản có thể giúp chẩn đoán hình ảnh giúp phát hiện các biến chứng teo hẹp, loét thực quản hoặc thoát vị hoành. Đo pH thực quản có thể xác định sự có mặt của axit trong thực quản.
**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/) **- Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [Chứng trào ngược dạ dày xảy ra như thế nào](https://bvnguyentriphuong.com.vn/noi-soi/kham-noi-soi-thuc-quan-phat-hien-trao-nguoc-da-day#chng-tro-ngc-d-dy-xy-ra-nh-th-no)
  * [Nguyên nhân gây trào ngược dạ dày – thực quản](https://bvnguyentriphuong.com.vn/noi-soi/kham-noi-soi-thuc-quan-phat-hien-trao-nguoc-da-day#nguyn-nhn-gy-tro-ngc-d-dy-thc-qun)
  * [Khám nội soi thực quản chẩn đoán bệnh trào ngược dạ dày](https://bvnguyentriphuong.com.vn/noi-soi/kham-noi-soi-thuc-quan-phat-hien-trao-nguoc-da-day#khm-ni-soi-thc-qun-chn-on-bnh-trao-ngc-da-day)



## ️ Đau dạ dày nên siêu âm hay nội soi?

  * [Nên chọn siêu âm dạ dày hay nội soi](https://bvnguyentriphuong.com.vn/noi-soi/dau-da-day-nen-sieu-am-hay-noi-soi#nn-chn-siu-m-d-dy-hay-ni-soi)
  * [Tại sao chọn phương pháp nội soi khi bị đau dạ dày là chính xác nhất?](https://bvnguyentriphuong.com.vn/noi-soi/dau-da-day-nen-sieu-am-hay-noi-soi#ti-sao-chn-phng-php-ni-soi-khi-b-au-d-dy-l-chnh-xc-nht)
  * [Các phương pháp nội soi dạ dày](https://bvnguyentriphuong.com.vn/noi-soi/dau-da-day-nen-sieu-am-hay-noi-soi#cc-phng-php-ni-soi-d-dy)
  * [Kết quả nội soi dạ dày](https://bvnguyentriphuong.com.vn/noi-soi/dau-da-day-nen-sieu-am-hay-noi-soi#kt-qu-ni-soi-d-dy)
  * [Lưu ý trước và sau khi nội soi dạ dày](https://bvnguyentriphuong.com.vn/noi-soi/dau-da-day-nen-sieu-am-hay-noi-soi#lu-trc-v-sau-khi-ni-soi-d-dy)
  * [Tại sao khi đau dạ dày không nên lựa chọn phương pháp siêu âm?](https://bvnguyentriphuong.com.vn/noi-soi/dau-da-day-nen-sieu-am-hay-noi-soi#ti-sao-khi-au-d-dy-khng-nn-la-chn-phng-php-siu-m)


## **Nên chọn siêu âm dạ dày hay nội soi**
Siêu âm dạ dày là phương pháp thăm khám cận lâm sàng, được dùng để phát hiện các điểm bất thường trong vùng bụng. Với cách thăm khám này, các bác sĩ sẽ sử dụng máy siêu âm và các thiết bị hỗ trợ nhằm phát hiện ra những vấn đề không bình thường xảy ra ở vùng bụng của bệnh nhân.
Khác với siêu âm, nội soi dạ dày là phương pháp chẩn đoán xâm lấn. Bằng việc sử dụng ống nội soi có gắn đầu camera để luồn sâu vào trong dạ dày, các bác sĩ có thể quan sát trực tiếp lớp niêm mạc dạ dày. Từ đó, có thể đưa ra kết quả chẩn đoán chính xác nhất về bệnh lý mà bệnh nhân đang gặp phải.
Đối với người nghi ngờ bị đau dạ dày, việc sử dụng phương pháp nội soi sẽ mang lại kết quả tối ưu nhất. Nội soi cho chúng ta nhìn thấy hình ảnh rõ nét của dạ dày và dễ dàng phát hiện các tổn thương bề mặt bất thường, đây là điều mà phương pháp siêu âm không thể thấy được.
_Nội soi là phương pháp chẩn đoán bệnh đau dạ dày chính xác nhất_
## **Tại sao chọn phương pháp nội soi khi bị đau dạ dày là chính xác nhất?**
**Thế nào là nội soi dạ dày?**
Nội soi dạ dày là một phương thức thăm khám trực tiếp phần trên của ống tiêu hóa (bao gồm thực quản, dạ dày và tá tràng) nhờ vào một ống soi mềm nhỏ. Nhờ quan sát hình ảnh qua máy nội soi, bác sĩ có thể biết được những bất thường đang xảy ra bên trong ống tiêu hóa, từ đó có được chẩn đoán và phương pháp điều trị thích hợp, hiệu quả nhất.
**Đối tượng cần nội soi dạ dày**
Nội soi là phương pháp hiệu quả trong khám chữa bệnh. Tuy nhiên, không phải bất kỳ trường hợp nào chúng ta cũng nên dùng nội soi để kiểm tra. Tùy vào mục đích và tình trạng của người bệnh, các bác sĩ sẽ chỉ định có nên nội soi hay không.
Qua quá trình nội soi, các bác sĩ có thể phát hiện những tổn thương nhỏ chỉ vài milimet trong dạ dày và có thể xét nghiệm tìm vi khuẩn HP gây bệnh hoặc sinh thiết để tìm ung thư. Nội soi dạ dày cũng được áp dụng để theo dõi quá trình điều trị các tổn thương, nhiễm khuẩn, viêm loét hay chảy máu dạ dày. 
Người bệnh nếu thấy những triệu chứng bất ổn về đường tiêu hóa thì nên tiến hành nội soi dạ dày như:
  * Nuốt đau, nuốt nghẹn, khó nuốt hoặc nuốt vướng;
  * Nóng rát thượng vị, có thể nôn ra máu;
  * Đau thượng vị, đau sau xương ức, thường xuyên nôn ói khi đánh răng;
  * Thường xuyên ợ hơi, ợ chua, ợ nóng, đầy bụng, ăn không tiêu, thiếu máu, thiếu sắt;
  * Ho, viêm họng kéo dài, cảm giác vướng víu ở cổ họng;
  * Sụt cân, người gầy yếu không rõ nguyên nhân;
  * Sinh hoạt chung với người đã nhiễm vi khuẩn HP;
  * Buồn nôn, nôn sau khi ăn hoặc khi làm việc nặng;
  * Đi đại tiện ra phân đen.


## **Các phương pháp nội soi dạ dày**
**Nội soi dạ dày qua đường miệng**
Nội soi dạ dày qua đường miệng là phương thức nội soi truyền thống, nhờ vào một ống soi mềm nhỏ đường kính khoảng 1 cm đưa vào qua đường miệng, thanh quản và tiếp cận đến bên trong dạ dày để tiến hành quan sát niêm mạc, bề mặt dạ dày.
Người bệnh sẽ được xịt thuốc tê nhẹ vào khoang miệng trước khi đưa ống nội soi vào. Thuốc tê sẽ làm giảm cảm giác khó chịu do ống nội soi kích thích vào miệng và họng. Ống nội soi mềm khi xuống tới dạ dày của người bệnh, bác sĩ có thể theo dõi và đưa ra các chẩn đoán thông qua hình ảnh từ camera được truyền tải về màn hình. Kết thúc nội soi, ống soi sẽ được nhẹ nhàng rút ra khỏi miệng của bệnh nhân.
Phương pháp này cho độ chính xác cao, giá thành thấp lại dễ thực hiện. Tuy nhiên, do ống mềm có kích thích lớn, khi đi qua đường miệng vào lưỡi gà, vòm khẩu cái, đáy lưỡi dễ làm bệnh nhân buồn nôn, có cảm giác sợ hãi khi nội soi. Để làm giảm các triệu chứng trên, người bệnh nên hít thở thật sâu và chậm rãi.
**Nội soi dạ dày qua đường mũi**
Là phương pháp dùng một ống nội soi rất nhỏ, luồn qua đường mũi đã được gây tê, qua họng rồi lần lượt dẫn xuống các cơ quan như thực quản, dạ dày, hành tá tràng, tá tràng để quan sát bề mặt niêm mạc của ống tiêu hóa trên. Người bệnh được yêu cầu nuốt nhẹ xuống và các bác sĩ sẽ di chuyển ống soi xuống dạ dày. Tại đây, camera được gắn trên đầu ống soi sẽ truyền hình ảnh tới màn hình để bác sĩ có thể dễ dàng quan sát và đưa ra các chẩn đoán nếu phát hiện có bất thường..
Phương pháp này được đánh giá cao về tính an toàn và hiệu quả. Do ống nội soi nhỏ, đi qua đường mũi nên ít gây kích thích vào lưỡi gà, vòm khẩu cái, đáy lưỡi nên ít gây đau và làm giảm phản xạ nôn ói và cũng không cần gây mê nên ít gây thay đổi về tâm lý, huyết áp cũng như nhịp tim của người bệnh.
_Nội soi dạ dày gây mê là phương pháp an toàn và hiệu quả trong chẩn đoán bệnh dạ dày_
**Nội soi dạ dày gây mê**
Phương pháp nội soi dạ dày không đau (gây mê) là thủ thuật thực hiện đưa ống nội soi qua đường miệng, khi bệnh nhân đã được gây mê. Ưu điểm của phương pháp là bệnh nhân sẽ không cảm thấy buồn nôn, khó chịu hay tránh được tình trạng sợ hãi.
Người bệnh sẽ được gây mê ngắn từ 10-15 phút. Người bệnh hoàn toàn không có cảm giác khó chịu, thời gian tỉnh mê hoàn toàn khoảng 1-2 tiếng sau nội soi. Sau tỉnh, bệnh nhân sẽ được bác sĩ thăm khám, hỏi thăm, thông báo về tình trạng của bản thân và có những lời khuyên sau nội soi.
## **Kết quả nội soi dạ dày**
Thông thường bác sĩ sẽ trả hình ảnh kết quả ngay sau khi nội soi. Trường hợp có lấy mẫu để chẩn đoán nhiễm vi khuẩn HP (Helicobacter pylori hay H. pylori) kết quả sẽ được trả 1-2 giờ sau đó. Kết quả sinh thiết tế bào để chẩn đoán ung thư thường có trong vòng 1 tuần. Bệnh nhân có thể chủ động hỏi bác sĩ về thời gian nhận kết quả nội soi và sinh thiết của mình. 
## **Lưu ý trước và sau khi nội soi dạ dày**
Trước và sau khi nội soi bệnh nhân cần lưu ý những điều sau:
  * Nhịn ăn trong vòng 6 – 8 giờ trước khi đi nội soi dạ dày. Bạn có thể đi nội soi vào buổi sáng, khi chưa ăn sáng. Việc nhịn ăn này là để ngăn ngừa tình trạng nôn, sặc, và giúp bác sĩ quan sát rõ vùng niêm mạc dạ dày;
  * Trước khi nội soi, không uống các loại nước có màu như: cà phê, sữa, nước cam, nước uống có gas… Bạn có thể uống nước lọc nhưng với một lượng ít, không uống đầy bụng;
  * Không hút thuốc để giúp bác sĩ dễ quan sát, soi rõ được tổn thương;
  * Không sử dụng các thuốc tráng bao tử (như Phosphalugel, thường gọi là gói thuốc chữ P,…) hoặc thuốc viên than hoạt trước khi nội soi;
  * Nếu bản thân có dị ứng với các loại thuốc tê, thuốc gây mê, băng dính thì cần báo với bác sĩ trước khi tiến hành nội soi dạ dày;
  * Khi đi nội soi dạ dày, đặc biệt là nội soi có gây mê, nên có người thân đi cùng để hỗ trợ sau khi nội soi. Với nội soi gây mê, sẽ cần một khoảng thời gian để tỉnh táo trở lại và thuốc mê hết tác dụng hoàn toàn (thường là khoảng 1 giờ). Vì vậy, tốt nhất là nên có người nhà đi cùng và đưa về;
  * Người bệnh có thể cảm thấy: đau rát họng, khó nuốt, đau bụng, chướng bụng nhẹ, tình trạng này sẽ nhanh chóng biến mất sau vài giờ;
  * Khoảng 2 giờ sau khi nội soi, bệnh nhân có thể dùng các món ăn mềm, lỏng, dễ tiêu hóa như cháo, súp, món hầm nhừ. Có thể dùng sữa nguội, nhưng không nên uống sữa nóng có thể làm tổn thương dạ dày.


_Cần trao đổi kỹ càng với bác sỹ về bệnh sử trước khi nội soi dạ dày_
## **Tại sao khi đau dạ dày không nên lựa chọn phương pháp siêu âm?**
**Siêu âm dạ dày là gì?**
Siêu âm dạ dày là phương pháp thăm khám cận lâm sàng, được dùng để phát hiện được các điểm bất thường trong vùng bụng. Với cách thăm khám này, các bác sĩ sẽ sử dụng máy siêu âm và các thiết bị hỗ trợ nhằm phát hiện ra những vấn đề không bình thường xảy ra ở vùng bụng của bệnh nhân.
**Nhược điểm của siêu âm dạ dày**
So với các phương pháp chẩn đoán khác, siêu âm được xem là tiện dụng, không gây đau đớn, khá dễ thực hiện. Tuy nhiên, phương pháp siêu âm thường không được chỉ định để chẩn đoán các bệnh về dạ dày. Bởi lẽ, nó không thể giúp các bác sĩ quan sát được trực tiếp niêm mạc dạ dày, không thể lấy mẫu bệnh phẩm để tiến hành thí nghiệm.
Ngoài ra, siêu âm chỉ sử dụng các bước sóng nên hình ảnh thu được khá khó quan sát và không thật sự rõ nét. Đối với những bệnh nhân bị nặng, hoặc có cân nặng lớn, việc quan sát các mức độ tổn thương, những vết viêm loét không được rõ ràng vì các mô mỡ gây cản trở nhiều. Do đó, khi siêu âm, bác sĩ rất khó xác định chính xác các tổn thương.
**Đối tượng nên siêu âm dạ dày**
Siêu âm dạ dày được các bác sĩ chỉ định cho một số trường hợp như:
  * Người có các biểu hiện bệnh lý về đường tiêu hóa, cần phải được xem xét kỹ lưỡng
  * Những người không thể thực hiện được phương pháp nội soi
  * Bệnh nhân bị giãn dạ dày cấp tính, sa dạ dày cấp tính
  * Cần kiểm tra các khối polyp dạ dày, khối u trong dạ dày
  * Bệnh nhân bị rối loạn chức năng dạ dày
  * Người bị các dị tật bẩm sinh đường tiêu hóa như hẹp môn vị phì đại bẩm sinh, dị tật đường tiêu hóa
  * Các trường hợp có dấu hiệu viêm thực quản và dạ dày nặng.
  * Những người xuất hiện dị vật trong dạ dày.


**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/) **- Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [Nên chọn siêu âm dạ dày hay nội soi](https://bvnguyentriphuong.com.vn/noi-soi/dau-da-day-nen-sieu-am-hay-noi-soi#nn-chn-siu-m-d-dy-hay-ni-soi)
  * [Tại sao chọn phương pháp nội soi khi bị đau dạ dày là chính xác nhất?](https://bvnguyentriphuong.com.vn/noi-soi/dau-da-day-nen-sieu-am-hay-noi-soi#ti-sao-chn-phng-php-ni-soi-khi-b-au-d-dy-l-chnh-xc-nht)
  * [Các phương pháp nội soi dạ dày](https://bvnguyentriphuong.com.vn/noi-soi/dau-da-day-nen-sieu-am-hay-noi-soi#cc-phng-php-ni-soi-d-dy)
  * [Kết quả nội soi dạ dày](https://bvnguyentriphuong.com.vn/noi-soi/dau-da-day-nen-sieu-am-hay-noi-soi#kt-qu-ni-soi-d-dy)
  * [Lưu ý trước và sau khi nội soi dạ dày](https://bvnguyentriphuong.com.vn/noi-soi/dau-da-day-nen-sieu-am-hay-noi-soi#lu-trc-v-sau-khi-ni-soi-d-dy)
  * [Tại sao khi đau dạ dày không nên lựa chọn phương pháp siêu âm?](https://bvnguyentriphuong.com.vn/noi-soi/dau-da-day-nen-sieu-am-hay-noi-soi#ti-sao-khi-au-d-dy-khng-nn-la-chn-phng-php-siu-m)



## ️ Quy trình nội soi dạ dày

  * [Nội soi dạ dày là gì?](https://bvnguyentriphuong.com.vn/noi-soi/quy-trinh-noi-soi-da-day#ni-soi-da-day-la-gi)
  * [Quy trình nội soi dạ dày](https://bvnguyentriphuong.com.vn/noi-soi/quy-trinh-noi-soi-da-day#quy-trnh-ni-soi-d-dy)
  * [Trước khi nội soi:](https://bvnguyentriphuong.com.vn/noi-soi/quy-trinh-noi-soi-da-day#trc-khi-ni-soi)
  * [Quá trình thực hiện:](https://bvnguyentriphuong.com.vn/noi-soi/quy-trinh-noi-soi-da-day#qu-trnh-thc-hin)
  * [Sau khi nội soi:](https://bvnguyentriphuong.com.vn/noi-soi/quy-trinh-noi-soi-da-day#sau-khi-ni-soi)


Nội soi dạ dày là một trong các phương pháp hiệu quả nhất để phát hiện và chẩn đoán các bệnh lý liên quan đến dạ dày. Tuy nhiên do cách thức và quy trình nội soi dạ dày có thể gây đau đớn nên nhiều người vẫn e ngại hoặc sợ nội soi, dẫn đến tình trạng phát hiện và điều trị bệnh ở giai đoạn muộn.
## **Nội soi dạ dày là gì?**
**Người bệnh nên khám nội soi dạ dày khi có các dấu hiệu khó chịu vùng bụng**
Nội soi dạ dày là phương pháp thăm khám trực tiếp phần trên của ống tiêu hóa (bao gồm thực quản, dạ dày và tá tràng) bằng cách đưa một ống soi mềm nhỏ qua đường miệng. Bác sĩ có thể quan sát các thay dấu hiệu bất thường trong dạ dày qua hình ảnh trên máy soi, từ đó đưa ra chẩn đoán và phương pháp điều trị thích hợp.
Qua nội soi dạ dày, bác sĩ có thể phát hiện các tổn thương rất nhỏ trên dạ dày để chẩn đoán bệnh. Ngoài ra, nội soi dạ dày còn được dùng để theo dõi quá trình điều trị các tổn thương loét, điều trị nhiễm khuẩn và chảy máu dạ dày.
### **Quy trình nội soi dạ dày**
#### **Trước khi nội soi:**
Người bệnh cần nhịn ăn uống ít nhất là 8 giờ để chống nôn, bảo vệ đường thở và giúp bác sĩ soi thấy rõ tổn thương. Trong một số bệnh lý đặc biệt như hẹp môn vị…, bệnh nhân cần phải nhịn ăn lâu hơn (12 – 24 giờ) hoặc phải thực hiện bơm rửa dạ dày.
**Người bệnh trước nội soi dạ dày cần thông báo cho bác sĩ các loại thuốc đang sử dụng**
Trong trường hợp người bệnh đang uống thuốc, cần thông báo cho bác sĩ về các loại thuốc đang sử dụng, tiền sử dị ứng thuốc và các bệnh lý kèm theo khác nhằm đảm bảo tính an toàn khi thực hiện nội soi.
#### **Quá trình thực hiện:**
Nội soi dạ dày kéo dài khoảng 10 phút. Trước khi soi, bệnh nhân được xịt thuốc tê vào sâu trong miệng để làm bớt khó chịu khi đưa ống soi vào. Máy soi được đưa qua họng và vào thực quản. Lúc đầu bệnh nhân có thể có cảm giác khó chịu, nghẹn thở và muốn ho hay sặc, cảm giác này sẽ biến mất nhanh chóng. Nếu quá trình nội soi phát hiện dấu hiệu bất thường và nghi ngờ ung thư dạ dày, bác sĩ sẽ lấy một mẫu mô nhỏ trong dạ dày để làm sinh thiết và xét nghiệm mô bệnh học.
#### **Sau khi nội soi:**
Sau khi kết thúc nội soi dạ dày, người bệnh nên nghỉ ngơi một thời gian ngắn. Cần chú ý không được ăn uống trong vòng 1 giờ sau khi soi do thuốc tê vẫn chưa hết tác dụng.
Ngoài ra, sau khi nội soi dạ dày, bệnh nhân sẽ có cảm giác đau họng hay trướng bụng nhẹ. Tình trạng này sẽ không kéo dài. Sau khoảng 30 phút, bác sĩ sẽ giải thích về các tổn thương quan sát được trong quá trình nội soi và hẹn ngày lấy kết quả sinh thiết nếu có.
**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/) **- Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [Nội soi dạ dày là gì?](https://bvnguyentriphuong.com.vn/noi-soi/quy-trinh-noi-soi-da-day#ni-soi-da-day-la-gi)
  * [Quy trình nội soi dạ dày](https://bvnguyentriphuong.com.vn/noi-soi/quy-trinh-noi-soi-da-day#quy-trnh-ni-soi-d-dy)
  * [Trước khi nội soi:](https://bvnguyentriphuong.com.vn/noi-soi/quy-trinh-noi-soi-da-day#trc-khi-ni-soi)
  * [Quá trình thực hiện:](https://bvnguyentriphuong.com.vn/noi-soi/quy-trinh-noi-soi-da-day#qu-trnh-thc-hin)
  * [Sau khi nội soi:](https://bvnguyentriphuong.com.vn/noi-soi/quy-trinh-noi-soi-da-day#sau-khi-ni-soi)



## ️ Phẫu thuật nội soi dạ dày: phương pháp điều trị an toàn và hiệu quả cao

**Phẫu thuật nội soi dạ dày là gì?**
Phẫu thuật nội soi dạ dày là phương pháp phẫu thuật ngoại khoa có mức độ xâm lấn thấp dùng để điều trị các bệnh liên quan đến đường tiêu hóa. Để thực hiện phương pháp này, bác sĩ sẽ tạo ra vết rạch nhỏ, rồi sử dụng ống soi có gắn camera và đèn chiếu để quan sát khu vực phẫu thuật bên trong cơ thể. Sau khi quan sát và xác định vị trí cơ quan bị ảnh hưởng, bác sĩ sẽ tiến hành xử lý bằng dụ cụ y tế chuyên dụng.
**Đối tượng chỉ định và chống chỉ định của phẫu thuật nội soi dạ dày**
_**Đối tượng chỉ định**_
Phương pháp phẫu thuật nội soi dạ dày được chỉ định cho những đối tượng cụ thể như sau:
  * Viêm loét dạ dày tá tràng
  * Xuất huyết dạ dày
  * Polyp dạ dày
  * Ung thư dạ dày
  * Thủng dạ dày


_Viêm loét dạ dày_
_**Đối tượng chống chỉ định**_
Thủ thuật mổ nội soi có thể gây nguy hiểm đối với một số đối tượng, cần được sự tư vấn của bác sĩ về mức độ rủi ro trước khi quyết định có thực hiện thủ thuật hay không:
  * Bệnh tiểu đường kinh niên
  * Bệnh nhân huyết áp cao
  * Phụ nữ đang mang thai


**Ưu điểm và nhược điểm của phẫu thuật nội soi dạ dày**
So với mổ hở truyền thống, phẫu thuật nội soi dạ dày mang lại nhiều ưu điểm và cũng có nhược điểm nhất định.
_**Ưu điểm**_
  * Giảm xuất huyết, mất máu, giảm nguy cơ cần truyền máu trong quá trình phẫu thuật
  * Vết mổ có kích thước nhỏ, không gây đau nhiều và rút ngắn thời gian hồi phục sau phẫu thuật, đồng thời không để lại sẹo gây mất thẩm mỹ.
  * Phẫu thuật nội soi dạ dày ít đau, nên không cần sử dụng đến thuốc giảm đau cần thiết.
  * Thời gian phục hồi sau phẫu thuật nhanh chóng, rút ngắn thời gian nằm viện, bệnh nhân có thể về nhà sau khi được theo dõi, nghỉ ngơi.
  * So với mổ mở, phẫu thuật nội soi dạ dày sẽ giảm phơi nhiễm các cơ quan nội tạng với môi trường bên ngoài, giúp làm giảm nguy cơ nhiễm trùng.


_**Nhược điểm**_
– Phẫu thuật nội soi chỉ phù hợp với tổn thương dạ dày nhỏ
– Giới hạn chuyển động tại vị trí phẫu thuật của bác sĩ, vì vậy đòi hỏi trình độ khéo léo và có kinh nghiệm của bác sĩ phẫu thuật.
– Bác sĩ không trực tiếp thao tác bằng tay với các mô mà thông qua các công cụ phẫu thuật cụ thể. Do đó có thể dẫn đến trường hợp không thể đánh giá chính xác lực tác động lên mô, nguy cơ mô bị tổn hại.
– Phẫu thuật nội soi khiến bác sĩ không thể quan sát được toàn bộ các cơ quan trong hệ tiêu hoá
– Chi phí phẫu thuật cao
**Quy trình phẫu thuật nội soi dạ dày**
Phẫu thuật nội soi dạ dày được thực hiện theo quy trình như sau:
  * Bệnh nhân được đặt nằm theo vị trí thuận lợi nhất cho thao tác phẫu thuật.
  * Bệnh nhân được tiêm thuốc gây mê toàn thân để không có cảm giác đau trong quá trình phẫu
  * Bác sĩ sẽ tiến hành rạch một vết mổ có kích thước nhỏ bên thành bụng và đưa ống nội soi vào bên trong dạ dày.
  * Trong quá trình thực hiện, bác sĩ sẽ bơm cacbon dioxide hoặc nitrous oxide để duy trì khí bên trong bụng giúp quan sát dễ hơn.
  * Quan sát hình ảnh hiển thị thu được từ ống nội soi và đánh giá tổn thương của dạ dày.
  * Bác sĩ sẽ kiểm tra một số cơ quan trong ổ bụng để hạn chế rủi ro phát sinh khi thực hiện phẫu thuật.
  * Sau đó bác sĩ sẽ tiến hành xử lý vấn đề đã được xác định trước (cắt bỏ khối u, cắt một phần dạ dày, khâu vết thương,…)
  * Cuối cùng, bác sĩ sẽ khâu vết mổ và đánh giá tình trạng sức khỏe của bệnh nhân.


**Triệu chứng sau khi phẫu thuật nội soi dạ dày**
  * Sau khi thực hiện phẫu thuật khoảng vài ngày, bệnh nhân sẽ cảm thấy mệt mỏi và khó chịu, cảm giác đau ở vết mổ nhất là khi cử động, đi lại hoặc tác động đến vết thương
  * Bệnh nhân sẽ cảm thấy đau rát họng vì trong quá trình phẫu thuật, ống thở được đặt vào cổ họng bệnh nhân. Để giảm cảm giác đau, có thể ngậm nước muối, dùng thuốc ngậm họng.
  * Do tác dụng phụ của loại khí được sử dụng trong phẫu thuật, bệnh nhân có thể bị đau lưng hoặc đau vai.
  * Cảm giác tức bụng, chướng bụng sẽ xuất hiện trong 1 – 2 ngày sau phẫu thuật. Một số loại phẫu thuật còn gây chảy máu hoặc ra dịch hồng ở âm đạo trong 1 – 2 tuần sau phẫu thuật.


Đây đều là các triệu chứng không đáng lo ngại, sẽ tự hết trong vài ngày sau phẫu thuật. Trường hợp triệu chứng ở mức độ nghiêm trọng và diễn ra trong thời gian dài cần đến gặp bác sĩ để được tư vấn và kiểm tra.
**Lưu ý trước và sau khi phẫu thuật nội soi dạ dày**
_**Lưu ý trước phẫu thuật**_
  * Hạn chế việc sử dụng đồ uống có cồn và các chất kích thích như thuốc lá, rượu bia… để quá trình phẫu thuật được diễn ra huận lợi.
  * Ngưng sử dụng một số loại thuốc gây rủi ro khi phẫu thuật như thuốc chống đông máu, Aspirin,…
  * Trước khi phẫu thuật từ 7-9 giờ, nên nhịn ăn và uống đồ có màu đậm để dạ dày trống và sạch sẽ


_**Lưu ý sau phẫu thuật**_
  * Sau khi tỉnh cần bổ sung nước cho cơ thể
  * Không nằm nhiều, nên ngồi dậy và tập đi lại ngay khi có thể để tránh dính ruột
  * Cố gắng xì hơi sớm, sau khi xì hơi có thể ăn uống bình thường
  * 1-2 tuần đầu sau phẫu thuật, cần tránh vận động mạnh, các hoạt động thể lực để không ảnh hưởng đến cơ thể
  * Hạn chế quan hệ tình dục trong 4 – 6 tuần sau mổ.


**B****iến chứng xảy ra khi phẫu thuật nội soi dạ dày**
Phẫu thuật nội soi dạ dày không tránh khỏi việc sẽ để lại những biến chứng nhất định, bệnh nhân cần theo dõi cơ thể và đến ngay cơ sở y tế khi gặp biến chứng.
  * Nhiễm trùng (sốt, ớn lạnh, đau quặn bụng,…)
  * Xuất huyết dạ dày (phân có màu sẫm, đen…)
  * Trào ngược dạ dày thực quản
  * Tắc nghẽn ruột non
  * Tổn thương các cơ quan lân cận
  * Xuất huyết tại vùng bị rạch
  * Thoát vị ở vùng rạch


**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/) **- Đa khoa Hạng I Thành phố Hồ Chí Minh

## ️ Nội soi đại tràng gây mê: Những điều mà BẠN nên biết

  * [Nội soi đại tràng gây mê được sử dụng để làm gì?](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-dai-trang-gay-me-nhung-dieu-ma-ban-nen-biet#ni-soi-i-trng-gy-m-c-s-dng-lm-g)
  * [Cần chuẩn bị gì trước khi nội soi đại tràng gây mê?](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-dai-trang-gay-me-nhung-dieu-ma-ban-nen-biet#cn-chun-b-g-trc-khi-ni-soi-i-trng-gy-m)
  * [Nội soi đại tràng gây mê có gì khác so với nội soi truyền thống?](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-dai-trang-gay-me-nhung-dieu-ma-ban-nen-biet#ni-soi-i-trng-gy-m-c-g-khc-so-vi-ni-soi-truyn-thng)


## **Nội soi đại tràng gây mê được sử dụng để làm gì?**     Nội soi đại tràng gây mê được sử dụng để tìm ra nguyên nhân dẫn tới các tình trạng như máu trong phân, đau bụng, tiêu chảy hoặc thay đổi thói quen đại tiện hay sự bất thường được tìm thấy trên hình ảnh X quang đại tràng hoặc CT scan
Tương tự như nội soi đại tràng truyền thống, nội soi đại tràng gây mê có thể được thực hiện vì rất nhiều lý do. Thông thường phương pháp này được sử dụng để tìm ra nguyên nhân dẫn tới các tình trạng như máu trong phân, đau bụng, tiêu chảy hoặc thay đổi thói quen đại tiện hay sự bất thường được tìm thấy trên hình ảnh X quang đại tràng hoặc CT scan. Người bệnh trước đó đã từng có polyp đại tràng hoặc ung thư đại tràng và một số trường hợp có tiền sử gia đình mắc phải các vấn đề về đại tràng có thể làm tăng nguy cơ ung thư như viêm loét đại tràng và polyp đại tràng. Những đối tượng này cần phải tiến hành nội soi đại tràng định kỳ theo hướng dẫn của bác sĩ vì nguy cơ phát triển polyp và ung thư đại tràng của họ cao hơn so với bình thường.
## **Cần chuẩn bị gì trước khi nội soi đại tràng gây mê?**
Trước khi nội soi gây mê, người bệnh cần phải làm sạch ruột theo hướng dẫn của bác sĩ bằng một trong những cách sau:
  * Uống một chai thuốc Fleet Phosphosoda 45 ml với khoảng 1 lít nước ngay trước hôm đi nội soi, đi cầu nhiều lần cho tới khi nước trong.
  * Bệnh nhân thụt tháo bằng cách đưa nước vào đại tràng qua ngã hậu môn, đi cầu nhiều lần cho tới khi nước trong. Thủ thuật này thường được thực hiện tại bệnh viện và mất khoảng 2 giờ.


Đặc biệt với nội soi đại tràng gây mê, người bệnh cần nhịn ăn ít nhất là 12 tiếng trước khi thực hiện nội soi. Lưu ý người bệnh cũng nên thông báo cho bác sĩ biết về loại thuốc hiện đang sử dụng, bao gồm cả chất bổ sung và các loại thảo dược, để được biết có nên tạm ngừng sử dụng hay không. Đồng thời cần báo cho bác sĩ biết nếu bị dị ứng với bất cứ loại thuốc nào.
## **Nội soi đại tràng gây mê có gì khác so với nội soi truyền thống?**     Nội soi đại tràng gây mê được đánh giá là an toàn và rất ít biến chứng.
Trước đây mỗi khi nhắc tới nội soi đại tràng truyền thống, người bệnh hay cảm thấy e ngại vì sợ đau, khó chịu mỗi khi phải nội soi. Tuy nhiên với nội soi đại tràng gây mê, nỗi sợ hãi này sẽ được xóa bỏ hoàn toàn. Trong quá trình nội soi, người bệnh sẽ được gây mê bằng thuốc an thần có tác dụng ngắn, tỉnh ngay sau 15 phút và không ảnh hưởng tới sức khỏe. Nhờ đó người bệnh sẽ không còn cảm thấy khó chịu hay đau đớn sau khi đã hoàn thành thủ thuật. Ngoài ra, phương pháp này cũng được đánh giá là an toàn và rất ít biến chứng. Thời gian gây mê ngắn, lượng thuốc gây mê ít và được tính toán phù hợp với thể trạng của người bệnh nên không gây hại cho sức khỏe.
**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/) **- Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [Nội soi đại tràng gây mê được sử dụng để làm gì?](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-dai-trang-gay-me-nhung-dieu-ma-ban-nen-biet#ni-soi-i-trng-gy-m-c-s-dng-lm-g)
  * [Cần chuẩn bị gì trước khi nội soi đại tràng gây mê?](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-dai-trang-gay-me-nhung-dieu-ma-ban-nen-biet#cn-chun-b-g-trc-khi-ni-soi-i-trng-gy-m)
  * [Nội soi đại tràng gây mê có gì khác so với nội soi truyền thống?](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-dai-trang-gay-me-nhung-dieu-ma-ban-nen-biet#ni-soi-i-trng-gy-m-c-g-khc-so-vi-ni-soi-truyn-thng)



## ️ 10 câu hỏi thường gặp trong nội soi ống tiêu hóa

**Nội soi là gì?**
Nội soi là một phương thức thăm khám trực tiếp trên cơ thể người bệnh. Với phương pháp này, các bác sĩ sẽ đưa một ống soi mềm, đầu có gắn đèn và camera phóng đại gấp nhiều lần giúp quan sát trực tiếp, thấy rõ các tổn thương từ lớn đến nhỏ như viêm loét, dị vật, dị dạng mạch máu niêm mạc…mà camera truyền tải về trên máy tính. Từ đó, các bác sĩ sẽ xác định được mức độ những tổn thương của người bệnh để đưa ra phác đồ điều trị phù hợp nhất.
Ống nội soi được đưa vào cơ thể thông qua các đường tự nhiên như miệng, mũi, hậu môn… Với kỹ thuật nội soi, các bác sĩ có thể quay phim, chụp hình bên trong các cơ quan, có thể lấy đi dị vật, sinh thiết và đặc biệt là có thể thực hiện phẫu thuật nội soi.
Hiện nay, nội soi được sử dụng hầu hết trong các chuyên khoa như: tai mũi họng, tiêu hóa, sản, ngoại, tiết niệu, thẩm mỹ…
**Vai trò của nội soi ống tiêu hóa là gì?**
  * Phát hiện chính xác các tổn thương bên trong các cơ quan trong cơ thể dù rất nhỏ và những bất thường như polyp, khối u lành tính hay ác tính, các tổn thương trên ống tiêu hóa bị chảy máu…
  * Chẩn đoán xác định, không bỏ sót tổn thương nào ngay khi người bệnh chưa có bất kỳ triệu chứng nào.
  * Giúp phát hiện những vùng niêm mạc bất thường rõ nét và bác sĩ có thể tiến hành can thiệp như lấy mẫu bệnh phẩm sinh thiết, giúp chẩn đoán chính xác ung thư.
  * Qua nội soi, các bác sĩ có thể can thiệp cầm máu (nếu đang chảy máu) hoặc cắt polyp để tránh polyp chảy máu hoặc phát triển thành tiền ung thư.


**Nội soi ống tiêu hóa được áp dụng cho những đối tượng nào?**
  * Những người có các triệu chứng bất thường trong cơ thể như: buồn nôn, khó tiêu, đi ngoài ra máu, đau thượng vị, đau rát họng…
  * Bệnh nhân mắc các bệnh mãn tính như dạ dày, đại trực tràng… thì nên đi nội soi định kỳ khoảng 2 lần/năm.
  * Người có người thân bị mắc các bệnh về đường tiêu hóa, ung thư…thì cũng nên đi nội soi kiểm tra định kỳ.
  * Người thường xuyên hút thuốc lá, uống rượu bia.
  * Những người đi tầm soát để phát hiện sớm các bệnh ung thư dạ dày, ung thư đại trực tràng…


Tuy nhiên, trong một số trường hợp, bác sĩ cũng có thể không áp dụng phương pháp nội soi ống tiêu hóa cho bệnh nhân nếu bệnh nhân ở trong các trường hợp như: người bị suy tim, người bị suy hô hấp, người bị thiếu máu, nhồi máu cơ tim, người mắc hội chứng tâm thần không phối hợp và người mới ăn no.
**Bao nhiêu lâu nên nội soi ống tiêu hóa một lần?**
Việc thời gian nội soi dạ dày bao lâu một lần còn tùy theo mục đích và từng tình trạng bệnh mà bệnh nhân gặp phải thì thời gian để tái khám nội soi cũng được quy định không giống nhau.
Thêm vào đó, một ca nội soi cũng rất tốn kém đặc biệt là những phương pháp có gây mê, nội soi cắt polyp… Chính vì vậy, việc chúng ta đi nội soi thường xuyên là một lựa chọn không nên.
Một số các trường hợp và mức độ nội soi cần thiết cụ thể như:
  * Nhiễm vi khuẩn HP đường tiêu hóa mãn tính, không có loạn sản thì nên nội soi tầm soát ung thư 3 năm/ 1 lần.
  * Bệnh nhân bị tổn thương đường tiêu hóa nghiêm trọng và chưa điều trị thì nội soi 3 – 6 tháng/ 1 lần để kiểm tra.
  * Những người bị đau dạ dày, đại trực tràng ở mức độ nhẹ, không phát hiện thấy loạn sản thì không cần phải đi nội soi lại lần 2.
  * Bệnh nhân bị xuất huyết cơ quan tiêu hóa thì cần nội soi vài lần trong ngày để tiến hành các biện pháp điều trị.


**Nội soi nhiều có tốt không? Có ảnh hưởng gì không?**
Kỹ thuật nội soi ống tiêu hóa mặc dù mang nhiều ưu điểm vượt trội so với nhiều phương pháp thăm khám khác trong việc chẩn đoán các bệnh lý và mang lại kết quả chính xác gần như tuyệt đối, tốn ít thời gian, đối tượng an toàn. Tuy nhiên, theo các khuyến cáo của bác sĩ, nếu nội soi thường xuyên mà không được các bác sĩ chỉ định thì cơ thể của bạn cũng có thể gặp những ảnh hưởng không tốt.
Nội soi được đánh giá là phương pháp thăm khám có tính an toàn cao, rất ít bị tai biến, tuy nhiên phương pháp này sử dụng công cụ chuyên biệt để đưa vào cơ thể nên trong quá trình nội soi có thể xảy ra những tình huống không mong muốn như bị đau họng, đau mũi, thủng dạ dày… Một số vấn đề thường gặp sau nội soi dạ dày là đau bụng; đau quặn bụng sau khi nội soi đại tràng…
Để không gây ra cảm giác đau, khó chịu cho người bệnh trong quá trình nội soi, bác sĩ sẽ gây mê cho người bệnh. Một số người dùng phương pháp nội soi gây mê có thể bị tụt huyết áp, dị uống thuốc mê, huyết áp rối loạn…
Tuy nhiên, các tình trạng này cũng rất ít khi xảy ra, nên bạn cũng không cần phải quá lo lắng nhé.
**Nội soi có đau không?**
Hiện nay, có 2 phương pháp nội soi ống tiêu hóa là nội soi gây mê và không gây mê.
Tùy vào từng bệnh lý của bệnh nhân mà bác sĩ sẽ đưa ra lời khuyên phù hợp là bệnh nhân nên sử dụng phương pháp nào.
Những bệnh nhân đi kiểm tra nội soi tai mũi họng thông thường sẽ không cần gây mê do quá trình nội soi nhẹ nhàng, nhanh chóng và không gây đau đớn hay khó chịu gì cho người bệnh.
Còn những bệnh nhân có bệnh lý về đường tiêu hóa như dạ dày, đại trực tràng thì bác sĩ sẽ chỉ định nội soi gây mê. Bác sĩ sẽ tiêm một lượng thuốc vừa đủ vào tĩnh mạch trên cánh tay giúp bệnh nhân trải qua một giấc ngủ ngắn. Kèm theo đó là có các thiết bị theo dõi nhịp tim, nhịp thở và huyết áp được gắn trên người bệnh nhân. Bệnh nhân sẽ không có bất kỳ cảm giác đau đớn hay khó chịu trong quá trình nội soi. Cũng như thời gian gây mê ngắn, lượng thuốc mê ít nên không ảnh hưởng đến sức khỏe và tâm sinh lý người bệnh.
Để trả lời cho câu hỏi “Nội soi có đau không?” thì các bạn yên tâm, với sự phát triển của y khoa và các phương pháp hỗ trợ thì nội soi sẽ không gây cho bạn cảm giác đau đớn trong quá trình thực hiện.
**Nội soi xong bị đau họng có ảnh hưởng gì không?**
Một trong số các biến chứng xảy ra sau quá trình nội soi ống tiêu hóa có thể gây đau họng cho người bệnh. Chúng ta cùng tìm hiểu nguyên nhân và các hạn chế tình trạng này nhé.
Phương pháp nội soi qua đường miệng có thể gây đau họng cho bệnh nhân. Một số nguyên nhân gây nên như:
  * Bác sĩ sử dụng ống soi cứng, khó di chuyển gây tổn thương vòm họng trong quá trình luồn ống soi.
  * Xước niêm mạc họng cạnh Amidan do luồn ống nội soi. Nếu trong trường hợp này, có thể bạn bị viêm amidan cấp hoặc mãn tính khiến amidan của bạn to hơn bình thường.
  * Do thao tác của bác sĩ thực hiện chưa khéo léo dẫn đến cổ họng bị xước trong quá trình nội soi.
  * Bệnh nhân vẫn còn thức và cử động nhiều trong quá trình nội soi sẽ tăng nguy cơ tổn thương vùng họng khi đưa ống nội soi qua.


Vậy để hạn chế tình trạng bị đau họng sau khi nội soi ống tiêu hóa, bạn có thể áp dụng một vài cách dưới đây nhé:
  * Làm sạch khoang miệng bằng cách súc miệng bằng nước muối sinh lý, đặc biệt bạn nên tránh ho hoặc khạc nhổ.
  * Ngậm mật ong.
  * Nên dùng thức ăn lỏng như: súp; cháo loãng, sữa nguội…
  * Tránh thực phẩm cay nóng, đồ chế biến ăn sẵn.
  * Không nên dùng: bia, rượu, thuốc lá… không dùng đá lạnh.
  * Nếu trường hợp bạn bị đau họng sau nội soi do amidan thì bạn nên đến cơ sở y tế để thăm khám và điều trị amidan.


**Cần lưu ý gì trước khi nội soi ống tiêu hóa?**
**_Có cần nhịn ăn không?_**
Tùy vào phương pháp nội soi cũng như nội soi cơ quan nào trong cơ thể thì bác sĩ sẽ căn dặn bệnh nhân có cần phải nhịn ăn hay không.
  * Nội soi tai mũi họng không cần nhịn ăn. Nếu cần, người bệnh chỉ cần làm sạch vùng khoang miệng và mũi bằng cách vệ sinh với nước muối sinh lý trước khi đến nội soi
  * Nội soi tiêu hóa như nội soi dạ dày, nội soi đại trực tràng… bệnh nhân cần nhịn ăn từ tối hôm trước hoặc ít nhất 6 tiếng, cần làm sạch ruột bằng thuốc hoặc thụt trước khi nội soi để hình ảnh nội soi được rõ ràng và chính xác.
  * Trong trường hợp bệnh nhân làm phương pháp nội soi gây mê. Trước khi nội soi, người bệnh cần phải thực hiện một số các xét nghiệm máu. Nên để kết quả xét nghiệm được chính xác, bệnh nhân nên nhịn ăn trước khi nội soi.


**_Có cần nhịn uống không?_**
Cũng như phần trên, trước khi nội soi ống tiêu hóa bệnh nhân cần nhịn ăn ít nhất 6 tiếng thì việc nhịn uống cũng hết sức quan trọng.
Người bệnh nên nhịn uống trước 2 – 3 tiếng trước khi nội soi. Đặc biệt, người bệnh tránh dùng các loại sữa, nước có chất tạo màu như cà phê, nước ngọt, nước hoa quả…trước khi nội soi đường tiêu hóa.
**Chi phí nội soi là bao nhiêu?**
Chi phí nội soi ống tiêu hóa luôn là câu hỏi được rất nhiều người bệnh băn khoăn đặt ra và tìm hiểu. Thực tế thì hầu như không có con số cụ thể nào cho việc thăm khám bằng phương pháp nội soi bởi chi phí thực hiện sẽ phụ thuộc vào nhiều yếu tố khác nhau như: phương pháp thực hiện, địa chỉ thăm khám…
Vậy nên, ngoài việc bạn quan tâm đến chi phí thì việc quan trọng nhất là bạn nên tìm một địa chỉ y tế uy tín để thực hiện nội soi ống tiêu hóa một cách chính xác nhất.
**Nội soi ống tiêu hóa ở bệnh viện nào uy tín nhất hiện nay?**
Hiện nay, có rất nhiều cơ sở khám chữa bệnh thực hiện được kỹ thuật nội soi ống tiêu hóa. Tuy nhiên, bạn nên tìm hiểu kỹ và chọn nội soi ở bệnh viện, phòng khám uy tín, đội ngũ bác sĩ, trang bị máy nội soi hiện đại, phương pháp khử trùng trước và sau nội soi…
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh

## ️ Nội soi dạ dày phát hiện 8 bệnh lý nguy hiểm

  * [Nội soi dạ dày là gì?](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-da-day-phat-hien-8-benh-ly-nguy-hiem#ni-soi-d-dy-l-g)
  * [Nội soi dạ dày được chỉ định trong trường hợp nào?](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-da-day-phat-hien-8-benh-ly-nguy-hiem#ni-soi-d-dy-c-ch-nh-trong-trng-hp-no)
  * [Nội soi dạ dày giúp phát hiện những bệnh lý nào?](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-da-day-phat-hien-8-benh-ly-nguy-hiem#ni-soi-d-dy-gip-pht-hin-nhng-bnh-l-no)
  * [Bệnh viêm dạ dày](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-da-day-phat-hien-8-benh-ly-nguy-hiem#bnh-vim-d-dy)
  * [Bệnh loét dạ dày](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-da-day-phat-hien-8-benh-ly-nguy-hiem#bnh-lot-d-dy)
  * [Trào ngược dạ dày](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-da-day-phat-hien-8-benh-ly-nguy-hiem#tro-ngc-d-dy)
  * [Xuất huyết dạ dày](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-da-day-phat-hien-8-benh-ly-nguy-hiem#xut-huyt-d-dy)
  * [Phát hiện dị vật lạ trong dạ dày](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-da-day-phat-hien-8-benh-ly-nguy-hiem#pht-hin-d-vt-l-trong-d-dy)
  * [Kết quả nội soi dạ dày](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-da-day-phat-hien-8-benh-ly-nguy-hiem#kt-qu-ni-soi-d-dy)
  * [Tầm quan trọng của việc nội soi tầm soát ung thư dạ dày](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-da-day-phat-hien-8-benh-ly-nguy-hiem#tm-quan-trng-ca-vic-ni-soi-tm-sot-ung-th-d-dy)


## **Nội soi dạ dày là gì?**
**Nội soi dạ dày** là phương pháp hữu hiệu để chẩn đoán chính xác các bệnh lý liên quan đến dạ dày. Phương pháp này sử dụng thiết bị quan sát đặc biệt gọi là ống nội soi. Ống nội soi là một ống mềm, có đường kính khoảng 1cm đưa qua đường miệng để thăm khám trực tiếp vào bên trong thực quản, dạ dày và phần đầu tiên của ruột non (tá tràng).
## **Nội soi dạ dày được chỉ định trong trường hợp nào?**
Nội soi dạ dày được áp dụng tất cả đối tượng, tuy nhiên có một số đối tượng sau nên **nội soi dạ dày** càng sớm càng tốt như:
– Gia đình có tiền sử bệnh ung thư dạ dày, hay những bệnh lý dạ dày mạn tính.
– Những người bệnh xuất hiện các triệu chứng như
+ Khó nuốt, nuốt đau, nuốt vướng, nuốt nghẹn.
+ Đau sau xương ức, cảm giác trào ngược, thường xuyên nôn ói khi đánh răng.
+ Đau thượng vị, nóng rát thượng vị, nôn ra máu.
+ Ợ chua, ợ hơi, ợ nóng, ăn chậm tiêu, cảm thấy buồn nôn, thiếu máu, thiết sắt, sụt cân nhanh
+ Ho, viêm họng lâu, kéo dài, cảm giác vướng cổ họng.
+ Đi ngoài phân đen.
– Những người bệnh có nhu cầu nội soi để tầm soát ung thư dạ dày.
_Nếu gặp phải các dấu hiệu về đường tiêu hóa cần đi nội soi dạ dày ngay_
## **Nội soi dạ dày giúp phát hiện những bệnh lý nào?**
**Nội soi dạ dày** có độ chính xác cao hơn các phương pháp chụp chiếu X-quang hay siêu âm, giúp phát hiện được hầu hết các tổn thương dạ dày dù nhỏ nhất. Hơn nữa, trong quá trình nội soi sẽ giúp bác sĩ dễ dàng lấy sinh thiết để chẩn đoán chính xác hơn. Bằng phương pháp này, 8 bệnh lý cơ bản sau sẽ được phát hiện:
### **Bệnh viêm dạ dày**
Viêm dạ dày là bệnh rất phổ biến về tiêu hóa. Thông thường viêm dạ dày có biểu hiện đau thượng vị, tuy nhiên ở một số người có những triệu chứng nhẹ hơn như đầy hơi, ợ chua, ợ nóng. Viêm dạ dày là hiện tượng dạ dày bị viêm, sưng, tấy đỏ, bệnh có thể xảy ra bất ngờ (viêm dạ dày cấp tính) hoặc kéo dài (viêm dạ dày mạn tính). Bệnh thông thường không nguy hiểm và sẽ ổn định sau khi được điều trị. Nhưng nếu không được điều trị kịp thời sẽ làm tăng nguy cơ loét dạ dày hoặc nặng hơn là ung thư dạ dày, đặc biệt là khi nguyên nhân gây bệnh do vi khuẩn Hp (Helicobacter pylori)
### **Bệnh loét dạ dày**
Loét dạ dày là tổn thương hở tại lớp niêm mạc dạ dày. Tổn thương này xảy ra ở dưới da xuống lớp mô hay phần cơ do lớp niêm mạc bảo về cuối cùng của dạ dày bị bào mòn. Bệnh lý này gây nên những cơn đau âm ỉ theo chu kỳ, thường xảy ra khi đói hoặc vài giờ sau bữa ăn. Thậm chí nặng hơn nữa là xuất huyết tiêu hóa nếu ổ loét lớn, chảy máu. Bệnh nếu không được phát hiện và điều trị sớm sẽ hình thành những cơn đau với tần suất ngày càng tăng, gặp nhiều biến chứng, đe dọa tính mạng người bệnh.
Hiện nay viêm loét dạ dày không chỉ gặp ở những đối tượng người già như trước mà phổ biến trong mọi lứa tuổi, mọi thành phần.
_Viêm loét dạ dày_
### **Phát hiện Hp**
Hp là viết tắt của Helicobacter pylori, là 1 loại vi khuẩn gây hại vô cùng nguy hiểm đối với hệ dạ dày. Vi khuẩn này là nguyên nhân hàng đầu gây nên tình trạng viêm loét dạ dày và có thể biến chứng nặng thành ung thư dạ dày bởi vì sau khi xâm nhập vi khuẩn sẽ sinh sống và phát triển tại lớp nhầy niêm mạc dạ dày, chúng tiết ra độc tố làm mất khả năng chống lại acid của lớp niêm mạc.
Phương pháp để phát hiện ra vi khuẩn Hp chính là **nội soi dạ dày** kết hợp với sinh thiết lấy mẫu mô xét nghiệm.
### **Polyp dạ dày**
Polyp dạ dày là những khối tế bào được hình thành ở lớp lót bên trong dạ dày. Hầu hết các polyp dạ dày không đáng quan ngại vì là những khối u lành tính. Tuy nhiên một số loại có thể làm tăng nguy cơ gây ung thư dạ dày trong tương lai.
Trong giai đoạn đầu, sẽ không thấy xuất hiện triệu chứng hay dấu hiệu cụ thể. Nhưng nếu polyp càng lớn, lan rộng sẽ có dấu hiệu như đau bụng, nôn mửa, nóng rát ở bụng, đi ngoài ra máu… Bệnh chỉ có thể được phát hiện bằng phương pháp **nội soi dạ dày.**
### **Trào ngược dạ dày**
Trào ngược dạ dày hay còn gọi là trào ngược axit dạ dày, là tình trạng trào ngược từng lúc hay thường xuyên của dịch dạ dày lên thực quản. Bệnh có các triệu chứng gồm ợ chua, ợ nóng, hôi miệng, đau ngực, nôn mửa, khó thở … Ngoài ra nếu bệnh mạn tính có thể gây các biến chứng nặng hơn như viêm thực quản, hẹp thực quản… **Nội soi dạ dày** sẽ phát hiện và chẩn đoán chính xác bệnh lý này.
_Trào ngược dạ dày_
### **Xuất huyết dạ dày**
Xuất huyết dạ dày chính là chảy máu dạ dày, là hiện tượng lớp niêm mạc dạ dày bị tổn thương khiến bên trong dạ dày bị chảy máu. Bệnh xuất hiện đột ngột và tiến triển rất nhanh chóng. Nếu không được can thiệp và điều trị kịp thời thì bệnh có thể gây nguy hiểm đến tính mạng. Hiện nay, **nội soi dạ dày** chính là giải pháp cấp cứu nhanh chóng và hiệu quả cao nhất. 
### **Ung thư dạ dày**
Đây là bệnh lý nguy hiểm nhất trong các bệnh lý về dạ dày. Ung thư dạ dày là hiện tượng các tế bào cấu trúc bình thường của dạ dày trở nên bất thường, đột biến và tăng sinh một cách không kiểm soát, xâm lấn các mô ở gần hay ở xa qua hệ thống bạch huyết. Ung thư dạ dày là nguyên nhân gây tử vong rất cao trong các bệnh ung thư. Bệnh lý này được phát hiện bằng cách nội soi dạ dày kết hợp sinh thiết tế bào.
### **Phát hiện dị vật lạ trong dạ dày**
Bằng **nội soi dạ dày** có thể phát hiện dị vật lạ trong dạ dày như giun…
## **Kết quả nội soi dạ dày**
**Thời gian trả kết quả**
Hình ảnh và kết quả nội soi sẽ được bác sĩ trả sau khi bệnh nhân nội soi xong. Nếu có lấy mẫu xét nghiệm vi khuẩn HP sẽ được trả kết quả sau 1-2 giờ. Trong trường hợp kết cần thiết phải sinh thiết tế bào thì kết quả này sẽ được trả sau đó 5-7 ngày.
**Giải thích kết quả**
Kết quả và hình ảnh nội soi được chia làm 2 loại: kết quả bình thường và kết quả bất thường
Kết quả bình thường: Kết quả nội soi được cho là bình thường khi không có các dấu hiệu sau: không có dấu hiệu nhiễm trùng như viêm loét dạ dày, không nhiễm vi khuẩn HP hay dấu hiệu ung thư khác.
Kết quả bất thường: Ngược lại với kết quả bình thường là bất thường nếu có các dấu hiệu sau: nhiễm vi khuẩn HP, viêm dạ dày, loét dạ dày, polyp dạ dày… Bác sĩ sẽ căn cứ vào tình trạng bệnh cụ thể, giai đoạn tiến triển của bệnh để có phác đồ điều trị hợp lý và hiệu quả cho người bệnh.
## **Tầm quan trọng của việc nội soi tầm soát ung thư dạ dày**
Vài năm gần đây, tỉ lệ người dân đến các cơ sở y tế nội soi tầm soát ung thư dạ dày ngày càng tăng. Điều đó chứng tỏ mức độ nguy hiểm của bệnh lý này nếu không được phát hiện và điều trị kịp thời
Theo thống kê, nếu các bệnh lý về dạ dày đặc biệt là ung thư dạ dày được chẩn đoán và phát hiện sớm thì cơ hội chữa khỏi, sống trên 5 năm sau mổ lên tới 80-90% nhưng nếu phát hiện muộn thì khả năng sống trên 5 năm sau mổ chỉ còn 10-15%.
Nội soi tầm soát ung thư dạ dày nếu phát hiện những bất thường, các dấu hiệu ung thư dạ dày ở giai đoạn đầu, bác sĩ sẽ có những phác đồ điều trị khả quan và hiệu quả hơn, đảm bảo sức khỏe cho người bệnh. Vì vậy nội soi tầm soát ung thư dạ dày rất cần thiết, càng sớm càng tốt và ở mọi lứa tuổi, kể cả khi không có các triệu chứng rõ rệt.
**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/) **- Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [Nội soi dạ dày là gì?](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-da-day-phat-hien-8-benh-ly-nguy-hiem#ni-soi-d-dy-l-g)
  * [Nội soi dạ dày được chỉ định trong trường hợp nào?](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-da-day-phat-hien-8-benh-ly-nguy-hiem#ni-soi-d-dy-c-ch-nh-trong-trng-hp-no)
  * [Nội soi dạ dày giúp phát hiện những bệnh lý nào?](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-da-day-phat-hien-8-benh-ly-nguy-hiem#ni-soi-d-dy-gip-pht-hin-nhng-bnh-l-no)
  * [Bệnh viêm dạ dày](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-da-day-phat-hien-8-benh-ly-nguy-hiem#bnh-vim-d-dy)
  * [Bệnh loét dạ dày](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-da-day-phat-hien-8-benh-ly-nguy-hiem#bnh-lot-d-dy)
  * [Trào ngược dạ dày](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-da-day-phat-hien-8-benh-ly-nguy-hiem#tro-ngc-d-dy)
  * [Xuất huyết dạ dày](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-da-day-phat-hien-8-benh-ly-nguy-hiem#xut-huyt-d-dy)
  * [Phát hiện dị vật lạ trong dạ dày](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-da-day-phat-hien-8-benh-ly-nguy-hiem#pht-hin-d-vt-l-trong-d-dy)
  * [Kết quả nội soi dạ dày](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-da-day-phat-hien-8-benh-ly-nguy-hiem#kt-qu-ni-soi-d-dy)
  * [Tầm quan trọng của việc nội soi tầm soát ung thư dạ dày](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-da-day-phat-hien-8-benh-ly-nguy-hiem#tm-quan-trng-ca-vic-ni-soi-tm-sot-ung-th-d-dy)



## ️ Khi nào cần nội soi đại tràng?

**Nội soi đại tràng là gì?**
Nội soi đại tràng là phương pháp chẩn đoán hình ảnh, bác sĩ sẽ đưa một ống nội soi mềm, đầu có gắn camera và nguồn sáng vào đường hậu môn, đi qua toàn bộ đại tràng đến tận manh tràng (Vùng nối tiếp giữa ruột non và ruột già) để kiểm tra tình trạng cụ thể bên trong lòng đại tràng của bệnh nhân.
**Khi nào cần nội soi đại tràng?**
**Bệnh nhân có những triệu chứng hoặc tiền sử bệnh lý sau đây**
Không phải trường hợp nào đi khám tiêu hóa cũng được chỉ định kỹ thuật nội soi đại tràng. Phương pháp này thường được chỉ định nếu bệnh nhân có các dấu hiệu sau:
  * Cảm giác đau âm ỉ hoặc đau quặn từng cơn vùng bụng (nhất là vị trí vùng bụng dưới rốn).
  * Tiêu chảy hoặc táo bón kéo dài. Khi đi cầu phân có lẫn máu hoặc chất nhầy, phân có màu đen.
  * Người có tiền sử bệnh lý liên quan đến đại tràng hoặc có người thân trong gia đình mắc ung thư đại tràng.
  * Người khỏe mạnh, chưa có dấu hiệu bệnh cụ thể, từ 30 tuổi trở lên nên nội soi đại tràng để tầm soát ung thư sớm.


**Nội soi đại tràng để điều trị dựa vào chỉ định của bác sĩ**
Bên cạnh việc tầm soát các bệnh như ung thư đại tràng, trĩ, nhiễm ký sinh trùng, dị vật….Nội soi đại tràng còn là phương pháp được chỉ định để cắt Polyp đại tràng, cầm máu một số tổn thương như chảy máu từ cuống Polyp sau cắt Polyp, nong các tổn thương hẹp đại tràng, đặt ống thông hay còn gọi stent (do ác tính, tia xạ, viêm mạn,….)
**Bao lâu thì tiến hành nội soi đại tràng một lần?**
Theo các chuyên gia và bác sĩ, việc bao lâu nên nội soi đại tràng một lần còn tùy vào từng trường hợp. Ví dụ, người từ 30 tuổi trở lên nên nội soi đại tràng 3-5 năm/lần để tầm soát ung thư sớm. Trong khi người từng mắc Polyp đại tràng, tiền sử gia đình có người bị ung thư đại tràng, trực tràng nên tiến hành nội soi đại tràng 1 năm/lần …
Vì vậy, bạn nên đến thăm khám tại các bệnh viện uy tín, gặp trực tiếp bác sĩ chuyên khoa để có được những tư vấn cụ thể, chính xác cho bản thân trước khi thực hiện nội soi đạt hiệu quả cao nhất.
_Nên nội soi đại tràng định kỳ, đừng đợi đau mới đi khám_
**Những trường hợp không nên nội soi đại tràng?**
Một số trường hợp sau đây không được nội soi đại tràng:
  * Người có bệnh lý về tim, phổi hoặc chức năng tim phổi không bình thường.
  * Người mới qua phẫu thuật đường ruột hoặc người mới sử dụng phóng xạ vùng ổ bụng và vùng khoang chậu trong thời gian gần đây. Sau khi phẫu thuật hoặc xạ trị, ít nhiều đường ruột vẫn còn đang yếu, vị trí phẫu thuật vẫn còn chưa lành. Nếu tiến hành nội soi đại tràng rất có thể sẽ gây tổn thương đến ruột và vùng ổ bụng.
  * Người đang có tình trạng viêm phúc mạc, nghỉ ngờ thủng ruột, tắc ruột…
  * Phụ nữ mang thai, đặc biệt là trong những tháng đầu của thai kỳ
  * Người bị nhiễm độc tiêu hóa (kiết, lỵ), viêm loét kết tràng nhiễm độc. Người bệnh nên chữa trị dứt điểm tình trạng nhiễm độc trước khi muốn nội soi đại tràng.


**Các phương pháp nội soi đại tràng hiện nay?**
Hiện nay, có 2 phương pháp nội soi đại tràng được sử dụng phổ biến là nội soi thường và nội soi gây mê.
**Nội soi thường (nội soi không gây mê)**
Đây là kỹ thuật nội soi truyền thống được triển khai thực hiện tại hầu hết các bệnh viện. Với phương pháp này, bệnh nhân tỉnh táo hoàn toàn trong suốt quá trình thực hiện nội soi.
_**Ưu điểm**_
  * Chi phí thấp hơn nội soi gây mê
  * An toàn vì không có các tình huống dị ứng thuốc, sốc phản vệ
  * Bệnh nhân hoàn toàn tỉnh táo sau khi nội soi


**_Nhược điểm_**
  * Người bệnh sẽ có cảm giác khó chịu khi nội soi, khi đưa ống nội soi vào trong hậu môn.
  * Khi nội soi, khi bơm vào đại tràng qua ống soi khiến cho người bệnh có cảm giác khó chịu, muốn đi cầu (mặc dù bên trong không có phân).
  * Nhiều trường hợp đặc biệt là trẻ nhỏ, vì khó chịu đã ngọ nguậy, giật mình gây khó khăn cho bác sĩ, cũng có thể cọ xát làm tổn thương lòng đại tràng.


**Nội soi không đau (nội soi gây mê)**
Phương này này bệnh nhân được tiêm thuốc gây mê vào trong tĩnh mạch nên sẽ không cảm thấy bất kì triệu chứng khó chịu nào. Trước khi thực hiện, bác sĩ sẽ tiên lượng thời gian nội soi để tính toán liều lượng thuốc gây mê sử dụng cho phù hợp để bệnh nhân có thể tỉnh táo ngay sau khi làm nội soi xong.
**_Ưu điểm_**
  * Người bệnh ngủ trong lúc nội soi nên không có cảm giác khó chịu, muốn đi đại tiện.
  * Bệnh nhân gây mê không bị kích thích giúp kỹ thuật nội soi dễ dàng. Nếu cần áp dụng các thủ thuật khác như: cắt Polyp đại tràng qua nội soi, chẩn đoán ung thư bằng nhuộm màu, tiêm cầm máu trong xuất huyết tiêu hóa…sẽ mang lại kết quả chính xác.


**_Nhược điểm_**
  * Chi phí nội soi gây mê cao hơn so với nội soi không gây mê.
  * Mặc dù rất hiếm nhưng có thể gặp phản ứng dị ứng thuốc gây mê, sốc phản vệ hoặc xảy ra biến chứng tai biến khác của thuốc gây mê.


**Quy trình nội soi đại tràng diễn ra như thế nào?**
_Người bệnh cần được làm sạch ruột trước khi nội soi đại tràng_
Sau đây là 3 bước chuẩn bị trước khi nội soi đại tràng
  * _**Đặt lịch và lên kế hoạch**_


Trước khi nội soi đại tràng, bác sĩ sẽ chỉ định bạn làm một số xét nghiệm cũng như nhận thuốc để làm sạch ruột. Vì vậy, bạn nên gọi đến bệnh viện hoặc phòng khám đặt lịch trước để có được những hướng dẫn cụ thể về chế độ dinh dưỡng trước khi nội soi, cách dùng thuốc rửa ruột như thế nào …
Nếu bạn làm gói nội soi đại tràng gây mê, sau khi kết thúc nội soi cơ thể sẽ vẫn còn tác dụng của thuốc gây mê. Do đó, bạn cần lên kế hoạch để bố trí người đi cùng bạn đến bệnh viện hoặc phòng khám, không nên tự lái xe đến một mình gây nguy hiểm cho bản thân.
  * _**Điều chỉnh chế độ ăn uống trước khi nội soi**_


Để giúp đại tràng sạch hơn, 2 – 3 ngày trước khi nội soi bạn nên ăn nhẹ nhàng, lựa chọn thực phẩm ít chất xơ, dễ tiêu hóa như bánh mỳ, cơm, trái cây không hạt, thịt nạc, trứng. Bên cạnh đó, cũng nên tránh các thức ăn như: bỏng ngô, ngũ cốc, trái cây có vỏ hoặc hạt, món ăn giàu chất béo…
Trong trường hợp đang dùng các loại thuốc tây, nên hỏi ý kiến của bác sĩ có cần dùng hay không.
Vào ngày nội soi, bạn nên nhịn ăn hoàn toàn, chỉ uống thuốc, nước theo hướng dẫn của nhân viên y tế.
  * _**Làm sạch ruột**_


Làm sạch ruột sẽ được thực hiện tại nhà bệnh nhân vào đêm trước khi nội soi hoặc tiến hành tại bệnh viện. Mỗi cơ sở y tế sẽ thực hiện phương pháp khác nhau, người bệnh có thể uống thuốc xổ hoặc thụt nước kết hợp thuốc thụt qua đường hậu môn.
Bác sĩ nội soi sẽ giải thích rõ cho người bệnh những khó chịu không mong muốn trong khi làm sạch ruột như buồn nôn, đầy bụng hoặc đau bụng .. trước khi nội soi.
**Tiến hành nội soi đại tràng**
Người bệnh nằm nghiêng trái. Bác sĩ sẽ đưa ống nội soi đại tràng qua hậu môn, vào trực tràng rồi từ từ đến manh tràng (vị trí ruột non tiếp giáp với đại tràng).
Những tín hiệu thu được từ ống nội soi sẽ truyền qua bộ xử lý để chuyển thành hình ảnh rõ nét phản ánh trung thực tình trạng bên trong của đại tràng. Nhờ vậy, các bác sĩ sẽ đánh giá chính xác vấn đề bệnh nhân đang gặp phải.
Quá trình nội soi diễn ra khoảng 15 – 30 phút tùy thuộc đại tràng khó hay dễ, có thực hiện thủ thuật (sinh thiết, cắt Polyp …) hay không? Trong quá trình nội soi, bệnh nhân thường có cảm giác đau tức bụng, nhất là ở những đoạn đại tràng gập góc. Nhưng cảm giác chướng hơi, đau bụng nhẹ sẽ giảm dần sau vài giờ.
**Sau khi nội soi đại tràng**
  * Người bệnh có thể có cảm giác trướng bụng hay đau quặn bụng tạm thời do hơi được bơm vào lòng đại tràng trong quá trình nội soi. Cảm giác này sẽ nhanh chóng mất đi khi người bệnh trung tiện và đi vệ sinh.
  * Người bệnh sẽ được bác sĩ giải thích về kết quả nội soi. Nếu có sinh thiết thì người bệnh sẽ được nhận kết quả sau 5 – 7 ngày.
  * Người bệnh có thể ăn uống bình thường sau khi nội soi. Nếu có cắt Polyp thì bác sĩ nội soi sẽ hướng dẫn chế độ ăn cụ thể cho người bệnh.


**Nội soi đại tràng có đau không?**
Nội soi đại tràng có đau hay không là câu hỏi được rất nhiều bệnh nhân quan tâm. Trong đa số trường hợp không gây đau, bệnh nhân chỉ cảm thấy hơi căng tức bụng trong lúc nội soi. Tuy nhiên ngưỡng chịu đau ở mỗi người là khác nhau.
Do đó ở những người có ngưỡng chịu đau kém, bác sĩ sẽ tiến hành gây mê cho bệnh nhân. Trong lúc nội soi, bệnh nhân sẽ ngủ và sẽ không biết đến cảm giác đau tức bụng.
Đây là một kỹ thuật dễ thực hiện, độ an toàn cao, mang đến khả năng chẩn đoán chính xác và giúp người bệnh cảm thấy thoải mái trong quá trình nội soi.
Tại phòng Nội soi tiêu hóa, Bệnh viện Đa khoa Hồng Ngọc, với đội ngũ y bác sĩ có chuyên môn cao, thái độ tư vấn và chăm sóc bệnh nhân tận tình, chu đáo cùng những trang thiết bị hiện đại, được khử khuẩn tối đa, mang đến cho bệnh nhân sự tiện nghi, cảm giác thoải mái, đem lại cho bệnh nhân kết quả chính xác nhất.
Bác sĩ của Bệnh viện Đa khoa Hồng Ngọc sẽ cùng với bệnh nhân trao đổi về tình trạng bệnh ngay trong lúc nội soi và bệnh nhân sẽ về ngay sau khi nội soi. Đối với những bệnh nhân làm nội soi đại tràng gây mê, bác sĩ sẽ cho thuốc để bệnh nhân ngủ trong lúc nội soi và được theo dõi tình trạng sức khỏe bằng máy Monitoring.
**Một số biến chứng có thể xảy ra sau nội soi**
Mặc dù tai biến của nội soi đại tràng rất thấp nhưng vẫn có thể xảy ra những trường hợp sau đây:
**Cảm giác đầy bụng**
Bệnh nhân không nên quá lo lắng về cảm giác đầy bụng này vì đây là một trong những triệu chứng mà đa phần những bệnh nhân vừa trải qua quá trình nội soi đại tràng đều gặp phải. Cảm giác này sẽ biến mất sau vài ba lần xì hơi.
**Đau tức nhẹ vùng bụng**
Tình trạng đau tức và khó chịu vùng bụng thường kích hoạt ở vị trí bụng dưới do việc đưa thiệt bị nội soi vào đại tràng và di chuyển nó ở trong cơ quan này khiến niêm mạc đại tràng tự kích thích, gây cảm giác đau nhẹ và khó chịu trong một thời gian ngắn. Cảm giác này cũng sẽ biến mất trong khoảng sau 2 tiếng.
**Chảy máu sau nội soi**
Nếu trong quá trình nội soi, bác sĩ phát hiện ra dấu hiệu bất thường ở đại tràng và tiến hành sinh thiết để kiểm tra, bệnh nhân có thể sẽ bị đại tiện ra máu sau khi kết thúc quá trình nội soi đại tràng. Bệnh nhân không nên quá hoang mang, lo lắng vì triệu chứng này chỉ kéo dài khoảng 1 vài ngày đầu sau nội soi.
Nếu tình trạng đại tiện ra máu diễn ra nghiêm trọng (ra nhiều máu, kéo dài trong nhiều ngày), bệnh nhân nên báo với bác sĩ ngay để có hướng xử lý kịp thời.
_Sau nội soi đại tràng nên ăn những thực phẩm mềm, dễ tiêu hóa_
**Những lưu ý sau khi tiến hành nội soi đại tràng**
Nội soi đại tràng là thủ thuật khá an toàn, ít gây ra những vấn đề nghiêm trọng sau khi thực hiện. Tuy nhiên, người bệnh cũng cần chú ý chăm sóc tốt cho sức khỏe để tránh những vấn đề không mong muốn phát sinh.
_**Thực phẩm nên ăn**_
Bổ sung dinh dưỡng đóng vai trò rất quan trọng trong việc phục hổi sức khỏe cho bệnh nhân sau khi trải qua quá trình nội soi đại tràng. Ăn uống lành mạnh giúp cơ thể hạn chế những triệu chứng khó chịu phát sinh sau nội soi và giúp đại tràng nhanh chóng ổn định trở lại
Sau đây là một số loại thực phẩm bệnh nhân cần bổ sung:
  * Cháo loãng: đây là món ăn dễ tiêu, tốt cho người vừa trải qua nội soi đại tràng. Tuy nhiên nên ăn cháo khi nguội, không nên ăn nóng do có thể gây tổn thương đại tràng và trong quá trình chế biến nên nêm nếm ít gia vị để tốt hơn cho hoạt động của đại tràng và các cơ quan tiêu hóa.
  * Trứng gà: vitamin A,E, D có trong trứng gà giúp người bệnh nhanh hồi phục. Bệnh nhân nên ăn sau vài ngày và không nên ăn quá nhiều.
  * Trái cây, rau củ:
  * Bổ sung hàm lượng vitamin trong trái cây tươi mang lại nhiều lợi ích cho sức khỏe. Bởi trong trái cây còn chứ chất chống oxy hóa và axit folic – dưỡng chất tăng hệ miễn dịch cho cơ thể, bảo vệ tim mạch và hồi phục sức khỏe. Tuy nhiên, không nên chọn những loại quả có tính chua.
  * Canh, soup: ngoài cháo loãng, canh hoặc soup cũng có thể là lựa chọn thích hợp cho bệnh nhân sau nội soi. Đây là những món ăn rất dễ tiêu, không gây ra cảm giác khó chịu cho hệ tiêu hóa.


_**Thực phẩm không nên ăn**_
Sau khi nội soi đại tràng nếu nạp vào cơ thể những thực phẩm không tốt sẽ làm gia tăng các triệu chứng thường xảy ra sau nội soi (chướng bụng, đau bụng, đầy hơi, …), khiến các cơ quan tiêu hóa phải chịu nhiều áp lực, làm chậm quá trình phục hồi sức khỏe, cơ thể thường xuyên mệt mỏi.
Sau đây là những thực phẩm bệnh nhân nên tránh:
  * Các loại thực phẩm tanh sống, lạnh, bảo quản lâu ngày
  * Thực phẩm có chứa quá nhiều dầu, mỡ
  * Chất xơ không hòa tan và thức ăn cứng
  * Thực phẩm có chứa hàm lượng đường cao.
  * Rượu, bia, trà đặc, cà phê, nước ngọt có gas và các chất kích thích khác
  * Đồ ăn cay nóng, thực phẩm lạnh: tuyệt đối không được ăn những đồ lạnh như kem, nước đá, đồ ăn trực tiếp trong tủ lạnh


_**Chế độ sinh hoạt, nghỉ ngơi**_
Sau khi kết thúc quá trình nội soi, bệnh nhân nên nằm nghỉ ngơi khoảng vài ba tiếng để làm giảm tình trạng mệt mỏi, khó chịu. Điều này sẽ giúp các cơ quan tiêu hóa ổn định trở lại.
Với những người có thể trạng tốt thì các triệu chứng mệt mỏi, đau bụng dưới thường sẽ cải thiện hoàn toàn chỉ sau vài giờ đồng hồ.
**Những tư vấn để đại tràng khỏe mạnh**
Bên cạnh những thông tin tham khảo về quá trình nội soi đại tràng, những tư vấn sau đây sẽ rất hữu ích đối với sức khỏe của bạn, đặc biệt là đại tràng:
  * Có chế độ dinh dưỡng hợp lý, nên ăn những thực phẩm có chứa nhiều axit folic, chất xơ như các loại rau xanh, trái cây tươi như: đu đủ, chuối, táo …các loại củ như khoai lang, cà rốt .. Uống nhiều nước.
  * Hạn chế các thực phẩm chế biến sẵn, các thực phẩm đông lạnh
  * Hạn chế rượu bia, bỏ thuốc lá càng sớm càng tốt.
  * Duy trì thói quen vận động, thể dục.
  * Duy trì cân nặng ổn định.
  * Tập thói quen đi cầu một lần một ngày vào một thời điểm nhất định


**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh

## ️ Tổng hợp điều cần biết về nội soi dạ dày

Nội soi dạ dày là phương pháp an toàn và được sử dụng rộng rãi trong chẩn đoán, điều trị các bệnh lý dạ dày.
**Thế nào là nội soi dạ dày?**
Nội soi dạ dày là kỹ thuật chẩn đoán hình ảnh, trong đó bác sĩ sẽ kiểm tra trực tiếp phần trên ống tiêu hóa (bao gồm thực quản, dạ dày, tá tràng và hành tá tràng) của người bệnh thông qua một camera nhỏ được gắn ở đầu ống nội soi. Camera thu hình trực tiếp và gửi các hình ảnh này lên màn hình, giúp bác sĩ dễ dàng quan sát và phát hiện các bất thường của hệ thống tiêu hóa khi đang nội soi.
**Khi nào cần nội soi dạ dày?**
Nội soi thực quản – dạ dày – tá tràng (hay gọi chung là nội soi dạ dày) được sử dụng để:
– Xác định nguyên nhân gây ra các triệu chứng về tiêu hóa như buồn nôn/ nôn, đầy hơi, khó nuốt, đau bụng dai dẳng… Trong trường hợp cần thiết, bác sĩ có thể tiến hành làm xét nghiệm Clo-test để chẩn đoán nhiễm H. Pylori (HP) trong quá trình nội soi
– Chẩn đoán loét dạ dày hoặc trào ngược dạ dày thực quản (GORD)
– Điều trị các tình trạng: xuất huyết đường tiêu hóa, tắc nghẽn thực quản, lấy dị vật, cắt polyp…. thông qua những dụng cụ chuyên biệt luồn qua ống nội soi
– Sinh thiết tìm ung thư: Bằng cách lấy một mảnh mô nhỏ khi nội soi, bác sỹ sẽ quan sát dưới kính hiển vi để hiển thị các tế bào ung thư (nếu có), mà không gây đau đớn hay khó chịu cho người bệnh.
_Bác sĩ chỉ định nội soi dạ dày_
**Các phương pháp nội soi dạ dày**
Hiện nay y học sử dụng 4 phương pháp nội soi dạ dày chính. Tùy thuộc vào từng ưu, nhược điểm của mỗi phương pháp cũng như trường hợp bệnh cụ thể mà bác sĩ sẽ tư vấn và chỉ định cho người bệnh.
**_Nội soi dạ dày qua đường miệng_**
Với ưu điểm dễ thực hiện, chi phí thấp, phù hợp với nhiều đối tượng, nôi soi dạ dày qua đường miệng đang là phương pháp được sử dụng phổ biến nhất hiện nay. Trong trường hợp bệnh nhân hợp tác tốt, nội soi dạ dày qua đường miệng cho độ chính xác cao.
Tuy nhiên, do dùng ống mềm đường kính lớn nên nội soi dạ dày qua đường miệng dễ gây khó chịu, buồn nôn, thậm chí xây xát họng khi soi làm người bệnh cảm thấy sợ hãi.
**_Nội soi dạ dày qua đường mũi_**
Ưu điểm: Có độ chính xác cao, dễ thực hiện. Ngoài ra, do sử dụng ống soi có đường kính nhỏ, chỉ 5,9 mm và đi qua đường mũi, nên ít gây buồn nôn, sợ hãi cho người bệnh
Nhược điểm: Chi phí cao hơn soi đường miệng. Không dùng trong trường hợp bệnh nhân bị bệnh vùng mũi, hẹp khe mũi. Khi phát hiện bệnh lý cần can thiệp như lấy dị vật, cắt Polyp, cầm máu, thắt tĩnh mạch thực quản… thì không thực hiện được và phải chuyển sang soi đường miệng…
**_Nội soi dạ dày gây mê (hay thường gọi là nội soi dạ dày không đau)_**
Về bản chất, đây chính là phương pháp nội soi dạ dày qua đường miệng nhưng bệnh nhân đã được gây mê. Điểm cộng lớn nhất khi sử dụng phương pháp này là bệnh nhân sẽ không cảm thấy buồn nôn, sợ hãi, tránh được có hành động nguy hiểm khi bị soi (giãy giụa hay giật ống soi). Nhờ đó, bác sĩ thực hiện các thủ thuật can thiệp khi cần thiết (cắt polyp, lấy dị vật…) nhanh chóng và an toàn hơn.
Nhược điểm: Chi phí cao hơn nội soi thường, cần sự hỗ trợ của bác sĩ gây mê và phải thực hiện thêm một số xét nghiệm trước khi nội soi. Người bệnh cần được theo dõi sát sao, vì có thể xảy ra phản ứng phụ với thuốc mê
**_Nội soi bằng viên nang_**
Ưu điểm: Bác sĩ có thể kiểm tra được toàn bộ các cơ quan trong ống tiêu hóa một cách chi tiết mà không gây khó chịu cho người bệnh. Trong quá trình nội soi, người bệnh vẫn đi lại, sinh hoạt bình thường. Sau khi nội soi, viên nang tự đào thải ra ngoài theo đường tiêu hóa.
Nhược điểm: Thời gian thực hiện kéo dài khoảng 12 tiếng và giá thành khá cao, do đó dù là phương pháp hiện đại song nội soi viên nang ít được bệnh nhân lựa chọn.
_Nội soi dạ dày gây mê_
**Quy trình nội soi dạ dày diễn ra như thế nào?**
Nội soi dạ dày khá đơn giản và thường được sử dụng như một thủ thuật ngoại trú nên bệnh nhân không phải ở lại viện qua đêm. Sau khi thăm khám, bác sĩ sẽ chỉ định phương pháp thích hợp và tiến hành nội soi cho bệnh nhân. Dù soi bằng phương pháp nào, bạn cũng cần tuân thủ 1 vài điểm cơ bản như nhịn ăn tối thiểu từ 6-8 tiếng trước nội soi hoặc không dùng các thuốc đặc trị/ rượu bia/ nước có màu…
Mỗi ca nội soi thường kéo dài từ 15-20 phút tùy tình trạng bệnh lý của bệnh nhân.
**Với nội soi dạ dày thông thường** : Sau khi nằm nghiêng trái và được xịt thuốc gây tê cục bộ vào cổ họng, bạn sẽ được bác sĩ đặt ống nội soi vào miệng và yêu cầu nuốt phần đầu tiên của ống. Bạn có thể thấy khó chịu, thậm chí muốn nôn ra, song cảm giác này sớm qua khi ống soi xuống thực quản và vào dạ dày. Hãy cố gắng hít thở chậm và hợp tác theo hướng dẫn của bác sĩ để hạn chế các xây xát bộ phận tiêu hóa khi ống soi đang di chuyển.
Bác sĩ sẽ quan sát hình ảnh được ghi lại trên camera của ống soi để tìm các bất thường đường tiêu hóa. Không khí có thể được bơm nhẹ vào thực quản của bệnh nhân, giúp bác sĩ quan sát tốt hơn, song điều này có thể khiến bạn bị căng tức hoặc đầy hơi.
Tùy thuộc vào bệnh lý được phát hiện khi nội soi, các dụng cụ chuyên biệt sẽ được sử dụng để lấy sinh thiết hoặc thực hiện các thủ thuật điều trị như cắt polyp, cầm máu, nong thực quản…
**Với nội soi dạ dày gây mê** , các bước cũng được tiến hành tương tự, song bạn sẽ cảm thấy dễ chịu và đơn giản hơn vì được gây mê trong suốt quá trình nội soi.
**Nội soi dạ dày có đau không?**
Nội soi dạ dày là một thủ thuật tương đối an toàn. Ngoài một vài khó chịu trong quá trình nội soi, hầu hết người bệnh đều không cảm thấy đau.
Nếu quá e sợ khi phải nội soi qua đường miệng/ đường mũi, bạn nên lựa chọn phương pháp nội soi dạ dày không đau, để hạn chế các biến chứng có thể xảy ra như xây xát niêm mạc, chảy máu… do giãy giụa/ giật ống soi trong khi soi.
**Các điều cần lưu ý trước và sau khi nội soi dạ dày**
**_Lưu ý trước khi nội soi dạ dày_**
  * 24h trước khi nội soi, bạn nên uống thật nhiều nước hoặc ăn đồ ăn lỏng, nhằm hạn chế tình trạng mất nước của dạ dày trong quá trình nội soi.
  * Tránh các loại nước uống và thực phẩm có màu đậm, đặc biệt là màu đỏ, cam vì dễ nhầm lẫn với tình trạng chảy máu đường tiêu hóa, làm ảnh hưởng tới kết quả nội soi.
  * Nhịn ăn tối thiểu từ 6 – 8 tiếng trước khi nội soi
  * Không dùng thuốc băng niêm mạc dạ dày như: Gastropulgit, Phosphalugel… trước khi nội soi.
  * Thông báo tình trạng sức khỏe, bệnh lý hay các loại thuốc đang sử dụng với bác sĩ thực hiện. Với bệnh nhân có bệnh mãn tính như tiểu đường, tim mạch, huyết áp… nên hỏi kỹ tư vấn của bác sĩ gây mê trước khi thực hiện thủ thuật.


**_Lưu ý sau khi nội soi dạ dày_**
  * 2 giờ sau nội soi, chỉ nên ăn hoặc uống các đồ có dạng lỏng, nguội, dễ tiêu hóa như cháo, súp, sữa, hoa quả mềm để hạn chế tổn thương dạ dày.
  * Nên nghỉ ngơi tại bệnh viện một thời gian ngắn trước khi ra về và có người thân đi cùng khi nội soi, không nên tự lái xe về.
  * Không nên có những quyết định quan trọng liên quan đến các vấn đề cá nhân hay tài chính trong vòng 24 giờ sau khi nội soi.
  * Uống thuốc theo đơn, tuân thủ chế độ ăn uống và tái khám đúng lịch hẹn của bác sĩ


**Nội soi dạ dày có những rủi ro/ biến chứng gì?**
Nội soi dạ dày là phương pháp rất an toàn, tuy nhiên vẫn có những rủi ro có thể xảy ra, dù tỉ lệ rất nhỏ. Các biến chứng bao gồm:
– Rách niêm mạc thực quản, dạ dày hoặc tá tràng: Nguy cơ của biến chứng này rất thấp, tuy nhiên vẫn có khả năng xảy ra khi có các can thiệp trong quá trình nội soi như điều trị giãn thực quản.
– Phản ứng với thuốc an thần: Người bệnh có thể gặp 1 vài tác dụng phụ khi sử dụng thuốc an thần. Đó là lí do người bệnh được theo dõi chặt chẽ và nên ở lại viện 1 thời gian ngắn sau khi kết thúc nội soi. Bạn cũng nên báo cho bác sĩ gây mê biết tất cả các thuốc đang sử dụng cũng như tiền sử dị ứng của mình
– Chảy máu trong/ Xuất huyết: thường xảy ra khi bác sĩ thực hiện thủ thuật lấy mẫu sinh thiết hay kết hợp điều trị bệnh lý, tuy nhiên rủi ro này rất thấp và có thể kiểm soát được
– Nhiễm trùng: Mặc dù nguy cơ nhiễm trùng thấp song hầu hết bệnh nhân đều được bác sĩ chỉ định dùng kháng sinh phòng ngừa trước khi làm nội soi.
Để giảm nguy cơ biến chứng có thể xảy ra, bạn nên thực hiện chính xác và đầy đủ các hướng dẫn của bác sĩ khi chuẩn bị nội soi, cũng như lựa chọn phương pháp nội soi thích hợp.
**Thời gian nhận được kết quả nội soi dạ dày**
Sau khi kết thúc quá trình nội soi, bác sĩ sẽ trả kết quả cũng như tư vấn, kê đơn (nếu cần thiết) cho người bệnh.
Các kết quả Clo-test để chẩn đoán nhiễm HP sẽ mất thêm 1 – 2 giờ, trong khi kết quả sinh thiết sẽ có trong vòng 1 – 2 tuần. Bệnh nhân có thể hỏi bác sĩ về thời gian nhận kết quả nội soi và sinh thiết của mình để tránh chờ đợi lâu.
**Chi phí nội soi dạ dày**
Tùy vào phương pháp nội soi (đường mũi hay đường miệng, nội soi dạ dày có mê hay không mê) mà chi phí nội soi dạ dày ở mỗi cơ sở y tế sẽ khác nhau.
**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/) **- Đa khoa Hạng I Thành phố Hồ Chí Minh

## ️ Nội soi trực tràng ống mềm

**ĐỊNH NGHĨA**
Nội soi trực tràng ống mềm là thủ thuật đưa ống nội soi mềm vào hậu môn trực tràng để chẩn đoán và điều trị các bệnh lý vùng hậu môn trực tràng.
**CHỈ ĐỊNH**
Soi thường: Cho tất cả các bệnh lý vùng hậu môn - trực tràng.
Ỉa máu.
Rối loạn đại tiện: đau hậu môn, ỉa không tự chủ, khó đại tiện.
Rối loạn phân.
Viêm đại trực tràng chảy máu.
Crohn.
Ung thư.
Polyp.
Rò hậu môn.
Nứt hậu môn.
Ngứa hậu môn.
**CHỐNG CHỈ ĐỊNH**
Không có chống chỉ định tuyệt đối.
Thận trọng khi người bệnh quá già yếu, có thai hoặc các trường hợp viêm phổi cấp nặng, có cản trở không đưa ống soi vào được.
**CHUẨN BỊ**
**Phương tiện**
Phòng soi kín và bàn soi trực tràng.
Dụng cụ soi: Ống soi mềm.
**Nguồn sáng**
Máy hút, kìm gắp.
Kìm sinh thiết, bông băng.
**Người bệnh**
Người bệnh được giải thích để hợp tác với thầy thuốc.
Thụt tháo hai lần (tối hôm trước và sáng hôm sau trước khi soi 3 giờ) hoặc bơm Microlax hai lần (tối hôm trước và sáng hôm sau).
**CÁC BƯỚC TIẾN HÀNH**
**Tư thế người bệnh**
_Nằm ngửa hoặc nghiêng trái:_
Ở tư thế nằm ngửa thì dễ áp dụng, dễ nhìn thấy ánh sáng qua thành bụng và người bệnh dễ thở hơn.
Còn ở tư thế nghiêng trái: Dễ đưa đèn qua chỗ nối trực tràng- đại tràng sigma.
_Tiến hành_
Bước đầu tiên: Thăm hậu môn trực tràng rồi đưa đèn vào sau khi đã bôi trơn máy bằng mỡ lidocain hoặc silicon.
Đưa đèn soi vào trực tràng, vừa soi vừa tìm đường đi.
Soi đoạn trực tràng ít gặp khó khăn, có thể quan sát toàn bộ trực tràng khi phối hợp quay ngược máy.
Sinh thiết: Khi có tổn thương bấm bằng kìm sinh thiết, cắt polyp khi thấy polyp có cuống.
Cầm máu bằng que bông có thấm adrenalin 1 % hoặc kim cầm máu.
**THEO DÕI**
Trong khi làm thủ thuật có thể gặp người bệnh đau bụng do co thắt trực tràng hoặc do thủng.
**TAI BIẾN VÀ XỬ TRÍ**
Nếu co thắt nhiều phải bơm hơi tìm đường mới vào.
Nếu có thủng: gửi chuyên khoa Ngoại.
**TÀI LIỆU THAM KHẢO**
Nội soi tiêu hóa, Khoa tiêu hóa bệnh viện Bạch Mai, Nhà xuất bản Y học.
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh

## ️ Nội soi tiền mê và những điều cần biết

**Nội soi tiền mê là gì?**
Nội soi tiền mê là một phương pháp khám và chẩn đoán các bệnh lý liên quan đến thực quản – dạ dày – tá tràng bằng cách đưa ống soi dạ dày qua đường miệng vào thực quản rồi xuống dạ dày và tá tràng.
Phương pháp này giúp tìm ra những bất thường và tổn thương nếu có của thực quản, dạ dày và tá tràng.
Nội soi tiền mê còn được gọi là nội soi không đau. Việc nội soi chỉ được thực hiện khi có chỉ định của bác sĩ và bệnh nhân đã trong trạng thái tiền mê.
**Ưu điểm vượt trội của nội soi tiền mê**
Phương pháp nội soi tiền mê là phương pháp nội soi kỹ thuật cao, tiên tiến nhất hiện nay. Phương pháp này khắc phục được những nhược điểm mà nội soi thông thường không thực hiện được.
  * Không đau, khó chịu, người bệnh không còn cảm giác lo lắng.
  * Trong quá trình nội soi, người bệnh sẽ nằm yên tĩnh, không bị kích thích giúp quá trình thực hiện được thuận lợi, áp dụng được nhiều kỹ thuật cần độ chính xác cao như cắt polyp, thắt tĩnh mạch thực quản trong bệnh lý xuất huyết tiêu hóa, sinh thiết giải phẫu bệnh…
  * Nội soi tiền mê là phương pháp an toàn, ít rủi ro biến chứng xảy ra.
  * Do người bệnh nằm yên trong quá trình nội soi nên sẽ cho hình ảnh rõ nét và chính xác hơn.
  * Nội soi tiền mê sẽ cho kết quả nhanh chóng chỉ 15 – 20’, giúp tiết kiệm thời gian thăm khám cho bệnh nhân.
  * Bác sĩ có thể thực hiện thăm dò hầu hết các bộ phận của đường tiêu hóa.
  * Thời gian thủ thuật này thường ngắn, lượng thuốc an thần ít nên không hại đến sức khỏe, bệnh nhân sẽ tỉnh ngay sau khi kết thúc cuộc nội soi.


**Nội soi tiền mê và nội soi gây mê khác nhau như thế nào?**
Rất nhiều người sẽ nghĩ nội soi tiền mê và nội soi gây mê là hai phương pháp giống nhau, nhưng thực ra chúng hoàn toàn khác nhau.
Trong nội soi gây mê, bác sĩ sẽ cho bệnh nhân ngửi thuốc mê qua đường mũi hoặc tiêm thuốc qua tĩnh mạch giúp bệnh nhân mất ý thưc tạm thời và mất cảm giác toàn thân. Trong quá trình nội soi, người bệnh sẽ hoàn toàn không biết gì và không cảm thấy đau.
Còn với phương pháp nội soi tiền mê, bác sĩ sẽ dùng loại thuốc an thần, người bệnh có thể uống hoặc tiêm. Việc này giúp bệnh nhân không còn cảm giác khó chịu, đau đớn khi nội soi.
**Những ai nên thực hiện nội soi tiền mê?**
Việc bác sĩ chỉ định cho bệnh nhân nội soi tiền mê còn phụ thuộc vào nhiều yếu tố như:
  * Tùy thuộc vào tình trạng bệnh lý của bệnh nhân trong quá khứ và hiện tại. Trường hợp bản thân bệnh nhân hay có người thân có tiền sự dị ứng với thuốc gây mê thì nên sử dụng phương pháp nội soi tiền mê.
  * Trạng thái, tâm lý và sức chịu đựng của bệnh nhân.
  * Bệnh nhân mắc một số bệnh như: suy hô hấp, suy thận nặng, suy tim…thì nên dùng phương pháp nội soi tiền mê thay cho gây mê.
  * Những người già cao tuổi thì nên sử dụng phương pháp nội soi tiền mê.


**Nội soi tiền mê – Phương pháp phát hiện bệnh lý tiêu hóa sớm**
**_Nội soi dạ dày_**
Nội soi dạ dày là phương pháp hữu hiệu để kiểm tra và xác định các bệnh lý liên quan ở đường tiêu hóa. Nội soi dạ dày thường được thực hiện qua đường miệng để chẩn đoán và điều trị.
Nội soi dạ dày giúp bác sĩ xác định được nguyên nhân của các triệu chứng liên quan đến đường tiêu hóa như buồn nôn, nôn mửa, đau bụng, chảy máu dạ dày…
Thông qua nội soi, bác sĩ sẽ thấy được hình ảnh và lấy mẫu sinh thiết để xét nghiệm và chẩn đoán như ung thư dạ dày…
Bác sĩ có thể luồn dụng cụ chuyên biệt qua ống nội soi để điều trị các bệnh lý dạ dày như xuất huyết dạ dày, lấy dị vật, cắt polyp…
**_Nội soi đại tràng_**
Nội soi đại tràng là kỹ thuật được sử dụng để phát hiện những tổn thương trong đại tràng và trực tràng. Phương pháp này giúp bác sĩ chẩn đoán chính xác được những bất thường trong đại tràng và tìm ra được các nguy cơ gây ung thư.
Nội soi trực tràng là phương pháp an toàn và hiệu quả để đánh giá các vấn liên quan đến đại trực tràng như đau âm ỉ bụng dưới, đi ngoài ra máu, mất máu, tiêu chảy mãn tính, những bất thường có thể phát hiện trước đó bằng xét nghiệm…
Đây cũng là một cách quan trong để kiểm tra ung thư đại tràng và điều trị polyp đại tràng.
**_Nội soi tá tràng_**
Nội soi tá tràng là phương pháp kỹ thuật cho phép bác sĩ có thể chẩn đoán và điều trị các bệnh lý ở đường tiêu hóa trên.
Bác sĩ sử dụng ống nội soi thực quản dạ dày tá tràng đưa qua đường miệng và họng của bệnh nhân, sau đó đi qua thực quản rồi xuống dạ dày, tá tràng (phần đầu của ruột non). Bác sĩ sẽ kiểm tra mặt trong của các cơ quan này và phát hiện những bất thường. Từ đó sẽ đưa ra phác đồ điều trị thích hợp.
**_Nội soi thực quản_**
Nội soi thực quản nhằm mục đích kiểm ra những bất thường bên trong lớp lót thực quản. Khi các bạn thấy những dấu hiệu sau đây thì nên đi nội soi ngay để phát hiện kịp thời và chữa trị bệnh càng sớm càng tốt:
  * Có một số biểu hiện bất thường như: nuốt vướng, nghẹn, khó thở, nóng rát ở thực quản, cảm giác có dị vật ở thực quản…
  * Nghi ngờ có tổn thương hoặc bệnh ý ở thực quản và dạ dày.


Phương pháp này sẽ giúp chúng ta phát hiện ra những tổn thương dù chỉ rất nhỏ của thực quản và có khả năng can thiệp ngay khi cần.
**Quy trình tiến hành nội soi tiền mê**
**_Trước khi tiền mê_**
Để chuẩn bị cho 1 cuộc nội soi tiền mê, bác sĩ chuyên khoa gây mê sẽ kiểm ra kỹ tình trạng bệnh nhân trước khi thực hiện nhằm mục đích kiểm tra tiền sử, các bệnh lý liên quan có thể ảnh hưởng đến nguy cơ khi tiến hành kỹ thuật. Bác sĩ sẽ giải thích rõ về quy trình tiến hành cho bệnh nhân và người nhà bệnh nhân .
  * Nếu bệnh nhân nội soi dạ dày thì cần nhịn ăn ít nhất 6 tiếng trước khi nội soi.
  * Nếu nội soi đại tràng thì bệnh nhân sẽ được làm sạch đại tràng theo quy trình.


Bệnh nhân đồng ý làm thủ thuật sẽ phải ký vào giấy chấp nhận làm thủ thuật. Sau đó bệnh nhân được theo dõi sát sao về mạch, huyết áp, nồng độ oxy trong máu trước, trong và sau khi nội soi. Bệnh nhân sẽ có người nhà đi kèm.
**_Trong khi tiền mê_**
Bác sĩ sẽ đặt đường truyền tĩnh mạch cho bệnh nhân, lựa chọn thuốc, định liều và tiến hành tiền mê.
Sau đó, các bác sĩ sẽ theo dõi quá trình tiền mê qua trạng thái ý thức của bệnh nhân, theo dõi các chỉ số về mạch, huyết áp, oxy trong máu và bắt đầu tiến hành nội soi.
**_Sau khi tiền mê_**
Kết thúc quá trình nội soi, bệnh nhân được chăm sóc theo dõi tại phòng hồi tỉnh đến khi tỉnh hẳn. bác sĩ sẽ đánh giá các chức năng ý thức, hô hấp, tim mạch, vận động, cảm giác đau hay khó chịu của người bệnh trước khi xuất viện.
**Lưu ý trước khi nội soi tiền mê**
Để phòng tránh các tai biến có thể xảy ra trong quá trình nội soi tiền mê, bác sĩ chuyên khoa gây mê sẽ khám đánh giá bệnh nhân trước khi làm và có thể làm thêm một số xét nghiệm cần thiết khác.
Người bệnh có tiền sử bệnh mạn tính như tăng huyết áp, đái tháo dường, bệnh phổi, tim mạch… cần thông báo cho bác sĩ trước khi tiền hành tiền mê.
Bệnh nhân cần được theo dõi tiếp khoảng 1 giờ sau khi tiền mê, người bệnh không được điều khiển xe và vận hành máy trong trong vòng 2 giờ sau khi tiền mê.
Trong trường hợp, bệnh nhân nội soi dạ dày cần nhịn ăn tối thiểu 6 tiếng trước soi. Bệnh nhân nội soi đại tràng cần được thụt tháo, làm sạch đại tràng trước khi soi.
**Biến chứng của nội soi tiền mê và cách xử lý**
Các biến chứng hiếm gặp khi nội soi tiền mê chủ yếu là do tác dụng phụ của thuốc gây mê gây ra như buồn ngủ, buồn nôn, tiền mê kéo dài, tụt huyết áp, ức chế hô hấp…
Khi gặp các biến chứng này, bác sĩ có thể sẽ áp dụng những các xử trí sau:
  * Trong trường hợp bệnh nhân tiền mê kéo dài, các bác sĩ có thể dùng thuốc hồi tỉnh theo từng loại thuốc mê đã sử dụng.
  * Khi người bệnh bị ức chế hô hấp, giảm oxy máu, nguyên nhân có thể do ức chế trung tâm hô hấp, co thắt khí phế quản, tắc nghẽn đường thở trên do tụt lưỡi vào… bác sĩ sẽ hướng dẫn hoặc kích thích bệnh nhân thở sâu để cung cấp đầy đủ oxy. Hút đờm rãi, sử dụng thuốc hồi tỉnh, hỗ trợ hô hấp nếu nhịp thở người bệnh không đáp ứng được.
  * Do thuốc mê có thể làm giãn tĩnh mạch, gây tụt huyết áp ở những bệnh nhân giảm khối lượng tuần hoàn dẫn đến suy tuần hoàn. Lúc này, bác sĩ sẽ nâng cao chân của bệnh nhân, truyền dịch theo đường tĩnh mạch, dùng thuốc hồi tỉnh hoặc dùng thuốc co mạch nếu cần thiết.


**Nội soi tiền mê có đắt không?**
Chi phí nội soi tiền mê sẽ phụ thuộc vào rất nhiều yếu tố như: địa điểm thăm khám, phương pháp thực hiện, kỹ thuật phát sinh trong quá trình nội soi (như cắt polyp, cầm máu trong xuất huyết…) mà chi phí sẽ khác nhau và có sự chênh lệch.
**Nội soi tiền mê ở đâu tốt nhất hiện nay**
Việc sử dụng thuốc tiền mê để thực hiện nội soi cần có bác sĩ tay nghề cao tiến hành nếu không sẽ gây ra những ảnh hưởng xấu đến sức khỏe của người bệnh, cũng như đảm bảo kết quả chính xác, hạn chế sự khó chịu đau đớn khi nội soi. Chính vì lẽ đó, việc lựa chọn cơ sở uy tín để nội soi tiền mê là điều vô cùng cần thiết.
Bằng những kinh nghiệm và sự đánh giá của bệnh nhân, Bệnh viện Nguyễn Tri Phương đã và đang là 01 trong những địa chỉ tin cậy cho nhu cầu thăm khám và thực hiện kỹ thuật nội soi tiền mê.
**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/) **- Đa khoa Hạng I Thành phố Hồ Chí Minh

## ️ Đặt ống thông mật mũi

  * [Người thực hiện](https://bvnguyentriphuong.com.vn/noi-soi/dat-ong-thong-mat-mui#ngi-thc-hin)


### **ĐẠI CƯƠNG**
Đặt ống thông mật mũi là kỹ thuật dẫn lưu đường mật tụy để giải quyết tạm thời tình trạng tắc ống mật tụy, hoặc theo dõi tình trạng chảy máu đường mật. Kỹ thuật này phải được thực hiện qua chụp mật tụy ngược dòng qua nội soi – ERCP.
### **CHỈ ĐỊNH**
Chỉ định đặt dẫn lưu mật mũi.
Tắc mật do sỏi đường mật, người bệnh trong tình trạng nặng chưa thể mổ hoặc lấy sỏi mật qua ERCP ngay được.
Sau lấy sỏi mật qua ERCP nhưng chưa lấy hết (sỏi to và khó lấy).
Các trường hợp cần theo dõi dịch mật.
Các trường hợp cần bơm rửa đường mật hoặc cần chụp đường mật lại sau đó.
### **CHỐNG CHỈ ĐỊNH**
Người bệnh có chống chỉ định ERCP.
### **CHUẨN BỊ**
#### **Người thực hiện**
01 bác sĩ có chuyên môn nội soi, sử dụng kỹ thuật ERCP thành thạo.
02 điều dưỡng phụ nội soi.
#### **Phương tiện**
Máy nội soi cửa sổ bên có kênh thủ thuật.
Màn huỳnh quang tăng sáng (C-ARM).
Ống dẫn lưu mật mũi bằng nhựa polyetylen kích cỡ 5Fr và 7Fr, chiều dài ít nhất gấp 2 lần chiều dài dây máy nội soi.
Dây dẫn đường (guidewire) và catheter có thể cho dây dẫn đi qua, dao mở cơ vòng Oddi.
#### **Người bệnh**
Nhịn ăn trước khi làm thủ thuật 6 giờ.
Đã được kiểm tra không có tình trạng rối loạn đông máu nặng (TC ≥ 70G/l, PT ≥ 50%).
Không có chống chỉ định làm ERCP.
#### **Hồ sơ bệnh án**
Ghi chép đầy đủ quá trình thực hiện thủ thuật, tai biến xảy ra (nếu có), ngày, giờ đặt ống thông dẫn lưu.
**CÁC BƯỚC TIẾN HÀNH**
Thực hiện quy trình ERCP thường quy.
Sau khi đặt catheter vào đường mật, luồn dây dẫn vào đường mật qua catheter.
Rút catheter, luồn ống thông mật mũi qua dây dẫn vào đường mật. Khi đầu của ống dẫn lưu mật mũi đã nằm ở vị trí mong muốn thì rút dây dẫn ra.
Rút dây nội soi ra khỏi người bệnh, bác sĩ vừa rút dây nội soi, điều dưỡng phụ vừa đẩy ống thông mật mũi vào. Kiểm tra lại trên màn huỳnh quang tăng sáng để chắc chắn ống thông mật mũi nằm ở đúng vị trí yêu cầu.
Đặt ống thông mềm qua mũi (có thể dùng ống thông mũi dạ dày), luồn ống thông mật mũi qua ống mềm lên mũi. Rút ống thông mềm.
Cố định ống thông mật mũi trên da.
### **THEO DÕI**
Số lượng dịch mật.
Màu sắc dịch mật (máu).
### **TAI BIẾN**
Tắc ống thông mật mũi.
Tuột ống thông mật mũi xuống tá tràng.
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [Người thực hiện](https://bvnguyentriphuong.com.vn/noi-soi/dat-ong-thong-mat-mui#ngi-thc-hin)



## ️ 4 bước của quy trình nội soi đại tràng

  * [Nội soi đại tràng là gì?](https://bvnguyentriphuong.com.vn/noi-soi/4-buoc-cua-quy-trinh-noi-soi-dai-trang#ni-soi-i-trng-l-g)
  * [Tại sao phải nội soi đại tràng](https://bvnguyentriphuong.com.vn/noi-soi/4-buoc-cua-quy-trinh-noi-soi-dai-trang#ti-sao-phi-ni-soi-i-trng)
  * [Đối tượng nào phải nội soi đại tràng?](https://bvnguyentriphuong.com.vn/noi-soi/4-buoc-cua-quy-trinh-noi-soi-dai-trang#i-tng-no-phi-ni-soi-i-trng)
  * [Trước khi nội soi đại tràng cần lưu ý gì?](https://bvnguyentriphuong.com.vn/noi-soi/4-buoc-cua-quy-trinh-noi-soi-dai-trang#trc-khi-ni-soi-i-trng-cn-lu-g)
  * [Quy trình nội soi đại tràng diễn ra như thế nào](https://bvnguyentriphuong.com.vn/noi-soi/4-buoc-cua-quy-trinh-noi-soi-dai-trang#quy-trnh-ni-soi-i-trng-din-ra-nh-th-no)
  * [Trước khi nội soi](https://bvnguyentriphuong.com.vn/noi-soi/4-buoc-cua-quy-trinh-noi-soi-dai-trang#trc-khi-ni-soi)
  * [Trong quá trình nội soi](https://bvnguyentriphuong.com.vn/noi-soi/4-buoc-cua-quy-trinh-noi-soi-dai-trang#trong-qu-trnh-ni-soi)
  * [Đọc kết quả sau quy trình nội soi đại tràng](https://bvnguyentriphuong.com.vn/noi-soi/4-buoc-cua-quy-trinh-noi-soi-dai-trang#c-kt-qu-sau-quy-trnh-ni-soi-i-trng)
  * [Một số triệu chứng thường gặp sau nội soi đại tràng](https://bvnguyentriphuong.com.vn/noi-soi/4-buoc-cua-quy-trinh-noi-soi-dai-trang#mt-s-triu-chng-thng-gp-sau-ni-soi-i-trng)
  * [Những biến chứng có thể gặp phải sau nội soi đại tràng](https://bvnguyentriphuong.com.vn/noi-soi/4-buoc-cua-quy-trinh-noi-soi-dai-trang#nhng-bin-chng-c-th-gp-phi-sau-ni-soi-i-trng)
  * [Một số câu hỏi thường gặp về nội soi đại tràng](https://bvnguyentriphuong.com.vn/noi-soi/4-buoc-cua-quy-trinh-noi-soi-dai-trang#mt-s-cu-hi-thng-gp-v-ni-soi-i-trng)


Hiện nay, nội soi đại tràng là một phương pháp đơn giản, an toàn, không gây đau giúp bác sĩ phát hiện sớm và chẩn đoán một số bệnh về đường tiêu hóa như: ung thư đại tràng, Polype đại tràng, những vùng bị viêm hay chảy máu trong đại tràng.
Những tư vấn sau đây sẽ là những thông tin hữu ích giúp bạn đọc hiểu thêm về nội soi đại tràng và quy trình nội soi đại tràng diễn ra như thế nào?
## **Nội soi đại tràng là gì?**
Nội soi đại tràng giúp phát hiện những bất thường như dị vật, viêm loét, polyp, khối u thông qua một ống nội soi nhỏ, mềm có gắn camera ở đầu ống.
Ống nội soi này được luồn từ hậu môn vào bên trong đại tràng xuống đến tận manh tràng (vùng tiếp nối giữa ruột non và ruột già), hình ảnh thu được qua camera sẽ đượcphóng đại và chiếu lên màn hình, giúp bác sĩ khảo sát toàn bộ đại tràng và đoạn cuối của ruột non.
_Nội soi đại tràng giúp phát hiện sớm những bất thường_
## **Tại sao phải nội soi đại tràng**
Nội soi đaị tràng để tìm ra hoặc để tầm soát một số bệnh như sau:
– Tầm soát ung thư đại tràng
_–_ Polyp đại tràng
– Túi thừa đại tràng
– Bệnh trĩ
– Tìm dị vật
– Tìm ký sinh trùng.
## **Đối tượng nào phải nội soi đại tràng?**
Chỉ định nội soi đại tràng tương đối rộng rãi. Hầu hết các bệnh nhân nghi ngờ có vấn đề ở đường tiêu hóa dưới đều được chỉ định soi đại tràng, cụ thể:
  * Xuất huyết tiêu hóa dưới
  * Có bệnh lý viêm, loét, u đường tiêu hóa dưới
  * Triệu chứng không rõ nguyên nhân: tiêu chảy, đau bụng…
  * Tầm soát ung thư với những đối tượng có nguy cơ cao
  * Bất thường trên X quang khung đại tràng chưa xác định được


Nội soi điều trị được chỉ định khi:
  * Cắt Polyp đại tràng qua nội soi
  * Nong các tổn thương hẹp đại tràng, đặt ống thông (do ác tính, do tia xạ, do viêm mạn…)
  * Cầm máu một số tổn thương như loạn sản mạch máu, chảy máu từ cuống polyp sau khi cắt polyp…
  * Lấy dị vật đường tiêu hóa dưới


Trong trường hợp rối loạn chức năng đại tràng, viêm đại tràng mãn tính, các bác sĩ vẫn có thể chỉ định nội soi đại tràng để chắc chắn loại trừ khả năng bị ung thư.
_Cần nội soi đại tràng ngay khi có dấu hiệu bất thường_
## **Trước khi nội soi đại tràng cần lưu ý gì?**
– Cần thông báo cho bác sĩ về tình trạng sức khỏe của mình: Có thai, cho con bú, tình trạng tim mạch và những thuốc đang sử dụng ví dụ thuốc chống đông máu, thuôc chống ngưng tập tiểu cầu, các thuốc làm ảnh hưởng đến chức năng đông máu…
– Trước khi nội soi đại tràng người bệnh được bác sĩ tư vấn về những lợi ích và nguy hiểm có thể xảy ra. Nếu bệnh nhân đồng ý sẽ được ký vào cam kết đồng ý nội soi.
– Không ăn chất xơ, những loại hoa quả có hạt như ổi, thanh long, nho, dưa lê.., không uống nước có màu, không ăn thanh long đỏ 1-2 ngày trước khi nội soi.
– Nhịn ăn và phải làm sạch đại tràng bằng thuốc uống rất hay được áp dụng hoặc thụt tháo trước khi nội soi. Làm sạch đại tràng vô cùng quan trọng giúp quan sát được toàn bộ niêm mạc đại trực tràng phát hiện được những tổn thương rất nhỏ, nghi ngờ ác tính khi can thiệp cắt polyp hoặc ESD sẽ thuận lợi và giảm thiểu tai biến tối đa.
## **Quy trình nội soi đại tràng diễn ra như thế nào**
**Quy trình nội soi đại tràng** được diễn ra khép kín gồm:
### **Trước khi nội soi**
  * Trước nội soi, bác sĩ sẽ tiến hành khám hậu môn để kiểm tra tổn thương, sau đó nếu không có vấn đề gì bất thường bác sĩ sẽ cho bệnh nhân dùng thuốc để làm sạch đường ruột giúp thuận tiện cho việc nội soi. Bệnh nhân có thể được dùng thêm thuốc an thần và giảm đau. Đây là bước thiết yếu trong **quy trình nội soi đại tràng** để làm sạch đường ruột.
  * Dưới tác dụng của thuốc, bệnh nhân sẽ cảm thấy bớt căng thẳng và hơi buồn ngủ. Trường hợp nội soi đại tràng có gây mê thì bệnh nhân được tiêm thuốc gây mê.


### **Trong quá trình nội soi**
  * Người bệnh được hướng dẫn nằm nghiêng sang trái, co đầu gối lại hướng về phìa trước ngực.
  * Một ống nội soi mềm, nhỏ gắn camera ở đầu sẽ được đưa vào cửa hậu môn của bệnh nhân rồi luồn vào đến trực tràng, đại tràng một cách nhẹ nhàng, chậm rãi. Bác sĩ cũng tiến hành bơm khí khí vào trong để làm căng đại tràng, giúp camera có thể dễ dàng ghi nhận được các tổn thương và truyền hình ảnh về máy tính để bác sĩ quan sát.
  * Trong **quy trình nội soi đại tràng** này, bệnh nhân có thể được yêu cầu thay đổi tư thế vài lần để ống nội soi được đưa vào hết ngóc ngách bên trong ruột già và ít gây đau hơn. Khi cần sinh thiết, bác sĩ sẽ thực hiện nhanh trong quá trình nội soi và bệnh nhân sẽ không cảm thấy đau.
  * Toàn bộ quá trình nội soi kéo dài từ 7 đến 10 phút, nhanh hơn nếu được sự hợp tác tốt của bệnh nhân. Đối với một số trường hợp khó, bệnh nhân có thể được tiêm thêm thuốc an thần hay giãn cơ để bớt khó chịu. Cảm giác này chỉ kéo dài tối đa 1 giờ sau khi nội soi.


**Sau khi nội soi**
  * Bác sĩ sẽ dựa vào kết quả nội soi để đưa ra những chẩn đoán xác định và hướng điều trị cho bệnh nhân. Bên cạnh đó, bác sĩ sẽ đưa ra những lời khuyên giúp bệnh nhân nhanh phục hồi lại sức khỏe sau quá trình nội soi: chế độ dinh dưỡng, chế độ sinh hoạt nghỉ ngời, v.v…
  * Bệnh nhân nên nghỉ ngơi, thư giãn cho đến khi hết cảm giác khó chịu ở bụng
  * Nhiều bệnh nhân sau khi nội soi đại tràng thường gặp phải tình trạng đau âm ỉ ở bụng, chướng bụng, thường xuyên mót rặn nhưng không đi cầu được. Đây là những vấn đề thường xảy ra sau khi kết thúc quá trình nội soi và sẽ biến mất vào ngày hôm sau
  * Nếu phát hiện thấy các biến chứng nghiêm trọng như sốt, đau nhiều, chóng mặt, bênh nhân nên ở lại bệnh viện để được bác sĩ theo dõi.


### **Đọc kết quả sau quy trình nội soi đại tràng**
**Quy trình nội soi đại tràng** hoàn tất bằng bước trả kết quả:
  * _Kết quả bình thường_


Bác sĩ có thể loại trừ nguyên nhân các bệnh lý về đại tràng cho bệnh nhân và chuyển hướng chẩn đoán, điều trị sang hướng khác.
Đối với những bệnh nhân nội soi đại tràng để tầm soát ung thư sớm, với kết quả đại tràng bình thường, tạm thời bệnh nhân có thể yên tâm. Tuy nhiên, bệnh nhân nên chú ý khám và kiểm tra lại định kỳ để phát hiện sớm những tổn thương và bệnh lý nguy hiểm liên quan đến đại tràng.
  * _Kết quả không bình thường_


Dựa vào kết quả nội soi đại tràng, bác sĩ sẽ đưa ra những chẩn đoán và hướng điều trị tùy theo tình trạng bệnh:
– Trường hợp phát hiện những tổn thương bất thường trên niêm mạc đại tràng như viêm, khối u … bác sĩ nội soi sẽ tiến hành sinh thiết để xác định chắc chắn bản chất của tổn thương.
– Trường hợp polyp đại tràng, đã có xét nghiệm đông máu: Cắt polyp qua nội soi.
– Trường hợp xuất huyết do loét: Càm máu bằng đốt điện hay kẹp cầm máu bằng clip.
– Trường hợp búi trĩ đang chảy máu: Thắt trĩ bằng vòng cao su.
– Trường hợp dị vật: Lấy dị vật qua nội soi bằng dụng cụ chuyên biệt.
_Quy trình nội soi đại tràng được thực hiện khép kín_
Thời gian nội soi đại tràng diễn ra khoảng 15-20 phút. Nếu nội soi can thiệp như cắt polyp hoặc cắt tách dưới niêm mạc qua nội soi – ESD điều trị ung thư sớm đại trực tràng … thì thời gian thực hiện sẽ lâu hơn khoảng 60-90 phút.
## **Một số triệu chứng thường gặp sau nội soi đại tràng**
– **Đầy bụng:** Cảm giác đầy bụng xảy ra vì trong quá trình nội soi bác sĩ tiến hành bơm hơi vào trong ruột để giúp thấy rõ các vị trí và mức độ tổn thương bên trong đại tràng. Đây là triệu chứng phổ biến và hầu như ai tiến hành nội soi xong cũng đều gặp phải. Vậy nên, bệnh nhân không cần phải lo lắng vì tình trạng sẽ tự hết sau vài tiếng.
– **Đau tức nhẹ bụng:** Trong quá trình tiến hành nội soi, bác sĩ sẽ di chuyển ống nội soi để giúp cho việc quan sát dễ dàng và tránh bỏ sót các vấn. Chính vì điều này khiến niêm mạc đại tràng có thể bị kích thích dẫn đến cảm giác đau tức nhẹ vùng bụng dưới. Tuy nhiên tình trạng cũng sẽ biến mất sau khoảng 2 tiếng nên bệnh nhân cũng không cần quá lo lắng.
Ngoài ra, bệnh nhân cũng có thể gặp thêm tình trạng chảy máu sau khi nội soi. Vì có thể trong quá trình nội soi, bác sĩ phát hiện dấu hiệu bất thường sinh thiết lấy mẫu tế bào để làm mô bệnh học nên có thể dẫn tới chảy ít máu. Tình trạng này có thể khiến bệnh nhân đi ngoài ra ít máu nhưng nó cũng sẽ tự hết sau một vài ngày nên bệnh nhân không cần quá hoảng sợ.
## **Những biến chứng có thể gặp phải sau nội soi đại tràng**
Theo các chuyên gia đánh giá, nội soi đại tràng là một thủ thuật khá an toàn và gần như không phát sinh những biến chứng nghiêm trọng sau đó. Kể cả khi **quy trình nội soi đại tràng** không xảy ra bất cứ sai sót nòa thì sau khi nội soi đại tràng, người bệnh vẫn có thể gặp một số biến chứng khó chịu:
  * Tổn thương, chảy máu ở niêm mạc đại trực tràng do thao tác nội soi quá mạnh, bác sĩ thực hiện không có kinh nghiệm.
  * Tình trạng xuất huyết cũng có thể xảy ra ở những vị trí được cắt bỏ polyp hoặc nơi lấy mẫu làm sinh thiết. Tuy nhiên vấn đề này thường không quá nghiêm trọng và bác sĩ có thể áp dụng ngay các biện pháp cầm máu ngay trong khi nội soi. Hiếm khi có trường hợp nào phải xứ lý cấp cứu bằng cách truyền máu hoặc phẫu thuật.
  * Rách hoặc xuất hiện lỗ thủng tại thành đại tràng. Nguy cơ này thường xảy ra ở những người có thành ruột mỏng hoặc ruột già bị viêm loét nặng.
  * Biến chứng do sử dụng thuốc an thần, gây mê: Dị ứng thuốc, sưng đỏ ở vị trí tiêm thuốc.


Mặc dù nội soi đại tràng ít khi gây ra các biến chứng nguy hiểm nhưng bệnh nhân cũng cần đề phòng bằng cách theo dõi sức khỏe của bản thân. Nếu nhận thấy bất kì dấu hiệu nghiêm trọng nào sau khi nội soi như đau bụng dữ dội, đại tiện ra máu, sốt cao, ớn lạnh trong người… thì nên thông báo cho bác sĩ biết ngay.
## **Một số câu hỏi thường gặp về nội soi đại tràng**
Có rất nhiều câu hỏi liên quan đến vấn đề nội soi đại tràng. Dưới đây là một số câu hỏi thường gặp:
**Nội soi đại tràng mất bao nhiêu lâu?**
Tùy vào đại tràng khó hay dễ, có làm thêm thủ thuật cắt Polyp, sinh thiết hoặc nong các tổn thương hẹp đại tràng hay không mà thời gian nội soi sẽ kéo dài từ 30 – 60 phút.
**Nội soi đại tràng có an toàn không?**
Tỷ lệ tai biến do nội soi đại tràng là rất thấp, khoảng 0,1 – 0,5 %. Do vậy, đây là một phương pháp chẩn đoán hình ảnh rất an toàn và hiện nay đang được sử dụng rộng rãi tại các bệnh viện trên cả nước.
**Nội soi đại tràng có đau không?**
Trong quá trình nội soi đại tràng, đa phần bệnh nhân chỉ cảm thấy đau tức nhẹ phần bụng dưới và cảm giác này sẽ nhanh chóng biến mất sau khi kết thúc quá trình nội soi khoảng vài tiếng.
Hiện nay, tại các bệnh viện và phòng khám chuyên khoa tiêu hóa đã áp dụng phương pháp nội soi đại tràng gây mê. Đây là phương pháp nội soi an toàn, giải quyết hầu hết cảm giác đau tức bụng của bệnh nhân, giúp cho quá trình nội soi diễn ra nhanh chóng, thuận lợi.
**Có nên nội soi đại tràng và dạ dày cùng lúc?**
Nội soi đại tràng và nội soi dạ dày đều là những phương pháp an toàn, thuận tiện và đều cần dùng đến thuốc gây mê. Do vậy, nếu nội soi dạ dày và đại tràng cùng lúc, bạn sẽ tránh được việc phải gây mê 2 lần. Dựa vào kết quả nội soi đại tràng và dạ dày, bác sĩ sẽ đưa ra những chẩn đoán rộng hơn cho bệnh nhân, giúp cho quá trình điều trị đạt kết quả tốt nhất..
Đối với những bệnh nhân nội soi dạ dày và đại tràng để tầm soát ung thư sớm, việc kết hợp cả nội soi dạ dày và đại tràng sẽ giúp bệnh nhân hiểu rõ hơn về sức khỏe hiện tại của bản thân, có chế độ dinh dưỡng, nghỉ ngơi, chăm sóc bản thân tốt hơn.
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [Nội soi đại tràng là gì?](https://bvnguyentriphuong.com.vn/noi-soi/4-buoc-cua-quy-trinh-noi-soi-dai-trang#ni-soi-i-trng-l-g)
  * [Tại sao phải nội soi đại tràng](https://bvnguyentriphuong.com.vn/noi-soi/4-buoc-cua-quy-trinh-noi-soi-dai-trang#ti-sao-phi-ni-soi-i-trng)
  * [Đối tượng nào phải nội soi đại tràng?](https://bvnguyentriphuong.com.vn/noi-soi/4-buoc-cua-quy-trinh-noi-soi-dai-trang#i-tng-no-phi-ni-soi-i-trng)
  * [Trước khi nội soi đại tràng cần lưu ý gì?](https://bvnguyentriphuong.com.vn/noi-soi/4-buoc-cua-quy-trinh-noi-soi-dai-trang#trc-khi-ni-soi-i-trng-cn-lu-g)
  * [Quy trình nội soi đại tràng diễn ra như thế nào](https://bvnguyentriphuong.com.vn/noi-soi/4-buoc-cua-quy-trinh-noi-soi-dai-trang#quy-trnh-ni-soi-i-trng-din-ra-nh-th-no)
  * [Trước khi nội soi](https://bvnguyentriphuong.com.vn/noi-soi/4-buoc-cua-quy-trinh-noi-soi-dai-trang#trc-khi-ni-soi)
  * [Trong quá trình nội soi](https://bvnguyentriphuong.com.vn/noi-soi/4-buoc-cua-quy-trinh-noi-soi-dai-trang#trong-qu-trnh-ni-soi)
  * [Đọc kết quả sau quy trình nội soi đại tràng](https://bvnguyentriphuong.com.vn/noi-soi/4-buoc-cua-quy-trinh-noi-soi-dai-trang#c-kt-qu-sau-quy-trnh-ni-soi-i-trng)
  * [Một số triệu chứng thường gặp sau nội soi đại tràng](https://bvnguyentriphuong.com.vn/noi-soi/4-buoc-cua-quy-trinh-noi-soi-dai-trang#mt-s-triu-chng-thng-gp-sau-ni-soi-i-trng)
  * [Những biến chứng có thể gặp phải sau nội soi đại tràng](https://bvnguyentriphuong.com.vn/noi-soi/4-buoc-cua-quy-trinh-noi-soi-dai-trang#nhng-bin-chng-c-th-gp-phi-sau-ni-soi-i-trng)
  * [Một số câu hỏi thường gặp về nội soi đại tràng](https://bvnguyentriphuong.com.vn/noi-soi/4-buoc-cua-quy-trinh-noi-soi-dai-trang#mt-s-cu-hi-thng-gp-v-ni-soi-i-trng)



## ️ Biến chứng nội soi đại tràng có nguy hiểm không?

**Nội soi đại tràng tiến hành như thế nào?**
Biến chứng nội soi đại tràng, nội soi đại tràng là tiêu chuẩn vàng trong tầm soát ung thư đại tràng, thủ thuật này được tiến hành các bước như sau:
  * Sau khi làm sạch ruột, bệnh nhân được tiêm thuốc gây mê để bớt lo lắng và không có cảm giác đau đớn trong quá trình thực hiện (nếu nội soi gây mê)
  * Tiếp theo bác sĩ đưa ống nội soi vào trong hậu môn và đi sâu vào trong trực tràng cho đến hết ruột già
  * Bơm không khí vào để ruột già phình to ra. Hình ảnh nội soi được ghi nhận và chiếu lên màn hình để bác sĩ dễ dàng chẩn đoán, phát hiện những tổn thương bên trong;
  * Nếu phát hiện polyp thì bác sĩ có thể tiến hành cắt bỏ trong quá trình nội soi. Sau khi nội soi xong, bác sĩ từ từ rút ống nội soi ra ngoài, bạn sẽ tỉnh lại sau đó.


_Minh họa nội soi đại tràng_
**Những rủi ro khi nội soi có thể gặp phải**
Nội soi đại tràng hầu như không có biến chứng nghiêm trọng với sức khỏe của bệnh nhân. Tuy nhiên, trong một vài trường hợp có thể gặp một vài biến chứng sau:
**Vết thủng nhỏ ở ruột**
Cực kì hiếm gặp, đây là tình trạng thủng ruột do đại tràng dài, gập góc và xoắn, nên sau nội soi bệnh nhân có thể gặp phải tình trạng này. Bệnh nhân sẽ được theo dõi, điều trị nội khoa hoặc phẫu thuật khâu chỗ thủng.
**Chảy máu**
Trong quá trình nội soi bác sĩ phát hiện những bất thường và tiến hành sinh thiết để kiểm tra hoặc có thủ thuật như cắt polyp thì sẽ xuất hiện hiện tượng chảy máu. Chảy máu có thể xảy ra trong hoặc sau khi làm thủ thuật. Chảy máu trong khi làm thủ thuật không đáng ngại vì phần nhiều tự cầm máu và có thể cầm máu qua nội soi dễ dàng.
Chảy máu muộn sau khi làm thủ thuật là điều đáng ngại vì vậy người bệnh cần liên hệ với bác sĩ và đến viện ngay nếu đi ngoài ra máu với số lượng nhiều và kéo dài.
**Bỏng sau khi cắt polyp**
Polyp không có cuống và kích thước không to thì sẽ cắt kìm sinh thiết nhiệt. Polyp có cuống to thì bác sĩ sẽ dùng dòng điện để cắt, do đó có thể gặp hiện tượng bỏng sau khi cắt polyp.
**Phản ứng với thuốc mê**
Có một số tác dụng phụ mà thuốc gây mê để lại cho bệnh nhân như khó thở, nhịp tim không đều và có thể có bệnh nhân bị dị ứng với thuốc gây mê
**Nhiễm trùng**
Những tổn thương ở hậu môn trước khi nội soi hoặc những polyp được cắt đi để lại những vết thương. Đây là những vị trí không mấy sạch sẽ nên cũng dễ bị nhiễm trùng sau nội soi.
**Biến chứng khác như: chướng hơi, buồn nôn**
Khi nội soi bác sĩ phải bơm không khí vào cho đại tràng phình to ra để nhìn rõ những tổn thương, nên sau nội soi bệnh nhân có cảm giác đầy hơi, thường xuyên trung tiện, và xuất hiện cảm giác buồn nôn.
**Hiện tượng đau bụng sau khi nội soi đại tràng nguy hiểm không?**
Sau khi trải qua nội soi cắt polyp đại tràng bệnh nhân sẽ cảm thấy đau tức bụng vì còn chướng hơi trong lòng ruột do bơm hơi trong quá trình nội soi nhưng nó sẽ tự hết trong vòng một vài giờ. Điều này là hoàn toàn bình thường. 
Cùng với chế độ ăn uống hợp lý, sau một thời gian cảm giác đau sẽ mất dần. Bệnh nhân cần ăn uống theo chỉ định của bác sĩ và thực hiện điều trị bệnh tại nhà. Không phải quá lo lắng, tuy nhiên nếu đau nhiều và các cơn đau dày hơn thì nên liên lạc với bác sĩ của bạn ngay.
_Có thể xảy ra tình trạng đau bụng sau nội soi_
**Rủi ro sau nội soi đối với người cao tuổi**
Thực hiện nội soi đại tràng ở những bệnh nhân cao tuổi đặt ra một thử thách khá lớn bởi nguy cơ biến chứng cao hơn so với những bệnh nhân trẻ tuổi.
Khi bệnh nhân lớn tuổi gặp phải những biến chứng sau nội soi như thủng ruột, chảy máu, nhiễm trùng, bỏng sau khi cắt polyp, phản ứng với thuốc gây mê, chướng hơi, buồn nôn thì việc điều trị gặp nhiều khó khăn hơn do hệ tiêu hóa, hệ miễn dịch, sức đề kháng đều đã kém đi.
Tỉ lệ điều trị thành công thấp hơn và khả năng tái phát bệnh cũng cao hơn so với bệnh nhân trẻ tuổi.
Việc làm sạch ruột trước khi nội soi cho người lớn tuổi là một vấn đề đáng lo ngại bởi nó có thể dẫn đến mất nước hoặc mất cân bằng điện giải. Vì vậy việc uống đủ nước là rất quan trọng.
Những bệnh nhân cao tuổi lại có tiền sử bệnh tim mạch có thể bị tăng thể tích nước nội mạch gây ra biến chứng phù nề
Đồ uống pha chế có chứa natri phosphate cũng có thể gây biến chứng ở thận đối với một số bệnh nhân lớn tuổi.
Những bệnh nhân lớn tuổi cũng có thể tăng nguy cơ gặp biến chứng liên quan đến tim hoặc phổi trong thời gian sau nội soi đại tràng.
**Trường hợp nào cần liên hệ với bác sĩ**
Trong trường hợp bệnh nhân sau khi thực hiện ca phẫu thuật thấy các triệu chứng như: cơ thể mệt mỏi, cảm giác muốn nôn khan, buồn nôn, đầu óc quay cuồng, bị sốt, tức ngực, khó thở, bị ho. Đau nhiều ở vùng bụng, chướng bụng, vị trí trực tràng tiết ra dịch, hậu môn bị phù, đi ngoài phân đen hoặc dính máu.
Những dấu hiệu trên đều là những triệu chứng bất thường sau khi cắt polyp đại tràng, cảnh báo biến chứng nguy hiểm của bệnh. Bệnh nhân không nên chủ quan mà cần liên hệ ngay với bác sĩ và tới các cơ sở y tế để thăm khám và điều trị kịp thời.
Nội soi đại tràng là phương pháp sàng lọc hiệu quả cao được sử dụng để phát hiện ung thư đại trực tràng và các tình trạng khác. Phương pháp này rất an toàn, nhưng không phải không có biến chứng. Những bệnh nhân cao tuổi gặp mức độ rủi ro do biến chứng sau nội soi cao hơn so với bệnh nhân trẻ tuổi.
**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/) **- Đa khoa Hạng I Thành phố Hồ Chí Minh

## ️ Nội soi dạ dày có đau không, có khó chịu không?

**Tại sao phải nội soi dạ dày?**
Bệnh đau dạ dày là một trong những căn bệnh phổ biến nhất về đường tiêu hóa. Căn bệnh này có rất nhiều dấu hiệu biểu hiện ra bên ngoài cơ thể như: ợ chua, chướng hơi, đầy bụng, đau vùng thượng vị, nôn hoặc buồn nôn, chảy máu đường tiêu hóa (nôn hoặc đi ngoài ra máu). Tuy nhiên nếu chỉ dựa vào các triệu chứng trên thì vẫn chưa thể chẩn đoán chính xác bệnh liên quan đến dạ dày.
Rất nhiều phương pháp hiện đại như siêu âm, hay chụp CT, cộng hưởng từ (MRI) tuy đắt tiền nhưng lại không có giá trị nhiều trong chẩn đoán bệnh dạ dày nói riêng cũng như các bệnh liên quan đến ống tiêu hóa nói chung. Chỉ có phương pháp nội soi mới giúp bác sĩ đưa ra chẩn đoán chính xác nhất các bệnh liên quan đến ống tiêu hóa bao gồm cả bệnh dạ dày.
**Tác dụng của nội soi dạ dày**
Nôi soi dạ dày là một kỹ thuật hiện đại cho phép nhìn trực tiếp hình ảnh bên trong hệ thống tiêu hóa trên (từ thực quản, đến dạ dày và tá tràng) bằng cách đưa ống nội soi mềm có đầu gắn camera vào đường tiêu hóa của bệnh nhân.
Nhờ máy nội soi bác sĩ có thể phát hiện những tổn thương bên trong dạ dày như viêm loét, nhiễm trùng hay chảy máu dạ dày…đặc biệt những tổn thương dù rất nhỏ dù chỉ vài milimet cũng có thể phát hiện được.
Ngoài ra nội soi có thể cho phép tìm vi khuẩn Helicobacter Pylori (HP) trong dạ dày, lấy các dị vật trong ống tiêu hóa, lấy mẫu mô sinh thiết, hoặc điều trị xuất huyết tiêu hóa mà không phải mổ…
**Các phương pháp nội soi dạ dày**
_**Nội soi dạ dày qua đường miệng**_
Nội soi dạ dày qua đường miệng là phương pháp truyền thống và phổ biến nhất hiện nay. Với phương pháp này ống nội soi được đưa vào cơ thể quay đường miệng.
__Ưu điểm của nội soi qua đường miệng:__
  * Dễ thực hiện, mang lại độ chính xác cao.
  * Giá thành thấp.
  * Trong quá trình nội soi nếu phát hiện những bệnh lý và cần can thiệp như lấy dị vật, cầm máu, cắt polyp, lấy mẫu sinh thiết, xét nghiệm tìm vi khuẩn HP… thì có thể thực hiện luôn.


__Nhược điểm của nội soi qua đường miệng:__
  * Ống mềm dùng để nội soi có đường kính lớn, nên khi đi qua miệng sẽ kích thích lưỡi gà, vòm khẩu cái, đáy lưỡi làm bạn có cảm giác khó chịu, có thể buồn nôn. Nếu lựa chọn hình thức nội soi thông thường (không gây mê) rất nhiều người cảm thấy sợ hãi khi nuốt ống nội soi. Một số trường hợp nôn nhiều nên có thể bị sây sát họng, đau rát họng sau khi thực hiện nội soi.


_Nội soi qua đường miệng_
_**Nội soi dạ dày qua đường mũi**_
Là phương pháp nội soi nhờ đưa ống nội soi mềm nhỏ qua đường mũi, xuống thực quản, đến dạ dày, hành tá tràng.
__Ưu điểm của nội soi qua đường mũi:__
  * Nội soi qua đường mũi dễ chịu hơn so với nội soi qua đường miệng vì ống nội soi qua đường mũi có kích thước rất nhỏ, mặt khác luồn ống qua đường mũi sẽ không gây kích ứng đến vùng lưỡi gà, hầu họng nên ít gây khó chịu hơn.
  * Độ chính xác cao và dễ thực hiện. Quá trình nội soi nhanh chóng chỉ khoảng 15 phút.


__Nhược điểm của nội soi qua đường mũi:__
  * Những trường hợp có bệnh lý về vùng mũi, hẹp khe mũi thì không thực hiện được phương pháp này.
  * Trong quá trình nội soi nếu phát hiện các bệnh lý và cần can thiệp như lấy dị vật, cầm máu, cắt polyp, lấy mẫu sinh thiết… thì phương pháp này sẽ không thực hiện được và bắt buộc lại chuyển qua nội soi qua đường miệng.
  * Chi phí nội soi qua đường mũi cao hơn nội soi qua đường miệng.


_Nội soi qua đường mũi_
_**Nội soi dạ dày có gây mê – không đau**_
Gọi là nội soi dạ dày không đau do trong quá trình nội soi bệnh nhân được gây mê nên hoàn toàn không có bất kì cảm giác khó chịu, đau đớn nào. Khi nội soi bệnh nhân được gây mê trong thời gian ngắn khoảng 5 – 15 phút và sau đó sẽ tỉnh lại nhanh chóng nên hoàn toàn không ảnh hưởng nhiều tới sức khỏe.
__Ưu điểm của nội soi qua gây mê:__
  * Bệnh nhân được gây mê nên sẽ không cảm thấy khó chịu, buồn nôn trong quá trình thực hiện nội soi. Hạn chế được tình trạng nguy hiểm như bệnh nhân giãy giụa hay giật ống nội soi.
  * Nếu trong quá trình nội soi bác sĩ cần thực hiện các thủ thuật can thiệp thì bệnh nhân sẽ không cảm thấy đau nên an toàn hơn.


__Nhược điểm của nội soi dạ dày có gây mê:__
  * Khi sử dụng thuốc gây mê có thể làm tăng nguy cơ dị ứng thuốc, sốc thuốc và sau khi nội soi bệnh nhân có thể mắc một số tác dụng phụ của thuốc gây mê như đau đầu, buồn ngủ, mệt mỏi.
  * Để thực hiện gây mê thì bệnh nhân cần làm các xét nghiệm liên quan. Do đo chi phí nội soi gây mê cũng cao hơn.


**Quy trình nội soi dạ dày**
_**Trước khi nội soi**_
  * Bác sĩ nội soi tiến hành thăm khám, đánh giá tình trạng bệnh sử, bệnh lý và chỉ định làm những xét nghiệm cần thiết trước nội soi. Nếu bạn đang sử dụng bất kì loại thuốc gì: thuốc điều trị hay thực phẩm chức năng cũng cần thông báo cho bác sĩ.
  * Bác sĩ sẽ giải thích cho bệnh nhân về thủ thuật và gây mê (nếu chọn làm nội soi có gây mê). Nếu bạn đã hiểu về quy trình thực hiện, các rủi ro có thể có… và chấp nhận thực hiện thủ thuật thì ban phải kí cam kết đồng ý.
  * Làm sạch đường tiêu hóa của bệnh nhân để giúp cho bác sĩ quan sát và đánh giá tổn thương được tốt nhất. Trước khi nội soi bệnh nhân đã được dặn nhịn ăn từ 6 – 8 tiếng, khi đến viện thực hiện nội soi trước khi vào làm thủ thuật 10 – 30 phút bệnh nhân sẽ được cho uống dung dịch làm sạch bọt và nhày trong dạ dày.
  * Một lưu ý quan trọng nữa trước khi nội soi là bệnh nhân cần ngừng dùng một số loại thuốc nhất định như thuốc chống đông vài ngày trước khi nội soi vì chúng sẽ làm gia tăng nguy cơ xuất huyết (trong trường hợp cần làm một số thủ thuật trong quá trình nội soi). Nếu bệnh nhân có bệnh lý mãn tính (tiểu đường, bệnh tim mạch hay huyết áp cao) thì bác sĩ gây mê sẽ hướng dẫn cụ thể cho bệnh nhân về các loại thuốc đang dùng.


_**Quá trình nội soi**_
  * Bệnh nhân được hướng dẫn nằm nghiêng bên trái, chân trên co, chân dưới thẳng. Nếu nội soi qua đường miệng bệnh nhân sẽ được cho ngậm một dụng cụ bằng nhựa giúp bảo vệ răng miệng và giữ miệng luôn mở.
  * Các thiết bị hỗ trợ để theo dõi mạch, huyết áp, nhịp tim sẽ được gắn trên người bệnh nhân. Nếu chọn hình thức nội soi gây mê thì thuốc mê sẽ được truyền qua đờng tĩnh mạch trên cánh tay.
  * Bác sĩ đưa ống nội soi vào, trên đầu ống nội soi có gắn một camera nhỏ sẽ truyền hình ảnh tới màn hình bên ngoài để bác sĩ quan sát tìm ra các dấu hiệu bất thường, sau đó chụp và ghi lại để kiểm tra.


_**Sau khi nội soi**_
  * Nếu làm nội soi có gây mê, bệnh nhân sẽ được đưa ra nằm tại vị trí hồi tỉnh một thời gian khoảng 30 phút.
  * Bác sĩ đọc kết quả, kê đơn thuốc (nếu cần), tư vấn cho bệnh nhân chế độ dinh dưỡng cũng như cách chăm sóc sức khỏe, hẹn tái khám (nếu cần).


**Nội soi dạ dày có đau không?**
Nội soi dạ dày thường không đau, tuy nhiên một số người thường sợ nội soi dạ dày do có cảm giác buồn nôn khi bác sĩ luồn ống nội soi vào.
Việc luồn ống nội soi qua họng làm nhiều người có cảm giác như bị móc họng, gợn vướng ở cổ họng nên sẽ cố nôn ọe. Việc nôn ọe sẽ làm xước, đau họng mặt khác làm thời gian nội soi bị kéo dài, từ đó hình thành tâm lý sợ, ám ảnh khi nội soi dạ dày.
Nếu chọn hình thức nội soi dạ dày có gây mê thì bệnh nhân sẽ dễ chịu hơn. Do trước khi nội soi bệnh nhân đã được gây mê hoàn toàn nên không có bất cứ cảm giác khó chịu buồn nôn nào trong lúc thực hiện nội soi. Để đảm bảo an toàn cho việc gây mê, bác sĩ sẽ chỉ định làm một số xét nghiệm trước đó. Còn sau khi nội soi bệnh nhân có thể hơi choáng do thuốc mê nên cần có người thân đi cùng khi lựa chọn hình thức nội soi này.
Với hình thức nội soi dạ dày qua đường mũi sẽ hạn chế cảm giác khó chịu buồn nôn như khi nội soi qua đường miệng. Khi tiến hành nội soi, vùng mũi của bệnh nhân đã được gây tê nên không có cảm giác đau, nhột khi luồn ống nội soi vào bên trong.
**Lưu ý trước và sau khi nội soi**
_**Trước khi nội soi**_
  * Cần nhịn ăn tối thiểu 6 tiếng trước khi thực hiện nội soi dạ dày. Việc nay để tránh tình trạng trong quá trình nội soi bị trào ngược, sặc thức ăn và cũng đảm bảo thức ăn trong dạ dày đã tiêu hóa hết giúp việc quan sát, đánh giá những tổn thương bên trong được dễ dàng, chính xác hơn.
  * Riêng trường hợp người thực hiện nội soi bị hẹp môn vị, cần nhịn ân lâu hơi từ 12 – 24 tiếng hoặc phải đặt ống bơm rửa dạ dày trước khi nội soi.
  * Nếu chọn phương pháp nội soi gây mê thì cần nhịn uống ít nhất 2 tiếng trước khi nội soi để tránh khi nội soi xảy ra tình trạng trào ngược vào phổi.
  * Vào buổi sáng ngày thực hiện nội soi không uống sữa, các loại đồ uống có màu, thuốc cản quang để tránh việc ảnh hưởng đến khả năng quan sát khi tiến hành nội soi.
  * Trước khi nội soi cần cung cấp cho bác sĩ tiền sử bệnh, tiền sử dị ứng thuốc, các loại thuốc đang sử dụng để bác sĩ nắm được và đảm bảo an toàn khi thực hiện thủ thuật.


_**Sau khi nội soi**_
  * Sau khi nội soi 1 tiếng, không nên ăn uống bất kì thứ gì. Sau 2 tiếng có thể ăn các món mềm, lỏng, dễ tiêu hóa. Không nên uống đồ quá nóng, ăn các đồ cay nóng vì có thể làm tổn thương dạ dày.
  * Sau khi nội soi dạ dày có thể khiến bạn khó chịu ở cổ họng và có cảm giác buồn nôn do việc luồn ống nội soi vào sâu. Nên tránh khạc nhổ và nên ngậm, súc miệng với nước muối pha loãng.
  * Sau khi thực hiện nội soi bạn có thể cảm thấy một vài dấu hiệu như:
  * Khó chịu, đau rát ở cổ họng và có cảm giác buồn nôn do việc luồn ống nội soi vào sâu. Nên tránh khạc nhổ và nên ngậm, súc miệng với nước muối pha loãng.
  * Đầy hơi, tức bụng do trong quá trình nội soi không khí được bơm nhẹ vào thực quản để làm căng phồng ống tiêu hóa giúp cho ống nội soi di chuyển dễ dàng hơn và bác sĩ có thể quan sát rõ hơn những nếp gấp của ống tiêu hóa.
  * Mệt mỏi và buồn ngủ do tác dụng phụ của thuốc mê (trong trường hợp làm nội soi có gây mê). Để đảm bảo an toàn, sau khi nội soi bạn không nên lái xe và làm các công việc phức tạp hay đòi hỏi tập trung cao và nên có người thân đi cùng.


Những dấu hiệu này sẽ hết từ từ mà không cần can thiệp gì, nếu cảm thấy quá chịu bạn có thể tham khảo thêm ý kiến bác sĩ.
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh

## ️ Đặt ống thông tá tràng dưới hướng dẫn C-ARM

  * [Người thực hiện](https://bvnguyentriphuong.com.vn/noi-soi/dat-ong-thong-ta-trang-duoi-huong-dan-c-arm#ngi-thc-hin)
  * [CÁC BƯỚC THỰC HIỆN](https://bvnguyentriphuong.com.vn/noi-soi/dat-ong-thong-ta-trang-duoi-huong-dan-c-arm#cc-bc-thc-hin)
  * [TAI BIẾN VÀ XỬ TRÍ](https://bvnguyentriphuong.com.vn/noi-soi/dat-ong-thong-ta-trang-duoi-huong-dan-c-arm#tai-bin-v-x-tr)


### **ĐẠI CƯƠNG**
Đặt ống thông tá tràng là đưa ống thông qua mũi hoặc miệng xuống tá tràng nhằm mục đích lấy bệnh phẩm, điều trị hoặc là một phần của các thủ thuật khác. Đây là một thủ thuật đơn giản nhưng đòi hỏi sự khéo léo của người làm thủ thuật, thường được thực hiện dưới hướng dẫn của màn huỳnh quang tăng sáng (C-ARM).
### **CHỈ ĐỊNH**
Lấy bệnh phẩm là dịch mật hoặc dịch tụy.
Bơm thuốc tẩy giun vào tá tràng.
Cho ăn qua ống thông tá tràng.
Bơm nước trong chụp MSCT ruột non.
### **CHỐNG CHỈ ĐỊNH**
Hẹp môn vị.
Loét hành tá tràng.
### **CHUẨN BỊ**
#### **Người thực hiện**
01 bác sĩ.
01 điều dưỡng phụ.
#### **Phương tiện**
Máy C-ARM.
Ống thông tá tràng (đầu ống thông có vạch cản quang).
#### **Người bệnh**
Nhịn ăn 4 - 6 giờ trước khi làm thủ thuật.
#### **Hồ sơ bệnh án**
Ghi chép đầy đủ quá trình thực hiện thủ thuật.
### **CÁC BƯỚC THỰC HIỆN**
Đặt ống thông qua mũi hoặc miệng xuống dạ dày.
Quan sát dưới màn huỳnh quang tăng sáng xem đầu ống thông xuống hang vị (nếu chưa xuống hang vị có thể cho người bệnh đứng dậy đi lại một lúc sau đó kiểm tra lại).
Luồn ống thông qua lỗ môn vị xuống tá tràng.
Xác định vị trí đặt ống thông qua màn huỳnh quang tăng sáng.
Cố định ống thông trên da.
### **THEO DÕI**
Tùy mục đích đặt ống thông có rút ống thông sau khi thực hiện các thủ thuật khác hoặc lưu ống thông trong trường hợp theo dõi hoặc cho ăn qua ống thông.
### **TAI BIẾN VÀ XỬ TRÍ**
Đặt ống thông nhầm vào khí quản.
Chảy máu (thường trên nền niêm mạc ống tiêu hóa có tổn thương trước như loét hoặc ung thư).
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [Người thực hiện](https://bvnguyentriphuong.com.vn/noi-soi/dat-ong-thong-ta-trang-duoi-huong-dan-c-arm#ngi-thc-hin)
  * [CÁC BƯỚC THỰC HIỆN](https://bvnguyentriphuong.com.vn/noi-soi/dat-ong-thong-ta-trang-duoi-huong-dan-c-arm#cc-bc-thc-hin)
  * [TAI BIẾN VÀ XỬ TRÍ](https://bvnguyentriphuong.com.vn/noi-soi/dat-ong-thong-ta-trang-duoi-huong-dan-c-arm#tai-bin-v-x-tr)



## ️ Kỹ thuật Soi dạ dày - tá tràng ống mềm

  * [Soi dạ dày - hành tá tràng](https://bvnguyentriphuong.com.vn/noi-soi/ky-thuat-soi-da-day-ta-trang-ong-mem#soi-d-dy-hnh-t-trng)
  * [Chỉ định của ph­ương pháp soi dạ dày - hành tá tràng](https://bvnguyentriphuong.com.vn/noi-soi/ky-thuat-soi-da-day-ta-trang-ong-mem#ch-nh-ca-phng-php-soi-d-dy-hnh-t-trng)
  * [Chống chỉ định của ph­ương pháp soi dạ dày - hành tá tràng :](https://bvnguyentriphuong.com.vn/noi-soi/ky-thuat-soi-da-day-ta-trang-ong-mem#chng-ch-nh-ca-phng-php-soi-d-dy-hnh-t-trng-)
  * [Các b­ước làm thủ thuật :](https://bvnguyentriphuong.com.vn/noi-soi/ky-thuat-soi-da-day-ta-trang-ong-mem#cc-bc-lm-th-thut-)
  * [Kỹ thuật soi ng­ược :](https://bvnguyentriphuong.com.vn/noi-soi/ky-thuat-soi-da-day-ta-trang-ong-mem#k-thut-soi-ngc-)
  * [Ích lợi và những hạn chế của ph­ương pháp soi dạ dày - hành tá tràng.](https://bvnguyentriphuong.com.vn/noi-soi/ky-thuat-soi-da-day-ta-trang-ong-mem#ch-li-v-nhng-hn-ch-ca-phng-php-soi-d-dy-hnh-t-trng)
  * [HÌNH ẢNH DẠ DÀY - HÀNH TÁ TRÀNG BÌNH TH­ƯỜNG](https://bvnguyentriphuong.com.vn/noi-soi/ky-thuat-soi-da-day-ta-trang-ong-mem#hnh-nh-d-dy-hnh-t-trng-bnh-thng)
  * [Vành móng ngựa :](https://bvnguyentriphuong.com.vn/noi-soi/ky-thuat-soi-da-day-ta-trang-ong-mem#vnh-mng-nga-)
  * [Mặt tr­ước dạ dày :](https://bvnguyentriphuong.com.vn/noi-soi/ky-thuat-soi-da-day-ta-trang-ong-mem#mt-trc-d-dy-)
  * [Mặt sau dạ dày vùng thân vị :](https://bvnguyentriphuong.com.vn/noi-soi/ky-thuat-soi-da-day-ta-trang-ong-mem#mt-sau-d-dy-vng-thn-v-)
  * [Hành tá tràng :](https://bvnguyentriphuong.com.vn/noi-soi/ky-thuat-soi-da-day-ta-trang-ong-mem#hnh-t-trng-)
  * [HÌNH ẢNH BỆNH LÝ Ở DẠ DÀY - HÀNH TÁ TRÀNG](https://bvnguyentriphuong.com.vn/noi-soi/ky-thuat-soi-da-day-ta-trang-ong-mem#hnh-nh-bnh-l-d-dy-hnh-t-trng)
  * [Bệnh lý ở dạ dày](https://bvnguyentriphuong.com.vn/noi-soi/ky-thuat-soi-da-day-ta-trang-ong-mem#bnh-l-d-dy)
  * [Những hình ảnh của viêm niêm mạc dạ dày:](https://bvnguyentriphuong.com.vn/noi-soi/ky-thuat-soi-da-day-ta-trang-ong-mem#nhng-hnh-nh-ca-vim-nim-mc-d-dy)
  * [Viêm dạ dày do chấn th­ương :](https://bvnguyentriphuong.com.vn/noi-soi/ky-thuat-soi-da-day-ta-trang-ong-mem#vim-d-dy-do-chn-thng-)
  * [Viêm dạ dày chợt nông phẳng:](https://bvnguyentriphuong.com.vn/noi-soi/ky-thuat-soi-da-day-ta-trang-ong-mem#vim-d-dy-cht-nng-phng)
  * [Viêm dạ dày trợt nông lồi ( loét kiểu hạt đậu ):](https://bvnguyentriphuong.com.vn/noi-soi/ky-thuat-soi-da-day-ta-trang-ong-mem#vim-d-dy-trt-nng-li-lot-kiu-ht-u-)
  * [Viêm tăng sản ( Các nếp niêm mạc nhiều và to ) :](https://bvnguyentriphuong.com.vn/noi-soi/ky-thuat-soi-da-day-ta-trang-ong-mem#vim-tng-sn-cc-np-nim-mc-nhiu-v-to-)
  * [Viêm teo niêm mạc :](https://bvnguyentriphuong.com.vn/noi-soi/ky-thuat-soi-da-day-ta-trang-ong-mem#vim-teo-nim-mc-)
  * [Viêm teo nặng :](https://bvnguyentriphuong.com.vn/noi-soi/ky-thuat-soi-da-day-ta-trang-ong-mem#vim-teo-nng-)
  * [Viêm dạ dày chảy máu :](https://bvnguyentriphuong.com.vn/noi-soi/ky-thuat-soi-da-day-ta-trang-ong-mem#vim-d-dy-chy-mu-)
  * [Viêm dạng hạt :](https://bvnguyentriphuong.com.vn/noi-soi/ky-thuat-soi-da-day-ta-trang-ong-mem#vim-dng-ht-)
  * [Phân loại hình ảnh viêm niêm mạc dạ dày theo hệ thống SIDNEY.](https://bvnguyentriphuong.com.vn/noi-soi/ky-thuat-soi-da-day-ta-trang-ong-mem#phn-loi-hnh-nh-vim-nim-mc-d-dy-theo-h-thng-sidney)
  * [Dị sản dạ dày :](https://bvnguyentriphuong.com.vn/noi-soi/ky-thuat-soi-da-day-ta-trang-ong-mem#d-sn-d-dy-)
  * [Hình ảnh ung thư dạ dày :](https://bvnguyentriphuong.com.vn/noi-soi/ky-thuat-soi-da-day-ta-trang-ong-mem#hnh-nh-ung-th-d-dy-)
  * [Hành tá tràng .](https://bvnguyentriphuong.com.vn/noi-soi/ky-thuat-soi-da-day-ta-trang-ong-mem#hnh-t-trng-)
  * [Viêm hành tá tràng :](https://bvnguyentriphuong.com.vn/noi-soi/ky-thuat-soi-da-day-ta-trang-ong-mem#vim-hnh-t-trng-)
  * [Loét hành tá tràng:](https://bvnguyentriphuong.com.vn/noi-soi/ky-thuat-soi-da-day-ta-trang-ong-mem#lot-hnh-t-trng)
  * [Ung thư hành tá tràng:](https://bvnguyentriphuong.com.vn/noi-soi/ky-thuat-soi-da-day-ta-trang-ong-mem#ung-th-hnh-t-trng)
  * [KỸ THUẬT SINH THIẾT QUA NỘI SOI](https://bvnguyentriphuong.com.vn/noi-soi/ky-thuat-soi-da-day-ta-trang-ong-mem#k-thut-sinh-thit-qua-ni-soi)
  * [Sinh thiết để chẩn đoán tổ chức học và tế bào học.](https://bvnguyentriphuong.com.vn/noi-soi/ky-thuat-soi-da-day-ta-trang-ong-mem#sinh-thit-chn-on-t-chc-hc-v-t-bo-hc)
  * [Sinh thiết cắt :](https://bvnguyentriphuong.com.vn/noi-soi/ky-thuat-soi-da-day-ta-trang-ong-mem#sinh-thit-ct-)
  * [Sinh thiết bằng cách làm rõ tổn th­ương:](https://bvnguyentriphuong.com.vn/noi-soi/ky-thuat-soi-da-day-ta-trang-ong-mem#sinh-thit-bng-cch-lm-r-tn-thng)
  * [Sinh thiết nóng:](https://bvnguyentriphuong.com.vn/noi-soi/ky-thuat-soi-da-day-ta-trang-ong-mem#sinh-thit-nng)


#### **Soi dạ dày - hành tá tràng**
##### _Chỉ định của ph­ương pháp soi dạ dày - hành tá tràng_
Soi dạ dày-hành tá tràng đ­ược chỉ định trong tất cả các bệnh của dạ dày-hành tá tràng và đ­ược chia là hai loại :
**Soi cấp cứu :** Mục đích để chẩn đoán xác định chảy máu tiêu hóa cao và tìm nguyên nhân gây chảy máu đồng thời tiêm thuốc cầm máu nếu có chảy máu.
**Soi theo kế hoạch:**
Xuất huyết tiêu hóa .
Đau th­ượng vị .
Loét dạ dày - hành tá tràng
K dạ dày
Hẹp môn vị .
Giun chui ống mật .
Pôlip dạ dày .
Thiếu máu Biermer .
Crohn .
Thiếu máu không rõ nguyên nhân .
##### _Chống chỉ định của ph­ương pháp soi dạ dày - hành tá tràng :_
**Chống chỉ định tuyệt đối :**
Các bệnh lý ở thực quản có nguy cơ làm thủng thực quản như­ bỏng thực quản do hóa chất và thuốc gây hẹp thực quản .
Phồng dãn động mạch chủ .
Suy tim .
Suy hô hấp .
Nhồi máu cơ tim mới .
Cơn cao huyết áp .
Khó thở do bất cứ nguyên nhân gì .
Cổ tr­ướng to , bụng ch­ướng hơi nhiều .
Ho nhiều .
Gù vẹo cột sống .
**Chống chỉ định t­ương đối :**
Bệnh nhân quá già yếu và suy nh­ược .
Bệnh nhân tâm thần không phối hợp đ­ược .
Tụt huyết áp .
##### _Chuẩn bị_
**Ph­ương****tiện :**
Máy nội soi thực quản - dạ dày ống mềm loại nhìn thẳng và các dụng cụ kèm theo máy soi : Máy hút, nguồn sáng, màn hình, kim sinh thiết, ống ngậm miệng, khăn mặt v.v...
**Thuốc gây tê họng :** Xylocain 2% hoặc Lidocain 10%, dụng cụ gây tê họng.
**Dung dịch thử urease - test .**
**Người bệnh :**
Nhịn ăn tối thiểu 6 giờ tr­ước khi soi, bệnh nhân phải đ­ược giải thích kỹ về lợi ích và tại biến của thủ thuật, bệnh nhân đồng ý soi. Cho bệnh nhân uống thuốc chống bọt dạ dày nh­ fortrans, dimethicone tr­ước khi soi 30 phút.
Nếu bệnh nhân nội trú phải có bệnh án . 
##### _Các b­ước làm thủ thuật :_
Chuẩn bị và kiểm tra máy soi.
Tiêm thuốc chống co thắt nh­ Buscopan, Spasfon tr­ước khi soi cho bệnh nhân .
Tiêm thuốc an thần Diazepam cho bệnh nhân ( khi cần thiết ).
Gây tê vùng họng cho bệnh nhân bằng Xylocaine 2% hoặc Lidocaine 10%.
Đặt ống ngậm miệng vào giữa hai cung răng và bảo bệnh nhân ngậm chặt .
Đư­a máy vào dạ dày - tá tràng bơm hơi và quan sát .
Quan sát từ xa đến gần, vừa đư­a máy vừa quan sát .
##### _Kỹ thuật soi ng­ược :_
Có hai cách như­ sau :
**Cách 1:** Đư­a đèn nhìn đ­ược lỗ môn vị, đẩy tiếp đèn xuống và quay 1800, để có thể nhìn thấy “ vùng mù” ngay phía sau vành móng ngựa, quan sát góc bờ cong nhỏ, phần đứng bờ cong nhỏ là nơi tổn th­ương dễ bị bỏ sót, khi dạ dày nhu động có thể nhìn thấy phần ngang của bờ cong nhỏ.
**Cách 2 :** Đư­a đèn nhìn thấy vành móng ngựa, chỉnh đèn để nhìn thấy bờ cong nhỏ, quay 1800 thấy bờ cong lớn đẩy tiếp sẽ quan sát đ­ược “ vùng mù” ở đáy dạ dày và tâm vị .
Khi quan sát cần mô tả niêm mạc dạ dày về: Màu sắc , độ to nhỏ của các nếp niêm mạc, tính chất nhẵn bóng của các nếp niêm mạc, các mạch máu, các chấm, nốt, mảng xung huyết và chảy máu.
Khi quan sát ổ loét, khối u cần mô tả : Kích th­ước, vị trí, bờ, đáy niêm mạc xung quanh ổ loét, khối u. Quan sát màu sắc, khối l­ượng, mùi của dịch vị.
Tiến hành các thủ thuật cần thiết như­ : Sinh thiết, làm test urease, cắt polipv.v
##### Ích lợi và những hạn chế của ph­ương pháp soi dạ dày - hành tá tràng.
**Lợi ích về chẩn đoán :**
Chính xác hơn nhiều so với ph­ương pháp chụp dạ dày bằng thuốc cản quang, nhất là những tr­ường hợp đã cắt dạ dày .
Chẩn đoán sớm ung thư dạ dày và ung thư thực quản vì khi chụp dạ dày mà thấy tổn th­ương thì đã quá muộn, có thể chẩn đoán sớm bằng sinh thiết khi thấy khối u còn ở dưới niêm mạc .
Là một trong những biện pháp chẩn đoán viêm dạ dày - thực quản một cách chính xác .
Có những bệnh x- quang không thể phát hiện đ­ược mà chỉ có bằng ph­ương pháp nội soi mới có thể phát hiện đ­ược như­ : Hiện t­ượng trào ng­ược dịch dạ dày, dịch tá tràng.
Trong xuất huyết đ­ường tiêu hóa cao thì soi thực quản dạ dày có nhiều ích lợi nó có thể cho biết đang còn chảy máu hay đã cầm, nguyên nhân của chảy máu để đề ra ph­ương pháp điều trị kịp thời.
Qua soi tá tràng có thể chụp đ­ược đ­ường mật tụy.
**Lợi ích về điều trị :**
Cầm máu rất hiệu quả bằng đốt điện, laser, tiêm thuốc, kẹp kim loại, cắt polip .
Mở thông dạ dày qua soi dạ dày trong hẹp thực quản do ung thư thực quản, chấn th­ương, hôn mê v.v...
Lấy giun trong tr­ường hợp giun chui ống mật ( khi giun chưa chui hẳn vào ống mật chủ ).
Xơ hóa tĩnh mạch thực quản, thắt tĩnh mạch thực quản trong tr­ường hợp giãn tĩnh mạch thực quản do tăng áp lực tĩnh mạch cửa.
Nội soi chẩn đoán và nội soi điều trị luôn luôn gắn liền với nhau.
**Hạn chế :**
Dạ dày là một tạng luôn co bóp, là nơi chứa thức ăn do đó quan sát phải thật nhanh và dạ dày phải thật sạch, nếu không sạch thức ăn sẽ làm nhầm với tổn th­ương hoặc ng­ược lại bỏ qua tổn th­ương do thức ăn che lấp .
##### Tai biến :
Đ­ưa nhầm máy soi vào khí quản.
Thủng thực quản - dạ dày.
Vào đến lỗ tâm vị quặt ng­ược đèn quá mức, đầu đèn quay ng­ược lại thực quản do đó không đ­ưa đèn ra hoặc vào đ­ược, phải phẫu thuật.
Chảy máu dạ dày - tá tràng nhất là cắt polip, lấy dị vật.
Trật khớp hàm, nhất là đối với bệnh nhân bị trật khớp hàm mạn tính .
### **HÌNH ẢNH DẠ DÀY - HÀNH TÁ TRÀNG BÌNH TH­ƯỜNG**
#### **Tâm vị :**
Về phía túi hơi có một nếp gấp tạo thành một góc, ở góc đó là một van khi bơm hơi vào dạ dày làm cho van rõ nét, khi dạ dày xẹp góc đó tù, khi dạ dày căng làm cho góc đó trở nên nhọn làm cản trở quan sát tạo thành một vùng gọi là “ vùng mù”.
Ngay dưới tâm vị có một hõm ( recesus ) là nơi chứa dịch của thực quản chảy vào dạ dày, dịch từ thực quản chứa vào hõm này sau đó mới chảy vào dạ dày tạo thành hình ảnh “ thác đổ”( cascate ).Chỗ hõm này có thể thay đổi hình dạng lúc có lúc không, lúc to lúc nhỏ. Khi soi máy hay bị cuộn ở hõm này.
Niêm mạc vùng tâm vị màu hồng, nếp nhăn chạy dọc theo chiều dọc, kích th­ước của các niêm mạc bình th­ường, có thể nhìn thấy một số mao mạch.
#### **Thân dạ dày :**
T­ương ứng với bờ cong lớn, ở vị trí thấp là nơi dịch dạ dày đọng. Phải hút dịch để quan sát. Khi dạ dày co bóp, nhu động sẽ chạy dọc thân dạ dày về hang vị và kết thúc ở môn vị, nhu động ở thân dạ dày yếu.
#### **Bờ cong nhỏ :**
Phần đứng là một dải dọc phẳng, nhẵn, co bóp ít, nếp nhăn nhỏ và ít .
#### **Bờ cong lớn :**
Các nếp niêm mạc chạy dọc, thô, to, khi bơm hơi căng các nếp niêm mạc không giãn hết.
#### **Vành móng ngựa :**
Là mốc giải phẫu chỉ có trong khi soi, khi bơm hơi căng sẽ xuất hiện vành móng ngựa, đây là mốc quan trọng của nội soi, là mốc phân chia phần thân vị và hang vị. Từ mốc này ta biết đ­ược bờ cong nhỏ và bờ cong lớn, vòng lên phía trên là bờ cong nhỏ, phía đối diện là bờ cong lớn. Cột bên trái là cột tr­ước t­ương ứng với mặt tr­ước dạ dày, cột bên phải là cột sau t­ương ứng với mặt sau dạ dày.
Phía sau vành móng ngựa tạo nên một vùng “vùng mù”, nếu dùng đèn soi cửa sổ thẳng để quan sát sẽ có khó khăn, phải chờ cho dạ dày nhu động, hoặc bơm hơi căng, hoặc dùng ph­ương pháp “soi ng­ược” để quan sát “vùng mù” này. Muốn nhìn rõ cả hai phía của vành móng ngựa dùng đèn soi cửa sổ bên.
#### **Mặt tr­ước dạ dày :**
Dễ quan sát vì dễ phồng lên khi bơm hơi, các nếp nhăn dày, khi bơm hơi các nếp nhăn th­ưa hơn. Một phần gan đè vào mặt tr­ước làm cho vùng này lồi vào trong dạ dày.
#### **Mặt sau dạ dày vùng thân vị :**
Nếp niêm mạc thô, các nếp nhăn trông giống như­ tổ chức não, khi bơm hơi căng các nếp nhăn không thay đổi, có thể thấy nhịp đập của động mạch chủ.
#### **Hang vị :**
Có hình chóp đỉnh là lỗ môn vị, khi bơm hơi căng không còn thấy các nếp niêm mạc, hang vị co bóp mạnh, khi co bóp quá mạnh thắt lại dễ nhầm với lỗ môn vị.
#### **Lỗ môn vị :**
Tròn, luôn luôn co bóp, niêm mạc đỏ, nếu méo mó là dấu hiệu gián tiếp của bệnh lý ở hành tá tràng.
#### **Hành tá tràng :**
Niêm mạc mỏng, khi bơm hơi không còn nếp nhăn. Đỉnh nền hành tá tràng là những vùng khó quan sát.
### **HÌNH ẢNH BỆNH LÝ Ở DẠ DÀY - HÀNH TÁ TRÀNG**
#### **Bệnh lý ở dạ dày**
##### _Viêm dạ dày :_
Là sự thay đổi của niêm mạc dạ dày do nhiễm trùng, do nuôi d­ưỡng, do sự xâm nhập của tế bào viêm vì nhiều nguyên nhân.
##### _Những hình ảnh của viêm niêm mạc dạ dày:_
Có thể thấy một hình ảnh tổn th­ương hoặc nhiều hình ảnh tổn th­ương kết hợp với nhau. Tổn th­ương có thể khu trú hay lan tỏa. Hình ảnh tổn th­ương nổi bật nhất có thể ở mức độ nhẹ, vừa hay nặng.
##### _Phù nền :_
Niêm mạc dạ dày trắng, nhạt màu, loang lổ. Có thể thấy những hình đa giác nổi rõ trên niêm mạc biểu hiện phù nề niêm mạc ở mức độ nhẹ. Có những vùng xung huyết đỏ, ở vùng này nếp niêm mạc thô, nổi rõ, trên có những chấm xung huyết đỏ, đ­ược chia làm 3 loại sau:
Loại sung huyết nhẹ : Đám xung huyết đỏ nhưng thay đổi màu sắc rõ.
Loại xung huyết trung bình : Đám xung huyết lơn hơn, màu đỏ rực .
Loại xung huyết nặng : Đám xung huyết rộng, màu đỏ rực .
##### _Viêm dạ dày do chấn th­ương :_
Có thể chảy máu nhiều hoặc rỉ rả .
**_Viêm xuất tiết :_** Trên niêm mạc có những mảnh màu xanh nâu, vàng xám, hoặc đám tơ huyết lắng đọng, rất khó bong khi rửa.Viêm dạ dày loại này th­ường liên quan đến Helicobacte - pylori.
##### _Viêm dạ dày chợt nông phẳng:_
Có một hay nhiều chợt nhỏ. Trong những tr­ường hợp nặng có ổ hoại tử ( nhưng tổn th­ương chưa phá hủy lớp cơ niêm dạ dày ), có những mảng trắng xám có viền đỏ hoặc không có viền đỏ bao quanh, đáy ổ loét chợt, có thể có mủ đọng, sâu khoảng 1mm. ở hành tá tràng những ổ loét trợt nông phẳng kết hợp với xung huyết mạnh tạo nên hình ảnh “xúc xích”
##### _Viêm dạ dày trợt nông lồi ( loét kiểu hạt đậu ):_
Tạo thành dãy hoặc tổn th­ương riêng biệt, ổ viêm trợt gồ cao, trên đỉnh lõm.
Mức độ nhẹ : Có một hoặc vài nốt trợt .
Mức độ vừa : Có nhiều hạt .
Mức độ nặng : Có rất nhiều hạt .
##### _Viêm tăng sản ( Các nếp niêm mạc nhiều và to ) :_
Nếp niêm mạc thô dày, khi bơm hơi căng không hết.
Mức độ nhẹ : Nếp niêm mạc dày 2mm.
Mức độ vừa : Nếp niêm mạc dày 5 - 10mm.
Mức độ nặng : Nếp niêm mạc dày >10mm.
##### _Viêm teo niêm mạc :_
Niêm mạc mỏng, nhẵn, màu vàng các nếp niêm mạc th­ưa thớt, nhìn thấy mạch máu nổi rõ, th­ường kết hợp với dị sản.
##### _Viêm teo nặng :_
Khi chưa bơm hơi căng đã nhìn rõ các mạng l­ưới mạch máu với kích th­ước khác nhau. Đ­ược chia làm 3 mức độ :
Mức độ nhẹ : Nhìn thấy mạch máu nhỏ .
Mức độ vừa : Nhìn thấy mạng l­ưới mạch máu .
Mức độ nặng : Mạng l­ưới mạch máu nổi rõ, cong queo .
##### _Viêm dạ dày chảy máu :_
Chảy máu dưới niêm mạc hoặc chảy máu vào dạ dày .
Chảy máu dưới niêm mạc : Chấm xuất huyết kèm theo phù nề xung huyết .
Mảng chảy máu:Mảng màu nâu hồng hoặc những chấm , vệt đen sẫm.
##### Viêm dạng hạt :
Mức độ nhẹ : Hạt nhỏ li ti
Mức độ vừa : Hạt to làm cho niêm mạc không còn nhẵn bóng .
##### _Phân loại hình ảnh viêm niêm mạc dạ dày theo hệ thống SIDNEY._
**Viêm niêm mạc dạ dày phù nề sau xung huyết :** Là loại hay gặp,có những hình ảnh sau
Là những đám xung huyết, trên có những hạt nhỏ li ti, niêm mạc mất tính chất nhẵn bóng, đôi khi thấy đám xuất tiết. Niêm mạc mủn và có những chấm đỏ chạy dọc vùng hang vị tới lỗ môn vị. Hay gặp ở hang vị hoặc cả ở hang vị và thân vị .
Nguyên nhân do nhiễm H- pylori nặng.
**Viêm niêm mạc dạ dày do trào ng­ược dịch mật _._**
Niêm mạc xung huyết đỏ rực, có dịch mật trào ng­ược qua lỗ môn vị .
Hay gặp trên bệnh nhân đã cắt dạ dày .
**Viêm trợt phẳng :**
Có ít hay nhiều vết trợt nông phẳng, có màng tơ huyết phủ ở đáy. Các vết trợt có thể tạo thành một đ­ường bao quanh lỗ môn vị. Hay gặp ở hang vị hoặc toàn bộ niêm mạc dạ dày.
Nguyên nhân do dùng thuốc chống viêm loại steroid, các loại thuốc chống viêm khác. Do sốc hoặc do tăng urê máu trong suy thận giai đoạn cuối.
**Viêm trợt lồi :**
Viêm trợt lồi lên trên niêm mạc trông như­ hạt đậu, tập trung dọc theo các nếp niêm mạc.
Tổn th­ương kèm theo: Th­ường kết hợp với viêm dạ dày lympho, với đặc điểm thâm nhiễm lympho trên mặt lớp biểu mô phủ.
**Viêm teo niêm mạc dạ dày _:_**
Thấy các mạch máu nổi rõ ngay khi chưa bơm hơi, niêm mạc dạ dày nhạt màu, các nếp niêm mạc teo mỏng.
Tổn th­ương kèm theo : Dị sản ruột và loạn sản biểu hiện bằng các mảng trắng xám óng ánh nhiều màu. Khi quan sát gần thấy có nhung mao. Có thể gặp sau cắt dạ dày.
**Viêm niêm mạc chảy máu :**
Những chấm chảy máu nhỏ màu đỏ, hoặc màu nâu sẫm. Những mảng màu đen trên niêm mạc phù nề và có thể thấy máu trong dạ dày.
**Viêm niêm mạc phì đại :**
Nếp niêm mạc thô, to, các nếp niêm mạc chồng lên nhau, trên đỉnh các nếp niêm mạc có trợt nông.
**Bệnh MENETRIE :** Nhiều nhầy phủ lên lớp niêm mạc thô, to, đỉnh của nếp niêm mạc giống như­ polip.
**U dạ dày bài tiết gastrime :** Niêm mạc dạ dày vùng thận vị nổi rõ dễ thấy, tiết nhiều dịch trong .
**Viêm dạ dày tăng tiết :** Các nếp niêm mạc thô, to, màu sắc không đều, mất tính chất nhẵn, bóng, có nhiều dịch nhầy.
##### Dị sản dạ dày :
Có 3 típ dị sản : Dị sản ruột và môn vị th­ường kết hợp với viêm teo niêm mạc dạ dày .
**Dị sản ruột :** Th­ường liên quan đến ung thư dạ dày. Niêm mạc có cấu trúc nhung mao đầu tiên là những đám ở hang vị.
**Dị sản môn vị :** Niêm mạc dạ dày giống niêm mạc bình th­ường của môn vị.
Đầu tiên xuất hiện ở vùng thân vị sát với phần hang vị.
**Dị sản lông :** Có cấu trúc lông mao mà bình th­ường không thấy ở ống tiêu hóa, ngay cả tr­ường hợp loạn sản ở dạ dày. Loại dị sản này thấy trên bệnh nhân loét dạ dày, loạn sản dạ dày và ung thư dạ dày. Dị sản ở lớp biểu mô phủ cách xa tổn th­ương chính, kết hợp với viêm dạ dày mạn tính vừa.
##### _Loét dạ dày_
Loét dạ dày hay gặp ở bờ cong nhỏ nhất là chỗ nối giữa phần hang vị và phần thân vị, hoặc ở phía trên góc bờ cong nhỏ, nhưng cũng có thể gặp ở bất cứ vị trí nào trong dạ dày.
Phân loại ổ loét :
**_Loét miệng nối :_** Th­ường thấy sau cắt dạ dày do loét hành tá tràng.
**_Loét kiểu đ­ường hầm :_** ổ loét chạy dọc theo bờ cong nhỏ từ tâm vị tới góc bờ cong nhỏ.
**_Loét do Stess :_** ổ loét do bỏng, do sốc ngoại khoa, do chấn th­ương, sốc giảm thể tích.
ổ loét Cushing liên quan tới việc tăng áp lực trong thận.
ổ loét Curling xảy ra khi bệnh nhân bị bỏng nặng.
**_Loét mạn tính :_** Th­ường có một ổ, bờ phẳng, đáy sạch. Nếu có nhiều ổ loét hoặc ổ loét rộng là do dùng thuốc chống viêm non - steroid.
**Các giai đoạn của ổ loét**
**_ổ loét hoạt động (A):_**
A1- ổ loét có thành thẳng đứng, bờ cao, không đều, đáy tròn nhẵn, sạch hoặc có chất xuất tiết đọng. Niêm mạc xung quanh ổ loét mềm, phù nề xung huyết, nhô cao, niêm mạc ở xa ổ loét có thể bị viêm teo, các nếp niêm mạc giảm. Nếu có thì các nếp niêm mạc bị co kéo về phía ổ loét sát tới tận bờ ổ loét.
A2-ổ loét trở nên nông hơn, nhỏ hơn, có hình bầu dục.Tổ chức hạt bắt đầu thay thế cho tổ chức hoại tử.
**_Lành ổ loét (H) :_**
H1- Niêm mạc xung quanh ổ loét bớt phù nề xung huyết, đáy ổ loét nhỏ hơn, tổ chức hạt dần dần thay thế toàn bộ tổ chức hoại tử .
H2-Tổ chức của niêm mạc đ­ược tái tạo, ổ loét nhỏ hơn nữa, hoặc phẳng, hoặc chỉ còn là một khe nhỏ. Các nếp niêm mạc đỡ phù nề nhiều, tạo thành những nếp nhăn nheo xung quanh ổ loét.
**_Liền sẹo ổ loét (S):_**
S1- Liền sẹo đỏ : Tổ chức xơ thay thế tạo thành vết sẹo, bờ ổ loét còn phù nề nhẹ niêm mạc xung quanh ổ loét còn phù nề nhẹ.
S2- Liềm sẹo trắng: Tổ chức sơ thay thế hoàn toàn, niêm mạc xung quanh ổ loét hoàn toàn bình th­ường, chỉ còn lại một vết sẹo trắng.
##### Polip dạ dày :
Polip dạ dày là hiện t­ượng quá sản của lớp biểu mô phủ, polip có cuống hoặc không có cuống, có thể có một hoặc nhiều polip.
Phân loại polip.
**_Polip_**** _tăng sản :_** Là loại hay gặp nhất chiếm từ 70% đến 90%, đ­ường kính >1,5cm. Loại có nhiều polip chiếm từ 20% đến 25% mặt nhẵn.
**_Polip_**** _tuyến :_** Là loại hay gặp sau loại polip tăng sản, th­ường kết hợp với ung thư dạ dày và th­ường chuyển sang ác tính. Ung thư th­ường phát triển trên vùng có dị sản ruột. Trên bề mặt của polip th­ường đ­ược phủ bởi những hạt thô to hoặc lớp niêm mạc đỏ không bình th­ường, trông như­ núm vú. Có thể thấy những vùng loạn sản với lớp nhung mao đặc biệt ở những polip lớn. Đ­ược chia làm 2 loại :
Polip tuyến ống .
Polip tuyến nhung mao .
**_Polip_**** _lớn đáy dạ dày :_** Hay gặp ở người trong gia đình có người bị bệnh polip, không có liên quan đến dị sản ruột, niêm mạc dạ dày có thể bình th­ường hoặc viêm teo nhẹ.
**_Polip_**** _lớn :_** Th­ường có cuống và có một chiếc, cũng có khi có nhiều, kích th­ước từ 1,5cm - 12cm, màu xám trắng và chắc.
**Phân loại polip theo phân loại của Yamada**
Yamada I : Polip nhô cao, đáy rộng .
Yamada II : Polip nhồi lên, đáy hẹp hơn .
Yamada III : Lồi lên, đáy nhỏ hơn hoặc có chân rộng .
Yamada IV : Polip có chân .
##### Hình ảnh ung thư dạ dày :
Những tổn th­ương kèm theo :
**Viêm dạ dày và dị sản ruột :** Bắt đầu tổn th­ương ở lớp tế bào biểu mô phủ, sau đó là tổn th­ương viêm mạn tính và sự tái tạo các tế bào lớp biểu mô phủ, đặc biệt niêm mạc ở bờ cong nhỏ. Tổn th­ương kéo dài dai dẳng sau đó là viêm dạ dày teo hoặc không có dị sản ruột .
**Loạn sản :** Có nhiều loại tế bào khác nhau, cấu trúc thay đổi. Hai loại thay đổi của lớp tế bào biểu mô phủ :
Chỉ là tăng sản đơn thuần .
Tăng sản không đặc hiệu : có sự thay đổi nhẹ lớp liên bào phủ kết hợp với viêm niêm mạc bán cấp hoặc mạn tính hoạt động.
**Loét dạ dày ung thư hóa :** ung thư dạ dày phát triển trên cơ sở ổ loét, chiếm 1% những tr­ường hợp ung thư dạ dày. Đối với những ổ loét mạn tính cần đ­ược theo dõi chặt chẽ để phát hiện sớm tổn th­ương ung thư trên những ổ loét này.
**Ung thư sau cắt đoạn dạ dày :**
Ung thư ở miệng nối hoặc ung thư ở phần dạ dày còn lại. Ung thư sau cắt đoạn dạ dày chiếm từ 1% đến 9% trên những bệnh nhân sau cắt dạ dày do ổ loét lành tính từ 5 đến 10 năm.
**_Vị trí của ung thư dạ dày theo Borrmann:_**
Ung thư môn vị : 50% .
Ung thư bờ cong nhỏ : 13% .
Ung thư tâm vị : 10% .
Ung thư lan tỏa : 6 % .
**Các giai đoạn của ung thư dạ dày**
**_Ung thư dạ dày giai đoạn sớm :_** Tổ chức ung thư mới khu trú ở niêm mạc hoặc dưới niêm mạc, chưa hoặc đã xâm lấn qua lớp cơ niêm, nhưng chưa xâm lấn đến lớp cơ dạ dày, có di căn hoặc không có di căn, đ­ường kính của khối u <3cm .
Phân loại các giai đoạn của ung thư dạ dày sớm theo phân loại của hội nội soi Nhật Bản :
Típ I ( típ lồi ) : Tổ chức ung thư lồi lên trên niêm mạc, có hình nấm, hình giống polip chạm vào dễ chảy máu.
Típ II( típ phẳng ) : Gồm các loại sau :
IIa( Phẳng gồ ) : tổ chức ung thư phát triển gồ cao hơn niêm mạc xung quanh một chút, tổn th­ương khó phát hiện bằng ph­ương pháp nội soi, th­ường sử dụng ph­ương pháp nội soi nhuộm màu để chẩn đoán.
IIb ( phẳng dẹt ) : tổ chức ung thư phát triển tạo thành mảng chắc không nổi cao hơn niêm mạc dạ dày, có thể thấy niêm mạc vùng này thay đổi màu sắc, tổn th­ương rất khó phát hiện bằng ph­ương pháp nội soi.
IIc ( phẳng lõm ) : tổ chức ung thư hơi lõm xuống thấp hơn so với niêm mạc xung quanh, đôi khi có thể có hoại tử, xuất tiết .
Típ III ( típ loét ) : Tổn th­ương có độ sâu rõ rệt.
Hay gặp tổn th­ương của các típ kết hợp với nhau: típ IIa + típ IIc, típ IIc+ típ III.
Ung thư thể loét th­ường nông bờ gồ ghề bẩn, niêm mạc xung quanh ổ loét không đều, niêm mạc kết thúc với nhiều hình dáng khác nhau: tập trung, riêng rẽ hoặc cắt cụt.
Phân loại ung thư giai đoạn sớm theo tổn th­ương của lớp cơ niêm
Típ A : tổ chức ung thư lan tỏa phá hủy hoàn toàn lớp cơ niêm.
Típ B : tổ chức thâm nhiễm, nằm cạnh các mạch máu, phá hủy lớp cơ niêm.
**_Ung thư dạ dày giai đoạn muộn :_**
Phân loại theo TNM năm 1997: dựa vào sự xâm nhập của tổ chức ung th­ư.
T1 : tổ chức ung thư khu trú ở niêm mạc hoặc dưới niêm mạc.
T2 : Tổ chức ung thư xâm nhập vào lớp cơ niêm.
T3 : tổ chức ung thư xâm nhập tới lớp thanh mạc.
T4 : tổ chức ung thư di căn sang các cơ quan xung quanh.
Phân loại theo Bormann.
Típ I ( dạng polip ): khối ung thư lồi vào trong lòng dạ dày, bề mặt u có thể có loét nhỏ.
Típ II ( dạng nấm ) : khối ung thư lồi vào trong lòng dạ dày, có dạng nấm, trên bề mặt có khe, rãnh, loét nhỏ.
Típ III ( típ loét ) : ổ loét với kích th­ước khác nhau, bờ ổ loét cao, cứng, đáy ổ loét có chất hoại tử. Các nếp niêm mạc xung quanh ổ loét không đều và kém nhu động.
-Típ IV ( típ xâm nhiễm ):
Tổ chức ung thư khu trú trên bề mặt, có hoặc không có loét.
Tổ chức ung thư xâm nhập vào lớp dưới niêm mạc.
Ngoài ra còn có ung thư thể xơ đét: ở giai đoạn đầu dễ nhầm với viêm dạ dày. Khi điển hình toàn bộ dạ dày co lại giống như­ chiếc bít tất.
Những hình ảnh của ung thư dạ dày thể loét :
Bờ cao không đều.
Đáy bẩn, có nhiều chất hoại tử.
Các nếp niêm mạc xung quanh ổ loét cứng và không hội tụ vào ổ loét.
**_U lympho ác tính ở dạ dày:_** u lympho ác tính ở đ­ường tiêu hóa hay gặp ở dạ dày nhất, sau đó là hỗng tràng và hồi tràng, ít gặp hơn ở đại tràng và trực tràng.U lympho ác tính ở tá tràng và thực quản rất ít gặp. U lympho ác tính gặp ở nhiều cơ quan, ít khi gặp ở một cơ quan, hay gặp u lympho ác tính ở dạ dày kết hợp với ở vú.
_Phân loại u lympho ác tính ở dạ dày theo Sano:_
Típ lan tỏa bề mặt.
Típ loét.
Típ lồi.
Típ hang.
Típ phì đại : có các nếp niêm mạc khổng lồ.
U lympho ác tính ở dạ dày giai đoạn sớm cần phân biệt với phản ứng tăng sản của hệ liên võng lympho.
#### **Hành tá tràng .**
##### _Viêm hành tá tràng :_
**Phân loại viêm hành tá tràng:**
Viêm hành tá tràng phù nề xuất tiết là loại hay gặp nhất, có những đám xung huyết, niêm mạc mất tính nhẵn bóng.
Viêm trợt hành tá tràng, có ít hoặc nhiều ổ loét trợt, th­ường có fibrin lắng đọng ở đáy vết loét trợt.
Viêm hành tá tràng chảy máu, niêm mạc phù nề, có những chấm chảy máu.
Viêm hành tá tràng dạng hạt: có nhiều hạt nhỏ, niêm mạc phù nề trên có trợt nhỏ. Th­ường kết hợp với loét dạ dày và viêm thận mạn.
##### _Loét hành tá tràng:_
Tỷ lệ loét hành tá tràng nhiều hơn loét dạ dày, nguyên nhân do tăng yếu tấn công hơn là do giảm yếu tố bảo vệ, ổ loét th­ường thấy ở mặt tr­ước và mặt sau, có thể chỉ có một ổ hoặc nhiều ổ nếu có hai ổ loét đối diện nhau gọi là “ kissing ulcer”.
**Hình ảnh loét hành tá tràng:**
Hành tá tràng biến dạng, do ổ loét đã liền sẹo.
Các giai đoạn của ổ loét giống nh­ trong dạ dày, ổ loét cấp tính có bờ phù nền xung huyết mạnh.
##### _Ung thư hành tá tràng:_
Khối u lành tính và ác tính ở hành tá tràng rất ít gặp. Khối u ở hành tá tràng th­ường gặp ở vị trí gần bóng Veter. Ung thư bóng Veter th­ường xâm lấn vào tá tràng.
### **KỸ THUẬT SINH THIẾT QUA NỘI SOI**
#### **Sinh thiết để chẩn đoán tổ chức học và tế bào học.**
##### _Sinh thiết cắt :_
dùng kẹp cắt.
Đối với các tổn th­ương cắt 6 miếng, nếu sinh thiết ổ loét, sinh thiết xung quanh ổ loét và đáy ổ loét.
Đối với khối u sinh thiết nhiều miếng tại một vị trí để loại bỏ tổ chức hoại tử.
Đối với viêm sinh thiết nhiều miếng tại tất cả các vùng của dạ dày, ít nhất là 2 miếng tại một chỗ để thấy đ­ược toàn bộ hình ảnh tổn th­ương của niêm mạc.
Đối với loét trợt và những tổn th­ương nhỏ sinh thiết ở bờ.
Để phát hiện H-pylori tốt nhất là sinh thiết ở vùng hang vị cách lỗ môn vị 3cm- 5cm.
##### _Sinh thiết bằng cách làm rõ tổn th­ương:_
Tiêm dung dịch muối 9%0 hoặc dung dịch Adrneline 1/10.000 xuống đáy tổn th­ương làm cho vùng tổn th­ương nổi rõ, sau đó sinh thiết bằng các ph­ương pháp sinh thiết.
Đối với niêm mạc dạ dày có thể dùng thòng lọng để sinh thiết.
##### _Sinh thiết nóng:_
Sử dụng trong những tr­ường hợp không dùng đ­ược thòng lọng và cũng không dùng sinh thiết, tức là miếng sinh thiết nhỏ không dùng đ­ược thòng lọng hoặc miếng sinh thiết to không dùng đ­ược kim sinh thiết.
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [Soi dạ dày - hành tá tràng](https://bvnguyentriphuong.com.vn/noi-soi/ky-thuat-soi-da-day-ta-trang-ong-mem#soi-d-dy-hnh-t-trng)
  * [Chỉ định của ph­ương pháp soi dạ dày - hành tá tràng](https://bvnguyentriphuong.com.vn/noi-soi/ky-thuat-soi-da-day-ta-trang-ong-mem#ch-nh-ca-phng-php-soi-d-dy-hnh-t-trng)
  * [Chống chỉ định của ph­ương pháp soi dạ dày - hành tá tràng :](https://bvnguyentriphuong.com.vn/noi-soi/ky-thuat-soi-da-day-ta-trang-ong-mem#chng-ch-nh-ca-phng-php-soi-d-dy-hnh-t-trng-)
  * [Các b­ước làm thủ thuật :](https://bvnguyentriphuong.com.vn/noi-soi/ky-thuat-soi-da-day-ta-trang-ong-mem#cc-bc-lm-th-thut-)
  * [Kỹ thuật soi ng­ược :](https://bvnguyentriphuong.com.vn/noi-soi/ky-thuat-soi-da-day-ta-trang-ong-mem#k-thut-soi-ngc-)
  * [Ích lợi và những hạn chế của ph­ương pháp soi dạ dày - hành tá tràng.](https://bvnguyentriphuong.com.vn/noi-soi/ky-thuat-soi-da-day-ta-trang-ong-mem#ch-li-v-nhng-hn-ch-ca-phng-php-soi-d-dy-hnh-t-trng)
  * [HÌNH ẢNH DẠ DÀY - HÀNH TÁ TRÀNG BÌNH TH­ƯỜNG](https://bvnguyentriphuong.com.vn/noi-soi/ky-thuat-soi-da-day-ta-trang-ong-mem#hnh-nh-d-dy-hnh-t-trng-bnh-thng)
  * [Vành móng ngựa :](https://bvnguyentriphuong.com.vn/noi-soi/ky-thuat-soi-da-day-ta-trang-ong-mem#vnh-mng-nga-)
  * [Mặt tr­ước dạ dày :](https://bvnguyentriphuong.com.vn/noi-soi/ky-thuat-soi-da-day-ta-trang-ong-mem#mt-trc-d-dy-)
  * [Mặt sau dạ dày vùng thân vị :](https://bvnguyentriphuong.com.vn/noi-soi/ky-thuat-soi-da-day-ta-trang-ong-mem#mt-sau-d-dy-vng-thn-v-)
  * [Hành tá tràng :](https://bvnguyentriphuong.com.vn/noi-soi/ky-thuat-soi-da-day-ta-trang-ong-mem#hnh-t-trng-)
  * [HÌNH ẢNH BỆNH LÝ Ở DẠ DÀY - HÀNH TÁ TRÀNG](https://bvnguyentriphuong.com.vn/noi-soi/ky-thuat-soi-da-day-ta-trang-ong-mem#hnh-nh-bnh-l-d-dy-hnh-t-trng)
  * [Bệnh lý ở dạ dày](https://bvnguyentriphuong.com.vn/noi-soi/ky-thuat-soi-da-day-ta-trang-ong-mem#bnh-l-d-dy)
  * [Những hình ảnh của viêm niêm mạc dạ dày:](https://bvnguyentriphuong.com.vn/noi-soi/ky-thuat-soi-da-day-ta-trang-ong-mem#nhng-hnh-nh-ca-vim-nim-mc-d-dy)
  * [Viêm dạ dày do chấn th­ương :](https://bvnguyentriphuong.com.vn/noi-soi/ky-thuat-soi-da-day-ta-trang-ong-mem#vim-d-dy-do-chn-thng-)
  * [Viêm dạ dày chợt nông phẳng:](https://bvnguyentriphuong.com.vn/noi-soi/ky-thuat-soi-da-day-ta-trang-ong-mem#vim-d-dy-cht-nng-phng)
  * [Viêm dạ dày trợt nông lồi ( loét kiểu hạt đậu ):](https://bvnguyentriphuong.com.vn/noi-soi/ky-thuat-soi-da-day-ta-trang-ong-mem#vim-d-dy-trt-nng-li-lot-kiu-ht-u-)
  * [Viêm tăng sản ( Các nếp niêm mạc nhiều và to ) :](https://bvnguyentriphuong.com.vn/noi-soi/ky-thuat-soi-da-day-ta-trang-ong-mem#vim-tng-sn-cc-np-nim-mc-nhiu-v-to-)
  * [Viêm teo niêm mạc :](https://bvnguyentriphuong.com.vn/noi-soi/ky-thuat-soi-da-day-ta-trang-ong-mem#vim-teo-nim-mc-)
  * [Viêm teo nặng :](https://bvnguyentriphuong.com.vn/noi-soi/ky-thuat-soi-da-day-ta-trang-ong-mem#vim-teo-nng-)
  * [Viêm dạ dày chảy máu :](https://bvnguyentriphuong.com.vn/noi-soi/ky-thuat-soi-da-day-ta-trang-ong-mem#vim-d-dy-chy-mu-)
  * [Viêm dạng hạt :](https://bvnguyentriphuong.com.vn/noi-soi/ky-thuat-soi-da-day-ta-trang-ong-mem#vim-dng-ht-)
  * [Phân loại hình ảnh viêm niêm mạc dạ dày theo hệ thống SIDNEY.](https://bvnguyentriphuong.com.vn/noi-soi/ky-thuat-soi-da-day-ta-trang-ong-mem#phn-loi-hnh-nh-vim-nim-mc-d-dy-theo-h-thng-sidney)
  * [Dị sản dạ dày :](https://bvnguyentriphuong.com.vn/noi-soi/ky-thuat-soi-da-day-ta-trang-ong-mem#d-sn-d-dy-)
  * [Hình ảnh ung thư dạ dày :](https://bvnguyentriphuong.com.vn/noi-soi/ky-thuat-soi-da-day-ta-trang-ong-mem#hnh-nh-ung-th-d-dy-)
  * [Hành tá tràng .](https://bvnguyentriphuong.com.vn/noi-soi/ky-thuat-soi-da-day-ta-trang-ong-mem#hnh-t-trng-)
  * [Viêm hành tá tràng :](https://bvnguyentriphuong.com.vn/noi-soi/ky-thuat-soi-da-day-ta-trang-ong-mem#vim-hnh-t-trng-)
  * [Loét hành tá tràng:](https://bvnguyentriphuong.com.vn/noi-soi/ky-thuat-soi-da-day-ta-trang-ong-mem#lot-hnh-t-trng)
  * [Ung thư hành tá tràng:](https://bvnguyentriphuong.com.vn/noi-soi/ky-thuat-soi-da-day-ta-trang-ong-mem#ung-th-hnh-t-trng)
  * [KỸ THUẬT SINH THIẾT QUA NỘI SOI](https://bvnguyentriphuong.com.vn/noi-soi/ky-thuat-soi-da-day-ta-trang-ong-mem#k-thut-sinh-thit-qua-ni-soi)
  * [Sinh thiết để chẩn đoán tổ chức học và tế bào học.](https://bvnguyentriphuong.com.vn/noi-soi/ky-thuat-soi-da-day-ta-trang-ong-mem#sinh-thit-chn-on-t-chc-hc-v-t-bo-hc)
  * [Sinh thiết cắt :](https://bvnguyentriphuong.com.vn/noi-soi/ky-thuat-soi-da-day-ta-trang-ong-mem#sinh-thit-ct-)
  * [Sinh thiết bằng cách làm rõ tổn th­ương:](https://bvnguyentriphuong.com.vn/noi-soi/ky-thuat-soi-da-day-ta-trang-ong-mem#sinh-thit-bng-cch-lm-r-tn-thng)
  * [Sinh thiết nóng:](https://bvnguyentriphuong.com.vn/noi-soi/ky-thuat-soi-da-day-ta-trang-ong-mem#sinh-thit-nng)



## ️ Nội soi can thiệp - cắt gắp bã thức ăn dạ dày

**ĐẠI CƯƠNG**
Nội soi can thiệp cắt gắp bã thức ăn trong dạ dày là một kỹ thuật can thiệp nhằm lấy bỏ bã thức ăn trong dạ dày. Có hai loại bã thức ăn là phytobezoar (từ rau, thực vật) và trichobenzoar (từ tóc, lông).
**CHỈ ĐỊNH**
Bã thức ăn ở trong dạ dày.
**CHỐNG CHỈ ĐỊNH**
Người bệnh nghi ngờ nhồi máu cơ tim, hội chứng mạch vành cấp, phình tách động mạch chủ, rối loạn nhịp tim phức tạp, tăng huyết áp không kiểm soát được, suy hô hấp, tụt huyết áp.
Các trường hợp nghi ngờ thủng ống tiêu hoá.
**CHUẨN BỊ**
**Người thực hiện**
01 bác sĩ và 02 điều dưỡng thành thục kỹ thuật.
**Phương tiện**
Dàn máy nội soi, dây soi có kênh thủ thuật.
Thòng lọng (snaire) kích thước lớn.
Rọ gắp dị vật.
Ống overtube.
**Người bệnh**
Người bệnh phải nhịn ăn tối thiểu 6 giờ.
Người bệnh hoặc người nhà người bệnh phải được giải thích trước và ký giấy cam đoan đồng ý làm thủ thuật.
Người bệnh nên được khuyên sử dụng đồ uống có ga trước 1 tuần: Cocacola…
**Hồ sơ bệnh án**
Người bệnh sau khi tiến hành thủ thuật phải được ghi vào Phiếu kết quả nội soi để trả lại cho người bệnh. Nếu người bệnh nội trú thì dán kết quả vào bệnh án.
Giấy cam đoan đồng ý làm thủ thuật phải được lưu tối thiểu 6 tháng.
**CÁC BƯỚC TIẾN HÀNH**
Đưa ống overtube qua máy soi.
Nội soi dạ dày theo quy trình.
Dùng thòng lọng cắt nhỏ từng phần cục bã thức ăn. Đôi khi bã thức ăn rất khó cắt.
Sau khi cắt nhỏ cục bã thức ăn, dùng rọ gắp dần kéo ra ngoài qua đường miệng bằng cách kéo cả dây máy soi ra ngoài.
**THEO DÕI TAI BIẾN**
Biến chứng thủng, chảy máu.
Biến chứng tắc ruột do các mảnh, cục bã thức ăn lưu thông trong lòng ruột và gây tắc ruột.
**TÀI LIỆU THAM KHẢO**
Nib Soehendra, Kenneth F. Binmoeller, Hans Seifert, Hans Wilhelm Schreiber,
“Therapeutic Endoscopy – Color atlas of operative techniques for the gastrointestinal tract”, Thieme 2005
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh

## ️ Nội soi can thiệp - đặt dẫn lưu nang giả tụy vào dạ dày

  * [Người thực hiện](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-can-thiep-dat-dan-luu-nang-gia-tuy-vao-da-day#ngi-thc-hin)
  * [Phương tiện, thuốc, vật tư y tế](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-can-thiep-dat-dan-luu-nang-gia-tuy-vao-da-day#phng-tin-thuc-vt-t-y-t)
  * [Thuốc và trang thiết bị vật tư tiêu hao](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-can-thiep-dat-dan-luu-nang-gia-tuy-vao-da-day#thuc-v-trang-thit-b-vt-t-tiu-hao)
  * [CÁC BƯỚC TIẾN HÀNH](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-can-thiep-dat-dan-luu-nang-gia-tuy-vao-da-day#cc-bc-tin-hnh)
  * [Kiểm tra người bệnh](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-can-thiep-dat-dan-luu-nang-gia-tuy-vao-da-day#kim-tra-ngi-bnh)
  * [Thực hiện kỹ thuật](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-can-thiep-dat-dan-luu-nang-gia-tuy-vao-da-day#thc-hin-k-thut)
  * [TAI BIẾN VÀ XỬ TRÍ](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-can-thiep-dat-dan-luu-nang-gia-tuy-vao-da-day#tai-bin-v-x-tr)
  * [TÀI LIỆU THAM KHẢO](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-can-thiep-dat-dan-luu-nang-gia-tuy-vao-da-day#ti-liu-tham-kho)


### **ĐẠI CƯƠNG**
Nội soi can thiệp đặt dẫn lưu nang giả tuỵ vào dạ dày là một kỹ thuật nhằm dẫn lưu dịch nang giả tuỵ qua một ống nhựa (stent) vào trong lòng dạ dày.
### **CHỈ ĐỊNH**
Nang giả tuỵ kích thước lớn (> 6cm) gây triệu chứng đau hoặc gây biến chứng nhiễm trùng.
Nang giả tuỵ gây ép thành dạ dày quan sát được trên nội soi dạ dày.
### **CHỐNG CHỈ ĐỊNH**
Người bệnh mới bị nhồi máu cơ tim
Bệnh lý tim phổi nặng
Dị ứng với thuốc cản quang
Rối loạn đông máu nặng
Giảm tiểu cầu
Đang dùng thuốc chống kết tập tiểu cầu
Nang tụy không ép vào thành dạ dày trên nội soi.
### **CHUẨN BỊ**
#### **Người thực hiện**
01 bác sĩ chuyên làm nội soi mật tụy nược dòng, 01 kỹ thuật viên gây mê, 03 điều dưỡng trong đó có điều dưỡng phải sử dụng được máy C- Arm.
#### **Phương tiện, thuốc, vật tư y tế**
##### **Phương tiện**
Phòng nội soi cho phép chiếu tia Xquang, có hệ thống oxy.
Máy tăng sáng xquang (C.Arm).
Hệ thống máy nội soi tá tràng (máy nội soi cửa sổ bên) với kênh làm thủ thuật có đường kính 4,2mm, canuyn.
Nguồn cắt đốt.
Máy theo dõi lifescope và dụng cụ cấp cứu: mặt nạ, bóng bóp, nội khí quản.
Áo chì 05 bộ
##### Thuốc và trang thiết bị vật tư tiêu hao
**Thuốc**
Thuốc mê và tiền mê: midazolam 5mg từ 1 - 4 ống, fantanyl 0,1 mg từ 1 - 3 ống, propofol 20 ml 1 - 4 ống.
Thuốc cản quang 50ml (telebrix, xenetix ) 1 - 2 lọ.
**Vật tư**
02 dây dẫn (guidewire) 0,035, 01 dao cắt cơ vòng Oddi, 01 dao cắt điểm.
Ống đẩy stent
02 stent nhựa loại đuôi lợn 7 F, 7 cm.
10 đôi găng tay
02 áo mổ
#### **Người bệnh**
Ký giấy cam kết đồng ý làm thủ thuật.
Nhịn ăn trước khi làm thủ thuật 8 giờ.
Đặt đường truyền tĩnh mạch.
#### **Hồ sơ bệnh án**
Người bệnh được làm hồ sơ vào viện điều trị nội trú, đã được làm các xét nghiệm cơ bản, như: chức năng gan, thận, nhóm máu, đông máu cơ bản, chức năng tụy, các marker vi rút, điện tâm đồ.
### **CÁC BƯỚC TIẾN HÀNH**
#### **Kiểm tra hồ sơ**
Để đảm bảo có thể tiến hành tiền mê hoặc gây mê, đảm bảo có thể tiến hành thủ thuật gây chảy máu.
#### **Kiểm tra người bệnh**
Đánh giá chức năng sống của người bệnh để đảm bảo an toàn trước khi làm thủ thuật, đã tuân thủ nhịn ăn trước đó.
#### **Thực hiện kỹ thuật**
Sau khi người bệnh được tiền mê hoặc gây mê, sẽ tiến hành thủ thuật.
Đưa máy xuống dạ dày
Máy nội soi qua thực quản "bán mù", do đó không quan sát được toàn bộ thực quản.
Máy nội soi vào dạ dày: Đưa đầu dây nội soi vào dạ dày tìm điểm nang tụy ép vào thành dạ dày.
**Cắt thành dạ dày**
Dùng dao cắt điểm chọc vuông góc với thành dạ dày vào nang tụy cho tới khi nào dịch nang chảy ra, chú ý sử dụng nguồn cắt đốt. Rút dao cắt luồn dây dẫn vào nang tụy qua thành dạ dày. Tiếp theo sau đó đưa dao cắt cơ vòng Oddi theo dây dẫn để cắt thành dạ dày. Chú ý cắt vừa đủ rộng để đặt 02 stent, nếu cắt rộng quá stent dễ tụt ra ngoài.
**Đặt stent**
Đưa dây dẫn nằm trong nang tụy 02 vòng dưới hướng dẫn của màn tăng sáng.
Qua dao cắt cơ vòng Oddi đưa dây dẫn thứ hai vào trong nang tụy giống như dây dẫn thứ nhất.
Qua dây dẫn lần lượt dùng bộ đẩy stent đặt 02 stent vào trong nang tụy.
Kiểm tra lại vị trí stent trong nang tụy dưới màn tăng sáng.
### **THEO DÕI**
Theo dõi những biến chứng của gây mê như suy hô hấp, tụt huyết áp.
Theo dõi phát hiện viêm tụy cấp: đau bụng, tình trạng ổ bụng, xét nghiệm amylase và lipase sau thủ thuật.
Theo dõi chảy dịch từ nang ra ổ bụng: tình trạng bụng, chụp bụng không chuẩn bị.
### **TAI BIẾN VÀ XỬ TRÍ**
Chảy máu do cắt thành dạ dày. Nội soi cầm máu.
Biến chứng liên quan tới gây mê: tụt huyết áp, suy hô hấp, buồn nôn hoặc nôn. Tiến hành truyền dịch, thở oxy.
Viêm tụy cấp. Nhịn ăn, nuôi dưỡng bằng đường tĩnh mạch, dùng kháng sinh nếu có biểu hiện nhiễm trùng.
Chảy dịch nang vào ổ bụng: nhịn ăn, nuôi bằng đường tĩnh mạch.
### **TÀI LIỆU THAM KHẢO**
Bộ Y tế, Quy trình kỹ thuật bệnh viện.
Sivak M. V. Gastroenterologic Endoscopy 1987.
Kenneth F. Binmoeller, Nib Shoehendra.Gastroenterologic endoscopy. 2004.
Ginberg G.G. Clinical Gastrointestinal Endoscopy 2005.
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [Người thực hiện](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-can-thiep-dat-dan-luu-nang-gia-tuy-vao-da-day#ngi-thc-hin)
  * [Phương tiện, thuốc, vật tư y tế](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-can-thiep-dat-dan-luu-nang-gia-tuy-vao-da-day#phng-tin-thuc-vt-t-y-t)
  * [Thuốc và trang thiết bị vật tư tiêu hao](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-can-thiep-dat-dan-luu-nang-gia-tuy-vao-da-day#thuc-v-trang-thit-b-vt-t-tiu-hao)
  * [CÁC BƯỚC TIẾN HÀNH](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-can-thiep-dat-dan-luu-nang-gia-tuy-vao-da-day#cc-bc-tin-hnh)
  * [Kiểm tra người bệnh](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-can-thiep-dat-dan-luu-nang-gia-tuy-vao-da-day#kim-tra-ngi-bnh)
  * [Thực hiện kỹ thuật](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-can-thiep-dat-dan-luu-nang-gia-tuy-vao-da-day#thc-hin-k-thut)
  * [TAI BIẾN VÀ XỬ TRÍ](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-can-thiep-dat-dan-luu-nang-gia-tuy-vao-da-day#tai-bin-v-x-tr)
  * [TÀI LIỆU THAM KHẢO](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-can-thiep-dat-dan-luu-nang-gia-tuy-vao-da-day#ti-liu-tham-kho)



## ️ Nội soi can thiệp - thắt búi giãn tĩnh mạch thực quản bằng vòng cao su

**ĐỊNH NGHĨA**
Thắt tĩnh mạch thực quản bằng vòng cao su là phương pháp qua đường nội soi dạ dày dùng vòng cao su thắt các búi tĩnh mạch giãn to làm cho máu không còn lưu thông trong tĩnh mạch vỡ và ngừng lại dẫn đến hình thành huyết khối và do đó xơ hóa thành tĩnh mạch.
**CHỈ ĐỊNH**
Thắt cấp cứu khi đang chảy máu do vỡ tĩnh mạch thực quản.
Người bệnh giãn tĩnh mạch thực quản trong tiền sử có chảy máu.
Người bệnh có giãn to tĩnh mạch thực quản, có nguy cơ vỡ.
**CHỐNG CHỈ ĐỊNH**
Hôn mê gan.
Có kèm theo giãn tĩnh mạch phình vị dạ dày.
Suy gan nặng.
Suy tim phổi cấp.
Choáng nặng, không có hồi sức hỗ trợ.
**CHUẨN BỊ**
**Người thực hiện**
01 bác sĩ có trình độ nội soi thuần thục.
02 điều dưỡng biết sử dụng các dụng cụ nội soi và nắm được các bước tiến hành thủ thuật.
**Phương tiện**
Máy nội soi ống mềm cửa sổ thẳng có đường can thiệp tương đối lớn: GIF1T30 hoặc GIF2- T20.
Ống hút có thể lắp nhiều vòng cao su. -Vòng cao su.
**Người bệnh**
Nhịn ăn ít nhất 6 giờ trước khi làm thủ thuật.
Giải thích kỹ cho người bệnh biết mục đích, lợi ích, tai biến của thủ thuật. Cho người bệnh ký giấy cam đoan.
**Hồ sơ bệnh án**
Ghi rõ tình trạng của người bệnh trước khi làm thủ thuật, mạch, huyết áp.
**CÁC BƯỚC TIẾN HÀNH**
Kiểm tra hồ sơ
Tên, tuổi người bệnh. Tình trạng toàn thân, mạch, huyết áp.
Kiểm tra người bệnh
Bác sĩ khám tình trạng người bệnh, các bệnh phối hợp. -Điều dưỡng do mạch, huyết áp.
Thực hiện kỹ thuật
Soi thực quản dạ dày để nhận định mức độ giãn tĩnh mạch thực quản, vị trí giãn, các tổn thương phối hợp ở dạ dày.
Tiến hành lồng vòng cao su vào ống hút, sau đó lắp ống hút có vòng cao su vào đầu đèn soi, mỗi lần lắp được 6 vòng cao su.
Đưa máy nội soi (đã gắn với súng bắn) vào sát búi tĩnh mạch cần thắt, hút từ từ để búi tĩnh mạch chui vào trong vòng nhựa.
Quay tay quay 1 vòng theo chiều kim đồng hồ để vòng cao su tuột ra khỏi ống hút.
Đưa đầu máy soi đến vị trí búi giãn khác để thắt tiếp.
Vị trí thắt: cách tâm vị vài cm và vào nhiều búi tĩnh mạch theo vòng chu vi của thực quản.
Các đợt thắt cách nhau khoảng 2 - 3 tuần.
**THEO DÕI**
Sau khi thắt người bệnh nằm theo dõi trong 24 giờ, ăn thức ăn lỏng, mềm trong 24 giờ.
Theo dõi toàn trạng, mạch, huyết áp.
**TAI BIẾN VÀ XỬ TRÍ**
Chảy máu tại búi thắt: truyền máu kết hợp dùng thuốc.
Đau sau xương ức, khó nuốt: ăn lỏng, dùng thuốc giảm đau.
Loét thực quản: dùng thuốc giảm tiết axít.
Hội chứng não cửa chủ. -Sốt: dùng kháng sinh.
**TÀI LIỆU THAM KHẢO**
Ứng dụng nội soi trong chẩn đoán và điều trị bệnh lý tiêu hóa (2001)
Endoscopic therapy for Upper Gastrointestinal, Variceal hemorrhage, Volume two: 2834-2851.
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh

## ️ Nội soi ruột non bóng kép (Double Baloon Endoscopy)

**ĐẠI CƯƠNG**
Kỹ thuật nội soi ruột non bằng bóng đôi được phát minh bởi Giáo sư Hirononi Yamamoto vào năm 2001, kỹ thuật này dựa trên nguyên lý sử dụng hai bóng được gắn trên đầu ống soi và overtube có thể được bơm hơi và làm xẹp bởi hệ thống bơm có điều khiển. Kể từ đó đến nay, kỹ thuật này được phát triển đến hoàn thiện và có rất nhiều ứng dụng trên lâm sàng trong chẩn đoán và điều trị các bệnh lý ở ruột non.
**CHỈ ĐỊNH**
Sinh thiết các tổn thương ở ruột non sau khi tiến hành nội soi bằng viên nang phát hiện được.
Chảy máu do tổn thương nghi ngờ từ ruột non.
Chẩn đoán và điều trị các tổn thương làm hẹp ruột non.
Chẩn đoán khối u ruột non.
Bệnh Crohn ruột non.
Điều trị lấy dị vật ở ruột non.
Phát hiện các nguyên nhân gây tắc ruột.
Soi đại tràng các trường hợp khó.
**CHỐNG CHỈ ĐỊNH**
Nghi ngờ hội chứng mạch vành cấp.
Tăng huyết áp chưa kiểm soát được.
Nghi ngờ thủng tạng rỗng.
Nghi ngờ phình, tách động mạch chủ.
Người bệnh trong tình trạng suy hô hấp.
Người bệnh suy tim nặng.
Người bệnh rối loạn tâm thần không hợp tác.
Chống chỉ định tương đối: tụt huyết áp huyết áp tâm thu < 90mmHg.
**CHUẨN BỊ**
**Người thực hiện**
Bác sĩ: 01 bác sĩ đã có chứng chỉ tốt nghiệp nội soi tiêu hóa.
Điều dưỡng: 02.
**Phương tiện**
01 Máy nội soi bóng kép: EN-450P5 và EN-450T5 hoặc tương đương, máy có chiều dài 2 m, đường kính ngoài 8,5 mm, kênh 2,2 mm.
01 Overtube (TS-12140, TS-13140).
01 Bóng soi.
Máy bơm CO2.
Máy C- arm.
Máy theo dõi lifescope và dụng cụ cấp cứu: mặt nạ, bóng bóp, nội khí quản.
Thuốc mê và tiền mê: midazolam 5mg: 2 ống, fantanyl 0,1 mg: 2 ống, propofol: 2 ống.
01 kìm sinh thiết.
02 lọ đựng bệnh phẩm.
02 bơm tiêm 20 ml.
06 đôi găng tay.
02 áo mổ.
**Người bệnh**
Chuẩn bị người bệnh.
Giải thích cho người bệnh: mục đích, tai biến của thủ thuật.
Những người bệnh nguy cơ cao: tuổi > 60, nghi ngờ có bệnh lý tim - phổi mạn tính cần làm thêm xét nghiệm điện tâm đồ và X quang tim phổi.
Chuẩn bị nội soi bóng kép qua đường miệng người bệnh cần chuẩn bị nhịn ăn. Chuẩn bị nội soi bóng kép qua đường hậu môn người bệnh cần được thụt tháo, hoặc uống thuốc làm sạch đại tràng: ví dụ tối ngày hôm trước tiến hành nội soi bóng kép uống sennoside trước khi đi ngủ, dùng polyethylene glycol.
**Hồ sơ bệnh án**
Kiểm tra không có chống chỉ định.
Nhận giấy chỉ định.
Giải thích người bệnh ký giấy đồng ý làm thủ thuật.
**CÁC BƯỚC TIẾN HÀNH**
Mời người bệnh vào phòng, hướng dẫn người bệnh nằm lên cáng thủ thuật.
Mắc monitor theo dõi, theo chỉ định của bác sĩ soi.
Tiến hành gây mê theo chỉ định của bác sĩ.
Nội soi bóng kép qua miệng hướng dẫn người bệnh nằm tư thế nghiêng trái, chân trên co, chân dưới duỗi. Cho người bệnh ngậm canun, bắt đầu đưa máy soi và bóng có bôi trơn Xylocaine jelly qua đường miệng, khi máy soi vào dạ dày hút hơi và dịch dạ dày tránh để cuộn máy, khi máy soi vào tới hang vị điều dưỡng phụ bắt đầu luồn overtube với kỹ thuật đẩy kéo dựa trên nguyên lý bóng ở phần đầu có tác dụng giữ chặt vào thành ống tiêu hóa giúp máy soi có thể đi vào vị trí sâu hơn mà không bị cuộn máy, bóng thứ hai giúp máy không bị kéo ra ngoài khi thao tác overtube quan sát niêm mạc dạ dày hành tá tràng và tá tràng, ruột non. Ra y lệnh chụp ảnh minh họa tổn thương, hoặc sinh thiết nếu cần.
**Hình 1. Hình ảnh minh họa nội soi bóng kép qua đường miệng**
Nội soi bóng kép qua đường hậu môn, đưa máy qua đại tràng qua van hồi manh tràng đến vị trí ruột non, quan sát tổn thương ở niêm mạc ruột non.
**Hình 2. Hình ảnh minh họa nội soi bóng kép qua đường hậu môn**
Nội soi ruột non bằng bóng kép qua đường miệng và đường hậu môn cho phép khảo sát toàn bộ niêm mạc ruột non.
Theo dõi toàn trạng người bệnh trong toàn bộ quá trình làm thủ thuật.
Sau khi kết thúc thủ thuật, đánh và in kết quả.
Sau khi bác sĩ kết thúc quá trình nội soi, điều dưỡng phải giúp người bệnh lau miệng, đỡ người bệnh dậy và đưa người bệnh ra khỏi phòng nội soi tới nơi ngồi chờ.
Hướng dẫn người bệnh bổ sung thêm phiếu xét nghiệm sinh thiết nếu cần.
Điều dưỡng rửa máy theo quy trình kỹ thuật.
Trả kết quả nội soi cho người bệnh.
**THEO DÕI**
Theo dõi toàn trạng người bệnh trong quá trình làm thủ thuật, theo dõi tình trạng thành bụng và ỉa máu (vì hai biến chứng hay gặp là thủng ruột non và chảy máu ruột non).
**TAI BIẾN VÀ XỬ TRÍ**
Phát hiện và xử trí các biến chứng chảy máu khi lấy bệnh phẩm, mạch chậm hoặc ngừng tim do cường phế vị, biến chứng thủng ruột non, ghi vào phiếu trả kết quả hoặc cho người bệnh nhập viện xử trí tiếp tùy thuộc từng biến chứng.
**TÀI LIỆU THAM KHẢO**
H. Niwa. H. Tajiri, M. Nakajima, K Yasuda (2008). New Challenges in Gastrointestinal Endoscopy. Springer. pp243-262
K. Sugano. H. Yamamoto. H. Kita (2006). Double-Balloon Endoscopy Theory and Practice. Springer. pp1-21
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh

## ️ Nội soi ruột non bằng viên nang (Capsule endoscopy)

**ĐẠI CƯƠNG**
Nội soi viên nang là kỹ thuật nội soi ruột non bằng cách uống viên nang nội soi có kích thước như viên thuốc, trong có chứa một máy quay nhỏ có thể ghi hình lại với tốc độ 3 hình/ giây trong vòng 11 tiếng.
**CHỈ ĐỊNH**
Phát hiện bệnh lý ruột non như: Khối u, xác định nguyên nhân và vị trí xuất huyết tiêu hoá tại ruột non.
**CHỐNG CHỈ ĐỊNH**
Người bệnh khó nuốt, nghi ngờ tắc ruột.
Không nên sử dụng người bệnh đã can thiệp phẫu thuật ống tiêu hoá, đang mang thai hoặc có mang máy tạo nhịp tim.
**CHUẨN BỊ**
**Người thực hiện**
01 bác sĩ và 01 điều dưỡng thành thục kỹ thuật.
**Phương tiện**
Bộ xử trí hình ảnh Workstation - olympus WS-1.
Hệ thống thu nhận và lưu trữ tín hiệu hình ảnh không dây. -Viên nang endocapsule sử dụng 1 lần.
**Người bệnh**
Trong vòng 1 tuần trước khi nội soi viên nang, người bệnh không nên uống thuốc có chứa sắt.
Người bệnh phải nhịn ăn và uống các nước màu như sữa, cà phê… tối thiểu 12 giờ trước khi nội soi (có thể uống nước lọc trắng).
Người bệnh được uống thuốc nhuận tràng (Sodium phosphat) trước khi nội soi viên nang 12 giờ.
Người bệnh nên kiêng hút thuốc lá trong 12 giờ trước khi nội soi viên nang.
Trước khi nội soi 2 giờ, người bệnh không được uống bất kể thuốc gì.
Người bệnh được uống thuốc chống tạo bọt simethicone 20 phút trước khi tiến hành nội soi.
Người bệnh hoặc người nhà người bệnh phải được giải thích trước và ký giấy cam đoan đồng ý làm thủ thuật.
**HỒ SƠ BỆNH ÁN**
Người bệnh sau khi tiến hành thủ thuật phải được ghi vào Phiếu kết quả nội soi để trả lại cho người bệnh. Nếu người bệnh nội trú thì dán kết quả vào bệnh án.
Giấy cam đoan đồng ý làm thủ thuật phải được lưu tối thiểu 6 tháng.
**CÁC BƯỚC TIẾN HÀNH**
Mắc 8 điện cực có ăng ten lên da bụng người bệnh đúng vị trí, nối với máy thu nhận tín hiệu.
Đeo máy thu nhận tín hiệu hình ảnh không dây cho người bệnh.
Cho người bệnh uống viên nang nội soi.
**Hướng dẫn người bệnh**
Đeo dây đai gắn máy thu nhận tín hiệu trong suốt thời gian (8 - 11 giờ) làm thủ thuật.
Sau khi uống viên nang nội soi 2 giờ, người bệnh có thể uống nước. 4 giờ sau khi uống viên nang, người bệnh có thể ăn nhẹ.
Sau 8 - 11 giờ thu nhận tín hiệu, tháo máy thu nhận tín hiệu cho người bệnh. Kết nối với bộ xử trí hình ảnh, đọc kết quả và in kết quả cho người bệnh.
**Hướng dẫn người bệnh:**
Theo dõi phân để phát hiện viên nang được đào thải ra khỏi cơ thể (thường sau 1 - 3 ngày).
**THEO DÕI TAI BIẾN**
Tỷ lệ tai biến rất thấp, có thể gặp là vẫn giữ viên nang nội soi trong cơ thể (0% người bình thường, 1,5% người bệnh chảy máu tiêu hoá ẩn, 5% người bệnh nghi ngờ Crohn và 21% người bệnh tắc ruột).
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh

## ️ Nội soi thực quản - dạ dày - tá tràng qua đường mũi

  * [Chống chỉ định tuyệt đối](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-thuc-quan-da-day-ta-trang-qua-duong-mui#chng-ch-nh-tuyt-i)
  * [Chống chỉ định tương đối](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-thuc-quan-da-day-ta-trang-qua-duong-mui#chng-ch-nh-tng-i)
  * [Người thực hiện](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-thuc-quan-da-day-ta-trang-qua-duong-mui#ngi-thc-hin)
  * [CÁC BƯỚC TIẾN HÀNH](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-thuc-quan-da-day-ta-trang-qua-duong-mui#cc-bc-tin-hnh)
  * [Kiểm tra hồ sơ bệnh án](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-thuc-quan-da-day-ta-trang-qua-duong-mui#kim-tra-h-s-bnh-n)
  * [Kiểm tra người bệnh](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-thuc-quan-da-day-ta-trang-qua-duong-mui#kim-tra-ngi-bnh)
  * [Thực hiện kỹ thuật](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-thuc-quan-da-day-ta-trang-qua-duong-mui#thc-hin-k-thut)
  * [TAI BIẾN VÀ XỬ TRÍ](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-thuc-quan-da-day-ta-trang-qua-duong-mui#tai-bin-v-x-tr)
  * [TÀI LIỆU THAM KHẢO](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-thuc-quan-da-day-ta-trang-qua-duong-mui#ti-liu-tham-kho)


### **ĐỊNH NGHĨA**
Soi thực quản - dạ dày - tá tràng qua đường mũi là đưa ống soi dạ dày qua đường mũi vào thực quản rồi xuống dạ dày và tá tràng nhằm mục đích chẩn đoán những bệnh lý của thực quản, dạ dày và tá tràng. Ưu điểm của phương pháp nội soi này là ống soi có đường kính nhỏ (đường kính khoảng 5,9 mm) và đi qua đường mũi, không chạm vào lưỡi gà và vùng hầu họng nên ít phản xạ ho, người bệnh đỡ khó chịu hơn.
### **CHỈ ĐỊNH**
Đau thượng vị, nôn không rõ nguyên nhân, hội chứng trào ngược
Thiếu máu, gầy sút cân
Đau ngực sau khi đã kiểm tra tim mạch bình thường
Nuốt nghẹn
Hội chứng kém hấp thu
Tiền sử dùng thuốc chống viêm, giảm đau
Cắt 2/3 dạ dày sau 10 năm
Soi kiểm tra người bệnh trước mổ nặng
Xơ gan, tăng áp lực tĩnh mạch cửa tiên phát
Bệnh polyp gia đình
Bệnh Crohn
Tắc mạch sâu
### **CHỐNG CHỊ ĐỊNH**
#### **Chống chỉ định tuyệt đối**
Các bệnh lý ở thực quản có nguy cơ làm thủng thực quản như bỏng thực quản do hóa chất và thuốc gây hẹp thực quản.
Phình động mạch chủ ngực.
Suy tim, nhồi máu cơ tim, cơn tăng huyết áp.
Suy hô hấp, khó thở do bất cứ nguyên nhân gì, ho nhiều.
Dị tật, polyp cuốn mũi… làm cản trở việc đưa máy soi qua mũi.
#### **Chống chỉ định tương đối**
Gù vẹo cột sống nhiều
Người bệnh già yếu
Người bệnh tâm thần không phối hợp được
Tụt huyết áp
### **CHUẨN BỊ**
#### **Người thực hiện**
01 bác sĩ chuyên khoa nội soi tiêu hóa, 02 điều dưỡng.
#### **Phương tiện**
Máy nội soi thực quản - dạ dày - tá tràng ống mềm, kích thước nhỏ, loại cửa sổ thẳng và các dụng cụ đi kèm máy nội soi.
Nguồn sáng
Máy hút
Nước cất để bơm rửa khi cần thiết trong quá trình nội soi.
Chất bôi trơn đầu máy soi: K – Y
Thuốc gây tê vùng họng: Xylocain 2% hoặc Lidocain 10 % -Găng, gạc, bơm tiêm 20 ml.
#### **Người bệnh**
Nhịn ăn tối thiểu 6 giờ trước nội soi. Người bệnh phải được giải thích kỹ về lợi ích và tai biến của thủ thuật và đồng ý soi.
Nếu người bệnh nội trú phải có bệnh án.
### **CÁC BƯỚC TIẾN HÀNH**
#### **Kiểm tra hồ sơ bệnh án**
Nếu người soi là người bệnh nội trú.
#### **Kiểm tra người bệnh**
Đúng họ tên, tuổi, giới, địa chỉ. Người bệnh nằm nghiêng trái hoặc ngồi thẳng trong trường hợp khó.
#### **Thực hiện kỹ thuật**
Chuẩn bị và kiểm tra máy soi.
Gây tê bên lỗ mũi soi bằng Xylocain 2% hoặc Lidocain 10%.
Đưa máy soi qua mũi, họng vào thực quản, dạ dày, tá tràng bơm hơi và quan sát. Có thể dùng bơm tiêm bơm nước cất vào cho sạch chất bẩn ở những vùng cần quan sát kỹ.
Rút máy và tẩy uế, khử khuẩn máy soi theo đúng quy định sau:
**Rửa máy:**
Dùng 500 ml dung dịch xà phòng trung tính 0,5 %, van bơm tăng cường để rửa sạch phần ngoài của máy và các đường bên trong máy.
**Thử hơi:**
Dùng dụng cụ thử hơi kèm máy soi để xem vỏ cao su của máy có bị rách không, nếu rách không được ngâm máy vào dung dịch tẩy uế mà phải gửi máy đi sửa ngay.
**Tẩy uế:** chỉ tiến hành khi máy soi không bị rách.
Dùng 5 lít xà phòng trung tính 0,5%, bàn chải, van ba chiều để tẩy uế.
Ngâm toàn bộ máy vào dung dịch tẩy uế, dùng bàn chải, van ba chiều để rửa sạch phần ngoài và các đường bên trong của máy.
**Sát khuẩn:**
Dùng 5 lít dung dịch sát khuẩn Glutaraldehyd 2%, van ba chiều để sát khuẩn máy.
Ngâm toàn bộ máy vào dung dịch sát khuẩn để rửa sạch các đường bên trong của máy.
Sấy khô máy: dùng van bơm tăng cường, bộ phận bơm khí của nguồn sáng, máy hút để làm khô các đường bên trong của máy trước khi cất máy.
### **THEO DÕI**
Tình trạng chung của người bệnh, mạch, huyết áp nếu người bệnh có xuất huyết tiêu hóa.
Tình trạng nuốt khó.
### **TAI BIẾN VÀ XỬ TRÍ**
Đưa máy nhầm vào khí quản: phải rút máy ra, đưa lại vào thực quản.
Nuốt khó có thể do thủng thực quản. Nếu nghi ngờ cho người bệnh đi chụp X quang, tùy mức độ có thể cho nhịn ăn, dùng kháng sinh và gửi ngoại khoa nếu cần thiết.
### **TÀI LIỆU THAM KHẢO**
Soi dạ dày - tá tràng. Hướng dẫn quy trình kỹ thuật bệnh viện Tập I. Nhà xuất bản Y học 1999, 506 - 507.
Phạm Thị Bình. Soi dạ dày - tá tràng. Ứng dụng nội soi trong chẩn đoán và điều trị bệnh lý tiêu hóa. Bệnh viện Bạch Mai. 2001, 14 - 30.
Mark Topazian. Upper endoscopy. Harrison,s Gastroenterology and Hepatology. 2010: 94.
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [Chống chỉ định tuyệt đối](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-thuc-quan-da-day-ta-trang-qua-duong-mui#chng-ch-nh-tuyt-i)
  * [Chống chỉ định tương đối](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-thuc-quan-da-day-ta-trang-qua-duong-mui#chng-ch-nh-tng-i)
  * [Người thực hiện](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-thuc-quan-da-day-ta-trang-qua-duong-mui#ngi-thc-hin)
  * [CÁC BƯỚC TIẾN HÀNH](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-thuc-quan-da-day-ta-trang-qua-duong-mui#cc-bc-tin-hnh)
  * [Kiểm tra hồ sơ bệnh án](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-thuc-quan-da-day-ta-trang-qua-duong-mui#kim-tra-h-s-bnh-n)
  * [Kiểm tra người bệnh](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-thuc-quan-da-day-ta-trang-qua-duong-mui#kim-tra-ngi-bnh)
  * [Thực hiện kỹ thuật](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-thuc-quan-da-day-ta-trang-qua-duong-mui#thc-hin-k-thut)
  * [TAI BIẾN VÀ XỬ TRÍ](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-thuc-quan-da-day-ta-trang-qua-duong-mui#tai-bin-v-x-tr)
  * [TÀI LIỆU THAM KHẢO](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-thuc-quan-da-day-ta-trang-qua-duong-mui#ti-liu-tham-kho)



## ️ Đo vận động thực quản 24 giờ

  * [Người thực hiện](https://bvnguyentriphuong.com.vn/noi-soi/do-van-dong-thuc-quan-24-gio#ngi-thc-hin)
  * [CÁC BƯỚC TIẾN HÀNH](https://bvnguyentriphuong.com.vn/noi-soi/do-van-dong-thuc-quan-24-gio#cc-bc-tin-hnh)


### **ĐẠI CƯƠNG**
Đo vận động thực quản (esophageal manometry) là xét nghiệm đánh giá chức năng của cơ thắt tâm vị (lower esophageal sphincter) và các cơ thắt khác của thực quản.
Đo vận động thực quản không chỉ cho biết sự di chuyển thức ăn từ thực quản xuống dạ dày, mà còn cho thấy cách cơ thắt tâm vị ngăn chặn trào ngược dịch vị lên thực quản.
### **CHỈ ĐỊNH**
Nuốt khó, nuốt đau không rõ nguyên nhân.
Ợ nóng, ợ chua.
Đau ngực không rõ nguyên nhân.
### **CHỐNG CHỈ ĐỊNH**
Người bệnh có bệnh lý tim mạch và hô hấp nặng. -Dị ứng với các thành phần nhựa trong máy đo.
### **CHUẨN BỊ**
#### **Người thực hiện**
01 bác sĩ.
01 điều dưỡng phụ.
#### **Phương tiện**
Máy đo vận động thực quản: ống thông mũi - dạ dày có gắn cảm biến đo áp lực, bộ ghi dữ liệu.
#### **Người bệnh**
Trong 24 giờ trước khi làm xét nghiệm, không dùng các thuốc chẹn kênh calci.
Trong 12 giờ trước khi làm xét nghiệm, không dùng các thuốc an thần.
Nhịn ăn 4 - 6 giờ trước khi làm xét nghiệm.
#### **Hồ sơ bệnh án**
Ghi lại thời gian bắt đầu và kết thúc thủ thuật.
### **CÁC BƯỚC TIẾN HÀNH**
Người bệnh được đặt ống thông có gắn cảm biến áp lực qua đường mũi xuống thực quản, dạ dày.
Cảm biến được đặt ở vị trí cơ thắt tâm vị (lower esophageal sphincter).
Kiểm tra vị trí cảm biến bằng nội soi ống mềm dạ dày.
Kết nối cảm biến với bộ ghi dữ liệu, kiểm tra hoạt động của cảm biến.
Tiến hành đo áp lực của cơ thắt tâm vị, đo áp lực của các cơ thắt thực quản tại các vị trí khác nhau, đánh giá sự phối hợp giữa các cơ thắt bằng cách cho người bệnh nuốt và uống nước.
Thời gian đo từ 10 - 15 phút.
Kết thúc đo, rút ống thông ra khỏi người bệnh.
### **THEO DÕI**
Tình trạng người bệnh trong và sau khi làm xét nghiệm.
### **TAI BIẾN**
Chảy máu khi đưa ống thông qua mũi xuống dạ dày.
Đau họng.
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [Người thực hiện](https://bvnguyentriphuong.com.vn/noi-soi/do-van-dong-thuc-quan-24-gio#ngi-thc-hin)
  * [CÁC BƯỚC TIẾN HÀNH](https://bvnguyentriphuong.com.vn/noi-soi/do-van-dong-thuc-quan-24-gio#cc-bc-tin-hnh)



## ️ Nội soi thực quản - dạ dày - tá tràng cấp cứu

  * [Người thực hiện](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-thuc-quan-da-day-ta-trang-cap-cuu#ngi-thc-hin)
  * [CÁC BƯỚC TIẾN HÀNH](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-thuc-quan-da-day-ta-trang-cap-cuu#cc-bc-tin-hnh)
  * [Kiểm tra hồ sơ bệnh án](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-thuc-quan-da-day-ta-trang-cap-cuu#kim-tra-h-s-bnh-n)
  * [Thực hiện kỹ thuật](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-thuc-quan-da-day-ta-trang-cap-cuu#thc-hin-k-thut)
  * [TAI BIẾN VÀ XỬ TRÍ](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-thuc-quan-da-day-ta-trang-cap-cuu#tai-bin-v-x-tr)
  * [TÀI LIỆU THAM KHẢO](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-thuc-quan-da-day-ta-trang-cap-cuu#ti-liu-tham-kho)


### **ĐỊNH NGHĨA**
Soi thực quản - dạ dày - tá tràng cấp cứu là đưa ống soi dạ dày qua đường miệng vào thực quản rồi xuống dạ dày và tá tràng nhằm mục đích chẩn đoán và điều trị những bệnh lý của thực quản, dạ dày và tá tràng trong tình trạng cấp cứu.
### **CHỈ ĐỊNH**
Nôn ra máu, đi ngoài phân đen
Hóc dị vật
Giun chui ống mật
### **CHỐNG CHỈ ĐỊNH**
Tình trạng huyết động không ổn định, huyết áp tâm thu < 80 mmHg mà chưa có sẵn đường truyền máu.
Chưa có sẵn đường truyền máu.
### **CHUẨN BỊ**
#### **Người thực hiện**
01 bác sĩ chuyên khoa nội soi tiêu hóa, 02 điều dưỡng.
**Phương tiện**
Máy nội soi thực quản - dạ dày - tá tràng ống mềm, loại cửa sổ thẳng và các dụng cụ đi kèm máy nội soi.
Nguồn sáng
Máy hút
Kim tiêm cầm máu qua nội soi, kẹp Clip cầm máu.
Snare điện, nguồn đốt.
Kìm gắp dị vật hoặc rọ.
Súng thắt vòng cao su đối với thắt giãn tĩnh mạch thực quản.
Ống ngậm miệng.
Nước cất để bơm rửa khi cần thiết trong quá trình nội soi.
Chất bôi trơn đầu máy soi: K - Y.
Thuốc gây tê vùng họng: Xylocain 2% hoặc Lidocain 10%.
Thuốc Adrenalin 1/1000, Natriclorua 0,9% hoặc 5 %.
Găng, gạc, bơm tiêm 20 ml.
Hệ thống Oxy, máy Monitor theo dõi.
#### **Người bệnh**
Nhịn ăn tối thiểu 6 giờ trước nội soi. Người bệnh phải được giải thích kỹ về lợi ích và tai biến của thủ thuật và đồng ý soi. Trong trường hợp xuất huyết tiêu hóa người bệnh cần phải đặt trước đường truyền tĩnh mạch.
Nếu người bệnh nội trú phải có bệnh án.
Người nhà người bệnh viết cam đoan.
### **CÁC BƯỚC TIẾN HÀNH**
#### **Kiểm tra hồ sơ bệnh án**
Nếu người soi là người bệnh nội trú. Kiểm tra các xét nghiệm về đông, cầm máu. 2. Kiểm tra người bệnh
Đúng họ tên, tuổi, giới, địa chỉ.
#### **Thực hiện kỹ thuật**
Người bệnh được mắc Monitor theo dõi nhịp tim, SpO2, đo huyết áp, đặt đường truyền tĩnh mạch nếu đang có xuất huyết tiêu hóa. Người bệnh nằm nghiêng trái, chân phải co, chân trái duỗi.
Chuẩn bị và kiểm tra máy soi.
Đặt ống ngậm miệng vào giữa hai cung răng và bảo người bệnh ngậm chặt.
Đưa máy soi qua miệng, họng vào thực quản, dạ dày, tá tràng bơm hơi và quan sát. Có thể dùng bơm tiêm bơm nước cất vào cho sạch chất bẩn ở những vùng cần quan sát kỹ.
Có thể can thiệp điều trị qua nội soi như:
Tiêm cầm máu tại ổ loét dạ dày - tá tràng, vết rách tâm vị.
Kẹp Clip cầm máu đối với loét dạ dày, tá tràng, chảy máu điểm mạch.
Thắt giãn tĩnh mạch thực quản bằng vòng cao su, tiêm xơ tĩnh mạch phình vị.
Cắt polyp khi polyp đang chảy máu và các xét nghiệm đông cầm máu trong giới hạn bình thường.
Gắp giun đang chui lên đường mật tại papilla.
Gắp dị vật như xương (hóc xương ), đồng xu…
Rút máy và tẩy uế, khử khuẩn máy soi theo đúng quy định như đối với soi thực quản dạ dày, tá tràng thông thường.
### **THEO DÕI**
Tình trạng chung của người bệnh, mạch, huyết áp.
Tình trạng chảy máu, thủng.
### **TAI BIẾN VÀ XỬ TRÍ**
Các tai biến và xử trí giống như các tai biến của nội soi dạ dày thông thường.
Ngoài ra có các tai biến của cầm máu qua nội soi như chảy máu do cắt polyp; có thể cầm máu lại bằng nguồn đốt hoặc kẹp Clip.
### **TÀI LIỆU THAM KHẢO**
Soi dạ dày - tá tràng. Hướng dẫn quy trình kỹ thuật bệnh viện Tập I. Nhà xuất bản Y học 1999, 506- 507.
Phạm Thị Bình. Soi dạ dày - tá tràng. Ứng dụng nội soi trong chẩn đoán và điều trị bệnh lý tiêu hóa. Bệnh viện Bạch Mai. 2001, 14 - 30.
Mark Topazian. Upper endoscopy. Harrison,s Gastroenterology and Hepatology. 2010: 94.
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [Người thực hiện](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-thuc-quan-da-day-ta-trang-cap-cuu#ngi-thc-hin)
  * [CÁC BƯỚC TIẾN HÀNH](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-thuc-quan-da-day-ta-trang-cap-cuu#cc-bc-tin-hnh)
  * [Kiểm tra hồ sơ bệnh án](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-thuc-quan-da-day-ta-trang-cap-cuu#kim-tra-h-s-bnh-n)
  * [Thực hiện kỹ thuật](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-thuc-quan-da-day-ta-trang-cap-cuu#thc-hin-k-thut)
  * [TAI BIẾN VÀ XỬ TRÍ](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-thuc-quan-da-day-ta-trang-cap-cuu#tai-bin-v-x-tr)
  * [TÀI LIỆU THAM KHẢO](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-thuc-quan-da-day-ta-trang-cap-cuu#ti-liu-tham-kho)



## ️ Những dặn dò trước khi thực hiện nội soi đại tràng

Bản hướng dẫn này sẽ giải thích cách làm sạch ruột già. Bản hướng dẫn sẽ khác nhau **nếu bạn bị**** tiểu đường, bệnh lý tim mạch, bệnh thận mạn** hoặc đang dùng thuốc chống đông máu, chuẩn bị làm can thiệp: CẮT POLYP thì thông báo cho NHÂN VIÊN KHOA NỘI SOI.
**Những điều ****cần thiết**
**_1.Chống chỉ định của thuốc xổ ruột_**
**-Bệnh nhân khó thở**
**-Bệnh nhân có suy tim, bệnh thận mạn, có rối loạn nước điện giải nghiêm trọng.**
**-Bệnh nhân có dấu hiệu tắc ruột: ói nhiều, bụng chướng, đau quặn bụng , không xì hơi lẫn không đi cầu được.**
**_2.Những điều cần làm trước khi chuẩn bị ruột nội soi:_**
  1. Nếu bạn được chỉ định gây mê: bạn sẽ được BS gây mê đánh giá tình trạng sức khỏe của bạn để đảm bảo cuộc soi an toàn và êm ái.
  2. Nếu bạn được chỉ đinh can thiệp CẮT POLYP, bạn cần xét nghiệm: đông máu toàn bộ để giảm thiểu tối đa biến chứng xuất huyết sau cắt polyp do rối loạn đông cầm máu.Nếu bạn đang sử dụng các thuốc làm loãng máu (thuốc chống đông, chống kết tập tiểu cầu), bạn cần được BS tim mạch đồng ý cho ngưng thuốc vài ngày để làm thủ thuật.
  3. Bs sẽ giải thích lợi ích và nguy cơ tai biến, biến chứng của cắt polyp cho bạn và cần sự đồng thuận của bạn trước khi tiến hành thủ thuật.


**_3.Cách thức chuẩn bị ruột:_**
  1. Thuốc chuẩn bị cho việc rửa ruột – bao gồm: Fortran. Khoa nội soi sẽ cung cấp toa thuốc cho bạn mua tại nhà thuốc.
  2. Bạn sẽ uống **hai liều riêng biệt theo****TỜ HƯỚNG DẪN do Khoa Nội Soi cung cấp**


***Một ngày trước khi làm thủ thuật**
a. Bạn được phép: 1) ăn cháo thịt hay cá loãng, ngũ cốc (cereal) mà không có hạt với sữa; 2) uống nước trái cây mà không có bã; và 3) uống tất cả các loại chất lỏng và trong mà bạn thích, bao gồm cả nước, trà và cà phê.
) KHÔNG ĂN: CHẤT XƠ ( các loại rau củ quả có chất xơ)
**b. Nếu bạn đang làm hóa trị** 1-2 tuần trước khi làm nội soi, bạn sẽ cần phải làm một xét nghiệm máu. Xét nghiệm máu này nên làm trong hai mươi bốn (24) giờ trước khi làm thủ thuật. Kết quả sẽ xác định bạn có thể làm nội soi hoặc nên dời ngày lại
**c. Sau 17h: bạn cần nhịn ăn.Bạn có thể uống nước.**
**d. Bạn sẽ uống liều thuốc thứ 01 ( giờ bắt đầu uống sẽ được điều dưỡng ghi cụ thể trong TỜ HƯỚNG DẪN): 01 gói Fortran pha với đủ 01 lít nước lọc uống trong vòng 1 tiếng ( Lưu ý: bạn không được lâu hơn 1 tiếng sẽ giảm tác dụng của thuốc.Tuy nhiên, bạn có thể uống sớm hơn 1 tiếng ).Sau đó, bạn sẽ đi lỏng vài lần trong đêm.**
**e.Bạn có thể thay nước lọc bằng các loại nước trắng trong, KHÔNG MÀU khác như: nước dừa, Spite, 7-up,nước ép trái cây,…..**
**f.Tuyệt đối: không uống nước có màu như cà phê, sữa, sting đỏ sẽ nhầm lẫn với máu hoặc bám đục niêm mạc dẫn đến sai lệch chẩn đoán**
*** Vào ngày làm thủ thuật:**
a. Để đảm bảo an toàn cho bạn, sắp xếp một người lớn có thể đi với bạn đến buổi hẹn, đưa bạn về và ở lại với bạn. Bạn sẽ được cho thuốc an thần để làm cho bạn ngủ trong khi làm thủ thuật. **Nếu bạn không có người**** đi cùng, thủ thuật nội soi sẽ được hoãn lại hoặc dời lại.**
**b.Bạn cần tiếp tục nhịn ăn. **
c. Buổi sáng, bạn sẽ uống liều thuốc 02 ( giờ bắt đầu uống sẽ ghi trong TỜ HƯỚNG DẪN) bao gồm: 02 gói Fortran pha với 02 lít nước lọc uống trong vòng  tiếng (Lưu ý: không uống lâu hơn 2 tiếng sẽ làm giảm tác dụng của thuốc).Sau đó, bạn sẽ đi cầu nhiều lần đến khi bạn đi cầu ra NƯỚC TRONG SUỐT để đảm bảo ruột bạn sạch thì BS mới quan sát được những sang thương u hoặc polyp nhỏ ( < 5mm).Nếu bạn đã uống đủ 02 lít nước mà đi cầu vẫn còn lợn cợn phân, bạn cần uống thêm nước lọc cho đến khi: bạn đi cầu NƯỚC TRONG SUỐT.
d. Nếu bạn được nội soi gây mê, bạn cần NGƯNG UỐNG NƯỚC 2 TIẾNG trước khi nội soi 
**e. Bạn có thể thay nước lọc bằng các loại nước trắng trong, KHÔNG MÀU khác như: nước dừa, Spite, 7-up,nước ép trái cây,…..**
**f. Tuyệt đối: không uống nước có màu như cà phê, sữa, sting đỏ sẽ nhầm lẫn với máu hoặc bám đục niêm mạc dẫn đến sai lệch chẩn đoán**
**_Săn sóc tại nhà_**
  1. **Thuốc** **làm** **bạn** **đi** **cầu**. Nếu bạn bị rát ở vùng hậu môn, hãy rửa sạch. Bạn có thể dùng miếng thuốc dán (thí dụ như Tucks®) và chất mỡ (thí dụ như Vaseline®) để giúp làm dịu da.
  2. **khi nội soi, bạn có thể đau quặn bụng nhẹ do BS bơm hơi để quan sát tổn thương.Bạn chỉ cần xì hơi là sẽ hết đau bụng.**
  3. **bạn được gây mê:****Đừng lái xe** , vận hành máy móc hoặc đi làm, cho đến một ngày sau khi bạn nội soi
  4. **khi cắt polyp, bạn sẽ đọc bảng hướng dẫn theo dõi sau cắt polyp tại BẢNG THÔNG TIN tại Khoa Nội Soi bao gồm những lưu ý sau:**


  * Uống sữa hoặc tất cả các loại nước LẠNH trong ngày đầu tiên sau cắt polyp.
  * Ngày thứ 2-4, bạn có thể ăn cháo loãng nguội.
  * Ngày thứ 5, bạn có thể ăn uống lại bình thường.
  * Hạn chế vận động mạnh, cường độ cao trong ít nhất 02 tuầh đầu sau cắt polyp.


**_Vấn đề về y khoa hay trường hợp khẩn cấp_**
n cần nhập viện ngay khi có các dấu hiệu sau
  1. nhiều lần khi đang uống thuốc xổ.
  2. Uống trên 2 lít thuốc xổ mà vẫn không đi cầu được.
  3. Ói ra máu hay đi cầu ra máu đỏ tươi hay đỏ bầ sau cắt polyp.
  4. Đau ở bụng dưới một cách trầm trọng.
  5. mệt nhiều, khó thở 


**_TÁI KHÁM HOẶC NỘI SOI:_**
-Sau khi nội soi, nếu bs có làm SINH THIẾT ( giải phẫu bệnh lý) nhằm xác định bệnh lý bạn là: lành tính, ác tính ( ung thư), viêm loét, lao hay các vấn đề khác.Xin vui lòng lấy kết quả theo lịch hẹn.
-Lần nội soi tiếp theo, xin vui lòng đem theo kết quả: NỘI SOI VÀ GIẢI PHẪU BỆNH LÝ để BS có thể theo dõi, đánh giá bệnh của bạn đã tốt hơn, xấu hơn hay đã khỏi hoàn toàn và có kế hoạch chỉ định thời gian kiểm tra định kỳ cho bạn ( quan trọng: sau cắt ung thư đại tràng, cắt polyp để phòng ngừa ung thư đại tràng,….)

## ️ Nội soi hậu môn ống cứng can thiệp - tiêm xơ búi trĩ

**ĐẠI CƯƠNG**
Tiêm xơ búi trĩ là phương pháp tiêm một chất gây xơ vào gốc búi trĩ để điều trị trĩ nội bằng nội soi hậu môn ống cứng.
**CHỈ ĐỊNH**
Trĩ nội độ 1, độ 2, và độ 3 nhỏ.
**CHỐNG CHỈ ĐỊNH**
Trĩ nội độ 3 to, độ 4, trĩ hỗn hợp, trĩ ngoại, huyết khối trĩ.
Viêm nhiễm tại hậu môn.
Bệnh rối loạn đông máu, bệnh toàn thân giai đoạn cấp, bệnh suy giảm miễn dịch HIV.
**CHUẨN BỊ**
**Người thực hiện**
01 bác sĩ và 01 điều dưỡng phụ.
**Phương tiện**
Ống soi hậu môn, nguồn sáng tốt, bơm tiêm, thuốc sát trùng.
Thuốc gây xơ: Polidocanol.
**Người bệnh**
Giải thích kỹ để người bệnh hiểu và cộng tác, thụt tháo phân, đi tiểu trước khi làm thủ thuật.
**Hồ sơ bệnh án**
Kiểm tra tên, tuổi người bệnh, xét nghiệm đông máu, cầm máu.
**CÁC BƯỚC TIẾN HÀNH**
**Kiểm tra hồ sơ**
Tên, tuổi người bệnh, các xét nghiệm.
**Kiểm tra người bệnh**
Người bệnh nằm sấp. Bác sĩ tiến hành thăm hậu môn, soi hậu môn để xác định lại chẩn đoán, chọn các búi trĩ sẽ tiêm thuốc.
**Thực hiện kỹ thuật**
Lau sạch ống hậu môn, bôi thuốc khử khuẩn dịu như Betadine, banh hậu môn để gốc búi trĩ. Tiêm thuốc gây xơ vào gốc búi trĩ vùng dưới niêm mạc, mỗi búi từ 1, 2, 3 ml tùy kích thước búi trĩ. Rút kim ra, nếu chảy máu ở lỗ đâm kim, ấn chặt một miếng bông.
Tiêm trên đường lược ít nhất 5 mm, người bệnh không đau. Tiếp tục điều trị búi trĩ khác. Không tiêm quá 3 búi trĩ trong một lần điều trị. Tránh tiêm ở vị trí 12 giờ. Các lần tiêm cách nhau 1- 2 tuần lễ.
**THEO DÕI**
Trước, trong và sau khi làm thủ thuật: theo dõi mạch, nhiệt độ, huyết áp.
Sau khi làm người bệnh nghỉ ngơi 15 phút rồi cho về.
Cho thuốc giảm đau, nhuận tràng, an thần.
Ngâm hậu môn bằng nước ấm 2 lần/1 ngày trong 7 ngày.
**TAI BIẾN VÀ XỬ TRÍ**
Sốc phản vệ: Mạch nhanh, huyết áp tụt. Xử trí theo phác đồ sốc phản vệ.
Choáng: cho người bệnh nằm nghỉ, theo dõi mạch, huyết áp.
Tiêm không đúng khoang dưới niêm mạc: sâu quá lớp cơ, người bệnh đau, rút bớt kim lại. Tiêm nông quá, niêm mạc trắng bệch, thuốc trào ra ngoài, không có tác dụng.
Chảy máu chỗ tiêm: ấn chặt miếng bông, ép gạc.
Đau do tiêm thấp dưới đường lược hoặc tiêm quá sâu: cho thuốc giảm đau.
Áp xe hay nứt kẽ hậu môn.
Nhiễm khuẩn nặng: sốt cao, đau nhiều, bí đái: cho người bệnh vào viện.
**TÀI LIỆU THAM KHẢO**
Bộ Y tế, Quy trình kỹ thuật bệnh viện (1999): 325-327
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh

## ️ Nội soi ruột non bóng đơn (Single Baloon Endoscopy)

  * [Người thực hiện](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-ruot-non-bong-don-single-baloon-endoscopy#ngi-thc-hin)
  * [CÁC BƯỚC TIẾN HÀNH](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-ruot-non-bong-don-single-baloon-endoscopy#cc-bc-tin-hnh)
  * [TAI BIẾN VÀ XỬ TRÍ](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-ruot-non-bong-don-single-baloon-endoscopy#tai-bin-v-x-tr)
  * [TÀI LIỆU THAM KHẢO](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-ruot-non-bong-don-single-baloon-endoscopy#ti-liu-tham-kho)


### **ĐẠI CƯƠNG**
Kỹ thuật nội soi ruột non bằng bóng đơn được phát minh nhằm hạn chế thăm khám ruột non, vì các máy nội soi thông thường chỉ có thể quan sát được đến tá tràng, nội soi ruột non bóng đơn đi đường miệng có thể đưa xuống tới góc Treitz và đi sâu xuống tới 80 cm. Nội soi ruột non bóng đơn đi qua hậu môn có thể khắc phục hạn chế của nội soi đại tràng, có thể vào sâu khảo sát ruột non qua van hồi manh tràng.
### **CHỈ ĐỊNH**
Sinh thiết các tổn thương ở ruột non sau khi tiến hành nội soi bằng viên nang phát hiện được.
Chảy máu do tổn thương nghi ngờ từ ruột non.
Chẩn đoán và điều trị các tổn thương làm hẹp ruột non.
Chẩn đoán khối u ruột non.
Bệnh Crohn ruột non.
Điều trị lấy dị vật ở ruột non.
Phát hiện các nguyên nhân gây tắc ruột.
Soi đại tràng các trường hợp khó.
### **CHỐNG CHỈ ĐỊNH**
Nghi ngờ hội chứng mạch vành cấp.
Tăng huyết áp chưa kiểm soát được.
Nghi ngờ thủng tạng rỗng.
Nghi ngờ phình, tách động mạch chủ.
Người bệnh trong tình trạng suy hô hấp.
Người bệnh suy tim nặng.
Người bệnh rối loạn tâm thần không hợp tác.
Chống chỉ định tương đối: tụt huyết áp huyết áp tâm thu < 90mmHg.
### **CHUẨN BỊ**
#### **Người thực hiện**
Bác sĩ: 01 bác sĩ đã có chứng chỉ tốt nghiệp nội soi Tiêu hóa.
Điều dưỡng: 02
#### **Phương tiện**
01 hệ thống máy nội soi bóng đơn bao gồm: dây soi SIF-Q180, 01 bóng overtube.
Máy bơm CO2
Máy C - arm.
Máy theo dõi lifescope và dụng cụ cấp cứu: mặt nạ, bóng bóp, nội khí quản.
Thuốc mê và tiền mê: midazolam 5mg: 2 ống, fantanyl 0,1 mg: 2 ống, propofol: 2 ống.
01 Kìm sinh thiết.
05 Lọ đựng bệnh phẩm.
Bơm tiêm 20 ml: 2 bơm.
Găng tay 6 đôi.
Áo mổ 02 cái
#### **Người bệnh**
Chuẩn bị người bệnh:
Giải thích người bệnh: mục đích, tai biến thủ thuật.
Các người bệnh nguy cơ cao: tuổi > 60, nghi ngờ có bệnh lý tim - phổi mạn tính cần làm thêm xét nghiệm điện tâm đồ và X quang tim phổi.
Chuẩn bị nội soi bóng kép qua đường miệng người bệnh cần chuẩn bị nhịn ăn.
Chuẩn bị nội soi bóng kép qua đường hậu môn người bệnh cần được thụt tháo, hoặc uống thuốc làm sạch đại tràng: tối ngày hôm trước tiến hành nội soi bóng kép uống sennoside trước khi đi ngủ, dùng polyethylene glycol.
#### **Hồ sơ bệnh án**
Kiểm tra không có chống chỉ định.
Nhận giấy chỉ định.
Giải thích cho người bệnh ký giấy đồng ý làm thủ thuật.
### **CÁC BƯỚC TIẾN HÀNH**
Mời người bệnh vào phòng, hướng dẫn người bệnh nằm lên cáng thủ thuật.
Mắc monitor theo dõi, theo chỉ định của bác sĩ soi.
Tiến hành gây mê theo chỉ định của bác sĩ.
Nội soi bóng đơn qua miệng hướng dẫn người bệnh nằm tư thế nghiêng trái, chân trên co, chân dưới duỗi. Cho người bệnh ngậm canun. Bắt đầu đưa máy soi và bóng có bôi trơn Xylocaine jelly qua đường miệng, khi máy soi vào dạ dày hút hơi và dịch dạ dày tránh để cuộn máy, khi máy nội soi tới hang vị đưa overtube vào hang vị, sau đó đưa máy nội soi đến đoạn ba tá tràng. Tiếp tục đưa overtube đến đoạn ba tá tràng, sau đó bơm bóng và cố định overtube ở đoạn ba tá tràng, rồi bắt đầu rút máy và overtube để làm ngắn ruột, sau đó tiếp tục đẩy máy soi vào góc Treitz và hỗng tràng, cố định đầu máy soi ở đây, tiếp tục tháo hơi bóng rồi đẩy overtube theo máy nội soi vào hồi tràng.
Cứ theo nguyên tắc đẩy và rút máy như vậy sẽ tiếp tục nội soi đến hết ruột non và quan sát niêm mạc ruột non. Ra y lệnh chụp ảnh minh họa tổn thương, hoặc sinh
**Hình 1. Hình ảnh minh họa các bước nội soi bóng đơn qua đường miệng**
Nội soi bóng đơn qua đường hậu môn cũng theo nguyên tắc đẩy và rút máy phối hợp với thay đổi tư thế người bệnh khi cần thiết, đưa máy qua đại tràng và van hồi manh tràng đến vị trí ruột non quan sát niêm mạc đại tràng và niêm mạc ruột non.
Theo dõi toàn trạng người bệnh trong toàn bộ quá trình làm thủ thuật.
Sau khi kết thúc thủ thuật, đánh và in kết quả.
Sau khi bác sĩ kết thúc quá trình nội soi, điều dưỡng phải giúp người bệnh lau miệng, đỡ người bệnh dậy và đưa người bệnh ra khỏi phòng nội soi tới nơi ngồi chờ.
Hướng dẫn người bệnh bổ sung thêm phiếu xét nghiệm sinh thiết nếu cần.
Điều dưỡng rửa máy theo quy trình kỹ thuật.
Trả kết quả nội soi cho người bệnh.
### **THEO DÕI**
Theo dõi toàn trạng người bệnh trong quá trình làm thủ thuật.
Theo dõi tình trạng thành bụng và ỉa máu (vì hai biến chứng hay gặp là thủng ruột non và chảy máu ruột non).
### **TAI BIẾN VÀ XỬ TRÍ**
Phát hiện và xử trí các biến chứng chảy máu khi lấy bệnh phẩm, mạch chậm hoặc ngừng tim do cường phế vị, biến chứng thủng ruột non, ghi vào phiếu trả kết quả hoặc cho người bệnh nhập viện xử trí tiếp tùy thuộc từng biến chứng.
### **TÀI LIỆU THAM KHẢO**
H. Niwa. H. Tajiri, M. Nakajima, K Yasuda (2008). New Challenges in Gastrointestinal Endoscopy. Springer. pp242-251
K laus F, R Schiller, Roy Cockel, Richard H. Hunt, Bryan F. Warren (2002).
Atlas of Gastrointestinal Endoscopy and Related Pathology. Blackwell Science. pp 453-458
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [Người thực hiện](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-ruot-non-bong-don-single-baloon-endoscopy#ngi-thc-hin)
  * [CÁC BƯỚC TIẾN HÀNH](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-ruot-non-bong-don-single-baloon-endoscopy#cc-bc-tin-hnh)
  * [TAI BIẾN VÀ XỬ TRÍ](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-ruot-non-bong-don-single-baloon-endoscopy#tai-bin-v-x-tr)
  * [TÀI LIỆU THAM KHẢO](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-ruot-non-bong-don-single-baloon-endoscopy#ti-liu-tham-kho)



## ️ Nội soi siêu âm can thiệp - chọc hút tế bào khối u gan, tụy, u ổ bụng bằng kim nhỏ

  * [Người thực hiện](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-sieu-am-can-thiep-choc-hut-te-bao-khoi-u-gan-tuy-u-o-bung-bang-kim-nho#ngi-thc-hin)
  * [CÁC BƯỚC TIẾN HÀNH](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-sieu-am-can-thiep-choc-hut-te-bao-khoi-u-gan-tuy-u-o-bung-bang-kim-nho#cc-bc-tin-hnh)
  * [THEO DÕI VÀ XỬ TRÍ TAI BIẾN](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-sieu-am-can-thiep-choc-hut-te-bao-khoi-u-gan-tuy-u-o-bung-bang-kim-nho#theo-di-v-x-tr-tai-bin)
  * [TÀI LIỆU THAM KHẢO](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-sieu-am-can-thiep-choc-hut-te-bao-khoi-u-gan-tuy-u-o-bung-bang-kim-nho#ti-liu-tham-kho)


### **ĐỊNH NGHĨA**
Chọc hút tế bào u gan, u tụy là kỹ thuật lấy bệnh phẩm để xét nghiệm tế bào học, mô bệnh học tại tổn thương và thủ thuật này được thực hiện dưới sự hướng dẫn của siêu âm nội soi.
### **CHỈ ĐỊNH**
**Khối u tụy**
Chẩn đoán và xử trí tổn thương nang tụy
Khối tổn thương quanh tụy
Tổn thương gan trái
**CHỐNG CHỈ ĐỊNH**
Người bệnh suy hô hấp, nhồi máu cơ tim.
Rối loạn đông máu nặng, giảm tiểu cầu.
Không thể quan sát tổn thương (trướng hơi, nhiều dịch trong ổ bụng).
Mạch máu lớn tại vị trí chọc hút.
Nguy cơ di căn theo kim chọc hút (tổn thương thân, đuôi tụy).
### **CHUẨN BỊ**
#### **Người thực hiện**
01 bác sĩ chuyên khoa, 02 điều dưỡng điều dưỡng (01 phụ giữ người bệnh, 01 hỗ trợ chọc hút tế bào).
#### **Dụng cụ**
Máy siêu âm nội soi, có đầu dò convex 360 và đầu dò linear để chọc hút.
Kim chọc hút: 19 Gauge (u dưới niêm mạc), 22 G ( u tụy), 25 G (hay dùng).
Các dụng cụ khác: bơm và kim tiêm, thuốc sát khuẩn, thuốc tiền mê (propofol, midazolam/ fentanyl), lam kính, cồn tuyệt đối để cố định tiêu bản, khăn trải có lỗ. Máy theo dõi mạch, huyết áp, SpO2.
#### **Người bệnh**
Đối với người bệnh ngoại trú nên nằm lưu tại bệnh viện vài ngày sau làm thủ thuật. Một số trường hợp chọc hút cần dùng kháng sinh đường uống 3 - 5 ngày.
Được giải thích trước về thủ thuật.
Chuẩn bị tương tự soi dạ dày.
Kiểm tra bilan đông máu, điều chỉnh các rối loạn đông máu.
### **CÁC BƯỚC TIẾN HÀNH**
#### **Người bệnh**
Nằm tư thế nghiêng trái, đầu và ngực hơi cao, vai trái hơi ra sau, chân phải gập ra trước (giống tư thế soi dạ dày).
#### **Tiền mê**
Propofol hoặc midazolam/fentanyl đường tĩnh mạch hoặc đặt nội khí quản tùy trường hợp. Mắc monitor theo dõi mạch, huyết áp, nhiệt độ, nhịp thở.
#### **Kỹ thuật**
Đưa đầu dò siêu âm nội soi xuống tá tràng, sau đó rút dần đầu dò siêu âm lên để xác định vị trí chọc khối u.
Nguyên tắc là lựa chọn vị trí sinh thiết trên mặt cắt “thẳng và đường ngắn”.
**Kỹ thuật chọc hút:**
Trước khi chọc hút, xác định vị trí và hình ảnh tổn thương trên siêu âm nội soi và xác định vị trí không có mạch máu đan xen bằng mở phổ siêu âm doppler đánh giá. Bằng việc sử dụng tần số có thể thay đổi phạm vi đầu dò (sâu/nông) để tìm vị trí chọc hút mà không có mạch máu đi qua.
Siêu âm hoặc nội soi xác định vỏ của kim chọc hút bằng cách đẩy thử qua kênh sinh thiết, nếu đẩy khó qua có thể bị gập góc nên cần phải điểu chỉnh để có thể đẩy qua mà không gặp cản trở. Một cách để tìm đường cho kim chọc hút qua được ống soi là gập đầu ống soi xuống ở vị trí thẳng giúp hạn chế tổn thương đầu dò khi đưa kim chọc hút qua.
Đo khoảng cách xa nhất từ đầu kim chọc hút tới vị trí chọc để không chọc quá vị trí tổn thương.
Đẩy kim qua lớp niêm mạc vào hướng vào trong tổn thương dưới hướng dẫn siêu âm nội soi.
Rút nòng ra khỏi kim và nối kim vào một bơm tiêm và hút với áp lực âm, sau đó di chuyển kim qua lại bên trong tổn thương.
Lưu ý: Không đưa kim ra khỏi vị trí sinh thiết khi trong quá trình lấy tế bào. Do đầu ống soi sẽ di chuyển cùng với kim trong quá trình chọc hút, nên cần phải giữ chắc trục của ống soi để quan sát được kim trên siêu âm trong quá trình làm thủ thuật.
Lấy bệnh phẩm bằng cách đẩy nòng (stylet) qua kim chọc hút hoặc bơm nước muối sinh lý hoặc bơm khí.
Gửi xét nghiệm tế bào học.
### **THEO DÕI VÀ XỬ TRÍ TAI BIẾN**
Người bệnh sau làm thủ thuật cần được theo dõi trên 6 giờ, không cần lưu tại bệnh viện vài ngày.
Biến chứng khi chọc hút dưới siêu âm nội soi khoảng 2 - 6% .
Nhiễm trùng.
Chảy máu, tụ máu trong thành ruột.
Viêm tụy cấp (chọc tổn thương tụy).
### **TÀI LIỆU THAM KHẢO**
Bệnh viện Bạch Mai, Khoa Tiêu hóa (2001) “Ứng dụng nội soi trong chẩn đoán và điều trị bệnh lý tiêu hóa” trang 127-140.
Gress.F, Savides.T (2007) “ Endoscopic Ultrasonography” page 110 -128.
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [Người thực hiện](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-sieu-am-can-thiep-choc-hut-te-bao-khoi-u-gan-tuy-u-o-bung-bang-kim-nho#ngi-thc-hin)
  * [CÁC BƯỚC TIẾN HÀNH](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-sieu-am-can-thiep-choc-hut-te-bao-khoi-u-gan-tuy-u-o-bung-bang-kim-nho#cc-bc-tin-hnh)
  * [THEO DÕI VÀ XỬ TRÍ TAI BIẾN](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-sieu-am-can-thiep-choc-hut-te-bao-khoi-u-gan-tuy-u-o-bung-bang-kim-nho#theo-di-v-x-tr-tai-bin)
  * [TÀI LIỆU THAM KHẢO](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-sieu-am-can-thiep-choc-hut-te-bao-khoi-u-gan-tuy-u-o-bung-bang-kim-nho#ti-liu-tham-kho)



## ️ Nội soi can thiệp - mở thông dạ dày

**ĐẠI CƯƠNG**
Mở thông dạ dày là kỹ thuật tạo một lỗ mở trực tiếp vào dạ dày để nuôi dưỡng người bệnh tạm thời hoặc vĩnh viễn.
**CHỈ ĐỊNH**
Nuôi dưỡng qua đường tiêu hóa lâu dài do: ung thư thực quản, hầu, họng không có khả năng phẫu thuật.
Nuôi dưỡng tạm thời: hẹp thực quản do bỏng, viêm và sau phẫu thuật lớn ở bụng cần được nuôi dưỡng bổ sung, chấn thương nặng vùng sọ và mặt.
Nuôi dưỡng trong các trường hợp dinh dưỡng kém do: rối loạn thần kinh sau tai biến mạch máu não, hôn mê kéo dài, u não, người bệnh cao tuổi có rối loạn tâm thần kèm suy dinh dưỡng, suy dinh dưỡng nặng (ở các người bệnh ung thư, suy tim, suy hô hấp).
**CHỐNG CHỈ ĐỊNH**
Có bệnh lý dạ dày từ trước (loét hay ung thư).
Rối loạn đông máu nặng.
Gan lách quá to.
Người bệnh quá béo, cổ trướng.
Suy thận đang được điều trị bằng lọc màng bụng.
Rò ở đoạn cao của ruột non, tắc ruột non.
Cắt toàn bộ dạ dày.
**CHUẨN BỊ**
**Người thực hiện**
01 bác sĩ và 02 điều dưỡng thành thục kỹ thuật.
**Phương tiện**
Dàn máy nội soi, dây soi có kênh thủ thuật.
Kìm sinh thiết.
Kim khâu da, chỉ khâu.
Bông, băng, gạc
Kít để mở thông dạ dày qua nội soi (có nhiều loại kít Bard, Ansell Medical, ABS, cook,…).
**Người bệnh**
Người bệnh phải nhịn ăn tối thiểu 6 giờ.
Người bệnh hoặc người nhà người bệnh phải được giải thích trước và ký giấy cam đoan đồng ý làm thủ thuật.
**Hồ sơ bệnh án**
Người bệnh sau khi tiến hành thủ thuật phải được ghi vào Phiếu kết quả nội soi để trả lại cho người bệnh. Nếu người bệnh nội trú thì dán kết quả vào bệnh án.
Giấy cam đoan đồng ý làm thủ thuật phải được lưu tối thiểu 6 tháng.
**CÁC BƯỚC TIẾN HÀNH**
Nội soi dạ dày theo quy trình để kiểm tra tình trạng dạ dày, tá tràng.
Thay đổi tư thế người bệnh sang nằm ngửa nhưng đầu vẫn giữ nghiêng trái.
Bơm hơi căng để thành dạ dày sát vào thành bụng.
Xác định vị trí chọc troca qua ánh đèn sáng lên thành bụng, lấy ngón tay ấn vào chỗ sáng rồi qua đèn soi kiểm tra chỗ ngón tay lồi vào thành dạ dày.
Vị trí đặt ống thông tốt nhất là ở giữa mặt trước của hang vị hoặc ranh giới giữa hang vị và thân vị.
Ở trên da, đường chọc thường ở đoạn giữa nối bờ trái và rốn nhưng cũng có thay đổi nên dựa vào nội soi.
Sau khi gây tê tại chỗ, dùng dao nhọn rạch da rộng 1cm rồi dùng panh bóc tách sâu hơn, chọc troca qua da, qua thành bụng vào khoang dạ dày dưới kiểm soát của nội soi.
Luồn dây mềm qua troca vào dạ dày rồi cho kìm sinh thiết vào cặp dây, sau đó kéo cả máy và kìm sinh thiết ra ngoài.
Buộc dây vào đầu có sợi chỉ của ống thông, rồi từ từ kéo đầu dây còn ở phía ngoài thành bụng để kéo ống thông vào dạ dày, kéo cho tới khi đầu trong của ống thông được kéo sát vào thành dạ dày.
Cho đèn vào lại để kiểm tra vị trí đúng của ống thông và kiểm tra xem có chảy máu không.
Cố định đầu ống thông ngoài thành bụng, khâu dưới da.
Cắt chỉ để lại đoạn ống thông dài 15cm. Lắp nắp ống thông và băng lại.
**THEO DÕI**
Kháng sinh dự phòng: Augmentin 1g tiêm tĩnh mạch trước và sau thủ thuật 4 giờ.
Bơm thức ăn có thể tiến hành 24 giờ sau khi làm thủ thuật.
**TAI BIẾN VÀ XỬ TRÍ**
**Biến chứng nhẹ**
Hội chứng bán tắc và đau bụng, sốt nhẹ: điều trị kháng sinh.
Trào ngược dạ dày - thực quản.
Nhiễm khuẩn thành bụng, có khi tạo thành khối ở thành bụng.
Tụ máu thành loét quanh chỗ đặt ống thông.
Tràn khí phúc mạc.
**Biến chứng nặng**
Rò dạ dày, đại tràng.
Chảy máu dạ dày.
Viêm phúc mạc.
Hoại tử thành.
Ống thông bị tuột, rơi vào gây tắc ruột.
Trong khi thủ thuật: co thắt thanh quản, ngừng tim, trào ngược dịch dạ dày vào phổi.
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh

## ️ Nội soi mật tụy ngược dòng can thiệp - lấy sỏi, giun đường mật

**ĐẠI CƯƠNG**
Nội soi mật tụy ngược dòng (NSMTND) can thiệp - lấy sỏi, giun đường mật là tiến hành nội soi mật tụy ngược dòng có cắt cơ vòng Oddi với mục đích để lấy sỏi hoặc giun ống mật chủ.
**CHỈ ĐỊNH**
Lấy sỏi ống mật chủ.
Lấy giun trong ống mật chủ.
**CHỐNG CHỈ ĐỊNH**
Người bệnh mới bị nhồi máu cơ tim
Bệnh lý tim phổi nặng
Dị ứng với thuốc cản quang
Rối loạn đông máu nặng
Giảm tiểu cầu
Đang dùng thuốc chống kết tập tiểu cầu.
**CHUẨN BỊ**
**Người thực hiện**
01 bác sĩ chuyên làm NSMTND, 01 kỹ thuật viên gây mê, 03 điều dưỡng trong đó có điều dưỡng phải sử dụng được máy C - Arm.
**Phương tiện, thuốc, vật tư y tế**
**Phương tiện**
Phòng nội soi cho phép chiếu tia Xquang, có hệ thống oxy.
Máy tăng sáng xquang (C. Arm)
Hệ thống máy nội soi tá tràng (máy nội soi cửa sổ bên) với kênh làm thủ thuật có đường kính 4,2 mm, canun.
Nguồn cắt đốt.
Máy theo dõi lifescope và dụng cụ cấp cứu: mặt nạ, bóng bóp, nội khí quản
Bộ nghiền sỏi
Áo chì 5 bộ
**Thuốc và trang thiết bị vật tư tiêu hao.**
**_Thuốc_**
Thuốc mê và tiền mê: midazolam 5mg từ 1 - 4 ống, fantanyl 0,1 mg từ 1 - 3 ống, propofol 20 ml 1 - 4 ống
Thuốc cản quang 50ml (telebrix, xenetix ) 1 - 2 lọ.
**_Vật tư_**
01catheter, 02 guidewire, 01 dao cắt cơ vòng Oddi, 01 bóng lấy sỏi, 01 rọ lấy sỏi, 01 rọ tán sỏi.
Stent đường mật: 02 stent nhựa
Stent đường tụy: 01
Găng tay 10 đôi
Áo mổ 02.
**Người bệnh**
Nhịn ăn trước khi làm thủ thuật 8 giờ.
Đặt đường truyền tĩnh mạch.
**Hồ sơ bệnh án**
Người bệnh được làm hồ sơ vào viện điều trị nội trú, đã được làm các xét nghiệm cơ bản, như: chức năng gan, thận, nhóm máu, đông máu cơ bản, chức năng tụy, các marker virus, điện tâm đồ.
**CÁC BƯỚC TIẾN HÀNH**
**Kiểm tra hồ sơ**
Để đảm bảo có thể tiến hành tiền mê hoặc gây mê, đảm bảo có thể tiến hành thủ thuật gây chảy máu.
**Kiểm tra người bệnh**
Đánh giá chức năng sống của người bệnh để đảm bảo an toàn trước khi làm thủ thuật, đã tuân thủ nhịn ăn trước đó. 3. Thực hiện kỹ thuật
**Đưa máy xuống tá tràng**
Máy nội soi qua thực quản "bán mù", do đó không quan sát được toàn bộ thực quản.
Máy nội soi vào dạ dày: Đưa đầu dây nội soi qua thân vị và hang vị để đến lỗ môn vị rồi vào hành tá tràng.
Máy qua gối trên tá tràng vào đoạn II tá tràng: Quay đầu máy soi lên trên ở vị trí trung gian và đẩy máy vào đoạn II tá tràng. Quay máy 900 sang bên phải với đầu máy quay sang phải và lên trên sẽ nhìn thấy phần giữa của đoạn II tá tràng và papilla. Rút máy ra để máy đi dọc theo góc bờ cong nhỏ và nằm trong dạ dày đoạn ngắn nhất khoảng 60 - 70 cm cách cung răng trên. Thường để ống soi ở vị trí ngắn nhất cho phép quan sát trực diện với papilla để luồn catheter vào papilla được thuận lợi.
**Tìm papilla**
Cho người bệnh nằm hơi sấp sẽ nhìn thấy trực diện papilla nằm ở đoạn DIII tá tràng có hình dáng và kích thước khác nhau. Papilla có màu hồng sẫm hơn màu hồng của niêm mạc tá tràng, phía trên có nếp niêm mạc to trùm lên trên papilla gọi là mũ papilla, phía dưới có những nếp niêm mạc chạy dọc hội tụ vào papilla, ở đỉnh papilla có lỗ tiết mật, có kích thước to nhỏ khác nhau, qua lỗ này có thể thấy dịch mật chảy vào tá tràng.
**Luồn Catheter vào papilla để bơm thuốc cản quang**
Việc thành công của thủ thuật này tùy theo kinh nghiệm của người làm thủ thuật, tùy theo hình dạng và tổn thương ở papilla. Để đầu catheter đối diện với papilla, đẩy từ từ vào và hướng lên vị trí 11giờ theo hướng của đường mật chính. Đưa sâu catheter vào 3 - 5 cm để chụp đường mật. Tốt nhất là đầu catheter nằm sâu vào đường mật ở ngã ba đường mật (đi qua chỗ đổ của túi mật vào ống mật chủ). Khi bơm thuốc, thuốc sẽ tỏa đều vào đường mật.
**Bơm thuốc chụp đường mật tụy**
Nồng độ thuốc cản quang: thuốc cản quang được pha loãng với nước cất với tỉ lệ 50%. Số lượng thuốc cản quang: từ 30ml - 100ml, tuỳ theo mức độ giãn đường mật. Khi chụp đường tuỵ không nên bơm nhiều thuốc cản quang, vì nếu bơm nhiều sẽ làm tăng áp lực đường tuỵ gây biến chứng viêm tuỵ.
**Cắt cơ vòng Oddi đường mật**
Đưa dây dẫn vào qua catheter sau khi chụp đường mật lên nhánh gan phải sau đó rút catheter ra, đưa dao cắt vào theo dây dẫn. Tiến hành cắt cơ vòng Oddi.
Có thể tiến hành cắt cơ vòng Oddi tối đa tới mũ của papilla.
**Nong****cơ vòng Oddi**
Trong trường hợp sỏi nhỏ hoặc giun trong ống mật chủ có thể không cần cắt cơ vòng Oddi mà chỉ cần tiến hành dùng bóng nong cơ vòng Oddi để lấy sỏi hoặc giun (kỹ thuật nội soi mật tụy ngược dòng can thiệp nong đường mật bằng bóng).
**Lấy sỏi và giun ống mật chủ**
Tùy theo kích thước của sỏi mà tiến hành lấy bằng các dụng cụ khác nhau.
Đối với sỏi kích thước dưới 8 mm có thể lấy sỏi bằng rọ thường không cần tán sỏi. Sỏi mật từ 8 đến dưới 10 mm có thế lấy bằng rọ thường nếu cơ vòng Oddi được cắt tối đa. Trong trường hợp nếu cơ vòng Oddi không được cắt tối đa, cần dùng bộ tời để tán sỏi, sau đó lấy sỏi đã tán bằng rọ thường và cuối cùng dùng bóng để lấy phần cặn sỏi còn lại.
Sỏi mật từ 10 - 20 mm cần dùng bộ tời để tán sỏi, sau đó lấy sỏi đã tán bằng rọ thường và cuối cùng dùng bóng để lấy phần cặn sỏi còn lại.
Nếu sỏi lớn ống mật chủ mà không lấy được ngay, thì đặt 2 stent vào ống mật chủ sau 3 tháng để sỏi mềm ra và nhỏ lại khi đó có thể lấy sỏi thì 2.
Đối với giun có thể cắt cơ oddi và dùng rọ thường hoặc bóng để lấy giun giống như với lấy sỏi nhỏ dưới 8 mm.
Trong trường hợp tiến hành thủ thuật lâu hoặc có nguy cơ cao viêm tụy sau lấy sỏi cần đặt stent đường tụy dự phòng.
**THEO DÕI**
Theo dõi những biến chứng của gây mê như suy hô hấp, tụt huyết áp.
Theo dõi phát hiện viêm tụy cấp: đau bụng, tình trạng ổ bụng, xét nghiệm amylase và lipase sau thủ thuật.
Theo dõi thủng tá tràng: tình trạng bụng, chụp cắt lớp nếu thấy nghi ngờ thủng ra khoang sau phúc mạc.
**TAI BIẾN VÀ XỬ TRÍ**
Hàng đầu là viêm tụy cấp với tỉ lệ khoảng 5%. Nhịn ăn, nuôi dưỡng bằng đường tĩnh mạch, dùng kháng sinh nếu có biểu hiện nhiễm trùng hoặc trước đó người bệnh có nhiễm trùng đường mật.
Thủng tá tràng do cắt cơ vòng Oddi, hay gặp ở những trường hợp có túi thừa tá tràng, papilla nằm cạnh hoặc trong túi thừa. Điều trị phẫu thuật.
Chảy máu do cắt cơ vòng Oddi. Nội soi cầm máu.
Biến chứng liên quan tới gây mê: tụt huyết áp, suy hô hấp, buồn nôn hoặc nôn. Tiến hành truyền dịch, thở oxy.
**TÀI LIỆU THAM KHẢO**
Bộ Y tế, Quy trình kỹ thuật bệnh viện.
Sivak M. V. Gastroenterologic Endoscopy 1987
Baron T.H. ERCP 2008
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh

## ️ Nội soi can thiệp - tiêm cầm máu

**ĐẠI CƯƠNG**
Nội soi can thiệp tiêm cầm máu là một phương pháp can thiệp điều trị nhằm mục đích cầm chảy máu tổn thương qua nội soi ống tiêu hoá. Biện pháp này có thể áp dụng cho tổn thương ở bất kể vị trí nào trong quá trình nội soi với ưu điểm là kỹ thuật đơn giản, rẻ tiền, có thể áp dụng dễ dàng. Cơ chế tác dụng dung dịch tiêm gồm nước muối sinh lý pha Adrenalin gây phồng lớp tổ chức dưới niêm mạc ép vào mạch máu đang chảy máu để làm cầm máu và Adrenalin gây co mạch tại chỗ. Tuy nhiên ngày nay không khuyến cáo dùng đơn thuần phương pháp này mà phối hợp với các phương pháp cầm máu khác.
**CHỈ ĐỊNH**
Ổ loét niêm mạc ống tiêu hoá đang chảy máu hoặc có dấu hiệu vừa chảy máu có nguy cơ tái xuất huyết cao (Phân loại Forrest độ IA, IB, IIA, IIB).
Rách tâm vị chảy máu.
Sau can thiệp qua nội soi tiêu hoá, tổn thương chảy máu hoặc có nguy cơ cao chảy máu có thể chỉ định tiêm cầm máu.
**CHỐNG CHỈ ĐỊNH**
Người bệnh đang trong tình trạng sốc giảm thể tích tuần hoàn, huyết áp dưới 90/60 mmHg.
Người bệnh nghi ngờ nhồi máu cơ tim, hội chứng mạch vành cấp, phình tách động mạch chủ, rối loạn nhịp tim phức tạp, tăng huyết áp không kiểm soát được, suy hô hấp.
Các trường hợp nghi ngờ thủng ống tiêu hoá.
Người bệnh không thể hợp tác được (bệnh lý tâm thần kinh), nếu bắt buộc soi phải sử dụng thuốc tiền mê.
Người bệnh có thai, nếu bắt buộc phải nội soi can thiệp phải giải thích trước cho người nhà và người bệnh các nguy cơ rủi ro cho thai và được sự đồng ý của người bệnh và gia đình, có ghi vào giấy cam đoan đồng ý làm thủ thuật.
**CHUẨN BỊ**
**Người thực hiện**
01 bác sĩ và 02 điều dưỡng thành thục kỹ thuật nội soi tiêm cầm máu.
**Phương tiện**
Dàn máy nội soi, dây soi có kênh thủ thuật.
Kim tiêm cầm máu qua nội soi: nên sử dụng kim có đầu vát ngắn khoảng 4 - 5mm.
Thuốc tiêm cầm máu: nước muối sinh lý, Adrenalin 1/10.000 x 2 ống
Bơm tiêm nhựa 10ml x 1 cái.
Thuốc tiền mê: Midazolam, Fentanyl. Trong trường hợp người bệnh kích thích cần sử dụng thuốc tiền mê.
**Người bệnh**
Người bệnh phải nhịn ăn tối thiểu 6 giờ. Nếu < 6 giờ và cần phải nội soi can thiệp ngay thì người bệnh phải được rửa dạ dày sạch trước soi.
Người bệnh hoặc người nhà người bệnh phải được giải thích trước và ký giấy cam đoan đồng ý làm thủ thuật. Trường hợp cấp cứu, người bệnh phải được hồi sức tích cực trước soi, bao gồm đặt đường truyền tĩnh mạch truyền dịch, truyền máu để bù thể tích tuần hoàn, thở oxy kính, mắc monitor theo dõi trước khi làm nội soi. Người bệnh suy hô hấp, rối loạn ý thức phải được đặt nội khí quản, kiểm soát tình trạng hô hấp trước soi.
**Hồ sơ bệnh án**
Người bệnh sau khi tiến hành thủ thuật phải được ghi vào Phiếu kết quả nội soi để trả lại cho người bệnh.
Giấy cam đoan đồng ý làm thủ thuật phải được lưu tối thiểu 6 tháng.
**CÁC BƯỚC TIẾN HÀNH**
Tiến hành nội soi tiêu hoá thông thường. Khi thấy tổn thương đang chảy máu hoặc đã chảy máu nhưng có nguy cơ tái phát chảy máu cao, hoặc các tổn thương sau can thiệp thủ thuật gây chảy máu hoặc có nguy cơ chảy máu cao thì tiến hành tiêm cầm máu.
Pha dung dịch Natriclorua và Adrenalin theo tỷ lệ Adrenalin 1mg/1ml + 9ml Natriclorua 0,9% vào bơm tiêm nhựa 10ml. Trong trường hợp không có Adrenalin, có thể sử dụng Natriclorua 0,9% đơn thuần, Natriclorua ưu trương hoặc nước cất.
Nên tiêm mỗi lần 1 - 2ml vòng quanh rìa ổ loét. Nếu ổ loét lớn và sâu thì tiêm ở quanh vị trí gây chảy máu hoặc mạch máu nhìn thấy. Tối đa tiêm 20ml dung dịch Adrenalin và Natriclorua.
Kiểm tra tổn thương sau tiêm cầm chảy máu.
Nếu đánh giá thấy nguy cơ tái chảy máu cao, nên phối hợp thêm các biện pháp cầm máu khác như kẹp clip, cầm máu bằng nhiệt.
**THEO DÕI TAI BIẾN**
Lưu ý người bệnh can thiệp trong tình trạng cấp cứu có nguy cơ rối loạn chức năng tuần hoàn, hô hấp. Luôn phải theo dõi tình trạng người bệnh trong quá trình làm thủ thuật.
Tiêm cầm máu bằng Adrenalin đơn thuần có nguy cơ tái chảy máu cao hơn so với phối hợp tiêm cầm máu bằng Adrenalin với kẹp clip hoặc cầm máu bằng nhiệt. Vì vậy cần theo dõi kỹ người bệnh nhằm phát hiện kịp thời các trường hợp chảy máu lại để xử trí thích hợp.
Theo dõi các biến chứng khác của nội soi tiêu hoá, đặc biệt là thủng ống tiêu hoá.
Các tác dụng phụ do Adrenalin: hầu như hiếm gặp.
**TÀI LIỆU THAM KHẢO**
Nib Soehendra, Kenneth F. Binmoeller, Hans Seifert, Hans Wilhelm Schreiber,
“Therapeutic Endoscopy - Color atlas of operative techniques for the gastrointestinal tract”, Thieme 2005.
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh

## ️ Nội soi mật tụy ngược dòng - (ERCP)

**ĐẠI CƯƠNG**
Nội soi mật tụy ngược dòng (NSMTND) là kỹ thuật nội soi tá tràng dưới màn tăng sáng X quang để chẩn đoán và điều trị một số bệnh lý đường mật và tụy tạng. Kỹ thuật được tiến hành đưa catheter vào đường mật hoặc đường tụy qua máy nội soi tá tràng, qua đó bơm thuốc cản quang vào đường mật hoặc đường tụy với mục đích chẩn đoán và điều trị bệnh lý của đường mật và đường tụy. Ngày nay, NSMTND chủ yếu để sử dụng cho điều trị, ít sử dụng cho mục đích chẩn đoán vì có nhiều phương pháp chẩn đoán hình ảnh với độ nhạy cao và an toàn hơn.
**CHỈ ĐỊNH**
**Chẩn đoán**
Vàng da tắc mật ngoài gan chưa rõ nguyên nhân
Giãn đường mật
Sỏi túi mật mà có giãn ống mật chủ
U đường mật
Rối loạn chức năng vận động cơ Oddi
Giãn ống tụy
**Điều trị**
Cắt cơ Oddi
Lấy sỏi ống mật chủ
Lấy sỏi tụy
Dẫn lưu mật mũi
Đặt stent đường mật:
Ung thư đường mật vùng rốn gan.
Ung thư đường mật vùng ngoài rốn gan khi không còn khả năng phẫu thuật.
Hẹp đường mật lành tính.
Sỏi lớn ống mật chủ chưa thể lấy ngay được.
Sỏi ống mật chủ nhưng người bệnh trong tình trạng nặng không cho phép lấy sỏi.
Nhiễm trùng đường mật cần dẫn lưu.
Đặt stent đường tụy.
**CHỐNG CHỈ ĐỊNH**
Người bệnh mới bị nhồi máu cơ tim
Bệnh lý tim phổi nặng
Dị ứng với thuốc cản quang
Rối loạn đông máu nặng
Giảm tiểu cầu
Đang dùng thuốc chống kết tập tiểu cầu.
**CHUẨN BỊ**
**Người thực hiện**
01 bác sĩ chuyên làm NSMTND, 01 kỹ thuật viên gây mê, 03 điều dưỡng trong đó có điều dưỡng phải sử dụng được máy C- Arm.
**Phương tiện, thuốc, vật tư tiêu hao**
**Phương tiện**
Phòng nội soi cho phép chiếu tia Xquang, có hệ thống oxy -Máy tăng sáng X quang (C.Arm).
Hệ thống máy nội soi tá tràng (máy nội soi cửa sổ bên) với kênh làm thủ thuật có đường kính 4,2mm, canun.
Nguồn cắt đốt.
Máy theo dõi lifescope và dụng cụ cấp cứu: mặt nạ, bóng bóp, nội khí quản
Áo chì 05 bộ
Bộ nghiền sỏi và bơm bóng nong cơ Oddi
**Thuốc**
Thuốc mê và tiền mê: midazolam 5mg từ 1 - 4 ống, fantanyl 0,1 mg từ 1 - 3 ống, propofol 20 ml 1 - 4 ống
Thuốc cản quang (telebrix, xenetix ) 50ml 1 - 2 lọ
**Vật tư tiêu hao**
01catheter, 02 guidewire, 01 dao cắt cơ Oddi, 01bóng lấy sỏi, 01 bóng nong cơ Oddi,
01 rọ lấy sỏi, 01 rọ tán sỏi.
Stent đường mật: 02 stent kim loại hoặc 02 stent nhựa
Stent đường tụy: 01
Găng tay 10 đôi
Áo mổ 02 chiếc
Người bệnh
Nhịn ăn trước khi làm thủ thuật 8 giờ
Đặt đường truyền tĩnh mạch
Hồ sơ bệnh án
Người bệnh được làm hồ sơ vào viện điều trị nội trú, đã được làm các xét nghiệm cơ bản, như: chức năng gan, thận, nhóm máu, đông máu cơ bản, chức năng tụy, các marker virus, điện tâm đồ.
**CÁC BƯỚC TIẾN HÀNH**
**Kiểm tra hồ sơ**
Để đảm bảo có thể tiến hành tiền mê hoặc gây mê, đảm bảo có thể tiến hành thủ thuật gây chảy máu.
Kiểm tra người bệnh
Đánh giá chức năng sống của người bệnh để đảm bảo an toàn trước khi làm thủ thuật, đã tuân thủ nhịn ăn trước đó.
Thực hiện kỹ thuật
Sau khi người bệnh được tiền mê hoặc gây mê, sẽ tiến hành thủ thuật:
**Đưa máy xuống tá tràng**
Máy nội soi qua thực quản "bán mù", do đó không quan sát được toàn bộ thực quản.
Máy nội soi vào dạ dày: Đưa đầu dây nội soi qua thân vị và hang vị để đến lỗ môn vị rồ vào hành tá tràng.
Máy qua gối trên tá tràng vào đoạn II tá tràng: Quay đầu máy soi lên trên ở vị trí trung gian và đẩy máy vào đoạn II tá tràng. Quay máy 900 sang bên phải với đầu máy quay sang phải và lên trên sẽ nhìn thấy phần giữa của đoạn II tá tràng và papilla. Rút máy ra để máy đi dọc theo góc bờ cong nhỏ và nằm trong dạ dày đoạn ngắn nhất khoảng 60-70 cm cách cung răng trên. Thường để ống soi ở vị trí ngắn nhất cho phép quan sát trực diện với papilla để luồn catheter vào papilla được thuận lợi.
**Tìm papilla**
Cho người bệnh nằm hơi sấp sẽ nhìn thấy trực diện papilla nằm ở đoạn DIII tá tràng có hình dáng và kích thước khác nhau. Papilla có màu hồng sẫm hơn màu hồng của niêm mạc tá tràng, phía trên có nếp niêm mạc to trùm lên trên papilla gọi là mũ papilla, phía dưới có những nếp niêm mạc chạy dọc hội tụ vào papilla, ở đỉnh papilla có lỗ tiết mật, có kích thước to nhỏ khác nhau, qua lỗ này có thể thấy dịch mật chảy vào tá tràng.
Luồn Catheter vào papilla để bơm thuốc cản quang
Việc thành công của thủ thuật này tùy theo kinh nghiệm của người làm thủ thuật, tùy theo hình dạng và tổn thương ở papilla. Để đầu catheter đối diện với papilla, đẩy từ từ vào và hướng lên vị trí 11giờ theo hướng của đường mật chính, để vào đường tụy hướng vào vị trí 1giờ theo hướng của ống tuỵ. Đưa sâu catheter vào 3 - 5 cm để chụp đường mật. Tốt nhất là đầu catheter nằm sâu vào đường mật ở ngã ba đường mật (đi qua chỗ đổ của túi mật vào ống mật chủ). Khi bơm thuốc, thuốc sẽ tỏa đều vào đường mật.
**Bơm thuốc chụp đường mật hoặc đường tụy**
Nồng độ thuốc cản quang: thuốc cản quang được pha loãng với nước cất với tỉ lệ 50%.
Số lượng thuốc cản quang: từ 30ml - 100ml, tuỳ theo mức độ giãn đường mật. Khi chụp đường tuỵ không nên bơm nhiều thuốc cản quang, vì nếu bơm nhiều sẽ làm tăng áp lực đường tuỵ gây biến chứng viêm tuỵ.
Chụp đường tụy bằng 5 - 10 ml thuốc cản quang.
**Các thủ thuật điều trị**
Tùy theo từng loại bệnh mà có thể tiến hành các thủ thuật tiếp theo như: cắt cơ Oddi, lấy sỏi và đặt stent đường mật hoặc đường tụy.
**THEO DÕI**
Theo dõi những biến chứng của gây mê như suy hô hấp, tụt huyết áp.
Theo dõi phát hiện viêm tụy cấp: đau bụng, tình trạng ổ bụng, xét nghiệm amylase và lipase sau thủ thuật.
Theo dõi thủng tá tràng: tình trạng bụng, chụp cắt lớp nếu thấy nghi ngờ thủng ra khoang sau phúc mạc.
**TAI BIẾN VÀ XỬ TRÍ**
Hàng đầu là viêm tụy cấp với tỉ lệ khoảng 5%. Nhịn ăn, nuôi dưỡng bằng đường tĩnh mạch dùng kháng sinh nếu có biểu hiện nhiễm trùng hoặc trước đó người bệnh có nhiễm trùng đường mật.
Thủng tá tràng do cắt cơ Oddi, hay gặp ở những trường hợp có túi thừa tá tràng, papilla nằm cạnh hoặc trong túi thừa. Điều trị phẫu thuật.
Viêm đường mật, hay xảy ra trong trường hợp tắc mật do ung thư đường mật mà sau nội soi chụp mật tụy ngược dòng mà không đặt được stent. Dùng kháng sinh và dẫn lưu mật qua da trong trường hợp thất bại dẫn lưu mật qua papilla.
Chảy máu do cắt cơ Oddi. Nội soi cầm máu.
Biến chứng liên quan tới gây mê: tụt huyết áp, suy hô hấp, buồn nôn hoặc nôn. Tiến hành truyền dịch, thở oxy.
**TÀI LIỆU THAM KHẢO**
Bộ Y tế, Quy trình kỹ thuật bệnh viện.
Sivak M. V. Gastroenterologic Endoscopy 1987
Baron T.H. ERCP 2008
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh

## ️ Nội soi dạ dày được hiểu là gì? Khi nào cần nội soi dạ dày?

  * [1. Định nghĩa nội soi dạ dày - phương pháp y khoa phổ biến hiện nay](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-da-day-duoc-hieu-la-gi-khi-nao-can-noi-soi-da-day#1-nh-ngha-ni-soi-d-dy-phng-php-y-khoa-ph-bin-hin-nay)
  * [2. Khi nào cần nội soi dạ dày?](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-da-day-duoc-hieu-la-gi-khi-nao-can-noi-soi-da-day#2-khi-no-cn-ni-soi-d-dy)
  * [3. Quy trình thực hiện và mức chi phí cho nội soi dạ dày](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-da-day-duoc-hieu-la-gi-khi-nao-can-noi-soi-da-day#3-quy-trnh-thc-hin-v-mc-chi-ph-cho-ni-soi-d-dy)
  * [3.1. Các bước thực hiện](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-da-day-duoc-hieu-la-gi-khi-nao-can-noi-soi-da-day#31-cc-bc-thc-hin)
  * [3.2. Mức chi phí chính cho nội soi dạ dày hiện nay](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-da-day-duoc-hieu-la-gi-khi-nao-can-noi-soi-da-day#32-mc-chi-ph-chnh-cho-ni-soi-d-dy-hin-nay)


## **1. Định nghĩa nội soi dạ dày - phương pháp y khoa phổ biến hiện nay**
**Nội soi dạ dày** là phương pháp can thiệp chẩn đoán các vấn đề bên trọng của dạ dày bằng cách thức nội soi. Cụ thể hơn, bác sĩ sẽ sử dụng công cụ là 1 ống soi mỏng đường kính 9mm. Ống soi này có độ mềm khá an toàn khi tiến hành đưa vào khoang miệng, thăm khám trong thực quản. Thêm vào đó, bệnh nhân còn được nội soi tích hợp vào đường tiêu hóa.
_Nội soi dạ dày được ứng dụng phổ biến_
Dựa vào hình ảnh nội soi trên máy nội soi, bác sĩ quan sát đánh giá ống tiêu hóa trên để ra chẩn đoán và điều trị phù hợp. Các phương pháp nội soi dạ dày hiện nay được đánh giá là không quá gây đau cho bệnh nhân, hợp với các độ tuổi. Về tiến trình điều trị nội soi dạ dày hiện nay cũng cực kỳ nhanh và không gây tốn kém. 
Nội soi dạ dày sẽ giúp bạn phát hiện và thăm khám bệnh triệt để và tốt hơn. Có những vấn đề bệnh lý liên quan đến dạ dày và chỉ có nội soi mới có thể phát hiện được. Lấy ví dụ như các vấn đề bệnh như: ung thư dạ dày, viêm loét hay có thể là loại bỏ những dị vật. Nhìn chung, nội soi dạ dày giúp phát hiện bệnh triệt để nhất và an toàn nhất đối với bạn. 
## **2. Khi nào cần nội soi dạ dày?**
Thực tế, phương pháp này không chỉ thăm khám dạ dày mà còn có thể kiểm tra toàn bộ đường tiêu hóa của bạn. Cụ thể là các phần thuộc dạ dày, thực quản phần ống tiêu hóa trên. Mục đích chính của việc nội soi là để chẩn đoán và điều trị các bệnh liên quan đến đường tiêu hóa. Vậy **khi nào cần nội soi dạ dày**? 
_Khi nào cần nội soi dạ dày, phương pháp này áp dụng khi nào?_
Những trường hợp sau đây sẽ được chỉ định nội soi dạ dày: 
  * Người bệnh có 1 số triệu chứng nghi ngờ liên quan đến bệnh đường tiêu hóa, như buồn nôn, nôn, đau bụng, khó nuốt hay thậm chí là bị xuất huyết tiêu hóa.
  * Trường hợp cần lấy mẫu mô của đường tiêu hóa để chẩn đoán 1 số bệnh như ung thư đường tiêu hóa, viêm nhiễm,... 
  * Khi bệnh nhân đang điều trị 1 số căn bệnh như giãn thực quản, loại bỏ dị vật hoặc cắt bỏ polyp. 
  * Kỹ thuật nội soi đôi khi được kết hợp với khá nhiều phương pháp khác nhau, cụ thể là siêu âm để chẩn đoán nhiều dạng bệnh lý. 


## **3. Quy trình thực hiện và mức chi phí cho nội soi dạ dày**
Sau khi đã xác định được các vấn đề về bệnh lý dạ dày, các bác sĩ sẽ tiến hành xác định phác đồ điều trị cho bạn. Phác đồ điều trị sẽ tùy thuộc vào độ nặng nhẹ và vấn đề bệnh mà bạn đang gặp phải. Phác đồ ở đây có thể hiểu đó là quy trình điều trị cơ bản của nội soi dạ dày. Dưới đây là phần phân tích quá trình nội soi dạ dày và chi phí chính cho quá trình nội soi. 
### **3.1. Các bước thực hiện**
Thời gian nội soi dạ dày khá là nhanh chóng. Ở một lần thăm khám và **nội soi dạ dày** bình thường thì bạn chỉ mất khoảng gần 15 phút. Thời gian phát sinh thường sẽ vì lí do bạn cần điều trị chung một tình trạng nhất định. Về thủ tục thăm khám thường là do các bác sĩ hoặc y tá hướng dẫn và tư vấn cụ thể. 
_Thực hiện nội soi dạ dày trải qua nhiều bước_
Trước khi tiến hành nội soi, bạn sẽ được gặp y tá trước khi làm các thủ thuật nội soi. Bạn sẽ được quyền hỏi bất cứ câu hỏi nào có liên quan đến quy trình nội soi. Điều này sẽ giúp giải quyết các vấn đề tâm lý chung của bệnh nhân trước khi tiến hành chữa bệnh. 
Sau khi đã hoàn thành việc hỏi han về sức khỏe, các bác sĩ sẽ tiến hành nội soi. Đầu tiên là tiến hành gây mê bằng loại thuốc xịt gây tê cục bộ vùng họng. Loại thuốc gây tê này sẽ được thông báo trước khi tiến hành làm tê. Đối với đối tượng bệnh nhân là trẻ nhỏ thì thường sử dụng biện pháp gây mê toàn phần. Mục đích chung của thuốc tế là để làm dịu đi cảm giác khó chịu khi tiến hành đưa ống soi và họng. Sau đó, các bác sĩ sẽ thực hiện đưa ống nội soi vào trong thực quản. 
### **3.2. Mức chi phí chính cho nội soi dạ dày hiện nay**
Chi phí nội soi liệu có đắt đỏ như bạn nghĩ? Quá trình nội soi thường sẽ phát sinh những chi phí nào thêm ngoài chi phí cho 1 lần nội soi chính? 
_Mức chi phí chính cho một lần nội soi_
Nhìn chung trên thực tế hiện nay, sẽ không có con số cụ thể nào trả lời chính xác giá tiền cho 1 lần nội soi. Tuy nhiên, sẽ có những yếu tố để bạn có thể định trước được khoản chi phí bạn sẽ phải trả cho 1 lần nội soi. Cụ thể như sau:
  * Về phương pháp thực hiện: Nhìn chung sẽ có khoảng 2 phương pháp chính đó là nội soi hiện đại và truyền thống. Hiện đại thì thường được nội soi chẩn đoán bằng máy tính và công cụ hiện đại. Chúng tôi khuyên bạn nên điều trị bằng phương pháp hiện đại. Bạn sẽ hoàn toàn được chữa trị mà không xảy ra bất cứ tình huống đau đớn nào cả. Thông thường hiện nay, mức chi phí cho một lần khám nội soi gây mê khoảng 1 triệu đồng. 
  * Về địa chỉ, phòng khám chữa bệnh: Không phải ở bất cứ địa chỉ chữa khám nội soi dạ dày cũng đều uy tín. Tùy thuộc vào địa chỉ, đội ngũ y bác sĩ và cơ sở máy móc chữa bệnh mức giá sẽ khác nhau. Bạn nên lựa chọn thăm khám ở những địa chỉ uy tín và chất lượng. Chính bởi ở những cơ sở uy tín, bạn mới có thể an tâm chữa trị mà không cần phải lo bất cứ vấn đề gì. 


**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [1. Định nghĩa nội soi dạ dày - phương pháp y khoa phổ biến hiện nay](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-da-day-duoc-hieu-la-gi-khi-nao-can-noi-soi-da-day#1-nh-ngha-ni-soi-d-dy-phng-php-y-khoa-ph-bin-hin-nay)
  * [2. Khi nào cần nội soi dạ dày?](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-da-day-duoc-hieu-la-gi-khi-nao-can-noi-soi-da-day#2-khi-no-cn-ni-soi-d-dy)
  * [3. Quy trình thực hiện và mức chi phí cho nội soi dạ dày](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-da-day-duoc-hieu-la-gi-khi-nao-can-noi-soi-da-day#3-quy-trnh-thc-hin-v-mc-chi-ph-cho-ni-soi-d-dy)
  * [3.1. Các bước thực hiện](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-da-day-duoc-hieu-la-gi-khi-nao-can-noi-soi-da-day#31-cc-bc-thc-hin)
  * [3.2. Mức chi phí chính cho nội soi dạ dày hiện nay](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-da-day-duoc-hieu-la-gi-khi-nao-can-noi-soi-da-day#32-mc-chi-ph-chnh-cho-ni-soi-d-dy-hin-nay)



## ️ Nội soi phế quản: Quy trình và các biến chứng có thể xảy ra

  * [1. Nội soi là gì? Thế nào là nội soi phế quản?](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-phe-quan-quy-trinh-va-cac-bien-chung-co-the-xay-ra#1-ni-soi-l-g-th-no-l-ni-soi-ph-qun)
  * [2. Bạn nên thực hiện nội soi phế quản khi nào?](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-phe-quan-quy-trinh-va-cac-bien-chung-co-the-xay-ra#2-bn-nn-thc-hin-ni-soi-ph-qun-khi-no)
  * [3. Các kỹ thuật nội soi và quy trình nội soi](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-phe-quan-quy-trinh-va-cac-bien-chung-co-the-xay-ra#3-cc-k-thut-ni-soi-v-quy-trnh-ni-soi)
  * [4. Các biến chứng và nguy cơ có thể xảy ra ](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-phe-quan-quy-trinh-va-cac-bien-chung-co-the-xay-ra#4-cc-bin-chng-v-nguy-c-c-th-xy-ra)
  * [5. Những điều nên làm sau khi thực hiện nội soi phế quản](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-phe-quan-quy-trinh-va-cac-bien-chung-co-the-xay-ra#5-nhng-iu-nn-lm-sau-khi-thc-hin-ni-soi-ph-qun)


## **1. Nội soi là gì? Thế nào là nội soi phế quản?**
- **Nội soi** (Endoscopy) là kỹ thuật y học hiện đại giúp quan sát được các bề mặt bên trong các cơ quan, bộ phận đề chẩn đoán và điều trị bệnh. Kỹ thuật nội soi được ứng dụng để quay phim, chụp hình các cơ quan bên trong, phẫu thuật nội soi, lấy dị vật,… 
- **nội soi phế quản** là kỹ thuật nội soi giúp quan sát được bên trong bề mặt phế quản và đường dẫn khí bằng việc đưa ống soi phế quản qua mũi, miệng hoặc đường mở khí quản. Ống soi phế quản có cấu tạo là một ống nhỏ có gắn camera và đèn ở đầu giúp bác sĩ dễ dàng quan sát được bên trong đường dẫn khí. Ngày nay, kỹ thuật nội soi phế quản bằng ống mềm thường được sử dụng bởi vì tránh làm tổn thương đường hô hấp, được trang bị camera có chất lượng cao, màu sắc chân thực để dễ dàng đánh giá được tình trạng niêm mạc, đồng thời tiến hành trong thời gian ngắn (chỉ 5 - 10 phút) nên hạn chế gây khó chịu cho bệnh nhân.
_Nội soi phế quản_
## **2. Bạn nên thực hiện nội soi phế quản khi nào?**
Bạn sẽ được bác sĩ chỉ định thực hiện nội soi phế quản khi nghi ngờ gặp phải các vấn đề về hô hấp, đường dẫn khí, phổi,… Trong một số trường hợp, kỹ thuật này được sử dụng trong điều trị, ứng phó với một số bệnh, có thể dùng để lấy dị vật đường hô hấp.
Mục đích của việc nội soi phế quản:
  * Chẩn đoán bệnh về đường hô hấp, bệnh về phổi (viêm phổi, viêm phế quản cấp, mạn tính, các khối u trong đường thở,…).
  * Chẩn đoán và xác định được mức độ của ung thư phổi, ung thư phế quản.
  * Lấy các dị vật có trong đường hô hấp (trường hợp bị sặc).
  * Phát hiện và tìm ra nguyên nhân của các chứng chảy máu đường thở, ho mạn tính, khó thở,…
  * Lấy mẫu xét nghiệm: mẫu đờm, mẫu mô đường thở.
  * Điều trị chứng hẹp đường hô hấp, điều trị các khối u có trong đường hô hấp.
  * Chữa ung thư đường hô hấp bằng phương pháp xạ trị bên trong.


## **3. Các kỹ thuật nội soi và quy trình nội soi**
**Phân loại:**
  * Nội soi ống cứng: Thường được sử dụng để lấy các dị vật trong đường hô hấp. Nó cũng cho phép bảo vệ đường dẫn khí, kiểm soát dị vật nên thích hợp cho việc phục hồi đường thở khi hít phải dị vật. Trong trường hợp mất máu nhiều do xuất huyết đường thở, kỹ thuật nội soi ống cứng cho phép thực hiện đốt điện giúp kiểm soát chảy máu nhờ lòng ống rộng.
  * Nội soi ống mềm: Ống mềm dài, nhỏ, mềm hơn ống cứng, bác sĩ dễ dàng điều khiển các kênh vào từng tiểu thuỳ phổi. Hệ thống camera, màn hình, đèn, dây cáp,… giúp cho việc tiếp nhận và truyền tải hình ảnh tốt hơn. Nội soi ống mềm chỉ mất 5 - 10 phút và ít gây khó chịu cho bệnh nhân, được thực hiện dễ dàng và an toàn, vì thế được sử dụng phổ biến trong chẩn đoán bệnh đường hô hấp.


Quy trình thực hiện:
  * Bước 1: 


- Chuẩn bị nơi nội soi: phòng mổ, phòng hồi sức cấp cứu, nơi có đầy đủ các thiết bị, dụng cụ, nhân lực để có thể xử lý khi xảy ra các trường hợp cấp cứu về hô hấp.
- Chuẩn bị ống nội soi và hệ thống màn hình. Ống nội soi cần được kiểm tra chức năng và vô trùng trước khi tiến hành nội soi. 
Nội soi phế quản cần thực hiện ở nơi đầy đủ thiết bị và nhân lực
  * Bước 2: Dùng atropin hoặc morphin để bệnh nhân an thần, giảm tiết dịch. Mục đích để bệnh nhân đỡ thấy đau, khó chịu, các dịch tiết từ miệng và đường hô hấp nhiều sẽ cản trở quan sát. 
  * Bước 3: Gây tê cục bộ màng nhầy của hầu thanh quản để tránh phản xạ ho khi gặp dị vật (bản thân ống nội soi chính là dị vật).
  * Bước 4: Đưa ống nội soi từ từ vào đường hô hấp trên, rồi tiếp tục đi xuống khí quản, phế quản. Nếu thấy dấu hiệu bất thường thì sẽ tiến hành lấy mẫu bệnh phẩm tại đó bằng kim, bàn chải, kẹp. 


Đối với kỹ thuật nội soi ống cứng thì bệnh nhân cần được thực hiện dưới gây mê bởi vì ống soi cứng có tiết diện lớn, thiết bị gây mê được nối với ống soi và khí được lưu thông qua ống soi.
## **4. Các biến chứng và nguy cơ có thể xảy ra**
Nội soi phế quản là một thủ thuật khá an toàn đối với sức khỏe người bệnh. Tuy nhiên trong một số trường hợp nhất định, bệnh nhân có thể gặp phải các nguy cơ về sử dụng thuốc và nguy cơ về thủ thuật, cụ thể như sau:
  * Co thắt đường dẫn khí gây khó thở, ngạt thở.
  * Hiện tượng dị ứng.
  * Loạn nhịp tim, rối loạn tuần hoàn.
  * Nội soi ống cứng có thể làm tổn thương đường hô hấp gây chảy máu, làm rách dây thanh dẫn đến khản tiếng.
  * Nội soi ống mềm có thể gây chảy máu do quá trình sinh thiết lấy mẫu.
  * Rất hiếm trường hợp gây tràn khí màng phổi, co thắt thanh quản.
  * Bệnh nhân có khối u đường hô hấp có thể gây khó thở, phù nề niêm mạc đường hô hấp.
  * Một số trường hợp gây viêm phổi.


Tuy nhiên, các biến chứng hầu như có thể được giải quyết trong điều kiện y tế đầy đủ, sử dụng thuốc để điều trị viêm phổi, đặt ống thông nội khí quản khi bệnh nhân khó thở, sử dụng thuốc an thần, thuốc trợ tim, cầm máu,…
## **5. Những điều nên làm sau khi thực hiện nội soi phế quản**
Nếu bạn được sử dụng thuốc an thần, giảm đau thì thuốc sẽ còn tác dụng 1 thời gian sau khi nội soi, thường là 2 giờ.
Bác sĩ sẽ thông báo cho bạn về kết quả nội soi, bao gồm những gì đã tìm thấy trong đường hô hấp của bạn, đưa ra nhận xét và hướng điều trị tốt nhất.
Dưới đây là những điều bạn cần lưu ý sau khi thực hiện nội soi:
  * Chỉ nên ăn uống sau 2 giờ kể từ khi thực hiện nội soi phế quản. Sau khi nội soi, tác dụng của thuốc vẫn còn nên khi nuối bạn sẽ có cảm giác nghẹn. Do đó bạn chỉ nên ăn uống sau khi thuốc hết tác dụng, khi đó bạn nuốt sẽ không còn cảm giác nghẹn nữa. Bạn nên uống một ngụm nước trước khi chuẩn bị ăn.
  * Không nên lái xe trong vòng 8 giờ kể từ khi nội soi: cũng do tác dụng của thuốc an thần sẽ có thể ảnh hưởng đến việc điều khiển xe của bạn.
  * Không nên hút thuốc lá trong vòng 24 giờ: Sau khi nội soi, niêm mạc đường thở của bạn đang ở trạng thái kích thích, nếu tiếp xúc với khói thuốc lá là chất độc hại thì sẽ ảnh hưởng xấu đến cơ quan hô hấp.


_Không nên hút thuốc trong 24 giờ sau khi nội soi_
Nội soi phế quản là một kỹ thuật chẩn đoán và điều trị bệnh được sử dụng rộng rãi hiện nay. 
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [1. Nội soi là gì? Thế nào là nội soi phế quản?](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-phe-quan-quy-trinh-va-cac-bien-chung-co-the-xay-ra#1-ni-soi-l-g-th-no-l-ni-soi-ph-qun)
  * [2. Bạn nên thực hiện nội soi phế quản khi nào?](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-phe-quan-quy-trinh-va-cac-bien-chung-co-the-xay-ra#2-bn-nn-thc-hin-ni-soi-ph-qun-khi-no)
  * [3. Các kỹ thuật nội soi và quy trình nội soi](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-phe-quan-quy-trinh-va-cac-bien-chung-co-the-xay-ra#3-cc-k-thut-ni-soi-v-quy-trnh-ni-soi)
  * [4. Các biến chứng và nguy cơ có thể xảy ra ](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-phe-quan-quy-trinh-va-cac-bien-chung-co-the-xay-ra#4-cc-bin-chng-v-nguy-c-c-th-xy-ra)
  * [5. Những điều nên làm sau khi thực hiện nội soi phế quản](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-phe-quan-quy-trinh-va-cac-bien-chung-co-the-xay-ra#5-nhng-iu-nn-lm-sau-khi-thc-hin-ni-soi-ph-qun)



## Nội soi đường tiêu hóa


## ️ Nguy hiểm của dị vật thực quản

  * [DỊ VẬT THỰC QUẢN HAY GẶP TRONG TÌNH HUỐNG NÀO?](https://bvnguyentriphuong.com.vn/noi-soi/nguy-hiem-cua-di-vat-thuc-quan#d-vt-thc-qun-hay-gp-trong-tnh-hung-no)
  * [-. Giai đoạn viêm nhiễm.](https://bvnguyentriphuong.com.vn/noi-soi/nguy-hiem-cua-di-vat-thuc-quan#-giai-on-vim-nhim)
  * [DỊ VẬT THỰC QUẢN CẦN NỘI SOI THỰC QUẢN CẤP CỨU VÌ](https://bvnguyentriphuong.com.vn/noi-soi/nguy-hiem-cua-di-vat-thuc-quan#d-vt-thc-quncn-ni-soi-thc-qun-cp-cu-vi)
  * [LỜI KHUYÊN DÀNH CHO BỆNH NHÂN:](https://bvnguyentriphuong.com.vn/noi-soi/nguy-hiem-cua-di-vat-thuc-quan#li-khuyn-dnh-cho-bnh-nhn)


Dị vật đường ăn nhất là dị vật thực quản là một cấp cứu có tính phổ biến, là một tai nạn, thực sự nguy hiểm tới tính mạng người bệnh và có tỷ lệ tử vong cao. Thường nhất là xương động vật (cá, gia cầm, lợn...). Khi bệnh nhân lỡ nuốt nhầm dị vật sắc nhọn thì dị vật có thể gây đâm thủng thực quản xuyên qua phổi, trung thất, tim mạch máu lớn gây xuất huyết ồ ạt hoặc viêm phổi, trung thất dẫn đến tử vong.Khi bệnh nhân nuốt các dị vật không phải là vật sắc nhọn nhưng kích thước lớn gây tắc nghẽn như khối thịt bò, gà,..làm bệnh nhân khó thở hoặc các vật có chứa chất gây ăn mòn như pin có thể gây bệnh nhân viêm loét , thủng đường tiêu hoá hoặc nhiễm độc cơ thể.
## **DỊ VẬT THỰC QUẢN HAY GẶP TRONG TÌNH HUỐNG NÀO?**
-**Tình huống thường gặp:** khi bệnh nhân nói cười khi ăn, không nhai kỹ hoặc uống thuốc vội, ngủ quên khi ngậm tăm.
### **Triệu chứng.**
- Giai đoạn đầu: Sau khi mắc dị vật, bệnh nhân hay có cảm giác vướng do dị vật, nuốt thức ăn hoặc nuốt nước bọt rất đau, thường không ăn được nữa mà phải bỏ dở bữa ăn và đau ngày càng tăng.
Nếu dị vật ở đoạn ngực, bệnh nhân sẽ đau sau xương ức, đau xiên ra sau lưng, lan lên bả vai.
### -. **Giai đoạn viêm nhiễm.**
Dị vật gây ra xây sát niêm mạc thực quản hoặc thủng thành thực quản. Nếu dị vật là xương lẫn thịt thì nhiễm khuẩn càng nhanh. Sau 1-2 ngày, các triệu chứng nuốt đau, đau cổ, đau ngực tăng dần đến nỗi nước bệnh nhân cũng không nuốt được, ứ đọng nước bọt, đờm dãi, hơi thở hôi.
## **DỊ VẬT THỰC QUẢN CẦN NỘI SOI THỰC QUẢN CẤP CỨU VÌ**
  * Để được lấy dị vật càng sớm càng tốt trước khi biến chứng có thể xảy ra.
  * Nếu đến muộn, dị vật có thể xuống ruột.Khi đó không thể tiến hành lấy dị vật, dị vật có thể đi qua ruột non và ruột già, trong chặng đường đi có thể đâm xuyên thủng ruột dẫn đến phải phẫu thuật ổ bụng để lấy dị vật ra.


## **LỜI KHUYÊN DÀNH CHO BỆNH NHÂN:**
1. Không nên nói cười, đùa giỡn khi đang ăn uống, bỏ thói quen ngậm tăm.
2. Kiểm tra kỹ các loại thuốc có vỏ kim loại sắc nhọn trước khi uống.
3. Khi nuốt dị vật cần nhanh chóng đến bệnh viện gần nhất có khoa nội soi để tiến hành lấy dị vật càng sớm càng tốt
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [DỊ VẬT THỰC QUẢN HAY GẶP TRONG TÌNH HUỐNG NÀO?](https://bvnguyentriphuong.com.vn/noi-soi/nguy-hiem-cua-di-vat-thuc-quan#d-vt-thc-qun-hay-gp-trong-tnh-hung-no)
  * [-. Giai đoạn viêm nhiễm.](https://bvnguyentriphuong.com.vn/noi-soi/nguy-hiem-cua-di-vat-thuc-quan#-giai-on-vim-nhim)
  * [DỊ VẬT THỰC QUẢN CẦN NỘI SOI THỰC QUẢN CẤP CỨU VÌ](https://bvnguyentriphuong.com.vn/noi-soi/nguy-hiem-cua-di-vat-thuc-quan#d-vt-thc-quncn-ni-soi-thc-qun-cp-cu-vi)
  * [LỜI KHUYÊN DÀNH CHO BỆNH NHÂN:](https://bvnguyentriphuong.com.vn/noi-soi/nguy-hiem-cua-di-vat-thuc-quan#li-khuyn-dnh-cho-bnh-nhn)



## ️ Các xét nghiệm kiểm tra vi khuẩn HP dạ dày

  * [Các yếu tố lựa chọn chỉ định xét nghiệm HP](https://bvnguyentriphuong.com.vn/noi-tieu-hoa/cac-xet-nghiem-kiem-tra-vi-khuan-hp-da-day#cc-yu-t-la-chn-ch-nh-xt-nghim-hp)
  * [Các xét nghiệm kiểm tra vi khuẩn HP dạ dày](https://bvnguyentriphuong.com.vn/noi-tieu-hoa/cac-xet-nghiem-kiem-tra-vi-khuan-hp-da-day#cc-xt-nghim-kim-tra-vi-khun-hp-d-dy)
  * [Nội soi làm sinh thiết kiểm tra vi khuẩn HP](https://bvnguyentriphuong.com.vn/noi-tieu-hoa/cac-xet-nghiem-kiem-tra-vi-khuan-hp-da-day#ni-soi-lm-sinh-thit-kim-tra-vi-khun-hp)
  * [Xét nghiệm phân](https://bvnguyentriphuong.com.vn/noi-tieu-hoa/cac-xet-nghiem-kiem-tra-vi-khuan-hp-da-day#xt-nghim-phn)


## **Các yếu tố lựa chọn chỉ định xét nghiệm HP**
Có nhiều xét nghiệm giúp kiểm tra **vi khuẩn HP dạ dày** , để chọn đúng chỉ định bác sỹ tùy thuộc vào các yếu tố sau:
  * Điều kiện vật chất và kỹ thuật của cơ sở khám chữa bệnh: cơ sở khám chữa bệnh có những test kiểm tra vi khuẩn Hp trong dạ dày nào?
  * Yêu cầu xét nghiệm nhanh hay chậm: nếu bệnh không phải cấp tính và bệnh nhân có thể chờ đợi kết quả thì bác sỹ sử dụng các test chậm hơn như nuôi cấy vi khuẩn.
  * Các yêu cầu khác kèm theo việc kiểm tra nhiễm khuẩn Hp: bệnh nhân có cần kiểm tra tình trạng tổn thương dạ dày không, có cần làm xét nghiệm kháng sinh đồ không?


## **Các xét nghiệm kiểm tra vi khuẩn HP dạ dày**
Dựa trên các đặc điểm trên, bác sỹ sẽ quyết định làm một trong các xét nghiệm sau, hoặc làm kết hợp các test sau:
### **Nội soi làm sinh thiết kiểm tra vi khuẩn HP**
Bác sỹ dùng một ống nội soi nhỏ xâm nhập vào dạ dày qua ống thực quản tới dạ dày. Bác sỹ sẽ lấy một mảnh sinh thiết quanh vị trí có tổn thương dạ dày để làm xét nghiệm Clo Test hoặc nuôi cấy vi khuẩn, hoặc chỉ đơn giản là nhìn hình thái của tổn thương dạ dày, bác sỹ có thể chẩn đoán sơ bộ tình trạng nhiễm khuẩn HP của bệnh nhân.
Đối với xét nghiệm này, bác sỹ không những chẩn đoán chính xác được tình trạng nhiễm khuẩn HP trong dạ dày của bệnh nhân, đồng thời còn đánh giá được mức độ tổn thương, vị trí tổn thương và đưa ra các phán đoán về diễn biến của bệnh và phác đồ điều trị phù hợp nhất.
Chính vì vậy, sẽ không ngạc nhiên, nếu như bạn tới phòng khám với tình trạng đau dạ dày và rất có khả năng được bác sỹ chỉ định nội soi dạ dày. Đây là một thủ thuật không hề dễ chịu, nhưng đây lại là thủ thuật vô cùng quan trọng để đánh giá tình trạng tổn thương dạ dày mà không có xét nghiệm nào có thể làm được. Ngoài ra, nếu bạn đã từng điều trị vi khuẩn HP mà không thành công thì bác sỹ có thể chỉ định làm kháng sinh đồ để xem vi khuẩn HP đã kháng thuốc chưa, còn có thể sử dụng phác đồ thuốc nào dành cho bạn.
### **Test thở Ure**
Bạn sẽ được đưa một thiết bị và thở vào đó. Hiện nay có 2 dạng, test thở sử dụng bóng – thổi vào thiết bị giống quả bóng, test thở sử dụng thẻ – bạn thổi vào thiết bị giống 1 chiếc thẻ ATM. Sau đó hơi thở của bạn được đánh giá trên thiết bị phân tích và có chỉ số đánh giá xem bạn có dương tính với Hp hay không. Nếu dương tính với HP tức là bạn đã nhiễm HP, còn âm tính thì ngược lại.
Test thở này cũng cho kết quả rất chính xác và được khuyến khích sử dụng trên mọi đối tượng do test diễn ra nhanh, bệnh nhân không bị can thiệp, có thể dùng dễ dàng trên trẻ em. Tuy nhiên, chi phí 1 test này ở Việt Nam thường nằm trong khoảng 400.000 – 600.000 thậm chí cao hơn, tùy vào cơ sở khám, thiết bị khám, cho nên không phải ai cũng có điều kiện để chi trả. Test hơi thở này đặc biệt hữu ích đối với những người đã điều trị vi khuẩn Hp và cần đánh giá lại hiệu quả tiệt trừ Hp.
Bạn cũng cần lưu ý, hiện nay có 2 loại test thở khác nhau, 1 loại sử dụng C13 (Carbon 13), một loại sử dụng C14 (Carbon14) có giá thành khác nhau và đối tượng chỉ định cũng có khác nhau. Loại sử dụng C14 có giá thành rẻ hơn nhưng C14 là yếu tố phóng xạ cho nên hạn chế sử dụng trên đối tượng trẻ em dưới 6 tuổi và phụ nữ trong độ tuổi sinh đẻ. Trước khi thăm khám và kiểm tra ở các cơ sở, bạn hoàn toàn có thể yêu cầu được biết loại xét nghiệm mình làm là C13 hay C14 để có quyết định phù hợp. Do tính chất, test thở là loại test mới ở Việt Nam, nên có ít thông tin tra cứu, vì vậy bạn cần trang bị kiến thức để tránh ảnh hưởng tới sức khỏe của mình.
### **Xét nghiệm phân**
Vi khuẩn HP nếu có trong dạ dày sẽ được thải trừ thường xuyên qua phân. Xét nghiệm phân bằng phản ứng miễn dịch huỳnh quang giúp phát hiện vi khuẩn Hp trong phân một cách chính xác. Đây cũng là một xét nghiệm chính xác, được ưu tiên sử dụng trong đánh giá nhiễm khuẩn HP.
Mặc dù dễ dàng thực hiện đối với bệnh nhân, kết quả chính xác, chi phí hợp lý nhưng test này không cho kết quả nhanh chóng nên không phải là test nhanh. Ngoài ra, việc lấy phân đi xét nghiệm cũng còn nhiều vấn đề về vệ sinh, tiện lợi cho người bệnh và kỹ thuật viên.
### **Xét nghiệm máu**
Khi bạn nhiễm khuẩn HP, cơ thể bạn sẽ sinh ra kháng thể kháng HP, loại kháng thể này được lưu hành trong máu và có thể phát hiện được bằng xét nghiệm kháng thể trong máu. Test này có mặt ở hầu hết các cơ sở khám chữa bệnh cấp tỉnh, thành phố trên cả nước.
Tuy nhiên, đây không phải loại xét nghiệm được ưu tiên thực hiện, chỉ những cơ sở không có phương pháp xét nghiệm nào khác mới thực hiện xét nghiệm này. Lý do là vì vi khuẩn HP có thể tồn tại ở một số khu vực khác như khoang miệng, xoang, đường ruột nhưng hoàn toàn không gây bệnh. Lý do thứ hai là mặc dù vi khuẩn HP trong dạ dày đã bị tiệt trừ hết, tuy nhiên, kháng thể kháng HP vẫn có thể lưu hành trong máu trong thời gian một vài tháng tới một vài năm sau đó. Nếu dựa vào đó để chẩn đoán nhiễm HP rất dễ xảy ra tình trạng dương tính giả.
## **Kết luận**
Trên đây là một số test thường được sử dụng để **kiểm tra nhiễm vi khuẩn HP dạ dày** nhất. Mỗi loại xét nghiệm sẽ có ưu, nhược điểm khác nhau. Bác sỹ sẽ chỉ định cho bạn loại xét nghiệm phù hợp khi bạn đi thăm khám. Tuy nhiên, bạn cần trang bị kiến thức tổng quan như trên để tránh những lo lắng không cần thiết, cũng như hiểu hơn về tình trạng nhiễm khuẩn HP của mình cũng như tự bảo vệ mình trước các thông tin truyền miệng, thông tin trên các phương tiện truyền thông đại chúng về xét nghiệm HP.
Xem thêm: [**Vi khuẩn HP và bệnh lý dạ dày**](https://www.youtube.com/watch?v=GGKPX13IdUI)
**Bệnh viện Nguyễn Tri Phương** - Bệnh viện Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [Các yếu tố lựa chọn chỉ định xét nghiệm HP](https://bvnguyentriphuong.com.vn/noi-tieu-hoa/cac-xet-nghiem-kiem-tra-vi-khuan-hp-da-day#cc-yu-t-la-chn-ch-nh-xt-nghim-hp)
  * [Các xét nghiệm kiểm tra vi khuẩn HP dạ dày](https://bvnguyentriphuong.com.vn/noi-tieu-hoa/cac-xet-nghiem-kiem-tra-vi-khuan-hp-da-day#cc-xt-nghim-kim-tra-vi-khun-hp-d-dy)
  * [Nội soi làm sinh thiết kiểm tra vi khuẩn HP](https://bvnguyentriphuong.com.vn/noi-tieu-hoa/cac-xet-nghiem-kiem-tra-vi-khuan-hp-da-day#ni-soi-lm-sinh-thit-kim-tra-vi-khun-hp)
  * [Xét nghiệm phân](https://bvnguyentriphuong.com.vn/noi-tieu-hoa/cac-xet-nghiem-kiem-tra-vi-khuan-hp-da-day#xt-nghim-phn)



## ️ Nội soi đại tràng

  * [Thủ thuật nội soi đại tràng](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-dai-trang#th-thut-ni-soi-i-trng)
  * [Điều gì sẽ diễn ra sau thủ thuật nội soi](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-dai-trang#iu-g-s-din-ra-sau-th-thut-ni-soi)
  * [Cần chuẩn bị gì cho thủ thuật nội soi đại tràng](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-dai-trang#cn-chun-b-g-cho-th-thut-ni-soi-i-trng)
  * [Khi nào nên thực hiện nội soi đại tràng?](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-dai-trang#khi-no-nn-thc-hin-ni-soi-i-trng)
  * [Các nguy cơ của nội soi đại tràng](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-dai-trang#cc-nguy-c-ca-ni-soi-i-trng)
  * [Nội soi đại tràng có đau không?](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-dai-trang#ni-soi-i-trng-c-au-khng)
  * [Tuổi nào nên thực hiện nội soi đại tràng?](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-dai-trang#tui-no-nn-thc-hin-ni-soi-i-trng)
  * [Làm gì nếu như phát hiện bất thường?](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-dai-trang#lm-g-nu-nh-pht-hin-bt-thng)


Khi thăm khám, bác sĩ sẽ đưa ống nội soi – một ống dẻo nhỏ có gắn camera – đi qua trực tràng vào đại tràng. Bác sĩ cũng có thể sẽ lấy mẫu mô (sinh thiết) hoặc loại bỏ mô bất thường trong quá trình thực hiện thủ thuật.
Bài viết này sẽ mô tả về những việc sẽ diễn ra trong và sau quá trình thực hiện thủ thuật, và những bước chuẩn bị trước khi thực hiện.
## **Thủ thuật nội soi đại tràng**
Thủ thuật này thường kéo dài khoảng 30-60 phút. Tuy nhiên, nên dành ra khoảng 2-3 tiếng khi đi đến thực hiện thủ thuật để có thêm thời gian chuẩn bị cũng như thời gian hồi phục sau khi thực hiện.
Trước thủ thuật, bệnh nhân sẽ được cho dùng thuốc an thần dạng viên hoặc đường tĩnh mạch.
Trong lúc thực hiện thủ thuật, bệnh nhân được khoác áo của bệnh viện cấp và nằm nghiêng trên bàn thủ thuật. Ống nội soi được đưa vào trực tràng. Bác sĩ có thể sẽ sử dụng khí hoặc cacbon dioxide làm căng đại tràng lên để quan sát tốt hơn. Khi thực hiện việc đó hoặc khi di chuyển ống nội soi thì bệnh nhân có thể cảm thấy khó chịu trong bụng hoặc cảm giác muốn đi cầu. Những hiện tượng này là bình thường.
Nếu như bác sĩ quyết định là họ cần lấy mẫu sinh thiết hoặc cắt bỏ mô bất thường thì họ sẽ đưa vào thêm những dụng cụ khác qua đường trực tràng.
## **Điều gì sẽ diễn ra sau thủ thuật nội soi**
Khi bác sĩ đã thăm khám xong, bệnh nhân sẽ được chuyển vào một phòng hồi sức đặc biệt cho đến khi thuốc mê hết tác dụng.
Bác sĩ hoặc điều dưỡng sẽ cho lời khuyên về việc khi nào thì bệnh nhân ăn uống bình thường lại được sau khi thực hiện thủ thuật cũng như là khi nào bệnh nhân có thể quay trở lại công việc và sinh hoạt hằng ngày.
Một số triệu chứng nhẹ khác – ví dụ như chướng bụng, đầy hơi hoặc co thắt nhẹ - là bình thường sau thủ thuật. Những triệu chứng này thường sẽ mất đi sau 24 giờ. Trung tiện hay đi bộ cũng giúp làm giảm bớt sự khó chịu.
Việc chảy máu ít sau thủ thuật cũng là điều bình thường. Tuy nhiên, nên gặp bác sĩ ngay nếu như chảy máu vẫn còn tiếp tục hoặc nếu như phân có chứa nhiều máu hoặc máu đông.
## **Cần chuẩn bị gì cho thủ thuật nội soi đại tràng**
Thụt tháo ruột là rất cần thiết cho sự thành công của thủ thuật. Bác sĩ sẽ cho chỉ định cụ thể về cách thực hiện việc này. Một số khuyến cáo có thể được đưa ra như:
  * **Thay đổi chế độ ăn** : Một ngày trước khi thực hiện thủ thuật, việc thay đổi chế độ ăn là rất cần thiết, ví dụ như chỉ ăn sáng và ăn trưa nhẹ, không ăn tối hoặc chỉ dùng thức ăn hoặc thức uống lỏng.
  * **Chỉ dùng các thức uống trong suốt** : Bác sĩ sẽ yêu cầu chỉ được uống nước, súp, trà và cà phê không sữa một ngày trước khi thực hiện thủ thuật.
  * **Thuốc nhuận tràng** : Thường thì nên dùng các thuốc nhuận tràng 1 ngày trước thủ thuật, dạng viên hoặc nước. Đôi khi, người bệnh cũng cần dùng chúng vào buổi sáng của ngày tiến hành thủ thuật.
  * **Thuốc xổ:** Một vài người cũng có thể cần sử dụng thuốc xổ vào buổi tối trước hoặc buổi sáng ngày thủ thuật.
  * **Tắm rửa:** Nên tắm rửa sạch sẽ trước khi thực hiện thủ thuật.


Những người đang sử dụng thuốc hoặc các thực phẩm chức năng nên hỏi ý kiến của bác sĩ. Bác sĩ có thể sẽ yêu cầu tạm ngưng sử dụng hoặc điều chỉnh lại liều lượng một số thuốc.
Chú ý cần phải thông báo cho bác sĩ biết khi đang sử dụng:
  * Thuốc làm loãng máu (ví dụ như aspirin hay warfarin)
  * Thuốc tiểu đường, tăng huyết áp hay tim mạch
  * Thuộc có chứa sắt


## **Khi nào nên thực hiện nội soi đại tràng?**
Nội soi đại tràng là phương pháp chính để bác sĩ có thể khám được những triệu chứng ở đường tiêu hóa dưới, ví dụ như:
  * Chảy máu từ trực tràng.
  * Táo bón mạn tính
  * Tiêu chảy mạn tính
  * Đau dạ dày


Cộng đồng y khoa cũng xem nội soi đại tràng là tiêu chuẩn vàng trong việc tầm soát ung thư đại trực tràng. Nội soi đại tràng có thể phát hiện ung thư đại trực tràng ở giai đoạn sớm, trước khi bộc lộ triệu chứng. Phát hiện sớm có thể cải thiện tiên lượng điều trị.
Bác sĩ có thể khuyến cáo thực hiện nội soi đại tràng ở những người:
  * Có quan hệ họ hàng cách nhau trong 1 thế hệ mắc bệnh đa polyp đại tràng hoặc ung thư đại tràng.
  * Có nguy cơ cao dựa theo tiền căn bệnh lý của cá nhân
  * Trên 50 tuổi, kể cả khi không có yếu tố nguy cơ ở hiện tại.


## **Các nguy cơ của nội soi đại tràng**
Nội soi đại tràng hiếm khi gây ra các vấn đề nghiêm trọng. Hiệp hội Nội soi đường tiêu hóa của Mỹ báo cáo rằng tỷ lệ biến chứng nghiêm trọng xảy ra trên những người có nguy cơ trung bình là xấp xỉ 2.8/1000 lượt thủ thuật (0.28%).
Các nguy cơ liên quan đến thủ thuật nội soi bao gồm chảy máu và rách các mô bên ngoài của đại tràng hay trực tràng (thủng), những nguy cơ này có thể tăng lên nếu như có sinh thiết hay cắt bỏ cắt mô bất thường. Sử dụng thuốc mê cũng có những nguy cơ, ví dụ:
  * Tăng nhịp thở
  * Thay đổi nhịp tim
  * Buồn nôn và nôn


## **Nội soi đại tràng có đau không?**
Nội soi đại tràng thường không đau, vì các bệnh nhân thường chọn thực hiện thủ thuật có thuốc mê. 
Sau thủ thuật, bệnh nhân có thể có cảm giác khó chịu nhẹ trong vòng 24 giờ. Bệnh nhân có thể gặp các cơn co thắt dạ dày nhẹ, đau khi trung tiện, và đầy hơi.
Ngoài sự khó chịu nhẹ ra thì cũng có thể chảy ít máu nếu như bác sĩ thực hiện sinh thiết hay cắt mô.
## **Tuổi nào nên thực hiện nội soi đại tràng?**
Bất cứ độ tuổi nào cũng có thể thực hiện nội soi đại tràng, đặc biệt là khi tiền căn cá nhân hoặc gia đình có nguy cơ cao mắc ung thư đại trực tràng.
Các chuyên gia cho biết cho dù có nguy cơ hay không, tất cả các người trong độ tuổi 50-70 cũng nên thực hiện tầm soát ung thư đại trực tràng, ví dụ như nội soi đại tràng, ít nhất mỗi 10 năm. Mọi người nên tầm soát thường xuyên hơn nếu như có các yếu tố nguy cơ khác ngoài tuổi tác.
Theo Hiệp hội Ung thư Mỹ, những người có nguy cơ trung bình nên bắt đầu tầm soát định kỳ sớm hơn nữa, lúc 45 tuổi. Hiệp hội khuyên rằng những người có sức khỏe tốt nên tiếp tục tầm soát cho đến 75 tuổi.
Theo hiệp hội thì quyết định thực hiện tầm soát ở người từ 75-85 tuổi phụ thuộc vào nhu cầu cá nhân, sức khỏe và tuổi thọ. Hiệp hội cũng khuyến cáo những người trên 85 tuổi không cần phải thực hiện tầm soát ung thư đại trực tràng nữa.
## **Làm gì nếu như phát hiện bất thường?**
Nếu như bác sĩ phát hiện thấy vùng mô bất thường trong khi thực hiện thủ thuật, ví dụ như polyp, họ thường sẽ cắt chúng và gửi mẫu đến phòng xét nghiệm để xác định xem nó mang tính chất ung thư hay bình thường.
Nếu như bác sĩ phải cắt đi các polyp hay mô bất thường, thì họ sẽ khuyến cáo thực hiện nội soi đại tràng lặp lại thường xuyên hơn. Tần suất như thế nào còn phụ thuộc vào kích cỡ và số lượng của các polyp, cũng như các yếu tố nguy cơ khác.
## **Tóm tắt**
Nội soi đại trực tràng là một thủ thuật tầm soát phổ biến, quan trọng và tương đối an toàn để thăm khám các vấn đề về đường tiêu hóa, và kiểm tra các dấu hiệu của ung thư đại trực tràng.
Các cá nhân có nguy cơ cao mắc ung thư đại trực tràng và những người lớn tuổi có thể cần phải thực hiện thủ thuật để giám sát sức khỏe của ruột.
Thủ thuật thường không đau, mặc dù nó có thể gây chút khó chịu kéo dài khoảng 1 ngày.
Nếu như có thêm thắc mắc về nội soi đại trực tràng thì nên liên hệ với bác sĩ để biết thêm thông tin.
Xem thêm: [**Những dặn dò trước khi thực hiện nội soi đại tràng**](https://bvnguyentriphuong.com.vn/noi-soi/nhung-dan-do-truoc-khi-thuc-hien-noi-soi-dai-trang)
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [Thủ thuật nội soi đại tràng](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-dai-trang#th-thut-ni-soi-i-trng)
  * [Điều gì sẽ diễn ra sau thủ thuật nội soi](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-dai-trang#iu-g-s-din-ra-sau-th-thut-ni-soi)
  * [Cần chuẩn bị gì cho thủ thuật nội soi đại tràng](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-dai-trang#cn-chun-b-g-cho-th-thut-ni-soi-i-trng)
  * [Khi nào nên thực hiện nội soi đại tràng?](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-dai-trang#khi-no-nn-thc-hin-ni-soi-i-trng)
  * [Các nguy cơ của nội soi đại tràng](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-dai-trang#cc-nguy-c-ca-ni-soi-i-trng)
  * [Nội soi đại tràng có đau không?](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-dai-trang#ni-soi-i-trng-c-au-khng)
  * [Tuổi nào nên thực hiện nội soi đại tràng?](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-dai-trang#tui-no-nn-thc-hin-ni-soi-i-trng)
  * [Làm gì nếu như phát hiện bất thường?](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-dai-trang#lm-g-nu-nh-pht-hin-bt-thng)



## ️ Nội soi đường tiêu hóa trên: ý nghĩa lâm sàng giá trị kết quả

  * [Nhận định chung](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-duong-tieu-hoa-tren-y-nghia-lam-sang-gia-tri-ket-qua#nhn-nh-chung)
  * [Chỉ định nội soi đường tiêu hóa trên](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-duong-tieu-hoa-tren-y-nghia-lam-sang-gia-tri-ket-qua#ch-nh-ni-soi-ng-tiu-ha-trn)
  * [Chuẩn bị nội soi đường tiêu hóa trên](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-duong-tieu-hoa-tren-y-nghia-lam-sang-gia-tri-ket-qua#chun-b-ni-soi-ng-tiu-ha-trn)
  * [Thực hiện nội soi đường tiêu hóa trên](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-duong-tieu-hoa-tren-y-nghia-lam-sang-gia-tri-ket-qua#thc-hin-ni-soi-ng-tiu-ha-trn)
  * [Cảm giác khi nội soi đường tiêu hóa trên](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-duong-tieu-hoa-tren-y-nghia-lam-sang-gia-tri-ket-qua#cm-gic-khi-ni-soi-ng-tiu-ha-trn)
  * [Rủi ro của nội soi đường tiêu hóa trên](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-duong-tieu-hoa-tren-y-nghia-lam-sang-gia-tri-ket-qua#ri-ro-ca-ni-soi-ng-tiu-ha-trn)
  * [Ý nghĩa lâm sàng giá trị kết quả](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-duong-tieu-hoa-tren-y-nghia-lam-sang-gia-tri-ket-qua#-ngha-lm-sng-gi-tr-kt-qu)
  * [Yếu tố ảnh hưởng đến nội soi đường tiêu hóa trên](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-duong-tieu-hoa-tren-y-nghia-lam-sang-gia-tri-ket-qua#yu-t-nh-hng-n-ni-soi-ng-tiu-ha-trn)
  * [Điều cần biết thêm](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-duong-tieu-hoa-tren-y-nghia-lam-sang-gia-tri-ket-qua#iu-cn-bit-thm)


Bác sĩ áp dụng kỹ thuật nội soi để phát hiện những tổn thương loét, viêm, khối u, nhiễm trùng, hoặc tổn thương đang chảy máu. Bên cạnh đó, có thể sinh thiết được mẫu mô bên trong cơ thể, cắt polyp, và điều trị cầm máu.
## **Nhận định chung**
Nội soi đường tiêu hóa trên (UGI) là một thủ thuật cho phép bác sĩ quan sát niêm mạc bên trong thực quản, dạ dày và đoạn đầu của ruột non (tá tràng). Trong quá trình thực hiện, đầu của ống nội soi được đưa vào qua miệng và sau đó nhẹ nhàng di chuyển xuống họng vào thực quản, dạ dày và tá tràng (đường tiêu hóa trên).
Thủ thuật này được gọi là nội soi thực quản-dạ dày- tá tràng esophagogastroduodenoscopy (EGD).
Dựa vào kỹ thuật nội soi, bác sĩ có thể phát hiện tổn thương loét, viêm, khối u, nhiễm trùng hoặc vị trí chảy máu. Có thể thu thập các mẫu mô trong cơ thể (sinh thiết), cắt bỏ polyp và điều trị cầm máu qua nội soi. Là những vấn đề mà kỹ thuật X-quang thường không thể phát hiện được.
Thủ thuật này góp phần giúp ngăn ngừa nguy cơ phải mổ thám sát trên bệnh nhân.
## **Chỉ định nội soi đường tiêu hóa trên**
Mục đích để khảo sát các vấn đề của đường tiêu hóa trên (GI). Bao gồm:
  * Viêm dạ dày hoặc thực quản.
  * Bệnh trào ngược dạ dày thực quản (GERD).
  * Hẹp thực quản.
  * Giãn tĩnh mạch ở dạ dày hoặc thực quản.
  * Barrett thực quản, một tình trạng làm tăng nguy cơ ung thư thực quản.
  * Thoát vị.
  *   * Ung thư.
  * Tìm nguyên nhân gây ra tình trạng nôn ra máu.
  * Tìm nguyên nhân của các triệu chứng, chẳng hạn như đau bụng trên hoặc đầy hơi, khó nuốt, nôn ói, hoặc sụt cân không giải thích được.
  * Tìm nguyên nhân nhiễm trùng.
  * Kiểm tra tình trạng vết loét dạ dày.
  * Quan sát bên trong dạ dày và đoạn đầu ruột non (tá tràng) sau phẫu thuật.
  * Tìm kiếm khối U của dạ dày hoặc thực quản.


Nội soi cũng có thể được thực hiện để:
  * Kiểm tra tổn thương thực quản trong trường hợp cấp cứu. (Ví dụ, nếu nghi ngờ bệnh nhân nuốt phải chất độc).
  * Thu thập các mẫu mô (sinh thiết) để làm xét nghiệm.
  * Cắt bỏ polyp từ bên trong thực quản, dạ dày hoặc ruột non.
  * Điều trị 1 số vấn đề gây chảy máu.
  * Loại bỏ dị vật trong đường tiêu hóa.
  * Điều trị hẹp của thực quản.
  * Điều trị Barrett thực quản.


## **Chuẩn bị nội soi đường tiêu hóa trên**
Trước khi nội soi đường tiêu hóa trên, hãy thông báo với bác sĩ nếu có bạn các vấn đề dưới đây:
  * Bị dị ứng với bất kỳ loại thuốc nào, kể cả thuốc gây mê.
  * Thuốc đang sử dụng.
  * Đang sử dụng thuốc hoặc các chất làm loãng máu hoặc có vấn đề chảy máu.
  * Có vấn đề về tim mạch.
  * Đang hoặc nghi ngờ có thai.
  * Bị đái tháo đường và đang dùng insulin.
  * Đã được phẫu thuật hoặc xạ trị vào thực quản, dạ dày hoặc tá tràng.


Không ăn hoặc uống bất cứ thứ gì trong 6 đến 8 giờ trước khi thủ thuật. Dạ dày trống giúp bác sĩ quan sát rõ ràng hơn, nó cũng làm giảm nguy cơ nôn ói. Nếu bị nôn trong quá trình làm thủ thuật, một rủi ro nhỏ là chất nôn có thể xâm nhập vào phổi. Nếu thủ thuật được thực hiện trong trường hợp cấp cứu, một ống sonde được đưa vào qua mũi hoặc miệng để làm trống dạ dày.
Bạn có thể được yêu cầu ký vào một mẫu đơn đồng thuận sau khi đã được tư vấn về các rủi ro của thủ thuật và đồng ý thực hiện.
Hãy trao đổi với bác sĩ về bất kỳ mối quan tâm nào của bạn trước khi đồng ý làm thủ thuật, bao gồm cả những rủi ro của quá trình, các bước thực hiện và ý nghĩa của kết quả.
Bạn có thể phải ngừng sử dụng các sản phẩm aspirin, thuốc kháng viêm không steroid (NSAID) và bổ sung sắt 7 đến 14 ngày trước khi thực hiện thủ thuật. Nếu buộc phải dùng thuốc làm loãng máu hằng ngày, hãy trao đổi với bác sĩ để họ có phương án chuẩn bị cho bạn.
Không dùng sucralfate (Sulcrate) hoặc thuốc kháng axit vào ngày làm thủ thuật. Những loại thuốc này có thể làm bác sĩ khó quan sát đường tiêu hóa trên.
Trước khi thực hiện, bạn sẽ mặc áo choàng bệnh viện; các vật dụng như răng giả, đồ trang sức, kính áp tròng hoặc kính cận cần phải tháo bỏ ở bên ngoài. Để giúp thoải mái, bạn nên đi vệ sinh trước khi vào phòng thực hiện thủ thuật.
Sắp xếp để có người đưa bạn về nhà sau khi thủ thuật bởi vì bạn sẽ được gây mê trong thủ thuật này nên việc tự lái xe sẽ không an toàn.
## **Thực hiện nội soi đường tiêu hóa trên**
Nội soi đường tiêu hóa có thể được thực hiện tại cơ sở y tế tư nhân hoặc bệnh viện. Ở lại qua đêm trong bệnh viện thường là không cần thiết. Thủ thuật này thường được thực hiện bởi một bác sĩ chuyên khoa tiêu hóa như nội tiêu hóa hoặc ngoại tiêu hóa.
Trước khi làm thủ thuật, xét nghiệm máu có thể được thực hiện để kiểm tra lượng máu trong cơ thể hoặc các vấn đề đông cầm máu. Cổ họng có thể được gây tê bằng thuốc xịt, thuốc súc miệng hoặc viên ngậm. Điều này giúp cho việc đưa ống nội soi vào bên trong họng dễ dàng hơn.
Trong quá trình thủ thuật, bạn có thể được truyền thuốc giảm đau và thuốc an thần thông qua đường truyền tĩnh mạch (IV) trên cánh tay hoặc bàn tay. Những loại thuốc này làm giảm đau, an thần và gây buồn ngủ. Vậy nên bạn thường không thể nhớ nhiều về thủ thuật.
Bạn sẽ được yêu cầu nằm nghiêng về bên trái, đầu hơi cúi về phía trước. Một thiết bị bảo vệ được đặt trong miệng để bảo vệ răng khỏi ống nội soi. Sau đó, đầu bôi trơn của ống nội soi sẽ được luồn vào trong miệng. Bác sĩ sẽ nhẹ nhàng nhấn lưỡi ra khỏi đường đi ống. Bạn có thể được yêu cầu nuốt để giúp ống di chuyển vào trong dễ dàng hơn. Ống soi không to hơn nhiều so với các loại thực phẩm thông thường và nó sẽ không gây ra vấn đề với đường thở.
Sau khi ống nội soi nằm trong thực quản, đầu sẽ nghiêng thẳng để giúp ống soi trượt xuống thực quản dễ dàng hơn. Trong thủ thuật, cố gắng không nuốt trừ khi được yêu cầu. Điều dưỡng sẽ dùng 1 thiết bị chuyên dụng để hút nước bọt của bạn.
Bác sĩ sẽ vừa quan sát trên màn hình vừa từ từ di chuyển ống nội soi. Bác sĩ sẽ kiểm tra thành của thực quản, dạ dày và tá tràng. Không khí hoặc nước có thể được bơm qua ống soi để giúp dẫn đường cho ống soi hoặc để tránh mờ ống kính. Một đầu hút có thể được đưa vào để loại bỏ không khí hoặc dịch tiết.
Một máy ảnh gắn liền với ống soi chụp ảnh. Bác sĩ cũng có thể chèn các dụng cụ nhỏ như kẹp, và gạc qua ống soi để thu thập các mẫu mô (sinh thiết), cắt polyp hoặc cầm máu.
Để giúp dễ dàng quan sát các phần khác nhau của đường tiêu hóa trên (GI), họ có thể thay đổi vị trí hoặc đè lực nhẹ lên bụng bệnh nhân. Sau khi kiểm tra xong, ống soi được rút từ từ.
Quá trình thực hiện thường mất 30 đến 45 phút. Nhưng nó có thể kéo dài hơn tùy thuộc vào những gì được phát hiện ra và những thủ thuật được thực hiện đi kèm.
Sau khi hoàn thành thủ thuật, bạn sẽ được theo dõi trong 1 đến 2 giờ cho đến khi thuốc hết tác dụng. Nếu cổ họng bị tê trước khi kiểm tra, không nên ăn hoặc uống cho đến khi cổ họng không còn tê và phản xạ vùng hầu họng trở về bình thường.
Khi đã bình phục hoàn toàn, bạn có thể về nhà. Bạn sẽ không thể lái xe hoặc vận hành máy móc trong 12 giờ sau khi thủ thuật. Bác sĩ sẽ cho biết khi nào bạn có thể quay lại chế độ ăn uống và sinh hoạt thông thường. Không uống rượu trong 12 đến 24 giờ sau khi hoàn thành thủ thuật.
## **Cảm giác khi nội soi đường tiêu hóa trên**
Bạn có thể thấy đau nhói do kim đâm khi kim tiêm được đặt trong tĩnh mạch ở cánh tay. Thuốc gây tê cục bộ được phun vào cổ họng thường có vị hơi đắng. Nó sẽ làm cho lưỡi và cổ họng cảm thấy tê và sưng. Một số người kể lại rằng họ cảm thấy như không thể thở được, đây là một cảm giác gây ra bởi thuốc mê. Đường thở của bạn luôn thông thoáng kể cả khi có ống trong miệng và cổ họng. Vì vậy hãy thoải mái và hít thở sâu.
Trong quá trình thủ thuật, có thể cảm thấy rất buồn ngủ và thư giãn bởi thuốc an thần và giảm đau. Đôi khi có thể bị nôn, buồn nôn, đầy hơi hoặc đau quặn nhẹ trong bụng khi ống soi di chuyển. Nếu bị đau, hãy báo cho bác sĩ bằng dấu hiệu đã được thỏa thuận trước như gõ nhẹ vào cánh tay hoặc giơ tay lên. Mặc dù không thể nói chuyện trong khi làm thủ thuật, nhưng vẫn có thể giao tiếp bằng ngôn ngữ cơ thể.
Máy hút được sử dụng để loại bỏ dịch tiết, nó không gây đau. Việc lấy các mẫu sinh thiết cũng không đau.
Bạn sẽ cảm thấy lảo đảo choáng váng sau khi thủ thuật hoàn thành cho đến khi thuốc hết tác dụng. Điều này thường mất một vài giờ. Nhiều người báo cáo rằng họ nhớ rất ít về quá trình này vì thuốc an thần được sử dụng trước và trong khi thủ thuật.
Sau thủ thuật, bạn có thể ợ hơi và cảm thấy đầy bụng trong một thời gian. Ngoài ra bạn có thể bị khô họng hoặc miệng, hơi khàn tiếng, và có thể bị đau họng nhẹ. Những triệu chứng này có thể kéo dài vài ngày. Thuốc viên ngậm và nước súc miệng ấm có thể giúp giảm các triệu chứng cổ họng.
Nếu trẻ em thực hiện thủ thuật này, điều tương tự cũng xảy ra. Nếu trẻ bị đau họng và từ 4 tuổi trở lên, có thể cho bé uống viên ngậm trị đau họng. Ngoài ra, một đứa trẻ 8 tuổi trở lên có thể súc miệng bằng nước muối ấm.
Không uống rượu sau khi hoàn thành thủ thuật.
## **Rủi ro của nội soi đường tiêu hóa trên**
Biến chứng rất hiếm. Có một rủi ro nhỏ là bị thủng thực quản, dạ dày hoặc tá tràng. Nếu điều này xảy ra, bạn có thể cần phải phẫu thuật để điều trị biến chứng này. Cũng có một nguy cơ nhỏ bị nhiễm trùng sau khi thực hiện nội soi.
Chảy máu cũng có thể xảy ra trong quá trình thực hiện thủ thuật hoặc lấy mẫu mô (sinh thiết). Nhưng chảy máu thường tự cầm mà không cần điều trị. Nếu xảy ra nôn trong khi thủ thuật và một số chất nôn vào phổi, viêm phổi hít có thể mắc phải, đây là 1 tình trạng cần phải điều trị bằng kháng sinh.
Nhịp tim không đều có thể xảy ra trong quá trình thủ thuật. Nhưng nó hầu như luôn tự hết mà không cần điều trị.
Nguy cơ của các vấn đề cao hơn ở những người mắc bệnh tim nghiêm trọng, người lớn tuổi và những người có thể chất kém. Hãy trao đổi với bác sĩ về những rủi ro của thủ thuật này.
Sau khi hoàn thành nội soi, hãy báo khẩn cấp cho bác sĩ nếu có các tình trạng dưới đây:
  * Tức ngực.
  * Cảm thấy khó thở hoặc chóng mặt.
  * Có triệu chứng nhiễm trùng, chẳng hạn như sốt hoặc ớn lạnh.
  * Nôn ra máu, cho dù là máu tươi và đỏ hay máu cũ màu như bã cà phê.


## **Ý nghĩa lâm sàng giá trị kết quả**
Nội soi đường tiêu hóa trên (UGI) cho phép bác sĩ quan sát niêm mạc bên trong thực quản, dạ dày và phần đầu tiên của ruột non (tá tràng). 
Bác sĩ có thể trao đổi với bạn về một số phát hiện ngay sau khi hoàn tất thủ thuật nội soi. Nhưng các loại thuốc an thần giảm đau được sử dụng có thể làm suy giảm trí nhớ tạm thời, vì vậy bác sĩ có thể đợi cho đến khi chúng hết hẳn rồi sau đó sẽ thông báo kết quả cho bạn. Có thể mất 2 đến 4 ngày cho một số kết quả sinh thiết. Các xét nghiệm cho một số bệnh nhiễm trùng đôi khi phải mất vài tuần.
### **Bình thường**
Thực quản, dạ dày và ruột non trên (tá tràng) trông bình thường.
### **Bất thường**
  * Viêm hoặc tình trạng kích thích trong thực quản, dạ dày hoặc ruột non.
  * Chảy máu, loét, khối u, rách hoặc giãn tĩnh mạch.
  * Thoát vị dạ dày.
  * Hẹp thực quản.
  * Dị vật được tìm thấy trong thực quản, dạ dày hoặc ruột non.


Sinh thiết có thể được thực hiện để:
  * Tìm hiểu xem khối u hoặc vết loét có chứa tế bào ung thư hay không?
  * Xác định vi khuẩn H. pylori hoặc nấm candida – là nguyên nhân gây viêm loét dạ dày- tá tràng.


## **Yếu tố ảnh hưởng đến nội soi đường tiêu hóa trên**
Không nên thực hiện nội soi đường tiêu hóa trên dưới 2 ngày sau khi có chụp X-quang tiêu hóa trên (GI), để bác sĩ có thể quan sát niêm mạc dạ dày và ruột non rõ hơn.
## **_Điều cần biết thêm_**
Nội soi đường tiêu hóa trên (GI) là cách tốt nhất để đánh giá niêm mạc thực quản, dạ dày và ruột non trên (tá tràng). Bác sĩ có thể lấy mẫu mô để kiểm tra tình trạng nhiễm H. pylori, được cho là nguyên nhân chính gây loét dạ dày hoặc tá tràng.
Ung thư có thể được tìm thấy hoặc loại trừ thông qua nội soi.
Nội soi có thể được thực hiện sau khi chụp Xquang đường tiêu hóa có nghi ngờ bất thường.
Trẻ nhỏ có thể thực hiện nội soi một cách an toàn.
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [Nhận định chung](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-duong-tieu-hoa-tren-y-nghia-lam-sang-gia-tri-ket-qua#nhn-nh-chung)
  * [Chỉ định nội soi đường tiêu hóa trên](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-duong-tieu-hoa-tren-y-nghia-lam-sang-gia-tri-ket-qua#ch-nh-ni-soi-ng-tiu-ha-trn)
  * [Chuẩn bị nội soi đường tiêu hóa trên](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-duong-tieu-hoa-tren-y-nghia-lam-sang-gia-tri-ket-qua#chun-b-ni-soi-ng-tiu-ha-trn)
  * [Thực hiện nội soi đường tiêu hóa trên](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-duong-tieu-hoa-tren-y-nghia-lam-sang-gia-tri-ket-qua#thc-hin-ni-soi-ng-tiu-ha-trn)
  * [Cảm giác khi nội soi đường tiêu hóa trên](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-duong-tieu-hoa-tren-y-nghia-lam-sang-gia-tri-ket-qua#cm-gic-khi-ni-soi-ng-tiu-ha-trn)
  * [Rủi ro của nội soi đường tiêu hóa trên](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-duong-tieu-hoa-tren-y-nghia-lam-sang-gia-tri-ket-qua#ri-ro-ca-ni-soi-ng-tiu-ha-trn)
  * [Ý nghĩa lâm sàng giá trị kết quả](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-duong-tieu-hoa-tren-y-nghia-lam-sang-gia-tri-ket-qua#-ngha-lm-sng-gi-tr-kt-qu)
  * [Yếu tố ảnh hưởng đến nội soi đường tiêu hóa trên](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-duong-tieu-hoa-tren-y-nghia-lam-sang-gia-tri-ket-qua#yu-t-nh-hng-n-ni-soi-ng-tiu-ha-trn)
  * [Điều cần biết thêm](https://bvnguyentriphuong.com.vn/noi-soi/noi-soi-duong-tieu-hoa-tren-y-nghia-lam-sang-gia-tri-ket-qua#iu-cn-bit-thm)



