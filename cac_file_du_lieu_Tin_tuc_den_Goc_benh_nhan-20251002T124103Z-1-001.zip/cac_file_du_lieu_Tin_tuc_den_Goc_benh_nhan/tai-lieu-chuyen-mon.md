## ADA 2022 trong điều trị đái tháo đường

## **Tóm tắt vài điểm mới của ADA 2022:**
- Chẩn đoán ĐTĐ týp 1: tích hợp thêm Đồng thuận ADA/EASD 2021 về Quản lý ĐTĐ týp 1.
- Tầm soát ĐTĐ týp 2: nên bắt đầu từ 35 tuổi cho tất cả mọi người, thay vì 45 tuổi như khuyến cáo trước đây.
- Phần ĐTĐ thai kỳ: nêu rõ hơn về thời điểm và lựa chọn xét nghiệm tầm soát bất thường đường huyết sớm trong tam cá nguyệt 1 (trước tuần 15).
- Điều trị Tiền Đái tháo đường: thêm khuyến cáo liên quan metformin và đề cập kết quả khả quan của Vitamin D trong một vài nhóm dân số nhất định.
- Theo dõi đường huyết: Thuật ngữ Tự theo dõi đường huyết (bằng máy thử đường huyết mao mạch) (Self-monitoring of blood glucose - SMBG) được đổi thành tên đơn giản hơn là Theo dõi đường huyết (Blood glucose monitoring - BGM), phân biệt với CGM (continuous glucose monitoring) là theo dõi đường huyết liên tục.
- Bút insulin: hiện nay có những bút thông minh (smart pen), tên mới là bút insulin có kết nối (connected insulin pen - CIP), với khả năng ghi nhận và chuyển dữ liệu về liều đã sử dụng qua app điện thoại.
- Điều trị béo phì: FDA chấp thuận thêm một đồng vận thụ thể GLP-1 là semaglutide, bên cạnh liraglutide 3mg trước đây.
- Điều trị ĐTĐ: (1) Týp 1: tích hợp thêm Đồng thuận ADA/EASD 2021 về Quản lý ĐTĐ týp 1; (2) Týp 2: gần tương tự ADA 2021, sơ đồ giản lược hơn, thêm khuyến cáo nhấn mạnh tiếp tục dùng metformin dù đã khởi trị insulin.
- Phần Biến chứng mạch máu lớn: bàn luận thêm về kết quả các thử nghiệm DAPA-HF, DAPA-CKD, SOLOIST-WHF, AMPLITUDE-O, VERTIS-CV, SCORED, EMPEROR-Reduced.
- Tách Bệnh thận mạn ra một phần riêng khỏi Biến chứng mạch máu nhỏ, thêm khuyến cáo sử dụng finerenone.
Link tải PDF (Final): [**ADA 2022**](https://drive.google.com/file/d/1m55C6-tkIWD9aDmsj3lt9zO3JEShzysD/view?usp=sharing)
**Thực hiện bởi Dược lâm sàng - Thông tin thuốc**

## TIẾP CẬN & ĐIỀU TRỊ TỔN THƯƠNG KHÍ PHẾ QUẢN SAU ĐẶT NỘI KHÍ QUẢN

Xem toàn bộ tài liệu [**tại đây**](https://bvnguyentriphuong.com.vn/uploads/112023/files/TIE%CC%82%CC%81P%20CA%CC%A3%CC%82N%20%26%20%C4%90IE%CC%82%CC%80U%20TRI%CC%A3%20TO%CC%82%CC%89N%20THU%CC%9BO%CC%9BNG%20KHI%CC%81%20QUA%CC%89N%20SAU%20%C4%90A%CC%A3%CC%86T%20NKQ%202024\(1\).pdf)
Biên dịch: **Ths. Bs Hồ Hoàng Kim - BV Nguyễn Tri Phương**

## Tài liệu chuyên môn “Hướng dẫn điều trị dự phòng thuyên tắc huyết khối tĩnh mạch”

Huyết khối tĩnh mạch sâu (HKTMS) chi dưới và thuyên tắc động mạch phổi được coi là hai biểu hiện cấp tính có chung một quá trình bệnh lý, gọi là thuyên tắc huyết khối tĩnh mạch (TTHKTM). Có nhiều thuật ngữ được sử dụng để chỉ thuyên tắc động mạch phổi như thuyên tắc phổi, tắc động mạch phổi, nhồi máu phổi. Tuy nhiên, để thống nhất chúng tôi sử dụng thuật ngữ tắc động mạch phổi hoặc thuyên tắc phổi, viết tắt là TTP xuyên suốt trong phác đồ. HKTMS là sự hình thành cục máu đông trong các tĩnh mạch sâu của hệ tuần hoàn, thường gặp nhất là tĩnh mạch chi dưới, gây tắc nghẽn hoàn toàn hoặc một phần dòng máu trong lòng tĩnh mạch. HKTMS chi dưới đoạn gần là thuật ngữ để chỉ vị trí của huyết khối nằm từ tĩnh mạch khoeo trở lên, lan đến các tĩnh mạch sâu tầng đùi, chậu, hay tĩnh mạch chủ dưới. Khi huyết khối này bứt ra khỏi lòng mạch, sẽ di chuyển theo dòng máu về tim phải lên động mạch phổi, dẫn đến bệnh cảnh tắc động mạch phổi. TTP là sự tắc nghẽn cấp tính động mạch phổi và/hoặc các nhánh của nó, do cục máu đông (có thể là khí, mỡ, tắc mạch ối nhưng hiếm hơn) di chuyển từ hệ thống tĩnh mạch (HKTMS), hoặc hình thành tại chỗ trong động mạch phổi. Nhồi máu phổi (chiếm khoảng 30% các trường hợp TTP) xảy ra khi huyết khối nhỏ làm tắc các nhánh động mạch phổi phía xa, dẫn đến tình trạng thiếu máu cục bộ, chảy xuất huyết nang và hoại tử nhu mô phổi.
Tại các nước phát triển, TTHKTM đứng thứ 3 trong số các nguyên nhân tử vong tim mạch. Mỗi năm tại Hoa Kỳ có khoảng 900.000 trường hợp bị thuyên tắc HKTM, gây ra 60.000 đến 300.000 ca tử vong hàng năm. Theo các nghiên cứu dịch tễ, tỷ lệ mới mắc TTHKTM hàng năm xấp xỉ 100/100.000 dân tại Châu Âu và Bắc Mỹ, thấp hơn ở Châu Á (16/100.000 tại Đài Loan, 17/100.000 tại Hồng Kông, 57/100.000 tại Singapore), nhưng có xu hướng tăng lên. Nguy cơ TTHKTM ở bệnh nhân nằm viện mà không được phòng ngừa dao động từ 10-80%. Theo nghiên cứu INCIMEDI tại Việt Nam, tỷ lệ TTHKTM không triệu chứng ở bệnh nhân nội khoa nằm viện là 22%. 9,9% bệnh nhân sau phẫu thuật ung thư phụ khoa (Diệp Bảo Tuấn và cs), 39% bệnh nhân sau phẫu thuật khớp háng bị TTHKTM (Nguyễn Văn Trí và cs). Tỷ lệ này cao hơn ở bệnh nhân suy tim mạn tính điều trị nội trú (42,6%) hoặc bệnh nhân tại khoa hồi sức tích cực (46%), theo báo cáo của Huỳnh Văn Ân và cs. 
Cơ chế hình thành TTHKTM là do sự phối hợp của yếu tố (gọi là tam giác Virchow): ứ trệ tuần hoàn tĩnh mạch, rối loạn quá trình đông máu gây tăng đông, và tổn thương thành mạch. Ứ máu tĩnh mạch: tuần hoàn tĩnh mạch kém và ứ trệ thúc đẩy sự hình thành huyết khối. Các yếu tố làm tăng nguy cơ bị ứ máu tĩnh mạch là tình trạng bất động, gây mê toàn thân, liệt, tổn thương tủy sống, tuổi trên 40, các bệnh nội khoa cấp tính như NMCT, đột quỵ, suy tim sung huyết, đợt tiến triển của bệnh phổi tắc nghẽn mạn tính… Tăng đông máu: một số tình trạng bệnh lý (cả di truyền và mắc phải) làm tăng nguy cơ TTHKTM do tăng đông máu, như ung thư, nồng độ estrogen cao (béo phì, mang thai, điều trị hormone), viêm ruột, hội chứng thận hư, nhiễm khuẩn huyết, và tăng đông máu do di truyền (đột biến gen prothrombin, thiếu hụt protein C, S, thiếu antithrombin III, hội chứng kháng phospholipid). Tổn thương thành mạch: tổn thương tế bào nội mô thúc đẩy sự hình thành huyết khối, thường bắt đầu ở các van tĩnh mạch. Tổn thương thành mạch có thể xảy ra sau một số nguyên nhân gồm chấn thương, tiền sử HKTM, phẫu thuật, lấy tĩnh mạch hiển và đặt ống thông tĩnh mạch trung tâm… 
Xem đầy đủ tài liệu [**tại đây**](https://bvnguyentriphuong.com.vn/uploads/112023/files/phong%20ngua%20thuyen%20tac.pdf)
#### Nội dung trong file:

syt_bacgiang_vt_Van thu SYT Bac Giang_23/10/2023 11:45:07 
 
 
 
 
 
 
 
 
 
HƯỚNG DẪN ĐIỀU TRỊ DỰ PHÒNG  
THUYÊN TẮC HUYẾT KHỐI TĨNH MẠCH  
(Ban hành kèm theo Q uyết định số  3908 /QĐ-BYT 
ngày 20 tháng 10 năm 202 3 của Bộ trưởng Bộ Y  tế) 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
Hà N ội, 202 3 
 
 
 
 syt_bacgiang_vt_Van thu SYT Bac Giang_23/10/2023 11:45:07 
 
MỤC LỤC  
DANH SÁCH BAN BIÊN SOẠN “HƯỚNG DẪN DỰ PHÒNG THUYÊN TẮC 
HUYẾT KHỐI TĨNH MẠCH”  ................................ ................................ ..................  4 
DANH  MỤC KÝ HI ỆU VÀ CH Ữ VIẾT TẮT ................................ ..........................  6 
DANH M ỤC BẢNG ................................ ................................ ................................ .... 7 
DANH M ỤC SƠ Đ Ồ................................ ................................ ................................ .... 9 
PHẦN KHUY ẾN CÁO  ................................ ................................ .............................  10 
1.Nhóm khuy ến cáo:  ................................ ................................ ................................ .... 10 
2.Mức bằng ch ứng ................................ ................................ ................................ ....... 10 
3. M ức khuy ến cáo ASH  ................................ ................................ .............................  10 
CHƯƠNG 1. ĐẠI CƯƠNG  ................................ ................................ ......................  12 
1.Định nghĩa:  ................................ ................................ ................................ ............  12 
2.Dịch tễ học: ................................ ................................ ................................ ...........  12 
3.Sinh lý b ệnh: ................................ ................................ ................................ .........  12 
4.Yếu tố nguy cơ:  ................................ ................................ ................................ ..... 13 
CHƯƠNG  2. CHIẾN LƯỢC DỰ PHÒNG  THUYÊN T ẮC HUY ẾT KHỐI 
TĨNH M ẠCH CHUNG  ................................ ................................ .............................  14 
1.Quy trình chung d ự phòng TTHKTM trên b ệnh nhân:  ................................ .........  14 
2.Lưu ý đi ều chỉnh liều khi d ự phòng TTHKTM trên nhóm b ệnh nhân đ ặc biệt: ... 16 
CHƯƠNG 3 . DỰ PHÒNG TTHKTM Ở BỆNH NHÂN  NỘI KHOA  ..................  19 
1. Dự phòng TTHKTM ở bệnh nhân n ội khoa:  ................................ .......................  20 
2. Dự phòng TTHKTM cho b ệnh nhân  nội khoa c ấp tính t ại khoa  hồi sức tích c ực 
(ICU)  ................................ ................................ ................................ ........................  21 
3. Dự phòng TTHKTM ở bệnh nhân đ ột quỵ: ................................ .........................  22 
4. Dự phòng TTHKTM ở bệnh nhân n ội khoa COVID – 19 ................................ ... 24 
CHƯƠNG  4. DỰ PHÒNG THUYÊN T ẮC HUYẾT KHỐI T ĨNH MẠCH Ở 
BỆNH NHÂN NỘI  UNG THƯ  ................................ ................................ .................  26 
1. Đánh giá nguy cơ Huy ết khối ................................ ................................ ..............  26 
2. Đánh giá nguy cơ Xu ất huy ết ................................ ................................ ...............  27 
3. Phác đ ồ dự phòng TT HKTM trên b ệnh nhân n ội ung thư:  ................................ .. 28 
3.1. D ự phòng tiên phát  ................................ ................................ ...............................  28 
3.2. D ự phòng tái phát  ................................ ................................ ................................ . 29 
CHƯƠNG  5. DỰ PHÒNG TTHKTM Ở BỆNH NHÂN NGO ẠI KHOA  
CHUNG  ................................ ................................ ................................ ......................  33 
1.Chỉ định ................................ ................................ ................................ .................  33 
2.Mục tiêu................................ ................................ ................................ .................  33 syt_bacgiang_vt_Van thu SYT Bac Giang_23/10/2023 11:45:07 
 
3.Nội dung  ................................ ................................ ................................ ................  33 
3.1. Đánh giá nguy cơ TTHKTM cho BN ngo ại khoa chung:  ................................ ..... 33 
3.2. Xem  xét ch ống ch ỉ định thu ốc kháng đông trên b ệnh nhân  ngoại khoa chung:  .. 34 
3.3. D ự phòng TTHKTM trên b ệnh nhân Ph ẫu thu ật tổng quát:  ................................  34 
CHƯƠNG  6. DỰ PHÒNG TTHKTM Ở BỆNH NHÂN PH ẪU THU ẬT CH ẤN 
THƯƠNG S Ọ NÃO  ................................ ................................ ................................ ... 37 
1. Chỉ định ................................ ................................ ................................ ................  37 
2. M ục tiêu................................ ................................ ................................ ................  37 
3. Nội dung  ................................ ................................ ................................ ...............  37 
CHƯƠNG  7. DỰ PHÒNG THUYÊN T ẮC HUY ẾT KH ỐI TĨNH M ẠCH Ở 
BỆNH NHÂN PH ẪU THU ẬT UNG THƯ  ................................ ..............................  39 
1. Đánh giá nguy cơ TTHKTM cho b ệnh nhân  ................................ .......................  39 
2. Xem xét ch ống ch ỉ định thu ốc kháng đông trên b ệnh nhân  phẫu thu ật ...............  39 
3.Lựa chọn các bi ện pháp d ự phòng  ................................ ................................ ........  39 
3.1. Các bi ện pháp d ự phòng chính  ................................ ................................ .............  39 
3.2. Chi ến lược dự phòng c ụ thể................................ ................................ ..................  39 
3.3. M ột số khuy ến cáo c ủa Hội ung thư Lâm sàng Hoa K ỳ về dự phòng TTHKTM ở 
bệnh nhân ph ẫu thu ật Ung thư.  ................................ ................................ ...................  41 
CHƯƠNG  8. DỰ PHÒNG TTHKTM Ở BỆNH NHÂN CH ẤN THƯƠNG 
CHỈNH HÌNH  ................................ ................................ ................................ ............  42 
1. Chỉ định ................................ ................................ ................................ ................  42 
2. M ục tiêu................................ ................................ ................................ ................  42 
3. Nội dung  ................................ ................................ ................................ ...............  42 
3.1. D ự phòng TTHKTM trên b ệnh nhân ph ẫu thu ật thay kh ớp háng và kh ớp gối .... 43 
3.2. D ự phòng TTHKTM trên b ệnh nhân ph ẫu thu ật gãy xương ch ậu, xương hông, 
xương đùi . ................................ ................................ ................................ ....................  43 
3.3.  D ự phòng TTHKTM trên b ệnh nhân ch ấn thương n ặng, đa ch ấn thương  ..........  44 
3.4. Dự phòng TTHKTM trên b ệnh nhân ch ấn thương ch ỉnh hình khác  ....................  44 
CHƯƠNG 9. DỰ PHÒNG  THUYÊN TẮC  HUYẾT KHỐI TĨNH MẠCH Ở 
BỆNH NHÂN SẢN PHỤ KHOA  ................................ ................................ .............  46 
1.Dự phòng TTHKTM ở bệnh nhân  phẫu thu ật phụ khoa:  ................................ ..... 46 
2.Dự phòng TTHKTM ở bệnh nhân  sản khoa  ................................ .........................  46 
2.1. Đại cương  ................................ ................................ ................................ .............  46 
2.2. Các y ếu tố nguy cơ (YTNC)  ................................ ................................ .................  46 
2.3. Dự phòng thuyên t ắc huy ết khối tĩnh m ạch ở bệnh nhân s ản khoa  .....................  47 
CHƯƠNG  10. HƯỚNG D ẪN XỬ TRÍ BI ẾN CH ỨNG XU ẤT HUY ẾT Ở BỆNH 
NHÂN DÙNG KH ÁNG ĐÔNG  ................................ ................................ ...............  53 syt_bacgiang_vt_Van thu SYT Bac Giang_23/10/2023 11:45:07 
 
1.Xu ất huyết lớn ................................ ................................ ................................ ....... 53 
2.  Các bước xử lý xu ất huy ết do quá li ều kháng đông  ................................ ............  53 
2.1. Các bư ớc thực hiện khi b ệnh nhân có bi ến cố xuất huy ết (bảng 19)  ...................  53 
2.2. M ột số trường hợp cụ thể đặc biệt ................................ ................................ ........  57 
3. Sử dụng lại kháng đông  ................................ ................................ ........................  58 
3.1. Đánh giá b ệnh nhân trư ớc khi ch ỉ định dùng l ại thuốc kháng đông  ....................  58 
3.2. S ử dụng lại thuốc kháng đông  và kháng ngưng t ập tiểu cầu sau bi ến chứng xu ất 
huyết ................................ ................................ ................................ .............................  62 
3.3. M ột số trường hợp cụ thể đặc biệt ................................ ................................ ........  63 
3.4. S ử dụng lại kháng đông sau xu ất huy ết nặng trên b ệnh nhân huy ết khối tĩnh m ạch
 ................................ ................................ ................................ ................................ ..... 65 
4. Giảm tiểu cầu do Heparin  ................................ ................................ ....................  65 
4.1. Đại cương  ................................ ................................ ................................ .............  65 
4.2. Cơ ch ế bệnh sinh  ................................ ................................ ................................ .. 65 
4.3. Ch ẩn đoán  ................................ ................................ ................................ .............  66 
4.4. Đi ều trị ................................ ................................ ................................ ..................  69 
TÀI LI ỆU THAM KH ẢO ................................ ................................ .........................  73 
 
 
 
 
 
 
 
 
 
 
 
 
 syt_bacgiang_vt_Van thu SYT Bac Giang_23/10/2023 11:45:074 
 
DANH SÁCH BAN BIÊN  SOẠN  
 
Chỉ đạo biên soạn   
GS.TS. Trần Văn Thuấn  Thứ trưởng Bộ Y tế  
  
Chủ biên   
PGS.TS. Lương Ngọc Khuê  Phó Chủ tịch Hội đồng Y khoa Quốc gia, Cục trưởng 
Cục Quản lý Khám, chữa bệnh (QLKCB)  
GS. TS. Nguyễn Gia Bình  Chủ tịch Hội Hồi sức Cấp cứu  và Chống  độc Việt Nam  
 
Tham gia biên soạn và thẩm định  
TS. Huỳnh Văn Ân  Phó Chủ Tịch, Tổng Thư ký Liên chi Hội Hồi sức Cấp 
cứu thành phố Hồ Chí Minh  (TPHCM) , Trưởng khoa 
Hồi sức tích cực – Bệnh viện  Nhân Dân Gia Định  
GS.TS. Nguyễn Gia Bình  Chủ tịch Hội Hồi sức  Cấp cứu  và Chống độc  Việt Nam  
PGS. TS. Phạm Văn Bình  Phó Giám Đốc Bệnh viện K  
PGS. TS. Lê Hoài Chương  Phó Giám đốc Bệnh viện Phụ sản Trung ương 
PGS.TS Đào Xuân Cơ  Giám đốc Bệnh viện Bạch Mai   
TS. Phù Chí Dũng  Giám đốc Bệnh viện Truyền máu - Huyết học , TPHCM  
TS. Vương Ánh Dương  Phó Cục trưởng Cục QLKCB  
PGS.TS. Hoàng Bùi Hải  Trưởng khoa Cấp cứu - Hồi sức tích cực , Bệnh viện 
Đại học Y Hà Nội  
ThS. Nguyễn Tuấn Hải  Trưởng phòng C6  - Viện Tim mạch - Bệnh viện Bạch Mai  
GS.TS. Nguyễn Như Hiệp  Giám đốc Bệnh v iện Trung ương  Huế, Phó Chủ tịch 
Hội Ngoại khoa và Phẫu thuật nội soi Việt Nam, Phó 
chủ tịch hội Ung thư Việt Nam 
PGS.TS. Phạm Mạnh Hùng  Viện trưởng Viện Tim mạch  - Bệnh viện Bạch Mai, 
Phó Chủ tịch Hội Tim mạch Việt Nam  
PGS. TS. Đỗ Phước Hùng  Chủ nhiệm Bộ  môn Chấn thương chỉnh hình – Trường 
Đại học Y – Dược TPHCM  
PGS.TS Đinh Thị Thu Hương  Nguyên Phó Viện Trưởng Viện Tim mạch – Bệnh viện 
Bạch Mai  
PGS. TS. Nguyễn Mạnh Khánh  Phó Giám đốc  BV Hữu nghị Việt Đức , Phó Viện 
trưởng Viện Chấn thương chỉnh hình – BV Hữu nghị 
Việt Đức  
TS. Bạch Quốc Khánh  Phó Chủ tịch kiêm Tổng thư ký Hội Huyết học Truyền 
máu Việt Nam  syt_bacgiang_vt_Van thu SYT Bac Giang_23/10/2023 11:45:075 
 
TS. Nguyễn Trọng Khoa   Phó C ục trưởng C ục QLKCB  
TS. Trần Viết Lực  Phó Giám đốc Bệnh viện Lão khoa Trung ương  
TS. Trần Thị Kiều My  Trưởng khoa Đông máu – Viện Huyết học  – Truyền máu 
Trung ương  
PGS.TS . Huỳnh Nghĩa   Trưởng Khoa Huyết học Nhi 2 – Bệnh viện Truyền 
máu Huyết học , TPHCM  
BSCKII . Nguyễn Bá Mỹ Nhi  Giám đốc Trung tâm Sản phụ khoa, Bệnh viện Đa khoa 
Tâm Anh TPHCM; Nguyên Phó Giám đốc phụ trách  
chuyên môn, Bệnh viện Phụ sản Từ Dũ  
PGS.TS . Lê Văn Quảng  Giám đốc Bệnh viện K  
PGS.TS . Vũ Bá Quyết  Nguyên Giám đốc Bệnh viện Phụ sản Trung ương  
GS.TS . Trịnh Hồng Sơn  Nguyên Phó Giám đốc Bệnh viện Hữu nghị Việt Đức  
PGS.TS . Hoàng Văn Sỹ  Trưởng khoa Nội t im mạch – Bệnh viện Chợ Rẫy, Chủ 
nhiệm Bộ môn Nội – Đại học Y Dược TPHCM  
PGS.TS Nguyễn Huy Thắng  Chủ tịch Hội Đột quỵ thành phố HCM, Phó Chủ tịch 
Hội Đột quỵ Việt Nam, Trưởng khoa Bệnh lý mạch 
máu não, Bệnh viện Nhân Dân 115 TPHCM  
GS.TS . Phạm Thắng  Chủ t ịch Hội Lão khoa Việt Nam  
PGS.TS Phạm Thị Ngọc Thảo  Phó giám đốc Bệnh viện Chợ Rẫy  - Trưởng Bộ môn 
Hồi sức cấp cứu - chống độc, Đại học Y Dược TPHCM  
GS.TS Nguyễn Văn Thông  Phó Chủ tịch Hội phòng, chống Tai biến mạch máu não 
Việt Nam  
PGS.TS. Đặng Quốc Tu ấn  Nguyên Trưởng khoa Hồi sức tích cực  - Bệnh viện 
Bạch Mai   
PGS.TS. Trần Thanh Tùng  Trưởng khoa Huyết học  - Bệnh viện Chợ Rẫy   
TS. Nguyễn Tuấn Tùng  Giám đốc Trung tâm Huyết học  - Bệnh viện Bạch Mai   
  
Tổ Thư ký   
PGS. TS. Hoàng Bùi Hải  Trưởng khoa Cấp cứu-Hồi sức tích cực, Bệnh viện Đại 
học Y Hà Nội  
ThS. Trương Lê Vân Ngọc  Trưởng Phòng Nghiệp vụ - Bảo vệ sức khỏe cán bộ, 
Cục QLKCB  
CN. Đỗ Thị Thư  Cục QLKCB – Bộ Y tế  
 syt_bacgiang_vt_Van thu SYT Bac Giang_23/10/2023 11:45:076 
 
DANH  MỤC KÝ HI ỆU VÀ CH Ữ VIẾT TẮT 
 
 
Tiếng Anh   
AIS Abbreviated Injury Score: Thang  điểm ch ấn thương rút g ọn 
DOAC  Direct Oral Anticoagulant: Thuốc kháng đông tr ực tiếp đường uống 
NOAC  Non-vitamin K Oral Anticoagulant  : Thuốc kháng đông đưòng uống 
không phải kháng vitamin K   
GCS  Graduated Compression Stockings: Tất áp l ực y khoa  
IPC Intermittent Pneumatic Compression: Thiết bị bơm hơi áp l ực ngắt 
quãng  
HIT Heparin -Induced Thrombocytopenia: Gi ảm tiểu cầu do heparin   
LMWH  Low Molecule Weight Heparin: Heparin tr ọng lư ợng phân t ử thấp 
(Heparin TLPTT)  
PPS Padua Prediction Score: Thang đi ểm dự báo Padua  
UFH  Unfractionated  Heparin: Heparin không phân đo ạn hay heparin chu ẩn  
eGFR  Estimated Glomerular filtration rate: Mức lọc cầu thận ước tính   
Tiếng Việt   
HKTM  Huyết khối tĩnh m ạch 
HKTMS  Huyết khối tĩnh m ạch sâu  
MLCT  Mức lọc cầu thận 
NMCT  Nhồi máu cơ tim  
TDD  Tiêm dư ới da 
TTHKTM  Thuyên t ắc huy ết khối tĩnh m ạch 
TTP, TĐMP  Thuyên t ắc phổi, Tắc động m ạch ph ổi  
YTNC  Yếu tố nguy cơ  
VNHA  Hội Tim m ạch học Việt Nam  
 
 
 
 syt_bacgiang_vt_Van thu SYT Bac Giang_23/10/2023 11:45:077 
 
DANH M ỤC BẢNG 
 
Bảng 1: Các y ếu tố nguy  cơ chính c ủa TTHKTM  ................................ ........................  13 
Bảng 2: Quy trình chung d ự phòng TTHKTM trên b ệnh nhân  ................................ ..... 14 
Bảng 3: T ổng hợp các bi ện pháp d ự phòng TTHKTM v à các bư ớc thực hiện .............  14 
Bảng 4: T ổng hợp các bi ện pháp d ự phòng TTHKTM và ch ỉ định ..............................  15 
Bảng 5: Điều chỉnh liều Heparin trong d ự phòng TTHKTM cho b ệnh nhân suy th ận 
 ................................ ................................ ................................ ................................ ....... 17 
Bảng 6: Điều chỉnh liều kháng đông đường uống dự phòng TTHKTM trên bệnh    
nhân thay khớp háng, khớp gối bị suy thận  ................................ ................................ ... 17 
Bảng 7: Khuyến cáo điều chỉnh liều Heparin TLPTT ở bệnh nhân béo phì  .................  18 
Bảng 8: Thang đi ểm PADUA đánh giá nguy cơ TTHKTM ở bệnh nhân n ội khoa  ...... 19 
Bảng 9: Thang đi ểm IMPROVE đánh giá nguy cơ xu ất huy ết ở bệnh nhân n ội khoa
 ................................ ................................ ................................ ................................ ..... ..20 
Bảng 10: Khuy ến cáo d ự phòng TTHKTM ở bệnh nhân n ội khoa theo hư ớng dẫn    
Hội Tim m ạch học Việt Nam (VNHA) 2016  ................................ ................................  20 
Bảng 11: Hướng dẫn các bư ớc dự phòng TTHKTM ở bệnh nhân n ội khoa  .................  21 
Bảng 12: Hướng dẫn các bư ớc dự phòng TTHKTM ở bệnh nhân Đ ột quỵ cấp ...........  23 
Bảng 13: Hướng dẫn các bư ớc dự phòng TTHKTM ở bệnh nhân COVID -19.............  25 
Bảng 14: Thang đi ểm KHORANA  ................................ ................................ ...............  26 
Bảng 15: Thang đi ểm SAVED (dành c ho nhóm b ệnh nhân đa u t ủy được điều trị thuốc 
điều biến miễn dịch kết hợp Dexamethasone li ều cao)  ................................ .................  27 
Bảng 16: Bảng ch ống ch ỉ định của thu ốc kháng đông  ................................ ..................  27 
Bảng 17: Bảng lựa chọn các phương pháp trong d ự phòng TTHKTM cho b ệnh nhân 
ung thư đi ều trị nội trú ................................ ................................ ................................ ... 32 
Bảng 18: Bảng lựa chọn các phương pháp trong d ự phòng TTHKTM cho b ệnh nhân 
ung thư đi ều trị nội khoa ngo ại trú ................................ ................................ ................  32 
Bảng 19: B ảng đánh giá YTNC TTHKTM ở bệnh nhân ngo ại khoa b ằng thang đi ểm 
CAPRINI  ................................ ................................ ................................ .......................  33 
Bảng 20: Dự phòng TTHKTM trên b ệnh nhân ph ẫu thu ật chung  ................................  35 
Bảng 21: Thang đi ểm đánh giá nguy cơ TTHKTM trên b ệnh nhân ph ẫu thu ật chấn 
thương s ọ não ................................ ................................ ................................ ................  37 
Bảng 22: Hư ớng dẫn dự phòng TTHKTM ở bệnh nhân ph ẫu thu ật chấn thương s ọ   
não................................ ................................ ................................ ................................ .. 38 
Bảng 23: Chiến lược dự phòng TTHKTM ở bệnh nhân ph ẫu thu ật ung thư d ựa theo 
phân t ầng nguy cơ c ủa thang đi ểm CAPRINI  ................................ ...............................  40 
Bảng 24: Bảng khuy ến cáo d ự phòng TTHKTM ở bệnh nhân  phẫu thu ật chỉnh hình 
theo hư ớng dẫn VNHA 2016  ................................ ................................ .........................  42 syt_bacgiang_vt_Van thu SYT Bac Giang_23/10/2023 11:45:078 
 
Bảng 25: Các phương pháp d ự phòng TTHKTM ở bệnh nhân ph ẫu thu ật thay kh ớp 
háng, kh ớp gối ................................ ................................ ................................ ...............  43 
Bảng 26: Các phươ ng pháp d ự phòng TTHKTM ở bệnh nhân ph ẫu thu ật gãy xương 
chậu, xương hông và xương đùi  ................................ ................................ ....................  43 
Bảng 27: Các phương pháp d ự phòng TTHKTM ở bệnh nhân ch ấn thương n ặng, đa 
chấn thương  ................................ ................................ ................................ ..................  45 
Bảng 28: Các phương pháp d ự phòng TTHKTM ở bệnh nhân ch ấn thương ch ỉnh    
hình khác  ................................ ................................ ................................ ........................  45 
Bảng 29: Thang đi ểm đánh giá nguy cơ TTHKTM trư ớc và sau sinh  ..........................  48 
Bảng 30: Li ều LMWH trong d ự phòng TTHKTM ở bệnh nhân s ản khoa theo cân  
nặng ................................ ................................ ................................ ...............................  49 
Bảng 31: Liều UFH trong d ự phòng TTHKTM ở bệnh nhân s ản khoa theo cân  n ặng 50 
Bảng 32: Thời gian gi ữa việc dùng thu ốc kháng đông và gây tê t ủy sống/gây tê ngoài 
màng c ứng ................................ ................................ ................................ .....................  51 
Bảng 33: Bảng phân chia các m ức độ xuất huy ết ................................ .........................  53 
Bảng 34: Các bư ớc xử trí bi ến chứng xu ất huy ết do quá li ều thu ốc kháng đông  .........  54 
Bảng 35: Bảng phân nhóm nguy cơ huy ết khối động m ạch ................................ ..........  59 
Bảng 36: Bảng phân nhóm nguy cơ HKTM ................................ ................................ .. 60 
Bảng 37: Bảng đánh giá nguy cơ huy ết khối ở bệnh nhân có nhi ều bệnh lý ph ối hợp
 ................................ ................................ ................................ ................................ ..... ..61 
Bảng 38: Bảng phân nhóm nguy cơ xu ất huy ết................................ .............................  61 
Bảng 39: Thang đi ểm HAS -BLED  ................................ ................................ ................  62 
Bảng 40: Than g điểm 4T’s  ................................ ................................ ............................  67 
Bảng 41: Các giai đo ạn của HIT  ................................ ................................ ...................  68 
Bảng 42: Các thu ốc kháng đông không ph ải Heparin trong đi ều trị HIT .....................  71 
 
 
 
 
 
 
 
 
 
 
 
 syt_bacgiang_vt_Van thu SYT Bac Giang_23/10/2023 11:45:079 
 
DANH M ỤC SƠ Đ Ồ 
 
 
Sơ đồ 1: Dự phòng TTHKTM ở bệnh nhân ung thư đi ều trị nội trú .............................  30 
Sơ đồ 2: Dự phòng TTHKTM ở bệnh nhân ung thư đi ều trị ngoại trú .........................  31 
Sơ đồ 3: Quy trình đánh giá và x ử trí TTHKTM ở bệnh nhân s ản khoa  ......................  47 
Sơ đồ 4: Các bư ớc xử trí ở bệnh nhân xu ất huy ết lớn sau dùng thu ốc kháng đông  ...... 56 
Sơ đồ 5: Các bư ớc sử dụng lại thuốc kháng đông và kháng k ết tập tiểu cầu sau bi ến 
chứng xu ất huy ết ................................ ................................ ................................ ...........  63 
Sơ đồ 6: Hư ớng dẫn chẩn đoán HIT  ................................ ................................ ..............  68 
Sơ đồ 7: Hư ớng dẫn điều trị HIT ................................ ................................ ...................  70 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 syt_bacgiang_vt_Van thu SYT Bac Giang_23/10/2023 11:45:0710 
 
PHẦN KHUY ẾN CÁO  
 
1. Nhóm khuy ến cáo  
Nhóm  Mức độ khuyến cáo  Thuật ngữ sử dụng  
I Chứng cứ và/hoặc sự đồn g thuận cho thấy việc điều 
trị mang lại lợi ích và hiệu quả  Khuyến cáo dùng,  
Chỉ định  
II Chứng cứ còn đang bàn cãi và/hoặc ý kiến khác 
nhau về lợi ích/hiệu quả của việc điều trị   
- IIa Chứng cứ/ý kiến ủng hộ mạnh về tính hiệu quả của 
điều trị  Nên chỉ địn h 
- IIb Chứng cứ/ý kiến cho thấy ít có hiệu quả của điều trị  Có thể chỉ định  
III Chứng cứ và/hoặc sự đồng thuận cho thấy việc điều 
trị không mang lại lợi ích và hiệu quả, trong một vài 
trường hợp có thể gây hại.  Không được dùng,  
Không chỉ định  
2. Mức bằng chứng 
 
A Dữ liệu có từ nhiều nghiên cứu lâm sàng ngẫu nhiên hoặc các phân tích gộp  
B Dữ liệu có từ một nghiên cứu lâm sàng ngẫu nhiên hoặc các nghiên cứu lâm 
sàng lớn không ngẫu nhiên  
C Sự đồng thuận của các chuyên gia và/hoặc các nghiên cứu nhỏ, các n ghiên 
cứu hồi cứu  
 
3. Mức khuy ến cáo ASH  
Độ mạnh của khuyến cáo là “mạnh” (“hội đồng hướng dẫn khuyến cáo …”) hoặc “có 
điều kiện” (“hội đồng hướng dẫn đề nghị …”) và có giải nghĩa như sau:   
Khuyến cáo mạnh  
- Với bệnh nhân: hầu hết bệnh nhân trong tình huống này sẽ muốn nhận được các 
hành động được khuyến cáo thực hiện, và chỉ có một tỷ lệ nhỏ không mong muốn.    
- Với bác sĩ lâm sàng: hầu hết các bác sĩ sẽ thực hiện các hành động được khuyến 
cáo. Quy trình hỗ trợ ra quyết định chính thức thường không cần thiết trong trường 
hợp này để giúp mỗi bệnh nhân đưa ra lựa chọn phù hợp với giá trị và mong muốn 
của họ  
- Với người hoạch định chính sách : khuyến cáo có thể phù hợp để làm chính sách 
trong hầu hết các tình huống. Tuân thủ các khuyến cáo trong hướng dẫn này có thể  
được sử dụng làm tiêu chí chất lượng hoặc chỉ số hiệu suất.  
- Với nhà nghiên cứu: khuyến cáo được hỗ trợ bởi các nghiên cứu đáng tin cậy hoặc 
các đánh giá thuyết phục khác khiến cho các nghiên cứu bổ trợ thêm khó lòng làm 
thay đổi khuyến cáo. Đôi khi một kh uyến cáo mạnh có thể dựa trên mức độ bằng 
chứng  thấp hoặc rất thấp. Trong các trường hợp này, các nghiên cứu sâu hơn có thể 
cung cấp những thông tin quan trọng làm thay đổi khuyến cáo.  syt_bacgiang_vt_Van thu SYT Bac Giang_23/10/2023 11:45:0711 
 
Khuyến cáo có điều kiện  
- Với bệnh nhân: phần lớn bệnh nhân trong tình hu ống này sẽ muốn nhận được các 
hành động được khuyến cáo thực hiện, nhưng nhiều bệnh nhân có thể không muốn. 
Quy trình đưa ra quyết định có thể hữu ích để giúp bệnh nhân ra quyết định dựa 
trên yếu tố nguy cơ cá nhân, các giá trị và mong muốn của họ.  
- Với bá c sĩ lâm sàng: các lựa chọn khác nhau có thể thích hợp cho từng cá thể, và 
bác sĩ lâm sàng phải giúp mỗi bệnh nhân đi đến quyết định phù hợp với các giá trị 
và mong muốn của bệnh nhân. Quá trình hỗ trợ ra quyết định có thể hữu ích trong 
việc giúp bệnh nhân  đưa ra lựa chọn phù hợp với nguy cơ, giá trị và mong muốn cá 
nhân của họ.  
- Người hoạch định chính sách : các nhà hoạch định chính sách cần thêm các cuộc 
tranh luận và sự tham gia của nhiều bên. Đo lường hiệu quả của các hành động 
được đề nghị nên tập trung xem liệu một quy trình đưa ra quyết định có được ghi 
chép hợp lệ.  
- Với nhà nghiên cứu : khuyến cáo này cần được làm mạnh hơn (để cập nhật trong 
tương lai hoặc sửa đổi) bởi các nghiên cứu bổ sung. Việc đánh giá các điều kiện và 
tiêu chí (và các phán đoán liên  quan, bằng chứng nghiên cứu và các cân nhắc khác) 
khiến khuyến nghị được đưa ra ở mức có điều kiện (chứ không phải mạnh), sẽ giúp 
xác định các khoảng trống nghiên cứu có thể còn tồn tại.  
 
 
 syt_bacgiang_vt_Van thu SYT Bac Giang_23/10/2023 11:45:0712 
 
CHƯƠNG 1. ĐẠI CƯƠNG  
1. Định nghĩa   
Huyết khối tĩnh mạch sâu ( HKTMS ) chi dưới và thuyên tắc động mạch phổi được coi 
là hai biểu hiện cấp tính có chung một quá trình bệnh lý, gọi là thuyên tắc huyết khối 
tĩnh mạch ( TTHKTM ). Có nhiều thuật ngữ được sử dụng để chỉ thuyên tắc động mạch 
phổi như thuyên tắc phổi, tắc động mạch p hổi, nhồi máu phổi. Tuy nhiên, để thống 
nhất chúng tôi sử dụng thuật ngữ tắc  động mạch phổi hoặc thuyên tắc phổi , viết tắt là 
TTP xuyên suốt trong phác đồ.  
HKTMS là sự hình thành cục máu đông trong các tĩnh mạch sâu của hệ tuần hoàn, 
thường gặp nhất là tĩn h mạch chi dưới, gây tắc nghẽn hoàn toàn hoặc một phần dòng 
máu trong lòng tĩnh mạch. HKTMS chi dưới đoạn gần là thuật ngữ để chỉ vị trí của 
huyết khối nằm từ tĩnh mạch khoeo trở lên, lan đến các tĩnh mạch sâu tầng đùi, chậu, 
hay tĩnh mạch chủ dưới. Khi hu yết khối này bứt ra khỏi lòng mạch, sẽ di chuyển theo 
dòng máu về tim phải lên động mạch phổi, dẫn đến bệnh cảnh tắc động mạch phổi.  
TTP là sự tắc nghẽn cấp tính động mạch phổi và/hoặc các nhánh của nó, do cục máu 
đông (có  thể là khí, mỡ, tắc mạch ối  nhưng  hiếm hơn ) di chuyển từ hệ thống tĩnh mạch 
(HKTMS), hoặc hình thành tại chỗ trong động mạch phổi. Nhồi máu phổi (chiếm 
khoảng 30% các trường hợp TTP) xảy ra khi huyết khối nhỏ làm tắc các nhánh động 
mạch phổi phía xa, dẫn đến tình trạng thiếu máu cục bộ, c hảy xuất huyết nang và hoại 
tử nhu mô phổi.  
2. Dịch tễ học  
Tại các nước phát triển, TTHKTM đứng thứ 3 trong số các nguyên nhân tử vong tim 
mạch. Mỗi năm tại Hoa Kỳ có khoảng 900.000 trường hợp bị thuyên tắc HKTM, gây 
ra 60.000 đến 300.000 ca tử vong hàng năm.  Theo các nghiên cứu dịch tễ, tỷ lệ mới 
mắc TTHKTM hàng năm xấp xỉ 100/100.000 dân tại Châu Âu và Bắc Mỹ, thấp hơn ở 
Châu Á (16/100.000 tại Đài Loan, 17/100.000 tại Hồng  Kông, 57/100.000 tại 
Singapore), nhưng có xu hướng tăng lên. Nguy cơ TTHKTM ở bệnh nhâ n nằm viện 
mà không được phòng ngừa dao động từ 10 -80%. Theo nghiên cứu INCIMEDI tại 
Việt Nam, tỷ lệ TTHKTM không triệu chứng ở bệnh nhân nội khoa nằm viện là 22%. 
9,9% bệnh nhân sau phẫu thuật ung thư phụ khoa (Diệp Bảo Tuấn và cs), 39% bệnh 
nhân sau phẫu  thuật khớp háng bị TTHKTM (Nguyễn Văn Trí và cs). Tỷ lệ này cao 
hơn ở bệnh nhân suy tim mạn tính điều trị nội trú (42,6%) hoặc bệnh nhân tại khoa hồi 
sức tích cực (46%), theo báo cáo của Huỳnh Văn Ân và cs.  
3. Sinh lý bệnh  
Cơ chế hình thành TTHKTM là do sự phối hợp của 3 yếu tố (gọi là tam giác 
Virchow): ứ trệ tuần hoàn tĩnh mạch, rối loạn quá trình đông máu gây tăng đông, và 
tổn thương thành mạch.  
Ứ máu tĩnh mạch : tuần hoàn tĩnh mạch kém và ứ trệ thúc đẩy sự hình thành huyết 
khối. Các yếu tố làm tăng nguy c ơ bị ứ máu tĩnh mạch là tình trạng bất động, gây mê 
toàn thân, liệt, tổn thương tủy sống, tuổi trên 40, các bệnh nội khoa cấp tính như 
NMCT, đột quỵ, suy tim sung huyết, đợt tiến triển của bệnh phổi tắc nghẽn mạn tính…  
Tăng đông máu : một số tình trạng bệnh  lý (cả di truyền và mắc phải) làm tăng nguy 
cơ TTHKTM do tăng đông máu, như ung thư, nồng độ estrogen cao (béo phì, mang 
thai, điều trị hormone), viêm ruột, hội chứng thận hư, nhiễm khuẩn hu yết, và tăng syt_bacgiang_vt_Van thu SYT Bac Giang_23/10/2023 11:45:0713 
 
đông máu do di t ruyền  (đột biến gen prothrombin, thi ếu hụt protein C, S, thiếu anti -
thrombin III, hội chứng kháng phospholipid).  
Tổn thương thành mạch : tổn thương tế bào nội mô thúc đẩy sự hình thành huyết 
khối, thường bắt đầu ở các van tĩnh mạch. Tổn thương thành mạch có thể xảy ra sau 
một số nguyên nhân g ồm chấn thương, tiền sử HKTM, phẫu thuật, lấy tĩnh mạch hiển 
và đặt ống thông tĩnh mạch trung tâm…  
4. Yếu tố nguy cơ  
Nguyên nhân gây ra TTHKTM thường được chia làm hai nhóm: di truyền và mắc phải 
(Bảng 1). Tuy nhiên, TTHKTM có thể là hậu quả của nhiều yếu tố,  gọi là các yếu tố 
thúc đẩy, góp phần làm tăng nguy cơ hình thành cục máu đông dẫn đến TTHKTM. 
Nguy cơ tái phát TTHKTM  phụ thuộc một phần vào sự tham gia của các yếu tố thúc 
đẩy tại thời điểm bị TTHKTM lần đầu. Các yếu tố thúc đẩy tạm thời là những yếu tố 
sớm được giải quyết sau khi gây ra tình trạng huyết khối, như mới phẫu thuật, mổ lấy 
thai, bệnh cấp tính phải nằm tại giường bệnh trên 3 ngày…Yếu tố thúc đẩy dai dẳng là 
những YTNC tồn tại kéo dài, như ung thư tiến triển, tái phát, hoặc đang trong liệu 
trình điều trị. Cũng có thể là bệnh lý không ung thư, nhưng làm tăng nguy cơ tái phát 
TTHKTM ít nhất 2 lần sau khi dừng điều trị kháng đông như viêm ruột. TTHKTM 
không rõ yếu tố thúc đẩy nếu không xác định được rõ ràng các YTNC nói trên.  
Bảng 1: Các YTNC chí nh của TTHKTM  
 
Mắc phải  
(YTNC thúc đẩy)  Di truyền  
(Tăng đông bẩm sinh)  
- Mới phẫu thuật, đặc biệt là phẫu thuật chỉnh 
hình 
- Chấn thương: cột sống, tủy sống, chi dưới  
- Bất động: suy tim, đột quỵ…  
- Ung thư  
- Có thai  
- Điều trị Hormone thay thế, hoặc thuốc tránh 
thai chứa Oestrogen  
- Hội chứng thận hư  
- Hội chứng kháng Phospholipid  
- Bệnh lý viêm ruột  
- Tiền sử HKTM  - Thiếu hụt Protein C  
- Thiếu hụt Protein S  
- Thiếu hụt Antithrombin III  
- Đột biến yếu tố V Leyden  
- Đột biến gen Prothrombin 
G20210A 
 
5. Tầm quan trọng của dự phòng TTHKTM  
Nghiên cứu ENDORSE là một nghiên cứu cắt ngang đánh giá mức độ phổ biến của 
nguy cơ TTHKTM trên 68.183 bệnh nhân cấp tính điều trị tại 358 trung tâm của 32 
quốc gia, đã chỉ ra 64% bệnh nhân ngoại khoa và 42% bệnh nhân nội khoa có nguy cơ 
bị TTHKTM. Mặc dù  TTHKTM thường được coi là một biến chứng sau phẫu thuật, tử 
vong do TTP cấp ở bệnh nhân nội khoa cao gấp đôi so với bệnh nhân ngoại khoa. 
Triệu chứng lâm sàng không đặc hiệu, dễ chồng lấp nên khó phát hiện sớm TTHKTM 
ở bệnh nhân nhập viện . Gánh nặng điều trị kháng đông khi bị thuyên tắc huyết khối, 
chi phí điều trị cao hơn nhiều lần chi phí dự phòng (thống kê tại Châu Âu cho thấy để 
điều trị một trường hợp TTHKTM cần 1348,68 euro, so với 373,03  Euro để dự 
phòng), là những nguyên nhân chính yêu cầu phải có một chiến lược dự phòng 
TTHKTM đúng đắn cho mọi trường hợp bệnh nhân điều trị tại bệnh viện.  syt_bacgiang_vt_Van thu SYT Bac Giang_23/10/2023 11:45:0714 
 
CHƯƠNG  2. CHIẾN LƯỢC  ĐIỀU TRỊ  DỰ PHÒNG  TTHKTM  CHUNG  
 
1. Quy trình chung điều trị dự phòng TTHKTM trên bệnh nhân:  
 
Bảng 2: Quy trình chung điều trị dự phòng TTHKTM t rên b ệnh nhân  
 
Bước 1  Đánh giá nguy cơ thuyên tắc HKTM của các bệnh nhân nhập viện dựa vào 
các YTNC nền, và tình trạng bệnh lý của bệnh nhân  
Bước 2  Đánh giá nguy cơ xuất huyết, chống chỉ định của thuốc kháng đông  
Bước 3  Tổng hợp các nguy cơ, cân nhắc lợi  ích của việc dự phòng và nguy cơ 
xuất huyết khi phải dùng kháng đông, đặc biệt chú ý tới chức năng thận, 
bệnh nhân cao tuổi  
Bước 4  Lựa chọn biện pháp dự phòng, và thời gian dự phòng phù hợp  
 
Bảng 3: T ổng hợp các bi ện pháp d ự phòng TTHKTM và các bư ớc thực hiện 
 
Bước 1  Đánh giá nguy cơ TTHKTM của các bệnh nhân nhập viện dựa vào 
các YTNC nền, và tình trạng bệnh lý của bệnh nhân  
- Thang điểm Padua cho nhóm bệnh nhân nội khoa cấp tính, hồi sức tích 
cực nội khoa  
- Thang điểm Caprini cho nhóm bệnh nhân ngoại khoa c hung, chấn 
thương chỉnh hình, ngoại sản  
  Bước 2  Đánh giá nguy cơ xuất huyết, chống chỉ định của điều trị kháng 
đông:  
- Thang đi ểm đánh giá nguy cơ xu ất huyết IMPROVE cho b ệnh nhân 
Nội khoa  
- Hoặc bệnh nền và tình trạng bệnh lý nguy cơ xuất huyết cho  nhóm 
bệnh nhân ngoại khoa chung, chấn thương, ngoại sản  khoa  
- Xem x ét bảng chống chỉ đinh, th ận trọng khi s ử dụng thu ốc kháng 
đông:  
Bảng Chống chỉ định, thận trọng khi điều trị thuốc kháng đông  
Chống chỉ định tuyệt đối  Chống chỉ định tương đối  
(thận trọng)  
- Suy gan n ặng 
- Xuất huy ết não 
- Tình trạng xuất huy ết đang ti ến triển 
(ví dụ: xu ất huyết do lo ét dạ dày tá 
tràng) - Suy thận nặng (ClCr ≤ 30 
ml/phút)  
- Chọc dò tuỷ sống  
- Đang d ùng các thuốc chống 
ngưng tập tiểu cầu (aspirin, 
clopidogrel…)  syt_bacgiang_vt_Van thu SYT Bac Giang_23/10/2023 11:45:0715 
 
- Tiền sử xuất huy ết giảm tiểu cầu 
nhất là hạ tiểu cầu do heparin (HIT,  
heparin -induced thrombocytopenia)  
- Dị ứng thu ốc kháng đông  
- Rối loạn đông m áu bẩm sinh hay 
mắc phải - Số lượng tiều cầu <100.000 /µl 
- Tăng huy ết áp nặng ch ưa 
được kiểm soát (HA tâm th u > 
180 mmHg, và / hoặc HA tâm 
trương > 110 mmHg)  
- Mới ph ẫu thuật sọ não, ph ẫu 
thuật tuỷ sống hay c ó xuất 
huyết nội nhãn cầu 
- Phụ nữ ở giai đoạn chuẩn bị 
chuyển dạ, với nguy cơ xuất 
huyết cao (rau tiền đạo…)  
Không dùng thuốc kháng đông khi c ó 1 
trong c ác yếu tố nêu trên. Nên l ựa chọn 
phương ph áp dự phòng cơ h ọc Trì hoãn sử dụng thuốc 
kháng đông cho đ ến khi nguy 
cơ xu ất huyết đã giảm 
Bước 3  Tổng hợp các nguy cơ, cân nhắc lợi ích của việc dự ph òng và nguy cơ 
xuất huyết khi dùng thuốc kháng đông, đặc biệt chú ý chức năng thận, 
người cao tuổi để lựa chọn.  
Bước 4  Khuy ến cáo biện pháp d ự phòng TTHKTM và thời gian dự phòng phù 
hợp. 
 
Bảng 4: T ổng hợp các bi ện pháp d ự phòng TTHKTM và ch ỉ định 
 
Biện pháp  BN nội khoa  BN ngoại khoa 
chung  BN chấn thương  
chỉnh hình  
Biện pháp chung  BN được khuyến khích ra khỏi giường bệnh vận động sớm và 
thường xuyên  
Biện pháp cơ học  
(Thiết  bị bơm hơi 
áp lực ngắt quãng.  
Tất / Băng chun 
áp lực y khoa (áp 
lực 16 – 20 
mmHg) Được sử dụng khi bệnh nhân chống chỉ định tuyệt đối với thuốc 
kháng đông.  
Đối với bệnh nhân chống chỉ định tương đối với thuốc kháng 
đông thì đến khi nguy cơ xuất huyết giảm, nên chuyển sang biện 
pháp dược lý.  
 
Heparin  
TLPTT  Enoxaparin 40 mg x 
1 lần/n gày TDD, 
hoặc  
Enoxaparin 30 mg x 
1 lần/ngày TDD với 
BN suy thận 
(MLCT ≤ 30 
ml/phút)  Enoxaparin 40 
mg x 1 lần/ngày 
TDD, hoặc   
Enoxaparin 30 
mg x 1 lần/ngày 
TDD với BN 
suy thận (MLCT 
≤ 30 ml/phút)  Enoxaparin 40 mg x 1 
lần/ngày TDD, hoặc  
Enoxaparin 30 mg x 2  
lần/ngày TDD, hoặc  
Enoxaparin 30 mg x 1 
lần/ngày TDD với BN 
suy thận (MLCT ≤ 30 
ml/phút)  syt_bacgiang_vt_Van thu SYT Bac Giang_23/10/2023 11:45:0716 
 
Biện pháp  BN nội khoa  BN ngoại khoa 
chung  BN chấn thương  
chỉnh hình  
Fondaparinux  Liều 2,5 mg x 1 lần/ngày TDD, hoặc  
Liều 1,5 mg x 1 lần/ngày TDD với BN suy thận (MLCT 30 – 50 
ml/phút)  
* Được dùng thay thế Heparin TLPTT hoặc Heparin không 
phân đoạn  khi bệnh nhân bị HIT.  
Heparin  không 
phân đoạn  Liều 5000 UI x 2 lần/ngày TDD  
* Chỉ định với suy thận nặng (MLCT < 30 ml/phút)  
Kháng  
vitamin K  Không  Không  Liều hiệu chỉnh sao cho 
INR từ 2 – 3 
* Không được khuyến 
cáo nếu cần đạt hiệu quả 
dự phòng sớm, trong 
thời gian ngắn  
Rivaroxaban  Không   Không  10 mg x 1 lần/ngày  
Dabigatran  Không  Không  110 mg x 1 lần trong 
ngày đầu, sau đó 110 
mg x 2 viên uống 1 
lần/ngày  
Apixaban  Không  Không  Ban đầu: Cho 2,5 mg 
12-24 giờ sau phẫu 
thuật . 
Thay khớp háng:  2,5 mg 
2 lần/ngày trong 3 2-38 
ngày  
Thay khớp gối: 2,5 mg 
2 lần/ngày trong 1 0-14 
ngày  
      
2. Lưu ý điều chỉnh liều khi dự phòng TTHKTM trên nhóm bệnh nhân đặc biệt:  
Bệnh nhân suy thận  
Các bảng sau đây cho thấy các khuyến cáo về điều trị dự phòng dược lý  ở bệnh nhân 
suy thận. Cần quan sát lâm sàng cẩn thận. Đối với bệnh nhân suy thận cấp, bệnh thận 
giai đoạn cuối, phụ thuộc lọc máu* hoặc các tình trạng eGFR có thể không chính xác, 
sử dụng UFH; không sử dụng Heparin TLPPT cho những bệnh nhân này. Đối với b ệnh 
nhân béo phì bị suy thận, nên dựa vào chỉ định của bác sĩ chuyên khoa.  
Bệnh nhân chạy thận nhân tạo nội viện nên được đánh giá về nguy cơ TTHKTM và 
cần dự   phòng TTHKTM   như tất cả các bệnh nhân nội viện khác, bất kể việc sử dụng 
thuốc kháng đông tro ng hệ lọc ngoài cơ thể trong những ngày chạy thận nhân tạo.  syt_bacgiang_vt_Van thu SYT Bac Giang_23/10/2023 11:45:0717 
 
 
Bảng 5: Đi ều chỉnh liều Heparin trong d ự phòng TTHKTM cho b ệnh nhân suy th ận 
 
Chức năng thận 
(mL/phút) * Heparin không phân đoạn  Heparin TLPTT  
30 – 50 Không cần điều chỉnh  Không cần điều chỉnh  
15 – 29 Không cần điều chỉnh  Enoxaparin: Giảm liều 
xuống 30 mg mỗi ngày  
Dưới 15  Không cần điều chỉnh  KHÔNG sử dụng  
*Tài liệu tham khảo sử dụng CrCl (mL/phút) làm chỉ số cho chức năng thận, tuy nhiên 
chức năng thận cũng có thể được ước tính trong tình huố ng này bằng eGFR (mL/phút 
/ 1,73m2). Nên có khuyến cáo cho bệnh nhân có trọng lượng quá cao.  
 
Bảng 6: Điều chỉnh liều kháng đông đường uống dự phòng TTHKTM trên bệnh nhân 
thay khớp háng, khớp gối bị suy thậ n 
 
Chức năng 
thận* 
(mL/phút)  Rivaroxaban  Dabigatra n Apixaban  
30-50 10mg hàng ngày  Chỉnh liều xuống 
150mg hàng ngày  2,5mg 2 lần/ngày  
25-29 10mg hàng ngày  
(thận trọng khi 
dùng)  Chống chỉ định  2,5mg 2 lần/ngày  
(thận trọng khi dùng)  
15-24 10mg hàng ngày  
(thận trọng khi 
dùng)  Chống chỉ định  Chống chỉ định  
Dưới 15  Chống chỉ định  Chống chỉ định  Chống chỉ định  
Lọc máu  Chống chỉ định  Chống chỉ định  Chống chỉ định  
*Tài liệu tham khảo sử dụng CrCl (mL/phút) làm chỉ số cho chức năng thận, tuy nhiên 
chức năng thận cũng có thể được ước tính trong tình huống này bằ ng eGFR 
(mL/phút/1,73m2). Nên có khuyến cáo cho bệnh nhân có trọng lượng quá cao.  
Bệnh nhân có nguy cơ xuất huyết cao  
Bệnh nhân có nguy cơ xuất huyết cao gồm những người bị bệnh nặng, đã được thực 
hiện các thủ thuật, phẫu thuật có nguy cơ xuất huyết cao ho ặc có các tình trạng khác 
liên quan đến nguy cơ xuất huyết cao (xem Bảng 3. Chống chỉ định, thận trọng khi 
điều trị thuốc kháng đông trong bước 2 ). Bệnh nhân cần được theo dõi chặt chẽ các 
dấu hiệu biến chứng xuất huyết và điều chỉnh liều thuốc kháng đông nên được thực 
hiện theo quyết định của bác sĩ điều trị . 
 syt_bacgiang_vt_Van thu SYT Bac Giang_23/10/2023 11:45:0718 
 
 
Dự phòng bằng Heparin chuẩn có thể được coi là một lựa chọn thay vì Heparin 
TLPTT cho bệnh nhân có nguy cơ xuất huyết cao. Rivaroxaban chống chỉ định bởi nhà 
sản xuất trên bệnh nhân có nguy cơ xuất huyết cao. Cần thận trọng khi sử dụng các 
thuốc kháng đông khác. Tham khảo thông tin sản phẩm để được hướng dẫn thêm.  
Bệnh nhân thiếu cân (trọng lượng cơ thể < 50 kg)  
Bằng chứng cho việc sử dụng Heparin TLPTT trong các trường hợp cân nặng dưới 
tiêu chuẩn c òn hạn chế và cần phải theo dõi lâm sàng cẩn thận. Tham khảo các khuyến 
cáo của chuyên gia về việc sử dụng và theo dõi liều điều chỉnh Heparin TLPTT.  
Bệnh nhân thừa cân, béo phì (BMI > 30 kg/m2) 
Bệnh nhân có chỉ số cơ thể (BMI) ≥ 30 kg/m2 có nguy cơ mắc TT HKTM và có thể 
không tuân theo mối quan hệ liều đáp ứng có thể dự đoán được. Heparin TLPTT ở liều 
dự phòng tiêu chuẩn dường như không đủ ở bệnh nhân có BMI ≥ 40 Kg/m2.  
Đối với bệnh nhân béo phì bị suy thận, nên theo lời khuyên của bác sĩ chuyên khoa.  
 Bảng 7: Khuyến cáo điều chỉnh liều Heparin TLPTT ở bệnh nhân béo phì  
 
BMI (kg/m2) Nguycơ TTHKTM  Liều khuyến cáo  
30 - 40 Thấp / Trung bình  Sử dụng liều chuẩn Heparin TLPTT dự 
phòng TTHKTM  
Cao Cân nhắc điều chỉnh liều Heparin 
TLPTT:  
Enoxaparin: 40mg TDD hai lần/ ngày, 
hoặc  
Giảm 0,5mg / kg mỗi ngày/ lần  40 - 60 Thấp/ Trung bình/ 
Cao 
Trên 60  Thấp/ Trung bình/ 
Cao Hỏi ý kiến chuyên gia  
Nguồn: Các khuyến cáo về liều cho enoxaparin được điều chỉn h từ một số tài liệu 
tham khảo10,11 của Nhóm công tác dự phòng TTHKTM toàn tiểu bang Queensland 
2018.  
  BMI (kg/m2) Nguycơ TTHKTM  Liều khuyến cáo  
30 - 40 Thấp / Trung bình  Sử dụng liều chuẩn Heparin TLPTT dự 
phòng TTHKTM  
Cao Cân nhắc điều chỉnh liều Heparin TLPTT:  
Enoxaparin: 40mg TDD hai lần/ ngày, 
hoặc  
Giảm 0,5mg / kg mỗi ngày/ lần  40 - 60 Thấp/ Trung bình / 
Cao 
Trên 60  Thấp/ Trung bình/ 
Cao Hỏi ý kiến chuyên gia  
syt_bacgiang_vt_Van thu SYT Bac Giang_23/10/2023 11:45:0719 
 
CHƯƠNG 3 . DỰ PHÒNG TTHKTM Ở BỆNH NHÂN N ỘI KHOA  
 
Tất cả bệnh nhân n ội khoa đi ều trị nội trú c ần được đánh giá nguy cơ TTHKTM d ựa 
vào tình tr ạng bệnh lý  của họ, và các y ếu tố nguy cơ TTHKTM ph ối hợp. Bệnh nhân 
nội khoa c ấp tính là nh ững bệnh nhân n ằm viện vì các v ấn đề cấp tính, không liên quan 
đến phẫu thu ật, gồm bệnh nội khoa c ấp (suy tim, suy hô h ấp, đột quỵ, nhiễm khu ẩn, 
bệnh kh ớp…), ung thư ti ến triển, đang đi ều trị hoặc tái phát.  
Bảng đánh giá nguy cơ d ựa trên thang đi ểm dự báo PADUA (Padua Prediction 
Score - PPS) khuy ến cáo đư ợc sử dụng để đánh giá nguy cơ TTHKTM c ủa bệnh nhân 
là thấp hay cao . 
Với bệnh nhân có ch ỉ định dự phòng b ằng thu ốc kháng đông,  cần xem xét các ch ống 
chỉ định v ới thu ốc kháng đông, và đánh giá nguy cơ xu ất huy ết bằng thang đi ểm 
IMPROVE, đ ể đánh giá cân b ằng lợi ích/nguy cơ đ ạt được trư ớc khi l ựa chọn biện 
pháp d ự phòng phù h ợp. 
 
Bảng 8: Thang đi ểm PADUA đánh giá nguy cơ TTHKTM ở bệnh nhân n ội khoa  
 
Yếu tô nguy cơ  Điểm 
Ung thư ti ến triển 3 
Tiền sử thuyên t ắc HKTM (lo ại trừ HKTM nông)  3 
Bất động (do h ạn chế của chính b ệnh nhân ho ặc do ch ỉ định của bác sĩ)  3 
Tình tr ạng bệnh lý tăng đông đã bi ết 3 
Mới bị chấn thương và/ho ặc phẫu thuật (≤ 1 tháng)  2 
Tuổi cao (≥ 70 tu ổi) 1 
Suy tim và/ho ặc suy hô h ấp 1 
Nhồi máu cơ tim  cấp hoặc nhồi máu não c ấp 1 
Nhiễm khu ẩn cấp và/ho ặc bệnh cơ xương kh ớp do th ấp 1 
Béo phì (BMI ≥ 30)  1 
Đang đi ều trị hormone  1 
PPS < 4: Nguy cơ th ấp bị thuyên t ắc HKTM: không c ần điều trị dự phòng  
PPS ≥ 4: Nguy cơ cao b ị thuyên t ắc HKTM: c ần điều trị dự phòng  
 
 
 
 
 syt_bacgiang_vt_Van thu SYT Bac Giang_23/10/2023 11:45:0720 
 
Bảng 9: Thang đi ểm IMPROVE đánh giá nguy cơ xu ất huy ết ở bệnh nhân n ội khoa  
YTNC  Điểm 
Loét d ạ dày tá tràng ti ến triển 4,5 
Xuất huy ết trong vòng 3 thá ng trư ớc nhập viện 4 
Số lượng tiểu cầu < 50 x 109/l 4 
Tuổi ≥ 85  3,5 
Suy gan (INR > 1,5)  2,5 
Suy th ận nặng (MLCT < 30 ml/phút/1,73m2) 2,5 
Đang n ằm điều trị tại khoa h ồi sức tích c ực. 2,5 
Catheter tĩnh m ạch trung tâm  2 
Bệnh th ấp khớp 2 
Đang b ị ung t hư 2 
Tuổi 40 – 84 1,5 
Giới nam  1 
Suy th ận trung bình (MLCT 30 -59 ml/phút/1,73m2) 1 
Tổng đi ểm ≥ 7: Nguy cơ xu ất huy ết nặng, ho ặc xuất huy ết có ý nghĩa lâm sàng  
1. Dự phòng TTHKTM ở bệnh nhân nội khoa  
Bệnh nhân n ội khoa c ấp tính có nhi ều YTNC d ẫn đến TT HKTM. Nguy cơ TTHKTM 
vẫn có th ể tồn tại sau khi b ệnh nhân đã ra vi ện. M ột số báo cáo d ựa vào k ết quả giải 
phẫu tử thi đã ch ỉ ra TTP là nguyên nhân t ử vong c ủa 1/3 b ệnh nhân n ội khoa c ấp 
trong th ời gian n ằm viện, và 45% bi ến cố TTHKTM trong vòng 3 tháng k ể từ khi b ệnh 
nhân ra vi ện.  
Bảng 10: Khuy ến cáo d ự phòng TTHKTM ở bệnh nhân n ội khoa theo hư ớng dẫn 
VNHA 2016  
Khuyến cáo  Nhóm  Mức 
chứng cứ  
 BN nội khoa điều trị nội trú có nguy cơ cao thuyên tắc 
HKTM được khuyến cáo dự phòng bằng Heparin TLPTT, 
Heparin khôn g phân đoạn hoặc Fondaparinux (*)   
I  
B 
 BN nội khoa điều trị nội trú có nguy cơ cao thuyên tắc 
HKTM nhưng nguy cơ chảy máu cao, nên được dự phòng 
bằng bơm hơi áp lực ngắt quãng hoặc tất chun áp lực.   
IIa  
C 
(*) Thời gian đi ều trị dự phòng: khuy ến cáo k éo dài th ời gian d ự phòng t ới khi b ệnh 
nhân ra vi ện, ho ặc có th ể đi lại được. Với một số đối tượng ch ọn lọc (BN cai th ở máy, 
BN b ất động đang trong giai đo ạn phục hồi chức năng), có th ể kéo dài th ời gian d ự 
phòng t ới 10 ± 4 ngày  syt_bacgiang_vt_Van thu SYT Bac Giang_23/10/2023 11:45:0721 
 
Bảng 11: Hư ớng dẫn các bư ớc dự phòng TTHKTM ở bệnh nhân n ội khoa  
 
Tất cả bệnh nhân n ội khoa c ấp tính nh ập viện 
KHÔNG c ần dự phòng n ếu bệnh nhân đang dùng thu ốc kháng đông  
Đánh giá nguy cơ TTHKTM, nguy cơ xu ất huy ết, ch ống ch ỉ định v ới thu ốc 
kháng đông:  
- Trong vòng 24 giờ kể từ khi vào viện  
- Sau mỗi 48 – 72 giờ, hoặc khi có thay đổi tình trạng lâm sàng; mục tiêu 
điều trị  
Nguy cơ 
TTHKTM  THẤP 
(PADUA < 4)  CAO  
(PADUA ≥ 4)  
Biện pháp 
dự phòng  - Không c ần d ự 
phòng  
- Khuy ến khích v ận 
động s ớm, đ ảm 
bảo không thi ếu 
dịch 
 Nguy cơ xu ất huy ết 
CAO  
(IMPROVE ≥ 7) Nguy cơ xu ất 
huyết THẤP 
(IMPROVE < 7) 
Khởi động IPC ngay t ừ 
khi vào vi ện 
Khi nguy cơ xu ất huy ết 
giảm, trong khi nguy 
cơ TTHKTM còn cao: 
chuy ển từ IPC sang các 
biện pháp dư ợc lý Enoxaparin 40 mg 
x 1 l ần/ngày TDD 
bụng 
 
Thời gian 
dự phòng  Khôn g áp d ụng Duy trì đ ến khi kh ả năng v ận động tr ở lại 
mức mong đ ợi hoặc ch ấp nh ận đư ợc trên 
lâm sàng, ho ặc khi b ệnh nhân ra vi ện. 
Chú ý đi ều chỉnh các bi ện pháp d ự phòng dư ợc lý v ới nhóm b ệnh nhân đ ặc biệt: 
- MLCT (CrCl) < 30 ml/p; hoặc eGFR < 30/ml/p/1,73m2  
- Cân nặng dưới 50 kg hoặc BMI ≥ 30 kg/ m2      
 
2. Dự phòng TTHKTM cho bệnh  nhân  nội khoa cấp tính tại  khoa  hồi sức tích cực 
(ICU)  
Tại Việt Nam, tỷ lệ HKTMS chi dưới ở bệnh nhân nằm tại khoa Hồi sức  tích cực  
(không phân biệt nội ngoại) bệnh viện Chợ R ẫy là 12,5%, tỷ lệ HKTMS chi dưới là 
46% bệnh nhân sau 1 tuần nằm viện tại khoa ICU Nội bệnh viện Nhân dân Gia 
Định.Tỉ lệ HKTMS chi dưới ở bệnh nhân suy tim mạn tính mức độ NYHA III/IV là 
42,6%. Bệnh nhân suy tim NYHA IV có tỉ lệ HKTMS cao hơn (NYHA III: 3 1,3%, 
NYHA IV: 70%, p=0,0001).  
Theo Hướng dẫn VNHA 2016, bệnh  nhân  điều trị tại khoa Hồi sức tích cực: do có 
nhiều YTNC thuyên tắc HKTM phối hợp nên được dự phòng một cách hệ thống bằng 
Heparin TLPTT hoặc Heparin không phân đoạn, trừ trường hợp nguy cơ ch ảy máu 
cao: dự phòng bằng máy bơm hơi áp lực ngắt quãng (IIC).  syt_bacgiang_vt_Van thu SYT Bac Giang_23/10/2023 11:45:0722 
 
Bệnh nhân nội khoa cấp tính: dự phòng TTHKTM bằng phương pháp dược lý  
Khuyến cáo:  Đối với bệnh nhân nội khoa cấp tính, đề nghị sử dụng dự phòng kháng 
đông toàn thân bằng Heparin hoặc Heparin T LPTT thì tốt hơn là không sử dụng 
(khuyến cáo điều kiện, mức độ bằng chứng thấp). Trong các kháng đông, đề nghị sử 
dụng Heparin TLPTT (mức độ bằng chứng thấp ++) hơn là Heparin chuẩn. Lưu ý: các 
khuyến cáo này cũng áp dụng cho bệnh nhân đột quỵ được dự phò ng TTHKTM.  
Bệnh nhân nội khoa nằm hồi sức tích cực: biện pháp dược lý dự phòng TTHKTM  
Khuyến cáo:   Đối với bệnh nhân nội khoa nằm hồi sức tích cực, khuyến cáo sử dụng 
Heparin, Heparin TLPTT hơn là không sử dụng (khuyến cáo mạnh, mức độ bằng 
chứng trung bìn h +++) và sử dụng Heparin TLPTT hơn là dùng Heparin chuẩn 
(khuyến cáo điều kiện, mức độ bằng chứng trung bình +++).  
Bệnh nhân nội khoa nằm hồi sức tích cực: so sánh các biện pháp dự phòng 
TTHKTM (dược lý, cơ học)  
Khuyến cáo:  Đối với bệnh nhân nội khoa cấp tính hoặc cần hồi sức tích cực, sử dụng 
biện pháp dự phòng TTHKTM bằng phương pháp dược lý hơn là cơ học (khuyến cáo 
điều kiện, mức độ bằng chứng rất thấp +).  
Khuyến cáo:  Đối với bệnh nhân nội khoa cấp tính hoặc cần hồi sức tích cực không dự 
phòng HKTMS bằ ng phương pháp dược lý, đề nghị sử dụng biện pháp cơ học hơn là 
không dự phòng (khuyến cáo điều kiện, mức độ bằng chứng trung bình +++).  
Khuyến cáo:  Đối với bệnh nhân nội khoa cấp tính hoặc cần hồi sức tích cực, đề nghị 
dự phòng HKTMS bằng phương pháp dược  lý hoặc cơ học đơn độc hơn là phối hợp 
hai biện pháp này (khuyến cáo điều kiện, mức độ bằng chứng rất thấp +).  
Khuyến cáo:   Đối với bệnh nhân nội khoa cấp tính hoặc cần hồi sức tích cực dự phòng 
HKTMS bằng phương pháp cơ học, đề nghị sử dụng máy bơm áp lự c ngắt quãng hoặc 
tất áp lực y khoa (khuyến cáo điều kiện, mức độ bằng chứng rất thấp +).  
Kháng đông đường uống so với Heparin TLPTT đối với bệnh nhân nội khoa cấp tính  
Khuyến cáo :  Đối với bệnh nhân nội khoa cấp tính nằm viện, khuyến cáo sử dụng 
Heparin T LPTT hơn là kháng đông đường uống để dự phòng TTHKTM (khuyến cáo 
mạnh, mức độ bằng chứng trung bình +++).  
Khuyến cáo:   Đối với bệnh nhân nội khoa cấp tính nằm viện, khuyến cáo dự phòng 
HKTMS bằng Heparin TLPTT trong thời gian nằm viện hơn là dự phòng kéo d ài thêm 
khi xuất viện với kháng đông đường uống (khuyến cáo mạnh, mức độ bằng chứng 
trung bình +++). Dự phòng TTHKTM ở bệnh nhân ung thư nằm viện . 
3. Dự phòng TTHKTM ở bệnh nhân đột quỵ:  
 syt_bacgiang_vt_Van thu SYT Bac Giang_23/10/2023 11:45:0723 
 
Bảng 12: Hư ớng dẫn các bư ớc dự phòng TTHKTM ở bệnh nhân Đ ột quỵ cấp 
Nguy cơ TTHKTM ở bệnh nhân đ ột quỵ liên quan ch ủ yếu đến tình tr ạng bất động kéo 
dài do li ệt. Tỷ lệ HKTM sâu chi dư ới có tri ệu chứng ở BN đ ột quỵ cấp dao đ ộng từ 1 – 
10%, nhưng th ực tế tỷ lệ HKTM không tri ệu chứng còn cao hơn (11% sau 10 ngày, 
15% sau 30 ngày). Nguy cơ TTHKTM ở BN đ ột quỵ xảy ra s ớm, ngay t ừ ngày th ứ 2 
của bệnh, và  cao nh ất ở thời điểm 2 – 7 ngày. T ử vong do TTP c ấp chi ếm 13 – 29% 
nguyên nhân t ử vong ở bệnh nhân đ ột quỵ cấp.  Tất cả bệnh nhân đ ột quỵ cấp 
KHÔNG c ần điều trị dự phòng n ếu bệnh nhân đang dùng thu ốc kháng đông  
Đánh giá nguy cơ TTHKTM, nguy cơ xu ất huy ết, ch ống ch ỉ định v ới thu ốc kháng 
đông:  
- Ngay khi vào viện  
- Sau 24 giờ, hoặc ngay khi có thay đổi tình trạng lâm sà ng; mục tiêu điều trị  
Nguy 
cơ 
TTHK
TM THẤP 
(PADUA < 4)  CAO  
(PADUA ≥ 4)  
Biện 
pháp  
dự 
phòng  - Không c ần 
dự phòng  
-Khuy ến 
khích v ận 
động sớm, 
đảm bảo đủ 
dịch 
 Đột quỵ 
XUẤT HUY ẾT Đột quỵ 
TẮC MẠCH 
Khởi động IPC 
ngay t ừ khi vào 
viện 
Khi nguy cơ xu ất 
huyết giảm, trong 
khi nguy cơ 
TTHKTM còn 
cao: chuy ển từ 
IPC sang các 
biện pháp dư ợc 
lý Khởi động IPC ngay t ừ khi vào vi ện 
Cân nh ắc thời điểm chuy ển sang:  
Enoxaparin 40 mg x 1 l ần/ngày TDD  
Nếu bệnh nhân có ch ỉ định tiêu s ợi 
huyết:  
- Chống ch ỉ định thu ốc kháng đôn g trong 
vòng 24 gi ờ đầu sau tiêu s ợi huy ết 
- Chỉ khởi động dự phòng kháng đông:  
+ Sau khi lo ại trừ nguy cơ xu ất huy ết có 
ý nghĩa trên hình ảnh học điện quang  
+ Theo quy ết định của bác sĩ lâm sàng  
Thời 
gian 
dự 
phòng  Không áp 
dụng Dự phòng cơ h ọc: Tiếp tục IPC trong vòng 30 ngày ho ặc đến 
khi b ệnh nhân v ận động thư ờng xuyên. Không nên s ử dụng 
băng chun hay t ất áp l ực 
Dự phòng dư ợc lý: Duy trì Enoxaparin đ ến khi kh ả năng v ận 
động tr ở lại mức mong đ ợi hoặc chấp nh ận đư ợc trên lâm 
sàng, ho ặc khi b ệnh nhân ra vi ện. 
Chú ý đi ều chỉnh các bi ện pháp d ự phòng dư ợc lý v ới nhóm b ệnh nhân đ ặc biệt: 
- MLCT (CrCl) < 30 ml/p; hoặc eGFR < 30/ml/p/1,73m2  
- Cân nặng dưới 50 kg hoặc BMI ≥ 30 kg/ m2      syt_bacgiang_vt_Van thu SYT Bac Giang_23/10/2023 11:45:0724 
 
Hướng dẫn các bư ớc dự phòng TTHKTM ở bệnh nhân đ ột quỵ cấp 
Theo Hướng dẫn VNHA 2016:  
- Bệnh  nhân  đột quỵ cấp do tắc mạch:  Khuyến cáo dự phòng b ằng máy bơm hơi áp 
lực từng lúc với BN nhập viện trong vòng 72 giờ kể từ khi bắt đầu triệu chứng, và 
có liệt vận động. Xem xét dự phòng bằng thuốc chống đông có thể bắt đầu sớm 
nhất là 48 giờ sau khi bị đột quỵ, và kéo dài trong vòng 2 tuần, hoặc tới khi B N có 
thể vận động (nhưng không quá 6 tuần).  
- Bệnh  nhân  đột quỵ cấp do chảy máu não:  Khuyến cáo dự phòng bằng máy bơm 
hơi áp lực ngắt quãng ngay khi nhập viện. Xem xét dự phòng bằng chống đông 
sớm nhất sau 3 ngày, sau khi đã cân nhắc kỹ nguy cơ chảy máu (dự a vào lâm sàng, 
huyết áp, kích thước vùng chảy máu trên phim chụp sọ não) và nguy cơ tắc mạch 
(tình trạng bất động) đối với từng trường hợp cụ thể.           
4. Dự phòng TTHKTM ở bệnh nhân nội khoa COVID – 19  
COVID – 19 là đ ại dịch toàn c ầu do SARS -CoV -2, một loại coronavirus gây ra nh ững 
triệu chứng và bi ến chứng tr ầm trọng tại đường hô h ấp cũng như các cơ quan khác. 
Bệnh nhân COVID – 19 có nguy cơ b ị TTHKTM và vi huy ết khối, do tình tr ạng thi ếu 
oxy kéo dài, ho ạt hóa quá m ức quá trình viêm, ho ạt hóa ti ểu cầu, rối loạn chức năng 
nội mạc và ứ trệ. Các phân tích t ổng hợp mới nhất chỉ ra tỷ lệ mới mắc TTHKTM ở 
bệnh nhân COVID -19 n ằm vi ện là 17%, trong đó n ếu chỉ dựa vào tri ệu chứng lâm 
sàng s ẽ chỉ phát hi ện đư ợc 9,8% b ệnh nhân TTHKTM, nhưng t ỷ lệ TTHKTM ch ẩn 
đoán qua các bi ện pháp sàng l ọc lên t ới 33%. 27,9% b ệnh nhân COVID – 19 đi ều trị 
tại Khoa h ồi sức tích c ực bị TTHKTM so v ới chỉ 7,1% b ệnh nhân ở phòng đi ều trị 
thường.  
Bệnh nhân COVID -19 đi ều trị tại Khoa h ồi sức tích c ực (ICU/CCU):  là nh ững bệnh 
nhân COVID -19 kèm theo suy hô h ấp hoặc tuần hoàn, c ần đư ợc chăm sóc tích c ực 
trong ICU/CCU (ho ặc một cơ s ở y tế tương đương, đư ợc thiết kế với tính năng dành 
cho ICU/CCU).  
Bệnh nhân COVID -19 đi ều trị tại Khoa đi ều trị thường: là nh ững bệnh nhân nhi ễm 
COVID -19 có tri ệu chứng lâm sàng, như khó th ở, thiếu oxy m ức độ nhẹ hoặc trung 
bình, c ần điều trị tại bệnh vi ện, ho ặc cơ s ở y tế mà không c ần phương ti ện hỗ trợ tích 
cực như trong ICU/CCU.  
Các Hi ệp hội và t ổ chức quốc tế như ISTH (H ội đông c ầm máu qu ốc tế); CHEST 
(Hiệp hội bác sĩ l ồng ng ực Hoa K ỳ); ESC (H ội tim m ạch Châu Âu); ASH (H ội huy ết 
học Hoa K ỳ); NICE (Vi ện sức khỏe quốc gia và chăm sóc ch ất lượng cao Anh Qu ốc) 
đã nhanh chóng đưa ra các khuy ến cáo đ ể dự phòng TTHKTM ở bệnh nhân COVID -
19. Nh ững th ử nghiệm lâm sàng g ần đây như INSPIRATION, REMAP -CAP, ACTIV -
4a, and ATTACC đã kh ẳng định sự an toàn c ủa Heparin TLPTT/Heparin thư ờng liều 
chuẩn so v ới liều trung gian ho ặc liều điều trị, trong d ự phòng TTHKTM ở bệnh nhân 
COVID – 19. Tuy nhiên, v ẫn chưa có thang đi ểm hay mô h ình đánh giá nguy cơ t ắc 
mạch và xu ất huy ết dành riêng cho b ệnh nhân COVID -19. Vì v ậy, ch ỉ định và l ựa 
chọn phương pháp d ự phòng TTHKTM ở bệnh nhân COVID – 19, c ần được đặt ra v ới 
từng bệnh nhân nh ập viện điều trị, trên cơ s ở hội chẩn và đ ồng thu ận của các  chuyên 
gia trong lĩnh v ực này.  
 syt_bacgiang_vt_Van thu SYT Bac Giang_23/10/2023 11:45:0725 
 
Bảng 13: Hư ớng dẫn các bư ớc dự phòng TTHKTM ở bệnh nhân COVID -19 
 
Tất cả bệnh nhân COVID - 19 có tri ệu chứng, c ần điều trị tại bệnh vi ện 
KHÔNG  cần điều trị dự phòng n ếu bệnh nhân đang dùng thu ốc kháng đông  
Đánh giá nguy cơ TTHKTM, nguy cơ xu ất huy ết, chống ch ỉ định v ới thu ốc kháng 
đông:  
- Trong vòng 24 gi ờ kể từ khi vào vi ện 
- Sau m ỗi 48 – 72 gi ờ, hoặc khi có thay đ ổi tình tr ạng lâm sàng; m ục tiêu đi ều trị 
Biện 
pháp 
dự 
phòng  Bệnh nhân COVID -19 
tại Khoa đi ều trị 
thường Bệnh n hân COVID -19 
tại Khoa h ồi sức tích 
cực Dự phòng  
sau khi ra vi ện 
Dự phòng kháng đông 
bằng Heparin TLPTT  
(Enoxaparin 40 mg x 1 
lần/ngày) nên đư ợc 
khuy ến cáo cho t ất cả 
bệnh nhân.  
Với bệnh nhân BMI cao 
(>30), D. Dimer 1000 -
3000 thì căn c ứ BMI>20 
cho enoxa parin 40mg x 
2 lần mỗi ngày.  
Sử dụng bi ện pháp d ự 
phòng cơ h ọc nếu chống 
chỉ định dùng thu ốc 
kháng đông.  Dự phòng kháng đông 
bằng Heparin TLPTT 
hoặc Heparin thư ờng liều 
chuẩn (Enoxaparin 40 
mg x 1 l ần/ngày HO ẶC 
Heparin thư ờng x 5000 
UI x 2 l ần/ngày) nên 
được khuy ến cáo cho t ất 
cả bệnh nhân.  
Có D -Dimer > 3000 
hoặc ECMO, th ở máy 
dùng li ều đi ều tr ị: 
enoxaparin 1mg/kg x 2 
lần/ngày.  
Sử dụng bi ện pháp d ự 
phòng cơ h ọc nếu chống 
chỉ định dùng thu ốc 
kháng đông.  Có th ể cân nh ắc dựa 
vào t ừng b ệnh nhân 
và các YTNC t ại thời 
điểm ra vi ện nếu nguy 
cơ TTHKTM l ớn hơn 
nguy cơ xu ất huy ết 
(tương t ự khuy ến cáo 
dành cho b ệnh nhân 
không b ị COVID -19). 
Có th ể xem xét dùng 
thuốc DOAC  kéo dài 
tới 4 tu ần. 
 syt_bacgiang_vt_Van thu SYT Bac Giang_23/10/2023 11:45:0726 
 
CHƯƠNG  4. DỰ PHÒNG THUYÊN T ẮC HUYẾT KHỐI T ĨNH MẠCH Ở 
BỆNH NHÂN NỘI  UNG TH Ư 
 
Bệnh nhân ung thư có nguy cơ b ị thuyên t ắc tĩnh m ạch tăng g ấp 6 l ần so v ới ngư ời 
không b ị ung thư.  Trong t ất cả các trư ờng hợp thuyên t ắc huy ết khối tĩnh m ạch, 19,8 
% bệnh nhân TTHKTM phát hi ện bị ung thư. T ần suất TTHKTM hàng năm ở BN ung 
thư kho ảng ≈  1/250. Trong t ất cả các trư ờng hợp ung thư, ch ỉ 15% b ị TTHKTM có 
triệu chứng, và có t ới 50% phát hi ện TTHKTM qua k ết quả tử thiết. TTHKTM là 
nguyên nhân t ử vong th ứ 2 ở bệnh nhân, m ức độ lan r ộng, th ời gian b ị ung thư, 
phương pháp đi ều trị… ung thư, sau c hính căn b ệnh này. Có nhi ều yếu tố làm tăng 
nguy cơ thuyên t ắc huy ết khối ở bệnh nhân ung thư như v ị trí u (cao nh ất ở những 
bệnh nhân u não, ung thư bi ểu mô tuy ến phổi, buồng tr ứng, tụy, đại tràng, d ạ dày ti ền 
liệt tuyến, thận, và ung thư máu).  
 
1. Đánh giá nguy cơ huyết khối:  
 
Bảng 14: Thang đi ểm KHORANA  
- Đối với bệnh nhân khối u đặc: Thang điểm Khorana   
- Đối với bệnh nhân ung thư huyết học: Thang điểm SAVED  (dành cho nhóm bệnh 
nhân đa u tủy được điều trị thuốc điều biến miễn dịch kết hợp Dexamethasone liều  
cao) 
 
 
 
 Đặc điểm bệnh nhân  Điểm nguy cơ  
Ung thư nguyên phát  
Nguy cơ rất cao: Tụy, dạ dày, não.  
Nguy cơ cao: Phổi, ung thư hạch, phụ khoa, bàng quang, tinh hoàn   
+2 
+1 
Tiểu cầu  trước điều trị (≥ 350 G/L)  +1 
Hb < 10g/L hoặc đang điều trị thuốc EPO  +1 
Bạch cầu  trước điều trị (≥ 11 G/L)  +1 
BMI ≥ 35 kg.m3 +1 
Tổng điểm :          0       Nguy cơ thấp (0,8 -3%) 
                            1-2    Nguy cơ trung bình (1,8 -8,4%)  
                             ≥3    Nguy c ơ cao (7,1 -41%)   syt_bacgiang_vt_Van thu SYT Bac Giang_23/10/2023 11:45:0727 
 
Bảng 15: Thang đi ểm SA VED (giành cho nhóm b ệnh nhân đa u t ủy được điều trị 
thuốc điều biến miễn dịch kết hợp Dexamethasone li ều cao)  
 2. Đánh giá nguy cơ xuất huyết:  
   Tham khảo và sử dụ ng Bảng chống chỉ định của kháng đông   
Bảng 16: B ảng ch ống ch ỉ định của thu ốc kháng đông  
Chống ch ỉ định tuy ệt đối Chống ch ỉ định tương đ ối (thận trọng) 
- Suy gan n ặng 
- Xuất huy ết não 
- Tình trạng xu ất huy ết đang ti ến 
triển (ví d ụ: xuất huy ết do lo ét dạ 
dày tá tràng) 
- Tiền sử xuất huyết giảm tiểu cầu 
nhất là HIT (Heparin -induced 
thrombocytopenia)  
- Dị ứng thu ốc kháng đông  
- Rối loạn đôn g máu bẩm sinh hay 
mắc phải - Suy th ận nặng (CrCl  ≤ 30 ml/phút)  
- Chọc dò tuỷ sống  
- Đang d ùng các thuốc chống ngưng t ập 
tiểu cầu (aspirin, clopidogrel…)  
- Số lượng tiều cầu < 100.0 00/µl 
- Tăng huy ết áp nặng chưa đư ợc kiểm 
soát (HA tâm thu > 180 mmHg, và / 
hoặc HA tâm trương > 110 mmHg)  
- Mới phẫu thu ật sọ não, ph ẫu thu ật tuỷ 
sống hay c ó xuất huyết nội nhãn cầu 
- Phụ nữ ở giai đo ạn chu ẩn bị chuy ển dạ, 
với nguy cơ xu ất huy ết cao (nhau ti ền 
đạo…) 
Không d ùng thu ốc kháng đông khi c ó 
1 trong c ác yếu tố nêu trên. Nên l ựa 
chọn phương p háp dự phòng cơ học Trì hoãn sử dụng thuốc kháng đông cho 
đến khi nguy cơ xu ất huyết đã giảm  Đặc điểm bệnh nhân  Thang điểm  
Phẫu thuật trong vòng 90 ngày  +2 
Chủng tộc Châu Á  -3 
Tiền sử TTHKTM   +3 
Tuổi ≥ 80  +1 
Liều dexamethasone  
- Liều chuẩn 120 -160 mg/CK  
- Liều cao > 160 mg/CK   
+1 
+2 
Phân nhóm nguy cơ :     
- Nguy cơ cao  ≥ 2 điểm:  
 Dự phòng kh áng đông  
                            Enoxaparin 40 mg/ngày (TDD hàng ngày)  
                            Rivaroxaban 10 mg (uống hàng ngày ) 
                            Apixaban 2,5 mg (uống hàng ngày)      
- Nguy cơ thấp  < 2 điểm
 Không dự phòng kh áng đông  
                            Hoặc aspirin 81mg - 325 mg (uống) hàng ngày  syt_bacgiang_vt_Van thu SYT Bac Giang_23/10/2023 11:45:0728 
 
3. Phác đồ dự phòng TTHKTM trên bệnh nhân nội ung thư:  
3.1. Dự phòng tiên phát  
Sử dụng các biện pháp dự phòng trên nhóm bệnh nhân có nguy cơ cao huyết khối tĩnh 
mạch không kèm theo tiền sử huyết khối tr ước đó.  
Cần cân nhắc dự phòng: đánh giá lợi ích - nguy cơ dự phòng thuốc kháng đông, giá 
thành điều trị, cách sử dụng thuốc (uống hoặc tiêm), tình trạng bệnh nhân nội trú hay 
ngoại trú.  
3.1.1. Dự phòng huyết khối tĩnh mạch trên bệnh nhân nội ung thư nhập viện  
Đây là nhóm nguy cơ cao huyết khối tĩnh mạch, điều trị dự phòng giúp giảm tỷ lệ bị 
huyết khối, tuy nhiên chưa rõ rệt về hiệu quả giảm tỷ lệ tử vong.  
- Dự phòng bằng thuốc:  Bệnh nhân ung thư điều trị nội trú có/không kèm theo giảm 
vận động, nên dự phòn g huyết khối bằng thuốc nếu không có nguy cơ biến chứng 
(ví dụ: bn mới phẫu thuật, xu ất huyết đại thể, giảm tiểu cầu < 50,000 /microL).  
+ Ưu tiên sử dụng heparin trọng lượng phân tử thấp (LMWH) hơn DOAC do 
nguy cơ xu ất huyết thấp hơn (qua 2 nghiên cứu MAG ELLAN và ADOPT so 
sánh sử dụng rivaroxaban uống 10 mg/ngày hoặc apixaban uống 2,5 mg/ngày 
với enoxaparin 40 mg/ngày TDD cho thấy nguy cơ xu ất huy ết tăng gấp 2 -6 lần 
ở nhóm dùng thuốc uống DOAC với tỷ lệ xu ất huyết lần lượt là 2 ,8 >< 1,2% và 
3 ><0 ,5 %).  
Thuốc và liều điều trị theo Bảng 4  
(Xem phần. Bảng 4 . Tổng hợp các biện pháp dự phòng TTHKTM và chỉ định)  
- Nếu bệnh nhân có chống chỉ định sử dụng thuốc kh áng đông:  Có thể sử dụng các 
biện pháp dự phòng cơ học.  
3.1.2. Dự phòng huyết khối trên bệnh nhân ngoại trú  
- Đánh giá nguy cơ  
+ Đánh giá nguy cơ dựa vào thang điểm Khorana.  
+ Kèm theo có thể kết hợp thêm một số yếu tố khác đánh giá tăng nguy cơ huyết 
khối: phác đồ điều trị có thuốc điều biến miễn dịch trong đa u tủy như 
Thalidomide, và 2 giá trị xét nghiệm  Soluble  P-selectin, D -Dimer, Fibrinogen, 
phân đoạn prothrombine 1 +2, thời gian aPTT, thời gian Prothrombine.  
- Chỉ định dự phòng huyết khối:  Cần được cân nhắc kỹ trên từng trường hợp cụ thể, 
cần đánh giá các nguy cơ (xuất huyết) và lợi ích dự phòng mang lạ i.  
+ Nhóm nguy cơ thấp, Khorana < 2 điểm: Không chỉ định dự phòng huyết khối 
tiên phát, tuy nhiên có thể dự phòng bước 2 với nhóm bệnh nhân nguy cơ cao 
như tiền sử huyết khối nhưng không được điều trị liên tục.  
+ Nhóm nguy cơ cao, Khorana ≥ 3 điểm hoặc các b ệnh nhân có Khorana < 3 
điểm kèm theo các yếu tăng nguy cơ khác như sử dụng thuốc điều biến miễn 
dịch trong đa u tủy, tiền sử huyết khối động mạch (nhồi máu, đột quỵ…): Có 
chỉ định dự phòng huyết khối tiên phát.  
- Phác đồ và liều điều trị:  Nhìn chung các hướ ng dẫn lâm sàng ung thư đều thống 
nhất sử dụng một trong hai nhóm thuốc  syt_bacgiang_vt_Van thu SYT Bac Giang_23/10/2023 11:45:0729 
 
+ Thuốc ức chế Xa như apixaban  hoặc rivaroxaban   
+ Heparin trọng lượng phân tử thấp (LMWH)  
+ Kết quả qua các thử nghiệm lâm sàng cho t hấy hiệu quả dự phòng tương tự 
nhau ở cả 2 nhóm.  
+ Trong một số trường hợp bệnh nhân đa u tủy được điều trị thuốc điều biến miễn 
dịch kết hợp dexamethasone, có thể sử dụng thuốc aspirin như liệu pháp dự 
phòng huyết khối nếu nguy cơ theo thang điểm SAVED thấ p < 2 điểm.  
+ Liều điều trị theo bảng 2  
3.2. Dự phòng tái phát  
Tỷ lệ tái phát huyết khối tĩnh mạch tăng lên 21% ở những bệnh nhân có tiền sử huyết 
khối trước đó (cao gấp 3 -4 lần so với nhóm không có tiền sử huyết khối).  
3.2.1. Đánh giá nguy cơ huyết khối t ái phát  
Một số thang điểm nguy cơ được đưa ra để đánh giá nguy cơ huyết khối thứ phát. Tuy 
nhiên các thang điểm chưa được áp dụng rộng rãi trên lâm sàng và cần thêm các bằng 
chứng từ thử nghiệm lâm sàng chứng minh giá trị dự đoán của các bảng nguy cơ này. 
Thử nghiệm CLOT  và CANTHANOX cho thấy một số yếu tố tăng nguy cơ huyết khối 
thứ phát bao gồm:  
- Sử dụng thuốc kh áng đông không đ ủ liều  (do liều thấp đặc biệt Wafarin, do hấp thu 
kém, không tuân thủ điều trị, dừng điều trị kh áng đông do xuất huyết, hoặc do biến 
chứng điều trị).  
- Một số yếu tố liên quan người bệnh:  
+ Tuổi trẻ < 65 (OR 3 ,0; 95% CI 1 ,9-4,9) 
+ Huyết khối phổi lúc chẩn đoán ban đầu (OR 1 ,9; 95% CI 1 ,2-3,1) 
+ Bệnh ung thư mới được chẩn đoán <3  tháng  (OR 2 ,0; 95% CI 1 ,5-3,6) 
- Một số yếu tố liên quan bệnh ung thư:  
+ Nguy cơ cao: ung thư tụy, phổi, vú, đại trực tràng…  
+ Bệnh ung thư tiến triển, giai đoạn di căn.  
3.2.2.  Chỉ định và thuốc dự phòng huyết khối thứ phát   
Tương tự như dự phòng tiên phát cho nhóm nguy cơ cao.  syt_bacgiang_vt_Van thu SYT Bac Giang_23/10/2023 11:45:0730 
Sơ đồ 1: Dự phòng TTHKTM ở bệnh nhân un g thư đi ều trị nội trú 
Yếu tố nguy cơ  
- BN n ội khoa ho ặc ngo ại 
khoa  
- Chẩn đoán UT  
- Cân nh ắc giữa lợi ích và 
nguy cơ d ự phòng huy ết 
khối, sự tuân th ủ điều trị 
của BN  Đánh giá ban đầu  
- Tiền sử HK và t ổng trạng  
- Công thứ c máu và số 
lượng tiểu cầu  
- Thời gian đông máu 
ngoại sinh (PT) 
- Thời gian đông máu nội 
sinh (aPTT ) 
- Chức năng gan thận  
- Đánh giá nguy cơ huyết 
khối theo Khorana   
Chống chỉ định  
dùng kháng đông   
Không  
 
Có Dự phòng ban đ ầu: 
+ Liệu pháp d ự phòng 
huyết khối bằng thu ốc  
+ Cân nh ắc s ử dụng 
Heparin TLPTT t rong 
thời gian n ội trú, sau đó 
có th ể chuy ển DOAC .   
Tiếp tục dự 
phòng sau 
khi ra vi ện 
 
Dự phòng 
bằng các 
biện pháp 
cơ học syt_bacgiang_vt_Van thu SYT Bac Giang_23/10/2023 11:45:0731 
 
 
Sơ đồ 2: Dự phòng TTHKTM ở bệnh nhân ung thư đi ều trị ngoại trú 
Yếu tố nguy cơ:  
- BN đi ều trị nội khoa  
- Chẩn đoán ung thư  
- Đã d ự phòng huy ết khối 
trong th ời gian n ội trú  
- Bệnh nhân n ội trú ung 
thư s ắp được ra vi ện 
- Bệnh nhân ngo ại trú có 
yếu tố nguy cơ  
- Cân nh ắc giữa lợi ích và 
nguy cơ d ự phòng huy ết 
khối, sự tuân th ủ điều trị 
của bệnh nhân . 
 Bệnh nhân đa u t ủy xương 
có đi ều trị thuốc điều biến 
miễn dịch 
Các bệnh ung thư khác có y ếu 
tố nguy cơ đư ợc đánh giá 
theo thang đi ểm Khorana  
 Đánh giá nguy cơ huy ết khối dựa theo 
thang đi ểm SAVED  
 
Nguy cơ huy ết khối trung bình và cao 
(Khorana ≥ 2)  
- Cân nh ắc dùng kháng đông đư ờng 
uống tới 6 tháng ho ặc lâu hơn n ếu vẫn 
còn y ếu tố nguy cơ: enoxaparin ; 
apixaban; rivaroxaban  
  
Nguy cơ huy ết khối thấp (Khorana < 2)  
- Không d ự phòng huy ết khối tĩnh m ạch 
- Có th ể sử dụng dự phòng cơ h ọc  
  syt_bacgiang_vt_Van thu SYT Bac Giang_23/10/2023 11:45:0732 
Bảng 17: B ảng lựa chọn các phương pháp trong d ự phòng TTHKTM cho b ệnh nhân 
ung thư đi ều trị nội trú 
Thuốc Liều cơ bản (nhóm 1)  Chỉnh li ều suy 
thận Chỉnh li ều béo phì  
(BMI ≥ 40kg/m2) 
Enoxaparin  40 mg TDD hàng ngày  Dùng 30 mg TDD 
hàng ngày n ếu 
CrCl < 30ml/phút  Cân nh ắc 40 mg 
TDD  mỗi 12 gi ờ 
Hoặc 0,5mg/kg 
TDD hàng ngày  
Fondaparinux  2,5 mg TDD hàng ngày 
(tránh dùng trê n bệnh nhân 
cân n ặng < 50 kg)  Chú ý n ếu CrCl 
30-49 ml/phút  Cân nh ắc 5 mg 
TDD  hàng ng ày 
Heparin 
không phân 
đoạn (UFH)  5000 đơn v ị TDD m ỗi 8-12 
giờ Như li ều dùng cơ 
bản Cân nh ắc 7500 đơn 
vị TDD m ỗi 8 gi ờ 
 
Bảng 18: B ảng lựa chọn các phương pháp trong d ự phòng TTHKTM cho b ệnh nhân 
ung thư đi ều trị nội khoa ngo ại trú 
Thuốc Liều cơ b ản (nhóm 1)  Chỉnh li ều suy 
thận Chỉnh li ều trong 
trường hợp khác  
Enoxaparin  1mg/kg tiêm dư ới da hàng 
ngày trong 3 th áng sau đ ó 
40 mg TDD hàng ngày  Dùng 30 mg 
TDD hàng ngày 
nếu CrCl < 
30ml/phút  Giảm 0,5mg/kg 
TDD hàng ngày n ếu 
tiểu cầu 50. 000-
70.000/mcrg  
Tránh dùng n ếu tiểu 
cầu < 50 G/L  
Apixaban  uống 2,5 mg 2 l ần 1 ngày  Không dùng n ếu 
CrCl < 30ml/phút  Tránh dùng n ếu tiểu 
cầu < 50 G/L  
Tránh dùng n ếu cân 
nặng < 40kg  
Rivaro xaban  uống 10 mg 1 l ần 1 ngày  Không dùng n ếu 
CrCl < 15ml/phút  Tránh dùng n ếu tiểu 
cầu < 50 G/L  syt_bacgiang_vt_Van thu SYT Bac Giang_23/10/2023 11:45:0733 
 
CHƯƠNG  5. DỰ PHÒNG TTHKTM Ở BỆNH NHÂN NGO ẠI KHOA CHUNG  
 
1.Chỉ định  
Quy trình d ự phòng TT HKTM áp d ụng cho t ất cả các b ệnh nhân c ủa các khoa phòng 
Ngoại khoa  trong b ệnh vi ện. Các b ệnh nhân m ới nhập viện và các b ệnh nhân đang 
nằm điều trị. Quy trình  được thực hiện hàng ngày trong quá khi khám  – chữa bệnh tại 
mỗi khoa phòng . 
2.Mục tiêu  
Quy chu ẩn hóa các bư ớc dự phòng đ ể đảm bảo giảm thi ểu tối đa s ự hình thành h uyết 
khối tĩnh m ạch và các bi ến chứng thuyên t ắc mạch. 
3.Nội dung   
3.1. Đánh giá nguy cơ TTHKTM cho BN ngo ại khoa chung:  
Đánh giá YTNC TTHKTM ở bệnh nhân ngo ại khoa b ằng thang đi ểm CAPRINI  
 
Bảng 19: B ảng đánh giá YTNC TTHKTM ở bệnh nhân ngo ại khoa b ằng tha ng đi ểm 
CAPRINI  
YTNC  Điểm  
bệnh nhân  
Tuổi 41 -60 1 
Có kế hoạch tiểu phẫu  1 
Tiền sử đại phẫu (<1 tháng)  1 
Suy tĩnh mạch  1 
Tiền sử viêm đường ruột (như bệnh Crohn….)  1 
Sưng chân (tại thời điểm khám)  1 
Béo phì (BMI >25)  1 
NMCT cấp  1 
Suy tim sung huyết (<1 tháng)  1 
Nhiễm khuẩn  huyết (<1 tháng)  1 
Bệnh phổi nghiêm trọng bao gồm viêm phổi (<1 tháng)  1 
Chức năng phổi bất thường (COPD)  1 
Bệnh nội khoa nằm tại giường  1 
Đang uống thuốc tránh thai hoặc liệu pháp hormone thay thế  1 
Mang thai hoặc hậu sản (< 1 tháng)  1 
Tiền sử tử vong sơ sinh không rõ nguyên nhân, sảy thai liên tục (≥ 
3), sinh non có nhiễm độc huyết hoặc thai chậm phát triển  1 
Tuổi 61 -74 2 syt_bacgiang_vt_Van thu SYT Bac Giang_23/10/2023 11:45:0734 
 
YTNC  Điểm  
bệnh nhân  
Phẫu thuật nội soi khớp  2 
Đã/đang có bệnh lí ác tính  2 
Đại phẫu (> 45 phút)  2 
Phẫu thuật nội soi ( > 45 phút)  2 
Bất động tại giường (>72h)  2 
Bó bột hoặc nẹp vít bất động (<1 tháng)  2 
Đặt catheter TM trung tâm  2 
Bệnh nhân ≥ 75 tuổi  3 
Tiền sử TTHKTM*  3 
Giảm tiểu cầu do heparin  3 
Gia đình có cha mẹ hoặc anh chị em bị TTHKTM   
Yếu tố di truyền: Yếu t ố V Leiden dương tính, Yếu tố Prothombin 
20210A dương tính, tăng homocysteine  huyết thanh, kháng đông 
Lupus dương tính, tăng kháng thể anticardiolipin,  các bệnh lí tăng 
đông bẩm sinh/mắc phải   3 
Chấn thương tủy sống cấp (liệt) (< 1 tháng)  5 
Phẫu thuật kh ớp chi dưới chương trình  5 
Đa chấn thương (<1 tháng)  5 
Gãy chân, khớp háng, khung chậu < 1 tháng  5 
Đột quỵ < 1 tháng  5 
Tổng điểm   
Tổng đi ểm: 
− Nguy cơ th ấp: 1 – 2 điểm  
− Nguy cơ trung bình:  3 – 4 điểm  
− Nguy cơ cao:  5 – 8 điểm 
− Nguy cơ r ất cao:  > 8 đi ểm  
3.2. Xem xét ch ống ch ỉ định thu ốc kháng đông trên b ệnh nhân  ngoại khoa chung:   
(Xem phần Bảng 16. Bảng chống chỉ định thuốc kháng đông)  
3.3. D ự phòng TTHKTM trên b ệnh nhân Ph ẫu thu ật tổng quát:  
Dựa theo các khuy ến cáo m ới nhất từ Hiệp Hội Huy ết Học Mỹ - ASH 2019, bao g ồm:  
- Khuyến cáo 20 . Đối với bệnh nhân trải qua phẫu thuật tổng quát, Hội đồng hướng 
dẫn ASH đề nghị sử dụng dự phòng dược lý hơn so với không có dự phòng dược lý 
(khuyến cáo có điều kiện về độ chắc chắn thấp với bằng chứng về hiệu quả ++).  syt_bacgiang_vt_Van thu SYT Bac Giang_23/10/2023 11:45:0735 
 
- Khuyến cáo 21 .  Đối với bệnh nhân trải qua phẫu thuật tổng quát, Hội đồng hướng 
dẫn ASH đề nghị sử dụng LMWH hoặc UFH (khuyến cáo có điều kiện, dựa trên độ 
chắc chắn rất thấp với các bằng chứng về hiệu quả +)  
- Khuyến cáo 22 . Đối với bệnh nhân phẫu thuật cắt t úi mật nội soi, Hội đồng hướng 
dẫn ASH đề nghị không sử dụng dự phòng dược lý (khuyến cáo có điều kiện dựa 
trên độ chắc chắn rất thấp với các bằng chứng về hiệu quả +).  
Ghi chú: B ệnh nhân có các YTNC khác đ ối với TTHKTM (ví d ụ, tiền sử TTHKTM, 
thrombophil ia, ho ặc bệnh ác tính) có th ể được hưởng lợi từ dự phòng dư ợc lý.  
Bảng 20: D ự phòng TTHKTM trên b ệnh nhân ph ẫu thu ật chung  
 
Bệnh nhân  Bệnh nhân trưởng thành - Phẫu thuật chung  
Bao gồm phẫu thuật chung, phụ khoa, tiết niệu, tiêu hóa, thẩm mỹ 
hoặc tái tạo, p hẫu thuật vùng tai, mũi, họng, vùng miệng hay vùng 
hàm – mặt, tim, l ồng ng ực, mạch m áu, cột sống cấp cứu.  
KHÔNG cần dự phòng dược lý nếu bệnh nhân đã dùng thuốc kháng đông  
Nên xem xét chống chỉ định và / hoặc nguy cơ xuất huyết trước khi kê đơn  
Nguy cơ 
TTHKTM  
Xem Bảng 
đánh giá 
nguy cơ theo 
Caprini  Nguy cơ 
TTHKTM 
thấp 
(Điểm 
Caprini 1 - 
2) Nguy cơ TTHKTM 
trung bình  
(Điểm Caprini 3 - 4) Nguy cơ TTHKTM cao  
(Điểm Caprini ≥ 5)  
 
  Nguy 
cơ xuất 
huyết 
cao Nguy cơ xuất 
huyết thấp  Nguy cơ 
xuất huyết 
cao Nguy  cơ 
xuất huyết 
thấp 
Dự phòng 
TTHKTM  Sử dụng thiết  
bị bơm hơi 
áp lực ngắt 
quãng (IPC)  
 
 
 
HOẶC  
 
GCS (tất áp 
lực y khoa)  
ngay từ đầu  Sử 
dụng 
IPC 
ngay từ 
đầu Sau phẫu 
thuật, dùng  
LMWH# 
- Enoxaparin 
40 mg TDD 
hàng ngày.  
 
HOẶC  
 
IPC Sử dụng IPC  
ngay từ đầu  
Sau phẫu 
thuật, đánh 
giá lại (và 
ghi nhận) 
nguy cơ.  
Ngay khi 
nguy cơ xuất 
huyết giảm  
CỘNG 
THÊM 
VÀO:  
Các biện 
pháp dự 
phòng dược 
lý Sử dụng 
IPC  hoặc 
GCS ngay 
từ đầu  
VÀ 
Sau phẫu 
thuật ti ến 
hành dự 
phòng 
LMWH# 
- 
Enoxaparin 
40 mg TDD 
hàng ngày.  
Thời gian  N/A Dự phòng cơ học: Tiếp tục trong 30 ngày hoặc cho 
đến khi bệnh nhân vận động hoặc xuất viện, tùy theo 
điều kiện nào sớm hơn  
Dự phòng dược lý: Sử dụng tối thiểu 7 ngày**  syt_bacgiang_vt_Van thu SYT Bac Giang_23/10/2023 11:45:0736 
 
*: Trong dự phòng dược lý, liều dự phòng cuối cùng nên được dùng không dưới 24 giờ 
trước  khi phẫu thuật cho những bệnh nhân có nguy cơ TTHKTM cao hơn nguy cơ 
xuất huyết. Không tiến hành dự phòng dược lý cho bệnh nhân bị dị tật vỡ mạch máu 
não hoặc bệnh nhân bị xuất huyết nội sọ cho đến khi tổn thương được bảo đảm hoặc 
tình trạng đã ổn định5. 
#:  Điều chỉnh liều LMWH hoặc khuyến cáo các thay thế có thể được yêu cầu ở bệnh 
nhân:  
- eGFR dưới 30 ml/phút/1,73m2 hoặc CrCl dưới 30 ml/phút  
- Tăng nguy cơ xuất huyết  
- Trọng lượng cơ thể dưới 50 kg  
- BMI trên 30 kg/m2  
Xem ph ần Lưu ý điều chỉnh liều khi dự ph òng TTHKTM trên nhóm bệnh nhân  
đặc biệt để biết thêm thông tin 
**: Bệnh nhân cao tuổi nội viện đang trải qua phục hồi chức năng: Cân nhắc kéo dài 
thời gian dự phòng vượt quá thời gian tối thiểu được đề nghị cho đến khi khả năng vận 
động đã trở lại mức dự đoán hoặc mức chấp nhận lâm sàng hoặc khi bệnh nhân được 
xuất viện.  
Khuyến cáo dựa trên ý kiến chuyên gia đồng thuận do thiếu bằng chứng.  syt_bacgiang_vt_Van thu SYT Bac Giang_23/10/2023 11:45:0737 
 
CHƯƠNG  6. DỰ PHÒNG TTHKTM Ở BỆNH NHÂN  
PHẪU THU ẬT CH ẤN THƯƠNG S Ọ NÃO  
 
1. Chỉ định  
Quy trình d ự phòng TTHKTM áp d ụng cho t ất cả các b ệnh nhân c ủa các khoa thuộc 
Trung tâm ph ẫu thu ật thần kinh . Các b ệnh nhân m ới nhập viện và các b ệnh nhân đang 
nằm điều trị. Quy trình  được thực hiện hàng ngày trong khi khám  chữa bệnh tại mỗi khoa.  
2. M ục tiêu  
Quy chu ẩn hóa các bư ớc dự phòng đ ể đảm bảo giảm thi ểu tối đa s ự hình thành huy ết 
khối tĩnh m ạch và các bi ến chứng thuyên t ắc mạch. 
3. Nội dung   
3.1. Đánh  giá nguy cơ TTHKTM trên bệnh nhân phẫu thuật chấn thương sọ não  
Bảng 21: Thang đi ểm đánh giá nguy cơ TTHKTM trên b ệnh nhân  
phẫu thu ật chấn thương s ọ não 
Thang điểm đánh giá nguy cơ  Điểm  
Béo phì  2 
Bệnh ác tính  2 
Bất thường đông máu  2 
Tiền căn thuyên tắc huyết khối  3 
Đặt catheter tĩnh mạch đùi  2 
Truyền máu > 4 đơn vị  2 
Phẫu thuật > 2 giờ  2 
Phẫu thuật tĩnh mạch lớn  3 
Chấn t hương vùng ngực với AIS > 2 điểm  2 
Chấn thương vùng bụng AIS > 2 điểm  2 
Chấn thương vùng đầu AIS > 2 điểm  2 
Gãy đốt sống  3 
Điểm hôn mê Glasgow < 8  3 
Gãy xương chi dưới nghiêm trọng  4 
Gãy xương chậu  4 
Chấn thương tủy sống  4 
Tuổi từ 40 đến 60  2 
Tuổi  từ 60 đến 75  3 
Trên 75 tuổi  4 
(AIS - Abbreviated Injury Score; GCS - Glasgow Coma Scale: Thang điểm Glasgow 
đánh giá mức độ hôn mê).  
Nguy cơ cao khi > 5 điểm  syt_bacgiang_vt_Van thu SYT Bac Giang_23/10/2023 11:45:0738 
 
3.2. Xem  xét chống chỉ định khi sử dụng kháng đông trên bệnh nhân phẫu thuật 
chấn thương sọ não :  
(Xem phần Bảng 16. Bảng chống chỉ định thuốc kháng đông)  
3.3. Hư ớng dẫn dự phòng TTHKTM trên bệnh nhân phẫu thuật chấn thương não:   
 
Bảng 22: Hư ớng dẫn dự phòng TTHKTM ở bệnh nhân ph ẫu thu ật chấn thương s ọ não 
NGUY 
CƠ 
TTHKT
M Mọi bệnh nhân ph ẫu thu ật chấn thương s ọ não n ặng đều đư ợc xem là 
đối tượng có nguy cơ cao b ị TTHKTM  
Dự 
phòng  - Khởi động IPC (thi ết bị bơm hơi áp l ực ngắt quãng) khi nh ập viện 
- Trong ch ấn thương s ọ não, th ời điểm bắt đầu điều trị dự phòng dư ợc lý nên 
được thảo luận với nhóm ph ẫu thu ật thần kinh. Nhìn chung:  
+ Ở những bệnh nhân không b ị xuất huy ết nội sọ, điều trị dự phòng dư ợc lý 
có th ể được bắt đầu ngay l ập tức 
+ Ở những bệnh nhân b ị xuất huy ết nội sọ, trì hoãn đi ều trị dự phòng dư ợc lý 
cho đ ến khi đ ạt được khả năng c ầm máu th ỏa đáng (th ường sau 48 gi ờ) 
+ Theo dõi áp l ực nội sọ đơn thu ần không ph ải là ch ống ch ỉ định trong đi ều 
trị dự phòng dư ợc lý: 
+ Các lựa chọn dự phòng dư ợc lý:  
• UFH 5000 đơn v ị TDD  2 -3 lần mỗi ngày  
• LMWH:  Enoxaparin 40 mg TDD hàng ngày  
Thời 
gian Dự phòng cơ h ọc: tiếp tục cho đ ến khi kh ả năng v ận động đư ợc như mong 
đợi hoặc chấp nhận được trên lâm sàng ho ặc khi b ệnh nhân xu ất viện 
Dự phòng dư ợc lý: s ử dụng tối thiểu 7 ngày. N ếu chấn thương t ủy sống cấp 
tính và ch ấn thương s ọ não d ẫn đến giảm vận động đáng k ể, tiếp tục điều 
trị dự phòng dư ợc lý TTHKTM trong 3 tháng sau ph ẫu thu ật hoặc cho đ ến 
khi kh ả năng v ận động trở lại mức mong đ ợi/chấp nhận được trên lâm sàng  
 
 
 
 
 syt_bacgiang_vt_Van thu SYT Bac Giang_23/10/2023 11:45:0739 
 
CHƯƠNG  7. DỰ PHÒNG THUYÊN T ẮC HUY ẾT KH ỐI TĨNH M ẠCH Ở 
BỆNH NHÂN PH ẪU THU ẬT UNG THƯ  
 
1. Đánh giá ngu y cơ TTHKTM cho b ệnh nhân  
Phân tầng nguy cơ dựa theo thang điểm Caprini   
(Xem phần Bảng 19.  Đánh giá YTNC TTHKTM ở bệnh nhân ngoại khoa bằng thang 
điểm CAPRINI)  
2. Xem xét chống chỉ định thuốc kháng đông trên bệnh  nhân  phẫu thuật  
Xem Bảng Chống chỉ định củ a Kháng đông  
(Xem phần Bảng 16. Bảng chống chỉ định thuốc kháng đông)  
3.Lựa chọn các biện pháp dự phòng  
3.1. Các biện pháp dự phòng chính  
3.1.1.  Cơ học  
- Tất chun, băng quấn áp lực.  
- Bơm hơi áp lực ngắt quãng.  
- Lưới lọc tĩnh mạch chủ dưới (dự phòng TTP).  
3.1.2.  Dược lý  
- Thuố c kháng đông đường tiêm: Heparin không phân đoạn, heparin trọng lượng 
phân tử thấp, Fondaparinux.  
- Thuốc kháng đông đường uống: chưa có khuyến cáo.  
3.2. Chiến lược dự phòng cụ thể  
Chiến lược dự phòng dựa theo phân tầng nguy cơ của thang điểm Caprini:  syt_bacgiang_vt_Van thu SYT Bac Giang_23/10/2023 11:45:0740 
 
Bảng 23: Chi ến lược dự phòng TTHKTM ở bệnh nhân ph ẫu thu ật ung thư d ựa theo 
phân t ầng nguy cơ c ủa thang đi ểm CAPRINI  
Bệnh 
nhân  Bệnh nhân trư ởng thành - Phẫu thu ật Ung Thư  
Phẫu thu ật phần bụng dư ới 
KHÔNG cần dự phòng dư ợc lý n ếu bệnh nhân đã dùng thu ốc kháng đô ng 
Nên xem xét ch ống ch ỉ định và / ho ặc nguy cơ xu ất huy ết trước khi kê toa  
Nguy cơ 
TTHKTM  
 Nguy cơ 
TTHKT
M th ấp 
(Điểm 
Caprini  
 1 - 2) Nguy cơ 
TTHKTM 
trung bình  
(Điểm 
Caprini  
3 - 4) Nguy cơ TTHKTM cao  
Tất cả các ph ẫu thu ật bụng dư ới trên b ệnh 
nhân ung thư  có th ể được coi là nguy cơ 
cao phát tri ển TTHKTM  
 Nguy cơ xu ất huy ết 
cao Nguy cơ xu ất huy ết 
thấp 
Dự phòng 
TTHKTM  -Không c ần dự phòng 
dược lý. 
-Dự phòng cơ h ọc 
trong th ời gian n ằm 
viện. Sử dụng IPC ngay t ừ 
đầu 
 
Sau ph ẫu thu ật, đánh 
giá l ại (và ghi nh ận 
nguy cơ.  
 
Khi nguy cơ xu ất 
huyết giảm,  
THÊM  
dự phòng dư ợc lý Sử dụng IPC ho ặc 
GCS  ngay t ừ đầu 
VÀ 
Sau ph ẫu thu ật, sử 
dụng m ột trong các 
biện pháp dư ợc lý 
sau: 
- Heparin chu ẩn 
(Heparin  không 
phân đo ạn) 5000 UI 
TDD 1 l ần mỗi 8h. 
- Enoxaparin TDD 
40 mg m ỗi ngày m ột 
lần* 
Thời gian  Dự phòng cơ h ọc: Ti ếp tục cho đ ến khi kh ả 
năng v ận động tr ở lại mức dự đoán ho ặc mức 
chấp nhận lâm sàng ho ặc khi b ệnh nhân đư ợc 
xuất viện 
Dự phòng dư ợc lý: Cân nh ắc kéo dài đi ều trị 
dự phòng đ ến 4 tu ần sau ph ẫu thu ật** 
(*):  Đi ều chỉnh li ều LMWH ho ặc khuy ến cáo các thay th ế có th ể được yêu c ầu ở 
bệnh nhân:  
• eGFR dư ới 30 ml/phút/1,73m2 hoặc CrCl dư ới 30 ml/phút  
• Tăng nguy cơ xu ất huy ết 
• Trọng lư ợng cơ th ể dưới 50 kg  
• BMI trên 30 kg/m2  
(**): Bệnh nhân cao tu ổi nội viện đang tr ải qua ph ục hồi chức năng: Cân nh ắc kéo dài 
thời gian d ự phòng vư ợt quá th ời gian t ối thiểu được đề nghị cho đ ến khi kh ả năng 
vận động đã tr ở lại mức dự đoán ho ặc mức chấp nhận lâm sàng ho ặc khi b ệnh nhân 
được xuất viện.  
Khuy ến cáo d ựa trên ý ki ến chuyên gia đ ồng thu ận do thi ếu bằng ch ứng. syt_bacgiang_vt_Van thu SYT Bac Giang_23/10/2023 11:45:0741 
 
3.3. Một số khuyến cáo của Hội ung thư Lâm sàng Hoa Kỳ về dự phòng TTHKTM 
ở bệnh nhân phẫu thuật Ung thư.  
- Dự phòng TTHKTM thường quy KHÔNG được khuyến cáo cho tất cả các bệnh 
nhân ung thư, có thể cân nhắc với những bệnh  nhân nguy cơ cao.  
- Phần lớn bệnh nhân ung thư đang hoạt động cần dự phòng TTHKTM trong thời 
gian nằm viện. Tuy nhiên KHÔNG đủ dữ liệu để khuyến cáo dự phòng thường quy 
với những BN nhập viện để làm các thủ thuật nhỏ hoặc truyền hóa chất ngắn ngày.  
- Dự phòng  huyết khối thường quy bằng Heparin TLPTT hoặc Heparin không phân 
đoạn với những bệnh nhân ung thư nhập viện với bệnh cảnh nội khoa cấp tính và 
bệnh nhân ung thư phẫu thuật chính.  
- BN phẫu thuật ung thư chính nên được dự phòng từ trước phẫu thuật và kéo dài  ít 
nhất 7 -10 ngày. Dự phòng kéo dài sau phẫu thuật tới 4 tuần nên được cân nhắc với 
những bệnh nhân nguy cơ cao như như bất động, béo phì và tiền sử bị TTHKTM; 
phẫu thuật chính vùng ổ bụng hoặc tiểu khung.  
 
syt_bacgiang_vt_Van thu SYT Bac Giang_23/10/2023 11:45:0742 
 
CHƯƠNG  8. DỰ PHÒNG TTHKTM Ở BỆNH NHÂN CH ẤN THƯƠ NG 
CHỈNH HÌNH  
 
1. Chỉ định  
Quy trình d ự phòng TTHKTM áp d ụng cho t ất cả các b ệnh nhân c ủa các khoa Chấn 
thương Ch ỉnh hình . Các b ệnh nhân m ới nhập viện và các b ệnh nhân đang n ằm điều trị. 
Quy trình  được thực hiện hàng ngày trong khi khám  – chữa bệnh tại mỗi khoa.  
2. M ục tiêu  
Quy chu ẩn hóa các bư ớc dự phòng đ ể đảm bảo giảm thi ểu tối đa s ự hình thành huy ết 
khối tĩnh m ạch và các bi ến chứng thuyên t ắc mạch. 
3. Nội dung   
 
Bảng 24: B ảng khuy ến cáo d ự phòng TTHKTM ở bệnh nhân ph ẫu thu ật chỉnh hình 
theo hư ớng dẫn VNHA 2016  
Khuyến cáo  Nhóm  Mức bằng  
chứng  
BN phẫu thuật thay khớp háng hoặc thay khớp gối được 
khuyến cáo điều trị dự phòng TTHKTM thường quy bằng một 
trong các biện pháp sau:  
- Heparin TLPTT, Fondaparinux, Dabigatran, Rivaroxaban, 
Heparin không phân đoạn , kháng Vitamin K liều hiệu chỉnh (1)  
- hoặc bơm  hơi áp  lực ngắt quãng   
 
 
 
I 
I  
 
 
 
B 
C 
BN phẫu thuật gãy xương đùi được khuyến cáo điều trị dự 
phòng TTHKTM thường quy bằng một trong các biện pháp 
sau:  
- Heparin TLPTT, Fondaparinux, Heparin không phân đ oạn, 
kháng Vitamin K liều hiệu chỉnh (1)  
- hoặc bơm  hơi áp  lực ngắt quãng   
 
I 
 
I  
 
B 
 
C 
Thời gian duy trì dự phòng trung bình là 10 -14 ngày kể từ khi 
phẫu thuật  I B 
Có thể kéo dài thời gian dự phòng sau khi BN ra viện tới 35 
ngày kể từ khi phẫu thuật  IIb B 
Thời gian b ắt đầu dự phòng:  
-Heparin TLPTT: b ắt đầu trư ớc phẫu thu ật 12 gi ờ, hoặc sau ph ẫu thu ật 18-24 gi ờ. 
-Fondaparinux: b ắt đầu sau ph ẫu thu ật 6-24 gi ờ 
-Rivaroxaban, Dabigatran: b ắt đầu sau ph ẫu thu ật 6-10 gi ờ syt_bacgiang_vt_Van thu SYT Bac Giang_23/10/2023 11:45:0743 
 
3.1. D ự phòng TTHKTM trên b ệnh nhân ph ẫu thu ật thay kh ớp háng và kh ớp gối  
- Nguy cơ TTHKTM: 100% BN thay kh ớp háng và kh ớp gối có nguy cơ TTHKTM 
cao. 
- Trước khi kê đơn, xem xét ch ống ch ỉ định và/ho ặc nguy cơ xu ất huy ết: 
 
Bảng 25: Các phương pháp d ự phòng TTH KTM ở bệnh nhân ph ẫu thu ật thay kh ớp 
háng, kh ớp gối 
Thay kh ớp háng  Thay kh ớp gối 
- Sử dụng IPC ho ặc GCS khi nh ập viện 
cho đ ến khi b ệnh nhân xu ất viện 
VÀ 
- Heparin TLPTT 28 ngày  
HOẶC  
- Rivaroxaban 10 mg/ngày trong 28 ngày  - Sử dụng IPC hoặc GCS khi nh ập viện 
cho đến khi b ệnh nhân xu ất viện 
VÀ 
- Heparin TLPTT 28 ngày  
HOẶC 
- Rivaroxaban 10 mg/ngày trong 28 
ngày  
 
3.2. D ự phòng TTHKTM trên b ệnh nhân ph ẫu thu ật gãy xương ch ậu, xương hông, 
xương đùi .  
Nguy cơ TTHKTM: có nguy cơ TTHKTM cao.  
Trước khi kê đơn, xem xét ch ống chỉ định và/ho ặc nguy cơ xu ất huy ết 
 
Bảng 26: Các phương pháp d ự phòng TTHKTM ở bệnh nhân ph ẫu thu ật gãy xương 
chậu, xương hông và xương đùi  
Phẫu thu ật gãy xương ch ậu, xương hông và xương đùi  
Sử dụng IPC ho ặc GCS khi nh ập viện cho đ ến khi b ệnh nhân xu ất viện 
VÀ 
Sử dụng Heparin TLPTT 12 gi ờ sau ph ẫu thu ật, tiếp tục đến 28 ngày  
Nếu phẫu thu ật bị trì hoãn sau ngày nh ập viện, cân nh ắc dùng Heparin TLPTT trư ớc 
phẫu thu ật, với liều cuối cùng ng ừng trư ớc phẫu thu ật từ 12 gi ờ trở lên 
 
 
 
 
 
 
 syt_bacgiang_vt_Van thu SYT Bac Giang_23/10/2023 11:45:0744 
 
3.3.  D ự phòng TTHKTM t rên b ệnh nhân ch ấn thương n ặng, đa ch ấn thương  
 
Bảng 27: Các phương pháp d ự phòng TTHKTM ở bệnh nhân ch ấn thương n ặng,  
đa ch ấn thương  
 
NGUY CƠ 
TTHKTM  Mọi bệnh nhân ph ẫu thu ật chấn thương l ớn đều đư ợc xem là 
đối tượng có nguy cơ cao b ị TTHKTM  
Dự phòng  Khởi động IPC (*) khi nh ập viện 
VÀ 
Sau ph ẫu thu ật, tái đánh giá (**) (và ghi l ại) nguy cơ h ằng ngày 
hoặc nhi ều lần hơn n ếu cần thiết 
THÊM heparin khi nguy cơ xu ất huy ết giảm xu ống và s ự cầm máu 
bình thư ờng. Cân nh ắc heparin TLPTT (***) sau 3 ngày ho ặc 
ngay kh i nguy cơ xu ất huy ết giảm xu ống.  
Thời gian  Dự phòng cơ h ọc: tiếp tục cho đ ến khi kh ả năng v ận động đư ợc 
như mong đ ợi hoặc chấp nhận đư ợc trên lâm sàng ho ặc khi b ệnh 
nhân xu ất viện 
Dự phòng dư ợc lý: s ử dụng tối thiểu 7 ngày. N ếu chấn thương t ủy 
sống cấp tính và ch ấn thương s ọ não d ẫn đến giảm vận động đáng 
kể, tiếp tục điều trị dự phòng dư ợc lý TTHKTM trong 3 tháng sau 
phẫu thu ật hoặc cho đ ến khi kh ả năng v ận động tr ở lại mức mong 
đợi/chấp nhận được trên lâm sàng  
(*) Tùy thu ộc vào lo ại chấn thương, đi ều trị dự phòng b ằng cơ h ọc có th ể được chống 
chỉ định ở những bệnh nhân b ị chấn thương chi dư ới. Tuy nhiên, n ếu không có ch ống 
chỉ định nào khác, nên đi ều trị dự phòng cơ h ọc ở chân không b ị thương.  
(**) Trong ch ấn thương s ọ não, th ời điểm bắt đầu điều trị dự phòng dư ợc lý nên đư ợc 
thảo luận với nhóm ph ẫu thu ật thần kinh. Nhìn chung:  
- Ở những bệnh nhân không b ị xuất huy ết nội sọ, điều trị dự phòng dư ợc lý có th ể 
được bắt đầu ngay l ập tức 
- Ở những bệnh nhân b ị xuất huy ết nội sọ, trì hoãn đi ều trị dự phòng dư ợc lý cho đ ến 
khi đ ạt được khả năng c ầm máu th ỏa đáng (thư ờng sau 48 gi ờ) 
Theo dõi áp l ực nội sọ đơn thu ần không ph ải là ch ống ch ỉ định trong đi ều trị dự phòng 
dược lý 
 
3.4. D ự phòng TTHKTM trên b ệnh nhân ch ấn thương ch ỉnh hình khác  
 syt_bacgiang_vt_Van thu SYT Bac Giang_23/10/2023 11:45:0745 
 
Bảng 28: Các phương pháp d ự phòng TTHKTM ở bệnh nhân  
chấn thương ch ỉnh hình khác  
KHÔNG c ần dự phòng b ằng bi ện pháp dư ợc lý n ếu bệnh nhân : 
− Đang s ử dụng kháng đông  đủ liều vì m ục đích đi ều trị bệnh khác (ví d ụ: rung nhĩ)  
− Phẫu thu ật trong ngày và đư ợc thực hiện gây tê t ại chỗ, không gi ới hạn vận động 
Trước khi kê đơn, xem xét ch ống ch ỉ định và/ho ặc nguy cơ xu ất huy ết 
Nguy cơ TTHKTM th ấp 
Bệnh nhân tr ải qua các th ủ thuật chỉnh 
hình khác đư ợc gây tê t ại chỗ mà không 
bị giới hạn vận động HO ẶC không có 
bất kỳ YTNC nào đư ợc liệt kê t rong c ột 
nguy cơ TTHKTM trung bình / cao  Nguy cơ TTHKTM trung bình ho ặc cao  
Bệnh nhân tr ải qua các th ủ thuật chỉnh hình 
khác v ới một hoặc nhi ều YTNC sau:  
− Ung thư đang ho ạt động ho ặc điều trị 
− Thrombophilia hoăc ti ền sử TTHKTM cá 
nhân/gia đình  
− Đang mang tha i hoặc hậu sản 
− Phẫu thu ật kéo dài hơn 120 phút  
− ≥ 60 tu ổi 
− BMI ≥ 40 kg/m2 
− Bất động trư ớc mổ ít nhất 4 ngày  
− Suy tĩnh m ạch m ạn tính  
Không khuy ến cáo d ự phòng TTHKTM. 
Khuy ến khích đ ảm bảo đủ nước và v ận 
động sớm Khởi động GCS ho ặc IPC khi nh ập viện và 
tiếp tục đến khi BN xu ất viện  
VÀ/HO ẶC 
Cân nh ắc sử dụng Heparin TLPTT  
 
 
 
 
 
 
 
 
 
 
 
 
 syt_bacgiang_vt_Van thu SYT Bac Giang_23/10/2023 11:45:0746 
 
CHƯƠNG 9. DỰ PHÒNG  THUYÊN TẮC  HUYẾT KHỐI TĨNH MẠCH Ở 
BỆNH NHÂN SẢN PHỤ KHOA  
 
1.Dự phòng TTHKTM ở bệnh  nhân  phẫu thuật phụ khoa:   
(xem Chương  6. Dự phòng thuyên t ắc huy ết khối tĩnh mạch ở bệnh nhân ngo ại khoa chung ) 
2.Dự phòng TTHKTM ở bệnh  nhân  sản khoa  
2.1. Đại cương   
Phụ nữ mang thai ho ặc trong th ời kỳ hậu sản có nguy cơ m ắc bệnh huy ết khối cao g ấp 
4-5 lần so v ới phụ nữ không mang thai. Kho ảng 80% các trư ờng hợp huy ết khối trong  
thai k ỳ là huy ết khối tĩnh m ạch, chi ếm tỉ lệ 0,5-2,0/1.000 s ản ph ụ. Bệnh thuyên t ắc 
huyết khối tĩnh m ạch (TTHKTM) là m ột trong nh ững nguyên nhân hàng đ ầu gây t ử 
vong m ẹ tại Hoa K ỳ, chiếm 9,3% t ổng số ca tử vong m ẹ. 
Trong các lo ại TTHKTM trong thai k ỳ: HKT MS  chi ếm 75 -80%, TTP chi ếm 20 -25%. 
TTHKTMS trong thai k ỳ thường liên quan đ ến chi dư ới bên trái nhi ều hơn so v ới bên 
phải. 
Về sinh lý b ệnh: Cơ ch ế hình thành huy ết khối tĩnh m ạch là do s ự phối hợp của 3 y ếu 
tố: ứ trệ tuần hoàn tĩnh m ạch, r ối loạn quá trìn h đông máu gây tăng đông và t ổn 
thương thành m ạch. Các thay đ ổi sinh lý và gi ải phẫu trong thai k ỳ làm tăng nguy cơ 
TTHKTM bao g ồm tăng đông máu, tăng ứ trệ tĩnh m ạch, gi ảm lưu lư ợng tĩnh m ạch, 
đè ép tĩnh m ạch ch ủ dưới và tĩnh m ạch ch ậu do s ự lớn lên c ủa tử cung và gi ảm kh ả 
năng  vận động của sản phụ. Thai k ỳ cũng làm tăng đông và làm thay đ ổi nồng độ của 
các y ếu tố đông máu.  
2.2. Các yếu tố nguy cơ (YTNC)  
Nguy cơ TTHKTM xu ất hiện từ đầu thai k ỳ và tăng lên vào 3 tháng cu ối thai k ỳ. Nguy 
cơ TTHKTM trong giai  đoạn hậu sản cao hơn trong thai k ỳ, đặc biệt trong tu ần 1 giai 
đoạn hậu sản. 
- Tiền sử bị huyết khối: đây là YTNC quan tr ọng nh ất, nguy cơ TTHKTM tái phát 
trong thai k ỳ tăng 3 -4 lần. 15 -25% các trư ờng hợp TTHKTM trong thai k ỳ là do tái 
phát.  
- Bệnh lý tăng đô ng m ắc ph ải hoặc di truy ền: chi ếm 20 -25% các trư ờng h ợp 
TTHKTM trong thai k ỳ và giai đo ạn hậu sản. 
- Các YTNC khác: b ệnh tim, b ệnh lý hemoglobin, tăng huy ết áp, ti ền sản giật, 
hội chứng th ận hư, lupus ban đ ỏ hệ thống, m ổ lấy thai, băng huy ết sau sinh, 
nghén nặng, truy ền máu, thai lưu, nhi ễm trùng h ậu sản, hỗ trợ sinh s ản, đa 
thai, sinh non, tu ổi >35,  béo phì (BMI >30 kg/m2), hút thu ốc lá (> 10 
điếu/ngày), b ất động th ời gian đài...  
 
 syt_bacgiang_vt_Van thu SYT Bac Giang_23/10/2023 11:45:0747 
2.3. Dự phòng thuyên tắc huyết khối tĩnh mạch ở bệnh nh ân sản khoa  
2.3.1. Quy trình ch ẩn đoán và x ử trí: 
Sơ đồ 3: Quy trình đánh giá và x ử trí TTHKTM ở bệnh nhân s ản khoa  
 Đánh giá nguy cơ trư ớc sinh  
Nguy cơ cao (≥ 4 điểm)  Nguy cơ trung bình (3 điểm)  Nguy c ơ thấp (≤ 2 điểm)  
Không dự phòng TTHKTM bằng 
thuốc: tránh mất nước, vận động 
sớm 
 ± mang vớ áp lực y khoa  Dự phòng TTHKTM bằng thuốc 
khi thai 28 tuần  Dự phòng TTHKTM bằng thuốc 
ngay  
Tiếp tục thuốc kháng đông dự 
phòng trong 3 -6 tuần  Tiếp tục thuốc khá ng đông dự 
phòng trong 3 tuần  Đánh giá nguy cơ TTHKTM  
≤ 2 điểm  ≥ 4 điểm  3 điểm  
-  Vận động sớm  
 ± Mang vớ áp lực  
- Tránh mất nước  Thuốc kháng đông dự phòng  
trong 10 ngày  Thuốc kháng đông dự phòng  
trong 3 tuần  Đánh giá nguy cơ sau sinh  B3: Lựa ch ọn biện 
pháp và thời gian 
dự phòng  B1, B2: Đánh giá 
nguy cơ huyết 
khối và xuất huyết  
B4: Tái đánh giá 
và dự phòng giai 
đoạn hậu sản  syt_bacgiang_vt_Van thu SYT Bac Giang_23/10/2023 11:45:0748 
 
2.3.2 . Đánh giá nguy cơ huy ết khối 
Bảng 29: Thang đi ểm đánh giá nguy cơ TTHKTM trư ớc và sau sinh  
 
Yếu tố n guy cơ TTHKTM  Điểm  
NGUY  CƠ ĐÃ TỒN TẠI TỪ TRƯỚC  
Tiền sử TTHKTM (trừ biến cố TTHKTM đơn độc liên quan đến đại phẫu)  4 
Tiền sử TTHKTM khởi phát sau đại phẫu  3 
Nguy cơ cao bệnh lý tăng đông đ ã biết (**) 3 
Bệnh lý kèm theo: ung thư , suy tim, lupus ban đỏ hệ t hống đang hoạt động,  
viêm  đa khớp, viêm ruột , HC thận hư, đ ái tháo đường type 1 biến chứng 
thận, người được truyền thuốc qua TM  3 
Tiền sử gia đình bị TTHKTM  1 
Nguy cơ thấp bệnh lý tăng đông (không có TTHKTM) (*)  1 (a) 
Tuổi > 35  1 
Béo phì  
BMI ≥ 40 kg/m2 
BMI ≥ 30 -39 kg/m2  
2 
1 
Sinh ≥ 3 con  1 
Hút thuốc lá  1 
Có giãn tĩnh mạch lớn  1 
NGUY CƠ SẢN KHOA  
Mổ lấy thai trong chuyển dạ  2 
Mổ lấy thai chủ động  1 
Tiền sản giật  trong thai kì này  1 
Hỗ trợ sinh sản/ Thụ tinh trong ống nghiệm ( yếu tố trước sinh)  1 
Đa thai  1 
Sinh thủ thuật  1 
Chuyển dạ kéo dài ( > 24 giờ)  1 
Băng huyết sau sinh ( > 1L máu) hoặc cần truyền máu  1 
Sinh non < 37 tuần trong thai kỳ này  1 
Thai lưu (hiện tại)  1 
NGUY CƠ THOÁNG QUA  
HC quá kích buồng trứng ( chỉ trong 3 tháng đầu)  4 
Bất kỳ phẫu thuật thủ thuật nào trong thai kỳ hay thời kỳ hậu sản ngoại trừ 
cắt khâu tầng sinh môn , mổ ruột thừa, triệt sản sau sinh …
  3 
Nôn nhiều  3 
Bất động (***)/mất nước  1 
Nhiễm trùng toàn thân, nhiễm trùng hậu sản  1 syt_bacgiang_vt_Van thu SYT Bac Giang_23/10/2023 11:45:0749 
 
Lưu ý:  
- Khuyến cáo sử dụng kháng  đông dự phòng huyết khối trong giai đoạn sản phụ có 
các nguy cơ thoáng qua, cân nhắc dừng thuốc khi không còn các nguy cơ này.  
- Các thời điểm cần đánh giá nguy cơ: trước khi mang thai, khi mang thai, lúc nhập 
viên hoặc khi xuất hiện các bệnh lý kèm theo,  ngay sau sinh.  
- BN có nguy cơ chảy máu đã được xác định, cân bằng giữa chảy máu và nguy cơ 
nên được thảo luận cùng BS Huyết học, BS  tim mạch, hồi sức cấp cứu có kinh 
nghiệm về TTHKTM và chảy máu liên quan thai kỳ.  
- BN nhập viện trước sinh nên được xem x ét dự phòng TTHKTM. BN nằm viện ≥ 3 
ngày hoặc tái nhập viện trong thời kỳ hậu sản nên được xem xét dự phòng 
TTHKTM.  
(*) Nguy cơ thấp bệnh lý tăng đông : yếu tố dị hợp tử V Leiden; đột biến dị hợp tử 
prothrombin gen G20210A  
(**) Nguy cơ cao bệnh lý tăng đông : hội chứng kháng phospholipid, đồng hợp tử 
yếu tố V Leiden; đột biến đồng hợp tử prothrombin gen G20210A; thiếu 
antithrombin, thiếu hụt protein C hoặc protein S.  
(***) Bất động : đa số thời gian nằm tại giường (≥ 24 giờ) hoặc có các y ếu tố khác 
như: liệt 2  chi dưới  
(a) Nếu phụ nữ có bệnh lý tăng đông nguy cơ thấp và có tiền sử gia đình (trực hệ) 
mắc TTHKTM thì nên tiếp tục điều trị dự phòng TTHKTM sau sinh trong 6 tuần.  
2.3.3 . Đánh giá nguy cơ xu ất huy ết 
(Xem Bảng 16. Bảng chống chỉ định thuốc kháng đông)  
2.3.4 . Lựa chọn các bi ện pháp d ự phòng  
2.3.4 .1. Biện pháp dự phòng dược lý  
a- Heparin tr ọng lư ợng phân t ử thấp: Li ều dự phòng TTHKTM  
Bảng 30: Li ều LMWH trong d ự phòng TTHKTM ở bệnh nhân s ản khoa theo cân n ặng 
Theo dõi:  
- Đánh giá ti ểu cầu và creatinin huy ết thanh trư ớc điều trị 
- Không theo dõi anti -Xa th ường quy tr ừ các trư ờng hợp cân n ặng < 50 kg ho ặc > 90 
kg. M ục tiêu: n ồng đ ộ anti-Xa đ ạt 0,6 -1,0 đv/mL th ời điểm 4 gi ờ sau mũi tiêm 
cuối. 
+ Xét nghi ệm tiểu cầu mỗi lần khám thai  Cân n ặng hi ện tại (kg)  Enoxaparin ( heparin tr ọng lư ợng phân t ử thấp) 
<50 20 mg x 1 l ần /ngày  
50-90 40 mg x 1 l ần /ngày  
91-130 60 mg x 1 l ần /ngày  
131-170 80 mg x 1 l ần /ngày  
> 170  0,6 mg/kg x 1 l ần /ngày  syt_bacgiang_vt_Van thu SYT Bac Giang_23/10/2023 11:45:0750 
 
+ Trường hợp ngư ời bệnh suy th ận: cần giảm liều LMWH 30 mg x 1 lần/ngày 
TDD (v ới cân n ặng 50 -90 kg và MLCT 15-29 mL/phút) ho ặc chuy ển sang 
Heparin không phân đo ạn (cần hội chẩn chuyên khoa)  
b- Heparin không phân đo ạn: 
Bảng 31: Li ều UFH trong d ự phòng TTHKTM ở bệnh nhân s ản khoa theo cân n ặng 
Cân n ặng hi ện tại (kg)  Heparin không phân đo ạn (TDD)  
<50 Cân nh ắc giảm liều 
50-90 5.000 đv m ỗi 12 gi ờ 
>90 7.500 đv m ỗi 12 gi ờ 
Theo dõi:  
- Cần theo dõi n ội trú 
- Cần theo dõi ti ểu cầu mỗi 2-3 ngày t ừ ngày 4 -14 đến khi ng ừng sử dụng Heparin.  
 c- Fondaparinux  
- Không đ ủ dữ liệu dùng trong thai k ỳ vì thu ốc qua đư ợc nhau thai và bài ti ết  
qua s ữa mẹ, chỉ dùng trong trư ờng hợp sản phụ dị ứng nặng với Heparin.  
- Thời gian bán h ủy dài và không có thu ốc đối kháng.  
2.3.4 .2. Các biện pháp dự phòng TTHKTM không dùng thuốc  
a- Vận động th ể lực phù h ợp theo kh ả năng c ủa ngư ời bệnh, nên v ận động sớm sau 
sinh, sau ph ẫu thu ật. 
b- Tránh m ất nước, nhu c ầu lượng dịch vào  cơ th ể: 
- Đối với phụ nữ mang thai:  > 2,3 lít/ngày  
- Đối với phụ nữ cho cho con bú: > 2,6 lít/ngày  
c- Các bi ện pháp cơ h ọc: 
Chỉ định cho ngư ời bệnh cần dự phòng  huyết khối tĩnh m ạch nhưng có nguy cơ xu ất 
huyết cao ho ặc chống ch ỉ định dùng kháng đông, c ần phối hợp hoặc chuy ển sang các 
biện pháp dư ợc lý ngay khi nguy cơ xu ất huy ết giảm. 
Các bi ện pháp cơ h ọc gồm: 
- Tất, băng chun áp l ực y khoa  
- Thiết bị bơm hơi áp l ực ngắt quãng  
Chống ch ỉ định của các bi ện pháp cơ h ọc: 
- Biến dạng chân nghiêm tr ọng ho ặc béo phì n ặng không th ể dùng v ớ áp lực 
- Bệnh th ần kinh ngo ại biên nghiêm tr ọng 
- Bệnh lý m ạch máu ngo ại biên nghiêm tr ọng ho ặc loét  
- Mới phẫu thu ật ghép da  
- Phẫu thu ật bắc cầu mạch máu ngo ại biên  syt_bacgiang_vt_Van thu SYT Bac Giang_23/10/2023 11:45:0751 
 
- Phù chân n ặng ho ặc phù ph ổi do suy tim sung huy ết 
- Dị ứng với các v ật liệu cơ h ọc 
- Các v ấn đề tại chỗ ở chân: ho ại thư, viêm da, v ết thương nhi ễm trùng chưa đi ều trị... 
2.3.5 . Một số lưu ý khi d ự phòng TTHKTM ở BN S ản khoa  
2.3.5 .1. Điều trị khi sinh  
- Có thể cân nh ắc chuyển đổi từ Heparin tr ọng lư ợng phân t ử thấp sang Heparin  
không phân đo ạn khi s ản phụ nhập viện và ch ờ chấm dứt thai k ỳ. 
- Ngừng thu ốc kháng đông d ự phòng ít nh ất 12 gi ờ trước khi kh ởi phát chuy ển dạ 
nếu lâm sàng cho phép. N ếu thời gian s ử dụng Heparin > 4 ngày, xét nghi ệm tiểu 
cầu trư ớc khi kh ởi phát chuy ển dạ hoặc khi s ản phụ chuy ển dạ. 
- Nếu sản phụ đã ng ừng Heparin, c ần sử dụng thi ết bị bơm hơi áp l ực ngắt quãng.  
- Cần đề phòng băng huy ết sau sinh.  
- Ngừng sử dụng thu ốc kháng đông ( nếu lâm sàng cho phép) khi s ản phụ có dấu hiệu 
chuy ển dạ hoặc ra máu âm đ ạo. 
2.3.5 .2. Mổ lấy thai  
- Ngừng thu ốc kháng đông 24 gi ờ trước khi m ổ lấy thai n ếu lâm sàng cho phép.  
- Nếu sản phụ đang dùng li ều kháng đông đi ều trị và cần mổ lấy thai, cân nh ắc đặt 
dẫn lưu sau m ổ. 
- Khuy ến cáo s ử dụng thi ết bị bơm hơi áp l ực ngắt quãng trư ớc khi m ổ lấy thai và 
cần vận động sớm sau m ổ. 
2.3.5 .3. Phương pháp vô c ảm 
Khoảng cách th ời gian gi ữa việc dùng thu ốc kháng đông và tê t ủy sống/tê ngoài màng 
cứng 
Bảng 32: Th ời gian gi ữa việc dùng thu ốc kháng đông và gây tê t ủy sống/gây tê ngoài 
màng c ứng 
Khoảng cách thời gian giữa  Heparin 
TLPPT  Heparin  
không phân đoạn  
Liều thuốc kháng đông gần nhất và gây tê  12 giờ  4 giờ  
Gây tê và tái sử dụng thuốc kháng đông  4 giờ  1 giờ  
(*) Lưu ý: Khoảng cách th ời gian trên ch ỉ áp dụng khi s ản phụ dự phòng TTHKTM 
bằng Heparin không phân đo ạn  với liều 5.000 đv  2 l ần/ngày, c ần xét nghi ệm aPTT 3 -
4 giờ sau li ều cuối. 
- Cần theo dõi bi ến chứng máu t ụ trong vòng 24 gi ờ sau t ủy sống/tê ngoài màng 
cứng ho ặc sau khi rút catheter ngoài màng c ứng. 
2.3.5 .4. Giai đo ạn hậu sản 
- Để hạn chế biến chứng xu ất huy ết sau sinh, thu ốc kháng đông nên đư ợc tiếp tục sử 
dụng sớm nh ất là 4 -6 giờ nếu sinh đư ờng âm đ ạo và 6 -12 gi ờ sau m ổ lấy thai.  
- Thận trọng khi dùng thu ốc kháng viê m không steroid do tăng nguy cơ xu ất huy ết 
tiêu hóa.  syt_bacgiang_vt_Van thu SYT Bac Giang_23/10/2023 11:45:0752 
 
- Nếu có ch ỉ định tiếp tục sử dụng thu ốc kháng đông sau sinh, s ản phụ nên đư ợc sử 
dụng thi ết bị bơm hơi áp l ực ngắt quãng t ại chỗ đến khi có th ể đi lại và dùng kháng 
đông.  
2.3.5 .5.  Biện pháp  tránh thai  
- Nguy cơ TTHKTM  tăng 35 -99 lần ở phụ nữ có đột biến đồng h ợp tử yếu tố V 
Leiden, tăng 16 l ần ở phụ nữ bị đột biến prothrombin G20210A khi dùng thu ốc 
tránh thai ph ối hợp có estrogen.  
- Các bi ện pháp tránh thai  có th ể áp d ụng thay cho viên tránh thai ph ối hợp có  
estrogen là : dụng c ụ tử cung, thu ốc viên tránh thai ch ỉ chứa progestin, Depot 
Medroxy progesterone acetate DMPA, que c ấy tránh thai, d ụng cụ tử cung, bao cao 
su.  
 
 
 
syt_bacgiang_vt_Van thu SYT Bac Giang_23/10/2023 11:45:0753 
 
CHƯƠNG  10. HƯỚNG D ẪN XỬ TRÍ BI ẾN CH ỨNG XU ẤT HUY ẾT Ở BỆNH 
NHÂN DÙNG KH ÁNG ĐÔNG  
 
1. Xuất huyết lớn  
- Tỷ lệ biến chứng xu ất huy ết sau dùng thu ốc kháng huy ết khối dao đ ộng từ 1-10% 
- -Căn c ứ phân lo ại xuất huy ết: theo ISTH (International society on thrombosis and 
hemostasis), và BARC (Bleeding Academic Research Consortium)  
- -Xuất huy ết được phân chia t hành các m ức độ: Xuất huy ết đe d ọa tính m ạng, xu ất 
huyết mức độ nặng, xu ất huy ết mức độ vừa và nh ẹ 
 
Bảng 33: B ảng phân chia các m ức độ xuất huy ết 
Xuất huyết mức nguy hiểm 
đến tính mạng  − Xuất huyết gây mất> 50g/l hemoglobin; phải truyền≥5 
đơn vị khối hồng cầ u hoặc máu toàn phần trong vòng 
48h; mất máu qua catheter≥2l/24h; mất >150ml/phút.  
− Cần truyền vận mạch  
− Xuất huyết sau phẫu thuật bắc cầu mạch vành; phải phẫu 
thuật lại sau phẫu thuật cắt tử cung cầm máu;  
− Có dấu hiệu ép tim cấp;  
Xuất huyết mức độ nặng  − Xuất huyết gây  mất>=2 0g/l Hb ; phải truyền>2 đơn vị 
khối hồng cầu hoặc máu toàn phần  
− Xuất huyết ở những vùng trọng yếu bao gồm: não (mô 
não, xuất huyết dưới màng cứng, ngoài màng cứng, 
khoang dưới nhện) ; tủy sống; ngoại tâm mạc; nội nhãn;  
− Xuất huy ết trong  đường thở; xu ất huyết trung thất; trong 
ổ bụng,  phúc mạc; nội khớp; xuất huyết trong cơ gây hội 
chứng khoang … 
− Xuất huyết niêm mạc cần phẫu thuật hoặc can thiệp cầm 
máu (với các vị trí như răng, mũi, da, trĩ…)  
 Xuất huyết mức độ trung 
bình Xuất huyết ti êu hóa, mất <20g/l huyết sắc tố  
Xuất huyết mức độ nhẹ  Xuất huyết dưới da và niêm mạc, mất <20g/l huyết sắc tố  
 
2.  Các bước xử lý xu ất huy ết do quá li ều kháng đông   
2.1. Các bư ớc thực hiện khi b ệnh nhân có bi ến cố xuất huy ết (bảng 19)  
Lưu ý: luôn ph ải đánh giá song song nguy cơ huy ết khối và nguy cơ xu ất huy ết tái 
phát 
 syt_bacgiang_vt_Van thu SYT Bac Giang_23/10/2023 11:45:0754 
 
Bảng 34: Các bư ớc xử trí bi ến chứng xu ất huy ết do quá li ều thu ốc kháng đông  
BƯỚC 1: ĐÁNH 
GIÁ MỨC ĐỘ 
XUẤT HUYẾT  
(Nếu có sẽ chuyển 
sang bước 2)  XUẤT HUYẾT ĐE DỌA TÍNH MẠNG:  
− Sốc.  
− Mất > 5g/dl hemoglobin  
− Truyền  ≥ 5 đơn vị máu toàn phần hoặc khối hồng cầu trong 
vòng 48h; mất máu qua catheter  ≥ 2l/24h  
XUẤT HUYẾT NẶNG:  
− Huyết động không ổn định. Mất  > 2g/dl hemoglobin. Xuất 
huyết ở vị trí quan  trọng (xin xem bảng 1).  
− Phải truyền ít nhất 2 đơn vị khối hồng cầu hoặc máu toàn 
phần  
XUẤT HUYẾT MỨC ĐỘ TRUNG BÌNH HOẶC NHẸ:  
- Xem bảng 1  
BƯỚC 2: XỬ TRÍ  VỚI XUẤT HUYẾT MỨC ĐỘ ĐE DỌA TÍNH MẠNG 
HOẶC NẶNG:  
− Ngừng thuốc kh áng đông. Xác định thời gian dùng liều cuối  
− Uống than hoạt nếu BN dùng liều cuối <  4h (tr ánh áp dụng 
cho trường hợp xuất huyết tiêu hóa cao do gây cản trở thủ 
thuật nội soi cầm máu)  
− Xét nghiệm đông máu (PT, APTT, fibrinogen, số lượng tiểu 
cầu, Rotem và XN đặc hiệu cho từng loại kh áng đô ng*), chức 
năng thận  
− Chỉ định chất hóa giải trường hợp xu ất huy ết đe dọa tính 
mạng.  
(Idaruxizumab với bn dùng Dabigatran. Vitamin K với B N 
dùng kháng vitamin K. Protamin với bệnh nhân dùng nhóm 
Heparin. Truyền khối tiểu cầu với B N dùng thuốc kháng 
ngưng tập tiểu cầu hoặc giảm tiểu cầu do xu ất huyết nặng. 
(Liều lượng cụ thể xin xem ở sơ đồ 1)  
− Nếu không có  chất hóa giải đặc hiệu: sử dụng PCC  
(Prothrombin complex  concentrate ), aPCC  (activated 
prothrombin complex concentrate) , huyết tương tươi đông 
lạnh, vitamin K, khối tiểu cầu (tùy loại thuốc BN dùng và tình 
trạng cụ thể. Liều lượng xem sơ đồ 1)  
− Phối hợp các chuyên khoa để cầm máu (ví dụ nội soi cầm 
máu nếu xu ất huyết dạ dày, phẫu thuật lại …) 
− Có thể xem xét dùng VIIa, transamin hoặc lọc máu (với bệnh 
nhân dùng dabigatran). Cần cân nhắc nguy cơ huyết khối ở 
BN cụ thể.  
− Đảm bảo huyết động  
− Truyền khối hồng cầu theo mức độ mất máu  syt_bacgiang_vt_Van thu SYT Bac Giang_23/10/2023 11:45:0755 
 
Bảng 1  VỚI XUẤT HUYẾT MỨC ĐỘ TRUNG BÌNH  
− Ngừng thuốc  
− Xét nghiệm  
− Phối hợp các biện pháp cầm máu tại chỗ  
− Với BN dùng kháng vitamin K, INR ở mức 4,5 -8: cho uống 
vitamin K hoặc dùng tĩnh mạch 2,5mg  
Có thể chuyển sang kh áng đông đường tiêm liều thấp nếu 
nguy cơ huyết khối cao  
− Truyền khối hồng cầu nếu BN thiếu máu  
− Theo dõi sát tình trạng lâm sàng và chức năng thận  
− Có thể sử dụng Tranxamin  
VỚI XUẤT HUYẾT MỨC ĐỘ NHẸ  
− Ngừng thuốc  
− Theo dõi BN 
Dùng c ác biện pháp cầm máu tại chỗ (với xuất huyết niêm 
mạc)  
BƯỚC 3: DÙNG 
LẠI KHÁNG 
ĐÔNG  SỬ DỤNG LẠI KHI: BN ổn định, vẫn có chỉ định dùng 
thuốc kháng đông. KHÔNG CÓ ≥ 1 yếu tố trong các yếu tố 
dưới đây:  
− Xuất huyết vùng trọng yếu  
− Nguy cơ tái xuất huyết cao  
− Nguy ên nhân xuất huyết chưa xác định  
− BN cần phẫu thuật  
− BN không muốn dùng lại kháng đông  
 *Các xét nghi ệm đông máu đ ặc hiệu: 
Bệnh nhân dùng kháng vitamin K: PT, INR  
Bệnh nhân dùng Heparin tiêu chu ẩn: APTT, Anti Xa, ACT  
Bệnh nhân dùng Heparin tr ọng lư ợng phân tử thấp và fondaparinux: anti Xa  
Bệnh nhân dùng rivaroxaban, apixaban: anti Xa đ ặc hiệu 
Bệnh nhân dùng dabigatran: APTT, dTT, ECA, ECT  syt_bacgiang_vt_Van thu SYT Bac Giang_23/10/2023 11:45:0756 
Sơ đồ 4: Các bư ớc xử trí ở bệnh nhân xu ất huy ết lớn sau dùng thu ốc kháng đông  
BN Xu ất huy ết nặng ho ặc đe d ọa tính m ạng 
 
BN Xu ất huy ết nặng ho ặc đe d ọa tính m ạng Xem lại loại kháng đông  BN đang dù ng, thời điểm dùng  
 
Xem lại loại kháng đông  BN đang dùng, thời điểm dùng  
Kháng Vitamin K  
4FPCC:  
INR 2 -<4: 25UI/kg  
INR 4 -6: 35UI/kg  
INR>6: 50UI/kg  
Hoặc có thể dùng liều cố 
định -1,000 UI với các 
trường hợp xuất huyết  nặng 
không phải xuất huyết não  
 -1,500 với trường hợp xuất 
huyết não.  
Nếu không có 4F -PCC sử 
dụng huyết tương tươi đông 
lạnh 10 –15 mL/kg  
 
Kháng Vitamin K  
4FPCC:  
INR 2 -<4: 25UI/kg  
INR 4 -6: 35UI/kg  
INR>6: 50UI/kg  
Hoặc có thể dùng liều cố 
định -1,000 UI với các 
trường hợp xuất huyết  nặng 
không phả i xuất huyết não  Kháng Xa 
(apixaban và 
rivaroxaban)  
+Có thể dùng 
PCC hoặc aPCC  
  
Kháng IIa  
+idarucizumab 
5g, tĩnh m ạch.  
+Có th ể dùng 
PCC ho ặc aPCC  
+ Có th ể xem xét 
dung than ho ạt 
tính n ếu thu ốc 
dùng trong vòng 
2-4h  
 
 
Kháng IIa  
+idarucizumab 
5g, tĩnh m ạch.  
+Có th ể dùng 
PCC ho ặc aPCC  
+ Có th ể xem xét 
dung than ho ạt 
tính n ếu thu ốc 
dùng trong vòng Kháng IIa  
+idarucizumab 
5g, tĩnh m ạch.  
+Có th ể dùng 
PCC ho ặc aPCC  
+ Có th ể xem xét 
dung than ho ạt 
tính n ếu thu ốc 
dùng trong vòng 
2-4h  
 Nhóm ức chế 
gián ti ếp 
(Heparin , 
LMWH, 
fondaparinux)  
Protamin  
 
 
   
 Kháng ngưng t ập tiểu cầu 
Truy ền 1-2 đơn v ị khối tiểu 
cầu từ 1 ngư ời cho ho ặc tiểu 
cầu pool.  
Trường hợp só lư ợng tiểu 
cầu thấp, cần duy trì s ố lượng 
tiểu cầu>75G/l ho ặc >100G/l 
ở bệnh nhân đa ch ấn thương 
hoặc xuất huy ết não và n ội 
nhãn.  
 
Kháng ngưng t ập tiểu cầu 
Truy ền 1-2 đơn v ị khối tiểu 
cầu từ 1 ngư ời cho ho ặc tiểu 
cầu pool.  
Trường hợp só lư ợng tiểu 
cầu thấp, cần duy trì s ố lượng 
tiểu cầu>75G/l ho ặc >100G/l 
ở bệnh nhân đa ch ấn thương 
hoặc xuất huy ết não và n ội 
nhãn.   
 
BN có xu ất huy ết nặng, đe d ọa tính 
mạng, sau can thi ệp cầm máu  
 
 
BN có xu ất huy ết nặng, đe d ọa tính 
mạng, sau can thi ệp cầm máu  
 
 
BN có xu ất huy ết nặng, đe d ọa tính 
mạng, sau can thi ệp cầm máu  Sử dụng lại thu ốc kháng đông khi tình tr ạng bệnh nhân ổn định (xem ph ần 3) 
 
 syt_bacgiang_vt_Van thu SYT Bac Giang_23/10/2023 11:45:0757 
 
2.2. M ột số trường hợp cụ thể đặc biệt 
2.2.1. Xu ất huy ết não  
- Nguy cơ xu ất huy ết não ở bệnh nhân dùng thu ốc kháng vitamin K (cao hơn so v ới 
các b ệnh nhân dùng DOACs (kho ảng 16% trong vòng 30 ngày)  
- Nhanh chóng xác đ ịnh vị trí và m ức độ tổn thương não b ằng ch ẩn đoán hình ảnh  
- Với các ổ kích thư ớc lớn, vị trí trọng yếu, nguy cơ lan r ộng cần nhanh chóng dùng 
thuốc đảo ngư ợc 
- Có th ể sử dụng xét nghi ệm ROTEM  và antiXa đ ể theo dõi v ới những trư ờng hợp 
dùng nhóm thu ốc kháng tr ực tiếp Xa  
Với bệnh nhân đang s ử dụng Heparin tiêu chu ẩn: 
 Dừng thuốc.  
 Tiêm tĩnh m ạch 1mg protamine cho mỗi 100 UI Heparin đang dùng (tối đa 
50 mg protamine)  
 Nếu liều cuối cùng dùng trước đó 30 phút thì giảm ½ liều protamin e→ 0,5 mg 
protamine tĩnh mạch cho mỗi 100 UI Heparin.  
 Nếu liều cuối cùng dùng trước đó >2  h → 0,25 mg protamine tiê m TM cho mỗi 
100 UI Heparin.  
Với bệnh nhân đang s ử dụng Heparin tr ọng lư ợng phân t ử thấp: 
 Liều cuối cùng trong vòng 8  h → 1 mg protamine tĩnh mạch cho mỗi 100 UI 
Heparin đang dùng (tối đa 50  mg protamine)  
 Liều cuối cùng trong vòng 8 -12h→  0,5 mg protamine t ĩnh mạch cho mỗi 100 
UI Heparin.  
 Liều cuối cùng >12  h → chỉ sử dụng protamine khi bệnh nhân có suy thận  
Lưu ý: Adexanet có thể được sử dụng như thuốc đảo ngược tác dụng của Heparin 
trọng lượng phân tử thấp  
Với bệnh nhân đang s ử dụng kháng vitamin K  
 Ngừng t huốc  
 *Kiểm tra INR, truyền 4PCC hoặc 3PCC  điều chỉnh như sau  
INR 1.5 –1.9 → PCC 10 UI/kg (tối đa 1000 UI)  
INR 2.0 –3.9 → PCC 25 U/kg (tối đa 2500 UI)  
INR 4.0 –5.9 → PCC 35 U/kg (tối đa 3500 UI)  
INR > 6.0 → PCC 50 U/kg (tối đa 5000 UI)  
     Trường hợp không có  PCC, có thể truyền huyết tương tươi đông lạnh liều 10 -
20ml/kg.  
Với bệnh nhân đang dùng Dabigatran  
 Dừng thuốc  
 idarucizumab 5g tĩnh mạch  syt_bacgiang_vt_Van thu SYT Bac Giang_23/10/2023 11:45:0758 
 
 Nếu không có idarucizumab, có thể sử dụng 4FPCC 25 -50UI/kg, aPCC 
50UI/kg  
 Có thể cho uống 50g than hoạt nếu liều cuối sử dụng <2h  
 Có thể lọc thận  
 Cân nhắc dùng rFVIIa (20 –90 mcg/kg) or huyết tương tươi đông lạnh nhất là 
trường hợp huyết áp tụt do mất máu  
Với bệnh nhân đang dùng rivaroxaban, apixaban, endoxaban  
 Dừng thuốc  
 4FPCC 25 -50UI/kg, aPCC 50UI/kg  
Có thể cho uống 50g th an hoạt nếu liều cuối sử dụng <2  
Cân nhắc dùng rFVIIa (20 –90 mcg/kg) or huyết tương tươi đông lạnh, nhất là 
trường hợp huyết áp tụt do mất máu  
Trường hợp bệnh nhân trư ớc đó có s ử dụng tPA  
 Truyền cryo để nâng fibrinogen  > 150 mg/dL.  
 Nếu không có cryo có th ể xem xét dùng các thuốc chống tiêu sợi huyết  
Aminocaproic acid: 4  g IV truyền tĩnh mạch trong 60 phút, sau đó 1  g/h trong 
8 h. 
Hoặc  
Tranexamic acid: 10  mg/kg mỗi 6  h trong 24  h 
Luôn theo dõi sát vì có thể có nguy cơ huyết khối.  
2.2.2. Bệnh nhân đa chấn thương:  
- Bệnh nhân đa ch ấn thương có th ể có suy đa t ạng, tiêu s ợi huy ết, giảm tiểu cầu..Vì 
vậy cần nhanh chóng s ử dụng các bi ện pháp can thi ệp cơ h ọc song song v ới dùng 
chất hóa gi ải và ho ặc truy ền các ch ế phẩm máu, y ếu tố đông máu, huy ết tương.  
- Sử dụng XN  ROTEM đánh giá m ức độ và số lượng ch ế phẩm cần truy ền. 
- Sử dụng các thu ốc chống tiêu s ợi huy ết như tranexamic acid.  
- Theo dõi sát xét nghi ệm đông máu và ti ểu cầu mỗi 6h, đ ảm bảo duy trì s ố lượng 
tiểu cầu>50G/l  
2.2.3. B ệnh nhân đang dùng thu ốc chống ngưng t ập tiểu cầu: 
- Dừng thu ốc 
- Trường hợp xuất huy ết nặng ho ặc đe d ọa tính m ạng: truy ền khối tiểu cầu, tốt nhất 
là kh ối tiểu cầu từ một ngư ời cho: 1 -2 đơn v ị 
- Theo dõi và cân nh ắc truy ền tiếp theo tình tr ạng xu ất huy ết 
3. Sử dụng lại kháng đông   
3.1. Đánh giá b ệnh nhân trư ớc khi ch ỉ định dùng l ại thu ốc kháng đông  
- Biến chứng xu ất huy ết là tác d ụng ph ụ nguy hi ểm nh ất của các thu ốc kháng đông 
kháng k ết tập tiểu cầu sử dụng trong đi ều trị và dự phòng các b ệnh lý huy ết khối. syt_bacgiang_vt_Van thu SYT Bac Giang_23/10/2023 11:45:0759 
 
Tuy nhiên, n ếu ngưng s ử dụng các thu ốc kháng đông và kháng k ết tập tiểu cầu lâu 
dài do bi ến chứng xu ất huy ết, bệnh nhân có nguy cơ g ặp biến chứng của huy ết 
khối. Do v ậy, cần có m ột chiến lược rõ ràng đ ể điều trị lại các thu ốc kháng đông và 
kháng k ết tập tiểu cầu sau xu ất huy ết.  
- Cần phải đán h giá nguy cơ huy ết khối và nguy cơ xu ất huy ết dựa trên các thang 
điểm sau:  
Đánh giá nguy cơ huy ết khối dựa vào các b ảng 8,14,15,19  
Đánh giá nguy cơ xu ất huy ết dựa vào b ảng 9,16  
Bảng 35: B ảng phân nhóm nguy cơ huy ết khối động m ạch 
Nhóm  
nguy cơ  Nguy cơ huyết khối đối với bệnh 
mạch vành  Nguy cơ huyết khối đối 
với rung nhĩ/van cơ học  
Rất cao  Hội chứng vành cấp (HCVC) hoặc 
can thiệp mạch vành đặt stent có 
phủ thuốc <8 ngày  
Đặt dụng cụ nội mạch < 30 ngày  Rung nhĩ (RN) có điểm 
CHAD 2DS 2-VASc ≥ 6  
Van 2 lá cơ h ọc. Dụng cụ 
hỗ trợ tim  
Cao Hội chứng vành cấp (HCVC) hoặc 
can thiệp mạch vành đặt stent có 
phủ thuốc 8 -30 ngày  
Đặt dụng cụ nội mạch 1 -12 tháng  Rung nhĩ (RN) có điểm 
CHAD 2DS 2-VASc 4 -5 
Van động mạch chủ cơ học  
Trung bình  Hội chứng vành cấp (HCVC) hoặc 
can thiệp mạch vành đặt stent có 
phủ thuốc 1 -12 tháng  Rung nhĩ (RN) có điểm 
CHAD 2DS 2-VASc 2 -3 
 
Trung bình – 
Thấp  Bệnh mạch vành mạn (>12 tháng 
sau Hội chứng vành cấp hoặc can 
thiệp mạch vành đặt stent có phủ 
thuốc), nhưng có tắc động mạch 
vành trái, tắc 2 đoạ n, hay HCVC tái 
phát Rung nhĩ (RN) có điểm 
CHAD 2DS 2-VASc 1 (nam) 
hoặc 2 (nữ)  
 
Thấp  Bệnh mạch vành mạn (>12 tháng 
sau Hội chứng vành cấp hoặc can 
thiệp mạch vành đặt stent có phủ 
thuốc), không có YTNC khác  Rung nhĩ (RN) có điểm 
CHAD 2DS 2-VASc 0 (nam) 
hoặc 1  (nữ) 
 
 
 
 
 
 
 
 syt_bacgiang_vt_Van thu SYT Bac Giang_23/10/2023 11:45:0760 
 
Bảng: Thang đi ểm CHAD 2DS 2-VASc:  
 
Tiêu chí  Điểm 
Tuổi < 65 tu ổi 0 
65 - 74 tu ổi +1 
≥ 75 tu ổi +2 
Giới tính  Nam gi ới 0 
Nữ giới +1 
Tiền sử suy tim sung huy ết +1 
Tiền sử tăng huy ết áp +1 
Lịch sử đột quỵ / TIA / huy ết khối +2 
Tiền sử bệnh mạch máu  +1 
Tiền sử đái tháo đư ờng +1 
 
Bảng 36: B ảng phân nhóm nguy cơ HKTM  
Nguy cơ cao  Nguy cơ trung bình  Nguy cơ thấp  
Huyết khối tĩnh mạch < 
3 tháng  Huyết khối tĩnh mạch 3 -12 
tháng  Huyết khối tĩnh mạch > 
12 tháng, không có 
YTNC khác  
Giảm Protein C,  Protein 
S hoặc Antithrombin  Yếu tố V Leiden dị hợp tử   
Hội chứng kháng 
Phospholipid  Đột biến Prothrombin 20210   
Nhiều nguy cơ tăng 
đông kết hợp  Huyết khối tĩnh mạch tái 
phát  
 Bệnh lý ác tính chưa ổn định   
 
 
 
 
 syt_bacgiang_vt_Van thu SYT Bac Giang_23/10/2023 11:45:0761 
 
Bảng 37: B ảng đánh giá nguy cơ huy ết khối ở bệnh nhân có nhi ều bệnh lý ph ối hợp 
Nguy cơ cao  Nguy cơ trung bình  Nguy cơ thấp  
Chấn thương lớn  
Gãy xương chậu, đùi  
Thay khớp háng, khớp gối  
Phẫu thuật lớn  
Chấn thương cột sống  
Hội chứng kháng 
phospholipid    Bệnh lý ác tính  
Hóa trị  
Liệu pháp hormone thay thế  
Dùng thuốc ngừa thai  
Phụ nữ sau sinh  
Tiền sử huyết khối tĩnh mạch  
Phẫu thuật nội soi khớp gối  
Đột quỵ gây liệt  
Đã có tiền sử huyết khối  
Nhiễm khuẩn  
Bệnh lý tự miễn  
Đái tháo đường  Nằm lâu>3 ngày  
Ngồi lâu (bay đường 
dài hoặc ngồi xe quá 
lâu) 
Tuổi ca o 
Béo phì  
Tăng huyết áp  
Giãn tĩnh mạch  
Có thai  
 
Bảng 38: B ảng phân nhóm nguy cơ xu ất huy ết 
Nhóm  
nguy cơ  Vị trí và mức độ xu ất huyết Hoàn cảnh lâm sàng  YTNC 
của bệnh 
nhân  
Rất cao  Xuất huyết nội sọ không thể 
điều trị.  
Xuất huyết ngoài sọ đe dọa 
tính mạng  nhưng không thể 
xác định nguồn xu ất huyết 
hoặc không thể kiểm soát 
nguồn xu ất huyết Không có ý tố nguy 
cơ hoặc khởi phát có 
thể điều trị được (tăng 
huyết áp, chấn 
thương, thủ thuật, quá 
liều thuốc).  
Nguy cơ huyết khối 
cao nên khó ngưng 
thuốc kháng 
đông/kháng kết tập 
tiểu cầu  HAS -
BLED ≥ 5  
Cao Xuất huyết ngoài sọ nặng 
nhưng không thể xác định 
nguồn xu ất huyết hoặc không 
thể kiểm soát nguồn xu ất 
huyết Không có YTNC có 
thể điều trị  
Xuất huyết ngoài sọ 
nhẹ HAS -
BLED 3 -
4 syt_bacgiang_vt_Van thu SYT Bac Giang_23/10/2023 11:45:0762 
 
Nhóm  
nguy cơ  Vị trí và mức độ x uất huy ết Hoàn cảnh lâm sàng  YTNC 
của bệnh 
nhân  
Trung bình  Xuất huyết nội sọ có thể điều 
trị hiệu quả nguyên nhân và 
các YTNC.  
Xuất huyết ngoài sọ nặng có 
thể xác định và kiểm soát 
nguồn xu ất huyết  HAS -
BLED 2  
Trung bình – 
Thấp  Xuất huyết ngoài sọ n hẹ Xuất huyết liên quan 
thuốc kháng đông có 
thể tạm ngưng được  HAS -
BLED 1  
Thấp  Xuất huyết ngoài sọ không 
đáng kể  Xuất huyết liên quan 
thuốc kháng đông có 
thể tạm ngưng được  HAS -
BLED 0  
 
Bảng 39: Thang đi ểm HAS -BLED  
Tiêu chí  Điểm  
Tăng huyết áp không k iểm soát, huyết áp tâm thu > 160 mmHg  1 
Bệnh thận mạn (lọc thận, ghép thận hoặc Creatinin > 2,26 mg/dL hay 
200 µmol/L)  1 
Bệnh gan (Xơ gan hoặc bilirubin > 2 lần ngưỡng trên bình thường kèm 
AST/ALT/ALP tăng > 3 lần ngưỡng trên bình thường)  1 
Tiền căn đột  quỵ 1 
Tiền căn xuất huyết  1 
INR không ổn định/kéo dài, thời gian INR trong ngưỡng điều trị < 60%  1 
Tuổi > 65  1 
Thuốc ( aspirin, clopidogrel, kháng viêm không steroid)  1 
Uống rượu  1 
 
3.2. S ử dụng lại thu ốc kháng đông  và kháng ngưng t ập tiểu cầu sau bi ến chứng 
xuất huy ết 
Nguyên t ắc chung: ph ải căn c ứ trên tình tr ạng từng bệnh nhân c ụ thể 
- Sử dụng lại kháng đông sau khi xu ất huy ết đã đư ợc kiểm soát.  
- Bệnh nhân ph ải được kiểm soát và theo dõi sát sau đó  
- Bệnh nhân có nguy cơ huy ết khối cao hơn nguy cơ tá i phát xu ất huy ết (xem các 
bảng nguy cơ huy ết khối) hoặc 1 số trường hợp đặc biệt 
- BN không có k ế hoạch ph ẫu thu ật cấp syt_bacgiang_vt_Van thu SYT Bac Giang_23/10/2023 11:45:0763 
 
Các bư ớc được tóm t ắt ở sơ đồ: 
Sơ đồ 5: Các bư ớc sử dụng lại thuốc kháng đông và kháng k ết tập tiểu cầu sau bi ến 
chứng xu ất huy ết 
 
3.3. M ột số trường hợp cụ thể đặc biệt 
3.3.1. S ử dụng kháng ngưng t ập tiểu cầu và kháng đông ở bệnh nhân sau xu ất huy ết 
ngoài s ọ 
a. Với thuốc kháng ngưng t ập tiểu cầu: 
- Với bệnh nhân nguy cơ huy ết khối rất cao (b ảng 3), tình tr ạng xu ất huyết nhẹ đến 
vừa, có th ể tiếp tục dùng aspirin li ều thấp. Bắt đầu lại thuốc kháng ngưng t ập tiểu 
cầu thứ 2 càng s ớm càng t ốt sau khi tình tr ạng xu ất huy ết đã ổn định 
- Đối với bệnh nhân có nguy cơ huy ết khối trung bình, có xu ất huy ết không đe d ọa 
tính m ạng, tiếp tục aspirin ngay khi xu ất huy ết được kiểm soát, t ối ưu là trong vòng 
3 ngày. Thu ốc kháng k ết tập tiểu cầu thứ 2 được sử dụng nếu nguy cơ huy ết khối 
cao hơn nguy cơ xu ất huy ết. Ví d ụ nếu BN vừa đặt stent ph ủ thuốc trong vòng 3 
tháng, ti ếp tục kháng  kết tập tiểu cầu kép cho đ ủ ít nhất 3 tháng. N ếu BN đặt stent 
phủ thuốc trên 3 tháng, có nguy cơ xu ất huy ết cao, ch ỉ nên ti ếp tục 1 thu ốc. BN có xu ất huy ết nặng, đe d ọa 
tính m ạng, sau can thi ệp cầm máu  
Đã ngừng xuất huyết ? 
  
 
Đã ngừng xuất huyết ? 
  Chưa dùng  lại kháng đông  
 
Chưa dung lại  kháng đông  BN có đang ở nơi có đ ầy đủ 
phương ti ện theo dõi và c ấp cứu? 
 
 
BN có đang ở nơi có đ ầy đủ 
phương ti ện theo dõi và c ấp cứu? 
 Nguy cơ huy ết khối? 
 
 
Nguy cơ huy ết khối? 
 Đánh giá nguy cơ xuất huy ết? 
  
 
Đánh giá nguy cơ xuất huy ết? 
  Bắt đầu dùng Heparin  liều thấp. 
Đích APTT đ ạt mức thấp của 
khoảng đi ều trị 
 
 
Bắt đầu dùng Heparin  liều thấp. 
Đích APTT đ ạt mức thấp của 
khoảng đi ều trị 
 Theo dõi ch ặt 
 
 
Theo dõi ch ặt 
 Theo dõi chặt  
  
 
Theo dõi chặt  
  Bắt đầu dùng l ại NOAC  
  
 
Bắt đầu dùng l ại NOAC  
  
Dừng Heparin  và bắt đầu dùng 
NOAC  
 
Dừng Heparin  và bắt đầu dùng 
NOAC  Dừng Heparin  và xem xét can 
thiệp cầm máu  
 
Dừng Heparin  và xem xét can 
thiệp cầm máu  Không  
 
Không  Có 
 
Có Có 
 
Có 
Điểm CHA 2DS 2-VAS c =0,1  
 
Điểm CHA 2DS 2-VAS c =0,1  Điểm CHA 2DS 2-VAS c ≥2 
 
Điểm CHA 2DS 2-VAS c ≥2 Cao 
 
Cao Không  
 
Không  
Xuất huy ết tái phát  
 
Xuất huy ết tái phát  Không có kh ả năng 
Xuất huy ết tái phát  
 
Không có kh ả năng 
Xuất huy ết tái phát  syt_bacgiang_vt_Van thu SYT Bac Giang_23/10/2023 11:45:0764 
 
- Tiếp tục dùng kháng k ết tập tiểu cầu kép trong ít nh ất 12 tháng t ừ khi đ ặt dụng cụ 
nội mạch. 
- Nếu bệnh nhân xu ất huy ết bất thư ờng khi đang dùng prasugrel hay ticagrelor, nên 
chuy ển sang clopidogrel. B ắt đầu lại sau 7 -10 ngày ngưng prasugrel và 3 -5 ngày t ừ 
khi ngưng ticagrelor.  
- Nếu bệnh nhân có ti ền căn h ội chứng vành c ấp không đư ợc can thi ệp mạch vành, 
có xu ất huy ết khi đang dùng kháng k ết tập tiểu cầu kép, nên chuy ển sang kháng k ết 
tập tiểu cầu đơn.  
- Nếu bệnh nhân có b ệnh m ạch vành ổn định, b ị xuất huy ết tiêu hóa trên, đư ợc xác 
định nguy cơ xu ất huy ết tái phát th ấp dựa theo n ội soi, không nên ngưng kháng k ết 
tập tiểu cầu. Nếu nguy cơ xu ất huy ết tái phát cao, aspirin nên đư ợc sử dụng lại 
trong vòng 3 ngày t ừ khi xu ất huy ết được kiểm soát. Thu ốc kháng k ết tập tiểu cầu 
thứ 2 nên đư ợc tiếp tục khi nguy cơ xu ất huy ết được kiểm soát hoàn toàn.  
- Thuốc ức chế bơm proton được dùng song song v ới kháng k ết tập tiểu cầu trên t ất cả 
bệnh nhân xu ất huy ết tiêu hóa trên có nguy cơ xu ất huy ết tái phát cao ho ặc rất cao.  
b. Với thuốc kháng đông  
- Thuốc kháng đông đư ờng u ống nên đư ợc sử dụng lại ngay khi xu ất huy ết được 
kiểm soát, t ối ưu là trong vòng 1 tu ần 
- Khi b ắt đầu lại thu ốc kháng đông đư ờng uống th ế hệ mới, nên theo dõi sát ch ức 
năng th ận. 
- Nếu đã ph ải dùng thu ốc đối kháng (ví d ụ idarucizumab) trong đi ều trị xuất huy ết trước 
đó, nên dùng l ại kháng đông càng s ớm càng t ốt, tối ưu là trong vòng 3 -4 ngày.  
- Nếu bệnh nhân có van tim cơ h ọc, đặc biệt là van 2 lá, h ết sức cân nh ắc khi ng ừng 
thuốc trong su ốt quá trình đi ều trị do có th ể gây t ắc van (n ếu ngừng, không quá 14 
ngày và c ần quy ết định dựa trên ch ỉ số INR).  
- Không s ử dụng NOAC cho b ệnh nhân có van cơ h ọc 
c. Kết hợp kháng k ết tập tiểu cầu và kháng đông  
- Đối với bệnh nhân đã can thi ệp mạch vàng, có rung nhĩ, c ần điều trị kháng đông và 
kháng k ết tập tiểu cầu kép, nên ngưng aspirin ho ặc clopidrogrel (ch ỉ ngưng 
clopidogrel n ếu đặt stent trên 1 tháng). Đ ối với kháng đông, n ếu dùng kháng 
vitamin K, duy trì INR 2,0 -2,5, n ếu dùng kháng đông đư ờng uống th ế hệ mới thì 
duy trì v ới liều dự phòng th ấp nhất. 
- Nếu bệnh nhân đang dùng kháng đông và kháng k ết tập tiểu cầu đơn, có xu ất huy ết 
nặng, có th ể ngưng kháng k ết tập tiểu cầu dù th ời gian dùng < 1 năm.  
- Ngừng kháng đông, duy trì kháng ngưng t ập tiểu cầu kép n ếu bệnh nhân rung nhĩ, 
nguy cơ huy ết khối thấp, có bi ểu hiện xuất huy ết khi đang đi ều trị. 
3.3.2. Sau xu ất huy ết nội sọ 
- Tùy theo nguy cơ h uyết khối và nguy cơ xu ất huy ết tái phát, quy ết định dùng l ại 
kháng đông đư ợc cân nh ắc trên t ừng bệnh nhân.  
- Với bệnh nhân có van tim nhân t ạo: bắt đầu dùng l ại kháng vitamin K  
- Trên b ệnh nhân rung nhĩ không do b ệnh van tim: thu ốc kháng đông đư ờng uống 
thế hệ mới (NOAC) đư ợc ưu tiên hơn kháng vitamin K sau xu ất huy ết não. Duy trì syt_bacgiang_vt_Van thu SYT Bac Giang_23/10/2023 11:45:0765 
 
liều NOAC th ấp nhất có th ể. Theo dõi tu ổi, cân n ặng, ch ức năng th ận, tương tác 
thuốc để điều chỉnh liều cho phù h ợp. 
3.3.3. S ử dụng lại kháng đông sau xu ất huy ết dạ dày 
a. Với bệnh nhân đang dùng kháng ngưng t ập tiểu cầu 
- Với các b ệnh nhân b ệnh m ạch vành có dùng kháng ngưng t ập tiểu cầu, cần dựa vào 
phân lo ại nội soi d ạ dày đ ể xác đ ịnh nguy cơ xu ất huy ết tái phát và quy ết định dùng 
lại thuốc. 
- Với bệnh nhân đang s ử dụng aspirin li ều thấp đơn đ ộc hoặc kháng ngưng t ập tiểu 
cầu kép, xu ất huy ết tại các vùng nguy cơ tái phát th ấp (Forrest IIc, III): không c ần 
dừng thu ốc 
- Với bệnh nhân đư ợc nội soi xác đ ịnh nguy cơ tái phát cao (Forrest Ia, Ib, IIa, IIb), 
nếu đang dùng li ều thấp aspirin đơ n độc thì t ạm ng ừng thu ốc 3 ngày, n ếu đang 
dùng kháng ngưng t ập tiểu cầu kép thì ti ếp tục liều thấp aspirin. C ần nội soi l ần 2 
để đánh giá l ại 
b. Với bệnh nhân đang dùng kháng đông:  
Bệnh nhân đang dùng kháng vitamin K: V ới bệnh nhân rung nhĩ không do b ệnh van  
tim, vi ệc sử dụng lại kháng vitamin K sau xu ất huy ết dạ dày có th ể sau 1 tu ần. Với 
bệnh nhân có van tim nhân t ạo hết sức cân nh ắc khi ng ừng thu ốc trong su ốt quá trình 
điều trị do có th ể gây t ắc van (n ếu ngừng, không quá 14 ngày và c ần quy ết định dựa 
trên chỉ số INR).  
3.4. S ử dụng lại kháng đông sau xu ất huy ết nặng trên b ệnh nhân huy ết khối tĩnh 
mạch 
Trên b ệnh nhân có huy ết khối tĩnh m ạch, có xu ất huy ết nghiêm tr ọng, nên ti ếp tục 
kháng đông trong vòng 2 tu ần - 90 ngày t ừ khi xu ất huy ết, nếu bệnh nhâ n có nguy cơ 
huyết khối tĩnh m ạch tái phát cao hơn nguy cơ xu ất huy ết tái phát.  
4. Giảm  tiểu cầu do Heparin  
4.1. Đại cương  
Giảm tiểu cầu do Heparin (Heparin -induced thrombocytopenia – HIT) là một phản 
ứng có hại sau sử dụng Heparin, biểu hiện lâm sàng là  giảm số lượng tiểu cầu (< 
150G/l hoặc giảm trên 50% so với số lượng tiểu cầu ở thời điểm trước khi sử dụng 
Heparin) và có thể có hoặc không có các biến chứng huyết khối.  Thời điểm bắt đầu 
giảm tiểu cầu sau sử dụng Heparin thay đổi theo tiền sử dùng Hepari n. Ở các bệnh 
nhân chưa từng sử dụng hoặc đã sử dụng Heparin cách hơn 100 ngày, thời điểm giảm 
tiểu cầu thường khoảng 4 đến 10 ngày sau khi sử dụng Heparin. Đối với các bệnh nhân 
có tiền sử dùng Heparin gần đây, giảm tiểu cầu có thể xảy ra sớm hơn, có thể trong vài 
giờ. 
Tỉ lệ HIT x ảy ra ở những bệnh nhân này kho ảng <0 ,1% đ ến 7% ph ụ thuộc vào lo ại 
Heparin đư ợc sử dụng (UFH hay g ặp hơn LMWH)  
4.2. Cơ chế bệnh sinh  
Giảm tiểu cầu do Heparin gồm có 2 loại: HIT type I không do cơ chế miễn dịch và HIT 
type II do c ơ chế miễn dịch  qua trung gian kháng th ể IgG v ới đích g ắn và ph ức hợp yếu tố 
4 tiểu cầu (Platelet factor 4 - PF4) và Heparin , có thể gây tử vong cho bệnh nhân. Vì vậy syt_bacgiang_vt_Van thu SYT Bac Giang_23/10/2023 11:45:0766 
 
trong thực hành lâm sàng thường quan tâm đến HIT type II, thời điểm xuất hiện HIT, mức 
độ giảm số lượng tiểu cầu, loại Heparin sử dụng và nguy cơ huyết khối.  
-HIT type I: Thư ờng xảy ra s ớm, kho ảng 1-2 ngày sau s ử dụng Heparin. Cơ ch ế do tác 
dụng tr ực tiếp của Heparin lên quá trình ho ạt hóa ti ểu cầu. Gi ảm tiểu cầu thư ờng nh ẹ 
(> 100 G/l), không gây ra xu ất huy ết hoặc huy ết khối. Số lượng tiểu cầu dần hồi phục 
mà không c ần phải dừng Heparin.  
-HIT type II: x ảy ra kho ảng 4-10 ngày sau khi s ử dụng Heparin và có th ể gây ra bi ến 
chứng huy ết khối chi ho ặc toàn thân đe d ọa tính m ạng ngư ời bệnh, hi ếm khi xuất 
huyết. Cơ ch ế do cơ th ể sinh kháng th ể kháng ph ức hợp Heparin - yếu tố 4 tiểu cầu 
(khả năng t ạo ph ức hợp với yếu tố 4 tiểu cầu của Heparin tiêu chu ẩn nhi ều hơn 
Heparin tr ọng lư ợng phân t ử thấp). Các ph ức hợp kháng nguyên kháng th ể này t ập 
trung trên b ề mặt của các t ế bào bao g ồm tiểu cầu, tế bào đơn đơn nhân, trong huy ết 
tương và có th ể trên t ế bào n ội mô. Các ph ức hợp kháng nguyên kháng th ể khi g ắn trên 
bề mặt của tiểu cầu sẽ hoạt hóa ti ểu cầu và phóng thích các các y ếu tố tiền đông ho ạt 
hoá dòng thác  đông máu; h ậu quả là giảm số lượng tiểu cầu và có th ể gây huy ết khối. 
4.3. Chẩn đoán  
4.3.1.  Lâm sàng  
- Biểu hiện lâm sàng ch ủ yếu là huy ết khối, hiếm khi là xu ất huy ết mặc dù s ố lượng 
tiểu cầu giảm. Nguy cơ huy ết khối sau d ừng Heparin v ẫn có th ể kéo dài k ể cả khi 
số lượng tiểu cầu đã tr ở về bình thư ờng. Bi ểu hiện huy ết khối tĩnh m ạch nhi ều hơn 
là động m ạch ho ặc có th ể cả hai: TTHKTMS, huy ết khối động m ạch (não, m ạch 
vành, các đ ộng m ạch ngo ại biên).  
- Có th ể biểu hiện phản ứng toàn thân c ấp tính (l ạnh run, s ốt, khó th ở, đau ng ực) sau 
tiêm Heparin, t ổn thương da t ại chỗ tiêm, n ặng hơn có th ể hoại tử chi, hôn mê và t ử 
vong tu ỳ vào m ức độ tắc mạch, v ị trí tắc mạch. 
4.3.2. Cận lâm sàng  
- Số lượng tiểu cầu: số lượng tiểu cầu giảm dư ới 150 G/l, có th ể giảm rất nặng (dư ới 
10G/l ), tuy nhiên HIT type I thư ờng ít khi gi ảm dư ới 100 G/l; ho ặc số lượng tiểu cầu 
giảm ≥ 50% so v ới thời điểm trư ớc điều trị Heparin. Gi ảm tiểu cầu trong HIT type II 
thường xảy ra kho ảng ngày 4 đ ến ngày 10 sau khi b ắt đầu điều trị Heparin; có th ể xảy 
ra vài giờ sau khi dùng l ại Heparin ho ặc có th ể sau 3 tu ần ngừng đi ều trị Heparin.  
- Kháng th ể kháng Heparin -yếu tố 4 tiểu cầu 
+ Xét nghiệm xác định kháng thể: hay còn gọi là xét nghiệm huyết thanh, được 
chỉ định khi có nghi ngờ lâm sàng, không khuyến cáo cho tất cả các bệnh nhân 
điều trị Heparin. Kháng thể được phát hiện bởi xét nghiệm huyết thanh có thể 
không biểu hiện HIT.  
+ Xét nghiệm đánh giá sự hoạt hóa tiểu cầu: hay còn gọi là xét nghiệm chức năng, 
phát hiện khả năng gắn của các kháng thể kháng PF4 -heaprin và hoạ t hóa tiểu 
cầu thông qua các thụ thể Fc trên tiểu cầu. Xét nghiệm đánh giá sự hoạt hoá tiểu 
cầu chỉ phát hiện các kháng thể hoạt hóa tiểu cầu ; vì vậy xét nghiệm có độ nhạy 
và đặc hiệu cao đối với biểu hiện HIT.  
- Chẩn đoán hình ảnh: Các xét nghi ệm hình ảnh được thực hiện để xác đ ịnh các t ổn 
thương huy ết khối. Vì v ậy khi nghi ng ờ HIT, nên th ực hiện các xét nghi ệm: siêu 
âm Doppler, CLVT đ ể tấm soát huy ết khối tuỳ thuộc vào v ị trí nghi ng ờ. syt_bacgiang_vt_Van thu SYT Bac Giang_23/10/2023 11:45:0767 
 
- Các xét nghi ệm để chẩn đoán phân bi ệt với các b ệnh khác gây gi ảm tiểu cầu, huy ết 
khối, xuất huy ết, các xét nghi ệm theo dõi HIT: t ổng phân tích t ế bào máu ngo ại vi, 
các xét nghi ệm đông máu, t ủy đồ; xét nghi ệm tìm nguyên nhân: b ệnh tự miễn, 
nhiễm trùng, ung thư…  
4.3.3 Chẩn đoán  
- Chẩn đoán HIT c ần dựa vào các bi ểu hiện lâm sàng nghi n gờ để thực hiện xét 
nghiệm phát hi ện kháng th ể kháng PF4 -Heparin.  
- Nghi ng ờ lâm sàng bao g ồm: m ức độ giảm tiểu cầu; thời điểm giảm tiểu cầu; biểu 
hiện huy ết khối và các bi ến chứng khác; nguyên nhân gi ảm tiểu cầu khác không rõ 
ràng đ ể đánh giá m ức độ nguy c ơ HIT d ựa vào thang đi ểm 4T’s (b ảng 40).  
Bảng 40: Thang đi ểm 4T’s  
4T 2 1 0 
Giảm tiểu cầu  Giảm > 50% và mức tiểu 
cầu thấp nhất ≥ 20 G/l  Giảm 30 -50% hoặc 
mức tiểu cầu thấp 
nhất 10 -19 G/l  Giảm <30% 
hoặc mức tiểu 
cầu thấp nhất 
< 10 G/l  
Thời điểm 
giảm tiểu c ầu  Từ ngày 5 -10; hoặc ≤ 1 
ngày (nếu dùng Heparin 
trong vòng 30 ngày)  Từ ngày 5 -10 nhưng 
không rõ (số lượng 
tiểu cầu ban đầu) ; 
hoặc giảm tiểu cầu 
sau ngày thứ 10; 
hoặc giảm ≤ 1 ngày 
(dùng Heparin trong 
vòng 30 -100 ngày)  Thời điểm 
giảm ≤ 4 ngày 
(không sử 
dụng Heparin 
gần đây)  
Huyết khối 
hoặc biến 
chứng khác  Huyết khối mới; hoại tử 
da; phản ứng toàn thân 
sau bolus Heparin  Huyết khối tái phát 
hoặc tiến triển; tổn 
thương da không 
hoại tử; nghi ngờ 
huyết khối  Không  
Nguyên nhân 
khác gây giảm 
tiểu cầu không 
rõ ràng  Không có nguyên nhân rõ 
ràng khác giảm tiểu cầu  Nghi ngờ nguyên 
nhân khác giảm tiểu 
cầu Xác định rõ 
nguyên nhân 
khác giảm tiểu 
cầu 
Nguy cơ  0-3: Thấp  
4-5: Trung bình  
6-8: Cao  
 
- Chẩn đoán giai đo ạn của HIT theo b ảng 41: syt_bacgiang_vt_Van thu SYT Bac Giang_23/10/2023 11:45:0768 
 
 
Bảng 41: Các giai đo ạn của HIT  
Phase  Số lượng tiểu cầu  Xét nghiệm đánh giá 
chức năng  Xét nghiệm 
miễn dịch  
Nghi ngờ  Giảm  ? ? 
Cấp Giảm  + + 
Bán cấp A  Bình thường  + + 
Bán cấp B  Bình thường  - + 
HIT thoái lui  Bình thường  - - 
- Các bư ớc chẩn đoán HIT được thực hiện theo sơ đ ồ 6: 
Sơ đồ 6: Hướng dẫn chẩn đoán HIT  
 Nghi ng ờ HIT 
 
Nghi ng ờ HIT Tính đi ểm 4Ts  
 
 
Tính đi ểm 4Ts  
 Nguy cơ trung bình/ cao trê n lâm sàng  
Điểm 4Ts ≥4  
  
 
Nguy cơ trung bình/ cao trên lâm sàng  
Điểm 4Ts ≥4  
  Nguy cơ th ấp 
Điểm 4Ts ≤3  
 
Nguy cơ th ấp 
Điểm 4Ts ≤3  Làm các xét nghi ệm mi ễn dịch HIT  
 
Làm các xét nghi ệm mi ễn dịch HIT  
Dương tính  
 
Dương tính  Âm tính  
 
Âm tính  
Làm các xét ngh iệm đánh 
giá ch ức năng  
 
 
Làm các xét nghi ệm đánh 
giá ch ức năng  
 Dương tính  
 
Dương tính  Âm tính  
 
Âm tính  Khả năng là HIT  
 
Khả năng là HIT  Không ph ải HIT  
Không làm các xét nghi ệm HIT  
 
 
Không ph ải HIT  
Không làm các xét nghi ệm HIT  
 syt_bacgiang_vt_Van thu SYT Bac Giang_23/10/2023 11:45:0769 
 
4.4. Điều trị  
4.4.1 . Nguyên tắc điều trị  
Nguy cơ trung bình/cao trên lâm sàng: ngừng điều trị Heparin, bao gồm cả Heparin 
duy trì catheter tĩnh mạch, điều trị kháng đông thay thế. Nguy cơ thấp trên lâm s àng có 
thể ngừng Heparin/ hoặc tiếp tục dùng nếu vẫn có chỉ định (sơ đồ 2).  
- Không đi ều trị LMWH thay th ế Heparin tiêu chu ẩn vì kh ả năng ph ản ứng chéo cao 
với các kháng th ể Heparin - PF4 lưu hành; Không hi ệu quả khi dùng Aspirin đơn 
độc, khi đ ặt lưới lọc tĩnh mạch ch ủ dưới; Không đi ều trị warfarin đơn đ ộc; Không 
truyền tiểu cầu để phòng.  
- Điều trị kháng đông thay th ế: ức chế trực tiếp thrombin ho ặc Heparinoid (b ảng 3). 
Việc lựa chọn thu ốc phụ thuộc vào tính s ẵn có c ủa thu ốc, xét nghi ệm theo dõi, kinh 
nghiệm sử dụng và tình tr ạng lâm sàng c ủa bệnh nhân.  
syt_bacgiang_vt_Van thu SYT Bac Giang_23/10/2023 11:45:0770 
 
Sơ đồ 7: Hư ớng dẫn điều trị HIT 
 
 
 
 
 
 
 Nghi ng ờ HIT 
 
Nghi ng ờ HIT 
 
Nghi ng ờ HIT 
 
Nghi ng ờ HIT 
 
Nghi ng ờ HIT 
 
Nghi ng ờ HIT 
 
Nghi ng ờ HIT 
 
Nghi ng ờ HIT Tính đi ểm 4Ts  
 
 
Tính đi ểm 4Ts  
 
 
Tính đi ểm 4Ts  
 
 
Tính đi ểm 4Ts  
 
 
Tính đi ểm 4Ts  
 
 
Tính đi ểm 4Ts  
 
 
Tính đi ểm 4Ts  
 
 
Tính đi ểm 4Ts  
 Nguy cơ trung bình/ cao trên lâm sàng  
Điểm 4Ts ≥4  
  
 
Nguy cơ trung bình/ cao trên lâm sàng  
Điểm 4Ts ≥4  
  
 
Nguy cơ trung bình/ cao trên lâm sàng  
Điểm 4Ts ≥4  
  
 
Nguy cơ trung bình/ cao trên lâm sàng  
Điểm 4Ts ≥4  
  
 
Nguy cơ trung bình/ cao trên lâm sàng  
Điểm 4Ts ≥4  
  
 
Nguy cơ trung bình/ cao trên l âm sàng  
Điểm 4Ts ≥4  
  
 
Nguy cơ trung bình/ cao trên lâm sàng  
Điểm 4Ts ≥4  
  
 
Nguy cơ trung bình/ cao trên lâm sàng  
Điểm 4Ts ≥4  
  Nguy cơ th ấp 
Điểm 4Ts ≤3  
 
Nguy cơ th ấp 
Điểm 4Ts ≤3  
 
Nguy cơ th ấp 
Điểm 4Ts ≤3  
 
Nguy cơ th ấp 
Điểm 4Ts ≤3  
 
Nguy cơ th ấp 
Điểm 4Ts ≤ 3 
 
Nguy cơ th ấp 
Điểm 4Ts ≤3  
 
Nguy cơ th ấp 
Điểm 4Ts ≤3  
 
Nguy cơ th ấp 
Điểm 4Ts ≤3  Làm các xét nghi ệm mi ễn dịch HIT  
 
Làm các xét nghi ệm mi ễn dịch HIT  
 
Làm các xét nghi ệm mi ễn dịch HIT  
 
Làm các xét nghi ệm mi ễn dịch HIT  
 
Làm các xét nghi ệm mi ễn dịch HIT  
 
Làm c ác xét nghi ệm mi ễn dịch HIT  
 
Làm các xét nghi ệm mi ễn dịch HIT  
 
Làm các xét nghi ệm mi ễn dịch HIT  Dương tính  
 
Dương tính  
 
Dương tính  
 
Dương tính  
 
Dương tính  
 
Dương tính  
 
Dương tính  
 
Dương tính  Âm tính  
 
Âm tính  
 
Âm tính  
 
Âm tính  
 
Âm tính  
 
Âm tính  
 
Âm tính  
 
Âm tính  Làm các xét nghi ệm đánh 
giá ch ức năng  
 
 
Làm các xét nghi ệm đánh 
giá ch ức năng  
 
 
Làm các xét nghi ệm đánh 
giá ch ức năng  
 
 
Làm các xét nghi ệm đánh 
giá ch ức năng  
 
 
Làm các xét nghi ệm đánh 
giá ch ức năng  
 Dương tính  
 
Dương tính  
 
Dương tính  
 
Dương tính  
 
Dương tính  
 
Dương tính  
 
Dương tính  Âm tính  
 
Âm tính  
 
Âm tính  
 
Âm tính  
 
Âm tính  
 
Âm tính  
 
Âm tính  Khả năng là HIT  
Điều trị thay th ế Heparin    
 
 
Khả năng là HIT  
Điều trị thay th ế Heparin    
 
 
Khả năng là HIT  
Điều trị thay th ế Heparin    
 
 
Khả năng là HIT  
Điều trị thay th ế Heparin    
 
 Không ph ải HIT;  
Tiếp tục sử dụng heparin  nếu có ch ỉ định 
Dừng kháng đông không ph ải heparin  (nếu có th ể) 
 
 
Không ph ải HIT;  
Tiếp tục sử dụng Heparin  nếu có ch ỉ định 
Dừng kháng đông không ph ải Heparin  (nếu có th ể) 
 
 
Không ph ải HIT;  
Tiếp tục sử dụng Heparin  nếu có ch ỉ định 
Dừng kháng đông không ph ải Heparin  (nếu có th ể) 
 Ngừng heparin ; Bắt đầu sử dụng kháng đông 
không ph ải heparin  
Điểm 4Ts ≥4  
  
 
Ngừng Heparin ; Bắt đầu sử dụng kháng đông 
không ph ải Heparin  
Điểm 4Ts ≥4  
  
 
Ngừng Heparin ; Bắt đầu sử dụng kháng đông 
không ph ải Heparin  
Điểm 4Ts ≥4  
  
 
Ngừng Heparin ; Bắt đầu sử dụng kháng đông 
không ph ải Heparin  
Điểm 4Ts ≥4  
  
 
Ngừng Heparin ; Bắt đầu sử dụng kháng đông 
không ph ải Heparin  
Điểm 4Ts ≥4  
  
 
Ngừng Heparin ; Bắt đầu sử dụng kháng đông 
không ph ải Heparin  
Điểm 4Ts ≥4  
  
 
Ngừng Heparin ; Bắt đầu sử dụng kháng đông 
không ph ải Heparin  
Điểm 4Ts ≥4  Tiếp tục ngừng heparin ;  
tiếp tục sử dụng kháng đông không ph ải heparin  
  
 
Tiếp tục ngừng Heparin ;  
tiếp tục sử dụng kháng đông không ph ải Heparin  
  
 
Tiếp tục ngừng Heparin ;  
tiếp tục sử dụng kháng đông không ph ải Heparin  
  
 
Tiếp tục ngừng Heparin ;  
tiếp tục sử dụng kháng đông không ph ải Heparin  
  
 
Tiếp tục ngừng Heparin ;  
tiếp tục sử dụng kháng đông không ph ải Heparin  
  
 
Tiếp tục ngừng Heparin ;  
tiếp tục sử dụng kháng đông không ph ải Heparin  
  
 syt_bacgiang_vt_Van thu SYT Bac Giang_23/10/2023 11:45:0771 
 
4.4.2 Các thu ốc kháng đông đi ều trị thay th ế  
Bảng 42: Các thu ốc kháng đông không ph ải heparin trong đi ều trị HIT 
Thuốc Cơ ch ế 
Tác d ụng Chuy ển 
hóa ban 
đầu và 
T/2 Liều lượng Theo 
dõi 
Argatroban  ức chế trực 
tiếp thrombin  Gan m ật, 
(40-50 
phút)  Truy ền tĩnh m ạch liên t ục 
(không bolus): 2 
mg/kg/phút  
Bất thường ch ức năng gan 
suy tim, phù toàn thân, sau 
phẫu thu ật tim m ạch→ 
0.5-1.2 mg/kg/phút  Điều 
chỉnh để 
APTT 
gấp 1.5 
– 3 lần 
so với 
nền  
Fondaparinux*  ức chế trực 
tiếp Yếu tố 
Xa Thận 
(17-24h) TDD: <50 kg: 5 mg 1 
lần/ngày; 50 -100 kg:  7.5 
mg 1l ần/ ngày; >100 kg:10 
mg 1 l ần/ngày  Không  
Apixaban*†  ức chế trực 
tiếp Yếu tố 
Xa Gan 
(8-15h) HITT: u ống 10 mg 2 
lần/ngày trong 1 tu ần, sau 
đó 5 mg 2 l ần/ngày  
HIT đơn đ ộc: uống 5 mg 2 
lần/ngày cho đ ến số lượng 
tiểu cầu phục hồi Không  
Dabigatran*†  ức chế trực 
tiếp thrombin  Thận 
(12-17h) HITT: u ống 150 mg 2 l ần/ 
ngày t ừ ngày th ứ 5 điều trị 
bằng kh áng đông không 
phải Heparin không qua 
đường ru ột.  
HIT đơn đ ộc: uống 150 mg 
2 lần/ngày cho đ ến số 
lượng tiểu cầu phục hồi Không  
Rivaroxaban*†  ức chế trực 
tiếp Yếu tố 
Xa Thận 
(5-9h) HITT: u ống 15 mg 2 l ần/ 
ngày trong 3 tu ần, sau đó 
20 mg 1 l ần/ ngày  
HIT đơn đ ộc: uống 15 mg, 
2 lần/ngày cho đ ến số 
lượng tiểu cầu phục hồi Không  
Chú ý  
*: Không đư ợc sử dụng trong phase HIT c ấp 
†: Li ều dùng trong đi ều trị HIT c ấp chưa đư ợc chính th ức hóa. Li ều dùng g ợi ý theo 
điều trị TTHKTM và d ựa trên các k ết quả nghiên c ứu về HIT.  
4.4.3. Một số khuyến cáo điều trị cụ thể  syt_bacgiang_vt_Van thu SYT Bac Giang_23/10/2023 11:45:0772 
 
a. Theo dõi b ệnh nhân HIT không tri ệu chứng 
- Bệnh nhân nguy cơ HIT th ấp (<0.1%): không theo dõi HIT b ằng số lượng tiểu cầu. 
- Bệnh nhân có nguy cơ HIT ở mức trung bình (0.1 -1%) ho ặc cao (>1%), đ ếm số 
lượng tiểu cầu để theo dõi HIT. N ếu đã sử dụng Heparin trong vòng30 ngày trư ớc 
đợt điều trị Heparin l ần này thì đ ếm số lượng ti ểu cầu bắt đầu từ ngày D0. N ếu 
bệnh nhân không đi ều trị Heparin trong vòng30 ngày tr ở lại đây thì đ ếm số lượng 
tiểu cầu bắt đầu từ ngày D4 đ ến ngày D14 ho ặc cho đ ến khi d ừng đi ều trị bằng 
Heparin. B ệnh nhân nguy cơ cao, theo dõi s ố lượng ti ểu cầu ít nh ất 2 ngày 1 l ần, 
bệnh nhân nguy cơ trung bình, theo dõi s ố lượng tiểu cầu 2 đ ến 3 ngày 1  lần. 
b. Trên b ệnh nhân ph ẫu thu ật tim m ạchBệnh nhân HIT c ấp tính ho ặc HIT A bán c ấp 
cần phải phẫu thu ật tim m ạch nên trì hoãn cho đ ến khi b ệnh nhân chuy ển sang giai 
đoạn HIT B ho ặc HIT đang thoái lui.  
- Nếu ph ẫu thu ật không th ể trì hoãn đư ợc, lựa chọn 1 trong 3 cách sau: Heparin 
trong ph ẫu thu ật sau khi đã đi ều trị trao đ ổi huy ết tương t rước phẫu thu ật và/ ho ặc 
trao đ ổi huy ết tương trong ph ẫu thu ật; ho ặc heparin trong ph ẫu thu ật kết hợp với 
thuốc kháng ti ểu cầu (ch ất tương t ự prostacyclin ho ặc tirofiban).  
- Bệnh nhân HIT B bán c ấp hoặc HIT đang thoái lui mà c ần phẫu thu ật tim m ạch, 
nên s ử dụng kh áng đông trong ph ẫu thu ật bằng Heparin hơn là đi ều trị bằng kh áng 
đông không ph ải Heparin ho ặc trao đ ổi huy ết tương k ết hợp Heparin, ho ặc Heparin 
kết hợp với thuốc kháng ti ểu cầu.  
c. Bệnh nhân can thi ệp mạch qua da  
Bệnh nhân HIT c ần can thi ệp mạch qu a da nên đi ều trị bằng bivalirudin  hơn là các 
thuốc kháng đông khác.  
d. Bệnh nhân th ận nhân t ạo: Bệnh nhân HIT c ấp tính mà c ần liệu pháp đi ều trị thay th ế 
thận và c ần sử dụng kh áng đông đ ể ngăn ng ừa huy ết khối trong h ệ thống m ạch lọc 
máu thì nên đi ều trị bằng argatroban  
- Bệnh nhân HIT A ho ặc HIT B bán c ấp, HIT thoát lui c ần liệu pháp th ận nhân t ạo 
nên s ử dụng citrate t ại chỗ. 
e. Điều trị và dự phòng TTHKTM ở bệnh nhân HIT thoái lui  
Bệnh nhân HIT thoát lui mà c ần điều trị hoặc dự phòng TTHKTM, nên s ử dụng kh áng 
đông không ph ải Heparin  như apixaban, dabigatran, edoxaban, fondaparinux, 
rivaroxaban, ho ặc kháng Vitamin K.  
 
 
 
 syt_bacgiang_vt_Van thu SYT Bac Giang_23/10/2023 11:45:0773 
 
TÀI LI ỆU THAM KH ẢO 
1. ACCP (2012), VTE, Thrombophilia, Antithrombotic Therapy, and Pregnancy  
2. ACOG (2018), Thromboembolism in pregnancy, Practic e Bulletin number 196, 
vol. 132, No 1.  
3. Ahmed AB, Koster A, Lance M, Faraoni D. European guidelines on perioperative 
venous thromboembolism prophylaxis: Cardiovascular and thoracic surgery. 
European Journal of Anaesthesiology. 2018;35(2):84 -9. 
4. American Soci ety of Hematology 2019 guidelines for management of venous 
thromboembolism: prevention of venous thromboembolism in surgical hospitalized 
patients_ David R. Anderson et al . 
5. Amy West Pollak, and Robert D. McBane II. Succinct Review of the New VTE 
Prevention  and Management Guidelines. Mayo Clin Proc. 2014;89(3):394 -408. 
6. Anderson, D. R., Morgano, G. P., Bennett, C., Dentali, F., Francis, C. W., Garcia, 
D. A, & Dahm, P. (2019). American Society of Hematology 2019 guidelines for 
management of venous thromboembol ism: prevention of venous thromboembolism 
in surgical hospitalized patients. Blood advances, 3(23), 3898 -3944.  
7. Asian venous thromboembolism guidelines: Prevention of venous 
thromboembolism (2012), International angiology, 3 (6): 501 -516. 
8. Attia J, Ray JG, C ook DJ, Douketis J, Ginsberg JS, Geerts WH. Deep vein 
thrombosis and its prevention in critically ill adults. Arch Intern Med 200; 
161:1268 –1279 . 
9. Bosch FTM, Mulder FI, Kamphuisen PW, et al. Primary thromboprophylaxis in 
ambulatory cancer patients with a high Khorana score: a systematic review and 
meta -analysis. Blood Adv 2020; 4:5215.  
10. Cade JF. High risk of the critically ill f or venous thromboembolism. Crit Care Med 
1982;10: 448 –450. 
11. Chavez -MacGregor M, Zhao H, Kroll M, et al. Risk factors and inci dence of 
thromboembolic events (TEEs) in older men and women with breast cancer. Ann 
Oncol 2011; 22:2394.  
12. Chee M. Chan, Andrew F. Shorr, Venous Thromboembolic Disease in the 
Intensive Care Unit, Seminars in respiratory and critical care medicine/ Volume 3 1, 
number 1, 2010.  
13. Clive Kearon; Elie A, Akl; Joseph Ornelas et al (2016). Antithrombotic Therapy 
for VTE Disease chest Guideline and Expert Panel Report. Chest.  
14. CLOTS (Clots in Legs Or stockings after Stroke) Trials Collaboration, Dennis M, 
Sandercock P, et al. Effectiveness of intermittent pneumatic compression in 
reduction of risk of deep vein thrombosis in patients who have had a stroke 
(CLOTS 3): a multicentre randomised controlled trial [published correction 
appears in Lancet. 2013 Aug 10;382(9891):50 6] [published correction appears in 
Lancet. 2013 Sep 21;382(9897):1020].  Lancet . 2013;382(9891):516 -524. 
Doi:10.1016/S0140 -6736(13)61050 -8 syt_bacgiang_vt_Van thu SYT Bac Giang_23/10/2023 11:45:0774 
 
15. Connors JM. Prophylaxis against venous thromboembolism in ambulatory patients 
with cancer. N Engl J Med 2014; 370:2515.  
16. Crowther MA, Cook DJ, Griffith LE, et al. Deep venous thrombosis: clinically 
silent in the intensive care unit. J Crit C are 2005; 20:334 –340. 
17. Cuker, A., Arepally, G. M., Chong, B. H., Cines, D. B., Greinacher, A., Gruel, Y., 
... & Santesso, N. (2018). American Society of Hematology 2018 guidelines for 
management of venous thromboembolism: Heparin -induced thrombocytopenia. 
Blood advances, 2(22), 3360 -3392.  
18. D.Farge, P. Debourdeau, M. Beckers et al. (2013) International clinical practice 
guidline for the treatment and prophylaxis of venous thromboembolism in patients 
with cancer. Journal of Thrombosis and Haemostasis.  
19. Đặng Vạn Phước và cs (2010),"Huy ết khối tĩnh m ạch sâu: ch ẩn đoán bằng siêu âm 
Duplex trên b ệnh nhân n ội khoa c ấp nhập viện", T ạp chí Tim M ạch học (56), pp. 
24-36. 
20. Dennis M, Caso V, Kappelle LJ, Pavlovic A, Sandercock P; European Stroke 
Organisation.  European Stroke Organisation (ESO) guidelines for prophylaxis for 
venous thromboembolism in immobile patients with acute ischaemic stroke.  Eur 
Stroke J . 2016;1(1):6 -19. Doi:10.1177/2396987316628384 . 
21. Diệp Bảo Tuấn, Quách Thanh Khánh,  Nguyễn Văn Tiến: Tỷ lệ  TTHKTM sâu chi 
dưới sau phẫu thuật ung thư phụ khoa Tại Bệnh Viện Ung Bướu TP.HCM  
22. Dipasco PJ, Misra S, Koniaris LG, Moffat FL Jr. Thrombophilic state in cancer, 
part I: biology, incidence, and risk factors. J Surg Oncol 2011; 104:316.  
23. Faraoni D, Comes RF, Geerts W, Wiles MD. European guidelines on perioperative 
venous thromboembolism prophylaxis: Neurosurgery. European Journa l of 
Anaesthesiology. 2018;35(2):90 -5. 
24. Frits I. Mulder , Matteo Candeloro “The Khorana score for prediction of venous 
thromboembolism in cancer patients: a systematic review and meta -analysis”, 
Hematologica 2019 Jun; 104(6): 1277 –1287.  
25. Gibler, W. Brian MD*; Racadio, Judy M.  MD; Associate Editor; Hirsch, Amy L. 
Assistant Editor; Roat, Todd W. Production & CME Manager. Management of 
Severe Bleeding in Patients Treated with Oral Anticoagulants.Proceedings 
Monograph From the Emergency Medicine Cardiac Research and Education 
Grou p-International Multidisciplinary Severe Bleeding Consensus Panel October 
20, 2018. Critical Pathways in Cardiology: September 2019 - Volume 18 - Issue 3 - 
p 143 -166 doi: 10.1097/HPC.0000000000000181 . 
26. Guideline for the Prevention of Venous Thromboembolism (VTE) in Adult 
Hospitalized Patients_ Queensland Government 2018 . 
27. Guyatt GH, Akl EA, Crowther M, Gutterman DD, Schuünemann HJ. Executive 
Summary: Antithrombotic Therapy and Prevention of Thrombosis, 9th ed: 
American College of Chest Physicians Evidence -Based Clinical Practice 
Guidelines. Chest. 2012;141(2 Suppl):7S -47S. 
28. Hà Quang Huy, Hoàng Bùi Hải . Vai trò của máy bơm hơi áp lực ngắt quãng trong 
dự phòng TTHKTM ở bệnh nhân đột quỵ. Trên báo Tạp chí y học Việt Nam. Số 02 
tháng 10/2019 . syt_bacgiang_vt_Van thu SYT Bac Giang_23/10/2023 11:45:0775 
 
29. Hai Hoang  Bui, Phuc Do  Giang, Vu Kim Van, “Venous thromboembolism 
prophylaxis in at -risk postoperative patients: a problem in Vietnam?”, Vietnam 
Journal of Medcicine and Pharmacy, Volume 4, no1, 4/2014, pp: 10 -14. 
30. Halvorsen S, Storey RF, Rocca B, Sibbing D, Ten Berg J, Grove EL , Weiss TW, 
Collet JP, Andreotti F, Gulba DC, Lip GYH, Husted S, Vilahur G, Morais J, 
Verheugt FWA, Lanas A, Al -Shahi Salman R, Steg PG, Huber K; ESC Working 
Group on Thrombosis. Management of antithrombotic therapy after bleeding in 
patients with coronary  artery disease and/or atrial fibrillation: expert consensus 
paper of the European Society of Cardiology Working Group on Thrombosis. Eur 
Heart J. 2017 May 14;38(19):1455 -1462. doi: 10.1093/eurheartj/ehw454. PMID: 
27789570.  
31. Henry Watson, et al. (2012). Gui delines on the diagnosis and management of 
Heparin -induced thrombocytopenia: second edition British Journal of 
Haematology.  
32. Hiệp hội huyết học Hoa Kỳ 2018 hướng dẫn quản lý thuyên tắc huyết khối tĩnh 
mạch: dự phòng huyết khối tĩnh mạch cho bệnh nhân Nội kh oa nằm viện và không 
nằm viện – ASH 2018  
33. Hiệp hội huyết học Hoa Kỳ 2019: Hướng dẫn quản lý thuyên tắc huyết khối tĩnh 
mạch: dự phòng huyết khối tĩnh mạch ở bệnh nhân phẫu thuật nội viện – ASH 
2019  
34. Hoàng Bùi H ải, Đỗ Doãn L ợi, Nguy ễn Đạt Anh (2013). Nghiên c ứu chẩn đoán và 
điều trị thuyên t ắc động m ạch ph ổi cấp, Lu ận án ti ến sĩ y h ọc. 
35. Hoàng Bùi Hải, Mai Đức Thảo, Lương Quốc Chính, Đỗ Ngọc Sơn, Đặng Quốc 
Tuấn, Nguyễn Gia Bình (2015), “Dự phòng HKTMS/Tắc động mạch phổi ở bệnh 
nhân hồi sức tích cực - Nhân một tr ường hợp tắc động mạch phổi cấp”, Tim mạch 
học Việt Nam, số 70, tr75 -80. 
36. Hoàng Bùi Hải, Nguyễn Khắc Điệp (2016), “Tình hình dự phòng TTHKTM ở bệnh 
nhân nội khoa cấp tính mới nhập viện tại bệnh viện đại học y Hà Nội”, Y học Việt 
Nam, Y học Việt Nam – tập 44 6 – tháng 9, số 1, tr.121 -6. 
37. Hồ Châu Anh Thư, Phan Thị Xuân, Phạm Thị Ngọc Thảo, Lê Minh Khôi (2018), 
Tỷ lệ và một số YTNC HKTMS chi dưới ở bệnh nhân tại khoa hồi sức bệnh viện 
Chợ Rẫy, Y học TP. Hồ Chí Minh , 22(2):45 -50. 
38. Hoàng Bùi Hải, Nguyễn Khắc Điệp (2 016), “Tình hình dự phòng TTHKTM ở bệnh 
nhân nội khoa cấp tính mới nhập viện tại bệnh viện đại học y Hà Nội”, Y học Việt 
Nam, Y học Việt Nam – tập 446 – tháng 9, số 1, tr.121 -6. 
39. Lương  Thanh Lâm, Bùi Th ị Hương Th ảo, Đỗ Giang Phúc và Hoàng Bùi H ải. Tình 
hình dự phòng thuyên t ắc huy ết khối tĩnh m ạch tại bệnh vi ện Đại học Y Hà N ội 
giai đo ạn 2021 -2022.  TCNCYH 14/2/2023.  
40. Hội Hồi sức Cấp cứu và chống độc Việt Nam (2017), “Hướng dẫn dự phòng 
TTHKTM ở bệnh nhân Hồi sức tích cực”.  
41. Hội Tim mạch học Việt Nam (2016), “ Hướng dẫn chẩn đoán, điều trị và dự phòng 
thuyên tắc huyết khối tĩnh mạch”.  
42. Hội Tim mạch học Việt Nam (2016), “Hướng dẫn chẩn đoán, điều trị và dự phòng 
thuyên tắc huyết khối tĩnh mạch”.  syt_bacgiang_vt_Van thu SYT Bac Giang_23/10/2023 11:45:0776 
 
43. Hướng dẫn dự phòng huyết khối tĩnh mạch (VTE) trên bệnh nhân trưởng t hành 
nằm viện ở Queensland 2018  
44. Huỳnh Văn Ân (2016), Nghiên cứu lâm sàng, một số YTNC HKTMS chi dưới ở 
bệnh nhân suy tim mạn tính, Y học TP. Hồ Chí Minh , 20(6):67 -73. 
45. Huỳnh Văn Ân, Ngô Văn Thành (2009) HKTMS ở bệnh nhân nội khoa tại khoa 
săn sóc đặc biệt ( ICU) bệnh viện Nhân Dân Gia Định. Y Học TPHCM 13, 127 -
134.   
46. Kaatz S, Ahmad D, Spyropoulos AC, Schulman S, for the Subcommittee on 
Control of Anticoagulation. Definition of clinically relevant non -major bleeding in 
studies of anticoagulants in atrial fibri llation and venous thromboembolic disease 
in non -surgical patients: communication from the SSC of the ISTH. J Thromb 
Haemost 2015; 13: 2119 –26. 
47. Kahn SR, Lim W, Dunn AS, et al. American College of Chest Physicians 
Prevention of VTE in nonsurgical patients: Antithrombotic Therapy and Prevention 
of Thrombosis, 9th ed: American College of Chest Physicians Evidence -Based 
Clinical Practice Guidelines. Chest. 2012;141(2 Suppl): e195S –e226S.  
48. Karen A. Hicks, MD; Norman L. Stockbridge, MD, PhD; Shari L. Targum, MD; 
Robert J. Temple, MD. Bleeding Academic Research Consortium Consensus 
Report the Food and Drug Administration Perspective. (Circulation. 2011; 
123:2664 -2665. DOI: 10.1161/CIRCULATIONAHA.111.032433 . 
49. Khorana AA, Francis CW, Culakova E, et al. Thromboembolism is a leading cause 
of death in cancer patients receiving outpatient chemotherapy. J Thromb Haemost 
2007; 5:632.  
50. Khorana AA. Risk assessment and prophylaxis for VTE in cancer patients. J Natl 
Compr Canc Netw 2011; 9:789.  
51. Khorana AA. Venous thromboembolism prevention in cancer outpatients. J Natl 
Compr Canc Netw 2013; 11:1431.  
52. Khuy ến cáo Hi ệp hội Ung thư lâm sàng Hoa K ỳ. 
53. Konstantinides SV, Torbiki A, Agnelli G, and Danchin N (2014), “ESC Guidelines 
on the diagnosis and management of acute pulmonary embolism”, Eur Heart J.  
54. Kucher N, Spirk D, Baumgartner I, et al. Lack of prophylaxis before the onset of 
acute venous thromboembolism among hospitalized cancer patients: the SWIss 
Venous ThromboEmbolism Registry (SWIVTER). Ann Oncol 2010; 21:931.  
55. Levitan N, Dowlati A, Remick SC, et al. Rates of initial and recurrent 
thromboembolic disease among patients with malignanc y versus those without 
malignancy. Risk analysis using Medicare claims data. Medicine (Baltimore) 1999; 
78:285 . 
56. Lim W. Usi ng low molecular weight Heparin in special patient populations. 
Journal of Thrombosis and Thrombolysis. 2010; 29:233 -40. 
57. Micromedex 2. United States: IBM Corporation; 2018.  
58. MIMS Online. Australia: MIMS; 2018.  
59. NCCN guidelines version 2.2021 https://www.nccn.org  syt_bacgiang_vt_Van thu SYT Bac Giang_23/10/2023 11:45:0777 
 
60. Nguyễn Văn Trí, Nguyễn Vĩnh Thống và cs: Nghiên cứu quan sát dịch tễ học tỷ lệ 
hiện mắc HKTMS ở chi dưới trên bệnh nhân phẫu thuật thay khớp hang . 
61. NICE clinical guideline 46. April 2007 (**) pages 1─163.  
62. Otto CM , Nishimura RA, Bonow RO, Carabello BA, Erwin JP 3rd, Gentile F, 
Jneid H, Krieger EV, Mack M, McLeod C, O’Gara PT, Rigolin VH, Sundt TM 3rd, 
Thompson A, Toly C. 2020 ACC/AHA guideline for the management of patients 
with valvular heart disease: a report of the American College of 
Cardiology/American Heart Association Joint Committee on Clinical Practice 
Guidelines. Circulation. 2021;143:e72 -e227. doi: 
10.1161/CIR.0000000000000923 . 
63. Phác đồ BV T ừ Dũ (2021), Q uy trình chuyên môn khám ch ữa bệnh d ự phòng 
TTHKTM  trong thai k ỳ. 
64. Phuc Do Giang, Anh Duy Nguyen, Hai Hoang Bui (2015), “Venous 
thromboembolism prophylaxis in at -risk inpatients with cancer in Hanoi Medical 
University Hospital, Vietnam”, Vietnam Journal of Medcicine and Pharmacy, 
VJMP 6 (3), p 31 -5. 
65. Powers  WJ, Rabinstein AA, Ackerson T, et al. Guidelines for the Early 
Management of Patients with Acute Ischemic Stroke: 2019 Update to the 2018 
Guidelines for the Early Management of Acute Ischemic Stroke: A Guideline for 
Healthcare Professionals From the Ameri can Heart Association/American Stroke 
Association [published correction appears in Stroke. 2019 Dec;50(12): e440 -
e441].  Stroke . 2019;50(12): e344 -e418. Doi:10.1161/STR.0000000000000211 . 
66. Practice Management Guidelines for the Prevention of Venous Thromboemb olism 
in Trauma Patients: The EAST Practice Management Guidelines Work Group 
2002 . 
67. Prevention of TTHKTM in Nonsurgical Patients, Antithrombotic Therapy and 
Prevention of Thrombosis, 9th ed: American College of Chest Physicians 
Evidence -Based Clinical Pract ice Guidelines, CHEST 2012; 141(2) (Suppl): 
e195S –e226S.  
68. Queensland Clinical Guidelines (2020), Venous thromboembolism (VTE) 
prophylaxis in pregnancy and the puerperium.  
69. Queensland Health. Guideline for the Prevention of Venous Thromboembolism 
(VTE) in Adu lt Hospitalised Patients. Dec 2018 . 
70. RCOG (2015), Throboembolic disease in pregnancy and the puerperium: acute 
managements  
71. Roberts C, Horner D, Coleman G, Maitland L, Curl -Roper T, Smith R, et al. 
Guidelines in Emergency Medicine Network - GEMNet: Guideline  for the use of 
thromboprophylaxis in ambulatory trauma patients requiring temporary limb 
immobilisation. United Kingdom, 2013.  
72. Rodina M, Michelle W, Rodgers G, Draper L, Pendleton R. Weight -based dosing 
of enoxaparin for VTE prophylaxis in morbidly obese,  medically - ill patients. 
Thrombosis Research. 2010;125(3):220 -3. syt_bacgiang_vt_Van thu SYT Bac Giang_23/10/2023 11:45:0778 
 
73. Rodina M, Michelle W, Rodgers G, Draper L, Pendleton R. Weight -based dosing 
of enoxaparin for VTE prophylaxis in morbidly obese, medically - ill patients. 
Thrombosis Research. 2010;125(3):2 20-3. 
74. Routheir N, Tagalakis V, Bouchard -Dechene V. VTE prophylaxis. BMJ Best 
Practice. Jan 2017 . 
75. Sancar Eke (2019). Heparin -Induced Thrombocytopenia. Updated: Dec 12, 2019 
https://emedi cine.medscape.com/article/1357846 -overview . 
76. Sandercock PA, Counsell C, Kane EJ. Anticoagulants for acute ischaemic 
stroke.  Cochrane Database Syst Rev . 2015;2015(3):CD000024. Published 2015 
Mar 12. Doi: 10.1002/14651858.CD000024.pub4 . 
77. Schunemann HJ, Wierci och W, Etxeandia I, et al. (2014). Guidelines 2.0: 
systematic development of a comprehensive checklist for a successful guideline ¨ 
enterprise. CMAJ;186(3): E123 -E142.  
78. Sebaaly J, Covert K. Enoxaparin Dosing at Extremes of Weight: Literature Review 
and Dosi ng Recommendations. Annals of Pharmacotherapy. 2018;52(9):898 -909. 
79. Senzel L, Coldren D. (2016). Negative Heparin -induced thrombocytopenia test 
result after massive transfusion: believe it or not? Am J Clin Pathol;145(5).  
80. Sun L, Gimotty PA, Lakshmanan S, Cu ker A. (2016). Diagnostic accuracy of rapid 
immunoassays for Heparin -induced thrombocytopenia. A systematic review and 
meta -analysis. Thromb Haemost;115(5):1044 -1055.  
81. TTHKTM và ngừa thai nội tiết. Hướng dẫn RCOG Greentop số 40. London: Royal 
College of Ob stetricians and Gynecologists, 2010.  
82. University of Winsconsin hospitals and clinics. Venous Thromboembolism 
Prophylaxis – Adult – Inpatient/Ambulatory –Clinical Practice Guideline.  
83. Uptodate version 2021 https://www.u ptodate.com  
84. Venclauskas L, Llau JV, Jenny J -Y, Kjaersgaard -Andersen P, Jans Ø. European 
guidelines on perioperative venous thromboembolism prophylaxis: Day surgery 
and fast -track surgery. European Journal of Anaesthesiology. 2018;35(2):134 -8. 
85. Viện Y tế và  Chăm sóc Sức khỏe: TTHKTM ở độ tuổi trên 16: giảm nguy cơ 
HKTMS nội viện hoặc TTP, NICE 2018  
86. Warkentin TE. (2017). Fondaparinux for treatment of Heparin -induced 
thrombocytopenia: too good to be true? J Am Coll Cardiol;70(21):2649 -2651.  
87. Whiteley WN, Adams  HP Jr, Bath PM, et al. Targeted use of Heparin, 
Heparinoids, or low -molecular -weight Heparin to improve outcome after acute 
ischaemic stroke: an individual patient data meta -analysis of randomised controlled 
trials.  Lancet Neurol . 2013;12(6):539 -545. Doi: 10.1016/S1474 -4422(13)70079 -6. 
88. William H. Geerts. Prevention of Venous Thromboembolism: American College of 
Chest Physicians (8th Edition) Evidence -Based Clinical Practice Guidelines. Chest 
2008; 133;381 -453.  
89. Witt DM, Nieuwlaat R, Clark NP, Ansell J, Holb rook A, Skov J, Shehab N, Mock 
J, Myers T, Dentali F, Crowther MA, Agarwal A, Bhatt M, Khatib R, Riva JJ, 
Zhang Y, Guyatt G. American Society of Hematology 2018 guidelines for syt_bacgiang_vt_Van thu SYT Bac Giang_23/10/2023 11:45:0779 
 
management of venous thromboembolism: optimal management of anticoagulation 
therapy. Blood Adv. 2018 Nov 27;2(22):3257 -3291. doi: 
10.1182/bloodadvances.2018024893. PMID: 30482765; PMCID: PMC6258922.  
90. Witt DM. What to do after the bleed: resuming anticoagulation after major 
bleeding. Hematology Am Soc Hematol Educ Progam. 2016 Dec 2; 20 16(1): 620 –
624. doi: 10.1182/asheducation -2016.1.620 PMCID: PMC6142471 PMID: 
27913537 . 
91. Yngve Falck -Ytter at el, Prevention of VTE in Orthopedic Surgery Patients: 
Antithrombotic Therapy and Prevention of Thrombosis, American College of 
Chest Physicians (9th  Edition) Evidence -Based Clinical Practice Guidelines, Chest 
2012 ; 141(2), e278S –e325S . 
 
syt_bacgiang_vt_Van thu SYT Bac Giang_23/10/2023 11:45:07

## Tóm tắt hướng dẫn điều trị suy tim của Hoa Kỳ ACC/AHA/HFSA 2022

ANAHEIM, CA – Hội Tim mạch học Hoa Kỳ (American College of Cardiology/ACC) và Hiệp hội Tim mạch Hoa Kỳ (American Heart Association/AHA)
Link tải PDF (Final): [**ACC 2022**](https://drive.google.com/file/d/1XT2nP1NZyVvJ_QVwrUNER6bjTTjRwbfo/view?usp=sharing)
**Thực hiện bởi Dược lâm sàng - Thông tin thuốc**

## HƯỚNG DẪN XÁC ĐỊNH TRẠNG THÁI CAI ĐẶC TRƯNG CÁC CHẤT MA TÚY

_(Ban hành kèm theo Thông tư số 18_ _/2021/TT-BYT ngày 16_ _tháng 11_ _năm 2021 của Bộ trưởng Bộ Y tế)_
1. Các dấu hiệu để xác định trạng thái cai các chất dạng thuốc phiện
a) Có bằng chứng về việc mới ngừng hoặc giảm sử dụng chất dạng thuốc phiện sau khi đã sử dụng chất này lặp đi lặp lại trong thời gian dài;
b) Có ít nhất 03 trong số 12 triệu chứng cai dưới đây xuất hiện sau dấu hiệu (a) trên đây vài phút đến vài ngày:
- Cảm giác thèm chất ma túy;
- Ngạt mũi hoặc hắt hơi;
- Chảy nước mắt;
- Đau cơ hoặc chuột rút;
- Co cứng bụng;
- Buồn nôn hoặc nôn;
- Tiêu chảy;
- Giãn đồng tử;
- Nổi da gà hoặc ớn lạnh;
- Nhịp tim nhanh hoặc tăng huyết áp;
- Ngáp;
- Ngủ không yên.
c) Các triệu chứng cai này không thể quy cho một bệnh nội khoa không liên quan đến việc sử dụng chất dạng thuốc phiện và không thể quy cho một rối loạn tâm thần hoặc một rối loạn hành vi khác.
2. Các dấu hiệu để xác định trạng thái cai các chất kích thần (các chất dạng amphetamine, cocain hoặc các chất kích thần khác):
a) Có bằng chứng về việc mới ngừng hoặc giảm sử dụng chất kích thần sau khi đã sử dụng chất này lặp đi lặp lại trong thời gian dài;
b) Có rối loạn khí sắc (buồn hoặc mất khoái cảm);
c) Có ít nhất 02 trong số 06 triệu chứng cai dưới đây xuất hiện sau dấu hiệu (a) trên đây vài giờ đến vài ngày:
- Ngủ lịm hoặc mệt mỏi;
- Chậm chạp hoặc kích động tâm thần vận động;
- Cảm giác thèm khát chất kích thần;
- Tăng khẩu vị;
- Mất ngủ hoặc ngủ nhiều;
- Có các giấc mơ kỳ quặc khó hiểu.
d) Các triệu chứng cai này không thể quy cho một bệnh nội khoa không liên quan đến việc sử dụng chất kích thần và không thể quy cho một rối loạn tâm thần hoặc một rối loạn hành vi khác.
3. Các dấu hiệu để xác định trạng thái cai cần sa
a) Có bằng chứng về việc mới ngừng hoặc giảm sử dụng cần sa sau khi đã sử dụng cần sa lặp đi lặp lại trong thời gian dài.
b) Có ít nhất 03 trong số 07 triệu chứng cai dưới đây xuất hiện sau dấu hiệu (a) trên đây trong vòng tối đa 05 ngày:
- Kích thích, giận dữ hoặc gây hấn;
- Căng thẳng hoặc lo âu;
- Rối loạn giấc ngủ (mất ngủ hoặc ác mộng);
- Chán ăn hoặc giảm cân;
- Đứng ngồi không yên;
- Giảm khí sắc;
- Ít nhất có 1 trong các triệu chứng sau: đau bụng, run ray, vã mồ hôi, sốt, ớn lạnh, đau đầu.
c) Các triệu chứng cai này không thể quy cho một bệnh nội khoa không liên quan đến việc sử dụng cần sa và không thể quy cho một rối loạn tâm thần hoặc một rối loạn hành vi khác.

## ️ Dịch truyền tĩnh mạch: tính chất và chỉ định

_**Textbook: Acid-Base, Fluids, and Electrolytes made ridiculously simple, 3rd edition, Richard A. Preston**_
Trên lâm sàng, chúng ta sẽ đối diện với rất nhiều loại túi và chai dịch, mỗi loại lại có những cái tên khác nhau như Saline 0.9% hay Saline 0.45% D5. Những loại dịch truyền đó chứa đựng những gì và sử dụng cho những mục đích nào? Hãy nhớ rằng mỗi loại dịch đều có cách sử dụng và những chỉ định riêng biệt. 
**1) Dung dịch chứa muối ăn – Sodium Chloride – Natri Clorua hay Saline mà trương lực của nó gần bằng với huyết tương nên được gọi là đẳng trương.** Thường gặp là dung dịch saline 0.9% và Ringer’s Lactate. Những loại dịch này thường được truyền với mục đích nhằm nâng thể tích dịch ngoại bào – ECFV (extracellular fluid volume). Nhìn chung, thường chuộng dùng những loại dịch đẳng trương hơn là nhược trương để nâng ECFV. Các dịch truyền như D5 (Glucose 5%), saline 0.45% và saline 0.45% D5 thì sẽ cung cấp nước tự do. Trong trường hợp suy giảm ECFV mà cung cấp thêm nhiều nước tự do có thể dẫn đến hạ natri máu.
Một số dung dịch saline đẳng trương có chứa thêm 5% glucose, như là D5 0.9% saline và Ringer’s Lactate D5 giúp cung cấp thêm một lượng nhỏ glucose (50 g/L). Trong điều kiện bình thường, đường sau đó được đưa vào trong tế bào mà không làm ảnh hưởng đáng kể đến đường huyết của bệnh nhân. Ví dụ như cho truyền một lít saline 0.9% D5, chúng ta đang cung cấp một lít saline nồng độ 0.9% vào ECFV và 50g glucose. Song, do đường được vận chuyển vào tế bào nên kết quả sau cùng đối với ECF chỉ là bổ sung thêm 1 lít 0.9% saline. Tuy nhiên, đối với những bệnh nhân đái tháo đường – khi mà glucose không được đưa vào tế bào một cách thuận lợi thì đường huyết có thể tăng khi dùng dịch có chứa 5% glucose. 
Một số trường hợp mà saline 0.9% thích hợp để chỉ định:
• Giảm ECFV trong mọi trường hợp – các loại dung dịch nhược trương có thể dẫn đến hạ natri máu trong trường hợp ECFV giảm. • Bù dịch sau phẫu thuật – dịch truyền nhược trương cũng có thể gây hạ natri máu ở đối tượng này. • Shock do mọi nguyên nhân. • Chảy máu. • Kết hợp với truyền máu – dung dịch nhược trương sẽ gây vỡ hồng cầu. • Bỏng
**2) Dung dịch saline nhược trương như: saline 0.45% có thể được xem như có 50% thể tích là dung dịch saline 0.9% (normal saline hay saline đẳng trương) và 50% thể tích còn lại là nước tự do.** Như vậy dung dịch này phù hợp được dùng với mục đích vừa muốn nâng ECFV, vừa muốn cung cấp thêm nước tự do. Những bệnh nhân như thế thường vừa có mất dịch mà vừa có áp suất thẩm thấu máu tăng (hoặc tăng natri máu hoặc tăng đường huyết nặng hoặc cả hai). Khi truyền dung dịch này, Na+ sẽ giúp nâng mức ECFV, trong khi đó nước sẽ giúp điều chỉnh trương lực của huyết tương. Các dung dịch nhược trương sẽ cung cấp nước tự do – có thể dẫn đến hạ natri máu. Vì thế cần phải theo dõi sát nồng độ natri huyết tương.
Dưới đây là một số trường hợp mà dung dịch saline nhược trương thích hợp sử dụng:
• Tăng áp suất thẩm thấu máu do tăng đường huyết nặng (saline 0.45% không chứa D5) • Tăng natri huyết đi kèm giảm ECFV
**3) Dung dịch D5 thường được dùng để cung cấp nước tự do và có thể hữu ích trong trường hợp điều trị tăng natri máu nặng miễn là không gây glucose niệu.** Một lít D5 cung cấp 1 lít nước cho bệnh nhân. Lượng nước này sẽ phân bố cả ECFV và ICFV, cùng với 50g glucose mà thông thường sẽ đi vào tế bào. Kết quả sau cùng còn lại tương đương cung cấp 1 lít nước tự do cho bệnh nhân. Không dùng nước tinh khiết để truyền TM do gây tán huyết. D5 cũng thường được dùng làm dung môi pha thuốc. Một lợi điểm của D5 là không cung cấp Na+ mà nếu như không cần thiết có thể gây quá tải ECFV. D5 cũng có thể được truyền với tốc độ thấp (10-25ml/h) để giữ kim luồn TM không bị tắc.
Một số trường hợp có thể dùng D5:
• Điều trị tăng natri máu nặng – theo dõi sát đường huyết và đường niệu ở bệnh nhân. • Truyền thuốc ở những bệnh nhân không mắc đái tháo đường. • Chống tắc kim luồn ở những bệnh nhân quá tải ECFV – D5 không chứa Na+ nên không làm tăng thêm ECFV nhiều như các dụng dịch saline.
**4) Nếu khả thi, bù kali qua đường uống là tốt nhất.** Chỉ định bổ sung kali đường tĩnh mạch có thể được dùng khi:
• Bệnh nhân hạ kali máu nặng, đe dọa tính mạng • Bệnh nhân không dung nạp với kali đường uống. • Dùng ở mức liều duy trì khi đã tính toán kỹ lưỡng.
Truyền kali đường TM tiềm ẩn nhiều mối nguy hiểm do nguy cơ gây tăng kali máu cấp tính (hãy nhớ là cân bằng kali giữa nội-ngoại bào rất khó đánh giá). Kali có tính kích ứng với TM nên nồng độ K+ vượt quá 30 mEq/L dịch truyền hay tốc độ truyền quá 10 mEq/h thường không được khuyến cáo trong những trường hợp không cấp cứu.
**5) Một trong những đánh giá rất quan trọng nhưng thường bị bỏ qua chính là cân nặng của bệnh nhân.** Mọi bệnh nhân được điều trị với dịch truyền đường TM cần được kiểm tra cân nặng mỗi ngày nếu có thể. Cân nặng bệnh nhân thay đổi đột ngột có thể gợi ý về bất thường trong cân bằng dịch của bệnh nhân.
**6) Nhìn chung, nồng độ điện giải, BUN và creatinine (Cr) trong máu nên được kiểm tra hằng ngày ở những bệnh nhân có dịch truyền TM để theo dõi.** Nên kiểm tra thường xuyên hơn ở những bệnh nhân truyền dịch tốc độ lớn hay rối loạn điện giải nặng. Chỉ định điều trị cho mỗi bệnh nhân cần được thực hiện tỉ mỉ và đánh giá lại mỗi ngày.
Nói chung, cân nặng, điện giải, BUN và Cr cần được theo dõi mỗi ngày ở mọi bệnh nhân có truyền dịch TM. Một số bệnh trạng phổ biến như giảm chức năng thận, suy tim sung huyết và bệnh gan có thể ảnh hưởng rất nhiều đến chế độ điều trị cho bệnh nhân. 
**7) Một điều nữa cần cẩn trọng, nhiều bệnh nhân nhập viện với những bệnh cảnh tiềm tàng khả năng làm tăng ADH trong máu như: đau, buồn nôn, có các can thiệp ngoại khoa và do thuốc.** Truyền các loại dịch nhược trương có thể đưa đến tích tụ nước tự do quá mức và nguy cơ gây hạ natri máu. Nhu cầu dịch truyền TM nên được lượng giá cẩn trọng ở mỗi bệnh nhân và dịch nhược trương không nên được chỉ định thường quy hay khi không thể theo dõi sát. 
Khi quyết định sử dụng đường truyền TM, dịch truyền nên được sử dụng thận trọng và theo dõi sát điện giải và cân nặng (tối thiểu là hàng ngày).
**8) Đối với những bệnh nhân có bệnh mạn tính, loạn dưỡng hay nghiện rượu; có thể lượng thiamine (Vitamin B1) trong cơ thể cùng với các loại vitamin khác và điện giải trở nên thiếu hụt.** Truyền các loại dung dịch có chứa glucose cho các bệnh nhân như vậy rất nguy hiểm vì nguy cơ gây bệnh não Wernicke và dẫn đến các tổn thương vĩnh viễn ở hệ thần kinh. Chú ý bổ sung thiamine trước khi chỉ định các loại dịch như thế ở các bệnh nhân nghiện rượu hoặc suy dinh dưỡng. Thường sử dụng (đối với cơ sở của tác giả) một loại chế phẩm (gọi là “rally pack”) có chứa:
• 100 mg thiamine đường TM • 5 mg folate (B9) đường TM • 1 ống multi-vitamin đường TM
Liều thiamine có thể lặp lại để đảm bảo nguồn dữ trữ vitamine này trong cơ thể được phục hồi. Chúng ta cũng nên đánh giá những bệnh nhân nghi ngờ loạn dưỡng dể tìm các dấu hiệu thiếu Calcium (Ca), Phosphorus hay Magnegium (Mg) – thường ít khi rõ ràng trong 2-3 ngày đầu.
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh

## Hướng dẫn chẩn đoán và điều trị đái tháo đường típ 1 ở trẻ em và thanh thiếu niên

Xem toàn bộ tài liệu [**tại đây**](https://bvnguyentriphuong.com.vn/uploads/112023/files/Quye%CC%82%CC%81t%20%C4%91i%CC%A3nh-1760-Q%C4%90-BYT.pdf)
#### Nội dung trong file:

háng   
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
  
HƯỚNG DẪN CHẨN ĐOÁN VÀ ĐIỀU TRỊ  
BỆNH ĐÁI THÁO ĐƯỜNG TÍP 1 
Ở TRẺ EM  VÀ THANH THIẾU NIÊN  
                (Ban hành kèm theo Quyết định số         /QĐ-BYT 
ngày      tháng     năm 2024 ) 
Hà Nội, 2024  
  2 
 
 CHỈ ĐẠO BIÊN SOẠN  
GS.TS. Trần Văn Thuấn – Thứ trưởng Bộ Y tế  
 
CHỦ BIÊN  
PGS.TS. Lương Ngọc Khuê, Phó Chủ tịch Hội đồng Y khoa Quốc gia , nguyên Cục 
trưởng Cục Quản lý Khám, chữa bệnh;  
GS.TS. Trần Hữu Dàng – Chủ tịch Liên đoàn Nội tiết Đông Nam Á, Chủ tịch Hội 
Nội tiết – Đái tháo đường Việt Nam ; 
PGS.TS. Trần Minh Điển  – Chủ tịch Hội Nhi khoa Việt Nam  
 
THAM  GIA BIÊN SOẠN VÀ THẨM ĐỊNH  
TS. Nguyễn Quang Bảy – Trưởng khoa Nội tiết – Đái tháo đường, Bệnh viện Bạch Mai;  
BSCKI. Lê Thanh Bình  – Phó Trưởng khoa Thận – Nội tiết, Bệnh viện Nhi đồng 
Thành phố  Hồ Chí Minh ; 
PGS.TS. Phan Hướng Dương – Phó Giám đốc Bệnh viện Nội tiết Trung ương;  
PGS.TS . Vũ Chí Dũng  – Giám đốc Trung tâm Nội tiết, Chuyển hóa, Di truyền và 
Liệu pháp phân tử, Bệnh viện Nhi Trung ương;  
TS. Phan Hữu Hên – Trưởng khoa Nội tiết, Bệnh viện Chợ Rẫy;  
TS. Nguyễn Trọng Khoa – Phó Cục trưởng phụ trách quản lý, điều hành Cục Quản lý 
Khám, chữa bệnh;  
PGS.TS. Trần Thừa Nguyên  – Trưởng khoa Nội tổng hợp – Lão khoa, Bệnh viện Đa 
khoa Trung ương Huế ;  
TS. Huỳnh Thị Vũ Quỳnh  – Trưởng khoa Thận – Nội tiết, Bệnh viện Nhi đồng 2, 
Thành phố  Hồ Chí Minh ; 
BSCKII. Ng uyễn Đức Quang – Trưởng khoa Thận – Nội tiết, Bệnh viện Nhi đồng 1, 
Thành phố  Hồ Chí Minh;  
BSCKII. Nguyễn Thị Thu – Khoa Nội tiết – Đái tháo đường, Bệnh viện Bạch Mai ; 
PGS.TS. Hoàng Thị Thủy Yên – Bộ môn Nhi, Trường Đại học Y Dược Huế . 
 
TỔ THƯ KÝ  
TS. Cấn Thị Bích Ngọc – Trung tâm Nội tiết, Chuyển hóa, Di truyền và Liệu pháp 
phân tử, Bệnh viện Nhi Trung ương;  
ThS. Trương Lê Vân Ngọc – Trưởng phòng Nghiệp vụ - Bảo vệ sức khoẻ cán bộ, Cục 
Quản lý Khám, chữa bệnh, Bộ Y tế;  
TS. Bùi Phương Thảo – Phó Giám đốc  Trung tâm Nội tiết, Chuyển hóa, Di truyền và 
Liệu pháp phân tử, kiêm Trưởng khoa Nội tiết và Đái tháo đường, Bệnh viện Nhi 
Trung ương;  
CN. Đỗ Thị Thư – Cục Quản lý Khám, chữa bệnh, Bộ Y tế.  3 
 
 LỜI NÓI ĐẦU  
 
Đái tháo đường (ĐTĐ) là một trong những vấn đề y t ế toàn cầu lớn nhất của thế kỷ 21, làm 
chậm quá trình phát triển kinh tế, cản trở quá trình đạt mục tiêu phát triển bền vững, đặc biệt 
ở các nước thu nhập thấp và trung bình. Bệnh ĐTĐ  phổ biến nhất ở trẻ em và thanh thiếu niên 
là ĐTĐ típ 1, theo thống kê Đ TĐ típ 1 chiếm 90% bệnh ĐTĐ ở trẻ em.  
Theo Liên đoàn Đái tháo đường Thế giới ( IDF) năm 2022, trên thế giới có 8,75 triệu người 
đang chung sống với ĐTĐ  típ 1, trong đó 1/5 số người sống ở các nước thu nhập thấp và trung 
bình thấp. Về phân bố nhóm tuổi, 1 ,52 triệu người (17 ,4%) dưới 20 tuổi, 5 ,56 triệu người 
(63,5%) ở độ tuổi 20 -59 và 1 ,67 triệu người (19 ,1%) ở độ tuổi từ 60 trở lên đang chung sống 
với bệnh. Tính riêng năm 2022, trên toàn cầu có tới 530.000 ca mắc ĐTĐ  típ 1 mới ở mọi lứa 
tuổi, trong đó có 20 1.000 người mắc ở độ tuổi dưới 20i. Tại Việt Nam, hiện chưa có dữ liệu 
đầy đủ về dịch tễ của ĐTĐ típ 1.  
Để tăng cường chuẩn hóa  và chất lượng trong khám bệnh, chữa bệnh ĐTĐ típ 1 , dựa trên tiến 
bộ khoa học kỹ thuật  và các  khuyến cáo quốc tế , Bộ Y tế đã triển khai xây dựng  Hướng dẫn 
chẩn đoán và điều trị ĐTĐ  típ 1 ở trẻ em  và thanh thiếu niên . Hướng dẫn tập trung chủ yếu 
vào thực hành lâm sàng chẩn đoán và điều trị ĐTĐ  típ 1.  
Hướng dẫn chẩn đoán và điều trị bệnh ĐTĐ  típ 1 ở trẻ em và thanh thiếu niên được x ây dựng 
với đóng góp  chuyên môn của hai hội y khoa chuyên ngành: Hội Nội tiết - Đái tháo đường 
Việt Nam và Hội Nhi khoa Việt Nam và các chuyên gia về nội tiết  và nhi khoa  có kinh nghiệm 
lâm sàng, giảng dạy và soạn thảo tài liệu chuyên môn  của một số bệnh v iện. Bộ Y tế đánh giá 
cao và ghi nhận những đóng góp tích cực, có giá trị của Hội Nội tiết - Đái tháo đường Việt 
Nam và Hội Nhi khoa Việt Nam và các chuyên gia trong xây dựng tài liệu hướng dẫn chuyên 
môn quan trọng này.  
Chúng tôi xin trân trọng cảm ơn Bà Đào Hồng Lan - Bộ trưởng Bộ Y tế, GS.TS. Trần Văn 
Thuấn - Thứ trưởng Bộ Y tế đã chỉ đạo tích cực hoạt động xây dựng các hướng dẫn chuyên 
môn, quy trình kỹ thuật khám bệnh, chữa  bệnh.  
Tài liệu chuyên môn “Hướng dẫn chẩn đoán và điều trị bệnh đái tháo đường  típ 1 ở trẻ em  và 
thanh thiếu niên ” năm 2024 là ấn bản đầu tiên có thể còn nhiều thiếu sót, chúng tôi rất mong 
nhận được sự đóng góp từ quý độc giả, đồng nghiệp để Tài liệu ngày một hoàn thiện hơn.  
 
THAY MẶT NHÓM BIÊN SOẠN  
GS.TS. TRẦN HỮU DÀNG  
 
 
i https://diabetesatlas.org/idfawp/resource -files/2021/07/IDF_Atlas_10th_Edition_2021.pdf  
ii https://diabetesatlas.org/atlas/t1d -index -2022/  4 
 
 MỤC LỤC 
LỜI NÓI Đ ẦU -------------------------------- -------------------------------- -------------------------------- -----------------------------  3 
DANH M ỤC CÁC T Ừ VIẾT TẮT -------------------------------- -------------------------------- -------------------------------- -------  5 
PHẦN 1: Đ ỊNH NGHĨA VÀ D ỊCH T Ễ-------------------------------- -------------------------------- -------------------------------- -- 6 
PHẦN 2: PHÂN LO ẠI VÀ CH ẨN ĐOÁN ĐÁI THÁO ĐƯ ỜNG Ở TRẺ EM VÀ THANH THI ẾU NIÊN  ---------------------  7 
1. Phân lo ại đái tháo đư ờng -------------------------------- -------------------------------- -------------------------------- --- 7 
2. Chẩn đoán  -------------------------------- -------------------------------- -------------------------------- ----------------------  8 
PHẦN 3: CƠ CH Ế BỆNH SINH VÀ CÁC GIAI ĐOẠN ĐÁI THÁO ĐƯ ỜNG TÍP 1  -------------------------------- -----------  11 
PHẦN 4: ĐI ỀU TR Ị ĐÁI THÁO ĐƯ ỜNG KHÔNG CÓ BI ẾN CH ỨNG NHI ỄM TOAN CETON KHI M ỚI CHẨN 
ĐOÁN  -------------------------------- -------------------------------- -------------------------------- -------------------------------- ----- 12 
1. Thăm khám lâm sàng  -------------------------------- -------------------------------- -------------------------------- --------  12 
2. Điều trị -------------------------------- -------------------------------- -------------------------------- --------------------------  12 
PHẦN 5: CH ẨN ĐOÁN VÀ ĐI ỀU TR Ị NHIỄM TOAN CETON DO ĐÁI THÁO ĐƯ ỜNG VÀ TÌNH TR ẠNG TĂNG 
GLUCOSE HUY ẾT TĂNG ÁP L ỰC TH ẨM TH ẤU -------------------------------- -------------------------------- ------------------  14 
1. Toan ceton do đái tháo đư ờng -------------------------------- -------------------------------- ----------------------------  14 
2. Tình tr ạng tăng Glucose huy ết tương tăng áp l ực thẩm thấu -------------------------------- ----------------------  22 
PHẦN 6: S Ử DỤNG INSULIN ĐI ỀU TR Ị ĐÁI THÁO ĐƯ ỜNG TÍ P 1 Ở TRẺ EM VÀ THANH THI ẾU NIÊN  ------------  25 
1. Phân lo ại Insulin  -------------------------------- -------------------------------- -------------------------------- -------------  25 
2. Nguyên t ắc của liệu pháp Insulin  -------------------------------- -------------------------------- ------------------------  26 
3. Hướng dẫn chỉnh liều -------------------------------- -------------------------------- -------------------------------- -------  27 
4. Đường dùng và cách b ảo quản -------------------------------- -------------------------------- ---------------------------  29 
PHẦN 7: DINH DƯ ỠNG VÀ T ẬP LUY ỆN TRONG ĐÁI THÁO ĐƯ ỜNG TÍP 1 Ở TRẺ EM VÀ THANH THI ẾU NIÊN  32 
1. Chế độ dinh dư ỡng -------------------------------- -------------------------------- -------------------------------- -----------  32 
2. Chế độ vận động và t ập luy ện -------------------------------- -------------------------------- -----------------------------  35 
PHẦN 8: THEO DÕI GLUCOS E HUY ẾT TRONG ĐÁI THÁO ĐƯ ỜNG TÍP 1  Ở TRẺ EM VÀ THANH THI ẾU NIÊN  --- 37 
1. HbA1c  -------------------------------- -------------------------------- -------------------------------- ---------------------------  38 
2. Test glucose mao m ạch - SMBG  -------------------------------- -------------------------------- --------------------------  38 
3. Theo dõi glucose huy ết liên t ục (CGM)  -------------------------------- -------------------------------- -----------------  39 
PHẦN 9: CHĂM SÓC TR Ẻ ĐÁI THÁO ĐƯ ỜNG TÍP 1 KHI B Ị ỐM -------------------------------- -----------------------------  40 
1. Theo dõi glucose huy ết thường xuyên hơn  -------------------------------- -------------------------------- -------------  40 
2. Không d ừng insulin  -------------------------------- -------------------------------- -------------------------------- ----------  40 
3. Kiểm tra ceton trong nư ớc tiểu -------------------------------- -------------------------------- ---------------------------  40 
4. Điều chỉnh insulin  -------------------------------- -------------------------------- -------------------------------- ------------  40 
5. Chăm sóc tr ẻ đái tháo đư ờng sử dụng bơm insulin khi b ị ốm -------------------------------- ---------------------  41 
PHẦN 10: H Ạ GLUCOSE HUY ẾT TRONG ĐÁI THÁO ĐƯ ỜNG Ở TRẺ EM VÀ THANH THI ẾU NIÊN  ------------------  42 
1. Nguyên nhân và các y ếu tố gây h ạ glucose huy ết -------------------------------- -------------------------------- ---- 42 
2. Triệu chứng lâm sàng  -------------------------------- -------------------------------- -------------------------------- -------  42 
3. Biến chứng của hạ glucose huy ết trong đái tháo đư ờng -------------------------------- ----------------------------  43 
4. Xử trí và d ự phòng  -------------------------------- -------------------------------- -------------------------------- -----------  43 
PHẦN 11: BI ẾN CH ỨNG M ẠCH MÁU TRONG ĐÁI THÁ O ĐƯ ỜNG  Ở TRẺ EM VÀ THANH  THIẾU NIÊN  ---------  46 
1. Sàng l ọc và ch ẩn đoán  -------------------------------- -------------------------------- -------------------------------- ------  46 
2. Điều trị -------------------------------- -------------------------------- -------------------------------- --------------------------  51 
PHẦN 12: PH ẪU THU ẬT TRÊN TR Ẻ EM VÀ THANH THI ẾU NIÊN M ẮC BỆNH ĐÁI THÁO ĐƯ ỜNG -----------------  54 
1. Đích glucose huy ết dành cho ph ẫu thu ật -------------------------------- -------------------------------- ---------------  54 
2. Phân lo ại phẫu thu ật/thủ thuật và đánh giá trư ớc phẫu thu ật -------------------------------- --------------------  54 
3. Chăm sóc trư ớc mổ cho tr ẻ đái tháo đư ờng đi ều trị bằng Insulin  -------------------------------- ---------------  54 
PHỤ LỤC 1: T ỐC ĐỘ BÙ D ỊCH THEO CÂN N ẶNG VÀ M ỨC ĐỘ MẤT NƯ ỚC TRONG NHI ỄM TOAN  CETON DO 
ĐÁI THÁO ĐƯ ỜNG (ML/KG/GI Ờ) -------------------------------- -------------------------------- -------------------------------- - 57 
PHỤ LỤC 2: CÁC LO ẠI INSULIN VÀ TH ỜI GIAN TÁC D ỤNG KHI TIÊM DƯ ỚI DA  -------------------------------- -------  58 
PHỤ LỤC 3: V Ị TRÍ TIÊM INSULIN VÀ KH Ả NĂNG H ẤP THU C ỦA TỪNG V Ị TRÍ -------------------------------- ---------  59 
TÀI LI ỆU THAM KH ẢO -------------------------------- -------------------------------- -------------------------------- ----------------  60 
 5 
 
 DANH MỤC CÁC TỪ VIẾT TẮT  
 
ACR  Urine albumin to creatinine ratio ( albumin ni ệu tính theo creatinine)  
ARDS  Acute respiratory distress syndrome  (hội chứng suy hô h ấp tiến triển)  
CGM  Continuous gluco se monitoring (theo dõi glucose  liên t ục) 
DNA  Axit deoxyribonucleic  
DME  Diabetic macular edema (phù hoàng đi ểm) 
ĐTĐ  Đái tháo đư ờng 
DKA  Diabetic ketoacidosis ( toan ceton do đái tháo đư ờng) 
MODY  Maturity onset diabetes of the young  (đái tháo đư ờng kh ởi phát ở người trẻ 
tuổi) 
EMA  European Medical Agency (Cơ quan Y t ế châu Âu)  
FDA  U.S. Food and Drug Administration (Cơ quan qu ản lý Thực phẩm và Dược 
phẩm Hoa K ỳ) 
HHS  Hyperosmolar Hyperglycaemic State  (hội chứng tăng glucose huy ết tăng áp 
lực thẩm thấu) 
MDI  Multiple daily injection  (tiêm nhi ều lần mỗi ngày)  
NPDR  Nonproliferative diabetic retinopathy (b ệnh võng m ạc không tăng sinh)  
PDR  Prolife rative diabetic retinopathy (b ệnh võng m ạc tăng sinh)  
SMBG  Self-monitoring of blood glucose ( tự theo dõi glucose mao m ạch) 
VEGF  Vascular endothelial growth factor  (yếu tố tăng trư ởng nội mạch) 
 
 
 
 
 
 
 
 
 
 6 
 
 PHẦN 1: ĐỊNH NGHĨA V À DỊCH TỄ  
 
Bệnh đái tháo đư ờng (ĐTĐ)  là rối loạn chuy ển hóa ph ức tạp, đư ợc đặc trưng b ởi tăng glucose 
huyết mạn tính do khi ếm khuy ết về bài ti ết insulin, ho ạt động của insulin ho ặc cả hai. Bài ti ết 
insulin không đ ủ và/ho ặc giảm ph ản ứng của mô v ới insulin d ẫn đến thi ếu hoạt động của 
insulin trên các mô đích, gây nên r ối loạn chuyển hóa của cacbohydrat , protide , lipid. ĐTĐ  
típ 1, đư ợc đặc trưng b ởi sự phá h ủy các t ế bào β, thư ờng do quá trình t ự miễn, dẫn đến mất 
khả năng s ản xuất insulin n ội sinh.  
ĐTĐ típ 1 là loại ĐTĐ  phổ biến nhất ở trẻ em và thanh thi ếu niên, chi ếm 90% b ệnh ĐTĐ  ở 
trẻ em. Ngày nay có s ự thay đ ổi đáng k ể trong t ỷ lệ mắc ĐTĐ  ở trẻ em. Theo Liên đoàn Đái 
tháo đư ờng Thế giới, năm 2021 , tỷ lệ mắc ĐTĐ  cao nh ất ở Phần Lan chi ếm tới 52,2/100.000 
người, đáng chú ý 04 trong 10 quốc gia có t ỷ mắc cao nh ất có tên các nư ớc không thu ộc châu 
Âu như: Kuwait, Quatar, Ả Rập Saudi và Algerie, trong khi đó t ỷ lệ mắc ở Trung Qu ốc và 
Nhật Bản dao đ ộng từ 1,9 đ ến 2,2/100.000 ngư ời 1 năm.  
Ngoài s ự khác bi ệt lớn về tỷ lệ mắc bệnh gi ữa các qu ốc gia, còn có s ự khác bi ệt đáng k ể về 
mặt địa lý trong chính các qu ốc gia liên quan đ ến chủng tộc/dân t ộc. Ví d ụ: tỷ lệ mắc ĐTĐ 
típ 1 ở người da tr ắng không ph ải gốc Tây Ban Nha cao hơn so v ới các thanh thiếu niên dưới 
20 tu ổi gốc Tây Ban Nha, ngư ời da đen  và ngư ời Mỹ gốc Ấn Độ. Tỷ lệ mắc ĐTĐ ở trẻ em 
cao hơn liên quan đ ến yếu tố môi trư ờng như m ức độ đô th ị hoá, m ật độ dân s ố, tình tr ạng 
kinh t ế xã hội, vĩ đ ộ hoặc kho ảng cách xa hơn so v ới đường xích đ ạo. Các y ếu tố tiềm ẩn sự 
khác bi ệt về địa lý trong t ỷ lệ mắc ĐTĐ típ  1 ở trẻ em v ẫn chưa đư ợc hiểu rõ. 
Nhìn chung, không có s ự khác bi ệt đáng k ể về tỷ lệ mắc ĐTĐ típ 1  ở trẻ em theo gi ới tính. 
Tuy nhiên, tr ẻ nam trên 15 tu ổi chiếm ưu th ế trong t ỷ lệ mắc ĐTĐ típ 1 . Tỷ lệ mắc ĐTĐ típ 
1 ở trẻ em thay đ ổi theo đ ộ tuổi, tuổi khởi phát hay g ặp nhất từ 10-14 tu ổi ở nhiều quần thể. 
Những năm g ần đây, đ ộ tuổi khởi phát b ệnh đang có xu hư ớng gi ảm dần ở một số quốc gia.  
Tỷ lệ phát hi ện bệnh ĐTĐ típ 1  ở trẻ em cao nh ất vào nh ững tháng mùa thu và mùa đông.  
Dịch tễ học của bệnh ĐTĐ  ở trẻ em đang ti ếp tục thay đ ổi với sự khác bi ệt rõ r ệt giữa các 
quốc gia và các nhóm nhân kh ẩu học khác nhau trong chính các qu ốc gia.  
Ở Việt Nam, hi ện chưa có d ữ liệu đầy đủ về dịch tễ của ĐTĐ típ 1 ở trẻ em. Dữ liệu từ các 
bệnh vi ện chuyên khoa  nhi cho th ấy cả nước có kho ảng gần 2000 tr ẻ được chẩn đoán ĐTĐ 
típ 1. T ại Bệnh vi ện Nhi Trung ương trong 33 năm có 943 tr ẻ được chẩn đoán ĐTĐ típ 1, 
tính đ ến nay s ố trẻ mắc < 18 tu ổi vẫn đang đư ợc điều trị và qu ản lý là 586 tr ẻ. Số trẻ mắc 
ĐTĐ típ 1 có xu  hướng gi a tăng trong c ả nước từ 7 năm g ần đây . Tại Bệnh vi ện Nhi Trung 
ương , từ năm 2017 đ ến 2023,  mỗi năm có t ừ 60 đến 95 trẻ mới được chẩn đoán ĐTĐ típ 1.   7 
 
 PHẦN 2: PHÂN LOẠI VÀ  CHẨN ĐOÁN ĐÁI THÁO ĐƯỜNG  
 Ở TRẺ EM VÀ THANH THIẾU NIÊN  
 
1. Phân lo ại đái tháo đ ường 
Phân lo ại ĐTĐ  đóng vai trò quan tr ọng để xác đ ịnh phương pháp đi ều trị, tối ưu hoá đi ều trị 
cho t ừng cá th ể. Ở trẻ em và thanh thi ếu niên, ĐTĐ đư ợc phân ra các th ể như sau : 
1.1. Đái tháo đư ờng típ 1 
- Do phá hu ỷ tế bào β, d ẫn đến thiếu hụt insulin hoàn toàn  
- Do mi ễn dịch (đ ặc trưng b ởi sự xuất hiện của một hoặc nhi ều các kháng th ể tự miễn) 
- Vô căn  
1.2. Đái tháo đư ờng típ 2: do kháng insulin v ới sự thiếu hụt insulin tương đ ối và sau đó tăng 
glucose huy ết 
1.3. Các nhóm khác  
b) Các d ạng ph ổ biến của bệnh ĐTĐ  đơn gen:  
- ĐTĐ  khởi phát ở người trẻ tuổi (MODY), nhóm này bao g ồm ĐTĐ đo đ ột biến các 
gen HNF4 -A; GCK ; HNF1A ; HNF1B  
- ĐTĐ  sơ sinh do đ ột biến các gen:  KCNJ11 ; INS; ABCC 8; 6q24  (PLAGL1, HYMA1) ; 
GATA6 ; EIF2AK3 ; FOXP3  
c) Khiếm khuy ết di truy ền trong ho ạt động của insulin:  
- INSR  
- Loạn dưỡng m ỡ toàn thân b ẩm sinh  
- Loạn dưỡng m ỡ cục bộ có tính ch ất gia đình  
- PIK3R1 ( hội chứng lùn)  
d) Các b ệnh về tụy ngo ại tiết: 
- Viêm t ụy, chấn thương/ph ẫu thu ật cắt tụy, u tân sinh , ĐTĐ liên quan đ ến xơ nang , thừa 
sắt liên quan đ ến truy ền máu  
e) Các b ệnh nội tiết như h ội chứng cushing , cường giá p, u tủy thư ợng th ận, u tiết glucagon , 
u tế bào sigma đ ảo tụy Langerhans ( Somatostatinoma) . 
f) Do thu ốc hoặc hóa ch ất: các thu ốc corticoid , thuốc ức chế protease (th ế hệ thứ nhất), nhóm 
thuốc statin , diazoxide , phenytoin , L-asparaginase , pentamidine , thuốc lợi tiểu thiazide , 
hocmon tăng trư ởng tái t ổ hợp.  
g) Nhiễm trùng:  rubella b ẩm sinh , enterovirus , cytomegalovirus  
h) Các d ạng bệnh ĐTĐ  qua trung gian mi ễn dịch không ph ổ biến: 
- Kháng th ể kháng th ụ thể insulin  
- Thiếu hụt tự miễn dịch đa tuy ến nội tiết APS I và II  8 
 
 i) Các h ội chứng di truy ền khác:  
- Hội chứng Down  
- Hội chứng Klinefelter  
- Hội chứng Turner  
- Chứng m ất điều hòa Friedreich  
- Loạn dưỡng tăng trương l ực cơ 
- Rối loạn chuy ển hóa porphyrin  
- Hội chứng Prader - Willi  
1.4. Phân bi ệt đái tháo đường típ 1, típ 2 và đái tháo đư ờng đơn gen  
 
Bảng 1. Đặc điểm lâm sàng c ủa ĐTĐ típ 1, típ 2 và ĐTĐ đơn gen  
ở trẻ em và thanh thi ếu niên  
 
Đặc điểm Típ 1  Típ 2  Đơn gen  
Di truy ền Đa gen  Đa gen  Đơn gen  
Tuổi khởi phát  6 tháng tu ổi – 
người trư ởng 
thành tr ẻ tuổi Thường tu ổi dậy thì 
hoặc mu ộn hơn  Thường sau tu ổi dậy 
thì, ngo ại trừ ĐTĐ sơ 
sinh ho ặc ĐTĐ do 
đột biến GCK  
Triệu chứng lâm 
sàng Hầu hết cấp tính, 
diễn biến nhanh  Khác nhau: t ừ diễn biến 
chậm, nh ẹ (âm th ầm) 
hoặc nặng Khác nhau, có th ể 
tình c ờ phát hi ện như 
đột biến GCK  
Các bi ểu hiện kết hợp khác  
Tự miễn Có  Không  Không  
Nhiễm toan 
ceton  Phổ biến Không ph ổ biến Phổ biến ở ĐTĐ sơ 
sinh, hi ếm ở các th ể 
khác  
Béo phì  Tương đương v ới 
tỉ lệ của quần thể 
bình thư ờng Tỉ lệ cao có béo phì  Tương đương v ới tỉ 
lệ của quần thể bình 
thường 
Gai đen  Không  Có Không  
Tỉ lệ % trong s ố 
ĐTĐ ở người trẻ Thường > 90%  Hầu hết các nư ớc < 10% 
(Nhật Bản 60-80%)  1-4% 
Bố mẹ mắc ĐTĐ  2-4% 80% 90% 
 
2. Chẩn đoán  
2.1. Tiêu chu ẩn chẩn đoán ĐTĐ dựa vào 1 trong 4 tiêu chí sau đây:  9 
 
 i/ Người bện h có các triệu chứng cổ điển của tăng glucose huyết hoặc của cơn tăng glucose 
huyết cấp kèm theo mức glucose huyết tương bất kỳ ≥ 200 mg/dL  (11,1 mmol/L ). hoặc 
ii/ Glucose  huyết tương  lúc đói ≥ 126 mg/dL  (hay 7,0 mmol/L ), hoặc 
iii/ Glucose huyết tương ở thời điểm sau 2 giờ thực hiện nghiệm pháp  dung nạp glucose 
đường uống ≥ 200 mg/dL  (hay 11,1 mmol/L ), hoặc  
iv/ HbA1C ≥ 6,5% (48 mmol/mol) . Xét nghiệm phải được thực hiện bằng phương pháp đã 
chuẩn hóa theo tiêu chuẩn quốc tế.    
Chẩn đoán xác đ ịnh nếu có 2 kết quả trên ngư ỡng ch ẩn đoán trong cùng 1 m ẫu máu xét 
nghiệm ho ặc ở 2 thời điểm khác nhau đ ối với tiêu chí (i i), (iii), hoặc (iv); riêng tiêu chí (i) thì 
chỉ cần một lần xét nghi ệm duy nh ất.  
Các lưu ý khi ch ẩn đoán ĐTĐ ở trẻ em và thanh thi ếu niên:  
- Glucose lúc đói đư ợc đo khi trẻ nhịn ăn (không u ống nư ớc ngọt, có th ể uống nư ớc lọc) ít 
nhất 8 gi ờ; 
- Nghi ệm pháp dung n ạp glucose b ằng đư ờng uống ph ải được thực hiện theo hư ớng dẫn 
của Tổ chức Y t ế thế giới: trẻ nhịn đói t ừ nửa đêm trư ớc khi làm nghi ệm pháp, d ùng m ột 
lượng 1,75 g/kg tr ọng lư ợng cơ th ể (tối đa 75 g) glucose hòa tan trong nư ớc và u ống trong 
khoảng 5 phút. Nghi ệm pháp này ít đư ợc chỉ định để chẩn đoán ĐTĐ típ 1 ở trẻ em và 
thanh thi ếu niên. Tuy nhiên, nghi ệm pháp này có giá tr ị trong ch ẩn đoán các  thể ĐTĐ 
khác như ĐTĐ típ 2, ĐTĐ đơn gen. Trư ờng hợp nghi ng ờ có th ể tiến hành l ại định kỳ tới 
khi có ch ẩn đoán. Trong 3 ngày trư ớc khi th ực hiện nghi ệm pháp thì trẻ cần ăn kh ẩu phần 
tối thiểu có kho ảng 150 g cacbohydrat  mỗi ngày.  
- Vai trò c ủa HbA1C trong chẩn đoán ĐTĐ típ 1 ở trẻ em không rõ ràng, n ếu HbA1C < 
6,5% cũng chưa lo ại trừ được ĐTĐ ở trẻ em.  
- Các tri ệu chứng đi ển hình c ủa ĐTĐ ở trẻ em và thanh thi ếu niên bao g ồm: đái nhi ều, uống 
nhiều, đái đêm, s ụt cân, ăn nhi ều, mệt mỏi, rối loạn hành vi, m ắt mờ. Có th ể có các tri ệu 
chứng của nhi ễm toan ceton do ĐTĐ khi đư ợc chẩn đoán (chi ếm tỉ lệ 28-42% trong s ố 
các trẻ ĐTĐ típ 1).  
2.2. Chẩn đoán ĐTĐ típ 1 và chẩn đoán phân bi ệt 
- Các xét nghi ệm hỗ trợ chẩn đoán xác đ ịnh phân loại ĐTĐ  bao g ồm: các tự kháng th ể liên 
quan đến ĐTĐ típ 1  như t ự kháng th ể kháng glutamic acid decarboxylase 65  (GAD 65), 
tyrosine phosphatase -like insulinoma  antigen 2 (IA2), kháng th ể kháng insulin (IAA) , tự 
kháng th ể chống ch ất vận chuy ển kẽm tế bào beta đ ặc hiệu 8 (ZnT8). Sự hiện diện của 
một hoặc nhi ều các kháng th ể trên giúp ch ẩn đoán xác đ ịnh ĐTĐ típ 1 . 
- Chẩn đoán các thể ĐTĐ  khác nên đư ợc đặt ra khi trẻ có kết quả âm tính v ới các kháng th ể 
liên quan đ ến bệnh và:  
+ Tiền sử gia đình có đ ột biến gen tr ội của ĐTĐ (MODY ); 
+ ĐTĐ  khởi phát dư ới 12 thá ng, đ ặc biệt là dư ới 6 tháng tu ổi (ĐTĐ  sơ sinh) ; 
+ Tăng nh ẹ glucose huyết tương  lúc đói (5,5 -8,5 mmol/L  hay 100-150 mg/dL ), đặc biệt 10 
 
 ở người trẻ, không béo phì, không có tri ệu chứng (MODY ); 
+ Thời kỳ “trăng m ật” kéo dài trên 1 năm ho ặc liều insulin th ấp bất thường < 0,5 
UI/kg/ngày sau 1 năm mắc bệnh ĐTĐ  (MODY) ; 
+ Các tình tr ạng liên quan như đi ếc, teo th ị giác ho ặc các h ội chứng đặc trưng (b ệnh ty 
thể); 
+ Tiền sử tiếp xúc v ới các lo ại thuốc được biết là gây đ ộc cho t ế bào β hoặc gây ra kháng 
insulin (ví d ụ: thuốc ức chế miễn dịch như tacrolimus ho ặc cyclosporin; glucocorticoid 
hoặc một số thuốc chống trầm cảm). 
+ Xét nghi ệm di truy ền phân t ử có th ể giúp xác đ ịnh nguyên nhân c ụ thể của bệnh và 
lựa chọn phương pháp đi ều trị thích h ợp cho tr ẻ nghi ng ờ mắc ĐTĐ  đơn gen. Trong 
khi m ột số đặc điểm lâm sàng đ ặc hiệu sẽ cảnh báo các bác sĩ lâm sàng v ề khả năng 
mắc ĐTĐ  đơn gen, tuy nhiên n ếu không có nh ững tri ệu chứng này cũng không lo ại 
trừ bệnh.  11 
 
 PHẦN 3: CƠ CH Ế BỆNH SINH VÀ CÁC GIAI ĐOẠN ĐÁI THÁO ĐƯ ỜNG TÍP 1  
 
ĐTĐ  được đặc trưn g bởi sự phá h ủy các t ế bào β, thư ờng do quá trình t ự miễn dẫn đến mất 
khả năng s ản xuất hoàn toàn ho ặc 1 ph ần insulin n ội sinh. Trong ph ần lớn các trư ờng hợp, sự 
phá hu ỷ tế bào β c ủa tụy do trung gian mi ễn dịch xảy ra v ới tốc độ khác nhau, chịu ảnh hư ởng 
bởi các y ếu tố khác nhau bao g ồm gen, tu ổi và s ắc tộc. Quá trình này tiến triển liên t ục qua 
các giai đo ạn có th ể xác đ ịnh rõ ràng trư ớc khi có các tri ệu chứng lâm sàng:  
- Giai đo ạn 1: có th ể kéo dài hàng tháng đ ến nhi ều năm, đ ặc trưng b ởi sự xuất hiện của 
các tự kháng th ể kháng  tế bào β, giai đo ạn này, chưa có các bi ểu hiện của triệu chứng 
lâm sàng và glucose huyết tương  bình thư ờng. 
- Giai đo ạn 2: r ối loạn dung n ạp glucose huyết tương  nhưng chưa có tri ệu chứng lâm sàng  
(giai đo ạn tiền triệu chứng). 
- Giai đo ạn 3: kh ởi phát b ệnh và có tri ệu chứng lâm sàng . 
- Giai đo ạn 4. ĐTĐ  típ 1 kéo dài.  
Nguyên nhân c ủa ĐTĐ  bao g ồm nhi ều yếu tố như tính nh ạy cảm di truy ền, các y ếu tố môi 
trường, h ệ thống mi ễn dịch và các t ế bào β; tuy nhiên vai trò c ụ thể của các y ếu tố này chưa 
rõ ràng.  
Tỷ lệ mắc ĐTĐ típ 1  trong dân s ố nói chung là 0,4%. H ọ hàng c ủa những ngư ời mắc ĐTĐ 
típ 1 có nguy cơ cao hơn: t ỷ lệ mắc của anh ch ị em ru ột là 6 -7%, ở con c ủa ngư ời mẹ mắc 
ĐTĐ típ 1  là 1,3 - 4%, ở con c ủa ngư ời cha mắc ĐTĐ típ 1  là 6- 9%; nguy cơ m ắc ĐTĐ típ 1  
ở các c ặp sinh đôi khác tr ứng tương t ự như ở anh ch ị em ru ột, nhưng ở các c ặp sinh đôi cùng 
trứng thì t ỷ lệ này có th ể vượt quá 70%. Tính nh ạy cảm với ĐTĐ típ 1  được xác đ ịnh bởi 
nhiều gen như: vùng HLA trên nhi ễm sắc thể  6p21 liên quan đ ến 30-50% các trư ờng trư ờng 
hợp ĐTĐ típ 1 . Có 60 locus gen có nguy cơ cao gây ĐTĐ típ 1 . Trong s ố đó chi ếm tỷ lệ cao 
nhất là gen insulin ( INS) trên nhi ễm sắc thể 11p15, tyrosine phosphatase, lo ại không th ụ thể 
22 (PTPN22 ), trên nhi ễm sắc thể 1p13, protein liên  kết với tế bào lympho T gây đ ộc tế bào 
(CTLA -4). 
Các y ếu tố khởi phát (nhi ễm trùng, dinh dư ỡng, béo phì, hoá ch ất…) đư ợc cho là liên quan 
đến sự phá hu ỷ tế bào β c ủa tụy phần lớn chưa đư ợc biết đến, nhưng quá trình phá hu ỷ tế bào 
β thư ờng bắt đầu nhi ều tháng đ ến nhi ều năm trư ớc khi xu ất hiện các tri ệu chứng lâm sàng. 
Nhiễm enterovirus trong quá trình mang thai, th ời kỳ nhũ nhi, tr ẻ nhỏ và thanh thi ếu niên có 
ảnh hư ởng đến sự phát tri ển của các y ếu tố tự miễn của tiểu đảo tụy, đặc biệt khi nhi ễm virus 
trong  thời kỳ trẻ nhỏ. Enterovirus đã đư ợc phát hi ện trong ti ểu đảo tụy của ngư ời bệnh ĐTĐ 
típ 1. Ngoài ra, m ắc rubella b ẩm sinh cũng đư ợc phát hi ện có liên quan đ ến sự phát tri ển của 
ĐTĐ típ 1 . 
 
 
 
 12 
 
 PHẦN 4: ĐIỀU TRỊ ĐÁI  THÁO ĐƯỜNG KHÔNG CÓ  BIẾN CHỨNG  
NHIỄM TOAN  CETON KHI MỚI CHẨN ĐOÁN  
 
1. Thăm khám lâm sàng  
Mất nước < 3%, không có triệu chứng nhiễm toan và không nôn  
Xét nghiệm cần làm cho tất cả trẻ được chẩn đoán ĐTĐ  lần đầu  
- Ceton máu tại giường (nếu có) hoặc ceton niệu với mọi trẻ có glucose huyết  ≥ 11,1 
mmol/L . 
+ Nếu ceton dương tính, c ần chỉ định khí máu tĩnh m ạch để đánh giá nhi ễm toan, n ếu 
pH < 7,3: x ử trí theo ph ần “Ch ẩn đoán và đi ều trị nhiễm toan ceton và tăng áp l ực 
thẩm thấu do ĐTĐ ” trong tài li ệu này.  
+ Trong trư ờng hợp khí máu không toan, ceton dương tính:  cần tiếp tục theo dõi ceton 
cùng v ới glucose huyết tương  để đảm bảo thể ceton gi ảm khi b ắt đầu điều trị với 
insulin (d ừng theo dõi khi 2 m ẫu liên ti ếp âm tính  và th ử lại ceton khi glucose huyết 
có m ẫu > 15,0 mmol/L ). 
- Kháng thể GAD, IAA, IA2, ZnT8  và chức năng tuyến giáp  
- Các xét nghiệm khác: Với trẻ nhỏ hoặc trẻ vị thành niên  có thừa cân béo phì hoặc có triệu 
chứng gai đen  
+ Định lư ợng C -peptid và insulin máu (nh ằm phân bi ệt với ĐTĐ  típ 2, tuy nhiên, ĐTĐ  
típ 1 vẫn là ch ẩn đoán ưu tiên trong b ệnh cảnh này) . 
+ Các xét nghi ệm về lipid máu . 
+ Các xét nghi ệm đánh giá ch ức năng gan . 
2. Điều trị  
Quyết định lựa chọn phác đồ insulin riêng cho từng trẻ cần được trao đổi giữa nhóm y bác sĩ 
với trẻ và gia đình. Lựa chọn insulin và liều dùng dưới đây chỉ mang tính định hướng và t ừng 
bác sĩ lâm sàng có thể đưa ra các cách tiếp cận khác nhau . 
2.1. Xử trí ban đầu  
- Tiêm ngay: Insulin tác dụng nhanh, tiêm dưới da với liều: 0,25 UI/kg 
+ Nếu thời điểm vào trong kho ảng 2 gi ờ trước bữa chính, hoãn li ều tiêm ngay này và ch ỉ 
tiêm v ới liều insulin đầu tiên này trước bữa ăn chính.  
+ Giảm 50% li ều nếu trẻ ≤ 4 tu ổi. Liều thấp hơn n ếu không có nhi ễm toan.  
2.2. Điều trị duy trì  
Với trường hợp chẩn đoán ĐTĐ  lần đầu, có thể lựa chọn 1 trong 2 phác đồ insulin tiêu chuẩn 
sau đây . Cần cá thể hóa sự lựa chọn dựa trên  khả năng tuân thủ điều trị, cung ứng insulin và 
điều kiện chăm sóc tại gia đình cũng như tại trường học. Cần tham khảo chi tiết trong phần: 
“Điều trị ĐTĐ típ 1 ở trẻ em và thanh thiếu niên bằng insulin ” trong tài liệu này.  13 
 
 a) Tiêm nhiều lần trong ngày với m ột liều insulin tác dụng kéo dài vào ban đêm và insulin 
tác dụng nhanh trước các bữa ăn  
- Bắt đầu với tổng liều hàng ngày: 1,0 UI/kg/ngày.   
- Liều insulin nền: 0,4 UI/kg (insulin tác dụng kéo dài như glargine) lúc 20:00 – 21:00  giờ. 
- Liều insulin tác dụng nhanh  còn lại chia đều cho 3 lần trước các bữa ăn (khoảng 0,2 UI/kg 
trước mỗi bữa chính).  
- Nếu trẻ mới chẩn đoán và có kế hoạch theo phác đồ insulin này đến khám vào buổi sáng, 
cần tăng nhẹ liều trước bữa ăn (tăng lên khoảng 0,25 UI/kg/lần) cho đến khi tiêm được  
insulin nền vào đêm cùng ngày.  
- Ưu điểm của phác đồ tiêm insulin nhiều lần trong ngày là linh hoạt, dễ điều chỉnh theo lối 
sống của từng trẻ (thời điểm bữa chính, hoạt động thể thao…); tuy nhiên, trẻ lớn cần được 
hướng dẫn để có thể tự tiêm insulin khi kh ông có bố mẹ hỗ trợ (khi ở trường  học), phù 
hợp với trẻ trên 10 tuổi.  
b)  Tiêm hai lần mỗi ngày với insulin trộn (insulin tác dụng ngắn và trung bình)  
- Thường bắt đầu với tổng liều hàng ngày (total daily dose, TDD) là 1 UI/kg/ngày nhưng 
cần cá thể hóa (ví dụ:  giảm liều ở trẻ dưới 5 tuổi).  
- Liều insulin được phân bổ như sau: 2/3 tổng liều hàng ngày vào buổi sáng, 1/3 tổng liều 
hàng ngày vào ban đêm. Insulin tác dụng trung bình chiếm tỉ lệ 2/3 insulin trong mỗi liều, 
còn lại là insulin tác dụng ngắn.  
- Phác đồ tiêm  2 lần mỗi ngày phù hợp với trẻ dưới 10 tuổi.  
- Lưu ý: nếu trẻ mới chẩn đoán và có kế hoạch theo phác đồ tiêm hai lần mỗi ngày nhưng 
đến khám sau 22 giờ, có thể không kịp bắt đầu ngay lần tiêm tối với insulin trộn. Trong 
trường hợp này, cần tiêm dưới da ins ulin tác dụng ngắn với liều 0,25 UI/kg, nhắc lại sau 
4-6 giờ, kèm một bữa ăn nhẹ (tùy vào glucose huyết , ceton và khoảng cách tới bữa sáng).  
- Xét nh ập viện hoặc hội chẩn bác sĩ chuyên khoa nhi:  Tất cả các trẻ ĐTĐ  mới chẩn đoán. 
Trẻ cần được nhập viện để điều chỉnh liều insulin và giáo d ục sức khỏe về ĐTĐ .  
- Xét chuy ển tuy ến tới các B ệnh vi ện Nhi tuy ến tỉnh ho ặc các Bệnh vi ện Nhi khu v ực: Tình 
trạng bệnh vượt quá kh ả năng đi ều trị của Bệnh vi ện tuy ến huy ện hoặc tỉnh. 
 
 
 
  14 
 
 PHẦN 5: CHẨN ĐOÁN VÀ  ĐIỀU TRỊ NHIỄM TO AN CETON DO ĐÁI THÁO  ĐƯỜNG 
VÀ TÌNH TRẠNG TĂNG G LUCOSE HUYẾT TĂNG ÁP  LỰC THẨM THẤU  
 
1.  Toan ceton do đái tháo đư ờng 
Toan ceton do ĐTĐ  (Diabetic ketoacidosis - DKA) x ảy ra do thi ếu insulin hoàn toàn ho ặc 
một phần kèm theo s ự tăng n ồng độ của các hormon đi ều hòa đối kháng: cathecholamin, 
glucagon, cortisol, và hormon tăng trư ởng. DKA có th ể xuất hiện trong l ần đầu nhập viện 
nhưng cũng có th ể xuất hiện ở trẻ ĐTĐ  đang đi ều trị nhưng b ỏ tiêm Insulin hay khi b ị ốm 
nặng.  
1.1. Ch ẩn đoán  
- Tiêu chu ẩn chẩn đoán DKA v ề xét nghi ệm: 
+ Glucose huy ết tương cao >11 mmol/L  (~ 200 mg/dL ) 
+ pH < 7,3 ho ặc bicarbonate <18 mmol/L  
+ Ceton máu cao (beta -hydroxybutyrate ≥ 3 mmol/L ) hoặc ceton ni ệu ở mức trung bình 
hoặc nhi ều (từ 2+) 
- Phân lo ại mức độ nặng của DKA  
+ Nhẹ: pH < 7,3 ho ặc HCO3 < 18 mmol/L 
+ Trung bình: pH <7,2 ho ặc HCO3 <10 mmol/L  
+ Nặng: pH <7,1 ho ặc HCO3 < 5 mmol/L  
1.2. Đánh giá c ấp cứu 
- Tuân th ủ các hư ớng dẫn về đánh giá ngư ời bệnh theo APLS (Advanced Pediatric Life 
Support – Cấp cứu nhi khoa nâng cao), đ ảm bảo đường th ở và tu ần hoàn.  
- Đánh giá các ch ỉ số sống, đo cân n ặng hi ện tại 
- Thiết lập 2 đư ờng truy ền ngo ại biên,  
+ Một đường truy ền để lấy máu làm xét nghi ệm: glucose, beta -hydroxybutyrat (ceton 
máu), khí máu, đi ện giải đồ, ure, creatinine.  
+ Một đường truy ền để bù dịch 
- Hỏi bệnh sử, khám l âm sàng bao g ồm mức độ ý thức, tìm ổ nhiễm trùng.  
- Đánh giá m ức độ mất nước:  
+ Mất nước nặng (10%): các tri ệu chứng gi ống như s ốc: mạch yếu, hạ huyết áp, chi l ạnh, 
thời gian đ ổ đầy mao m ạch kéo dài, vô ni ệu. Tương ứng với DKA n ặng  
+ Mất nước trung bình (7%):  thời gian đ ổ đầy mao m ạch kéo dài, n ếp véo da m ất chậm, 
niêm m ạc khô, không có nư ớc mắt, mắt trũng. Tương ứng với DKA trung bình  
+ Mất nước nhẹ (5%): Không có tri ệu chứng. Tương ứng với DKA nh ẹ.  15 
 
 - Đánh giá m ức độ ý thức theo thang đi ểm Glasgow.  
- Nếu ngư ời bệnh mất ý th ức, không đ ảm bảo đường th ở cần đặt sonde d ạ dày và cân nh ắc 
đặt nội khí qu ản.  
- Nếu có s ốc: Cho th ở oxy 
- Nếu có b ằng ch ứng của nhi ễm khu ẩn cần dùng kháng sinh  
- Các xét nghi ệm khác c ần làm thêm: Công th ức máu, albumin, calci, phosphat, magie, 
HbA1c,  CRP và các kháng th ể kháng t ụy (nếu bệnh nhi  vào l ần đầu), áp l ực thẩm thấu 
máu.  
Lưu ý : Trẻ cần được điều trị tại các khoa, phòng có kinh nghi ệm và đư ợc đào t ạo để điều trị 
DKA. V ới trẻ bị DKA n ặng (tri ệu chứng kéo dài, suy tu ần hoàn, r ối loạn ý th ức) ho ặc có 
nguy cơ t ổn thương não (< 5 tu ổi, pH < 7,1, pCO2 < 21  mmHg, ure máu > 20 mg/dL ): nên 
điều trị tại khoa h ồi sức cấp cứu  
1.3. Đi ều trị 
- Mục tiêu đi ều trị:  
+ Điều chỉnh tình tr ạng nhi ễm toan và nhi ễm ceton  
+ Điều chỉnh tình tr ạng m ất nước, điện giải đồ 
+ Điều chỉnh glucose huy ết tương   
+ Theo dõi và đi ều trị các bi ến chứng của DKA  
+ Xác đ ịnh và đi ều trị mọi yếu tố làm n ặng lên tình tr ạng DKA  
1.3.1. Bù d ịch  
- Mục tiêu bù d ịch: 
+ Khôi ph ục thể tích tu ần hoàn  
+ Bù nư ớc thiếu và đi ều chỉnh Natri máu  
+ Cải thiện mức lọc cầu thận, tăng đ ộ thanh th ải glucose và th ể ceton  
- Cách bù d ịch  
+ Nếu trẻ có gi ảm thể tích tu ần hoàn nhưng chưa s ốc: bolus 10 – 20 ml/kg NaCl 0,9% 
trong vòng 20 - 30ph  
+ Nếu trẻ có sốc: bolus ngay 20  ml/kg NaCl 0,9% và đánh giá l ại tuần hoàn sau m ỗi lần 
bolus  
+ Thận trọng với trẻ DKA c ần bolus > 2 l ần  
+ Bù d ịch bằng NaCl 0,45% - 0,9% ho ặc Ringerlactat  
+ Tổng lư ợng dịch cần bù = lư ợng dịch m ất + dịch nhu c ầu. Tổng lư ợng dịch này s ẽ bù 
trong 24 - 48 gi ờ (tham kh ảo bảng)   16 
 
 Lượng dịch m ất = 10 x % d ịch m ất x cân n ặng (ml ) 
Ví dụ: Mất nước nhẹ (DKA nh ẹ): 5%, m ất nước vừa (DKA v ừa) 7%, m ất nước nặng 
(DKA n ặng): 10%  
Dịch nhu c ầu được tính theo công th ức Hollyday – segar  
+ ≤ 10 kg: 100 ml/kg/24 h  
+ 11–20 kg: 1000 ml + 50 ml/ kg /24h cho m ỗi kg t ừ 11–20kg  
+ >20 kg : 1500 ml + 20 ml/ kg/ 24h cho m ỗi kg >20  
+ Lượng dịch m ất qua đư ờng tiểu thư ờng không đư ợc tính vào trong lư ợng dịch bù.  
+ Tốc độ dịch truy ền không ảnh hư ởng đến nồng độ Natri huy ết thanh, nhưng n ồng độ 
Natri trong d ịch truy ền thì có ảnh hư ởng. Do v ậy, nếu Natri máu không tăn g song hành 
với mức giảm glucose huy ết tương thì s ẽ điều chỉnh Natri trong d ịch truy ền. Tham 
khảo phục lục 1.  
1.3.2.  Bù đi ện giải  
- Bù Kali  
+ Nguyên nhân gây thi ếu Kali: tăng áp l ực thẩm thấu máu ở lòng m ạch, do toan chuy ển 
hóa, h ủy glycogen/protein th ứ phát do thi ếu insulin, thi ếu dịch gây cư ờng aldosterone 
thứ phát làm tăng th ải Kali qua đư ờng ni ệu. 
+ Bù Kali là c ần thiết: ngo ại trừ suy th ận 
+ Nếu có gi ảm kali: kh ởi đầu bù d ịch và bù kali, t ạm hoãn Insulin cho đ ến khi Kali máu 
> 3,5  mmol/L , tốc độ bù Kali không quá 0, 5 mmol/kg/gi ờ. Xét nghi ệm Kali 1 gi ờ/1 
lần cho đ ến khi Kali máu > 3,5 mmol/L  thì bắt đầu truy ền Insulin. Lưu ý: bù Kali song 
song v ới bù d ịch nhưng b ằng 2 đư ờng truy ền riêng bi ệt.  
+ Nếu kali máu cao > 5,5  mmol/L : dùng d ịch truy ền không có Kali và xét nghi ệm Kali 
1 giờ/1 lần cho đ ến khi Kali máu <5,5 mmol/L  thì chuy ển sang d ịch truy ền có Kali.  
+ Nếu không đo đư ợc Kali máu thì s ử dụng đi ện tâm đ ồ:  
+ Kali th ấp: PR kéo dài, sóng T d ẹt, ST th ấp, U cao, QT kéo dài  
+ Kali cao: sóng T cao/nh ọn/cân đ ối, QT ng ắn  
+ Với trường hợp Kali máu t ừ 3,5 – 5,5 mmol/L  thì dùng d ịch ch ứa 40 mmol/L  Kali 
(30ml KCl 10% pha trong 1000ml d ịch truy ền). 
+ Xét nghi ệm Kali máu đư ợc thực hiện 2 – 4 giờ/lần nếu nồng độ Kali máu bình thư ờng. 
- Bù phospho  
+ Mất Phospho trong DKA là do l ợi niệu thẩm thấu, thư ờng gi ảm khi b ắt đầu điều trị 
Insulin. H ạ Phospho máu có tri ệu chứng có th ể xảy ra khi nh ịn ăn truy ền dịch quá 24 
giờ 
+ Phospho máu > 0,32  mmol/L : thường không có tri ệu chứng 17 
 
 + Phospho máu < 0,32 mmol/L : cần điều trị để tránh h ạ phospho máu n ặng có tri ệu 
chứng: (ví d ụ: bệnh não, gi ảm ch ức năng co bóp cơ tim, suy hô h ấp do y ếu cơ hoành, 
yếu cơ g ốc chi, khó nu ốt, tắc ruột, huy ết tán, gi ảm tiểu cầu, tiêu cơ vân)  
+ Khi truy ền phospho c ần theo dõi calci máu và magie máu  
1.3.3. Truy ền insulin  
- Mục đích truy ền insu lin nh ằm:  
+ Chuy ển hóa t ế bào bình thư ờng  
+ Ngăn phá h ủy mô m ỡ/tạo ra ceton  
+ Làm bình thư ờng nồng độ glucose  
- Bắt đầu truy ền insulin 1 gi ờ sau b ắt đầu bù d ịch đư ờng tĩnh m ạch 
- Liều insulin:  
+ Từ 0,05 – 0,1 UI/kg/gi ờ, loại insulin tác d ụng ng ắn (regular insulin)  
+ Với trường hợp pH > 7,15: li ều 0,05 UI/kg/gi ờ 
+ Với trẻ nhỏ < 3 tu ổi + DKA nh ẹ: dùng li ều thấp 0,03 UI/kg/gi ờ 
+ Duy trì li ều insulin cho đ ến khi DKA h ồi phục (khi h ết nhiễm toan pH >7,3)  
+ Cân nh ắc tăng li ều Insulin: n ếu cải thiện sinh hóa ch ậm hơn d ự kiến 
+ Đích truyền Insulin: T ốc độ giảm glucose huy ết tương: thư ờng từ 2 - 5 mmol/gi ờ (36 
– 90 mg/dL /giờ) 
- Một số lưu ý:  
+ Truy ền Insulin tĩnh m ạch liều thấp là an toàn và hi ệu quả 
+ Tuyệt đối không bolus insulin  
+ Sau khi pha d ịch insulin: c ần xả dịch trong dây truy ền 
+ Nếu không đ ặt được ven, xem xét tiêm b ắp, không nên dùng ven tĩnh m ạch trung tâm  
- Phòng h ạ glucose:  
+ Khi glucose huy ết tương gi ảm còn  14 - 17 mmol/L  (~250 – 300 mg/dL ) hoặc glucose 
huyết tương gi ảm nhanh trên 5  mmol/L /giờ (~90  mg/dL /giờ): cần pha thêm glucose 
vào dịch truy ền. Kh ởi đầu có th ể pha thêm Glucose 5%, n ếu glucose huy ết tương ti ếp 
tục giảm, cần pha thêm Glucose 10%. N ồng độ glucose trong d ịch truy ền có th ể lên 
tới 10 - 12,5%. Ví d ụ: pha Glucose 10% v ới NaCl 0,9% t ỉ lệ 1:1 đư ợc dung d ịch m ới 
với nồng độ glucose 5%.  
+ Nếu chỉ số sinh hóa c ủa DKA như pH, kho ảng trống anion, ceton máu không c ải thiện:  
+ Đánh giá l ại, xem l ại điều trị insulin  
+ Tìm nguyên nhân gây ch ậm đáp ứng với insulin (nhi ễm trùng, pha sai, đư ờng dùng)  18 
 
 - Với DKA nh ẹ / trung bình có th ể điều trị như sau:  
+ Dùng Insulin tác d ụng nhanh (rapid -acting insulin analog) tiêm dư ới da 1 gi ờ/lần hoặc 
2 giờ/lần 
+ Liều khởi đầu: 0,15 UI/kg m ỗi 2 gi ờ (bắt đầu tiêm sau bù d ịch 1 gi ờ) 
+ Nếu glucose huy ết tương gi ảm nhanh > 5 mmol/L /giờ (~ 90 mg/dL /giờ) và/ho ặc phải 
bù dịch có glucose đ ể đảm bảo glucose huy ết tương thì dùng li ều insulin 0,1 UI/kg 
mỗi 2 gi ờ  
+ Lưu ý: ch ỉ thực hiện khi tư ới máu bình thư ờng  
- Với DKA nh ẹ  
+ Tiêm dư ới da insulin ng ắn hạn (regular insulin) 4 gi ờ/lần  
+ Liều 0,13 -0,17 UI/kg/li ều (hay 0,8 – 1 UI/kg/n gày) 
+ Tăng/gi ảm liều 10-20% trư ớc mỗi lần tiêm, d ựa vào n ồng độ glucose  
+ Tăng li ều sau 2 -3 giờ nếu toan không c ải thiện  
1.3.4. Bù ki ềm 
- Bù ki ềm: không có l ợi ích trên lâm sàng, th ậm chí có th ể gây toan d ịch não t ủy.  
- Chỉ định bù khi:  
+ Kali cao nguy hi ểm tính mạng  
+ Toan n ặng (pH < 6,9) kèm theo có b ằng ch ứng của giảm sức co bóp cơ tim.  
- Khi bù ki ềm, cần giám sát ch ặt chẽ nồng độ Kali huy ết thanh.  
- Nếu toan h ồi phục chậm:  
+ Chủ yếu do toan chuy ển hóa Clo máu tăng: thư ờng lành tính và không c ần trì hoãn 
việc chuy ển tiêm dư ới da 
+ Có th ể do thi ếu dịch, nhi ễm trùng, pha sai insulin.  
1.3.5. Chuy ển đường uống và insulin tiêm dư ới da 
- Cho tr ẻ ăn trở lại và chuy ển Insulin tiêm dư ới da khi DKA h ồi phục: hết nhiễm toan (pH 
> 7,3)  
- Chọn thời điểm ng ừng insulin truy ền tĩnh m ạch: thường trư ớc bữa ăn chính  
- Việc lựa chọn chế độ tiêm insulin 2 mũi hay 4 mũi/ngày c ần phù h ợp với thực tiễn. Tuy 
nhiên, nên l ựa chọn phác đ ồ 4 mũi/ngày khi m ới chuy ển từ truyền tĩnh m ạch sang tiêm 
dưới da. 
- Với phác đ ồ 4 mũi  
+ Liều insulin đ ầu:  
+ Nếu dùng insu lin tác d ụng ng ắn (regular insulin): tiêm dư ới da trư ớc khi d ừng truy ền 19 
 
 Insulin 30 phút.  
+ Nếu dùng insulin tác d ụng dụng nhanh (rapid acting analogue): tiêm dư ới da ngay 
trước khi d ừng truy ền Insulin.  
+ Đối với trẻ đang s ử dụng ch ế độ tiêm 4 mũi (basal – bolus), li ều insulin n ền đầu tiên 
có th ể được tiêm vào bu ổi tối và ng ừng truy ền insulin vào sáng hôm sau.  
- Liều Insulin nên b ắt đầu từ 0,8 – 1 UI/kg/ngày, li ều mỗi mũi tiêm c ần dựa trên l ựa chọn 
chế độ tiêm (xin xem thêm bài đi ều trị Insulin).  
- Sau khi chuy ển tiêm dư ới da: Đo glucose huy ết mao m ạch thư ờng xuyên đ ể tránh tăng/h ạ 
glucose. Vào ngày đ ầu sau khi chuy ển tiêm dư ới da có th ể kiểm tra 2 - 4 giờ/lần, vào 
những ngày sau có th ể kiểm tra 5 m ẫu/ngày.  
1.4. Theo dõi lâm sàng và sinh hóa  
- Ghi chép t ỉ mỉ, từng giờ, kẻ bảng. 
- Theo dõi hàng gi ờ các ch ỉ tiêu sau:  
+ Chỉ số sinh t ồn  
+ Đánh giá tri giác b ằng thang đi ểm Glasgow, d ấu hiệu/triệu chứng tổn thương não  
+ Liều lượng insulin  
+ Glucose huy ết mao m ạch  
- Mỗi 2-4 giờ cần theo dõi các ch ỉ tiêu sau: Đi ện giải đồ, glucose, ure, calci, magie, phospho, 
khí máu.  
1.5. Bi ến chứng 
- Tỉ lệ tử vong (3 - 13%): do t ổn thương não  
- Di ch ứng th ần kinh nghiêm tr ọng: suy gi ảm trí nh ớ, giảm chú ý…  
- Tổn thương ống th ận (RTD) và t ổn thương th ận cấp tính (AKI): 43 – 46% 
- Biến chứng khác: H ạ kali, hạ glucose huy ết tương , hạ Calci, h ạ magie, h ạ phospho máu 
nặng, nhi ễm toan tăng Clo, nhi ễm kiềm hạ clo, huyết khối tĩnh m ạch xoang, huy ết khối 
động m ạch nền, xu ất huy ết nội sọ, nhồi máu não, huy ết khối tĩnh m ạch sâu, thuyên t ắc 
phổi, phù ph ổi, ARDS, QTc  kéo dài, tràn khí màng ph ổi, trung th ất, dưới da, tiêu cơ vân, 
hoại tử ruột, suy th ận, viêm t ụy cấp… 
1.5.1. Tổn thương não liên quan tới DKA  
- Tỉ lệ: 0,5 – 0,9%. T ỉ lệ tử vong: 21 - 24% 
- Căn nguyên:  chưa rõ ràng. Có th ể do gi ảm tưới máu não và tình tr ạng viêm  quá m ức  
- Yếu tố dự báo: pCO2 th ấp, Ure cao, nhi ễm toan n ặng khi nh ập viện, điều trị nhiễm toan 
bằng Bicarbonat.  20 
 
 - Tổn thương não = 1 tiêu chu ẩn chẩn đoán HO ẶC 2 tiêu chu ẩn chính HO ẶC 1 tiêu chu ẩn 
chính + 1 tiêu chu ẩn phụ  
 
Bảng 2. Tiêu chu ẩn chẩn đoán t ổn thương não liên quan t ới DKA  
 
Tiêu chu ẩn chẩn đoán  Tiêu chu ẩn chính  Tiêu chu ẩn phụ 
Đáp ứng vận động ho ặc lời nói: 
bất thường  
Tư th ế bóc v ỏ/mất não  
Liệt dây th ần kinh s ọ (đặc biệt 
dây III, IV và VI)  
Kiểu thở bất thư ờng (thở rên, 
thở nhanh, ki ểu thở Cheyn e-
Stokes, ngưng th ở) Thay đổi ý th ức, lú l ẫn 
Nhịp tim gi ảm liên t ục (gi ảm 
hơn 20 nh ịp mỗi phút) không 
phải do c ải thiện thể tích n ội 
mạch ho ặc ngủ 
Tiểu không t ự chủ không phù 
hợp với lứa tuổi Nôn m ửa 
Đau đ ầu 
Thờ ơ  
Huyết áp tâm 
trương > 90 mm Hg 
Tuổi < 5 tu ổi 
 
 
- Điều trị:  
+ Điều trị ngay khi nghi ng ờ 
+ Điều chỉnh dịch tránh quá t ải dịch ho ặc hạ huyết áp 
+ Manitol 0,5 –1g/kg tiêm tĩnh m ạch trong 10 –15 phút, hi ệu quả sau 15 phút, kéo dài 
120 phút, có th ể lặp lại sau 30 phút.   
+ Có th ể sử dụng NaCl 3% 2,5 –5 ml/kg tron g 10–15 phút thay th ế cho Manitol, ho ặc 
lâm sàng không đáp ứng với Manitol sau 15 – 30 phút  
+ Đặt nội khí qu ản nếu có suy hô h ấp  
+ Sau khi đi ều trị bằng các thu ốc tăng áp l ực thẩm thấu, có th ể chụp não  
+ Không trì hoãn đi ều trị để đợi chụp não  
+ Mục đích ch ụp não là đ ể đánh giá các t ổn thương c ần can thi ệp cấp cứu: Xu ất huy ết 
nội sọ, huy ết khối. 
 21 
 
  
Lưu đồ 1 . Điều trị toan ceton do ĐTĐ  
(Trích dẫn từ tác giả Pinhas -Hamiel and Sperling)  
 
 22 
 
 2. Tình tr ạng tăng Glucose huy ết tương tăng áp l ực thẩm th ấu 
Tình tr ạng tăng gluc ose huy ết tương tăng áp l ực thẩm thấu (Hyperosmolar hyperglycemic - 
HHS) đ ặc trưng b ởi tình tr ạng glucose huy ết tương và áp l ực thẩm thấu (ALTT) tăng r ất cao 
trong khi không có ceton rõ ràng. Nguy cơ bi ến chứng và t ử vong c ủa HHS cao hơn trong 
DKA. Tuy nhi ên, có th ể có sự chồng chéo gi ữa HHS và DKA. Nhi ễm toan nh ẹ có th ể xuất 
hiện ở trẻ HHS do nhi ễm toan lactic vì m ất nước nghiêm tr ọng. Cũng có th ể có tình tr ạng 
glucose huy ết tương r ất cao trong DKA d ẫn đến tăng ALTT . 
2.1. Tiêu chu ẩn chẩn đoán HHS đơn thu ần: 
- Glucose huy ết tương > 33,3 mmol/L  (~ 600  mg/dL ) 
- Khí máu: pH đ ộng m ạch > 7,3 ho ặc pH tĩnh m ạch > 7,25; HCO 3- > 15mmol/L  
- Ceton ni ệu ít, ceton máu ít ho ặc không có  
- Áp lực thẩm thấu máu hi ệu dụng > 320 mOsm/kg  
 
Bảng 3. Phân bi ệt giữa DKA và HHS  
 
 DKA nh ẹ DKA trung bình  DKA n ặng HHS  
Glucose huy ết tương  > 11 > 11 > 11 > 33,3  
pH tĩnh m ạch < 7,3  < 7,2  < 7,1  > 7,3  
HCO3- < 18 < 10 < 5 > 15 
Ceton ni ệu (+) (+) (+) Ít hoặc (-) 
Beta-hydroxybutyrate  
(ceton máu)  Cao Cao Cao Bình thư ờng 
hoặc tăng  
Áp lực thẩm thấu máu Thay đ ổi Thay đ ổi Thay đ ổi > 320  
Tinh th ần Tỉnh Tỉnh/Lơ mơ  Hôn mê  Hôn mê  
 
2.2. Đi ều trị 
2.2.1. Truy ền dịch 
- Mục tiêu: Tăng th ể tích trong lòng m ạch và h ồi phục tưới máu th ận 
- Tốc độ: khuy ến cáo nên bù nhanh hơn DKA  
+ Lượng bolus ban đ ầu phải là ≥ 20 ml/kg  NaCl 0,9% (gi ả định lư ợng dịch thi ếu kho ảng 
12- 15%)  
+ Sau đó nên dùng NaCl 0,45% đ ến 0,75%, ưu tiên s ử dụng dung d ịch NaCl 0,45%.   
+ Đo n ồng độ natri máu thư ờng xuyên và đi ều chỉnh nồng độ natri trong d ịch truy ền để 
giảm Natri máu hi ệu chỉnh và ALTT máu  
+ Khuyến cáo: m ục tiêu gi ảm Natri máu 0,5  mmol/L  mỗi giờ nếu mất nước tăng Natri 
máu 
+ Tỷ lệ tử vong có liên quan đ ến việc không gi ảm đư ợc nồng độ natri máu hi ệu chỉnh 
khi đi ều trị  23 
 
 - Nếu bù đ ủ nước (khi chưa dùng i nsulin) glucose huy ết tương có th ể giảm 4,1 – 5,5 mmol/L  
(~ 74 – 100 mg/dL ) mỗi giờ. Glucose huy ết tương s ẽ giảm nhanh trong vòng vài gi ờ đầu 
sau bù d ịch. N ếu tiếp tục giảm nhanh (>  5,5 mmol/L  hoặc 100  mg/dL ) cần thêm Glucose 
2,5% ho ặc Glucose 5% vào d ịch truy ền.  
- Tính t ổng lư ợng dịch cần bù = d ịch nhu c ầu + d ịch thi ếu + s ố lượng nư ớc tiểu (công th ức 
tính d ịch nhu c ầu và d ịch thi ếu, xin xem l ại phần DKA)  
- Không c ần dùng i nsulin quá s ớm. 
- Tình tr ạng HHS có th ể gây h ạ Kali n ặng  rối loạn nhịp tim  
2.2.2. Insulin  
- Không b ắt đầu dùng insulin cho đ ến khi đã h ồi phục khối lượng tu ần hoàn.  
- Bắt đầu dùng i nsulin khi t ốc độ giảm glucose huy ết tương dư ới 3 mmol/L /giờ (~ 54  
mg/dL /giờ) khi ch ỉ bù dịch. Li ều: insulin 0,025 – 0,05 UI/kg/gi ờ (insulin tác d ụng ng ắn – 
regular insulin) đ ể giảm glucose huy ết tương 3 – 4 mmol/L /giờ (54 – 72 mg/dL /giờ) 
- Với trẻ có cả tình tr ạng DKA và HHS, có th ể sử dụng insulin s ớm hơn (xin xem ph ần sau)  
2.2.3. Bù đi ện giải và bù toan.  
- Trong HHS, ngư ời bệnh thi ếu kali, phospho và magie nhi ều hơn trong DKA.  
- Nên b ổ sung kali (40 mmol/L  dịch bù) kh i nồng độ kali và ch ức năng th ận bình thư ờng.  
- Đo lại kali sau m ỗi 2-3 giờ cùng theo dõi đi ện tim. N ếu kali máu h ạ nên ki ểm tra hàng 
giờ.  
- Chống ch ỉ định dùng bicarbonat do nguy cơ làm h ạ kali và ảnh hư ởng xấu đến cung c ấp 
oxy cho t ổ chức.  
- Nếu ngư ời bệnh có hạ Phospho, có th ể sử dụng kết hợp Kali phosphate và Kali clorua tỷ 
lệ 1:1. Nên theo dõi n ồng độ phospho 3 – 4 giờ/lần 
- Cần theo dõi Magie máu thư ờng xuyên (3 – 4 giờ/lần). N ếu có h ạ Magie, c ần bổ sung 25 
- 50 mg/kg/l ần x 3 – 4 lần/ngày, t ốc độ truyền tối đa là 150  mg/phút và 2  g/giờ.  
2.2.4. Bi ến chứng của HHS  
- Huyết khối tĩnh m ạch: nên d ự phòng Heparin tr ọng lư ợng phân t ử thấp ở bệnh nhân có 
nguy cơ cao.  
- Tiêu cơ vân.  
+ Tam ch ứng kinh đi ển: Đau cơ, m ệt, nước tiểu sẫm màu.  
+ Hậu quả: suy th ận cấp, tăng Kali,  hạ Calci n ặng 
+ Theo dõi CK máu 2 -3 giờ/lần 
- Tăng thân nhi ệt ác tính  
- Hiếm khi gây phù não.  
a) HHS và DKA ph ối hợp  24 
 
 - Khó nh ận biết, do đó đi ều trị không phù h ợp, dẫn đến tăng nguy cơ bi ến chứng 
- Trẻ đáp ứng các tiêu chu ẩn của DKA và có áp l ực thẩm th ấu máu hi ệu dụng > 320 
mOsm/kg và glucose huy ết tương > 33,3 mmol/L  (600 mg/dL ) 
- Đặc biệt theo dõi các d ấu hiệu thần kinh.  
- Mức độ bù dịch và đi ện giải thường ph ải nhiều hơn so v ới DKA đơn thu ần. 
- Insulin nên cho s ớm hơn (so v ới HHS đơn thu ần) khi tu ần hoàn ổn định và tr ẻ đã đư ợc bù 
dịch ban đ ầu.  
- Hạ Kali máu và h ạ phospho máu n ặng có th ể xảy ra, c ần theo dõi sát.   
 
 
Lưu đ ồ 2. Điều trị tình tr ạng tăng glucose huy ết tương tăng áp l ực thẩm thấu máu (HHS)  
 
 
 
 
 
 
  
25 
 
 PHẦN 6: S Ử DỤNG INSULIN ĐI ỀU TR Ị ĐÁI THÁO ĐƯ ỜNG TÍP 1  
Ở TRẺ EM VÀ THANH THI ẾU NIÊN  
 
Không có m ột công th ức chung dành cho t ất cả người bệnh ĐTĐ, đ ặc biệt ở trẻ em, b ởi nhu 
cầu insulin ở các l ứa tuổi sẽ khác nhau và ph ụ thuộc vào s ự phát tri ển, tăng trư ởng, và thay 
đổi hormon ở từng giai đo ạn. Chính vì v ậy, ngư ời bệnh ĐTĐ típ 1 c ần một liệu trình đi ều trị 
linh ho ạt để duy trì glucose huy ết tối ưu và ki ểm soát các y ếu tố bất lợi gây gián đo ạn điều trị.  
1. Phân loại Insulin   
a) Phân lo ại theo c ấu trúc phân t ử:  
- Human insulin (insulin ngư ời): tổng hợp bằng phương pháp tái t ổ hợp DNA, trình t ự acid 
amin gi ống insulin mà cơ th ể tạo ra. Ví d ụ: regular insulin (insulin thư ờng, tác d ụng ng ắn), 
NPH insulin (insulin tác d ụng trung bình).  
- Insulin analog: t ổng hợp bằng kĩ thu ật tái t ổ hợp DNA, có thay đ ổi một hoặc một số acid 
amin ho ặc gắn thêm chu ỗi polypeptide đ ể thay đ ổi dược tính. Ví d ụ: insulin tác d ụng 
nhanh (aspart, lispro, gluisine), insulin tác d ụng kéo dài.  
b) Phân lo ại theo th ời gian tác d ụng: 
- Insulin tác d ụng rất-nhanh  
- Insulin tác d ụng nhanh  
- Insulin tác d ụng trung bình   
- Insulin tác d ụng kéo dài  
1.1. Insulin tác d ụng nhanh :  
- Insulin tác d ụng rất-nhanh (Ultra -rapid -acting insulin): Tiêm trư ớc mỗi bữa ăn trong ch ế 
độ tiêm nhi ều mũi/ngày, dùng cho bơm insulin ho ặc dụng cụ đưa insulin t ự động. Đã đư ợc 
FDA cho dùng ở trẻ ≥ 2 tuổi 
- Insulin tác d ụng nhanh (RAI):  lispro (dùng m ọi lứa tuổi), aspart (≥ 1 tu ổi), và glulisine (≥ 
6 tuổi). 
+ Liều phụ thuộc vào lư ợng cacbohydrat  tiêu th ụ và nồng độ glucose huy ết. 
+ Tiêm ngay ho ặc trước bữa ăn 10 -15 phút.  
- Insulin tác d ụng ng ắn (insulin thư ờng): Tiêm trư ớc mỗi bữa ăn 20 -30 phút k ết hợp với 
insulin tác d ụng trung bình 2 -3 lần/ ngày ho ặc insulin tác d ụng kéo dài (1 ho ặc 2 l ần/ 
ngày).  
1.2. Insulin tác d ụng trung bình  
- Ưu đi ểm: chi phí r ẻ, số lượng mũi tiêm gi ảm. Thu ốc nên dùng vào bu ổi sáng đ ể kiểm soát 
được glucose huy ết sau ăn b ữa phụ sáng và b ữa trưa (đ ặc biệt với trẻ đi học không tiêm 
được insulin trư ớc bữa ăn trưa).  26 
 
 - Nhược điểm: hạ glucose huy ết cao (n ửa đêm đ ến 4 gi ờ sáng) ho ặc hiện tượng bình minh 
(dawn phenomenon): tăng glucose huy ết vào bu ổi sáng (4 -8 giờ sáng). S ử dụng 2 l ần/ 
ngày đ ể cung c ấp insulin n ền cần thiết.  
- Thuốc cần lăn nh ẹ 12-15 lần trư ớc khi s ử dụng. 
1.3. Insulin tác d ụng kéo dài (glargine, detemir, degludec)  
-    Thuốc hấp thu ch ậm, gần như không có tác d ụng đỉnh ho ặc rất ít; ổn định nồng độ trong 
thời gian dài → giảm nguy cơ gây h ạ glucose huy ết. 
- Sử dụng 1-2 lần/ngày (tr ừ insulin degludec có th ời gian tác d ụng kéo dài nên s ử dụng 1 
lần/ngày); ưu tiên s ử dụng vào bu ổi tối. Trong trư ờng hợp trẻ có nguy cơ h ạ glucose huy ết 
ban đêm nê n chọn sử dụng vào bu ổi sáng. Detemir đư ợc FDA phê duy ệt cho dùng ở trẻ 
≥ 2 tuổi. Glargine U100 (100 UI/ml) thư ờng tiêm 1 l ần vào bu ổi tối. Glargine U300 (300 
UI/ml) làm gi ảm hạ glucose vào bu ổi đêm và cho glucose ổn định hơn ở người lớn ĐTĐ 
típ 1 ch ứ khôn g rõ ở trẻ em ĐTĐ típ 1. Glargine U300 đư ợc FDA cho dùng ở trẻ em ≥ 6 
tuổi. Degludec đư ợc FDA cho dùng ở trẻ ≥ 1 tuổi. 
1.4. Insulin tr ộn sẵn: hỗn hợp của NPH ho ặc protamine và insulin tác d ụng ng ắn/nhanh.  
- Có nhi ều loại khác nhau ph ụ thuộc vào t ỷ lệ insulin  ngắn/insulin thư ờng với NPH (10:90, 
15:85, 20:80, 25:75, 30:70, 40:60, 50:50)  hoặc insulin tác d ụng kéo dài/tác d ụng ng ắn như 
Degludec/Aspart t ỷ lệ 70/30.  Insulin h ỗn hợp ở Việt Nam có các t ỷ lệ 25/75, 30/70 và 
50/50 . 
- Sử dụng trong bút tiêm, c ần lăn nh ẹ khoảng 20 l ần trư ớc khi dùng.  
2. Nguyên t ắc của liệu pháp Insulin  
2.1. Phác đ ồ tiêm insulin tích c ực 
- Ưu đi ểm: lư ợng insulin đi ều chỉnh linh ho ạt, kiểm soát glucose huy ết tốt hơn, gi ảm biến 
chứng về mạch máu.  
- Hạn chế:  
+ Tiêm nhi ều mũi insulin trong ngày → tốn kém.  
+ Kiểm tra glucose mao m ạch liên t ục (≥ 4 l ần/ ngày).  
+ Nguy cơ h ạ glucose huy ết. 
a) Phác đồ tiêm nhiều lần (Multiple daily injection – MDI)  
- Phác đ ồ tiêm nhi ều lần ưu vi ệt hơn ch ế độ tiêm 2 mũi dùng tr ộn sẵn và ch ế độ tiêm 3 mũi, 
nhưng c ần được cá th ể hóa, phụ thuộc vào hoàn c ảnh của trẻ/gia đình và mong mu ốn của 
trẻ. Nếu dùng phác đ ồ insulin truy ền thống sau vài năm, s ẽ chuy ển sang phác đ ồ tiêm 
insulin tích c ực.   
- Insulin tác d ụng nhanh (ưu vi ệt hơn dùng insulin ngư ời) (55 -70% t ổng li ều insulin c ả 
ngày): ti êm trư ớc mỗi bữa ăn, đi ều chỉnh theo glucose huy ết/thức ăn/m ức độ hoạt động 
(sáng - trưa – chiều). 
- Insulin tác d ụng kéo dài (30 -45% t ổng liều insulin c ả ngày): tiêm 1 -2 lần/ ngày.  27 
 
 b) Truy ền insulin dư ới da liên t ục (bơm tiêm insulin):  phù h ợp với mọi lứa tuổi mắc ĐTĐ típ 
1, đặc biệt trong các trư ờng hợp sau:  
 
+ Hạ glucose huy ết nặng tái di ễn 
+ Glucose huy ết không ổn định 
+ Kiểm soát b ệnh không t ối ưu (HbA1c vư ợt 
ngưỡng bình thư ờng theo tu ổi). 
+ Dễ bị toan ceton  
+ Biến chứng vi m ạch máu và/ ho ặc có y ếu tố 
nguy cơ gây biến chứng m ạch lớn + Trẻ nhỏ  
+ (< 1 tu ổi hoăc ti ền học đường) 
+ Chế độ dùng insulin ảnh hư ởng nhi ều 
đến chất lượng sống. 
+ Thanh thi ếu niên có r ối loạn ăn u ống 
+  Phụ nữ mang thai.  
+ Vận động viên thi đ ấu. 
2.2. Phác đ ồ insulin truy ền thống: không đ ạt được mục đích kiểm soát t ốt glucose huy ết, 
nhưng phù h ợp với ngư ời có thói quen sinh ho ạt hàng ngày đ ều đặn, thời gian ăn c ố định. 
- Phác đ ồ ít tích c ực (less intensive): Tiêm 2 ho ặc 3 mũi m ỗi ngày, s ử dụng insulin tr ộn. 
Insulin tác d ụng nhanh đư ợc điều chỉnh dựa trên glu cose huy ết và lư ợng cacbohydrat  tiêu 
thụ. 
- Phác đ ồ cố định: Li ều 2 mũi insulin tr ộn sẵn/ngày c ố định, không đi ều chỉnh ho ặc điều 
chỉnh rất ít. 
- Phác đ ồ 3 mũi/ngày: insulin tr ộn tiêm sáng; insulin thư ờng/tác d ụng nhanh trư ớc ăn t ối; 
insulin n ền (thư ờng dùng t ác dụng trung bình).  
- Trong ch ế độ tiêm nhi ều lần có th ể sử dụng phác đ ồ tiêm 3 mũi như sau: trư ớc 2 b ữa ăn 
chính tiêm dư ới da insulin tác d ụng nhanh (thư ờng là b ữa sáng và b ữa trưa); trư ớc 1 b ữa 
ăn chính (thư ờng là b ữa tối) tiêm dư ới da insulin tr ộn sẵn De gludec/Aspart t ỷ lệ 70/30, và 
không ph ải tiêm thu ốc insulin tác d ụng kéo dài đơn đ ộc. Insulin tr ộn sẵn Degludec/Aspart 
tỷ lệ 70/30 đư ợc dùng cho tr ẻ em ĐTĐ t ừ 2 tuổi trở lên, nhưng khi dùng cần xem xét gi ảm 
tổng liều insulin trong ngày đ ể giảm nguy cơ h ạ glucose huy ết, và th ận trọng khi s ử dụng, 
đặc biệt cho tr ẻ em từ 2 đến 5 tu ổi vì nguy cơ h ạ glucose huy ết. 
- Metformin đư ợc dùng đ ể phòng ng ừa, và k ết hợp với insulin đ ể điều trị thanh thi ếu niên 
ĐTĐ típ 1 ở 1 số nghiên c ứu nhưng ít đư ợc chỉ định trong th ực hành lâm sàng .  
3. Hướng dẫn chỉnh li ều  
3.1. Các y ếu tố ảnh hư ởng đến liều insulin  
 
- Thời gian và giai đo ạn điều trị ĐTĐ  
- Tình tr ạng tại vị trí tiêm thu ốc 
- Kết quả glucose huyết và HbA1c  
- Thói quen ho ạt động hàng ngày  - Tuổi, cân n ặng 
- Giai đo ạn dậy thì 
- Chu kì kinh nguy ệt 
- Tình tr ạng dinh dư ỡng 
- Bệnh nền tái di ễn 
 
 28 
 
 Ví dụ:  
- Giai đo ạn tự phục hồi (giai đo ạn trăng m ật): giảm liều insulin < 0,5 UI/kg/ngày.  
- Giai đo ạn mẫu giáo (6 tháng – 6 tuổi): 0,4 – 0,8 UI/kg/ngày  
- Giai đo ạn tiền dậy thì (ngoài giai đo ạn tự phục hồi): 0,7 -1 UI/kg/ngày.  
- Giai đo ạn dậy thì: 1 -2 UI/kg/ngày.  
3.2. Phân ph ối liều insulin hàng ngày  (sử dụng phác đ ồ MDI)  
3.2.1 Li ều insulin n ền: 30-45% t ổng liều insulin c ả ngày  
- Glargine: tiêm 1 l ần/ngày t ại một thời điểm cố định (tr ẻ em có th ể dùng 2 l ần/ngày ho ặc 
phối hợp với NPH).  
- Detemir: tiêm 2 mũi/ngày. Khi chuy ển từ NPH sang detemir, gi ữ nguyên li ều ban đ ầu 
hoặc tăng li ều phụ thuộc vào k ết quả glucose huyết.  
- Degludec: tiêm 1 l ần/ngày, b ất kì bu ổi nào trong ngày. Đ ối với trẻ em nên tiêm c ố định 
một kho ảng th ời gian trong ngày.  
- Insulin tác d ụng trung bình (NPH): s ử dụng vào bu ổi sáng đ ể bao ph ủ insulin trong c ả ngày, 
đặc biệt sau b ữa ăn trưa ho ặc bữa ăn nh ẹ ở những trẻ không th ể tiêm insulin ở trường. 
3.2.2 Li ều insulin bolus trư ớc mỗi bữa ăn:  
- Chiếm 55%  đến 75% t ổng liểu insulin/ngày  
- Dựa vào: t ổng lư ợng cacbohydrat  tiêu th ụ và m ức glucose huyết mong mu ốn đạt được. 
a) Li ều insulin d ựa trên t ổng lư ợng cacbohydrat  tiêu th ụ (insulin CHO)  
- Bước 1: Tính t ỷ lệ cacbohydrat / insulin (CIR) (1 UI insulin có th ể chuy ển hóa bao nhiêu 
gram cacbohydrat ): Quy t ắc 500  
+ CIR = 500
𝑇ổ𝑛𝑔 𝑖𝑛𝑠𝑢𝑙𝑖𝑛  𝑐ả 𝑛𝑔à𝑦 
+ Khác nhau ở từng độ tuổi: trẻ 1-2 tuổi: dùng quy t ắc 300 ho ặc 250; tr ẻ tiền học đường: 
quy t ắc 500  
+ CIR thông thư ờng 1:20 ho ặc 1:25  
Ví dụ: 1 tr ẻ A cần sử dụng ins ulin sáng/trưa/chi ều, mỗi lần 6 UI và 12 UI insulin n ền.  
- Tổng liều insulin c ả ngày = 6+6+6+12 = 30UI và CIR= 500
30 = 16,7 g/UI  
- Bước 2: Tính li ều insulin sau ăn = 𝐻à𝑚 𝑙ượ𝑛𝑔 𝑐𝑎𝑐𝑏𝑜ℎ𝑦𝑑𝑟𝑎𝑡  ướ𝑐 𝑡í𝑛ℎ 𝑡𝑟𝑜𝑛𝑔  𝑏ữ𝑎 ă𝑛
𝐶𝐼𝑅 
Ví dụ: trẻ A (ở ví dụ trên) c ần tiêu th ụ bữa ăn v ới lượng carbohyrate 45g.   
 
 
b) Li ều insulin d ựa trên m ức glucose huyết mong mu ốn đạt được  Liều insulin c ần dùng = 45/16,7 = 2,67 UI  
 29 
 
 - Bước 3: Tính h ệ số nhạy cảm insulin (1 UI insulin có th ể làm gi ảm xu ống bao nhiêu 
mg/dL  glucose huyết.): “quy t ắc 1800” n ếu đo glucose theo  mg/dL  hay “quy t ắc 100” n ếu 
đo glucose theo mmol/L . 
+ Hệ số nhạy cảm insulin = 1800
𝑇ổ𝑛𝑔 𝑙𝑖ề𝑢 𝑖𝑛𝑠𝑙𝑖𝑛  𝑐ả 𝑛𝑔à𝑦 (nếu glucose huy ết tính theo mg/dL ) 
+ Hoặc = 100
𝑇ổ𝑛𝑔 𝑙𝑖ề𝑢 𝑖𝑛𝑠𝑢𝑙𝑖𝑛  𝑐ả 𝑛𝑔à𝑦 (nếu glucose huy ết tính theo mmo/l)  
+ Đối với nhóm kháng insulin nhi ều hoặc dùng insulin regular: dùng quy t ắc 1500.  
+ Ví dụ: Hệ số nhạy cảm insulin (tr ẻ A – ví dụ trên) = 1800
30 = 60 
- Bước 4:  
+ Tính li ều insulin hi ệu ch ỉnh = 𝐺𝑙𝑢𝑐𝑜𝑠𝑒  ℎ𝑢𝑦ế𝑡 ℎ𝑖ệ𝑛 𝑡ạ𝑖   – 𝐺𝑙𝑢𝑐𝑜𝑠 𝑒 ℎ𝑢𝑦ế𝑡 𝑚𝑜𝑛𝑔  𝑚𝑢ố𝑛 
𝐻ệ 𝑠ố 𝑛ℎạ𝑦 𝑐ả𝑚 𝑖𝑛𝑠𝑢𝑙𝑖𝑛 (UI 
glucose: mg/dL ) 
+ Glucose huyết mong mu ốn: 120 mg/dL . 
Ví dụ: trẻ A có test glucose huy ết hiện tại là 270 mg/ dL  
 
 
- Như v ậy, qua 4 bư ớc, xác đ ịnh đư ợc liều insulin c ủa trẻ A cần dùng trư ớc bữa ăn đó = 
liều insulin c ần dùng + li ều insulin hi ệu chỉnh = 2,67 + 2,5 = 5,1 UI  
+ Trẻ A cần tiêm 5  UI insulin trư ớc bữa ăn này.  
3.3. Cách đi ều chỉnh insulin  
- Glucose huy ết tăng cao trư ớc bữa ăn sáng: tăng li ều insulin tác d ụng trung bình/ kéo dài 
trước khi  đi ng ủ (chú ý h ạ glucose huy ết về đêm).  
- Tăng glucose huy ết sau ăn: tăng insulin r ất nhanh/nhanh/thư ờng trư ớc mỗi bữa ăn.  
- Tăng glucose huy ết trước ăn trưa/chi ều: tăng insulin n ền trư ớc ăn sáng ho ặc tăng li ều 
insulin r ất nhanh/nhanh/thư ờng trư ớc bữa ăn sáng  (nếu sử dụng phác đ ồ MID).  
- Khi s ử dụng phương pháp tính lư ợng cacbohydrat , nếu glucose huy ết tăng dai d ẳng sau 
ăn, c ần điều chỉnh lại hệ số cacbohydrat : insulin. N ếu glucose huy ết vẫn tiếp tục tăng dai 
dẳng sau ăn m ặc dù đã đi ều chỉnh li ều insulin hi ệu chỉnh, c ần điều chỉnh hệ số nhạy 
insulin.  
- Hạ glucose huy ết không rõ nguyên nhân: c ần đánh giá l ại liều lượng và phác đ ồ insulin. 
Tăng glucose huy ết không rõ nguyên nhân có th ể do nguyên nhân là sau h ạ glucose huyết 
làm tr ẻ ăn nhi ều và tăng hormon đi ều hòa đối kháng.  
- Liều insulin c ần linh ho ạt và thay đ ổi theo m ức độ hoạt động và s ự thay đ ổi chế độ ăn.  
4. Đường dùng và cách b ảo quản 
4.1. Cách tiêm insulin  
4.1.1. Bi ến chứng tại chỗ tiêm 
- Phì đ ại lớp mỡ: cần thay đ ổi vị trí tiêm.  Liều insulin hi ệu chỉnh = (270 – 120)/ 60 = 2,5 UI  
 30 
 
 - Teo l ớp mỡ dưới da: hi ếm gặp 
- Đau tại chỗ tiêm: hay g ặp; cần kiểm tra góc tiêm, chi ều dài kim tiêm, đ ộ sâu khi tiêm đ ể 
tránh tiêm vào l ớp cơ.  
- Phản ứng quá m ẫn tại chỗ 
- Bầm tím và ch ảy máu: x ảy ra ph ổ biến khi tiêm b ắp hoặc ép ch ặt da. 
4.1.2. Các y ếu tố ảnh hư ởng đến tiêm insulin  
- Nồng độ, thể tích và li ều insulin th ấp hơn → hấp thu nhanh hơn.  
- Vị trí tiêm: insulin tác d ụng ng ắn (insulin thông thư ờng) h ấp thu nhanh hơn khi tiêm ở 
bụng, ch ậm hơn khi tiêm ở cánh tay, sau là đùi và mông. Không có s ự khác bi ệt lớn khi 
tiêm insulin tác d ụng nhanh v à kéo dài.  
- Tốc độ dòng máu đ ến các mô c ủa cơ th ể: Hút thu ốc lá làm gi ảm lưu lư ợng máu đ ến các 
mô, d ẫn đến giảm hấp thu insulin. Ch ạy bộ làm tăng lưu lư ợng máu đ ến phần dưới cơ th ể, 
tăng h ấp thu insulin khi tiêm vào đùi ho ặc mông.  
+ Các y ếu tố khác làm tăng nhiệt độ da (tập thể dục, xoa bóp vùng tiêm,…) cũng làm 
tăng h ấp thu insulin.  
+ Béo phì: Tăng l ớp mỡ dưới da khi ến insulin h ấp thu ch ậm hơn do gi ảm dòng máu dư ới 
da.  
- Phì đ ại lớp mỡ dưới da: làm ch ậm sự hấp thu c ủa insulin.  
4.2. Cách b ảo quản insulin  
- Insuli n chưa đư ợc sử dụng: 
+ Bảo quản trong t ủ lạnh ở nhiệt độ 2-8 độ C cho đ ến khi h ết hạn sử dụng (không đ ể quá 
gần chế độ làm đông).  
+ Không nên s ử dụng insulin đã b ị hóa đông do ảnh hư ởng ch ất lượng thu ốc. 
+ Insulin đã s ử dụng: 
+ Bảo quản ở nhiệt độ phòng (dư ới 25 h oặc 30 đ ộ C) trong 4 tu ần. 
+ Thời gian s ử dụng sau khi m ở nắp từ 10 ngày đ ến 8 tu ần (tùy thu ộc từng lo ại insulin 
khác nhau), khuy ến cáo theo hư ớng dẫn của nhà s ản xuất. 
+ Insulin dùng trong bơm tiêm c ần thay đ ổi thư ờng xuyên. Nhà s ản xuất khuyên dùng 
insulin a spart và insulin lispro khi s ử dụng trong bơm tiêm đ ể nhiệt độ phòng không 
quả 6 và 7 ngày.  31 
 
  
Hình 1.  Sơ đồ các mũi tiêm insulin theo phác đ ồ tích c ực và truy ền thống 
 
 
  
32 
 
 PHẦN 7: DINH DƯ ỠNG VÀ T ẬP LUY ỆN TRONG ĐÁI THÁO ĐƯ ỜNG TÍP 1  
Ở TRẺ EM VÀ THANH THI ẾU NIÊN  
 
1. Chế độ dinh dưỡng  
Can thi ệp dinh dư ỡng bao g ồm: tư v ấn dinh dư ỡng cá th ể hóa, giáo d ục về dinh dư ỡng, thúc 
đẩy thay đ ổi hành vi ăn u ống lành m ạnh, xây d ựng quan h ệ hỗ trợ tin cậy với gia đình và t ạo 
ra mục tiêu chung. Ch ế độ dinh dư ỡng tốt giúp c ải thiện kết quả lâm sàng và ch ất lượng sống 
của trẻ. 
1.1. Nguyên t ắc dinh dư ỡng chung  
- Đảm bảo cân b ằng năng lư ợng: Đánh giá ngu ồn thực phẩm, thói quen ăn u ống cụ thể của 
trẻ. Từ đó, giáo d ục, hư ớng dẫn trẻ và gia đình v ề lựa chọn thực phẩm, nh ằm đạt cân n ặng 
và glucose huy ết mục tiêu. Nhu c ầu năng lư ợng và thói quen ăn u ống không c ố định, thay 
đổi theo giai đo ạn phát tri ển của trẻ, đặc biệt trong giai đo ạn dậy thì.  
- Duy trì cân n ặng lý tư ởng: Thừa cân và béo phì trong nhóm này có t ỷ lệ cao, do thay đ ổi 
chế độ ăn uống và gi ảm ho ạt động th ể chất. Cần hướng dẫn về điều chỉnh dinh dư ỡng, 
hoạt động th ể chất và gi ấc ngủ lành m ạnh. Đánh giá đ ịnh kỳ chiều cao, cân n ặng và theo 
dõi tốc độ phát tri ển, phát hi ện tăng ho ặc giảm cân b ất thường. 
- Cân đ ối trong m ức nạp năng lư ợng: Cacbohydrat  nên là ngu ồn cung c ấp tối thiểu 45% 
nhu c ầu năng lư ợng, tỉ lệ này có th ể cao hơn (60%) trong hoàn c ảnh ngu ồn thực phẩm 
ngoài cacbohydrat  hạn chế. Có th ể giảm cacbohydrat  (40%) và tăng protein (25%) đ ối với 
trẻ có kèm theo th ừa cân ho ặc béo phì.  
1.2. Các nhóm th ực phẩm 
- Cacbohydrat   
+ Trẻ có th ể tiêu th ụ 40-50% năng lư ợng từ cacbohydrat .  
+ Nên s ử dụng ngu ồn cacbohydrat  lành m ạnh như bánh mì nguyên h ạt, ngũ c ốc, đậu, 
các lo ại hạt, trái cây, rau và các s ản phẩm sữa ít béo (s ữa không tách kem hoàn toàn 
cho tr ẻ dưới 2 tu ổi). 
+ Chế độ ăn ít cacbohydrat  (dưới 26% t ổng năng lư ợng) ho ặc rất ít cacbohydrat  (20-50 
gram/ngày) hi ện chưa có đ ủ bằng ch ứng.  
- Sucrose  
+ Sucrose có th ể chiếm đến tối đa 10% t ổng năng lư ợng hàng ngày. Khi s ử dụng thêm 
sucrose c ần chú ý đ ến cân b ằng với liều insulin đang dùng.  
+ Hạn chế sử dụng đồ uống có đư ờng và có ga. Đ ồ uống sử dụng đư ờng ăn kiêng (g ắn 
mác "light", "diet") có th ể dùng trong các d ịp đặc biệt. Sucrose có th ể dùng thay cho 
glucose đ ể dự phòng và đi ều trị hạ glucose huy ết. 
- Protein : Nhu c ầu protein gi ảm dần theo tu ổi, giảm từ khoảng 2 g/kg/ngày ở trẻ nhũ nhi 
đến 1 g/kg/ngày v ới trẻ khoảng 10 tu ổi, giảm còn 0,8 - 0,9 g/kg/ngày ở cuối giai đo ạn vị 33 
 
 thành niên. Ưu tiên s ử dụng ngu ồn protein t ừ động vật bao g ồm cá, th ịt nạc và các s ản 
phẩm từ sữa tách kem, các protein th ực vật từ đậu. 
- Chất béo : Tỷ lệ chất béo: 30 -40% t ổng năng lư ợng, nên dùng các  loại chất béo chưa bão 
hòa mono (MUFA) và poly (PUFA) . Trẻ nên ăn các lo ại cá nhi ều dầu 1 - 2 lần mỗi tuần 
với lượng kho ảng 80-120 g.  
- Chất xơ: Nên dùng các th ực phẩm có ch ứa chất xơ như rau, qu ả và ngũ c ốc nguyên cám, 
đặc biệt các th ực phẩm tươi, thô, chưa qua chưa qua tinh ch ế.  
- Vitamin và khoáng ch ất: Trẻ em m ắc ĐTĐ có nhu c ầu vitamin và khoáng ch ất như các tr ẻ 
cùng l ứa tuổi. Cần bổ sung n ếu trẻ có dấu hiệu có thi ếu vi ch ất, đặc biệt là vitamin D.  
- Muối 
+ Trẻ mắc ĐTĐ nên h ạn chế lượng mu ối hàng ngày.  
+ Khuy ến cáo v ề lượng natri ăn vào m ỗi ngày như sau:  
+ Trẻ 1 đến 3 tu ổi: 1 g/ngày tương đương v ới 2,5 g mu ối ăn  
+ Trẻ từ 4 đến 8 tu ổi: 1200 mg/ngày tương đương 3 g mu ối ăn   
+ Trẻ trên 9 tu ổi: 1500 mg/ngày tương đương v ới 3,8 g mu ối ăn  
- Rượu bia và đ ồ uống có c ồn: Sử dụng rư ợu bia tăng r ủi ro v ề hạ glucose huy ết và/ho ặc 
tăng glucose huy ết, đặc biệt là h ạ glucose huy ết muộn sau u ống rư ợu bia t ừ 8 – 12 giờ.  
- Đường ăn kiêng và các th ực ph ẩm chuyên bi ệt: Các polyol như sorbitol, xylitol, 
isomaltose... đư ợc dùng t ạo ngọt và có th ể dùng đ ể cải thiện vị giác, có th ể gây r ối loạn 
tiêu hóa khi dùng trên 20 gram, đ ặc biệt ở trẻ nhỏ.  
1.3. N ội dung tư v ấn dinh dư ỡng 
1.3.1. T ần suất tư v ấn  
Tư v ấn dinh dư ỡng cần tiến hành ngay trong vòng tháng đ ầu sau khi ch ẩn đoán.  
Ngay t ừ lần đánh giá đ ầu tiên, c ần khai thác các thông tin sau:  
- Thói quen ăn u ống, truy ền thống và tín ngư ỡng sẵn có c ủa gia đình.  
- Các th ực phẩm thư ờng ăn, liên quan đ ến tổng lư ợng năng lư ợng, lư ợng cacbohydrat, t ỷ lệ 
phân b ổ theo b ữa ăn, lư ợng ch ất béo, l ựa chọn thực phẩm, th ời điểm ăn.  
- Các ho ạt động thư ờng ngày có ảnh hưởng như gi ờ giấc, ho ạt động ở trường học, trư ờng 
mẫu giáo, nơi làm vi ệc hoặc các ho ạt động th ể lực thể thao khác.  
Chế độ dinh dư ỡng cần được thiết kế tại thời điểm ch ẩn đoán d ựa trên thăm khám c ủa bác sĩ 
nội tiết - dinh dư ỡng và k ế hoạch cá th ể hóa.  
Các lần tư v ấn tiếp theo c ần được thực hiện trong vòng 3 đ ến 6 tháng sau khi l ần tư v ấn đầu 
tiên. T ần suất những lần thăm khám ti ếp theo tùy thu ộc vào đi ều kiện của khu v ực, tối thiểu 34 
 
 2 đến 4 l ần trong m ột năm đ ầu tiên và m ỗi năm m ột lần những năm sau đó, k ết hợp cùng 
chuyên khoa dinh dư ỡng. 
1.3.2. Tư v ấn về chế độ ăn lành m ạnh 
Sử dụng linh ho ạt các mô hình đĩa, tháp đ ể hướng dẫn trực quan sinh đ ộng về tỷ lệ các th ực 
phẩm ch ứa cacbohydrat so v ới các nhóm khác. Tr ẻ cần có các b ữa phụ lành m ạnh để cung 
cấp đủ các nguyên t ố đa lư ợng và vi lư ợng. Dư ới đây là m ột mô hình Đĩa ăn lành m ạnh để 
tham kh ảo:  
 
Hình 2. Mô hình đĩa ăn lành m ạnh 
1.3.3. Tư v ấn về phương pháp tính cacbohydrat  
Lượng cacbohydrat và li ều insulin tiêm trư ớc ăn là nh ững yếu tố quan tr ọng nh ất ảnh hư ởng 
đến glucose huy ết sau ăn. Trong đi ều kiện cho phép, có th ể tập huấn các phương pháp như 
kỹ năng đ ếm cacbohydrat  (carb counting) cơ b ản và nâng cao, giúp c ải thiện kiểm soát 
glucose huy ết và linh ho ạt trong kh ẩu phẩn ăn.  
1.3.4. Tư v ấn về Chỉ số Glucose huyết (GI, Glycemic Index)  
Áp d ụng ch ỉ số GI giúp c ải thiện kiểm soát glucose huy ết. Ch ỉ số GI không nên s ử dụng đơn 
độc mà c ần kết hợp với kỹ năng đ ếm cacbohydrat . Giá tr ị phân lo ại chỉ số GI: GI cao (> 70), 
GI trung bình (56 - 79), GI th ấp (< 55). Ch ỉ số GI của một món ăn ảnh hư ởng bởi nhiều yếu 
tố như cách ch ế biến, loại tinh b ột, lượng ch ất béo và đ ạm có trong nguyên li ệu. Các th ực 
phẩm giàu ch ất xơ, có ch ỉ số GI th ấp giúp làm ch ậm quá trình h ấp thu glucose vào máu.  
1.3.5. Ch ế độ dinh dư ỡng theo nhóm tu ổi 
- Trẻ dưới 6 tu ổi: Các b ữa nhỏ cố định trong ngày giúp c ải thiện về kiểm soát glucose huy ết. 
Không nên cho tr ẻ ăn vặt quá nhi ều vì có th ể làm cho tr ẻ từ chối ăn vào b ữa chính và gây 
ra tăng glucose huy ết sau ăn.  
- Trẻ học tiểu học – trung h ọc: Nhà trư ờng cần tạo điều kiện linh ho ạt để trẻ có th ể thử 
glucose huy ết, dùng thu ốc xen k ẽ trong th ời gian bi ểu và có k ế hoạch xử trí cấp cứu. M ột 
35 
 
 số trẻ sẽ cần thầy cô nh ắc nhở động viên ăn b ữa phụ hoặc tiêm insulin trư ớc khi ra chơi 
trong gi ờ nghỉ. 
- Trẻ vị thành niên : Nếu trẻ được chẩn đoán khi còn nh ỏ, trẻ cần được tư v ấn và giáo d ục 
sức khỏe lại về vai trò c ủa ăn u ống lành m ạnh và t ự quản lý ĐTĐ. C ần chú ý trao đ ổi về 
theo dõi cân n ặng, các áp l ực tâm lý, s ử dụng ch ất kích thích, bia rư ợu. Ứng dụng công 
nghệ số trong quản lý ĐTĐ có th ể phù h ợp và h ấp dẫn nhóm tu ổi này.  
1.3.6. Dinh dư ỡng trong hoàn c ảnh đặc biệt 
- Trong các s ự kiện và l ễ hội: Các s ự kiện đặc biệt này bao g ồm nhi ều hoạt động như ti ệc 
tùng, gi ỗ chạp, lễ Tết, hội hè đ ặc trưng cho t ừng vùng mi ền và văn hóa tí n ngư ỡng. M ỗi 
trường hợp sẽ cần có l ời khuyên và k ế hoạch cụ thể để duy trì th ời điểm ăn các b ữa chính 
– phụ và đi ều chỉnh insulin trư ớc các b ữa ăn giàu đ ạm, cacbohydrat  và ch ất béo.  
- Trẻ có hoàn c ảnh khó khăn : Gia đình kinh t ế khó khăn thư ờng có xu hư ớng sử dụng 
cacbohydrat  chất lượng th ấp. Tư v ấn dinh dư ỡng cho nhóm tr ẻ này c ần phù h ợp với thu 
nhập và đi ều kiện sống. Bác sĩ có th ể hướng dẫn các lưu ý trong chu ẩn bị và ch ế biến, 
điều chỉnh về tỷ lệ carbohydrat trong ch ế độ ăn, đưa ra các th ực phẩm lành m ạnh có chi 
phí h ợp lí. 
- Khi ho ạt động th ể dục thể thao 
+ Trước khi tập luy ện từ 1 đến 3 gi ờ: bổ sung b ữa phụ có cacbohydrat  và ít ch ất béo.  
+ Trong quá trình t ập, nếu bài t ập aerobic kéo dài trên 60 phút: b ổ sung cacbohydrat  từ 
các lo ại nước uống th ể thao đ ẳng trư ơng. Sau bu ổi tập, ăn thêm cacbohydrat đ ể bù đắp 
dự trữ glycogen ở cơ, gan và tránh h ạ glucose huy ết do tăng nh ạy cảm insulin khi cơ 
hồi phục.  
+ Trẻ cần được bù d ịch xuyên su ốt quá trình t ập luy ện. Nư ớc lọc là đ ồ uống phù h ợp 
cho ph ần lớn hoạt động dư ới 60 phút. Tuy nhiên đ ồ uống th ể thao có ch ứa 6 đ ến 8% 
cacbohydrat  hiệu quả hơn trong d ự phòng h ạ glucose huy ết và nâng cao hi ệu suất thi 
đấu, đặc biệt khi ho ạt động trên 1 gi ờ. 
1.3.7. Dinh dư ỡng với các phác đ ồ insulin  
- Với phác đ ồ 2 mũi m ỗi ngày : Cần duy trì ổn định lư ợng cacbohydrat  nạp vào hàng ngày 
(thường với ba b ữa chính và các b ữa phụ xen k ẽ). Trẻ cần có b ữa phụ có cacbohydrat  
trước khi ng ủ tối để dự phòng h ạ glucose huy ết về đêm. N ếu không th ể áp dụng các b ữa 
phụ này, phác đ ồ insulin 2 mũi m ỗi ngày không  nên áp d ụng ở trẻ nhỏ tuổi. 
- Với phác đ ồ insulin 3 – 4 mũi m ỗi ngày : Có th ể tiếp cận linh ho ạt với phương pháp dùng 
tỷ lệ insulin - cacbohydrat  (ICR) k ết hợp với đếm cacbohydrat , cho phép  chọn liều insulin 
vừa đủ với với lượng cacbohydrat  ăn vào c ủa bữa ăn đó. 
2. Chế độ vận động và tập luyện  
Thể dục thư ờng xuyên giúp c ải thiện kiểm soát glucose huy ết, kiểm soát cân n ặng, gi ảm biến 
chứng và nâng cao ch ất lượng sống. Tr ẻ cần tập thể dục ít nh ất 60 phút m ỗi ngày, v ới các 36 
 
 hoạt động hi ếu khí cư ờng độ trung bình (đ i bộ nhanh, đ ạp xe...), cư ờng độ cao (ch ạy bộ, nhảy 
dây...) và các bài t ập sức bền – kháng l ực (3 bu ổi mỗi tuần) theo tư v ấn của nhân viên y t ế. 
Trẻ và gia đình c ần đư ợc hướng dẫn về nguy cơ r ối loạn glucose huy ết liên quan đ ến tập 
luyện, cách phòng tránh,  điều chỉnh insulin và b ổ sung b ữa phụ.  
2.1. Điều chỉnh insulin và dinh dư ỡng trong t ập luy ện 
Trẻ có th ể tập thể dục tại trường nếu không có ch ống ch ỉ định khác. Gia đình và nhà trư ờng 
cần trao đ ổi thông tin đ ể có phương án phù h ợp. Các bu ổi tập trên 30 phút c ần có đi ều chỉnh 
trước, trong, sau và trong đêm sau bu ổi tập.  
Mục tiêu: glucose trong khi t ập từ 5,0–15,0 mmol/L và d ự phòng h ạ glucose huy ết sau t ập. 
Nếu glucose huy ết ngay trư ớc tập ho ặc trong bu ổi tập < 5 mmol/L: t ạm ngh ỉ, bổ sung 
carbohydrat, x ử trí hạ glucose huy ết, thử lại glucose huy ết trước khi b ắt đầu hoặc tập lại. 
2.1.1.  Điều chỉnh trư ớc buổi tập 
- Giảm liều insulin ở bữa ăn trư ớc buổi tập kho ảng 25 đ ến 75%. 
- Cần chú ý kho ảng th ời gian gi ữa bữa ăn và bu ổi tập (tốt nhất là 90 phút).  
- Nếu bữa ăn cách th ời điểm bắt đầu tập trên 2 ti ếng: không ch ỉnh liều insulin.  
2.1.2.  Điều chỉnh trong bu ổi tập 
Trẻ cần ăn (u ống) thêm carbohydrat (0,5 – 1 gram/kg cho m ỗi giờ tập) khi t ập kéo dài. Tr ẻ 
cần kiểm tra glucose huy ết mỗi 30 phút (v ới SMBG), xem xu hư ớng glucose huy ết mỗi 20 
phút (v ới CGM). Chú ý sai s ố chậm trễ khi dùng CGM trong t ập hiếu khí.  
2.1.3.  Điều chỉnh ngay sau bu ổi tập  
- Giảm 50% li ều insulin trư ớc bữa ăn sau bu ổi tập, đặc biệt với tập hiếu khí.  
- Tập giãn cơ cu ối buổi tập để dự phòng tăng glucose huy ết do tích t ụ lactat, ad renalin.  
2.1.4.  Điều chỉnh trong đêm sau bu ổi tập 
Nếu tập luy ện sau 16h, c ần điều chỉnh: gi ảm 20% li ều insulin n ền (giảm 20% t ốc độ nền của 
bơm insulin trong 6 ti ếng); và thêm b ữa phụ. Với trẻ tiêm insulin 2 l ần mỗi ngày, không đi ều 
chỉnh liều tối và thêm b ữa phụ trước ngủ. 
2.2. Các trư ờng hợp chống ch ỉ định tạm thời 
ĐTĐ không ph ải là ch ống ch ỉ định với hoạt động th ể thao t ại tất cả các c ấp học, cấp độ huấn 
luyện và thi đ ấu. Các ch ống ch ỉ định tạm thời bao g ồm: 
- Có cơn h ạ glucose huy ết nặng (có r ối loạn tri giác) trong vòng 24 gi ờ trước buổi tập.  
- Glucose huy ết > 15 mmol/L, kèm theo có ceton máu ho ặc ceton ni ệu.  
- Trẻ đang có ch ấn thương và/ho ặc nhi ễm khu ẩn cấp tính.  
- Tránh thi đ ấu đối kháng khi ki ểm soát glucose huy ết kém, ho ặc có bi ến chứng nặng. 
 37 
 
 PHẦN 8: THEO DÕI GLUCOS E HUY ẾT TRONG ĐÁI THÁO ĐƯ ỜNG TÍP 1  
Ở TRẺ EM VÀ THANH THI ẾU NIÊN  
 
Hiện nay có nh ững phương pháp theo dõi glucose huyết như CGM  (continuous glucose 
monitoring - theo dõi glucose huyết liên t ục), SMBG (Self -monitoring of blood glucose - tự 
theo dõi glucose mao m ạch), và HbA1c.  Khi duy trì đư ợc đích glucose huyết tương  qua theo 
dõi CGM, HbA1c và/ho ặc SMBG s ẽ giảm đư ợc các nguy cơ, bi ến chứng cấp và mãn tính c ủa 
ĐTĐ , và gi ảm thiểu các h ậu quả của tăng/h ạ glucose huyết đối với sự phát tri ển của não, cải 
thiện khả năng nh ận thức, tinh th ần và ch ất lượng cu ộc sống.  
Tuy nhiên, trong m ột số trường hợp đặc biệt, các m ục tiêu này không c ần quá nghiêm ng ặt 
vì có th ể gây h ại cho s ức kho ẻ tổng th ể của ngư ời bệnh ho ặc ngư ời chăm sóc h ọ. Các y ếu tố 
cần xem xét khi đ ặt mục tiêu ít nghiêm ng ặt hơn bao g ồm (nhưng không gi ới hạn): 
- Công ngh ệ phân ph ối insulin tiên ti ến (bơm insulin t ự động), v ật tư c ần thiết để thường 
xuyên ki ểm tra m ức glucose mao m ạch, ho ặc CGM c ần thiết đạt được mục tiêu m ột cách 
an toàn.  
- Các v ấn đề về sức khỏe tâm th ần tiềm ẩn trở nên tr ầm trọng hơn khi n ỗ lực để đạt được 
mức glucose huyết mục tiêu.  
 
 
Hình 3. Các đích glucose ph ụ thuộc vào nh ững công c ụ sẵn có như:  SMBG (finger stick), 
HbA1c, và CGM . Glucose mao m ạch lúc đói đư ợc khuy ến cáo trong ngư ỡng 4 – 8 mmol/L 
(70 – 144 mg/dL ) 
 
38 
 
 1. HbA1c  
Hemoglobin glycated (HbA1c) v ẫn là m ột trong nh ững ch ỉ số chính trong vi ệc quản lý 
glucose huyết, nhờ vào nh ững yếu tố sau:  
- Có b ằng ch ứng rõ ràng v ề mối liên quan gi ữa HbA1c và s ự xuất hiện của các bi ến chứng 
do ĐTĐ .  
- Là một phương pháp và có quy trình tham chi ếu được tiêu chu ẩn hóa do Liê n đoàn Hóa 
sinh Lâm sàng Y  học Quốc tế (IFCC) đ ặt ra và đư ợc tất cả các bên liên quan đ ồng thu ận. 
- Là phương pháp d ễ tiếp cận khi t ới khám đ ịnh kỳ tại các cơ s ở y tế hoặc cơ s ở tư vấn từ 
xa. 
- Dễ tiếp cận hơn so v ới CGM.  
Mỗi năm ngư ời bệnh ph ải được đo lư ờng HbA1c 4 l ần (mỗi 3 tháng m ột lần). 
1.1. Mục tiêu  
- Đích khuy ến cáo trong ĐTĐ típ 1 ở trẻ em và thanh thi ếu niên  là < 53 mmol/mol (< 7,0%). 
Mức này đư ợc chứng minh là gi ảm thi ểu được những biến chứng lâu dài ở vi mạch và 
mạch máu l ớn. 
- Mức HbA1c  < 48 mmol/mol (6,5%) đư ợc khuy ến cáo cho giai đo ạn đầu của ĐTĐ , “trăng 
mật”, khi đang đư ợc theo dõi qua CGM ho ặc khi đang đi ều trị bằng insulin bơm t ự động. 
1.2. Các h ạn chế của HbA1c  
- Một số tình tr ạng liên quan đ ến tốc độ thay đ ổi huy ết sắc tố hoặc sự sống sót c ủa hồng 
cầu sẽ ảnh hư ởng đến chỉ số HbA1c và đánh giá trên lâm sàng.  
- Tăng luân chuy ển hồng cầu dẫn tới giảm HbA1c:  
+ Phục hồi từ tình tr ạng thi ếu sắt, thiếu vitamin B12 và thi ếu folate . 
+ Mang tha i: quý hai của thai k ỳ. 
+ Bệnh th ận mãn tính: Đi ều trị bằng Erythropoietin và l ọc máu . 
+ Mất máu c ấp tính . 
+ Tan máu (b ệnh hồng cầu hình li ềm, thalassemia, G6PD) . 
+ Bệnh xơ nang  
+ Hóa tr ị 
- Giảm luân chuy ển hồng cầu dẫn tới tăng HbA1c:  
+ Các tình tr ạng thi ếu sắt, thiếu vitamin B12, thi ếu folate . 
+ Mang thai: quý ba c ủa thai k ỳ. 
+ Bệnh th ận mạn: đái máu . 
2. Test glucose mao m ạch - SMBG  
SMBG nên đư ợc đánh giá ít nh ất từ 4-6 lần mỗi ngày đ ối với ngư ời mắc bệnh ĐTĐ  đang 
dùng insulin.  39 
 
 Bảng 4. Mối tương quan gi ữa HbA1c và glucose huyết 
HbA1c (%)  5,5–6,5 6,5–6,9 7,0–7,4 7,5–7,9 8,0–8,5 
Glucose huyết 
trung bình ư ớc tính 
(mmol/L ) 6,2–7,7 7,8–8,5 8,6–9,3 9,4–10,1 10,2–
10,9 
2.1. Đích glucose mao m ạch 
Nên đư ợc duy trì trong kho ảng 4-10 mmol (70 -180mg/dL ) và v ới phạm vi m ục tiêu lúc đói 
hẹp hơn là 4 -8 mmol/L  (70-144 mg/dL ). Mức SMBG nên đư ợc nhắm mục tiêu tương ứng 
với HbA1c < 53 mmol/mol (7%). Đi ều này phù h ợp với thời gian CGM trong ph ạm vi m ục 
tiêu > 70% trong kho ảng từ 3,9-10 mmol (70 -180 mg/dL ) và m ối tương quan ch ặt chẽ của 
các ch ỉ số CGM v ới HbA1c đã đư ợc xem xét trư ớc đó.  
Glucose mao m ạch khi t ập luy ện 
- Mức glucose m ao m ạch trước và trong th ời gian t ập luy ện phụ thuộc vào nhi ều yếu tố như 
là thời gian t ập luy ện, ch ế độ dùng insulin, có s ử dụng CGM không. Kho ảng glucose m ao 
mạch khuy ến cáo đư ợc duy trì trong t ập luy ện là 5 -15 mmol/L  (90-270 mg/dL ) và tránh 
những tập luy ện mạnh khi ến hạ glucose huyết. 
- Những ho ạt động th ể lực mức độ vừa phải, như đi b ộ và đạp xe trong 15 -45 phút gi ữa các 
bữa ăn, giúp h ạ mức glucose huyết > 10,5 mmol/L (1 90 mg/dL ) một cách an toàn.  
3. Theo dõi glucose huy ết liên t ục (CGM)  
Khuy ến cáo dư ới đây v ề các đích glucose huyết thông qua CGM dành cho tr ẻ em, thanh thi ếu 
niên và ngư ời trẻ < 25 tu ổi. Áp dụng sớm CGM t ừ lúc ch ẩn đoán có liên quan đ ến lợi ích lâu 
dài đ ối với HbA1c. Tuy nhiên, vi ệc tiếp cận CGM không đư ợc phổ biến ở nhiều nơi.  
Lý do hay g ặp nhất dừng theo dõi qua CGM là t ổn thương da, ho ặc hiện tượng chai lì v ới báo 
động, vì v ậy cần được cá th ể hoá khi s ử dụng các báo đ ộng của CGM.  
Mục tiêu  glucose huyết: 
- > 70% gi ữa 3,9 và 10 mmol/L  (70-180 mg/dL ) 
- < 4%: <  3,9 mmol/L  (70 mg/dL ) 
- < 1%: <  3,0 mmol/L  (54 mg/dL ) 
- < 25%: >  10 mmol/L  (180 mg/dL ) 
- < 5%: >  13,9 mmol/L  (250 mg/dL ) 
- Biến thiên glucose huyết (hệ số biến thiên, [%CV]) m ục tiêu ≤ 36%  
 
 
 
 
  40 
 
 PHẦN 9: CHĂM SÓC TRẺ  ĐÁI THÁO ĐƯỜNG TÍP 1 KHI BỊ ỐM  
 
1. Theo dõi glucose huyết thường xuyên hơn  
- Đối với trẻ mắc bệnh ĐTĐ , khi bị ốm, glucose huyết thường bị rối loạn: tăng, giảm hoặc 
cũng có thể bình thường. Khi trẻ bị ốm đặc biệt có nôn, sốt hoặc tiêu chảy, cần phải kiểm 
tra gl ucose huyết, và ceton trong nước tiểu thường xuyên. Mức độ thường xuyên tùy thuộc 
vào mức độ nghiêm trọng của bệnh nhưng thường mỗi 2 -3 giờ một lần.  
- Mục tiêu glucose huyết là 70 -180 mg/dL  (3,9 – 10 mmol/L ) 
2. Không dừng insulin  
- Bệnh tật và nhiễm trùng có thể  là dấu hiệu báo trước của nhiễm toan ceton ĐTĐ  (DKA).  
- Ngay cả khi bị bệnh, trẻ ăn kém hoặc không ăn được  cũng sẽ cần insulin. Liều lượng 
insulin có thể cần phải điều chỉnh nếu glucose huyết tăng cao, giảm thấp hoặc có ceton 
trong máu hoặc nước tiểu nhiều  hay ít.  
3. Kiểm tra ceton trong nước tiểu  
- Ceton trong nước tiểu phản ánh tình trạng thiếu insulin. Vì vậy, khi có ceton trong nước 
tiểu trung bình hoặc nhiều, cần bổ sung insulin tác dụng nhanh hoặc bù dịch cho trẻ  
- Mục tiêu ceton máu < 0,6 mmo/l hoặc ceton  nước tiểu dạng vết  
4. Điều chỉnh insulin  
Glucose ( mg/dL ) 
(mmol/L ) Ceton âm tính hoặc dương tính 
nhẹ Ceton trung bình hoặc nặng  
< 100  
(< 5,5)  Sử dụng dịch có đường  
Không tiêm insulin  Sử dụng dịch có đường  
Tiêm insulin bình thường  
100-199 
(5,5-10,9)  Sử dụng dịch có đường  
Tiêm insulin bình thường  Sử dụng dịch có đường  
Tăng liều insulin gấp 1,5 lần  
>200  
(>11)  Sử dụng dịch không có đường  
Tiêm insulin như bình thường  Cho dịch không đường  
Tăng liều insulin gấp 1,5 lần  
- Cách bù dịch  
+ Nên u ống từng ng ụm (15 -30 ml) sau m ỗi 10-15 phút. U ống dung d ịch không ch ứa 
caffeine đ ể ngăn ng ừa tình tr ạng m ất nước. 
+ Khi lư ợng glucose huy ết dưới 200 mg/dL  (11,1 mmol/L ), hãy u ống từng ng ụm dung 
dịch bù nư ớc thể thao ho ặc đồ uống có ch ứa đường khác.  
+ Khi lư ợng glucose huy ết trên 200 mg/dL  (11,1 mmol/L ), hãy u ống từng ng ụm dung 
dịch không đư ờng. 
+ Nếu sử dụng theo hư ớng dẫn ở trên m ột lần nhưng không ti ến triển (trẻ vẫn nôn ho ặc 
có ceton m ức độ trung bình đ ến nặng, c ần liên h ệ trực tiếp với bác s ỹ chuyên khoa đ ể 41 
 
 được tư v ấn. Nếu trẻ đau b ụng dữ dội và/ho ặc khó th ở với lượng ceton v ừa đến lớn, 
hãy đưa tr ẻ đến phòng c ấp cứu. 
5. Chăm sóc trẻ đái tháo đường sử dụng bơm insulin khi bị ốm  
- Kiểm tra glucose huyết mỗi 1 đến 2 giờ.  
- Kiểm tra ceton nước tiểu hoặc ceton trong máu nếu glucose huyết từ 250 mg/dL  (13,8 
mmol/L ) trở lên và trẻ nôn, buồn nôn, đau bụng .  
5.1. Đối với ceton vết hoặc dương tính nhẹ  
- Thay đổi vị trí đặt sensor, đặc biệt nếu đã được thay trước đó hơn 2 -3 ngày.  
- Tiêm liều bolus điều chỉnh bằng bơm insulin.  
- Khuyến khích bổ sung nước hoặc dung  dịch không đường khác.  
- Kiểm tra glucose huyết và ceton 1 -2 giờ sau khi tiêm liều bolus.  
5.2. Đối với ceton dương tính vừa hoặc mạnh  
- Tiêm liều điều chỉnh gấp 1,5 lần thông thường bằng bút insulin hoặc xi lanh.  
- Thay đổi vị trí đặt sensor.  
- Khuyến khích bổ sung nư ớc hoặc dung dịch không đường khác.  
- Kiểm tra glucose huyết và ceton 1 -2 giờ sau khi tiêm liều bolus.  
- Nếu không cải thiện sau liều điều chỉnh, hãy liên hệ với bác sỹ chuyên khoa.  
Chú ý :  
- KHÔNG BAO GIỜ bỏ qua lượng glucose trong máu  cao! 
- Hai mẫu liên tiếp c ao không giải thích được có thể do vị trí truyền insulin hoặc bơm có 
vấn đề.  
 
  42 
 
 PHẦN 10: HẠ GLUCOSE HUYẾT TRONG ĐÁI THÁO  ĐƯỜNG  
Ở TRẺ EM VÀ THANH TH IẾU NIÊN  
 
Hạ glucose huy ết trong ĐTĐ  được định nghĩa là tình tr ạng các đ ợt hạ glucose  huyết gây ảnh 
hưởng tới chức năng não và gây nguy hi ểm cho trẻ và khi glucose huy ết tương <3,9 mmol/L  
(70 mg/dL ). Hạ glucose  huyết là bi ến chứng thư ờng gặp trong đi ều trị ĐTĐ típ 1.  
1. Nguyên nhân và các y ếu tố gây h ạ glucose huy ết 
Nguyên nhân chính c ủa hạ glucose huy ết là sự không phù h ợp giữa sử dụng insulin và th ức 
ăn đư ợc cung c ấp. 
Nguyên nhân:  
- Thừa insulin: tăng li ều do thi ếu hiểu biết về insulin: nh ầm liều, nh ầm loại thuốc.  
- Chế độ ăn gi ảm: gi ảm ăn ho ặc bỏ bữa. 
- Tập luy ện quá m ức: nguy cơ h ạ glucose huy ết ngay sau t ập luy ện hoặc sau 7 -11 gi ờ sau 
luyện tập. 
- Khi ng ủ: hạ glucose huy ết khi ng ủ xảy ra kho ảng 8% người ĐTĐ  và tần suất cao hơn ở 
trẻ em.  
- Uống rư ợu: giảm lượng glucose n ội sinh k ết hợp ăn không đ ủ cacbohydrat , say rư ợu làm 
giảm ý th ức nhận thức dấu hiệu hạ glucose huy ết. 
Yếu tố nguy cơ:  
- Nhận thức kém v ề hạ glucose huy ết; có cơn h ạ glucose huy ết nặng trư ớc đó; Đ TĐ lâu 
năm.  
   Các b ệnh kèm theo làm tăng nguy cơ h ạ glucose huy ết: 
- Bệnh Celiac (không dung n ạp Gluten); B ệnh Addison (Suy thư ợng th ận mãn tính); Suy 
giáp; R ối loạn tâm lý . 
2. Triệu chứng lâm sàng  
Hạ glucose huy ết thường có tri ệu chứng ho ặc dấu hiệu của thần kinh th ực vật (cư ờng giao 
cảm) và/ho ặc triệu chứng của suy gi ảm thần kinh do thi ếu glucose trong não. Các tri ệu chứng 
của thần kinh th ực vật ở trẻ em thư ờng xảy ra khi glucose huy ết tương 3,9 mmol/L . Tuy 
nhiên, m ỗi người bệnh có bi ểu hiện lâm sàng v ới các ngư ỡng hạ glucose huy ết khác nhau.  
Hầu hết các cơn h ạ glucose huy ết nặng xảy ra vào đêm khi đang ng ủ. 
- Các tri ệu chứng và d ấu hiệu thần kinh th ực vật: Lo ạng cho ạng, run r ẩy, vã m ồ hôi, run 
tay, m ạch nhanh, da xanh tái . 
- Các tri ệu chứng và d ấu hiệu thần kinh: Thi ếu tập trung, nhìn m ờ, nhìn đôi, r ối loạn màu, 
nghe kém, nói l ắp, kh ả năng phán đoán kém, nh ầm lẫn, vấn đề với trí nh ớ ngắn hạn, yếu 
cơ, tê bì, chóng m ặt, dán g đi lo ạng cho ạng, ph ối hợp kém, m ất ý th ức, co gi ật. 
- Các tri ệu chứng và d ấu hiệu hành vi: kích thích, hành vi b ất thường, kích đ ộng, ác m ộng, 
khóc kéo dài . 43 
 
 - Các tri ệu chứng không đ ặc hiệu:cảm giác đói, đau đ ầu, bu ồn nôn, m ệt mỏi. 
3. Biến chứng của hạ glucose huyết trong đái tháo đư ờng 
Tử vong do h ạ glucose huy ết ở trẻ ĐTĐ  chiếm 4 – 10%. 
Biến chứng th ần kinh: Suy gi ảm nh ận thức thoáng qua, ph ục hồi sau 1 gi ờ khi n ồng độ glucose 
huyết bình thư ờng. Chưa có b ằng ch ứng rõ ràng v ề tổn thương th ần kinh kéo dài ở trẻ em liên 
quan đ ến hạ glucose huy ết tương . 
Biến chứng tâm th ần của hạ glucose  huyết: Hạ glucose  huyết có th ể gây h ậu quả tiêu c ực về 
tâm lý xã h ội và các hành vi không mong mu ốn, gây căng thăng, b ối rối và ảnh hư ởng đến 
hoạt động th ể chất, xã h ội và h ọc tập. 
4. Xử trí và d ự phòng  
Việc giáo d ục ĐTĐ  tập trung vào nh ận biết nguyên nhân và y ếu tố nguy cơ, kh ả năng phát 
hiện triệu chứng hạ glucose huy ết, tầm quan tr ọng của việc phát hi ện hạ glucose huy ết bằng 
theo dõi  glucose huy ết, điều trị hạ glucose huy ết một cách  thích h ợp, tiếp cận phòng cơn trong 
tương lai. CGM đã h ỗ trợ tích c ực việc phát hi ện sớm và qu ản lý h ạ glucose huy ết tốt hơn. 
Glucose mao m ạch đư ợc chỉ định khi có tri ệu chứng lâm sàng c ủa hạ glucose huy ết. 
Xử trí hạ glucose huy ết: 
- Khi glucose huy ết tương  < 3,9 mmol/L  (70 mg/dL ) 
+ Bổ sung cacbohydrat  đường uống:  
Người lớn: 20 g  (viên glucose ho ặc nước hoa qu ả/mật ong)  
Trẻ em: 0,3 g/kg (viên glucose ho ặc nước hoa qu ả/mật ong)  
+ Kiểm tra l ại glucose huy ết tương sau 15 phút:  
Nếu glucose huy ết tương < 3,9 mmol/L : nhắc lại liều uống trên.  
Nếu glucose > 3,9 mmol/L : trẻ nên ăn b ữa nhẹ vào th ời điểm đó ( bánh m ỳ, sữa, bánh 
quy, hoa qu ả) 
- Hạ glucose huy ết nặng cần điều trị cấp cứu: 
+ Trẻ hôn mê/không có kh ả năng nu ốt: 
Một trong 4 thu ốc sau  nếu có 
Glucagon 1mg/ml: > 25kg:  tiêm dư ới da/tiêm b ắp 1mg  
                               < 25kg: tiêm dư ới da/tiêm b ắp 0,5mg  
Glucagon 3mg : > 4 tu ổi: nhỏ mũi 
Glucagon  0,6mg:  6 tuổi: tiêm dư ới da 
Glucagon 0,5mg; 1mg: > 2 tu ổi;  > 45 kg: 1mg tiêm dư ới da; <45 kg: 0,5mg tiêm dư ới da 
+ Tiêm tĩnh m ạch glucose 0,2g – 0,5 g/kg (2ml – 5 ml glucose 10%).  
+ Kiểm tra l ại glucose huy ết tương sau 15 phút:  44 
 
 Nếu glucose <3,9 mmol/L  và tr ẻ lơ mơ: ti ếp tục 1 l ần glucagon ho ặc tiêm tĩnh m ạch 
glucose như trên  
Nếu glucose >3,9 mmol/L , trẻ tỉnh táo: tr ẻ nên ăn b ữa nhẹ vào th ời điểm đó ( bánh m ỳ, 
sữa, bánh quy, hoa qu ả)  
    Dự phòng h ạ glucose huy ết  
+ Tìm hi ểu nguyên nhân và y ếu tố nguy cơ gây h ạ glucose huy ết: Bỏ bữa ăn, t ập thể 
dục, dùng sai li ều insulin, b ệnh kèm theo . 
+ Tư v ấn cho trẻ về nguy cơ h ạ glucose huy ết: khi ốm, khi có b ệnh kèm theo, khi t ập thể 
dục, khi ng ủ.  
+ Tư v ấn cách phát hi ện và cách x ử trí hạ glucose huy ết. 
+ Chỉnh lại liều insulin và đi ều chỉnh lối sống với từng trẻ. 
+ Tư v ấn sử dụng các ti ến bộ công ngh ệ để phát hi ện hạ glucose huy ết, đặc biệt về đêm: 
CGM; bơm insulin.  
 45 
 
  
Lưu đ ồ 3. Nhận biết, xử trí và d ự phòng h ạ glucose huy ết trong ĐTĐ típ 1.  
 
  
46 
 
 PHẦN 11: BI ẾN CH ỨNG M ẠCH MÁU TRONG ĐÁI THÁ O ĐƯ ỜNG   
Ở TRẺ EM VÀ THANH THI ẾU NIÊN  
 
Biểu hiện lâm sàng các b ệnh lý m ạch máu (m ạch máu nh ỏ và lớn) thư ờng ít g ặp trong th ời kì 
trẻ nhỏ và thanh thi ếu niên. Tuy nhiên, nh ững tổn thương vi th ể về cấu trúc và ch ức năng s ẽ 
sớm xu ất hiện sau vài năm kh ởi phát ĐTĐ típ 1 . Giáo d ục, theo dõi chuyên sâu, và sàng l ọc 
nhằm phát hi ện, điều trị và ngăn ng ừa biến chứng là nh ững yếu tố quan tr ọng hàng đ ầu trong 
việc chăm sóc tr ẻ em và thanh thi ếu niên m ắc ĐTĐ típ 1 . 
1. Sàng l ọc và ch ẩn đoán  
1.1. Sàng l ọc biến chứng m ạch máu do đái tháo đư ờng 
Bảng 5. Khuy ến ngh ị sàng l ọc các bi ến chứng m ạch máu  trong ĐTĐ típ 1  
 Thời điểm sàng l ọc Phương pháp sàng l ọc 
Bệnh lý th ận Tuổi dậy thì ho ặc 11 
tuổi với kho ảng th ời 
gian m ắc bệnh từ 2 – 5 
năm Đo ACR ni ệu 
Bệnh ph ẩm: m ẫu nước tiểu buổi sáng  
Tần suất: hàng năm   
Bệnh lý võng m ạc 11 tu ổi với thời gian 
mắc bệnh 2 – 5 năm.  Chụp hoặc soi đáy m ắt 
Tần suất: mỗi 2 – 3 năm.  
Bệnh lý th ần kinh  11 tu ổi với thời gian 
mắc bệnh 2 – 5 năm.  Khai thác ti ền sử 
Khám th ực thể 
Các test lâm sàng  
Tần xuất: hàng năm  
Bệnh lý m ạch máu 
lớn 11 tu ổi với thời gian 
mắc bệnh 2 – 5 năm.  Xét nghi ệm lipid máu: m ỗi 3 năm  
Huyết áp: hàng năm, t ốt nhất là m ỗi 
lần thăm khám.  
 
Khuy ến ngh ị:  
1.1.1. B ệnh th ận do đái tháo đư ờng 
- Thời điểm sàng l ọc: albumin ni ệu, độ lọc cầu thận ước tính (eGFR) ở tuổi dậy thì ho ặc từ 
11 tu ổi với thời gian m ắc bệnh 2-5 năm . Sau đó l ặp lại hàng năm.  
- Chẩn đoán xác đ ịnh tăng albumin ni ệu khi ≥ 2/3 m ẫu (+) trong th ời gian 3 -6 tháng. Các 
yếu tố gây nhi ễu bao g ồm tập thể dục, kinh nguy ệt, viêm đư ờng tiết niệu, sốt, bệnh th ận 
không do ĐTĐ  và glucose huyết cao. 
- Xét nghi ệm tìm nguyên nhân b ệnh th ận không do ĐTĐ  ở tất cả trẻ em và thanh thi ếu niên 
mắc bệnh ĐTĐ típ 1 có d ấu hiệu bệnh th ận mạn (CKD) ở giai đo ạn A3 (t ỷ lệ 47 
 
 albumin/creatinin ni ệu > 300 mg/g ho ặc 30 mg/ mmol) ho ặc G2 -5 (eGFR < 90 
ml/phút /1,73m2) bao g ồm phân tích nư ớc tiểu, siêu âm th ận và xét nghi ệm mi ễn dịch. 
1.1.2. B ệnh võng m ạc do đái tháo đư ờng 
- Thời điểm sàng l ọc bệnh võng m ạc nên b ắt đầu ở tuổi dậy thì ho ặc từ 11 tu ổi với thời gian 
mắc bệnh 2-5 năm v ới ĐTĐ típ 1 . 
- Sàng l ọc bệnh võng m ạc được thực hiện bởi bác sĩ chuyên khoa m ắt hoặc chuyên gia có 
kinh nghi ệm bằng ki ểm tra soi đáy m ắt có giãn đ ồng tử qua kính hi ển vi quang h ọc hoặc 
chụp ảnh đáy m ắt. 
- Tần suất: khi th ời gian m ắc ĐTĐ  dưới 10 năm, b ệnh võng m ạc không tăng sinh m ức độ 
nhẹ (NPDR, ví d ụ: vi phình m ạch) và ki ểm soát glucose  huyết đạt mục tiêu thì t ần suất 
sàng l ọc bệnh võng m ạc có th ể 2 năm/ lần. Tần suất có th ể giảm xu ống 3 năm/ lần nếu 
không có b ệnh võng m ạc ở lần đánh giá đ ầu tiên, nhưng s ẽ lặp lại thư ờng xuyên hơn ở 
những trư ờng hợp có các y ếu tố/ đặc điểm nguy cơ cao gây m ất thị lực. 
- Kiểm soát gluc ose huyết kém kéo dài: ti ến triển xấu của bệnh võng m ạc có th ể diễn ra 
nhanh chóng nhưng cũng có th ể được phục hồi nhanh chóng. Khuy ến ngh ị theo dõi nhãn 
khoa t ại thời điểm trư ớc khi b ắt đầu điều trị tích c ực, sau đó m ỗi 3 tháng trong 6 -12 tháng, 
đặc biệt với những trư ờng hợp bệnh võng m ạc không tăng sinh m ức độ trung bình – nặng 
hoặc tình tr ạng bệnh võng m ạc xấu tại thời điểm bắt đầu điều trị. 
- Kết hợp theo dõi tích c ực với bác s ỹ chuyên khoa m ắt những ngư ời trẻ mắc bệnh võng 
mạc đe d ọa thị lực (bệnh võng m ạc không tăng sinh m ức độ trung bình – nặng và/ho ặc 
phù hoàng đi ểm do ĐTĐ (DME) . 
1.1.3. B ệnh lý th ần kinh do đái tháo đư ờng 
- Sàng l ọc bệnh lý th ần kinh ngo ại biên b ắt đầu ở tuổi dậy thì ho ặc từ 11 tu ổi với thời gian 
mắc bệnh 2-5 năm đ ối với ĐTĐ típ 1 .  
- Sàng  lọc bệnh lý th ần kinh ngo ại biên bao g ồm đánh giá nhi ệt độ hoặc cảm giác kim châm, 
độ rung và ph ản xạ mắt cá chân.  
- Sàng l ọc bệnh lý th ần kinh t ự động bao g ồm đánh giá s ự thay đ ổi của tư th ế và nh ịp tim, 
hay test đáp ứng nh ịp tim v ới nghi ệm pháp Valsalva ( Novak P, 2011).  
1.1.4. B ệnh lý m ạch máu l ớn 
- Tầm soát tăng huy ết áp: đo huy ết áp ít nh ất hàng năm và t ốt nhất là ở mỗi lần tái khám 
khi tr ẻ được chẩn đoán ĐTĐ típ 1 . 
- Tầm soát r ối loạn lipid máu  với ĐTĐ típ 1 : ngay khi chẩn đoán ở trẻ từ 11 tuổi (khi 
glucos e huyết  ổn định). Nếu nồng độ lipid b ình thường, kiểm tra lại 3 năm/ lần. Nếu tiền 
sử gia đình bị tăng cholesterol huyết , bệnh tim mạch (CVD) hoặc không rõ tiền sử gia 
đình, bắt đầu sàng lọc sớm từ năm 2 tuổi.  
1.2. Ch ẩn đoán  
1.2.1. Bệnh th ận do đái tháo đư ờng 48 
 
 - Biến chứng th ận là nguyên nhân chính gây b ệnh tật và t ử vong ở người trẻ mắc ĐTĐ típ 
1, thường đư ợc chia làm 5 giai đo ạn, tương ứng với những thay đ ổi cụ thể và tiến triển về 
hình thái và ch ức năng th ận. 
+ Giai đo ạn sớm nh ất được đặc trưng b ởi phì đ ại cầu thận, siêu l ọc và tăng tư ới máu.  
+ Giai đo ạn tiếp theo là giai đo ạn cận lâm sàng v ới sự thay đ ổi hình thái và tăng t ỉ lệ bài 
tiết albumin.  
+ Giai đo ạn 3 là giai đo ạn tiếp tục tăng bài ti ết albumin qua nư ớc tiểu với tỷ lệ bài ti ết 
albumin t ừ 30-300 mg/ 24h ho ặc 20 -200 µg/ phút trong 24h ho ặc tỷ lệ 
albumin/creatinin t ừ 3-30 mg/mmol (30 -300 mg/g), cho th ấy sự tăng albumin ni ệu 
mức độ trung bình, trư ớc đây g ọi là microalbumin ni ệu. 
+ Giai đo ạn 4 là giai đo ạn tăng albumin ni ệu nghiêm tr ọng (trư ớc đây g ọi là albumin 
niệu đại thể) với tỷ lệ bài ti ết albumin > 200 µg/phút ho ặc > 300 mg/ 24h; t ỷ lệ 
albumin/creatinine  > 30 mg/ mmol (> 300 mg/g).  
+ Giai đo ạn 5: ti ến triển suy th ận. 
- Albumin ni ệu là m ột trong nh ững dấu hiệu đầu tiên c ủa bệnh th ận ĐTĐ , ngư ỡng phát hi ện 
có giá tr ị là ≥ 30 mg/g ho ặc 3 mg/mmol. Ch ẩn đoán xác đ ịnh albumin ni ệu khi ≥ 2/3 m ẫu 
nước tiểu dương tính trong 3 -6 tháng. Tuy nhiên, albumin ni ệu không ph ải dấu hiệu duy 
nhất của bệnh th ận ĐTĐ  nên vi ệc đánh giá thư ờng xuyên ch ức năng th ận cũng r ất quan 
trọng. Theo  dõi thư ờng xuyên eGFR là r ất quan tr ọng để phát hi ện tình tr ạng suy gi ảm 
chức năng th ận và kh ả năng l ọc của thận. 
- Bệnh th ận mạn: 50 -60% tr ẻ được phát hi ện có microalbumin ni ệu sẽ tiến triển sang b ệnh 
thận ĐTĐ . Bênh th ận ĐTĐ  được định nghĩa là nh ững bất thường về cấu trúc ho ặc chức 
năng th ận, xu ất hiện >3 tháng. B ệnh th ận ĐTĐ  hiện được phân lo ại theo Cause, GFR (G1 -
5) và Albumin ni ệu (A1 -3) (hư ớng dẫn của KDIGO).  49 
 
   
Lưu đ ồ 4. Sàng l ọc bệnh th ận do m ắc ĐTĐ típ 1 và 2.  
  
50 
 
 1.2.2.  B ệnh võng m ạc do đái tháo đư ờng 
- Bệnh võng m ạc được định nghĩa và phân lo ại quốc tế theo Thang đo m ức độ nghiêm tr ọng 
bệnh lý võng m ạc ĐTĐ  của Wilkinson và c ộng sự. 
- Bệnh lý võng m ạc nền được đặc trưng b ởi các vi phình m ạch đặc trưng cho b ệnh võng 
mạc ĐTĐ , xuất huy ết cả trước và trong võ ng m ạc, xu ất tiết mềm và c ứng liên quan đ ến 
vi nh ồi máu, rò r ỉ protein và lipid tương ứng, các b ất thường và giãn m ạch vi m ạch trong 
võng m ạc, co th ắt và ngo ằn ngoèo c ủa mạch máu. B ệnh võng m ạc nền không đe d ọa thị 
lực và không ti ến triển thành b ệnh võng m ạc tăng sinh.  
- Bệnh võng m ạc tiền tăng sinh đư ợc đặc trưng b ởi tắc ngh ẽn mạch máu, các b ất thường vi 
mạch trong võng m ạc tiến triển và nh ồi máu các s ợi thần kinh võng m ạc gây ra các đ ốm 
bông gòn.  
- Bệnh võng m ạc tăng sinh (PDR) đư ợc đặc trưng b ởi tân m ạch ở võng m ạc và/ho ặc bề mặt 
sau th ủy tinh th ể. Các m ạch máu có th ể bị vỡ hoặc chảy máu vào khoang d ịch kính võng 
mạc, đe d ọa thị lực. Sự bao b ọc trong mô liên k ết dẫn đến kết dính, có th ể gây xu ất huy ết 
và bong võng m ạc.  
- Bệnh võng m ạc không tăng sinh (NPDR) đ ặc trưng b ởi vi phình m ạch, xu ất huy ết võng 
mạc (cả trước và trong võng m ạc), các đ ốm sáng liên quan đ ến thiếu máu c ục bộ và nh ồi 
máu vi mô, xu ất huy ết cứng do rò r ỉ protein và lipid, b ất thư ờng m ạch máu nh ỏ trong 
võng m ạc (IRMA) và giãn tĩnh m ạch.  
- Phù ho àng đi ểm (DME) đ ặc trưng b ởi giảm sức bền thành m ạch (tăng tính th ấm thành 
mạch) và hình thành vi phình m ạch, gây ti ết dịch và phù ở trung tâm võng m ạc.  
- Các phương pháp phát hi ện bệnh võng m ạc: 
+ Chụp ảnh đáy mắt lập thể và chụp mạch huỳnh quang có độ nhạ y cao.  
+ Các kỹ thuật khác được sử dụng trong việc phát hiện bệnh võng mạc do ĐTĐ  bao gồm 
soi đáy mắt gián tiếp và chụp ảnh đơn sắc trường đơn.  
1.2.3. B ệnh th ần kinh do đái tháo đư ờng 
- Các b ệnh th ần kinh cơ th ể liên quan đ ến ĐTĐ  được chia thành hai lo ại chính:  
+ Bệnh th ần kinh khu trú bao g ồm bệnh đơn dây th ần kinh như h ội chứng ống cổ tay, 
liệt dây th ần kinh mác, li ệt dây III, … (ví dụ bệnh teo cơ do ĐTĐ ). 
+ Bệnh đa dây th ần kinh c ảm giác v ận động ĐTĐ  là bệnh th ần kinh t ổng quát ph ổ biến 
nhất do đó  thuật ngữ đơn gi ản hóa “b ệnh th ần kinh ĐTĐ ” thư ờng đư ợc sử dụng.  
+ Đánh giá lâm sàng bao g ồm hỏi bệnh sử, đặc biệt là tê, đau dai d ẳng ho ặc dị cảm; và 
kiểm tra th ể chất các ph ản xạ mắt cá chân, đ ộ rung và c ảm giác ch ạm nh ẹ (bằng cách 
kiểm tra th ần kinh thông thư ờng hoặc bằng các s ợi đơn chia đ ộ). 
+ Các xét nghi ệm thần kinh t ự chủ bao g ồm: nh ịp tim ph ản ứng với hơi th ở sâu, đ ứng từ 
tư thế nằm, Valsalva Manoeuvre, s ự thay đ ổi nhịp tim khi ngh ỉ ngơi, kho ảng QT, thay 
đổi huy ết áp tư th ế và ph ản ứng của đồng tử đối với sự thích nghi v ới ánh sáng và 
bóng t ối.  51 
 
 + Các xét nghi ệm th ần kinh ngo ại biên bao g ồm: đ ịnh lư ợng ngư ỡng phân bi ệt rung, 
nhiệt và d ẫn truy ền thần kinh.  
+ Đánh giá t ại giường ch ức năng các dây th ần kinh nh ỏ bao g ồm đánh giá nhi ệt độ hoặc 
cảm giác kim châm ở bàn ch ân. Ch ức năng s ợi thần kinh l ớn bằng âm thoa 128 Hz ở 
ngón chân cái (đ ộ đặc hiệu cao, đ ộ nhạy thấp) để nhận biết rung và d ụng cụ đo áp k ế 
10 g monofilament cho c ảm giác ch ạm/áp lực; ho ặc phản xạ mắt cá chân cho s ợi thần 
kinh l ớn.  
1.2.4.  Bệnh lý m ạch máu l ớn do đ ái tháo đư ờng 
- Bệnh lý tim m ạch (CVD) là m ột nguyên nhân quan tr ọng gây t ử vong ở người ĐTĐ típ 
1; Phát hi ện sớm xơ v ữa động m ạch bằng siêu âm đo đ ộ dày l ớp nội mạc động m ạch cảnh 
và động m ạch ch ủ (cIMT và aIMT).  
- Tăng huy ết áp: đ ối với trẻ ĐTĐ  < 13 tu ổi, tăng huy ết áp đư ợc định nghĩa là huy ết áp tâm 
thu (HATT) và/ ho ặc huy ết áp tâm tr ương (HATT) ≥ 95  bách phân v ị theo gi ới, tuổi, và 
chiều cao v ới ít nh ất 3 lần đo. V ới trẻ ≥ 13 tu ổi, tăng huy ết áp đư ợc xác đ ịnh khi HATT 
và/ ho ặc HATT ≥ 130/ 80 mmHg. Cân nh ắc đo holter huy ết áp 24h n ếu nghi ng ờ tăng 
huyết áp không rõ ràng.  
- Lipid máu: Cholesterol đóng m ột vai trò quan tr ọng trong s ự khởi đầu và ti ến triển của 
chứng xơ v ữa động m ạch. Nh ững thay đ ổi về lipid liên quan đ ến béo phì trung tâm làm 
tăng b ệnh lý tim m ạch ở người ĐTĐ típ 1 .  
2. Điều trị  
2.1. B ệnh th ận do đái tháo đư ờng 
- Tối ưu hóa glucose huyết, huy ết áp giúp phòng và ngăn s ự tiến triển của albumin ni ệu, 
bệnh th ận ĐTĐ . 
- Thuốc ức chế men chuy ển (trẻ em và thanh thi ếu niên):  
+ Captop ril: u ống, kh ởi đầu 0,3 -0,5 mg /kg/lần mỗi 8 gi ờ; có th ể tăng li ều tối đa hàng 
ngày lên 6mg/kg/ ngày chia 3 l ần (NHBPEP, 2004; NHLBI 2011) . 
+ Enalapril: u ống, b ắt đầu bằng liều 2,5 -5 mg/ ngày, sau đó tăng li ều dần trong 1 -2 tuần, 
có th ể tăng li ều lên 10 -40 mg/ ngày, chia 2 l ần. 
+ Lisinopril: U ống, kh ởi liều từ 0,07-0,1 mg/kg/l ần duy nh ất 1 lần/ngày (li ều khởi đầu 
tối đa 5mg/ ngày), tăng d ần liều trong 1 -2 tuần có th ể 0,6 mg/kg/ngày, t ối đa 40 
mg/ngày.  
2.2. Ki ểm soát huy ết áp 
Mục tiêu đi ều trị là HA luôn nh ỏ hơn 90 bách phân v ị theo tu ổi, giới tính và chi ều cao.  
 
 
 52 
 
 Bảng 6. Các ngư ỡng giá tr ị được đề xuất để can thi ệp và phòng ng ừa biến chứng vi m ạch và 
bệnh lý tim m ạch ở trẻ em và thanh thi ếu niên ĐTĐ típ 1  
 
Ngưỡng giá tr ị Can thi ệp 
< 13 tu ổi: HA > 90 bách phân v ị theo tu ổi, giới, và 
chiều cao  
≥ 13 tu ổi: HA >120/80 mnHg  Can thi ệp lối sống: th ể dục, ch ế độ 
ăn và gi ảm thời gian s ử dụng thi ết 
bị điện tử (lối sống tĩnh t ại). 
< 13 tu ổi: HA > 90 bách phân v ị theo tu ổi, giới, và 
chiều cao m ặc dù đã can thi ệp thay đ ổi lối sống 
≥ 13 tu ổi: HA > 120/80 mnHg  mặc dù đã can thi ệp 
thay đ ổi lối sống Thuốc ACEI ho ặc thu ốc hạ áp 
khác  
Nếu có albumin ni ệu tăng cao: 
thuốc ACEI ho ặc AIIRA  
< 13 tu ổi: HA > 95 bách phân v ị theo tu ổi, giới, và 
chiều cao  
≥ 13 tu ổi: HA >130/90 mnHg  Thay đ ổi lối sống và thu ốc ACEI 
hoặc các t huốc hạ áp khác  
Nếu albumin ni ệu tăng: ACEI 
hoặc AIIRA  
LDL - C > 2,6 mmol/ L (100 mg/dL ) Chế độ ăn và thay đ ổi lối sống 
LDL - C > 3,4 mmol/ L (100 mg/dL ) Statin  
 
AIIA ( angiotensin II receptor blockers), ức ch ế chọn th ụ thể angiotensin II; ACEI 
(Angiotensi n converting enzyme inhibitors), ức chế men chuy ển angiotensin.  
- Ở trẻ em và thanh thi ếu niên b ị tăng huy ết áp, đi ều trị ban đ ầu bao g ồm các can thi ệp về 
lối sống, bao g ồm ch ế độ ăn kiêng DASH (Dietary Approaches to Stop Hypertension) và 
hoạt động th ể chất trung bình đ ến mạnh ít nh ất 3 – 5 ngày m ỗi tuần (30 – 60 phút m ỗi 
lần). N ếu HA m ục tiêu không đ ạt được trong 6 tháng k ể từ khi b ắt đầu can thi ệp lối sống 
thì tr ẻ nên đư ợc can thi ệp điều trị bằng thu ốc. 
- Khi cao huy ết áp đư ợc chẩn đoán xác đ ịnh ở trẻ mắc bệnh ĐTĐ típ 1 , ngoài vi ệc thay đ ổi 
lối sống, c ần cân nh ắc kết hợp điều trị bằng thu ốc sớm hơn trong ĐTĐ típ 2 . Thu ốc điều 
trị ở trẻ em và thanh thi ếu niên nên b ắt đầu bằng ACEI, AIIRA, ch ẹn kênh canxi tác d ụng 
kéo dài ho ặc lợi niệu thiazid . Ưu tiên s ử dụng A CEI cho tr ẻ bị tăng huy ết áp và/ ho ặc 
albumin ni ệu, thay th ế bằng AIIRA n ếu không dung n ạp (do ho).  
2.3. Ki ểm soát r ối loạn mỡ máu 
- Sàng l ọc rối loạn mỡ máu c ần được thực hiện ở trẻ từ 11 tu ổi mắc bệnh ĐTĐ típ 1 . Nếu 
tiền sử gia đình có ngư ời tăng choleste rol máu ho ặc tử vong s ớm do CVD (< 55 tu ổi) thì 
trẻ cần được sàng l ọc từ lúc 2 tu ổi. Xét nghi ệm sàng l ọc có th ể không nh ịn ăn, nhưng khi 
phát hi ện rối loạn lipid (ví d ụ tăng triglyceride, cholesterol ho ặc LDL -C) thì c ần được xét 
nghiệm lại tại thời điểm kh i trẻ có nh ịn ăn.  
- Kiểm soát ban đ ầu (thư ờng kéo dài 6 tháng) khi có r ối loạn mỡ máu b ằng ch ế độ ăn, li ệu 
pháp t ập thể dục và ki ểm soát glucose huyết chặt chẽ cho th ấy cải thiện rõ r ệt tình tr ạng 53 
 
 rối loạn lipid máu. Ch ế độ ăn can thi ệp: ≤ 7% năng lư ợng từ chất béo bão hòa; kho ảng 
10% t ừ chất béo không bão hòa, và cholesterol trong kh ẩu phần ăn ≤ 2 00 mg/ ngày.  
- Kiểm soát b ằng thu ốc được thực hiện sau 6 tháng can thi ệp lối sống mà không làm gi ảm 
LDL -C < 3,4 mmol/ L (130 mg/dL ) với nhóm statin ở trẻ > 10 tu ổi, với mục tiêu LDL -C 
lý tư ởng < 2,6 mmol/L . Các thu ốc nhóm statin (Simvastatin, Lovastatin, và Pravastatin) 
cho th ấy có hi ệu quả và an toàn và tr ẻ em.  
2.4. Đi ều trị bệnh lý võng m ạc do đái tháo đư ờng 
- Sau khi phát hi ện đe d ọa thị lực, các l ựa chọn điều trị bao gồm quang đông b ằng laser và/ 
hoặc liệu pháp ch ống đông VEGF.  
- Đối với PDR, tiêm n ội nhãn kháng VEGF (Ranibizumab, Aflibercept, và Bevacizumab) 
được sử dụng ngày càng ph ổ biến và k ết quả cho th ấy hiệu quả về cải thiện thị lực tốt hơn 
PRP.   
- Đối với DME b ị mất thị lực, thu ốc kháng VEGF đư ợc coi là thu ốc điều trị tiêu chu ẩn và 
đã cho th ấy kết quả vượt trội trong 5 năm so v ới “liệu pháp laser”. S ử dụng steroid tác 
dụng kéo dài trong d ịch kính (Dexamethasone và Fluocinolone) là m ột giải pháp thay th ế 
cho thu ốc kháng VEGF ở người bệnh m ắc DME cho th ấy giảm kh ả năng nhi ễm trùng. 
Tuy nhiên, tác d ụng trên th ị lực kém hơn và tác d ụng ph ụ tiềm tàng gây đ ục thủy tinh th ể, 
tăng nhãn áp, do đó steroid không ph ải thuốc sử dụng đầu tay trong DME.  
- Phẫu thu ật cắt dịch kính đ ược chỉ định khi có xu ất huy ết dịch kính dai d ẳng, bong võng 
mạc co kéo ho ặc xơ hóa lan t ỏa.  54 
 
  
1. Đích glucose huyết dành cho phẫu thuật  
Duy trì n ồng độ glucose huy ết tương: 5 -10 mmol/L   
Ngăn ng ừa hạ glucose huy ết 
Ngăn ng ừa tình tr ạng toan ceton ĐTĐ  
2. Phân lo ại phẫu thu ật/thủ thuật và đánh giá trư ớc phẫu thu ật  
- Phân lo ại: phẫu thu ật lớn và ti ểu phẫu. Với các ph ẫu thu ật lớn trên tr ẻ ĐTĐ  điều trị tốt, 
việc kiểm soát glucose huy ết có th ể dễ dàng hơn  ở trẻ ĐTĐ  thực hiện tiểu phẫu nhưng 
điều trị không t ốt và chăm só c hạn chế.  
+   Tiểu phẫu được định nghĩa là các th ủ thuật ngắn (thư ờng dư ới 2 gi ờ), có/không dùng các 
thuốc an th ần hoặc gây mê, ph ục hồi nhanh chóng và tr ẻ có th ể ăn trở lại ở bữa tiếp theo 
trong ngày (trong vòng 2 -4 giờ) ví d ụ như: th ủ thuật nội soi, ch ụp phim, c ắt amidan, đ ặt 
ống thông khí ho ặc thay băng . 
+   Phẫu thu ật lớn bao g ồm: bất kỳ cuộc phẫu thu ật hoặc thăm dò nào dư ới gây mê mà th ời 
gian > 2 gi ờ, sau ph ẫu thu ật bệnh nhân có nguy cơ cao nôn, bu ồn nôn ho ặc không th ể nuôi 
dưỡng hoàn toàn b ằng đư ờng miệng. 
3. Chăm sóc trư ớc mổ cho tr ẻ đái tháo đư ờng đi ều trị bằng Insulin  
3.1. Nguyên t ắc chung  
- Cuộc phẫu thu ật nên đư ợc thực hiện đầu tiên vào bu ổi sáng đ ể tránh ngư ời bệnh ph ải nhịn 
ăn kéo dài và d ễ dàng đi ều chỉnh phác đ ồ điều trị. 
- Người bệnh nên đư ợc nhập viện trư ớc 1 ngày ho ặc cùng ngày ph ẫu thu ật/ thủ thuật. Nếu 
phẫu thu ật ngo ại trú, ngư ời bệnh cần được tư v ấn để glucose huy ết đạt đích. N ếu ngư ời 
bệnh cần nhập viện trư ớc khi ph ẫu thu ật nếu có lý do ho ặc ĐTĐ  không đư ợc kiểm soát 
tốt. 
- Bác s ỹ gây mê c ần có kinh nghi ệm với điều trị ĐTĐ  phụ thuộc insulin và h ội chẩn bác s ỹ 
chuyên khoa N ội tiết- Đái tháo đư ờng trư ớc đó. 
- Điều chỉnh insulin ph ụ thuộc tính ch ất cuộc phẫu thu ật và tình tr ạng glucose huy ết của 
người bệnh, k ể cả khi nh ịn ăn v ẫn cần dùng i nsulin đ ể ngăn ng ừa toan ceton ĐTĐ.  
- Thiết lập và duy trì đư ờng truy ền tĩnh m ạch trư ớc/trong ph ẫu thu ật để điều trị hạ glucose 
huyết nếu có. 
- Theo dõi glucose huy ết mỗi giờ trước, trong và sau ph ẫu thu ật để phát hi ện và ngăn ng ừa 
hạ hoặc tăng glucose huy ết. Xét nghi ệm nước tiểu hoặc ceton máu n ếu glucose huy ết 
tương > 14 mmol/L . 
- Một số trường hợp tiểu phẫu có chu ẩn bị người bệnh có th ể sử dụng bơm insulin n ếu 
glucose huy ết tương ổn định. 
3.2. Đ ối với các ph ẫu thu ật lớn PHẦN 12: PHẪU THUẬT TRÊN TRẺ EM VÀ THANH  THIẾU NIÊN  
MẮC BỆNH ĐÁI THÁO ĐƯỜNG  55 
 
 Buổi tối trước khi ph ẫu thu ật  
- Sử dụng isnsulin và o buổi tối trước khi đi ng ủ (có th ể giảm liều insulin n ền 20% -30%) . 
- Nếu dùng bơm insulin, ti ếp tục dùng insulin n ền liều thông thư ờng (cân nh ắc giảm 20% 
liều nếu lo ng ại hạ glucose huy ết). 
- Theo dõi glucose huy ết và đo Beta - hydroxybutyrate trong máu ho ặc xác định th ể ceton 
trong nư ớc tiểu nếu glucose huy ết > 14 mmol/L .  
Ngày  phẫu thu ật  
- Dừng insulin bu ổi sáng (li ều nền và li ều tác d ụng nhanh) vào ngày ph ẫu thu ật và b ắt đầu 
duy trì insulin tĩnh m ạch. 
- Duy trì insulin và d ịch truy ền (glucose 5% và Natri Clorua  0,9%) .  
- Dừng bơm insulin ngay khi duy trì insulin tĩnh m ạch. 
- Phụ thuộc vị trí dây truy ền insulin c ủa bơm insulin và ph ẫu trư ờng của cuộc mổ, dây 
truyền có th ể được giữ nguyên ho ặc gỡ bỏ.  
- Theo dõi glucose huy ết mỗi giờ trong giai đo ạn bắt đầu duy trì i nsulin tĩnh m ạch, trong 
phẫu thu ật và sau ph ẫu thu ật, thay đ ổi tốc độ dịch truy ền glucose ho ặc insulin đ ể glucose 
huyết đạt đích: 5 -10 mmol/L .  
- Nếu glucose huy ết < 4 mmol/L , bolus g lucose 10 % li ều 2ml/kg, ki ểm tra l ại glucose 
huyết sau 15 phút. N ếu glucose h uyết tương ti ếp tục < 4 mmol/L , dừng tiêm insulin trong 
15 phút và ki ểm tra l ại glucose.  
Sau ph ẫu thu ật 
Tiếp tục truy ền dung d ịch glucose cho đ ến khi trẻ có th ể ăn uống  
3.3. Đối với các phẫu thuật nhỏ    
Đối với tất cả trẻ ĐTĐ  điều trị bằng insulin  
- Nếu glu cose huy ết < 4 mmol/L , xử trí tiêm nhanh glucose 10% li ều 2ml/kg. Ki ểm tra l ại 
glucose huy ết sau 15 phút và l ặp lại nếu cần. 
- Nếu glucose huy ết > 14 mmol/L  kéo dài > 1 gi ờ, cân nh ắc sử dụng insulin tác d ụng nhanh 
tiêm dư ới da theo li ều thông thư ờng của trẻ hoặc hiệu chỉnh 5-10% t ổng liều duy trì h ằng 
ngày c ủa trẻ. Xét nghi ệm tìm th ể ceton trong máu ho ặc nước tiểu, và duy trì insulin n ếu 
thể ceton dương tính.  
3.4. Đối với trẻ ĐTĐ  điều trị bằng insulin nền phối hợp insulin tác dụng nhanh  
Đối với phẫu thu ật diễn ra vào bu ổi sáng  
- Vào bu ổi sáng ngày tiến hành  thủ thuật, tiếp tục sử dụng li ều insulin n ền hằng ngày 
(glargine, detemir, degludec). N ếu đánh giá trư ớc phẫu thu ật, trẻ có glucose huy ết buổi 
sáng th ấp, cân nh ắc giảm 20 -30% t ổng liều nền. 56 
 
 - Không s ử dụng ins ulin tác d ụng nhanh trư ớc bữa sáng và tiêm li ều insulin này vào b ữa 
sáng mu ộn sau ph ẫu thu ật hoặc sử dụng để điều trị tăng glucose huy ết nếu có sau ph ẫu 
thuật. 
- Trẻ ĐTĐ  điều trị phác đ ồ insulin đa mũi có tăng glucose huy ết cần truy ền dịch không 
chứa glucose . Tuy nhiên, trẻ ĐTĐ  điều trị bằng insulin NPH c ần đư ợc truy ền dịch có 
glucose đ ể giảm nguy cơ h ạ glucose huy ết. Truy ền insulin tĩnh m ạch trong trư ờng hợp 
phẫu thu ật lớn trên tr ẻ ĐTĐ . 
Đối với phẫu thu ật diễn ra vào bu ổi chiều  
- Trong buổi sáng ngày tiến hàn h thủ thuật, dùng liều insulin tác dụng kéo dài thông thường. 
Trên một số trẻ, giảm 20 -30% tổng liều có thể giảm nguy cơ hạ glucose huy ết.  
- Nếu bác sĩ gây mê cho phép trẻ ăn một bữa sáng nhẹ và uống các loại dịch trong suốt 
trong vòng 4 tiếng trước thủ thu ật, có thể truyền dịch và truyền insulin trước thủ thuật 2 
giờ nếu như bác sĩ nội tiết - đái tháo đường yêu cầu.   
3.5. Đối với trẻ ĐTĐ  điều trị bằng bơm insulin tiêm dưới da liên tục  
- Trẻ có th ể tiếp tục dùng bơm tiêm insulin liên t ục trong quá trình ph ẫu thuật, thủ thuật. 
Tuy nhiên, n ếu bác s ỹ gây mê không có kinh nghi ệm trong vi ệc sử dụng bơm insulin, nên 
dừng bơm insulin và s ử dụng insulin đư ờng tĩnh m ạch. 
- Khi trẻ đến phòng m ổ: cần cố định dây truy ền insulin và thi ết bị bơm tiêm đ ể tránh gián 
đoạn cung c ấp insulin trong su ốt quá trình ph ẫu thu ật. Vị trí gắn bơm cách xa khu v ực 
phẫu thu ật và không b ị đè ép, bơm tiêm nên đư ợc thay ngày trư ớc phẫu thu ật và không 
duy trì quá 2 ngày.  
- Nếu thời gian gây mê ng ắn (dư ới 2 gi ờ) có th ể tiếp tục duy trì insulin n ền liều tương t ự 
ngày thư ờng. Có th ể tạm dừng insulin n ền nếu cần thi ết để điều chỉnh cơn h ạ glucose 
huyết nhẹ nhưng không đư ợc quá 30 phút và d ừng các li ều insulin tác d ụng nhanh.   
- Nếu hạ glucose huy ết thì cần cấp cứu như trên .  
- Không tiêm bolus insulin tác d ụng nhanh tr ừ khi đ ể điều chỉnh tăng glucose huy ết và 
/hoặc thể ceton dương tính . 
- Nếu hạ huyết áp c ấp tính, truy ền nhanh NaCl 0,9% và tránh dùng dung d ịch có ch ứa kali.  
3.6.  Đối với phẫu thu ật cấp cứu  
- Các tri ệu chứng nhi ễm toan ceton có th ể giống bệnh lý b ụng ngo ại khoa. N ếu trẻ có tình 
trạng nhi ễm toan ceton (pH< 7, 3 và/ho ặc HCO3 - < 18 mmol/L , thể ceton dương tính) , 
điều trị theo phác đ ồ toan ceton ĐTĐ  và trì hoãn cu ộc phẫu thu ật cho đ ến khi tình tr ạng 
trẻ ổn định. 
- Nếu trẻ không có tình tr ạng nhi ễm toan ce ton, truy ền dịch và s ử dụng insulin tương t ự 
trên trẻ phẫu thu ật có chu ẩn bị. 
- Nếu phẫu thu ật lớn, cấp cứu trên tr ẻ bệnh nặng, dừng li ệu pháp bơm tiêm insulin liên 
tục.  57 
 
 PHỤ LỤC 1: TỐC ĐỘ BÙ  DỊCH THEO CÂN NẶNG VÀ MỨC ĐỘ MẤT NƯỚC  
TRONG NHIỄM TOAN CET ON DO ĐÁ I THÁO ĐƯỜNG (ML/KG/ GIỜ)  
 
Cân 
nặng 
(kg) TỐC ĐỘ BÙ DỊCH THEO 
CÂN NẶNG  (ml/kg/giờ)  Cân 
nặng 
(kg) TỐC ĐỘ BÙ DỊCH THEO 
CÂN NẶNG  (ml/kg/giờ)  
Mất 
nước 
nhẹ Mất 
nước 
vừa Mất 
nước 
nặng Mất 
nước 
nhẹ Mất 
nước 
vừa Mất 
nước 
nặng 
5 24 27 31 38 100 125 155 
7 33 38 43 40 105 130 160 
8 38 43 50 42 105 135 170 
10 48 54 62 44 110 135 175 
12 53 60 70 46 115 140 180 
14 60 65 80 48 115 145 185 
16 65 75 85 50 120 150 190 
18 70 80 95 52 120 155 195 
20 75 85 105 54 125 160 205 
22 80 90 110 56 125 160 210 
24 80 95 115 58 130 165 215 
26 85 100 120 60 133 171 220 
28 85 105 125 62 136 175 226 
30 90 110 135 64 139 179 232 
32 90 110 140 66 140 185 240 
34 95 115 145 68 145 185 245 
36 100 120 150 70 150 190 250 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 58 
 
 PHỤ LỤC 2: CÁC LOẠI INSULIN VÀ THỜI GIAN  TÁC DỤNG KHI  TIÊM DƯỚI DA  
 
Loại insulin  Thời gian b ắt đầu 
tác d ụng (gi ờ) Thời gian tác 
dụng đỉnh (gi ờ) Thời gian kéo 
dài (gi ờ) 
Insulin tác d ụng nhanh     
Tác d ụng cực nhanh (faster 
aspart)  0,1-0,2 1-3 3-5 
Tác d ụng nhanh – RAI 
(aspart, glulisine and 
lispro )  0,15 -0,35 1-3 3-5 
Tác d ụng ng ắn (insulin 
thông thư ờng) 
Regular/soluble (short 
acting)  0,5 - 1 2-4 5-8 
Insulin tác d ụng trung bình     
NPH, NPL* (isophane)  2-4 4-12 12-24 
Insulin tác d ụng kéo dài     
Glargine  2-4 8-12 22-24 
Detemir  1-2 4-7 20-24 
Glargine U300  2-6 Rất nhỏ 30-36 
Degludec  0,5 – 1,5 Rất nhỏ > 42 
 
* NPH: neutral protamine hagedorn; NPL: neutral protamine lispro  
 
 
 
  59 
 
 PHỤ LỤC 3: VỊ TRÍ TI ÊM INSULIN VÀ KHẢ NĂ NG HẤP THU CỦA TỪNG  VỊ TRÍ  
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
  
60 
 
 TÀI LIỆU THAM KHẢO  
 
1. Libman I, Haynes A, Lyons S, et al. ISPAD  Clinical Practice Consensus Guidelines 2022: 
Definition, epidemiology, and classification of diabetes in children and adolescents. Pediatr 
Diabe tes. 2022;23(8):1160 -1174.  
2. World Health Organization. Classification of Diabetes Mellitus. World Health 
Organization . 2019; Accessed May 19, 2023. https://apps.who.int/iris/handle/10665/325182  
3. Solis -Herrera C, Triplitt C, Reasner C, et al. Classification of Diabetes Mellitus. Endotext.  
2018, Accessed May 19, 2023. http://www.ncbi.nlm.nih.gov/books/NBK279119/  
4. Nicole G, Maria F, Leena P, et al. ISPAD Clinical Practice Consensus Guidelines 2022: 
Diabetic ketoacidosis and hyperglycemic hyperosmolar state. Pediatric Diabetes . 
2022;23(7):835 -856. 
5. Cengiz E, Danne T, Ahmad T, et al. ISPAD Clinical Practice Consensus Guidelines 2022: 
Insulin treatment in children and adolescents with diabetes . Pediatr Diabetes . 
2022;23(8):1277 -1296.  
6. Donner T & Sarkar S. Insulin – pharmacology, therapeutic regimens and principles of 
intensive insulin therapy. [Updated  2023 Feb 15]. In:  Feingold KR,  Anawalt B,  Boyce A, et 
al, eds. Endotext . [Internet]. South Dartmouth, MA: MDText.com, Inc.;  2000. PMID: 
25905175.  
7. Annan SF, Higgins LA, J elleryd E, et al. ISPAD Clinical Practice Consensus Guidelines 
2022: Nutritional management in children and adolescents with diabetes. Pediatr Diabetes . 
2022;23(8):1297 -1321.  
8. American Diabetes Association. Children and Adolescents:  Standards of Medical Ca re in 
Diabetes -2020. Diabetes Care . 2020;43(1):163 -182.  
9. Gujral J, Zgorski M , Tamborlane W.V. Exercise and Diabetes. In: Tamborlane, W.V. 
(eds) Diabetes in Children and Adolescents. Contemporary Endocrinology . 13 February 
2021.  
10. Chetty T, Shetty V, Fournier  PA, et al. Exercise Management for Young People With Típ 
1 Diabetes: A Structured Approach to the Exercise Consultation. Front Endocrinol 
(Lausanne) . 2019;10:326.  
11. De Bock M, Codner E, Craig ME, et al. ISPAD Clinical Practice Consensus Guidelines 
2022: Gl ycemic targets and glucose monitoring for children, adolescents, and young people 
with diabetes. Pediatric Diabetes . 2022;(23):1270 -6.  
12. Adolfsson P, Taplin CE, Zaharieva DP, et al. ISPAD Clinical Practice Consensus 
Guidelines 2022: Exercise in children and  adolescents with diabetes. Pediatric Diabetes . 
2022;(23):1341 -72.  
13. Elsayed NA, Aleppo G, Aroda VR, et al. Glycemic Targets: Standards of Care in 
Diabetes. Diabetes Care . 2023 ;(46):97 -110.  61 
 
 14. Cheng AYY, Feig DS, Ho J, et al. Blood Glucose Monitoring in adults and children with 
Diabetes: Update 2021. Can J Diabetes . 2021;45(7):580 -7.  
15. Imran SA, Agarwal G, Bajaj HS, et al. Targets for Glycemic Control. Can J Diabetes . 
2018;(42):42 -6.  
16. Mary B A, Beate K, Klemen D,  et al. I SPAD  Clinical Practice C onsensus Guidelin es 2022: 
Assessment and management of hypoglycemia in children and adolescents with diabetes. 
Pediatric Diabetes . 2022; 23(8):1322 -1340.  
17. International Hypoglycaemia Study Group. Minimizing hypoglycemia in diabetes. 
Diabetes Care . 2015;38(8):1583 -1591.  
18. Abra ham MB, Nicholas JA, Smith GJ, et al. Reduction in hypoglyce - mia with the 
predictive low -glucose management system: a long - term randomized controlled trial in 
adolescents with típ 1 diabetes. Diabetes Care . 2018;41(2):303 -310.  
19. Fredheim S, Johansen A, Th orsen SU, et al. Nationwide reduction in the frequency of 
severe hypoglycemia by half. Acta Diabetol . 2015;52(3):591 -599.  
20. Phelan  H, Hanas  R, et al. ISPAD Clinical Practice Consensus Guidelines 2022: Sick 
day management in children and adolescents with dia betes. Pediatr Diabetes . 
2022;23:912 –925.  
21. Kapellen T, Juliana CA, Lizabeth M, et al. ISPAD Clinical Practice Consensus Guidelines 
2022: Management of children and adolescents with diabetes requiring surgery. Pediatric 
Diabetes.  2022;23(8):1468 –77.  
22. Jeffer ies C, Rhodes E, Rachmiel M, et al. ISPAD clinical practice consensus guidelines 
2018: Management of children and adolescents with diabetes requiring surgery. Pediatric 
Diabetes . 2018;19(27): 227 -236. 
23. Martin LD, Hoagland MA, Rhodes ET, et al. Perioperative  Management of Pediatric 
Patients with Típ 1 diabetes mellitus. Anesth Analg . 2020;130(4):821 -827.  
24. Mihaela SP, Nirja K, Yashendra S, et al. Típ I diabetes mellitus and autoimmune diseases: 
A critical review of the association and the application of person alized medicine. J.Pers.Med . 
2023; 13(3): 422.  
25. Aleksandra K & Iwona BS. Effect of associated autoimmune diseases on típ 1 diabetes 
mellitus incidence and metabolic control in children and aldolescents. Biomed Res int . 2016: 
6219730.  
26. Fröhlich -Reiterer E, Elbarbary NS, Simmons K et al. ISPAD Clinical Practice Consensus 
Guidelines 2022: Other complications and associated conditions in children and adolescents 
with típ 1 diabetes. Pediatr Diabetes . 2022;23:1451 –1467.  
27. Bjornstad P,  Dart A,  Donaghue KC, et al.  ISPAD Clinical Practice Consensus Guidelines 
2022: Microvascular and macrovascular complications in children and adolescents with 
diabetes.  Pediatr Diabetes . 2022;23(8):1432 -1450  62 
 
 28. Lindholm OA, DeAbreu M, Greene S, et al. ISPAD Clinical Practice Consensus 
Guidelines 2022: Diabetes education in children and adolescents. Pediatric Diabete s. 
2022;23:1229 -42.  
29. Wherrett DK, Ho J, Huot C, et al. Típ 1 Diabetes in Children and Adolescents. Can J 
Diabetes . 2018;42:234 –46. 
30. Wherrett DK, Ho J, Huot C,  et al. Típ 1 Diabe tes in Children and Adolescents. Can J 
Diabetes . 2018;42:S234 -S246.  
31. Anju V, Stuart J. Brink, Angela M, et al. ISPAD Clinical Practice Consensus Guidelines 
2022: Management of the child, adolescent, and young adult with diabetes in limited resource 
settings . Pediatric Diabetes. 2022;23(8):1529 -1551.  
32. Mayer -Davis EJ, Kahkoska AR, Jefferies C et al . ISPAD Clinical   Practice Consensus 
Guidelines 2018: Definition, epidemiology, and classification of diabetes in children and 
adolescents .  Pediatric diabetes  2018;  19(Supple 27):7 -19. 
33. Wolfsdorf JI, Glaser N, Agus M at el. ISPAD Clinical Practice Consensus Guidelines 
2018: Diabetic ketoacidosis and the hyperglycemic hyperosmolar state. Pediatric diabetes  
2018; 19(Supple 27): 155 -177. 
34. American Diabetes Associa tion Professional Practice Committee. 14. Children and 
adolescents: Standards of Care in Diabetes —2024. Diabetes Care 2024;47(Suppl. 1):S258 –
S281.  
35. American Diabetes Association  Professional Practice Committee. 2. Diagnosis and  
classification of diabete s: Standards of Care in  Diabetes —2024. Diabetes Care  
2024;47(Suppl. 1):  S20–S42. 
36. American Diabetes Association Professional Practice Committee. 6. Glycemic goals and 
hypoglycemia: Standards of Care in Diabetes — 2024. Diabetes Care  2024;47(Suppl. 
1):S11 1–S125  
37. Besser REJ, Bell KJ, Couper JJ et al. ISPAD Clinical Practice Consensus Guidelines 
2022: Stages of típ 1 diabetes in children and adolescents. Pediatr Diabetes . 2022; 23: 1175 -
1187.  
38. Quattrin T, Mastrandrea LD, Walker LSK. Típ 1 diabetes. Lancet 2023; 401: 2149 –62.  
39. Ogle GD, James S, Dana Dabelea D et al. Global estimates of incidence of típ 1 diabetes 
in children and adolescents: Results from the International Diabetes Federation Atlas, 10th 
edition. Diabetes Res Clin Pract . 2022 ;183:109 083. 
40. Ng SM, Malene IV, Rassavong MNK, Chi Dung Vu, et al. Closing the Típ 1 Diabetes 
gap in South -East Asia through government partnership working with non -government 
organisations. Diabetes Res Clin Pract . 2022. 187:109868  
41. Can Thi Bich Ngoc, Vu Ch i Dung, De Franco E, Bui Phuong Thao, Nguyen Ngoc Khanh, 
Tran Minh Dien et al. Genetic etiology of neonatal diabetes mellitus in Vietnamese infants 63 
 
 and characteristics of those with INS gene mutations. Frontiers in Endocrinology . 2022;13: 1-
9. 
42. Can Thi B ich Ngoc, Tran Minh Dien,  Bui Phuong Thao, Nguyen Ngoc Khanh, Vũ Chí 
Dũng et al. Molecular Genetics, Clinical Characteristics, and Treatment Outcomes of KATP -
Channel Neonatal  Diabetes Mellitus in Vietnam National Children’s Hospital. Frontiers in 
Endocrino logy. 2021;12:1 -9. 
43. Bô Y t ế. Hướng dẫn chẩn đoán và đi ều trị đái tháo đư ờng típ 2. Nhà xu ất bản Y h ọc. Hà 
Nội - 2021.  
44. Bùi Th ị Hương, Bùi Th ị Xuân, Đ ỗ Thị Mơ, Tr ần Th ị Thùy Linh,  
Đỗ Thị Hoa, Vũ Chí Dũng, C ấn Th ị Bích Ng ọc. Th ực trạng tuân th ủ điều trị bệnh đái tháo 
đường típ 1 ở trẻ em tại Bệnh vi ện Nhi Trung ương năm 2021. Tạp chí Y h ọc Việt Nam . 
2022. 511  (1): 84-88.  
45. Nguy ễn T. H. ., Vũ, C. D., Nguy ễn T. N., Đ ỗ, T. T. M., & Bùi, P. T. M ột số yếu tố ảnh 
hưởng đến kiểm soát glucose máu ở trẻ Đái tháo đư ờng típ 1.  Vietnam Journal of Diabetes 
and Endocrinology , 2022; (55).  27-33. 
46. Vũ Chí Dũng, Tr ần Quang Thanh. Đặc điểm lâm sàng, cận lâm sàng đái tháo đường typ 
1 ở trẻ em và vị thành niên. Tạp chí Y học Việt Nam . 2020; 495(1): 145 -148. 
47. Vũ Ch í Dũng, Tr ần Quang Thanh. M ột số yếu tố liên quan đ ến khởi phát, m ức độ nặng 
và kết quả điều trị nhiễm toan ceton do đái tháo đư ờng típ 1 ở trẻ em và v ị thành niên. Tạp 
chí Y h ọc Việt Nam . 2021. 5(1): 199-203. 
48. Bùi, P. T., Vũ, C. D., Nguy ễn T. N ., Nguy ễn T. H. ., & Đ ỗ, T. T. M. K ết quả kiểm soát 
glucose máu ở trẻ Đái tháo đư ờng týp 1 t ại Bệnh vi ện Nhi Trung Ương.  Vietnam Journal of 
Diabetes and Endocrinology , 2023. (55).  22-26. 
49. Cấn, T. B. N., & Vũ, C. D. Các kháng th ể kháng ti ểu đảo tụy ở trẻ em đá i tháo đư ờng m ới 
được chẩn đoán.  Vietnam Journal of Diabetes and Endocrinology . 2021; (42), 80 -86.

## ️ Chiến lược kiểm soát đường thở khó (ASA 2022)



# **Mở đầu**
Chiến lược kiểm soát đường thở khó của Hiệp hội Gây mê Hoa Kỳ (American Society of Anesthesiologists – ASA) bao gồm 2 con đường kiểm soát liên tục: đặt nội khí quản khi bệnh nhân tỉnh táo và tự thở (awake intubation) và đặt nội khí quản sau khi tiến hành gây mê. Hướng dẫn này được đưa ra nhằm mô tả chiến lược lựa chọn hỗ trợ các chuyên gia gây mê hồi sức đưa ra quyết định nhanh chóng và chính xác hơn.
Chiến lược kiểm soát đường thở là chiến lược có sự tích hợp giữa nhiều yếu tố: các yếu tố điều kiện/hoàn cảnh, yếu tố liên quan đến bệnh nhân, quy trình phẫu thuật đề nghị, thiết bị, kỹ năng và quan trọng nhất là kinh nghiệm của bác sĩ gây mê hồi sức.
Chúng tôi xin lược dịch những điểm quan trọng của hướng dẫn nhằm cập nhật thông tin thực hành lâm sàng đến quý độc giả.
**Bốn yếu tố cần cân nhắc để đưa ra quyết định và lên kế hoạch kiểm soát đường thở**
1. ** _Liệu bệnh nhân có nguy cơ gặp khó khan trong nội soi thanh quản hay đặt nội khí quản?_** Các xét nghiệm thường quy dùng để xác định nguy cơ gặp khó khăn trong nội soi thanh quản trực tiếp hoặc đặt nội khí quản thường có độ nhạy và độ đặc hiệu kém. Thực tế, có nhiều nghiên cứu đã được tiến hành trên vấn đề này, tuy nhiên kết quả vẫn chưa được thống nhất và chưa đưa ra được kết luận cuối cùng. Vì vậy, việc xác định bệnh nhân có nguy cơ gặp khó khăn trong nội soi thanh quản trực tiếp và đặt nội khí quản vẫn phụ thuộc rất lớn và kinh nghiệm của bác sĩ gây mê hồi sức.
Với quy trình đánh giá kỹ lưỡng và cẩn thận, những khó khăn không lường trước vẫn có thể xảy ra, chính vì vậy, ASA đưa ra khuyến cáo cho cả 2 tình huống. Vì vậy, mặc dù con đường kiểm soát đường thở sau khi tiến hành các thủ thuật gây mê đã được lựa chọn, các phép đo lường trên đường thở vẫn nên được đánh giá để xác định kỹ thuật và các biện pháp hồi sinh đường thở phù hợp trong trường hợp có những khó khăn không lường trước được xảy ra.
2. ** _Có thể dùng mặt nạ thở/dụng cụ kiểm soát đường thở trên thanh môn (supraglottic ventilation)?_** Nếu sau quá trình đánh giá, bác sĩ gây mê hồi sức đưa ra kết luận quy trình đặt nội khí quản có thể phức tạp đối với bệnh nhân, thì việc tiến hành kiểm soát đường thở sau quá trình gây mê có thể được tiến hành sau khi được đánh giá là an toàn và khả thi. Trong các trường hợp này, kiểm soát đường thở bằng mặt nạ thở hoặc các thiết bị kiểm soát đường thở trên thanh môn có thể được cân nhắc. Trong trường hợp mặt nạ thở và các thiết bị kiểm soát đường thở trên thanh môn không được đánh giá cao, có thể cân nhắc đặt nội khí quản khi bệnh nhân tỉnh táo và tự thở.
Bác sĩ gây mê hồi sức khi đã quyết định gây mê trong những tình huống này thường phải lường trước trước các tình huống không thể đặt nội khí quản hay không thể đặt máy thở xảy ra.
3. ** _Bệnh nhân có nguy cơ hít sặc?_**
Sau khi đã cân nhắc các vấn đề về việc đặt nội khí quản và sử dụng máy thở thì việc tiếp theo các bác sĩ gây mê hồi sức cần cân nhắc là đánh giá nguy cơ hít sặc dịch tiêu hóa của bệnh nhân.
  * Nếu kết quả đánh giá cho thấy bệnh nhân có nguy cơ hít sặc cao thì nên cân nhắc con đường đặt nội khí quản khi bệnh nhân tỉnh táo và tự thở.
  * Nếu kết quả đánh giá cho thấy bệnh nhân không có nguy cơ hít sặc, con đường kiểm soát đường thở sau khi tiến hành các kỹ thuật gây mê có thể phù hợp cho bệnh nhân.


4. ** _Liệu bệnh nhân có thể chịu đựng ngưng thở chu kỳ?_**
Cuối cùng, khi đưa ra chiến lược kiểm soát đường thở, bác sĩ gây mê hồi sức cần cân nhắc đến những ảnh hưởng của tình trạng ngưng thở chu kỳ. Trong trường hợp bệnh nhân gặp khó khăn khi thở máy không lường trước, liệu rằng bệnh nhân có thể chịu đựng được tình trạng ngưng thở cho đến khi vấn đề được giải quyết.
  * Dựa trên các đặc điểm sinh lý của bệnh nhân (chẳng hạn shunt sinh lý, phụ nữ mang thai và bệnh nhân béo phì có bệnh kèm), bác sĩ gây mê hồi sức cho rằng tình trạng ngưng thở chu kỳ có thể không an toàn đối với bệnh nhân, công với kết quả đánh giá nội soi thanh quản và đặt nội khí quản, chiến lược phù hợp nhất có thể là đặt nội khí quản khi bệnh nhân tỉnh táo và tự thở.
  * Những cân nhắc tương tự có thể được áp dụng cho cả bệnh nhân có thể không dung nạp hypnotic agent hoặc những thay đổi nhanh chóng với thông khí áp lực dương.


Ngoài ra, các yếu tố khác (không liên quan đến đường thở) cũng có thể gây ảnh hưởng đến quá trình đưa ra quyết định của bác sĩ gây mê hồi sức. Khả năng chịu đựng của bệnh nhân đối với biện pháp đặt nội khí quản khi bệnh nhân còn tỉnh táo và tự thở, bệnh nhân phải luôn được đảm bảo đường thở (chẳng hạn bệnh nhân chấn thương không ổn định) và các yếu tố khác. Vì vậy, mặc dù đặt nội khí quản khi bệnh nhân còn tỉnh táo và tự thở được xem là biện pháp thường được lựa chọn hơn, tuy nhiên các biện pháp gây mê có thể vẫn cần phải được thực hiện để hoàn thiện quá trình kiểm soát đường thở và có thể phải kết hợp với nhiều quá trình khác thay thế.
Điều quan trọng là các biện pháp đánh giá đường thở (đặt nội khí quản, thông khí, hít sặc và khả năng chịu đựng ngưng thở chu kỳ) vẫn được tiếp tục để xác nhận kế hoạch kiểm soát mặc dù những đánh giá này có thể thay đổi chiến lược kiểm soát đường thở.
Thất bại của chiến lược kiểm soát đường thở có thể dẫn đến việc phải áp dụng các biện pháp xâm lấn để hồi sinh đường thở. Trong hướng dẫn điều trị trước, ASA đã đưa ra khuyến cáo về việc đánh giá giải phẫu ngoại khoa cổ của bệnh nhân nên được cân nhắc như là một phần của quá trình đánh giá đường thở. Kết quả của việc áp dụng kỹ thuật xâm lấn để tiếp cận đường thở có thể gây ra nhiều biến chứng vì không đánh giá đủ và phù hợp vị trí xâm lấn, tổn thương dây thần kinh, xuất huyết, chấn thường thực quản và khí quản, dị tật về lâu dài và kể cả tử vong. Hít sặc dịch tiêu hóa cũng có là xem là hậu quả của đặt nội khí quản thất bại hoặc chậm trễ ở bệnh nhân có nguy cơ, điều này có thể dẫn đến việc bệnh nhân phải điều trị ở khoa chăm sóc tích cực ngoài ý muốn, kéo dài thời gian đặt nội khí quản, các biến chứng hô hấp về lâu dài và kể cả tử vong.
Mặc dù đặt nội khí quản khi bệnh nhân tỉnh và tự thở là biện pháp được xem là an toàn nhất khi bệnh nhân được nhận định có thể thất bại khi được kiểm soát đường thở sau khi được gây mê, mặc dù vậy, vẫn có những kết cục lâm sàng xấu xảy ra ở bệnh nhân được đặt nội khí quản khi còn tỉnh và tự thở. Biến chứng tổng cộng ở bệnh nhân được tiến hành đặt nội khí quản khi còn tỉnh và tự thở lên đến 18%, các biến chứng này có thể bao gồm giảm oxy huyết động mạch, tăng CO2 máu động mạch, nhịp tim nhanh, hạ huyết áp hoặc hít sặc. Các biến chứng này có thể do gây mê quá liều, ngộ độc thuốc gây mê tại chỗ, bệnh nhân đang sử dụng các thuốc điều trị tim mạch khác, co thắt thanh quản hoặc tắc nghẽn đường thở khác.
## **Kết luận**
Việc lựa chọn giữa đặt nội khí quản khi bệnh nhân còn tỉnh và tự thở với kiểm soát đường thở sau khi tiến hành gây mê là điểm chính của hướng dẫn kiểm soát đường thở khó của ASA 2022. Để hỗ trợ bác sĩ gây mê đưa ra quyết định phù hợp, các yếu tố cần phải cân nhắc đều là các yếu tố cơ bản của quá trình quyết định kiểm soát đường thở: bối cảnh lâm sàng, tiền sử của bệnh nhân, thăm khám lâm sàng, đánh giá khả năng thực hiện của việc đặt nội khí quản, khả năng thành công của mặt nạ thở hoặc dụng cụ kiểm soát đường thở trên thanh môn, nguy cơ hít sặc, khả năng chịu đựng ngưng thở chu kỳ của bệnh nhân và sự phối hợp của bệnh nhân. Những đánh giá này đều phụ thuộc vào kinh nghiệm, khả năng của bác sĩ gây mê hồi sức.
Hướng dẫn điều trị này cũng có thể hỗ trợ các bác sĩ gây mệ hồi sức và các bác sĩ lâm sàng hiểu rõ hơn quá trình đánh giá nguy cơ của việc kiểm soát đường thở từ đó giúp các bác sĩ gây mê hồi sức chuẩn bị tốt hơn cho việc kiểm soát đường thở ở bệnh nhân.
## **Nguồn**
  1. William H. Rosenblatt and N. David Yanez. A Decision Tree Approach to Airway Management Pathways in the 2022 Difficult Airway Algorithm of the American Society of Anesthesiologists. Airway management. 2022;134. [DOI: 10.1213/ANE.0000000000005930](https://pubmed.ncbi.nlm.nih.gov/35171880/)


**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh



## Hướng dẫn chẩn đoán và điều trị suy tim mạn tính

**[Hướng dẫn chẩn đoán và điều trị suy tim mạn tính](https://bvnguyentriphuong.com.vn/uploads/072022/files/QD%201762-Ban%20h%C3%A0nh%20H%20%20ng%20d%20n%20ch%20n%20%20o%C3%A1n%20v%C3%A0%20%20i%20u%20tr%20%20suy%20tim%20m%20n%20t%C3%ADnh\(1\).pdf)**

## Kỹ thuật đặt nội khí quản cấp cứu

**1. Giải phẫu đường hô hấp trên**
Đường hô hấp trên gồm hầu và các khoang mũi, nhưng vài tác giả cũng kể luôn cả thanh quản và khí quản. Hầu có thể chia thành mũi hầu, miệng hầu và thanh hầu.
Mũi gồm xương và sụn, nối vào sọ mặt. Mũi là cấu trúc hình tháp, vách ngăn mũi chia mũi thành hai khoang mũi. Các khoang mũi được lót bởi niêm mạc có chức năng làm ấm và ẩm khí hít vào. Các xoang cạnh mũi dẫn lưu vào khoang mũi. Phần sau của miệng mở thành miệng hầu. Khi bệnh nhân ở tư thế nằm ngửa và mất ý thức, lưỡi và hàm dưới có thể trượt ra sau gây tắc đường thở bên trong miệng hầu.
Hầu là một ống xơ-cơ hình chữ U trải từ sàn sọ tới sụn nhẫn. Hầu bị giới hạn phía trước và trên bởi khoang mũi, tiếp theo ở phía dưới là miệng, và sau đó là thanh quản. Những đường biên này chia hầu thành mũi hầu, miệng hầu và thanh hầu tương ứng.
Sụn nắp thanh quản bảo vệ lỗ mở vào thanh môn hay lối vào thanh môn. Sụn nắp thanh quản là cấu trúc bằng sụn đàn hồi được bao phủ bởi niêm mạc gắn vào phía trước và phía sau tới thanh quản.
Bên dưới lối vào thanh môn là thanh quản. Thanh quản được giới hạn bởi các nếp sụn phễu, đỉnh của sụn nắp thanh môn và mép sau của bờ dưới sụn nhẫn. Thanh quản phình ra phía sau tạo thành hầu thanh quản. Bên dưới sụn nhẫn là khí quản, được tạo nên bởi các vòng sụn có hình chữ U trải tới carina trước khi phân nhánh thành mỗi phế quản gốc mỗi bên
**2. Chỉ định đặt nội khí quản**
Lợi ích:
Đặt nội khí quản nhằm duy trì sự thông thoáng của đường thở, cung cấp oxy nồng độ cao, đảm bảo cung cấp các thể tích khí lưu thông được cài đặt trước theo các nhịp thở khi thông khí nhân tạo, tạo thuận lợi cho việc hút đàm nhớt, chất tiết và giúp ngăn ngừa hít sặc các chất tiết từ dạ dày, họng, miệng hay đường hô hấp trên, giúp cung cấp PEEP (áp lực dương cuối thì thở ra), cô lập phổi, và tạo ra đường dùng các thuốc trong hồi sức khi đường truyền tĩnh mạch hay trong xươngkhi không thể có liền.
Các chỉ định đặt nội khí quản gồm:
- Tắc nghẽn đường thở cấp tính do chấn thương, dị vật, bỏng đường hô hấp trên, nhiễm trùng, phù mạch, phù nề hay co thắt thanh quản, u thanh quản
- Mất các phản xạ bảo vệ đường thở do bệnh nhân rối loạn tri giác do chấn thương đầu, quá liều thuốc, tai biến mạch máu não hay nhiễm trùng hệ thần kinh trung ương
- Suy hô hấp giảm oxy máu, tăng CO2
- Ngừng hô hấp tuần hoàn
- Bệnh nhân chấn thương đầu, nên đặt nội khí quản ngay khi có 1 trong các tiêu chuẩn sau:
o GCS ≤ 8
o Mất các phản xạ bảo vệ đường thở
o Suy hô hấp
o Tăng thông khí tự phát
o Loạn nhịp thở như ngưng thở
Chỉ định đặt nội khí quản không phải làm ngay nhưng có thể cần thiết trước khi di chuyển bệnh nhân:
- Suy giảm mức độ ý thức đáng kể
- Gãy xương hàm cả 2 bên
- Chảy máu nhiều vào miệng hay khoang họng
- Co giật cơn lớn
**3. Kỹ thuật**
Quy trình:
(1) Chuẩn bị bệnh nhân:
- Cung cấp oxy trước đặt nội khí quản bằng cách dùng các nhịp thở bình thường (thể tích lưu thông) trong 3 phút hay hơn với FiO2 gần 1 hoặc 8 nhịp thở sâu (dung tích sống) trong 1,5 phút
- Lấy bỏ răng giả (nếu có)
- Lập đường truyền tĩnh mạch hay qua xương
- Chuẩn bị tư thế bệnh nhân
- Đánh giá khả năng đặt nội khí quản khó dựa trên giải phẫu của bệnh nhân.
(2) Chuẩn bị dụng cụ:
- Lắp cán đèn vào lưỡi đèn
- Kiểm tra tất cả các dụng cụ cần thiết: ống nội khí quản, que dẫn đường, bóng bóp giúp thở
- Chọn ống nội khí quản có kích thước phù hợp. Nhìn chung, ống nội khí quản có đường kính 8 mm là phù hợp cho bệnh nhân (người lớn) nam và 7 mm cho bệnh nhân (người lớn) n
- Chọn loại kích cỡ và lưỡi đèn (thẳng hay cong) phù hợp
- Kiểm tra bóng chèn
(3) Kỹ thuật đặt:
- Bôi trơn và cố định que dẫn đường bên trong ống nội khí quản
- Đặt đầu bệnh nhân ở tư thế trung tính, giữ thẳng trục cổ làm thẳng trục miệng-thanh quản-hầu họng
- Mở miệng bệnh nhân bằng cách dùng kỹ thuật “ngón cái và ngón trỏ”
- Đặt nhẹ nhàng lưỡi đèn vào phía bên phải của miệng bệnh nhân bằng tay trái, gạt lưỡi sang trái và nâng nắp thanh quản
- Quan sát thanh môn đang mở, các dây thanh
- Hút sạch chất tiết trong đường thở (nếu cần) bằng tay phải
- Đưa ống nội khí quản vào bằng tay phải và quan sát khi ống nội khí quản đi qua 2 dây thanh
- Bơm bóng chèn nội khí quản với khoảng 5-10 mL không khí
- Lấy lưỡi đèn ra khỏi miệng bệnh nhân
- Giữ ống nội khí quản bằng một tay và rút que dẫn đường bằng tay kia
- Đặt dụng cụ ngăn cắn
- Nối bóng giúp thở vào ống nội khí quản
- Bóp bóng giúp thở trong khi quan sát cử động lên xuống của lồng ngực
- Đánh giá vị trí chính xác của ống nội khí quản
- Cố định ống nội khí quản bằng dây vải
- Thông khí cho bệnh nhân và tiếp tục theo dõi tình trạng của bệnh nhân và vị trí của ống nội khí quản (bằng lâm sàng hay bằng các phương tiện khác .
- Nếu bệnh nhân đang được xoa bóp tim ngoài lồng ngực, cần phải giảm thiểu tới tối đa sự gián đoạn quá trình xoa bóp tim. Đưa lưỡi đèn vào và ống nội khí quản đã sẵn sàng trên tay ngay khi tạm ngưng xoa bóp tim. Gián đoạn quá trình xoa bóp tim chỉ để quan sát các dây thanh và đưa ống nội khí quản vào; lí tưởng là không quá 10 giây. Quay trở lại xoa bóp tim ngay khi ống nội khí quản đi qua giữa 2 dây thanh.
- Nếu không đặt được nội khí quản trong vòng 30 giây, hãy tiếp tục thông khí bằng bóp bóng qua mặt nạ với oxy 100% và cố gắng đặt lại trong 20-30 giây. Hãy giữ cho SpO2 của bệnh nhân luôn > 95% mọi lúc.
- Độ sâu thích hợp của ống nội khí quản là 23 cm tại cung răng hay khóe miệng đối với nam và 21-22 cm đối với nữ. Trên phim X quang, đầu ống nội khí quản nên ở vị trí từ 2-7 cm trên carina, tối ưu là 4-7 cm trên carina khi đầu và cổ ở vị trí trung tính.
- Bóng chèn: áp lực bóng chèn tối ưu trong khoảng từ 20-30 cmH2O
- Các dấu hiệu cho biết có khả năng đường thở khó:
o Khó ngửa cổ: viêm khớp, chấn thương hay mổ trước đó
o Bất thường về giải phẫu: miệng nhỏ, lưỡi lớn, cổ đầy, hàm dưới thụt ra sau, vòm khẩu cái cao, béo phì
o Miệng không mở lớn được
o Thở rít hay dấu hiệu khác của viêm hô hấp trên từ viêm thanh thiệt, bỏng hay nhiễm trùng thanh quản
o Chấn thương thanh quản hay khí quản
o Biến dạng bẩm sinh mặt, đầu và cổ
**4. Biến chứng**
Biến chứng liên quan tới đặt nội khí quản có thể chia thành 3 nhóm: (a) trong khi đặt nội khí quản, (b) tại vị trí đặt nội khí quản và (c) sau khi rút nội khí quản.
a. Trong khi đặt nội khí quản:
- Đặt nhầm nội khí quản vào thực quản: bệnh nhân không được thông khí và oxy hóa máu trừ khi còn các nhịp tự thở. Nếu không nhận ra đặt nội khí quản nhầm vào thực quản, bệnh nhân có thể bị tổn thương não vĩnh viễn hay tử vong.
- Gây chấn thương:
o Rách môi hay lưỡi do dùng lực quá mạnh giữa lưỡi đèn và lưỡi hay cằm bệnh nhân
o Gãy/bể răng
o Di lệch sụn phễu
o Rách hầu họng hay khí quản do đầu tận của ống nội khí quản hay que dẫn đường
o Tràn khí màng phổi
o Tổn thương 2 dây thanh: loét, mất chức năng
o Thủng thực quản-họng
o Ói và hít dịch dạ dày vào đường hô hấp dưới
o Tăng hoạt hệ thần kinh tự động gây giải phóng nhiều epinephrine và norepinephrine, gây tăng huyết áp (MAP 35 mmHg), nhịp nhanh (30 nhịp/phút) hay rối loạn nhịp
o Tụt huyết áp và nhịp chậm do kích thích phó giao cảm
o Tăng áp lực nội sọ
- Đặt ống nội khí quản quá sâu, vào trong phế quản gốc bên phải (thường nhất) hay bên trái là biến chứng thường gặp nhất.
Đặt sai vị trí nội khí quản có thể gây ra các hậu quả rất nghiêm trọng, có thể làm bệnh nhân tử vong. Do đó, chỉ nên thực hiện kỹ thuật này bởi một bác sĩ đã được huấn luyện kỹ về đặt nội khí quản. Tất cả các thành viên trong nhóm hồi sức phải hiểu về nội dung kỹ thuật đặt nội khí quản và các bước có liên quan để hỗ trợ khi thực hiện kỹ thuật này.
b. Các biến chứng tại chỗ đặt nội khí quản:
- Hít sặc
- Liệt dây thanh hay liệt dây thần kinh thoáng qua
- Loét và tạo u hạt trong khí quản và trên dây thanh
- Dính khí quản (tracheal synechiae)
- Hẹp hạ thanh môn
- Tạo màng thanh quản (laryngeal webbing)
- Nhuyễn khí quản
- Rò khí quản-thực quản, khí quản-động mạch vô danh, hay khí quản-động mạch cảnh
- Tổn thương thần kinh thanh quản trên và quặt ngược
c. Các biến chứng sau rút nội khí quản:
- Hẹp hạ thanh môn
- Tổn thương dây thanh
- Khàn tiếng
**5. Chăm sóc ống nội khí quản**
• Bóng chèn NKQ
− Áp lực 20-30 cmH2O
− Kiểm tra áp lực bóng chèn 2 lần/ngày
− Xả bóng chèn cho máu lưu thông, hút sạch đàm trước khi xả bóng
• Hút đàm
− Nhận biết dấu hiệu tắc ống, bán tắc
− Áp lực hút
− Tăng oxy 100% trước hút 2-3 phút mỗi lần hút
• Kiểm tra vị trí ống NKQ
− Thường ở vị trí 20-25 cm
− Kiểm tra trên X quang phổi
• Theo dõi SpO2
• Kiểm tra vị trí ống Mayor
• Cố định ống an toàn, chắc chắn, đổi bên để tránh đè cấn gây loét niêm mạc miệng
• Vệ sinh răng miệng 2 lần /ngày
• Theo dõi dấu hiệu sinh tồn chú ý nhịp thở
• Tư thế bệnh nhân: cổ thẳng không cúi gập hoặc ưỡn cổ
• Thay mũi giả, ống nối mỗi ngày
• Thay và kiểm tra catheter oxygen khi bệnh nhân thở oxy qua NKQ
• Rút ống nội khí quản :
− Thường rút vào buổi sáng
− Kiểm tra dấu sinh hiệu
− Chuẩn bị đầy đủ dụng cụ đặt lại NKQ khi cần
− Hút sạch đàm nhớt
− Xả xẹp bóng chèn hoàn toàn rồi mới rút
− Cho bệnh nhân thở oxy
− Đo lại dấu hiệu sinh tồn, theo dõi sát bệnh nhân (một số bệnh nhân bị dấu hiệu co thắt sau khi rút)

## Điều trị sốc tim

**1. ĐẠI CƯƠNG**
- Sốc tim là tình trạng giảm cung lượng tim không đáp ứng được nhu cầu oxy của các tổ chức trong cơ thể.
- Chẩn đoán sốc tim đặt ra sau khi đã loại trừ các sốc khác: sốc giảm thể tích, sốc phản vệ, sốc nhiễm khuẩn.
- Các rối loạn huyết động đặc trưng trong sốc tim:
+ Cung lượng tim giảm với chỉ số tim < 2,2 lít/phút/m2
+ Áp lực tĩnh mạch trung tâm cao ( > 10 mmHg) và áp lực mao mạch phổi bít cao ( > 15mmHg).
+ Chênh lệch oxy giữa máu mao mạch và máu tĩnh mạch cao (DA-VO2 lớn hơn
0,55ml O2/lít) do rối loạn trong sốc tim là do tổn thương chức năng tim không phải do rối loạn ở ngoại vi.
- Trong điều trị sốc tim: một mặt khẩn trương điều trị triệu chứng và hồi sức toàn diện, mặt khác cần tìm và giải quyết nguyên nhân sớm nếu có thể được.
- Suy tim trong bệnh cảnh sốc tim là vấn đề lâm sàng lớn bởi vì tỉ lệ tử vong cao lên tới 30 – 90%. Tiên lượng phụ thuộc nhiều vào nguyên nhân gây ra sốc tim và khả năng can thiệp của thầy thuốc.
- Đây là tình trạng cần được cấp cứu tại chỗ và vận chuyển bằng xe ôtô có trang thiết bị cấp cứu ban đầu đến khoa hồi sức.
**2. NGUYÊN NHÂN**
2.1. Giảm sức co bóp cơ tim
- Thiếu máu cục bộ cơ tim (đặc biệt là nhồi máu cơ tim cấp).
- Bệnh cơ tim do nhiễm khuẩn (liên cầu nhóm B, bệnh Chagas,…), nhiễm vi rút (enterovirus, adenovirus, HIV, vi rút viêm gan C, parvovirus B19, vi rút Herpes, EBV, CMV).
- Bệnh cơ tim do miễn dịch, do chuyển hóa.
- Bệnh cơ tim do nguyên nhân nội tiết: cường hoặc suy giáp.
- Bệnh cơ tim do ngộ độc.
- Giai đoạn cuối của bệnh cơ tim giãn hay bệnh van tim.
2.2. Tăng hậu gánh (nguyên nhân tắc nghẽn)
- Tắc động mạch phổi nặng.
- Hẹp động mạch chủ.66
2.3. Ép tim cấp do tràn dịch màng ngoài tim cấp
2.4. Tổn thương cơ học của tim
- Hở van động mạch chủ, hở van hai lá cấp.
- Thủng vách liên thất.
2.5. Rối loạn nhịp tim: cơn nhịp nhanh, đặc biệt là cơn nhịp nhanh thất hoặc nhịp quá chậm do bloc nhĩ thất.
**3. TRIỆU CHỨNG**
3.1. Triệu chứng lâm sàng
- Huyết áp tụt: huyết áp tối đa dưới 90mmHg hoặc giảm so với huyết áp nền trên 30mmHg (ở người cơ tăng huyết áp).
- Da lạnh tái, nổi vân tím trên da, đầu chi tím lạnh.
- Thiểu niệu hoặc vô niệu, nước tiểu < 0,5 ml/kg/giờ.
- Các dấu hiệu ứ trệ tuần hoàn ngoại vi (gan to, tĩnh mạch cổ nổi), xuất hiện ran ẩm ở phổi.
- Tiếng tim bất thường: tùy theo nguyên nhân gây ra sốc tim, nhịp tim nhanh, tiếng T1 mờ, xuất hiện T3, T4, tiếng ngựa phi nếu viêm cơ tim cấp do nhiễm độc, vi rút.
- Bệnh lý gây sốc tim (tùy theo nguyên nhân): ngộ độc, chuyển hóa, viêm cơ tim cấp, bệnh van tim cấp, rối loạn chức năng thất phải cấp tính.
- Thần kinh: ý thức của bệnh nhân giảm.
3.2. Cận lâm sàng
- Lactat máu tăng trên 1,5 mmol/l (phản ánh tình trạng thiếu oxy do giảm tưới máu tổ chức). Toan chuyển hóa và toan lactat khi lactat máu tăng kéo dài từ 2-4 mmol/l. Lactat máu trên 4 mmol/l trong các trường hợp nặng.
- Thăm dò huyết động: áp lực tĩnh mạch trung tâm tăng, áp lực mao mạch phổi bít tăng (trên 15mmHg), cung lượng tim giảm, chỉ số tim giảm dưới 2,2 lít/phút/m2
**4. CHẨN ĐOÁN**
4.1. Chẩn đoán xác định
a) Chẩn đoán lâm sàng dựa vào các tiêu chuẩn sau:
- Huyết áp tâm thu ≤ 90mmHg kéo dài hoặc phải sử dụng thuốc vận mạch để duy trì huyết áp tâm thu ≥ 90mmHg hoặc huyết áp tâm thu giảm trên 30mmHg so với huyết áp tâm thu nền của bệnh nhân.
- Có bằng chứng của giảm tưới máu các cơ quan (nước tiểu dưới 30ml/giờ hoặc chi lạnh/vã mồ hôi hoặc có biến đổi ý thức.
- Bằng chứng tăng áp lực đổ đầy thất trái (phù phổi)
b) Các thông số thăm dò huyết động:
- Chỉ số tim (CI) dưới 2,0 l/ph/m2 da khi không sử dụng trợ tim hoặc dưới 2,2 l/ph/m2 da khi có sử dụng thuốc trợ tim.67
4.2. Chẩn đoán phân biệt
Chẩn đoán phân biệt các tình trạng sốc dựa vào: tiền sử bệnh, các đặc điểm lâmsàng và cận lâm sàng.
a) Sốc nhiễm khuẩn
- Có tình trạng nhiễm khuẩn kèm theo phải có thời gian xuất hiện kéo dài.
- Áp lực tĩnh mạch trung tâm giảm, áp lực mao mạch phổi bít giảm.
- Chỉ số tim bình thường hoặc tăng.
- Sức cản mạch hệ thống và sức cản mạch phổi giảm.
b) Sốc giảm thể tích
- Hoàn cảnh xuất hiện nhanh: ỉa chảy, nôn nhiều, đái nhiều hoặc viêm tụy cấp nặng.
- Áp lực tĩnh mạch trung tâm giảm, áp lực mao mạch phổi bít giảm.
c) Sốc phản vệ
- Tình huống xuất hiện thường khá đột ngột liên quan đến thuốc hoặc thức ăn.
- Áp lực tĩnh mạch trung tâm giảm, áp lực mao mạch phổi bít giảm.
- Có thể có các dấu hiệu khác của dị ứng.như đỏ da, sẩn, ngứa …
4.3. Chẩn đoán nguyên nhân
a) Siêu âm tim: có thể đánh giá chức năng thất phải và thất trái và phát hiện nguyên nhân
- Hội chứng ép tim cấp.
- Rối loạn chức năng van hai lá.
- Thủng vách liên thất.
- Phình tách động mạch chủ đoạn gần.
- Rối loạn vận động vùng hoặc toàn bộ của thất phải, thất trái.
- Tăng áp lực động mạch phổi, đo các chênh áp qua các bệnh lý van tim cấp tính.
b) Điện tim: có thể có các biểu hiện của bệnh tim nguyên nhân
c) Xquang ngực:
- Hình ảnh của bệnh tim nguyên nhân.
- Hình ảnh tăng đậm các nhánh mạch phổi.
- Phình tách động mạch chủ.
- Tràn khí trung thất, tràn khí màng phổi áp lực.
d) Các xét nghiệm đặc hiệu khác tùy theo nguyên nhân gây sốc tim
- Men tim, troponin, BNP, LDH, AST tăng trong nhồi máu cơ tim.
- Chụp mạch phổi trong tắc mạch phổi,…
e) Các xét nghiệm phát hiện vi khuẩn hay virus gây viêm cơ tim cấp
- Soi hoặc cấy dịch/máu.
- PCR virus gây viêm cơ tim.
f) Thông tim đánh giá mạch vành68
- Đánh giá tưới máu mạch vành.
- Có biện pháp tái tưới máu sớm khi có chỉ định.
4.4. Chẩn đoán mức độ: Tiêu chuẩn của ACC/AHA 2007
a) Tiền sốc
- Áp lực mao mạch phổi bít trên 15mmHg.
- Huyết áp tâm thu trên 100mmHg.
- Chỉ số tim dưới 2,5l/ph/m2 da.
b) Sốc tim
- Áp lực mao mạch phổi bít trên 15mmHg.
- Huyết áp tâm thu dưới 90mmHg.
- Chỉ số tim dưới 2,5l/ph/m2 da.
c) Sốc tim điển hình
- Chỉ số tim dưới 2 l/ph/m2 da.
- Áp lực mao mạch phổi bít trên 20mmHg.
**5. XỬ TRÍ**
5.1. Nguyên tắc chung
- Giai đoạn sớm, hỗ trợ huyết động để phòng ngừa các rối loạn và suy chức năng cơ quan, thậm chí phải giải quyết nguyên nhân gây sốc tim như tái tưới máu sớm trong nhồi máu cơ tim cấp , tạo nhịp cấp cứu trong trường hợp nhịp chậm.
+ Hỗ trợ chức năng tim: Tim phổi nhân tạo tại giừơng ( ECMO), bơm bóng ngược dòng động mạch chủ hoặc thiết bị hỗ trợ thất trái.
+ Hồi sức cơ bản: điều chỉnh các rối loạn do sốc tim gây nên như suy hô hấp, suy thận...
- Giai đoạn giải quyết nguyên nhân nhanh chóng để đảo ngược tình trạng sốc tim.
5.2. Xử trí ban đầu và vận chuyển cấp cứu
- Nhanh chóng xác định tình trạng sốc tim của bệnh nhân, loại trừ các nguyên nhân khác gây ra huyết áp thấp.
- Giảm tối đa các gắng sức: giảm đau, giảm căng thẳng lo âu.
- Thiết lập đường truyền tĩnh mạch.
- Hỗ trợ thở oxy (nếu có).
- Làm điện tim, xác định chẩn đoán nhồi máu cơ tim cấp và xét chỉ định dùng thuốc tiêu sợi huyết nếu thời gian vận chuyển đến trung tâm can thiệp mạch gần nhất trên 3 giờ.
- Vận chuyển bệnh nhân đến các trung tâm cấp cứu và hồi sức gần nhất.
5.3. Xử trí tại bệnh viện
5.3.1. Hỗ trợ thông khí
- Oxy liệu pháp: hỗ trợ oxy nên được tiến hành ngay để tăng oxy vận chuyển và phòng ngừa tăng áp lực động mạch phổi.69
- Thông khí nhân tạo: ưu tiên thông khí nhân tạo xâm nhập khi bệnh nhân sốc tim với các lợi ích: nhu cầu oxy của cơ hô hấp và giảm hậu gánh thất trái, chỉ định gồm:
+ Bệnh nhân khó thở nhiều.
+ Giảm oxy máu.
+ pH < 7,30.
5.3.2. Hồi sức dịch
- Hồi sức dịch giúp cải thiện vi tuần hoàn và tăng cung lượng tim.
- Lượng dịch truyền đủ rất khó xác định ở bệnh nhân sốc tim:
+ Về lý thuyết, lượng dịch để cho cung lượng tim tăng theo tiền gánh.
+ Về thực hành, có nhiều phương pháp khác nhau bao gồm: theo dõi và điều chỉnh áp lực tĩnh mạch trung tâm, áp lực mao mạch phổi bít, bão hòa oxy tĩnh mạch trung âm và tĩnh mạch trộn; làm liệu pháp truyền dịch; theo dõi đáp ứng điều trị như lưu lượng nước tiểu, nồng độ lactat máu,...
- Lựa chọn dịch truyền:
+ Dịch muối đẳng trương là lựa chọn đầu tiên với ưu điểm dễ dung nạp và giá thành rẻ.
+ Các dung dịch keo cũng được sử dụng khi có thiếu lượng lớn dịch trong lòng mạch.
+ Dung dịch albumin cũng được sử dụng trong các trường hợp giảm albumin máu.
- Liệu pháp truyền dịch có thể nhắc lại khi nghi ngờ bệnh nhân thiếu dịch ở bệnh nhân sốc tim.
5.3.3. Thuốc vận mạch và trợ tim
- Dùng thuốc vận mạch để duy trì huyết áp tối đa trên 90mmhg (hoặc huyết áp trung bình trên 70mmHg). Ưu tiên dùng noradrenalin hơn dopamine vì khả năng ít gây rối loạn nhịp ở bệnh nhân sốc tim.
- Dobutamin được chỉ định trong các trường hợp sốc tim do tổn thương cơ tim.
+ Liều dùng: bắt đầu 5µg/kg/ph.
+ Tăng liều mỗi lần 2,5 – 5µg/kg/ph tùy theo đáp ứng của bệnh nhân.
+ Liều tối đa 20µg/kg/ph.
- Thuốc giãn mạch giúp làm giảm hậu gánh dẫn đến làm tăng cung lượng tim và cũng giúp cải thiện tưới máu vi tuần hoàn và chuyển hóa tế bào ở bệnh nhân sốc tim. Tuy nhiên, thuốc giãn mạch có thể làm tụt huyết áp và làm nặng tình trạng giảm tưới máu mô nên cần được theo dõi sát. Dẫn chất nitrates được chỉ định trong các trường hợp có thiếu máu cục bộ cơ tim (nhồi máu cơ tim, cơn đau thắt ngực không ổn định).
5.3.4. Các biện pháp hỗ trợ cơ học
- Tim phổi nhân tạo (ECMO – extracorporeal membrane oxygenation) chỉ làm được ở các đơn vị chuyên sâu và được đào tạo:
+ Để duy trì huyết động nhân tạo thay thế chức năng co bóp của cơ tim, tạo điều kiện cho cơ tim được nghỉ ngơi để hồi phục.
+ Chỉ định: sốc tim do bệnh lý cơ tim, ( EF < 35 % cần cân nhắc chỉ định), do tắc mạch phổi nặng hoặc do rối loạn dẫn truyền chưa hồi phục.
Biện pháp hỗ trợ tim phổi nhân tạo đạt hiệu quả cao trong các bệnh lí cơ tim có khả năng phục hồi sau giai đoạn sốc.
- Bơm bóng ngược dòng động mạch chủ (IABC – intraaortic balloon counterpulsation).
+ Để làm giảm hậu gánh và tăng tưới máu mạch vành.
+ Chỉ định trong sốc tim do bệnh lí cơ tim, tắc mạch phổi.
Các nghiên cứu gần đây cho thấy, biện pháp bơm bóng ngược dòng động mạch chủ không đạt hiệu quả rõ ràng ở bệnh nhân sốc tim.
5.3.5. Điều trị nguyên nhân cụ thể
a) Nhổi máu cơ tim
- Xét chỉ định tái tưới máu cơ tim (nong động mạch vành, đặt giá đỡ hoặc dùng thuốc tiêu sợi huyết hoặc phẫu thuật) sớm trong 6 giờ đầu khi nhồi máu cơ tim cấp gây sốc tim.
- Không dùng dẫn chất nitrat khi huyết áp thấp.
- Không chỉ định dùng thuốc nhóm ức chế bêta giao cảm.
b) Tắc động mạch phổi lớn
- Duy trì ổn định áp lực tĩnh mạch trung tâm.
- Dùng dobutamin và noradrenalin để năng huyết áp.
- Xét chỉ định và chống chỉ định dùng thuốc tiêu sợi huyết.
c) Ép tim cấp do tràn dịch màng ngoài tim
- Truyền dịch gây tăng áp lực tĩnh mạch trung tâm (tăng áp lực đổ đầy thất) nhằm chống lại áp lực ép vào từ màng ngoài tim.
- Điều trị quan trọng nhất là dẫn lưu dịch màng ngoài tim và điều trị nguyên nhân gây tràn dịch.
d) Sốc do tổn thương cơ học của tim: cần mổ cấp cứu để giải quyết tổn thương.
e) Sốc do loạn nhịp tim
- Điều trị loạn nhịp.
- Xem xét chỉ định sốc điện khi cơn nhịp nhanh gây nên tụt huyết áp.
- Nhịp chậm: chỉ định đặt máy tạo nhịp.
5.3.7. Một số biện pháp khác
- Kiểm soát tốt các rối loạn nhịp tim kèm theo (nếu có): sốc điện, đặt máy tạo nhịp tạm thời.
- Điều chỉnh các thăng bằng kiềm toan và các rối loạn điện giải (tăng/hạ kali,magie,…).
- Cho vitamin B1 nếu nghi ngờ viêm cơ tim do thiếu vitamin B1, corticoid nếu nghi ngờ tổn thương cơ tim do miễn dịch.
**6. TIÊN LƯỢNG VÀ BIẾN CHỨNG**
- Tỉ lệ tử vong trong bệnh viện khoảng 48 – 74%, các yếu tố tiên lượng tử vong: tuổi cao, tiền sử nhồi máu cơ tim trước đó, dấu hiệu lâm sàng khi được chẩn đoán (da lạnh ẩm), vô niệu.
- Biến chứng: suy đa tạng, sốc tim không hồi phục,..
**7. PHÒNG BỆNH**
Tái tưới máu mạch vành sớm và thích hợp cho vùng nhồi máu động mạch để bảo tổn tối đa cơ tim và giảm kích thước của vùng nhồi máu.
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh

## Quản lý chăm sóc tích cực người lớn bị nhiễm virus đường hô hấp nặng tại cộng đồng

Với việc sử dụng rộng rãi các xét nghiệm phân tử, mầm bệnh virus ngày càng được công nhận ở những bệnh nhân người lớn bị bệnh nghiêm trọng với bệnh hô hấp nặng mắc phải tại cộng đồng; Các nghiên cứu đã phát hiện nhiễm virus đường hô hấp (RVIs, respiratory viral infections) ở 17-53% bệnh nhân như vậy. Ngoài ra, các mầm bệnh mới bao gồm các coronavirus của động vật như các tác nhân gây ra Hội chứng hô hấp cấp tính nặng (SARS), Hội chứng hô hấp Trung Đông (MERS) và coronavirus mới 2019 (nCoV 2019) vẫn đang được xác định. Bệnh nhân bị RVI nặng cần được chăm sóc tại ICU thường bị suy hô hấp do thiếu oxy. Oseltamivir là chất ức chế neuraminidase được sử dụng rộng rãi nhất để điều trị cúm; dữ liệu cho thấy sử dụng sớm có liên quan đến việc giảm tỷ lệ tử vong ở những bệnh nhân bị cúm nặng.
Hiện tại, không có liệu pháp chống vi-rút nào về hiệu quả đã được chứng minh đối với các RVI nặng khác. Một số biện pháp can thiệp bằng thuốc bổ trợ đã được nghiên cứu về tác dụng điều hòa miễn dịch của chúng, bao gồm macrolide, corticosteroid, thuốc ức chế cyclooxygenase-2, sirolimus, statin, huyết tương miễn dịch chống cúm và vitamin C, nhưng hiện tại không được khuyến cáo sử dụng trong RVIs.
Chăm sóc hỗ trợ dựa trên bằng chứng là cơ sở chính để kiểm soát nhiễm virus đường hô hấp nặng. Thông khí không xâm lấn ở bệnh nhân RVI nặng gây suy hô hấp thiếu oxy cấp tính và viêm phổi có liên quan đến khả năng cao chuyển sang thở máy xâm lấn. Kiến thức hiện có hạn chế nhấn mạnh sự cần thiết của dữ liệu về chăm sóc hỗ trợ và liệu pháp dược lý bổ trợ dành riêng cho bệnh nhân bị bệnh nặng với RVI nặng. Cần có những thiết kế thực dụng và hiệu quả hơn để thử nghiệm các phương pháp trị liệu khác nhau cả riêng lẻ và kết hợp.
Toàn văn bài viết xin tham khảo [tại đây](https://drive.google.com/open?id=1k3RROPkSXlvyao-qLdN-OE7MpLy1_F-W)./.

## Lưu đồ và bảng kiểm quy trình tái thông trong điều trị nhồi máu não


## Hôn mê do tăng áp lực thẩm thấu trong đái tháo đường

**1. Cơ chế gây tăng áp lực thẩm thấu**
Hôn mê tăng áp lực thẩm thấu (TALTT) và nhiễm toan ceton là hai biến chứng cấp tính đe doạ đến tính mạng ở bệnh đái tháo đường.
Tình trạng thiếu hụt insulin gây tăng phân hủy glucogen tại gan, tăng tân tạo glucose, giảm sử dụng glucose của tổ chức, dẫn tới tăng nồng độ đường huyết.Tăng đường huyết sẽ gây tăng bài niệu do thẩm thấu, hậu quả là mất nước.
Tình trạng mất nước nhiều hơn mất muối sẽ làm TALTT máu. Khi áp lực thẩm
thấu tăng > 320 mOsm/kg, nước từ khoảng kẽ và trong tế bào trong đó có các tế bào thần kinh trung ương bị kéo vào trong lòng mạch gây ra tình trạng hôn mê và mất nước.
**2. Nguyên nhân**
Hôn mê TALTT gặp ở người bệnh đái tháo đường týp 2, kèm theo các tình trạng bệnh lý làm giảm khả năng uống nước. Các yếu tố nguy cơ bao gồm:
– Nhiễm khuẩn là nguyên nhân hay gặp nhất chiếm 57,1%. Phổ biến nhất là viêm phổi, nhiễm khuẩn tiết niệu, nhiễm khuẩn huyết.
– Bệnh đái tháo đường không được chẩn đoán, thường bị hôn mê tăng TALTT vì không phát hiện được các triệu chứng sớm của bệnh.
– Không tuân thủ chế độ điều trị tiểu đường (hay đái tháo đường).
– Các bệnh lý kèm theo: tai biến mạch não, nhồi máu cơ tim cấp, tăng hoặc giảm thân nhiệt, huyết khối mạc treo…
– Dùng thuốc lợi tiểu, corticoid, uống rượu.
**3. Chẩn đoán xác định**
Lâm Sàng và Cận Lâm Sàng
– Rối loạn ý thức các mức độ khác nhau từ lơ mơ đến hôn mê sâu.
– Dấu hiệu mất nước nặng: da khô, nếp véo da mất đi chậm, tĩnh mạch cổ xẹp,mạch nhanh, huyết áp tụt, nước tiểu ít …
– Các biểu hiện lâm sàng của các nguyên nhân thuận lợi: (nhiễm khuẩn, tai biến mạch não, nhồi máu cơ tim..).
– Tăng đường huyết thường > 40 mmol/l.
– Áp lực thẩm thấu máu > 320mOsm/l.
– Khí máu động mạch: pH > 7,3, bicarbonat > 15mmol/l.
– Không có ceton niệu hoặc rất ít.
– Natri máu thường tăng > 145mmol/l.
** Chẩn đoán phân biệt
– Nhiễm toan ceton do đái tháo đường và hôn mê tăng áp lực thẩm thấu
**Chẩn đoán nguyên nhân– yếu tố thuận lợi:
– Nhiễm khuẩn: viêm phổi, nhiễm khuẩn tiết niệu…
– Tai biến mạch não.
– Nhồi máu cơ tim.
– Sai lầm trong điều trị (dùng quá mức lợi tiểu, manitol, corticoid).
**4. Xử trí**
**Nguyên tắc xử trí
– Cấp cứu ban đầu A, B, C.
– Bù dịch nhanh và đủ.
– Điều chỉnh điện giải đồ.
– Dùng insulin kiểm soát đường máu.
– Chẩn đoán và điều trị nguyên nhân thuận lợi gây TALTT (viêm phổi, nhiễm khuẩn tiết niệu…).
**Xử trí ban đầu và vận chuyển cấp cứu
Đảm bảo hô hấp và tuần hoàn khi vận chuyển, đặt đường truyền dịch bù sớm nhanh tại chỗ và trên đường vận chuyển.
**Xử trí tại bệnh viện
a) Bù dịch
– Đặt ngay đường truyền tĩnh mạch lớn, sau đó đặt ống thông tĩnh mạch trung tâm để bù dịch (nếu có thể được).
– Bắt đầu truyền 1 lít natriclorua 0,9%0 trong 1 giờ, trong 2 giờ. Ước tính lượng nước thiếu khoảng 8- 10 lít.
– Trong quá trình bù dịch phải theo dõi sát mạch, huyết áp, độ bão hòa oxy,nước tiểu của người bệnh.
– Nếu có giảm thể tích nặng gây tụt huyết áp: truyền natriclorua 0,9% 1lít/ giờ cho đến khi hết tình trạng hạ huyết áp.
– Nếu mất nước nhẹ, tính natri hiệu chỉnh:
+ Na máu hiệu chỉnh = natri máu đo được + 1,6 mmol/l cho mỗi 5,6 mmol glucose tăng thêm trên 5,6 mmol/l.
+ Nồng độ natri bình thường hoặc tăng: truyền natriclorua 0,45% 250- 500ml/giờ tùy vào tình trạng mất nước. Khi glucose máu giảm xuống khoảng 15- 16 mmol/l, truyền thêm glucose 5% cùng với natriclorua 0,45%, tốc độ truyền 150 – 250ml/giờ.
+ Nồng độ natri giảm: truyền natriclorua 0,9% 250 – 500ml/giờ tùy vào tình trạng mất nước. Khi glucose máu khoảng 15 mmol/l truyền thêm glucose 5% với natriclorua 0,45% với tốc độ 150-250ml/giờ.
b) Insulin
– Theo dõi đường máu mao mạch 1 giờ/lần, trong 3 giờ đầu sau đó mỗi 3
giờ/lần để chỉnh liều insulin.
– Insulin 0,1đơn vị/kg tiêm tĩnh mạch sau đó truyền tĩnh mạch liên tục 0,1 đơn
vị/kg/giờ.
– Nếu glucose máu không giảm 3,0 mmol/l trong giờ đầu tiên có thể tăng gấp
đôi liều insulin.
– Khi glucose máu đạt khoảng 15- 16mmol/l, giảm insulin xuống còn 0,02 –
0,05 đơn vị/kg/giờ. Đảm bảo glucose máu 11- 15 mmol/l cho đến khi người bệnh tỉnh.
c) Bù Kali
– Theo dõi điện giải đồ 6 giờ/lần cho đến khi người bệnh ổn định.
– Nếu chức năng thận bình thường (nước tiểu ≥ 50ml/giờ).
– Nếu kali máu <3,5 mmol/l dùng insulin và truyền tĩnh mạch ( 1-2 gam/giờ) tương đương 20-30mmol kali/giờ cho đến khi nồng độ kali máu > 3,5 mmol/l.
– Nếu nồng độ kali ban đầu từ 3,5 – 5,3 mmol/l, bổ sung kali 20 – 30 mmol/l của dịch truyền tĩnh mạch để đảm bảo nồng độ kali máu duy trì từ 4 – 5mmol/l.
– Nếu nồng độ kali ban đầu > 5 mmol/l, không bù kali, kiểm tra kali máu mỗi 2
giờ. Khi người bệnh ổn định và có thể ăn được chuyển sang tiêm insulin dưới da. Tiếp tục truyền insulin tĩnh mạch 1-2 giờ sau khi tiêm insulin dưới da để đảm bảo đủ nồng độ insulin trong máu.
d) Điều trị nguyên nhân gây mất bù
– Kháng sinh nếu có bằng chứng về nhiễm khuẩn.
– Dùng thuốc dự phòng huyết khối tĩnh mạch sâu.
**5. Biến chứng và tiên lượng**
– Biến chứng do không điều trị đúng hôn mê tăng áp lực thẩm thấu là tắc mạch (tắc mạch mạc treo, nhồi máu cơ tim…) và tiêu cơ vân.
– Bù nước quá nhanh có thể dẫn đến suy hô hấp ở người lớn và phù não ở trẻ em, đây là biến chứng hiếm gặp nhưng có thể gây tử vong ở trẻ em.
+ Triệu chứng của phù não là đau đầu, thay đổi ý thức, hoặc là suy giảm ý thức đột ngột sau khi đã có cải thiện lúc đầu. Nhịp tim chậm, tăng huyết áp, phù gai thị.
+ Điều trị bằng manitol với liều 1-2g/kg truyền tĩnh mạch trong 30 phút và dexamethasone tiêm tĩnh mạch.
+ Điều chỉnh tình trạng tăng áp lực thẩm thấu một cách từ từ có thể tránh được biến chứng này ở trẻ em.
**6. Phòng bệnh**
– Người bệnh đái tháo đường phải được theo dõi diễn biến bệnh, sự thay đổi ý thức, kiểm tra đường máu một cách chặt chẽ và có hệ thống. Hướng dẫn chế độ ăn uống hợp lý, dùng insulin theo đúng chỉ định của thầy thuốc.
– Khám, phát hiện và điều trị các bệnh lý phối hợp như nhiễm trùng, bệnh lý tim mạch.

## Điều trị tăng áp lực nội sọ

1. ĐẠI CƯƠNG Tăng áp lực nội sọ (ALNS) có thể gây ra phù não, thiếu máu não, hoặc tụt não rất nhanh gây tử vong hoặc tổn thương không hồi phục, vì vậy cần phải được chẩn đoán sớm và xử trí tích cực. Ở người trưởng thành, thể tích hộp sọ khoảng 1500 ml gồm (tổ chức não chiếm 80%, máu chiếm 10%, dịch não tuỷ chiếm 10%. ALNS bình thường là10 mmHg, tăng ALNS khi áp lực bên trong hộp sọ lên trên 15 mmHg. Áp lực tưới máu não (ALTMN) lớn hơn 60 mmHg: theo công thức ALTMN = HATB – ALNS (HATB: huyết áp trung bình)
**2. NGUYÊN NHÂN** - Chấn thương sọ não. - Chảy máu não: trong nhu mô não, não thất, chảy máu dưới nhện. - Tắc nhánh lớn động mạch não: tắc động mạch cảnh trong, động mạch não giữa... - U não. - Nhiễm khuẩn thần kinh: viêm não, viêm màng não, áp xe não. - Não úng thủy. - Các nguyên nhân có khả năng gây tăng áp lực nội sọ khác:
+ Tăng CO2 máu; giảm oxy máu. + Thở máy có sử dụng PEEP cao (áp lực dương cuối thì thở ra). + Tăng thân nhiệt. + Hạ natri máu. + Tình trạng co giật.
**3. TRIỆU CHỨNG** 3.1. Lâm sàng Tuỳ vào người bệnh tỉnh hay mê mà có những diến biến bệnh khác nhau. a) Người bệnh tỉnh - Nhức đầu thường đau tăng dần lên, đau có thể lan toả hoặc khu trú. - Nôn: thường gặp trong các nguyên nhân ở hố sau. - Rối loạn thị giác: nhìn đôi, thoáng mờ, giảm thị lực, soi đáy mắt có phù gai. - Rối loạn thần kinh: ngủ gà, lờ đờ. b) Người bệnh hôn mê - Đang tỉnh đột ngột hôn mê, hoặc hôn mê sâu hơn. - Có biểu hiện tăng trương lực cơ. - Rối loạn thần kinh tự động (là dấu hiệu nặng):
+ Nhịp tim nhanh hoặc chậm, tăng huyết áp hoặc giảm huyết áp.139 + Rối loạn hô hấp: thở nhanh, sâu hoặc Cheyne-Stockes. + Rối loạn điều hoà thân nhiệt: sốt cao.
- Dấu hiệu tổn thương do tụt não:
+ Tụt thuỳ thái dương: liệt dây III, đồng tử giãn. + Tụt thuỳ hạnh nhân tiểu não: thở nhanh hoặc ngừng thở. + Tụt não trung tâm: biểu hiện tổn thương từ trên xuống dưới.
3.2. Cận lâm sàng - Xét nghiệm máu: có thể xác định nguyên nhân do hạ natri máu. - Chụp cắt lớp vi tinh (CT-scan) sọ não: có thể thấy
+ Phù não, cấu trúc não bị xô đẩy, cấu trúc đường giữa bị thay đổi. + Não thất giãn: do tắc nghẽn sự lưu thông của dịch não tuỷ. + Có thể thấy: chảy máu não, thiếu máu não, u não, áp xe não...
- Cộng hưởng tử (MRI) sọ não: cho biết rõ hơn về tổn thương não. - Chụp động mạch não: xác định được dị dạng mạch não. - Chọc dò tuỷ sống: khi nghi ngờ viêm màng não (chú ý để cho dịch não tuỷ chảy ra từ từ).
**4. CHẨN ĐOÁN** 4.1. Chẩn đoán xác định - Đau đầu ngày càng tăng. - Buồn nôn hoặc nôn. - Có thể có rối loạn ý thức kèm theo. - Soi đáy mắt: có phù gai thị giác. - CTscanner sọ não hoặc chụp cộng hưởng từ sọ não: có thể xác định được nguyên nhân gây TALNS. 4.2. Chẩn đoán phân biệt - Hôn mê: hôn mê tăng thẩm thấu, toan xeton, hạ đường máu, hôn mê gan... - Nhìn mờ: các bệnh lý thực thể ở mắt. - Đau đầu: các nguyên nhân do thần kinh ngoại biên, rối loạn vận mạch. _4.3. Chẩn đoán nguyên nhân_ - Chấn thương sọ não: CT scanner có thể thấy hình ảnh chảy máu não, tổn thương não do đụng dập, vỡ xương sọ. - Chảy máu não: CT scanner sọ não thấy hình ảnh chảy máu trong nhu mô não, não thất, chảy máu dưới nhện. - U não: CT scanner hoặc MRI sọ não cho thấy vị trí, kích thước, số lượng khối u. - Não úng thuỷ: CT scanner và MRI có hình ảnh não thất giãn to làm cho các rãnh cuộn não mất nếp nhăn. - Nhiễm khuẩn thần kinh: Xét nghiệm dịch não tủy: protein tăng kèm theo bạch cầu tăng (viêm màng não mủ). viêm màng não, áp xe não. Dịch não tủy bình thường trong viêm não....MRI có thể thấy hình ảnh viêm não, áp xe não. - Các nguyên nhân có khả năng gây tăng áp lực nội sọ khác:
+ Tăng CO2 máu; giảm oxy máu: xét nghiệm khí máu. + Thở máy có sử dụng PEEP (áp lực dương cuối thì thở ra). + Tăng thân nhiệt: nhiệt độ > 40oC, kéo dài liên tục. + Hạ natri máu: xét nghệm điện giải đồ cho thấy [Na+] máu < 130 mmol/l. + Tình trạng co giật: xét nghiệm sinh hóa máu có CK máu tăng cao.
**5. XỬ TRÍ** 5.1. Nguyên tắc xử trí - Cần theo dõi áp lực nội sọ liên tục để duy trì đủ áp lực tưới máu não. - Áp dụng các biện pháp làm giảm áp lực nội sọ . - Duy trì huyết áp của người bệnh cao hơn mức bình thường hoặc huyết áp nền để đảm bảo áp lực tưới máu não (Cranial Perfusion Pressure - CPP) từ 65-75 mmHg. - Duy trì áp lực thẩm thấu máu 295 to 305 mOsm/L. - Hạn chế tối đa các biến chứng do tăng áp lực nội sọ gây ra. - Loại bỏ nguyên nhân gây tăng áp lực sọ não. 5.2. Xử trí ban đầu và vận chuyển cấp cứu - Cho người bệnh nằm yên tĩnh nếu người bệnh tỉnh. - Đầu cao 30o - 45o nếu không có hạ huyết áp. - Cung cấp đủ oxy cho người bệnh: thở oxy kính. - Duy trì huyết áp cao hơn huyết áp nền của người bệnh.
+ Hạ huyết áp: truyền dịch NaCl 0,9 %. + Tăng huyết áp: dùng thuốc hạ huyết áp (chẹn kênh canxi, ức chế men chuyển).
- Chống phù não: glucocorticoid khi có u não.
+ Methylprednisolon: 40 - 120 mg tiêm tĩnh mạch, duy trì 40mg/6giờ. + Dexamethasone: 8 mg tiêm bắp hoặc tĩnh mạch, duy trì 4 mg/6giờ.
- Xử trí tăng thân nhiêt: paracetamol 0,5 gram bơm qua xông hoặc 1 gram truyền tĩnh mạch. - Vận chuyển khi huyết áp và hô hấp được đảm bảo. 5.3. Xử trí tại bệnh viện a) Nội khoa - Chung
+ Cho người bệnh nằm yên tĩnh nếu tỉnh. + Đầu cao 30o - 45o. + Điều chỉnh rối loạn nước điện giải. + Điều trị tăng thân nhiệt: paracetamol 0,5 gram bơm qua ống thông dạ dày hoặc 1 gram truyền tĩnh mạch. + Kháng sinh: khi có dấu hiệu nhiễm khuẩn thần kinh cần phải sử dụng kháng sinh càng sớm càng tốt, lựa chọn kháng sinh dễ thấm màng não, phải đủ liều lượng, vi khuẩn còn nhậy cảm với kháng sinh đó, thường dùng 2 loại kháng sinh kết hợp, thuốc truyền tĩnh mạch, điều chỉnh liều theo mức lọc cầu thận. Cephalosporin thế hệ 3: ceftazidime 2g/ 8 giờ, cefotaxime 2g/ 4-6 giờ, ceftriaxone 2g/ 12 giờ... Cephalosporin thế hệ 4: cefepime 2g/ 8 giờ. Nhóm carbapenem: meropenem 2g/ 8 giờ. Chloramphenicol: 4g/ 6 giờ. Vancomycin 30-60 mg/kg/ngày chia 2-3lần. Thường kết hợp với 1 trong các kháng sinh trên (khi chưa có kháng sinh đồ).
- Hồi sức bảo hô hấp: cung cấp đủ oxy cho người bệnh
+ Người bệnh tỉnh: thở oxy kính. + Người bệnh hôn mê, rối loạn hô hấp cần phải đặt nội khí quản và thở máy (tránh sử dụng PEEP hoặc dùng PEEP thấp 5 cm H2O), duy trì PaCO2 từ 35 - 45 mmHg.
- Hồi sức tuần hoàn * Cần chú ý: duy trì huyết áp cao hơn bình thường hoặc huyết áp nền (HATT 140-180 mmHg, HATTr <120 mmHg) để đảm bảo áp lực tưới máu não (CPP: 65-75 mmHg).
+ Nếu người bệnh có hạ huyết áp: cần đặt ống thông tĩnh mạch trung tâm 3 lòng. Truyền đủ dịch: dựa vào ALTMTT, không truyền glucosa 5% và NaCl 0,45% vì làm tăng áp lực nội sọ do phù não tăng lên. HA vẫn không đạt được yêu cầu: sử dụng dopamine truyền tĩnh mạch.
+Điều trị tăng huyết áp khi: HATT > 180 mmHg và/hoặc HATTr > 120 mmHg kèm theo suy thận. Nếu HATT > 230 mmHg và/hoặc HATTr> 140 mmHg: nitroprussid truyền TM: 0,1 - 0,5 µg/kg/ph, tối đa 10 µg/kg/phút. Hoặc nicardipine truyền TM: 5 -15mg/giờ. Nếu HATT 180 - 230 mmHg và/hoặc HATTr 105 - 140 mmHg: uống chẹn β (labetalol) nếu nhịp tim không chậm < 60 lần/phút. Nếu HATT < 180 mmHg và/hoặc HATTr< 105 mmHg: uống chẹn β (nếu nhịp tim không chậm < 60 lần /phút. Hoặc ức chế men chuyển: enalaprin 10mg/viên; peridopril 5mg/viên. Lợi tiểu furosemid tiêm tĩnh mạch nếu thuốc hạ HA không kết quả.
- Chống phù não: giữ áp lực thẩm thấu máu 295 - 305 mOsm/L.
+ Manitol chỉ dùng khi có phù não: 0,5 - 1g/kg/6giờ truyền tĩnh mạch trong 30 phút; không dùng quá 3 ngày. + Dung dịch muối ưu trương 7,5 - 10% 100 ml/lần có tác dụng giảm nhanh áp lực nội sọ, thời gian tái phát tăng áp lực nội sọ muộn hơn so với manitol 20%, cho kết quả tốt ở người bệnh bị chấn thương sọ não. Thời gian dùng không quá 3 ngày. + Thuốc an thần truyền tĩnh mạch Thuốc: phenobacbital hoặc thiopental (100mg/giờ), propofol (5 - 80 μg/kg/phút). Tác dụng với liều gây mê: giảm phù não, giảm nhu cầu sử dụng oxy ở não, chống co giật. Tác dụng phụ: hôn mê sâu hơn, hạ huyết áp. Cần theo dõi sát ý thức và huyết áp. + Glucocorticoid: chỉ định trong u não, áp xe não.Không dùng khi có tăng huyết áp.Thuốc: Synacthen 1mg tiêm bắp/ngày (tác dụng tốt trong u não). Methylprednisolon: 40 - 120 mg tiêm tĩnh mạch, duy trì40mg/6giờ.Dexamethasone: 8 mg tiêm bắp hoặc tĩnh mạch, duy trì 4 mg/6giờ.
b) Ngoại khoa: khi biết rõ nguyên nhân, điều trị nội khoa không kết quả. - Não úng thuỷ: mổ dẫn lưu não thất. - Khối máu tụ lớn: lấy khối máu tụ, giải quyết chảy máu do vỡ dị dạng. - U não:
+ Khối u to: mổ láy khối u (thường khó khăn). + Khối u nhỏ ≤ 2 cm: xạ trị với tia Gama
- Áp xe não: sau khi đã điều trị nội khoa ổn định, áp xe khu trú lại. - Chấn thương sọ não có đụng dập não nhiều: mổ bỏ một phần xương sọ vùng đập dập ra ngoài để giảm áp lực nội sọ. c) Theo dõi áp lực nội sọ - Qua não thất: thông qua hệ thống dẫn lưu não thất. - Trong nhu mô não: đầu nhận cảm áp lực được đặt vào trong nhu mô não qua một lỗ khoan nhỏ ở xương sọ và được nối với máy theo dõi liên tục. - Dưới màng nhện: đầu nhận cảm áp lực được đặt vào khoang dưới nhện qua một lỗ khoan nhỏ ở xương sọ và được nối với máy theo dõi liên tục. - Ngoài màng cứng: đầu nhận cảm áp lực được đặt vào khoang ngoài màng cứng qua một lỗ khoan nhỏ ở xương sọ và được nối với máy theo dõi liên tục.
**6. TIÊN LƯỢNG VÀ BIẾN CHỨNG** 6.1. Tiên lượng Tăng áp lực nội sọ kéo dài sẽ có tổn thương não khó hồi phục, tiên lượng xấu. Ở người bệnh hôn mê do chấn thương sọ não cho thấy thời gian tăng áp lực nội sọ càng kéo dài liên quan đến tiên lượng càng xấu. 6.2. Biến chứng Tăng áp lực nội sọ nếu không được xử trí kịp thời sẽ tạo ra vòng xoắn bệnh lý làm cho áp lực nội sọ ngày càng tăng có thể dẫn đến co giật, đột quỵ…tổn thương não không hồi phục.. Tụt não là biến chứng nặng, có thể làm cho người bệnh tử vong nhanh chóng.
**7. PHÒNG BỆNH** Khi có dấu hiệu của đau đầu, nhìn mờ không rõ nguyên nhân cần phải chụp cắt lớp sọ não để loại trừ nguyên nhân tăng áp lực nội sọ. Khi có tăng áp lực nội sọ, người bệnh cần phải được theo dõi sát và xử trí nguyên nhân gây ra tăng áp lực nội sọ.
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh

## Tài liệu chuyên môn 'Hướng dẫn chẩn đoán và điều trị bệnh phổi tắc nghẽn mạn tính'

**DOWNLOAD FIlE**
- Quyết định " Vv ban hành tài liệu chuyên môn HƯỚNG DẪN CHẨN ĐOÁN VÀ ĐIỀU TRỊ BỆNH PHỔI TẮC NGHẼN MẠN TÍNH" [Tải file tại đây](https://drive.google.com/open?id=1pvCtzn3eRWIPx4feIc_JTwNYvXDWxvKs) - Tài liệu "HƯỚNG DẪN CHẨN ĐOÁN VÀ ĐIỀU TRỊ BỆNH PHỔI TẮC NGHẼN MẠN TÍNH" [Tải file tại đây](http://kcb.vn/wp-content/uploads/2018/07/B%E1%BB%99-Y-t%E1%BA%BF-H%C6%B0%E1%BB%9Bng-d%E1%BA%ABn-ch%E1%BA%A9n-%C4%91o%C3%A1n-v%C3%A0-%C4%91i%E1%BB%81u-tr%E1%BB%8B-BPTNMT-b%E1%BA%A3n-c%E1%BA%ADp-nh%E1%BA%ADt-2018.pdf)
#### Nội dung trong file:

Lỗi khi xử lý file http://kcb.vn/wp-content/uploads/2018/07/B%E1%BB%99-Y-t%E1%BA%BF-H%C6%B0%E1%BB%9Bng-d%E1%BA%ABn-ch%E1%BA%A9n-%C4%91o%C3%A1n-v%C3%A0-%C4%91i%E1%BB%81u-tr%E1%BB%8B-BPTNMT-b%E1%BA%A3n-c%E1%BA%ADp-nh%E1%BA%ADt-2018.pdf: EOF marker not found

## Sốc nhiễm khuẩn

**1. ĐẠI CƯƠNG** Sốc nhiễm khuẩn là giai đoạn nặng của quá trình diễn biến liên tục bắt đầu từ đáp ứng viêm hệ thống do nhiễm khuẩn, nhiễm khuẩn nặng, sốc nhiễm khuẩn và suy đa tạng. Tỷ lệ do sốc nhiễm khuẩn chiếm từ 40 đến 60%. Vi khuẩn xâm nhập vào cơ thể gây ra các đáp ứng viêm hệ thống làm giải phóng các cytokin gây viêm, có sự mất cân bằng giữa yếu tố gây viêm và yếu tố kháng viêm (yếu tố kháng viêm yếu hơn yếu tố gây viêm) dẫn đến gây tổn thương cơ quan thứ phát và tạo nên vòng xoắn suy đa tạng.
**2. NGUYÊN NHÂN** Do vi khuẩn hoặc nấm từ các ổ nhiễm khuẩn xâm nhập vào máu từ:
- Da, mô mềm, cơ xương khớp. - Đường tiêu hóa như: viêm ruột, nhiễm khuẩn đường mật, áp xe gan. - Đường hô hấp: viêm phổi, áp xe phổi, viêm phế quản, viêm mủ màng phổi... - Hệ tiết niệu như: viêm mủ bể thận, ứ mủ bể thận ... - Hệ thần kinh: viêm màng não mủ, áp xe não ... - Một số nhiễm khuẩn khác : như viêm nội tâm mạc cấp và bán cấp ..**.**
**3. TRIỆU CHỨNG** 3.1. Lâm sàng - Dấu hiệu lâm sàng của đáp ứng viêm hệ thống như: xác định khi có từ 2 tiêu chuẩn sau đây trở lên. + Sốt > 38oC hay hạ thân nhiệt < 36oC. + Nhịp nhanh > 90 ck/phút. + Thở nhanh, tần số > 20 lần/phút. + Tăng số lượng bạch cầu trên trên 10000/ml, hoặc giảm số lượng bạch cầu<4000/ml, hoặc số lượng bạch cầu non > 10%. - Các biểu hiện của nhiễm khuẩn nặng: + Hội chứng đáp ứng viêm hệ thống. + Có ổ nhiễm khuẩn. + Rối loạn chức năng cơ quan như tăng lactat máu ≥ 2 hoặc thiểu niệu (thể tích nước tiểu < 0,5 ml/kg/giờ). - Dấu hiệu suy chức năng cơ quan: + Thận: thiểu niệu; số lượng nước tiểu giảm dần và < 0,5 ml/kg/giờ hoặc vô niệu. + Huyết áp: tụt hạ huyết áp liên quan đến nhiễm khuẩn nặng là HATT < 90 mmHg, hay HATB < 70 mmHg, hay HATT giảm > 40 mmHg so với trị số bình thường. 3.2. Cận lâm sàng - Các xét nghiệm cận lâm sàng xác định nhiễm khuẩn như: + Số lượng bạch cầu tăng (trên 10000/ml), tăng tỉ lệ đa nhân trung tính tăng cao trên giá trị bình thường, hoặc tỉ lệ bạch cầu non > 10%. + Máu lắng tăng. + CRP tăng trên 0,5 mg/dl. + Procalcitonin tăng > 0,125 ng/ml. - Xét nghiệm vi sinh xác định căn nguyên gây nhiễm khuẩn: cấy máu mọc vi khuẩn, virus, kí sinh trùng, nấm. - Giảm tưới máu tổ chức: tăng lac tát máu (≥ 2 mmol/L). - Dấu hiệu cận lâm sàng của rối loạn, suy chức năng cơ quan như: + Suy thận: tăng ure và creatinin. + Suy hô hấp: tỉ lệ PaO2/FiO2< 300, trường hợp nặng tỉ lệ này < 200. + Suy gan: tăng ALT, AST, bilirubin máu, giảm tỉ lệ prothrombin máu ... + Giảm số lượng tiểu cầu, rối loạn đông máu, đông máu nội mạch rải rác... + Nhiễm toan chuyển hóa, tăng kali máu, tăng đường máu.
**4. CHẨN ĐOÁN** 4.1. Chẩn đoán xác định khi có đủ các tiêu chuẩn sau - Các biểu hiện của nhiễm khuẩn nặng. - Rối loạn chức năng cơ quan tiến triển thành suy chức năng cơ quan không đáp ứng với bù dịch và phải dùng thuốc vận mạch. 4.2. Chẩn đoán phân biệt - Sốc giảm thể tích: mất nước hoặc mất máu, áp lực tĩnh mạch trung tâm thấp, sốc đáp ứng tốt với bù dịch hoặc máu. - Sốc tim do nhiều nguyên nhân; từ màng ngoài tim, cơ tim với nhiều tác nhân như chèn ép tim cấp, viêm cơ tim, nhồi máu cơ tim..., với đặc trưng cung lượng tim giảm nhiều. - Sốc phản vệ: thường liên quan đến các dị nguyên với các biểu hiện quá mẫn. 4.3. Chẩn đoán nguyên nhân - Tiến hành khám lâm sàng toàn diện các cơ quan để xác định ổ nhiễm khuẩn. - Phối hợp các biện pháp chẩn đoán hình ảnh như siêu âm, chụp x quang, chụp cắt lớp vi tính... - Cấy các bệnh phẩm nghi ngờ của nhiễm khuẩn như; mủ, chất tiết đờm dãi, dịch, mủ màng phổi, màng tim, dịch não tủy, máu và nước tiểu hay mủ hoặc dịch dẫn lưu ổ áp xe .... 4.4. Chẩn đoán mức độ - Có tiến triển suy đa tạng là yếu tố tiên lượng nặng. - Lactat máu tăng dần và tụt huyết áp không đáp ứng với thuốc vận mạch là biểu hiện nặng của sốc.
**5. XỬ TRÍ** 5.1. Nguyên tắc xử trí Nhanh chóng, tích cực và mục tiêu cần đạt trong vòng 6 giờ đầu: - Duy trì áp lực tĩnh mạch trung tâm (ALTMTT): 11 - 16 cmH2O - Duy trì huyết áp trung bình ≥ 65 mmHg. - Duy trì ScvO2 ≥ 70% hoặc SvO2 ≥ 65%. - Thế tích nước tiểu ≥ 0,5 ml/kg/giờ. 5.2. Xử trí ban đầu và vận chuyển cấp cứu Đảm bảo hô hấp và tuần hoàn để duy trì tính mạng cho người bệnh bằng các biện pháp: - Làm nghiệm pháp truyền dịch: truyền 1000 - 2000 ml dung dịch natriclorua 0,9% hoặc ringerlactat trong vòng 1 đến 2 giờ đầu ở những người bệnh tụt huyết áp do nhiễm khuẩn đảm bảo huyết áp trung bình ≥ 65 mmHg. - Đảm bảo hô hấp cho người bệnh bằng các biện pháp oxy liệu pháp (thở oxy kính, mặt nạ đơn giản, mặt nạ có túi hít lại), thở hệ thống áp lực dương liên tục (CPAP) có kết nối oxy hỗ trợ sao cho duy trì được SpO2 ≥ 92%. - Sử dụng thuốc vận mạch (nếu cần) như noradrenalin hoặc adrenalin đưỡng truyền tĩnh mạch liên tục liều khởi đầu 0,05 mcg/kg/phút để đảm bảo huyết áp khi đã đánh giá tụt huyết áp của người bệnh không do thiếu dịch. 5.3. Xử trí tại bệnh viện a) Bồi phụ thể tích dịch - Truyền dịch sớm và nhanh ngay khi có tụt huyết áp nhằm mục đích bù đủ thể tích dịch lòng mạch, tuy nhiên cũng tránh gây phù phổi cấp huyết động do thừa dịch. Bù 1000 ml dịch tinh thể (natri clorua 0,9% hoặc ringer lactat) hoặc 500 ml dung dịch cao phân tử gelatin trong 30 phút, sau đó chỉnh theo đáp ứng và đánh giá lâm sàng. - Làm nghiệm pháp truyền dịch cho đến khi đạt mức áp lực tĩnh mạch trung tâm mong muốn, duy trì áp lực trung tâm 8-12 cmH2O, nếu người bệnh đang thở máy, duy trì CVP 12 – 15 cmH2O. - Loại dịch: dịch tinh thể NaCl 0,9%, hoặc ringerlactat, nếu đã truyền nhiều dung dịch tinh thể nên truyền thêm dung dịch keo gelatin hoặc albumin để hạn chế thoát mạch. - Đường truyền: nếu là đường ngoại vi phải đủ lớn hoặc đặt 2-3 đường truyền, nên đặt ống thông tĩnh mạch trung tâm để bù dịch. b) Dùng vận mạch - Chỉ sử dụng thuốc vận mạch khi đã đánh giá đã bù đủ dịch. - Noradrenalin là thuốc sử dụng đầu tay với liều khởi đầu 0,05 µg/kg/phút, tăng dẫn liều 0,05mcg/kg/phút mỗi 5 – 10 phút đạt huyết áp trung bình ≥ 65 mmHg. - Có thể sử dụng dopamin nếu không có nhịp nhanh hoặc loạn nhịp hoặc adrenalin với liều dopamin khởi đầu 5 mcg/kg/giờ tăng dần 3-5 µg/kg/giờ mỗi 5-10 phút đến khi đạt HA đích, tối đa không tăng quá 20 µg/kg/giờ, với adrenalin bắt đầu liều 0,05 µg/kg/giờ, tăng dần 0,05 – 0,1 µg/kg/phút đến khi đạt HA đích, tối đa không tăng quá 5 µg/kg/giờ. - Thuốc tăng co bóp cơ tim: dobutamin không sử dụng thường quy cho các người bệnh nhiễm khuẩn nặng và sốc nhiễm khuẩn, chỉ sử dụng cho người bệnh có rối loạn chức năng thất trái thông qua đánh giá siêu âm tim hoặc ống thông động mạch phổi. Trường hợp có chỉ định, dùng dobutamin với liều khởi đầu 3 µg/kg/phút sau đó theo dõi và tăng dần mỗi lần 5 µg/kg/phút, không vượt quá 20 µg/kg/phút. c) Chẩn đoán căn nguyên nhiễm khuẩn và dùng kháng sinh - Áp dụng các biện pháp lâm sàng kết hợp xét nghiệm vi sinh và chẩn đoán hình ảnh để xác định ổ nhiễm khuẩn và cấy máu trước khi dùng kháng sinh. - Giải quyết ổ nhiễm khuẩn bằng chọc hút, dẫn lưu hoặc phẫu thuật dẫn lưu nếu có chỉ định trên cơ sở cân nhắc giữa lợi ích và nguy cơ cho bệnh nhân. - Dùng kháng sinh đường tĩnh mạch càng sớm càng tôt, tốt nhất trong giờ đầu ngay sau khi có chẩn đoán nhiễm khuẩn, lưu ý dùng kháng sinh sau khi đã cấy máu. - Dùng kháng sinh phổ rộng theo liệu pháp kháng sinh kinh nghiệm và xuống thang trên cơ sở dựa theo các dữ liệu nhạy cảm và đề kháng kháng sinh ở mỗi đơn vị hoặc xem tham khảo sử dụng kháng sinh trong nhiễm khuẩn nặng và sốc nhiễm khuẩn của Bộ Y tế. Sau khi có kết quả vi khuẩn và độ nhạy cảm cần lựa chọn kháng sinh nhạy cảm có phổ hẹp và ngấm tốt vào mô cơ quan bị nhiễm khuẩn. - Phối hợp kháng sinh trong các trường hợp: + Nếu người bệnh có giảm bạch cầu phải phối hợp kháng sinh phủ tối đa phổ nhiễm khuẩn (vi khuẩn gram âm, gram dương hay vi khuẩn nội bào ...). + Nếu nghi ngờ nhiễm trực khuẩn mủ xanh, Acinetobacte baumanni cần phối hợp với các kháng sinh nhạy cảm với trực khuẩn mủ xanh (Carbapenem kết hợp Colistin). + Nếu nghi ngờ do cầu khuẩn đường ruột phối hợp thêm kháng sinh có nhạy cảm với cầu khuẩn đường ruột như: vancomycine, cubicin... - Lưu ý ở các người bệnh có suy thận, liều kháng sinh phải dựa vào độ thanh thải creatinin, liều đầu tiên dùng như bình thường không cần chỉnh liều, chỉ chỉnh liều từ các liều sau. d) Dùng corticoide - Chỉ dùng khi sốc kém đáp ứng với vận mạch hoặc chưa cắt được vận mạch sau 48 giờ (không dùng thường quy) với thuốc được lựa chọn hydrocortison liều 50 mg mỗi 6 giờ tiêm tĩnh mạch. Giảm liều và ngừng khi người bệnh thoát sốc và cắt được thuốc co mạch. - Lưu ý có thể làm nhiễm khuẩn tiến triển nặng hơn nếu liệu pháp kháng sinh kinh nghiệm không phù hợp và gây tăng đường máu. e) Kiểm soát đường máu Kiểm soát đường máu mao mạch bằng insulin qua đường tiêm bắp ngắt quãng hoặc đường truyền tĩnh mạch, nếu đường máu mao mạch ≥ 11 mmol/l, mục tiêu duy trì đường máu từ 7 - 9 mmol/l. f) Điều trị dự phòng các biến chứng - Dự phòng huyết khối tĩnh mạch bằng một trong hai biện pháp sau: + Heparin trọng lượng phân tử thấp như Enoxaparin 1 mg/kg tiêm dưới da, giảm liều khi người bệnh có suy thận hoặc fraxiparin. + Sử dụng bao thay đổi áp lực định kỳ 2 tay và 2 chân. Thời gian dự phòng cho đến khi bệnh nhân hết các yếu tố nguy cơ. - Xuất huyết tiêu hóa: dùng thuốc băng niêm mạc dạ dày như sucalfate 2 gói/ngày chia 2 uống hoặc bơm qua dạ dày ... hoặc các thuốc ức chế bơm proton như omeprazole liều 20 mg uống hoặc tiêm tĩnh mạch/ngày, pantoprazole, esomeprazole liều 20-40mg uống hoặc tiêm tĩnh mạch, hoặc các thuốc kháng H2 như ranitidin ..., lưu ý đường dùng trong từng trường hợp cụ thể và tương tác thuốc. Thời gian sử dụng khi hết các yếu tố nguy cơ và bệnh đã ăn lại theo đường miệng. g) Thở máy - Mục tiêu: SpO2> 92% hoặc PaO2> 60 mmHg và pH > 7,15. - Các biện pháp: + Thở máy không xâm nhập với CPAP hoặc BiPAP nếu người bệnh tỉnh và hợp tác (xem bài thở máy không xâm nhập). + Thở máy xâm nhập có sử dụng PEEP (nếu không có chống chỉ định dùng PEEP) khi thở máy không xâm nhập thất bại hoặc người bệnh không hợp tác (xem kỹ thuật thở máy cho người bệnhARDS). h) Lọc máu liên tục - Lọc máu liên tục sớm nhất nếu có thể ngay sau khi có chẩn đoán sốc nhiễm khuẩn và lưu ý phải kiểm soát được ổ nhiễm khuẩn. - Chỉ lọc máu khi đã nâng được huyết áp tâm thu > 90 mmHg. - Ngừng lọc máu liên tục khi cắt được các thuốc co mạch ít nhất 12 giờ và huyết áp ổn định và chuyển lọc máu ngắt quãng nếu còn chỉ định. i) Hướng dẫn truyền máu và các chế phẩm máu - Không truyền plasma tươi đông lạnh để điều chỉnh các bất thường trên xét nghiệm khi không có nguy cơ chảy máu trên lâm sàng cũng như không có kế hoạch làm thủ thuật. - Chỉ truyền khối hồng cầu khi hemoglobin < 7g/l ở các bệnh nhân trẻ, với các bệnh nhân có nguy cơ giảm oxy máu như cao tuổi, nhồi máu cơ tim, đột quỵ não ... nên duy trì nồng độ hemoglobin 7 – 9 g/l. - Truyền khối tiểu cầu (KTC) khi số lượng tiểu cầu (SLTC) < 10.000/ml ngay khi lâm sàng không có nguy cơ chảy máu. Truyền KTC khi SLTC < 20000/ml kết hợp 78 có nguy cơ chảy máu trên lâm sàng. Đưa SLTC lên trên 50000/ml nếu có kế hoạch làm thủ thuật hoặc phẫu thuật.
**6. TIÊN LƯỢNG VÀ BIẾN CHỨNG** Tiên lượng sốc nhiễm khuẩn diễn biến nặng khi có một trong hai yếu tố sau: - Tiến triển suy đa tạng. - Lactat tăng dần và tụt huyết áp không đáp ứng với thuốc vận mạch.
**7. PHÒNG BỆNH** Phát hiện và xử trí sớm các nhiễm khuẩn.
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh

