## ️ Các phương pháp xác định mật độ xương

  * [Chẩn đoán bằng cách đo mật độ xương – BMD](https://bvnguyentriphuong.com.vn/co-xuong-khop/cac-phuong-phap-xac-dinh-mat-do-xuong#chn-on-bng-cch-o-mt-xng-bmd)
  * [Mối liên quan giữa mật độ xương với loãng xương và nguy cơ gãy xương](https://bvnguyentriphuong.com.vn/co-xuong-khop/cac-phuong-phap-xac-dinh-mat-do-xuong#mi-lin-quan-gia-mt-xng-vi-long-xng-v-nguy-c-gy-xng)
  * [Vấn đề đo lặp lại để theo dõi điều trị](https://bvnguyentriphuong.com.vn/co-xuong-khop/cac-phuong-phap-xac-dinh-mat-do-xuong#vn-o-lp-li-theo-di-iu-tr)
  * [Chỉ định đo mật độ xương](https://bvnguyentriphuong.com.vn/co-xuong-khop/cac-phuong-phap-xac-dinh-mat-do-xuong#ch-nh-o-mt-xng)
  * [Các phương pháp đánh giá nguy cơ loãng xương dựa vào chỉ số OSTA](https://bvnguyentriphuong.com.vn/co-xuong-khop/cac-phuong-phap-xac-dinh-mat-do-xuong#cc-phng-php-nh-gi-nguy-c-long-xng-da-vo-ch-s-osta)
  * [Phương pháp DEXA](https://bvnguyentriphuong.com.vn/co-xuong-khop/cac-phuong-phap-xac-dinh-mat-do-xuong#phng-php-dexa)
  * [Phương pháp đo mật độ xương bằng siêu âm](https://bvnguyentriphuong.com.vn/co-xuong-khop/cac-phuong-phap-xac-dinh-mat-do-xuong#phng-php-o-mt-xng-bng-siu-m)


Hiện nay, việc phát hiện những người loãng xương hoặc có nguy cơ loãng xương đang được thực hiện rộng rãi nhờ các máy móc thăm dó khối lượng xương.
Từ năm 2002, các hội nghị quốc tế về loãng xương đã thống nhất quan điểm về giá trị của các loại máy đo mật độ xương: máy đo mật độ xương dùng siêu âm chỉ có giá trị sàng lọc, chỉ có máy sử dụng tia X năng lượng kép, được gọi là DEXA (Dual – Energy X – ray Absorptionmetry) mới chẩn đoán.
## **Chẩn đoán bằng cách đo mật độ xương – BMD**
Sử dụng tiêu chuẩn của WHO dựa vào mật độ xương (BMD – Bonne Mineral Density) tính theo T – score để chẩn đoán loãng xương. T – score cuả một cá thể đó so với BMD của nhóm người trẻ tuổi làm chuẩn.
  * Loãng xương: T – socre dưới -2,5 (BMD dưới ngưỡng cố định là -2,5 độ lệch chuẩn so với giá trị trung bình của người trưởng thành trẻ tuổi, tại bất kì vị trí nào của xương).
  * Loãng xương nặng: T – score dưới -2,5 và có một hoặc nhiều gãy xương.


Thiểu xương (osteopenia): T – score trong khoảng từ -1 đến -2,5.
## **Mối liên quan giữa mật độ xương với loãng xương và nguy cơ gãy xương**
Như một quy tắc, nguy cơ gãy xương cuả bệnh nhân tăng lên gấp đôi với mỗi một độ lệch chuẩn dưới ngưỡng tham khảo của người trưởng thành khỏe mạnh.
Ví dụ: nếu bệnh nhân có chỉ số T –score là -2 SD, có nghĩa là người này có nguy cơ gãy xương cao gấp 4 lần so với phụ nữ trẻ có mật độ xương đỉnh.
Trên những đối tượng có mật độ xương thấp, nguy cơ gãy xương đốt sống tăng lên gấp 2 -3 lần. Tỉ lệ này tăng lên đến 5 lần trên các đối tượng bị loãng xương.
## **Vấn đề đo lặp lại để theo dõi điều trị**
Vấn đề theo dõi mật độ xương còn nhiều tranh cãi. Một số bác sĩ khuyên nên đo lại mật độ xương sau 1 -2 năm. Nhìn chung tần số của đo mật độ xương là một lần trong 2 năm. Hội Y khoa Mĩ cho rằng để theo dõi kết quả điều trị hay dự phòng loãng xương thì đo nhắc lại mất độ xương là không cần thiết do:
  * Sự thay đổi mật độ xương do điều trị chậm đến mức nhỏ hơn cả sai số kĩ thuật của máy. Nói cách khác, đôi khi khoogn thể phân biệt được sự tăng mật độ xương thực sự do điều trị với sự thay đổi kết qủa đo của máy.
  * Trong khi mục tiêu thực sự của điều trị loãng xương là giảm gãy xương trong tương lai, thì lại không có sự tương quan rõ rệt giữa tăng mật độ xương với sự giảm nguy cơ gãy xương do điều trị. Ví dụ alendronat đã được chứng minh làm giảm nguy cơ gãy xương xuống 50%, nhưng chỉ làm tăng chút ít mật độ xương.
  * Đo mật độ xương trong quá trình điều trị không giúp các bác sĩ lập kế hoạch hay thay đổi mật điều trị. Ví dụ thậm chí nếu mật độ xương tiếp tục xấu đi trong điều trị, thì vẫn chưa có nghiên cứu chứng tỏ thay đổi thuốc, hoặc tăng liều thuốc có thể làm giảm nguy cơ gãy xương trong tương lai.
  * Các kết quả nghiên cứu mới đây cho thấy, phụ nữ mất mật độ xương trong năm đầu điều trị hormon thay thế sẽ lấy lại mật độ xương trong hai năm tiếp theo, còn những phụ nữ tăng mật độ xương trong năm đầu điều trị có khuynh hướng mất mật độ xương trong hai năm về sau. Như vậy, mật độ xương thay đổi tự nhiên và điều đó không liên quan đến khả năng bảo vệ gãy xương của thuốc.


## **Chỉ định đo mật độ xương**
Đo nật độ xương hàng loạt cho phụ nữ và/ hoặc phụ nữ sau mãn kinh không có triệu chứng là không cần thiết. Những đối tượng cần đo mật độ xương là:
  * Tất cả những phụ nữ sau mãn kinh, dưới 65 tuổi, có nguy cơ loãng xương (tức là người đã từng bị gãy xương trước đó, gầy, hút thuốc lá, tiền sử gia đình có người bị gãy xương do loãng xương).
  * Tất cả phụ nữ trên 65 tuổi, dù có hay không có các yếu tố nguy cơ kể trên.


Những người đang hoặc sẽ phải dùng glucocorticoid kéo dài (> 3 tháng), với liều lớn hơn 7,5 mg prednison/ ngày.
  * Phụ nữ sau mãn kinh bị gãy xương.
  * Phụ nữ sử dụng hormon thay thế trong tời gian dài.
  * Mãn kinh hay đã cắt buồng trứng trước 40 tuổi.
  * Những người có bất thường cột sống. Phát hiện trên X quang xẹp đốt sống không do các nguyên nhân khác (chấn thương hay u).
  * Phụ nữ mãn kinh có tiền sử bệnh lí có thể gây loãng xương thứ phát (suy sinh dục kéo dài, cường giáp tiến triển không được điều trị, cường vỏ thượng thận và cường giáp tiên phát).


## **Các phương pháp đánh giá nguy cơ loãng xương dựa vào chỉ số OSTA**
Tại các cơ sở không có máy đo mật độ xương, có thể đánh giá nhanh, sơ bộ nguy cơ loãng xương nhờ vào các dụng cụ xác định chỉ số OSTA (Osteoporosis Self – Assessment Tool for Asians Index). Các nước trong khu vực (Philippin, Thái Lan…) đã sử dụng chỉ số này. Một số nước Âu, Mĩ cũng đã sử dụng và có một số nghiên cứu khẳng định tính hiệu quả của chỉ số này đối với người bản xứ. Việt Nam chưa có nghiên cứu đối với người Việt, tuy nhiên do các tương đồng đối với các chủng tộc của người châu Á, có thể sử dụng chỉ số này như một phương pháp bổ trợ.
### **Phương pháp DEXA**
DEXA (Dual Energy X-ray Absorptiometry) là phương pháp đo mật độ xương được sử dụng rộng rãi nhất trên thế giới. Xét nghiệm này chỉ cần liều chiếu tia X ít hơn là chụp X quang phổi. Độ chính xác của phương pháp cao, từ 85% đến 99%.
**Nguyên tắc:** máy DEXA
trên hai khu vực chính là háng và cột sống. Do loãng xương ảnh hưởng đến tất cả cơ thể, đo mật độ xương ở một vị trí có thể dự báo được gãy xương ở các vị trí khác. Tuy nhiên cũng cần phải quan sát trực tiếp. Ví dụ đo mật độ xương háng cho phép dự báo tốt nguy cơ gãy xương háng so với đo mật độ xương ở các vị trí khác. Nhìn chung quét DXA được thực hiện ở háng, bao gồm một khu vực ở xương đùi gọi là tam giácWard (Wards triangle) và đốt sống. Quá trình quét thường mất từ 10 – 20 phút.
Được phép chẩn đoán loãng xương nguyên phát khi có triệu chứng âm tính quan trọng sau:
  * Toàn thân: bình thường (không gầy sút, không có rối loạn nội tiết hoặc các cơ quan khác)
  * X quang: không có các vùng hủy xương của thân đốt sống. Khe đĩa đệm không bị hẹp. Các cung sau hầu như bình thường.
  * Xét nghiệm: hội chứng viêm âm tính (tốc độ lắng máu, protein phản ứng C, điện di protein máu…) và bilan phospho – calci (calci máu, niệu, phosphatase kiềm…) phải bình thường.


### **Phương pháp đo mật độ xương bằng siêu âm**
Siêu âm là một phương pháp đo mật độ xương tương đối mới. Phương pháp này không đòi hỏi có nguồn phóng xạ.
**Nguyên tắc:** chùm tia siêu âm hướng trực tiếp vào vùng sẽ đo. Sự hấp thụ sóng âm cho phép đánh giá mật độ xương. Kết quả không chính xác bằng các phương pháp khác. Xương gót, vị trí xương ngoại vi duy nhất để đánh giá nguy cơ gãy xương. Xương gót là xương bè có chu chuyển xương cao. Đó là xương dễ nghiên cứu, bao gồm 75 – 90% xương bè, một mô xương xốp, đáp ứng tốt với các thay đổi của tuổi tác, bệnh tật và điều trị.
Bộ phận biến âm của máy phát và nhận sóng siêu âm đi qua xương gót. Từ các tín hiệu nhận được, máy đưa ra ba thông số siêu âm: tốc độ lan truyền âm SOS ( Speed Of Sound – SOS) và mức độ giảm diêu âm dải rộng BUA (Broadband Ultrasound Attentuation – BUA) và chỉ số định lượng siêu âm Stiffnesss, là sự kết hợp của SOS và BUA. Hệ thống phần mềm của máy sẽ tự động tính mật độ xương từ giá trị QUI này.
Do đo mật độ xương ở vị trí ngoại vi (gót chân), kỹ thuật này không nhạy bằng DEXA vì kết quả đo ở gót chân vẫn có thể bình thường trong khi các vị trí trung tâm như háng và cột sống đã bất thường một cách đáng kể. Thêm nữa, thay đổi mật độ xuwowgn ở gót chân chậm hơn so với háng và cột sống do vậy, đo mật độ xương bằng siêu âm không được sử dụng để theo dõi đáp ứng điều trị của bệnh nhân.
Xem thêm: [**Đo loãng xương bằng phương pháp Dexa, Dxa**](https://bvnguyentriphuong.com.vn/co-xuong-khop/do-loang-xuong-bang-phuong-phap-dexa-dxa)
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [Chẩn đoán bằng cách đo mật độ xương – BMD](https://bvnguyentriphuong.com.vn/co-xuong-khop/cac-phuong-phap-xac-dinh-mat-do-xuong#chn-on-bng-cch-o-mt-xng-bmd)
  * [Mối liên quan giữa mật độ xương với loãng xương và nguy cơ gãy xương](https://bvnguyentriphuong.com.vn/co-xuong-khop/cac-phuong-phap-xac-dinh-mat-do-xuong#mi-lin-quan-gia-mt-xng-vi-long-xng-v-nguy-c-gy-xng)
  * [Vấn đề đo lặp lại để theo dõi điều trị](https://bvnguyentriphuong.com.vn/co-xuong-khop/cac-phuong-phap-xac-dinh-mat-do-xuong#vn-o-lp-li-theo-di-iu-tr)
  * [Chỉ định đo mật độ xương](https://bvnguyentriphuong.com.vn/co-xuong-khop/cac-phuong-phap-xac-dinh-mat-do-xuong#ch-nh-o-mt-xng)
  * [Các phương pháp đánh giá nguy cơ loãng xương dựa vào chỉ số OSTA](https://bvnguyentriphuong.com.vn/co-xuong-khop/cac-phuong-phap-xac-dinh-mat-do-xuong#cc-phng-php-nh-gi-nguy-c-long-xng-da-vo-ch-s-osta)
  * [Phương pháp DEXA](https://bvnguyentriphuong.com.vn/co-xuong-khop/cac-phuong-phap-xac-dinh-mat-do-xuong#phng-php-dexa)
  * [Phương pháp đo mật độ xương bằng siêu âm](https://bvnguyentriphuong.com.vn/co-xuong-khop/cac-phuong-phap-xac-dinh-mat-do-xuong#phng-php-o-mt-xng-bng-siu-m)



## ️ Tư thế điện học của tim

**KHÁI NIỆM**
Tư thế giải phẫu của tim trong lồng ngực là một yếu tố quan trọng ảnh hưởng lên các sóng điện tim. Tư thế điện học của tim nói lên tư thế giải phẫu của tim. Thông thường, trục điện tim trùng với trục giải phẫu của tim. Khi có bệnh lý làm thay đổi giải phẫu của tim sẽ làm thay đổi các sóng điện tim và trục điện tim bị lệch đi.
Tư thế điện học của tim và trục điện tim là hai yếu tố đồng hành, bổ sung cho nhau giúp cho chẩn đoán định đoán được tư thế giải phẫu của tim nhờ đó xác định chính xác hơn bệnh lý của tim. Do đó, sau khi tính trục điện tim, người ta sẽ xác định luôn tư thế tim.
Tuy nhiên, ở một số trường hợp tư thế điện tim có thể không chính xác do các sóng điện bị đảo lộn, như trong dày thất, bloc nhánh và trong nhồi máu cơ tim. Ở những trường hợp này chúng ta không cần xác định tư thế điện học của tim.
**PHÂN LOẠI**
Người ta xác định ba trục của tim gồm:
Trục trước – sau.
Trục dọc .
Trục ngang.
Khi tim dịch chuyển, dựa vào ba trục này để người ta định hướng xoay của tim.
**_Hình D1.1._**_**Vị trí tim trong lồng ngực và ba trục tim**_
**Vị trí điện học và giải phẫu của tim**
Tim bình thường, vị trí trung gian, thất phải chiếm hầu hết mặt trước, thất trái nằm bên trái và chủ yếu ở phía sau tim. Trục tim đi từ đáy tim đến mỏm tim, hướng từ sau ra trước, xuống dưới và qua trái. 
Dựa vào ba trục sau để xác định vị trí giải phẫu của tim.
**Trục trước – sau (Long axis of Body)**
Trục thẳng đứng dọc theo cơ thể (trục cơ thể) đi qua tâm của tim. 
Khi mỏm tim xoay theo chiều kim đồng hồ, hướng xuống dưới, tim sẽ ở tư thế thẳng đứng. 
Khi mỏm tim xoay ngược chiều kim đồng hồ, hướng lên trên, tim sẽ nằm ngang.
**Trục dọc (Long axis of Heart)**
Trục đi từ giữa đáy tim đến mỏm tim. Tim xoay quanh trục này. 
Khi xoay theo chiều kim đồng hồ, thất phải sẽ xoay ra mặt trước và thất trái chuyển ra sau, xuống dưới. 
Ngược lại, khi xoay ngược chiều kim đồng hồ, thất trái sẽ chiếm phần lớn mặt trước của tim.
**Trục ngang (Horizontal axis)**
Hướng từ phải sang trái, ngang qua trung tâm khối cơ tim. Tim xoay trên mặt phẳng ngang. Tim quay ra trước, nghĩa là mỏm tim sẽ hơi xoay về phía trước và đáy tim ra sau và ngược lại. 
Dựa vào hướng xoay theo trục trước - sau và trục dọc, người ta thường chia ra 6 loại tư thế điện tim như sau: 
Tư thế trung gian.
Tư thế nằm ngang.
Tư thế nửa nằm.
Tư thế đứng thẳng.
Tư thế nửa đứng. 
Tư thế vô định.
**_Ngoài ra, khi tim xoay xung quanh trục ngang sinh ra_**
Tư thế mỏm tim ra sau. 
Tư thế mỏm tim ra trước.
**NHẬN DẠNG TƯ THẾ ĐIỆN HỌC CỦA TIM**
**Tư thế trung gian (intermediate position)**
Bình thường, tim nằm nghiêng trong lồng ngực hướng từ sau ra trước, từ tên xuống dưới và từ phải qua trái với trục dọc tạo một góc 30°. Người ta gọi đó là tư thế trung gian.
Các chuyển đạo aVL và aVF đều nhận điện thế từ thất trái nên đều dương tính với dạng Rs hay qR. Các phức bộ QRS của V5, V6 giống aVL và aVF. 
Góc α khoảng +30°.
**Hình D1.2. Tim ở tư thế trung gian**
**Tư thế nằm ngang (horizontal position)**
Tim xoay ngược kim đồng hồ (counter-clockwise rotation) quanh trục của nó so với tư thế trung gian. aVL nhận được điện thế thất trái nên dương tính và có dạng R hay qR, còn aVF thì lại nhận điện thế của thất phải nên âm tính và có dạng rS. 
Hình ảnh QI SIII: DI có Q sâu hơn S, còn DIII có S sâu hơn Q. Chuyển đạo chuyển tiếp chuyển phải tức là về phía V1, V2.
Các phức bộ QRS của V5, V6 giống aVL, DI; V1, V2 giống aVF, DIII. Góc α khoảng -30°.
**Tư thế nửa nằm ngang**
Khi tim xoay theo tư thế nằm nhưng chỉ mới nửa chừng. Các phức bộ QRS của aVL, DI dương giống V5, V6; còn aVF thì có biên độ thấp hoặc gần bằng 0.
Góc α khoảng 0°.
**Tư thế đứng thẳng (vertical position)**
Mỏm tim hướng xuống dưới. Tim đã xoay theo kim đồng hồ theo trục trước – sau làm trục điện tim xoay mạnh sang phải. Đồng thời tim cũng xoay thuận chiều kim đồng hồ theo trục dọc của nó. 
aVF dương và có dạng qR. Ngược lại, aVL âm và có dạng rS. Có hình ảnh SI QIII: DI có S sâu hơn Q, còn DIII có Q sâu hơn S. Vùng chuyển tiếp chuyển trái (V5, V6).
Góc α khoảng 90°. 
**_Hình D1.3._**_**Tư thế nằm đứng: tim xoay thuận chiều kim đồng hồ**_
**Tư thế nửa đứng**
Khi tim xoay theo tư thế đứng nhưng mới xoay được nửa chừng. Các phức bộ QRS của aVF, DII dương và có dạng qR giống V5, V6; aVL có điện thế thấp. Góc α khoảng 60°.
**Tư thế vô định**
Các phức bộ QRS không có liên hệ gì với nhau. aVL và aVF không có các hình thái rõ rệt hoặc đều có biên độ tương đối gần 0.
**Tư thế mỏm tim ra sau**
Sóng S ở DI, DII, DIII sâu, biên độ của các chuyển đạo trước tim thấp.
**Tư thế mỏm tim ra trước**
Sóng Q ở DI, DII, DIII sâu, biên độ của các chuyển đạo trước tim cao.
**TÓM TẮT NHẬN DẠNG TƯ THẾ ĐIỆN HỌC CỦA TIM**
**Bảng D1.1.** Bảng so sánh chuyển đạo
**Bảng D1.2.** **Phức độ QRS ở các tư thế tim khác nhau**
**THAY ĐỔI SINH LÝ CỦA TƯ THẾ TIM**
**Theo lứa tuổi**
Ở trẻ em và thanh niên, tim thường ở vị trí đứng và nửa đứng. Đến trung niên, tim chuyển dần sang tư thế trung gian hay nửa nằm. Ở người lớn tuổi, phần lớn tim ở tư thế nằm.
**Tạng người**
Người cao, gầy ốm, lồng ngực hẹp tim thường đứng. Ở người có chiều cao trung bình, tim thường ở tư thế tim trung gian và tim ở tư thế nằm thường gặp ở những người thấp, mập, lồng ngực rộng.
**Hô hấp**
Khi hít sâu, lồng ngực dãn ra kéo theo mỏm tim nên tim có vị trí thẳng đứng hơn và có xu hướng xoay theo chiều kim đồng hồ. Ngược lại lúc thở ra hết, lồng ngực ngắn lại, tim sẽ nằm ngang hơn và có xu hướng xoay ngược chiều kim đồng hồ.
**THAY ĐỔI BỆNH LÝ CỦA TƯ THẾ TIM**
**Dày thất phải:** tim ở vị trí đứng hay nửa đứng. Nếu ở trẻ em và kèm trục lệch phải mà không đảo ngược phủ tạng hay bloc nhánh phải nên nghĩ đến bệnh tim bẩm sinh.
**Dày thất trái:** tim ở vị trí nằm. Thường là dày và tăng gánh thất thất trái.
**Tư thế vô định:** hay gặp trong khí phế thũng, tâm phế mạn, đôi khi trong nhồi máu cơ tim thành trước, bloc vùng đáy thất trái...
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh

## ️ Ghi điện cơ trong lâm sàng thần kinh

  * [1.1. Tổng quát: ](https://bvnguyentriphuong.com.vn/tham-do-chuc-nang/ghi-dien-co-trong-lam-sang-than-kinh#11-tng-qut)
  * [ 1.2. Quy trình khám nghiệm:](https://bvnguyentriphuong.com.vn/tham-do-chuc-nang/ghi-dien-co-trong-lam-sang-than-kinh#12-quy-trnh-khm-nghim)
  * [2. PHƯƠNG PHÁP ĐO DẪN TRUYỀN THẦN KINH:](https://bvnguyentriphuong.com.vn/tham-do-chuc-nang/ghi-dien-co-trong-lam-sang-than-kinh#2-phng-php-o-dn-truyn-thn-kinh)
  * [ 2.1. Thời gian tiềm vận động ngoại vi và tốc độ dẫn truyền vận động: (Distal Motor Latency – DML & Motor Conduction Velocity – MCV)](https://bvnguyentriphuong.com.vn/tham-do-chuc-nang/ghi-dien-co-trong-lam-sang-than-kinh#21-thi-gian-tim-vn-ng-ngoi-vi-v-tc-dn-truyn-vn-ng-distal-motor-latency-dml-motor-conduction-velocity-mcv)
  * [ 2.2. Tốc độ dẫn truyền cảm giác: (Sensory Conduction Velocity – SCV)](https://bvnguyentriphuong.com.vn/tham-do-chuc-nang/ghi-dien-co-trong-lam-sang-than-kinh#22-tc-dn-truyn-cm-gic-sensory-conduction-velocity-scv)
  * [ 2.3. Sóng F, thời gian tiềm và tần số:](https://bvnguyentriphuong.com.vn/tham-do-chuc-nang/ghi-dien-co-trong-lam-sang-than-kinh#23-sng-f-thi-gian-tim-v-tn-s)
  * [2.4. Phản xạ H: (H-reflex)](https://bvnguyentriphuong.com.vn/tham-do-chuc-nang/ghi-dien-co-trong-lam-sang-than-kinh#24-phn-x-h-hreflex)
  * [3. PHƯƠNG PHÁP ĐIỆN CƠ: (Electromyography hoặc needle EMG)](https://bvnguyentriphuong.com.vn/tham-do-chuc-nang/ghi-dien-co-trong-lam-sang-than-kinh#3-phng-php-in-celectromyography-hoc-needle-emg)
  * [3.1. Hoạt động điện do đâm kim (Insertional activity):](https://bvnguyentriphuong.com.vn/tham-do-chuc-nang/ghi-dien-co-trong-lam-sang-than-kinh#31-hot-ng-in-do-m-kim-insertional-activity)
  * [3.2. Hoạt động điện tự phát (spontaneous activity):](https://bvnguyentriphuong.com.vn/tham-do-chuc-nang/ghi-dien-co-trong-lam-sang-than-kinh#32-hot-ng-in-t-pht-spontaneous-activity)
  * [3.3. Điện thế của đơn vị vận động (motor unit action potentials – MUP/MUAP):](https://bvnguyentriphuong.com.vn/tham-do-chuc-nang/ghi-dien-co-trong-lam-sang-than-kinh#33-in-th-ca-n-v-vn-ng-motor-unit-action-potentials-mupmuap)
  * [3.4. Hình ảnh kết tập (recruitment pattern):](https://bvnguyentriphuong.com.vn/tham-do-chuc-nang/ghi-dien-co-trong-lam-sang-than-kinh#34-hnh-nh-kt-tp-recruitment-pattern)


## **1. CƠ SỞ:**
### **1.1. Tổng quát:**
Phương pháp ghi điện cơ, thực ra thường được y văn gọi là phương pháp Chẩn đoán điện (electrodiagnosis), bao gồm các phương pháp: 1) đo dẫn truyền thần kinh (nerve conduction studies), 2) điện cơ đồ (electromyography – EMG). Ngoài ra, còn có một số kỹ thuật khác như: kích thích lặp lại liên tiếp (repetitive stimulation), phản xạ nhắm mắt (blink reflex), tetany test…
### **1.2. Quy trình khám nghiệm:**
Người bác sỹ làm điện cơ cần phải có hiểu biết về giải phẫu, sinh lý và lâm sàng thần kinh, đặc biệt là của hệ thần kinh ngoại vi và hệ cơ xương. Trước khi làm chẩn đoán điện cần phải khám lâm sàng thần kinh, từ đó xác định mục đích làm điện cơ trên từng bệnh nhân cụ thể, trong quá trình làm điện cơ lại có bổ sung hoặc sửa đổi, tùy thuộc những vấn đề vừa nảy sinh.
Điện cơ cũng chỉ là một xét nghiệm, phải xem xét kết quả điện cơ trong tổng thể lâm sàng và các xét nghiệm khác.
## **2. PHƯƠNG PHÁP ĐO DẪN TRUYỀN THẦN KINH:**
Bao gồm: đo thời gian tiềm vận động ngoại vi, tốc độ dẫn truyền của dây thần kinh (NCV: nerve conduction velocity) bao gồm tốc độ dẫn truyền vận động (MCV) và tốc độ dẫn truyền cảm giác (SCV), và thời gian tiềm của sóng F. Thường chỉ đo được trên một số dây thần kinh: dây thần kinh giữa (median n.) hoặc trụ (ulnar n.) và quay (radial n.) cho chi trên, dây chầy sau (posterior tibial n.), dây hiển (sural n.) và mác nông hoặc mác sâu (superficial peroneal & deep peroneal n.) cho chi dưới. Trong 12 đôi dây thần kinh sọ não, chỉ có khả năng đo dẫn truyền (không trực tiếp) của dây V và VII.
### **2.1. Thời gian tiềm vận động ngoại vi và tốc độ dẫn truyền vận động: (Distal Motor Latency – DML & Motor Conduction Velocity – MCV)**
Khi kích thích một dây thần kinh vận động bằng một xung điện, dây thần kinh sẽ bị khử cực tại điểm kích thích, tạo thành một xung thần kinh. Xung này di chuyển dọc theo dây thần kinh vận động, gây co cơ. Điện cực ghi (đặt trên bắp cơ) ghi được hoạt động điện do co cơ sinh ra, khi tăng dần cường độ kích thích, thì làn sóng ghi được do co cơ trên màn hình máy cũng tăng biên độ. Tới một giới hạn nào đó, khi tăng cường độ kích thích thì biên độ sóng co cơ cũng không tăng theo, chứng tỏ tất cả các sợi thần kinh vận động của dây thần kinh đó đều đã bị kích thích. Sóng co cơ khi đó được gọi là hay điện thế hoạt động cơ toàn phần (Compound Muscle Action Potential – CMAP). Thời gian tính từ khi kích thích dây thần kinh đến khởi điểm của CMAP, được gọi là thời gian tiềm vận động (motor latency). Thời gian tiềm này bao gồm 3 thành phần: 1) Thời gian dẫn truyền dọc theo dây thần kinh; 2) Thời gian dẫn truyền qua synap; và 3) Thời gian lan tỏa khử cực dọc theo sợi cơ. Nếu muốn tính được tốc độ dẫn truyền xung của riêng dây thần kinh vận động, ta phải kích thích tại 2 điểm khác nhau. Khi kích thích thân dây thần kinh tại điểm ngoại vi của nó (dây giữa và trụ tại cổ tay, dây chày ở ngay sau mắt cá trong, dây mác ở cổ chân) thì ta có được  _thời gian tiềm vận động ngoại vi_(Distal Motor Latency – _DML_), tính bằng ms. Ta đặt ký hiệu là L1. Sau đó nếu kích thích chính dây thần kinh ấy ở phía trên (dây giữa và dây trụ ở khuỷu tay, dây chày và mác ở đầu gối), ta lại được một đáp ứng co cơ (CMAP) khác, có thời gian tiềm dài hơn, vì xung điện kích thích phải di chuyển dọc theo thân dây thần kinh trên một quãng đường dài hơn, ta gọi nó là L2. Hiệu số t=(L2-L1) chính là thời gian xung kích thích đi giữa 2 điểm kích thích điện.
Dùng thước dây để đo khoảng cách giữa 2 điểm, gọi là d, tính bằng mm. Tốc độ là: ** _v = d/t_** tính bằng m/s. Đó chính là  _tốc độ dẫn truyền vận động_ (Motor Conduction Velocity –  _MCV_).
Ngoài tốc độ, chúng ta còn quan tâm tới biên độ (amplitude) và hình dạng của CMAP. Biên độ là chiều cao của đường ghi đáp ứng co cơ, tính từ đường đẳng điện tới đỉnh của nó, biên độ tính bằng mV. Người ta còn tính diện tích (area) của phần nằm giữa đường ghi đáp ứng co cơ và đường đẳng điện.
**Hình 1:** Đo dẫn truyền thần kinh vận động dây thần kinh giữa, ghi đáp ứng co cơ ở ô mô cái, kích thích điện vào dây giữa ở 2 điểm: S1 là kích thích điện ở cổ tay, S2 là kích thích điện ở khuỷu tay. Tương ứng trên màn hình và giấy ghi ta có đáp ứng co cơ R1 và R2. Thời gian tiềm là khoảng thời gian từ lúc có kích thích tới lúc có đáp ứng co cơ, ta có tương ứng là L1 và L2, trong đó L1 chính là DML. Hiệu số l = L2-L1 (tính bằng ms) là khoảng thời gian xung điện đi từ khuỷu (điểm S2) tới cổ tay (điểm S1).
### **Ứng dụng:**
  * So sánh với giá trị bình thường của từng dây thần kinh, nếu thời gian tiềm dài hơn, MCV chậm hơn, thì chứng tỏ dây thần kinh bị tổn thương bao Myelin.
  * So sánh biên độ của CMAP: nếu kích thích ở phía trên có biên độ thấp hơn so với kích thích ở dưới trên 50%, đó là hiện tượng chẹn dẫn truyền (conduction block) một phần tại điểm nằm giữa 2 điểm kích thích. Ví dụ khi tìm hiện tượng chèn ép dây mác ở phía sau của đầu trên xương mác, và dây trụ ở rãnh khuỷu tay.
  * Hiện tượng phát tán theo thời gian (temporal dispersion) là: CMAP với kích thích dây thần kinh gần trung tâm (ví dụ: dây giữa ở khuỷu tay) có biên độ thấp hơn CMAP với kích thích phía ngoại vi (ví dụ: dây giữa ở cổ tay), nhưng lại rộng hơn (đáp ứng co cơ kéo dài ra), và do vậy diện tích phần nằm dưới đường ghi co cơ ít thay đổi. Hiện tượng này thường là do dây thần kinh bị tổn thương myelin từng ổ và rải rác suốt dọc chiều dài của nó, hay thấy trong các bệnh bệnh dây thần kinh hủy myelin mắc phải, như hội chứng Guillain-Barré hay CIDP.


### **2.2. Tốc độ dẫn truyền cảm giác: (Sensory Conduction Velocity – SCV)**
Sóng ghi được khi kích thích dây thần kinh cảm giác, gọi là điện thế hoạt động của dây thần kinh cảm giác (sensory nerve action potential – SNAP). Thời gian tiềm cảm giác là thời gian tính từ lúc kích thích điện cho tới lúc thu được sóng đáp ứng. Có 2 phương pháp nghiên cứu dẫn truyền thần kinh cảm giác.
  * **Phương pháp thuận chiều (orthodromic):** kích thích điện vào thụ thể cảm giác ở ngoài da và ghi đáp ứng trên thân dây thần kinh, xung điện đi xuôi chiều sinh lý của dẫn truyền cảm giác.
  * **Phương pháp ngược chiều (antidromic):** kích thích điện trên thân dây thần kinh và ghi đáp ứng ở vùng chi phối cảm giác da – dermatoma của nó, xung động điện đi ngược chiều sinh lý của dẫn truyền cảm giác.


**Ứng dụng:** Trong thực tế thường nghiên cứu dẫn truyền cảm giác của: dây giữa, dây trụ, dây quay, dây mác nông.
  * Trong bệnh đa dây thần kinh gây tổn thương sợi trục, biên độ của điện thế cảm giác thấp xuống hoặc mất.
  * Trong hội chứng ống cổ tay giai đoạn sớm, thời gian tiềm cảm giác của dây giữa dài ra trong khi của dây trụ là bình thường.
  * Trong các bệnh cơ và bệnh neuron vận động, đường cảm giác không bị ảnh hưởng, nên thời gian tiềm cảm giác và biên độ của đáp ứng cảm giác là bình thường.
  * Nếu BN mất cảm giác trên lâm sàng, nhưng SCV và biên độ SNAP bình thường, ta nghi rễ sau.


### **2.3. Sóng F, thời gian tiềm và tần số:**
Khi kích thích dây thần kinh vận động, xung thần kinh di chuyển theo cả 2 hướng: ly tâm và hướng tâm. Hướng ly tâm cho đáp ứng co cơ (CMAP), dùng để đo DML và MCV. Hướng hướng tâm, đi ngược về phía các rễ trước của tủy sống, kích động các neuron vận động của sừng trước tủy sống. Một số neuron phát ra xung thần kinh mới xuôi xuống theo hướng ly tâm, tạo nên một co cơ nữa. Trên màn hình của máy điện cơ, sau đáp ứng M còn có một đáp ứng co cơ nữa, gọi là sóng F. Gọi là sóng F vì thoạt đầu người ta phát hiện nó ở chân (F: foot), về sau thấy cũng có sóng này ở tay. Khi bị kích thích, không phải tất cả các neuron của sừng trước tủy sống đều đáp ứng, mà chỉ có một nhóm nhỏ đáp ứng, do vậy sóng F có biên độ nhỏ hơn nhiều so với CMAP. Ngoài ra, mỗi một xung điện hướng tâm khác nhau sẽ cho đáp ứng của một nhóm neuron khác nhau. Kết quả là khi kích thích nhiều lần vào cùng một dây thần kinh, ghi đáp ứng ở cùng một bắp cơ do dây đó chi phối, ta lại được những sóng F có hình dạng và thời gian tiềm luôn thay đổi. Thông thường người ta hay dùng chuỗi 16 hoặc 20 kích thích, và tính tần số xuất hiện sóng F (F wave frequency), qui thành %.
**Hình 2** : Kim điện cơ kiểu đồng tâm (concentric needle) là kim thông thường, dùng trong các xét nghiệm điện cơ thường quy, kim ghi được điện thế của một nhóm các sợi cơ (và do vậy ghi được các MUP).
**Ứng dụng:**
  * Sóng F cũng để khảo sát gián tiếp tốc độ dẫn truyền vận động: muốn tìm hiểu về tốc độ dẫn truyền của đoạn thần kinh ở cao, như từ nách lên tới cổ, hay từ khoeo chân tới thắt lưng, nếu MCV ở đoán dưới là bình thường, nhưng thời gian tiềm của sóng F lại dài ra, suy ra đoạn bị chậm dẫn truyền nằm ở đoạn gốc của dây thần kinh, các đám rối thần kinh, hoặc rễ trước.
  * Hội chứng Guillain-Barré: trong giai đoạn sớm, có thể dịch não tủy chưa có phân ly Albumin – tế bào, thời gian tiềm sóng F đã có thể kéo dài, hoặc mất hẳn sóng F.
  * Trong bệnh neuron vận động, tần số sóng F suy giảm, sóng F trở nên đơn điệu về hình dạng.


### **2.4. Phản xạ H: (H-reflex)**
Phản xạ H do P.Hoffmann phát hiện (do vậy mang tên H). Phản xạ này ghi được ở tất cả các bắp cơ của trẻ em. Nhưng ở người lớn phản xạ này mất dần và thường chỉ còn ghi được ở cơ sinh đôi cẳng chân, cơ dép, cơ gấp cổ tay quay.
Cách ghi phản xạ H: kích thích điện vào thân dây thần kinh tọa ở hố khoeo chân. Với cường độ kích thích thấp, sóng co cơ chưa xuất hiện hoặc đã có nhưng biên độ còn rất thấp, phía sau nó là 1 sóng có biên độ cao hơn và cách một khoảng cách cố định. Đó chính là phản xạ H. Khi cường độ kích thích tăng dần lên, biên độ co cơ trực tiếp sẽ cao dần, và tối đa là trở thành CMAP. Khi tăng dần cường độ kích thích như vậy, biên độ của phản xạ H cũng cao dần, nhưng tới một mức nào đó sẽ nhỏ đi, rồi biến mất.
**Hình 3** : Phản xạ H tại cơ dép, với kích thích cường độ thấp, ta thấy đáp ứng co cơ trực tiếp (sóng đi trước) có biên độ rất thấp và phản xạ H có biên độ cao hơn. Từ trên xuống dưới: với cường độ kích thích tăng dần thì phản xạ H cũng tăng biên độ, nhưng khi kích thích với cường độ trên tối đa thì mất phản xạ H và sóng F xuất hiện. (Tư liệu của tác giả).
Cơ chế sinh lý của phản xạ H: xung kích thích đi theo các sợi cảm giác (nằm trong thân dây thần kinh hỗn hợp cảm giác và vận động), đi ngược về phía tủy sống, tới rễ sau của tủy sống, rồi tới sừng trước, gây co cơ. Cung phản xạ H là cung phản xạ 1 synap kinh điển của tủy sống, bao gồm cả đường cảm giác, lẫn đường vận động.
**Ứng dụng:**
  * Phản xạ H ở chân (cơ dép/cơ sinh đôi cẳng chân) giúp khảo sát khả năng tổn thương rễ S1. Phản xạ H ở cơ gấp cổ tay quay (Flexor carpi radialis) cho thông tin về dẫn truyền cảm giác hướng tâm ở đoạn gần gốc của tay (rễ C6 và C7).
  * Giúp chẩn đoán phân biệt loại bệnh đa dây thần kinh chỉ tổn thương sợi cảm giác, trong khi các sợi vận động alpha còn nguyên vẹn.
  * Mất phản xạ H là 1 dấu hiệu sớm nhất để chẩn đoán hội chứng Guilain – Barré.
  * Người ta còn nghiên cứu phản xạ H trong một số bệnh lý thần kinh trung ương như: bệnh Parkinson, loạn trương lực (dystonia), chấn thương tủy sống…


Các đáp ứng muộn (sóng F và phản xạ H) rất có ích lợi cho nghiên cứu dẫn truyền thần kinh ở trẻ nhỏ. Chi thể của trẻ rất ngắn, việc đo lường khoảng cách để tính tốc độ (MCV và SCV) khó khăn và dễ sai số. Người ta đã chứng minh là thời gian tiềm ngắn nhất của sóng F và phản xạ H có tương quan chặt chẽ với chiều cao và cân nặng của trẻ. Trẻ sơ sinh có tốc độ dẫn truyền thần kinh (MCV và SCV) khoảng bằng 1/2 của người lớn, tốc độ sẽ tăng dần theo tuổi, tới khoảng 3-5 tuổi thì đạt tới giá trị của người lớn. Bình thường ở trẻ 1-2 tuổi, thời gian tiềm ngắn nhất (minimal latency) của phản xạ H là dưới 18 ms, còn ở trẻ 3-5 tuổi là dưới 20 ms. Thời gian tiềm ngắn nhất của sóng F ở trẻ dưới 5 tuổi là dưới 18 ms.
## **3. PHƯƠNG PHÁP ĐIỆN CƠ: (Electromyography hoặc needle EMG)**
Điện cơ thường qui thường dùng loại điện cực kim đồng tâm. Có 4 bước khám nghiệm điện cơ kim.
### **3.1. Hoạt động điện do đâm kim (Insertional activity):**
Bệnh nhân thư giãn cơ, đâm điện cực kim xuyên vào cơ, nhằm khảo sát các hoạt động điện do kim đâm gây ra
**Ứng dụng:**
  * Điện thế do đâm kim bị giảm mất trong cơn kịch phát của bệnh liệt chu kỳ, hoặc khi kim điện cực di chuyển trong tổ chức xơ sợi hoặc mỡ.
  * Điện thế do đâm kim tăng lên thường do mất phân bố thần kinh (denervation), đôi khi cũng có trong các bệnh cơ.


**Hình 4** : Kim điện cơ kiểu đồng tâm (concentric needle) là kim thông thường, dùng trong các xét nghiệm điện cơ thường quy, kim ghi được điện thế của một nhóm các sợi cơ (và do vậy ghi được các MUP).
### **3.2. Hoạt động điện tự phát (spontaneous activity):**
Để kim nằm im trong bắp cơ đang thư giãn hoàn toàn (không co cơ), nhằm tìm các hoạt động điện tự phát của cơ đó nếu có. Thường gồm điện thế co giật sợi cơ và sóng nhọn dương, người ta chia mức độ xuất hiện thành 4 độ:
(+1) tăng điện thế do đâm kim;
(+2) có ở ít nhất là 2 vị trí được thăm dò trong bắp cơ đó;
(+3) Bất kỳ tại vị trí nào của bắp cơ cũng có thể thấy các điện thế tự phát;
(+4) Các sóng điện thế tự phát rất nhiều, gần như tràn ngập màn hình.
**Ứng dụng:**
  * Nếu điện thế tự phát xuất hiện ở mức 2 (+), tức là có hiện tượng mất phân bố (chi phối) thần kinh của cơ đó. Căn cứ vào các sơ đồ thần kinh – cơ, có thể định khu được chỗ tổn thương của dây thần kinh ngoại vi (hoặc rễ hay đám rối…).
  * Liệt trung ương hoặc hoặc hysteria thì không có hoạt động điện tự phát ở cơ bị liệt. Nếu có điện thế tự phát trên bệnh nhân liệt trung ương, thì cần nghi có tổn thương ngoại vi thứ phát.


### **3.3. Điện thế của đơn vị vận động (motor unit action potentials – MUP/MUAP):**
Cho bệnh nhân co cơ một cách nhẹ nhàng để các đơn vị vận động phát xung rời rạc, khảo sát hình ảnh của từng điện thế của đơn vị vận động. MUP (hay MUAP) là sóng thu được trên màn hình khi các sợi cơ thuộc 1 đơn vị vận động cùng co. Mỗi MUAP là của 1 đơn vị vận động, nó được đặc trưng bởi: biên độ, thời khoảng và số lượng pha.
Ứng dụng: tại mỗi một cơ, ta cố gắng thu nhận được 20 MUAP, từ đó tính được số trung bình của biên độ, thời khoảng và số pha của MUAP chung cho bắp cơ đó. Những chỉ số này, được so sánh với tiêu chuẩn bình thường, giúp chẩn đoán phân biệt yếu bại hoặc teo cơ do bệnh cơ (myogenic) với do căn nguyên thần kinh (neurogenic), ví dụ phân biệt giữa teo cơ do bệnh loạn dưỡng cơ với teo cơ do bệnh xơ cột bên teo cơ.
### **3.4. Hình ảnh kết tập (recruitment pattern):**
Yêu cầu bệnh nhân co cơ mạnh dần lên, khi co cơ còn nhẹ, chỉ có các MUAP đơn lẻ xuất hiện rời rạc. Khi co cơ mạnh hơn, sẽ có nhiều đơn vị vận động khác tham gia vào co cơ, trên màn hình xuất hiện nhiều MUAP hơn, gọi là hình ảnh kết tập. Tới mức co cơ cực đại thì trên màn hình dầy đặc các MUAP, không còn thấy đường đẳng điện nữa, ta gọi là hình ảnh giao thoa (interference pattern).
**Ưng dụng:**
  * So sánh trong bệnh neuron vận động trên với bệnh neuron vận động dưới: Trong bệnh neuron vận động dưới (xơ cột bên teo cơ, bệnh lý thần kinh ngoại biên, có hình ảnh giảm kết tập và giao thoa không hoàn toàn, với các nhịp phóng điện của từng MUAP nhanh hơn (fast firing rates). Ngược lại, trong tổn thương thần kinh trung ương, có hình giảm kết tập, với nhịp phóng điện chậm.
  * Trong bệnh cơ: có kết tập sớm, nhanh có hình ảnh giao thoa với biên độ thấp.


**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh
[youtube.com/bvntp](http://youtube.com/bvntp)
  * [1.1. Tổng quát: ](https://bvnguyentriphuong.com.vn/tham-do-chuc-nang/ghi-dien-co-trong-lam-sang-than-kinh#11-tng-qut)
  * [ 1.2. Quy trình khám nghiệm:](https://bvnguyentriphuong.com.vn/tham-do-chuc-nang/ghi-dien-co-trong-lam-sang-than-kinh#12-quy-trnh-khm-nghim)
  * [2. PHƯƠNG PHÁP ĐO DẪN TRUYỀN THẦN KINH:](https://bvnguyentriphuong.com.vn/tham-do-chuc-nang/ghi-dien-co-trong-lam-sang-than-kinh#2-phng-php-o-dn-truyn-thn-kinh)
  * [ 2.1. Thời gian tiềm vận động ngoại vi và tốc độ dẫn truyền vận động: (Distal Motor Latency – DML & Motor Conduction Velocity – MCV)](https://bvnguyentriphuong.com.vn/tham-do-chuc-nang/ghi-dien-co-trong-lam-sang-than-kinh#21-thi-gian-tim-vn-ng-ngoi-vi-v-tc-dn-truyn-vn-ng-distal-motor-latency-dml-motor-conduction-velocity-mcv)
  * [ 2.2. Tốc độ dẫn truyền cảm giác: (Sensory Conduction Velocity – SCV)](https://bvnguyentriphuong.com.vn/tham-do-chuc-nang/ghi-dien-co-trong-lam-sang-than-kinh#22-tc-dn-truyn-cm-gic-sensory-conduction-velocity-scv)
  * [ 2.3. Sóng F, thời gian tiềm và tần số:](https://bvnguyentriphuong.com.vn/tham-do-chuc-nang/ghi-dien-co-trong-lam-sang-than-kinh#23-sng-f-thi-gian-tim-v-tn-s)
  * [2.4. Phản xạ H: (H-reflex)](https://bvnguyentriphuong.com.vn/tham-do-chuc-nang/ghi-dien-co-trong-lam-sang-than-kinh#24-phn-x-h-hreflex)
  * [3. PHƯƠNG PHÁP ĐIỆN CƠ: (Electromyography hoặc needle EMG)](https://bvnguyentriphuong.com.vn/tham-do-chuc-nang/ghi-dien-co-trong-lam-sang-than-kinh#3-phng-php-in-celectromyography-hoc-needle-emg)
  * [3.1. Hoạt động điện do đâm kim (Insertional activity):](https://bvnguyentriphuong.com.vn/tham-do-chuc-nang/ghi-dien-co-trong-lam-sang-than-kinh#31-hot-ng-in-do-m-kim-insertional-activity)
  * [3.2. Hoạt động điện tự phát (spontaneous activity):](https://bvnguyentriphuong.com.vn/tham-do-chuc-nang/ghi-dien-co-trong-lam-sang-than-kinh#32-hot-ng-in-t-pht-spontaneous-activity)
  * [3.3. Điện thế của đơn vị vận động (motor unit action potentials – MUP/MUAP):](https://bvnguyentriphuong.com.vn/tham-do-chuc-nang/ghi-dien-co-trong-lam-sang-than-kinh#33-in-th-ca-n-v-vn-ng-motor-unit-action-potentials-mupmuap)
  * [3.4. Hình ảnh kết tập (recruitment pattern):](https://bvnguyentriphuong.com.vn/tham-do-chuc-nang/ghi-dien-co-trong-lam-sang-than-kinh#34-hnh-nh-kt-tp-recruitment-pattern)



## ️ Quy trình kỹ thuật đo điện tim

**CHUẨN BỊ DỤNG CỤ**
Máy đo điện tim
Các điện cực và dây
Dây nguồn của máy 
Gel bôi điện cực và khăn giấy
Gòn tẩm cồn
Máy đo huyết áp
**TIẾN HÀNH**
**Bước 1 - Chuẩn bị bệnh nhân và máy móc:**
Mang máy điện tim và dụng cụ đến nơi làm chuẩn bị đo.
Thông báo và giải thích cho bệnh nhân biết về việc sắp làm. 
Động viên bệnh nhân yên tâm và cộng tác. 
Kiểm tra xem chung quanh có máy móc nào lớn đang hoạt động, khả dĩ có thể làm ảnh hưởng tới sóng điện tim không. 
Nhắc bệnh nhân lấy trong người ra hết những gì có thể gây nhiễu sóng: kim loại, máy điện thoại…
Cho bệnh nhân nằm thẳng, hai bàn tay ngữa, hai chân không chạm nhau. Nằm đúng tư thế nhưng thoải mái, mắt nhắm. Nếu là bệnh nhân nhi, giãy giụa nhiều phải cho uống thuốc an thần để trẻ ngủ yên.
Kiểm tra lại các thông số cần thiết khi đo điện tim: đo Huyết áp, cân nặng, chiều cao.
Để lộ ngực bệnh nhân hoàn toàn; không nên chỉ vén áo, kể cả áo ngực. Nếu nhân viên nam đo cho nữ bệnh nhân cần có người thứ ba trong phòng.
Đặt máy ở nơi bằng phẳng, vững chắc.
Kiểm tra nguồn điện. Những nguồn điện không ổn định ngoài việc có thể làm mau hỏng máy còn làm nhiễu điện khi đo. Trong trường hợp đó tốt nhất là đo bằng nguồn điện dự trữ từ pin có sẵn trong máy.
Mở máy đo điện tim. Kiểm tra máy xem có hoạt động bình thường không.
Dùng bông đã tẩm cồn lau trên bề mặt da sẽ tiếp xúc với các mặt điện cực để tăng cường diện tiếp xúc. Có thể bôi gel lên cả bề mặt tiếp xúc của các điện cực sẽ có hiệu quả hơn.
**Bước 2 - Gắn các điện cực**
**Cách đặt các chuyển đạo:**
Lau sạch bề mặt tiếp xúc của da với điện cực bằng cồn.
Thoa một lớp gel lên da, sau đó gắn các điện cực lên da. Lưu ý khi thoa gel không thoa quá rộng để nhiễu điện từ điện cực này sang điện cực khác.
Chọn chỗ thịt mềm để gắn điện cực, không nên đặt lên xương.
Có 12 chuyển đạo thông dụng: 6 chuyển đạo ngoại biên, 6 chuyển đạo trước tim.
**Chuyển đạo ngoại biên (các chi)**
Các điện cực đo chuyển đạo ngoại biên và màu thường quy ước như sau:
**Bảng 2.1.** Ký hiệu và màu điện cực
Mặt điện cực áp vào mặt trước 1/3 dưới cẳng tay và mặt trong 1/3 dưới cẳng chân.
Trong những trường hợp đặc biệt như vướng còng, bột bó cố định xương, cụt chi… có thể gắn điện cực ở vị trí cao hơn.
Các chuyển đạo sau được gọi là các chuyển đạo ngoại biên vì đều có điện cực thăm dò đặt ở các chi.
**_Ba chuyển đạo song cực chi (Bipolar leads)_**
DI (cổ tay phải và cổ tay trái): là sự khác biệt điện áp giữa điện cực LA và RA (LA - RA), hướng về LA ở 0º.
DII (cổ tay phải và cổ chân trái): là sự khác biệt điện áp giữa điện cực LL và RA (LL - RA), hướng về LL ở 60º.
DIII (cổ tay trái và cổ chân trái): là sự khác biệt điện áp giữa các điện cực LL và LA (LL - LA), hướng về LL ở 120º.
**_Ba chuyển đạo đơn cực chi tăng cường (Augmented unipolar leads)_**
aVR (cổ tay phải): hướng về phía điện cực RA (- 150º), được tính như sau: 
**aVR = RA - (LA + LL) / 2**
aVL (cổ tay trái): hướng về phía điện cực LA (- 30º), được tính như sau: 
**aVL = LA - (RA + LL) / 2**
aVF (cổ chân trái): hướng về phía điện cực LL (+ 90º), được tính như sau: 
**aVF = LL - (LA + RA) / 2**
**_Trung tâm Wilson(Wilson’s central terminus - WCT)_**
Điểm trung tâm Wilson được hình thành bằng cách kết nối một điện trở 5 k từ đầu chuyển đạo chi tới điểm trung tâm. Trên thực tế, điểm trung tâm Wilson không phải là độc lập mà là kết nối các điện cực RA, LA, và LL với nhau. 
Điểm trung tâm Wilson đại diện cho trung bình của điện thế các chi và được tính như sau: 
**WCT = 1/3 (RA + LA + LL)**
**Chuyển đạo trước tim**
V1: liên sườn 4, cạnh phải xương ức.
V2: liên sườn 4, cạnh trái xương ức.
V3: điểm giữa khoảng cách V2 và V4
V4: giao điểm của đường trung đòn trái với liên sườn 5.
V5: giao điểm của đường nách trước trái với đường ngang đi qua V4
V6: giao điểm của đường nách giữa trái với đường ngang đi qua V4
**Một số chuyển đạo trước tim khác**
V7: ở liên sườn V trên đường nách sau
V8: giữa đường xương vai
V9: cạnh đường liên gai sống trái
V3R, V4R, V5R, V6R: Các điện cực này đối xứng từng cặp với V3, V4, V5, V6 qua xương ức
E: mũi ức
**Bước 3 - Đo điện tim**
**Tiến hành đo**
_Trước khi đo, cần kiểm tra lại máy:_
Xem máy đã ổn định chưa, mặt phẳng đặt máy có vững chắc không
Sóng có bị nhiễu không
Kiểm tra các thông số đo có đang ở vị trí bình thường không: 1mV, tốc độ 25mm/giây, chế động tự động…
Trấn an bệnh nhân. Dặn bệnh nhân cố gắng nằm yên, ít cử động và không nói chuyện trong thời gian đo điện tim.
_Nhấn nút điều khiển cho máy chạy. Trong khi máy chạy phải liên tục quan sát:_
Máy có chạy bình thường không
Bệnh nhân có cử động hay xảy ra sự cố gì không (điện giật do hở mạch, run, hồi hộp…). Nếu trời lạnh cần giữ ấm cho bệnh nhân.
Khi có sự cố xảy ra phải ngưng ngay tiến trình đo. 
Theo dõi đường đẳng điện và chỉnh kịp thời để tránh hình ảnh các sóng bị cắt cụt.
Máy sẽ tự động đo theo chương trình cài đặt trước. Sau khi đo xong, máy sẽ tự động dừng.
Nếu thấy nhịp tim không đều thường phải đo thêm DII hoặc V1 liên tục 10-15 giây hoặc đo theo chỉ định. Để đo liên tục, cần tiến hành như sau:
Chuyển từ chế độ đo tự động sang chế độ đo bằng tay. (Auto → Manual)
Dịch chuyển đến chuyển đạo DII hoặc chuyển đạo được chỉ định (Thường là chuyển đạo gần trục điện tim nhất)
Nhấn nút đo và đếm ô hoặc bấm giờ. Cứ 1 giây tương đương 25 ô vuông nhỏ tức 5 ô vuông lớn. Đo liên tục 10 giây. 
**_Một số nút thông dụng_**
_**Hình 2.8.** Một máy ghi điện tim có nhiều phím chức năng_
Các nút chuyển đạo có thể được thiết kế riêng hoặc bằng 2 nút mũi tên để dịch chuyển.
Tùy theo hãng và chức năng của máy mà các nút điều khiển có thể được nhà sản xuất thêm vào.
**Bước 4 - Kết thúc**
Cho bệnh nhân mặc lại áo, đặt bệnh nhân nằm tư thế thoải mái, hoặc cho về.
**Thu dọn dụng cụ:**
Ngắt nguồn điện. 
Lau sạch mặt các điện cực bằng bông cồn.
Tháo rời dây nguồn, dây điện cực.
Cuốn gọn các dây đo. Tránh để dây bị gấp hoặc xoắn, rối. Nếu máy để nơi cố định để đo thì nên treo dây điện cực lên giá để bảo quản sẽ tốt hơn.
Cất dụng cụ vào nơi quy định.
**Ghi hồ sơ:**
Ngày giờ đo điện tim
Tình hình chung của bệnh nhân.
Dán kết quả vào giấy trả kết quả.
**ĐÁNH GIÁ KỸ THUẬT ĐO**
Một tác động bên ngoài hoặc kỹ thuật kém có thể dẫn đến nhiễu sóng và gây ra sai sót trong chẩn đoán. Vì vậy, cần kiểm tra kỹ trước khi tiến hành đo điện tim. 
**Yếu tố gây nhiễu:**
**Đường đẳng điện dao động:** thường do mặt tiếp xúc kém. Bề mặt tiếp xúc giữa da và điện cực là nơi quan trọng. Cần làm sạch da, lông, bôi gel để làm giảm điện trở. Đôi khi chỉ vì một sợi lông cũng gây ảnh hưởng đến kết quả đo. 
**Bệnh nhân không nằm yên:**
Có thể do bệnh nhân cảm thấy lạnh, do đó cần giữ ấm cho bệnh nhân.
Bệnh nhân căng thẳng, nói chuyện trong khi đo hoặc do bệnh nhân không hợp tác. Nên trấn an bệnh nhân và yêu cầu họ phải thở chậm nếu bị căng thẳng, cho bệnh nhân để cánh tay dọc sát cơ thể để giúp làm giảm run. Khi cần, phải cho bệnh nhân uống thuốc an thần.
Bệnh lý rung giật cơ: Parkinson, cường giáp hoặc run vô căn…
**Các yếu tố khác có thể ảnh hưởng đến đường biểu diễn:**
Bôi chất dẫn điện quá rộng làm mất sự khu trú chính xác.
Điện cực đặt trên xương nên dẫn điện kém.
Điện cực buộc lỏng, chỗ nối dây dẫn với điện cực không chặt
Các yếu tố khác: phòng ẩm, cách điện không tốt… 
**Hiệu chỉnh test mV:**
**Bình thường:** phóng dòng điện 1 mV vào máy, vặn nút điều chỉnh sao cho mỗi lần ấn nút phóng điện, cần đo vọt lên và dừng đúng vị trí cao 1cm, nhả nút ra, nó hạ xuống đúng đường đẳng điện.
**Quá đà (Overshoot):** do dây thạch anh bị chùng hoặc bộ phận đệm, kim ghi vặn quá lỏng khiến dây nảy quá đà, đường đẳng điện vọt lên và hạ xuống quá mức. Trên điện tâm đồ thể hiện sóng nhìn thấy nhanh hơn, hẹp hơn hoặc rộng hơn. 
**Quá mức (Overdamping):** do bộ phận đệm vặn chặt hoặc tăng sức cản ở da (ví dụ điện cực khô vì quên hoặc bôi ít gel dẫn điện). Trên điện tâm đồ thể hiện sóng như bị cùn, chậm hơn, rộng hơn, điện thế thấp hơn, có thể biến mất sóng S.
**Tiêu chuẩn điện thế:**
**Bình thường:** ứng với điện thế 1mV đường biểu diễn cao 1cm (2 ô lớn). Khi điện thể chuẩn không bằng đúng 1cm cần cân chỉnh lại hoặc hiệu chỉnh lại giá trị đo được theo điện thế chuẩn.
**Khi sóng quá thấp:** đo nhân đôi điện thế, ứng với dòng điện 1mV, đường biểu diễn cao 2cm.
**Khi sóng quá cao:** cần đo giảm điện thế, ứng với dòng điện 1mV đường biểu diễn cao 0,5cm. 
**Tiêu chuẩn thời gian:**
**Bình thường:** tốc độ giấy chạy mặc định là 25 mm/giây, và 1 ô rộng 1mm ứng với khoảng thời gian là 0,04 giây.
Khi nhịp tim quá nhanh hoặc muốn sóng rộng ra để dễ phân tích: cho giấy chạy nhanh với tốc độ 50 hoặc 100 mm/giây. 
**Mắc đúng điện cực:**
**Quy luật Einthoven:** tổng đại số biên độ điện thế II = I + III (điều kiện máy ghi đồng thời 3 chuyển đạo).
**Nếu DI có tất cả các sóng đều âm:** nhiều khả năng mắc lộn điện cực 2 tay.
**Chuyển đạo aVR thể hiện dương:** ngoại trừ do tim xoay sang phải thì có thể do mắc lộn điện cực.
**CÁC LỖI SÓNG ĐIỆN KHI ĐO VÀ CÁCH XỬ LÝ**
**Bảng 2.2.** Các lỗi sóng điện khi đo và cách xử lý
**PHÁT HIỆN MẮC LỘN ĐIỆN CỰC CHI (ECG LIMB LEAD REVERSALS)**
Mắc lộn điện cực ngoại biên có thể cho kết quả điện tâm đồ bất thường với hình ảnh như bệnh lý nhịp nhĩ lạc chỗ, dãn buồng tim hoặc thiếu máu cục bộ và nhồi máu cơ tim.
Nếu chỉ mắc lộn các điện cực chi (LA, RA, LL) với nhau thì kết quả sóng điện tại các chuyển đạo đó đảo ngược hoặc có thể không thay đổi. Nhưng khi mắc lộn một trong các điện cực chân tay với các điện cực trung tính (RL) thì sự thay đổi không chỉ ở các chuyển đạo ngoại biên mà còn ảnh hưởng đến các chuyển đạo trước tim.
Vì thế, ngoài việc người đo phải mắc cẩn thận, chính xác các điện cực thì người đọc còn phải biết cách phát hiện sự cố mắc lộn điện cực nếu xảy ra. 
Để xác định điện tâm đồ bị đảo lộn điện cực, trước tiên chúng ta xem kỹ hình ảnh bình thường của các chuyển đạo ngoại biên.
Đảo ngược Tay Trái /Tay Phải (LA / RA)
Trục điện tim đảo ngược 180O theo chiều ngang quanh trục của chuyển đạo aVF.
**Nhận biết**
Các sóng ở DI hoàn toàn bị đảo ngược.
DII thành DIII, aVL thành aVR và ngược lại. Chuyển đạo aVF không thay đổi.
_Lưu ý:_ Nếu tim bên phải cũng có hình ảnh tương tự nhưng chuyển đạo trước tim chỉ có sóng S chiếm ưu thế.
**Hình ảnh**
**Đảo ngược Tay Trái/Chân Trái (LA / LL)**
Trục điện tim đảo ngược 180O theo chiều ngang quanh trục của chuyển đạo aVR.
**Nhận biết**
Các sóng ở DIII bị đảo ngược.
Hình ảnh các chuyển đạo đối xứng qua aVF đảo ngược cho nhau DI thành DII và aVL thành aVF và ngược lại.
Chuyển đạo aVR không thay đổi.
**Hình ảnh**
**Đảo ngược Tay Phải/Chân Trái (RA / LL)**
Trục điện tim đảo ngược 180O theo chiều ngang quanh trục của chuyển đạo aVL.
**Nhận biết**
Các sóng ở DII bị đảo ngược.
Chuyển đạo DI và DIII đảo ngược (âm) và đổi vị trí cho nhau
Đổi vị trí aVR và aVF.
Chuyển đạo aVL không thay đổi.
**Hình ảnh**
**Đảo ngược Tay Phải/Chân Phải (RA / RL)**
Điện áp của Tay Phải (RA) và Chân Trái (LL) gần như giống hệt nhau, làm cho sự khác biệt giữa chúng không đáng kể, sóng điện tại DII gần như bằng không. 
Sóng điện thế thể hiện tại aVR giống như ở aVF và tương tự, sóng điện thế ở aVL xuất hiện hoàn toàn giống với sóng điện ghi nhận tại DI.
**Nhận biết**
Mất quy luật tam giác Eithoven
DII không có điện thế 
DI trở thành DIII đảo ngược.
DIII không thay đổi.
aVL xấp xỉ DIII đảo ngược.
aVR và aVF giống hệt nhau.
Các điện cực trung tính đã được di chuyển, điện áp trước tim cũng có thể bị bóp méo. 
**Hình ảnh**
Đảo ngược Chân Trái / Chân Phải (LL / RL)
Tam giác Einthoven dường như không đổi. Điện tâm đồ do đó cũng không thay đổi.
**Đảo ngược Tay Trái / Chân Phải (LA / RL)**
Quy luật Einthoven bị phá vỡ. Điện cực Tay Trái (LA) và Chân Trái (LL) ghi được điện áp gần giống nhau nên điện thế ghi nhận tại DIII gần bằng không.
**Nhận biết**
DIII sóng điện gần bằng không.
DI giống hệt DII.
aVL và aVF trở nên giống hệt nhau.
aVR giống hình ảnh đảo ngược của DII.
**Hình ảnh**
**Đảo ngược chuyển đạo Tay - Chân**
Mắc lộn điện cực của tay thành của chân và chân thành tay.
Điện áp tại RA và LA điện gần giống nhau, và làm cho chênh lệch điện áp giữa hai đầu (DI) là không đáng kể. Quy luật Einthoven bị phá vỡ.
**Nhận biết**
DI sóng điện gần bằng không.
DII, III, aVF giống nhau và đều là sóng âm
aVL và aVR giống nhau.
**Bảng 2.3. Tóm tắt cách nhận biết mắc lộn điện cực**
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh

## ️ Đại cương về đo điện tâm đồ

**KHÁI NIỆM**
Điện tâm đồ (Electrocardiogram) là đồ thị ghi lại quá trình hoạt động điện của tim, các biến thiên của các xung điện khử cực và tái cực của nhĩ và thất để giúp bác sĩ chẩn đoán, phát hiện và theo dõi các bệnh lý về tim mạch, tìm nguyên nhân bệnh tim để xử trí và điều trị kịp thời.
Tim co bóp theo điều khiển của một hệ thống dẫn truyền trong cơ tim. Các cực điện được đặt để ghi lại điện thế này và chuyển đến máy ghi. Máy ghi điện khuếch đại lên và ghi lại trên điện tâm đồ.
Khi không có tác động nào hiện hữu lên máy đo, máy sẽ ghi một đường thẳng nằm ngang gọi là đường đẳng điện.
Những chênh lệch trên đường đẳng điện gọi là sóng dương. Những chênh lệch dưới đường đẳng điện gọi là sóng âm.
**CHỈ ĐỊNH**
Phát hiện các bệnh về tim: rối loạn nhịp tim, suy tim, nhồi máu cơ tim, sự thay đổi cơ tim, viêm cơ tim...
Chẩn đoán một số thay đổi sinh hóa máu, các rối loạn điện giải ảnh hưởng đến tim.
Chẩn đoán một số ngộ độc thuốc: digoxin, chống trầm cảm 3 vòng…
**NHỮNG ĐIỀU CẦN BIẾT**
**Giấy đo ECG:**
Có nhiều cỡ giấy phù hợp cho các loại máy đo điện tim 1 cần, 3 cần và 6 cần Các cỡ giấy thường dùng:
50mm x 20m
50mm x 30m
60mm x 30m
63mm x 30m
145mm x 30mm
**MỘT SỐ LOẠI MÁY ĐO ĐIỆN TIM**
Hiện nay, người ta có thể đo điện tim bằng máy 1 cần (mỗi lần chỉ đo một chuyển đạo), 3 cần và 12 cần. Có loại máy đo và hình ảnh điện tim thể hiện trên màn hình vi tính. 
Máy điện tim hiện nay trên thị trường thường tích hợp chức năng tự động đọc kết quả.
Bút ghi bằng nhiệt được thiết kế gắn liền với máy in nhiệt.
Một số máy có màn hình hiển thị sóng điện tim, nhờ đó giúp người đo có thể xác nhận mức nhiễu trước khi in kết quả ra giấy.
**CÁC LOẠI ĐO ĐIỆN TIM ĐẶC BIỆT**
Cách đo điện tâm đồ thông thường nêu trên còn gọi là đo điện tâm đồ 12 chuyển đạo chuẩn. Bệnh nhân được đo lúc nghỉ ngơi và toàn bộ thời gian đo điện tim thường chỉ trong chưa đầy 1 phút. Nếu đo với máy điện tim 12 cần (cùng một lúc đo 12 chuyển đạo) thì chỉ mất vài giây. Do đó, với cách đo thông thường này nhiều lúc không phát hiện được những bệnh lý xảy ra không thường xuyên hoặc chỉ xuất hiện trong những điều kiện nhất định.
Các cách đo điện tâm đồ đặc biệt, chẳng hạn như đo điện tâm đồ gắng sức và Holter và theo dõi sự kiện, được sử dụng để chẩn đoán những loại bệnh như vậy.
**NGHIỆM PHÁP GẮNG SỨC**
Một số bệnh lý của tim chỉ xuất hiện khi tim đang hoạt động mạnh, cơ tim đòi hỏi oxy nhiều hơn. Để ghi nhận điều này, bệnh nhân được yêu cầu chạy trên thảm lăn, đạp xe đạp lực kế hoặc dùng thuốc. Tình trạng thiếu máu cơ tim sẽ biểu hiện ra bằng đau ngực và thay đổi trên điện tâm đồ. 
**_Điện tâm đồ Holter và theo dõi sự kiện_**
Máy đo điện tâm đồ Holter là máy ghi điện tim nhỏ gọn để bệnh nhân mang liên tục trên người, giúp ghi nhận hoạt động điện học của tim trong vòng 24 giờ. 
Máy đo điện tâm đồ theo dõi sự kiện cũng là máy ghi điện tim mang sẵn trên người. Khi cảm giác thấy hiện tượng bất thường, bệnh nhân sẽ nhấn nút ghi lại hoạt động điện của tim. Một số máy có thể tự động khởi động mỗi khi máy cảm thấy nhịp tim đập bất thường.
**CÁCH TÍNH TOÁN TRÊN GIẤY ĐIỆN TIM**
**Thời gian**
Tốc độ đo thông thường mặc định của các máy điện tim là 25mm/giây. Tốc độ này có thể thay đổi thành 50mm, 100mm/giây khi cần.
Với tốc độ giấy ghi điện tim là 25mm mỗi giây thì 1mm tương đương 0,04 giây
**Biên độ**
Điện thế chuẩn quy ước là 1mm chiều cao tương đương 0,1mV.
Trước mỗi chuyển đạo, máy sẽ nhảy điện thế chuẩn này để làm căn cứ tính biên độ của các sóng điện trên chuyển đạo đó. Máy sẽ thể hiện biên độ (chiều cao) 1mV của chuyển đạo đang được đo.
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh

## ️ Các xét nghiệm kiểm tra vi khuẩn HP dạ dày

  * [Các yếu tố lựa chọn chỉ định xét nghiệm HP](https://bvnguyentriphuong.com.vn/noi-tieu-hoa/cac-xet-nghiem-kiem-tra-vi-khuan-hp-da-day#cc-yu-t-la-chn-ch-nh-xt-nghim-hp)
  * [Các xét nghiệm kiểm tra vi khuẩn HP dạ dày](https://bvnguyentriphuong.com.vn/noi-tieu-hoa/cac-xet-nghiem-kiem-tra-vi-khuan-hp-da-day#cc-xt-nghim-kim-tra-vi-khun-hp-d-dy)
  * [Nội soi làm sinh thiết kiểm tra vi khuẩn HP](https://bvnguyentriphuong.com.vn/noi-tieu-hoa/cac-xet-nghiem-kiem-tra-vi-khuan-hp-da-day#ni-soi-lm-sinh-thit-kim-tra-vi-khun-hp)
  * [Xét nghiệm phân](https://bvnguyentriphuong.com.vn/noi-tieu-hoa/cac-xet-nghiem-kiem-tra-vi-khuan-hp-da-day#xt-nghim-phn)


## **Các yếu tố lựa chọn chỉ định xét nghiệm HP**
Có nhiều xét nghiệm giúp kiểm tra **vi khuẩn HP dạ dày** , để chọn đúng chỉ định bác sỹ tùy thuộc vào các yếu tố sau:
  * Điều kiện vật chất và kỹ thuật của cơ sở khám chữa bệnh: cơ sở khám chữa bệnh có những test kiểm tra vi khuẩn Hp trong dạ dày nào?
  * Yêu cầu xét nghiệm nhanh hay chậm: nếu bệnh không phải cấp tính và bệnh nhân có thể chờ đợi kết quả thì bác sỹ sử dụng các test chậm hơn như nuôi cấy vi khuẩn.
  * Các yêu cầu khác kèm theo việc kiểm tra nhiễm khuẩn Hp: bệnh nhân có cần kiểm tra tình trạng tổn thương dạ dày không, có cần làm xét nghiệm kháng sinh đồ không?


## **Các xét nghiệm kiểm tra vi khuẩn HP dạ dày**
Dựa trên các đặc điểm trên, bác sỹ sẽ quyết định làm một trong các xét nghiệm sau, hoặc làm kết hợp các test sau:
### **Nội soi làm sinh thiết kiểm tra vi khuẩn HP**
Bác sỹ dùng một ống nội soi nhỏ xâm nhập vào dạ dày qua ống thực quản tới dạ dày. Bác sỹ sẽ lấy một mảnh sinh thiết quanh vị trí có tổn thương dạ dày để làm xét nghiệm Clo Test hoặc nuôi cấy vi khuẩn, hoặc chỉ đơn giản là nhìn hình thái của tổn thương dạ dày, bác sỹ có thể chẩn đoán sơ bộ tình trạng nhiễm khuẩn HP của bệnh nhân.
Đối với xét nghiệm này, bác sỹ không những chẩn đoán chính xác được tình trạng nhiễm khuẩn HP trong dạ dày của bệnh nhân, đồng thời còn đánh giá được mức độ tổn thương, vị trí tổn thương và đưa ra các phán đoán về diễn biến của bệnh và phác đồ điều trị phù hợp nhất.
Chính vì vậy, sẽ không ngạc nhiên, nếu như bạn tới phòng khám với tình trạng đau dạ dày và rất có khả năng được bác sỹ chỉ định nội soi dạ dày. Đây là một thủ thuật không hề dễ chịu, nhưng đây lại là thủ thuật vô cùng quan trọng để đánh giá tình trạng tổn thương dạ dày mà không có xét nghiệm nào có thể làm được. Ngoài ra, nếu bạn đã từng điều trị vi khuẩn HP mà không thành công thì bác sỹ có thể chỉ định làm kháng sinh đồ để xem vi khuẩn HP đã kháng thuốc chưa, còn có thể sử dụng phác đồ thuốc nào dành cho bạn.
### **Test thở Ure**
Bạn sẽ được đưa một thiết bị và thở vào đó. Hiện nay có 2 dạng, test thở sử dụng bóng – thổi vào thiết bị giống quả bóng, test thở sử dụng thẻ – bạn thổi vào thiết bị giống 1 chiếc thẻ ATM. Sau đó hơi thở của bạn được đánh giá trên thiết bị phân tích và có chỉ số đánh giá xem bạn có dương tính với Hp hay không. Nếu dương tính với HP tức là bạn đã nhiễm HP, còn âm tính thì ngược lại.
Test thở này cũng cho kết quả rất chính xác và được khuyến khích sử dụng trên mọi đối tượng do test diễn ra nhanh, bệnh nhân không bị can thiệp, có thể dùng dễ dàng trên trẻ em. Tuy nhiên, chi phí 1 test này ở Việt Nam thường nằm trong khoảng 400.000 – 600.000 thậm chí cao hơn, tùy vào cơ sở khám, thiết bị khám, cho nên không phải ai cũng có điều kiện để chi trả. Test hơi thở này đặc biệt hữu ích đối với những người đã điều trị vi khuẩn Hp và cần đánh giá lại hiệu quả tiệt trừ Hp.
Bạn cũng cần lưu ý, hiện nay có 2 loại test thở khác nhau, 1 loại sử dụng C13 (Carbon 13), một loại sử dụng C14 (Carbon14) có giá thành khác nhau và đối tượng chỉ định cũng có khác nhau. Loại sử dụng C14 có giá thành rẻ hơn nhưng C14 là yếu tố phóng xạ cho nên hạn chế sử dụng trên đối tượng trẻ em dưới 6 tuổi và phụ nữ trong độ tuổi sinh đẻ. Trước khi thăm khám và kiểm tra ở các cơ sở, bạn hoàn toàn có thể yêu cầu được biết loại xét nghiệm mình làm là C13 hay C14 để có quyết định phù hợp. Do tính chất, test thở là loại test mới ở Việt Nam, nên có ít thông tin tra cứu, vì vậy bạn cần trang bị kiến thức để tránh ảnh hưởng tới sức khỏe của mình.
### **Xét nghiệm phân**
Vi khuẩn HP nếu có trong dạ dày sẽ được thải trừ thường xuyên qua phân. Xét nghiệm phân bằng phản ứng miễn dịch huỳnh quang giúp phát hiện vi khuẩn Hp trong phân một cách chính xác. Đây cũng là một xét nghiệm chính xác, được ưu tiên sử dụng trong đánh giá nhiễm khuẩn HP.
Mặc dù dễ dàng thực hiện đối với bệnh nhân, kết quả chính xác, chi phí hợp lý nhưng test này không cho kết quả nhanh chóng nên không phải là test nhanh. Ngoài ra, việc lấy phân đi xét nghiệm cũng còn nhiều vấn đề về vệ sinh, tiện lợi cho người bệnh và kỹ thuật viên.
### **Xét nghiệm máu**
Khi bạn nhiễm khuẩn HP, cơ thể bạn sẽ sinh ra kháng thể kháng HP, loại kháng thể này được lưu hành trong máu và có thể phát hiện được bằng xét nghiệm kháng thể trong máu. Test này có mặt ở hầu hết các cơ sở khám chữa bệnh cấp tỉnh, thành phố trên cả nước.
Tuy nhiên, đây không phải loại xét nghiệm được ưu tiên thực hiện, chỉ những cơ sở không có phương pháp xét nghiệm nào khác mới thực hiện xét nghiệm này. Lý do là vì vi khuẩn HP có thể tồn tại ở một số khu vực khác như khoang miệng, xoang, đường ruột nhưng hoàn toàn không gây bệnh. Lý do thứ hai là mặc dù vi khuẩn HP trong dạ dày đã bị tiệt trừ hết, tuy nhiên, kháng thể kháng HP vẫn có thể lưu hành trong máu trong thời gian một vài tháng tới một vài năm sau đó. Nếu dựa vào đó để chẩn đoán nhiễm HP rất dễ xảy ra tình trạng dương tính giả.
## **Kết luận**
Trên đây là một số test thường được sử dụng để **kiểm tra nhiễm vi khuẩn HP dạ dày** nhất. Mỗi loại xét nghiệm sẽ có ưu, nhược điểm khác nhau. Bác sỹ sẽ chỉ định cho bạn loại xét nghiệm phù hợp khi bạn đi thăm khám. Tuy nhiên, bạn cần trang bị kiến thức tổng quan như trên để tránh những lo lắng không cần thiết, cũng như hiểu hơn về tình trạng nhiễm khuẩn HP của mình cũng như tự bảo vệ mình trước các thông tin truyền miệng, thông tin trên các phương tiện truyền thông đại chúng về xét nghiệm HP.
Xem thêm: [**Vi khuẩn HP và bệnh lý dạ dày**](https://www.youtube.com/watch?v=GGKPX13IdUI)
**Bệnh viện Nguyễn Tri Phương** - Bệnh viện Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [Các yếu tố lựa chọn chỉ định xét nghiệm HP](https://bvnguyentriphuong.com.vn/noi-tieu-hoa/cac-xet-nghiem-kiem-tra-vi-khuan-hp-da-day#cc-yu-t-la-chn-ch-nh-xt-nghim-hp)
  * [Các xét nghiệm kiểm tra vi khuẩn HP dạ dày](https://bvnguyentriphuong.com.vn/noi-tieu-hoa/cac-xet-nghiem-kiem-tra-vi-khuan-hp-da-day#cc-xt-nghim-kim-tra-vi-khun-hp-d-dy)
  * [Nội soi làm sinh thiết kiểm tra vi khuẩn HP](https://bvnguyentriphuong.com.vn/noi-tieu-hoa/cac-xet-nghiem-kiem-tra-vi-khuan-hp-da-day#ni-soi-lm-sinh-thit-kim-tra-vi-khun-hp)
  * [Xét nghiệm phân](https://bvnguyentriphuong.com.vn/noi-tieu-hoa/cac-xet-nghiem-kiem-tra-vi-khuan-hp-da-day#xt-nghim-phn)



## ️ Các bước căn bản đọc điện tim

**CÁC BƯỚC ĐỌC ĐIỆN TÂM ĐỒ**
Thông thường, đọc điện tim nên thực hiện theo các bước sau:
**Nhận xét chung**
Nhịp tim
Tần số
Trục, tư thế và góc điện tim
Sóng P
Khoảng PR 
Phức bộ QRS
Đoạn ST
Sóng T
Khoảng QT
Sóng U
**Kết luận**
Dựa trên nhận xét để rút ra những hội chứng rồi xác định bệnh lý.
**NHỊP TIM (RHYTHM)**
Nhịp bình thường gọi là nhịp Xoang, được tạo ra bởi xung động điện hình thành trong nút xoang nhĩ.
**Nhịp xoang đặc trưng bởi:**
Sóng P đồng dạng trên cùng một chuyển đạo.
Sóng P (+) ở DII, aVF; P (-) ở aVR
Mỗi sóng P đi kèm với một QRS
PR/PQ hằng định và trong giới hạn 0,12- 0,20s
PP dài nhất – PP ngắn nhất < 0,16s
**Nhận xét nhịp cần đánh giá**
Nhịp cơ bản có phải nhịp xoang không
Nhịp có đều hay không
**TẦN SỐ (RATE)**
Tần số của tim được xác định dễ dàng bằng cách đếm số ô vuông lớn giữa 2 chu chuyển tim. 
Bình thường nhịp xoang có tần số từ 60-100 lần/phút.
**Cách tính tần số tim**
Với tốc độ đo thông thường là 25m/s thì
1giây = 5 x 0,20s # 5 ô lớn
1 phút = 60giây x 5 ô/giây # 300 ô lớn
Như vậy 300 ô lớn (1 phút) có N phức bộ QRS, nghĩa là nhịp tim có tần số N lần/phút
**Công thức tính Tần số tim**
Để đơn giản, Tần số của tim được xác định bằng cách đếm số ô vuông lớn giữa 2 chu chuyển tim, sau đó lấy 300 chia cho số ô lớn này
**Tần số Tim = 300 / Số ô lớn**
Muốn tính chính xác hơn thì đo một khoảng RR tính ra giây, rồi lấy 60 chia cho nó: 
**Tần số Tim = 60/RR giây**
Khi nhịp tim không đều, RR là trung bình cộng của một số khoảng RR độ dài khác nhau. Nên chọn một sóng R có đỉnh rơi đúng vào đường kẻ đậm để tính.
Trường hợp có bloc nhĩ-thất, các sóng P và R tách rời nhau ra, thì phải tính tần số nhĩ (P) riêng và tần số thất (R) riêng.
Hoặc nếu có rung nhĩ, cuồng nhĩ thì nên tính tần số các sóng f hay F.
Tần số < 60 chu kỳ/phút gọi là nhịp Chậm 
Tần số >100 chu kỳ/phút gọi là nhịp Nhanh
**TRỤC ĐIỆN TIM VÀ GÓC ALPHA**
**Trục điện tim**
Trục điện của tim là hướng trung bình của điện thế hoạt động đi qua tâm thất trong quá trình kích hoạt thất (khử cực). 
Trục điện tim được xác định bằng QRS, dựa vào biên độ đại số của các vectơ đo được tại các chuyển đạo ngoại biên
Để dễ tính, người ta thường đo biên độ tại DI và aVF (2 chuyển đạo vuông góc nhau) mà xác định trục và góc α của trục điện tim.
Tính biên độ của QRS
Q= - 2 mm
R= 23,5 mm
S= - 3 mm
Cộng = 18,5 mm
Trục DI và aVF chia thành 4 vùng và được gọi tên như sau:
Bảng 4.1. Cách xác định tên gọi trục điện tim
Sau đây là hình ảnh mô tả các phân vùng của trục điện tim
**Góc Alpha**
**Tính chính xác (phương pháp vector):**
Khi đã có biên độ đại số của DI và aVF, dùng hình vẽ quy chiếu để xác định trục điện tim và góc α.
Cũng có thể dùng công thức sau đây nhập vào một trình ứng dụng (ví dụ MS Excel) để tính góc α: 
**Tính ước lệ:**
Trên thực tế khi đọc điện tâm đồ, chúng ta chỉ cần tính ước lệ góc α. Để ước lệ tương đối chính xác, chúng ta có thể áp dụng những điều sau đây, theo thứ tự ưu tiên:
Chọn chuyển đạo nào biên độ đại số gần bằng 0, trục điện tim sẽ vuông góc với chuyển đạo ấy.
Ví dụ: Chuyển đạo aVL (-30º) ≈ 0 thì trục điện tim sẽ gần trùng với chuyển đạo DII (60º)
Tương tự như vậy, biên độ đại số chuyển đạo nào lớn nhất thì trục điện tim gần chuyển đạo đó nhất. Chọn hai chuyển đạo đối xứng với trục điện tim giả định, biên độ đại số của chuyển đạo nào lớn hơn thì trục điện tim nghiêng về chuyển đạo đó (gần chuyển đạo đó hơn). 
Ví dụ: Giả sử trục điện tim giả định gần trùng với trục DII thì chọn chuyển đạo DI và chuyển đạo DIII để so sánh. Nếu chuyển đạo DIII có biên độ đại số lớn hơn thì trục điện tim lệch về DIII nghĩa là góc α > 45º. 
Dễ dàng nhận thấy rằng đối xứng qua DI là aVL và aVR; đối xứng qua DII là DI và DIII; đối xứng qua DIII là DI và DII; đối xứng qua aVF là DII và DIII và đối xứng qua aVL là aVF và aVR
**SÓNG P**
**Khái niệm**
Là sóng đầu tiên của ECG và chỉ ra hoạt động lan truyền xung động điện ngang qua nhĩ (khử cực và tái cực nhĩ).
Sóng P dùng để xác định xem nhịp tim có xuất phát từ nút xoang (nhịp xoang) hay không.
**Bình thường**
Sóng P có hình vòm (smooth), không nhọn và không có khấc (notch).
P (+) ở DI, DII, V4-V6 và aVF.
P (-) ở aVR.
P thay đổi ở DIII, aVL và các chuyển đạo trước tim khác.
Trục sóng P từ 0 đến +75º
Thời gian 0,06-0,12s (< 3 ô nhỏ)
Biên độ 0,05-0,25 mV (< 2,5 ô nhỏ).
**Đánh giá**
Có sóng P không?
Sóng P có xuất hiện thường xuyên hay không?
Hình dạng sóng P có giống nhau trên cùng một chuyển đạo không?
Mỗi sóng P có đi kèm một phức bộ QRS hay không?
Biên độ và thời gian sóng P có trong giới hạn bình thường hay không?
**KHOẢNG PR/PQ:**
**Khái niệm**
Được tính từ thời điểm khởi đầu sóng P đến điểm bắt đầu phức bộ QRS.
Đây là thời gian cần thiết để xung động truyền từ nhĩ qua nút nhĩ thất đến các sợi tế bào cơ tâm thất (mạng lưới Purkinje)
Phần lớn thời gian khoảng PR phản ánh hiện tượng dẫn truyền chậm qua nút nhĩ thất.
**Bình thường**
Thời gian từ 0,12 - 0,20s (ở tốc độ 25mm/giây là 3-5 ô nhỏ) và không đổi;
Thời gian dẫn truyền này bị ảnh hưởng bởi hệ giao cảm và phó giao cảm, do đó khoảng PR thay đổi theo nhịp tim: khi nhịp tim nhanh - khoảng PR ngắn hơn là khi nhịp tim chậm; 
Khoảng PR cũng dài hơn ở những bệnh nhân lớn tuổi.
**Đánh giá**
**PQ kéo dài:**
Bloc nhĩ thất (do suy động mạch vành, thấp tim…)
Một vài trường hợp khác có thể gặp như hạ kali máu, viêm cơ tim, cường giáp…
**PQ ngắn lại:**
Nhịp bộ nối
Hội chứng Wolff-Parkinson-White
Hội chứng Lown-Ganong-Levine
Có thể ở bệnh nhân tăng huyết áp
Bệnh Fabry (lbệnh chuyển hóa do rối loạn di truyền, gây ra bởi sự thiếu hụt enzyme α-galactosidase A hoặc alpha GAL-locus gen trên nhiễm sắc thể X)
U tủy thượng thận
**Phân biệt: Đoạn PR/PQ**
Đoạn PR/RQ đại diện cho giai đoạn của quá trình tái cực tâm nhĩ, được tính từ thời điểm kết thúc sóng P đến điểm bắt đầu phức bộ QRS.
Nó rất hữu ích trong việc xác định bệnh lý của nút nhĩ thất và là phương tiện để chẩn đoán nhồi máu nhĩ.
Trong viêm màng ngoài tim, vị trí PR hạ thấp phổ biến nhất là ở DII (55,9%). Trong viêm màng ngoài tim, PR chênh xuống ở bất kỳ chuyển đạo nào có độ nhạy cao (88,2%), nhưng độ đặc hiệu khá thấp (78,3%). Tuy nhiên hiện tượng này hiếm thấy ở nhồi máu cơ tim có ST chênh lên nên được dùng để chẩn đoán phân biệt.
**PHỨC BỘ QRS:**
**Khái niệm**
Phức bộ QRS là thành phần quan trọng nhất của điện tâm đồ. 
Nó biểu hiện sự lan truyền xung động ngang qua cơ thất (khử cực và co thất). 
Dù hình dạng QRS trên các chuyển đạo có khác nhau nhưng thời gian là như nhau.
**Quy ước:**
Sóng âm khởi đầu là sóng Q;
Sóng dương đầu tiên là sóng R 
Sóng âm đi sau sóng R là sóng S …
Các sóng đi sau đó được gọi là R‟, S‟…
Nếu sóng có biên độ nhỏ thì được ký hiệu bằng chữ thường
**Bình thường**
Bình thường từ 0,05 - 0,10s. 
QRS > 0,12s là biểu hiện bất thường.
**Biên độ**
Tính từ đỉnh sóng dương cao nhất đến sóng âm nhất.
Điện thế QRS thấp bất thường khi tổng biên độ nhỏ hơn 5mm ở các chuyển đạo chi và nhỏ hơn 10 mm ở các chuyển đạo trước tim (hay nhỏ hơn 5mm ở V1V6, nhỏ hơn 7mm ở V2-V5 và nhỏ hơn 9mm ở V3-V4).
**Sóng Q**
Thời gian sóng Q bình thường < 0,03s.
Có sóng q ở V5-V6, nếu mất đi sóng q ở V5-V6 được xem là bất thường.
Có thể gặp sóng Q ở aVR và DIII
**Sóng R**
Bình thường tăng dần biên độ từ V1 → V4 hay V5. Việc mất đi diễn tiến này của sóng R có thể chỉ ra bất thường.
R cao ở V5, V6 gặp trong lớn thất trái; sóng R giảm dần biên độ từ V1 → V5 có thể chỉ ra bệnh lý NMCT.
**Biến thiên ở các chuyển đạo trước tim**
R tăng dần biên độ từ V1 → V3 hay V4 sau đó hạ thấp dần
S tăng dần biên độ từ V1 → V2 hay V3 sau đó giảm dần biên độ
V3, V4 còn được gọi là vùng chuyển tiếp
**ĐOẠN ST**
**Khái niệm**
Đây là khoảng thời gian cơ tâm thất còn trong giai đoạn khử cực, được tính từ cuối QRS (điểm J) đến đầu sóng T.
Điểm quan trọng nhất của đoạn ST chính là sự thay đổi vị trí của nó so với đường đẳng điện (ST level) và hình dạng của đoạn ST (ST shape).
**Bình thường**
Bình thường đoạn ST thường nằm ngang với đoạn TP (đường đẳng điện) hay chênh rất ít. 
Đôi khi đoạn ST nâng lên cao nhưng dưới 1mm ở chuyển đạo chi và dưới 2mm ở chuyển đạo trước ngực, nhưng không bao giờ nằm dưới đường đẳng điện trên 0,5 mm.
**SÓNG T**
**Khái niệm**
T là sóng biểu hiện thời gian hồi phục (tái cực) của các tâm thất.
Thời gian từ đầu QRS đến đỉnh của sóng T được gọi là thời gian trơ tuyệt đối. Nửa cuối của sóng T được gọi là thời gian trơ tương đối. 
**Đánh giá**
Cần chú ý đến 3 đặc điểm của sóng T: Direction - Shape - Height.
**Chiều**
Luôn Dương ở DI, DII, V3, V4, V5, V6 và Âm ở aVR.
Thay đổi ở DIII, aVL, aVF, V1 và V2.
Sóng T dương ở aVL và aVF nếu QRS cao hơn 5mm
Đảo ngược sóng T (sóng T âm) có thể là một dấu hiệu của thiểu năng vành, hội chứng Wellens, phì đại thất trái, hoặc rối loạn thần kinh trung ương.
**Hình dạng (Shape)**
Hình hơi tròn và không đối xứng. Sóng T có khấc (notch) thường gặp ở trẻ con bình thường, nhưng đôi khi gặp trong viêm màng ngoài tim. 
Sóng T nhọn và đối xứng (dương hoặc âm) nghi ngờ NMCT.
**Độ cao (Height)**
Bình thường không quá 5mm ở chuyển đạo chuẩn và không quá 10mm ở chuyển đạo trước tim. So với biên độ của phức bộ QRS đi trước biên độ sóng T không quá 1/3.
Sóng T cao gợi ý bệnh lý động mạch vành, tăng Kali, tai biến mạch não.
**Thời gian của sóng T:** không có vai trò quan trọng.
**KHOẢNG QT**
**Khái niệm**
Khoảng QT được tính từ đầu phức bộ QRS đến cuối sóng T, là thời gian hoạt hóa và hồi phục tâm thất. 
QT giảm đi khi nhịp tim gia tăng, do đó khoảng QT phải được điều chỉnh theo nhịp tim gọi là QT hiệu chỉnh (corrected QT) và được ký hiệu là QTc.
**Cách đo QT**
Khoảng QT được đo ở DII hoặc V5-6
Nếu có sóng U > 1mm đi liền sóng T thì đo chung vào QT
Nếu sóng U < 1mm hoặc tách biệt với sóng T thì không gộp chung vào QT
Phương pháp đánh chặn độ dốc tối đa được sử dụng để xác định sự kết thúc của sóng T
**Đánh giá**
Khoảng QT tỷ lệ nghịch với nhịp tim. QT kéo dài đồng nghĩa có bất thường. QTc của Bazett > 0,54s có nguy cơ biến cố tim mạch tăng 1,7 lần.
QTc hiệu chỉnh bằng khoảng 0,64s có nguy cơ biến cố tim mạch tăng 2,8 lần.
**QT kéo dài:** QT kéo dài là một dấu hiệu tiềm tàng của loạn nhịp nhanh thất như xoắn đỉnh và là yếu tố nguy cơ đột tử. Có 4 nguyên nhân chính
Bất thường điện giải: Hạ kali máu và giảm calci máu
Thuốc: liên quan đến xoắn đỉnh
**Các thuốc có thể gây QT kéo dài**
Nhóm thuốc chống loạn nhịp Ia: quinidine, procainamide, disopyramide
Nhóm thuốc chống loạn nhịp Ic: propafenone)
Thuốc chống loạn nhịp nhóm III: amiodarone, bretylium, dofetilide, n-acetyl-procainamide, sematilide, sotalol
Nhóm thuốc tâm thần: thuốc chống trầm cảm ba vòng, thuốc chống trầm cảm tetracyclic,
phenothiazin, haloperidol
Thuốc kháng histamin: astemizol, terfenadin
Kháng sinh: erythromycin, trimethoprimsulfamethoxazole
Thuốc kháng nấm: ketoco-nazole, itraconazole
Nhóm đối kháng Serotonin: ketanserin, zimeldine 
Hóa trị liệu: pentamidine, có thể anthracyclines 
Thuốc khác: bepridil, cisapride, prednisone, prenylamine, probucol, chloral hydrate…
Chất độc: thuốc trừ sâu lân hữu cơ, anthopleurinnA, chế độ ăn protein lỏng, một số loại thảo mộc
Bẩm sinh hội chứng QT dài: hội chứng QT kéo dài bẩm sinh rất hiếm, nhưng nếu xác định sẽ giúp điều trị sớm. Cần lưu ý ở bệnh nhân trẻ, những người có biểu hiện ngất hoặc tiền ngất.
Các nguyên nhân khác: Bloc nhĩ thất độ 3 (đôi khi độ 2), nhịp thất, phì đại thất trái, nhồi máu cơ tim tiến triển, thiếu máu cơ tim, tai biến mạch máu não (xuất huyết dưới nhện), hạ thân nhiệt nặng.
**QT ngắn:**
Tăng calci máu
Dùng digoxin
Cường giáp
Tăng trương lực giao cảm
Hội chứng QT ngắn bẩm sinh có liên quan với tăng nguy cơ rung nhĩ và rung thất kịch phát và đột tử do tim.
**SÓNG U**
**Khái niệm**
Nguồn gốc sóng U còn chưa chắc chắn 
Có thể là hiện tượng tái cực của các cấu trúc nội mạc như là cơ nhú hay của bó His và mạng lưới Purkinje.
Đánh giá
Bình thường không gặp trên ĐTĐ, nếu có là một sóng nhỏ đi sau sóng T và thường quan sát tốt ở V2 và V3.
Sóng U thường cùng hướng với sóng T, có biên độ bình thường tối đa là 1-2 mm và nhỏ hơn ¼ sóng T. Kích thước sóng U tỷ lệ nghịch với nhịp tim (sóng U lớn hơn khi nhịp tim chậm lại)
Sóng U cao thường gặp trong hạ Kali máu. Sóng U cũng có thể hiện diện trong hạ calci hoặc magne máu, cường giáp, hạ thân nhiệt, tăng áp lực nội sọ, cơ tim phì đại và hội chứng QT kéo dài bẩm sinh, sa van hai lá.
Các loại thuốc có thể gây ra hình ảnh sóng U nổi bật: digoxin, epinephrine, phenothiazin (thioridazine), thuốc chống loạn nhịp nhóm Ia (quinidine, procainamide) và nhóm III (sotalol, amiodarone)
Sóng U đảo ngược trong nhồi máu cơ tim, đau thắt ngực hoặc thiếu máu cục bộ do gắng sức, co thắt động mạch vành (đau thắt ngực Prinzmetal), đi sau ngoại tâm thu ở bệnh nhân bệnh mạch vành hoặc nguyên nhân không thiếu máu cơ tim.
**Thành phần** |  **Bình thường** |  |   
---|---|---|---  
**Sóng P** |  Thời gian: < 0,12s Biên độ: < 0,25 mV |  Thời gian > 0,12s: dày nhĩ trái |  Biên độ > 0,25mV: dày nhĩ phải  
**Khoảng PQ** |  Thời gian: 0,12 - 0,20s |  Thời gian > 0,20s: Bloc nhĩ thất  Hạ kali máu, viêm cơ tim, cường giáp… |  Thời gian < 0,12s: Nhịp bộ nối Hội chứng kích thích sớm U tủy thượng thận  
Biên độ: đẳng điện |  Chênh xuống: viêm màng ngoài tim giai đoạn 1  
**Sóng Q** |  < 25% R  |  Sâu > 1mm  Thời gian: > 0,03s  Nhồi máu cơ tim hiện tại hoặc trước đó. |  Sóng Q vắng mặt ở V5, V6 thường do bloc nhánh Trái.  
**Phức bộ QRS** |  Thời gian: 0,05 - 0,10s |  Thời gian > 0,10s: Bloc nhánh Nhịp thất |  Bình thường  
**Đoạn ST** |  Chênh lên: < 1mm CĐ chi  < 2mm CĐ trước ngực Chênh xuống < 0,5mm |  Tổn thương cơ tim Các rối loạn tái cực |  Bình thường  
**Sóng T** |  Biên độ: < 2/3 QRS |  Cao:  Bệnh lý động mạch vành Tăng Kali, tai biến mạch não Cường giao cảm |  Thấp:  Thiếu máu cơ tim Hạ Kali Viêm màng ngoài tim mãn  
**Khoảng QT** |  < ½ RR |  Dài: > 0,4s Bất thường điện giải: Hạ kali máu, giảm calci máu Thuốc: liên quan đến xoắn đỉnh |  Ngắn: Tăng calci máu Dùng digoxin Cường giáp Tăng trương lực giao cảm  
**Sóng U** |  Biên độ bằng 10% T hoặc < 1.5mm |  Cao: Hạ Kali máu.  Cường giáp, hạ thân nhiệt, tăng áp lực nội sọ, cơ tim phì đại và hội chứng QT kéo dài bẩm sinh,  Thuốc: digoxin, thuốc chống loạn nhịp nhóm Ia  |  Nhồi máu cơ tim, thiếu máu cục bộ, đau thắt ngực Prinzmetal Sau ngoại tâm thu ở bệnh nhân bệnh mạch vành  Nguyên nhân không thiếu máu cơ tim.  
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh

## ️ Giải thích một số cận lâm sàng hay gặp khi đi khám bệnh

  * [Viêm gan siêu vi B](https://bvnguyentriphuong.com.vn/khoa-kham-benh/giai-thich-mot-so-can-lam-sang-hay-gap-khi-di-kham-benh#vim-gan-siu-vi-b)
  * [Chụp X Quang phổi](https://bvnguyentriphuong.com.vn/khoa-kham-benh/giai-thich-mot-so-can-lam-sang-hay-gap-khi-di-kham-benh#chp-x-quang-phi)
  * [Phết tế bào cổ tử cung (Pap’s mear)](https://bvnguyentriphuong.com.vn/khoa-kham-benh/giai-thich-mot-so-can-lam-sang-hay-gap-khi-di-kham-benh#pht-t-bo-c-t-cung-paps-mear)
  * [Phương pháp chẩn đoán này được Hiệp Hội Phòng chống bệnh Hoa Kỳ khuyến cáo để tầm soát ung thư vú. Trên 40 tuổi nếu là nữ, bạn nên chụp nhũ ảnh mỗi năm. Chụp nhũ ảnh chính xác và nhạy hơn siêu âm vú. Kiểm tra sớm nhằm phát hiện những bất thường của vú để phòng bệnh và điều trị kịp thời bệnh ung thư vú.](https://bvnguyentriphuong.com.vn/khoa-kham-benh/giai-thich-mot-so-can-lam-sang-hay-gap-khi-di-kham-benh#phng-php-chn-on-ny-c-hip-hi-phng-chng-bnh-hoa-k-khuyn-co-tm-sot-ung-th-v-trn-40-tui-nu-l-n-bn-nn-chp-nh-nh-mi-nm-chp-nh-nh-chnh-xc-v-nhy-hn-siu-m-v-kim-tra-sm-nhm-pht-hin-nhng-bt-thng-ca-v-phng-bnh-v-iu-tr-kp-thi-bnh-ung-th-v)
  * [Tầm soát ung thư tuyến tiền liệt (PSA )](https://bvnguyentriphuong.com.vn/khoa-kham-benh/giai-thich-mot-so-can-lam-sang-hay-gap-khi-di-kham-benh#tm-sot-ung-th-tuyn-tin-lit-psa-)
  * [Nội soi cổ tử cung](https://bvnguyentriphuong.com.vn/khoa-kham-benh/giai-thich-mot-so-can-lam-sang-hay-gap-khi-di-kham-benh#ni-soi-c-t-cung)
  * [Nội soi dạ dày - trực tràng - đại tràng](https://bvnguyentriphuong.com.vn/khoa-kham-benh/giai-thich-mot-so-can-lam-sang-hay-gap-khi-di-kham-benh#ni-soi-d-dy-trc-trng-i-trng)


## **Công thức máu**
[**Công thức máu**](https://bvnguyentriphuong.com.vn/xet-nghiem/xet-nghiem-cong-thuc-mau-toan-bo) là 1 xét nghiệm thường qui, cung cấp cho chúng ta nhiều giá trị trong các bệnh lý thường gặp như bệnh nhiễm trùng, ung thư máu… và đặc biệt là xem có tình trạng thiếu máu hay không. Đây là bệnh thường gặp ở VN chúng ta, nguyên nhân gặp là do ký sinh trùng. Thiếu máu làm cho chúng ta có cảm giác mệt mỏi, chóng mặt, mau mệt, giảm khả năng tập trung và ảnh hưởng đến năng suất làm việc. Việc phát hiện và điều trị sớm giúp cho bệnh nhân mau hồi phục sức khỏe.
## **Đường huyết**
Bệnh tiểu đường do rối loạn chuyển hoá, khi nền kinh tế phát triển thì tỷ lệ mắc bệnh tiểu đường trong cộng đồng cũng tăng theo. Trong giai đoạn sớm của bệnh, thường không có triệu chứng. Việc phát hiện sớm giúp rất nhiều trong việc điều trị nhằm ngăn ngừa những biến chứng nguy hiểm của bệnh như là tổn thương mắt, thận, tim mạch và hệ thần kinh.
##  **Cholesterol**
Theo như khuyến cáo của hiệp hội im mạch của Úc cho rằng tất cả những người trên 20 tuổi nên kiểm tra cholesterol trong máu, vì nồng độ cholesterol tăng cao làm tăng nguy cơ phát triển bệnh mạch vành. Vì vậy việc tầm soát và điều trị kịp thời sẽ hạn chế nguy cơ bệnh mạch vành.
## **Chức năng gan**
Gan đóng vai trò quan trọng trong cơ thể như là chức năng lọc máu, bài tiết mật, chuyển hoá các chất lipid, protein, carbonhydrat, dự trữ vitamin và muối khoáng Khi nền kinh tế phát triển con người phải giao tiếp và làm việc nhiều dễ phát sinh những bệnh lý gan thường gặp như là Viêm gan do siêu vi, viêm gan do rượu, viêm gan do ký sinh trùng, gan nhiễm mỡ…Vì vậy việc phát hiện sớm và điều trị kịp thời sẽ hạn chế những nguy hiểm của những biến chứng xơ gan, ung thư gan.
## **Chức năng thận**
Những bệnh lý về thận ở giai đoạn sớm không có triệu chứng, và đặc biệt là bệnh cao huyết áp lâu ngày và điều trị không triệt để sẽ có ảnh hưởng lên thận. Vì vậy việc khám và phát hiện sớm chức năng thận giúp cho chúng ta kiểm soát bệnh 1 cách hiệu quả hơn.
## **Viêm gan siêu vi B**
Việt Nam là 1 nước nằm trong vùng có tỷ lệ lưu hành bệnh cao, theo như Hội Gan Mật, tỷ lệ lưu hành siêu vi B trong cộng đồng vào khoảng 10 - 15 %. Viêm gan siêu vi B có thể đưa đến biến chứng như là ung thư gan và xơ gan rất cao, tuy nhiên rất may mắn chúng ta đã có thuốc chủng ngừa bệnh siêu vi B, và thuốc điều trị bệnh rất hiệu quả. Vì vậy việc xét nghiệm này giúp chúng ta ngăn ngừa bệnh tật bằng cách chích ngừa cho những ai không bị mắc bệnh và điều trị cho những ai đang bị mắc bệnh.
## **Chụp X Quang phổi**
Lao phổi và những bệnh lý tắc nghẽn phổi mãn tính do hút thuốc lá và bụi công nghiệp là những bệnh lý thường gặp ở nước ta. Việc thăm khám bệnh và chụp hình phổi là những biện pháp đơn giản dể thực hiện nhằm giúp cho chúng ta phát hiện sớm và ngăn ngừa hậu quả của nó.
## **Phết tế bào cổ tử cung (Pap’s mear)**
Ung thư cổ tử cung là 1 bệnh lý rất nguy hiểm, đứng hàng thứ nhất trong ung thư đường sinh dục nữ. Nếu được phát hiện sớm và điều trị kịp thời sẽ hạn chế tỷ lệ tử vong và thương tật. Theo Hiệp Hội Ung Thư Mỹ khuyến cáo nên làm thường qui nhằm phát hiện sớm và điều trị kịp thời căn bệnh nguy hiểm nầy.
## **Siêu âm bụng**
Là 1 phương pháp đơn giản, rất kinh tế nhằm phát hiện những thay đổi bất thường trong ổ bụng, như là bệnh lý gan mật, thận, lá lách, tuỵ… Là 1 phương pháp mang tính chất tầm soát rất hữu hiệu.
## **Đo điện tim**
Nhằm phát hiện những thay đổi bất thường ở tim do các bệnh lý tim mạch gây nên , có những trường hợp cao huyết áp mà bệnh nhân không phát hiện (như là không đo huyết áp kiểm tra, không khám sức khỏe định kỳ), lâu ngày ảnh hưởng lên tim. Vì vậy việc đo điện tim nhằm giúp cho chúng ta phát hiện bệnh cao huyết áp cũng như biến chứng của các bệnh tim mạch.
## **Siêu âm ngực**
Ngoài việc khám phụ khoa và làm pap’s mear để phát hiện sớm bệnh ung thư cổ tử cung. Ở phụ nữ cũng nên làm thêm siêu âm ngực kiểm tra nhằm phát hiện sớm những thay đổi cấu trúc, những bất thường ở ngực để phòng bệnh và điều trị kịp thời bệnh ung thư vú
## **Đo loãng xương**
Loãng xương liên quan đến các yếu tố: tuổi, tình trạng thể lực, chất dinh dưỡng kém, mãn kinh sớm, tuổi bắt đầu kinh muộn. Đây là bệnh của cả hai giới, tỷ lệ ở nam có cao hơn, nhất là ở nam giới hút thuốc lá và uống rượu. là một trong những hình thức kiểm tra tình trạng sức khỏe của xương mà từ đó để ngăn ngừa và điều trị kịp thời bệnh Loãng xương.
##  **Chụp nhũ ảnh**
## Phương pháp chẩn đoán này được Hiệp Hội Phòng chống bệnh Hoa Kỳ khuyến cáo để tầm soát ung thư vú. Trên 40 tuổi nếu là nữ, bạn nên chụp nhũ ảnh mỗi năm. chính xác và nhạy hơn siêu âm vú. Kiểm tra sớm nhằm phát hiện những bất thường của vú để phòng bệnh và điều trị kịp thời bệnh ung thư vú.
## **Tầm soát ung thư tuyến tiền liệt (PSA )**
Xét nghiệm nầy được Viện Ung Thư Hoa kỳ khuyến cáo nên làm mỗi năm cho nam giới trên 50 tuổi. Đây là một trong những ung thư hay gặp ở nam giới. Nếu phát hiện sớm, việc điều trị trở nên hữu hiệu hơn.
## **Nội soi cổ tử cung**
Theo Tổ chức Y Tế Thế giới (WHO), ung thư cổ tử cung là nhóm bệnh chủ yếu gây tử vong 54 % trong tổng số bệnh nhân ở thế kỷ nầy. Vì thế soi cổ tử cung để tầm soát viêm và ung thư rất cần thiết nhằm phát hiện sớm và điều trị đúng, có thể chửa khỏi và không bị tái phát.
## **Nội soi dạ dày - trực tràng - đại tràng**
Ung thư dạ dày - trực tràng - là bệnh lý phổ biến và đứng hàng thứ hai trong các ung thư tiêu hoá. Nội soi nhằm phát hiện và cắt bỏ sớm các polyps, đây là những khối tiền ung thư. Việc tầm soát nầy làm giảm đáng kể tỷ lệ tử vong gây ra do bệnh ung thư đại trực tràng.
Tìm hiểu thêm: [**Ý nghĩa các thông số trong xét nghiệm nước tiểu**](https://bvnguyentriphuong.com.vn/xet-nghiem/y-nghia-cac-thong-so-trong-xet-nghiem-nuoc-tieu)
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [Viêm gan siêu vi B](https://bvnguyentriphuong.com.vn/khoa-kham-benh/giai-thich-mot-so-can-lam-sang-hay-gap-khi-di-kham-benh#vim-gan-siu-vi-b)
  * [Chụp X Quang phổi](https://bvnguyentriphuong.com.vn/khoa-kham-benh/giai-thich-mot-so-can-lam-sang-hay-gap-khi-di-kham-benh#chp-x-quang-phi)
  * [Phết tế bào cổ tử cung (Pap’s mear)](https://bvnguyentriphuong.com.vn/khoa-kham-benh/giai-thich-mot-so-can-lam-sang-hay-gap-khi-di-kham-benh#pht-t-bo-c-t-cung-paps-mear)
  * [Phương pháp chẩn đoán này được Hiệp Hội Phòng chống bệnh Hoa Kỳ khuyến cáo để tầm soát ung thư vú. Trên 40 tuổi nếu là nữ, bạn nên chụp nhũ ảnh mỗi năm. Chụp nhũ ảnh chính xác và nhạy hơn siêu âm vú. Kiểm tra sớm nhằm phát hiện những bất thường của vú để phòng bệnh và điều trị kịp thời bệnh ung thư vú.](https://bvnguyentriphuong.com.vn/khoa-kham-benh/giai-thich-mot-so-can-lam-sang-hay-gap-khi-di-kham-benh#phng-php-chn-on-ny-c-hip-hi-phng-chng-bnh-hoa-k-khuyn-co-tm-sot-ung-th-v-trn-40-tui-nu-l-n-bn-nn-chp-nh-nh-mi-nm-chp-nh-nh-chnh-xc-v-nhy-hn-siu-m-v-kim-tra-sm-nhm-pht-hin-nhng-bt-thng-ca-v-phng-bnh-v-iu-tr-kp-thi-bnh-ung-th-v)
  * [Tầm soát ung thư tuyến tiền liệt (PSA )](https://bvnguyentriphuong.com.vn/khoa-kham-benh/giai-thich-mot-so-can-lam-sang-hay-gap-khi-di-kham-benh#tm-sot-ung-th-tuyn-tin-lit-psa-)
  * [Nội soi cổ tử cung](https://bvnguyentriphuong.com.vn/khoa-kham-benh/giai-thich-mot-so-can-lam-sang-hay-gap-khi-di-kham-benh#ni-soi-c-t-cung)
  * [Nội soi dạ dày - trực tràng - đại tràng](https://bvnguyentriphuong.com.vn/khoa-kham-benh/giai-thich-mot-so-can-lam-sang-hay-gap-khi-di-kham-benh#ni-soi-d-dy-trc-trng-i-trng)



## ️ Chu chuyển tim và tên gọi các thành phần trên điện tâm đồ

  * [HÌNH DẠNG VÀ TÊN GỌI CÁC SÓNG ĐIỆN TIM TRONG MỘT CHU CHUYỂN TIM](https://bvnguyentriphuong.com.vn/tham-do-chuc-nang/chu-chuyen-tim-va-ten-goi-cac-thanh-phan-tren-dien-tam-do#hnh-dng-v-tn-gi-cc-sng-in-tim-trong-mt-chu-chuyn-tim)


### **CHU CHUYỂN TIM**
Chu chuyển tim là một chuỗi những sự kiện xảy ra tại tim trong một nhịp đập hoàn chỉnh của nó. Mỗi một chu chuyển tim chiếm khoảng 0,8s và bao gồm hai thời kỳ. Thời kỳ tâm trương, thường gọi là giai đoạn đổ đầy thất, tâm nhĩ co đẩy máu xuống và tâm thất dãn ra để hút máu về. Trong thời kỳ tâm thu, hai tâm thất co bóp tống máu từ tâm thất vào động mạch phổi (tại tâm thất phải) và động mạch chủ (tại tâm thất trái).
**Hình 3.1.** **Các sóng điện trong một chu chuyển tim**
### **HÌNH DẠNG VÀ TÊN GỌI CÁC SÓNG ĐIỆN TIM TRONG MỘT CHU CHUYỂN TIM**
Trên điện tâm đồ các giai đoạn cũng thể hiện tương tự. Hình dạng Điện tâm đồ bình thường bao gồm các thành phần tương ứng với các hoạt động điện trong một nhịp tim. Các dạng sóng được đặt tên P, Q, R, S, T và U. 
Trên một ĐTĐ bình thường, các sóng có hình dạng như sau:
**Hình 3.2**. **Các sóng điện trong một chu chuyển**
**Sóng P:** là sóng đầu tiên và thường dương (trên đường đẳng điện). Nó đại diện cho sự khử cực tâm nhĩ.
**Phức bộ QRS:** sau sóng P. Nó thường bắt đầu với một đường đi xuống (âm) đó là sóng Q.
Tiếp đó đường điện tim hướng cao lên trên, đó là sóng R. Sau sóng R là âm đi xuống gọi là sóng S. QRS đại diện cho sự khử cực tâm thất và co bóp thất. Như vậy trong phức bộ QRS thì:
Sóng Q: sóng âm khởi đầu phức bộ.
Sóng R: các sóng dương.
Sóng S: các sóng âm còn lại.
**Sóng T:** thường thấp hơn và đi sau phức bộ QRS, đại diện cho quá trình tái cực tâm thất.
**Sóng U:** chỉ ra sự phục hồi của các sợi dẫn Purkinje. Phần sóng này có thể không quan sát.
**Hỉnh.3.3.** **Tên gọi các sóng điện tim**
**Đoạn PQ/PR (PR segment):** khởi đầu từ cuối sóng P cho đến điểm khởi đầu của phức bộ QRS.
**Khoảng PQ/PR (PR interval):** khởi đầu từ đầu sóng P cho đến điểm khởi đầu của phức bộ QRS (bao gồm sóng P và đoạn PR).
**Đoạn ST:** khởi đầu từ cuối phức bộ QRS cho đến điểm khởi đầu của sóng T.
**Điểm J:** là đường giao nhau giữa cuối phức bộ QRS và sự bắt đầu của đoạn ST.
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [HÌNH DẠNG VÀ TÊN GỌI CÁC SÓNG ĐIỆN TIM TRONG MỘT CHU CHUYỂN TIM](https://bvnguyentriphuong.com.vn/tham-do-chuc-nang/chu-chuyen-tim-va-ten-goi-cac-thanh-phan-tren-dien-tam-do#hnh-dng-v-tn-gi-cc-sng-in-tim-trong-mt-chu-chuyn-tim)



## ️ 07 lựa chọn thay thế cho nội soi

  * [Nội soi đại tràng là gì?](https://bvnguyentriphuong.com.vn/noi-tieu-hoa/07-lua-chon-thay-the-cho-noi-soi#ni-soi-i-trng-l-g)
  * [Tại sao bệnh nhân e ngại nội soi?](https://bvnguyentriphuong.com.vn/noi-tieu-hoa/07-lua-chon-thay-the-cho-noi-soi#ti-sao-bnh-nhn-e-ngi-ni-soi)
  * [Các xét nghiệm, thăm dò chức năng khác về ung thư đại tràng](https://bvnguyentriphuong.com.vn/noi-tieu-hoa/07-lua-chon-thay-the-cho-noi-soi#cc-xt-nghim-thm-d-chc-nng-khc-v-ung-th-i-trng)
  * [Xét nghiệm sinh hóa miễn dịch phân](https://bvnguyentriphuong.com.vn/noi-tieu-hoa/07-lua-chon-thay-the-cho-noi-soi#xt-nghim-sinh-ha-min-dch-phn)
  * [Thuốc xổ bari tương phản kép](https://bvnguyentriphuong.com.vn/noi-tieu-hoa/07-lua-chon-thay-the-cho-noi-soi#thuc-x-bari-tng-phn-kp)
  * [Xét nghiệm máu ẩn trong phân](https://bvnguyentriphuong.com.vn/noi-tieu-hoa/07-lua-chon-thay-the-cho-noi-soi#xt-nghim-mu-n-trong-phn)
  * [Chụp CT đại tràng](https://bvnguyentriphuong.com.vn/noi-tieu-hoa/07-lua-chon-thay-the-cho-noi-soi#chp-ct-i-trng)
  * [Soi đại tràng sigma](https://bvnguyentriphuong.com.vn/noi-tieu-hoa/07-lua-chon-thay-the-cho-noi-soi#soi-i-trng-sigma)
  * [Lợi ích của nội soi](https://bvnguyentriphuong.com.vn/noi-tieu-hoa/07-lua-chon-thay-the-cho-noi-soi#li-ch-ca-ni-soi)
  * [Làm thế nào để kiểm tra so sánh?](https://bvnguyentriphuong.com.vn/noi-tieu-hoa/07-lua-chon-thay-the-cho-noi-soi#lm-th-no-kim-tra-so-snh)


## **Nội soi đại tràng là gì?**
Nội soi đại tràng (Colonoscopy) là một kiểm tra được sử dụng để phát hiện những thay đổi bất thường trong đại tràng và trực tràng giúp chẩn đoán được các bệnh đại tràng cũng như tìm ra được các nguy cơ gây ung thư.
Trong quá trình nội soi đại tràng, một ống dài được đưa từ lỗ hậu môn qua toàn bộ đại tràng đến tận manh tràng. Một máy quay nhỏ và đèn ở đầu của ống, thu được hình ảnh của niêm mạc đại tràng được phóng đại trên màn hình màu cho phép các bác sĩ xem bên trong của toàn bộ đại tràng.
Nội soi đại tràng có thể phát hiện các thương tổn ở đại tràng, đặc biệt là những tổn thương có khả năng phát triển thành ung thư ở giai đoạn sớm mà phương pháp X-quang hay siêu âm bụng dễ bỏ sót. Nếu cần thiết, khối u hoặc các loại mô bất thường có thể được cắt bỏ thông qua phạm vi trong quá trình nội soi. Sinh thiết cũng có thể được thực hiện trong quá trình này.
## **Tại sao bệnh nhân e ngại nội soi?**
Mặc dù nội soi là phương pháp tốt nhất trong tầm soát ung thư đại tràng, một số người còn e ngại thực hiện thủ thuật này vì các lý do sau:
  * Cần sự chuẩn bị trước cả ngày, bao gồm chế độ ăn, đồ uống theo quy định, các thuốc nhuận tràng để gây tiêu chảy và đôi khi là thuốc xổ để làm sạch ruột hơn nữa.
  * Cần gây mê, khi bệnh nhân thức dậy có thể sẽ cảm thấy áp lực từ khí có thể đã bơm vào đại tràng.
  * Ngoài việc cảm thấy lo lắng về sự khó chịu thể chất, bệnh nhân có thể lo lắng về chi phí của nội soi. Đối với những người có ít kinh phí hoặc không có bảo hiểm y tế, đây có thể là một phương pháp ít được lựa chọn thực hiện.


Nội soi đại tràng đã được chứng minh là giúp cứu sống nhiều trường hợp. Nội soi giúp phát hiện sớm ung thư đại tràng, bệnh nhân được điều trị kịp thời, từ đó giảm tỉ lệ tử vong liên quan đến ung thư đại tràng.
Tuy nhiên, chi phí và sự khó chịu của thủ thuật đã khiến một số người tránh không thực hiện thủ thuật này.
## **Các xét nghiệm, thăm dò chức năng khác về ung thư đại tràng**
Có một số xét nghiệm, thăm dò chức năng có thể thay thế cho nội soi. Tất cả các phương pháp này khác nhau về độ nhạy và tính đặc hiệu của chúng trong
phát hiện ung thư đại tràng. Mặc dù nội soi có thể là lựa chọn tốt nhất, các hương án thay thế có thể giúp bệnh nhân tầm soát ung thư đại tràng nếu họ không thể hoặc không muốn thực hiện nội soi.
### **Xét nghiệm sinh hóa miễn dịch phân**
Xét nghiệm sinh hóa miễn dịch phân (FIT) là một lựa chọn sàng lọc phổ biến ở nhiều khu vực trên thế giới được cơ quan Quản lý Thực phẩm và Dược phẩm Hoa Kỳ (FDA) chấp thuận sử dụng.
FIT sử dụng kháng thể để phát hiện máu trong phân của người không thể nhìn thấy bằng mắt thường.
Tuy nhiên, để giảm khả năng dương tính giả, bệnh nhân nên báo với bác sĩ nếu bị bệnh trĩ hoặc nứt hậu môn, hay đang có kinh nguyệt đối với phụ nữ.
Bệnh nhân được đưa một bộ dụng cụ để thu thập mẫu phân tại nhà. Các bước thực hiện xét nghiệm này khá đơn giản với chi phí thấp. Tuy nhiên cần phải được lặp lại hàng năm.
Nếu FIT xác định có các bất thường, nội soi có thể được chỉ định kiểm tra chuyên sâu hơn. Khi được tiến hành hàng năm, FIT có thể có hiệu quả tương đương với nội soi.
### **Thuốc xổ bari tương phản kép**
Chụp bari tương phản kép là một phương pháp có sử dụng tia X kết hợp với barisunfat (BaSO4) để kiểm tra đại tràng. Phương pháp này có thể có hiệu quả trong việc phát hiện các polyp đại tràng lớn, nhưng có thể bỏ sót các polyp nhỏ.
Tương tự như nội soi, ở phương pháp này đại tràng phải được làm sạch hoàn toàn với việc nhịn ăn và thụt tháo hoặc sử dụng thuốc nhuận tràng.
Nếu có hình ảnh bất thường của đại tràng, để loại trừ các nguy cơ, bác sĩ vẫn có thể sẽ yêu cầu bệnh nhân thực hiện nội soi.
### **Xét nghiệm máu ẩn trong phân**
Xét nghiệm máu ẩn trong phân (FOBT) có thể hiệu quả như nội soi, nhưng cần được thực hiện hàng năm để đảm bảo tính hiệu quả.
Xét nghiệm này kết hợp xét nghiệm máu với xét nghiệm sinh hóa miễn dịch phân để có được phát hiện chính xác ung thư đại tràng.
### **Cologuard**
Cologuard là xét nghiệm sàng lọc DNA phân duy nhất để phát hiện ung thư đại tràng - một xét nghiệm phân khác có thể được sử dụng thay cho nội soi.
Khi được sử dụng thay vì nội soi, xét nghiệm cologuard nên được thực hiện 3 năm một lần.
### **DNA phân**
Xét nghiệm DNA phân là xét nghiệm theo quy định có thể được thực hiện tại nhà. Xét nghiệm này tìm máu và một số DNA cụ thể trong mẫu phân có thể chỉ ra sự hiện diện của ung thư đại tràng.
Nếu phát hiện ung thư, người bệnh sẽ cần được nội soi để loại bỏ sự phát triển của các tế bào ung thư.
### **Chụp CT đại tràng**
Phương pháp này thường bao gồm thêm chụp X-quang đại tràng. Tương tự như nội soi, đại tràng sẽ cần phải được làm sạch trước.
Bệnh nhân không cần phải được gây mê trong khi chụp. Trong phương pháp này, đại tràng được bơm căng bằng không khí để cung cấp một hình ảnh tốt hơn.
Nếu phát hiện có polyp hoặc ung thư trong đại tràng, nội soi sẽ được chỉ định để xác định chẩn đoán hoặc điều trị loại bỏ tổn thương.
### **Soi đại tràng sigma**
Soi đại tràng sigma là một phương pháp tương tự như nội soi đại tràng nhưng chỉ kiểm tra một phần nhỏ của đại tràng. Như với nội soi, thông thường, phương pháp này đòi hỏi sự chuẩn bị chuyên sâu bao gồm nhịn ăn và làm sạch ruột.
Vì ống soi đại tràng sigma chỉ kiểm tra một phần nhỏ của đại tràng nhưng cần sự chuẩn bị và có những khó chịu tương tự nội soi đại tràng thông thường, phương pháp này thường không được khuyến nghị thường xuyên.
## **Lợi ích của nội soi**
Nội soi chủ yếu được sử dụng để tìm ra sự phát triển ung thư và tiền ung thư trong đại tràng. Đây thường được coi là phương pháp hiệu quả trong việc phát hiện sớm ung thư đại trực tràng.
Ung thư đại trực tràng là ung thư phát triển chậm có thể được điều trị hiệu quả khi được phát hiện sớm.
Các chuyên gia xem xét nghiệm phân, soi đại tràng và soi đại tràng sigma có hiệu quả như một phương pháp sàng lọc, trong đó xét nghiệm phân là lựa chọn ít xâm lấn nhất.
## **Làm thế nào để kiểm tra so sánh?**
Xét nghiệm phân và soi đại tràng sigma cũng tốt như nội soi trong việc giảm tỷ lệ tử vong của ung thư đại trực tràng. Tuy nhiên, xét nghiệm phân không thể ngăn ngừa ung thư đại trực tràng, chỉ có thể giúp phát hiện ra khi có hiện diện của ung thư.
Nội soi và soi đại tràng sigma có thể giúp ngăn ngừa ung thư đại trực tràng bằng cách tìm thấy các u tuyến như **polyp** xuất hiện trước khi một khối u phát triển.
Bác sĩ có thể giới thiệu các phương pháp để bệnh nhân lựa chọn. Một số lựa chọn xét nghiệm phân do ít xâm lấn. Tuy nhiên, những trường hợp tầm soát ung thư có thể cần nội soi đại tràng hoặc soi đại tràng sigma.
**Hướng dẫn sàng lọc 2019**
Các chuyên gia khuyến nghị những phương án sau đây là các lựa chọn sàng lọc cho người trưởng thành có nguy cơ mắc ung thư đại trực tràng trung bình trong độ tuổi từ 50 đến 75 tuổi:
  * **Xét nghiệm phân** 2 năm một lần;
  * **Nội soi đại tràng** sau mỗi 10 năm;
  * Soi đại tràng sigma cứ sau 10 năm kết hợp với xét nghiệm phân sau mỗi 2 năm.


## **Tổng kết**
Khi thực hiện các phương pháp sàng lọc theo khuyến cáo, các biện pháp thay thế cho nội soi có thể có hiệu quả tương đương với nội soi trong việc phát hiện ung thư đại tràng. Tuy nhiên, nếu có bất kỳ dấu hiệu bất thường nào, bác sĩ có thể chỉ định nội soi.
Mọi người cần phải hiểu tầm quan trọng của việc sàng lọc ung thư đại tràng qua tuổi 50.
Mặc dù nội soi là biện pháp hiệu quả nhất và các lựa chọn thay thế cũng có thể nên được xem xét khi không muốn nội soi.
Xem thêm: [**Chuẩn bị trước khi nội soi đại tràng**](https://bvnguyentriphuong.com.vn/noi-soi/nhung-dan-do-truoc-khi-thuc-hien-noi-soi-dai-trang)
**Bệnh viện Nguyễn Tri Phương** - Bệnh viện Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [Nội soi đại tràng là gì?](https://bvnguyentriphuong.com.vn/noi-tieu-hoa/07-lua-chon-thay-the-cho-noi-soi#ni-soi-i-trng-l-g)
  * [Tại sao bệnh nhân e ngại nội soi?](https://bvnguyentriphuong.com.vn/noi-tieu-hoa/07-lua-chon-thay-the-cho-noi-soi#ti-sao-bnh-nhn-e-ngi-ni-soi)
  * [Các xét nghiệm, thăm dò chức năng khác về ung thư đại tràng](https://bvnguyentriphuong.com.vn/noi-tieu-hoa/07-lua-chon-thay-the-cho-noi-soi#cc-xt-nghim-thm-d-chc-nng-khc-v-ung-th-i-trng)
  * [Xét nghiệm sinh hóa miễn dịch phân](https://bvnguyentriphuong.com.vn/noi-tieu-hoa/07-lua-chon-thay-the-cho-noi-soi#xt-nghim-sinh-ha-min-dch-phn)
  * [Thuốc xổ bari tương phản kép](https://bvnguyentriphuong.com.vn/noi-tieu-hoa/07-lua-chon-thay-the-cho-noi-soi#thuc-x-bari-tng-phn-kp)
  * [Xét nghiệm máu ẩn trong phân](https://bvnguyentriphuong.com.vn/noi-tieu-hoa/07-lua-chon-thay-the-cho-noi-soi#xt-nghim-mu-n-trong-phn)
  * [Chụp CT đại tràng](https://bvnguyentriphuong.com.vn/noi-tieu-hoa/07-lua-chon-thay-the-cho-noi-soi#chp-ct-i-trng)
  * [Soi đại tràng sigma](https://bvnguyentriphuong.com.vn/noi-tieu-hoa/07-lua-chon-thay-the-cho-noi-soi#soi-i-trng-sigma)
  * [Lợi ích của nội soi](https://bvnguyentriphuong.com.vn/noi-tieu-hoa/07-lua-chon-thay-the-cho-noi-soi#li-ch-ca-ni-soi)
  * [Làm thế nào để kiểm tra so sánh?](https://bvnguyentriphuong.com.vn/noi-tieu-hoa/07-lua-chon-thay-the-cho-noi-soi#lm-th-no-kim-tra-so-snh)



## ️ Điện cơ (EMG) là gì?

  * [Tại sao điện cơ được thực hiện?](https://bvnguyentriphuong.com.vn/co-xuong-khop/dien-co-emg-la-gi#ti-sao-in-c-c-thc-hin)
  * [Cần chuẩn bị gì khi làm điện cơ?](https://bvnguyentriphuong.com.vn/co-xuong-khop/dien-co-emg-la-gi#cn-chun-b-g-khi-lm-in-c)
  * [Điều gì xảy ra khi làm điện cơ?](https://bvnguyentriphuong.com.vn/co-xuong-khop/dien-co-emg-la-gi#iu-g-xy-ra-khi-lm-in-c)
  * [Bệnh nhân được yêu cầu nằm xuống bàn kiểm tra hoặc ngồi trên ghế tựa. Bác sĩ có thể yêu cầu di chuyển đến các vị trí khác nhau trong suốt quá trình tiến hành thủ thuật. Có 2 phần trong xét nghiệm EMG: Nghiên cứu dẫn truyền thần kinh và EMG kim.](https://bvnguyentriphuong.com.vn/co-xuong-khop/dien-co-emg-la-gi#bnh-nhn-c-yu-cu-nm-xung-bn-kim-tra-hoc-ngi-trn-gh-ta-bc-s-c-th-yu-cu-di-chuyn-n-cc-v-tr-khc-nhau-trong-sut-qu-trnh-tin-hnh-th-thutc-2-phn-trong-xt-nghim-emg-nghin-cu-dn-truyn-thn-kinh-v-emg-kim)
  * [Những nguy cơ của điện cơ là gì?](https://bvnguyentriphuong.com.vn/co-xuong-khop/dien-co-emg-la-gi#nhng-nguy-cca-in-c-l-g)
  * [EMG là một thủ thuật có rủi ro rất thấp. Tuy nhiên, có thể cảm thấy đau ở khu vực đã được đo. Đau nhức có thể kéo dài trong một vài ngày và có thể thuyên giảm với thuốc giảm đau không kê đơn nếu cần thiết.](https://bvnguyentriphuong.com.vn/co-xuong-khop/dien-co-emg-la-gi#emg-l-mt-th-thut-c-ri-ro-rt-thp-tuy-nhin-c-th-cm-thy-au-khu-vc-c-o-au-nhc-c-th-ko-di-trong-mt-vi-ngy-v-c-th-thuyn-gim-vi-thuc-gim-au-khng-k-n-nu-cn-thit)
  * [Ý nghĩa của kết quả điện cơ?](https://bvnguyentriphuong.com.vn/co-xuong-khop/dien-co-emg-la-gi#-ngha-ca-kt-qu-in-c)
  * [Bác sĩ có thể trao đổi kết quả với bệnh nhân ngay sau khi làm thủ thuật. Nếu EMG cho thấy bất kỳ hoạt động điện trong cơ bắp ở trạng thái nghỉ ngơi, thì có thể có:](https://bvnguyentriphuong.com.vn/co-xuong-khop/dien-co-emg-la-gi#bc-s-c-th-trao-i-kt-qu-vi-bnh-nhn-ngay-sau-khi-lm-th-thut-nu-emg-cho-thy-bt-k-hot-ng-in-trong-c-bp-trng-thi-ngh-ngi-th-c-th-c)


Điện cơ (EMG) là một thủ thuật chẩn đoán đánh giá tình trạng sức khỏe của cơ bắp và các tế bào thần kinh kiểm soát chúng. Những tế bào thần kinh này được gọi là tế bào thần kinh vận động. Chúng truyền tín hiệu điện khiến cơ bắp co và thư giãn. EMG chuyển các tín hiệu điện này thành các biểu đồ hoặc con số giúp các bác sĩ chẩn đoán.
EMG sẽ được chỉ định ở những bệnh nhân có triệu chứng rối loạn cơ hoặc thần kinh. Những triệu chứng này bao gồm ngứa ran, tê hoặc yếu chi không rõ nguyên nhân. Kết quả EMG có thể giúp chẩn đoán các rối loạn cơ, rối loạn thần kinh và rối loạn ảnh hưởng đến sự kết nối giữa các dây thần kinh và cơ bắp.
## **Tại sao điện cơ được thực hiện?**
Chỉ định đo EMG nếu bệnh nhân gặp phải các triệu chứng có liên quan đến rối loạn cơ hoặc thần kinh. Một số triệu chứng có thể cần phải đo EMG bao gồm:
  * Ngứa ran
  * Yếu cơ
  * Đau cơ hoặc chuột rút
  * Tê liệt
  * Co giật cơ không chủ động.


Kết quả của EMG có thể giúp bác sĩ xác định nguyên nhân cơ bản của những triệu chứng này bao gồm:
  * Rối loạn cơ, chẳng hạn như loạn dưỡng cơ.
  * Rối loạn ảnh hưởng đến khả năng của tế bào thần kinh vận động gửi tín hiệu điện đến cơ, chẳng hạn như nhược cơ.
  * Bệnh phóng xạ.
  * Rối loạn thần kinh ngoại biên ảnh hưởng đến các dây thần kinh ngoài tủy sống, chẳng hạn như hội chứng ống cổ tay.
  * Rối loạn thần kinh, chẳng hạn như xơ cứng teo cơ một bên (ALS).


## **Cần chuẩn bị gì khi làm điện cơ?**
Hãy nhớ thông báo cho bác sĩ về bất kỳ loại thuốc không kê đơn hoặc thuốc theo toa nào bạn có thể đang dùng. Nó cũng rất cần thiết khi nói với bác sĩ nếu bạn bị rối loạn đông máu, hoặc nếu bạn đang được đặt máy tạo nhịp tim hoặc máy khử rung tim cấy ghép. Bạn có thể sẽ không được đo EMG nếu có bất kỳ điều kiện hoặc thiết bị y tế nào trong số này.
Nếu bạn được đo EMG, cần phải:
  * Tránh hút thuốc ít nhất ba giờ trước khi làm thủ thuật.
  * Tắm để loại bỏ dầu ra khỏi da. Đừng bôi bất kỳ loại kem hoặc chất dưỡng sau khi tắm.
  * Mặc quần áo thoải mái mà không làm vướng khu vực mà bác sĩ của bạn cần đánh giá. Bạn có thể được yêu cầu thay áo choàng bệnh viện ngay trước khi làm thủ thuật.


## **Điều gì xảy ra khi làm điện cơ?**
##  Bệnh nhân được yêu cầu nằm xuống bàn kiểm tra hoặc ngồi trên ghế tựa. Bác sĩ có thể yêu cầu di chuyển đến các vị trí khác nhau trong suốt quá trình tiến hành thủ thuật. Có 2 phần trong xét nghiệm EMG: Nghiên cứu dẫn truyền thần kinh và EMG kim.
Nghiên cứu dẫn truyền thần kinh có liên quan đến việc đặt các cảm biến nhỏ gọi điện cực bề mặt trên da để đánh giá khả năng của các tế bào thần kinh vận động gửi tín hiệu điện. EMG kim cũng sử dụng các cảm biến để đánh giá tín hiệu điện. Các cảm biến được gọi là điện cực kim, và chúng trực tiếp đưa vào mô cơ để đánh giá hoạt động của cơ khi nghỉ ngơi và khi co lại.
Nghiên cứu dẫn truyền thần kinh được thực hiện trước. Trong phần này, bác sĩ sẽ đặt một số điện cực lên bề mặt da ở khu vực có triệu chứng. Những điện cực này sẽ đánh giá mức độ tế bào thần kinh vận động điều khiển cơ bắp tốt như thế nào. Sau khi thử nghiệm hoàn tất, các điện cực được loại bỏ khỏi da.
Sau khi nghiên cứu dẫn truyền thần kinh, bác sĩ sẽ thực hiện EMG kim. Trước tiên, khu vực tiến hành sẽ được sát khuẩn bằng chất khử trùng. Sau đó, kim được đưa điện cực vào mô cơ. Bệnh nhân có thể cảm thấy hơi khó chịu hoặc đau trong khi kim được đưa vào.
Các điện cực kim sẽ đánh giá hoạt động điện của cơ bắp khi co lại và khi nghỉ ngơi. Những điện cực này sẽ được tháo ra sau khi thủ thuật kết thúc.
Trong cả 2 phần của thủ thuật EMG, các điện cực sẽ truyền tín hiệu điện nhỏ đến dây thần kinh. Một máy tính sẽ chuyển đổi các tín hiệu này thành các biểu đồ hoặc các giá trị số để bác sĩ đọc. Toàn bộ thủ thuật này sẽ mất từ 30 đến 60 phút.
## **Những nguy cơ của điện cơ là gì?**
## EMG là một thủ thuật có rủi ro rất thấp. Tuy nhiên, có thể cảm thấy đau ở khu vực đã được đo. Đau nhức có thể kéo dài trong một vài ngày và có thể thuyên giảm với thuốc giảm đau không kê đơn nếu cần thiết.
Trong vài trường hợp hiếm hoi, bệnh nhân có thể bị ngứa ran, bầm tím và sưng tại các vị trí chèn kim. Hãy tư vấn ý kiến bác sĩ nếu tình trạng sưng hoặc đau trở nên trầm trọng hơn.
## **Ý nghĩa của kết quả điện cơ?**
## Bác sĩ có thể trao đổi kết quả với bệnh nhân ngay sau khi làm thủ thuật. Nếu EMG cho thấy bất kỳ hoạt động điện trong cơ bắp ở trạng thái nghỉ ngơi, thì có thể có:
  * Rối loạn cơ bắp
  * Một rối loạn ảnh hưởng đến các dây thần kinh kết nối với cơ bắp
  * Viêm do chấn thương


Nếu EMG của cho thấy hoạt động điện bất thường khi cơ co lại, thì bạn có thể bị thoát vị đĩa đệm hoặc rối loạn thần kinh, chẳng hạn như ALS hoặc hội chứng ống cổ tay.
Tùy thuộc vào kết quả, bác sĩ sẽ trao đổi với bạn về bất kỳ xét nghiệm hoặc phương pháp điều trị bổ sung nào cần thiết.
Xem thêm: [**Ghi điện cơ trong lâm sàng thần kinh**](https://bvnguyentriphuong.com.vn/tham-do-chuc-nang/ghi-dien-co-trong-lam-sang-than-kinh)
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [Tại sao điện cơ được thực hiện?](https://bvnguyentriphuong.com.vn/co-xuong-khop/dien-co-emg-la-gi#ti-sao-in-c-c-thc-hin)
  * [Cần chuẩn bị gì khi làm điện cơ?](https://bvnguyentriphuong.com.vn/co-xuong-khop/dien-co-emg-la-gi#cn-chun-b-g-khi-lm-in-c)
  * [Điều gì xảy ra khi làm điện cơ?](https://bvnguyentriphuong.com.vn/co-xuong-khop/dien-co-emg-la-gi#iu-g-xy-ra-khi-lm-in-c)
  * [Bệnh nhân được yêu cầu nằm xuống bàn kiểm tra hoặc ngồi trên ghế tựa. Bác sĩ có thể yêu cầu di chuyển đến các vị trí khác nhau trong suốt quá trình tiến hành thủ thuật. Có 2 phần trong xét nghiệm EMG: Nghiên cứu dẫn truyền thần kinh và EMG kim.](https://bvnguyentriphuong.com.vn/co-xuong-khop/dien-co-emg-la-gi#bnh-nhn-c-yu-cu-nm-xung-bn-kim-tra-hoc-ngi-trn-gh-ta-bc-s-c-th-yu-cu-di-chuyn-n-cc-v-tr-khc-nhau-trong-sut-qu-trnh-tin-hnh-th-thutc-2-phn-trong-xt-nghim-emg-nghin-cu-dn-truyn-thn-kinh-v-emg-kim)
  * [Những nguy cơ của điện cơ là gì?](https://bvnguyentriphuong.com.vn/co-xuong-khop/dien-co-emg-la-gi#nhng-nguy-cca-in-c-l-g)
  * [EMG là một thủ thuật có rủi ro rất thấp. Tuy nhiên, có thể cảm thấy đau ở khu vực đã được đo. Đau nhức có thể kéo dài trong một vài ngày và có thể thuyên giảm với thuốc giảm đau không kê đơn nếu cần thiết.](https://bvnguyentriphuong.com.vn/co-xuong-khop/dien-co-emg-la-gi#emg-l-mt-th-thut-c-ri-ro-rt-thp-tuy-nhin-c-th-cm-thy-au-khu-vc-c-o-au-nhc-c-th-ko-di-trong-mt-vi-ngy-v-c-th-thuyn-gim-vi-thuc-gim-au-khng-k-n-nu-cn-thit)
  * [Ý nghĩa của kết quả điện cơ?](https://bvnguyentriphuong.com.vn/co-xuong-khop/dien-co-emg-la-gi#-ngha-ca-kt-qu-in-c)
  * [Bác sĩ có thể trao đổi kết quả với bệnh nhân ngay sau khi làm thủ thuật. Nếu EMG cho thấy bất kỳ hoạt động điện trong cơ bắp ở trạng thái nghỉ ngơi, thì có thể có:](https://bvnguyentriphuong.com.vn/co-xuong-khop/dien-co-emg-la-gi#bc-s-c-th-trao-i-kt-qu-vi-bnh-nhn-ngay-sau-khi-lm-th-thut-nu-emg-cho-thy-bt-k-hot-ng-in-trong-c-bp-trng-thi-ngh-ngi-th-c-th-c)



## ️ Nội soi đường tiêu hóa phát hiện sớm bệnh ung thư

Những yếu tố nguy cơ cao bị ung thư đường tiêu hóa như: ngoài tuổi 40 xuất hiện những biểu hiện đau bụng kéo dài, sụt cân, thiếu máu, ăn không tiêu, đầy bụng, rối loạn tiêu hóa, rối loạn đi cầu, tiêu chảy, táo bón…; tiền sử người thân trong gia đình đã phát hiện bệnh… 
Khi có các biểu hiện bất thường như trên và trong độ tuổi nguy cơ cao, gia đình có tiền sử người mắc bệnh, người dân cần đến các cơ sở y tế có chuyên khoa tiêu hóa để được khám. Việc phát hiện sớm đem lại hiệu quả điều trị cao.
Toàn bộ nội dung bài viết xin tham khảo [tại đây](https://www.giaoduc.edu.vn/noi-soi-duong-tieu-hoa-phat-hien-som-benh-ung-thu.htm?fbclid=IwAR2LnvqFSljM3sWeTQ4z9OB1MKs80xWbK9uL5dsuWbIYSibe98MD1FdaQBk)./.
**Bệnh viện Nguyễn Tri Phương** - Bệnh viện Đa khoa Hạng I Thành phố Hồ Chí Minh
  * 468 Nguyễn Trãi, Phường 8, Quận 5, Tp. Hồ Chí Minh
  * Hotline: (84-028) 39234332
  * Mạng xã hội **Facebook** : [**Bệnh viện Nguyễn Tri Phương**](https://www.facebook.com/BVNTP/)
  * Đăng ký (Subcribe) kênh **Youtube** : [https://youtube.com/bvntp](https://youtube.com/bvntp?fbclid=IwAR3q_UvPI4OZAebT1uQGPKKwk3RmCzAFLkBJm9lb7EwIz0EHtgiLhKM5bxU)
  * Quan tâm Zalo Official: [zalo.me/1744466261097093886](https://zalo.me/1744466261097093886?fbclid=IwAR3E-fLqdh-x1cYSvuDY6E5Eyxfjo5ZSs4p0hDWAyBG-ROlTkxXkXvdEWAY)



## ️ Đo chức năng hô hấp

  * [Đo chức năng hô hấp là gì?](https://bvnguyentriphuong.com.vn/noi-ho-hap/do-chuc-nang-ho-hap#o-chc-nng-h-hp-l-g)
  * [Khi nào nên thực hiện đo chức năng hô hấp?](https://bvnguyentriphuong.com.vn/noi-ho-hap/do-chuc-nang-ho-hap#khi-no-nn-thc-hin-o-chc-nng-h-hp)
  * [Chống chỉ định:](https://bvnguyentriphuong.com.vn/noi-ho-hap/do-chuc-nang-ho-hap#chng-ch-nh)
  * [Chuẩn bị trước khi đo chức năng hô hấp](https://bvnguyentriphuong.com.vn/noi-ho-hap/do-chuc-nang-ho-hap#chun-b-trc-khi-o-chc-nng-h-hp)
  * [5. Các bước tiến hành:](https://bvnguyentriphuong.com.vn/noi-ho-hap/do-chuc-nang-ho-hap#5-cc-bc-tin-hnh)


## **Đo chức năng hô hấp là gì?**
Đo chức năng hô hấp là kỹ thuật thường được dùng trong chẩn đoán và theo dõi đánh giá mức độ nặng nhẹ của các bệnh lý hô hấp. Kỹ thuật giúp ghi lại những thông số liên quan đến hoạt động của phổi, từ đó giúp đánh giá hai hội chứng rối loạn thông khí: tắc nghẽn và hạn chế.
Đo chức năng hô hấp cho ta biết thông tin chính xác về lưu lượng không khí lưu thông trong phế quản và phổi, đồng thời cho phép đánh giá mức độ tắc nghẽn phế quản và mức độ trầm trọng của giãn phế nang.
Kết quả đo chức năng hô hấp được thể hiện bằng số cụ thể và bằng phần trăm so với giá trị của một người bình thường. Các trị số đo được của chức năng hô hấp sau đó được biểu diễn dưới dạng một đường cong trong đó một trục thể hiện các số đo về lưu lượng khí lưu thông, còn trục còn lại thể hiện các số đo của các thể tích khí có trong phổi, do vậy đường cong này còn được gọi là đường cong lưu lượng thể tích.
Đo chức năng hô hấp là thăm dò khá đơn giản và không gây đau cho bệnh nhân, hầu như không gây khó chịu hay tai biến.
Độ chính xác của kết quả phụ thuộc vào sự hợp tác của bệnh nhân. 
## **Khi nào nên thực hiện đo chức năng hô hấp?**
a. Chẩn đoán các bệnh lý hô hấp, khi có các triệu chứng lâm sàng và kết quả xét nghiệm khác bất thường
  * Triệu chứng lâm sàng: khó thở, khò khè, ngồi thở, thở ra khó khăn, ho đờm kéo dài, ho khan kéo dài, dị dạng lồng ngực
  * Xét nghiệm cận lâm sàng: giảm Oxy máu, tăng CO2 máu, đa hồng cầu, X-quang lồng ngực bất


b. Theo dõi, lượng giá, đáp ứng điều trị, diễn tiến bệnh như hen phế quản, bệnh phổi tắc nghẽn mạn tính, bệnh phổi hạn chế.
c. Tầm soát bệnh trên đối tượng có nguy cơ cao:
  * Người hút thuốc lá
  * Người làm việc nơi có khói và hóa chất độc hại


d. Lượng giá sức khỏe trước khi luyện tập
## **Chống chỉ định:**
  * Nhiễm trùng đường hô hấp cấp
  * Ho ra máu không rõ nguyên nhân
  * Phình động mạch chủ ngực, chủ bụng
  * Vừa mới qua đợt cấp bệnh phổi tắc nghẽn mạn tính (COPD), hen dưới 6 tuần
  * Nhồi máu cơ tim, phẫu thuật mắt,bụng, ngực dưới 3-6 tháng
  * Đau ngực không rõ chẩn đoán
  * Đau thắt ngực không ổn định trong 24 giờ
  * Lao phổi tiến triển


## **Chuẩn bị trước khi đo chức năng hô hấp**
  * Mặc quần áo rộng rãi
  * Không hút thuốc 1 giờ trước khi đo
  * Không uống rượu 4 giờ trước khi đo
  * Không vận động nặng 30 phút trước khi đo
  * Không ăn no trong vòng 2 giờ trước khi đo 
  * Đối với trường hợp đo hô hấp ký để chẩn đoán bệnh lần đầu tiên: Không sử dụng thuốc giãn phế quản trước khi đo: 6 giờ nếu là loại tác dụng ngắn; 12 giờ nếu là loại tác dụng kéo dài; 24 giờ nếu là loại uống như theophyllin.


## **5. Các bước tiến hành:**
Thông thường bệnh nhân được yêu cầu làm 2 động tác chính:
  * Động tác thứ nhất: hít vào thở ra bình thường, sau đó được yêu cầu hít vào sâu thật hết sức, rồi thở ra thật hết sức.
  * Động tác thứ hai: hít vào thở ra bình thường, rồi sau đó được yêu cầu hít vào thật hết sức và thổi ra thật nhanh, thật mạnh, hết sức có thể, và tiếp tục thở ra cho đến khi ít nhất 6 giây.


**Lưu ý:**
Trong khi thực hiện bất cứ động tác nào cũng phải làm liên tục, không được dừng. Việc dừng đột ngột, hoặc thực hiện không chính xác những gì mà kỹ thuật viên đo chức năng hô hấp yêu cầu sẽ gây sai lệch kết quả đo chức năng hô hấp, và do vậy dẫn đến nhận định sai kết quả thực mà chức năng thông khí phổi của người bệnh hiện có, từ đó có thể dẫn đến chẩn đoán và điều trị không phù hợp.
Nếu bệnh nhân hút thuốc lá, tuy nhiên kết quả đo chức năng hô hấp bình thường điều đó không có nghĩa là bạn không có nguy cơ mắc bệnh phổi tắc nghẽn mạn tính.
Nếu bệnh phổi tắc nghẽn mạn tính của bạn tiến triển thì FEV1 (thể tích thở ra tối đa trong giây đầu tiên) sẽ giảm dần. Khi FEV1 đo được dưới 40% trị số bình thường thì phổi của bệnh nhân không còn khả năng duy trì chức năng bình thường của nó và lượng oxy trong máu sẽ giảm sút. Thiếu oxy sẽ được phát hiện và đánh giá bằng một xét nghiệm gọi là khí máu.
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh
[youtube.com/bvntp](http://youtube.com/bvntp)
  * [Đo chức năng hô hấp là gì?](https://bvnguyentriphuong.com.vn/noi-ho-hap/do-chuc-nang-ho-hap#o-chc-nng-h-hp-l-g)
  * [Khi nào nên thực hiện đo chức năng hô hấp?](https://bvnguyentriphuong.com.vn/noi-ho-hap/do-chuc-nang-ho-hap#khi-no-nn-thc-hin-o-chc-nng-h-hp)
  * [Chống chỉ định:](https://bvnguyentriphuong.com.vn/noi-ho-hap/do-chuc-nang-ho-hap#chng-ch-nh)
  * [Chuẩn bị trước khi đo chức năng hô hấp](https://bvnguyentriphuong.com.vn/noi-ho-hap/do-chuc-nang-ho-hap#chun-b-trc-khi-o-chc-nng-h-hp)
  * [5. Các bước tiến hành:](https://bvnguyentriphuong.com.vn/noi-ho-hap/do-chuc-nang-ho-hap#5-cc-bc-tin-hnh)



