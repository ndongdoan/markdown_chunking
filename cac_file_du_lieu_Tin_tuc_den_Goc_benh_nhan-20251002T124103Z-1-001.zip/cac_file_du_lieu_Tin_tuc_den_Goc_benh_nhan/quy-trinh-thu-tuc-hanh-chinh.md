## BHXH Việt Nam hướng dẫn sử dụng số CCCD thay thế mã số BHXH từ ngày 01/8/2025

Ngày 04/8/2025, Bảo hiểm xã hội Việt Nam ban hành Công văn số 1804/BHXH-QLT hướng dẫn việc sử dụng số Định danh cá nhân (DDCN)/Căn cước công dân (CCCD) để thay thế mã số bảo hiểm xã hội (BHXH) của người tham gia. Đây là một văn bản hướng dẫn quan trọng, cụ thể hóa lộ trình ứng dụng cơ sở dữ liệu quốc gia về dân cư vào quản lý các chính sách an sinh xã hội, phù hợp với tinh thần cải cách hành chính mà Chính phủ đang đẩy mạnh.
**Mục tiêu triển khai**
Việc thay thế mã số BHXH bằng số DDCN/CCCD nhằm:
Tăng cường tính liên thông, đồng bộ giữa dữ liệu BHXH, BHYT và cơ sở dữ liệu quốc gia.
Góp phần đơn giản hóa thủ tục hành chính, giảm giấy tờ, tạo thuận lợi tối đa cho người dân và doanh nghiệp khi giao dịch với cơ quan BHXH.
Chuẩn hóa mã định danh cho người tham gia BHXH, BHYT và đơn vị sử dụng lao động, làm cơ sở triển khai các dịch vụ số toàn diện của ngành BHXH trong thời gian tới.
**Nội dung chính của công văn**
**1. Sử dụng số DDCN/CCCD thay mã số BHXH, BHYT**
Từ 1/8/2025, toàn bộ mã số BHXH của người tham gia BHXH, BHYT (gồm 10 ký tự) hiện nay sẽ được thay thế bằng chính số ĐDCN/CCCD. Đây là số định danh duy nhất, được cấp cho từng cá nhân, đảm bảo không trùng lặp.
**2. Quy định Bộ mã định danh đơn vị tham gia**
Để đảm bảo tính thống nhất trong quản lý, Công văn 1804 quy định rõ việc định danh Bộ mã đơn vị tham gia BHXH, BHYT đối với: cơ quan, đơn vị, doanh nghiệp, tổ chức sử dụng lao động; Cơ quan quản lý đối tượng; Cơ sở trợ giúp xã hội; Cơ sở từ thiện, tôn giáo; Cơ sở nuôi dưỡng, điều dưỡng thương binh; Tổ chức hỗ trợ phát triển đối tượng tham gia BHXH, BHYT theo quy định của pháp luật và các tổ chức khác (gọi chung là đơn vị):
**_Đối với đơn vị tham gia BHXH, BHYT_**
Cấu trúc mã: **ĐD ĐT LH** Trong đó:
**ĐD** : Mã định danh đơn vị, ghi trên các mẫu biểu trong giao dịch TTHC giữa đơn vị và cơ quan BHXH.
Với các đơn vị áp dụng theo Nghị định số 168/2025/NĐ-CP về đăng ký doanh nghiệp: là mã số doanh nghiệp, gồm 10 ký tự.
Với các đơn vị có quan hệ với ngân sách theo Thông tư số 185/2015/TT-BTC: là mã quan hệ ngân sách, gồm 7 ký tự do cơ quan tài chính cấp.
**ĐT** : Mã đối tượng, gồm 2 ký tự chữ, là mã đối tượng người tham gia BHYT (chi tiết tại Phụ lục I kèm theo).
**LH** : Mã loại hình sản xuất, kinh doanh, gồm 3 ký tự, theo Quyết định số 27/2018/QĐ-TTg ngày 06/7/2018 của Thủ tướng Chính phủ (Phụ lục II kèm theo).
**Ví dụ:**
Ví dụ 1: Doanh nghiệp nhà nước (mã đối tượng: DN), mã định danh: 0123456789, mã loại hình: A03 → Mã đơn vị: 0123456789DNA03
Ví dụ 2: Đơn vị hành chính sự nghiệp, mã quan hệ ngân sách: 1234567, mã đối tượng: HC → Mã đơn vị: 1234567HC
Ví dụ 3: UBND cấp xã, mã quan hệ ngân sách: 2345678, sẽ được cấp các mã đơn vị quản lý như sau:
Mã đóng BHXH, BHYT, BHTN cho cán bộ công chức: 2345678HC
Mã lập danh sách cấp thẻ BHYT hộ cận nghèo: 2345678CN
Mã lập danh sách cấp thẻ BHYT cho trẻ em: 2345678TE
Mã lập danh sách cấp thẻ BHYT cho người hoạt động không chuyên trách: 2345678KT
**_Đối với đơn vị thu hộ_**
Cấu trúc mã: **ĐD TH** **HC** **DT** Trong đó:
  * **ĐD** : Mã định danh đơn vị (như trên)
  * **TH** : Tên viết tắt của tổ chức thu hộ
  * **HC** : Mã đơn vị hành chính (7 ký tự, theo Quyết định số 19/2025/QĐ-TTg)
  * **DT** : Mã điểm thu (3 ký tự, từ 001 đến 999)


Ví dụ: Điểm thu số 3 (mã 003) thuộc Phường Hoàn Kiếm (mã 00070), Thành phố Hà Nội (mã 01), tổ chức thu hộ: Bưu điện (mã 3456789000) → Mã đơn vị quản lý: 3456789000TH0100070003
**3. Danh mục mã đối tượng tham gia BHYT**
Công văn cập nhật và hướng dẫn rõ ràng về mã đối tượng, mã khối thống kê và mức hưởng BHYT đối với từng nhóm người tham gia. Việc mã hóa này giúp hệ thống tự động xác định chính xác quyền lợi BHYT, tránh nhầm lẫn, sai sót khi khám chữa bệnh.

## Triển khai phần mềm văn phòng điện tử giúp Bệnh viện Nguyễn Tri Phương cải thiện việc theo dõi công việc khoa phòng

Bệnh viện Nguyễn Tri Phương là bệnh viện đa khoa hạng I trực thuộc Sở Y tế Thành phố Hồ Chí Minh, với nhiệm vụ khám và điều trị cho hàng ngàn bệnh nhân mỗi ngày. Trong bối cảnh công nghệ ngày càng phát triển, việc ứng dụng phần mềm văn phòng điện tử đã trở thành một xu hướng tất yếu để cải thiện quy trình làm việc và nâng cao hiệu quả quản lý. Gần đây, bệnh viện Nguyễn Tri Phương đã cùng Công ty Dịch vụ MobiFone khu vực 2, đơn vị cung cấp giải pháp, triển khai thành công phần mềm văn phòng điện tử - MobiFone eOffice nhằm nâng cao khả năng theo dõi và quản lý công việc của các khoa phòng.
_Bệnh viện Nguyễn Tri Phương và MobiFone ký kết thỏa thuận hợp tác_
Phần mềm văn phòng điện tử giúp bệnh viện Nguyễn Tri Phương quản lý công việc một cách hiệu quả hơn. Nhờ vào việc số hóa các tài liệu và quy trình, việc lưu trữ và truy xuất thông tin trở nên dễ dàng và nhanh chóng. Các trưởng khoa phòng và nhân viên có thể theo dõi tiến độ công việc, giao nhiệm vụ và cập nhật trạng thái công việc một cách minh bạch và chính xác.
Hệ thống bao gồm 4 phân hệ chính:
  * Phân hệ Quản lý văn bản: Cung cấp các chức năng, công cụ quản lí văn bản đến đi trong nội bộ và liên thông. Các Khoa Phòng sử dụng tài khoản của mình để thao tác tạo các văn bản như phiếu trình, phiếu yêu cầu, phiếu đề nghị… để để gửi các phòng ban liên quan hoặc lãnh đạo bệnh viện. Hệ thống cho phép theo dõi được luồng văn bản đã được xác nhận qua các đơn vị nào, kèm các ghi chú, trao đổi liên quan trong luồng đi của văn bản. 


_Giao diện Văn bản đi đã phát hành trong phân hệ Văn bản đi_
  * Phân hệ Quản lý công việc: Cung cấp các chức năng hữu ích cho công tác quản lý, đăng kí, đánh giá công việc trong đơn vị. Kết nối với luồng văn bản được ban hành, phân hệ quản lý công việc là bước triển khai các nội dung quy định trong từng văn bản. Tính năng giao việc được thể hiện ngay trên văn bản được ban hành giúp lãnh đạo nhanh chóng chuyển công việc đến các đơn vị kèm các căn cứ thực hiện. Sau khi nhận được công việc từ lãnh đạo, các Khoa phòng có thể tạo các công việc con bên trong để thực hiện công việc chính được giao. Khoa phòng chủ trì công việc sẽ là đơn vị báo cáo trực tiếp với lãnh đạo và có vai trò phê duyệt hoàn thành đối với các công việc con mà mình tạo ra. Dựa vào các thông tin trên phân hệ quản lý công việc, Ban lãnh đạo Bệnh viện có đủ căn cứ để đánh giá hoàn thành nhiệm vụ của các Khoa phòng theo các khoảng thời gian khác nhau.


_Giao diện Báo cáo tiến độ hoàn thành công việc_
  * Phân hệ Quản lý hành chính: Cung cấp các quy trình/thủ tục hành chính như đăng ký phòng họp, điều xe, họp hội nghị truyền hình,…
  * Phân hệ Quản trị hệ thống: Cung cấp các chức năng, công cụ cho người quản trị nói chung.


_Giao diện Quản lý vai trò trong phân hệ Quản trị hệ thống_
Với phần mềm văn phòng điện tử, mọi công việc và nhiệm vụ đều được ghi nhận và theo dõi chặt chẽ, và luồng công việc có thể khởi động từ các văn bản nhận đến từ cơ quan quản lý. Điều này không chỉ giúp nâng cao tính minh bạch mà còn tăng cường trách nhiệm của từng khoa, phòng trong luồng công việc, tăng cường phối hợp các phòng ban trong thực hiện các công việc chung. Nhân viên y tế và người quản lý có thể dễ dàng xác định ai là người chịu trách nhiệm cho từng công việc cụ thể và tiến độ thực hiện.
Việc sử dụng phần mềm văn phòng điện tử giúp bệnh viện tiết kiệm thời gian và theo dõi đầy đủ theo thời gian thực so với việc quản lý thủ công. Các quy trình phê duyệt và xử lý hồ sơ được tự động hóa, được ghi dấu trên phần mềm - hỗ trợ thao tác trên cả giao diện web và app di động, từ đó tăng cường hiệu quả trao đổi công việc, giúp giảm bớt việc phải tìm kiếm thủ công lịch sử triển khai công việc từ thời điểm bắt đầu cho đến khi tra cứu.
Triển khai phần mềm văn phòng điện tử - MobiFone eOffice tại bệnh viện Nguyễn Tri Phương đã mang lại nhiều lợi ích thiết thực, giúp cải thiện quy trình làm việc và nâng cao hiệu quả quản lý, từ đó góp phần cải cách thủ tục hành chính. Hiệu suất và tính hiệu quả hợp tác giữa các bộ phận được nâng cao mà lại giảm đi các mệnh lệnh hành chính, đây cũng chính là hiệu quả cải cách thủ tục hành chính đáng giá khi Bệnh viện triển khai phần mềm này.

## Sở Y tế TP.HCM chính thức triển khai toàn bộ 23 thủ tục hành chính theo Luật Khám bệnh, chữa bệnh 2023

Dưới đây là 23 thủ tục hành chính lĩnh vực Khám bệnh, chữa bệnh thuộc thẩm quyền giải quyết của Sở Y tế:

## Phần mềm quản lý và thống kê các chỉ số đánh giá chất lượng tại bệnh viện Nguyễn Tri Phương

  1. **Bối cảnh của sản phẩm:**


Tại Bệnh viện Nguyễn Tri Phương định kỳ hằng tháng/ hằng quý, các khoa/phòng sẽ phải nhập liệu các chỉ số, thông tin báo cáo để thống kê và tìm hướng giải quyết cho những vấn đề khó khăn, tuy nhiên các chỉ số báo cáo đều phải đăng nhập vào nhiều trang web khác nhau hoặc làm thủ công để thực hiện nên sẽ gây mất thời gian cho nhân viên và dễ bị nhầm lẫn giữa các trang web với nhau.
  1. **Nội dung sản phẩm**


Phần mềm được thiết kế với giao diện thân thiện, đơn giản hóa các thao tác và được tích hợp nhiều loại báo cáo vào cùng một trang web.
  * Về báo cáo sự cố y khoa: Phần mềm giúp cho người báo cáo có thể tiếp cận và báo cáo nhanh nhất có thể so với việc báo cáo bằng giấy như trước đây. Thông tin về sự cố y khoa lập tức được chuyển về phòng Quản lý chất lượng. Từ đó, phòng Quản lý chất lượng triển khai các bước của quy trình quản lý sự cố y khoa theo Thông tư 43/2018/TTBYT để khắc phục kịp thời nhằm đảm bảo an toàn cho người bệnh.


  * Về nhập liệu 83 tiêu chí chất lượng: phòng Quản lý chất lượng có thể phân quyền các tiêu chí phù hợp gửi đến từng khoa/ phòng, từ đó, các khoa/phòng sẽ nhập trực tiếp trên phần mềm, số liệu sẽ được lưu mà không cần phải gửi lại cho phòng Quản lý chất lượng. Cuối cùng, phòng Quản lý chất lượng chỉ cần tổng hợp trên phần mềm và gửi lên Sở Y tế.


  1. **Hiệu quả mang lại của sản phẩm**


Việc sử dụng phần mềm văn phòng điện tử giúp bệnh viện tiết kiệm thời gian thống kê số số liệu đã báo cáo và tần suất báo cáo ở các khoa, phòng. Thông tin được lưu trữ trên phần mềm bệnh viện và bất kì ai được phân quyền có thể vào xem hoặc in ra khi cần thiết. Chuyên viên phụ trách tiếp nhận và quản lý 83 tiêu chí chất lượng tại phòng Quản lý chất lượng sẽ giảm được gánh nặng công việc trong việc tổng hợp, phân tích và thống kê số liệu về 83 tiêu chí
Đây cũng là nền tảng để góp phần áp dụng công nghệ thông tin vào hầu hết các hoạt động quản lý của bệnh viện. Giảm thiểu tối đa giấy bút phải sử dụng, giảm một phần chi phí về hồ sơ, sổ sách và công tác lưu trữ.
Triển khai phần mềm văn phòng điện tử đã mang lại nhiều lợi ích thiết thực, giúp cải thiện quy trình làm việc và nâng cao hiệu quả quản lý, từ đó góp phần cải cách thủ tục hành chính. Hiệu suất và tính hiệu quả hợp tác giữa các bộ phận được nâng cao mà lại giảm đi các mệnh lệnh hành chính, đây cũng chính là hiệu quả cải cách thủ tục hành chính đáng giá khi Bệnh viện triển khai phần mềm này.

## Phần mềm hỗ trợ quản lý tài liệu cá nhân cho nhân viên

  * [* Đối với tổ chức:](https://bvnguyentriphuong.com.vn/quy-trinh-thu-tuc-hanh-chinh/phan-mem-ho-tro-quan-ly-tai-lieu-ca-nhan-cho-nhan-vien#i-vi-t-chc)
  * [* Đối với nhân viên:](https://bvnguyentriphuong.com.vn/quy-trinh-thu-tuc-hanh-chinh/phan-mem-ho-tro-quan-ly-tai-lieu-ca-nhan-cho-nhan-vien#-i-vi-nhn-vin)


Bệnh viện Nguyễn Tri Phương tích hợp vào phần mềm **quản lý nội bộ chức năng quản lý hồ sơ cá nhân** :
Khi một tổ chức tạo phần mềm giúp nhân viên **tải lên và tự quản lý các tài liệu cá nhân** như **lý lịch, văn bằng, giấy tờ tuỳ thân, hợp đồng lao động** , v.v., sẽ mang lại nhiều **lợi ích rõ rệt cho cả tổ chức và nhân viên** , cụ thể như sau:
### * **Đối với tổ chức:**
  1. **Tăng hiệu quả quản lý nhân sự**
     * Dễ dàng truy cập và tổng hợp hồ sơ nhân viên cho các hoạt động nội bộ như đánh giá, khen thưởng, đào tạo, hoặc kiểm tra định kỳ.
     * Giảm phụ thuộc vào hồ sơ giấy – dễ thất lạc, khó cập nhật.
  2. **Tiết kiệm thời gian và chi phí hành chính**
     * Không còn mất công thu thập giấy tờ thủ công từng đợt (ví dụ: bổ sung văn bằng, CCCD, chứng nhận tiêm chủng...).
     * Hạn chế lỗi nhập liệu do nhân viên tự cập nhật thông tin.
  3. **Cải thiện tuân thủ pháp lý và bảo mật**
     * Dễ dàng kiểm tra tình trạng đầy đủ của các giấy tờ bắt buộc theo quy định pháp luật.
     * Quản lý quyền truy cập, mã hóa dữ liệu, log hệ thống giúp tăng cường bảo mật.
  4. **Nền tảng cho các chức năng nhân sự nâng cao**
     * Dễ tích hợp với hệ thống đánh giá năng lực, lập kế hoạch đào tạo, lên lộ trình phát triển cá nhân (IDP)...


### * **Đối với nhân viên:**
  1. **Tự chủ và minh bạch thông tin cá nhân**
     * Chủ động cập nhật hồ sơ, biết rõ tổ chức đang nắm giữ những thông tin gì về mình.
     * Tăng sự tin tưởng và gắn bó với tổ chức.
  2. **Tiện lợi khi cần sử dụng lại tài liệu**
     * Có thể dễ dàng trích xuất tài liệu phục vụ cho công việc, học tập, thi cử, xin visa, v.v.
  3. **Hạn chế mất mát, thất lạc giấy tờ gốc**
     * Có nơi lưu trữ bản mềm an toàn, nhất là với văn bằng, chứng chỉ quan trọng.


### ✅ **Tổng kết:**
Phần mềm hỗ trợ quản lý tài liệu cá nhân cho nhân viên **không chỉ là công cụ hành chính** , mà còn là một **bước tiến trong chuyển đổi số và hiện đại hóa quản trị nhân sự**. Nó giúp **tăng tính tự phục vụ của nhân viên** , đồng thời **tối ưu hóa hoạt động nội bộ của tổ chức**. Đây là một hoạt động cải cách hành chính có ý nghĩa tại BV Nguyễn Tri Phương
  * [* Đối với tổ chức:](https://bvnguyentriphuong.com.vn/quy-trinh-thu-tuc-hanh-chinh/phan-mem-ho-tro-quan-ly-tai-lieu-ca-nhan-cho-nhan-vien#i-vi-t-chc)
  * [* Đối với nhân viên:](https://bvnguyentriphuong.com.vn/quy-trinh-thu-tuc-hanh-chinh/phan-mem-ho-tro-quan-ly-tai-lieu-ca-nhan-cho-nhan-vien#-i-vi-nhn-vin)



## Các biểu mẫu sử dụng trong trường hợp phơi nhiễm với HIV, nhiễm HIV do tai nạn rủi ro nghề nghiệp


## Quyết định thành lập hội đồng đạo đức trong nghiên cứu y sinh học

Thực hiện Thông tư 43/2024/TT-BYT 12/12/2024 của Bộ trưởng Bộ Y tế về Quy định việc thành lập, tổ chức và hoạt động của Hội đồng đạo đức trong nghiên cứu y sinh học, Bệnh viện Nguyễn Tri Phương cập nhật thông tin Quyết định thành lập hội đồng đạo đức trong nghiên cứu y sinh học trên Trang thông tin điện tử như sau:
Xem và tải chi tiết văn bản: [**TẠI ĐÂY.**](https://bvnguyentriphuong.com.vn/uploads2025/files/QUYET%20DINH%20hoi%20dong%20dao%20duc%20SO%20672%20NGAY%2023-05-2025.pdf)
#### Nội dung trong file:


**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/)** - Đa khoa Hạng I Thành phố Hồ Chí Minh

## Cải cách quy trình báo cáo sự cố y khoa trong bệnh viện

  * [Thực trạng trước khi ứng dụng công nghệ thông tin trong báo cáo sự cố y khoa](https://bvnguyentriphuong.com.vn/quy-trinh-thu-tuc-hanh-chinh/cai-cach-quy-trinh-bao-cao-su-co-y-khoa-trong-benh-vien#thc-trng-trc-khi-ng-dng-cng-ngh-thng-tin-trong-bo-co-s-c-y-khoa)
  * [Sau khi ứng dụng công nghệ thông tin trong báo cáo sự cố y khoa](https://bvnguyentriphuong.com.vn/quy-trinh-thu-tuc-hanh-chinh/cai-cach-quy-trinh-bao-cao-su-co-y-khoa-trong-benh-vien#sau-khi-ng-dng-cng-ngh-thng-tin-trong-bo-co-s-c-y-khoa)


## Thực trạng trước khi ứng dụng công nghệ thông tin trong báo cáo sự cố y khoa
Sự cố y khoa là các tình huống không mong muốn xảy ra trong quá trình chẩn đoán, chăm sóc và điều trị do các yếu tố khách quan, chủ quan mà không phải do diễn tiến bệnh lý hoặc cơ địa của người bệnh; tác động sức khỏe, tính mạng của người bệnh. Nhằm hạn chế tối thiểu các sự cố y khoa xảy ra và đảm bảo an toàn cho người bệnh, Bộ Y tế đã ban hành Thông tư số 43/2018/TT-BYT ngày 26/12/2018 về việc hướng dẫn phòng ngừa sự cố y khoa trong các cơ sở khám bệnh, chữa bệnh.
Việc báo cáo sự cố y khoa có một ý nghĩa vô cùng to lớn trong việc đi tìm hiểu và phân tích nguyên nhân gốc rễ của sự cố; nhằm có thể đưa ra các khuyến cáo phòng ngừa kịp thời, tránh tái diễn sự cố y khoa.
Trước đây, phòng Quản lý chất lượng triển khai việc báo cáo sự cố y khoa bằng các hình thức như sau: 
+ Báo cáo thông qua mẫu phiếu báo cáo sự cố y khoa ban hành kèm theo Thông tư 43/2018/TT-BYT.
+ Báo cáo miệng trực tiếp.
+ Báo cáo bằng thư điện tử 
+ Báo cáo bằng điện thoại
## Sau khi ứng dụng công nghệ thông tin trong báo cáo sự cố y khoa
Phần mềm báo cáo sự cố y khoa giúp cho người báo cáo có thể tiếp cận và báo cáo nhanh nhất có thể so với việc báo cáo bằng giấy như trước đây. Thông tin về sự cố y khoa lập tức được chuyển về phòng Quản lý chất lượng. Từ đó, phòng Quản lý chất lượng triển khai các bước của quy trình quản lý sự cố y khoa theo Thông tư 43/2018/TT-BYT để khắc phục kịp thời nhằm đảm bảo an toàn cho người bệnh.
Phần mềm báo cáo sự cố y khoa được tích hợp vào phần mềm quản lý hành chính nội bộ của bệnh viện nhằm tạo thuận lợi cho người báo cáo và có thể giữ bí mật, ẩn danh tính của người báo cáo.
  * Tỷ lệ ghi nhận báo cáo sự cố y khoa tại bệnh viện gia tăng đáng kể.
  * Thông tin về các báo cáo sự cố y khoa được lưu trữ trên hệ thống của bệnh viện nên bất kỳ nhân viên nào tại phòng Quản lý chất lượng đều có thể xem và in phiếu báo cáo sự cố y khoa.
  * Tiết kiệm thời gian thống kê số lượng các sự cố y khoa đã báo cáo và tần suất báo cáo ở các khoa, phòng. 


  * [Thực trạng trước khi ứng dụng công nghệ thông tin trong báo cáo sự cố y khoa](https://bvnguyentriphuong.com.vn/quy-trinh-thu-tuc-hanh-chinh/cai-cach-quy-trinh-bao-cao-su-co-y-khoa-trong-benh-vien#thc-trng-trc-khi-ng-dng-cng-ngh-thng-tin-trong-bo-co-s-c-y-khoa)
  * [Sau khi ứng dụng công nghệ thông tin trong báo cáo sự cố y khoa](https://bvnguyentriphuong.com.vn/quy-trinh-thu-tuc-hanh-chinh/cai-cach-quy-trinh-bao-cao-su-co-y-khoa-trong-benh-vien#sau-khi-ng-dng-cng-ngh-thng-tin-trong-bo-co-s-c-y-khoa)



## Đánh giá hiệu quả công việc thông qua hệ thống quản lý văn bản và giao việc

**Lợi ích của hệ thống quản lý văn bản và giao việc**
Hệ thống quản lý văn bản và giao việc của phần mềm văn phòng điện tử mang lại nhiều lợi ích cho việc giám sát luồng công việc và tiến độ hoàn thành.
  * Tối ưu hóa quy trình làm việc: Hệ thống cho phép tự động hóa quy trình xử lý văn bản, giảm thiểu thời gian và công sức cho nhân viên. Việc giao nhận văn bản, phê duyệt và theo dõi tiến độ công việc trở nên dễ dàng và minh bạch hơn. Việc tạo luồng quy trình xử lý văn bản được tùy chỉnh theo các nhu cầu khác nhau theo phân cấp Bệnh viên và cấp từng Khoa Phòng.


_Giao diện quản lý luồng văn bản trên phần mềm văn phòng điện tử_
  * Nâng cao hiệu quả công việc: Phần mềm giúp phân công nhiệm vụ rõ ràng, cụ thể và theo dõi tiến độ hoàn thành. Ban lãnh đạo bệnh viện giao việc trực tiếp từ luồng văn bản ban hành, theo dõi được công việc đã giao trên các mẫu báo cáo công việc. Nhân viên có thể dễ dàng nhận biết nhiệm vụ được giao, thời hạn hoàn thành và báo cáo tiến độ công việc một cách hiệu quả. 


_Giao diện quản lý công việc trong phân hệ công việc_
  * Quản lý thông tin tập trung: Tất cả các văn bản, tài liệu và thông tin liên quan đều được lưu trữ tập trung trên hệ thống, giúp việc tra cứu và quản lý trở nên thuận tiện, nhanh chóng và chính xác.


_Giao diện Văn bản đã tiếp nhận trong phân hệ Văn bản đến_
  * Tăng cường tính minh bạch và trách nhiệm: Hệ thống cho phép theo dõi và ghi nhận mọi hoạt động, từ đó nâng cao tính minh bạch và trách nhiệm của từng nhân viên trong quá trình thực hiện công việc.


**Góp phần cải tiến trong đánh giá hoàn thành nhiệm vụ**
Việc đánh giá hoàn thành nhiệm vụ thông qua hệ thống quản lý văn bản và giao việc mang lại nhiều ưu điểm như sau:
  * Công bằng và khách quan: Hệ thống tự động ghi nhận mọi hoạt động và tiến độ công việc của từng nhân viên, giúp đánh giá kết quả làm việc một cách công bằng và khách quan dựa trên dữ liệu thực tế. Quy trình báo cáo hoàn thành công việc yêu cầu có bằng chứng gửi lên hệ thống và được phê duyệt thì mới được xác nhận hoàn thành công việc, giúp mỗi công việc tạo ra đều được phân trách nhiệm từ đầu đến cuối quá trình thực hiện.


_Giao diện Công việc tôi giao trong phân hệ Công việc_
  * Dễ dàng theo dõi và đánh giá: Người quản lý có thể dễ dàng theo dõi tiến độ công việc của từng nhân viên, từ đó đưa ra đánh giá chính xác về hiệu suất làm việc. Các chỉ số như thời gian hoàn thành nhiệm vụ, chất lượng công việc và mức độ tuân thủ quy trình được thể hiện rõ ràng trên hệ thống.


_Giao diện Báo cáo tiến độ hoàn thành công việc_
  * Đưa ra phản hồi kịp thời: Thông qua hệ thống, quản lý có thể đưa ra phản hồi kịp thời cho nhân viên, giúp cải thiện hiệu suất làm việc và khắc phục những điểm yếu còn tồn tại.
  * Khuyến khích sự phát triển cá nhân: Việc đánh giá minh bạch và khách quan giúp nhân viên nhận thức rõ ràng về hiệu quả công việc của mình, từ đó có động lực phát triển và hoàn thiện bản thân.


Việc áp dụng hệ thống quản lý văn bản và giao việc của phần mềm văn phòng điện tử - MobiFone eOffice tại Bệnh viện Nguyễn Tri Phương không chỉ giúp tối ưu hóa quy trình làm việc mà còn mang lại nhiều lợi ích trong việc đánh giá mức độ hoàn thành nhiệm vụ của nhân viên. Hệ thống này đã chứng minh được tính hiệu quả và ưu việt trong việc nâng cao hiệu suất làm việc, đảm bảo tính minh bạch và công bằng trong đánh giá hiệu quả công việc của nhân viên. Điều này không chỉ góp phần nâng cao chất lượng dịch vụ y tế mà còn thúc đẩy sự phát triển bền vững của bệnh viện trong tương lai.

## Đồng bộ công tác triển khai văn bản và luồng phân công qua một phần mềm quản lý

Việc áp dụng hệ thống văn phòng điện tử MobiFone eOffice tại bệnh viện Nguyễn Tri Phương đã góp phần cải cách trong thủ tục hành chính, đặc biệt là nhờ tính năng kết hợp xử lý văn bản và giao việc trên cùng một luồng xử lý.
Văn phòng điện tử eOffice là một hệ thống quản lý văn phòng điện tử hiện đại, cho phép số hóa toàn bộ quy trình xử lý văn bản từ khâu tiếp nhận, phê duyệt đến lưu trữ. Hệ thống giúp loại bỏ hoàn toàn việc sử dụng giấy tờ thủ công, tiết kiệm thời gian và giảm chi phí. Văn bản được truyền tải nhanh chóng qua các bước xử lý, đảm bảo sự liên thông mượt mà giữa các phòng ban và nhân viên.
_Giao diện quản lý luồng văn bản trên phần mềm văn phòng điện tử_
Bên cạnh đó, tính năng giao việc là một phần không thể thiếu của eOffice đã hỗ trợ hiệu quả cho người quản lý trong việc theo dõi đồng thời cả triển khai văn bản và giao việc. Người quản lý có thể dễ dàng phân công nhiệm vụ cho từng cá nhân hoặc nhóm, theo dõi tiến độ công việc theo thời gian thực và đưa ra các điều chỉnh kịp thời nếu cần. Điều này giúp tăng cường tính minh bạch và trách nhiệm trong việc hoàn thành nhiệm vụ, đồng thời giảm thiểu tình trạng chậm trễ trong xử lý công việc.
_Giao diện quản lý công việc trong phân hệ công việc_
Sự kết hợp giữa hệ thống xử lý văn bản và tính năng giao việc trong cùng một luồng xử lý đã tạo nên một quy trình làm việc liên tục và hiệu quả. Mọi tài liệu và nhiệm vụ đều được gắn kết chặt chẽ, giúp việc phối hợp giữa các bộ phận trở nên dễ dàng hơn, đồng thời đảm bảo sự đồng bộ và thông suốt trong quá trình làm việc. Việc triển khai hệ thống văn phòng điện tử eOffice tại bệnh viện Nguyễn Tri Phương, với khả năng kết hợp linh hoạt giữa xử lý văn bản và giao việc, đã mang lại một bước tiến lớn trong cải cách hành chính. Hệ thống giúp tối ưu hóa quy trình công việc, tạo sự minh bạch và tăng cường trách nhiệm trong việc hoàn thành nhiệm vụ. Nhờ đó, không chỉ nội bộ bệnh viện được hưởng lợi từ hiệu suất làm việc nâng cao, mà cả bệnh nhân cũng được phục vụ tốt hơn.
_Giao diện giao việc dựa trên văn bản đã ban hành_
**Hệ thống** văn phòng điện tử MobiFone eOffice đang triển khai không chỉ đơn thuần là một giải pháp công nghệ mà còn là động lực giúp bệnh viện tiến tới sự chuyên nghiệp và hiện đại hóa trong quản lý, góp phần cải thiện môi trường làm việc và nâng cao chất lượng dịch vụ y tế. Sự đổi mới này sẽ đóng vai trò quan trọng trong việc xây dựng một hệ thống hành chính tinh gọn, và hiệu quả, hướng đến sự phát triển bền vững trong tương lai.

## Biểu mẫu xin cấp Chứng chỉ hành nghề y (Bác sĩ, Điều dưỡng, Kỹ thuật viên)

**Biểu mẫu xin cấp giấy xác nhận quá trình thực hành:**
- [Đơn xin cấp giấy xác nhận quá trình thực hành](https://bvnguyentriphuong.com.vn/uploads/072022/files/%C4%90%C6%A1n%20xin%20x%C3%A1c%20nh%E1%BA%ADn%20qu%C3%A1%20tr%C3%ACnh%20th%E1%BB%B1c%20h%C3%A0nh.docx)
#### Nội dung trong file:

ĐƠN XIN XÁC NHẬN QUÁ TRÌNH THỰC HÀNH



Họ và tên:	
Ngày tháng năm sinh:	 	Giới tính:	
Địa chỉ cư trú:1	
Giấy chứng minh nhân dân/Số định danh cá nhân/Số hộ chiếu:	
Ngày cấp:	  Nơi cấp:2	
Điện thoại:	 Email (nếu có):	
Văn bằng chuyên môn:3	 Năm tốt nghiệp:	
Nay tôi làm đơn này kính xin Ban Giám đốc Bệnh viện Nguyễn Tri Phương xác nhận trong khoảng thời gian tôi thực hành tại khoa	
thời gian từ 4	 đến 	
do:5	, chứng chỉ hành nghề số:	 ngày cấp:	, nơi cấp:	
	hướng dẫn thực hành với sự nhận xét như sau:
Năng lực chuyên môn: 	
Đạo đức nghề nghiệp: 	
Kính trình Ban lãnh đạo Bệnh viện Nguyễn Tri Phương xem xét và chấp thuận xác nhận quá trình thực hành./.

1 Ghi địa chỉ cư trú/ địa chỉ tạm trú tại thành phố Hồ Chí Minh.
2 Ghi đơn vị cấp (mặt phía sau tại vị trí chữ ký chứng minh nhân dân / Căn cước công dân)
Vd:	Chứng minh nhân dân: Công An Tỉnh……
Căn cước công dân: Cục Cảnh sát ĐKQL cư trú và DLQG về dân cư / Cục Cảnh sát QLHC về TTXH.
3 Ghi văn bằng chuyên môn cao nhất.
4 Ghi cụ thể thời gian thực hành: (xem trong tờ hướng dẫn thủ tục cấp giấy xác nhận quá trình thực hành)
5 Ghi đầy đủ học hàm và họ tên người hướng dẫn thực hành. Lưu ý: người hướng dẫn thực hành phải có học hàm ngang bằng hoặc cao hơn và đã có chứng chỉ hành nghề được 3 năm trở lên so với ngày bắt đầu thực hành tại mục 4.
Vd: Người xin xác nhận quá trình thực hành là BS. Nguyễn Văn A, thời gian thực hành từ ngày 01/02/2017 thì người hướng dẫn phải là BS hoặc BS. CKI, CKII và có chứng chỉ hành nghề cấp trước ngày 01/02/2014 (nhiều hơn 03 năm trở về trước so với ngày 01/02/2017)
- [Nhận xét quá trình thực hành](https://bvnguyentriphuong.com.vn/uploads/072022/files/Nh%E1%BA%ADn%20x%C3%A9t%20qu%C3%A1%20tr%C3%ACnh%20th%E1%BB%B1c%20h%C3%A0nh.docx)
#### Nội dung trong file:

NHẬN XÉT VỀ QUÁ TRÌNH THỰC HÀNH




Học viên được đánh giá:	
Ngày tháng năm sinh:	 
Giới tính: 		 Nam		 Nữ
Địa chỉ cư trú: 1	
Giấy chứng minh nhân dân/Số định danh cá nhân/Số hộ chiếu:2	
Ngày cấp ......................................... Nơi cấp: 3	
Văn bằng chuyên môn: ..................................................... Năm tốt nghiệp:	
Đơn vị công tác (nếu có):	
Đã thực hành tại khoa:	
Thời gian: từ 4	 đến	
Đánh giá về chất lượng thực hành: 
Thời gian thực hành:4	đến	
Năng lực chuyên môn:5	
Đạo đức nghề nghiệp: 6	

Xét từ những vấn đề trên, khoa đề nghị (chỉ đánh dấu 01 trong 03 mục lựa chọn sau):
 	Cấp Giấy xác nhận quá trình thực hành cho học viên.
 	Học viên cần thực hành lại để xem xét cấp Giấy xác nhận quá trình thực hành.
 	Không cấp Giấy xác nhận quá trình thực hành cho học viên.
Các ý kiến khác:
		





1 Ghi địa chỉ cư trú / địa chỉ tạm trú tại thành phố Hồ Chí Minh
2 Ghi một trong ba thông tin về số chứng minh nhân dân hoặc số định danh cá nhân hoặc số hộ chiếu còn hạn sử dụng.
3 Ghi đơn vị cấp (mặt phía sau tại vị trí chữ ký chứng minh nhân dân / Căn cước công dân)
Vd:	Chứng minh nhân dân: Công An Tỉnh……
Căn cước công dân: Cục Cảnh sát ĐKQL cư trú và DLQG về dân cư / Cục Cảnh sát QLHC về TTXH.
4 Ghi cụ thể thời gian thực hành: (xem trong hướng dẫn thủ tục cấp giấy xác nhận quá trình thực hành)
5 Nhận xét cụ thể về khả năng thực hiện các kỹ thuật chuyên môn theo chuyên khoa đăng ký thực hành( Xét theo chương trình đào tạo cụ thể của Khoa).
6 Nhận xét cụ thể về năng lực, giao tiếp, ứng xử của người đăng ký thực hành đối với đồng nghiệp và người bệnh.
**Biểu mẫu Cấp chứng chỉ hành nghề**
  * **Trường hợp mới cấp lần đầu:**
    *     *     * [Giấy xác nhận quá trình thực hành](https://bvnguyentriphuong.com.vn/uploads/072022/files/Gi%E1%BA%A5y%20x%C3%A1c%20nh%E1%BA%ADn%20th%E1%BB%9Di%20gian%20th%E1%BB%B1c%20h%C3%A0nh.docx)
#### Nội dung trong file:

GIẤY XÁC NHẬN QUÁ TRÌNH THỰC HÀNH
Bệnh viện Nguyễn Tri Phương xác nhận:

Ông/bà: …………………………………….	
Ngày, tháng, năm sinh: Ngày ……tháng …….năm …………...
Địa chỉ cư trú: ……………………………………………………………………..
Giấy chứng minh nhân dân/Số định danh cá nhân/Số hộ chiếu: ………………...
Ngày cấp: Ngày ……… tháng ………..năm ………….      
Nơi cấp: ………..	.
Văn bằng chuyên môn: 	.	Năm tốt nghiệp: ………..
Đã thực hành tại Bệnh viện Nguyễn Tri Phương do …………………………. chứng chỉ hành nghề số ……………………………….. hướng dẫn và đạt kết quả như sau:
1. Thời gian thực hành: Từ ngày ……. tháng …… năm ………đến ………….
2. Năng lực chuyên môn: …………………………………………………………….
3. Đạo đức nghề nghiệp: …………………………………………………………….
    * Giấy khám sức khỏe theo khám sức khỏe thông tư 14/2013/TT-BYT.


  * **Trường hợp Thay đổi phạm vi hoạt động chuyên môn:**
    * [Đơn xin Cấp thay đổi phạm vi hoạt động chuyên môn trong chứng chỉ hành nghề khám bệnh, chữa bệnh](https://bvnguyentriphuong.com.vn/uploads/072022/files/%C4%90%C6%A1n%20%C4%91%E1%BB%81%20ngh%E1%BB%8B%20c%E1%BA%A5p%20thay%20%C4%91%E1%BB%95i%20ph%E1%BA%A1m%20vi%20ho%E1%BA%A1t%20%C4%91%E1%BB%99ng%20chuy%C3%AAn%20m%C3%B4n%20trong%20ch%E1%BB%A9ng%20ch%E1%BB%89%20h%C3%A0nh%20ngh%E1%BB%81%20kh%C3%A1m%20b%E1%BB%87nh%2C%20ch%E1%BB%AFa%20b%E1%BB%87nh.docx)
#### Nội dung trong file:

ĐƠN ĐỀ NGHỊ
Cấp thay đổi phạm vi hoạt động chuyên môn trong chứng chỉ hành nghề khám bệnh, chữa bệnh


Họ và tên:	
Ngày, tháng, năm sinh:	
Địa chỉ cư trú:4	
Giấy chứng minh nhân dân/Số định danh cá nhân/Số hộ chiếu: 1	
Ngày cấp ........................................... Nơi cấp:	
Điện thoại: .......................................... Email (nếu có):	
Văn bằng chuyên môn: 2	
Số chứng chỉ hành nghề:.......................... Ngày cấp: .................. Nơi cấp:	
Phạm vi hoạt động chuyên môn đã được cấp:	
Phạm vi hoạt động chuyên môn đề nghị thay đổi:	
Tôi xin gửi kèm theo đơn này bộ hồ sơ bao gồm các giấy tờ sau đây: 3
Kính đề nghị quý cơ quan xem xét và cấp thay đổi phạm vi hoạt động chuyên môn trong chứng chỉ hành nghề khám bệnh, chữa bệnh cho tôi./.















1 Ghi một trong ba thông tin về số chứng minh nhân dân hoặc số định danh cá nhân hoặc số hộ chiếu còn hạn sử dụng. Nơi cấp CMND/CCCD: ghi đúng nơi cấp ở mặt phía sau của chứng minh thư tại vị trí chữ ký
2 Văn bằng chuyên môn ghi theo đối tượng xin cấp chứng chỉ hành nghề quy định tại Điều 17 Luật khám bệnh, chữa bệnh hoặc các văn bằng chuyên môn khác.
3 Đánh dấu X vào ô vuông tương ứng với những giấy tờ có trong hồ sơ.
4 khai địa chỉ đang ở tại thành phố Hồ Chí Minh.
    * [Giấy xác nhận quá trình thực hành](https://bvnguyentriphuong.com.vn/uploads/072022/files/Gi%E1%BA%A5y%20x%C3%A1c%20nh%E1%BA%ADn%20th%E1%BB%9Di%20gian%20th%E1%BB%B1c%20h%C3%A0nh.docx)
#### Nội dung trong file:

GIẤY XÁC NHẬN QUÁ TRÌNH THỰC HÀNH
Bệnh viện Nguyễn Tri Phương xác nhận:

Ông/bà: …………………………………….	
Ngày, tháng, năm sinh: Ngày ……tháng …….năm …………...
Địa chỉ cư trú: ……………………………………………………………………..
Giấy chứng minh nhân dân/Số định danh cá nhân/Số hộ chiếu: ………………...
Ngày cấp: Ngày ……… tháng ………..năm ………….      
Nơi cấp: ………..	.
Văn bằng chuyên môn: 	.	Năm tốt nghiệp: ………..
Đã thực hành tại Bệnh viện Nguyễn Tri Phương do …………………………. chứng chỉ hành nghề số ……………………………….. hướng dẫn và đạt kết quả như sau:
1. Thời gian thực hành: Từ ngày ……. tháng …… năm ………đến ………….
2. Năng lực chuyên môn: …………………………………………………………….
3. Đạo đức nghề nghiệp: …………………………………………………………….


  * **​​​​​​​Trường hợp Bổ sung phạm vi hoạt động chuyên môn:**
    * ​​​​​​​Đ[ơn xin bổ sung phạm vi hoạt động chuyên môn trong chứng chỉ hành nghề khám bệnh, chữa bệnh.](https://bvnguyentriphuong.com.vn/uploads/072022/files/%C4%90%C6%A1n%20%C4%91%E1%BB%81%20ngh%E1%BB%8B%20c%E1%BA%A5p%20thay%20%C4%91%E1%BB%95i%20ph%E1%BA%A1m%20vi%20ho%E1%BA%A1t%20%C4%91%E1%BB%99ng%20chuy%C3%AAn%20m%C3%B4n%20trong%20ch%E1%BB%A9ng%20ch%E1%BB%89%20h%C3%A0nh%20ngh%E1%BB%81%20kh%C3%A1m%20b%E1%BB%87nh%2C%20ch%E1%BB%AFa%20b%E1%BB%87nh\(1\).docx)
    * [Giấy xác nhận quá trình thực hành](https://bvnguyentriphuong.com.vn/uploads/072022/files/Gi%E1%BA%A5y%20x%C3%A1c%20nh%E1%BA%ADn%20th%E1%BB%9Di%20gian%20th%E1%BB%B1c%20h%C3%A0nh.docx)
#### Nội dung trong file:

GIẤY XÁC NHẬN QUÁ TRÌNH THỰC HÀNH
Bệnh viện Nguyễn Tri Phương xác nhận:

Ông/bà: …………………………………….	
Ngày, tháng, năm sinh: Ngày ……tháng …….năm …………...
Địa chỉ cư trú: ……………………………………………………………………..
Giấy chứng minh nhân dân/Số định danh cá nhân/Số hộ chiếu: ………………...
Ngày cấp: Ngày ……… tháng ………..năm ………….      
Nơi cấp: ………..	.
Văn bằng chuyên môn: 	.	Năm tốt nghiệp: ………..
Đã thực hành tại Bệnh viện Nguyễn Tri Phương do …………………………. chứng chỉ hành nghề số ……………………………….. hướng dẫn và đạt kết quả như sau:
1. Thời gian thực hành: Từ ngày ……. tháng …… năm ………đến ………….
2. Năng lực chuyên môn: …………………………………………………………….
3. Đạo đức nghề nghiệp: …………………………………………………………….


  * **Trường hợp Cấp lại chứng chỉ hành nghề do:​​​​​​​**
    * _CCHN được cấp không đúng thẩm quyền._
    * _CCHN có nội dung trái pháp luật._
    * ​​​​​​​Biểu mẫu gồm:
      * **​​​​​​​**[Đơn xin cấp lại chứng chỉ hành nghề.](https://bvnguyentriphuong.com.vn/uploads/072022/files/%C4%90%C6%A1n%20%C4%91%E1%BB%81%20ngh%E1%BB%8B%20c%E1%BA%A5p%20l%E1%BA%A1i%20ch%E1%BB%A9ng%20ch%E1%BB%89%20h%C3%A0nh%20ngh%E1%BB%81%20kh%C3%A1m%20b%E1%BB%87nh%2C%20ch%E1%BB%AFa%20b%E1%BB%87nh.docx)
#### Nội dung trong file:

ĐƠN ĐỀ NGHỊ
Cấp lại chứng chỉ hành nghề khám bệnh, chữa bệnh


Họ và tên: 	
Ngày, tháng, năm sinh: 	
Địa chỉ cư trú: 	
Giấy chứng minh nhân dân/Số định danh cá nhân/Số hộ chiếu: 1 	
Ngày cấp ...................................... Nơi cấp: 	
Điện thoại: ................................... Email (nếu có): 	
Văn bằng chuyên môn: 2 ...........................................	
Số chứng chỉ hành nghề đã được cấp (nếu có): 	
Ngày cấp: ...................................... Nơi cấp: 	
Lý do xin cấp lại : 3
Tôi xin gửi kèm theo đơn này bộ hồ sơ bao gồm các giấy tờ sau đây: 3
Kính đề nghị quý cơ quan xem xét và cấp lại chứng chỉ hành nghề khám bệnh, chữa bệnh cho tôi./.
 












1 Ghi một trong ba thông tin về số chứng minh nhân dân hoặc số định danh cá nhân hoặc số hộ chiếu còn hạn sử dụng.
2 Văn bằng chuyên môn ghi theo đối tượng xin cấp chứng chỉ hành nghề quy định tại Điều 17 Luật khám bệnh, chữa bệnh hoặc các văn bằng chuyên môn khác.
3 Đánh dấu X vào ô vuông tương ứng với lý do đề nghị cấp lại chứng chỉ hành nghề.
      * 

  * ​​​​​​​​​​​​​​​​​​​​​**Trường hợp cấp lại chứng chỉ hành nghề do** :​​​​​​​
    * _NHN không hành nghề trong thời hạn 02 năm liên tục._
    * _NHN được xác định có sai sót chuyên môn kỹ thuật gây hậu quả nghiêm trọng đến sức khỏe, tính mạng người bệnh.NHN không cập nhật kiến thức y khoa liên tục trong thời gian 02 năm liên tiếp._
    * _NHN không đủ sức khỏe để hành nghề._
    * _NHN thuộc một trong các đối tượng (quy định tại khoản 04 Điều 18 của Luật khám bệnh, chữa bệnh):_
      * _Đang trong thời gian bị cấm hành nghề, cấm làm công việc liên quan đến chuyên môn y, dược theo bản án, quyết định của Tòa án._
      * _Đang bị truy cứu trách nhiệm hình sự._
      * _Đang trong thời gian chấp hành bản án hình sự, quyết định hình sự của Tòa án hoặc quyết định áp dụng biện pháp xử lý hành chính đưa vào cơ sở giáo dục, cơ sở chữa bệnh._
      * _Đang trong thời gian bị kỷ luật từ hình thức cảnh cáo trở lên có liên quan đến chuyên môn khám bệnh, chữa bệnh._
      * _Mất hoặc hạn chế năng lực hành vi dân sự._
    * ​​​​​​​Biểu mẫu gồm:
      * [​​​​​​​Đơn xin cấp lại chứng chỉ hành nghề](https://bvnguyentriphuong.com.vn/uploads/072022/files/%C4%90%C6%A1n%20%C4%91%E1%BB%81%20ngh%E1%BB%8B%20c%E1%BA%A5p%20l%E1%BA%A1i%20ch%E1%BB%A9ng%20ch%E1%BB%89%20h%C3%A0nh%20ngh%E1%BB%81%20kh%C3%A1m%20b%E1%BB%87nh%2C%20ch%E1%BB%AFa%20b%E1%BB%87nh\(1\).docx)
      * 

  * **Trường hợp thay đổi họ tên, ngày tháng năm sinh trong chứng chỉ hành nghề**
    * [Đơn đề nghị Thay đổi họ và tên, ngày tháng năm sinh trong chứng chỉ hành nghề khám bệnh, chữa bệnh](https://bvnguyentriphuong.com.vn/uploads/072022/files/%C4%90%C6%A1n%20%C4%91%E1%BB%81%20ngh%E1%BB%8B%20thay%20%C4%91%E1%BB%95i%20h%E1%BB%8D%20v%C3%A0%20t%C3%AAn%2C%20ng%C3%A0y%20th%C3%A1ng%20n%C4%83m%20sinh%20trong%20ch%E1%BB%A9ng%20ch%E1%BB%89%20h%C3%A0nh%20ngh%E1%BB%81%20kh%C3%A1m%20b%E1%BB%87nh%2C%20ch%E1%BB%AFa%20b%E1%BB%87nh\(1\).docx)


**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/) **- Đa khoa Hạng I Thành phố Hồ Chí Minh
​​​​​​​​​​​​​​**​​​​​​​​​​​​​​**

## Thủ tục: Cấp giấy khám sức khỏe định kỳ đối với người lái xe ô tô

Tên thủ tục: | Thủ tục Cấp Giấy khám sức khỏe định kỳ đối với người lái xe ô tô  
---|---  
Cơ quan thực hiện: | Cơ sở khám bệnh, chữa bệnh  
Cơ sở pháp lý: | - Luật khám bệnh, chữa bệnh ngày 23 tháng 11 năm 2009, có hiệu lực từ ngày 01 tháng 01 năm 2011; - Luật Giao thông đường bộ số 23/2008/QH12 ngày 13 tháng 11 năm 2008,có hiệu lực từ ngày 01/7/2009; - Nghị Định số 87/2011/NĐ-CP ngày 27/9/2011 của Chính Phủ quy định chi tiết và hướng dẫn thi hành một số điều của Luật Khám bệnh, chữa bệnh, có hiệu lực từ ngày 15 tháng 11 năm 2011; - Thông tư số 14/2013/TT-BYT ngày 06/5/2013 của Bộ Y tế Hướng dẫn Khám sức khỏe, có hiệu lực từ ngày 01 tháng 7 năm 2013; - Thông tư số 24/2015/TTLT-BYT-BGTVT ngày 21/8/2015 của Bộ Y tế và Bộ Giao thông Vận tải quy định về tiêu chuẩn sức khỏe của người lái xe, việc khám sức khỏe định kỳ đối với người lái xe ô tô và quy định về cơ sở y tế khám sức khỏe cho người lái xe, có hiệu lực từ ngày 10 tháng 10 năm 2015.  
Trình tự thực hiện: | - Bước 1: Cá nhân/Tổ chức có nhu cầu khám sức khỏe định kỳ đến các cơ sở khám sức khỏe đủ điều kiện khám sức khỏe (KSK) theo quy định, nộp hồ sơ khám sức khỏe vào các ngày làm việc từ thứ hai đến thứ sáu (buổi sáng từ 07 giờ 30 phút đến 12 giờ 00 phút, buổi chiều từ 13 giờ 00 phút đến 16 giờ 30 phút). Khi cơ sở KSK triển khai khám chữa bệnh định kỳ theo hợp đồng, các cơ sở đã ký hợp đồng cần xuất trình hồ sơ khám sức khỏe (đối với khám sức khỏe tập trung). Đối với khám sức khỏe đơn lẻ: người khám sức khỏe cần xuất trình thêm giấy giới thiệu của cơ quan, tổ chức đề nghị khám sức khỏe định kỳ. - Bước 2: Cơ sở KBCB đối chiếu ảnh trong hồ sơ KSK với người đến KSK, đóng dấu giáp lai vào ảnh sau khi đã thực hiện việc đối chiếu, hướng dẫn quy trình KSK cho người được KSK. Cơ sở KBCB thực hiện việc KSK theo quy trình. - Bước 3: Kết luận và trả Sổ khám sức khỏe cho người được khám sức khỏe.  
Cách thức thực hiện: | Trực tiếp tại cơ sở khám bệnh, chữa bệnh  
Thành phần và số lượng: | - Thành phần hồ sơ: + Sổ KSK định kỳ theo mẫu quy định tại Phụ lục 3- Thông tư liên tịch số 24/2015/TTLT-BYT-BGTVT ngày 21/8/2015; + Giấy giới thiệu của cơ quan, tổ chức nơi người đó đang làm việc đối với trường hợp KSK định kỳ đơn lẻ hoặc có tên trong danh sách KSK định kỳ do cơ quan, tổ chức nơi người đó đang làm việc xác nhận để thực hiện KSK định kỳ theo hợp đồng. - Số lượng hồ sơ: 01 (bộ)  
Thời gian giải quyết: | KSK đơn lẻ : 24 giờ (trong ngày), trừ trường hợp phải khám hoặc xét nghiệm bổ sung theo yêu cầu của người thực hiện KSK KSK tập thể: theo thỏa thuận ghi trong hợp đồng  
Đối tượng thực hiện: | Cá nhân/Tổ chức  
Kết quả: | Giấy khám sức khỏe  
Yêu cầu và điều kiện: | Không có  
Lệ phí: | Nộp theo mức phí thu phí hiện hành  
**Tài liệu đính kèm:**
[Mẫu khám sức khỏe cấp giấy phép lái xe](https://bvnguyentriphuong.com.vn/uploads/072022/files/thu%20tuc%20hanh%20chih_kham%20chua%20benh_43_%20Mau%20-KSKDKCNLX.pdf)
#### Nội dung trong file:



## Sau khi triển khai phần mềm ASM, BV Nguyễn Tri Phương đã nhận được nhiều lợi ích

Phần mềm ASM giúp các cơ sở thuận tiện trong việc khai báo lưu trú đúng luật Cư trú, đồng thời giúp định danh người bệnh chính xác.
Nhờ sự chính xác trong thông tin về nhân thân của người bệnh, mà BV Nguyễn Tri Phương đã thực hiện được nhanh chóng và chính xác các thủ tục hành chính khác cho người dân như
- Cấp giấy chứng sinh
- Cấp giấy chứng tử
- Cấp giấy xác nhận nằm viện
- Cấp giấy xác nhận thương tích...
BV Nguyễn Tri Phương mong rằng tất cả người dân đều ủng hộ và nhanh chóng thực hiện thẻ CCCD có gắn chip, từ đó giúp cho các thủ tục hành chính tại BV sẽ thêm nhanh chóng, chính xác, hiệu quả./.

## Mẫu Giấy chứng nhận nghỉ việc hưởng bảo hiểm xã hội

Mẫu Giấy xác nhân chứng nhận nghỉ việc hưởng bảo hiểm xã hội được dùng để xác nhận số ngày nghỉ việc của người lao động để chăm con ốm hoặc để điều trị ngoại trú do ốm đau, thai sản, làm căn cứ tính trợ cấp bảo hiểm xã hội theo quy định của pháp luật bảo hiểm xã hội. 
MẪU GIẤY CHỨNG NHẬN NGHỈ VIỆC HƯỞNG BẢO HIỂM XÃ HỘI _(Kèm theo Thông tư số_ _56_ _/20_ _1_ _7/TT-BYT ngày_ _29_ _tháng_ _12 nă_ _m 20_ _1_ _7 của Bộ trưởng Bộ Y tế)_

## Mẫu giấy chuyển tuyến bảo hiểm y tế theo quy định

Cơ quan chủ quản 1:…
**CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM**
Độc lập - Tự do - Hạnh phúc
Số Hồ sơ: ……
Vào sổ chuyển tuyến số: ………..
**Tên cơ sở KBCB** 2:…
Số: ……../20…/GCT
**GIẤY CHUYỂN TUYẾN**
**Kính gửi:** ……………………………………………………………………………...
Cơ sở KBCB2 : …………………………………………… trân trọng giới thiệu:
- Họ và tên người bệnh: ……………………… Nam/Nữ:……..… Tuổi: ...............................
- Địa chỉ: .............................................................................................................
- Dân tộc: ……………………………..... Quốc tịch:..................................................
- Nghề nghiệp: ………………………… Nơi làm việc...............................................
- BHYT: giá trị từ …./…./….. đến …./…../….. Số thẻ: .........................................
Đã được khám bệnh/điều trị:
+ Tại: ……………….(Tuyến………) Từ ngày ……/……/…….. đến ngày ……./...../………
+ Tại: …………….....(Tuyến………) Từ ngày ……/……/…….. đến ngày ……./...../……...
**TÓM TẮT BỆNH ÁN**
- Dấu hiệu lâm sàng: ..........................................................................................................
- Kết quả xét nghiệm, cận lâm sàng 3:................................................................................
- Chẩn đoán:........................................................................................................................
- Phương pháp, thủ thuật, kỹ thuật, thuốc đã sử dụng trong điều trị: .................................
- Tình trạng người bệnh lúc chuyển tuyến: ..........................................................................
- Lí do chuyển tuyến: Khoanh tròn vào lý do chuyển tuyến phù hợp sau đây:
1. Đủ điều kiện chuyển tuyến.
2. Theo yêu cầu của người bệnh hoặc người đại diện hợp pháp của người bệnh.
- Hướng điều trị 4: ..........................................................................................
- Chuyển tuyến hồi: …….giờ ……phút, ngày …… tháng ……. năm 20.........
- Phương tiện vận chuyển: ..............................................................
- Họ tên, chức danh, trình độ chuyên môn của người hộ tống: ............................
**Y, BÁC SĨ KHÁM, ĐIỀU TRỊ**
(Ký và ghi rõ họ tên)
Ngày …. tháng ….. năm 20…
**NGƯỜI CÓ THẨM QUYỀN CHUYỂN TUYẾN****5**
(Ký tên, đóng dấu)
**Ghi chú:**
1. Cơ quan chủ quản: Bộ Y tế/Sở Y tế/Cục Y tế (đối với y tế bộ, ngành)...
2. Cơ sở KB, CB: Bệnh viện/ Phòng khám/ Trạm Y tế...
3. Kết quả xét nghiệm, cận lâm sàng: bao gồm xét nghiệm sinh hóa, huyết học, GPB, thăm dò chức năng, chẩn đoán hình ảnh...
4. Hướng điều trị: đối với trường hợp cơ sở khám bệnh, chữa bệnh tuyến trên chuyển người bệnh về tuyến dưới điều trị.
5. Người có thẩm quyền chuyển tuyến là người đứng đầu cơ sở khám bệnh, chữa bệnh hoặc người chịu trách nhiệm chuyên môn hoặc người được ủy quyền.
#### *** Cách xin giấy chuyển tuyến BHYT**
Nếu bạn muốn xin giấy chuyển tuyến bảo hiểm y tế, bạn cần thực hiện các bước sau đây:
_Bước 1_ : Cơ sở khám chữa bệnh cần thông báo và giải thích rõ lý do chuyển tuyến cho bạn hoặc người đại diện hợp pháp của bạn.
_Bước 2_ : Người đại diện cơ sở khám chữa bệnh ký giấy chuyển tuyến theo mẫu theo quy định.
_Bước 3_ : Làm các thủ tục kiểm tra trước khi chuyển bệnh nhân.

## Hướng dẫn thủ tục về cấp, nhận giấy chứng sinh

**I. Thủ tục cấp, nhận giấy chứng sinh:**
**1. Thủ tục cấp giấy chứng sinh:** Trẻ được sinh ra tại bệnh viện sản phụ hoặc người thân thích phải cung cấp giấy tờ sau để bệnh viện đối chiếu làm cơ sở cấp giấy chứng sinh:
  * Căn cước công dân (CCCD): Bản chính.
    * Trường hợp sản phụ mất CCCD có thể thay thế bằng hộ chiếu hoặc đơn trình báo mất giấy CCCD có hình và dấu giáp lai của cơ quan công an nơi cư trú.
    * Trường hợp không có giấy tờ tùy thân, sản phụ liên hệ công an nơi đang cư trú xin giấy xác nhận thông tin về cư trú CT07 và giấy xác nhận của công an (có hình và dấu giáp lai trên hình). 


**Trường hợp trẻ được sinh ra tại nhà hoặc tại nơi khác mà không phải là cơ sở khám bệnh, chữa bệnh:**
  * Người thân thích của trẻ có trách nhiệm điền vào Đơn đề nghị cấp Giấy chứng sinh theo mẫu quy định tại Phụ lục 02( đính kèm) ban hành kèm theo Thông tư Thông tư 17/2012 TT- BYT và nộp cho trạm y tế xã, phường để xin cấp Giấy chứng sinh cho trẻ. 
  * Trong thời hạn 03 ngày làm việc, kể từ ngày nhận được Đơn đề nghị cấp Giấy chứng sinh, trạm y tế xã phải xác minh việc sinh và làm thủ tục cấp Giấy chứng sinh cho trẻ. 
  * Trong trường hợp cần phải xác minh, thì thời hạn xác minh không được quá 05 ngày làm việc. 


**2. Thủ tục nhận giấy chứng sinh:**
Khi nhận giấy chứng sinh, sản phụ hoặc người thân thích phải cung cấp giấy tờ sau:
**a. Đối với sản phụ:**
  * Căn cước công dân (CCCD)/Chứng minh nhân dân (CMND)/Hộ chiếu;
  * Giấy ra viện;
  * Hóa đơn thanh toán viện phí.


**b. Đối với người có quan hệ hôn nhân (chồng)**
  * CCCD/CMND/Hộ chiếu (của sản phụ và chồng);
  * Giấy ra viện;
  * Hóa đơn thanh toán viện phí;
  * Giấy đăng ký kết hôn hoặc kiểm tra thông tin trên App định danh điện tử VNeID của người thân thích (Dữ liệu quốc gia về dân cư thể hiện mối quan hệ người thân thích).


**c. Đối với người có cùng dòng máu về trực hệ và người có họ trong phạm vi ba đời:**
  * CCCD/CMND/Hộ chiếu (của sản phụ và người thân thích);
  * Giấy ra viện;
  * Hóa đơn thanh toán viện phí;
  * Giấy Thông báo “Số định danh cá nhân và thông tin công dân trong Cơ sở dữ liệu quốc gia về dân cư” do Công An phường cung cấp hoặc giấy khai sinh của sản phụ và người thân thích hoặc kiểm tra thông tin trên App định danh điện tử VNeID của người thân thích (Dữ liệu quốc gia về dân cư thể hiện mối quan hệ người thân thích).


**d. Đối với người có quan hệ nuôi dưỡng:**
  * CCCD/CMND/Hộ chiếu (của sản phụ và người nuôi dưỡng);
  * Giấy ra viện;
  * Hóa đơn thanh toán viện phí;
  * Giấy khai sinh;
  * Giấy xác nhận nuôi dưỡng, giấy xác nhận đơn vị bảo trợ xã hội.


**e. Trường hợp khác:**
  * Người có Giấy ủy quyền của sản phụ; 
  * Giấy tờ tùy thân của người được ủy quyền và của sản phụ.
  * Giấy ủy quyền phải có xác nhận của chính quyền địa phương nơi người thân thích của sản phụ cư trú, trong giấy ủy quyền ghi rõ nội dung: 


_“Ủy quyền cho Ông (Bà) …………… là ………… (mối quan hệ với sản phụ) được nhận giấy chứng sinh của sản phụ tên là……..…… tại bệnh viện Nguyễn Tri Phương”._
**Lưu ý: Sản phụ hoặc người thân thích có trách nhiệm đọc, kiểm tra lại thông tin trước khi ký nhận.**
**II. Thủ tục cấp lại giấy chứng sinh:**
**1. Trường hợp đã cấp Giấy chứng sinh mà bố, mẹ, người thân thích phát hiện có nhầm lẫn khi khai thông tin:**
  * Bố, Mẹ hoặc Người thân thích của trẻ làm Đơn đề nghị cấp lại Giấy chứng sinh theo mẫu quy định tại Phụ lục 03 ban hành kèm theo Thông tư số 17/2012/TT-BYT, kèm theo giấy tờ chứng minh nội dung nhầm lẫn gửi Cơ sở khám bệnh, chữa bệnh nơi đã cấp Giấy chứng sinh cho trẻ lần đầu. 
  * Giấy giờ chứng minh nội dung nhầm lẫn:
    * Đối với trường hợp nhầm lẫn về Họ tên mẹ hoặc người nuôi dưỡng; Năm sinh; Nơi đăng ký hộ khẩu thường trú; Số chứng minh nhân dân; Dân tộc thì gửi kèm bản photo Căn cước công dân (CCCD)/ Chứng minh nhân dân (CMND) (mang theo bản chính để đối chiếu);
    * Đối với trường hợp nhầm lẫn về nơi đăng ký tạm trú thì kèm theo xác nhận của Công an khu vực về nơi đăng ký tạm trú.


**Đối với cơ sở khám bệnh, chữa bệnh:**
  * Trong thời hạn 02 ngày làm việc, kể từ ngày nhận được các giấy tờ hợp lệ, Cơ sở khám bệnh, chữa bệnh có trách nhiệm thu hồi Giấy chứng sinh có nhầm lẫn để hủy.
  * Đơn và giấy tờ chứng minh được lưu cùng với bản lưu cũ tại cơ sở khám bệnh, chữa bệnh.
  * Giấy chứng sinh được cấp lại phải ghi rõ Số, Quyển số của Giấy chứng sinh cũ và đóng dấu “CẤP LẠI”.
  * Trong trường hợp cần phải xác minh, thì thời hạn xác minh không quá 03 ngày làm việc.


**2. Trường hợp mất, rách, nát Giấy chứng sinh:**
  * Bố, Mẹ hoặc Người thân thích của trẻ làm Đơn đề nghị cấp lại Giấy chứng sinh theo mẫu quy định tại Phụ lục 03 ban hành kèm theo Thông tư số 17/2012/TT-BYT có xác nhận Ủy ban nơi thường trú (xác nhận chưa làm Giấy khai sinh cho trẻ từ ngày sản phụ sinh cho đến nay ngày/tháng/năm) gửi Cơ sở khám bệnh, chữa bệnh nơi đã cấp Giấy chứng sinh cho trẻ lần đầu.


**Đối với cơ sở khám bệnh, chữa bệnh:**
  * Cơ sở khám bệnh, chữa bệnh có trách nhiệm thu hồi Giấy chứng sinh rách, nát. Lưu lại đơn, giấy tờ chứng minh và cấp Giấy chứng sinh mới cho thân nhân của trẻ trong vòng 02 ngày làm việc.
  * Trong thời hạn 02 ngày làm việc kể từ ngày nhận được đơn, Cơ sở khám bệnh, chữa bệnh có trách nhiệm cấp lại Giấy chứng sinh mới như trường hợp cấp Giấy chứng sinh có nhầm lẫn.
  * Trong trường hợp cần phải xác minh, thì thời hạn xác minh không quá 03 ngày làm việc (trường hợp mất).


**III. Mẩu xin cấp lại chứng sinh:**
Tải mẫu đơn[**TẠI ĐÂY**](https://bvnguyentriphuong.com.vn/uploads/072022/files/M%E1%BA%AAU%20%C4%90%C6%A0N%20XIN%20C%E1%BA%A4P%20GI%E1%BA%A4Y%20CH%E1%BB%A8NG%20SINH.docx)
#### Nội dung trong file:

CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM
Độc lập - Tự do - Hạnh phúc
----------------
ĐƠN ĐỀ NGHỊ
Cấp lại Giấy chứng sinh

Kính gửi:................................................................................................................................
...............................................................................................................................................
Họ tên mẹ/người nuôi dưỡng:...............................................................................................
Số Chứng minh nhân dân/Hộ chiếu:......................................................................................
Địa chỉ:...................................................................................................................................
Sinh cháu: ngày:.................................... tháng:............................ năm: 20............................
Tại:..........................................................................................................................................
...............................................................................................................................................
Tên dự kiến của cháu:............................................................................................................
Đã được cơ quan cấp Giấy chứng sinh: tháng........... năm.............. Đề nghị cơ quan cấp lại 
Giấy chứng sinh cho cháu vì:
1- Mất/ thất lạc/ rách nát
2- Nhầm lẫn trong Giấy chứng sinh lần trước (Ghi cụ thể sự nhầm lẫn):.............................
..............................................................................................................................................
..............................................................................................................................................
..............................................................................................................................................
3- Khác             □ (Ghi cụ thể)..............................................................................................
..............................................................................................................................................
..............................................................................................................................................
**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/) **- Đa khoa Hạng I Thành phố Hồ Chí Minh

## SỬ DỤNG CĂN CƯỚC CÔNG DÂN THAY CHO THẺ BHYT KHI ĐI KHÁM BỆNH TẠI BỆNH VIỆN

Ngày 28/2/2022, Bộ Y Tế có Công văn số 931/BYT-BH về việc hướng dẫn triển khai thí điểm Khám chữa bệnh BHYT bằng CCCD gắn chíp, theo đó thời gian vừa qua, Bảo hiểm xã hội Việt Nam đã phối hợp với Bộ Công an thực hiện từng bước đồng bộ dữ liệu quốc gia về bảo hiểm với dữ liệu quốc gia về dân cư, xây dựng các giải pháp kỹ thuật để đảm bảo việc tra cứu thông tin về BHYT qua thẻ CCCD gắn chíp. Nhiều người dân đã được tích hợp thông tin về bảo hiểm y tế trong dữ liệu về CCCD.
Theo đó, Bộ Y Tế hướng dẫn triển khai tiếp đón, tổ chức khám chữa bệnh cho người bệnh có CCCD gắn chíp tích hợp mã thẻ BHYT hoặc qua ứng dụng VNEID, trong đó cần lưu ý một số nội dung sau:
_**Một là,**_ Cơ sở khám chữa bệnh thông báo công khai cho người bệnh biết và triển khai tiếp đón người bệnh khi đi khám chữa bệnh BHYT bằng CCCD có gắn chíp hoặc qua ứng dụng VNeID (_**chỉ áp dụng đối với công dân đã đăng ký thành công tài khoản định danh điện tử do Bộ Công an cung cấp**_).
_**Hai là**_ , đối với người bệnh đã được cấp CCCD có gắn chíp:
- Trường hợp khi kiểm tra CCCD (quét mã QR code) hoặc qua ứng dụng VNeID đã có thông tin hợp lệ về tham gia BHYT thì cơ sở khám chữa bệnh thực hiện kiểm tra, đối chiếu thông tin về BHYT và tiếp đón người bệnh theo quy trình khám chữa bệnh BHYT hiện hành; đồng thời thông tin cho người bệnh biết để đi khám chữa bệnh BHYT kể từ lần sau bằng CCCD gắn chíp hoặc bằng ứng dụng VNeID;
- Trường hợp khi kiểm tra thông tin nhưng không có thông tin hợp lệ về tham gia BHYT: Giải thích để người bệnh đó biết tình trạng của thẻ BHYT trên CCCD chưa thể thực hiện được; thực hiện tiếp đón người bệnh theo quy trình khám chữa bệnh BHYT hiện hành (_xuất trình thẻ BHYT và giấy tờ tùy thân có ảnh_).
Hiện nay về cơ bản, người dân ở các địa phương đều có thể sử dụng thẻ CCCD gắn chíp thay cho thẻ BHYT để khám chữa bệnh BHYT.
Vì vậy, nếu đã được cấp thẻ CCCD gắn chíp, người bệnh chỉ cần mang theo CCCD và không cần đem thẻ BHYT giấy đi cùng khi đến khám, chữa bệnh mà vẫn được giải quyết hưởng quyền lợi BHYT.
Khi đi khám, chữa bệnh, người bệnh xuất trình CCCD gắn chíp cho nhân viên y tế để được quét mã QR code kiểm tra thông tin và làm thủ tục khám, chữa bệnh theo đúng quy trình.

## Hướng dẫn thủ tục cấp tóm tắt hồ sơ bệnh án

**I. Đối với cá nhân ( Bệnh nhân, người thân thích của Bệnh nhân):**
Cung cấp các giấy tờ sau:
  * Đơn xin cấp tóm tắt bệnh án (theo mẫu) tại Phòng Kế Hoạch Tổng Hợp
  * Giấy ra viện bản chính hoặc bản photo của bệnh nhân.
  * Căn cước công dân bản chính hoặc bản photo của bệnh nhân.
  * Giấy tờ tùy thân của cá nhân .


**II. Đối với cơ quan/tổ chức/đơn vị:**
Cung cấp các giấy tờ sau: 
  * Giấy giới thiệu liên hệ công tác của cơ quan/tổ chức/ đơn vị
  * Giấy ra viện bản photo của bệnh nhân.
  * Căn cước công dân bản photo của bệnh nhân.
  * Giấy tờ tùy thân của cá nhân đại diện tổ chức đến liên hệ công tác.


* Nhân viên phòng Kế hoạch Tổng Hợp tiếp nhận, kiểm tra tính xác thực của giấy giới thiệu, đơn đề nghị và cung cấp giấy hẹn nhận tóm tắt hồ sơ bệnh án.( Không quá 07 ngày làm việc)
**III. Mẩu đơn xin tóm tắt bệnh án**
**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/) **- Đa khoa Hạng I Thành phố Hồ Chí Minh

## Cải cách thủ tục hành chính tại Bệnh viện Nguyễn Tri Phương: thay đổi để người dân thêm hài lòng

Với quan điểm “Lấy người bệnh làm trung tâm”, Bệnh viện Nguyễn Tri Phương luôn quan tâm tới công tác cải cách thủ tục hành chính, rút gọn các bước trong quy trình khám chữa bệnh, hướng đến sự hài lòng và an toàn của người bệnh. Để tạo thuận lợi cho người bệnh đến khám chữa bệnh, Đảng ủy - Ban Giám đốc Bệnh viện đã trực tiếp chỉ đạo thực hiện nhiều giải pháp đồng bộ, tích cực như: 
  * Tổ chức lực lượng phù hợp, sắp xếp lại từ phòng khám bệnh, phòng thu phí, phòng phát thuốc, các phòng xét nghiệm cận lâm sàng, chẩn đoán hình ảnh phù hợp hơn; 
  * Bố trí đội ngũ hướng dẫn luôn túc trực, hướng dẫn bệnh nhân và người nhà bệnh nhân một cách chu đáo và kịp thời. 
  * Cải tiến quy trình khám chữa bệnh bảo đảm hợp lý, thuận tiện như tăng thêm bàn khám, điều chỉnh nhân lực hợp lý để đáp ứng nhu cầu khám chữa bệnh trong giờ hành chính và những ngày cao điểm; bố trí khu chờ có đủ ghế ngồi, quạt mát...phục vụ chu đáo bệnh nhân và người nhà bệnh nhân. 


Để người bệnh hiểu rõ hơn quyền lợi được hưởng thụ khi tham gia khám chữa bệnh, Bệnh viện thực hiện công khai giờ khám bệnh, quy trình khám bệnh, đối tượng ưu tiên, hòm thư góp ý, đường dây nóng, quyền lợi, nghĩa vụ của người bệnh và nhân viên y tế... để người bệnh dễ quan sát. 
Bệnh viện còn bố trí khu vực chờ khám và khu vực tiếp đón người bệnh đảm bảo rộng rãi, có đủ ghế ngồi, nước uống, bố trí bảng chỉ dẫn, hướng dẫn quy trình khám bệnh, bảng giá viện phí công khai, bệnh viện thực hiện nghiêm túc việc niêm yết hòm thư góp ý, số điện thoại đường dây nóng, số điện thoại trực 24/24 giờ để tiếp nhận các ý kiến phản ánh và giải đáp thắc mắc của bệnh nhân và gia đình người bệnh.
Có thể thấy công tác cải cách hành chính được các bệnh viện chú trọng. Trung bình mỗi ngày, khoa khám bệnh của các bệnh viện tiếp nhận 1500 – 2500 lượt bệnh nhân, trong đó có đến 90% người bệnh khám chữa bệnh bằng thẻ Bảo hiểm y tế. Do đó với việc ứng dụng công nghệ thông tin trong quản lý khám chữa bệnh thì người bệnh là đối tượng được hưởng lợi đầu tiên, các thông tin lịch sử khám bệnh của bệnh nhân được lưu trữ trong hệ thống công nghệ thông tin của bệnh viện. 
Kê đơn thuốc được hệ thống chuyển nhanh qua bộ phận soạn thuốc, điều này vừa tiết kiệm thời gian cho bác sĩ, vừa để bệnh nhân dễ nhận thuốc. Đồng thời việc liên thông trong khám chữa bệnh Bảo hiểm y tế giúp cung cấp các thông tin bệnh nhân, tra cứu thẻ Bảo hiểm y tế, lịch sử khám chữa bệnh của người bệnh và quản lý thông tuyến trên phạm vi toàn quốc, giúp cho việc thanh toán chi phí khám chữa bệnh Bảo hiểm y tế hiệu quả, khách quan. Điều này cũng làm giảm thời gian chờ khám bệnh, thanh toán viện phí của người bệnh.

## Hướng dẫn thủ tục cấp, nhận giấy báo tử

Bệnh viện Nguyễn Tri Phương hướng dẫn thủ tục về cấp, nhận giấy báo tử cho bệnh nhân tử vong tại Bệnh viện Nguyễn Tri Phương
**I. Thủ tục cấp,nhận giấy báo tử :**
**1. Thủ tục cấp, nhận giấy báo tử :**
  * Căn cước công dân (CCCD)/Hộ chiếu: Bản chính của BN và người thân thích
  * Giấy tờ chứng minh là người thân thích:
    * Người có quan hệ hôn nhân (vợ/chồng): Giấy đăng ký kết hôn hoặc kiểm tra thông tin trên App định danh điện tử VNeID của người thân thích (Dữ liệu quốc gia về dân cư thể hiện mối quan hệ người thân thích).
    * Người có cùng dòng máu về trực hệ và người có họ trong phạm vi ba đời: Giấy Thông báo “Số định danh cá nhân và thông tin công dân trong Cơ sở dữ liệu quốc gia về dân cư” do Công An phường cung cấp hoặc giấy khai sinh của BN và người thân thích hoặc kiểm tra thông tin trên App định danh điện tử VNeID của người thân thích.
    * Người có quan hệ nuôi dưỡng: Giấy khai sinh của BN, Giấy xác nhận nuôi dưỡng, giấy xác nhận đơn vị bảo trợ xã hội.
    * Người có giấy ủy quyền của người thân thích của bệnh nhân.


_**Lưu ý: Trường hợp mất CCCD có thể thay thế bằng hộ chiếu hoặc đơn trình báo mất giấy CCCD có hình và dấu giáp lai của cơ quan công an nơi cư trú.**_
**2. Nhận giấy báo tử (người thân thích của BN).**
  * Người có quan hệ hôn nhân
  * Người có cùng dòng máu về trực hệ và người có họ trong phạm vi ba đời
  * Người có quan hệ nuôi dưỡng
  * Trường hợp khác:
    * Người có giấy ủy quyền của người thân thích của bệnh nhân và giấy tờ tùy thân của người được ủy quyền và của bệnh nhân. Giấy ủy quyền phải có xác nhận của chính quyền địa phương nơi người thân thích của bệnh nhân cư trú, trong giấy ủy quyền ghi rõ nội dung: “Ủy quyền cho ông (bà) A là (mối quan hệ với bệnh nhân) được nhận giấy báo tử của bệnh nhân tên là…tại bệnh viện Nguyễn Tri Phương.”


_**Lưu ý: Người thân thích nhận Giấy báo tử của bệnh nhân có trách nhiệm đọc, kiểm tra lại thông tin trước khi ký.**_
**II. Cấp lại giấy báo tử**
Giấy báo tử chỉ được cấp lại trong những trường hợp sau:
**1. Trường hợp nhầm lẫn khi ghi chép Giấy báo tử:**
**Đối với người thân thích của người tử vong:**
  * Người thân thích của người tử vong làm Đơn đề nghị cấp lại giấy báo tử theo mẫu đính kèm, kèm theo giấy tờ chứng minh nội dung nhầm lẫn gửi phòng Kế hoạch Tổng hợp (là nơi đã cấp giấy báo tử ban đầu cho người tử vong).
  * Giấy tờ chứng minh nội dung nhầm lẫn: đối với trường hợp nhầm lẫn về họ, chữ đệm, tên người tử vong, ngày tháng năm sinh, quốc tịch, số hộ chiếu, số chứng minh nhân dân, số thẻ căn cước công dân, số định danh cá nhân của người tử vong thì gửi kèm bản photo một trong các giấy tờ chứng minh sự nhầm lẫn sau đây: hộ chiếu, chứng minh nhân dân, thẻ căn cước công dân hoặc giấy tờ khác có dán ảnh và thông tin cá nhân thể hiện nội dung nhầm lẫn do cơ quan có thẩm quyền cấp, còn giá trị sử dụng ( giấy tờ chứng minh về nơi cư trú) và mang theo bản chính các giấy tờ chứng minh sự nhầm lẫn để đối chiếu.


**Đối với nhân viên phòng Kế hoạch tổng hợp - Bệnh viện Nguyễn Tri Phương**
  * Nhân viên phòng Kế hoạch tổng hợp nhận hồ sơ đề nghị cấp lại giấy báo tử bao gồm: đơn đề nghị và chứng từ chứng minh kể trên kèm Giấy báo tử đã cấp lần đầu (bản gốc) để hủy.
  * rong thời hạn 1 ngày làm việc kể từ ngày nhận đơn đề nghị cấp lại giấy báo từ, phòng Kế hoạch tổng hợp có trách nhiệm cấp lại giấy báo tử cho người tử vong có mộc “Cấp lại”. 
  * Trường hợp cần xác minh thông tin để cấp lại giấy báo tử thì thời hạn xác minh không quá 05 ngày làm việc.


_**Lưu ý: Giấy báo tử cấp lại phải có số đúng như giấy báo tử đã cấp lần đầu.**_
**2. Trường hợp mất, rách, nát giấy báo tử:**
**Đối với người thân thích của người tử vong:**
Người thân thích của người tử vong phải làm Đơn đề nghị cấp lại Giấy báo tử quy định tại Phụ lục III ban hành kèm theo Thông tư số 24/2020/TT-BYT gửi cơ sở khám bệnh, chữa bệnh đã cấp Giấy báo tử lần đầu.
**Đối với nhân viên phòng Kế hoạch tổng hợp - Bệnh viện Nguyễn Tri Phương:**
  * Trong thời hạn tối đa là 01 ngày làm việc kể từ thời điểm nhận được Đơn đề nghị cấp lại Giấy báo tử, cơ sở khám bệnh, chữa bệnh có trách nhiệm thu hồi Giấy báo tử bị rách, nát; kiểm tra thông tin trong đơn và đối chiếu với bản Giấy báo tử lưu lại cơ sở khám bệnh, chữa bệnh đã cấp. 
  * Giấy báo tử được cấp lại phải ghi rõ số, quyển số của Giấy báo tử cũ và đóng dấu “Cấp lại”. 
  * Trong trường hợp cần phải xác minh, thì thời hạn xác minh không quá 05 ngày làm việc (Trường hợp mất giấy báo tử) 


**III. Mẩu đơn đề nghị cấp lại giấy báo tử**
Tải mẫu đơn [**TẠI ĐÂY**](https://bvnguyentriphuong.com.vn/uploads/072022/files/M%E1%BA%AAU%20GI%E1%BA%A4Y%20B%C3%81O%20T%E1%BB%AC.docx)
#### Nội dung trong file:

PHỤ LỤC III
(Ban hành kèm theo Thông tư số 24/2020 ngày 28 tháng 12 năm 2020)
CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM
Độc lập - Tự do - Hạnh phúc
---------------
ĐƠN ĐỀ NGHỊ CẤP LẠI GIẤY BÁO TỬ
Kính gửi:(1)………………………………………………..
Họ, chữ đệm, tên người đề nghị(2): …………………………………………………………………..
Nơi cư trú:(3) ……………………………………………………………………………………………….
……………………………………………………………………………………………………………….
Giấy tờ tùy thân:(4) ……………………………………………………………………….………………..
……………………………………………………………………………………………………………….
Quan hệ với người đã tử vong:
Đề nghị cơ sở khám bệnh chữa bệnh cấp lại Giấy báo tử cho người có tên dưới đây:
Họ, chữ đệm, tên: ………………………………………………………………………………………..
Ngày, tháng, năm sinh: …………………………………………………………………………………..
Giới tính:………………….. Dân tộc:…………………….. Quốc tịch: …………………………………
Nơi cư trú:(3) ………………………………………………………………………………………………..
………………………………………………………………………………………………………………..
Giấy tờ tùy thân: (4) ……………………………………………………………………………………….
……………………………………………………………………………………………………………….
Đã tử vong vào lúc:…….. giờ…….. phút, ngày………… tháng……….… năm…………………….
Nguyên nhân tử vong: ……………………………………………………………………………………
Đã được cơ sở khám bệnh, chữa bệnh cấp Giấy báo tử
Số…… Quyển số….. ngày…… tháng……. năm…… (5)
Đề nghị cơ sở khám bệnh, chữa bệnh cấp lại Giấy báo tử vì:
1- Có nhầm lẫn về thông tin được ghi trong giấy báo tử(6) 
Ghi cụ thể sự nhầm lẫn:
………………………………………………………………………………………………………………
Giấy tờ chứng minh sự nhầm lẫn:
………………………………………………………………………………………………………………
2- Bị mất/ rách/ nát (5)                     
Ghi cụ thể sự mất/rách/nát
……………………………………………………………………………………………………………..
……………………………………………………………………………………………………………..
Tôi cam đoan những nội dung khai trên đây là đúng sự thật và chịu trách nhiệm trước pháp luật về cam đoan của mình.
Chú thích:
(1) Ghi rõ tên cơ quan cấp lại Giấy báo tử.
(2) Ghi rõ họ tên người thân thích của người đã tử vong (người có quan hệ hôn nhân, nuôi dưỡng, người có cùng dòng máu về trực hệ và người có họ trong phạm vi ba đời)
(3) Ghi theo nơi đăng ký thường trú; nếu không có nơi đăng ký thường trú thì ghi theo nơi đăng ký tạm trú; trường hợp không có nơi đăng ký thường trú và nơi đăng ký tạm trú thì ghi theo nơi đang sinh sống.
(4) Ghi thông tin về giấy tờ tùy thân như: hộ chiếu, chứng minh nhân dân hoặc giấy tờ hợp lệ thay thế (ví dụ: Chứng minh nhân dân số 001089123 do Công an thành phố Hà Nội cấp ngày 20/10/2004).
(5) Ghi theo Thông tin của Giấy báo tử được cấp lần đầu tiên mà bị nhầm lẫn hoặc mất/rách/nát
(6) Đề nghị đánh dấu X vào ô có nhầm lẫn hoặc mất/rách/nát.
**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/) **- Đa khoa Hạng I Thành phố Hồ Chí Minh

## XÉT NGHIỆM COVID-19 DÀNH CHO NGƯỜI XUẤT CẢNH

Bệnh viện sẽ có những giải đáp và thông tin về thay đổi trong hoạt động xét nghiệm SARS-CoV-2 (xét nghiệm Covid-19) có thu phí như sau:
**1/ Dịch vụ xét nghiệm virus SARS-CoV-2 tại Bệnh viện Nguyễn Tri Phương áp dụng cho đối tượng nào?**
Hiện tại, Bệnh viện Nguyễn Tri Phương chỉ áp dụng xét nghiệm đối với các trường hợp có nhu cầu xuất cảnh đi các nước khác mà yêu cầu nhập cảnh phải có giấy xét nghiệm âm tính với COVID-19.
**2/ Xét nghiệm phát hiện virus SARS-CoV-2 bằng phương pháp nào?**
  * Sử dụng kỹ thuật xét nghiệm **Realtime RT-PCR (thường gặp) hoặc test kháng nguyên (ít gặp)**
  * Xét nghiệm sinh học phân tử realtime RT-PCR là một phương pháp xét nghiệm xác định sự hiện diện của virus thông qua phát hiện vật liệu di truyền của virus SARS-CoV-2.
  * Theo CDC khuyến cáo, xét nghiệm realtime RT-PCR là “tiêu chuẩn vàng” để chẩn đoán COVID-19 hiện nay.


**3/ Thời gian đợi kết quả là trong bao lâu?**
  * Một trong những ưu điểm của phương pháp xét nghiệm Realtime RT-PCR là cho kết quả chậm nhất **trong vòng 24 giờ (thông thường là 8h).**
  * Kết quả sẽ được trả qua 2 hình thức: Trực tiếp và qua email.


**4/ Tôi cần chuẩn bị những gì để được đăng kí xét nghiệm sàng lọc COVID-19?**
Để được đăng kí xét nghiệm Covid-19, bạn cần chuẩn bị các giấy tờ sau:
  * Hộ chiếu (Passport)
  * Vé máy bay/vé xe: Bạn cần chắc chắn giờ bay cụ thể và theo dõi tình trạng chuyến bay, tránh trường hợp máy bay đổi chuyến hay trì hoãn ảnh hưởng thời gian có hiệu lực của kết quả xét nghiệm.


**5/ Trên giấy kết quả xét nghiệm của tôi thể hiện những gì?**
  * Giấy kết quả xét nghiệm của bạn có song ngữ Anh-Việt 
  * Đồng thời bao gồm các thông tin như: Họ tên, ngày sinh, số hộ chiếu, ngày giờ lấy mẫu, phương pháp thực hiện, tình trạng mẫu, kết quả âm hay dương tính…


**6/ Tôi có thể liên hệ như thế nào để được đăng kí xét nghiệm?**
  * Chủ động đăng ký thông tin cá nhân chính xác và trung thực tại **đường link do bệnh viện cung cấp (Mã QR sẽ tạo sau khi đã khai báo theo đường link này và dùng để phục vụ quét mã tại sân bay)**
  * Thực hiện đăng ký:
    * Trực tiếp tại BV
    * Phần cuối trang web BV


*** Thông tin cập nhật: BV đã ngưng cung cấp dịch vụ này từ tháng 4/2023**
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh

## Cải cách trong việc thanh toán viện phí và nhận thuốc BHYT


## Thủ tục tiếp công dân và xử lý đơn

Tên thủ tục: | Thủ tục tiếp công dân và xử lý đơn  
---|---  
Cơ quan thực hiện: | Bộ phận tiếp công dân  
Cơ sở pháp lý: | - Luật Khiếu nại năm 2011 có hiệu lực ngày 01/7/2012; - Luật Tố cáo năm 2011 có hiệu lực ngày 01/7/2012; - Luật Tiếp công dân năm 2013 có hiệu lực ngày 01/7/2014; - Nghị định số 64/2014/NĐ-CP ngày 26 tháng 6 năm 2014 của Chính phủ quy định chi tiết thi hành một số điều của Luật Tiếp công dân có hiệu lực ngày 15/8/2014; - Thông tư số 06/2014/TT-TTCP ngày 31 tháng 10 năm 2014 của Thanh tra Chính phủ quy định quy trình tiếp công dân có hiệu lực ngày 15/12/2014; - Thông tư số 07/2014/TT-TTCP ngày 31 tháng 10 năm 2014 quy định quy trình xử lý đơn khiếu nại, đơn tố cáo, đơn kiến nghị, phản ánh có hiệu lực ngày 15/12/2014.  
Trình tự thực hiện: |  - Bước 1: Công dân có nhu cầu khiếu nại, tố cáo, kiến nghị, phản ánh mang theo các giấy tờ nhân thân và hồ sơ liên quan đến việc khiếu nại, tố cáo, kiến nghị, phản ánh (nếu có) đến tại Bộ phận tiếp công dân. Thời gian: từ thứ hai đến thứ sáu hàng tuần (trừ các ngày nghỉ theo quy định), sáng từ 07 giờ 30 phút đến 12 giờ 00 phút, chiều từ 13 giờ đến 16 giờ 30. - Bước 2: Người tiếp công dân đón tiếp, xác định nhân thân của người đến khiếu nại, tố cáo, kiến nghị, phản ánh; xác định tính hợp pháp của người đại diện, người được ủy quyền theo quy định của pháp luật (Điều 5 đến Điều 8, Điều 17, Điều 28 Thông tư06/2014/TT-TTCP); người tiếp công dân tiếp nhận thông tin, tài liệu do công dân trình bày, cung cấp và phải viết, giao giấy biên nhận các tài liệu đã tiếp nhận cho công dân. + Khi người khiếu nại, tố cáo, kiến nghị, phản ánh có đơn trình bày nội dung rõ ràng, đầy đủ thì người tiếp công dân cần xác định nội dung vụ việc, yêu cầu của công dân để xử lý cho phù hợp. + Nếu nội dung đơn khiếu nại, tố cáo, kiến nghị, phản ánh không rõ ràng, chưa đầy đủ thì người tiếp công dân đề nghị công dân viết lại đơn hoặc viết bổ sung vào đơn những nội dung chưa rõ, còn thiếu. + Trường hợp không có đơn khiếu nại, tố cáo, kiến nghị, phản ánh thì người tiếp công dân hướng dẫn công dân viết đơn theo quy định của pháp luật. + Nếu công dân trình bày trực tiếp thì người tiếp công dân ghi chép đầy đủ, trung thực, chính xác nội dung khiếu nại, tố cáo, kiến nghị, phản ánh do công dân trình bày; nội dung nào chưa rõ thì đề nghị công dân trình bày thêm, sau đó đọc lại cho công dân nghe và đề nghị công dân ký tên hoặc điểm chỉ xác nhận vào văn bản. Trường hợp nhiều người đến khiếu nại, tố cáo, kiến nghị, phản ánh về cùng một nội dung thì người tiếp công dân hướng dẫn họ cử người đại diện để trình bày nội dung khiếu nại, tố cáo, kiến nghị, phản ánh; người tiếp công dân ghi lại nội dung bằng văn bản. + Trường hợp đơn có nhiều nội dung khác nhau thì người tiếp công dân hướng dẫn công dân tách riêng từng nội dung để gửi đến đúng cơ quan, tổ chức, đơn vị có thẩm quyền giải quyết.  - Bước 3: Phân loại, xử lý khiếu nại, tố cáo, kiến nghị, phản ánh tại nơi tiếp công dân: + Người tiếp công dân thực hiện việc phân loại, xử lý khiếu nại, tố cáo; phân loại, chuyển nội dung phản ánh, kiến nghị đến cơ quan, tổ chức, đơn vị, người có thẩm quyền thụ lý, giải quyết. + Việc phân loại, xử lý khiếu nại, tố cáo, kiến nghị, phản ánh tại nơi tiếp công dân được thực hiện theo quy định của Luật Tiếp công dân năm 2013; Thông tư số 06/2014/TT-TTCP ngày 31 tháng 10 năm 2014 của Thanh tra Chính phủ quy định quy trình tiếp công dân; Thông tư số 07/2014/TT-TTCP ngày 31 tháng 10 năm 2014 quy định quy trình xử lý đơn khiếu nại, đơn tố cáo, đơn kiến nghị, phản ánh.  - Bước 4: Thông báo kết quả xử lý: Trong thời hạn 10 ngày làm việc, kể từ ngày tiếp nhận nội dung khiếu nại, tố cáo, kiến nghị, phản ánh, người tiếp công dân có trách nhiệm trả lời trực tiếp hoặc thông báo bằng văn bản đến người đã đến khiếu nại, tố cáo, kiến nghị, phản ánh về một trong các nội dung sau đây: + Khiếu nại, tố cáo, kiến nghị, phản ánh đã được thụ lý để giải quyết; + Từ chối thụ lý đối với khiếu nại, tố cáo không thuộc thẩm quyền giải quyết của cơ quan, tổ chức, đơn vị mình hoặc không đủ điều kiện thụ lý; + Nội dung khiếu nại, tố cáo, kiến nghị, phản ánh đã được chuyển đến cơ quan, tổ chức, đơn vị, cá nhân có thẩm quyền giải quyết.  
Cách thức thực hiện: | Trực tiếp tại Bộ phận tiếp công dân  
Thành phần và số lượng: | - Thành phần hồ sơ: + Đơn khiếu nại, đơn tố cáo, đơn kiến nghị, phản ánh hoặc văn bản ghi lại nội dung khiếu nại, tố cáo, kiến nghị, phản ánh (có chữ ký hoặc điểm chỉ của công dân); + Giấy tờ đại diện (nếu có), ủy quyền (nếu có); + Các tài liệu, giấy tờ do người khiếu nại, tố cáo, kiến nghị, phản ánh cung cấp (nếu có). - Số lượng hồ sơ: 01 (Một) bộ - Tên mẫu đơn, mẫu tờ khai: Không  
Thời gian giải quyết: | Trong thời hạn 10 ngày làm việc, kể từ ngày tiếp nhận nội dung khiếu nại, tố cáo, kiến nghị, phản ánh.  
Đối tượng thực hiện: | Tổ chức, cá nhân.  
Kết quả: | Văn bản thông báo kết quả xử lý.  
Yêu cầu và điều kiện: | - Công dân không vi phạm Điều 9 Luật Tiếp công dân bao gồm các trường hợp sau: + Người trong tình trạng say do dùng chất kích thích, người mắc bệnh tâm thần hoặc một bệnh khác làm mất khả năng nhận thức hoặc khả năng điều khiển hành vi của mình. + Người có hành vi đe dọa, xúc phạm cơ quan, tổ chức, đơn vị, người tiếp công dân, người thi hành công vụ hoặc có hành vi khác vi phạm nội quy nơi tiếp công dân. + Người khiếu nại, tố cáo về vụ việc đã giải quyết đúng chính sách, pháp luật, được cơ quan nhà nước có thẩm quyền kiểm tra, rà soát, thông báo bằng văn bản và đã được tiếp, giải thích, hướng dẫn nhưng vẫn cố tình khiếu nại, tố cáo kéo dài. + Những trường hợp khác theo quy định của pháp luật. - Đơn theo quy định tại điểm a khoản 2 Điều 6 Thông tư 07/2014/TT-TTCP ngày 31 tháng 10 năm 2014 của Thanh tra Chính phủ quy định quy trình xử lý đơn khiếu nại, đơn tố cáo, đơn kiến nghị, phản ánh phải đảm bảo: + Đơn dùng chữ viết là tiếng Việt và được người khiếu nại, người tố cáo, người kiến nghị, phản ánh ghi rõ ngày, tháng, năm viết đơn; họ, tên, địa chỉ, chữ ký hoặc điểm chỉ của người viết đơn. + Đơn khiếu nại phải ghi rõ tên, địa chỉ của cơ quan, tổ chức, đơn vị, cá nhân bị khiếu nại, nội dung, lý do khiếu nại và yêu cầu của người khiếu nại. + Đơn tố cáo phải ghi rõ nội dung tố cáo; cơ quan, tổ chức, đơn vị, cá nhân bị tố cáo, hành vi vi phạm pháp luật bị tố cáo. + Đơn kiến nghị, phản ánh phải ghi rõ nội dung kiến nghị, phản ánh. + Đơn chưa được cơ quan, tổ chức, đơn vị tiếp nhận đơn xử lý theo quy định của pháp luật hoặc đã được xử lý nhưng người khiếu nại, người tố cáo được quyền khiếu nại, tố cáo tiếp theo quy định của pháp luật.  
Lệ phí: | Không có

## Hướng dẫn đặt xét nghiệm thực hiện tại nhà

Bước 1: truy cập trang web [khamtainha-bvntp.com](http://khamtainha-bvntp.com/?fbclid=IwAR1acGT9VhRW-a6NILOJpHe3kRNpxJCwoQQafAi5rzrfM9iYGYp2fgT3dj4)
Bước 2: chọn thẻ "Đăng ký xét nghiệm"
Bước 3: thực hiện khai báo các trường bắt buộc và chọn lựa các xét nghiệm cần thực hiện
Bước 4: bấm nút gửi (submit) khi đã hoàn thành để gửi toàn bộ các thông tin cho chúng tôi 
Bước 5: vui lòng chờ nhận cuộc gọi xác nhận từ nhân viên y tế bệnh viện Nguyễn Tri Phương
(Bạn cũng có thể nhắn tin trên fanpage của BV thông báo đã đặt lịch để chúng tôi có thể hỗ trợ nhanh hơn!)
Theo dõi các thông tin của BV trên facebook [tại đây](https://www.facebook.com/BVNTP)
Theo dõi các video về y tế của BV tại [kênh truyền thông](https://www.youtube.com/channel/UCRlRfMJl5emGJvWjuoJK7sg)./.

## Các biểu mẫu xin cấp chứng chỉ hành nghề Dược (SYT TPHCM)

[Giấy xác nhận thời gian thực hành](https://bvnguyentriphuong.com.vn/uploads/072022/files/giay_xac_nhan_thuc_hanh-_mau_so_03_4820179.docx)
#### Nội dung trong file:

Mẫu số 03
CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM 
Độc lập - Tự do - Hạnh phúc
-------------
GIẤY XÁC NHẬN 
Thời gian thực hành tại cơ sở thực hành chuyên môn về dược
Tên cơ sở: …………………………. Địa chỉ:………………………….……………………………….;
Số giấy CNĐĐKKDD:..………………………….(1) …………………………………………………….
Xác nhận Ông/Bà ………………………….………………………….………………………………….
Số CMND/Thẻ căn cước/Hộ chiếu/Các giấy tờ tương đương khác: ……………………………….
Ngày cấp:…………….…………………………………. Nơi cấp: ………………………………………
Thường trú tại …………….………………………………….…………….………………………………
Đã có thời gian thực hành dược tại: ………………………….…………….……………………………
Từ ngày .…………….……………………… đến ngày .…………….………………………………….
Nội dung thực hành: (2) .…………….……………………….…………….…………………………….
Tôi xin chịu hoàn toàn trách nhiệm về xác nhận trên./.




Ghi chú:
(1) Điền số giấy CNĐĐKKDD nếu là cơ sở kinh doanh dược
(2) Ghi nội dung thực hành theo quy định tại Điều 20 của Nghị định này.
(3) Đối với cơ sở thực hành là nhà thuốc, không phải đóng dấu vào Giấy xác nhận.

## Cải cách quy trình khám chữa bệnh


