## ️ Nguyên nhân và biểu hiện của Phù thũng

  * [1. Triệu chứng phù thũng như thế nào?](https://bvnguyentriphuong.com.vn/khoa-kham-benh/nguyen-nhan-va-bieu-hien-cua-phu-thung#1-triu-chng-ph-thng-nh-th-no)
  * [2. Vì sao bạn bị phù thũng?](https://bvnguyentriphuong.com.vn/khoa-kham-benh/nguyen-nhan-va-bieu-hien-cua-phu-thung#2-v-sao-bn-b-ph-thng)
  * [2.1. Phù thũng nhẹ do nguyên nhân sinh lý](https://bvnguyentriphuong.com.vn/khoa-kham-benh/nguyen-nhan-va-bieu-hien-cua-phu-thung#21-ph-thng-nh-do-nguyn-nhn-sinh-l)
  * [2.2. Phù thũng do nguyên nhân bệnh lý](https://bvnguyentriphuong.com.vn/khoa-kham-benh/nguyen-nhan-va-bieu-hien-cua-phu-thung#22-ph-thng-do-nguyn-nhn-bnh-l)
  * [3. Phù thũng có nguy hiểm không?](https://bvnguyentriphuong.com.vn/khoa-kham-benh/nguyen-nhan-va-bieu-hien-cua-phu-thung#3-ph-thng-c-nguy-him-khng)


## **1. Triệu chứng phù thũng như thế nào?**
**Phù thũng** là một thuật ngữ mô tả hay dùng trong các y văn thời xưa. Tham chiếu theo y học hiện đại, đó là tình trạng ứ dịch khoảng kẽ giữa các tế bào hoặc các khoang tự nhiên có thể xảy ra ở bất cứ vị trí nào của cơ thể. Vấn đề tích dịch có thể tùy cơ quan mà bệnh cảnh khác nhau, ví dụ như:
  * Phù thũng bụng, gọi là cổ trướng.
  * Phù thũng phần bàn tay hoặc chân dưới, gọi là phù ngoại biên.
  * Phù thũng ở ngực, thì có thể là phù phổi hoặc tràn dịch màng phổi tùy theo vị trí tích dịch là ngoài màng phổi hay bên trong phổi.


_Phù thũng là tình trạng tích dịch bất thường trong mô_
Vùng da bị phù thũng rất dễ nhận biết bằng những đặc điểm sau:
  * Sưng, phồng to ở các mô dưới da, thấy rõ nhất khi phù thũng ở cánh tay hoặc chân.
  * Vùng da bị phù thũng bị kéo căng và trông sáng bóng hơn bình thường.
  * Tình trạng phù ở chân dưới sẽ trở nên nghiêm trọng hơn vào cuối ngày, sau khi giữ nguyên một tư thế đứng hoặc ngồi trong thời gian dài.
  * Tăng kích thước vùng bụng bất thường khi phù thũng ở bụng.
  * Phù thũng ở ngực thường gây ra tình trạng khó thở, đau tức, đè ép vô cùng rõ ràng.


Có thể dùng tay để kiểm tra nhanh vùng da bị phù thũng như sau: Dùng lực ấn bình thường ngón tay vào vùng da nghi ngờ. Nếu do phù thũng, trên vùng da sẽ hình thành vết lõm tạm thời rất rõ ràng. Còn nếu sưng do bệnh lý, nhiễm trùng hoặc nguyên nhân nào khác, rất khó để lại vết lõm hoặc nếu có thì vết lõm mờ, nhanh biến mất.
_Kiểm tra bằng tay có thể xác định được tình trạng phù thũng_
Phù phổi là tình trạng cấp tính nguy hiểm, vì thế bệnh nhân nếu có dấu hiệu như đau ngực, khó thở, hụt hơi kéo dài không thuyên giảm thì cần đến bệnh viện kiểm tra, điều trị kịp thời.
## **2. Vì sao bạn bị phù thũng?**
Tình trạng**phù thũng** xảy ra do dịch tích tụ trong các mô của cơ thể, dịch này thường bắt nguồn từ các mao mạch tại vị trí này bị tổn thương và rò rỉ dịch. Cần xác định được nguyên nhân gây ra tình trạng phù thũng và xử lý điều trị đúng cách mới hạn chế tối đa tổn thương, biến chứng do bệnh gây ra.
### **2.1. Phù thũng nhẹ do nguyên nhân sinh lý**
Nhiều người có cơ địa nhạy cảm dễ bị phù thũng nhẹ do các nguyên nhân như:
  * Ăn quá mặn trong thời gian ngắn.
  * Ngồi hoặc đứng hoặc giữ một tư thế quá lâu.
  * Phù thũng ở phụ nữ mang thai, thường gặp nhất là phù thũng ở chân.
  * Dấu hiệu của tình trạng tiền kinh nguyệt.


Nếu do những nguyên nhân này, tình trạng phù thũng thường không nghiêm trọng và sẽ được cải thiện bằng các biện pháp chăm sóc đơn giản. Song vẫn cần tiếp tục theo dõi**triệu chứng phù thũng** cũng như các triệu chứng sức khỏe khác để can thiệp kịp thời nếu bệnh tiến triển nặng.
Ngoài ra, phù thũng có thể là tác dụng phụ do sử dụng một số loại thuốc điều trị như:
  * Thuốc giảm đau kháng viêm không Steroid.
  * Thuốc bổ sung nội tiết tố Estrogen.
  * Thuốc điều trị tăng huyết áp.
  * Corticosteroid.
  * Thuốc thuộc nhóm Thiazolidinedione trong điều trị đái tháo đường.


_Một số thuốc điều trị gây tác dụng phụ tích nước, sưng phù_
Có thể trao đổi với bác sĩ để lựa chọn thuốc điều trị thay thế không gây ra tình trạng phù thũng hoặc kiểm soát tình trạng này tốt hơn.
### **2.2. Phù thũng do nguyên nhân bệnh lý**
Cần cẩn thận với trường hợp **phù thũng** xuất hiện là triệu chứng bệnh lý, đây có thể là bệnh lý nguy hiểm như:
  * **Xơ gan**


Xơ gan giai đoạn tiến triển và giai đoạn cuối thường khiến dịch bị tích tụ nhiều trong khoang bụng, hay còn gọi là tình trạng cổ trướng. Ngoài ra, phù thũng cũng có thể xuất hiện ở chân do xơ gan.
  * **Suy tim sung huyết**


Suy tim sung huyết khiến hoạt động bơm máu của cả hai hoặc một bên tâm thất bị ảnh hưởng. Điều này khiến máu bị chảy ngược một phần về lại chân, gây phù bắp chân, mắt cá chân hoặc bàn chân. Ngoài ra, suy tim sung huyết cũng có thể gây phù ở vị trí khác trong cơ thể như: phù phổi khi dịch tích tụ trong phổi, phù bụng cổ trướng khi suy tim ảnh hưởng đến tim.
  * **Thận hư**


Hội chứng thận hư xuất phát từ các tổn thương ở mạch máu nhỏ trong đơn vị lọc cầu thận, khiến nồng độ Albumin trong máu giảm. Đây chính là nguyên nhân khiến dịch không thoát được, tích tụ trong mô và gây phù thũng.
_Bệnh lý về thận dễ gây tích dịch và phù thũng_
  * **Bệnh lý về thận**


Khi bị các bệnh lý về thận, nguy cơ tích tụ Natri và dịch dư thừa trong hệ tuần hoàn khá lớn. Tình trạng phù thũng do bệnh lý về thận thường xảy ra hơn ở vùng quanh mắt và chân.
  * **Bệnh lý liên quan đến hệ bạch huyết**


Trong cơ thể người, vai trò của hệ bạch huyết là loại bỏ dịch dư thừa có trong các mô, vì thế tình trạng tích dịch quá mức trong bệnh phù thũng có thể do tổn thương ở hệ thống này. Tổn thương hệ bạch huyết và mạch bạch huyết có thể do chấn thương, bệnh lý hoặc can thiệp phẫu thuật. Khả năng lưu dẫn dịch của hệ bạch huyết không tốt có thể gây phù thũng kéo dài, tái phát nhiều lần.
  * **Thiếu Protein kéo dài**


Protein rất cần thiết cho sự sống con người, ngoài ra cũng ảnh hưởng đến quá trình tích tụ dịch lỏng trong cơ thể. Vì thế, người có chế độ ăn uống thiếu hụt Protein trong hời gian dài dễ bị phù thũng hơn.
  * **Tổn thương hoặc suy yếu tĩnh mạch chân**


Tình trạng suy tĩnh mạch mãn tính có thể khiến chiều chảy trong mạch bị rối loạn, máu thậm chí còn chảy ngược, gây ứ đọng trong tĩnh mạch. Cuối cùng là tình trạng sưng, phù thũng ở chân. Cần phân biệt với tình trạng sưng bắp chân do cục máu đông cản trở đường vận chuyển máu trong tĩnh mạch. Nếu do huyết khối tĩnh mạch sâu, cần đến khám y tế càng sớm càng tốt.
_Phù thũng chân có thể do tổn thương tĩnh mạch_
## **3. Phù thũng có nguy hiểm không?**
Nếu không xác nhận nguyên nhân, điều trị tốt, tình trạng phù thũng có thể gây ra nhiều biến chứng như:
  * Giảm khả năng đi lại và hoạt động của chân bị phù thũng.
  * Đau và sưng do phù thũng càng nghiêm trọng, ảnh hưởng lớn đến sức khỏe và chất lượng sống.
  * Tăng nguy cơ nhiễm trùng.
  * Cảm giác ngứa, căng cứng, khó chịu ở vùng da căng.
  * Giảm lưu thông máu.
  * Tăng nguy cơ loét da, dễ hình thành sẹo giữa các mô.


Thực tế, để giải quyết triệt để tình trạng **phù thũng** cần xác định và tập trung điều trị nguyên nhân. Cần dựa trên đánh giá tiền sử, thông tin triệu chứng cũng như xét nghiệm để chẩn đoán và lựa chọn thuốc điều trị phù thũng phù hợp.
Cùng chuyên mục: [**Những điều bạn cần biết về sự phù nề**](https://bvnguyentriphuong.com.vn/dieu-duong/nhung-dieu-ban-can-biet-ve-su-phu-ne)
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [1. Triệu chứng phù thũng như thế nào?](https://bvnguyentriphuong.com.vn/khoa-kham-benh/nguyen-nhan-va-bieu-hien-cua-phu-thung#1-triu-chng-ph-thng-nh-th-no)
  * [2. Vì sao bạn bị phù thũng?](https://bvnguyentriphuong.com.vn/khoa-kham-benh/nguyen-nhan-va-bieu-hien-cua-phu-thung#2-v-sao-bn-b-ph-thng)
  * [2.1. Phù thũng nhẹ do nguyên nhân sinh lý](https://bvnguyentriphuong.com.vn/khoa-kham-benh/nguyen-nhan-va-bieu-hien-cua-phu-thung#21-ph-thng-nh-do-nguyn-nhn-sinh-l)
  * [2.2. Phù thũng do nguyên nhân bệnh lý](https://bvnguyentriphuong.com.vn/khoa-kham-benh/nguyen-nhan-va-bieu-hien-cua-phu-thung#22-ph-thng-do-nguyn-nhn-bnh-l)
  * [3. Phù thũng có nguy hiểm không?](https://bvnguyentriphuong.com.vn/khoa-kham-benh/nguyen-nhan-va-bieu-hien-cua-phu-thung#3-ph-thng-c-nguy-him-khng)



## Thông báo chuẩn bị triển khai phòng khám Hậu Covid - 19

**BỆNH VIỆN NGUYỄN TRI PHƯƠNG - KHOA NỘI TỔNG HỢP**
**CHUẨN BỊ TRIỂN KHAI GÓI KHÁM SỨC KHỎE HẬU COVID**
Đại dịch Covid cùng bệnh nhiễm Covid-19 ảnh hưởng lên đời sống và trực tiếp đến sức khỏe của từng Cá nhân-Gia đình. 
Bênh Covid-19 không chỉ gây ra 1 đợt diễn biến cấp tính 10-14 ngày, mà ngay cả khi đã hồi phục còn để lại những Rối loạn về chức năng và triệu chứng, bệnh lý kéo dài có thể **vài tháng hoặc lâu hơn**. Y khoa gọi đó là [**tình trạng Hậu Covid**](https://bvnguyentriphuong.com.vn/nghien-cuu-duoc-dang-tai-tren-tap-chi-quoc-te/hoi-chung-hau-covid)!
Tình trạng này bao gồm **rất nhiều triệu chứng** khác nhau, ảnh hưởng trên **nhiều hệ cơ quan** như: _Mệt mỏi, Ho-khó thở kéo dài, Đau nặng ngực, Mất mùi vị, Đau đầu, Giảm trí nhớ- Kém tập trung, Rụng lông tóc, v.v… thậm chí có thể tăng tần suất mắc bệnh tiểu đường, tim mạch, suy thận,..và các vấn đề về tâm lý-tinh thần kéo dài._
Chính vì vậy, **Gói khám sức khỏe Hậu Covid** nhằm Thăm khám-Kiểm tra và giúp các F0 được theo dõi-điều trị tình trạng Hậu Covid một cách **kỹ lưỡng và chuyên môn cao nhất, cùng những xét nghiệm, hình ảnh học chuyên sâu.**
**Gói khám sẽ tập trung vào các quý bệnh nhân** : 
- Có chẩn đoán của Bệnh viện Covid, Bệnh vện thu dung đã hồi phục/xuất viện và hoàn thành thời gian cách ly theo quy định.
- Bệnh nhân có nhu cầu Khám và tham vấn bệnh lý/tình trạng liên quan Covid.
- Có xét nghiệm PCR Âm tính trong thời hạn 72h.
Địa điểm tổ chức thăm khám: **Phòng khám hậu Covid-19 - khoa Nội tổng hợp**
Lầu 5 – Khu A – Bệnh viện Nguyễn Tri Phương
Thời gian triển khai sẽ được thông báo đến quý bệnh nhân sớm nhất
Kính báo./.

## ️ Đề phòng đau bụng thượng vị kéo dài

Biểu hiện lâm sàng ung thư tụy ngoại tiết không đặc hiệu, thường biểu hiện đau bụng âm ỉ, vàng da và gầy sút cân. Trong nghiên cứu của Porta và cộng sự 2005 trên 185 bệnh nhân ung thư tụy, tác giả nhận thấy các triệu chứng cơ năng thường gặp gồm: mệt mỏi (86%), gầy sút cân (85%), chán ăn (83%), đau bụng (79%), nước tiểu sẫm màu (59%), vàng da (56%), đau lưng (49%). Đau bụng là triệu chứng hay gặp nhất, dù kích thước u nhỏ (<2cm), thường đau âm ỉ vùng thượng vị, có thể lan ra sau lưng; người bệnh thường xuất hiện đau 1-2 tháng trước khi phát hiện bệnh. Đau cấp tính rất hiếm gặp, thường do u bít tắc ống tụy chính gây viêm tụy cấp.
Chính vì vậy khi đứng trước một trường hợp đau bụng thượng vị âm ỉ kéo dài kết hợp với các yếu tố nguy cơ như tuổi cao, hút thuốc hay tiểu đường luôn cần chẩn đoán phân biệt với ung thư tụy. Mặc dù siêu âm ổ bụng là biện pháp rẻ tiền và thuận lợi để phát hiện các bệnh lý mật tụy, siêu âm qua thành bụng tỏ ra ít hiệu quả trong các tổn thương tụy có kích thước <2cm. Chụp cắt lớp vi tính (CT scan) là biện pháp chẩn đoán hình ảnh được khuyến cáo chỉ định cho những trường hợp nghi ngờ ung thư tụy, đồng thời marker ung thư CA 19-9 được chứng minh là có giá trị cao trong chẩn đoán cũng như theo dõi ung thư tụy.
Phẫu thuật cắt tụy là chỉ định điều trị triệt căn duy nhât cho những trường hợp ung thư tụy, nhưng như đã đề cập ở trên chỉ một phần năm người bệnh đến viện mà khối u còn ở giai đoạn có thể phẫu thuật. Hơn thế nữa đây là một phẫu thuật phức tạp đòi hỏi kỹ năng phẫu tích, vét hạch và thực hiện các miệng nối nhằm giảm nguy cơ rò tụy (biến chứng xem là nguy hiểm và hay gặp nhất trong phẫu thuật tụy). Do đó người bệnh nên được khuyến cáo phẫu thuật ở những trung tâm ngoại khoa lớn (hàng năm phẫu thuật từ 12 trường hợp cắt khối tá tụy trở lên).
Từ những điều kể trên, mỗi chúng ta cần chú ý, có thái độ đề phòng với triệu chứng tưởng chừng như vô hại như đau thượng vị. Khi xuất hiện triệu chứng trên kết hợp với gầy sút cân hoặc ở người có nguy cơ như cao tuổi, hút thuốc lá hay tiểu đường cần đến thăm khám ở những cơ sở y tế lớn, để có những tư vấn và điều trị phù hợp nhất.
Tìm hiểu thêm: [**Trào ngược thực quản và viêm loét dạ dày**](https://bvnguyentriphuong.com.vn/noi-tieu-hoa/trao-nguoc-thuc-quan)
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh

## Phiếu tóm tắt thông tin điều trị các bệnh lý nội tổng hợp

**1. Phiếu tóm tắt thông tin điều trị là gì?**
Phiếu tóm tắt thông tin điều trị giúp cho người bệnh theo dõi và cùng tham gia vào quá trình điều trị với bác sĩ và nhân viên y tế 
Phiếu tóm tắt thông tin điều trị được xây dựng cho một bệnh xác định. Thiết kế theo dạng tờ rơi trên 1 tờ giấy khổ A4 hoặc A5 (1 trang hoặc 2 trang). Các thông tin chính được rút ra từ hướng dẫn chẩn đoán và điều trị của bệnh viện. Nội dung bao gồm:
  * Các triệu chứng lâm sàng;
  * Xét nghiệm CLS;
  * Chẩn đoán;
  * Phương pháp điều trị;
  * Biến chứng;
  * Điều trị biến chứng và Hướng dẫn chăm sóc, cách dùng thuốc, dinh dưỡng, sinh hoạt;
  * Phòng ngừa;
  * Truyền thông giáo dục sức khỏe. 


**2. Sử dụng phiếu tóm tắt thông tin như thế nào?**
Thông qua phiếu tóm tắt thông tin điều trị Người bệnh có thể biết được và tự theo dõi được quá trình điều trị bằng cách đánh dấu vào danh mục (hoặc bảng kiểm). Dựa trên các mục đã được đánh dấu, người bệnh có thể biết được các hoạt động thăm khám, xét nghiệm, chẩn đoán hình ảnh, nội soi, thăm dò chức năng, thủ thuật, phẫu thuật, phương pháp điều trị, loại thuốc điều trị... đã thực hiện hoặc dự kiến thực hiện. Từ việc theo dõi này, người bệnh có thể hỏi nhân viên y tế lý do chưa nhận được dịch vụ y tế trong phiếu tóm tắt và tiến trình điều trị đang đến giai đoạn nào.
Phiếu có thể tích hợp thêm các hướng dẫn, khuyến cáo tóm tắt về chế độ dinh dưỡng, phòng tránh tái phát, biến chứng của bệnh và các vấn đề cần lưu ý khác, giúp việc điều trị, chăm sóc hiệu quả hơn.
**[Phiếu tóm tắt thông tin điều trị bệnh lý viêm phổi](https://bvnguyentriphuong.com.vn/uploads/072022/files/1_%20VI%C3%8AM%20PH%E1%BB%94I.pdf)
#### Nội dung trong file:

BỆNH VI ỆN NGUY ỄN TRI PHƯƠNG  
KHOA NỘI TỔNG H ỢP PHIẾU TÓM T ẮT 
THÔNG TIN ĐI ỀU TR Ị 
VIÊM PH ỔI 
Viêm ph ổi là gì?  Là tình trạng nhiễm trùng cấp tính của nhu mô phổi bao gồm  phế 
nang và mô kẽ, có thể ảnh hưởng đến toàn bộ thùy, phân  thùy, 
phế nang tiếp cận với phế quản hay tổ chức kẽ  
Nguyên nhân gây 
bệnh Vi khuẩn, virus đường hô hấp  và một số tác nh ân kh ác 
Những yếu tố nguy  
cơ của bệnh Nghiện rượu, bệnh phổi tắc nghẽn, hút thuốc, bệnh do cấu trúc  
phổi, tắc phế quản, hít  sặc… 
Biểu hiện thư ờng gặp Sốt, ho đàm m ủ, đau ng ực, khó th ở, thở nhanh  
Biến chứng Nhiễm trùng huyết, suy hô hấp  
Cận lâm sàng c ần làm  X quang phổi, tổng phân tích tế bào máu, Ure, Creati nin, điện  
giải đồ, định lượng CRP, điện  tim, nuôi cấy đàm … 
Hướng đi ều trị Kháng sinh đường uống hoặc tĩnh mạch.  
Giảm ho  
Chế độ theo dõi và 
phòng ng ừa Phòng ngừa: tiêm vắc xin, ngưng hút thuốc, tập thể dục, ăn  uống 
lành mạnh, rửa tay**
**[Phiếu tóm tắt thông tin điều trị bệnh lý bệnh thận mạn](https://bvnguyentriphuong.com.vn/uploads/072022/files/2_%20B%E1%BB%86NH%20TH%E1%BA%ACN%20M%E1%BA%A0N.pdf)
#### Nội dung trong file:

BỆNH VI ỆN NGUY ỄN TRI PHƯƠNG  
KHOA NỘI TỔNG H ỢP PHIẾU TÓM T ẮT 
THÔNG TIN ĐI ỀU TR Ị 
BỆNH TH ẬN M ẠN 
Bệnh th ận mạn là gì?  Là tình trạng chức năng thận suy giảm mạn tính kéo dài hàng  
tháng cho đến hàng năm và không hồi phục  
Nguyên nhân gây 
bệnh Thường do b ệnh đái tháo đường, bệnh tăng huyết áp, bệnh cầu 
thận và nhiều bệnh l ý khác 
Những yếu tố nguy  
cơ của bệnh Bất thường tiết niệu bẩm sinh, sỏi hệ niệu, u xơ tiền liệt tuyến,  
nhiễm trùng tiểu tái phát nhiều lần  
Biểu hiện thư ờng gặp Ăn u ống kém, phù, ti ểu ít. 
Xét nghiệm máu có Creatine máu tăng, Ure máu tăng.  
Biến chứng Thiếu máu, loãng xương, tăng huyết áp, tăng kali máu  
Cận lâm sàng c ần làm  Tổng phân tích tế bào máu, Ure, creatinin, đ iện giải đồ, tổng  
phân tích nước tiểu  
Hướng đi ều trị Kiểm soát nguyên nhân gây bệnh thận mạn (đái tháo đường,  
tăng huyết áp…).  
Điều trị thiếu máu, loãng xương  
Chế độ theo dõi và 
phòng ng ừa Chế độ ăn giảm trái cây và nước trái cây. Cân bằng lượng nước  
xuất và nhập  
Ăn uống vệ sinh và môi trường sạch sẽ**
**[Phiếu tóm tắt thông tin điều trị bệnh lý loét dạ dày tá tràng](https://bvnguyentriphuong.com.vn/uploads/072022/files/3_%20LO%C3%89T%20D%E1%BA%A0%20D%C3%80Y%20T%C3%81%20TR%C3%80NG.pdf)
#### Nội dung trong file:

BỆNH VI ỆN NGUY ỄN TRI PHƯƠNG  
KHOA NỘI TỔNG H ỢP PHIẾU TÓM T ẮT 
THÔNG TIN ĐI ỀU TR Ị 
LOÉT DẠ DÀY T Á TR ÀNG  
Loét dạ dày tá tràng 
là gì?  Là tình trạng lớp niêm mạc dạ dày tá tràng bị khuyết do sự tấn  
công của chất acid có trong dạ dày, phá vỡ lớp hàng rào bảo vệ  
niêm mạc dạ dày tá tràng  
Nguyên nhân gây 
bệnh Sử dụng thuốc NSAID, ức chế COX 2, Aspirin  
Nhiễm vi trùng Helicobacter pylori  
Những yếu tố nguy  
cơ của bệnh Hút thuốc lá, uống rươu bia… 
Biểu hiện thư ờng gặp Đau trên r ốn, rối loạn tiêu hóa, khó tiêu, đ ầy hơi, chư ớng bụng, 
buồn nôn, chán ăn  
Biến chứng Loét trơ, xuất  huyết tiêu hóa, thủng dạ dày, ung thư hóa  
Cận lâm sàng c ần làm  Nội soi dạ dày tá tràng có CLO test, X quang dạ dày tá tràng có  
cản quang, tìm kháng nguyên HP có trong phân, test hơi thở tìm  
HP 
Hướng đi ều trị Điều trị không dùng thuốc:  điều ch ỉnh chế độ ăn  
- Thực phẩm ít gia vị: tránh chua, cay. Cử nước có gas. Tránh  
chất k ích thích như trà, café, chocolate. Hạn chế thức ăn  có 
hàm lượng mỡ quá cao như các món rán, xào, sốt.  
- Nên sử dụng thức ăn có hàm lượng đạm cao, ít béo (thịt  gà 
nạc, thịt heo nạc). Nên dùng rau củ dạng rau non (luộc,  om), 
nấu súp đối với bệnh nhân bị bón.  
Điều trị thuốc:  
- Điều trị triệu chứng:  
Thuốc trung hòa acid (Smelox, Phosphalugel…)  
Thuốc giảm đau, giảm co thắt cơ trơn, thuốc chống nôn, 
chống  
đầy b ụng…  
- Điều trị lành loét: thuốc ức chế bơm proton (ức chế tiết acid) : 
Loét tá tràng: 08 tuần, loét dạ dày: 12 tuần.  
- Điều trị diệt H. pylori : phác đồ diệt Hp trong 02 tuần.  
Chế độ theo dõi và 
phòng ng ừa Không hút thuốc lá, không rượu bia …**
**[Phiếu tóm tắt thông tin điều trị bệnh lý đái tháo đường tip 2](https://bvnguyentriphuong.com.vn/uploads/072022/files/4_%20%C4%90%C3%81I%20TH%C3%81O%20%C4%90%C6%AF%E1%BB%9CNG%20T2.pdf)
#### Nội dung trong file:

BỆNH VI ỆN NGUY ỄN TRI PHƯƠNG  
KHOA NỘI TỔNG H ỢP PHIẾU TÓM T ẮT 
THÔNG TIN ĐI ỀU TR Ị 
BỆNH ĐÁI THÁO ĐƯ ỜNG TIP 2  
Bệnh đái tháo đư ờng 
tip 2 là gì?  Là một rối loạn chuyển hoá đặc trưng bởi tình trạng tăng Glucose 
huyết lúc đói  do thiếu hụt insulin tuyệt đối hoặc tương  đối xảy ra 
trên nền đề kháng insulin  
Nguyên nhân gây 
bệnh Đề kháng Insulin  
Rối loạn tiết Insulin  
Những yếu tố nguy  
cơ của bệnh Béo phì, ít vận động  
Ăn nhiều mỡ động vật  
Biểu hiện thư ờng gặp Ăn nhi ều, khát nư ớc, tiểu nhi ều, sụt cân không rõ nguyên nhân  
Biến chứng 1. Xơ vữa mạch m áu: não, tim, mạch máu ngoại biên  
2. Bệnh võng mạc đái tháo đường, bệnh thận đái tháo đường,  
bệnh thần kinh ngoại biên  
3. Biến dạng bàn chân tiểu đường  
4. Nhiễm trùng  
Cận lâm sàng c ần làm  Glucose huyết khi đói ≥126mg/dl  
Glucose huyết bất kỳ >200mg/dl  
Nghiệm pháp dung nạp Glucos e > 200mg/dl  
Và các xét nghi ệm chẩn đoán hoặc điều trị biến ch ứng 
Hướng đi ều trị 1. Giảm cân, tập thể dục  
2. Chế độ ăn: ngày 3 bữa chính, không ăn bữa phụ/ lặt vặt, giảm  
tinh bột, hạn chế trái cây, không sử dụng thức uống ngọt, nước  
trái cây, sữa… Ăn nhiều đạm, rau xanh  
3. Có thể sử dụng các nhóm thuốc hạ đường huyết hoặc l iệu pháp 
insulin tùy chỉ định. Mục tiêu đường huyết nội viện: 140 –180 
mg/dL  
4. Theo dõi lượng đường huyết mao mạch  
Chế độ theo dõi và 
phòng ng ừa Glucose máu tại nhà, theo dõi huyết áp, khám định kỳ bàn chân  
đái tháo đường   
HbA1C mỗi 3 tháng / lần**
**[Phiếu tóm tắt thông tin điều trị bệnh lý sốt xuất huyết Dengue](https://bvnguyentriphuong.com.vn/uploads/072022/files/5_%20SXH%20DENGUE.pdf)
#### Nội dung trong file:

BỆNH VI ỆN NGUY ỄN TRI PHƯƠNG  
KHOA NỘI TỔNG H ỢP PHIẾU TÓM T ẮT 
THÔNG TIN ĐI ỀU TR Ị 
BỆNH S ỐT XU ẤT HUY ẾT DENGUE  
Bệnh sốt xuất huy ết 
Dengue là gì?  Là bệnh do virus Dengue gây ra. Muỗi Aedes aegypti là côn  
trùng trung gian chủ yếu lan truyền virus từ người bệnh sang  
người lành  
Nguyên nhân gây 
bệnh Virus Dengue  
Những yếu tố nguy  
cơ của bệnh Vùng đọng nước, muỗi  
Sống hoặc đi vào vùng dịch t ễ 
Biểu hiện thư ờng gặp Sốt, buồn nôn, nôn, đau nh ức, đau b ụng, ch ảy máu niêm m ạc, li bì 
hay b ức rứt 
Dấu dây th ắt dương tính  
Biến chứng Xuất huyết nặng, suy đa cơ quan , dẫn đến tử vong  
Cận lâm sàng c ần làm  Tổng phân tích tế bào máu, huyết thanh chẩn đoán sốt xuất  
huyết, NS1   
Hướng đi ều trị Điều trị không dùng thuốc:  
- Bồi hoàn nước, điện giải: uống nhiều nước lọc, nước trái cây,  
- dung dịch ORS  
- Dinh dưỡng, nâng đỡ  
Điều trị thuốc:  
- Hạ sốt (Paracetamol, lau mát)  
- Chỉ định truyền dịch  
- Điều chỉnh các rối loạn điện giải, thăng bằng kiềm toan  
- Chỉ định truyền các chế phẩm máu  
Chế độ theo dõi và 
phòng ng ừa Theo dõi các dấu hiệu xuất huyết, nước xuất nhập 24 giờ,  sinh 
hiệu, tri giác…  
Hướng dẫn phòng ngừa: ngăn cản muỗi đốt, diệt muỗi, diệt  lăng 
quăng, dọn dẹp nơi có nước tù đọng…**
**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/) **- Đa khoa Hạng I Thành phố Hồ Chí Minh

## ️ Giới thiệu Khoa Nội Tổng hợp Bệnh viện Nguyễn Tri Phương

  * [I. Thông tin lãnh đạo khoa: Nội Tổng Hợp](https://bvnguyentriphuong.com.vn/noi-tong-hop/gioi-thieu-khoa-nop-tong-hop-benh-vien-nguyen-tri-phuong#i-thng-tin-lnh-o-khoa-ni-tng-hp)
  * [2. Phó trưởng khoa](https://bvnguyentriphuong.com.vn/noi-tong-hop/gioi-thieu-khoa-nop-tong-hop-benh-vien-nguyen-tri-phuong#2-ph-trng-khoa)
  * [3. Phó trưởng khoa](https://bvnguyentriphuong.com.vn/noi-tong-hop/gioi-thieu-khoa-nop-tong-hop-benh-vien-nguyen-tri-phuong#3-ph-trng-khoa)
  * [3. Điều dưỡng trưởng: ](https://bvnguyentriphuong.com.vn/noi-tong-hop/gioi-thieu-khoa-nop-tong-hop-benh-vien-nguyen-tri-phuong#3-iu-dng-trng)
  * [II. Thông tin giới thiệu về khoa](https://bvnguyentriphuong.com.vn/noi-tong-hop/gioi-thieu-khoa-nop-tong-hop-benh-vien-nguyen-tri-phuong#ii-thng-tin-gii-thiu-v-khoa)


## **I. Thông tin lãnh đạo khoa: Nội Tổng Hợp**
### **1. Trưởng khoa**
Họ tên: NGUYỄN TRUNG THÀNH
Năm tốt nghiệp BS: 1991
Năm cấp bằng BS CK1: 2006, Chuyên ngành: Lao
Năm cấp bằng BS CK2 : 2015, Chuyên ngành: Lao
Số năm làm việc ở BV: 29 năm
### **2. Phó trưởng khoa**
Họ tên: NGUYỄN THỊ BÌNH MINH 
Năm tốt nghiệp BS: 1993
Năm cấp bằng BS CK1: 2009. Chuyên khoa: Nội Tổng Quát
Năm cấp bằng BSCK2 : 2013. Chuyên khoa: Nội Tổng Quát
Số năm làm việc ở BV : 26 năm.
### **3. Phó trưởng khoa**
Họ tên: PHÙNG MẠNH DŨNG
Năm tốt nghiệp BS: 2010
Năm cấp bằng CK1: 2018. Chuyên khoa: Nội Tổng Quát.
Số năm làm việc ở BV: 10 năm
### **3. Điều dưỡng trưởng:**
Họ tên: NGUYỄN THỊ HỒNG PHƯỢNG 
Năm tốt nghiệp trình độ cử nhân: 2018
Số năm làm việc ở BV : 15 năm.
## **II. Thông tin giới thiệu về khoa**
Khoa Nội Tổng Hợp là khoa điều trị lâm sàng trọng điểm của bệnh viện, điều trị các bệnh lý : tim mạch, hô hấp, tiêu hóa, thận niệu, nội tiết, thần kinh và các bệnh lý nội khoa tổng quát.
Đội ngũ BS của khoa là những bác sĩ chuyên khoa nhiều kinh nghiệm, cùng sự hợp tác của các chuyên khoa đầu ngành ở các chuyên khoa khác nhau ( hội chẩn chuyên môn và dịch vụ điều trị theo yêu cầu người bệnh.
Đội ngũ điều dưỡng có chuyên môn cao, năng động, chăm sóc bệnh nhân tận tâm, nhanh chóng giống như slogan của khoa : “ Điều trị tận tâm, chăm sóc tận tình”
Khoa Nội Tổng Hợp với không gian thoáng mát, phòng bệnh sạch sẽ, mỗi phòng bệnh chỉ có 02 giường, đầy đủ tiện nghi, hứa hẹn sẽ làm hài lòng tất cả bệnh nhân khi đến đây khám và điều trị.
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [I. Thông tin lãnh đạo khoa: Nội Tổng Hợp](https://bvnguyentriphuong.com.vn/noi-tong-hop/gioi-thieu-khoa-nop-tong-hop-benh-vien-nguyen-tri-phuong#i-thng-tin-lnh-o-khoa-ni-tng-hp)
  * [2. Phó trưởng khoa](https://bvnguyentriphuong.com.vn/noi-tong-hop/gioi-thieu-khoa-nop-tong-hop-benh-vien-nguyen-tri-phuong#2-ph-trng-khoa)
  * [3. Phó trưởng khoa](https://bvnguyentriphuong.com.vn/noi-tong-hop/gioi-thieu-khoa-nop-tong-hop-benh-vien-nguyen-tri-phuong#3-ph-trng-khoa)
  * [3. Điều dưỡng trưởng: ](https://bvnguyentriphuong.com.vn/noi-tong-hop/gioi-thieu-khoa-nop-tong-hop-benh-vien-nguyen-tri-phuong#3-iu-dng-trng)
  * [II. Thông tin giới thiệu về khoa](https://bvnguyentriphuong.com.vn/noi-tong-hop/gioi-thieu-khoa-nop-tong-hop-benh-vien-nguyen-tri-phuong#ii-thng-tin-gii-thiu-v-khoa)



## Tràn dịch màng phổi thể phức tạp là gì? Tràn dịch màng phổi gây biến chứng gì

**Tràn dịch màng phổi thể phức tạp** bao gồm:
  * Tràn dịch màng phổi thể 1: Tràn dịch dưỡng trấp.
  * Tràn dịch màng phổi thể 2: Tràn dịch màng phổi lao.
  * Tràn dịch màng phổi thể 3: Tràn dịch do bệnh lý ác tính.


Bệnh tràn dịch màng phổi sẽ càng trở nên nguy hiểm hơn khi xuất phát từ bệnh lý ung thư phổi hoặc bệnh lao phổi gây nên. Mặc dù bệnh nhân đã được điều trị đúng cách nhưng tràn dịch màng phổi vẫn có khả năng tái đi tái lại nhiều lần.
Ung thư phổi: Người bị bệnh ung thư phổi thường xuất hiện triệu chứng tràn dịch màng phổi. Đối với những bệnh nhân lớn tuổi, thường xuyên hút thuốc lá thì tình trạng tràn dịch màng phổi thường xảy ra rất nhanh, khó kiểm soát gây biến chứng nguy hiểm.
Lao màng phổi: Độ tuổi mắc bệnh lao màng phổi thường nằm trong khoảng từ 25 – 35 tuổi. Nhờ vào chụp **X quang tràn dịch màng phổi** các bác sĩ sẽ chẩn đoán được bệnh nhân đã bị tràn dịch màng phổi hay chưa để có biện pháp chữa trị kịp thời, tránh bệnh phát triển nhanh chóng thành lao phổi.
**Tràn dịch màng phổi có lây không?**
Tràn dịch màng phổi là nguyên nhân ảnh hưởng trực tiếp đến hệ hô hấp của bệnh nhân. Khi tràn dịch màng phổi không được xử lý kịp thời và đúng cách sẽ làm giảm khả năng hô hấp, chèn ép phổi đe dọa đến tính mạng của người bệnh.
Trong trường hợp tràn dịch màng phổi nặng dù đã được cấp cứu nhưng cũng để lại những biến chứng do lượng oxy cung cấp cho não bị thiếu hụt một cách nghiêm trọng trong thời gian dài.
Nếu trong trường hợp **tràn dịch màng phổi** xuất phát từ bệnh lao màng phổi sẽ lây lan qua đường hô hấp. Khi chúng ta tiếp xúc gần với bệnh nhân bị tràn dịch màng phổi có thể nhiễm các dịch tiết của họ và bị lây bệnh.
Như vậy không phải bệnh nhân nào bị tràn dịch màng phổi cũng lây nhiễm. Bản chất của lây nhiễm tràn dịch màng phổi thực chất là do người bệnh bị lao phổi.
Tuy nhiên, trước khi tìm ra chính xác nguyên nhân gây tràn dịch màng phổi, chúng ta cần có biện pháp bảo hộ khi tiếp xúc gần với bệnh nhân để ngăn chặn nguy cơ nhiễm bệnh.
**Tràn dịch màng phổi có nguy hiểm không?** Tràn dịch màng phổi là một trong những biểu hiện của bệnh lý liên quan đến đường hô hấp vô cùng nguy hiểm. Tràn dịch màng phổi tuỳ theo nguyên nhân gây bệnh sẽ gây ra mức độ ảnh hưởng đến sức khỏe người bệnh từ nhẹ đến nặng.

## ️ Thông báo chính thức triển khai gói khám sức khỏe hậu COVID

Đại dịch Covid cùng bệnh nhiễm Covid-19 ảnh hưởng lên đời sống và trực tiếp đến sức khỏe của từng Cá nhân-Gia đình
Bệnh Covid-19 không chỉ gây ra 1 đợt diễn tiến cấp tính 10-14 ngày, mà ngay cả khi đã hồi phục còn để lại những Rối loạn về chức năng và triệu chứng, bệnh lý kéo dài có thể **vài tháng đến 1 năm**. Y khoa gọi đó là **tình trạng Hậu Covid**!
Tình trạng này bao gồm **rất nhiều triệu chứng** khác nhau, ảnh hưởng trên **nhiều hệ cơ quan** như: _Mệt mỏi, Ho-khó thở kéo dài, Đau nặng ngực, Mất mùi vị, Đau đầu, Giảm trí nhớ- Kém tập trung, Rụng lông tóc,v.v… thậm chí có thể tăng tần suất mắc bệnh tiểu đường, tim mạch, suy thận,..và các vấn đề về tâm lý-tinh thần kéo dài._
Chính vì vậy, **Gói khám sức khỏe Hậu Covid** nhằm Thăm khám-Kiểm tra và giúp các F0 được theo dõi-điều trị tình trạng Hậu Covid 1 cách **kỹ lưỡng và chuyên môn cao nhất, cùng những xét nghiệm, hình ảnh học chuyên sâu.** Gói khám được đảm trách bởi các Bác sĩ khoa Nội tổng hợp BV Nguyễn Tri Phương với nhiều kinh nghiệm trong điều trị Covid và các bệnh lý, vấn đề: **Tim mạch, Hô hấp, Tiêu hóa, Thận niệu, Nội tiết, Thần kinh,…**
**Gói khám sẽ tập trung vào các quý bệnh nhân** : 
- Các F0 có chẩn đoán của Bệnh Viện Covid, Bệnh Viện Thu Dung đã hồi phục/xuất viện.
- Các F0 được chẩn đoán trong cộng đồng.
- Bệnh nhân có nhu cầu Khám và tham vấn bệnh lý/tình trạng liên quan Covid.
**_Bệnh nhân sẽ đến trực tiếp Khoa Nội tổng hợp (Lầu 5) để đăng kí và thực hiện gói khám_**.
Phòng khám Hậu Covid chính thức triển khai từ ngày **01/11/2021.**
Thời gian làm việc: Giờ hành chính**, từ thứ 2 đến thứ 6**.
**Để được tư vấn h ẹn****lịch khám tiện lợi và chu đáo, xin liên hệ SDT hoặc Zalo,Viber** (_Giờ hành chính_):
_Bác sĩ_ _CK1 Đặng Nhất_ _Tâm_ _: 0931.517.445_
_*Cử nhân điều dưỡng Nguyễn Thị Hồng Phượng_ _0903.733.644_
_(Với mong muốn chất lượng phục vụ tốt nhất có thể, chúng tôi sẽ không nhận phục vụ các bệnh nhân không đặt hẹn khám trước, kính mong thấu hiểu và thông cảm!)_
**Bảng chi tiết các hạng mục Thăm khám và Xét nghiệm** :
* **Gói khám A (cơ bản):** tổng phí khám + xét nghiệm **1.069.000 VND**
** **Gói khám B (nâng cao)** : tổng phí khám + xét nghiệm **1.940.00 VND**
*** **Gói khám C (xét nghiệm theo yêu cầu)** : Phí khám - tư vấn **300.000 VND(chưa bao gồm phí xét nghiệm)**. Bệnh nhân sẽ được khám toàn diện về tình trạng sức khỏe hiện tại kèm tư vấn đầy đủ, kỹ càng về các vấn đề liên quan Covid (Vaccine, đáp ứng kháng thể-khả năng miễn dịch, tình trạng tái nhiễm-tái dương tính, nguy cơ bệnh lý nền, làm Test tầm soát trầm cảm, rối loạn lo âu, trí nhớ,v.v…). Bác sĩ và bệnh nhân cùng thảo luận để tìm ra những xét nghiệm tầm soát cho bệnh nhân phù hợp với tình trạng sức khỏe nói chung và những vấn đề liên quan Covid nói riêng:
  * Quý Bệnh nhân sẽ được tư vấn và giải thích rõ về các xét nghiệm liên quan hoặc xét nghiệm **theo yêu cầu của mình**. 
  * Tư vấn thực hiện các xét nghiệm sức khỏe tổng quát hoặc **tầm soát** **Ung thư** (Nam: AFP, PSA, Cyfra 21...; Nữ: CA15.3, CA125, CEA…) theo nhu cầu của bệnh nhân.


**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh

## ️ Một số chẩn đoán khi đau bụng bên phải

  * [Vùng bụng của cơ thể con người gồm những thành phần nào?](https://bvnguyentriphuong.com.vn/noi-tieu-hoa/dau-bung-ben-phai-la-dau-hieu-cua-benh-gi#vng-bng-ca-c-th-con-ngi-gm-nhng-thnh-phn-no)
  * [Nguyên nhân đau bụng bên phải](https://bvnguyentriphuong.com.vn/noi-tieu-hoa/dau-bung-ben-phai-la-dau-hieu-cua-benh-gi#nguyn-nhn-au-bng-bn-phi)
  * [Đau bụng bên phải phía trên](https://bvnguyentriphuong.com.vn/noi-tieu-hoa/dau-bung-ben-phai-la-dau-hieu-cua-benh-gi#au-bng-bn-phi-pha-trn)
  * [Đau bụng bên phải phía dưới](https://bvnguyentriphuong.com.vn/noi-tieu-hoa/dau-bung-ben-phai-la-dau-hieu-cua-benh-gi#au-bng-bn-phi-pha-di)
  * [Điều trị đau bụng bên phải như thế nào?](https://bvnguyentriphuong.com.vn/noi-tieu-hoa/dau-bung-ben-phai-la-dau-hieu-cua-benh-gi#iu-tr-au-bng-bn-phi-nh-th-no)


## **Vùng bụng của cơ thể con người gồm những thành phần nào?**
Theo y học, vùng bụng của con người gồm 9 phần sau:
  * Vùng trên rốn: Dạ dày, đại tràng ngang, tụy, thùy gan trái
  * Vùng quanh rốn: Ruột non
  * Vùng dưới rốn: Bàng quang, tử cung
  * Vùng dưới sườn phải: Tá tràng, gan, túi mật, thận phải
  * Vùng mạn sườn phải: Đại tràng trên, niệu quản phải
  * Hố chậu trái: Đại tràng sigma, vòi trứng và buồng trứng.


_Các cơ quan thuộc vùng bụng cơ thể con người_
Việc hiểu rõ vị trí các cơ quan thuộc vùng bụng sẽ giúp chẩn đoán chính xác các bệnh lý liên quan. Vì vậy, khi gặp triệu chứng đau bụng không rõ nguyên nhân, người bệnh nên tới bệnh viện để được bác sĩ chuyên khoa kiểm tra, thăm khám và có phương pháp điều trị thích hợp.
## **Nguyên nhân đau bụng bên phải**
### **_Đau bụng bên phải phía trên_**
Nếu bạn thường xuyên có cơn đau quặn xuất hiện ở vùng bụng bên phải phía trên thì cần thăm khám ngay bởi cơn đau tại vị trí này có thể là dấu hiệu của một số bệnh lý nghiêm trọng sau:
  * _Bệnh ở gan_


Đau bụng bên phải có thể là triệu chứng cảnh báo bệnh viêm gan hay nghiêm trọng hơn là ung thư gan. Cơn đau do các bệnh lý về gan thường nhẹ, âm ỉ tại ổ bụng phải. Trường hợp bệnh nặng có thể kèm một số triệu chứng khác như sụt cân không rõ nguyên nhân, vàng mắt, vàng da, ăn không ngon miệng, mệt mỏi, suy nhược.
_Đau bụng bên phải có thể là triệu chứng cảnh báo các bệnh về gan_
  * _Tắc – nhiễm trùng ống mật, túi mật_


Tình trạng tắc – nhiễm trùng ống mật, túi mật thường xuất hiện đồng thời với biểu hiện đau quặn, đau nhói tại vùng bụng bên phải, đau chấn thủy. Cơn đau sẽ xuất hiện từng đợt, mỗi đợt tái phát đều nghiêm trọng và dữ dội hơn đợt trước.
Những dấu hiệu giúp nhận biết nhiễm trùng ống mật, túi mật:
  * Rối loạn tiêu hóa
  * Thở nhanh, đánh trống ngực
  * Đau bụng bên phải
  * 

Dấu hiệu nhận biết tắc ống mật, túi mật:
  * Phân thải ra có màu bạc
  * Kết mạc mắt vàng
  * Da vàng sẫm
  * Nước tiểu có màu vàng như trà đặc
  * Ngứa da
  * Đau dưới sườn phải (vùng bụng trên bên phải) kèm buồn nôn, nôn ói, sốt.
  * _Đau ruột già_


Bị đau ruột già sẽ có cảm giác trướng bụng, một phần của ruột già cuộn lại, có thể kèm theo tiêu chảy hoặc táo bón. Người bệnh sẽ bớt cảm giác khó chịu, nhẹ bụng hơn sau khi trung tiện.
_Bị đau ruột già sẽ có cảm giác trướng bụng kèm rối loạn tiêu hóa_
  * _Đau thận phải_


Đau lưng bên phải tiến triển và lan rộng đến vùng bụng là dấu hiệu cảnh báo chứng đau thận phải. Người bệnh cần sớm thăm khám và điều trị bởi tình trạng này có thể là triệu chứng một số bệnh lý nghiêm trọng gồm sỏi thận, viêm bể thận…
### **_Đau bụng bên phải phía dưới_**
  * _Viêm ruột thừa_


Đau bụng quanh rốn, đau bụng bên phải phía dưới là một trong những triệu chứng cảnh báo sớm bệnh viêm ruột thừa. Đây là bệnh lý cần được điều trị y tế ngay lập tức dự phòng tình trạng vỡ ruột thừa dẫn đến tử vong.
Một số triệu chứng giúp nhận biết bệnh viêm ruột thừa:
  * Đau âm ỉ tại vùng bụng quanh rốn, cơn đau sẽ trở nên nghiêm trọng và nặng nề hơn về các đợt sau.
  * Đau thắt, đau nhói khi vận động mạnh, ho kèm theo biểu hiệu sốt.
  * Cảm giác đau nhói quanh rốn hoặc đau nhói, quặn thắt tại vùng bụng bên phải phía dưới.
  * Cảm giác buồn nôn, nôn ói, rối loạn tiêu hóa, phình bụng.


​​​​​​​
_Đau bụng bên phải phía dưới là một trong những triệu chứng cảnh báo sớm bệnh viêm ruột thừa_
  * _Bệnh viêm đại tràng_


Nếu cơn đau bụng xuất phát ở bên phải, phía dưới thì có thể tổn thương tồn tại ở gần manh tràng. Ngoài tình trạng đau nhói ở bụng dưới bên phải, người bệnh sẽ gặp phải một số triệu chứng khó chịu sau:
  * Mệt mỏi, suy nhược, ăn ngủ kém
  * Suy giảm trí nhớ, sốt, hay cáu giận
  * Rối loạn đại tiện, đau hậu môn sau khi đi ngoài
  * Đi ngoài phân có máu
  * Ấn tay vào hố chậu phát ra tiếng óc ách, đau khi ấn dọc khung đại tràng.


  * _Viêm bàng quang_


Một trong những triệu chứng của viêm bàng quang là hình thành cơn đau bụng bên phải phía dưới. Ngoài ra, bệnh viêm bàng quang cũng có những dấu hiệu sau:
  * Tiểu buốt, nước tiểu có mủ ở cuối bãi, tiểu máu
  * Đau nhẹ vùng trên khớp mu, bên phải bụng phía dưới khi bàng quang có dấu hiệu căng.
  * Đối với phụ nữ cơn đau có thể lan rộng sang âm hộ, niệu đạo. Khi tiểu xong, cảm giác đau thường giảm hoặc hết.
  * Tiểu nhiều lần trong ngày, sốt.


**_Ở nữ giới, đau bụng dưới bên phải là triệu chứng của một số bệnh lý như:_**
  * _Đau bụng kinh_ : Cơn đau xuất phát từ bụng dưới bên phải trong hoặc trước thời kỳ kinh nguyệt. Tuy nhiên, đây là hiện tượng này hết sức bình thường.
  * _Mang thai ngoài tử cung:_ Cơn đau dữ dội và nghiêm trọng xảy ra ở vùng bụng dưới. Cơn đau có thể xuất hiện ở bên phải hoặc bên trái bụng.
  * _Viêm ống dẫn trứng:_ Viêm ống dẫn trứng khiến bệnh nhân bị đau tại bụng dưới bên phải. Cơn đau sẽ trở nên nặng nề hơn khi giao hợp.
  * _U nang buồng trứng:_ U nang buồng trứng phải sẽ gây ra triệu chứng đau bụng dưới bên phải hoặc đau bên trái khi bị u nang buồng trứng trái.


​​​​​​​
_Những cơn đau bụng xuất hiện trong kỳ kinh nguyệt có thể là do bệnh lạc nội mạc tử cung_
  * _Lạc nội mạc tử cung:_ Trong thời kỳ kinh nguyệt, những cơn đau bụng xuất hiện là do bệnh lạc nội mạc tử cung. Nguyên nhân của tình trạng này là do các tế bào trong tử cung di chuyển và lạc ra ngoài, bám bên ngoài tử cung nhưng vẫn phát triển, khiến máu kinh ra nhiều, bụng đau dữ dội.
  * _U xơ tử cung:_ Đau tức vùng bụng dưới âm ỉ, máu kinh ra nhiều và rối loạn kinh nguyệtlà những triệu chứng phổ biến nhất của bệnh u xơ tử cung. Những u xơ này lành tính và hình thành ở nhiều vị trí khác nhau trong tử cung.
  * _Ung thư buồng trứng:_ Ung thư buồng trứng khiến bệnh nhân thường xuyên bị đau bụng dưới bên phải hoặc trái, đau dữ dội, có nguy cơ cao cắt bỏ buồng trứng.
  * _Viêm vùng chậu:_ Cơn đau bụng dưới bên phải có thể xuất hiện do viêm vùng chậu hoặc viêm nhiễm một số cơ quan sinh dục khác như tử cung, vòi trứng, buồng trứng…


**_Ở nam giới, đau bụng phải có thể là dấu hiệu của các bệnh như:_**
  * _Xoắn tinh hoàn_


Cơn đau lưng xảy ra khi tinh hoàn xoay chuyển hoặc xoắn thừng tinh, làm giảm lưu lượng máu tới tinh hoàn dẫn đến đau đột ngột và sưng ở bìu. Tình trạng này cũng có thể gây ra triệu chứng đau bụng.
  * _Thoát vị bẹn_


Thoát vị bẹn xảy ra khi một phần của ruột hoặc mỡ mạc treo xuyên qua khu vực yếu của thành bụng đến hai bên của ống bẹn, tạo ra một chỗ phình. Ở nam giới thường gặp nhiều nhất gần khu vực chậu ở một bên hoặc cả hai bên.
_Đau bụng dưới bệnh phải có thê do thoát vị bẹn gây ra_
Các triệu chứng người bệnh gặp thoát vị bẹn thường gặp phải: Đau, rát, có tiếng sôi bụng ở chỗ phình; đau nhói khi nâng vật nặng, ho, vặn mình hoặc tập thể dục… Những trường hợp này bác sĩ thường chỉ định phẫu thuật.
## **Điều trị đau bụng bên phải như thế nào?**
Tùy thuộc vào nguyên nhân gây đau bụng bên phải sẽ có phác đồ điều trị riêng cho từng người bệnh.
Nếu bị nhiễm trùng, người bệnh phải dùng kháng sinh để điều trị theo phác đồ của bác sĩ.
Nếu đau bụng dưới bên phải do viêm ruột thừa, viêm bàng quang, thai ngoài tử cung, u nang buồng trứng, viêm ống dẫn trứng… cần phải đi khám và tiến hành phẫu thuật sớm.
Đau bụng dưới bên phải nếu xuất hiện theo từng đợt và dễ tái phát có thể là dấu hiệu của bệnh về đại tràng. Người bệnh cần thực hiện nội soi để tìm ra nguyên nhân và có biện pháp điều trị thích hợp…
Khi bị đau bụng không rõ nguyên nhân, người bệnh nên tới gặp bác sĩ để được chẩn đoán và điều trị đúng cách. Không tự ý mua thuốc về uống bởi có thể khiến bệnh thêm nặng hơn, dẫn tới những biến chứng nguy hiểm.
Xem thêm: [**Đau bụng vào buổi sáng - 16 nguyên nhân thường gặp**](https://bvnguyentriphuong.com.vn/noi-tieu-hoa/dau-bung-vao-buoi-sang-16-nguyen-nhan-thuong-gap)
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [Vùng bụng của cơ thể con người gồm những thành phần nào?](https://bvnguyentriphuong.com.vn/noi-tieu-hoa/dau-bung-ben-phai-la-dau-hieu-cua-benh-gi#vng-bng-ca-c-th-con-ngi-gm-nhng-thnh-phn-no)
  * [Nguyên nhân đau bụng bên phải](https://bvnguyentriphuong.com.vn/noi-tieu-hoa/dau-bung-ben-phai-la-dau-hieu-cua-benh-gi#nguyn-nhn-au-bng-bn-phi)
  * [Đau bụng bên phải phía trên](https://bvnguyentriphuong.com.vn/noi-tieu-hoa/dau-bung-ben-phai-la-dau-hieu-cua-benh-gi#au-bng-bn-phi-pha-trn)
  * [Đau bụng bên phải phía dưới](https://bvnguyentriphuong.com.vn/noi-tieu-hoa/dau-bung-ben-phai-la-dau-hieu-cua-benh-gi#au-bng-bn-phi-pha-di)
  * [Điều trị đau bụng bên phải như thế nào?](https://bvnguyentriphuong.com.vn/noi-tieu-hoa/dau-bung-ben-phai-la-dau-hieu-cua-benh-gi#iu-tr-au-bng-bn-phi-nh-th-no)



## Khu vực chữa bệnh dịch vụ cao tại khoa Nội tổng hợp

_**Trang thiết bị hiện đại - phòng ốc riêng tư, tiện nghi - đội ngũ y tế tận tình, thấu hiểu**_
**_Lầu 6 khu A, khoa Nội Tổng hợp BV Nguyễn Tri Phương_**

## ️ Một số chẩn đoán khi đau bụng bên trái

  * [Tình trạng đau bụng trái là gì?](https://bvnguyentriphuong.com.vn/noi-tieu-hoa/dau-bung-ben-trai-va-nhung-luu-y-can-biet#tnh-trng-au-bng-tri-l-g)
  * [Những vị trí đau bụng trái thường gặp và nguyên nhân](https://bvnguyentriphuong.com.vn/noi-tieu-hoa/dau-bung-ben-trai-va-nhung-luu-y-can-biet#nhng-v-tr-au-bng-tri-thng-gp-v-nguyn-nhn)
  * [Khắc phục đau bụng bên trái bằng cách nào?](https://bvnguyentriphuong.com.vn/noi-tieu-hoa/dau-bung-ben-trai-va-nhung-luu-y-can-biet#khc-phc-au-bng-bn-tri-bng-cch-no)
  * [Phòng tránh đau bụng bên trái ](https://bvnguyentriphuong.com.vn/noi-tieu-hoa/dau-bung-ben-trai-va-nhung-luu-y-can-biet#phng-trnh-au-bng-bn-tri)


## **Tình trạng đau bụng trái là gì?**
Triệu chứng thường gặp là đau bụng trên và đau bụng dưới hoặc ngang rốn, kèm theo các triệu chứng như buồn nôn, sốt, chán ăn, đi ngoài ra máu.
Ngoài ra, dựa vào các dấu hiệu của phân hoặc nước tiểu cũng như các biểu hiện như vàng da, khó thở, lạnh run khi đau bụng cũng xác định được các loại bệnh khác nhau liên quan tới vùng bụng trái.
_Vùng bụng bên trái có rất nhiều cơ quan quan trọng của cơ thể_
## **Những vị trí đau bụng trái thường gặp và nguyên nhân**
Để giúp quá trình thăm khám và chẩn đoán bệnh nhanh chóng, chính xác, người bệnh cần xác định được chính xác vị trí đau vùng bụng bên trái.
**Đau bụng bên trái ở phía trên**
Vùng bụng bên trên được tính từ rốn trở lên đến phần xương ức. Do đó, hoạt động của một số cơ quan như thận trái, tụy hay dạ dày có thể đang gặp vấn đề nếu bạn thấy có cảm giác đau âm ỉ ở phần bụng trên bên trái. Người bị bệnh thận sẽ có cảm giác lưng trái bỗng đau nhói, đây được xem là dấu hiệu rõ rệt nhất. Người bệnh sau đó có thể gặp khó khăn trong việc vận động, đi lại do cơn đau di chuyển sang vùng bụng trên bên trái.
Ngoài ra, bệnh nhân bị thận có thể thấy một vài biểu hiện khác như sốt cao hay đi tiểu ra máu. Đối với bệnh nhân bị đau dạ dày, không chỉ thấy đau vùng bụng bên trái âm ỉ mà còn có cảm giác bụng nóng và đôi khi xuất hiện những cơn đau dữ dội. Bên cạnh đó, các bệnh lý liên quan đến tụy tạng cũng có thể gây ra những cơn đau bụng bên trái phía trên. Lúc này, người bệnh thường phải chịu đựng những cơn đau quằn quại ở vùng lưng và bụng trên.
_Vùng bụng bên trên được tính từ rốn trở lên đến phần xương ức_
**Đau bụng bên trái ở phía dưới**
Vị trí ở phía bụng dưới bên trái là cơ quan tiêu hóa và bài tiết, đây đều là những cơ quan thiết yếu của cơ thể. Một trong những nguyên nhân chính dẫn đến cảm giác đau bụng bên trái phía dưới là rối loạn tiêu hóa, kèm theo cảm giác đau bụng quằn quại, có thể dẫn đến hiện tượng tiêu chảy.
Tuy nhiên, đây không phải là bệnh lý quá nguy hiểm và có thể dễ dàng điều trị. Ngoài ra, các bệnh liên quan đến bàng quang cũng có thể là nguyên nhân của tình trạng đau bụng bên trái phía dưới.
Để phân biệt với các bệnh lý khác, người bệnh cần chú ý đến các dấu hiệu như: đau buốt khi đi vệ sinh, đi tiểu nhiều lần, thậm chí có lẫn máu. Nhiều trường hợp khác cũng chỉ ra rằng đau bụng dưới bên trái là dấu hiệu của bệnh viêm loét trực tràng, đại tràng hay sỏi tiết niệu. 
  * **_Nguyên nhân do các bệnh về hệ tiêu hóa_**


Khi có biểu hiện đau bụng dưới, có khả năng bệnh nhân đã mắc phải chứng bệnh viêm túi thừa cấp. Bệnh lý này thường liên quan đến tình trạng viêm nhiễm các túi nằm ngoài thành ruột kết gọi là túi thừa. Thông thường những cơn đau bụng dưới sẽ kèm theo những triệu chứng khác đi như sốt, nôn mửa, táo bón và buồn nôn,…
Những bệnh về hệ tiêu hóa thường gặp khác có thể gây nên những cơn đau bụng dưới bên trái một cách đột ngột như: chứng táo bón, viêm ruột già, bệnh viêm đường ruột, thoát vị bẹn nghẹt,…
  * **_Nguyên nhân do bệnh lý về hệ sinh sản_**


Đối với phụ nữ trong độ tuổi sinh sản, những cơn đau nhói ở vùng bụng dưới bên trái có thể là dấu hiệu về các bệnh lý liên quan đến hệ sinh sản như: mang thai ngoài tử cung, lạc nội mạc tử cung, sảy thai, u nang buồng trứng hay bị bệnh u xơ tử cung,…
_Vị trí ở phía bụng dưới bên trái là cơ quan tiêu hóa và bài tiết, đây đều là những cơ quan thiết yếu của cơ thể_
  * **_Nguyên nhân do hệ bài tiết có vấn đề_**


Khi bị đau bụng dưới bên trái phụ nữ đã có thể mắc phải bệnh sỏi tiết niệu. Đây là hiện tượng sỏi kết lại ở thận và ống niệu. Biểu hiện cụ thể là những cơn đau quặn bụng dưới bên trái. Ngoài ra có những triệu chứng khác đi kèm như đi tiểu buốt hay đi tiểu ra máu, buồn nôn, nôn mửa,…
Bên cạnh đó bệnh nhiễm trùng đường tiết niệu có thể gây ra những cơn đau đột ngột ở phần vùng bụng dưới bên trái kèm với những dấu hiệu thường gặp như đi tiểu nhiều lần và bị đau buốt.
  * **_Nguyên nhân do một số bệnh lý khác liên quan_**


Bên cạnh những bệnh ở phần trên, khi bị đau bụng dưới bên trái có thể phụ nữ đã mắc phải một số bệnh khác như có vết bầm hay khối máu tụ bên trong thành bụng. Những cục máu đông, viêm các mạch máu ở vùng bụng dưới bên trái có thể dẫn đến các cơn đau đột ngột ở vùng này.
**Đau bụng bên trái cạnh rốn**
Đau bụng bên trái ngang rốn là tình trạng mà gần như ai cũng đã từng gặp ít nhất một lần trong đời. Đây có thể là hiện tượng sinh lý bình thường nhưng cũng có thể là dấu hiệu cảnh báo nhiều căn bệnh nguy hiểm. Dựa vào vị trí các cơn đau, bác sĩ có thể chẩn đoán bạn đang mắc phải bệnh gì.
Đau bụng bên trái cạnh rốn có thể do 5 nguyên nhân sau:
  * **_Nguyên nhân do bệnh viêm loét dạ dày – tá tràng_**


Đây là căn bệnh gây tổn thương viêm, loét cho niêm mạc dạ dày và phần đầu của ruột non. Ở nước ta, bệnh phổ biến ở nam nữ giới trong độ tuổi từ 40 – 49. Người bị viêm loét dạ dày tá tràng sẽ xuất hiện các cơn đau bụng bên trái ngang rốn.
Những cơn đau có thể từ mức độ khó chịu, âm ỉ cho đến đau dữ dội. Đi kèm với triệu chứng đau bụng, người bệnh thường hay gặp cảm thấy buồn nôn – nôn, chán ăn, cảm giác nóng rát, chướng bụng, ợ chua, sụt cân nhẹ. Nếu không được điều trị sớm và đúng cách, lâu ngày sẽ gây ra các biến chứng nguy hiểm, đặc biệt bệnh còn có thể chuyển biến thành ung thư, đe dọa trực tiếp đến tính mạng.
  * **_Nguyên nhân do viêm túi thừa đại tràng_**


Viêm túi thừa là tình trạng một hoặc nhiều túi thừa của ống tiêu hóa bị viêm hoặc nhiễm khuẩn. Ngoài những cơn đau bụng ngang rốn bên trái, người bệnh sẽ xuất hiện thêm các triệu chứng như sốt, buồn nôn và một số thay đổi trong thói quen đại tiện.
Bệnh thường xảy ra ở những người sau độ tuổi 40. Nhìn chung, viêm túi thừa không gây ra quá nhiều nguy hiểm cho sức khỏe. Ở trường hợp nhẹ, bạn chỉ cần nghỉ ngơi, thay đổi chế độ ăn uống và sử dụng một số loại thuốc kháng sinh phù hợp. Tuy nhiên, ở những trường hợp nghiêm trọng hơn, nhiều khả năng phải nhờ đến sự can thiệp ngoại khoa.
  * **_Nguyên nhân do sỏi thận_**


Sỏi thận là một trong những căn bệnh về đường tiết niệu thường gặp nhất hiện nay. Sỏi thận gây ra những cơn đau bụng ngang rốn bên trái, đau lưng, cơn đau có thể lan rộng xuống bụng dưới và bắp đùi. Sỏi thận kéo dài có thể gây tắc nghẽn đường tiểu, suy thận, thậm chí là vỡ thận.
_Đau bụng bên trái ngang rốn là tình trạng thường gặp của tất cả mọi người_
  * **_Nguyên nhân do hội chứng ruột kích thích_**


Mắc phải hội chứng này người bệnh sẽ cảm thấy đau nhẹ sau khi ăn, khi đi đại tiện, cơn đau thường tập trung ở phía bên trái ngang rốn. Hội chứng ruột kích thích thường xuất phát do các bất thường nhu động ruột, nhiễm trùng đường ruột, cơ thể không dung nạp hay dị ứng với thức ăn.
Tình trạng này không quá gây nguy hiểm đến sức khỏe nhưng rất dễ tái phát nhiều lần nếu không được điều trị dứt điểm, làm ảnh hưởng đến chất lượng sống, công việc và tinh thần người bệnh.
  * **_Nguyên nhân do phình động mạch chủ bụng_**


Đây là tình trạng động mạch chủ ở bụng với đường kính ngang lớn hơn 3cm hoặc gia tăng 50% so với đường kính ban đầu. Thông thường người bệnh không có triệu chứng gì đặc biệt cho đến khi chúng vỡ ra.
Bệnh thường gặp ở những người trên 50 tuổi và phổ biến hơn ở nam giới. Những người có tiền sử huyết áp cao, mắc các bệnh về tim mạch hay thường xuyên hút thuốc lá là những đối tượng dễ mắc bệnh nhất.
Nguyên nhân đau bụng bên trái ngang rốn không loại trừ khả năng do bị phình động mạch chủ tại bụng. Biến chứng nguy hiểm nhất mà bệnh gây ra là vỡ mạch. Đây là một tình trạng đặc biệt nguy hiểm, gây đau tức ngực, khó thở, da xanh, tụt huyết áp và thậm chí đe dọa đến tính mạng.
## **Khắc phục đau bụng bên trái bằng cách nào?**
**Một số bài thuốc dân gian**
**_Sử dụng gừng tươi_**
Tác dụng chính của gừng đó là lưu thông máu dễ dàng hơn, vì thế khi bạn bị đau bụng bên trái thì hãy thưởng thức một cốc trà gừng, vừa ấm bụng và giảm đau.
**_Sử dụng mật ong_**
Mật ong cũng được rất nhiều người tin tưởng sử dụng để giảm đau bụng tức thì. Bí quyết rất đơn giản, bạn pha mật ong cùng nước ấm rồi thưởng thức sẽ làm giảm đi những cơn đau.
**_Kết hợp giữa lá bạc hà, gừng, tỏi_**
Cả ba vị này đều có tính ấm, giúp cải thiện triệu chứng đau bụng. Cách thực hiện: Xay nhuyễn hỗn hợp gồm lá bạc hà, gừng, tỏi với nước ấm, uống ngày hai lần.
**_Sử dụng lá ổi_**
Lá ổi là một trong những dược liệu tự nhiên có thể kiểm soát cơn đau bụng rất tốt. Lấy một ít búp ổi non sau đó sao nóng với muối và đun sắc cùng một củ gừng đã nướng trong khoảng 15 phút. Mỗi ngày uống hai lần để đẩy lùi cơn đau bụng bên trái.
**Y khoa hiện đại**
Ngay khi có những triệu chứng đau bụng bên trái không rõ nguyên nhân, bạn nên tới các cơ sở y tế uy tín để được khám và điều trị kịp thời. Trong trường hợp người bệnh đau bụng dữ dội ở vùng bụng bên trái, cần tìm hiểu kĩ càng và thực hiện một số biện pháp sau:
  * Bình tĩnh theo dõi sức khỏe và tới các cơ sở y tế có uy tín để thăm khám kịp thời.
  * Khi các cơn đau tới với tần suất nhiều, không nên làm việc quá sức.
  * Trước khi thăm khám để xác định bệnh chính xác, không nên tự ý sử dụng thuốc khi chưa có sự tư vấn từ bác sĩ.
  * Dựa trên kết quả kiểm tra, bác sĩ sẽ đưa ra kết luận tình trạng bệnh, từ đó có phương án điều trị thích hợp.


## **Phòng tránh đau bụng bên trái**
**Chế độ ăn uống hợp lý**
Để hạn chế các cơn đau bụng trái, người bệnh nên chú ý tới chế độ ăn uống sau:
  * Không sử dụng rượu, bia, chất kích thích, nước uống có ga, đồ cay nóng, dầu mỡ.
  * Bổ sung nhiều thực phẩm giàu chất xơ, vitamin, khoáng chất… có nhiều trong rau xanh, các loại hoa quả tươi.
  * Ăn uống đủ chất dinh dưỡng, hạn chế đồ ăn nhanh, đồ ăn tái, sống, chưa chế biến kỹ.
  * Nên ăn chậm nhai kỹ, chia nhỏ bữa ăn, hạn chế gây áp lực lên dạ dày và các cơ quan tiêu hóa.
  * Tăng cường uống nước, uống ít nhất 2 lít nước mỗi ngày.


**Chế độ sinh hoạt, luyện tập điều độ**
Bên cạnh chếđộ ăn uống hợp lý, chếđộ sinh hoạt, tập luyện khoa học cũng là cách ngăn ngừa, hạn chếtình trạng đau bụng trái. Cụ thể như sau:
  * Hạn chế thức khuya, làm việc quá sức.
  * Tránh tâm lý căng thẳng, mệt mỏi kéo dài.
  * Tập thể dục, thể thao hàng ngày tăng cường sức đề kháng cho cơ thể.
  * Không nên bỏ bữa, nên ăn vào khung giờ cố định, tạo thói quen ăn chậm nhai kĩ.


Hiện tượng đau bụng bên trái là dấu hiệu của nhiều bệnh lý nguy hiểm, nếu như bạn chủ quan thì sẽ phải hứng chịu những hậu quả khó lường. Bản thân mỗi người nên biết trân trọng và bảo vệ sức khỏe của mình.
Xem thêm: [**Đề phòng đau bụng thượng vị kéo dài**](https://bvnguyentriphuong.com.vn/ngoai-tong-hop/de-phong-dau-bung-thuong-vi-keo-dai)
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [Tình trạng đau bụng trái là gì?](https://bvnguyentriphuong.com.vn/noi-tieu-hoa/dau-bung-ben-trai-va-nhung-luu-y-can-biet#tnh-trng-au-bng-tri-l-g)
  * [Những vị trí đau bụng trái thường gặp và nguyên nhân](https://bvnguyentriphuong.com.vn/noi-tieu-hoa/dau-bung-ben-trai-va-nhung-luu-y-can-biet#nhng-v-tr-au-bng-tri-thng-gp-v-nguyn-nhn)
  * [Khắc phục đau bụng bên trái bằng cách nào?](https://bvnguyentriphuong.com.vn/noi-tieu-hoa/dau-bung-ben-trai-va-nhung-luu-y-can-biet#khc-phc-au-bng-bn-tri-bng-cch-no)
  * [Phòng tránh đau bụng bên trái ](https://bvnguyentriphuong.com.vn/noi-tieu-hoa/dau-bung-ben-trai-va-nhung-luu-y-can-biet#phng-trnh-au-bng-bn-tri)



## ️ 7 triệu chứng dễ nhầm lẫn giữa các bệnh lý

  * [Đau cơ xơ hóa và viêm khớp dạng thấp](https://bvnguyentriphuong.com.vn/khoa-kham-benh/7-trieu-chung-de-nham-lan-giua-cac-benh-ly#au-c-x-ha-v-vim-khp-dng-thp)
  * [Viêm tuyến vú và ung thư vú](https://bvnguyentriphuong.com.vn/khoa-kham-benh/7-trieu-chung-de-nham-lan-giua-cac-benh-ly#vim-tuyn-v-v-ung-th-v)
  * [Bệnh tiểu đường và viêm dạ dày tá tràng hoặc rối loạn tiêu hóa.](https://bvnguyentriphuong.com.vn/khoa-kham-benh/7-trieu-chung-de-nham-lan-giua-cac-benh-ly#bnh-tiu-ng-v-vim-d-dy-t-trng-hoc-ri-lon-tiu-ha)
  * [Bệnh động mạch ngoại biên và xơ vữa động mạch](https://bvnguyentriphuong.com.vn/khoa-kham-benh/7-trieu-chung-de-nham-lan-giua-cac-benh-ly#bnh-ng-mch-ngoi-bin-v-x-va-ng-mch)
  * [Các vấn đề của cột sống và bệnh thận.](https://bvnguyentriphuong.com.vn/khoa-kham-benh/7-trieu-chung-de-nham-lan-giua-cac-benh-ly#cc-vn-ca-ct-sng-v-bnh-thn)
  * [Lạc nội mạc tử cung và u nang buồng trứng](https://bvnguyentriphuong.com.vn/khoa-kham-benh/7-trieu-chung-de-nham-lan-giua-cac-benh-ly#lc-ni-mc-t-cung-v-u-nang-bung-trng)
  * [Viêm mũi di ứng và cảm lạnh thông thường](https://bvnguyentriphuong.com.vn/khoa-kham-benh/7-trieu-chung-de-nham-lan-giua-cac-benh-ly#vim-mi-di-ng-v-cm-lnh-thng-thng)


## **Đau cơ xơ hóa và viêm khớp dạng thấp**
Viêm khớp dạng thấp và đau cơ xơ hóa là những tình trạng đau mãn tính thường đi cùng nhau, nhưng có những nguyên nhân khác nhau. Các triệu chứng có thể giống nhau vì vậy thường rất khó chẩn đoán phân biệt.
Những triệu chứng:
  * Đau khớp.
  * Đau đối xứng, có thể ở cùng một ví trí ở cả 2 phía.
  * Mệt mỏi, mất năng lượng, thờ ơ, lãnh cảm.
  * Trầm cảm.


Hãy cẩn thận đến đau khớp. Các cơn đau có thể bắt đầu đột ngột. Sự khác biệt quan trọng nhất là viêm khớp dạng thấp gây sưng khớp có kèm với nóng và vận động hạn chế.
## **Viêm tuyến vú và ung thư vú**
Viêm tuyến vú thường là do nhiễm trùng chủ yếu xuất hiện ở phụ nữ đang cho con bú. Ung thư vú có các triệu chứng rất giống viêm tuyến vú. Nếu được chẩn đoán bị viêm tuyến vú và việc điều trị bằng kháng sinh không cải thiện tình trạng trong vòng 1 tuần thì tốt hơn hết là nên siêu âm, chụp nhũ ảnh và sinh thiết để loại trừ tất cả các nguy cơ ung thư.
Triệu chứng phổ biến của viêm tuyến vú và ung thư vú:
  * Vú nhạy đau.
  *   * Nóng.
  * Ngứa.


## **Bệnh tiểu đường và viêm dạ dày tá tràng hoặc rối loạn tiêu hóa.**
Tiểu đường là một căn bệnh nguy hiểm liên quan đến các vấn đề với hoóc môn insulin và nhiều triệu chứng có thể nhầm lẫn với các rối loạn khác. Cần phải đi khám bác sĩ và không tự chẩn đoán. Bệnh tiểu đường có thể bị nhầm lẫn với các bệnh:
  1. **Viêm dạ dày ruột (virus):** Gây buồn nôn, nôn, tiêu chảy, ớn lạnh và các triệu chứng khác. Đối với bệnh này cần làm xét nghiệm máu để chẩn đoán.
  2. **Rối loạn ăn uống:** Vì sụt cân quá nhiều do lượng đường trong máu cao. Bệnh nhân có thể được chẩn đoán mắc chứng rối loạn ăn uống như: chán ăn hoặc cuồng ăn.


## **Bệnh động mạch ngoại biên và xơ vữa động mạch**
Bệnh động mạch ngoại biên là bệnh trong đó mảng bám tích tụ trong các động mạch mang máu đến não, các cơ quan và các chi.
Khi mảng bám tích tụ trong động mạch của cơ thể, tình trạng này được gọi là xơ vữa động mạch. Qua thời gian, các mảng bám có thể cứng lại và thu hẹp các động mạch. Điều này làm hạn chế dòng chảy của máu giàu oxy đến các cơ quan và các bộ phận khác của cơ thể.
Bệnh động mạch ngoại biên thường ảnh hưởng đến các động mạch ở chân.
Xơ vữa động mạch là tình trạng gây hẹp của động mạch làm giảm lưu lượng máu và oxy đến các cơ quan trong cơ thể của bạn bao gồm tim, não, chi, thận và các cơ quan quan trọng khác.
Triệu chứng khác:
  * Giảm lưu lượng máu.
  * Yếu sức.
  * Đau ở chân.
  * Da mỏng, lạnh và nhợt nhạt.


## **Các vấn đề của cột sống và bệnh thận.**
Một số bệnh lý của thận: nhiễm trùng, sỏi thận, tổn thương thận và huyết khối có thể gây ra rất các cơn đau gây nhầm lẫn với các tình trạng bệnh lý ở vùng lưng, cột sống.
Triệu chứng phổ biến:
  * Tiêu chảy hoặc táo bón.
  * Đi lại khó khăn.
  * Yếu sức.
  * Đau vùng lưng.


## **Lạc nội mạc tử cung và u nang buồng trứng**
[**Lạc nội mạc tử cung**](https://bvnguyentriphuong.com.vn/san-phu-khoa/tinh-trang-dinh-trong-benh-ly-lac-noi-mac-tu-cung) là tình trạng xảy ra khi các tế bào nội mạc tử cung (hay màng trong tử cung, là loại mô hình thành nên lớp niêm mạc tử cung) được tìm thấy bên ngoài tử cung của phụ nữ.
Nhiều phụ nữ bị u nang buồng trứng. Phần lớn các nang này tự tiêu biến mà không cần điều trị sau khoảng một vài tháng. Tuy nhiên có một số u nang bệnh lý cần điều trị đặc biệt.
Triệu chứng phổ biến:
  * Đau vùng chậu
  * Đau bụng liên quan đến hành kinh
  * Cường kinh, chảy máu âm đạo bất thường


## **Viêm mũi di ứng và cảm lạnh thông thường**
Cảm lạnh thường có**s** ổ mũi kéo dài có kèm đau đỏ mắt nhưng việc sử dụng thuốc trị cảm lạnh thông thường không làm thuyên giảm, cần theo dõi thời gian kéo dài của các triệu chứng để có điều trị phù hợp.
Triệu chứng phổ biến:
  * Mệt mỏi
  * Đau họng
  * Chảy nước mũi và nghẹt mũi


Điều quan trọng cần biết là nếu đó là viêm mũi dị ứng, nó sẽ không gây sốt, và có thể gây ngứa.
Điều chúng tôi muốn nói qua chủ đề này, là việc hiểu cơ thể mình luôn đáng khích lệ nhưng đừng bao giờ quyết định thay bác sĩ. Tất cả điều này là vì bạn, và vì sức khỏe của bạn!
Xem thêm: [**Phân thể và điều trị viêm mũi dị ứng**](https://bvnguyentriphuong.com.vn/noi-ho-hap/phan-the-va-dieu-tri-viem-mui-di-ung)
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [Đau cơ xơ hóa và viêm khớp dạng thấp](https://bvnguyentriphuong.com.vn/khoa-kham-benh/7-trieu-chung-de-nham-lan-giua-cac-benh-ly#au-c-x-ha-v-vim-khp-dng-thp)
  * [Viêm tuyến vú và ung thư vú](https://bvnguyentriphuong.com.vn/khoa-kham-benh/7-trieu-chung-de-nham-lan-giua-cac-benh-ly#vim-tuyn-v-v-ung-th-v)
  * [Bệnh tiểu đường và viêm dạ dày tá tràng hoặc rối loạn tiêu hóa.](https://bvnguyentriphuong.com.vn/khoa-kham-benh/7-trieu-chung-de-nham-lan-giua-cac-benh-ly#bnh-tiu-ng-v-vim-d-dy-t-trng-hoc-ri-lon-tiu-ha)
  * [Bệnh động mạch ngoại biên và xơ vữa động mạch](https://bvnguyentriphuong.com.vn/khoa-kham-benh/7-trieu-chung-de-nham-lan-giua-cac-benh-ly#bnh-ng-mch-ngoi-bin-v-x-va-ng-mch)
  * [Các vấn đề của cột sống và bệnh thận.](https://bvnguyentriphuong.com.vn/khoa-kham-benh/7-trieu-chung-de-nham-lan-giua-cac-benh-ly#cc-vn-ca-ct-sng-v-bnh-thn)
  * [Lạc nội mạc tử cung và u nang buồng trứng](https://bvnguyentriphuong.com.vn/khoa-kham-benh/7-trieu-chung-de-nham-lan-giua-cac-benh-ly#lc-ni-mc-t-cung-v-u-nang-bung-trng)
  * [Viêm mũi di ứng và cảm lạnh thông thường](https://bvnguyentriphuong.com.vn/khoa-kham-benh/7-trieu-chung-de-nham-lan-giua-cac-benh-ly#vim-mi-di-ng-v-cm-lnh-thng-thng)



## ️ Mất cân bằng điện giải: triệu chứng và điều trị

  * [Chất điện giải là gì?](https://bvnguyentriphuong.com.vn/khoa-kham-benh/mat-can-bang-dien-giai-trieu-chung-va-dieu-tri#cht-in-gii-l-g)
  * [Nguyên nhân nào gây ra sự mất cân bằng điện giải?](https://bvnguyentriphuong.com.vn/khoa-kham-benh/mat-can-bang-dien-giai-trieu-chung-va-dieu-tri#nguyn-nhn-no-gy-ra-s-mt-cn-bng-in-gii)
  * [Ở người lớn tuổi](https://bvnguyentriphuong.com.vn/khoa-kham-benh/mat-can-bang-dien-giai-trieu-chung-va-dieu-tri#-ngi-ln-tui)
  * [Biện pháp khắc phục tại nhà](https://bvnguyentriphuong.com.vn/khoa-kham-benh/mat-can-bang-dien-giai-trieu-chung-va-dieu-tri#bin-php-khc-phc-ti-nh)


## **Chất điện giải là gì?**
Chất điện giải là khoáng chất mà cơ thể cần để:
  * Cân bằng lượng nước;
  * Giúp vận chuyển chất dinh dưỡng vào tế bào;
  * Loại bỏ chất thải;
  * Tham gia vào hoạt động truyền tín hiệu của dây thần kinh;
  * Co duỗi cơ bắp;
  * Tham gia trong hoạt động của não và tim.


Cơ thể cần được cung cấp chất điện giải từ thực phẩm và đồ uống. Thận và gan giúp giữ cân bằng điện giải. Nếu nguồn thực phẩm đa dạng và uống đủ nước, chất điện giải thường ở mức cân bằng ổn định. Các chất điện giải trong cơ thể người bao gồm:
  * Natri;
  * Kali;
  * Canxi;
  * Magiê;
  * Phốt phát;
  * Clorua;
  * Bicarbonate.


Mất cân bằng điện giải xảy ra khi mức độ chất điện giải trở nên quá cao hoặc thấp. Tuy không phải là một bệnh lý nhưng đây là dấu hiệu của một số tình trạng sức khỏe bất thường của cơ thể.
## **Nguyên nhân nào gây ra sự mất cân bằng điện giải?**
Mất cân bằng điện giải có thể xảy ra nếu cơ thể bị mất nước hoặc có quá nhiều nước trong cơ thể. Những nguyên nhân phổ biến nhất gây mất cân bằng điện giải là:
  * Nôn;
  * Tiêu chảy;
  * Không uống đủ nước;
  * Thiếu dinh dưỡng;
  * Đổ quá nhiều mồ hôi;
  * Một số loại thuốc như thuốc nhuận tràng và thuốc lợi tiểu;
  * Vấn đề về gan hoặc thận;
  * Người đang điều trị ung thư;
  * Suy tim sung huyết.


## **Triệu chứng**
Cơ thể phản ứng với sự mất cân bằng điện giải theo nhiều phương diện khác nhau. Các tác động có thể phụ thuộc vào mức điện giải bị mất cân bằng, mức độ nghiêm trọng tình trạng và các vấn đề về sức khỏe khác nếu có.
Một nghiên cứu ở Hoa Kỳ đã xem xét dữ liệu từ 996 bệnh nhân cấp cứu vì mất cân bằng điện giải. Kết quả báo cáo rằng các triệu chứng phổ biến nhất là:
  * Sốt;
  * Thở gấp;
  * Lú lẫn;
  * Sưng phù;
  * Nhịp tim nhanh hoặc không đều.


Các triệu chứng khác có thể bao gồm:
  * Cáu gắt;
  * Mệt mỏi;
  * Tê, ngứa ran;
  * Yếu cơ;
  * Co giật, co thắt;
  * Thay đổi huyết áp nhanh chóng.


## **Đối với trẻ em**
Trẻ em có nguy cơ mất nước cao hơn người lớn do thể tạng nhỏ hơn và tốc độ chuyển hóa dịch và chất điện giải nhanh hơn.
Đối với trẻ có các tình trạng như bệnh lý **tuyến giáp** , tim hoặc bệnh thận có thể có nguy cơ mất cân bằng điện giải cao hơn. Trong trường hợp trẻ bị ốm nặng hoặc tiêu chảy có thể bị mất cân bằng điện giải cần được chăm sóc y tế càng sớm càng tốt.
## **Ở người lớn tuổi**
Các nghiên cứu đã phát hiện ra rằng người lớn tuổi có thể dễ bị mất nước và mất cân bằng điện giải hơn người trẻ tuổi. Có nhiều nguyên nhân gây ra tình trạng này bao gồm:
  * Thận suy giảm chức năng theo tuổi tác;
  * Người lớn tuổi có thể dùng nhiều loại thuốc có thể thay đổi nồng độ chất điện giải;
  * Không cung cấp đủ chất dinh dưỡng do nhiều nguyên nhân.


Đối với người lớn tuổi nên được theo dõi thường xuyên để nhận biết dấu hiệu mất nước đồng thời có sự điều chỉnh, bổ sung chế độ dinh dưỡng hàng ngày cho phù hợp. Các dấu hiệu mất nước ở người lớn tuổi có thể bao gồm:
  * Khô môi, miệng và lưỡi;
  * Mắt trũng;
  * Da khô, kém săn chắc hoặc kém đàn hồi;
  * Buồn ngủ;
  * Lú lẫn hoặc mất phương hướng;
  * Chóng mặt;
  * Huyết áp thấp.


## **Điều trị**
Nếu có tình trạng nôn mửa, tiêu chảy hoặc ra mồ hôi nhiều, uống nhiều nước hoặc dung dịch điện giải có thể giúp khôi phục lại sự cân bằng của chất điện giải trong cơ thể.
Một số người bị mất cân bằng điện giải có nguyên nhân do các tình trạng sức khỏe khác như bệnh lý về thận hoặc tim. Trong trường hợp này, vẫn có thể điều chỉnh sự mất cân bằng tại nhà trong vài ngày đến vài tuần. Tuy nhiên cần có sự theo dõi của bác sĩ để xem xét diễn tiến sức khỏe người bệnh một cách thường xuyên.
Tuy nhiên, việc uống nhiều chất điện giải mà không có hướng dẫn của bác sĩ có thể tạo ra sự mất cân bằng khác và dẫn đến các biến chứng về sức khỏe.
Ngoài ra, có thể cần điều trị bổ sung để khắc phục các nguyên nhân chính gây ra tình trạng mất cân bằng điện giải. Đối với người mắc bệnh thận nặng có thể cần lọc máu để điều chỉnh sự mất cân bằng điện giải.
Mất cân bằng điện giải có thể nguy hiểm đến tính mạng. Vì vậy đối với trường hợp mất cân bằng nghiêm trọng có thể cần bổ sung chất điện giải thông qua đường truyền tĩnh mạch được thực hiện tại bệnh viện.
## **Biện pháp khắc phục tại nhà**
Nếu nghi ngờ bản thân có thể bị mất nước nhẹ có thể thử uống bù nước để cân bằng lại mức độ điện giải.
Một số nghiên cứu đã phát hiện ra rằng đồ uống thể thao và dung dịch bù nước đường uống mang lại kết quả tương tự nhau ở những người tập thể dục trong thời tiết nóng. Tuy nhiên, hãy cân nhắc về việc sử dụng một số đồ uống thể thao cho mục đích này. Một số chuyên gia cho rằng đồ uống thể thao chứa quá nhiều đường và quá ít natri để điều chỉnh sự mất cân bằng.
Tổ chức Y tế Thế giới (WHO) khuyến nghị nên thực hiện các biện pháp bù nước bằng đường uống tại nhà thay vì sử dụng các đồ uống đã được pha chế sẵn.
Công thức pha chế bao gồm hòa tan 1 lít nước với 1 muỗng cà phê muối và 2 muỗng đường. Mất cân bằng điện giải có thể đe dọa đến tính mạng, vì vậy không nên thử các biện pháp khắc phục tại nhà nếu có các triệu chứng nghiêm trọng hoặc hiện có bất kì tình trạng bệnh lý nguy hiểm nào.
Trẻ sơ sinh, trẻ nhỏ và người lớn tuổi có thể có nguy cơ biến chứng cao hơn. Do đó, hãy luôn tham khảo ý kiến ​​bác sĩ trong những trường hợp này.
# **Tóm lược**
Đối với người lớn khỏe mạnh bình thường khi bị mất nước nhẹ có thể bổ sung chất điện giải bằng cách uống dung dịch bù nước. Tuy nhiên, nếu sự mất cân bằng gây ra bởi các vấn đề về sức khỏe khác, hãy tham khảo ý kiến ​​bác sĩ.
Người lớn tuổi, trẻ sơ sinh và trẻ em nên được chăm sóc đặc biệt nếu có bất kỳ triệu chứng mất cân bằng điện giải hoặc mất nước để tránh khiến cho tình trạng trở nên nghiêm trọng hơn.
Tìm hiểu thêm: **[Chóng mặt sau khi luyện tập](https://bvnguyentriphuong.com.vn/dieu-duong/chong-mat-sau-khi-luyen-tap)**
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [Chất điện giải là gì?](https://bvnguyentriphuong.com.vn/khoa-kham-benh/mat-can-bang-dien-giai-trieu-chung-va-dieu-tri#cht-in-gii-l-g)
  * [Nguyên nhân nào gây ra sự mất cân bằng điện giải?](https://bvnguyentriphuong.com.vn/khoa-kham-benh/mat-can-bang-dien-giai-trieu-chung-va-dieu-tri#nguyn-nhn-no-gy-ra-s-mt-cn-bng-in-gii)
  * [Ở người lớn tuổi](https://bvnguyentriphuong.com.vn/khoa-kham-benh/mat-can-bang-dien-giai-trieu-chung-va-dieu-tri#-ngi-ln-tui)
  * [Biện pháp khắc phục tại nhà](https://bvnguyentriphuong.com.vn/khoa-kham-benh/mat-can-bang-dien-giai-trieu-chung-va-dieu-tri#bin-php-khc-phc-ti-nh)



## ️ Giải thích một số cận lâm sàng hay gặp khi đi khám bệnh

  * [Viêm gan siêu vi B](https://bvnguyentriphuong.com.vn/khoa-kham-benh/giai-thich-mot-so-can-lam-sang-hay-gap-khi-di-kham-benh#vim-gan-siu-vi-b)
  * [Chụp X Quang phổi](https://bvnguyentriphuong.com.vn/khoa-kham-benh/giai-thich-mot-so-can-lam-sang-hay-gap-khi-di-kham-benh#chp-x-quang-phi)
  * [Phết tế bào cổ tử cung (Pap’s mear)](https://bvnguyentriphuong.com.vn/khoa-kham-benh/giai-thich-mot-so-can-lam-sang-hay-gap-khi-di-kham-benh#pht-t-bo-c-t-cung-paps-mear)
  * [Phương pháp chẩn đoán này được Hiệp Hội Phòng chống bệnh Hoa Kỳ khuyến cáo để tầm soát ung thư vú. Trên 40 tuổi nếu là nữ, bạn nên chụp nhũ ảnh mỗi năm. Chụp nhũ ảnh chính xác và nhạy hơn siêu âm vú. Kiểm tra sớm nhằm phát hiện những bất thường của vú để phòng bệnh và điều trị kịp thời bệnh ung thư vú.](https://bvnguyentriphuong.com.vn/khoa-kham-benh/giai-thich-mot-so-can-lam-sang-hay-gap-khi-di-kham-benh#phng-php-chn-on-ny-c-hip-hi-phng-chng-bnh-hoa-k-khuyn-co-tm-sot-ung-th-v-trn-40-tui-nu-l-n-bn-nn-chp-nh-nh-mi-nm-chp-nh-nh-chnh-xc-v-nhy-hn-siu-m-v-kim-tra-sm-nhm-pht-hin-nhng-bt-thng-ca-v-phng-bnh-v-iu-tr-kp-thi-bnh-ung-th-v)
  * [Tầm soát ung thư tuyến tiền liệt (PSA )](https://bvnguyentriphuong.com.vn/khoa-kham-benh/giai-thich-mot-so-can-lam-sang-hay-gap-khi-di-kham-benh#tm-sot-ung-th-tuyn-tin-lit-psa-)
  * [Nội soi cổ tử cung](https://bvnguyentriphuong.com.vn/khoa-kham-benh/giai-thich-mot-so-can-lam-sang-hay-gap-khi-di-kham-benh#ni-soi-c-t-cung)
  * [Nội soi dạ dày - trực tràng - đại tràng](https://bvnguyentriphuong.com.vn/khoa-kham-benh/giai-thich-mot-so-can-lam-sang-hay-gap-khi-di-kham-benh#ni-soi-d-dy-trc-trng-i-trng)


## **Công thức máu**
[**Công thức máu**](https://bvnguyentriphuong.com.vn/xet-nghiem/xet-nghiem-cong-thuc-mau-toan-bo) là 1 xét nghiệm thường qui, cung cấp cho chúng ta nhiều giá trị trong các bệnh lý thường gặp như bệnh nhiễm trùng, ung thư máu… và đặc biệt là xem có tình trạng thiếu máu hay không. Đây là bệnh thường gặp ở VN chúng ta, nguyên nhân gặp là do ký sinh trùng. Thiếu máu làm cho chúng ta có cảm giác mệt mỏi, chóng mặt, mau mệt, giảm khả năng tập trung và ảnh hưởng đến năng suất làm việc. Việc phát hiện và điều trị sớm giúp cho bệnh nhân mau hồi phục sức khỏe.
## **Đường huyết**
Bệnh tiểu đường do rối loạn chuyển hoá, khi nền kinh tế phát triển thì tỷ lệ mắc bệnh tiểu đường trong cộng đồng cũng tăng theo. Trong giai đoạn sớm của bệnh, thường không có triệu chứng. Việc phát hiện sớm giúp rất nhiều trong việc điều trị nhằm ngăn ngừa những biến chứng nguy hiểm của bệnh như là tổn thương mắt, thận, tim mạch và hệ thần kinh.
##  **Cholesterol**
Theo như khuyến cáo của hiệp hội im mạch của Úc cho rằng tất cả những người trên 20 tuổi nên kiểm tra cholesterol trong máu, vì nồng độ cholesterol tăng cao làm tăng nguy cơ phát triển bệnh mạch vành. Vì vậy việc tầm soát và điều trị kịp thời sẽ hạn chế nguy cơ bệnh mạch vành.
## **Chức năng gan**
Gan đóng vai trò quan trọng trong cơ thể như là chức năng lọc máu, bài tiết mật, chuyển hoá các chất lipid, protein, carbonhydrat, dự trữ vitamin và muối khoáng Khi nền kinh tế phát triển con người phải giao tiếp và làm việc nhiều dễ phát sinh những bệnh lý gan thường gặp như là Viêm gan do siêu vi, viêm gan do rượu, viêm gan do ký sinh trùng, gan nhiễm mỡ…Vì vậy việc phát hiện sớm và điều trị kịp thời sẽ hạn chế những nguy hiểm của những biến chứng xơ gan, ung thư gan.
## **Chức năng thận**
Những bệnh lý về thận ở giai đoạn sớm không có triệu chứng, và đặc biệt là bệnh cao huyết áp lâu ngày và điều trị không triệt để sẽ có ảnh hưởng lên thận. Vì vậy việc khám và phát hiện sớm chức năng thận giúp cho chúng ta kiểm soát bệnh 1 cách hiệu quả hơn.
## **Viêm gan siêu vi B**
Việt Nam là 1 nước nằm trong vùng có tỷ lệ lưu hành bệnh cao, theo như Hội Gan Mật, tỷ lệ lưu hành siêu vi B trong cộng đồng vào khoảng 10 - 15 %. Viêm gan siêu vi B có thể đưa đến biến chứng như là ung thư gan và xơ gan rất cao, tuy nhiên rất may mắn chúng ta đã có thuốc chủng ngừa bệnh siêu vi B, và thuốc điều trị bệnh rất hiệu quả. Vì vậy việc xét nghiệm này giúp chúng ta ngăn ngừa bệnh tật bằng cách chích ngừa cho những ai không bị mắc bệnh và điều trị cho những ai đang bị mắc bệnh.
## **Chụp X Quang phổi**
Lao phổi và những bệnh lý tắc nghẽn phổi mãn tính do hút thuốc lá và bụi công nghiệp là những bệnh lý thường gặp ở nước ta. Việc thăm khám bệnh và chụp hình phổi là những biện pháp đơn giản dể thực hiện nhằm giúp cho chúng ta phát hiện sớm và ngăn ngừa hậu quả của nó.
## **Phết tế bào cổ tử cung (Pap’s mear)**
Ung thư cổ tử cung là 1 bệnh lý rất nguy hiểm, đứng hàng thứ nhất trong ung thư đường sinh dục nữ. Nếu được phát hiện sớm và điều trị kịp thời sẽ hạn chế tỷ lệ tử vong và thương tật. Theo Hiệp Hội Ung Thư Mỹ khuyến cáo nên làm thường qui nhằm phát hiện sớm và điều trị kịp thời căn bệnh nguy hiểm nầy.
## **Siêu âm bụng**
Là 1 phương pháp đơn giản, rất kinh tế nhằm phát hiện những thay đổi bất thường trong ổ bụng, như là bệnh lý gan mật, thận, lá lách, tuỵ… Là 1 phương pháp mang tính chất tầm soát rất hữu hiệu.
## **Đo điện tim**
Nhằm phát hiện những thay đổi bất thường ở tim do các bệnh lý tim mạch gây nên , có những trường hợp cao huyết áp mà bệnh nhân không phát hiện (như là không đo huyết áp kiểm tra, không khám sức khỏe định kỳ), lâu ngày ảnh hưởng lên tim. Vì vậy việc đo điện tim nhằm giúp cho chúng ta phát hiện bệnh cao huyết áp cũng như biến chứng của các bệnh tim mạch.
## **Siêu âm ngực**
Ngoài việc khám phụ khoa và làm pap’s mear để phát hiện sớm bệnh ung thư cổ tử cung. Ở phụ nữ cũng nên làm thêm siêu âm ngực kiểm tra nhằm phát hiện sớm những thay đổi cấu trúc, những bất thường ở ngực để phòng bệnh và điều trị kịp thời bệnh ung thư vú
## **Đo loãng xương**
Loãng xương liên quan đến các yếu tố: tuổi, tình trạng thể lực, chất dinh dưỡng kém, mãn kinh sớm, tuổi bắt đầu kinh muộn. Đây là bệnh của cả hai giới, tỷ lệ ở nam có cao hơn, nhất là ở nam giới hút thuốc lá và uống rượu. là một trong những hình thức kiểm tra tình trạng sức khỏe của xương mà từ đó để ngăn ngừa và điều trị kịp thời bệnh Loãng xương.
##  **Chụp nhũ ảnh**
## Phương pháp chẩn đoán này được Hiệp Hội Phòng chống bệnh Hoa Kỳ khuyến cáo để tầm soát ung thư vú. Trên 40 tuổi nếu là nữ, bạn nên chụp nhũ ảnh mỗi năm. chính xác và nhạy hơn siêu âm vú. Kiểm tra sớm nhằm phát hiện những bất thường của vú để phòng bệnh và điều trị kịp thời bệnh ung thư vú.
## **Tầm soát ung thư tuyến tiền liệt (PSA )**
Xét nghiệm nầy được Viện Ung Thư Hoa kỳ khuyến cáo nên làm mỗi năm cho nam giới trên 50 tuổi. Đây là một trong những ung thư hay gặp ở nam giới. Nếu phát hiện sớm, việc điều trị trở nên hữu hiệu hơn.
## **Nội soi cổ tử cung**
Theo Tổ chức Y Tế Thế giới (WHO), ung thư cổ tử cung là nhóm bệnh chủ yếu gây tử vong 54 % trong tổng số bệnh nhân ở thế kỷ nầy. Vì thế soi cổ tử cung để tầm soát viêm và ung thư rất cần thiết nhằm phát hiện sớm và điều trị đúng, có thể chửa khỏi và không bị tái phát.
## **Nội soi dạ dày - trực tràng - đại tràng**
Ung thư dạ dày - trực tràng - là bệnh lý phổ biến và đứng hàng thứ hai trong các ung thư tiêu hoá. Nội soi nhằm phát hiện và cắt bỏ sớm các polyps, đây là những khối tiền ung thư. Việc tầm soát nầy làm giảm đáng kể tỷ lệ tử vong gây ra do bệnh ung thư đại trực tràng.
Tìm hiểu thêm: [**Ý nghĩa các thông số trong xét nghiệm nước tiểu**](https://bvnguyentriphuong.com.vn/xet-nghiem/y-nghia-cac-thong-so-trong-xet-nghiem-nuoc-tieu)
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [Viêm gan siêu vi B](https://bvnguyentriphuong.com.vn/khoa-kham-benh/giai-thich-mot-so-can-lam-sang-hay-gap-khi-di-kham-benh#vim-gan-siu-vi-b)
  * [Chụp X Quang phổi](https://bvnguyentriphuong.com.vn/khoa-kham-benh/giai-thich-mot-so-can-lam-sang-hay-gap-khi-di-kham-benh#chp-x-quang-phi)
  * [Phết tế bào cổ tử cung (Pap’s mear)](https://bvnguyentriphuong.com.vn/khoa-kham-benh/giai-thich-mot-so-can-lam-sang-hay-gap-khi-di-kham-benh#pht-t-bo-c-t-cung-paps-mear)
  * [Phương pháp chẩn đoán này được Hiệp Hội Phòng chống bệnh Hoa Kỳ khuyến cáo để tầm soát ung thư vú. Trên 40 tuổi nếu là nữ, bạn nên chụp nhũ ảnh mỗi năm. Chụp nhũ ảnh chính xác và nhạy hơn siêu âm vú. Kiểm tra sớm nhằm phát hiện những bất thường của vú để phòng bệnh và điều trị kịp thời bệnh ung thư vú.](https://bvnguyentriphuong.com.vn/khoa-kham-benh/giai-thich-mot-so-can-lam-sang-hay-gap-khi-di-kham-benh#phng-php-chn-on-ny-c-hip-hi-phng-chng-bnh-hoa-k-khuyn-co-tm-sot-ung-th-v-trn-40-tui-nu-l-n-bn-nn-chp-nh-nh-mi-nm-chp-nh-nh-chnh-xc-v-nhy-hn-siu-m-v-kim-tra-sm-nhm-pht-hin-nhng-bt-thng-ca-v-phng-bnh-v-iu-tr-kp-thi-bnh-ung-th-v)
  * [Tầm soát ung thư tuyến tiền liệt (PSA )](https://bvnguyentriphuong.com.vn/khoa-kham-benh/giai-thich-mot-so-can-lam-sang-hay-gap-khi-di-kham-benh#tm-sot-ung-th-tuyn-tin-lit-psa-)
  * [Nội soi cổ tử cung](https://bvnguyentriphuong.com.vn/khoa-kham-benh/giai-thich-mot-so-can-lam-sang-hay-gap-khi-di-kham-benh#ni-soi-c-t-cung)
  * [Nội soi dạ dày - trực tràng - đại tràng](https://bvnguyentriphuong.com.vn/khoa-kham-benh/giai-thich-mot-so-can-lam-sang-hay-gap-khi-di-kham-benh#ni-soi-d-dy-trc-trng-i-trng)



## ️ Nguyên nhân, phân loại và điều trị mỡ máu cao

  * [Các loại mỡ máu cao](https://bvnguyentriphuong.com.vn/khoa-kham-benh/nguyen-nhan-phan-loai-va-dieu-tri-mo-mau-cao#cc-loi-m-mu-cao)
  * [Chẩn đoán mỡ máu cao như thế nào?](https://bvnguyentriphuong.com.vn/khoa-kham-benh/nguyen-nhan-phan-loai-va-dieu-tri-mo-mau-cao#chn-on-m-mu-cao-nh-th-no)
  * [Điều trị tình trạng mỡ máu cao](https://bvnguyentriphuong.com.vn/khoa-kham-benh/nguyen-nhan-phan-loai-va-dieu-tri-mo-mau-cao#iu-tr-tnh-trng-m-mu-cao)


## **Nguyên nhân**
Các nguyên nhân gây ra mỡ máu cao bao gồm:
  * Di truyền: Các bác sĩ gọi đây là mỡ máu cao nguyên phát. Bệnh nhân mắc bệnh do di truyền từ cha mẹ.
  * Chế độ ăn không lành mạnh và các yếu tố khác: Các bác sĩ gọi đây là mỡ máu cao thứ phát.


Các yếu tố nguy cơ khác bao gồm:
  * Uống quá nhiều thức uống có cồn;
  * Béo phì;
  * Sử dụng các thuốc như hormone hay steroid;
  * Đái tháo đường;
  * Các hội chứng về chuyển hóa năng lượng;
  * Bệnh thận mạn;
  * Mãn kinh sớm;
  * Nhược giáp;
  * Mang thai;
  * Lối sống thụ động.


Bệnh mỡ máu gia đình là do rối loạn di truyền.
Cha hoặc mẹ truyền cho con đoạn gen bị đột biến dẫn đến thụ thể LDL bị mất hay rối loạn chức năng. Nghĩa là cơ thể không thể loại bỏ LDL ra khỏi máu, từ đó dẫn đến tăng nồng độ LDL máu đến mức nguy hiểm.
Một vài nhóm người như Người Canada-Pháp, người Leban đạo Cơ-đốc, và một vài nhóm người ở Nam Phi, bao gồm người Afrikan, Ashkenazi hồi giáo, và Ấn Độ, có nguy cơ cao mắc bệnh mỡ máu gia đình.
## **Các loại mỡ máu cao**
Có nhiều loại mỡ máu cao gây ra các ảnh hưởng khác nhau lên cơ thể. Các bác sĩ phân loại chúng dựa vào các loại chất béo liên quan và sự ảnh hưởng của từng loại lên cơ thể.
**Loại I:** Bệnh mỡ máu cao di truyền do thiếu hụt men lipase cảu lipoprotein, thường xảy ra từ khi còn nhỏ và rất trầm trọng. Đây là một rối loại di truyền gây ra sự gián đoạn sự phân hủy bình thường của chất béo và có thể gây ra đau bụng, viêm tụy cấp tái diễn, gan to và lách to.
**Loại II (a và b):** Loại IIa là cholesterol máu cao do di truyền, và IIb là mỡ máu cao kết hợp do di truyền, cả hai đều dẫn đến LDL cao. Chúng còn dẫn đến sự thải chất béo qua da và xung quanh mắt, và còn có thể làm tăng nguy cơ mắc bệnh tim.
**Loại III:** Là rối loạn chuyển hóa lipoprotein máu do di truyền, gây ảnh hưởng đến lipoprotein. Nó còn xảy ra khi nồng độ LDL trong máu quá thấp, nhưng nồng độ HDL vẫn bình thường. Một đặc tính điển hình của loại III là sự xuất hiện của xanthoma, hay các mảng vàng, vàng xám trên mí mắt và xung quanh mắt.
Loại III là tăng nguy cơ mắc bệnh tim và bệnh động mạch ngoại biên sớm.
**Loại IV:** Loại IV, hay tăng triglycreride máu, làm tăng nồng độ triglycerid máu hơn là tăng cholesterol. Loại này cũng dẫn đến béo phì, đường máu cao, và nồng độ insulin cao.
Bệnh nhân có thể không nhận ra đã mắc bệnh cho đến khi trưởng thành.
## **Chẩn đoán mỡ máu cao như thế nào?**
Các bác sĩ sẽ tầm soát mỡ máu cao bằng xét nghiệm máu.
Đây thường là xét nghiệm khi đói. Nghĩa là người được xét nghiệm sẽ không được ăn uống bất cứ thứ gì trong vòng 9-12 giờ trước khi lấy mẫu máu. Tuy nhiên, các hướng dẫn mới thì bớt nghiêm khắc hơn về việc nhịn đói, do đó nên tham khảo ý kiến bác sĩ về việc nhịn đói trước khi xét nghiệm.
Một hướng dẫn được cập nhật gần đây khuyên rằng các phụ huynh nên cho trẻ đi tầm soát lượng cholesterol từ 2 tuổi nếu như có tiền căn gia đình bị mỡ máu cao hay các bệnh tim mạch.
Hầu hết tất cả trẻ em nên được tầm soát trong khoảng từ 9–11 tuổi đến 17–21 tuổi.
## **Điều trị tình trạng mỡ máu cao**
Các phương pháp tự quản lý bản thân như chế độ ăn cân bằng và hoạt động thể chất thường xuyên có thể giúp làm giảm nồng độ lipoprotein trong máu.
Tuy nhiên, di truyền cũng góp phần quyết định nồng độ cholesterol, do đó một lối sống lành mạnh đôi khi vẫn chưa đủ để làm giảm cholesterol. Một vài cá nhân sẽ cần dùng đến thuốc.
Bác sĩ thường sẽ cho dùng các thuốc statin, ví dụ như simvastatin, lovastatin, atorvastatinm và rosuvastatin, để làm giảm cholesterol. Những loại thuốc này làm giảm lượng cholesterol mà gan sản xuất.
Statins có một số tác dụng phụ bao gồm cả đau nhức cơ. Đau nhức cơ dạng này thường vô hại, nhưng trong một vài trường hợp hiếm gặp, statin có thể gây tổn thương cơ hay suy nhược.
Nếu như cảm giác thấy không thể nào chịu được các cơn đau thì nên báo ngay cho bác sĩ trước khi dừng sử dụng thuốc. Việc giữ cân bằng giữa nguy cơ gây ra các sự kiện tim mạch và tác dụng phụ của thuốc là rất quan trọng trước khi quyết định ngưng sử dụng statins.
Những người không đạt được nồng độ cholesterol mục tiêu sau khi sử dụng statin có thể sẽ cần liều statin cao hơn hay dùng thêm các thuốc khác. Các thuốc khác bao gồm ezetimibe và ít gặp hơn là fibrate hay niacin. Theo hướng dẫn mới thì thuốc ức chế PCSK9 cũng được sử dụng, như là evolocumab (Repatha).
Thuốc ức chế PCSK9 rất đắt tiền, do đó bác sĩ cũng cần phải cân nhắc trước khi chỉ định chúng. Tuy nhiên, các hướng dẫn mới khuyến cáo nên hạ thấp giá thành cho các thuốc này để cho phép một bộ phận dân số cụ thể có thể sử dụng được thuốc. Dân số này bao gồm những người có mỡ máu cao do di truyền mà không thể sử dụng thuốc khác hay những người đã bị lên cơn đau tim và không đặt được nồng độ LDL mục tiêu với những loại thuốc khác.
## **Tóm tắt**
Bệnh mỡ máu cao là yếu tố nguy cơ lớn dẫn đến bệnh tim mạch. Đây là tình trạng nồng độ cholesterol LDL và tricglycerid trong máu quá cao.
Bác sĩ xem lipoprotein tỷ trọng thấp (LDL) là cholesterol xấu và lipoprotein tỷ trọng cao (HDL) là cholestrol tốt.
Nhược giáp, chế độ ăn nhiều chất béo, và bị thừa cân là những nhân tố góp phần làm tăng cholesterol. Tuy nhiên, một vài loại mỡ máu cao là do di truyền.
Hoạt động thể chất thường xuyên và chế độ ăn giàu chất béo tố có thể cải thiện sự cân bằng của cholesterol trong máu và giúp ngăn ngừa các vấn đề sức khỏe.
Xem thêm: [**Một số biện pháp giúp phòng ngừa tình trạng mỡ máu cao**](https://bvnguyentriphuong.com.vn/khoa-kham-benh/mot-so-bien-phap-giup-phong-ngua-tinh-trang-mo-mau-cao)
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [Các loại mỡ máu cao](https://bvnguyentriphuong.com.vn/khoa-kham-benh/nguyen-nhan-phan-loai-va-dieu-tri-mo-mau-cao#cc-loi-m-mu-cao)
  * [Chẩn đoán mỡ máu cao như thế nào?](https://bvnguyentriphuong.com.vn/khoa-kham-benh/nguyen-nhan-phan-loai-va-dieu-tri-mo-mau-cao#chn-on-m-mu-cao-nh-th-no)
  * [Điều trị tình trạng mỡ máu cao](https://bvnguyentriphuong.com.vn/khoa-kham-benh/nguyen-nhan-phan-loai-va-dieu-tri-mo-mau-cao#iu-tr-tnh-trng-m-mu-cao)



## ️ Điều gì xảy ra khi lượng canxi trong máu thấp?

  * [Hạ canxi máu dẫn đến tình trạng gì?](https://bvnguyentriphuong.com.vn/khoa-kham-benh/dieu-gi-xay-ra-khi-luong-canxi-trong-mau-thap#h-canxi-mu-dn-ntnh-trng-g)
  * [Các triệu chứng của tình trạng thiếu canxi như thế nào?](https://bvnguyentriphuong.com.vn/khoa-kham-benh/dieu-gi-xay-ra-khi-luong-canxi-trong-mau-thap#cc-triu-chng-ca-tnh-trng-thiu-canxi-nh-th-no)
  * [Các vấn đề về cơ](https://bvnguyentriphuong.com.vn/khoa-kham-benh/dieu-gi-xay-ra-khi-luong-canxi-trong-mau-thap#cc-vn-v-c)
  * [Các triệu chứng về móng và da](https://bvnguyentriphuong.com.vn/khoa-kham-benh/dieu-gi-xay-ra-khi-luong-canxi-trong-mau-thap#cc-triu-chng-v-mng-v-da)
  * [Thiếu xương và loãng xương ](https://bvnguyentriphuong.com.vn/khoa-kham-benh/dieu-gi-xay-ra-khi-luong-canxi-trong-mau-thap#thiu-xng-v-long-xng)
  * [Hội chứng tiền kinh nguyệt (PMS)](https://bvnguyentriphuong.com.vn/khoa-kham-benh/dieu-gi-xay-ra-khi-luong-canxi-trong-mau-thap#hi-chng-tin-kinh-nguyt-pms)
  * [Các vấn đề về răng miệng](https://bvnguyentriphuong.com.vn/khoa-kham-benh/dieu-gi-xay-ra-khi-luong-canxi-trong-mau-thap#cc-vn-v-rng-ming)
  * [Khi nào đến gặp bác sĩ](https://bvnguyentriphuong.com.vn/khoa-kham-benh/dieu-gi-xay-ra-khi-luong-canxi-trong-mau-thap#khi-no-n-gp-bc-s)
  * [Bệnh thiếu canxi phổ biến như thế nào?](https://bvnguyentriphuong.com.vn/khoa-kham-benh/dieu-gi-xay-ra-khi-luong-canxi-trong-mau-thap#bnh-thiu-canxi-ph-bin-nh-th-no)
  * [Điều trị và phòng ngừa](https://bvnguyentriphuong.com.vn/khoa-kham-benh/dieu-gi-xay-ra-khi-luong-canxi-trong-mau-thap#iu-tr-v-phng-nga)


## **Hạ canxi máu dẫn đến tình trạng gì?**
Hạ canxi máu, thường được gọi là bệnh thiếu canxi xảy ra khi nồng độ canxi trong máu thấp. Sự thiếu hụt canxi lâu dài có thể dẫn đến các vấn đề răng miệng, đục thủy tinh thể, hoạt động của não và loãng xương - khiến xương trở nên giòn và dễ gãy.
## **Các triệu chứng của tình trạng thiếu canxi như thế nào?**
Các triệu chứng được liệt kê dưới đây có thể trở nên trầm trọng hơn khi bệnh tiến triển.
### **Các vấn đề về cơ**
Đau nhức cơ, chuột rút và co thắt là những dấu hiệu sớm nhất của sự thiếu hụt canxi. Nhiều trường hợp cảm thấy đau ở đùi và cánh tay, đặc biệt là vùng dưới cánh tay, khi di chuyển. Sự thiếu hụt canxi cũng có thể gây tê và ngứa ran ở bàn tay, cánh tay, bàn chân, cẳng chân và quanh miệng.
Những triệu chứng này có thể xuất hiện và biến mất trong một khoảng thời gian sau đó.
### **Mệt mỏi**
Hàm lượng canxi thấp có thể gây mất ngủ hoặc buồn ngủ đi kèm các triệu chứng như:
  * Cực kì mệt mỏi;
  * Hôn mê;
  * Cảm giác uể oải;
  * Thiếu năng lượng.


Mệt mỏi liên quan đến thiếu canxi cũng có thể gây ra hoa mắt, chóng mặt, thiếu tập trung, hay quên.
### **Các triệu chứng về móng và da**
Thiếu canxi mãn tính có thể ảnh hưởng đến da và móng tay.
Da có thể trở nên khô và ngứa, và các nhà nghiên cứu đã chỉ ra mối liên quan giữa hạ canxi máu với **bệnh chàm** và **bệnh vẩy nến**.
Sự thiếu hụt canxi có thể dẫn đến móng tay khô, giòn và dễ gãy. Ngoài ra, tình trạng này cũng có thể góp phần gây ra chứng rụng tóc.
### **Thiếu xương và loãng xương**
Xương dự trữ canxi tốt, nhưng chúng cần hàm lượng cao để duy trì sự chắc khỏe. Khi mức độ tổng thể của canxi thấp, cơ thể cần lấy bớt nguồn canxi dự trữ từ xương.
Thiếu canxi có thể làm giảm mật độ khoáng của xương và có thể dẫn đến loãng xương. Loãng xương làm cho xương mỏng hơn và dễ bị gãy hơn.
Trong khi thiếu xương ít nghiêm trọng hơn loãng xương, nhưng cả hai đều gây giảm mật độ xương và tăng nguy cơ gãy xương.
Mất nhiều năm để xương giảm đi mật độ và sự thiếu hụt canxi có thể gây ra các vấn đề nghiêm trọng.
### **Hội chứng tiền kinh nguyệt (PMS)**
Mức canxi thấp có liên quan đến hội chứng tiền kinh nguyệt nghiêm trọng.
Những người tham gia vào một nghiên cứu năm 2017 cho biết tâm trạng được cải thiện và giảm tỷ lệ giữ nước sau khi uống 500 miligam (mg) canxi mỗi ngày trong 2 tháng.
Vào năm 2019, các tác giả của một bài đánh giá có hệ thống đã kết luận rằng lượng vitamin D và canxi thấp trong nửa sau của chu kỳ kinh nguyệt có thể góp phần gây ra các triệu chứng của PMS.
### **Các vấn đề về răng miệng**
Khi cơ thể thiếu canxi sẽ lấy canxi từ các nguồn như răng. Điều này có thể dẫn đến các vấn đề về răng miệng bao gồm chân răng yếu, nướu bị kích thích, răng giòn và sâu răng.
Ngoài ra, thiếu canxi ở trẻ sơ sinh có thể làm chậm quá trình hình thành răng.
### **Suy nhược**
Thiếu canxi có liên quan đến rối loạn tâm trạng bao gồm cả trầm cảm mặc dù hiện tại chưa có bằng chứng rõ ràng.
Nếu nghi ngờ rằng sự thiếu hụt canxi đang góp phần vào các triệu chứng trầm cảm nên yêu cầu kiểm tra mức độ canxi máu. Bổ sung canxi có thể giúp kiểm soát các triệu chứng này.
## **Khi nào đến gặp bác sĩ**
Bất kỳ ai gặp các triệu chứng thiếu canxi nên đi khám bác sĩ đề được kiểm tra nồng độ canxi trong máu.
Phạm vi bình thường đối với người lớn là **8,8–10,4 miligam trên decilit** (mg/dL). Đối với trẻ em cần nhiều canxi hơn người lớn và bất kỳ mức nào thấp hơn 8,8 mg/dL đều là thiếu hụt.
## **Bệnh thiếu canxi phổ biến như thế nào?**
Theo một báo cáo năm 2013 được công bố trên Tạp chí của Đại học Dinh dưỡng Hoa Kỳ, những người sau đây có nhiều khả năng bị thiếu canxi:
  * Người cao tuổi;
  * Thanh thiếu niên;
  * Người có chế độ ăn uống nghèo canxi;
  * Những người thừa cân.


Vào năm 2013, các tác giả tại các trường đại học Anh đã báo cáo rằng tình trạng thiếu canxi thường gặp ở những người mắc các bệnh mãn tính.
Theo ước tính toàn cầu được công bố vào năm 2015, **3,5 tỷ** người có nguy cơ bị thiếu canxi.
Các tác giả tại các trường đại học Pakistan đã khảo sát 252 phụ nữ tham gia. Trong khi 41% bị thiếu canxi và vitamin D, 78% cho biết có các triệu chứng giống với tình trạng thiếu hụt canxi bao gồm đau lưng, chân và khớp.
## **Các biến chứng**
Thiếu hụt canxi có liên quan đến các tình trạng như:
  * Co giật;
  * Các vấn đề răng;
  * Uể oải;
  * Các tình trạng về da;
  * Đau khớp và cơ mãn tính;
  * Gãy xương;
  * Một số dị tật ở trẻ sơ sinh.


Một nghiên cứu bao gồm 1.038 người được chăm sóc đặc biệt tại Bệnh viện Đại học Hoàng gia Liverpool - Anh cho thấy 55,2% bị hạ canxi máu và 6,2% trong số những người này bị thiếu hụt canxi trầm trọng.
## **Điều trị và phòng ngừa**
Cách an toàn và dễ dàng nhất để kiểm soát và ngăn ngừa sự thiếu hụt canxi là bổ sung thêm canxi vào chế độ ăn uống. Một số thực phẩm giàu canxi bao gồm:
  * Các sản phẩm từ sữa như sữa, pho-mát và sữa chua;
  * Đậu;
  * Quả sung;
  * Bông cải xanh;
  * Đậu hũ;
  * Sữa đậu nành;
  * Rau bina (cải bó xôi);
  * Ngũ cốc;
  * Các loại hạt.


Lượng canxi khuyến nghị hàng ngày trong chế độ ăn uống là **1.000 mg** cho những người từ 19–50 tuổi. Đối với trẻ em, thanh thiếu niên và người lớn tuổi có nhu cầu về canxi nhiều hơn.
Không nên bổ sung canxi mà không hỏi ý kiến ​​bác sĩ trước. Việc quá nhiều canxi làm tăng nguy cơ mắc bệnh tim mạch, sỏi thận và các vấn đề sức khỏe nghiêm trọng khác.
Đối với trường hợp thiếu hụt nghiêm trọng hoặc khi bổ sung và điều chỉnh chế độ ăn uống không đạt được kết quả bác sĩ có thể chỉ định tiêm canxi.
## **Tóm tắt**
Thiếu canxi là tình trạng được gây ra bởi nhiều nguyên nhân, tuy nhiên có thể dễ dàng cải thiện thông qua thay đổi chế độ ăn uống.
Hầu hết những trường hợp bị thiếu hụt canxi được bổ sung đều nhận thấy các triệu chứng được cải thiện trong vòng một vài tuần. Những người bị thiếu hụt canxi nghiêm trọng có thể cần được theo dõi để ngăn ngừa các biến chứng.
Xem tiếp: [**Hạ canxi máu là gì?**](https://bvnguyentriphuong.com.vn/dieu-duong/ha-canxi-mau)
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [Hạ canxi máu dẫn đến tình trạng gì?](https://bvnguyentriphuong.com.vn/khoa-kham-benh/dieu-gi-xay-ra-khi-luong-canxi-trong-mau-thap#h-canxi-mu-dn-ntnh-trng-g)
  * [Các triệu chứng của tình trạng thiếu canxi như thế nào?](https://bvnguyentriphuong.com.vn/khoa-kham-benh/dieu-gi-xay-ra-khi-luong-canxi-trong-mau-thap#cc-triu-chng-ca-tnh-trng-thiu-canxi-nh-th-no)
  * [Các vấn đề về cơ](https://bvnguyentriphuong.com.vn/khoa-kham-benh/dieu-gi-xay-ra-khi-luong-canxi-trong-mau-thap#cc-vn-v-c)
  * [Các triệu chứng về móng và da](https://bvnguyentriphuong.com.vn/khoa-kham-benh/dieu-gi-xay-ra-khi-luong-canxi-trong-mau-thap#cc-triu-chng-v-mng-v-da)
  * [Thiếu xương và loãng xương ](https://bvnguyentriphuong.com.vn/khoa-kham-benh/dieu-gi-xay-ra-khi-luong-canxi-trong-mau-thap#thiu-xng-v-long-xng)
  * [Hội chứng tiền kinh nguyệt (PMS)](https://bvnguyentriphuong.com.vn/khoa-kham-benh/dieu-gi-xay-ra-khi-luong-canxi-trong-mau-thap#hi-chng-tin-kinh-nguyt-pms)
  * [Các vấn đề về răng miệng](https://bvnguyentriphuong.com.vn/khoa-kham-benh/dieu-gi-xay-ra-khi-luong-canxi-trong-mau-thap#cc-vn-v-rng-ming)
  * [Khi nào đến gặp bác sĩ](https://bvnguyentriphuong.com.vn/khoa-kham-benh/dieu-gi-xay-ra-khi-luong-canxi-trong-mau-thap#khi-no-n-gp-bc-s)
  * [Bệnh thiếu canxi phổ biến như thế nào?](https://bvnguyentriphuong.com.vn/khoa-kham-benh/dieu-gi-xay-ra-khi-luong-canxi-trong-mau-thap#bnh-thiu-canxi-ph-bin-nh-th-no)
  * [Điều trị và phòng ngừa](https://bvnguyentriphuong.com.vn/khoa-kham-benh/dieu-gi-xay-ra-khi-luong-canxi-trong-mau-thap#iu-tr-v-phng-nga)



