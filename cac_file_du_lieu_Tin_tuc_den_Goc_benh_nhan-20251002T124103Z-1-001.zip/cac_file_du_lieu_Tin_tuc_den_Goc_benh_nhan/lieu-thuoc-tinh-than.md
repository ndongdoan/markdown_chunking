## 28 ngày để thực hành lòng biết ơn

  * [NGÀY 01: CẢM NHẬN HẠNH PHÚC](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/28-ngay-de-thuc-hanh-long-biet-on#ngy-01-cm-nhn-hnh-phc)
  * [NGÀY 02: HÒN ĐÁ NHIỆM MẦU](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/28-ngay-de-thuc-hanh-long-biet-on#ngy-02-hn-nhim-mu)
  * [NGÀY 03: MỐI QUAN HỆ NHIỆM MẦU](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/28-ngay-de-thuc-hanh-long-biet-on#ngy-03-mi-quan-h-nhim-mu)
  * [NGÀY 04: SỨC KHOẺ NHIỆM MẦU](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/28-ngay-de-thuc-hanh-long-biet-on#ngy-04-sc-kho-nhim-mu)
  * [NGÀY 05: TIỀN BẠC NHIỆM MẦU](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/28-ngay-de-thuc-hanh-long-biet-on#ngy-05-tin-bc-nhim-mu)
  * [NGÀY 06: CÔNG VIỆC NHIỆM MẦU](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/28-ngay-de-thuc-hanh-long-biet-on#ngy-06-cng-vic-nhim-mu)
  * [NGÀY 07: CÁNH CỬA THOÁT KHỎI SỰ TIÊU CỰC](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/28-ngay-de-thuc-hanh-long-biet-on#ngy-07-cnh-ca-thot-khi-s-tiu-cc)


## **NGÀY 01: CẢM NHẬN HẠNH PHÚC**
Lập danh sách 10 điều bạn cảm thấy biết ơn 
**_Hướng dẫn:_**
Vào buổi sáng, viết vào sổ 10 điều bạn cảm thấy biết ơn về bản thân, cơ thể, các giác quan, con người, gia đình, công việc,… mọi thứ xung quanh bạn, kèm theo lý do vì sao bạn biết ơn điều đó.
**_Ví dụ:_**
  * Tôi thật sự may mắn hạnh phúc có … vì …
  * Tôi thật sự hạnh phúc và biết ơn … vì …
  * Từ tận đáy lòng tôi chân thành biết ơn … vì …


Cảm ơn, cảm ơn, cảm ơn!
_**P/s:** Đặt tay lên trái tim, đọc lại những điều đã viết, nói lời cảm ơn, và cảm nhận năng lượng của lòng biết ơn. Bạn chỉ cần chọn 1 trong 3 ví dụ trên để ráp vào 10 điều biết ơn của bạn. Bài tập này sẽ được lặp lại trong 27 ngày tiếp theo vào mỗi buổi sáng._
## **NGÀY 02: HÒN ĐÁ NHIỆM MẦU**
Trong ngày thứ 2 này bạn sẽ thực hành 3 bài tập sau:
Bài tập 1. Lập danh sách 10 điều bạn cảm thấy biết ơn
Vào buổi sáng, lặp lại bài tập ngày 1 với 10 điều bạn cảm thấy biết ơn (giống hoặc khác đều được). Bản thân Văn thường viết lại 5 điều của ngày hôm trước và thêm vào 5 điều mới.
Bài tập 2. Hòn đá nhiệm mầu
Tìm một hòn đá tự nhiên để làm hòn đá nhiệm mầu. Kể từ giây phút này, hòn đá sẽ cùng bạn đi suốt hành trình thực hành lòng biết ơn. Hãy giữ gìn nó bên cạnh như một người bạn đồng hành, lắng nghe và chia sẻ. 
Bài tập 3. Thực hành hòn đá nhiệm mầu
Mỗi buổi tối trước khi đi ngủ (từ ngày 2 đến ngày 28), hãy cầm hòn đá nhiệm mầu trong tay và nghĩ về những điều tốt đẹp đã xảy ra trong ngày. Nói ra từ nhiệm mầu cảm ơn, cảm ơn, cảm ơn. Và cảm nhận sự rung động của lòng biết ơn từ trái tim bạn.
## **NGÀY 03: MỐI QUAN HỆ NHIỆM MẦU**
Trong ngày thứ 3 này bạn sẽ thực hành 3 bài tập sau:
Bài tập 1. Lập danh sách 10 điều bạn cảm thấy biết ơn
Bài tập 2. Mối quan hệ nhiệm mầu
_**Hướng dẫn:**_
Vào giờ nghỉ trưa (hoặc bất kỳ thời gian rảnh trong ngày), tìm ra 3 mối quan hệ thân thiết và hình ảnh của từng người để thực hành lòng biết ơn. Đặt bức ảnh của họ trước mắt bạn, viết ra 5 điều bạn cảm thấy biết ơn nhất về người đó. Hãy bắt đầu bằng từ nhiệm mầu CẢM ƠN, kết thúc bằng 3 từ nhiệm mầu cảm ơn, cảm ơn, cảm ơn.
_**Ví dụ:**_
  * Cảm ơn … vì …
  * Tôi thật sự biết ơn … vì …
  * Từ tận đáy lòng tôi chân thành biết ơn … vì …


Cảm ơn, cảm ơn, cảm ơn!
_**P/s:** Đặt tay lên trái tim, đọc lại những điều đã viết, nói lời cảm ơn, và cảm nhận năng lượng của lòng biết ơn. _
Bài tập 3. Thực hành hòn đá nhiệm mầu
## **NGÀY 04: SỨC KHOẺ NHIỆM MẦU**
Trong ngày thứ 4 này bạn sẽ thực hành 3 bài tập sau:
Bài tập 1. Lập danh sách 10 điều bạn cảm thấy biết ơn
Bài tập 2. Sức khoẻ nhiệm mầu
Lấy một mẩu giấy (giấy bìa cứng càng tốt) viết lên đó trong chữ **MÓN QUÀ SỨC KHỎE ĐANG GIÚP TÔI ĐƯỢC SỐNG**. Mang theo mẩu giấy trong ngày hôm nay hoặc đặt nó ở vị trí dễ bạn dàng nhìn thấy nhất. Trong ngày hôm ngày, ít nhất 4 lần, bạn hãy nhìn vào dòng chữ này đọc chúng thật chậm từng từ một, cảm nhận và biết ơn món quà sức khỏe bạn đang có.
Bài tập 3. Thực hành hòn đá nhiệm mầu
## **NGÀY 05: TIỀN BẠC NHIỆM MẦU**
Trong ngày thứ 5 này bạn sẽ thực hành 4 bài tập sau:
Bài tập 1. Lập danh sách 10 điều bạn cảm thấy biết ơn
Bài tập 2. Tiền bạc đến với tôi thật dễ dàng
Dành vài phút để nghĩ về tuổi thơ, nghĩ về tất cả những thứ mà bạn đã được nhận, được cho, được tặng, được miễn phí. Nhớ lại những ký ức mà ở đó tiền bạc được người khác chi trả cho bạn. Bằng cả tấm lòng, hãy nói từ nhiệm mầu CẢM ƠN đối với những kỉ niệm ấy.
Bài tập 3. Tờ tiền nhiệm mầu
Chuẩn bị một mẩu giấy và một tờ tiền. 
Viết lên mẩu giấy nội dung **CẢM ƠN TẤT CẢ NHỮNG KHOẢN TIỀN TÔI NHẬN ĐƯỢC TRONG CUỘC SỐNG**. 
Dán mẫu giấy lên tờ tiền bạn đã chuẩn bị. 
Mang theo TỜ TIỀN NHIỆM mầu trong ngày hôm nay, ít nhất 2 lần (sáng và chiều) cầm tờ tiền trong tay và đọc những dòng bạn viết với lòng biết ơn chân thành dành cho sự đủ đầy và tiền bạc mà bạn đã nhận được. 
Sau ngày hôm nay, hãy đặt tờ tiền nhiệm mầu ở nơi mà bạn có thể thường xuyên nhìn thấy mỗi ngày.
Bài tập 4. Thực hành hòn đá nhiệm mầu
## NGÀY 06: CÔNG VIỆC NHIỆM MẦU
Trong ngày thứ 6 này bạn sẽ thực hành 3 bài tập sau:
Bài tập 1. Lập danh sách 10 điều bạn cảm thấy biết ơn
Bài tập 2. Người quản lý mầu nhiệm
Người quản lý vô hình của lòng biết ơn. Khi làm việc hãy tưởng tượng có một người quản lý vô hình đi theo bạn và ghi chú lại mỗi khi bạn cảm thấy điều gì đó để biết ơn. 
Bằng cả tấm lòng hãy nói lời cảm ơn tới những điều bạn nhận được trong công việc của mình. 
Cảm ơn/Tôi rất biết ơn vì … (một điều gì đó liên quan đến công việc của bạn)
Bạn hãy nhớ rằng luôn có một người quản lý vô hình bên bạn và ghi nhận lại tất cả những điều bạn đã biết ơn về công việc của mình.
_**P/s:** Khi thực hành ngày 6, Văn cảm nhận được rằng ngoài biết ơn công việc của mình, tác giả còn muốn nhắc nhở chúng ta hãy cố gắng nỗ lực hoàn thành tốt công việc của mình, vì người quản lý (cấp trên) của bạn vẫn luôn âm thầm quan sát và ghi nhận lại tất cả những nỗ lực của bạn._
Bài tập 3. Thực hành hòn đá nhiệm mầu
## NGÀY 07: CÁNH CỬA THOÁT KHỎI SỰ TIÊU CỰC
Trong ngày thứ 7 này bạn sẽ thực hành 4 bài tập sau:
Bài tập 1. Lập danh sách 10 điều bạn cảm thấy biết ơn
Bài tập 2. Biết ơn những điều tiêu cực
Chọn một vấn đề tiêu cực trong cuộc sống mà bạn muốn giải quyết. Liệt kê 10 điều bạn cảm thấy biết ơn vì tình huống tiêu cực đó. 
_Ví dụ: Tôi biết ơn … vì nhờ nó tôi đã …_
Bài tập 3. Một ngày tích cực
Hãy cam kết trong suốt ngày hôm nay bạn sẽ không nghĩ và nói bất cứ điều gì tiêu cực. Nếu bạn có lỡ nghĩ hoặc nói một điều gì đó tiêu cực thì hãy dừng lại và nói từ nhiệm màu.
_Ví dụ: Tôi biết ơn + [điều tiêu cực bạn vừa nghĩ] + vì nhờ nó tôi đã + …_
Bài tập 4. Thực hành hòn đá nhiệm màu
[_**07 ngày tiếp theo**_](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/28-ngay-de-thuc-hanh-long-biet-on-2)
  * [NGÀY 01: CẢM NHẬN HẠNH PHÚC](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/28-ngay-de-thuc-hanh-long-biet-on#ngy-01-cm-nhn-hnh-phc)
  * [NGÀY 02: HÒN ĐÁ NHIỆM MẦU](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/28-ngay-de-thuc-hanh-long-biet-on#ngy-02-hn-nhim-mu)
  * [NGÀY 03: MỐI QUAN HỆ NHIỆM MẦU](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/28-ngay-de-thuc-hanh-long-biet-on#ngy-03-mi-quan-h-nhim-mu)
  * [NGÀY 04: SỨC KHOẺ NHIỆM MẦU](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/28-ngay-de-thuc-hanh-long-biet-on#ngy-04-sc-kho-nhim-mu)
  * [NGÀY 05: TIỀN BẠC NHIỆM MẦU](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/28-ngay-de-thuc-hanh-long-biet-on#ngy-05-tin-bc-nhim-mu)
  * [NGÀY 06: CÔNG VIỆC NHIỆM MẦU](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/28-ngay-de-thuc-hanh-long-biet-on#ngy-06-cng-vic-nhim-mu)
  * [NGÀY 07: CÁNH CỬA THOÁT KHỎI SỰ TIÊU CỰC](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/28-ngay-de-thuc-hanh-long-biet-on#ngy-07-cnh-ca-thot-khi-s-tiu-cc)



## Lagom là một triết lý sống đến từ Thụy Điển

Lagom thường được hiểu là: **“Không quá ít, không quá nhiều – vừa đủ là tốt nhất.”** Đây không chỉ là một khái niệm đơn thuần về tiết chế hay lối sống tối giản, mà là một cách sống cân bằng, biết đâu là điểm dừng vừa đẹp giữa tham vọng và hài lòng, giữa cho đi và giữ lại.
Từ “lagom” bắt nguồn từ cụm từ “laget om” – nghĩa là “phần chia đều cho mọi người”. Trong văn hóa Bắc Âu, việc mỗi người uống một ngụm rượu vừa đủ từ chiếc sừng chung truyền tay đã trở thành biểu tượng của sự chia sẻ và tiết chế. Lagom không có nghĩa là an phận, mà là biết đủ
Nhưng trong đời sống hiện đại, Lagom là lời nhắc tỉnh táo giữa một thế giới đang quá dư thừa, lagom không chỉ là sự vừa đủ về vật chất, mà còn là một triết lý sống hướng đến sự cân bằng trong mọi thứ:
• Làm việc vừa đủ – không kiệt sức, cũng không lười biếng.
• Ăn uống vừa đủ – không ép bản thân theo trào lưu, cũng không buông thả.
• Tiêu dùng vừa đủ – không chạy theo hàng hiệu, cũng không cực đoan kham khổ.
• Thể hiện cảm xúc vừa đủ – không quá phô trương, cũng không kìm nén.
Ngày xưa, người ta nói đến “work-life balance” cân bằng giữa công việc và cuộc sống như hai bên bàn cân tách biệt. Nhưng ngày nay, ranh giới đó mờ nhòe dần. Công nghệ cho phép chúng ta làm việc ở bất kỳ đâu, bất kỳ lúc nào. Và đó là lúc khái niệm “work-life integration” xuất hiện – hòa nhập công việc vào cuộc sống một cách hài hòa. Lagom không phủ nhận sự gắn bó giữa bạn và công việc. Nhưng nó khuyên bạn sắp xếp lại mọi thứ sao cho mỗi vai trò là người làm việc, người cha mẹ, người con, người yêu, người bạn đều có chỗ đứng vừa vặn trong cùng một đời sống duy nhất.
Không còn là “sống để làm”, cũng không hoàn toàn “làm để sống”. Mà là: Sống và làm việc theo cách khiến cả hai cùng phát triển mà bạn không đánh mất mình.
Trong một thế giới mà thành công thường được đo bằng tốc độ, độ phủ sóng và tài sản tích lũy, Lagom là lời nhắc nhớ ta sống chậm lại, sống chọn lọc, sống có chiều sâu. Một buổi chiều không họp – để đi bộ cùng con. Một ngày làm việc hiệu quả – nhưng vẫn ăn tối đúng giờ, không nhìn điện thoại. Một tách cà phê, không phải để “chống buồn ngủ”, mà để lắng lại phản tỉnh thân tâm một chút giữa dòng người hối hả.
Lagom không phải là sống nhỏ lại. Mà là sống vừa đủ để bạn có thể cười không gượng gạo, ngủ không day dứt, ăn không vội vàng và yêu không mỏi mệt. Bạn không cần có tất cả. Chỉ cần giữ được chính mình, là đã đủ rồi.
Lagom cũng không phải chủ nghĩa hoàn hảo. Cân bằng cuộc sống không đồng nghĩa với việc mọi khía cạnh trong đó đều đạt đến độ “hoàn hảo” hay “tốt nhất”. Ngược lại với chủ nghĩa hoàn hảo luôn đề cao kết quả, Lagom luôn tập trung vào quá trình, khuyên con người biết dừng lại khi cần thiết, và sự thiếu hoàn hảo cũng chính là một vẻ đẹp của sự hài hòa và tự nhiên.

## Inner Child – đứa trẻ bên trong, câu chuyện của sự chữa lành

Inner Child – “đứa trẻ bên trong” là cách nói ẩn dụ cho một phần tâm trí của mỗi người. Inner Child là nơi lưu giữ những ký ức, những trải nghiệm, và những cảm xúc chúng ta đã trải qua trong thời thơ ấu đến trước tuổi dậy thì. 
Những trải nghiệm đã diễn ra trong thời thơ ấu, cách mỗi người chúng ta được nuôi dưỡng và lớn lên ra sao, là một trong những viên gạch tạo nên nhận thức, cách suy nghĩ, cá tính và bản ngã của mỗi cá nhân trong hiện tại. Đứa trẻ bên trong mỗi người chúng ta vẫn luôn ở đó, có thể vui tươi hồn nhiên hạnh phúc, hay thường đau buồn mặc cảm với những tổn thương và vẫn chờ đợi để được xoa dịu hoặc chữa lành.
Đứa trẻ bên trong luôn là một phần đại diện trong bạn và sẽ đi theo bạn trong suốt cuộc đời. Có những nỗi đau trong quá khứ chưa được chữa lành sẽ luôn khiến bạn cảm thấy tủi thân và sợ hãi cảm giác bị bỏ rơi, cảm giác bất an khi ai đó lãng quên hay chỉ đơn giản là phớt lờ bạn. Có những người họ là một đứa trẻ mãi không chịu lớn, nhưng có thể từ nhỏ họ đã thiếu vắng đi tình thương và sự quan tâm

## 28 ngày để thực hành lòng biết ơn (4)

  * [07 ngày trước đó](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/28-ngay-de-thuc-hanh-long-biet-on-4#07-ngytrc-)
  * [NGÀY 22: PHÉP MẦU NGAY TRƯỚC MẮT](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/28-ngay-de-thuc-hanh-long-biet-on-4#ngy-22-php-mungay-trc-mt)
  * [NGÀY 23: KHÔNG KHÍ NHIỆM MÀU](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/28-ngay-de-thuc-hanh-long-biet-on-4#ngy-23-khng-kh-nhim-mu)
  * [NGÀY 24: CHIẾC ĐŨA PHÉP](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/28-ngay-de-thuc-hanh-long-biet-on-4#ngy-24-chic-a-php)
  * [NGÀY 25: GỢI Ý NHIỆM MẦU](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/28-ngay-de-thuc-hanh-long-biet-on-4#ngy-25-gi-nhim-mu)
  * [NGÀY 26: PHÉP MẦU BIẾN LỖI LẦM THÀNH HẠNH PHÚC](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/28-ngay-de-thuc-hanh-long-biet-on-4#ngy-26-php-mu-bin-li-lm-thnh-hnh-phc)
  * [NGÀY 27: TẤM GƯƠNG NHIỆM MẦU](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/28-ngay-de-thuc-hanh-long-biet-on-4#ngy-27-tm-gng-nhim-mu)
  * [NGÀY 28: NGHIỆM LẠI PHÉP MẦU](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/28-ngay-de-thuc-hanh-long-biet-on-4#ngy-28-nghim-li-php-mu)


## __
## **NGÀY 22: PHÉP MẦU NGAY TRƯỚC MẮT**
Trong ngày thứ 22 này bạn sẽ thực hành 3 bài tập sau:
Bài tập 1. Lập danh sách 10 điều bạn cảm thấy biết ơn
Bài tập 2. Phép mầu ngay trước mắt
Vào đầu ngày, lấy ra danh sách 10 mong muốn. Đọc lại danh sách 10 mong muốn của bạn. Hãy tưởng tượng rằng bạn đã nhận được điều mình mong muốn. Cảm nhận lòng biết ơn càng nhiều càng tốt. 
Trong ngày, mang theo danh sách mong muốn. Ít nhất 2 lần trong ngày hãy lấy nó ra đọc qua và cảm nhận lòng biết ơn càng nhiều càng tốt.
Bài tập 3. Thực hành hòn đá nhiệm mầu
## **NGÀY 23: KHÔNG KHÍ NHIỆM MÀU**
Trong ngày thứ 23 này bạn sẽ thực hành 3 bài tập sau:
Bài tập 1. Lập danh sách 10 điều bạn cảm thấy biết ơn
Bài tập 2. Không khí nhiệm mầu
Bạn đang hít thở dòng khí nhiệm màu. 5 lần trong ngày hãy nghĩ về dòng không khí tuyệt vời bạn đang hít thở. Hít vào thở ra 5 lần thật chậm. Cảm nhận luồng khí bên trong cơ thể bạn khi hít vào và niềm vui khi thở ra. Sau đó hãy nói câu nhiệm màu: “ _**Cảm ơn Dòng khí nhiệm màu tôi đang hít thở**_ ”. Cảm nhận lòng biết ơn chân thành nhất đối với dòng khí quý giá và quan trọng mà bạn đang hít thở.
Bài tập 3. Thực hành hòn đá nhiệm mầu
## **NGÀY 24: CHIẾC ĐŨA PHÉP**
Trong ngày thứ 24 này bạn sẽ thực hành 3 bài tập sau:
Bài tập 1. Lập danh sách 10 điều bạn cảm thấy biết ơn
Bài tập 2. Chiếc đũa phép
Chọn 3 người mà bạn yêu quý, đang thiếu thốn sức khỏe, tiền bạc, hạnh phúc hoặc cả 3. Tìm một tấm ảnh của mỗi người và để nó ở trước mặt khi thực hiện phương pháp này. Thực hiện lần lượt từng người một như sau: 
Cầm trên tay tấm ảnh của họ. 
Nhắm mắt lại và trong vòng một phút hãy hình dung bạn nhận được tin rằng người đó đã có được điều họ muốn. 
Mở mắt ra và trong khi vẫn cầm tấm ảnh trên tay, hãy nói từ nhiệm màu:  _**Cảm ơn, Cảm ơn, Cảm ơn vì [Tên Người Đó] đã có sức khỏe, tiền bạc và hạnh phúc**_. 
Bài tập 3. Thực hành hòn đá nhiệm mầu
## **NGÀY 25: GỢI Ý NHIỆM MẦU**
Trong ngày thứ 25 này bạn sẽ thực hành 3 bài tập sau:
Bài tập 1. Lập danh sách 10 điều bạn cảm thấy biết ơn
Bài tập 2. Gợi ý nhiệm mầu
Hãy tỉnh thức, sáng suốt để quan sát xung quanh và nhận ra ít nhất 7 gợi ý nhiệm màu trong ngày mà vũ trụ dành cho bạn. Cảm nhận và nói từ nhiệm màu CẢM ƠN chân thành đối với mỗi gợi ý ấy.
Bài tập 3. Thực hành hòn đá nhiệm mầu
## **NGÀY 26: PHÉP MẦU BIẾN LỖI LẦM THÀNH HẠNH PHÚC**
Trong ngày thứ 26 này bạn sẽ thực hành 3 bài tập sau:
Bài tập 1. Lập danh sách 10 điều bạn cảm thấy biết ơn
Bài tập 2. Phép màu biến lỗi lầm thành hạnh phúc
Chọn một lỗi lầm bạn mắc phải trong quá khứ. Tìm và viết ra 10 điều bạn cảm thấy biết ơn từ sai lầm này. Hãy tự hỏi bản thân mình: “ _Tôi học được gì sau sai lầm này?_ ”, “ _Sai lầm này mang đến cho tôi điều tốt đẹp gì?_ ”. 
Đặt tay lên trái tim mình. Đọc lại 10 điều bạn cảm thấy biết ơn. Nói từ nhiệm màu Cảm ơn, Cảm ơn, Cảm ơn. Cảm nhận sự rung động bên trong bạn.
Bài tập 3. Thực hành hòn đá nhiệm mầu
## **NGÀY 27: TẤM GƯƠNG NHIỆM MẦU**
Trong ngày thứ 27 này bạn sẽ thực hành 3 bài tập sau:
Bài tập 1. Lập danh sách 10 điều bạn cảm thấy biết ơn
Bài tập 2. Tấm gương nhiệm mầu
Mỗi khi nhìn chính mình trong gương, hãy nói hãy nói từ nhiệm màu CẢM ƠN. Hãy thực sự cảm nhận điều ấy hơn tất cả những gì bạn đã từng cảm nhận trước đây.
Khi sử dụng Tấm Gương Nhiệm Màu, hãy nói 3 điều bạn cảm thấy biết ơn về chính bản thân mình.
Bài tập 3. Thực hành hòn đá nhiệm mầu
## **NGÀY 28: NGHIỆM LẠI PHÉP MẦU**
Trong ngày thứ 28 này bạn sẽ thực hành 3 bài tập sau:
Bài tập 1. Lập danh sách 10 điều bạn cảm thấy biết ơn
Bài tập 2. Nhiệm lại phép mầu
Nghiệm lại phép màu bằng cách nhớ lại những điều hạnh phúc trong ngày hôm qua và viết chúng ra thành 1 danh sách.
Đặt tay lên trái tim mình. Đọc lại danh sách những điều hạnh phúc của ngày hôm qua. Nói từ nhiệm màu Cảm ơn, Cảm ơn, Cảm ơn. Cảm nhận sự rung động bên trong bạn.
Sau hôm nay bạn có thể thực hiện phương pháp này bằng cách viết, nói hay chỉ nghĩ trong đầu. Bạn có thể lập danh sách những điều làm bạn hạnh phúc và biết ơn chúng mỗi ngày.
Bài tập 3. Thực hành hòn đá nhiệm mầu
**_Tiếp tục thực hiện cho những ngày tiếp theo để mỗi ngày bạn đều có thể cảm nhận được hạnh phúc từ cuộc sống._**
  * [07 ngày trước đó](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/28-ngay-de-thuc-hanh-long-biet-on-4#07-ngytrc-)
  * [NGÀY 22: PHÉP MẦU NGAY TRƯỚC MẮT](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/28-ngay-de-thuc-hanh-long-biet-on-4#ngy-22-php-mungay-trc-mt)
  * [NGÀY 23: KHÔNG KHÍ NHIỆM MÀU](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/28-ngay-de-thuc-hanh-long-biet-on-4#ngy-23-khng-kh-nhim-mu)
  * [NGÀY 24: CHIẾC ĐŨA PHÉP](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/28-ngay-de-thuc-hanh-long-biet-on-4#ngy-24-chic-a-php)
  * [NGÀY 25: GỢI Ý NHIỆM MẦU](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/28-ngay-de-thuc-hanh-long-biet-on-4#ngy-25-gi-nhim-mu)
  * [NGÀY 26: PHÉP MẦU BIẾN LỖI LẦM THÀNH HẠNH PHÚC](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/28-ngay-de-thuc-hanh-long-biet-on-4#ngy-26-php-mu-bin-li-lm-thnh-hnh-phc)
  * [NGÀY 27: TẤM GƯƠNG NHIỆM MẦU](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/28-ngay-de-thuc-hanh-long-biet-on-4#ngy-27-tm-gng-nhim-mu)
  * [NGÀY 28: NGHIỆM LẠI PHÉP MẦU](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/28-ngay-de-thuc-hanh-long-biet-on-4#ngy-28-nghim-li-php-mu)



## Thực hành: Thiền buông thư

  * [Thiền buông thư là gì?](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/thuc-hanh-thien-buong-thu#thin-bung-th-l-g)
  * [Mục đích của thiền buông thư](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/thuc-hanh-thien-buong-thu#mc-ch-ca-thin-bung-th)
  * [Lợi ích của thiền buông thư](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/thuc-hanh-thien-buong-thu#li-ch-ca-thin-bung-th)


## **Thiền buông thư là gì?**
Thiền buông thư được mô tả là tập trung toàn bộ sự chú ý vào từng bộ phận trên cơ thể, chú ý đến bất kỳ cảm giác nào nảy sinh, chấp nhận chúng và gửi những suy nghĩ tử tế, từ bi đến những vùng đó với mục đích chữa lành.
Theo[ Trung tâm Y học Tổng hợp và Bổ sung Quốc gia – NCCIH](https://www.nccih.nih.gov/health/meditation-and-mindfulness-what-you-need-to-know) cho biết, thực hành thiền giúp bạn tăng khả năng giữ bình tĩnh, tạo ra sự thư giãn sâu cho tâm trí và cho toàn bộ cơ thể.
Kỹ thuật Body scan cũng vậy. Theo quan sát lâm sàng, nếu chỉ với một hiệu lệnh thư giãn, người tham gia thường có xu hướng vẫn giữ sự căng cứng ở một số vùng trên cơ thể. Đó có thể là các cơ trên mặt hay vùng cổ vai gáy… bởi sau thời gian dài làm việc trong ngày, họ đã quen với sự gồng cứng này và không nhận ra.
Với đặc trưng của bài tập là dành thời gian riêng cho từng phần của cơ thể, Body scan có khả năng hỗ trợ cơ thể được thư giãn toàn phần một cách hiệu quả. Bài tập sẽ điều hướng sự tập trung của cá nhân tới từng vùng nhỏ với hiệu lệnh thư giãn hoặc cảm nhận rõ ràng. Sau đó có thời gian để cá nhân thực hiện hiệu lệnh đầy đủ trước khi chuyển qua một vùng mới.
## Mục đích của thiền buông thư
Mục đích chính của thiền buông thư không chỉ là giảm căng thẳng mà còn tăng cường nhận thức và hiểu biết về bản thân và thế giới xung quanh. Trong xã hội ngày nay, nơi có áp lực công việc, cuộc sống bận rộn và nhận thức thường xuyên, tâm trí con người thường bị xáo trộn bởi những suy nghĩ về tương lai hay ký ức về quá khứ. Phương pháp này giúp tập trung vào thời điểm hiện tại, loại bỏ những suy nghĩ không cần thiết và tạo ra một không gian yên tĩnh để tâm trí có thể thư giãn và hồi phục.
## Lợi ích của thiền buông thư
  1. Giảm căng thẳng và lo lắng: Thiền buông thư giúp giảm bớt căng thẳng và lo lắng trong cuộc sống hàng ngày. Việc tập trung vào hơi thở và buông lỏng tâm trí giúp tạo ra một trạng thái tĩnh lặng, giảm áp lực từ những tác động xung quanh.
  2. Tăng cường sự tập trung: Qua việc luyện tập thiền buông thư, bạn phát triển khả năng tập trung và tăng cường sự chú ý đối với hiện tại. Điều này giúp cải thiện khả năng làm việc và đối diện với những thách thức hàng ngày.
  3. Phát triển nhận thức: Thiền buông thư giúp tăng cường sự nhận thức về ý nghĩ và cảm xúc. Bằng cách quan sát ý nghĩ mà không chấp nhận hay đánh giá chúng, bạn trở nên nhạy bén và tự nhìn nhận vấn đề một cách trung thực hơn.
  4. Cải thiện giấc ngủ: Thiền buông thư có thể giúp cải thiện chất lượng giấc ngủ. Việc thư giãn tâm trí trước khi đi ngủ giúp làm dịu cảm xúc và chuẩn bị tâm hồn cho một giấc ngủ sâu thoải mái.
  5. Tăng cường sự bình an: Thiền buông thư tạo nên một trạng thái tinh thần bình an và thanh thản. Bạn có thể trải qua cảm giác hòa mình với môi trường xung quanh, mang lại sự bình yên và hạnh phúc trong cuộc sống.
  6. Giải thoát tâm linh: Phương pháp thiền này có thể giúp bạn trải nghiệm sự kết nối sâu sắc với tất cả mọi thứ. Qua thiền buông thư, bạn có thể khám phá những khía cạnh tâm linh của bản thân và cảm nhận một chiều sâu hơn về ý thức.


Những lợi ích trên không chỉ mang lại sự cân bằng cho tâm hồn mà còn giúp cải thiện sức khỏe toàn diện, tạo ra một cuộc sống ý nghĩa và hòa mình vào tư duy tích cực. Để trải nghiệm đầy đủ lợi ích của thiền buông thư, quan trọng nhất là duy trì sự đều đặn và kiên nhẫn trong quá trình thiền.
**Bài tập buông thư**
Ta nằm trong tư thế thoải mái, hai cánh tay để buông xuôi theo thân thể. Ta để cho thân thể được nghỉ ngơi, thư giãn. Ta ý thức rõ ràng mình đang nằm trên nền nhà, toàn thân đang tiếp xúc với nền nhà. (Dừng một chút) Ta như có cảm tưởng là toàn thân đang mềm ra và lún dần xuống mặt đất (Dừng một chút)
Ta ý thức được hơi thở đang đi vào đi ra. Thở vào, biết mình đang thở vào; thở ra, biết mình đang thở ra. Thở vào, thấy bụng mình đang phồng lên; thở ra, thấy bụng mình xẹp xuống. (Dừng) Phồng lên… xẹp xuống… phồng lên… xẹp xuống. (Dừng)
Thở vào, để tâm vào đôi mắt của mình; thở ra, để cho đôi mắt được thư giãn. Để cho hai mắt chìm sâu vào trong đầu mình… thư giãn mọi cơ bắp ở quanh mắt… đôi mắt thật quý giá vô cùng, đôi mắt cho ta thấy bao nhiêu hình sắc tuyệt vời… hãy để cho đôi mắt có dịp được nghỉ ngơi… ta gởi đến đôi mắt tất cả lòng thương quí và biết ơn. (Dừng)
Thở vào, ta để tâm nơi miệng mình. Thở ra để cho miệng được thư giãn nghỉ ngơi. Ta buông thư tất cả những cơ bắp quanh miệng… đôi môi của ta là những cánh hoa xinh đẹp… hãy nở một nụ cười nhẹ nhàng… mỉm cười để làm rơi rụng tất cả những căng thẳng trên khuôn mặt… dần dần hai má cũng được thư giãn… quai hàm cũng được thư giãn… cổ họng cũng được thư giãn… (Dừng)
Thở vào, ta đưa ý thức xuống hai vai. Thở ra, để cho hai vai được thư giãn. Để cho hai vai lún dần xuống sàn nhà… hãy buông hết xuống sàn nhà tất cả những căng thẳng tích lũy bấy lâu nay… Trong quá khứ, ta đã gánh vác quá nhiều trên đôi vai của mình… bây giờ ta hãy đặt chúng xuống đất, để cho hai vai ta được nhẹ nhõm… Ta gởi đến đôi vai tất cả lòng thương quí và biết ơn.
Thở vào, ta đưa ý thức xuống hai cánh tay. Thở ra, ta buông thư hai tay. Để cho hai tay dần lún xuống sàn nhà… rồi cánh tay… khuỷu tay… cổ tay… các ngón tay… tất cả đều mềm ra, hoàn toàn thư giãn. Có thể cho các ngón tay cọ quậy chút đỉnh để các cơ bắp được thư giãn.
Thở vào, ta đưa ý thức đến trái tim của mình… Thở ra, cho phép trái tim được thư giãn… (Dừng)… Đã từ lâu ta quên chăm sóc cho trái tim của ta, vì ta chỉ lo làm ăn, bận bịu suốt ngày, rồi căng thẳng, bực bội, làm cho trái tim ta mệt mỏi… (Dừng)… Trong khi đó trái tim làm việc cho ta suốt ngày đêm không ngừng nghỉ… Ngay bây giờ hãy nhẹ nhàng ôm lấy trái tim bằng chánh niệm… hãy nói lời xin lỗi với trái tim và hứa từ nay sẽ chăm sóc trái tim với tất cả lòng thương quí và biết ơn.
Thở vào, ta đưa ý thức xuống hai chân. Thở ra, cho phép hai chân được thư giãn. Để rơi rụng tất cả những căng thẳng, để hai chân được hoàn toàn thư giãn… từ bắp đùi… đến đầu gối… đến mắt cá chân… bàn chân…các ngón chân… tất cả đều được hoàn toàn thư giãn. Có thể cọ quậy chút đỉnh để các ngón chân được thư giản. Gởi đến từng ngón chân tất cả lòng thương quí và biết ơn…(Dừng)
Thở vào, thở ra… ta thấy toàn thân nhẹ nhàng làm sao… như những cánh bèo đang trôi êm đềm trên mặt nước… không cần phải đi đâu nữa… không cần phải làm gì cả… ta thấy mình thong dong như mây bay trên bầu trời… (Dừng)
(Hát vài bài hát) (Dừng)
Đưa ý thức trở về với hơi thở… để ý đến bụng đang phình lên, xẹp xuống… (Dừng)
Theo dõi hơi thở. Ý thức về hai cánh tay và hai chân của mình… nhẹ nhàng lay động hai tay hai chân rồi duỗi thẳng. (Dừng)
Ta nhẹ nhàng ngồi dậy. Rồi nhẹ nhàng đứng lên.
Theo bài tập trên, ta có thể đưa ý thức đến từng bộ phận của cơ thể, để tâm chăm sóc từng bộ phận trong khi thở vào thở ra, nhất là những nơi đang đau nhức, để những nơi đó có thêm năng lượng tự chữa trị. Ta gửi theo từng hơi thở tất cả lòng thương quí và biết ơn của ta đến từng bộ phận của cơ thể, vì cơ thể của chúng ta là người bạn đồng hành thân thiết nhất.
  * [Thiền buông thư là gì?](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/thuc-hanh-thien-buong-thu#thin-bung-th-l-g)
  * [Mục đích của thiền buông thư](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/thuc-hanh-thien-buong-thu#mc-ch-ca-thin-bung-th)
  * [Lợi ích của thiền buông thư](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/thuc-hanh-thien-buong-thu#li-ch-ca-thin-bung-th)



## Thiền Vipassana là gì? Có tác dụng gì với sức khỏe

  * [Giảm căng thẳng, buông bỏ lo âu](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/thien-vipassana-la-gi-co-tac-dung-gi-voi-suc-khoe#gim-cng-thng-bung-b-lo-u)
  * [Hỗ trợ giảm các triệu chứng bệnh mãn kinh](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/thien-vipassana-la-gi-co-tac-dung-gi-voi-suc-khoe#h-tr-gim-cc-triu-chng-bnh-mn-kinh)
  * [Thúc đẩy sự linh hoạt của não bộ](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/thien-vipassana-la-gi-co-tac-dung-gi-voi-suc-khoe#thc-y-s-linh-hot-ca-no-b)


Vipassana – nghĩa là thấy sự việc đúng như thật – là một trong những phương pháp thiền cổ xưa nhất tại Ấn độ. Truyền thống thiền này được Đức Phật Gotama tái phát hiện cách đây hơn 2500 năm; và được Ngài giảng dạy như một liều thuốc chung chữa trị những bệnh chung của nhân loại – một Nghệ Thuật Sống. Phương pháp không tông phái này nhằm tới việc diệt trừ những bất tịnh tinh thần và đưa đến hạnh phúc cao cả nhất của việc hoàn toàn giải thoát.
Vipassana là con đường tự thay đổi bằng cách tự quan sát. Phương pháp thiền này chú trọng đến tương quan mật thiết giữa tâm và thân. Mối tương quan này có thể kinh nghiệm được trực tiếp bằng cách chú tâm thận trọng đến những cảm giác thực sự trên thân, những cảm giác luôn luôn đan xen và tạo ra các khuôn mẫu cho tâm. Hành trình quan sát và tự khám phá này đi vào cái gốc rễ chung của tâm và thân, từ đó xóa bỏ những bất tịnh tinh thần, mang đến một tâm quân bình tràn đầy tình thương và lòng từ bi.
Những định luật khoa học vốn chi phối ý nghĩ, cảm xúc, sự phán xét, và cảm giác của con người trở nên rõ ràng, dễ hiểu. Thông qua những trải nghiệm trực tiếp, ta hiểu được sự tiến bộ hay thụt lùi của bản thân diễn ra như thế nào, việc bản thân tạo ra những khổ đau hay việc tự giải thoát mình khỏi khổ đau diễn ra ra sao. Cuộc sống của ta gia tăng hiểu biết, không còn ảo tưởng, tràn ngập tự chủ và an lạc
Mục tiêu của thiền Vipassana là giúp bạn:
  * Làm dịu tâm trí để sống an yên hơn
  * Tập trung vào hiện tại
  * Biết chấp nhận bản chất của sự vật, sự việc 
  * Giảm bớt sự hối tiếc bằng cách nghĩ ít hơn về quá khứ
  * Bớt lo lắng cho tương lai
  * Biết cách ứng phó với các tình huống trên thực tế, thay vì lo lắng.


Thực hành thiền Vipassana thường xuyên có thể mang lại nhiều lợi ích cho sức khỏe:
### Giảm căng thẳng, buông bỏ lo âu
Tương tự như các kỹ thuật thiền khác, thiền Vipassana có thể giúp bạn dịu đi những căng thẳng và lo lắng trong tâm lý.
Trong một [nghiên cứu của Roberta A Szekeres và Eleanor H Wertheim](https://pubmed.ncbi.nlm.nih.gov/24515781/) với những người tham gia khóa thiền Vipassana trong vòng 6 tháng cho thấy: những người học thiền Vipassana có mức độ căng thẳng thấp hơn so với những người không tham gia khóa học.
Trong một [nghiên cứu của Chuan-Chih Yang và cộng sự năm 2019](https://www.nature.com/articles/s41598-019-47470-4?utm_medium=affiliate&utm_source=commission_junction&utm_campaign=CONR_PF018_ECOM_GL_PHSS_ALWYS_DEEPLINK&utm_content=textlink&utm_term=PID100090071&CJEVENT=2403aec6a54811ed830800b60a18b8fc), 14 người tham gia đã hoàn thành khóa học thiền kéo dài 40 ngày, trong đó có thiền Vipassana. Kết quả nghiên cứu cho thấy, mức độ lo lắng và trầm cảm của họ đã thấp hơn sau khi kết thúc khóa thiền.
### Hỗ trợ giảm các triệu chứng bệnh mãn kinh
Thiền Vipassana cũng có thể giúp bạn giảm các triệu chứng của thời kỳ mãn kinh, cụ thể như sau:
Theo [nghiên cứu của Min-Kyu Sung và cộng sự](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7478772/#:~:text=A%20systemic%20review%20has%20reported,sleep%2C%20and%20muscular%20skeletal%20pain.) cho thấy: Việc thực hành các liệu pháp tâm trí và thể chất, chẳng hạn như: thiền, yoga và thái cực quyền,... có thể làm giảm các triệu chứng mãn kinh như: đau đầu vận mạch (tình trạng đau nửa đầu có mạch đập), các vấn đề liên quan đến tâm trạng, giấc ngủ và đau cơ xương.
### Thúc đẩy sự linh hoạt của não bộ
Thực hành thiền định, bao gồm cả thiền Vipassana, có thể giúp tăng tính linh hoạt của não bộ.
Tính linh hoạt của não được hiểu đơn giản là khả năng tái cấu trúc bên trong não bộ để xử lý vấn đề khi nhận thấy có sự thay đổi từ môi trường bên ngoài.
Một [nghiên cứu của Anna Lardone và cộng sự năm 2018](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6312586/) cho thấy rằng thực hành thiền Vipassana thường xuyên có thể giúp thúc đẩy tính linh hoạt của não. Để đi đến kết luận này, các nhà khoa học đã sử dụng phương pháp quét hình ảnh thần kinh để kiểm tra mạng lưới não bộ của những người hành thiền Vipassana.
  * [Giảm căng thẳng, buông bỏ lo âu](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/thien-vipassana-la-gi-co-tac-dung-gi-voi-suc-khoe#gim-cng-thng-bung-b-lo-u)
  * [Hỗ trợ giảm các triệu chứng bệnh mãn kinh](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/thien-vipassana-la-gi-co-tac-dung-gi-voi-suc-khoe#h-tr-gim-cc-triu-chng-bnh-mn-kinh)
  * [Thúc đẩy sự linh hoạt của não bộ](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/thien-vipassana-la-gi-co-tac-dung-gi-voi-suc-khoe#thc-y-s-linh-hot-ca-no-b)



## 28 ngày để thực hành lòng biết ơn (2)

  * [07 ngày đầu tiên](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/28-ngay-de-thuc-hanh-long-biet-on-2#07-ngy-u-tin)
  * [NGÀY 08: GIA VỊ NHIỆM MẦU](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/28-ngay-de-thuc-hanh-long-biet-on-2#ngy-08-gia-v-nhim-mu)
  * [NGÀY 09: NAM CHÂM TIỀN BẠC](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/28-ngay-de-thuc-hanh-long-biet-on-2#ngy-09-nam-chm-tin-bc)
  * [NGÀY 10: BỤI PHÉP THUẬT DÀNH CHO MỌI NGƯỜI](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/28-ngay-de-thuc-hanh-long-biet-on-2#ngy-10-bi-php-thut-dnh-cho-mi-ngi)
  * [NGÀY 11: BUỔI SÁNG NHIỆM MẦU](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/28-ngay-de-thuc-hanh-long-biet-on-2#ngy-11-bui-sng-nhim-mu)
  * [NGÀY 12: NHỮNG CON NGƯỜI NHIỆM MÀU ĐÃ THAY ĐỔI CUỘC ĐỜI TÔI](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/28-ngay-de-thuc-hanh-long-biet-on-2#ngy-12-nhng-con-ngi-nhim-mu-thay-i-cuc-i-ti)
  * [NGÀY 13: HIỆN THỰC HÓA MỌI MƠ ƯỚC](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/28-ngay-de-thuc-hanh-long-biet-on-2#ngy-13-hin-thc-ha-mi-m-c)
  * [NGÀY 14: MỘT NGÀY NHIỆM MẦU](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/28-ngay-de-thuc-hanh-long-biet-on-2#ngy-14-mt-ngy-nhim-mu)


## [_**07 ngày đầu tiên**_](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/28-ngay-de-thuc-hanh-long-biet-on)
## **NGÀY 08: GIA VỊ NHIỆM MẦU**
Trong ngày thứ 8 này bạn sẽ thực hành 3 bài tập sau:
Bài tập 1. Lập danh sách 10 điều bạn cảm thấy biết ơn
Bài tập 2. Gia vị nhiệm mầu
Trước khi ăn hay uống bất kỳ món gì, hãy dành thời gian nhìn vào món ấy và nói từ nhiệm màu cảm ơn. Hãy nếm chúng và thật sự tập trung (nhai kỹ, nuốt chậm), tăng cường cảm quan mùi vị, tận hưởng món ăn thức uống với lòng biết ơn sâu sắc.
_**P/s:** bài tập này trong đạo phật gọi là ăn trong chánh niệm._
Bài tập 3. Thực hành hòn đá nhiệm mầu
## **NGÀY 09: NAM CHÂM TIỀN BẠC**
Trong ngày thứ 9 này bạn sẽ thực hành 4 bài tập sau:
Bài tập 1. Lập danh sách 10 điều bạn cảm thấy biết ơn
Bài tập 2. Biết ơn những hóa đơn chưa thanh toán
Lấy ra các hoá đơn chưa thanh toán và viết lên đó dòng chữ CẢM ƠN VÌ SỐ TIỀN. Cảm nhận lòng biết ơn vì mình có tiền để thanh toán những hóa đơn ấy, bất kể bạn đang có tiền thật hay không.
Bài tập 3. Biết ơn những hóa đơn đã thanh toán
Tìm 10 hoá đơn đã thanh toán và viết lên đó dòng chữ CẢM ƠN ĐÃ THANH TOÁN. Cảm nhận lòng biết ơn vì mình đã có tiền để thanh toán những hóa đơn ấy.
Bài tập 4. Thực hành hòn đá nhiệm mầu
_**P/s:** Nếu không có hoá đơn, bạn có thể thay thế bài tập 2 và 3 bằng cách sau:_
_Bước 1:_ Liệt kê các khoản chi của bạn (tiền điện, tiền nước, tiền xăng, tiền nhà trọ,…)
_Bước 2:_ Viết ra giấy câu biết ơn:
  * Tôi biết ơn vì đã có đủ tiền để thanh toán tiền điện
  * Tôi biết ơn vì đã có đủ tiền để thanh toán tiền nhà
  * Tôi biết ơn vì đã có đủ tiền để thanh toán tiền lãi ngân hàng


_Bước 3:_ Đặt tay lên trái tim, đọc lại những điều đã viết, nói lời cảm ơn, và cảm nhận năng lượng của lòng biết ơn.
## **NGÀY 10: BỤI PHÉP THUẬT DÀNH CHO MỌI NGƯỜI**
Trong ngày thứ 10 này bạn sẽ thực hành 3 bài tập sau:
Bài tập 1. Lập danh sách 10 điều bạn cảm thấy biết ơn
Bài tập 2. Rắc bụi phép thuật
Bụi phép thuật là hình ảnh đại diện cho lời cảm ơn. Hãy rắc bụi phép thuật bằng cách nói trực tiếp, nhắn tin hoặc thầm cảm ơn với 10 người đã đem lại lợi ích cho bạn hoặc đã phục vụ bạn. Cảm nhận lòng biết ơn vì những điều mà họ đang mang lại cho bạn.
Bài tập 3. Thực hành hòn đá nhiệm mầu
## **NGÀY 11: BUỔI SÁNG NHIỆM MẦU**
Trong ngày thứ 11 này bạn sẽ thực hành 2 bài tập sau:
Bài tập 1. Lập danh sách 10 điều bạn cảm thấy biết ơn
Ở bài tập này sẽ hơi khác với bài tập 1 của những ngày trước. Hôm nay bạn sẽ tập trung viết những điều cảm cảm thấy biết ơn có liên quan đến buổi sáng. Ví dụ như thức ăn sáng, ánh nắng mai, không khí trong lành, bình minh, người luôn bên cạnh bạn vào mỗi buổi sáng, …
Bài tập 2. Thực hành hòn đá nhiệm mầu
## **NGÀY 12: NHỮNG CON NGƯỜI NHIỆM MÀU ĐÃ THAY ĐỔI CUỘC ĐỜI TÔI**
Trong ngày thứ 12 này bạn sẽ thực hành 3 bài tập sau:
Bài tập 1. Lập danh sách 10 điều bạn cảm thấy biết ơn
Bài tập 2. Những con người nhiệm mầu
Tìm ra 3 người nhiệm màu đã thay đổi cuộc sống của bạn. Tìm một không gian tĩnh lặng, nhắm mắt lại và nghĩ về họ. Tưởng tượng họ đang xuất hiện trước mặt bạn. Nói với họ lời cảm ơn kèm theo lí do sao bạn biết ơn họ. Hãy nói từ nhiệm màu CẢM ƠN bằng tất cả những rung động từ sâu bên trong trái tim bạn.
Bài tập 3. Thực hành hòn đá nhiệm mầu
## **NGÀY 13: HIỆN THỰC HÓA MỌI MƠ ƯỚC**
Trong ngày thứ 13 này bạn sẽ thực hành 4 bài tập sau:
Bài tập 1. Lập danh sách 10 điều bạn cảm thấy biết ơn
Bài tập 2. Danh sách ước mơ
Viết ra danh sách 10 điều mong muốn.
Dùng trí tưởng tượng của bạn để trả lời 3 câu hỏi sau: 
  * Cảm xúc của bạn khi nhận được điều mình mong muốn là gì?
  * Ai là người bạn sẽ báo tin đầu tiên và bạn sẽ nói gì với họ?
  * Điều tuyệt vời gì bạn sẽ làm sau khi có được thứ bạn mong muốn?


Đặt tay lên trái tim bạn. Đọc lại danh sách 10 điều mong muốn. Nói từ nhiệm màu **Cảm ơn, Cảm ơn, Cảm ơn**. Cảm nhận như thể bạn đã đạt được chúng.
Bài tập 3. Tấm bảng nhiệm mầu (vision board)
Tạo một tấm bảng nhiệm màu bằng cách chuẩn bị một tấm bảng với hình ảnh, câu chữ được sưu tầm, cắt ghép thể hiện những mong muốn của bạn. Đặt ở nơi thường xuyên nhìn thấy. Đặt tiêu đề cho tấm bảng là **CẢM ƠN, CẢM ƠN, CẢM ƠN** với cỡ chữ lớn ở đầu bảng.
Bài tập 4. Thực hành hòn đá nhiệm mầu
## **NGÀY 14: MỘT NGÀY NHIỆM MẦU**
Trong ngày thứ 14 này bạn sẽ thực hành 3 bài tập sau:
Bài tập 1. Lập danh sách 10 điều bạn cảm thấy biết ơn
Bài tập 2. Biết ơn những kế hoạch
Tìm một không gian tĩnh lặng, nhắm mắt lại và tưởng tượng tất cả những công việc mà bạn sẽ làm trong ngày hôm nay. Hãy tưởng tượng hình ảnh bạn đã hoàn thành từng công việc một cách hoàn hảo và xuất sắc như thế nào. Sau khi tưởng tượng, hãy đặt tay lên trái tim bạn, nói từ nhiệm màu cảm ơn cảm ơn cảm ơn. Cảm nhận những rung động từ sâu bên trong bạn.
Bài tập 3. Thực hành hòn đá nhiệm mầu
[_**07 ngày tiếp theo**_](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/28-ngay-de-thuc-hanh-long-biet-on-3)
  * [07 ngày đầu tiên](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/28-ngay-de-thuc-hanh-long-biet-on-2#07-ngy-u-tin)
  * [NGÀY 08: GIA VỊ NHIỆM MẦU](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/28-ngay-de-thuc-hanh-long-biet-on-2#ngy-08-gia-v-nhim-mu)
  * [NGÀY 09: NAM CHÂM TIỀN BẠC](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/28-ngay-de-thuc-hanh-long-biet-on-2#ngy-09-nam-chm-tin-bc)
  * [NGÀY 10: BỤI PHÉP THUẬT DÀNH CHO MỌI NGƯỜI](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/28-ngay-de-thuc-hanh-long-biet-on-2#ngy-10-bi-php-thut-dnh-cho-mi-ngi)
  * [NGÀY 11: BUỔI SÁNG NHIỆM MẦU](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/28-ngay-de-thuc-hanh-long-biet-on-2#ngy-11-bui-sng-nhim-mu)
  * [NGÀY 12: NHỮNG CON NGƯỜI NHIỆM MÀU ĐÃ THAY ĐỔI CUỘC ĐỜI TÔI](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/28-ngay-de-thuc-hanh-long-biet-on-2#ngy-12-nhng-con-ngi-nhim-mu-thay-i-cuc-i-ti)
  * [NGÀY 13: HIỆN THỰC HÓA MỌI MƠ ƯỚC](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/28-ngay-de-thuc-hanh-long-biet-on-2#ngy-13-hin-thc-ha-mi-m-c)
  * [NGÀY 14: MỘT NGÀY NHIỆM MẦU](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/28-ngay-de-thuc-hanh-long-biet-on-2#ngy-14-mt-ngy-nhim-mu)



## 28 ngày để thực hành lòng biết ơn (3)

  * [07 ngày trước đó](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/28-ngay-de-thuc-hanh-long-biet-on-3#07-ngytrc-)
  * [NGÀY 15: PHÉP MẦU CẢI THIỆN MỐI QUAN HỆ](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/28-ngay-de-thuc-hanh-long-biet-on-3#ngy-15-php-mu-ci-thin-mi-quan-h)
  * [NGÀY 16: ĐIỀU KỲ DIỆU CỦA SỨC KHỎE](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/28-ngay-de-thuc-hanh-long-biet-on-3#ngy-16-iu-k-diu-ca-sc-khe)
  * [NGÀY 17: TẤM SÉC NHIỆM MẦU](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/28-ngay-de-thuc-hanh-long-biet-on-3#ngy-17-tm-sc-nhim-mu)
  * [NGÀY 18: DANH SÁCH NHIỆM MẦU](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/28-ngay-de-thuc-hanh-long-biet-on-3#ngy-18-danh-sch-nhim-mu)
  * [NGÀY 19: BƯỚC CHÂN NHIỆM MẦU](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/28-ngay-de-thuc-hanh-long-biet-on-3#ngy-19-bc-chn-nhim-mu)
  * [NGÀY 20: PHÉP MẦU CỦA TRÁI TIM](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/28-ngay-de-thuc-hanh-long-biet-on-3#ngy-20-php-muca-tri-tim)
  * [NGÀY 21: KẾT QUẢ TUYỆT DIỆU](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/28-ngay-de-thuc-hanh-long-biet-on-3#ngy-21-kt-qu-tuyt-diu)


## __
## **NGÀY 15: PHÉP MẦU CẢI THIỆN MỐI QUAN HỆ**
Trong ngày thứ 15 này bạn sẽ thực hành 3 bài tập sau:
Bài tập 1. Lập danh sách 10 điều bạn cảm thấy biết ơn
Bài tập 2. Phép màu cải thiện mối quan hệ
Chọn một mối quan hệ khó khăn hay đổ vỡ mà bạn muốn cải thiện.
Ngồi xuống và liệt kê danh sách 10 điều mà bạn cảm thấy biết ơn về người ấy.
Hãy viết theo cấu trúc: [Tên người ấy] + Tôi chân thành biết ơn vì + [Điều bạn cảm thấy biết ơn] 
Đặt tay lên trái tim bạn. Đọc lại 10 điều trên. Nói từ nhiệm màu Cảm ơn Cảm ơn Cảm ơn. Cảm nhận những rung động biết ơn bên trong bạn.
Bài tập 3. Thực hành hòn đá nhiệm mầu
## **NGÀY 16: ĐIỀU KỲ DIỆU CỦA SỨC KHỎE**
Trong ngày thứ 16 này bạn sẽ thực hành 5 bài tập sau:
Bài tập 1. Lập danh sách 10 điều bạn cảm thấy biết ơn
Bài tập 2. Biết ơn sức khỏe trong quá khứ
Hãy nhớ lại 3 thời điểm bạn cảm thấy tuyệt vời và nói từ nhiệm màu CẢM ƠN. Cảm nhận lòng biết ơn đối với 3 thời điểm đó.
Bài tập 3. Biết ơn sức khỏe trong hiện tại
Hãy chọn ra 5 bộ phận trong cơ thể đang hoạt động tốt. Lần lượt nói từ nhiệm màu CẢM ƠN cho từng bộ phận ấy. Đặt tay lên từng bộ phận bạn biết ơn và cảm nhận những rung động biết ơn bên trong bạn.
Bài tập 4. Biết ơn sức khỏe trong tương lai
Chọn một điều về cơ thể (hoặc về sức khoẻ) mà bạn muốn cải thiện trong tương lai. Dành một phút để hình dung ra bản thân đang có được trạng thái sức khỏe lý tưởng ấy. Nói từ nhiệm màu CẢM ƠN. Cảm nhận lòng biết ơn sâu sắc đối với những cải thiện tốt đẹp ngoài sức tưởng tượng ấy.
Bài tập 5. Thực hành hòn đá nhiệm mầu
## **NGÀY 17: TẤM SÉC NHIỆM MẦU**
Trong ngày thứ 17 này bạn sẽ thực hành 5 bài tập sau:
Bài tập 1. Lập danh sách 10 điều bạn cảm thấy biết ơn
Bài tập 2. Tấm séc nhiệm mầu (1)
Ở bài tập này bạn có thể dùng một tờ giấy trắng và trang trí theo mẫu bên dưới.
Cầm tấm séc nhiệm màu trong tay và tưởng tượng việc bạn dùng số tiền đó để làm điều bạn muốn. Hãy cảm nhận niềm vui và lòng biết ơn như thể bạn đã thật sự có thứ bạn muốn.
Bài tập 3. Tấm séc nhiệm mầu (2)
Đem theo tấm xét nghiệm màu trong ngày. Để nó ở nơi dễ dàng nhìn thấy. Ít nhất 2 lần trong ngày cầm tấm séc nhiệm màu trong tay và tưởng tượng việc bạn dùng số tiền đó để làm điều bạn muốn. Hãy cảm nhận niềm vui và lòng biết ơn như thể bạn đã thật sự có thứ bạn muốn.
Bài tập 4. Tấm séc nhiệm mầu (3)
Cuối ngày hôm nay hãy để tấm séc ở nơi dễ dàng nhìn thấy hàng ngày. Khi nhận được số tiền đã viết hãy viết một tấm séc khác và lập lại các bước trên để tiếp tục thực hiện phương pháp tấm séc nhiệm màu.
Bài tập 5. Thực hành hòn đá nhiệm mầu
## **NGÀY 18: DANH SÁCH NHIỆM MẦU**
Trong ngày thứ 18 này bạn sẽ thực hành 3 bài tập sau:
Bài tập 1. Lập danh sách 10 điều bạn cảm thấy biết ơn
Bài tập 2. Danh sách nhiệm mầu
Hãy viết 3 việc quan trọng nhất bạn muốn thực hiện hay phải giải quyết trong ngày hôm nay. Lần lượt tưởng tượng từng việc đã được thực hiện và giải quyết xong như thế nào. Đặt tay lên trái tim bạn. Nói từ nhiệm màu Cảm ơn, Cảm ơn, Cảm ơn. Cảm nhận lòng biết ơn bên trong bạn.
Bài tập 3. Thực hành hòn đá nhiệm mầu
## **NGÀY 19: BƯỚC CHÂN NHIỆM MẦU**
Trong ngày thứ 19 này bạn sẽ thực hành 3 bài tập sau:
Bài tập 1. Lập danh sách 10 điều bạn cảm thấy biết ơn
Bài tập 2. Bước chân nhiệm mầu
Thực hành bước 100 bước chân vào bất cứ lúc nào trong ngày. Với mỗi bước chân hãy nói từ nhiệm màu CẢM ƠN. Cảm nhận từng bước chân và sự rung động bên trong bạn.
Bài tập 3. Thực hành hòn đá nhiệm mầu
## **NGÀY 20: PHÉP MẦU CỦA TRÁI TIM**
Trong ngày thứ 20 này bạn sẽ thực hành 3 bài tập sau:
Bài tập 1. Lập danh sách 10 điều bạn cảm thấy biết ơn
Bài tập 2. Phép màu của trái tim
Tập trung sự chú ý của bạn vào khu vực gần trái tim. Nhắm mắt lại, tiếp tục tập trung đầu óc vào trái tim. Nói từ nhiệm màu Cảm ơn, Cảm ơn, Cảm ơn.
Lấy danh sách 10 điều mong muốn ra để thực hiện Phép Màu Của Trái Tim bằng cách đọc lại 10 điều mong muốn. 
Nhắm mắt lại tập trung tâm trí của bạn vào khu vực gần trái tim. Nói từ nhiệm màu Cảm ơn, Cảm ơn, Cảm ơn thật chậm.
Bài tập 3. Thực hành hòn đá nhiệm mầu
## **NGÀY 21: KẾT QUẢ TUYỆT DIỆU**
Trong ngày thứ 21 này bạn sẽ thực hành 3 bài tập sau:
Bài tập 1. Lập danh sách 10 điều bạn cảm thấy biết ơn
Bài tập 2. Kết quả tuyệt diệu
Vào đầu ngày, chọn viết ra danh sách 3 sự việc mà bạn muốn đạt được kết quả tốt. Trong lúc viết hãy cảm nhận như thể kết quả tuyệt vời đó đã xảy ra. Sau khi viết xong hãy viết tiếp câu: “ _**Cảm ơn vì kết quả tuyệt diệu**_ ”.
Trong ngày, khi có một sự việc bất ngờ phát sinh với kết quả tốt. Hãy nói câu nhiệm màu: “ _**Cảm ơn vì kết quả tuyệt diệu**_ ”.
Bài tập 3. Thực hành hòn đá nhiệm màu
[_**07 ngày tiếp theo**_](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/28-ngay-de-thuc-hanh-long-biet-on-4)
  * [07 ngày trước đó](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/28-ngay-de-thuc-hanh-long-biet-on-3#07-ngytrc-)
  * [NGÀY 15: PHÉP MẦU CẢI THIỆN MỐI QUAN HỆ](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/28-ngay-de-thuc-hanh-long-biet-on-3#ngy-15-php-mu-ci-thin-mi-quan-h)
  * [NGÀY 16: ĐIỀU KỲ DIỆU CỦA SỨC KHỎE](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/28-ngay-de-thuc-hanh-long-biet-on-3#ngy-16-iu-k-diu-ca-sc-khe)
  * [NGÀY 17: TẤM SÉC NHIỆM MẦU](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/28-ngay-de-thuc-hanh-long-biet-on-3#ngy-17-tm-sc-nhim-mu)
  * [NGÀY 18: DANH SÁCH NHIỆM MẦU](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/28-ngay-de-thuc-hanh-long-biet-on-3#ngy-18-danh-sch-nhim-mu)
  * [NGÀY 19: BƯỚC CHÂN NHIỆM MẦU](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/28-ngay-de-thuc-hanh-long-biet-on-3#ngy-19-bc-chn-nhim-mu)
  * [NGÀY 20: PHÉP MẦU CỦA TRÁI TIM](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/28-ngay-de-thuc-hanh-long-biet-on-3#ngy-20-php-muca-tri-tim)
  * [NGÀY 21: KẾT QUẢ TUYỆT DIỆU](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/28-ngay-de-thuc-hanh-long-biet-on-3#ngy-21-kt-qu-tuyt-diu)



## TẠI SAO MỤC ĐÍCH VÀ KỶ LUẬT LẠI THÚC ĐẨY SỨC KHOẺ TÂM LÝ?

_“Vô số khả năng là điều không phù hợp với con người; nếu chúng tồn tại, cuộc sống của bạn sẽ chỉ tản mác trong vô chừng. Để trở nên mạnh mẽ, một người cần giới hạn đời mình với bổn phận và lòng tự nguyện. Một người chỉ đạt được cuộc sống ý nghĩa cùng với tinh thần tự do bằng cách bao quanh mình bằng những giới hạn và bổn phận do chính mình lựa chọn." -**Kinh Dịch, quẻ 60.**_
**Sự tự do tâm lý** là khi mà chúng ta nhận thức rõ những điểm yếu và thói quen xấu của mình, và thay vì chìm đắm trong sự thương hại bản thân, chúng ta thực hành quyền tự chủ để theo đuổi một cuộc sống tốt đẹp hơn. Hình thức tự do này ngày nay đã quá vắng bóng. Nghiện ngập, không cưỡng lại được những thỏa mãn nhất thời, rối loạn thần kinh và các hành vi tự hủy hoại bản thân khác khiến nhiều người trong chúng ta bị giam hãm trong nhà tù của tâm trí và cản trở khả năng phát triển của ta.
Thường những vấn đề này được cho là do có sai sót trong gen hoặc cấu tạo sinh học của ta. Do đó, giải pháp hẳn là cần thay đổi những hoạt chất hóa học trong não của ta bằng cách kê toa thuốc. Nhưng không phải ai cũng đều đồng tình rằng kê thuốc là cách tốt nhất để thoát khỏi lối sống sai lệch của chúng ta.
**Steven Pressfield,** tác giả sách Turning Pro (Trở thành Chuyên nghiệp), đã đưa ra một giải pháp khác. Ông lập luận rằng nhiều người trong chúng ta sẽ chỉ chữa lành bản thân được nếu ta có thể giành lại quyền kiểm soát cuộc sống của mình, bằng cách định hướng cho phép ta có được trải nghiệm sống gắn liền với sự phát triển bản thân. Và cách tốt nhất để làm điều này, ông lập luận, là cam kết theo đuổi sự xuất sắc trong một lĩnh vực mà ta chọn, một quá trình mà ông gọi là 'trở thành chuyên nghiệp'.
Quyết định của người nghiệp dư chấp nhận một cuộc đời tầm thường, hay quyết định của một người chuyên nghiệp kỷ luật bản thân để trở nên xuất sắc, đều là những lựa chọn cho thấy cuộc sống là khó khăn.
Tuy nhiên, trong khi người nghiệp dư tìm cách giải tỏa nỗi đau của cuộc sống bằng sự đê mê của những cơn nghiện và theo đuổi thú vui, thì người chuyên nghiệp cố gắng vượt lên trên nỗi đau của mình bằng “lao động và tình yêu”. Một số người may mắn vì sớm tìm thấy tiếng gọi cuộc đời và cam kết trở thành chuyên nghiệp mà không cần đắn đo gì nhiều. Tuy vậy, với đa số người khác, thì lựa chọn trở thành chuyên nghiệp sẽ đi kèm với nhiều năm lãng phí trong tuyệt vọng, trước khi sự thức tỉnh ập tới, và họ nhận ra rằng cần phải thay đổi cuộc sống một cách có mục đích hơn.
Nếu ta quyết định trở thành chuyên nghiệp, thì ta cần biết rằng đó không phải là một nỗ lực nửa vời. Nó đòi hỏi sự rèn luyện mỗi ngày, điều mà các nhà tâm lý học gọi là “thực hành có chủ đích” (deliberate practice), mà nhờ đó, ta trau dồi kỹ năng của mình thông qua sự kiên trì và tập trung. Thiên tư, hay tiếng gọi của cuộc đời, phải trở thành ưu tiên hàng đầu của ta. Thời giờ của ta thay vì trước đây dành cho những thú vui sao lãng, thì nay ta phải dành chúng để trau dồi những thói quen và kỹ năng cần thiết để hoàn thành xuất sắc công việc của ta. Trở thành chuyên nghiệp, trong bất kỳ lĩnh vực nào chúng ta chọn, đồng nghĩa với việc đặt bản thân vào những xiềng xích kỷ luật mà ta tự áp vào chính mình, và nghịch lý thay, đây lại là con đường dẫn đến sự tự do về tâm lý.
“… Tự do về bản chất là sự chấp nhận những xiềng xích phù hợp với bạn, buộc bạn hướng tới một mục đích do chính bạn lựa chọn và đánh giá chứ không phải áp đặt từ bên ngoài. Nó không phải, và không bao giờ có thể thiếu vắng những hạn chế, nghĩa vụ hay luật pháp và bổn phận." - **Bronislaw Malinowski,** Tự do và Văn minh.
Trong khi hầu hết mọi người có thể xây dựng cuộc sống của họ xung quanh mục tiêu theo đuổi sự xuất sắc, thì nhiều người lại chạy trốn khỏi lối sống này bằng cách viện đến hai lý do chính. Lời bào chữa đầu tiên dựa trên niềm tin rằng chúng ta là những sinh vật tầm thường trong một vũ trụ vốn hoàn toàn ngó lơ mong ước của ta, và vì vậy mục đích của cuộc sống là tận hưởng chuyến đi, chứ không phải tự mang vác gánh nặng cho mình bằng nhiệm vụ phải đạt được bất cứ điều gì có giá trị lâu dài. Nhưng lối suy nghĩ này bỏ qua thực tế rằng bẩm sinh trong mỗi người chúng ta đều sở hữu một mong muốn vượt lên chính mình, và nếu chúng ta từ chối chú ý đến tiếng gọi này, thì chúng ta sẽ trở nên tự hủy hoại bản thân và dễ mắc các bệnh về tâm lý. 
Hay như nhà tâm lý học **James Hillman** đã viết:
“Hiện diện trong thể xác và vắng bóng trong tinh thần, anh ấy nằm ườn trên chiếc ghế dài, xấu hổ bởi chính… những tiềm năng trong anh mà anh đã không khuất phục được. Anh cảm thấy sự sụp đổ trong nội tâm, tưởng tượng trong sự thụ động của anh về những điều hung hăng và những ham muốn phải bị dập tắt. Giải pháp: nhiều việc hơn, nhiều tiền hơn, uống nhiều hơn, nhiều cân hơn, nhiều thứ hơn, nhiều thông tin giải trí hơn.” - James Hillman, Mật mã của linh hồn.
Mặt khác, một số người trong chúng ta nhận ra tầm quan trọng của việc trở nên chuyên nghiệp, nhưng chúng ta liên tục trì hoãn hành động. Chúng ta tự nhủ rằng ta sẽ trở nên chuyên nghiệp khi ta đã "tìm thấy chính mình", hoặc khi ta đã vượt qua được chứng trầm cảm, lo âu hoặc nghiện ngập. Tuy nhiên, nếu lý thuyết của Pressfield là đúng, thì chiến thuật trốn tránh này lại được xây dựng dựa trên một lỗi tư duy. Vì trở thành chuyên nghiệp không phải là điều chúng ta sẽ làm sau khi đã chữa khỏi các vấn đề của mình hoặc phát hiện ra mình là ai, mà đúng hơn, trở thành chuyên nghiệp chính là cách chữa trị - đó là phương tiện để chúng ta trở thành chính mình.
Nếu chúng ta quyết định trở thành chuyên nghiệp, thì điều quan trọng là chúng ta phải làm điều đó với những lý do chính đáng. Bởi vì trong khi trở thành chuyên nghiệp sẽ làm tăng cơ hội của chúng ta để đạt được sự giàu có, địa vị và thậm chí có thể nổi tiếng, thì nếu ta chỉ nhằm đến những thứ này, ta có thể phá hoại nỗ lực của bản thân. Năng lượng của ta, nếu quá chú trọng vào thành công bề ngoài, thì sẽ khiến công việc của ta bị ảnh hưởng tiêu cực. Và nếu những phần thưởng này không đến đủ nhanh, vì chúng hiếm khi xảy ra, thì không chắc chúng ta sẽ muốn tiếp tục thực hiện những hy sinh cần thiết để đạt được sự xuất sắc trong lĩnh vực của mình.
Nói cách khác, chúng ta sẽ không trở thành chuyên nghiệp được trừ khi ta có thể đặt ham muốn tiền bạc và địa vị đằng sau mong muốn nuôi dưỡng kỹ năng và tiềm năng của ta. Và nếu chúng ta có thể tìm thấy động lực bên trong để cam kết với lối sống không phổ biến này, ta rồi sẽ khám phá ra rằng theo thời gian, phần thưởng tâm lý mà ta có được sẽ vượt xa mọi hình thức thành công vật chất. Vì khi ta cố gắng hướng tới đỉnh cao của bản thân, thì các vấn đề tâm lý của ta cũng sẽ không còn tác động đến ta như chúng đã từng. Chúng sẽ bị vô hiệu hóa bởi cảm giác bình yên bên trong và những thành tựu mà ta đạt được, điều vốn thiếu thốn trong đời sống của hầu hết mọi người. Hay như Lão Tử đã khuyên:
_“Theo đuổi tiền bạc và sự đảm bảo, và trái tim bạn sẽ không bao giờ bình yên. Để tâm đến sự chấp thuận của kẻ khác, Và bạn sẽ là tù nhân của họ. Làm việc của bạn, rồi lui bước. Đây, con đường duy nhất của sự thanh thản.” -**Lão Tử, Đạo Đức Kinh.**_

## Các loại thiền thường được sử dụng và các cấp độ thiền

  * [Thiền siêu việt](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/cac-loai-thien-thuong-duoc-su-dung-va-cac-cap-do-thien#thin-siu-vit)
  * [Thiền chuyển động](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/cac-loai-thien-thuong-duoc-su-dung-va-cac-cap-do-thien#thin-chuyn-ng)


# Thiền Vipassana
Vipassana là một trong những hình thức thiền cổ xưa nhất trên thế giới, bắt nguồn từ chính Phật pháp giúp người hành thiền giảm căng thẳng và nhận thức sự việc tỏ tường hơn…
## Thiền tâm từ
Loại thiền này liên quan đến việc cố gắng tập trung sự chú ý của bạn vào cảm giác yêu thương và lòng trắc ẩn đối với bản thân và những người khác. ([1](https://ggia.berkeley.edu/practice/compassion_meditation))
Vipassana mang tính trung lập hơn, phương pháp thiền này liên quan đến việc quan sát những suy nghĩ và cảm xúc một cách không định kiến hay phán xét.
## Thiền định
Thiền định là một hình thức khi thực hiện sẽ tập trung sự chú ý vào một đối tượng duy nhất, không phân tâm để tâm trí an tĩnh để quan sát và suy ngẫm chân lý một cách tỏ tường. ([2](https://phatgiao.org.vn/thien-dinh-la-gi-d45081.html))
Trong thiền Vipassana, bạn chỉ được phép quan sát, không được có những suy nghĩ, phán xét hoặc có bất cứ hành động nào khác.
## Thiền siêu việt
Thiền siêu việt liên quan đến việc sử dụng một câu thần chú hoặc âm thanh để giúp bạn đạt được trạng thái thư giãn sâu và tinh thần minh mẫn. ([3](https://my.clevelandclinic.org/health/treatments/22292-transcendental-meditation))
Vipassana là hình thức thiền tĩnh lặng, sử dụng tâm trí để quan sát khi hành thiền.
## Thiền chuyển động
Thiền chuyển động - hay còn gọi là thiền Hành, liên quan đến việc tập trung vào các cảm giác thể chất trong khi đang chuyển động nhẹ nhàng, chẳng hạn như: đi bộ, yoga,... để mang tới sự cảm nhận nhiều hơn về những thay đổi, cảm giác nhỏ trong khi tập luyện - những thứ mà chúng ta bình thường không để ý đến. ([4](https://www.webmd.com/balance/the-basics-of-walking-meditation))
Ðứng về phương diện các trình độ của Thiền, kinh sách có dạy như sau:
_1. Thế gian thiền._ Thiền này có hai loại: Căn bản vị thiền và Căn bản tịnh thiền. Căn bản vị thiền gồm có mười hai phẩm, phân làm ba: Tứ thiền, Tứ vô lượng và Tứ không.
Người phàm chán cảnh tán loạn của Dục giới thì tu Tứ thiền. Người muốn phước lớn thì tu Tứ vô lượng. Kẻ nhàm chán cảnh sắc giới chật hẹp thì tu Tứ không. Vì mười hai phẩm Thiền này có thể làm căn bản cho thiện pháp xuất thế gian, nên gọi là Căn bản thiền. Với lại, an trú trong mười hai phẩm ấy, người tu Thiền còn ưa thích cảm giác lạc thọ của Thiền, nên gọi là Căn bản vị thiền.
Căn bản vị thiền, phân làm hai: Lục diệu môn và Thập lục đặc thắng. Ai có huệ tánh nhiều thì tu Lục diệu môn, kẻ nào có định tánh nhiều thì tu Thập lục đặc thắng. Những ai có huệ tánh và định tánh đều nhau thì có thể tu cả hai loại. Vì người ta có thể căn cứ vào pháp Thiền này để phát sinh vô lậu trí, không phải chỉ thuần hữu lậu, như ở Căn bản vị thiền, nên gọi là Căn bản tịnh thiền.
Tuy nhiên, cả hai loại đều chỉ là thế gian thiền mà thôi, vì trước thời Phật giáng thế, phép Thiền này đã có.
_2. Xuất thế gian thiền._ Pháp Thiền này là của bậc xuất thế. Có bốn thứ Thiền quán: Cửu tướng quán, Bát bối xả quán, Bát thắng xứ quán và Thập nhất thiết xứ quán. Tu bốn Thiền quán này, tuy là lấy các pháp hữu vi làm đối tượng suy nghiệm, nhưng có thể đi đến kết quả ly dục, phát sinh vô lậu trí, nên gọi là Xuất thế gian thiền.
_3. Xuất thế gian thượng thượng thiền._ Ðây là pháp Thiền cao tột của các bậc đại nhân. Kinh Ðịa trì có giải về chín môn đại thiền này như sau:
– Một là “Tự tánh thiền”, nghĩa là quán sát thật tướng của tự tâm, không cần lấy đối tượng ngoại cảnh.
– Hai là “Nhất thiết thiền”, có công năng tự hành và hóa tha.
– Ba là “Nan thiền”, môn Thiền gian nan, thâm diệu, khó tu.
– Bốn là “Nhất thiết môn thiền”, có nghĩa là tất cả các pháp Thiền định đều do môn (cửa) này mà phát xuất.
– Năm là “Thiện nhân thiền”, môn Thiền của những chúng sinh có đại thiện căn cùng tu.
– Sáu là “Nhất thiết hạnh thiền”, bao nhiếp tất cả hạnh pháp của Ðại thừa.
– Bảy là “Trừ não thiền”, có năng lực trừ diệt phiền não, khổ đau cho chúng sinh.
– Tám là “Thử thế tha thế lạc thiền”, có năng lực làm cho chúng sinh an lạc trong hiện tại và tương lai.
– Chín là “Thanh tịnh tịnh thiền”, có năng lực đoạn trừ hoàn toàn các hoặc nghiệp, và chứng được Tịnh báo đại Bồ đề. Ðến môn Thiền này, tâm ý hoàn toàn thanh tịnh và lại cũng không còn thấy cái tướng thanh tịnh ấy nữa, nên gọi là Tịnh báo.
  * [Thiền siêu việt](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/cac-loai-thien-thuong-duoc-su-dung-va-cac-cap-do-thien#thin-siu-vit)
  * [Thiền chuyển động](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/cac-loai-thien-thuong-duoc-su-dung-va-cac-cap-do-thien#thin-chuyn-ng)



## 7 cách bố thí, công đức và phước đức khác gì nhau?

**_Đức Phật dạy: “Một người cho dù hoàn toàn không có gì, vẫn có thể cho người khác 7 thứ”._**
7 cách bố thí Đức Phật nói chính là:
1. Nhan thí – cho nét mặt: Dù không có gì nhưng ai cũng có nụ cười, thái độ niềm nở, đều có thể đem cho những người mà mình gặp hàng ngày. 2. Ngôn thí – cho lời nói: Lời nói chẳng mất tiền mua, lúc nào chúng ta cũng có thể lựa lời nói những điều ấm áp, động viên người khác, khiến họ cảm thấy được an ủi, vỗ về. 3. Tâm thí – cho tấm lòng: Tấm lòng cũng chẳng tốn đồng nào, chỉ cần có cái tâm rộng mở, đối xử với mọi người chân thành, trung thực, thế cũng là đã cho đi rất nhiều rồi. 4. Nhãn thí – cho ánh mắt: Dùng cái nhìn thiện ý, động viên có thể khiến một ngày của ai đó trở nên tốt đẹp hơn. Không phải bạn cũng từng ít nhất một lần cảm thấy phấn chấn hơn chỉ với một ánh mắt sao? 5. Thân thí – cho hành động: Những hành động nhân ái, giúp đỡ người khác đôi khi còn giá trị hơn cả tiền bạc. 6. Tọa thí – cho chỗ ngồi: Khi đi tàu, xe hay thuyền, hãy nhường chỗ ngồi của mình cho người cần. 7. Phòng thí – cho nơi ở: Phòng ở còn trống, không dùng đến có thể cho người khác vào nghỉ ngơi.
Về căn bản, phước đức là những hành động, lời nói, suy nghĩ thiện lành như bố thí, cúng dường, từ thiện, giúp đỡ, an ủi, động viên, khích lệ… cho cá nhân, đoàn thể để họ bớt khổ, thêm vui. Người thường gieo trồng phước đức sẽ được hưởng phước báo lành, góp phần chuyển hóa nhân quả xấu ác trong quá khứ, tránh được một số oan khiên. Để dễ nhớ hơn - phước đức là cách bạn làm người khác tích cực hơn (vui sướng, thảnh thơi, hạnh phúc...)
Công đức là công phu thanh lọc nội tâm, phát huy tuệ giác, khai tâm mở trí để thấu rõ sự thật, chứng ngộ chân lý. Công đức thuộc pháp vô vi, giúp dứt trừ phiền não, thành tựu giác ngộ và giải thoát sinh tử luân hồi. Công đức, xét một khía cạnh tóm gọn, nó là thành tựu khi bạn giúp được người khác chuyển hóa được tốt đẹp hơn (đốn ngộ, tự giải thoát khỏi phiền não...)
Thực ra, công đức và phước đức luôn gắn liền với nhau, bổ sung và hỗ trợ lẫn nhau. Theo Phật giáo, khi thân người mất đi, tứ đại giai không tan rã, thì chuyển tiếp luân hồi sẽ có công đức, phước đức và dĩ nhiên - còn bao gồm cả ác đức!

## Sản phẩm du lịch trên địa bàn Quận tại Tp.HCM năm 2023

_Theo ông Lê Trương Hiền Hòa, Phó Giám đốc Sở Du lịch Thành phố Hồ Chí Minh, việc trên địa bàn có 21 địa phương ra mắt sản phẩm đặc trưng đã khẳng định ý nghĩa của chương trình “Mỗi quận/huyện có ít nhất một sản phẩm du lịch đặc trưng."_
**Hành trình du lịch đến các di tích lịch sử văn hóa Quận 1 - “Quận 1- sống động Sài Gòn”**
**Lái xe Vespa khám phá quận 3**
**“Quận 4 - Cù lao giữa lòng phố thị”**
**Quận 5 “Ký ức Sài Gòn - Chợ Lớn”**
**Quận 8 - vùng đất của những câu chuyện**
**Quận 10 “Phố sức khỏe”, "Một ngày du lịch - Dấu ấn quận 10”**
**“Quận 11 - Có một Chợ Lớn rất khác”.**
**Quận Tân Phú “Tân Phú đi là nhớ”**
**Du lịch Bình Thạnh - Vùng đất thanh bình với các điểm đến văn hóa lịch sử **
**“Sắc màu Bình Tân”**
**“Gò vấp - Trăm năm tìm lại dấu xưa”**
**"Hóc Môn - Vùng đất lịch sử”**
**“Tân Bình - Biết bao điều thú vị”**

## LÊ KI MA: LOÀI HOA BIỂU TƯỢNG CỦA NỮ ANH HÙNG VÕ THỊ SÁU

Chị Sáu hy sinh vào năm 1952, nhưng phải đến ba năm sau, hoa lêkima mới bước vào câu chuyện về người nữ anh hùng. Năm 1955, nhà thơ và cựu chiến binh Phùng Quán đã viết tiểu thuyết Vượt Côn Đảo và trường ca Tiếng Hát Trên Địa Ngục Côn Đảo.
Bản trường ca đã sử thi hóa câu chuyện về những ngày cuối cùng của Võ Thị Sáu trên Côn Đảo với những chi tiết như: Chị hát vang lời ca cách mạng trong nhà ngục, nhớ lại tuổi thơ dữ dội của mình trong lực lượng kháng chiến, và cài nhành hoa lêkima lên tóc. Bài thơ được đông đảo độc giả đón nhận và giành được các giải thưởng văn học quốc gia. Vần thơ hùng hồn của Phùng Quán về người chiến sĩ từ chối bịt mắt khi bị hành quyết đã khắc sâu vào trái tim người đương thời, khiến họ nhớ mãi về người con gái kiên cường đã ra đi ở tuổi trăng tròn, trên mái tóc xanh của nàng có cài nhành hoa lêkima của miền Đất Đỏ quê hương.
Theo lời kể được lưu truyền, trước đây, bên mộ chị Sáu có một cây dương liễu đã héo nhưng còn một cành cây hướng về phía Bắc vẫn sống tươi xanh lạ thường. Đó là chị Sáu hướng về miền Bắc, nơi có Chủ tịch Hồ Chí Minh, tên của Người mà chị đã hô vang trước họng súng của kẻ thù.
Năm 1995, ngôi mộ chị Sáu được trùng tu tôn tạo khang trang và đến năm 2000, người ta trồng thêm cây lê ki ma, mà phải lấy giống từ quê hương Đất Đỏ thì cây mới sống và đơm hoa, kết trái.
Kìa hoa lê ki ma nở
Đẹp thêm quê miền đất đỏ
Nơi đó sáng mãi tên người anh hùng
Bình minh đang rực sáng cho hoa kia nở
Mùa xuân lan tràn xứ sở
Tôi đến hát trước nấm mồ chôn sâu
Người nữ anh hùng.
Chị Võ Thị Sáu sinh năm 1933, tại thôn Phước Lợi, xã Long Mỹ, quận Đất Đỏ (nay là xã Phước Hội, huyện Đất Đỏ, tỉnh Bà Rịa – Vũng Tàu), thân sinh là ông Võ Văn Hợi, bà Nguyễn Thị Đậu, chị là người con thứ 5 trong gia đình có 6 anh chị em.
Câu chuyện về chị Võ Thị Sáu vẫn còn nhiều. Nhưng bất cứ ai cũng biết chị đã ra đi khi mới tuổi 19, độ tuổi đẹp nhất của người con gái và đã trở thành biểu tượng cao đẹp, cổ vũ tinh thần cho lớp lớp thanh niên Việt Nam đứng lên chiến đấu trong hai cuộc kháng chiến chống Pháp, Mỹ của dân tộc./.

## Ai cũng có một hoặc nhiều chiếc mặt nạ

1. Khi còn là một đứa trẻ, ai cũng muốn lớn thật nhanh để được đối xử như là người lớn. Còn khi trưởng thành, ai cũng muốn được như những đứa trẻ, vô lo, vô nghĩ, nhìn đời bằng còn mắt tròn xoe, trong vắt.
2. Lúc còn bé, gặp bất cứ chuyện gì hay bị ai bắt nạt cũng liền về mách với bố mẹ. Nhưng khi lớn lên, kể cả bị ấm ức hay bất công đến mức nào cũng chỉ mỉm cười nói: "Con ổn".
3. Khi bạn còn nhỏ - ba là siêu nhân và mẹ là bà tiên để thỏa mãn được tất cả những gì bạn cần. Khi lớn lên rồi - bạn nhận ra rất nhiều thứ ba mẹ không thể làm được. Một đứa trẻ còn rất nhỏ thì những gì cần là nhu cầu tồn tại, nhưng khi lớn lên rồi thì những đòi hỏi sẽ ngày một lớn. Đến lúc nào đó, mỗi đứa trẻ hiểu rằng không phải dễ dàng để có cái mình muốn và thậm chí việc "con muốn..." có thể là xa xỉ.
Với sự tôi luyện của năm tháng, chúng ta đã dần trở thành những người khác hơn, hay nói cách khác là trở thành phiên bản dễ được người khác chấp nhận và công nhận hơn. Trong các mối quan hệ, không phải lúc nào chúng ta cũng có thể tuỳ tiện nói ra những suy nghĩ trong lòng.
- - -
Mỗi người đều mang một chiếc mặt nạ vô thức
Đã khi nào bạn yêu mà không dám nói?
Đã khi nào bạn giận mà chưa dám bày tỏ?
Đã khi nào bạn buồn mà vẫn tỏ ra vui?
Đã khi nào dù không muốn nhưng bạn vẫn làm?
Đã khi nào bạn …. mà vẫn ….?
Đã khi nào bạn nhìn thấy người khác thờ ơ mà hiểu rằng họ đang yêu?
Đã khi nào bạn nhìn thấy người khác giận dữ mà hiểu rằng họ đang gặp chuyện ở ngoài?
Đã khi nào bạn nhìn thấy người khác cười mà hiểu rằng đằng sau đó là nỗi buồn vô tận?
Đã khi nào bạn thấy người khác làm điều gì đó cho mình mà hiểu rằng họ đang không làm vì điều họ muốn?
Mỗi ngày mới đến, chúng ta phải đối mặt với vô vàn điều phức tạp diễn ra quanh mình. Trong những lúc như vậy, chúng ta mang lên khuôn mặt của mình những chiếc mặt nạ MỘT CÁCH VÔ THỨC, nhiều đến nỗi đôi khi ta không biết được đâu mới là cảm xúc thật…
- - -
Tối nay về nhà, bạn hãy khóa cửa phòng mình lại, ngồi trong không gian riêng tư và quen thuộc, bạn hãy đứng trước gương, nhìn vô mọi thứ mà bạn nắm giữ, hoặc khoác lên người. Nếu có cái gì vượt khỏi tiện ích cơ bản, hãy tháo ra, vì nó chỉ tồn tại ở đó để phục vụ cái tôi của bạn mà thôi. Hãy nhìn vào cái váy này, nó sinh ra để che chắn và bảo vệ cơ thể hay để dựng hình ảnh cá nhân của bạn? Nếu không phải xuất hiện thanh lịch trước mặt người khác, bạn có cần cái này không? Còn đôi giày này thì sao, nếu không cần thiết có sự chuyên nghiệp, bạn có mua đôi giày khác thoải mái hơn?
Một chút nữa, hãy nhìn vào trang sức, hoặc chiếc cà vạt hoặc mái tóc vừa nhuộm của bạn... Có thứ nào phục vụ tiện ích cơ bản? Hãy xem nào, mỗi ngày, chúng ta đã khoác lên người bao nhiêu thứ chỉ để thỏa mãn cái tôi của mình. Bạn có cảm thấy nhẹ nhàng khi lột bỏ được chúng xuống không? Nằm trên gường với bộ đồ ngủ thoải mái, thật sự sướng hơn đúng không nào?
Cũng giống như vậy, một lúc nào đó, bạn hãy nhìn vô cảm xúc của bản thân bạn. Cảm xúc đấy có phải là bạn không? Hãy quan sát chúng. Mỗi ngày, bạn có biết bao nhiêu xúc cảm: buồn, vui, tổn thương, đau đớn, hy vọng rồi thất vọng, gần như các cảm xúc ấy do thế giới bên ngoài tác động đến bạn, do vậy, cảm xúc là cái gì đó thất thường, diễn ra từ cái tôi của chính bạn. Khi sự tự nhận thức của BẠN trở nên sâu sắc hơn, rồi bạn sẽ đạt đến một nhận thức rất quan trọng: bạn không phải là cảm xúc của bạn.
Bạn không phải là cảm xúc của bạn
Nếu bạn là một người hành thiền, rồi bạn sẽ nhận thấy sự chuyển đổi vi tế mà vô cùng quan trọng – rằng cảm xúc chỉ đơn giản là những gì bạn cảm thấy, chứ không phải con người bạn. Cảm xúc chuyển từ bản thể (tôi) sang trải nghiệm (tôi cảm thấy). Cảm xúc trở thành những gì bạn trải nghiệm trên cơ thể, vì vậy bạn sẽ lập tức chuyển từ “Tôi tức giận” sang “Tôi trải nghiệm sự tức giận trên cơ thể tôi”. Sự chuyển đổi vi tế này là cần thiết vì nó cho thấy loài người có khả năng làm chủ các cảm xúc.
Nếu có ai đó khiến bạn bị tổn thương nhiều nhất, thì đó là chính bạn. Đạt-lai Lạt-ma từng chia sẻ: tuy rằng bạn không thể khiến một suy nghĩ hoặc một cảm xúc không lành mạnh không khởi lên, bạn có sức mạnh để buông thả nó đi, và một tâm trí đã được rèn luyện kỹ càng sẽ có thể buông thả nó đi ngay khoảnh khắc nó khởi lên.

## Săn mây Cầu Đất, Đà Lạt - một chuyến đi có thể giúp chữa lành

Săn mây tại Cầu Đất - Đà Lạt giúp bạn có những khoảnh khắc tuyệt đẹp và hành trình di chuyển có thể giúp chữa lành nhiều âu lo, muộn phiền trong bạn
Nếu muốn săn mây ở cầu gỗ thì bạn nên khởi hành từ thành phố vào khung giờ 4:00 - 4:30 sáng, di chuyển theo hướng Trại Mát để đến điểm săn mây. Tùy thuộc vào tốc độ chạy xe mà bạn có thể lựa chọn giờ xuất phát phù hợp. 
  * Nếu bạn là người mới đi săn mây ở cầu gỗ lần đầu thì nên khởi hành sớm hơn và xem kỹ lịch trình di chuyển Đà Lạt để tiết kiệm thời gian. 
  * Nếu bạn đã quen thuộc thì 5.00-5.30 khởi hành vẫn kịp vì săn mây vẫn đẹp cho đến tầm 6.00-6.30 sáng


## **Những lưu ý khi đến với cầu gỗ săn mây Đà Lạt**
Khi đến tham quan, check-in cầu gỗ săn mây, bạn cần lưu ý những điều sau: 
- Để di chuyển từ Đà Lạt đến địa điểm cầu gỗ mất rất nhiều thời gian, đường đi cũng tương đối quanh co, khúc khuỷu. Do vậy, bạn cần phải chắc tay lái và di chuyển một cách cẩn thận, không nên quá vội vàng.
- Săn mây Cầu đất đi xe ô tô được không? Đường đi đủ rộng cho xe ô tô di chuyển đến tận sát nơi săn mây, nên bạn hoàn toàn có thể di chuyển bằng xe ô tô 4 chỗ, 7 chỗ. Nếu bạn đi bằng xe máy, hãy nhớ rằng có sương mù buổi sáng nên đèn pha của xe máy phải đảm bảo đủ sáng
- Để nhìn ngắm cảnh quang nơi đây và săn mây thì bạn nên lựa chọn thời điểm thích hợp để đi. Không nên đi vào những ngày có thời tiết xấu hoặc mùa mưa, bởi nếu như vậy thì và sương mù sẽ bao phủ và tầm nhìn sẽ bị hạn chế. 
* Lưu ý không xả rác ở khu vực điểm tham quan và cả trên đường di chuyển đến nơi đây. 

## Nỗi đau trải qua những quá trình nào ?

  * [Giai đoạn 1: Hình thành](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/noi-dau-trai-qua-nhung-qua-trinh-nao#giai-on-1-hnh-thnh)
  * [Giai đoạn 2: Nguôi ngoai](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/noi-dau-trai-qua-nhung-qua-trinh-nao#giai-on-2-ngui-ngoai)
  * [Giai đoạn 3: Tách biệt](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/noi-dau-trai-qua-nhung-qua-trinh-nao#giai-on-3-tch-bit)
  * [Giai đoạn 4: Biết ơn](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/noi-dau-trai-qua-nhung-qua-trinh-nao#giai-on-4-bit-n)


## Giai đoạn 1: Hình thành
Khi nỗi đau mới bắt đầu, ta dễ bị mắc kẹt ở trong nó.
Mình có một bé mèo vàng sống với mình hơn 10 năm. Hắn chứng kiến gần như mọi thăng trầm trong quá trình trưởng thành của mình. Những lần mình mệt nằm lỳ trên giường, hắn lại leo lên người mình, rồi nằm đó phát ra tiếng grừm grừm dễ thương đưa hai đứa vào giấc ngủ.
Một hôm mình đang ở văn phòng thì mẹ nhắn: không thấy hắn trong nhà nữa. Lúc đó mình chỉ nghĩ đơn giản trong đầu: “Chắc lại leo trèo lên nóc cục nóng máy lạnh nằm ngủ rồi, con này thích đu đưa lắm.”
Mọi thứ trở nên nghiêm trọng hơn khi mình về và tìm khắp mọi nơi không thấy hắn. Khoảng thời gian mình rời nhà đi thang máy xuống tìm gặp bác bảo vệ hỏi chuyện là khoảng thời gian cực kỳ căng thẳng.
Hôm đó, hắn đã quyết định không làm mèo trong nhà nữa, mà muốn được làm chim tự do trên bầu trời (hy vọng ở kiếp sau hắn đã được thoả lòng).
Còn mình thì thậm chí còn không có cơ hội được nhìn hắn lần cuối, vì người ta đã dọn đi mất.
Mình không muốn chia sẻ nhiều hơn về giai đoạn này, sợ rằng bạn đọc sẽ buồn theo. Những gì mình học được là những lý do vì sao người ta lại dễ bị mắc kẹt lại khi nỗi đau mới hình thành:
  * Ta mắc kẹt vì tìm cách xao nhãng bản thân khỏi sự kiện, như một cơ chế phòng vệ. Điều này giúp chúng ta tạm thời không phải đối mặt với mọi khía cạnh của đau đớn, nhưng nếu kéo dài, chúng ta có thể bị mắc kẹt.
  * Ta mắc kẹt vì muốn tự trừng phạt mình, vì ta phải chịu trách nhiệm cho sự kiện đã xảy ra.
  * Ta mắc kẹt vì không biết phải làm gì để khắc phục hậu quả.
  * Ta mắc kẹt vì nó đã trở thành một phần của ta. Ta sợ nếu không còn nỗi đau này nữa, ta cũng quên luôn lý do nó bắt đầu.


Cách duy nhất để vượt qua giai đoạn này là cho phép bản thân cảm nhận và trải qua đủ các loại cảm xúc mà nỗi đau mang đến. Đôi khi, việc chấp nhận sự thật lại là điều khó khăn nhất.
## Giai đoạn 2: Nguôi ngoai
Sau một thời gian ta sẽ bắt đầu nguôi ngoai, nhưng chưa thể hoàn toàn thoát ra khỏi nỗi đau, như đống tro còn âm ỉ cháy gặp gió sẽ bùng lên. Chẳng hạn như:
  * Khi Facebook bắt đầu nhắc về những tấm ảnh, những status mình đăng cùng bé mèo vàng.
  * Khi bé mèo muối tiêu (được mèo vàng chăm như con từ nhỏ) bắt đầu trở nên lạnh nhạt, mà mình cho rằng hắn trách mình đã đem chị của hắn đi mất.
  * Khi một người bạn kể về mèo bạn nuôi, lông vàng và tinh nghịch.


Mỗi lần như thế mình lại cảm thấy như vô tình chạm vào một mảnh vỡ còn sót lại trong lòng. Nỗi đau vẫn âm thầm tồn tại, thì thầm nhắc nhở mình "vẫn còn bài học đấy, học đi".
Nhà thơ Rumi từng viết:  _“You have to keep breaking your heart until it opens.”_
Ở giai đoạn này, phần nào đó trái tim của chúng ta vẫn còn đóng cửa, không thể đón nhận thêm niềm vui mới.
Kinh nghiệm của mình là hãy kể thật nhiều về nỗi đau này, cho chính mình, và cho những người thật sự muốn nghe. Để rồi vào một khoảnh khắc nào đó, chúng ta nhận ra mình đã thôi ngụp lặn trong nó.
## Giai đoạn 3: Tách biệt
Những người tu tập thường nói:
_“Khi thấy được núi, ta ở ngoài núi._
_Khi thấy được sông, ta ở ngoài sông._
_Khi thấy nỗi sợ, ta ở ngoài nỗi sợ.”_
Nỗi đau cũng vậy, khi mình nhận ra rằng mình có thể nghĩ về bé vàng mà không còn cảm thấy đau lòng, thì hắn đã trở thành một kỷ niệm đẹp, một phần của quá khứ đã qua. Cảm xúc của mình về những ký ức với bé mèo giờ đây là bình thản, giống như mặt hồ yên lặng không còn sóng vỗ.
Đây là giai đoạn tuyệt vời mà có thể người ta đang gọi là “sự chữa lành”, và mình cũng thường nói với người khác:  _“Chữa lành là khi không để nỗi đau làm phiền bạn nữa.”_
## Giai đoạn 4: Biết ơn
Gần đây, mình nhận ra thêm một giai đoạn khác của nỗi đau nữa, đó là sự trân trọng.
Có những nỗi đau trong quá khứ - những nỗi đau đủ mạnh làm thay đổi niềm tin của mình về cuộc sống, mà nay mình đã có thể hài hước kể về nó. Kết quả là người nghe không chỉ thoải mái đón nhận hơn, mà họ còn cảm thấy phần nào được xoa dịu cho những nỗi đau tương tự họ đang có.
  * [Giai đoạn 1: Hình thành](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/noi-dau-trai-qua-nhung-qua-trinh-nao#giai-on-1-hnh-thnh)
  * [Giai đoạn 2: Nguôi ngoai](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/noi-dau-trai-qua-nhung-qua-trinh-nao#giai-on-2-ngui-ngoai)
  * [Giai đoạn 3: Tách biệt](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/noi-dau-trai-qua-nhung-qua-trinh-nao#giai-on-3-tch-bit)
  * [Giai đoạn 4: Biết ơn](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/noi-dau-trai-qua-nhung-qua-trinh-nao#giai-on-4-bit-n)



## Nếu khổ đau không đến đây (Thơ)

_**NẾU KHỔ ĐAU KHÔNG ĐẾN ĐÂY**_
_**Thầy Thích Minh Niệm**_
Nếu không có những ngày tháng nằm rã rời - vô hồn trên giường bệnh 
Làm sao ta biết được rằng: nói, cười, đi, đứng - là diễm phúc thần tiên? 
Nếu không có những ngày dầm mình trong mưa bão triền miên 
Làm sao ta biết được: hơ tay bên bếp lửa nhà - lòng sẽ ngập tràn ấm áp?
Nếu không có những ngày tháng chia lìa, không thể gọi tên nhau mỗi khi thức giấc
Làm sao ta thấy được lòng mình đong đầy hạnh phúc khi có nhau?
Những ngày tháng qua, ta quay cuồng trong hành trình đầy biến động thương đau
Có lúc tưởng chừng như mặt trời sẽ không bao giờ được nhìn thấy nữa
Ta đã ném vào nhau những cái nhìn đầy hoang mang vì lòng không điểm tựa - Bao năm qua đã được gì?
Sao bây giờ bỗng mịt mờ không thể tính nổi chuyện ngày mai?
Những ngày tháng qua ta và cuộc đời bỗng bị tách ra làm hai
Những ngón tay không thể chạm vào nhau, những cái nhìn cũng phải cần khoảng cách
Ta cứ nằm co như con tôm, nghe tiếng đồng hồ quay đều đều với thanh âm diệu kỳ "tích tắc"
Lòng chợt thấy bồi hồi, cũng đã từ lâu lắm rồi - trong khu vườn yên tĩnh buổi bình minh
Những cành hoa đào đứng vươn mình vững chãi trong giá rét với niềm tin
Nếu không có khổ đau thì hoa đào không thể toả ngát hương trong nắng ấm
Nếu không có mùa đông thì hoa đào không thể làm cho mùa xuân thêm tươi thắm
Nếu khổ đau không đến kịp bây giờ - thì hạnh phúc cũng sẽ tình cờ như mỗi ngày lặng lẽ ra đi...

## Khi mẹ còn sống, anh em là một gia đình - Khi mẹ qua đời, chúng ta chỉ còn là người thân

Thứ tình cảm duy nhất không bao giờ vơi cạn có lẽ chỉ có thể là tình yêu thương của mẹ. Thứ vướng bận sâu thẳm trong trái tim của chúng ta đó chính là ngôi nhà đã sinh ra và nuôi dưỡng bạn…
Nếu như có ai đó hỏi bạn “Nhà bạn ở đâu”, bạn sẽ trả lời như thế nào? “Nhà” rốt cuộc là căn phòng cũ dưới quê nơi cha mẹ đang chờ, hay là căn chung cư thành phố nơi mà ta đang ở?
Giống với nhiều người khác, năm 18 tuổi tôi lên đại học, từ lúc đó tôi bắt đầu rời xa ngôi nhà mang ý nghĩa truyền thống của mình. Thoáng chốc, tôi đã xa nhà được 12 năm.
Có mẹ là có gia đình
Hầu hết chúng ta đều có một tuổi thơ để nhớ về, một thứ hạnh phúc đáng để chúng ta nhớ lại. Thời niên thiếu hạnh phúc đó đến từ nụ cười của mẹ, đến từ sự trông nom chăm sóc của mẹ. Khi trong nhà không còn mẹ nữa thì bạn sẽ khó thấy được nụ cười xuất hiện trên khuôn mặt của mình nữa.
Thuở ấu thơ…
Khi còn nhỏ, cả ngày đùa nghịch ở bên ngoài, chỉ đến khi đói rồi, mệt rồi bạn mới biết đến hai từ “về nhà”. Việc đầu tiên bạn làm khi về nhà đó là tìm mẹ, câu nói đầu tiên khi bước vào nhà đó là hét lên “mẹ ơi”.
Khi đó chỉ cần nhìn thấy bóng lưng bận rộn của mẹ, nghe được lời hồi đáp của mẹ là trong lòng liền yên bình lạ thường. Và thế là, bạn bắt đầu tìm đồ ăn. Ăn uống no say, rồi lại chạy đi chơi.
Đến khi lớn rồi, việc đầu tiên bạn làm khi bước vào nhà vẫn là tìm mẹ, chưa kịp đặt chiếc ba lô trên vai xuống đã tìm vội vã tìm mẹ khắp nơi. Mẹ nhìn thấy, bèn cười nói “Đứa trẻ ngu ngốc này, sao không bỏ ba lô ra cho đỡ mệt”. Có lẽ mẹ không biết rằng, khi tìm mẹ thì chúng con không biết mệt là gì.
Khi bạn có gia đình nhỏ của mình rồi, rảnh rỗi là bạn lại nghĩ “đi đâu thì thích đây?”. Thế là bạn liền trở về nhà. Tôi vĩnh viễn không bao giờ có thể thoát ra được sự mong chờ được trở về ngôi nhà này.
Mở cửa nhà đi vào, mẹ không ở nhà, cha đón chúng tôi vào và cùng nhau nói những chuyện trong cuộc sống. Tuy nhiên ánh mắt của tôi vẫn thường xuyên nhìn ra cửa để chờ mẹ về.
Khi mẹ đẩy cửa bước vào, trong lòng tôi mới có được cảm giác chân thực. Cứ như vậy, cho dù là ở đâu, bất cứ nơi đâu bất cứ lúc nào, tôi luôn nghĩ đến muốn về thăm nhà, khi về đến nhà rồi thì tiếng gọi đầu tiên vẫn luôn là “mẹ”.
Đó chính là niềm hạnh phúc của cuộc sống.
Nơi nào có mẹ nơi đó chính là nhà…
Kỳ thực, gia đình và mẹ chính là như vậy, luôn khắc ghi sâu trong tận đáy lòng của mỗi một đứa con. Càng lớn, mọi người sẽ càng hiểu rằng, dẫu cho tuổi tác làm thay đổi diện mạo, dẫu cho thế gian này thay đổi lớn như thế nào, thì thứ duy nhất không bao giờ thay đổi chính là cảm giác không thể tách rời với ngôi nhà và tình yêu vô bờ bến, bất tận của người mẹ đối với mình.
Có mẹ bên cạnh bạn có thể vững tâm tự mình khám phá thế giới, yên tâm đặt ra lí tưởng của bản thân tiến lên phía trước. Bạn vốn không thể đi một mạch tới đích, nhưng khi mỏi mệt luôn có một bến đỗ yên bình đợi bạn đó là gia đình, ở đó có mẹ đang chờ mong bạn hàng ngày.
Khi bạn đã trở thành người quyền cao chức trọng có địa vị, đặc biệt là khi sự nghiệp của bạn đã có những thành tựu nhất định hoặc là bạn trở thành một người đầu đội trời chân đạp đất, có thể hô mưa gọi gió, lúc đó bạn sẽ vội vã đi tìm một chỗ dựa tinh thần cho mình. Mà chỗ dựa tinh thần an toàn nhất, lâu dài nhất và đáng tin cậy nhất vẫn là mẹ và gia đình của bạn.
Có một người phụ nữ như thế….
Có người nói rằng, sau sự thành công của một người đàn ông nhất định có bóng hình của một người phụ nữ vĩ đại. Nếu đúng là như vậy thì trong số những người phụ nữ đó đầu tiên chắc chắn phải là mẹ.
Vào thời khắc tòa tháp đôi của Mĩ sụp xuống, một thương nhân có khối lượng tài sản khổng lồ nhận thức được đây là ngày tận thế của mình, thứ mà ông ấy nghĩ đến không phải là tài sản phía sau mình, mà là muốn gọi cho mẹ để nói câu nói đẹp nhất trên thế giới này “Mẹ, con yêu mẹ!”.
Vào khoảnh khắc nguy hiểm nhất, tình yêu giữa người mẹ và con cái đã xua đi những đám mây ảm đạm để phát ra một thứ ánh sáng rực rỡ. Sự vĩ đại của nhân cách con người đã dừng lại ở thời khắc đó.
Có thể khẳng định, gia đình, mãi mãi không bao giời rời xa bạn! Cho dù là cách xa trăm núi nghìn sông, muôn trùng sóng bể thì bóng hình của mẹ luôn theo sát hành trình của bạn, sự tận tâm của mẹ chính là lý do để bạn vượt qua tất cả để trở về nhà.
Thứ tình cảm mà nhân loại không bao giờ lung lay một chút nào có lẽ đó chính là tình yêu thương của mẹ. Thứ vướng bận tận sâu trong trái tim của chúng ta đó chính là ngôi nhà đã sinh ra và nuôi dưỡng bạn. Chỉ cần có mẹ là có gia đình!
Đúng vậy! Khi mẹ còn sống, anh em là một gia đình; Khi mẹ qua đời, chúng ta chỉ còn là người thân! Những người còn có mẹ, cho dù bạn có bận đến mức nào nhưng nhất định phải sắp xếp thời gian để về nhà thăm mẹ, và hãy nói: Mẹ ơi! Con mãi yêu mẹ.
“Ta đi trọn kiếp con người
Cũng không đi hết mấy lời mẹ ru"

## Tam quan là gì? Tam quan lệch lạc là vấn đề gì

  * [1. Tam quan là gì ?](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/tam-quan-la-gi-tam-quan-lech-lac-la-van-de-gi#1-tam-quan-l-g-)
  * [2. Tam quan lệch lạc là gì?](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/tam-quan-la-gi-tam-quan-lech-lac-la-van-de-gi#2-tam-quan-lch-lc-l-g)
  * [ 2.2 Suy nghĩ phân cực](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/tam-quan-la-gi-tam-quan-lech-lac-la-van-de-gi#22-suy-ngh-phn-cc)
  * [ 2.3 Khái quát hóa.](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/tam-quan-la-gi-tam-quan-lech-lac-la-van-de-gi#23-khi-qut-ha)
  * [ 2.4 Đọc trước suy nghĩ](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/tam-quan-la-gi-tam-quan-lech-lac-la-van-de-gi#24-c-trc-suy-ngh)
  * [ 2.5 Biến mọi thứ thành hiểm họa.](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/tam-quan-la-gi-tam-quan-lech-lac-la-van-de-gi#25-bin-mi-th-thnh-him-ha)
  * [ 2.6 Riêng tư hóa](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/tam-quan-la-gi-tam-quan-lech-lac-la-van-de-gi#26-ring-t-ha)
  * [ 2.7 Nhầm lẫn về khả năng kiểm soát.](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/tam-quan-la-gi-tam-quan-lech-lac-la-van-de-gi#27-nhm-ln-v-kh-nng-kim-sot)
  * [ 2.8 Nhầm lẫn về sự công bằng.](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/tam-quan-la-gi-tam-quan-lech-lac-la-van-de-gi#28-nhm-ln-v-s-cng-bng)
  * [ 2.10 Quá quy tắc ](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/tam-quan-la-gi-tam-quan-lech-lac-la-van-de-gi#210-quaquy-tc)
  * [ 2.11 Tư duy dựa trên cảm xúc](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/tam-quan-la-gi-tam-quan-lech-lac-la-van-de-gi#211-t-duy-da-trn-cm-xc)
  * [ 2.12 Ảo tưởng thay đổi người khác.](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/tam-quan-la-gi-tam-quan-lech-lac-la-van-de-gi#212-o-tng-thay-i-ngi-khc)
  * [ 2.13 Dán nhãn toàn thể](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/tam-quan-la-gi-tam-quan-lech-lac-la-van-de-gi#213-dn-nhn-ton-th)
  * [ 2.14 Tôi luôn đúng](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/tam-quan-la-gi-tam-quan-lech-lac-la-van-de-gi#214-ti-lun-ng)
  * [ 2.15 Ảo tưởng về phần thưởng](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/tam-quan-la-gi-tam-quan-lech-lac-la-van-de-gi#215-o-tng-v-phn-thng)


###  1. Tam quan là gì 
Trong triết học, tam quan là những quan điểm của con người về thế giới xung quanh. Đó là cách nhìn nhận, đánh giá khách quan về cuộc sống. Thế giới tam quan của con người được hình thành bởi 3 yếu tố:
  * Thế giới quan hay là vũ trụ quan. Đó là những quan điểm, suy nghĩ của con người về thế giới xung quanh và sự liên kết của con người và thế giới. Thế giới quan chính là cách bạn nhìn thế giới. Thế giới quan của một người được quyết định bởi những thứ họ tiếp xúc, nhìn thấy, nghe thấy. Ví dụ hôm nay bạn học được một công thức, đọc một quyển sách hay là kết giao được với một người bạn tài trí… Tất cả đều đang làm cho thế giới quan của bạn càng thêm phong phú hơn.
  * Gía trị quan: Đó là sự nhìn nhận, đánh giá tổng thể về ý nghĩa của một sự vật, sự việc nào đó diễn ra xung quanh cuộc sống của chúng ta. Giá trị quan là cách nhìn nhận của bạn đối với một sự vật hiện tượng: Thế nào là đúng? Thế nào là sai? Bởi vì cùng một sự việc nhưng mỗi người chúng ta lại có một cách nhìn nhận khác nhau. Có những người cho rằng tri thức quyết định vận mệnh, có người cho rằng sức khỏe mới là quan trọng nhất, cũng có người cho rằng tiền bạc mới là quan trọng nhất.
  * Nhân sinh quan: Thể hiện thái độ của con người đối với các vấn đề cốt lõi và cơ bản của thời thế, nhân sinh.Thế giới quan và giá trị quan sẽ cùng nhau quyết định nhân sinh quan của bạn. Bạn đọc nhiều sách đến vậy, đã trải qua nhiều thứ như vậy, ngoảnh đầu lại hỏi bản thân: Ước mơ của mình là gì? Mình muốn trở thành người như thế nào? Đó chính là Nhân sinh quan.


Tam quan của một người sẽ quyết định trực tiếp đến nhận thức và cách hành xử của cá nhân đó đối với thế giới xung quanh. Đồng thời, nó cũng là yếu tố quan trọng giúp chúng ta thiết lập nên các giá trị và đạo đức cho riêng mình.
## 2. Tam quan lệch lạc là gì?
Đó là những suy nghĩ lệch lạc, không đúng của con người về thế giới quan. Những suy nghĩ ấy có thể là do môi trường sống và làm việc, gia đình, bản chất của con người. Ở nhiều góc độ khác nhau mà suy nghĩ ấy sẽ tác động tiêu cực đến lối sống và hành động của con người, mang đến những kết quả không tốt, có cái nhìn tiêu cực về bản thân và những người xung quanh. Dưới đây là 15 lối suy nghĩ lệch lạc phổ biển nhất
### 2.1 Sàng lọc
Bạn tập trung vào các chi tiết tiêu cực và phóng đại chúng lên, cùng lúc đó bỏ ra ngoài mọi khía cạnh tích cực của sự việc. Một chi tiết đơn lẻ có thể được chọn ra, và rồi toàn bộ sự việc sẽ mang màu sắc của chi tiết đó. Khi bạn tách riêng những điều tiêu cực khỏi bối cảnh, bạn sẽ khiến chúng lớn hơn và tồi tệ hơn so với thực tế.
###  2.2 Suy nghĩ phân cực
Mọi thứ đầu đen hay trắng, tốt hay xấu; bạn phải là người hoàn hảo, nếu không thì là thất bại,...không có vị trí ở giữa, không có sự trung dung.
###  2.3 Khái quát hóa.
Bạn đi đến kết luận dựa trên một sự kiện đơn lẻ hoặc một ít chứng cứ. Nếu điều gì xấu xảy ra một lần, bạn sẽ cho rằng nó lại tiếp tục xảy ra nhiều lần. "Luôn luôn" và "không bao giờ" là những dấu hiệu cho thấy bạn đang suy nghĩ theo lối này. Kiểu suy nghĩ vội vàng có thể đưa đến một cuộc sống bị hạn chế, bởi bạn tránh các thất bại trong tương lai chỉ dựa trên một sự việc, sự kiện đơn lẻ.
###  2.4 Đọc trước suy nghĩ
Không cần mọi người lên tiếng, bạn đã biết họ đang có cảm giác gì và lý do tại sao họ lại hành động theo cách đó. Đặc biệt, bạn có khả năng tiên đoán mọi người có cảm nhận như thế nào về bạn. Việc đọc trước suy nghĩ phụ thuộc vào một quá trình gọi là "phép chiếu". Bạn tưởng tượng rằng mọi người cũng cảm nhận và phản ứng với mọi thứ giống bạn. Vì vậy, bạn không quan sát hay lắng nghe đủ cẩn thận và không nhận ra rằng họ thực sự khác biệt. Những người đọc trước suy nghĩ sẽ đi đến các kết luận chủ quan, nhưng lại không kiểm tra xem liệu điều đó có đúng với những người khác hay không.
###  2.5 Biến mọi thứ thành hiểm họa.
Bạn kì vọng thảm họa sẽ xảy ra. Bạn chú ý hoặc nghe về một vấn đề và rồi bắt đầu nghĩ "điều gì sẽ xảy ra nếu..." Điều gì sẽ xảy ra nếu bi kịch ập đến? Điều gì sẽ xảy ra nếu chuyện tồi tệ đến với tôi?
###  2.6 Riêng tư hóa
Nghĩ rằng những điều mọi người làm hoặc nói đều là một loại phản ứng nào đó đối với bạn. Bạn cũng so sánh bản thân mình với những người khác và cố xác định xem ai thông minh hơn, ai ưa nhìn hơn,...
###  2.7 Nhầm lẫn về khả năng kiểm soát.
Nếu bạn cảm thấy mình bị kiểm soát quá nhiều bởi các yếu tố bên ngoài, bạn sẽ nhìn nhận bản thân là bất lực, nạn nhân của số phận. Ngược lại, nếu bạn đặt cho mình quá nhiều sự kiểm soát, bạn có xu hướng trách nhiệm cho nỗi đau và hạnh phúc của mọi người xung quanh.
###  2.8 Nhầm lẫn về sự công bằng.
Bnạ cảm thấy bực bội vì cho rằng mình biết thế nào là công bằng, nhưng những người khác lại không đồng ý với bạn, hay không hành xử giống như quan điểm "công bằng" của bạn.
###  2.9 Đổ lỗi
Bạn cho rằng người khác phải chịu trách nhiệm cho những đau khổ của bạn, hoặc ngược lại, đổ lỗi cho bản thân về mọi vấn đề. Thông thường, đổ lỗi là hành động khiến người khác phải chịu trách nhiệm cho những lựa chọn và quyết định của cá nhân bạn. Trong các hệ thống đổ lỗi, bạn từ chối quyền (và trách nhiệm) của mình để nhấn mạnh nhu cầu của bản thân, từ chối, hoặc bỏ đi nơi khác để tìm những gì bạn muốn.
###  2.10 Quá quy tắc 
Bạn có cả một danh sách các quy tắc cứng nhắc quy định bạn và những người khác nên hành xử ra sao. Những ai phá vỡ quy tắc này sẽ khiến bạn tức giận, và bạn cảm thấy tội lỗi nếu chính mình vi phạm nguyên tắc đó.
###  2.11 Tư duy dựa trên cảm xúc
Bạn tin rằng những gì bạn cảm nhận là hoàn toàn đúng. Nếu bạn cảm thấy ngớ ngẩn và nhàm chán, vậy nghĩa là bạn thực sự ngớ ngẩn và nhàm chán. Nếu bạn cảm thấy tội lỗi, vậy chắc chắn bạn đã làm gì điều gì đó sai trái. Vấn đề của "tư duy theo cảm xúc" là: xúc cảm cảu bạn có tương tác và tương quan với quá trình tư duy. Vì vậy, nếu bạn có những niềm tin và suy nghĩ lệch lạc thì xúc cảm của bạn sẽ phản ánh những điều lệch lạc đó.
###  2.12 Ảo tưởng thay đổi người khác.
Bạn mong đợi người khác sẽ thay đổi để phù hợp với bạn, chỉ cần bạn đủ gây áp lực hoặc chiều chuộng họ. Bạn cần phải thay đổi mọi người bởi hy vọng được hạnh phúc của bạn dường như hoàn toàn phụ thuộc vào họ. Nhưng sự thật là, người duy nhất bạn có thể kiểm soát hoặc có hy vọng thay đổi là chính bản thân bạn. Nhận định ẩn bên dưới lối nghĩ này là: bạn cho rằng hạnh phúc của bạn phụ thuộc vào hành động của người khác. Nhưng thực tế là hạnh phúc của bạn phụ thuộc vào hàng nghìn quyết định lớn nỏ mà bạn đưa ra trong cuộc sống.
###  2.13 Dán nhãn toàn thể
Bạn khái quát một hoặc hai phẩm chất (ở bản thân hoặc người khác) thành một nhận định tiêu cực cho toàn thể. Dán nhãn toàn thể sẽ bỏ qua tất cả bằng chứng trái chiều, tạo nên một cái nhìn rập khuôn và một chiều về thế giới. Dán nhãn cho bản thân có thể gây tác động tiêu cực đến sự tự tin của bạn; trong khi dán nhãn lên những người khác có thể dẫn tới nhận định bộp chộp, các vấn đề về mối quan hệ và thành kiến.
###  2.14 Tôi luôn đúng
Bạn liên tục xem xét để chứng tỏ rằng ý kiến và hành động của bản thân là chính xác. Sai trái là điều không thể chấp nhận được và bạn sẽ làm mọi cách để chứng minh sự đúng đắn của mình.
###  2.15 Ảo tưởng về phần thưởng
Bạn mong đợi tất cả mọi hy sinh và từ bỏ lợi ích của mình sẽ được đền đáp, như thể có ai đó đang ghi sổ cho bạn. Bạn sẽ cảm thấy cay đắng khi phần thưởng không đến như kỳ vọng. Vấn đề chính là, mặc dù bạn luôn làm "điều tốt" nhưng bạn lại không thực sự đặt tâm vào đó, bạn chỉ đang làm tổn hại bản thân cả về thể chất lẫn tinh thần.
  * [1. Tam quan là gì ?](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/tam-quan-la-gi-tam-quan-lech-lac-la-van-de-gi#1-tam-quan-l-g-)
  * [2. Tam quan lệch lạc là gì?](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/tam-quan-la-gi-tam-quan-lech-lac-la-van-de-gi#2-tam-quan-lch-lc-l-g)
  * [ 2.2 Suy nghĩ phân cực](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/tam-quan-la-gi-tam-quan-lech-lac-la-van-de-gi#22-suy-ngh-phn-cc)
  * [ 2.3 Khái quát hóa.](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/tam-quan-la-gi-tam-quan-lech-lac-la-van-de-gi#23-khi-qut-ha)
  * [ 2.4 Đọc trước suy nghĩ](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/tam-quan-la-gi-tam-quan-lech-lac-la-van-de-gi#24-c-trc-suy-ngh)
  * [ 2.5 Biến mọi thứ thành hiểm họa.](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/tam-quan-la-gi-tam-quan-lech-lac-la-van-de-gi#25-bin-mi-th-thnh-him-ha)
  * [ 2.6 Riêng tư hóa](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/tam-quan-la-gi-tam-quan-lech-lac-la-van-de-gi#26-ring-t-ha)
  * [ 2.7 Nhầm lẫn về khả năng kiểm soát.](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/tam-quan-la-gi-tam-quan-lech-lac-la-van-de-gi#27-nhm-ln-v-kh-nng-kim-sot)
  * [ 2.8 Nhầm lẫn về sự công bằng.](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/tam-quan-la-gi-tam-quan-lech-lac-la-van-de-gi#28-nhm-ln-v-s-cng-bng)
  * [ 2.10 Quá quy tắc ](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/tam-quan-la-gi-tam-quan-lech-lac-la-van-de-gi#210-quaquy-tc)
  * [ 2.11 Tư duy dựa trên cảm xúc](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/tam-quan-la-gi-tam-quan-lech-lac-la-van-de-gi#211-t-duy-da-trn-cm-xc)
  * [ 2.12 Ảo tưởng thay đổi người khác.](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/tam-quan-la-gi-tam-quan-lech-lac-la-van-de-gi#212-o-tng-thay-i-ngi-khc)
  * [ 2.13 Dán nhãn toàn thể](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/tam-quan-la-gi-tam-quan-lech-lac-la-van-de-gi#213-dn-nhn-ton-th)
  * [ 2.14 Tôi luôn đúng](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/tam-quan-la-gi-tam-quan-lech-lac-la-van-de-gi#214-ti-lun-ng)
  * [ 2.15 Ảo tưởng về phần thưởng](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/tam-quan-la-gi-tam-quan-lech-lac-la-van-de-gi#215-o-tng-v-phn-thng)



## Chánh niệm là gì ? Tại sao chánh niệm có thể giúp giảm căng thẳng

  * [Chánh niệm là gì?](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/chanh-niem-la-gi-tai-sao-chanh-niem-co-the-giup-giam-cang-thang#chnh-nim-l-g)
  * [Lợi ích của chánh niệm là gì?](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/chanh-niem-la-gi-tai-sao-chanh-niem-co-the-giup-giam-cang-thang#li-ch-ca-chnh-nim-l-g)
  * [Mẹo để rèn luyện khả năng chánh niệm tốt hơn](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/chanh-niem-la-gi-tai-sao-chanh-niem-co-the-giup-giam-cang-thang#mo-rn-luyn-kh-nng-chnh-nim-tt-hn)


## Chánh niệm là gì?
Chánh niệm (tiếng Anh là mindfulness) là **khả năng nhận thức đầy đủ khoảnh khắc hiện tại,****thay vì sống trong quá khứ hoặc dự đoán về tương lai.** Hiểu đơn giản hơn là khi ta ý thức được ta đang ở đâu, đang làm những gì với thái độ không phán xét, không phản ứng thái quá hoặc bị choáng ngợp với những gì diễn ra xung quanh.
Một phần quan trọng trong chánh niệm là kết nối lại với cơ thể và những cảm giác mà chúng ta trải qua. Điều này có nghĩa là người thực hành chánh niệm sẽ nhận thức được suy nghĩ; cảm xúc và cảm giác (vị giác, xúc giác, khứu giác, thị giác và thính giác) của mình.
Khác với thiền là gì, chánh niệm là khả năng tự nhiên mà tất cả chúng ta đều sở hữu. Thiền sẽ là thực hành giúp ta rèn luyện khả năng này tốt hơn. Khi áp dụng các nguyên tắc của thiền, bạn sẽ rèn khả năng để tâm trí, cơ thể tập trung vào từng khoảnh khắc hiện tại tốt hơn.
## Lợi ích của chánh niệm là gì?
Khi chánh niệm, bạn sẽ nhận thức rõ ràng hơn về thời điểm hiện tại. Điều đó sẽ giúp bạn tận hưởng thế giới xung quanh nhiều hơn và hiểu bản thân hơn.
Chánh niệm cũng cho phép chúng ta nhận thức rõ hơn về dòng suy nghĩ và cảm xúc của mình. Để từ đó, bạn biết cách tháo gỡ, thay đổi những suy nghĩ, cảm nghĩ không hữu ích cho tinh thần của bạn.
Các nghiên cứu về lợi ích của chánh niệm là gì đã khẳng định thực hành này giúp:
  * Cải thiện trí nhớ.
  * Cải thiện giấc ngủ.
  * Tăng cảm giác hạnh phúc.
  * Kiểm soát nóng giận tốt hơn.
  * Cải thiện khả năng nhận thức.
  * Giảm căng thẳng, lo lắng và trầm cảm.
  * Giảm chứng đau nửa đầu và đau mãn tính.
  * Cải thiện các mối quan hệ nhờ kết nối và tương tác tốt với mọi người.
  * Giảm cân và cải thiện chứng rối loạn ăn uống nhờ tập trung vào cảm giác đói, hương vị của món ăn. Từ đó ăn uống chánh niệm giúp bạn xây dựng thói quen ăn uống lành mạnh hơn.


## Mẹo để rèn luyện khả năng chánh niệm tốt hơn
Một số bạn cảm thấy khó khăn khi thực hành chánh niệm, vậy mẹo giúp bạn chánh niệm tốt hơn là gì?
  * **Tập trung làm một việc trong một thời điểm.** Làm nhiều việc cùng một lúc có thể khiến bạn cảm thấy mất tập trung, vì vậy hãy thử tập trung hoàn toàn vào một nhiệm vụ với sự tập trung cao độ.
  * **Hãy tử tế với chính mình khi thực hành chánh niệm.** Đừng gay gắt hay phán xét nếu bạn thấy tâm trí mình đang lang thang. Chánh niệm cũng là chấp nhận bản thân và đối xử với bản thân bằng lòng trắc ẩn. Hãy cho bản thân thời gian để tập trung vào hiện tại.
  * **Hãy đặt ra một thời gian cụ thể trong ngày để thực hiện chánh niệm và duy trì thói quen này đều đặn.** Bạn có thể thực hành chánh niệm khi ăn uống, đi bộ hoặc trò chuyện để nhận thức về hiện tại.


**_Mặc dù bạn có thể thấy lợi ích chánh niệm là gì trong rất nhiều nghiên cứu; nhưng chánh niệm không dành cho tất cả mọi người. Một số người không thấy tác dụng chánh niệm trong kiểm soát lo âu, căng thẳng là gì. Khi này, tìm đến một tâm lý gia có thể là giải pháp tối ưu hơn dành cho bạn._**
  * [Chánh niệm là gì?](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/chanh-niem-la-gi-tai-sao-chanh-niem-co-the-giup-giam-cang-thang#chnh-nim-l-g)
  * [Lợi ích của chánh niệm là gì?](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/chanh-niem-la-gi-tai-sao-chanh-niem-co-the-giup-giam-cang-thang#li-ch-ca-chnh-nim-l-g)
  * [Mẹo để rèn luyện khả năng chánh niệm tốt hơn](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/chanh-niem-la-gi-tai-sao-chanh-niem-co-the-giup-giam-cang-thang#mo-rn-luyn-kh-nng-chnh-nim-tt-hn)



## Chỗ ngồi may mắn (truyện dịch)

Suốt gần một năm nay, nhà hàng của Dennis liên tục ế ẩm vì thời buổi kinh tế khó khăn sau cuộc khủng bố 9/11 đã làm chùn bước nhiều khách hàng. Nhà hàng của anh trước kia cũng đã có lúc khách đợi sắp hàng dài nhất trong khu shopping này, thế mà bây giờ thì cả chủ và thợ đều phải ngáp gió đập ruồi cho qua ngày tháng.
Dennis đã ráng cầm cự hơn sáu tháng nay, mỗi tháng anh phải mượn nợ từ bạn bè, thân thuộc để trang trải tiền công cho thầy thợ, tiền thuê cửa hàng. Nhưng tuần rồi anh bắt buộc phải tập hợp những người cộng tác của anh lại để thông báo cho biết là dịch vụ của nhà hàng sẽ phải tạm đình chỉ từ cuối tháng này.
Anh đã cẩn thận cộng đi cộng lại sổ sách nhiều lần, mỗi tháng dịch vụ thương mại của anh đều vướng phải một số âm to tướng. Trương mục tiết kiệm dành cho ngày dưỡng lão cũng biến thành một chữ số Zero. Dennis bắt đầu cảm thấy tay của anh giá lạnh như thể anh là một tay chơi trong sòng bài đang đến lúc cùng đường mạt vận. Buộc lòng anh phải nghĩ đến quyết định sau cùng là: Hãy bán hết ngày hôm nay, có thể anh phải đóng cửa kể từ ngày mai, tức là hai tuần sớm hơn dự định.
Đã đến giờ ăn tối mà sao khách của nhà hàng đi đâu hết rồi. Ở một góc khuất của quán ăn chỉ có hai cha con nọ đang ngồi đợi thực phẩm dọn lên, đứa nhỏ trông có vẻ nghịch ngợm, hết khua chén rồi lại gõ đĩa, người cha hình như có vẻ phiền muộn, không màng ngó ngàng đến đứa con đang làm huyên náo khung cảnh yên lặng của nhà hàng vắng khách.
Lúc đó, một người đàn ông ăn mặc sang trọng nhưng có gương mặt tái nhợt bước vào, Dennis chua chát nghĩ thầm: "Có thể đây là người khách cuối cùng của đêm nay mà cũng là người cuối cùng của nhà hàng mình chăng? Hay là ta đặc biệt chiêu đãi để tạo cho người ta có một thiện cảm với mình. Sau này, dù mình không còn mở cửa, nhưng biết đâu hình ảnh nhà hàng mình sẽ để lại trong lòng ông ta một ấn tượng đẹp đẽ!”
Người khách ngồi xuống gọi ngay một cốc rượu mạnh rồi mới bắt đầu lướt mắt qua tấm thực đơn đi tìm những món ăn đặc biệt nhất của tiệm Dennis. Không đợi ông gọi, Dennis tự động bước tới hớn hở nói với ông ta:
- Chúc mừng khách quí, ngài đã chọn đúng một chỗ ngồi tốt nhất, may mắn nhất trong tiệm của chúng tôi, vì vậy đêm nay không những ngài được miễn phí chiêu đãi mà những món ăn của ngài lại là phần ăn của một VIP.
Người khách ngây người nhìn Dennis một chặp rồi hỏi:
- Không ngờ tôi lại may mắn đến thế cơ à?
Dennis tiếp theo đó đã mang ra một phần ăn đặc biệt nhất trong tiệm anh để chiêu đãi người khách này. Đến món tráng miệng, thay vì chỉ một mẩu kem nhỏ thì anh mang ra một chiếc bánh ngọt hạng trung màu sắc rực rỡ và có nến thắp sáng giống như một chiếc bánh sinh nhật. Người khách lạ lúc này mới chịu nở một nụ cười tươi tắn.
Đứa trẻ bàn bên cạnh thấy chiếc bánh ngọt mang ra quá đẹp cũng ngây người nhìn một chặp rồi nó vòi vĩnh với cha:
-Ba à, con cũng muốn ăn chiếc bánh sinh nhật to như vậy đó.
Cha đứa bé nạt ngang:
-Cha con mình đâu có nhiều tiền để ăn những món đắt tiền như vậy đâu con.
Người khách may mắn thấy sự việc như vậy nên quay lại nói với Dennis:
-Đứa bé có vẻ thèm bánh ngọt, thôi thì anh hãy mang sự may mắn của tôi san sẻ với những người chung quanh của tôi vậy.
Dennis vâng lời chia cái bánh của ông làm đôi rồi mang nửa chiếc sang tặng cho cha con người khách ngồi bàn kế cận. Đứa bé hớn hở đón nhận tặng vật và múc ăn ngon lành. Người cha của đứa bé thấy con mình vui nên ông cũng cảm kích bước sang bên này để cảm ơn ông khách tốt bụng.
Hai ông khách từ những câu xã giao thông thường rồi bắt đầu bước vào thăm hỏi nhau qua nghề nghiệp. Ông khách sang trọng tự giới thiệu ông tên là Kent, chủ nhân kiêm giám đốc một hãng thiết kế điện tử ở Thung Lũng Hoa Vàng. Cơ sở của ông tuy còn rất nhỏ nhưng đã có những sản phẩm ăn khách bán chạy và bắt đầu có lời. Cha của đứa bé thì nghẹn ngào cho biết ông làm nghề địa ốc, nhưng tình hình kinh tế hiện nay đã khiến cho những tay dealer mua bán nhà cửa như ông gần như khánh tận. Ông đã nhận được giấy báo của công ty bắt đầu cho ông nghỉ việc kể từ đầu tháng tới.
Kent, ông khách sang trọng ngẫm nghĩ một chặp rồi nói với người cha đứa bé:
-Công ty của tôi đang cần những người saleman có khả năng, hay là anh vào hãng của tôi tạm thời làm thử một thời gian xem có thích hợp hay không?
Cha đứa bé bất ngờ gặp được quí nhân thì mừng rõ vô cùng, ông ta rối rít cảm ơn người khách lạ rồi họ trao đổi số phone và địa chỉ liên lạc …
Qua đêm hôm đó, Dennis bỗng nhiên bỏ qua ý định dẹp tiệm, anh nghĩ còn nước thì còn tát chớ có sao đâu. Bắt đầu từ ngày hôm đó, mỗi ngày anh chọn một vị trí may mắn trong nhà hàng của anh để chiêu đãi miễn phí cho một vị thực khách với tất cả sự vinh hạnh đúng nghĩa. Cái tin này được loan ra, thiên hạ ùn ùn kéo đến không ngớt. Người ta không chỉ muốn ăn miễn phí mà hình như ai nấy cũng muốn thử thời vận của họ xem có được là người may mắn trong đêm của nhà hàng nổi tiếng này hay không? Độc chiêu của Dennis bỗng nhiên hiệu nghiệm khiến nhà hàng của anh tức thì trở thành đông khách nhất khu vực tuy rằng trong giai đoạn kinh tế khó khăn này.
Mấy năm trôi qua, ông Kent đã trở thành khách thường trực và là bạn thân của Dennis. Một đêm cuối tuần, khi đợt khách cuối cùng đã ra về, được dịp Kent mời Dennis một ly rượu mạnh, ông bỗng hỏi Dennis một câu như sau:
- Anh có biết cái đêm hôm đó khi đến tiệm của anh, tôi đang nghĩ ngợi và có dự định gì trong đầu hay không?
Dennis lắc đầu, Kent gật gù nói:
- Buổi chiều ngày hôm đó tôi nhận được email của nhà tôi, bà ta cho biết là không thể nào chịu đựng thêm được cái tính say mê công việc (work-aholic) của tôi. Bà ta cho rằng dưới mắt tôi, bà ta không là gì cả, cho nên từ 6 tháng trước đó bà đã ngoại tình và hôm đó bà đã chính thức bỏ tôi để đi theo tiếng gọi của con tim. Tôi đã suy nghĩ cả một buổi chiều, ruột gan tôi rối tung lên. Đêm đó, trong đầu tôi dự định là sau khi ăn uống no say tôi sẽ trở về nhà để kết liễu sinh mạng của mình. Anh nên biết, cuộc đời tôi đã đi từ thành công này sang thành công khác, nhưng lúc đó tôi mới nhận ra là tôi đã thất bại hoàn toàn ngay từ bước đầu tiên. Kim tự tháp của tôi đã bị hỏng nền cho nên tôi chỉ còn cách là kết liễu sinh mạng của tôi thôi. Thế rồi tôi được anh chỉ cho một chỗ ngồi may mắn, tôi cảm thấy ngỡ ngàng và tưởng chừng như ông trời đang giở trò châm biếm tôi. Nhưng sau khi tôi mang nửa cái bánh tặng cho đứa bé, rồi mang một việc làm giúp cho cha đứa bé thì lúc đó tôi mới thấy là cuộc đời của tôi cũng còn có một chút xíu giá trị và hữu dụng. Cuộc đời tôi mới bắt đầu đứng lên từ lúc đó. Cho nên phải nói chính anh đã cứu lấy cuộc đời của tôi. Cám ơn Dennis, người bạn thân thiết của tôi.
Dennis cảm động ôm chầm lấy Kent, mắt anh cũng quanh tròng ngấn lệ, bây giờ anh mới hiểu ra, sự may mắn chỉ có thể đến với ta khi nào lòng ta mở rộng vị tha. Nếu như anh không nghĩ ra cách mang tặng một phần ăn miễn phí, thì có thể là cơ nghiệp của anh đã không có được như ngày hôm nay. Bản thân anh phải chăng cũng chính là một nhân vật may mắn nhất trong chuỗi cờ domino dài nhằng đang xảy ra nhan nhãn trên khắp quả địa cầu mà chúng ta đang cư ngụ.
**Nguồn : Phạm Huê dịch**

## Thuật ngữ 'nỗi buồn mùa mưa' có ý nghĩa gì ?

  * [Rối loạn cảm xúc theo mùa là gì?](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/thuat-ngu-noi-buon-mua-mua-co-y-nghia-gi#ri-lon-cm-xc-theo-ma-l-g)
  * [Làm gì để quản lý và ngăn chặn "nỗi buồn mùa mưa"?](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/thuat-ngu-noi-buon-mua-mua-co-y-nghia-gi#lm-g-qun-l-v-ngn-chn-ni-bun-ma-ma)


Tiến sĩ Sreystha Beppari, chuyên gia tư vấn tâm lý, phòng khám Apollo (Ấn Độ), cho biết cảm giác buồn bã khi trời mưa thường được gọi là "nỗi buồn mùa mưa". Đối với một số người, mùa mưa có thể mang lại cảm giác buồn hoặc mệt mỏi do mưa liên tục, theo tờ  _Indian Express._
Các nhà nghiên cứu từ Đại học Brigham Young (Mỹ) đã đưa ra thuật ngữ "nỗi buồn mùa mưa" để mô tả hiện tượng rối loạn tâm trạng mà một số người gặp phải trong mùa mưa. Nghiên cứu, được công bố trên tạp chí y tế  _Journal of Affective Disorders_ , đã làm sáng tỏ mối liên hệ giữa điều kiện thời tiết và cảm xúc.
Cô Sreystha Beppari nói thêm, "nỗi buồn mùa mưa" có thể chỉ ra sự hiện diện của chứng rối loạn cảm xúc theo mùa (SAD).
## Rối loạn cảm xúc theo mùa là gì?
Tiến sĩ Soumiya Mudgal, chuyên gia tư vấn cấp cao từ khoa Khoa học hành vi và sức khỏe tâm thần, Bệnh viện Max (Ấn Độ), cho hay một số người thường thay đổi tâm trạng nhiều hơn khi thay đổi thời tiết, do nhịp sinh học của họ.
Cô Soumiya Mudgal cho biết, khi mùa mưa bắt đầu, bạn sẽ thấy tâm trạng giảm sút.
Chuyên gia tâm lý Aishwarya Raj, nhà tâm lý học làm việc tại Delhi (Ấn Độ), cho biết "nỗi buồn mùa mưa" có thể ảnh hưởng đến mọi người theo những cách khác nhau, nhưng các triệu chứng phổ biến bao gồm cảm giác buồn bã, mệt mỏi, thờ ơ, giảm động lực, dễ cáu kỉnh, thay đổi khẩu vị, khó tập trung và cảm giác chung là tâm trạng thấp, theo  _Indian Express._
Những thay đổi về thời tiết, giảm ánh sáng mặt trời và tăng độ ẩm trong mùa mưa góp phần gây ra các triệu chứng trên.
## Làm gì để quản lý và ngăn chặn "nỗi buồn mùa mưa"?
Sau đây là một số cách quản lý cảm xúc trong mùa mưa do chuyên gia Raj chia sẻ:
  * _Tập thể dục thường xuyên có thể tăng cường tâm trạng và mức năng lượng._
  * _Dành thời gian ở ngoài trời khi có nắng có thể giúp điều chỉnh nhịp sinh học và cải thiện tâm trạng._
  * _Luôn kết nối với bạn bè, gia đình và những người thân yêu._
  * _Áp dụng chế độ ăn giàu dinh dưỡng với trái cây, rau, ngũ cốc nguyên hạt và protein nạc._
  * _Ưu tiên lịch trình ngủ đều đặn và đảm bảo giấc ngủ từ 7 - 8 giờ mỗi đêm_ , theo  _Indian Express._


  * [Rối loạn cảm xúc theo mùa là gì?](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/thuat-ngu-noi-buon-mua-mua-co-y-nghia-gi#ri-lon-cm-xc-theo-ma-l-g)
  * [Làm gì để quản lý và ngăn chặn "nỗi buồn mùa mưa"?](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/thuat-ngu-noi-buon-mua-mua-co-y-nghia-gi#lm-g-qun-l-v-ngn-chn-ni-bun-ma-ma)



## Nhứng câu nói giúp thức tỉnh khỏi khổ đau của thiền sư Thích Nhất Hạnh

1. Con người sẽ luôn đau khổ vì bị mắc kẹt trong những quan điểm cá nhân khác nhau. Chỉ khi nào giải phóng được những quan điểm đó thì chúng ta mới được tự do và hạnh phúc.
2. Thấu hiểu nỗi đau của người khác là món quà to lớn nhất mà bạn có thể trao tặng họ. Thấu hiểu là tên gọi khác của yêu thương. Nếu bạn không thể thấu hiểu, thì bạn chẳng thể yêu thương.
3. Hạnh phúc là được là chính mình. Bạn không cần phải được thừa nhận bởi người khác. Chỉ cần chính bạn thừa nhận mình là được rồi.
4. Một người tức giận là do không giải quyết được những đau buồn của mình. Họ là nạn nhân đầu tiên của sự đau buồn đó, còn bạn là người thứ hai. Hiểu được điều này, lòng từ bi sẽ nảy nở trong tim và sự tức giận sẽ tan biến. Đừng trừng phạt họ, thay vào đó, hãy nói gì đó, làm gì đó để vơi bớt nỗi đau buồn.
5. Mỗi sáng thức dậy tôi lại mỉm cười và hai mươi tư tiếng hạnh phúc sẽ ở ngay trước mắt tôi. Tôi nguyện sống trọn vẹn ý nghĩa cho từng giây và nhìn mọi điều bằng ánh mắt nhân ái.
6. Chúng ta luôn đau khổ là vì những thành kiến và mẫu thuẫn. Khi nhìn cuộc sống bằng ánh mắt cởi mở hơn, chúng ta sẽ được tự do, bình yên và chẳng còn khổ đau nữa.
7. Đôi khi niềm vui mang tới nụ cười. Nhưng cũng đôi khi, chính nụ cười mang tới niềm vui.
8. Bởi vì bạn đang sống nên mọi thứ đều có thể thành sự thật.
9. Mỗi người chúng ta nên tự hỏi mình: Tôi thật sự muốn gì? Trở thành người thành công số 1? Hay đơn giản là người hạnh phúc? Để thành công, bạn có thể phải hi sinh hạnh phúc của mình. Bạn có thể trở thành nạn nhân của thành công, nhưng bạn không bao giờ là nạn nhân của hạnh phúc.
10. Tĩnh lặng là điều cốt lõi. Chúng ta cần tĩnh lặng như chúng ta cần không khí, như cái cây cần ánh sáng mặt trời. Nếu tâm trí của chúng ta luôn chứa đầy những toan tính và lo lắng thì chúng ta chẳng thể tìm được một khoảng trống cho chính mình.

## Trà ướp hoa nhài truyền thống

Mặt trời vừa xuống núi những tia nắng tắt dần trong khoảng không của tiết trời đầu đông. Ngoài vườn hương nhài bắt đầu đã tỏa hương thơm ngọt, những bông hoa trắng muốt lưa thưa như những ánh sao lấp lánh tôi vẫn hay gọi đó là những vì sao tinh tú trong đêm. Đó cũng là loài hoa thật diệu kỳ chỉ khoe sắc và tỏa hương khi màn đêm buông xuống...
Mùi khói bếp nhà ai nhóm bằng rơm mới thu, tôi ngồi lặng người hít hà mùi hương ấy bởi lâu lắm rồi mới thấy mùi khói của rơm rạ. Hương trà nhài đang trong chảo được sấy bằng củi lửa thủ công cũng theo gió đưa hương. Tôi đưa tay mở một bản nhạc thiền du dương, nhâm nhi chén trà nóng hương nhài thơm vừa pha mới ướp thành phẩm…
Ngẫm lại mới thấy trà ướp hoa nhài thủ công truyền thống tuy vất vả mất nhiều công đoạn nhưng mang lại nhiều dư âm , đánh thức cả một thế giới tâm hồn mà người khác đang muốn kiếm tìm lại. Tinh hoa sẽ được tìm ra từ những tâm hồn đẹp, bởi uống trà là uống cả bình yên…
“Xa muôn trùng mây khói
Mờ ảo mùi sương mai,
Chén trà thơm đãi bạn
Tựa như gặp cố nhân…” 
**– Hải Trà**

## Thôi kệ (thơ)

Thôi kệ, kệ thôi, đã vậy rồi
Tiếc làm chi nữa, nước sông trôi
Ngày tháng một đi không trở lại
Sống tiếp thôi nào, các bạn tôi!
Thôi kệ, kệ thôi, luống nhọc nhằn
Than vãn có làm bớt khó khăn?
Cuộc sống của ta, ta phải bước
Ai người bước hộ, cõng ta chăng?
Thôi kệ, kệ thôi, sự yếu đau
Than thân trách phận, ích gì đâu?
Cứ đói thì ăn, đau uống thuốc
Tâm an trí lạc đặt lên đầu!
Thôi kệ, kệ thôi, những muộn phiền
Ai mà chẳng muốn sướng như tiên?
Nhưng cuộc sống này là như thế
Nếm đủ mùi đời - lẽ tự nhiên!
Thôi kệ, kệ thôi, sự bẽ bàng
Làm người nên cứ phải đa mang
Làm ơn làm phước rồi lãnh nợ
Buồn chữa lành, hay lại càng toang?
Thôi kệ, kệ thôi, cái sự đời
Trăm nghìn vạn mớ bạc như vôi
Buông bỏ hết đi mà vui sống
Nhớ nhé từ nay, KỆ, thế thôi!
**Tác giả: Vĩnh Nam**

## Không có so sánh, không có muộn phiền

Một bộ phim ngắn nhưng đã từng giành được giải Oscar. The Neighbors’ Window (Cửa sổ hàng xóm) kể về 1 câu chuyện rất bình thường, rất đời thường nhưng cũng rất ý nghĩa.
Nữ chính là bà nội trợ tên Alli. Mỗi ngày cô đều bận rộn với những công việc nhà, nấu ăn, chăm sóc ba đứa con nhỏ, dọn dẹp nhà cửa …
Một ngày nọ, Alli vô tình nhìn thấy đôi vợ chồng trẻ ở căn nhà đối diện qua ô cửa sổ. Họ nhảy múa ca hát, ôm hôn thắm thiết, lại có rất nhiều bạn bè đến chung vui.
Nhìn cảnh tượng hạnh phúc ấy, Alli không khỏi ngưỡng mộ và ganh tỵ.
Nhìn lại cảnh tượng của bản thân, hàng ngày quay cuồng với 3 đứa nhỏ, dọn dẹp, nấu ăn, làm tất cả mọi việc trong nhà đến mức không kịp thở.
Không có so sánh sẽ không có tổn thương. Cảnh tượng phía sau cánh cửa sổ đó khiến tinh thần Alli ngày càng tồi tệ.
Cho đến một hôm, cô nhìn thấy người đàn ông ở cửa sổ đối diện cạo trọc đầu nằm trên giường, sắc mặt có vẻ không được tốt lắm.
Còn người vợ mặt mày ủ rũ, thậm chí còn ôm mặt khóc vô cùng đau khổ. Hôm sau có hai người đến khiêng một cỗ thi thể rời đi.
Alli cảm thấy khó hiểu, cô đi xuống dưới lầu và gặp cô hàng xóm kia, thật không ngờ cô ấy nhận ra Alli:
“Chị sống ở tòa đối diện đúng không? 3 đứa trẻ nhà chị đáng yêu thật đấy! Em thường lén nhìn trộm sang nhà chị, vô cùng ngưỡng mộ cuộc sống vui vẻ bên ấy”.
Hóa ra, người đàn ông ở căn nhà đối diện kia mắc bệnh nan y, vì thời gian không còn nhiều nên hai vợ chồng luôn cố gắng sống vui vẻ những ngày tháng ngắn ngủi còn lại.
Thật khó có thể tưởng tượng rằng, những ngày tháng tầm thường yên ổn của mình lại trở thành cuộc sống mà người khác luôn ngưỡng mộ.
“Hạnh phúc bắt nguồn từ việc ngừng so sánh”.
Con người thường nhìn những gì mình không có và ganh tỵ hay ngưỡng mộ với những điều ấy. Điều đó gây nên những phiền muộn không đáng có.
Vậy nên thay vì nhìn cuộc sống của người khác rồi so sánh với cuộc sống của bản thân thì ta nên chăm chút cho cuộc sống của chính mình, hài lòng với cuộc sống hiện tại, chăm lo cho những người thân và cố gắng cho tương lai.
Hãy cảm nhận, vì chính những điều đơn giản đó là hạnh phúc của đời người.

## Một số khái niệm thường gặp trong Phật giáo

Giáo lý Phật Giáo được dịch từ chữ Phạn, nhiều khái niệm khó diễn đạt Việt hóa, hơn nữa những khái niệm này theo quan niệm tôn giáo nó lại có nghĩa rất rộng, vì thế nhiều khái niệm được giải thích không rõ ràng, ngay cả khi nghe các Sư Thầy giảng giải, khiến người ta khó hiểu hoặc hiểu lầm. Khi theo dõi chương trình 7 kỳ quan Phật Giáo thế giới của CNN, chúng tôi được nghe các GS chuyên nghiên cứu về Phật Giáo của các trường Đại học danh tiếng ở Mỹ, những khái niệm mà bản thân tôi còn rất mù mờ này được diễn giải một cách sáng sủa dễ hiểu. Vì vậy chúng tôi ghi lại để bạn đọc tham khảo.
**1. Niết bàn**
Niết bàn được hiểu là một trạng thái của tâm (tâm lý) khi mà người ta loại bỏ được hoàn toàn tham (tham lam), sân (sân hận, hận thù), si (mi mê, mê mờ, không hiểu biết) để sống một cuộc đời thanh thản không chịu tác động của bất kỳ yếu tố tác động nào từ bên trong hay bên ngoài dù yếu tố đó là dương tính hay âm tính.
Như vậy Niết bàn không phải là một cõi như người ta vẫn nói, vì nếu nói là cõi thì người ta sẽ hiểu nó là một nơi chốn, một địa danh nào đó và ở đâu đó giống như thiên đàng và gây ra sự hiểu lầm.
Như vậy mọi người đều có thể đạt tới niết bàn khi người ta hoàn toàn không còn quan tâm gì tới tham, sân, si. Quá trình tiến tới niết bàn gọi là giác ngộ (ngộ ra, nhận biết, thấu hiểu). Khi người ta đã giác ngộ hoàn toàn là lúc đạt tới niết bàn, không còn cảm thấy khổ đau khi bị đói kém, bị đối sử tàn tệ, bị bệnh tật đau đớn… hay bất kể sự kiện âm tính nào gặp phải trong đời sống và người đó vẫn thụ hưởng cuộc sống hiện tại một cách bình thản như nó đang xảy ra. Đó cũng là mục tiêu giáo lý của đạo Phật giúp con người vượt qua được khổ đau để sống một cuộc sống bình thản.
**2. Nghiệp**
Nghĩa đen nghiệp được hiểu là hành động và suy nghĩ, nó bao gồm cả tốt và xấu. Theo luật nhân quả nếu bạn gieo nghiệp xấu (suy nghĩ hoặc hành động xấu) thì sẽ thu được kết quả xấu, nếu bạn gieo nghiệp tốt (suy nghĩ hoặc hành động tốt) sẽ gặt hái được kết quả tốt.
**3. Thiền**
Thiền là trạng thái tĩnh tâm, tâm hướng vào bên trong bỏ qua mọi tác động từ bên ngoài.
Tập thiền là để rèn luyện trạng thái tĩnh tâm, để có thể hoàn toàn bình thản, tỉnh táo trước các biến cố, vì vậy thiền không nhất thiết phải tốn thời gian ngồi ở tư thế kiết già, tư thế này chỉ cần thiết trong giai đoạn rèn luyện ban đầu về sau người ta có thể thiền khi ở mọi tư thế, khi đang làm việc hay nghỉ ngơi. Thiền giúp cho người ta giải tỏa tâm lý căng thẳng, hóa giải mọi stress giữ được trạng thái cân bằng tâm lý trước mọi tác động từ bên trong hay bên ngoài.
Ở Nhật thiền được gọi là zen. Phật giáo vừa là triết học vừa là tôn giáo, thực chất là một hệ giáo dục rèn luyện tâm theo một triết lý triết học nhân quả và hóa giải mọi đau khổ để đạt tới trạng thái niết bàn, vì vậy thiền là một phương pháp tất yếu trong đạo Phật.
**4. Sắc và không**
“Sắc” được hiểu là vật chất có hình khối, trọng lượng (nói theo đạo Phật là có hình tướng).
“Không” được hiểu là trống rỗng, không phải là không có.
Bát nhã Tâm kinh có câu “Sắc tức thị không, không tức thị sắc”, thị nghĩa là nhìn (có thể hiểu đơn giản là cái vẫn có ở đó nhưng nhìn không thấy có, cái không nhìn thấy ở đó nhưng nó vẫn có ở đó), cái vật chất (sắc) mà lúc này chúng ta nhìn thấy đó, lúc khác nó vẫn còn đó nhưng nó không còn là cái mà chúng ta đã nhìn thấy trước đó tức là nó không còn đó (không). Ngược lại cái mà chúng ta không nhìn thấy bây giờ (không) không phải là hiện tại nó không có, nó vẫn có ở đó nhưng không phải là cái mà chúng ta nói tới nên chúng ta không nhìn thấy nó. Ví dụ chúng ta nhìn thấy một cái ô tô trước mặt đấy là “sắc”, bây giờ những người thợ tháo rời hết các bộ phận ra xếp thành một đống phụ kiện thì chúng ta không nhìn thấy cái ô tô nữa (không) như vậy chính là “sắc tức thị không” không ở đây không có nghĩa là nó không có. Bây giờ những người thợ lại lắp ráp các phụ kiện lại thành cái ô tô như vậy từ không nhìn thấy cái ô tô bây giờ lại nhìn thấy cái ô tô “không tức thị sắc” là vậy.
Có thể hiểu câu “sắc tức thị không, không tức thị sắc” cũng có nghĩa như định luật “Vật chất không tự nó sinh ra cũng không tự nó biến đi mà nó chỉ chuyển từ dạng này sang dạng khác”.
**5. Chân như**
Chân như là khái niệm Phật Giáo chỉ cái tuyệt đối cuối cùng của vạn sự, chỉ sự hằng định, ổn định, vĩnh cửu, không thay đổi. Chân như là thực tại “bất sinh bất diệt, bất cấu bất tịnh, bất tăng bất giảm”.
**6. Vô minh**
Vô minh là sự thiếu sáng suốt, chỉ sự nhận thức sai lầm về bản thân (bản ngã) và thế giới xung quanh.
**7. Vô thường**
Vô thường là sự “thay đổi”, “không chắc chắn”, “không trường tồn”. Vô thường là đặc tính chung của mọi sự vật và hiện tượng, nghĩa là mọi sự vật hiện tượng luôn biến đổi, không hằng định.
Vô thường là đặc tính chung của mọi sự sinh ra có điều kiện, tức là thành, trụ, hoại, không (sinh, trụ, dị, diệt).

## Gợi ý tên hay cho bé trai theo phẩm chất, tính cách mong muốn

  * [Tên hay cho bé trai mang ý nghĩa tốt về đạo đức](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/goi-y-ten-hay-cho-be-trai-theo-pham-chat-tinh-cach-mong-muon#tn-hay-cho-b-trai-mang-ngha-tt-v-o-c)
  * [Tên hay cho bé trai thể hiện sự thông minh, thành đạt](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/goi-y-ten-hay-cho-be-trai-theo-pham-chat-tinh-cach-mong-muon#tn-hay-cho-b-trai-th-hin-s-thng-minh-thnh-t)
  * [Tên hay cho bé trai thể hiện sự mạnh mẽ, nam tính](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/goi-y-ten-hay-cho-be-trai-theo-pham-chat-tinh-cach-mong-muon#tn-hay-cho-b-trai-th-hin-s-mnh-m-nam-tnh)
  * [Tên hay cho bé trai mang đến may mắn, bình an](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/goi-y-ten-hay-cho-be-trai-theo-pham-chat-tinh-cach-mong-muon#tn-hay-cho-b-trai-mang-n-may-mn-bnh-an)
  * [Cách đặt tên con trai theo tên đệm](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/goi-y-ten-hay-cho-be-trai-theo-pham-chat-tinh-cach-mong-muon#cch-t-tn-con-trai-theo-tn-m)


## **Tên hay cho bé trai mang ý nghĩa tốt về đạo đức**
Từ trước đến nay, mong muốn lớn nhất của bố mẹ có lẽ là con cái khỏe mạnh và sống chân thành, tử tế với mọi người. Khi chọn tên cho con, bố mẹ thường ưu ái tên hay và mang ý nghĩa tốt về đạo đức. Dưới đây là một vài gợi ý khi đặt tên cho bé trai để bố mẹ tham khảo:
  * Thiện Nhân: Con là người nhân ái, có tấm lòng yêu thương bao la
  * Đức Tài: Mong con trai của bố mẹ lớn lên sẽ là người tài năng, đức độ
  * Bảo Đức: Con chính là bảo bối của bố mẹ, mong con là người có đức tính tốt
  * Đức Việt: Con trai sẽ là người thông minh, ưu việt và có phẩm hạnh, tác phong tốt đẹp
  * Đức Uy: Mong muốn con có nhân phẩm tốt, may mắn, thành công, cuộc sống êm đềm
  * Hữu Đức: Mong con trai của bố mẹ là người có phẩm chất tốt đẹp, sống có đạo đức
  * Hữu Nghĩa: Con trai sẽ là người trọng tình nghĩa, thuận theo lẽ phải
  * Hữu Tâm: Hy vọng con trai lớn lên sẽ trở thành người có tấm lòng nhân ái, khoan dung độ lượng


## **Tên hay cho bé trai thể hiện sự thông minh, thành đạt**
Bố mẹ nào cũng mong muốn con trai yêu quý khi lớn lên sẽ là người thông minh, sự nghiệp vững vàng và cuộc sống ấm no, hạnh phúc. Dưới đây là một số tên hay cho bé trai thể hiện sự thông minh, thành đạt:
  * Đăng Khoa: Người con trai có tài, học vấn cao
  * Anh Minh: Người con trai thông minh, tài năng
  * Minh Quang: Con sẽ thông minh, tiền đồ rộng mở
  * Quang Khải: Con là chàng trai thông minh, thành đạt
  * Chí Thanh: Con trai sẽ là người thông minh, gan dạ
  * Khôi Vĩ: Mong con trai khôi ngô, đa tài và mạnh mẽ
  * Đức Tài: Con trai của bố mẹ là người tài đức vẹn toàn
  * Đăng Khoa: Hy vọng có tài năng, học cao hiểu rộng
  * Anh Tuấn: Con là người lịch lãm, thông minh, mạnh mẽ
  * Thế Bảo: Con sẽ là người thông minh, kiên định, thành đạt
  * Kiến Văn: Con trai là người hiểu biết, ý chí và sáng suốt
  * Mạnh Khôi: Mong con trai khi lớn sẽ ngôi ngô, thành đạt
  * Minh Khôi: Con trai của bố mẹ sẽ thông minh, tài giỏi
  * Nam Khánh: Con là người mạnh mẽ, có tài, thành công
  * Mạnh Hùng: Con trai sẽ mạnh mẽ, thông minh, quyết đoán
  * Công Vinh: Con là người công bằng, sáng suốt, thành công
  * Gia Huy: Hy vọng con sẽ trở thành người thông minh, tài giỏi
  * Gia Hưng: Lớn lên con sẽ là người làm rạng danh gia đình, dòng họ
  * Hữu Đạt: Con trai sẽ thực hiện được mọi ước mơ, sự nghiệp thành đạt
  * Thành Đạt: Mong muốn con trai sẽ thành công, sự nghiệp vững vàng
  * Quang Mạnh: Con là người mạnh mẽ, sáng suốt, thông minh, thành đạt
  * Quang Vinh: Con trai là người thông minh, thành đạt, làm rạng danh gia tộc
  * Toàn Thắng: Hy vọng con trai thành công, có nhiều niềm vui trong cuộc sống
  * Đức Trung: Mong con luôn quyết đoán, thông minh, thành công, đức độ
  * Việt Dũng: Chàng trai của bố mẹ khi lớn lên sẽ thông minh, dũng cảm
  * Bá Duy: Con là người thông minh, đa tài, cuộc sống hạnh phúc, giàu sang
  * Minh Nam: Mong con trai thông minh, sáng dạ, mạnh mẽ, làm nên sự nghiệp
  * Hoàng Nguyên: Con sẽ là người có tầm nhìn xa trông rộng, tiền đồ rộng mở
  * Xuân Hiếu: Con là người có hiếu, thông minh, đa tài, an nhàn, phú quý
  * Đình Trung: Mong con trai trở thành người tài giỏi, là niềm tự hào của gia đình
  * Hữu Khoa: Con là người tài trí, giỏi giang hơn người, tốt tính và sẽ thành công trong tương lai
  * Hải Đăng: Con trai của bố mẹ giống như ngọn đèn sáng giữa biển, thông minh và tài giỏi
  * Thái Hưng: Chàng trai của bố mẹ sẽ mạnh mẽ, thông minh, thành công trong mọi lĩnh vực
  * Quang Khải: Con trai sẽ là người sáng suốt, thông minh, thành công trong công việc và cuộc sống
  * Huy Hoàng: Mong con trai thông minh, sáng suốt, thành công, có tầm ảnh hưởng đến người khác
  * Thành Công: Bố mẹ mong con trai sẽ đạt được mục tiêu đề ra, thành công trong mọi lĩnh vực


## **Tên hay cho bé trai thể hiện sự mạnh mẽ, nam tính**
Nếu muốn chọn tên hay cho bé trai thể hiện sự mạnh mẽ, nam tính, bố mẹ có thể tham khảo một số tên sau:
  * Mạnh Đức: Con trai sẽ là người tài đức, mạnh mẽ
  * Quang Mạnh: Con là người mạnh mẽ, không ngại gian khó
  * Chí Kiên: Con trai sau này sẽ là người kiên cường, nghị lực
  * Anh Cường: Con trai là người mạnh mẽ, thông minh, thành đạt
  * Lâm Dũng: Người con trai có ý chí, sức mạnh tựa “núi rừng”
  * Anh Dũng: Mong con trai sẽ trở thành người mạnh mẽ, kiên cường
  * Ngọc Dũng: Mong con luôn mạnh mẽ và được mọi người yêu quý
  * Trung Dũng: Con trai của bố mẹ là người trung thành, mạnh mẽ
  * Hùng Dũng: Con sẽ là chàng trai mạnh mẽ, kiên cường, dũng cảm
  * Cao Cường: Con sẽ là người mạnh mẽ, rắn rỏi, tài giỏi hơn người
  * Hùng Cường: Hy vọng con sẽ luôn mạnh mẽ, vững vàng vượt qua mọi “sóng gió”
  * Trọng Nam: Con trai của bố mẹ chắc chắn là người mạnh mẽ, có tố chất lãnh đạo
  * Thanh Tùng: Chàng trai của bố mẹ sẽ luôn mạnh mẽ, vững vàng, sống ngay thẳng
  * Bảo Nam: Con chính là bảo bối của bố mẹ, mong muốn con sẽ mạnh mẽ, thành công
  * Chiến Thắng: Con trai của bố mẹ sẽ là người mạnh mẽ, kiên cường, luôn giành được chiến thắng
  * Trường An: Con sẽ là người mạnh mẽ, bố mẹ mong con gặp nhiều may mắn, bình an
  * Kỳ An: Con là cậu bé thông minh hơn người và mong muốn con luôn may mắn, bình an
  * Đình Nguyên: Mong con trai khỏe mạnh, có đủ ý chí và nghị lực để vượt qua mọi khó khăn


## **Tên hay cho bé trai mang đến may mắn, bình an**
Trong những tên ý nghĩa cho bé trai, bố mẹ có thể tham khảo và lựa chọn tên thể hiện sự may mắn, bình an mà Fitobimbi gợi ý dưới đây:
  * Gia An: Con sẽ là người ưu tú, luôn may mắn, bình an
  * Minh An: Mong con thông minh, sáng suốt, cuộc sống an yên
  * Bảo An: Con là bảo vật, mang đến bình an, may mắn
  * An Khải: Mong con trai của bố mẹ luôn vui vẻ, bình an
  * Thế Phương: Hy vọng con trai của bố mẹ luôn bình an, hạnh phúc
  * Hữu Phước: Con trai sau này sẽ gặp nhiều may mắn và luôn bình an
  * Minh Hùng: Hy vọng con trai luôn sáng suốt, mạnh khỏe, bình an
  * Nguyên Khang: Mong muốn con bình an, có cuộc sống giàu sang, yên ổn
  * Thanh Bình: Con sẽ là người điềm đạm, cao quý, gặp nhiều may mắn, bình an


**Tên cho con trai thể hiện sự thông minh, mạnh mẽ**
  * **Gia Hưng:** Bé sẽ là người làm hưng thịnh gia đình, dòng tộc.
  * **Gia Huy:** Bé sẽ là người làm rạng danh gia đình, dòng tộc.
  * **Quang Khải:** Thông minh, sáng suốt và luôn đạt mọi thành công trong cuộc sống.
  * **Minh Khang:** Một cái tên với ý nghĩa mạnh khỏe, sáng sủa, may mắn dành cho bé.
  * **Gia Khánh:** Bé luôn là niềm vui, niềm tự hào của gia đình.
  * **Ðăng Khoa:** Cái tên sẽ đi cùng với niềm tin về tài năng, học vấn và khoa bảng của con trong tương lai.
  * **Minh Khôi:** Sảng sủa, khôi ngô, đẹp đẽ.
  * **Trung Kiên:** Bé sẽ luôn vững vàng, có quyết tâm và có chính kiến.
  * **Tuấn Kiệt:** Bé vừa đẹp đẽ, vừa tài giỏi.
  * **Phúc Lâm:** Bé là phúc lớn trong dòng họ, gia tộc.
  * **Bảo Long:** Bé như một con rồng quý của cha mẹ, và đó là niềm tự hào trong tương lai với thành công vang dội.
  * **Anh Minh:** Thông minh, và lỗi lạc, lại vô cùng tài năng xuất chúng.
  * **Trường An:** Đó là sự mong muốn của bố mẹ để con bạn luôn có một cuộc sống an lành, và may mắn đức độ và hạnh phúc.
  * **Thiên Ân:** Nói cách khách sự ra đời của bé là ân đức của trời dành cho gia đình.
  * **Minh Anh:** Chữ Anh vốn dĩ là sự tài giỏi, thông minh, sẽ càng sáng sủa hơn khi đi cùng với chữ Minh.
  * **Quốc Bảo:** Đối với bố mẹ, bé không chỉ là báu vật mà còn hi vọng rằng bé sẽ thành đạt, vang danh khắp chốn.
  * **Ðức Bình:** Bé sẽ có sự đức độ để bình yên thiên hạ.
  * **Hùng Cường:** Bé luôn có sự mạnh mẽ và vững vàng trong cuộc sống không sơ những khó khăn mà bé có thể vượt qua tất cả.
  * **Hữu Đạt:** Bé sẽ đạt được mọi mong muốn trong cuộc sống.
  * **Minh Đức:** Chữ Đức không chỉ là đạo đức mà còn chứa chữ Tâm, tâm đức sáng sẽ giúp bé luôn là con người tốt đẹp, giỏi giang, được yêu mến.
  * **Anh Dũng:** Bé sẽ luôn là người mạnh mẽ, có chí khí để đi tới thành công.
  * **Đức Duy:** Tâm Đức sẽ luôn sáng mãi trong suốt cuộc đời con.
  * **Huy Hoàng:** Sáng suốt, thông minh và luôn tạo ảnh hưởng được tới người khác.
  * **Mạnh Hùng** : Mạnh mẽ, và quyết liệt đây là những điều bố mẹ mong muốn ở bé.
  * **Phúc Hưng:** Phúc đức của gia đình và dòng họ sẽ luôn được con gìn giữ, phát triển hưng thịnh.
  * **Hữu Nghĩa:** Bé luôn là người cư xử hào hiệp, thuận theo lẽ phải.
  * **Khôi Nguyên:** Đẹp đẽ, sáng sủa, vững vàng, điềm đạm.
  * **Ðức Thắng:** Cái Đức sẽ giúp con bạn vượt qua tất cả để đạt được thành công.
  * **Chí Thanh:** Cái tên vừa có [ý chí](https://chanhtuoi.com/y-chi-la-gi-p6839.html), có sự bền bỉ và sáng lạn.
  * **Hữu Thiện:** Cái tên đem lại sự tốt đẹp, điềm lành đến cho bé cũng như mọi người xung quanh.
  * **Phúc Thịnh:** Phúc đức của dòng họ, gia tộc ngày càng tốt đẹp.
  * **Ðức Toàn:** Chữ Đức vẹn toàn, nói lên một con người có đạo đức, giúp người giúp đời.
  * **Minh Triết:** Có trí tuệ xuất sắc, sáng suốt.
  * **Quốc Trung:** Có lòng yêu nước, thương dân, quảng đại bao la.
  * **Xuân Trường:** Mùa xuân với sức sống mới sẽ trường tồn.
  * **Anh Tuấn:** Đẹp đẽ, thông minh, lịch lãm là những điều bạn đang mong ước ở bé đó.
  * **Thanh Tùng:** Có sự vững vàng, công chính, ngay thẳng.
  * **Kiến Văn:** Bé là người có kiến thức, ý chí và sáng suốt.
  * **Quang Vinh:** Thành đạt, rạng danh cho gia đình và dòng tộc.
  * **Uy Vũ:** Con có sức mạnh và uy tín.
  * **Thiện Nhân:** Ở đây thể hiện một tấm lòng bao la, bác ái, thương người.
  * **Tấn Phát:** Bé sẽ đạt được những thành công, tiền tài, danh vọng.
  * **Chấn Phong:** Chấn là sấm sét, Phong là gió, Chấn Phong là một hình tượng biểu trưng cho sự mạnh mẽ, quyết liệt cần ở một vị tướng, vị lãnh đạo.
  * **Trường Phúc:** Phúc đức của dòng họ sẽ trường tồn.
  * **Minh Quân:** Bé sẽ là nhà lãnh đạo sáng suốt trong tương lai.
  * **Minh Quang:** Sáng sủa, thông minh, rực rỡ như tiền đồ của bé.
  * **Thái Sơn: V** ững vàng, chắc chắn cả về công danh lẫn tài lộc.
  * **Ðức Tài:** Vừa có đức, vừa có tài là điều mà cha mẹ nào cũng mong muốn ở bé.
  * **Hữu Tâm:** Tâm là trái tim, cũng là tấm lòng. Bé sẽ là người có tấm lòng tốt đẹp, khoan dung độ lượng.
  * **Xuân Trường:** Con như mùa xuân với sức sống mới sẽ trường tồn.
  * **Tuấn Kiệt** : Bé vừa đẹp đẽ, vừa tài giỏi.
  * **Anh Dũng** : Người mạnh mẽ, kiên cường, dám làm dám chịu.
  * **Anh Minh** : Thông minh, tài năng.
  * **Chí Kiên** : Ý chí mạnh mẽ, kiên cường.
  * **Chí Thanh** : Người có ý chí cao cả, dũng cảm, thông minh.
  * **Đăng Khoa** : Người có tài năng, học vấn cao.
  * **Chiến Thắng** : Con sẽ luôn đấu tranh, mạnh mẽ giành chiến thắng.
  * **Đức Tài** : Mong con sẽ trở thành một người có đức có tài vẹn toàn
  * **Đình Trung** : Người tài giỏi, mong con luôn là niềm tự hào của bố mẹ.
  * **Gia Huy** : Mong con sẽ trở thành người tài giỏi, làm rạng danh gia đình.
  * **Hải Đăng** : Một ngọn đèn sáng giữa biển đêm, thông minh, tài giỏi.
  * **Huy Hoàng:** Người thông minh, sáng suốt và luôn tạo ảnh hưởng đến mọi người.
  * **Hữu Đạt:** Con sẽ luôn thực hiện được mong muốn, ước mơ của mình.
  * **Hùng Cường** : Con sẽ là người mạnh mẽ, vững vàng trong cuộc sống.
  * **Hoàng Phi** : Một người có ý chí kiên cường, mạnh mẽ và tài giỏi.
  * **Mạnh Khôi** : Con sẽ là người khôi ngô, tuấn tú và tài giỏi.
  * **Kiến Văn** : Người có học thức và nhiều kinh nghiệm.
  * **Hữu Phước** : Mong con sau này sẽ luôn bình an, nhiều may mắn.
  * **Khôi Vĩ:** Mong sau này con sẽ trở thành người vĩ đại, mạnh mẽ và đẹp trai.
  * **Mạnh Hùng** : Một người mạnh mẽ, quyết đoán, thông minh.
  * **Minh Quang** : Người thông minh, sáng sủa, có nhiều tiền đồ.
  * **Toàn Thắng** : Mong con sẽ đạt được nhiều thành công trong cuộc sống.
  * **Tùng Quân** : Chàng trai luôn là chỗ dựa của mọi người.
  * **Thái Sơn** : Con luôn mạnh mẽ, vĩ đại như ngọn núi cao.
  * **Thành Công** : Mong con luôn thành công trong mọi lĩnh vực và đạt được các mục tiêu đặt ra.
  * **Thành Đạt** : Con sẽ thành công, làm nên sự nghiệp.
  * **Thanh Tùng** : Một chàng trai sống ngay thẳng, vững vàng, mạnh mẽ.
  * **Quang Mạnh** : Người sáng suốt, mạnh mẽ, thông minh.
  * **Nam Khánh:** Con sẽ mạnh mẽ, tài giỏi, thành công.
  * **Thái Hưng:** Chàng trai thông minh, mạnh mẽ, mong con đạt được nhiều thành công.
  * **Đức Trung:** Người có quyết đoán, thông minh, tài giỏi và mạnh mẽ.
  * **Quang Khải** : Con luôn thông minh, thành công.
  * **Minh Khôi** : Mong con luôn thông minh, tài giỏi.
  * **Gia Khánh** : Con luôn là niềm tự hào của gia đình.
  * **Trường An** : Người mạnh mẽ, may mắn, mong con luôn bình an.
  * **Việt Dũng** : Là chàng trai dũng cảm, thông minh, nổi trội.
  * **Hoàng Minh** : Mong con luôn thông minh, tiền đồ của con sẽ sáng sủa, rực rỡ.
  * **Anh Tuấn:** Chàng trai thông minh, lịch lãm, mạnh mẽ.
  * **Quốc Trung:** Người tài giỏi, chính trực, danh vang khắp chốn.
  * **Minh Nam:** Mong con luôn giỏi giang, mạnh mẽ, làm nên sự nghiệp.
  * **Thế Bảo:** Người thông minh, kiên định, có nhiều thành công trong cuộc sống.


## **Cách đặt tên con trai theo tên đệm**
  * **Tên An:** yên ổn và bình an


Ví dụ: Văn An, Hoàng An, Tường An, Nhật An, Bảo An, Thế An, Thanh An,…
  * **Tên Anh:** thông minh, nhanh nhẹn, tươi sáng, hoạt bát


Ví dụ: Hoàng Anh, Nhật Anh, Bảo Anh, Tuấn Anh, Trung Anh, Vũ Anh, Quang Anh, Việt Anh,…
  * **Tên Bách:** mạnh mẽ, vững vàng, kiên định


Ví dụ: Trung Bách, Văn Bách, Hoàng Bách, Thanh Bách, Quang Bách,…
  * **Tên Bảo:** báu vật, bảo vật


Ví dụ: Quốc Bảo, Gia Bảo, Duy Bảo, Minh Bảo,…
  * **Tên Cường:** mạnh mẽ, dũng cảm, kiên cường


Ví dụ: Hoàng Cường, Hùng Cường, Việt Cường, Văn Cường, Duy Cường,…
  * **Tên Dũng:** dũng cảm, dũng mãnh


Ví dụ: Anh Dũng, Duy Dũng, Quốc Dũng, …
  * **Tên Dương:** bao la, rộng lớn, hiền hòa


Ví dụ: Hoàng Dương, Minh Dương, Ánh Dương, Anh Dương, …
  * **Tên Duy:** thông minh, tươi sáng


Ví dụ: Thanh Duy, Thế Duy, Công Duy, Minh Duy, Văn Duy, Bảo Duy,…
  * **Tên Hải:** biển cả, rộng lớn


Ví dụ: Mạnh Hải, Công Hải, Duy Hải, Hoàng Hải, Minh Hải, Lưu Hải, Trường Hải,…
  * **Tên Hiếu** : hiếu thuận


Ví dụ: Minh Hiếu, Quang Hiếu, Trung Hiếu, Ngọc Hiếu, Duy Hiếu,..
  * **Tên Huy:** đẹp đẽ, tốt lành


Ví dụ: Anh Huy, Quang Huy, Văn Huy, Nhật Huy,…
  * **Tên Khoa** : thông minh, sáng tạo


Ví dụ: Anh Khoa, Minh Khoa, Văn Khoa, Đăng Khoa, Bảo Khoa,…
  * **Tên Long:** phú quý, mạnh mẽ


Ví dụ: Tuấn Long, Việt Long, Hoàng Long, Bảo Long, Tiến Long, Huy Long, …
  * **Tên Thành** : thành công, chí lớn


Ví dụ: Trấn Thành, Tuấn Thành, Duy Thành, Văn Thành, Việt Thành,…
  * **Tên Tùng:** vững chãi, mạnh mẽ


Ví dụ: Duy Tùng, Sơn Tùng, Văn Tùng, Hoàng Tùng, Bảo Tùng, Mai Tùng, Anh Tùng,..
  * **Tên Nam** : mạnh mẽ


Ví dụ: Đức Nam, An Nam, Sơn Nam, Hải Nam, Hoàng Nam, Khánh Nam, Ngọc Nam, Thành Nam,…
  * **Tên Phong** : Mạnh mẽ, vững vàng, phóng khoáng


Ví dụ: Hải Phong, Văn Phong, Minh Phong, Anh Phong, Huy Phong, Nguyên Phong, Thanh Phong, Dương Phong,…
  * **Tên Phúc** : phúc đức, có lộc


Ví dụ: Anh Phúc, Hoàng Phúc, Hồng Phúc, Sơn Phúc, Văn Phúc, Minh Phúc, Thiên Phúc, Quang Phúc,…
  * **Tên Quân** : giỏi giang, thành tài


Ví dụ: Anh Quân, Minh Quân, Dương Quân, Hoàng Quân, Trung Quân, Hồng Quân, Quốc Quân,…
  * **Tên Tuấn** : tài giỏi, xuất chúng


Ví dụ: Anh Tuấn, Duy Tuấn, Văn Tuấn, Bảo Tuấn, Sơn Tuấn, Minh Tuấn, Ngọc Tuấn, Quang Tuấn,…
  * **Tên Trung** : trung quân ái quốc


Ví dụ: Anh Trung, Thành Trung, Quang Trung, Duy Trung, Đức Trung, Hoàng Trung, Văn Trung, Minh Trung,…
  * **Tên Sơn** : mạnh mẽ, hùng vĩ


Ví dụ: Ngọc Sơn, Lam Sơn, Thành Sơn, Đức Sơn, Hoàng Sơn, Linh Sơn, Trí Sơn, Cao Sơn,…
  * **Tên Việt** : siêu việt, thông minh, hơn người


Ví dụ: Anh Việt, Hồng Việt, Duy Việt, Thanh Việt, Bảo Việt, Minh Việt, Hoàng Việt, Tân Việt,…
  * **Tên Vinh** : làm nên việc lớn, vinh hoa suốt đời


Ví dụ: Quang Vinh, Anh Vinh, Hoàng Vinh, Công Vinh, An Vinh, Tuấn Vinh, Nhật Vinh, Thế Vinh, Trọng Vinh,…
  * **Tên Uy** : uy vọng, danh tiếng


Ví dụ: Phúc Uy, Quốc Uy, Khải Uy, Hải uy, Thanh Uy, Chí Uy, Mạnh Uy…
  * **Tên Vũ** - Người có sức mạnh, uy quyền


Tên Vũ với các tên hay như: Uy Vũ, Đại Vũ, Đức Vũ, Đình Vũ, Minh Vũ, Thiên Vũ, Việt Vũ, Lâm Vũ…
  * **Tên Viễn** - Có tầm nhìn xa, ý tưởng, hoài bão lớn.


Tên Viễn với các tên hay như: Vũ Viễn, Quang Viễn, Lâm Viễn, Đại Viễn, Trí Viễn, Minh Viễn…
  * **Tên Trọng** - Nghĩa khí, có tài, có chí hướng lớn.


Tên Trọng với các tên hay như: Đình Trọng, Hoàng Trọng, Minh Trọng. Quốc Trọng, Lâm Trọng, Nhật Trọng…
  * **Tên Thành** - Mạnh mẽ, cương trực, tài giỏi.


Tên Thành với các tên hay như: Đạt Thành, Tuấn Thành, Viết Thành, Lê Thành, Trí Thành, Long Thành, Bá Thành, Hoàng Thành…
  * **Tên Quốc** - Mạnh mẽ, tham vọng, chí lớn.


Tên Quốc với các tên hay như: Minh Quốc, Bảo Quốc, Trí Quốc, Văn Quốc, Quang Quốc, Bá Quốc…
  * **Tên Công** - Công danh, sự nghiệp thăng tiến, thành công.


Tên Công với các tên hay như: Thành Công, Quốc Công, Minh Công, Tuấn Công, Hoàng Công, Trí Công, Việt Công, Đại Công…
  * **Tên Mạnh** - Mạnh mẽ, tài giỏi, quyết đoán


Tên Mạnh với các tên hay như: Hùng Mạnh, Hoàng Mạnh, Tiến Mạnh, Duy Mạnh, Trí Mạnh…
  * **Tên Thiên** - Có chí lớn, tài năng, mạnh mẽ.


Tên Mạnh với các tên hay như: Quốc Thiên, Văn Thiên, Trường Thiên, Hải Thiên, Thanh Thiên, Hoàng Thiên, Bảo Thiên…
  * **Tên Cương** - Cương trực, kiên định, mạnh mẽ, cá tính.


Tên Cương với các tên hay như: Bá Cương, Thế Cương, Phú Cương, Minh Cương, Tuấn Cương…
  * **Tên Tâm** - Tấm lòng cao cả, bao dung, thương người


Tên Tâm với các tên hay như: Đức Tâm, Trọng Tâm, Minh Tâm, Hoàng Tâm, Khải Tâm, Thiện Tâm, Thiên Tâm...
  * [Tên hay cho bé trai mang ý nghĩa tốt về đạo đức](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/goi-y-ten-hay-cho-be-trai-theo-pham-chat-tinh-cach-mong-muon#tn-hay-cho-b-trai-mang-ngha-tt-v-o-c)
  * [Tên hay cho bé trai thể hiện sự thông minh, thành đạt](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/goi-y-ten-hay-cho-be-trai-theo-pham-chat-tinh-cach-mong-muon#tn-hay-cho-b-trai-th-hin-s-thng-minh-thnh-t)
  * [Tên hay cho bé trai thể hiện sự mạnh mẽ, nam tính](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/goi-y-ten-hay-cho-be-trai-theo-pham-chat-tinh-cach-mong-muon#tn-hay-cho-b-trai-th-hin-s-mnh-m-nam-tnh)
  * [Tên hay cho bé trai mang đến may mắn, bình an](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/goi-y-ten-hay-cho-be-trai-theo-pham-chat-tinh-cach-mong-muon#tn-hay-cho-b-trai-mang-n-may-mn-bnh-an)
  * [Cách đặt tên con trai theo tên đệm](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/goi-y-ten-hay-cho-be-trai-theo-pham-chat-tinh-cach-mong-muon#cch-t-tn-con-trai-theo-tn-m)



## Đơn hàng của mẹ.

Mẹ tôi bắt đầu có thói quen mua hàng online kể từ đợt dịch 2 năm trước. Mẹ đặt rất nhiều thứ, từ đồ ăn, quần áo và có khi là mấy món đồ linh tinh. Mấy khi vắng nhà hoặc đang dở tay việc gì đó, mẹ thường gọi tôi xuống cửa lấy đồ hộ.
Hôm ấy, tôi mải mê chơi game trên phòng, còn mẹ thì đang cặm cụi lau dọn khu tầng dưới. Bất chợt, giọng mẹ vọng lên gọi tôi xuống nhà lấy đồ hộ. Tôi mặt nặng mày nhẹ, dậm tầng bước thật mạnh trên bậc thang. "Chắc lại đặt ba thứ linh tinh trên mạng nữa rồi" - Tôi thầm nghĩ trong bực dọc.
Lấy đơn hàng xong, tôi đóng cửa cái rầm. Định thảy thùng đồ lên ghế như thường lệ. Bỗng dưng, có chút tò mò, tôi nghía xem mẹ lại đặt thứ gì nữa đây! "THUỐC ĐAU KHỚP". Tôi sững người vài giây.
Bấy giờ, mẹ lọ mọ bước xuống nhà, mình mẩy nhễ nhại mồ hôi. Để ý mới thấy chân mẹ đang đeo đai bó gối, phảng phất trong không khí là thứ mùi của loại dầu nóng dùng để xóa bóp. Mẹ đã không còn khỏe như trước nữa... Tôi thấy mình vô tâm thật, từ lâu, tôi đã không thèm để tâm đến sức khỏe của mẹ. Tôi chẳng rõ mẹ đang mắc bệnh gì và cần uống những loại thuốc nào, cần chăm sóc thế nào để cải thiện sức khỏe. Tệ hơn là càng lớn, tôi lại càng chểnh mảng việc nhà. Tôi hay vịn cớ đi làm xa, chạy xe mệt để trì hoãn mọi thứ.
Vẫn chưa quá muộn! Thật may khi tôi sớm nhận ra vấn đề và nhìn nhận lại bản thân mình. Tôi tự nhủ mình phải dành thời gian, tình cảm và công sức cho những người thân yêu nhiều hơn.
Smiling Gecko

## Liệu pháp chữa lành (wounded healer) - đó là gì ?

**Thuật ngữ wounded healer - trị liệu chữa lành** chỉ những người sử dụng những tổn thương tâm lý hay những nỗi đau của chính mình để giúp đỡ những người có nỗi đau tương tự. Khái niệm này xuất hiện nhiều trong các văn bản về phân tâm học và tham vấn, trị liệu tâm lý.
Dù vậy, wounded healer không nhất thiết phải là một chuyên gia tâm lý, mà có thể đơn thuần chỉ những người có khả năng giúp đỡ người khác bằng những trải nghiệm cá nhân của mình. Trải nghiệm chữa lành vết thương cho người khác có thể giúp họ giải quyết các vấn đề của bản thân, từ đó tiến tới “khép miệng” chính vết thương của mình.
Nhiều nguồn tài liệu chỉ ra rằng nhà tâm thần học và phân tâm học Carl Jung là người đã khai sinh ra khái niệm này trong văn bản  _Fundamental Questions of Psychotherapy_ vào năm 1951. Tuy nhiên, trong văn bản này, khái niệm chính xác mà Jung sử dụng là “wounded physician” với hàm ý tương tự wounded healer, nhưng gói gọn trong phạm vi của công việc trị liệu và những nhà tham vấn.
Ý của Jung, về cơ bản, khi nhắc tới wounded physician là để minh họa rằng công việc trị liệu là một nỗ lực có tính đối thoại của người trị liệu với người được trị liệu và với chính bản thân mình. Theo Jung, chính nỗi đau của nhà tham vấn là công cụ và sức mạnh để họ chữa trị cho những bệnh nhân của mình.
## Tại sao wounded healer lại phổ biến?
Sự phổ biến của thuật ngữ đi kèm với sự phát triển của ngành tham vấn tâm lý hiện đại. Ngày nay, ta biết tới wounded healer một phần nhờ sự xuất hiện của các dòng sách chữa lành.
Bản thân sự tồn tại của một khái niệm như wounded healer có nhiều ý nghĩa quan trọng ở nhiều mặt. Đối với ngành trị liệu tâm lý và các nhà tham vấn, wounded healer là sự công nhận rằng tất cả mọi người đều có những tổn thương - kể cả những người đi chữa trị cho người khác. Do đó, các nhà tham vấn không nên sợ hãi, xấu hổ, hay che đậy những vết thương của mình, mà nên coi đó là thứ gắn kết mình với bệnh nhân.
Đối với những người không làm công việc tham vấn thì wounded healer cho thấy rằng ta có thể giúp đỡ người khác và giúp đỡ chính mình, bất kể bản thân có vụn vỡ tới đâu. Ở đây, có một khái niệm tương tự trong văn hóa Nhật Bản là  _kintsugi_ - chỉ việc chữa lại những chiếc bình, chiếc bát, hay chiếc cốc bằng gốm sứ đã vỡ bằng cách sử dụng hỗn hợp bột bằng vàng, bạc, và những kim loại khác để gắn liền những mảnh vỡ.

## 12 lợi ích của thiền dựa trên khoa học

  * [1. Thiền là gì?](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/12-loi-ich-cua-thien-dua-tren-khoa-hoc#1-thin-l-g)
  * [2. Lợi ích của thiền dựa trên khoa học](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/12-loi-ich-cua-thien-dua-tren-khoa-hoc#2-li-ch-ca-thin-da-trn-khoa-hc)
  * [2.1. Giảm căng thẳng](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/12-loi-ich-cua-thien-dua-tren-khoa-hoc#21-gim-cng-thng)
  * [2.2. Kiểm soát lo lắng](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/12-loi-ich-cua-thien-dua-tren-khoa-hoc#22-kim-sot-lo-lng)
  * [2.3. Thúc đẩy sức khỏe cảm xúc](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/12-loi-ich-cua-thien-dua-tren-khoa-hoc#23-thc-y-sc-khe-cm-xc)
  * [2.4. Nâng cao nhận thức về bản thân](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/12-loi-ich-cua-thien-dua-tren-khoa-hoc#24-nng-cao-nhn-thc-v-bn-thn)
  * [2.5. Kéo dài thời gian chú ý](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/12-loi-ich-cua-thien-dua-tren-khoa-hoc#25-ko-di-thi-gian-ch-)
  * [2.6. Có thể giảm mất trí nhớ ở người già](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/12-loi-ich-cua-thien-dua-tren-khoa-hoc#26-c-th-gim-mt-tr-nh-ngi-gi)
  * [2.7. Có thể tạo lòng tốt](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/12-loi-ich-cua-thien-dua-tren-khoa-hoc#27-c-th-to-lng-tt)
  * [2.8. Có thể giúp cai nghiện](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/12-loi-ich-cua-thien-dua-tren-khoa-hoc#28-c-th-gip-cai-nghin)
  * [2.9. Cải thiện giấc ngủ](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/12-loi-ich-cua-thien-dua-tren-khoa-hoc#29-ci-thin-gic-ng)
  * [2.10. Kiểm soát cơn đau](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/12-loi-ich-cua-thien-dua-tren-khoa-hoc#210-kim-sot-cn-au)
  * [2.11. Có thể làm giảm huyết áp](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/12-loi-ich-cua-thien-dua-tren-khoa-hoc#211-c-th-lm-gim-huyt-p)
  * [2.12. Có thể thực hiện ở mọi nơi](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/12-loi-ich-cua-thien-dua-tren-khoa-hoc#212-c-th-thc-hin-mi-ni)


## 1. Thiền là gì?
Thiền có thể mang lại sự bình yên cho nội tâm của bạn. Nếu căng thẳng khiến bạn lo lắng, và lo âu, hãy thử thiền định. Dành chỉ một vài phút trong thiền định cũng có thể khôi phục sự bình tĩnh và bình an nội tâm của bạn.
Trước đây, thiền giúp hiểu sâu hơn về các lực lượng thiêng liêng và huyền bí của cuộc sống. Còn ngày any, thiền được sử dụng để thư giãn và giảm căng thẳng. Thiền được coi là một loại thuốc bổ tâm và thể.
Trong khi thiền, bạn nên tập trung sự chú ý và loại bỏ luồng những suy nghĩ lộn xộn có thể khiến tâm trí bạn bị dồn nén và gây nên căng thẳng. Quá trình này có thể dẫn đến sức khỏe thể chất và cảm xúc của bạn được nâng cao. Bạn có thể sử dụng thiền để phát triển các thói quen và cảm giác có lợi khác, như tâm trạng và quan điểm tích cực, kỷ luật bản thân, thói quen lành mạnh và thậm chí tăng khả năng chịu đau.
Có 7 loại thiền phổ biến trên thế giới:
  * Thiền từ tâm
  * Thiền quét cơ thể (thư giãn tiến bộ)
  * Thiền chánh niệm
  * Thiền nhận thức hơi thở
  * Kundalini (Thiền hoạt động thể chất kết hợp các chuyển động với hít thở sâu và thần chú)
  * Thiền thiền
  * Thiền siêu việt.


## 2. Lợi ích của thiền dựa trên khoa học
### 2.1. Giảm căng thẳng
Đây được coi là một trong những lý do phổ biến nhất mà mọi người muốn bắt đầu với thiền. Thông thường, khi căng thẳng về tinh thần và thể chất sẽ làm tăng nồng độ hormone căng thẳng **cortisol**. Điều này tạo ra nhiều tác hại của căng thẳng như giải phóng những hóa chất gây viêm gọi là **cytokine-CRS**.
Những tác động này có thể làm **rối loạn giấc ngủ** của bạn, thúc đẩy **trầm cảm** và **lo lắng****,****tăng huyết áp** , góp phần gây ra mệt mỏi và suy nghĩ tiêu cực.
Trong một nghiên cứu kéo dài 8 tuần, một phong cách thiền được gọi là “thiền chánh niệm” đã làm giảm được phản ứng viêm do căng thẳng gây ra
Hơn nữa, nghiên cứu đã chỉ ra rằng thiền cũng có thể cải thiện được các triệu chứng của các tình trạng liên quan đến căng thẳng, gồm có **hội chứng ruột kích thích** , rối loạn giấc ngủ sau chấn thương và **đau cơ xơ hóa**.
### 2.2. Kiểm soát lo lắng
Thiền có thể giúp làm giảm mức độ căng thẳng, giúp giảm bớt lo lắng.
Một phân tích tổng hợp bao gồm gần 1.300 người lớn đã phát hiện ra được thiền định có thể giúp giảm lo lắng. Đáng chú ý là hiệu ứng này mạnh nhất ở những người có mức độ lo lắng cao nhất.
Ngoài ra, một nghiên cứu cho thấy 8 tuần thiền chánh niệm sẽ giúp giảm các triệu chứng lo âu ở những người mắc chứng rối loạn lo âu tổng quát , cùng với việc tăng các tuyên bố tích cực về bản thân mình và cải thiện khả năng phản ứng và đối phó với căng thẳng.
Một nghiên cứu khác ở 47 người bị đau mãn tính đã cho thấy việc hoàn thành chương trình thiền 8 tuần đã dẫn đến những cải thiện đáng kể về chứng trầm cảm, lo lắng và đau đớn trong suốt hơn 1 năm.
Ví dụ: yoga đã được chứng minh là giúp mọi người giảm căng thẳng bớt lo lắng. Điều này có thể do những lợi ích từ cả thực hành thiền định và hoạt động thể chất. Thiền cũng có thể giúp bạn kiểm soát lo lắng liên quan đến công việc. Một nghiên cứu cho thấy được những nhân viên sử dụng ứng dụng thiền chánh niệm trong vòng 8 tuần đã cải thiện được cảm giác hạnh phúc, giảm bớt sự lo lắng và căng thẳng trong công việc với những người trong nhóm đối chứng.
### 2.3. Thúc đẩy sức khỏe cảm xúc
Một số hình thức thiền có thể giúp bạn cải thiện hình ảnh của bản thân và có cái nhìn tích cực hơn về cuộc sống.
Ví dụ, một đánh giá về các phương pháp điều trị được thực hiện cho hơn 3.500 người lớn cho thấy được thiền chánh niệm đã cải thiện các triệu chứng trầm cảm.
Tương tự, một đánh giá của 18 nghiên cứu cho thấy rằng những người nhận được các liệu pháp thiền định giúp giảm các triệu chứng trầm cảm , so với những người trong nhóm đối chứng.
Một nghiên cứu khác cho thấy những người hoàn thành bài tập thiền sẽ ít có suy nghĩ tiêu cực hơn khi xem những hình ảnh tiêu cực, so với những người trong nhóm đối chứng
Hơn nữa, các hóa chất gây viêm được coi là cytokine, được giải phóng khi gặp căng thẳng, có thể ảnh hưởng đến tâm trạng, dẫn đến trầm cảm. Một đánh giá của một số nghiên cứu cho thấy được thiền cũng có thể giúp giảm trầm cảm bằng cách giảm mức độ của các hóa chất gây viêm này.
### 2.4. Nâng cao nhận thức về bản thân
Một số hình thức thiền có thể giúp bạn hiểu rõ hơn về bản thân mình, giúp bạn phát triển thành bản thân tốt nhất.
Ví dụ, thiền giúp bạn hiểu rõ hơn về bản thân và cách bạn liên hệ với những người xung quanh.
Các hình thức khác khiến bạn nhận ra được giới hạn của bản thân. Còn với thiền, bạn nhận thức được nhiều hơn về thói quen suy nghĩ của mình, và có thể hướng chúng theo các mô hình xây dựng hơn.
Một đánh giá của 27 nghiên cứu cho thấy được luyện tập thái cực quyền có thể liên quan đến việc cải thiện hiệu quả bản thân, là một thuật ngữ được dùng để mô tả niềm tin của một người vào năng lực bản thân hoặc khả năng vượt qua thử thách
Trong một nghiên cứu khác, với 153 người lớn sử dụng ứng dụng thiền chánh niệm trong vòng 2 tuần đã giảm cảm giác cô đơn và tăng cường tiếp xúc xã hội so với những con người trong nhóm đối chứng
Ngoài ra, kinh nghiệm thiền định có thể được trau dồi thêm các kỹ năng giải quyết vấn đề sáng tạo.
### 2.5. Kéo dài thời gian chú ý
Thiền tập trung chú ý cũng giống như nâng cấp khoảng thời gian chú ý của bạn. Thiền giúp tăng sức mạnh và độ bền sự chú ý của bạn.
Ví dụ, một nghiên cứu cho thấy những người nghe băng thiền đã cải thiện sự chú ý và độ chính xác trong khi hoàn thành nhiệm vụ, so với những người trong nhóm đối chứng.
Một nghiên cứu tương tự cho biết những người thường xuyên thực hành thiền định thực hiện tốt hơn nhiệm vụ thị giác và có khả năng tập trung cao hơn so với những người không có bất kỳ kinh nghiệm thiền định nào.
Hơn nữa, một đánh giá kết luận rằng thiền thậm chí còn có thể đảo ngược các mô hình trong não góp phần vào việc đầu óc lơ mơ, lo lắng và kém chú ý
Ngay cả khi bạn chỉ thiền trong một khoảng thời gian ngắn mỗi ngày cũng có thể mang lại lợi ích cho bạn. Một nghiên cứu cho thấy rằng chỉ ngồi thiền 13 phút mỗi ngày sẽ tăng cường khả năng chú ý và trí nhớ 8 tuần.
### 2.6. Có thể giảm mất trí nhớ ở người già
Cải thiện sự chú ý của suy nghĩ có thể giúp giữ cho tâm trí của bạn luôn tươi trẻ.
Kirtan Kriya là một phương pháp thiền định với sự kết hợp một câu thần chú hoặc tụng kinh với chuyển động lặp đi lặp lại của các ngón tay để tập trung suy nghĩ của bạn. Các nghiên cứu ở những người bị mất trí nhớ liên quan đến tuổi tác đã cho thấy nó cải thiện hiệu suất trong các bài kiểm tra tâm lý thần kinh.
Hơn nữa, một đánh giá đã tìm thấy bằng chứng sơ bộ rằng nhiều phong cách thiền định có thể giúp tăng cường sự chú ý, trí nhớ và tinh thần nhanh nhạy ở những tình nguyện viên đã lớn tuổi
Ngoài việc chống lại chứng mất trí nhớ do tuổi tác thông thường, thiền ít nhất có thể cải thiện một phần trí nhớ của bệnh sa sút trí tuệ. Nó cũng có thể giúp kiểm soát căng thẳng và cải thiện tinh thần với những người trong gia đình có người mắc chứng sa sút trí tuệ.
### 2.7. Có thể tạo lòng tốt
Một kiểu thiền được gọi là thiền từ tâm có thể làm tăng cảm giác và hành động tích cực đối với bản thân và người khác.
Thông qua thực hành, mọi người học cách mở rộng lòng tốt và có thể tha thứ cho trước tiên là bạn bè, sau đó là người quen, và cuối cùng là kẻ thù.
Một phân tích tổng hợp của 22 nghiên cứu về hình thức thiền này đã chứng minh khả năng của nó trong việc giúp tăng cường lòng trắc ẩn của mọi người đối với bản thân và những người khác.
Một nghiên cứu ở 100 người lớn được phân công ngẫu nhiên vào một chương trình bao gồm thiền định về lòng nhân ái cho thấy được những lợi ích này phụ thuộc vào thời gian bạn dành để thiền và hiệu quả của nó.
Nói cách khác, mọi người càng dành nhiều thời gian cho việc thực hành thiền từ tâm hàng tuần, họ càng trải qua nhiều cảm giác tích cực hơn
Một nghiên cứu khác ở 50 sinh viên đại học cho thấy thực hành thiền từ tâm 3 lần mỗi tuần giúp cải thiện cảm xúc tích cực, tương tác giữa các cá nhân và sự hiểu biết về người khác chỉ sau 4 tuần
Những lợi ích này sẽ được tích lũy theo thời gian.
### 2.8. Có thể giúp cai nghiện
Tinh thần kỷ luật của bạn phát triển thông qua thiền định có thể giúp bạn phá vỡ sự phụ thuộc bằng cách tăng cường khả năng tự kiểm soát và nhận thức được các yếu tố gây nghiện.
Nghiên cứu đã chỉ ra rằng thiền có thể giúp mọi người học cách chuyển hướng sự chú ý, quản lý cảm xúc và xung lực của họ, đồng thời tăng cường sự hiểu biết về những nguyên nhân đằng sau.
Một nghiên cứu ở 60 người được điều trị chứng rối loạn do sử dụng rượu cho thấy rằng thực hành thiền siêu việt có liên quan tới việc giảm mức độ căng thẳng, đau khổ về tâm lý, thèm rượu và sử dụng rượu sau 3 tháng
Thiền cũng có thể giúp cho bạn kiểm soát cảm giác thèm ăn. Một đánh giá của 14 nghiên cứu cho thấy thiền chánh niệm đã giúp những người tham gia giảm cảm giác thèm ăn.
### 2.9. Cải thiện giấc ngủ
Gần một nửa dân số thế giới sẽ phải vật lộn với chứng mất ngủ vào một thời điểm nào đó. Một nghiên cứu đã so sánh các chương trình thiền dựa trên chánh niệm và phát hiện ra rằng những người thiền định ngủ lâu hơn và cải thiện mức độ nghiêm trọng của chứng mất ngủ, so với những người có tình trạng mất ngủ áp dụng các biện pháp cải thiện chứng mất ngủ khác.
Thiền định thành thạo có thể giúp bạn kiểm soát hoặc chuyển hướng những suy nghĩ đua đòi hoặc chạy trốn thường dẫn đến mất ngủ. Ngoài ra, nó có thể giúp thư giãn cơ thể bạn, giải phóng căng thẳng và đưa bạn vào trạng thái yên bình, khiến bạn dễ dàng đi vào giấc ngủ và ngủ sâu hơn.
### 2.10. Kiểm soát cơn đau
Nhận thức của bạn về cơn đau có liên quan tới trạng thái tinh thần của bạn và nó có thể tăng lên trong điều kiện căng thẳng.
Một số nghiên cứu cho thấy rằng việc kết hợp thiền định vào thói quen của bạn có thể có lợi cho việc kiểm soát cơn đau.
Ví dụ, một đánh giá của 38 nghiên cứu đã kết luận rằng thiền chánh niệm có thể giúp giảm đau, cải thiện chất lượng cuộc sống và giảm các triệu chứng trầm cảm ở một số người bị đau mãn tính.
Một phân tích tổng hợp lớn về các nghiên cứu thu hút gần 3.500 người tham gia kết luận rằng thiền định có liên quan đến việc giảm đau
Những người thiền định và không thiền định đều trải qua những nguyên nhân gây đau giống nhau, nhưng những người thực hành thiền cho thấy khả năng đối phó với cơn đau cao hơn và thậm chí còn có thể giảm cảm giác đau.
### 2.11. Có thể làm giảm huyết áp
Thiền có thể cải thiện sức khỏe thể chất bằng cách giảm căng thẳng cho tim.
Theo thời gian, huyết áp cao làm cho tim hoạt động nhiều hơn để bơm máu, có thể dẫn đến chức năng tim bị kém. Huyết áp cao cũng góp phần vào việc **xơ vữa động mạch** hoặc thu hẹp động mạch, có thể dẫn tới **đau tim** và **đột quỵ**.
Một phân tích tổng hợp của 12 nghiên cứu thu hút gần 1000 người tham gia cho thấy thiền định sẽ giúp giảm huyết áp . Điều này sẽ hiệu quả hơn ở những người tình nguyện lớn tuổi và những người có huyết áp cao hơn trước khi nghiên cứu.
Một phần, thiền định kiểm soát được huyết áp bằng cách thư giãn các tín hiệu thần kinh điều phối chức năng tim, căng thẳng mạch máu và phản ứng “chiến đấu hoặc bỏ chạy” làm tăng mức độ tỉnh táo trong các tình huống căng thẳng
### 2.12. Có thể thực hiện ở mọi nơi
Bạn có thể thực hiện thiền ở mọi nơi chỉ với vài phút. Nếu bạn muốn bắt đầu thiền, hãy lựa chọn một trong hai phong cách thiền sau :
  * Thiền tập trung chú ý. Phong cách này cần tập trung sự chú ý vào một đối tượng, suy nghĩ, âm thanh hoặc hình ảnh duy nhất. Nó nhấn mạnh việc loại bỏ tâm trí của bạn khỏi những phiền muộn. Thiền có thể tập trung vào hơi thở của mình, câu thần chú hoặc âm thanh tĩnh tâm.
  * Thiền mở giám sát. Phong cách này khuyến khích việc mở rộng nhận thức về tất cả các khía cạnh của môi trường, rèn luyện tư duy và ý thức về bản thân. Nó có thể bao gồm nhận thức về những suy nghĩ, cảm xúc hoặc xung động bị đè nén.


Nếu môi trường làm việc và gia đình bạn không cho phép bạn có thể có được khoảng thời gian ở một mình ổn định và yên tĩnh, hãy cân nhắc tham gia một lớp học về thiền. Điều này cũng sẽ cải thiện cơ hội thành công của bạn do bạn sẽ nhận được sự hướng dẫn và hỗ trợ có bài bản hơn.
  * [1. Thiền là gì?](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/12-loi-ich-cua-thien-dua-tren-khoa-hoc#1-thin-l-g)
  * [2. Lợi ích của thiền dựa trên khoa học](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/12-loi-ich-cua-thien-dua-tren-khoa-hoc#2-li-ch-ca-thin-da-trn-khoa-hc)
  * [2.1. Giảm căng thẳng](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/12-loi-ich-cua-thien-dua-tren-khoa-hoc#21-gim-cng-thng)
  * [2.2. Kiểm soát lo lắng](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/12-loi-ich-cua-thien-dua-tren-khoa-hoc#22-kim-sot-lo-lng)
  * [2.3. Thúc đẩy sức khỏe cảm xúc](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/12-loi-ich-cua-thien-dua-tren-khoa-hoc#23-thc-y-sc-khe-cm-xc)
  * [2.4. Nâng cao nhận thức về bản thân](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/12-loi-ich-cua-thien-dua-tren-khoa-hoc#24-nng-cao-nhn-thc-v-bn-thn)
  * [2.5. Kéo dài thời gian chú ý](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/12-loi-ich-cua-thien-dua-tren-khoa-hoc#25-ko-di-thi-gian-ch-)
  * [2.6. Có thể giảm mất trí nhớ ở người già](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/12-loi-ich-cua-thien-dua-tren-khoa-hoc#26-c-th-gim-mt-tr-nh-ngi-gi)
  * [2.7. Có thể tạo lòng tốt](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/12-loi-ich-cua-thien-dua-tren-khoa-hoc#27-c-th-to-lng-tt)
  * [2.8. Có thể giúp cai nghiện](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/12-loi-ich-cua-thien-dua-tren-khoa-hoc#28-c-th-gip-cai-nghin)
  * [2.9. Cải thiện giấc ngủ](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/12-loi-ich-cua-thien-dua-tren-khoa-hoc#29-ci-thin-gic-ng)
  * [2.10. Kiểm soát cơn đau](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/12-loi-ich-cua-thien-dua-tren-khoa-hoc#210-kim-sot-cn-au)
  * [2.11. Có thể làm giảm huyết áp](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/12-loi-ich-cua-thien-dua-tren-khoa-hoc#211-c-th-lm-gim-huyt-p)
  * [2.12. Có thể thực hiện ở mọi nơi](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/12-loi-ich-cua-thien-dua-tren-khoa-hoc#212-c-th-thc-hin-mi-ni)



## NGÀY QUA ĐI, ĐÔI ĐIỀU ĐỌNG LẠI (Lê Thanh Hoàng)

Tiếng trẻ khóc làm ông chợt tỉnh, mới 4 giờ sáng. Ca sanh con so đêm qua đến 1 giờ sáng mới xong. Ông và cô nữ hộ sinh trực đều mệt nhoài. Nhìn lịch chợt nhớ hôm nay toàn thế giới kỷ niệm Ngày Điều Dưỡng-Hộ Sinh. Email ông nhận chiều qua, The International Council of Nurses (ICN) nêu chủ đề cho ngày kỷ niệm 12 tháng 5 năm 2023: “OUR NURSES. OUR FUTURE” .Với chủ đề này ICN xác định chúng ta đang có những người điều dưỡng, hộ sinh quý báu và những người này trong thời gian đến tất yếu góp phần quan trọng giải quyết những thách thức về vấn đề sức khỏe toàn cầu và cải thiện sức khỏe cho mọi người trên hành tinh chúng ta. ICN cũng nhấn mạnh cần học hỏi kinh nghiệm từ cơn đại dịch vừa qua để biến thành hành động trong tương lai nhằm bảo đảm người điều dưỡng, hộ sinh được bảo vệ, được tôn trọng, được đánh giá đúng giá trị của mình và được đầu tư đúng mực.
Vừa nhấp từng ngụm cafe ông nhớ lại những ngày thực tập chăm sóc người bệnh trong năm thứ hai y khoa, học cách đo huyết áp, đo nhiệt độ, chích thuốc, thay drap giường bệnh v.v...và người hướng dẫn là những chị điều dưỡng đầy kinh nghiệm về đào tạo. Nhiều bạn của ông tỏ vẻ coi thường các giờ học này, ông thì khác, vẫn cần cù thực hành cùng các chị. Cho đến nay - chỉ còn 2 năm nữa nghỉ hưu - ông càng thấm thía giá trị giờ học điều dưỡng ngày xưa, biết bao người thân trong gia đình được ông chăm sóc theo bài bản đã học, họ hài lòng. Lần đầu tiên giúp sinh cho một sản phụ, ông được chị nữ hộ sinh tận tình chỉ dẫn, chỉ dẫn từ cách theo dõi cơn co tử cung, lúc nào cho sản phụ rặn và khi cháu bé lọt lòng tốt đẹp thì câu đầu tiên phải nói với người mẹ chị ơi cháu trai và không thấy dị dạng bất thường bên ngoài, ôi, bao nhiêu nỗi đau đớn mệt nhọc trôi đi hết, chỉ còn đọng lại tiếng khóc inh ỏi của đứa con và nụ cười rạng rỡ của người mẹ, hạnh phúc nào bằng. Ông luôn nhớ: các chị chính là người thầy của ông trong bước đầu học làm bác sĩ. Năm vừa tốt nghiệp ông chính thức là bác sĩ điều trị tại một bệnh viện tỉnh, trong đêm trực ông khám một cháu bé và rất nhanh ông ghi chẩn đoán cháu bé bị tiêu chảy, chị điều dưỡng trưởng của khoa nói nhỏ với ông: theo tôi BS nên mời khoa ngoại hội chẩn, ông ngạc nhiên hỏi tại sao, chị nói BS có để ý dáng đi của cháu không, cháu đi nhưng tay phải cháu ôm hố chậu phải, dáng đi nghiêng bên phải, có thể viêm ruột thừa, tôi đã gặp vài năm trước. Tự ái, tự kiêu nhưng nhìn ánh mắt chân tình của chị ông cũng cho mời hội chẩn và cháu bé được mổ sớm ruột thừa viêm, nếu trễ bé sẽ ra sao? Những dấu hiệu lâm sàng sách vở không ghi chép nhưng chỉ có thể học được từ những người có kinh nghiệm có tình yêu thương chân thật với người bệnh với đồng nghiệp, chị là người thầy trên chặng đầu hành nghề của ông. Cách đây vài năm ông nhập viện để được mổ tuyến tiền liệt phì đại, người mổ là bạn ông, mỗi sáng ghé đến ông vài phút, thời gian còn lại ông chỉ gặp các cô điều dưỡng, ông biết họ tên, quá trình học hành và cả hoàn cảnh gia đình của họ, ông mở lòng với họ, họ sẵn lòng với ông trên mối quan hệ TÌNH NGƯỜI. Chị điều dưỡng trưởng cũng thường đến với ông, phương sách chăm sóc bệnh nhân sau mổ do chị hướng dẫn các cô điều dưỡng trong khoa từ chăm sóc vết mổ, theo dõi nước tiểu đậm lợt và chế độ ăn uống, nghỉ ngơi tại giường tránh biến chứng sau mổ, khi có bất thường chị mới báo cho bác sĩ điều trị. Nhìn sự phối hợp nhịp nhàng bình đẳng giữa điều dưỡng với điều dưỡng, giữa điều dưỡng với bác sĩ ông mới hiểu hết ý nghĩa sự phối hợp này và tất yếu người bệnh được chữa lành hoàn toàn về thể chất và tinh thần. Chị điều dưỡng trưởng tâm sự chúng tôi học KIẾN THỨC-THÁI ĐỘ-KỸ NĂNG trong thời gian ở trường nhưng trong thực tế THÁI ĐỘ HƠN TRÌNH ĐỘ. Ông thấm thía.
Có tiếng huyên náo ngoài hành lang, ông mở cửa và lặng nhìn những chiếc xe đẩy ngày thường là xe thuốc dụng cụ y khoa hôm nay lèn chặt những bó hoa, hoa tươi quá và tất nhiên cũng mắc quá. Hôm nay sẽ có bao lời có cánh, bao buổi gặp mặt chúc mừng ca tụng, ngày mai bộn bề thường nhật tiếng gọi của bác sĩ, tiếng kêu la của bệnh nhân bủa vây người điều dưỡng hộ sinh.
Vấn đề cốt lõi bác sĩ và điều dưỡng phải biết rằng hai bên có mối liên hệ bình đẳng hỗ tương để đạt kết quả điều trị, người bác sĩ bỏ đi tính tự tôn xưa nay cho rằng điều dưỡng hộ sinh chỉ là người giúp việc, điều dưỡng phải tự tin khẳng định mình là người cộng tác với bác sĩ điều trị bệnh nhân tốt.
Đôi dép không thể thiếu nhau, đúng, chỉ cần phẫu thuật viên đưa tay người điều dưỡng phụ mổ biết đặt dụng cụ gì vào tay ấy để cứu người bệnh. Người điều dưỡng hộ sinh không phải là người vô hình nhưng là người vô giá. Tri dị hành nan nhưng vẫn khả thi, ông tin thế.
Vào phòng giao ban ông bắt tay từng người, ánh mắt nụ cười ấm lòng nhau, bấy nhiêu thôi và ngày nào cũng thế, không cần hoa, không cần lời khách sáo.

## An nhiên là gì? Giá trị của sự an nhiên

  * [An nhiên là gì?](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/an-nhien-la-gi-gia-tri-cua-su-an-nhien#an-nhin-l-g)
  * [Ý nghĩa của một cuộc sống an nhiên](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/an-nhien-la-gi-gia-tri-cua-su-an-nhien#-ngha-ca-mt-cuc-sng-an-nhin)
  * [Làm sao để có được một cuộc sống an nhiên?](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/an-nhien-la-gi-gia-tri-cua-su-an-nhien#lm-sao-c-c-mt-cuc-sng-an-nhin)
  * [Quan sát và lắng nghe bản thân để khám phá nội tâm sâu sắc](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/an-nhien-la-gi-gia-tri-cua-su-an-nhien#quan-st-v-lng-nghe-bn-thn-khm-ph-ni-tm-su-sc)
  * [Ưu tiên chăm sóc sức khỏe ](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/an-nhien-la-gi-gia-tri-cua-su-an-nhien#u-tin-chm-sc-sc-khe)
  * [Nuôi dưỡng sức khỏe tinh thần](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/an-nhien-la-gi-gia-tri-cua-su-an-nhien#nui-dng-sc-khe-tinh-thn)


## **An nhiên là gì?**
An nhiên là 1 từ Hán Việt dùng để chỉ trạng thái tâm hồn và cuộc sống bình yên, tĩnh lặng, thư thái của con người.
Nghĩa của từ an nhiên cụ thể là gì? Trong tiếng Hán Việt , “an” có nghĩa là bình an, an yên, yên bình, bình thản, “nhiên” có nghĩa là tự nhiên, là thuận theo tự nhiên.
An nhiên là trạng thái tâm hồn bình thản, dẫu không quá vui cũng không buồn nhiều, có được thì cũng mất được, sẵn sàng buông bỏ, dừng đúng lúc để tìm thấy sự bình yên trong tâm hồn. Tâm thái hài hòa thì cuộc sống an nhiên. Một đời an nhiên là một đời bình thản, trải qua bao đắng cay ngọt bùi mà ngày càng ung dung tự tại không chút ưu phiền.
Chính vì thế, nhiều bậc cha mẹ đã chọn từ “an nhiên” để đặt tên cho con gái của mình, với mong muốn con có được một cuộc sống bình yên, thong thả.
## **Ý nghĩa của một cuộc sống an nhiên**
Sống an nhiên là một hành trình chứ không phải đích đến. Trong quá trình đó, bạn có thể khám phá ra được nhiều mặt tốt đẹp của tâm hồn, nhìn sâu vào bản thể và cảm nhận được sự bình an từ sâu thẳm trong tim.
Cuộc sống hiện đại cuốn con người vào guồng quay của cơm áo gạo tiền khiến những căn thẳng lo âu trở nên thường trực. Không phải giàu sang đã là sung sướng, nhất là khi ta không tìm được sự bình an từ sâu thẳm bên trong.
Khi có sự an nhiên thì trước mọi sóng gió, ta đều coi đó là cơ duyên, nhận lấy bài học và trưởng thành bước tiếp.
Hiện nay, cuộc sống an nhiên là điều rất nhiều người quan tâm và theo đuổi. An nhiên giúp chúng ta vững vàng trong cuộc sống, tự tin về chính mình, gạt bỏ những đố kỵ, thù hận, tham lam để mọi sự tốt đẹp dần theo năm tháng.
## **Làm sao để có được một cuộc sống an nhiên?**
Thử hỏi có ai là không mong muốn có một cuộc sống an nhiên, có ai muốn lúc nào cũng muộn phiền, sợ hãi, tuyệt vọng, chạy đua với đời? Tuy nhiên, việc buông bỏ tất cả những hỉ nộ ái ố đang tồn tại ngay trước mắt để có tâm thế thư thái bình thản chưa bao giờ là chuyện đơn giản với nhiều người bởi được mất phải song hành. An nhiên không phải là chỉ muốn được mà không muốn mất. Quan trọng là cách chúng ta nhìn nhận mọi sự xảy đến khi đó như thế nào.
Sau đây là một số điều bạn có thể làm để hướng dần đến sự an nhiên, bình thản:
### **Quan sát và lắng nghe bản thân để khám phá nội tâm sâu sắc**
Nhiều khi, vì không hiểu chính mình mà ta cứ loay hoay, phân vân, không dám lựa chọn, không dám hành động dẫn đến sự ngờ vực, bấp bênh trong tâm hồn. Thế nên, việc dành thời gian tìm hiểu chính mình, khám phá nội tâm bản thân có lẽ là điều đầu tiên chúng ta cần làm để đạt đến một cuộc sống an nhiên.
Khi hiểu rõ bản thân, bạn sẽ biết cái gì hợp với mình, cái gì không hợp với mình, từ đó dễ dàng đi tìm những điều làm mình hạnh phúc, thỏa mãn.
Bạn cũng sẽ hiểu rằng chính bạn mới là người quyết định cuộc sống của mình. Khó khăn không làm bạn chùn bước, quả ngọt luôn dành cho người biết cố gắng. Thất bại chỉ là tạm thời và đó là một bước để đi đến thành công. Khi đó, bạn có thể làm chủ được cảm xúc, tìm đến sự thư thái, bình an trong tâm hồn.
### **Ưu tiên chăm sóc sức khỏe**
Dù bạn có muốn đạt bất kỳ mục tiêu gì đi chăng nữa thì sức khỏe luôn là ưu tiên số một. Cơ thể khỏe mạnh là điều kiện cần cho một tinh thần phấn chấn, năng lượng tinh thần được giải phóng tối đa. Vì thế, muốn sống an nhiên, bạn nên lưu tâm chăm sóc cho cơ thể khỏe mạnh.
Ăn uống thực phẩm sạch, chế độ ăn uống phù hợp, tập thể dục thường xuyên, hạn chế thức khuya, sống tại nơi không gian thoáng đãng... đó đều là những cách giúp cơ thể dẻo dai, mạnh khỏe.
### **Nuôi dưỡng sức khỏe tinh thần**
Để cho tinh thần được phóng khoáng, chắc chắn bạn cần liên tục mở mang tri thức. Đọc sách là một cách hữu hiệu để làm giàu hiểu biết, giúp tâm hồn rộng mở, khai thông. Khi có sự hiểu biết đa chiều trên nhiều góc độ, tự bạn sẽ tìm thấy sự thấu hiểu, an nhiên.
Trên hết, biết ơn là khởi nguồn của mọi sự tốt đẹp trong cuộc đời. Khi bạn luôn biết ơn về tất cả những gì mình có, bạn sẽ luôn cảm thấy mình may mắn, hạnh phúc và an yên.
  * [An nhiên là gì?](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/an-nhien-la-gi-gia-tri-cua-su-an-nhien#an-nhin-l-g)
  * [Ý nghĩa của một cuộc sống an nhiên](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/an-nhien-la-gi-gia-tri-cua-su-an-nhien#-ngha-ca-mt-cuc-sng-an-nhin)
  * [Làm sao để có được một cuộc sống an nhiên?](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/an-nhien-la-gi-gia-tri-cua-su-an-nhien#lm-sao-c-c-mt-cuc-sng-an-nhin)
  * [Quan sát và lắng nghe bản thân để khám phá nội tâm sâu sắc](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/an-nhien-la-gi-gia-tri-cua-su-an-nhien#quan-st-v-lng-nghe-bn-thn-khm-ph-ni-tm-su-sc)
  * [Ưu tiên chăm sóc sức khỏe ](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/an-nhien-la-gi-gia-tri-cua-su-an-nhien#u-tin-chm-sc-sc-khe)
  * [Nuôi dưỡng sức khỏe tinh thần](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/an-nhien-la-gi-gia-tri-cua-su-an-nhien#nui-dng-sc-khe-tinh-thn)



## Đặt tên con gái: Gợi ý 345 cái tên ý nghĩa và nhiều may mắn (p2)

**191. Cẩm Oanh:** Theo nghĩa Hán – Việt, “cẩm” mang ý nghĩa là gấm vóc, lụa là, ý chỉ sự giàu sang, phú quý. Đặt tên con gái là Cẩm Oanh với mong muốn con mang vẻ đẹp đa quý phái, tinh tế, là người có hiểu biết sâu rộng và cuộc sống hạnh phúc.
**192. Kiều Oanh:** Tên Kiều nói về dáng điệu đáng yêu, kiều diễm của cô gái. Kiều Oanh là người con gái mang vẻ ngoài đáng yêu, đa sắc đa tài.
**193. Kim Oanh:** ý nghĩa tên Kim Oanh là loại chim oanh vàng, đặt tên gọi này cho con gái yêu với mong muốn con sau này sẽ có một cuộc sống vui vẻ, tràn ngập tiếng cười và luôn là đứa trẻ đáng yêu, có một cuộc sống giàu sang phú quý.
**194. Hoàng Oanh:** Hoàng oanh có nghĩa là con chim oanh vàng, một loài chim quý. Lấy tên Hoàng Oanh để đặt cho con gái hàm ý con xinh đẹp như chim oanh vàng, cuộc sống tự do.
**195. Phương Oanh:** Theo nghĩa Hán – Việt, “Phương” có nghĩa là hương thơm, chỉ sự lôi cuốn. Phương Oanh ý chỉ người con gái có tâm hồn lãng mạn, hiểu biết, có tài ăn nói thu hút.
**196.****Bảo Quế:** Trong dân gian “quế” là loài cây thơm ngát tượng trưng cho phú quý, sự ấm áp từ hương thơm của nó và hàm ý chỉ sự quý hiếm. Bảo Quế là tên thường được đặt cho con gái với hàm ý con chính là bảo vật của bố mẹ, con luôn được nâng niu.
**197. Hồng Quế:** Đặt tên cho con gái là Hồng Quế ý chỉ mong con là cô gái dịu dàng, dễ thích nghi để vươn lên trở thành người thành công, có chỗ đứng trong xã hội.
**198. Ngọc Quế:** Con là cô gái dịu dàng, ấm áp, là báu vật của gia đình mình.
**199. Thu Quế:** “Thu” tức mùa thu, mùa có tiết trời dịu mát nhất trong năm. Tên con gái là “Thu Quế” gợi đến đức tính thông minh, tinh anh cùng vẻ đẹp hiền hòa, dịu dàng như mùa thu.
**200. Ái Quỳnh:** Theo nghĩa Hán – Việt, chữ “quỳnh” được hiểu là viên ngọc đẹp, thanh tú. Ngoài ra, “Quỳnh” còn là loài hoa đẹp chỉ nở vào ban đêm, hoa có màu trắng tinh khôi, kiêu sa. Ái Quỳnh chỉ người con gái có tấm lòng nhân hậu, xinh đẹp, được yêu thương.
**201. Ánh Quỳnh:** Chỉ người con gái xinh đẹp, diễm lệ như đóa hoa quỳnh, thanh cao và có khí chất.
**202. Diễm Quỳnh:** Ý chỉ người con gái có dung mạo xinh đẹp, có tài năng, cuộc sống hạnh phúc.
**203. Khánh Quỳnh:** Ý người con gái có vẻ đẹp tựa như đóa hoa quỳnh, luôn gặt hái thành công.
**204. Hương Quỳnh:** Đặt tên con gái là Hương Quỳnh gợi lên vẻ đẹp thanh tao, mùi hương quyến rũ của hoa quỳnh khi nở về đêm, hàm ý con là cô gái duyên dáng, đằm thắm, dịu dàng
**205. Như Quỳnh:** Con mang vẻ đẹp dịu dàng, thanh tao như đóa hoa quỳnh.
**206. Thu Quỳnh:** Hoa quỳnh vốn dĩ đã đep, có mùi thơm quyến rũ, nở trong tiết trời mùa thu lại càng đẹp và lôi cuốn hơn. Do đó, cái tên Thu Quỳnh chỉ người con gái xinh đẹp, tính cách nhẹ nhàng.
**207. Bích Sương:** “Sương” là từ gợi đến hình ảnh giọt sương trong suốt thanh khiết, đọng lại trên những chiếc lá, mang vẻ đẹp lung linh, huyền ảo khi có ánh mặt trời soi chiếu. Ý nghĩa tên Bích Sương là con mang vẻ đẹp trong trẻo và tinh khôi như giọt sương.
**208. Mỹ Sương:** Mỹ sương là hình ảnh giọt sương đẹp đẽ với ý nghĩa thể hiện sự tinh khôi, thuần khiết, trong trẻo. Tên Mỹ Sương thường là cái tên dành riêng cho con gái với ý nhẹ nhàng và thuần khiết.
**209. Ngọc Sương:** Con mang vẻ đẹp của giọt sương buổi sớm trong veo như ngọc, hàm ý con có sự dịu dàng, đằm thắm.
**210. Thu Sương:** Giọt sương mùa thu, tên con gắn liền với thiên nhiên trong lành, tạo cảm giác nhẹ nhàng, yên ổn.
**211. Tuyết Sương:** Hai hình ảnh “tuyết” và “sương” đều đại diện cho sự trong trắng, tinh khôi và tinh khiết. Tên con gái là Tuyết Sương mang ý nghĩa con là cô gái luôn giữ được sự trong trẻo, tinh khiết.
**212. Ái Tâm:** Theo nghĩa Hán – Việt, “tâm” là tâm hồn, là tình cảm, là tinh thần. Tên Ái Tâm thể hiện mong muốn bình yên, hiền hòa, luôn hướng thiện, có phẩm chất tốt.
**213. Ánh Tâm:** Ánh là tia sáng. Tên Ánh Tâm là trái tim trong sáng, hàm nghĩa người có nhân cách đẹp đẽ.
**214. Băng Tâm:** Cái tên hàm ý chỉ người con gái có tâm hồn trong sáng, thanh cao.
**215. Bích Tâm:** Bích là ngọc bích. Bích Tâm là trái tim thuần khiết đẹp đẽ
**216. Diệu Tâm:** Diệu là kỳ ảo, Diệu Tâm là con tim hiền lành thuần phác
**217. Diệu Tâm:** Diệu là kỳ ảo, Diệu Tâm là con tim hiền lành thuần phác
**218. Hạnh Tâm:** Theo Hán – Việt, “hạnh” thứ nhất, có nghĩa là may mắn, là phúc lộc, là phước lành, nghĩa thứ hai là nói về mặt đạo đức, tính nết của con người. Đặt tên cho con gái là Hạnh Tâm ý chỉ con là người nết na, hiền hòa.
**219. Hằng Tâm:** Hằng Tâm là cái tên mang ý nghĩa con là người có trái tim nhân hậu.
**220 Hoàng Tâm:** Ý chỉ con không chỉ là người xinh đẹp mà còn là người sống có chuẩn mực đạo đức.
**221. Khánh Tâm:** Theo nghĩa Hán – Việt, “khánh” có ý nghĩa là tốt đẹp. Đặt tên con gái là Khánh Tâm ý chỉ con là người có trái tim yêu thương.
**222. Minh Tâm:** Con không chỉ xinh đẹp mà còn có một tấm lòng thánh thiện.
**223. Mỹ Tâm:** Là người con gái không chỉ xinh đẹp mà còn có một tấm lòng nhân ái bao la.
**224. Thanh Tâm:** Con là người có trái tim trong sáng, dạt dào tình yêu thương.
**225. Cát Tiên:** Theo nghĩa Hán – Việt, “tiên” có nghĩa là thoát tục, ý chỉ cuộc sống an nhàn, hướng đến điều thiện hướng đến tương lai tốt đẹp. Chữ Tiên còn thể hiện tính cách hiền dịu, thướt tha của người con gái. Cát Tiên hàm ý con là cô con gái xinh đẹp, giỏi giang, là điều may mắn nhất mà ba mẹ có được.
**226. Cẩm Tiên:** con là cô gái với nét đẹp truyền thống, được nhiều người yêu quý
**227. Bích Tiên:** “Bích” theo nghĩa Hán Việt là loại đá quý, càng được mài dũa càng đẹp. Con là một cô gái tài giỏi, đức hạnh, tài đức vẹn toàn
**228. Hồng Tiên:** cuộc sống con sẽ tràn đầy màu hồng, được nhiều người giúp đỡ, yêu thương
**229. Kiều Tiên:** con mãi luôn là co gái yêu kiề, xinh đẹp được nhiều người yêu quý
**230. Mỹ Tiên:** con mỹ miều, xinh đẹp, đoan trang, được nhiều người yêu thương.
**231. Ngọc Tiên:** con như viên ngọc quý của ba mẹ, vừa xinh đẹp giỏi giang lại có tâm hồn trong sáng như băng thanh ngọc khiết
**232. Thảo Tiên:** cô con gái của ba mẹ không những xinh đẹp, giỏi giang, còn nết na, hiền thảo với ba mẹ
**233. Thùy Tiên:** Thùy là dịu dàng. Thùy Tiên là cô gái dịu dàng, sống có chuẩn mực.
**234. Thủy Tiên:** Tên một loài hoa. Thủy Tiên là cô con gái xinh đẹp, mọi điều tốt đẹp nhất sẽ đến với con.
**235. Quỳnh Tiên: C** on là cô gái xinh đẹp như bông hoa quỳnh.
**236. Cát Tường:** Theo nghĩa Hán – Việt, “cát” (hay còn gọi là “kiết”) có nghĩa là tốt lành; “tường” có nghĩa là điều may mắn, phước lành. “Cát tường” là cụm từ dùng để nói đến những điều tốt lành, sự viên mãn, hạnh phúc. Việc đặt tên con gái là “Cát Tường” thể hiện niềm tin của ba mẹ rằng con chính là sự may mắn của gia đình, những điều tốt lành, may mắn sẽ đến với con.
**237. Bảo Thanh:** Theo nghĩa Hán – Việt, “bảo” có nghĩa là bảo bối, gia bảo; “thanh” là màu xanh, ý chỉ tuổi trẻ, sự thanh cao, thanh bạch. Cái tên Bảo Thanh mang ý nghĩa con là là đứa con quý, bố mẹ mong con lớn lên mạnh khỏe, xinh đẹp, trong sáng.
**238. Diệu Thanh:** Tên con gái là Diệu Thanh thể hiện mong ước lớn lên con không chỉ là cô gái xinh đẹp mà còn thanh cao, có khí chất.
**239. Kim Thanh:** Đặt tên cho con gái họ Nguyễn là Kim Thanh hàm ý mong con sau này sẽ có cuộc sống sung túc, ấm no.
**240. Ngọc Thanh:** Con là cô gái xinh đẹp, thanh tú như hòn viên ngọc quý.
**241. Xuân Thanh:** Xinh đẹp và căng tràn sức sống như mùa xuân. Cô gái không chỉ đẹp mà còn rất trong sáng, dịu dàng.
**242. Bích Thảo:** Theo nghĩa Hán – Việt, “thảo” có nghĩa là cỏ, “bích” là màu xanh và cũng là một loại ngọc. Do đó, tên “Thảo” thường chỉ những người có vẻ ngoài dịu dàng, mong manh, bình dị nhưng cũng rất mạnh mẽ, có khả năng sinh tồn cao. Do đó, tên con gái là “Bích Thảo” thường mang nghĩa tươi vui, tràn đầy sức sống như cỏ xanh.
**243. Dạ Thảo:** Dạ Thảo là tên một loài hoa thơm ngát, đặt cho con gái tên này gợi lên hình ảnh con là cô gái xinh đẹp, đáng yêu, tràn đầy sức sống.
**244. Huyên Thảo:** Huyên Thảo là cái tên hàm ý con sẽ là người hiếu thảo và hiền lành, có cuộc sống hạnh phúc.
**245. Nguyên Thảo:** Con là người có sức sống mạnh mẽ, luôn tươi vui, xinh đẹp và yêu kiều.
**246. Phương Thảo:** Theo nghĩa Hán – Việt, “phương” là hương thơm. Phương Thảo ý là “cỏ thơm” – một cái tên con gái đáng yêu.
**247. Quyên Thảo:** Theo nghĩa Hán – Việt, “quyên” là tên một loài chim – chim cuốc, thường thấy vào mùa hè. Đặt tên con gái là Quyên Thảo thể hiện mong muốn con luôn xinh đẹp, tràn đầy sức sống, luôn vui tươi, nhanh nhẹn.
**248. Thanh Thảo:** Cái tên gợi lên vẻ nhẹ nhàng, thanh thoát. Con là người luôn tươi tắn, dồi dào sức sống như thảm cỏ xanh.
**249. Xuân Thảo:** Xuân Thảo có nghĩa là hoa cỏ mùa xuân, ba mẹ mong con xinh đẹp, tràn trề sức sống.
**250. Hoài Thu:** Theo nghĩa Hán – Việt, “thu” có nghĩa là nhận lấy, nhận về từ nhiều nguồn; “hoài” nghĩa là nhớ, hoài niệm. Ngoài ra, “thu” còn là mùa thu – mùa chuyển tiếp từ hạ sang đông, tiết trời dịu mát. Cái tên Hoài Thu thường gợi đến hình ảnh người con gái dịu dàng, đáng yêu.
**251. Hồng Thu:** Hồng thu có ý nghĩa là mùa thu có sắc đỏ ý chỉ con là người có nhiệt huyết.
**252. Lệ Thu:** Con mang vẻ đẹp dịu dàng như mùa thu.
**253. Ngọc Thu:** “Ngọc” thể hiện người có dung mạo xinh đẹp, tỏa sáng như hòn ngọc quý, trong trắng, thuần khiết. Đặt tên con gái là Ngọc Thu hàm ý khẳng định con xinh đẹp như một viên ngọc, tính cách nhẹ nhàng ôn hòa như mùa thu.
**254. Anh Thư:** Theo nghĩa Hán – Việt, “thư” chỉ người con gái dễ thương, xinh đẹp, đoan trang, có tâm hồn trong sáng, bao dung và nhân hậu. Đặt tên con gái là Anh Thư thể hiện mong ước lớn lên con sẽ là một nữ lưu anh kiệt.
**255. Diễm Thư:** Con là cô gái xinh đẹp, kiều diễm.
**256. Kim Thư** : Ý chỉ người phụ nữ xinh đẹp, nết na, trước sau vẹn toàn.
**257. Hoàng Thư:** Con là cô gái xinh đẹp, thông tuệ và luôn hạnh phúc.
**258. Minh Thư** : Con sẽ là người phụ nữ trong sáng, chân thành không gian dối, là con người của sự chính nghĩa.
**259. Bích Thủy:** Theo nghĩa Hán – Việt, “thủy” là nước, một trong 5 yếu tố của ngũ hành, tồn tại trong tự nhiên rất cần thiết cho sự sống. Têm con gái là Bích Thủy gợi đến hình ảnh con xinh đẹp thướt tha như dòng nước trong xanh, hiền hòa.
**260. Hạnh Thủy:** Theo Hán – Việt, tên “hạnh” có nghĩa là may mắn, là phúc lộc, là phước lành, còn có nghĩa là tính nết, đức hạnh của con người. “Hạnh Thủy” là tên thường được dùng để đặt cho con gái, hàm ý chỉ người nết na, tâm tính hiền hòa, đôn hậu, phẩm chất cao đẹp.
**261. Phương Thủy:** Theo nghĩa Hán – Việt, “Phương” có nghĩa là hương thơm, “Thủy” có nghĩa là nước. “Phương Thủy” dùng để nói đến hương thơm tinh khiết, trong lành của nước. Tên “Phương Thủy” được đặt nhằm mong muốn con được xinh đẹp, trong sáng, thuần khiết, tinh tế.
**262. Thanh Thủy:** Con rất xinh đẹp, trong sáng và cuộc sống bình an.
**263. Thu Thủy:** Con luôn xinh đẹp, kiều diễm như trời thu và hạnh phúc.
**264. Bảo Trang:** Theo nghĩa Hán – Việt, “trang” không chỉ là nghiêm túc, là to lớn mà còn có nghĩa là trụ cột, là vẻ đẹp của sự mạnh mẽ, vững chắc. Đặt tên con gái họ Nguyễn là Bảo Trang mang ý nghĩa con là vật báu, là đứa con thông minh, xinh đẹp của bố mẹ.
**265. Ðoan Trang:** Cái tên thể hiện sự đẹp đẽ mà kín đáo, nhẹ nhàng, đầy nữ tính
**266. Kiều Trang:** Cái tên gợi đến hình ảnh một cô gái kiều diễm, đoan trang.
**267. Mai Trang:** “Mai” là tên một loài hoa đẹp nở vào đầu mùa xuân – hình ảnh tượng trưng cho ước mơ và hy vọng. “Mai Trang” dùng để chỉ những người có vóc dáng thanh tú, tính cách dịu dàng, đáng yêu và tràn đầy sức sống.
**268. Minh Trang:** Con là người con gái vừa thông minh, mang vẻ đẹp nhẹ nhàng.
**269. Ngọc Trang:** Cái tên gợi lên vẻ đẹp thùy mị, đoan trang cùng tâm hồn trong sáng, thanh khiết như ngọc.
**270. Bảo Trâm:** Theo từ điển Hán – Việt, “Trâm” là từ chỉ một loại phụ kiện của phụ nữ xưa, thường chỉ có những cô gái giàu sang. Do đó, Trâm là hàm ý chỉ những cô tiểu thư khuê các, sắc sảo, thông minh. Bảo Trâm hàm ý chỉ con là cô gái xinh đẹp, là bảo vật của cha mẹ.
**271. Bích Trâm** : người con gái xinh đẹp, kiều diễm, cao quý, tài giỏi, mong con được yêu thương, chiều chuộng.
**272. Kiều Trâm:** “Kiều” dùng để gợi đến dáng dấp mềm mại đáng yêu, con gái đẹp. Tên Kiều Trâm là cái tên thể hiện một cách tinh tế về một người con gái tài sắc vẹn toàn.
**273. Minh Trâm:** cô gái có dung mạo xinh đẹp, thanh cao, hiền hòa và đôn hậu.
**274. Quỳnh Trâm:** Đặt tên con gái là Quỳnh Trâm ý chỉ mong con luôn xinh đẹp, kiêu sa và hạnh phúc.
**275. Thùy Trâm** : Người con gái thùy mị, nết na, dịu dàng và có phong thái cao sang.
**276. Tuyết Trâm:** Con mang vẻ đẹp cao sang, trong sáng như bông tuyết trắng, tính cách ôn hòa, là mẫu hình lý tưởng của những cô gái.
**277. Bảo Uyên:** Theo nghĩa Hán – Việt, “uyên” là ý chỉ cô gái duyên dáng, thông minh và xinh đẹp, có tố chất cao sang, quý phái. Do đó, đặt tên con gái là Bảo Uyên ngụ ý con là cô gái thông minh, am tường mọi chuyện.
**278. Giáng Uyên:** Chữ “Giáng” không chỉ hàm ý chỉ sự khéo léo uyển chuyển mà còn mạnh mẽ khi cần thiết. Giáng Uyên mang ý nghĩa con có trí tuệ uyên thâm và có thừa sự khéo léo.
**279. Hạ Uyên:** Cái tên dịu dàng, đằm thắm, với mong muốn con gái luôn xinh xắn và đáng yêu.
**280. Lan Uyên:** Cô gái đẹp, nhu mì, tính tình hiền hòa.
**281. Mỹ Uyên:** Bố họ nguyễn đặt tên con gái là gì, tên Mỹ Uyên có ý nghĩa gì? Mỹ Uyên là cái tên gợi nên một vẻ đẹp tuyệt vời, kiêu sa, đài các.
**282. Ngọc Uyên:** Người con gái xinh đẹp, dịu dàng, chân thành và bình dị.
**283. Phương Uyên:** Con sẽ là cô gái xinh xắn và có cá tính, luôn trẻ trung và năng động.
**284. Quỳnh Uyên:** Đặt tên con gái họ Nguyễn là Quỳnh Uyên hàm ý con là cô gái xinh xắn, dễ thương, tươi tắn, rạng ngời.
**285. Thanh Uyên:** Theo nghĩa Hán – Việt, “Thanh” có nghĩa là màu xanh, tuổi trẻ, còn là sự thanh cao, trong sạch, thanh bạch. Cái tên “Thanh Uyên” gợi đến hình ảnh cô gái xinh đẹp, điềm đạm, nhẹ nhàng.
**286. Thảo Uyên:** Người con gái xinh đẹp, dịu dàng, chân thành và bình dị.
**287. Thu Uyên:** Con là cô gái đẹp có tâm hồn thơ mộng, dịu dàng và lãng mạn.
**288. Bạch Vân:** Theo nghĩa Hán – Việt, “vân” là mây, gợi cảm giác nhẹ nhàng, bồng bềnh, tự do. Bạch vân gợi hình ảnhđám mây trắng tinh khiết trên bầu trời. Đặt tên cho con gái là Bạch Vân hàm ý con xinh xắn và trong trẻo.
**289. Bích Vân:** Tên con gái là Bích Vân ý chỉ người con gái đẹp dịu dàng, cao quý, thanh tao.
**290. Cẩm Vân:** Theo nghĩa Hán – Việt, “cẩm” là một loại gỗ quý; “vân” là mây. Đặt tên con gái là “Cẩm Vân” ý chỉ người con gái nhẹ nhành, thanh tao, quý phái.
**291. Diệu Vân:** Theo nghĩa Hán – Việt, “diệu” có nghĩa là đẹp, là tuyệt diệu. Tên con gái là “Diệu Vân” mang ý nghĩa mong con xinh đẹp và có cuộc sống nhẹ nhàng, hạnh phúc.
**292. Hà Vân:** “Hà Vân” là hình ảnh của dòng sông mây trôi lững lờ trên nền trời xanh, mang dáng vẻ thanh cao, tao nhã, dịu dàng của người con gái.
**293. Hồng Vân:** Theo nghĩa gốc của từ Hán, “hồng” ý chỉ màu đỏ , mà màu đỏ vốn thể hiện cho niềm vui, sự may mắn, cát tường. Ngoài ra, hồng còn là tên gọi chung của một loại hoa đẹp. Trong văn hóa của người Việt, “Hồng” là cái tên thường được đặt cho con gái. “Hồng Vân” là đám mây hồng xinh đẹp, tươi vui, giàu sức sống.
**294. Khánh Vân:** Cái tên xuất phát từ câu thành ngữ “Đám mây mang lại niềm vui”.
**295. Kiều Vân:** Kiều Vân là cái tên ý chỉ con sẽ có cuộc sống nhẹ nhàng nhưng đầy thú vị.
**296. Mai Vân:** “Mai” là một loài hoa đẹp nở vào đầu mùa xuân – một mùa xuân tràn trề ước mơ và hy vọng. Tên “Mai” dùng để chỉ những người có vóc dáng thanh tú, luôn tràn đầy sức sống để bắt đầu mọi việc. Kết hợp với “Vân” là đám mây nhẹ nhàng, êm đềm. “Mai Vân” nghĩa là đám mây mùa xuân, nho nhã, thanh tú, luôn tràn trề ước mơ hy vọng.’
**297. Minh Vân:** Minh Vân là vầng sáng tỏa ra trong đám mây. Tên mang ý nghĩa con không chỉ xinh đẹp, thanh thoát mà còn thông minh, sáng chói
**298. Mỹ Vân:** “Mỹ” trong tiếng Hán Việt có nghĩa là xinh đẹp, tốt lành để chỉ về người con gái có dung mạo xinh đẹp như hoa. Tên “Mỹ” mang ý nghĩa mong con lớn lên xinh đẹp tâm tính tốt lành. “Mỹ Vân” có nghĩa là áng mây đẹp dịu dàng, nhẹ nhàng.’
**299. Ngọc Vân:** “Ngọc” theo tiếng Hán việt là viên ngọc, loại đá quý có nhiều màu sắc rực rỡ, sáng, trong lấp lánh, thường dùng làm đồ trang sức hay trang trí. Tên “Ngọc” thể hiện người có dung mạo xinh đẹp, tỏa sáng như hòn ngọc quý, mang ý nghĩa là trân bảo, là món quà quý giá của tạo hóa. “Ngọc Vân” là một đám mây nhiều màu sắc, rực rỡ, tỏa sáng và quý báu.
**300. Quỳnh Vân:** Theo nghĩa gốc Hán, “quỳnh” là một viên ngọc đẹp và thanh tú. Ngoài ra “Quỳnh” còn là tên một loài hoa luôn nở ngát hương vào ban đêm. Tên “Quỳnh” thể hiện người thanh tú, dung mạo xinh đẹp, bản tính khiêm nhường, thanh cao. Kết hợp với “Vân” gợi cảm giác nhẹ nhàng, thanh thoát, Quỳnh Vân mang ý nghĩa đám mây đẹp, thanh tú, đoan trang.
**301. Thanh Vân:** Bé như một áng mây trôi trên trời xanh, nhẹ nhàng, trong xanh đẹp đẽ.
**302. Thảo Vân:** Con sẽ là cô gái thảo hiền và nhẹ nhàng như đám mây trôi trên trời xanh.
**303. Thúy Vân:** Theo nghĩa Hán – Việt, “thúy” dùng để nói đến viên ngọc đẹp, ngọc quý. Thúy Vân là người con gái nhẹ nhàng như áng mây, xinh đẹp, quyền quý.
**304. Thụy Vân:** Theo tiếng Hán, “thụy” là tên chung của ngọc khuê ngọc bích, đời xưa dùng ngọc để làm tin. Ngoài ra, “thụy” còn có nghĩa là điềm lành, mong muốn cuộc sống bình an, may mắn, gặp được nhiều điều tốt lành. Thụy Vân là đám mây nhỏ, thanh cao, quý phái, nhẹ nhàng.
**305. Tuyết Vân:** Tuyết Vân là đám mây trắng, nhẹ nhàng, thanh khiết.
**306. Ái Vy:** Theo tiếng Hán – Việt, “ái” có nghĩa là yêu, chỉ người có tấm lòng lương thiện, nhân hậu, chan hòa; bên cạnh đó “ái” còn được dùng để nói về người phụ nữ có dung mạo xinh đẹp, đoan trang; “vy” nghĩa là nhỏ nhắn xin xắn. Tên con gái là Ái Vy hàm ý chỉ cô gái nhỏ nhắn, xinh đẹp, nết na, được quý mến.
**307. Bảo Vy:** Cái tên hàm ý con là cô gái nhỏ nhắn, xinh xắn, là bảo vật của bố mẹ.
**308. Bích Vy:** Tên mang ý nghĩa cô gái nhỏ nhắn có dung mạo xinh đẹp, sáng ngời.
**309. Cẩm Vy:** Tên con có ý nghĩa là cô gái nhỏ có dung mạo xinh đẹp, quý phái.
**310. Gia Vy:** Theo tiếng Hán – Việt, gia có 2 ý nghĩa là loài cỏ lau, mang lại điều tốt đẹp, phúc lành và còn là từu để chỉ gia đình, là mái nhà nơi mọi người sum vầy bên nhau. Gia Vy là cái tên chỉ người con gái đẹp, mang lại phúc lành cho gia đình.
**311. Hạ Vy:** Con sẽ luôn xinh đẹp và tràn đầy sức sống như những loài hoa nở trong mùa hạ
**312. Hiền Vy:** Theo nghĩa Hán – Việt, khi nói về người thì “hiền” có nghĩa là tốt lành, có tài có đức. Hiền Vy có nghĩa là cô gái nhỏ nhắn, xinh đẹp, tính tình ôn hòa đằm thắm, dịu dàng, thân thiện.
**313. Hồng Vy:** Theo nghĩa gốc Hán, “hồng” là ý chỉ màu đỏ , mà màu đỏ vốn thể hiện cho niềm vui, sự may mắn, cát tường. Trong văn hóa của người Việt, tên Hồng thường được đặt cho con gái vì đây còn là tên một loại hoa xinh đẹp luôn ngời sắc hương. Đặt tên con gái “Hồng Vy” mang ý nghĩa con xin xắn như đóa hồng nhỏ, rạng ngời sắc hương.
**314. Khánh Vy:** Theo tiếng Hán – Việt, “khánh” được dùng để chỉ những sự việc vui mừng, mang cảm giác hân hoan, thường dùng để diễn tả không khí vui tươi. Tên Khánh Vy hàm ý chỉ người con gái xinh đẹp, vui vẻ, luôn mang lại niềm vui cho mọi người.
**315. Lan Vy:** Cái tên thể hiện mong muốn con như loài hoa lan nhỏ nhắn, xinh xắn, tràn đầy sức sống.
**316. Mai Vy:** Con xinh đẹp, tinh khôi nhưng cũng mạnh mẽ và kiên cường như hoa mai.
**317. Ngọc Vy:** Con là viên ngọc quý, nhỏ bé nhưng giàu sức sống
**318. Nhã Vy:** Tên con là mang ý nghĩa một loại hoa vừa xinh đẹp vừa nho nhã và thanh tao
**319. Phương Vy:** Tên “Phương Vy” gợi đến nét đẹp dịu dàng, e ấp, kiêu sa, tính cách nhẹ nhàng, thùy mị, thu hút.
**320. Thanh Vy:** Cô gái nhỏ nhắn, xinh xắn, có khí chất điềm đạm, nhẹ nhàng, cao quý.
**321. Thảo Vy:** Đặt tên con gái họ Nguyễn là Thảo Vy nhằm bày tỏ mong ước con sẽ trở thành một người dịu dàng, hiếu thảo.
**322. Thục Vy:** Thục Vy là cái tên mang ý nghĩa cô gái nhỏ nhắn, xinh đẹp, hiền thục và chăm chỉ.
**323. Thùy Vy:** mẹ mong con sẽ trở thành một cô gái xinh đẹp, thùy mị
**324. Tú Vy:** Theo nghĩa Hán – Việt, “tú” là từ để chỉ ngôi sao, vì tinh tú lấp lánh chiếu sáng trên cao. Ngoài ra, “Tú” còn có nghĩa là dung mạo xinh đẹp, đáng yêu. Đặt tên con gái là Tú Vy thể hiện mong ước con là một ngôi sao sáng, xinh đẹp, đáng yêu.
**325. Tường Vy:** Cái tên gợi nhớ đến hình ảnh của một loài hoa đẹp.
**326. Yến Vy:** Ba mẹ mong con như con chim yến nhỏ nhắn, xinh xắn, thanh tú, đa tài.
**327. Ánh Xuân:** Theo nghĩa Hán – Việt, “ánh” là tia sáng. Bên cạnh đó, “xuân” mang ý nghĩa là mùa xuân và còn được hiểu là sự vui tươi, trẻ trung, xuân sắc, thường dùng để chỉ khoảng thanh xuân tươi trẻ. têm con gái là Ánh Xuân hàm ý con là người sắc sảo, tinh tế.
**328. Bảo Xuân:** Theo nghĩa Hán – Việt, “bảo” thường gắn liền với những vật trân quý như châu báu, quốc bảo. Tên “Bảo” thường để chỉ những người có cuộc sống ấm êm luôn được mọi người yêu thương, quý trọng. Bảo Xuân hàm ý con là cô gái xinh đẹp, là báo vật của cha mẹ.
**329. Kim Xuân:** Theo nghĩa Hán – Việt, “kim” có nghĩa là tiền, là vàng. Tên Kim Xuân mang ý nghĩa thể hiện sự tươi trẻ, sung túc, giàu sang, quý phái.
**330. Mỹ Xuân:** Ý chỉ người con gái xinh đẹp, thông minh, tràn trề sức sống.
**331. Ngọc Xuân:** Cái tên mang ý nghĩa con như viên ngọc quý, có sức sức sống tràn trề như mùa xuân.
**332. Quỳnh Xuân:** Cái tên mang ý nghĩa loài hoa quỳnh nở vào mùa xuân, vừa đẹp ngát hương, vừa tươi trẻ tràn đầy sức sống.
**333. Yến Xuân** : Theo nghĩa Hán – Việt, “yến” là chim én. “Yến Xuân” có nghĩa là cánh én mùa xuân, chỉ người con gái lanh lợi xinh đẹp, nhưng yêu kiều như cánh chim chao lượn trong trời xuân.
**334. Bạch Yến:** Xét theo nghĩa của từ Hán – Việt, “yến’ là từ thường được dùng để tượng trưng cho người con gái thanh tú, đa tài, vui vẻ, lạc quan, tự do; trong khi đó “bạch” là màu trắng, công minh, rõ ràng. Bạch yến cũng là tên một loài hoa có hương thơm. Đặt tên con gái là Bạch Yến ý chỉ con là người thẳng thắn, không làm hại người khác.
**335. Bảo Yến:** Đặt tên con gái là Bảo Yến ý chỉ con là người có phẩm giá, luôn mang đến những điều tốt đẹp, là báu vật của cha mẹ.
**336. Kim Yến:** theo tiếng Hán – Việt, “kim” có nghĩa là tiền, là vàng. Tên Kim Yến có nghĩa con như chú chim yến màu vàng, xinh xắn, đáng yêu và cũng có nghĩa là một người thanh tú, đa tài.
**337. Hải Yến:** Con chim biển dũng cảm vượt qua phong ba, bão táp.
**338. Hoài Yến:** Theo nghĩa Hán – Việt, “hoài” có nghĩa là nhớ, là mong chờ, trông ngóng; ngoài ra “hoài” còn có nghĩa là tấm lòng, là tâm tính, tình ý bên trong con người. Tên con gái là Hoài Yến mang hàm ý con như con chim yến xinh xắn, luôn yêu thương, trân trọng cuộc sống.
**339. Hoàng Yến** con chim yến màu vàng, xinh xắn, đáng yêu.
**340. Hồng Yến:** Ý chỉ con chim yến mang nhiều phúc lành.
**341. Kim Yến:** Con như chú chim yến màu vàng, xinh xắn, đáng yêu.
**342. Minh Yến:** Theo nghĩa Hán – Việt, bên cạnh nghĩa là ánh sáng, sự thông minh tài trí được ưa dùng khi đặt tên, “minh” còn có nghĩa chỉ các loại cây mới nhú mầm, hoặc sự vật mới bắt đầu xảy ra (bình minh) thể hiện sự khởi tạo những điều tốt đẹp. Minh Yến nghĩa là con chim yến xinh đẹp mang đến những điều tốt lành.
**343. Ngọc Yến:** loài chim quý.
**344. Phi Yến:** Con chim yến bay lượn tự do.
**345. Thu Yến:** Thu Yến con là nét đẹp dịu dàng của mùa thu, tươi vui rộn rã như chú chim yến.
Có thể bạn cũng quan tâm: [**Gợi ý tên hay cho bé trai**](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/goi-y-ten-hay-cho-be-trai-theo-pham-chat-tinh-cach-mong-muon)

## Đặt tên con gái: Gợi ý 345 cái tên ý nghĩa và nhiều may mắn

**1. Bảo An:** Con luôn được bao bọc và sống cuộc đời bình an, hạnh phúc.
**2. Gia An:** Con là người mang lại bình an, may mắn cho cả nhà.
**3. Hoài An:** Đặt tên con gái họ Nguyễn này mang nghĩa là mong muốn con có cuộc sống bình an.
**4. Tâm An:** Con sẽ có một cuộc sống thật bình an, hạnh phúc
**5. Cát Anh:** Mang ý nghĩa con là “cô gái may mắn của gia đình.
**6. Liên Anh:** Con mang vẻ đẹp và thuần khiết như một đóa hoa sen.
**7. Minh Anh:** Con là cô gái vừa có sự tinh anh vừa sắc sảo.
**8. Huyền Anh:** Hàm nghĩa con là người tinh anh, sắc sảo.
**9. Phương Anh:** Con là người con gái tài giỏi, mang lại tiếng thơm, vinh dự cho gia đình.
**10. Nguyệt Ánh:** Con như ánh trăng sáng ngời, tuyệt đẹp.
**11. Hạ Băng:** Cái tên thể hiện mong ước con có một vẻ đẹp thuần khiết như băng, sự thông minh và tài giỏi mà hiếm người nào có được.
**12. Hải Băng:** Mong ước con sẽ là người phong cách phóng khoáng nhưng bình dị, có cuộc sống an nhàn.
**13. Tuyết Băng:** Cô gái có làn da trắng như tuyết, nét xinh đẹp khó cưỡng, tâm hồn trong trắng, giàu phẩm hạnh.
**14. Ngọc Bích:** Đây là tên một loại ngọc quý, thể hiện sự thanh cao, cao quý.
**15. Thanh Bích:** Con là người có cuộc sống sang trọng, sức khỏe dồi dào luôn, sự may mắn.
**16. Bảo Châu:** Đặt tên con gái họ Nguyễn là Bảo Châu ngầm khẳng định con là viên ngọc quý của cha mẹ.
**17. Minh Châu:** Con là một cô gái có vẻ đẹp của một là viên ngọc quý, tỏa sáng muôn nơi.
**18. Ngọc Châu:** Con gái họ nguyễn đặt tên gì hay? Bạn có thể đặt tên con là Ngọc Châu – cái tên gợi đến vẻ đẹp của một viên ngọc sáng, tinh anh.
**19. Quỳnh Châu:** Quỳnh Châu hàm nghĩa là viên ngọc có sắc đỏ, là hình ảnh ẩn dụ để nói về con người cao quý, mang lại sự may mắn, thành công cho người khác.
**20. Diệp Chi:** Đối với cha mẹ con là cô gái cành vàng lá ngọc.
**21. Quỳnh Chi:** Tên con mang ý nghĩa là một bông hoa quỳnh thơm ngát.
**22. Thảo Chi:** Trong tiếng Hán, “thảo chi” là từ dùng để chỉ một loài cỏ may mắn mang lại những điều tốt đẹp nhất đến cho mọi người xung quanh. Việc đặt tên con gái là Thảo Chi cũng mang ý nghĩa tốt lành như trên.
**23. Thùy Chi:** con là cô gái hiền lành, thùy mị, nết na.
**24. Tùng Chi:** một cô gái hiền lành nhưng không kém phần cứng cỏi, vững chãi như cây tùng.
**25. Bích Diệp:** Trong nghĩa Hán – Việt “bích” là từ để chỉ viên ngọc quý, “diệp” là từ tượng trưng cho lá, ngụ ý con nhà quyền quý, dòng dõi danh giá. Vì thế, chọn tên “Bích Diệp” để đặt tên con gái họ Nguyễn là ý chỉ con là cô gái xinh đẹp, thanh tao.
**26. Ngọc Diệp:** Cô gái mang vẻ đẹp lấp lánh như viên ngọc.
**27. Kiều Diễm:** Cái tên ngụ ý về một người phụ nữ yêu kiều, tươi vui và lôi cuốn, được mọi người yêu mến.
**28. Ngọc Diễm:** Ngọc cũng chỉ những người con gái có sắc đẹp lộng lẫy, diễm là sự kiều diễm, xinh đẹp và cốt cách cao sang, vương giả.
**29. Kiều Dung:** Con có vẻ đẹp kiêu sa, lộng lẫy, yêu kiều.
**30. Hạnh Dung:** Việc chọn tên Hạnh Dung để đặt tên con gái họ Nguyễn hàm ý con là cô gái đức hạnh, nết na.
**31. Phương Dung:** Con vừa thông minh lanh lợi, và có lòng bao dung bác ái, hòa nhã với mọi người.
**32. Thu Dung:** Con mang vẻ đẹp đằm thắm của mùa thu.
**33. Thùy Dung:** Con là người thùy mị, nết na, đằm thắm.
**34. Hướng Dương:** Con gái họ nguyễn đặt tên gì hay? Bạn có thể đặt tên con là Hướng Dương – nếu bạn yêu thích hay có kỷ niệm gắn với loài hoa này. Con là cô gái thẳng thắn, chân thật, luôn hướng về ánh mặt trời.
**35. Mỹ Duyên:** Một cái tên hay với ý nghĩa xinh đẹp, duyên dáng mà bạn có thể chọn để đặt tên con gái họ Nguyễn.
**36. Huyền Diệu:** mang ý nghĩa con sẽ là người con gái có vẻ đẹp kì bí, lôi cuốn.
**37. Hương Giang:** Con mang vẻ đẹp của một dòng sông thơ mộng.
**38. Hồng Giang:** Cái tên thể hiện mong ước về một người con gái có vẻ đẹp kiều diễm, thùy mị và có ước mơ, hoài bão lớn.
**39. Lam Giang:** Con mang vẻ đẹp của một dòng sông xanh hiền hòa. Việc chọn tên Lam Giang đặt tên cho con còn bày tỏ hàm ý con khỏe mạnh, bình yên và sung túc.
**40. Thu Giang:** Con luôn xinh đẹp trong sáng tựa như dòng sông mùa thu mát lành.
**41. Ngọc Giao:** Con là viên ngọc quý của của ba mẹ.
**42. Quỳnh Giao:** Mong con luôn xinh đẹp, có cuộc sống hạnh phúc, ấm no.
**43. Bích Hà:** Cái tên thể hiện mong ước của cha mẹ về một người con xinh đẹp, dịu dàng, là niềm tự hào của gia đình.
**44. Minh Hà:** Thể hiện mong muốn con là người không chỉ thông minh mà còn xinh đẹp, có những đức tính và phẩm chất tốt.
**45. Ngọc Hà:** Việc chọn tên “Ngọc” kết hợp với “Hà” ngụ ý con là người có dung mạo xinh đẹp, dịu dàng, trong sáng.
**46. Thanh Hà:** Con là cô gái không chỉ xinh đẹp, rạng rỡ mà còn cư xử rất nhã nhẵn, ý tứ.
**47. Thu Hà:** Con là người con gái luôn dịu dàng, nhẹ nhàng như dòng sông mát lành của mùa thu.
**48. Bích Hảo:** Con xin đẹp như một viên ngọc xanh và tài giỏi.
**49. Mỹ Hảo:** Cái tên thể hiện sự hoàn mỹ, hướng tới cái đẹp, sự hoàn hảo.
**50. Nguyên Hảo:** Con gái họ nguyễn đặt tên gì hay? Gợi ý là bạn có thể đặt tên con là Nguyên Hảo. Đây là cái tên thể hiện mong ước con là tất cả những gì tốt đẹp của cha mẹ, con sẽ luôn giỏi giang, khôn khéo.
**51. Xuân Hảo:** Con luôn vui vẻ, tràn đầy sức sống như mùa xuân và giỏi giang
**52. Bảo Hân:** Thể hiện mong ước con là người vui vẻ, lạc quan, hạnh phúc, luôn yêu đời.
**53. Gia Hân:** Con chính là niềm vui của cha mẹ và thể hiện mong ước con có cuộc sống bình yên, vui vẻ, may mắn suốt đời.
**54. Bích Hạnh:** Con là điều quý giá của bố mẹ, mong con có cuộc sống hạnh phúc.
**55. Hồng Hạnh:** Con lớn lên luôn xinh đẹp, có phẩm hạnh tốt.
**56. Minh Hạnh:** “Minh Hạnh” là cái tên thể hiện mong ước con thông minh, có phẩm chất, có đức hạnh tốt.
**57. Ngân Hạnh:** Là người con ngoan hiền, hiếu thảo, đức hạnh tốt đẹp và có tương lai đầy đủ ấm no.
**58. Thúy Hạnh:** Cuộc sống hạnh phúc và mọi điều tốt đẹp nhất sẽ đến với con.
**59. Ánh Hoa:** Hoa là sự kết tinh đẹp đẽ của thế giới tự nhiên. Mỗi loài hoa thường mang một ý nghĩa khác nhau tượng trưng cho những tính cách, phẩm chất khác nhau và là biểu tượng dành cho phái đẹp. Tên Hoa thường được đặt cho nữ, chỉ những người con gái có dung mạo xinh đẹp, thu hút. Theo nghĩa Hán – Việt, “ánh” có nghĩa là chiếu sáng, phản chiếu phát ra ánh hào quang. Do đó, cái tên Ánh Hoa có nghĩa là con xinh xắn như một bông hoa, cuộc sống đầy hương sắc.
**60. Cẩm Hoa:** Theo nghĩa Hán – Việt, “cẩm” có nghĩa là gấm, cũng mang ý nghĩa là tươi đẹp, lộng lẫy, mỹ lệ. Cẩm Hoa có nghĩa là bông hoa đa màu sắc mang ý nghĩa loài hoa xinh xắn, mĩ lệ, yêu kiều.
**61. Kim Hoa:** Kim có nghĩa là tiền bạc, bền vững, kiên cố. Do đó, tên con gái là Kim Hoa có nghĩa con xinh đẹp và quý giá như một đóa hoa bằng vàng.
**62. Hoàng Hoa:** Những bông hoa rực rỡ khắp nơi trên đồng cỏ mang trong mình mệnh hoàng gia.
**63. Mai Hoa:** Con mang nét đẹp rực rỡ và tươi vui của hoa mai.
**64. Ngọc Hoa:** Con như đóa hoa, quý báu như ngọc.
**65. Quỳnh Hoa:** Đây là tên một loài hoa đẹp, có hương thơm thu hút. Đặt tên cho con gái là Quỳnh Hoa hàm ý con xinh đẹp và thu hút như đóa hoa quỳnh.
**66. Thanh Hoa:** sắc đẹp rực rỡ thanh bình
**67. Ánh Hồng:** Theo nghĩa Hán – Việt, “hồng” là ý chỉ màu đỏ, màu tượng trưng cho niềm vui, sự may mắn. Tên con gái là Ánh Hồng có ý nghĩa là con là cô gái có vẻ đẹp hoàn mỹ, rạng ngời như ánh sáng mặt trời toả sáng rực rỡ.
**68. Bích Hồng:** Theo nghĩa Hán – Việt, “bích” là một loại ngọc. Tên con gái là Bích Hồng hàm ý con như một viên ngọc sáng, mang vẻ đẹp thuần khiết, có cuộc sống thịnh vượng.
**69. Minh Hồng:** Đặt tên con gái họ Nguyễn là Minh Hồng có ý nghĩa gì? Theo nghĩa Hán – Việt, “minh” là thông minh, sáng dạ. Do đó, Minh Hồng là cái tên thể hiện mong ước con luôn thông minh, nhanh trí, có vẻ đẹp mỹ miều, hoàn mỹ.
**70. Phương Hồng:** Hồng Phương là cái tên gửi gắm ước mong con là người sống thơm thảo, đức hạnh, có cuộc sống bình yên.
**71. Thu Hồng:** Cái tên mang ý nghĩa lớn lên con sẽ là cô gái xinh đẹp, có tính cách nhẹ nhàng như thời tiết trời mùa thu mát lành.
**72. Thúy Hồng:** Theo nghĩa Hán – Việt, “thúy” nghĩa là màu xanh. Tên Thúy Hồng là cái tên hàm ý một con người vui tươi, hoạt bát, tràn đầy sức sống.
**73.** **Bích Huyền:** Con như viên ngọc bích, luôn thu hút và nổi bật.
**74. Khánh Huyền:** Theo từ điển Hán – Việt, cái tên Khánh Huyềlà hàm ý để chỉ người con gái đẹp, có sự khác biệt, thu hút.
**75. Minh Huyền:** Cái tên “Minh Huyền” có ý nghĩa là mong con sinh ra sẽ xinh đẹp, tài sắc, nhanh nhạy, hiểu biết mọi vấn đề một cách kỹ càng.
**76. Ngọc Huyền:** Ngọc Huyền được hiểu là viên ngọc màu đen, huyền ảo. Việc đặt tên con gái là Ngọc Huyền hàm ý thể hiện mong ước con là người xinh đẹp, yêu kiều, thùy mị và nết na.
**77. Phương Huyền:** Cái tên mang ý nghĩa con là tiếng thơm của cha mẹ, con là người giàu đức hạnh, có danh tiếng.
**78. Thu Huyền:** Con yêu sẽ là một cô gái xinh đẹp, dịu dàng như tiết trời mùa thu và có cuộc sống thanh nhàn, luôn thành công, sung túc về sau.
**79. Hoài Hương:** Bạn có từng thắc mắc đặt tên con gái họ Nguyễn là Hoài Hương có ý nghĩa gì? Theo nghĩa Hán – Việt, “hoài” có nghĩa là hoài bão, có chí lớn.tên con gái là Hoài Hương hàm ý chỉ mong con là người có ước mơ, có hoài bão, sự nghiệp tỏa sáng rạng rỡ.
**80. Lan Hương:** Con là một thiếu nữ dịu dàng và đáng yêu.
**81. Linh Hương:** Theo nghĩa Hán – Việt, “linh” có ý là linh thiêng, “hương” có nghĩa là hương thơm. Tên Linh Hương với ý nghĩa con là vật báu linh thiêng và tỏa hương cho đời. Ý nghĩa sâu xa là cha mẹ mong con sống có ích, là người tốt, được yêu thương.
**82. Lưu Hương:** Lưu Hương có nghĩa là làn gió thơm, thể hiện người con gái xinh đẹp nhẹ nhàng, tinh tế, thu hút.
**83. Lý Hương:** Lý Hương là cái tên để chỉ người thanh thoát, nhẹ nhàng, khiêm nhường và được mọi người yêu mến.
**84. Mai Hương:** Con gái họ nguyễn đặt tên gì hay, tên Mai Hương có ý nghĩa gì? Theo nghĩa Hán – Việt, “mai” là giọt sương, ánh nắng ban mai, ý chỉ sự tinh khôi. Mai Hương là cái tên ý chỉ concó vẻ đẹp như giọt sương ban mai, thanh khiết.
**85. Minh Hương:** Con là cô gái dịu dàng, rất thông minh và sáng suốt.
**86. Ngọc Hương:** Con mang vẻ đẹp của một viên ngọc.
**87. Thanh Hương:** Tên Thanh Hương có ý nghĩa gì? Theo nghĩa Hán – Việt, “thanh” tức là thanh tao, nhã nhẵn. Thanh Hương là cái tên con gái mang hàm ý lớn lên con là người có tâm hồn thanh tao, xinh đẹp và rạng rỡ.
**88. Quỳnh Hương:** Con như viên ngọc quý luôn xinh đẹp, đáng yêu, hòa nhã.
**89. Xuân Hương:** Xuân Hương là cái tên gợi lên sự nữ tính, hàm ý chỉ người con gái đẹp, có sức sống mơn mởn như mùa xuân.
**90. Kim Khánh:** Theo nghĩa Hán – Việt, “ngân khánh” là chỉ chiếc chuông vàng. Đặt tên con gái họ Nguyễn là Ngân Khánh hàm ý chỉ con như “chiếc chuông vàng” sẽ mang lại niềm vui cho cả gia đình.
**91. Lê Khánh:** Theo nghĩa Hán – Việt, “lê” tính từ có nghĩa là đông đảo, chỉ sự sum vầy; “khánh” thường để chỉ những người đức hạnh, tốt đẹp mang lại cảm giác vui tươi, hoan hỉ cho mọi người. Việc chọn tên Lê Khánh để đặt cho con gái hàm ý mong con sống vui tươi, hạnh phúc, đầm ấm.
**92. Mỹ Khánh:** Trong nghĩa Hán – Việt, “khánh” thường để chỉ những người đức hạnh, tốt đẹp mang lại cảm giác vui tươi, hoan hỉ. Mỹ Khánh ý chỉ một cô gái đẹp luôn mang niềm vui đến cho mọi người.
**93. Ngân Khánh:** Ngân Khánh là cái tên chỉ cô con gái có tâm hồn trong sáng, tính cách dịu dàng, tương lai sẽ có một cuộc sống sung túc, bình an.
**94. Ngọc Khánh:** Ngọc Khánh là cái tên gợi đến sự thuần khiết, trong sáng.
**95. Vân Khánh:** Cái tên con gái báo hiệu con là niềm vui của gia đình.
**96. Bích Khuê:** Theo nghĩa Hán – Việt, “Khuê” là tên của một vì sao trong thập nhị bát tú – sao Khuê và cũng là tên của một loại ngọc. Việc đặt tên con gái là Bích Khuê mang ý con có nét đẹp sáng trong, dịu dàng như ánh sao Khuê và sang trọng như ngọc.
**97. Hồng Khuê:** Theo nghĩa gốc Hán, “Hồng” là ý chỉ màu đỏ , mà màu đỏ vốn thể hiện cho niềm vui, sự may mắn, cát tường. Hồng Khuê là ý chỉ con luôn tươi vui, xinh đẹp cuốn hút như một vì sao.
**98. Minh Khuê:** Đặt tên con gái họ Nguyễn là Minh Khuê thể hiện mong muốn con sẽ luôn thông minh, giỏi giang, thành đạt và toả sáng như sao Khuê.
**99. Ngọc Khuê:** là hàm ý mong muốn người con có nét đẹp thanh tú, trong sáng và cuốn hút như sao Khuê, cốt cách cao sang.
**100. Thục Khuê:** Nhẹ nhàng, đằm thắm, tốt bụng, yêu thương mọi người.
**101. Tú Khuê:** Cô gái có vẻ đẹp thanh tú, sáng ngời, như sao khuê
**102. Bạch Lan:** Theo tiếng Hán – Việt, “lan” là tên một loài hoa đẹp, có hương thơm. Tên “Lan” thường được đặt cho con gái với mong muốn con lớn lên dung mạo xinh đẹp, tâm hồn thanh cao, tính tình dịu dàng, nhẹ nhàng. “Bạch Lan” có nghĩa là hoa lan trắng, dùng để chỉ người con gái xinh đẹp như hoa lan, tâm hồn trong sáng, được mọi người yêu quý.
**102. Bảo Lan:** Cái tên mang ý nghĩa con không chỉ xinh đẹp, duyên dáng mà còn có phẩm chất thanh cao.
**103. Bích Lan:** Lan là hoa lan thanh cao xinh đẹp. Bích là tên 1 loài ngọc đẹp, quý giá. Bích Lan có nghĩa cha mẹ mong con xinh đẹp, thanh cao và gặp may mắn
**104. Hà Lan:** Theo nghĩa Hán – Việt, “hà” có nghĩa là sông. Cái tên Hà Lan mang nghĩa con là cô gái có dung mạo xinh đẹp như hoa lan, hiền hòa như dòng sông. Bên cạnh đó, Hà Lan còn là tên 1 quốc gia xinh đẹp nổi tiếng với loài hoa tulip và cối xay gió – nơi đây có thể là nơi đánh dấu 1 kỉ niệm tình yêu đẹp của cha mẹ.
**105.** **Hoàng Lan:** Hoàng lan là tên một loài cây, hoa có hương thơm đặc biệt được ví là “hoa của các loài hoa”. Đặt tên con gái là “Hoàng Lan” mang ý nghĩa con là cô gái có dung mạo xinh đẹp, phẩm chất thanh cao, cuộc sống sung túc.
**106 Hồng Lan:** Tên đẹp dành cho người con gái với mong muốn con là người có dung mạo xinh đẹp, lôi cuốn và tinh tế.
**107. Hương Lan:** Tên cho các bé gái có ý nghĩa con sẽ là một cô gái có dung mạo như hoa, dịu dàng và đáng yêu.
**108. Kim Lan:** Kim Lan là đóa hoa lan bằng vàng, có nghĩa là cha mẹ mong con xinh đẹp, tỏa sáng và có cuộc sống giàu sang.
**109. Linh Lan:** Linh lan là tên một loài hoa màu trắng, có mùi hơm nhẹ nhàng. Đặt tên con gái họ Nguyên là Linh Lan gợi vẻ nữ tính, dịu dàng và lôi cuốn.
**110. Mai Lan:** Mai và lan là tên 2 loài hoa xuất hiện nhiều trong văn chương. Ý nghĩa tên Mai Lan là ý chỉ con mang vẻ đẹp đài các và lôi cuốn như 2 loài hoa này.
**111. Mỹ Lan:** Cái tên thể hiện mong muốn con thanh cao và xinh đẹp như đóa hoa lan.
**112. Như Lan:** Đặt tên cho con gái là Như Lan thể hiện mong muốn con có vẻ đẹp giống như loài hoa lan, thanh cao, đằm thắm.
**113. Ngọc Lan:** Ngọc Lan là tên một loài cây, có hoa ngát hương thơm.Tên con gái là Ngọc Lan hàm ý con là người có dung mạo xinh đẹp, tấm lòng thảo thơm.
**114. Quỳnh Lan:** Quỳnh là loài hoa nở về đêm có màu trắng, mùi hương rất thơm. Quỳnh Lan mang ý nghĩa con xinh đẹp, tinh tế thanh cao nhưng vẫn khiêm nhường, hiền hòa.
**115. Tuyết Lan:** Cái tên chỉ người con gái có dung mạo xinh đẹp, gương mặt thanh tú như hoa, tâm hồn trong sáng, dịu dàng, phong cách thanh lịch, tinh tế.
**116. Xuân Lan:** Con như nhành hoa lan nở vào mùa xuân, xinh đẹp và dồi dào sức sống.
**117. Bích Lâm:** Theo tiếng Hán – Việt, “lâm” có nghĩa là rừng, tựa như tính chất của rừng, tên Lâm dùng để chỉ những người bình dị, dễ gần gũi nhưng cũng đầy sức mạnh. Trong khi đó, “bích” là bức tường. Do đó, tên Bích Lâm mang ý nghĩa chỉ con người giỏi giang, mạnh mẽ.
**118. Diệu Lâm:** Diệu Lâm là cái tên chỉ người biết cân bằng cuộc sống, có lối sống tốt đẹp.
**119. Kiều Lâm:** Kiều ý nói lên vẻ đẹp mảnh mai, xinh đẹp, cuốn hút của người con gái. Kiều Lâm mang ý nghĩa chỉ nét đẹp nhu mì của người phụ nữ tài sắc vẹn toàn. Đặt tên con gái họ Nguyễn là Kiều Lâm, cha mẹ mong muốn những gì tốt lành, đẹp nhất sẽ đến với con.
**120. Ngọc Lâm:** Con là viên ngọc sáng, vô giá đối với ba mẹ.
**121. Thùy Lâm:** Cái tên Thùy Lâm mang ý nghĩa con xinh đẹp, mạnh mẽ và vững vàng như cánh rừng bạt ngàn.
**122. Mai Lâm:** Con xinh đẹp, tài năng nhưng rất giản dị.
**123. Quỳnh Lâm:** Tên con gái là Quỳnh Lâm thể hiện khao khát con mang vẻ đẹp thuần khiết như đóa hoa nhưng mạnh mẽ và lôi cuốn như một cánh rừng.
**124. Đan Lê:** “Lê” theo gốc chữ Hán có nghĩa là đông đảo, chỉ sự sum họp, đầm ấm; trong khi đó, “đan” có nghĩa là thuốc quý, là tiên đơn. Đan Lê là cái tên chỉ người con gái bình dị, dịu dàng, tâm hồn trong sáng song lại mạnh mẽ.
**125. Quỳnh Lê:** Cái tên với ý nghĩa mong con như những bông hoa quỳnh, thanh tú thịnh vượng, vun đầy.
**126. Diễm Lệ:** Theo nghĩa Hán – Việt, “diễm” là đẹp lộng lẫy. Do đó, Diễm Lệ là từ chỉ người con gái dung mạo xinh đẹp, sắc sảo.
**127. Kim Lệ:** Cái tên mang ý nghĩa người con gái xinh đẹp, tâm tính tốt, có ý chí kiên định vững vàng, thụ hưởng cuộc sống giàu sang, sung túc bền vững.
**128. Mỹ Lệ:** Cái tên thể hiện mong muốn con là người có dung mạo xinh đẹp, kiêu sa.
**129. Ngọc Lệ:** Con có dung mạo xinh đẹp, tâm hồn thanh cao trong sáng như ngọc.
**130. Nhật Lệ:** Người có dung mạo xinh đẹp, tỏa sáng như ánh mặt trời lan tỏa trên dòng sông.
**131. Thanh Lệ:** Thanh Lệ là một cái tên có ý nghĩa chỉ người con gái gia giáo nghiêm trang.
**132. Bích Liên:** Trong nghĩa Hán – Việt, “bích liên” có nghĩa là hoa sen xanh, đóa hoa mang vẻ đẹp tươi mới, bí ẩn. Đặt tên con gái là Bích Liên thể hiện mong ước con xinh đẹp như hoa và có cuộc sống bình an, hạnh phúc.
**133. Hồng Liên:** Hồng liên là đóa sen hồng, ý chỉ người thanh cao, ngay thẳng.
**134. Kim Liên:** Kim Liên là Với ý nghĩa là bông sen vàng, cái tên tượng trưng cho sự quý phái, thuần khiết.
**135. Ngọc Liên:** Ngọc Liên là cái tên để chỉ người có tâm hồn trong sáng, sống ngay thẳng dù trong bất cứ hoàn cảnh nào.
**136. Ánh Linh:** Ánh Linh có nghĩa là ánh sáng màu nhiệm, ý chỉ con sẽ mang đến một tương lai tươi mới cho gia đình.
**137. Bội Linh:** Theo nghĩa chữ Hán, “bội” nghĩa là lớn hơn gấp nhiều lần; “linh” nghĩa là thông minh lanh lợi. Tên Bội Linh mang ý nghĩa cha mẹ mong con thông minh, lanh lợi hơn người.
**138. Cẩm Linh:** Cẩm Linh là tên dành cho các bé gái mang ý nghĩa là mong con có một vẻ đẹp rực rỡ, lấp lánh và thông minh, lanh lợi.
**139. Diệu Linh:** Cái tên mang ý nghĩa là con là điều kỳ diệu của cha mẹ hoặc con là một cô bé xinh đẹp, nhanh nhẹn, hoạt bát.
**140. Ngọc Linh:** Ngọc Linh là cái tên tương đổi phổ biến, không chỉ dành đặt cho con gái họ Nguyễn, thể hiện mong muốn con xinh xắn như ngọc và có cuộc sống tốt đẹp.
**141. Phương Linh:** Trong Hán – Việt, từ “phương” có nghĩa là sự dịu dàng và hòa nhã, hương thơm ngát. Phương Linh là ý chỉ cô gái xinh đẹp, đáng yêu, tốt tính, cuộc sống gặp nhiều may mắn, bình yên.
**142. Thùy Linh:** Tên con gái thể hiện mong ước con sẽ là cô gái xinh đẹp, thông minh, lanh lợi, thùy mị và đáng yêu.
**143. Tú Linh:** Con gái họ nguyễn đặt tên gì hay? Gợi ý là bạn có thể đặt tên con là Tú Linh – ý chỉ cô gái xinh đẹp, thanh tú.
**144. Ánh Minh:** Theo nghĩa Hán – Việt, “minh” có nghĩa là ánh sáng, hay chỉ các loại cây mới nhú mầm hoặc sự vật mới bắt đầu xảy ra (bình minh). Ánh Minh ý chỉ con xinh đẹp, tỏa sáng như ánh bình minh.
**145. Hồng Minh:** Đây là cái tên phù hợp cho cả bé gái và bé trai. Đặt tên con là Hồng Minh nhằm gửi gắm khát khao con lớn lên sẽ là người thông minh, sáng suốt, luôn gặp may mắn, cuộc sống ngập tràn hạnh phúc.
**146. Ngọc Minh:** Đặt tên con gái là “Ngọc Minh” hàm ý con xinh đẹp và quý phái như một viên ngọc sáng.
**147. Nguyệt Minh:** Con có vẻ đẹp dịu dàng như ánh trăng.
**148. Thanh Minh:** Con là cô gái thông minh, sáng dạ, sống cuộc sống trong sạch thanh cao.
**149. Thu Minh:** Một cái tên đẹp dùng để đặt cho các bé gái với ý nghĩa con sẽ luôn tươi đẹp và dịu dàng như ánh sáng mùa thu.
**150. Thúy Minh:** Cái tên mang ý nghĩa xinh đẹp, sáng dạ thông minh.
**151. Bích Nga:** Theo nghĩa Hán – Việt, “nga” là từ dùng để chỉ người con gái xinh đẹp, thướt tha; “bích” là tên một loại ngọc quý, trong sáng. Do đó, cái tên Bích Nga thể hiện hàm ý con xinh đẹp như tiên, trong sáng như ngọc.
**152. Hằng Nga:** Con mang nét đẹp của chị Hằng trong sáng, rạng ngời.
**153. Hồng Nga:** Cái tên mang ý nghĩa con xinh đẹp, luôn vui tươi, tràn đầy sức sống.
**154. Phương Nga:** Bố họ nguyễn đặt tên con gái là gì? Bạn có thể đặt tên con là Phương Nga – đây là cái tên hàm ý con sẽ tạo nên tiếng thơm cùng những điều tốt đẹp cho đời.
**155. Ngọc Nga:** Con xinh đẹp, trong sáng thuần khiết như ngọc và luôn may mắn.
**156. Quỳnh Nga:** Con xinh đẹp, tính tình khiêm tốn, hiền hòa, thuần khiết.
**157. Thanh Nga:** Cái tên thể hiện ý mong muốn con là cô gái xinh đẹp và thanh tú.
**158. Tố Nga:** Từ thường dùng trong văn chương cổ ý chỉ một cô gái yểu điệu thục nữ, hiền hậu.
**159. Ái Ngân:** Ái Ngân có nghĩa con là báu vật của ba mẹ, mong muốn con gái xinh đẹp, đáng yêu và có tấm lòng nhân ái.
**160. Bích Ngân:** Con có tâm hồn trong trắng, con mang vẻ đẹp như một viên ngọc bích.
**161. Hoàng Ngân:** Con là cô gái xinh đẹp được cha mẹ xem như vật báu.
**162. Khả Ngân:** Là người con gái xinh đẹp, khả ái, đáng yêu, có cuộc sống sung túc, đủ đầy.
**163. Kiều Ngân:** Ý chỉ con là người con gái xinh xắn, dịu dàng.
**164. Kim Ngân** : Kim Ngân là cha mẹ mong muốn con có một cuộc sống giàu sang, sung túc.
**165. Đông Nghi:** tên con gái họ Nguyễn 2022 là cô gái có vẻ đẹp sắc sảo, dung mạo uy nghi.
**166. Xuân Nghi:** Xuân Nghi là dáng thức mùa xuân, chỉ người con gái phẩm chất đoan trang, tươi xinh đẹp đẽ.
**167. Bảo Ngọc:** Tên Ngọc thể hiện người có dung mạo xinh đẹp, tỏa sáng như hòn ngọc quý, trong trắng, thuần khiết. Đặt tên con gái là Bảo Ngọc thể hiện hàm ý con như viên ngọc quý luôn được mọi người nâng niu, trân trọng.
**168. Bích Ngọc:** Bích Ngọc là viên ngọc bích trong sáng, thuần khiết nhưng cứng cỏi. Đặt tên con gái họ Nguyễn bằng cái tên này thể hiện mong ước con lớn lên xinh đẹp, đoan trang, có ý chí cứng để vượt qua được mọi sóng gió cuộc đời.
**169. Khánh Ngọc:** Khánh Ngọc mang ý nghĩa chỉ những người con gái có dung mạo xinh đẹp như viên ngọc quý, đoan trang, vui tươi.
**170. Minh Ngọc:** Tên Minh Ngọc có ý nghĩa gì? Minh Ngọc là cái tên thường dùng để đặt cho con gái với mong muốn người con gái đó sẽ luôn thông minh, xinh đẹp, lộng lẫy, có sức hút như một viên ngọc.
**171. Thanh Ngọc:** Thanh Ngọc là con xinh đẹp, thanh cao, thuần khiết và lôi cuốn.
**172. Ánh Nguyệt:** Theo từ điển Hán Việt, “nguyệt” có nghĩa là “trăng”, và vẻ đẹp thanh cao của vầng trăng sáng, lúc tròn lúc khuyết những vẫn tràn đầy bí ẩn. Cái tên Ánh Nguyệt mang hàm ý con đẹp tựa ánh trăng dịu dàng.
**173. Bích Nguyệt:** Con như ánh trăng dịu dàng, trong sáng, thể hiện hàm ý con có cuộc sống hạnh phúc, viêm mãn.
**174. Minh Nguyệt:** Tên con là sự kết hợp hài hòa của nét đẹp trong sáng dịu dàng như vầng trăng & sự thông minh, tinh anh
**175. Thanh Nguyệt:** Tên con gái là Thanh Nguyệt hàm ý nói đến người có tâm hồn trong sáng, nét đẹp bình dị, phẩm chất thanh cao.
**176. Thu Nguyệt:** Tên con gái đẹp họ Nguyễn với hàm ý con mang vẻ đẹp dịu dàng của ánh trăng thu.
**177.** **Bảo Nhi:** Theo nghĩa Hán – Việt, “nhi” có ý nghĩa nhỏ nhắn, đồng thời cũng mang ý nghĩa chỉ người con gái xinh xắn, luôn mang đến cảm giác thân thiện. Đặt tên con gái là Bảo Nhi có ý nghĩa là con là bảo bối của cha mẹ, cha mẹ rất mực yêu thương con.
**178. Châu Nhi:** Cái tên này mang ý nghĩa cha mẹ yêu thương và mong con có cuộc sống sung túc.
**179. Diệu Nhi:** Cái tên thể hiện mong ước lớn lên con sẽ là một cô nàng thông minh, xinh đẹp
**180. Đông Nhi:** Đông Nhi là ý chỉ người con ngoan, biết suy nghĩ, bình tĩnh, sâu sắc và có thái độ sống tốt.
**181. Hương Nhi:** Đưa con xinh xắn ngoan hiền của cha mẹ, sống tốt, mang lại tiếng thơm cho đời.
**182. Kiều Nhi:** Có nghĩa là người con gái bé bỏng, xinh đẹp.
**183. Phương Nhi:** Con sẽ là con ngoan của cha mẹ, luôn đáng yêu và sống chan hòa với mọi người.
**184. Thảo Nhi:** Một người con ngoan hiền, hiếu thảo.
**185. Tuệ Nhi:** Cô gái xinh đẹp và thông tuệ.
**186. Tố Nhi:** Có ý chỉ người con gái nhỏ xinh đẹp, khiêm nhường, mộc mạc.
**187. Kiều Như:** Mong muốn con có nét đẹp thanh tao, quý phái như nhưng ngọc.
**188. Ngọc Như:** “Ngọc” là đá quý. “Ngọc Như” nghĩa là con người đáng quý đáng yêu như ngọc như ngà.
**189. Tố Như:** Tố là chân tình. Tố Như hàm nghĩa chỉ con người chân thành, tinh tếvà rất nhạy bén.
**190. Quỳnh Như:** Cái tên mang ý nghĩa chỉ một người vừa có tài vừa có sắc nhưng dịu dàng và khiêm nhường, không phô trương.
[_**(Xem tiếp phần 2)**_](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/dat-ten-con-gai-goi-y-345-cai-ten-y-nghia-va-nhieu-may-man-p2)

## Nỗi nhọc nhằn của bác sĩ hồi sức cấp cứu

Ngày xưa không hiểu tại sao mình đi nội trú hồi sức cấp cứu, nói chung ai cũng gàn, ai cũng bảo sao ngu thế, đâm đầu vào đấy vừa vất vả, vừa nghèo lại đầy rẫy những bất an. Mình bỏ ngoài tai tất cả, quyết tâm đi bằng được với anh mắt ái ngại của những người đi trước, chỉ vì thích.
Từ lúc quyết định lựa chọn con đường này cho đến bây giờ vị chi đã được 7 năm, thời gian chưa đủ nhiều những cũng làm cho cái lưng mình còng xuống vì áp lực công việc và kiến thức. Bệnh viện luôn luôn quá tải, quá tải 1 cách khủng khiếp. Có những khoa có thời điểm nằm đến 5 bệnh nhân 1 giường, mà trời nóng thế này đến mình còn nhão ra nữa là người bệnh.
Mình nhớ, hồi còn sinh viên nhi đồng thối tai lơ ngơ mới ra thành phố, đường phố quang đãng chẳng mấy khi tắc, lúc đó Hà Nội chỉ có chừng đó bệnh viện với chừng đó giường. Đến bây giờ làm giảng viên, lần nào về trường giảng bài cũng đi qua con đường đó 1 cách chậm chạp vì đông không thể tả, ngày nào cũng tắc. Và Hà Nội cũng chỉ chừng đó bệnh viện với số giường tăng không xi nhê gì với dân số. Đường đi tắc, trường học tắc và bệnh viện cũng tắc nốt. Bác sĩ có phải chịu trách nhiệm về việc này không, chắc là không.
Hồi mới vào nội trú, mỗi ngày mình và đồng nghiệp tiếp nhận 70-90 ca bệnh từ các tỉnh chuyển lên, hầu hết là bệnh nặng và phức tạp. Hùng hục làm việc phờ râu, hôm nào cao điểm lên đến 100 bệnh nhân thì tối về gào lên với bọn cùng phòng là hôm nay quá tải khủng khiếp. Đến bây giờ, mỗi ngày 90-100 bệnh nhân vào cấp cứu là chuyện thường, số lượng tăng dần theo từng năm. Trong khi số lượng bác sĩ gần như không thay đổi, lắm lúc mệt đến mức không muốn làm nữa nhưng mình không làm thì ai làm. Bệnh nhân thấy quá tải, bác sĩ cũng quá tải. Lắm lúc phải người nhà củ chuối thì phát rồ lên, mình cũng là người nên chẳng thể nào 1 ngày nhăn nhở mà cười với hàng trăm lượt bệnh nhân và gấp đôi thế người nhà được.
Làm cấp cứu khổ nhất là mặt bệnh đa dạng, áp lực bệnh nhân đông nhưng không được phép gặp sai lầm. Nếu không xử trí nhanh và giải quyết nhanh thì bệnh nhân ùn lại thì vỡ khoa mất. Mỗi tháng mình sơ sơ tính khoảng gần 3000 lượt bệnh nhân từ cả miền Bắc vào cấp cứu với 16 bác sĩ vừa làm hồi sức bệnh nặng vừa làm chẩn đoán. Tối về mình hùng hục cày sách để bổ sung kiến thức, thế mà vẫn thấy mình dốt. Có lẽ ngành y là một trong những ngành phải học cả đời, cái đầu mình hữu hạn, y học cũng hữu hạn nhưng vẫn mênh mông đối với loài người, có những cái vượt qua sự hiểu biết thông thường của khoa học thì đành chịu.
Một thầy giáo mình từng nói, các cậu phải học cho tốt để trước hết gia đình mình được nhờ, sau đó xã hội được nhờ. Mình, cũng như các bác sĩ khác trong khoa, hùng hục học đến 11 năm liên tục, gia đình nuôi báo cô hoàn toàn cho đến khi đi làm, cũng chưa 1 ngày nào gia đình được nhờ cả. Mình đi làm xa, bố mẹ, anh chị em mỗi lần ốm chẳng bao giờ mình có mặt ở nhà. Lắm lúc bị nói mát nuôi nó bao nhiêu năm trời chẳng nhờ được ngày nào, ốm toàn nhờ vả người khác. Đến ngay cả khi mẹ mình ốm, rồi lúc cụ mất mình cũng chẳng có mặt. Nhiều lúc nghĩ ngành y bạc, bạc lắm.
Với sự ích kỉ như hiện nay, có lẽ chỉ trong ngành mới hiểu được sự vất vả và những khó khăn gặp phải. Ngành nào cũng thế chẳng riêng gì ngành mình. Gần đây các bài báo chỉ nhăm nhăm tìm cái xấu để bới móc chứ chưa bao giờ nhìn thấy những khó khăn của người khác. Bởi người ta nhìn ra cái xấu của người khác nhanh và hấp dẫn hơn cái tốt. Mình chỉ lấy ví dụ nho nhỏ, mỗi tháng 3.000 ca cấp cứu, tổng một năm có gần 35.000 ca bệnh mà chỉ cần có 1 ca tiên lượng không tốt là báo chí sẵn sàng nhảy vào mổ xẻ. Họ không cần biết đến hàng chục ngàn ca khác thế nào. Và mục đích chính chỉ cần câu khách.
Ngạn ngữ có câu “chó cứ sủa còn người cứ đi”, nghề đã trở thành nghiệp ăn vào máu không thể bỏ được. Những ngày đi công tác, ăn ở an nhàn lại thấy nhớ không khí nháo nhào trên khoa. Cuối cùng, đâu là sự nhẫn tâm hãy để cho mỗi người tự cảm nhận lấy…
_**BS. Ngô Đức Hùng**_
**[(https://suckhoedoisong.vn/noi-nhoc-nhan-cua-bac-si-hoi-suc-cap-cuu-16968101.htm)](https://suckhoedoisong.vn/noi-nhoc-nhan-cua-bac-si-hoi-suc-cap-cuu-16968101.htm)**

## Nhiều loại cây xanh trồng trong nhà có tác dụng hồi phục sức khỏe, nâng cao sức khỏe tinh thần.

  * [1. Giúp giảm căng thẳng](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/nhieu-loai-cay-xanh-trong-trong-nha-co-tac-dung-hoi-phuc-suc-khoe-nang-cao-suc-khoe-tinh-than#1-gip-gim-cng-thng)
  * [2. Tăng khả năng tập trung, năng suất làm việc](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/nhieu-loai-cay-xanh-trong-trong-nha-co-tac-dung-hoi-phuc-suc-khoe-nang-cao-suc-khoe-tinh-than#2-tng-kh-nng-tp-trung-nng-sut-lm-vic)
  * [3. Hỗ trợ điều trị tâm thần](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/nhieu-loai-cay-xanh-trong-trong-nha-co-tac-dung-hoi-phuc-suc-khoe-nang-cao-suc-khoe-tinh-than#3-h-tr-iu-tr-tm-thn)
  * [4. Giúp người bệnh mau khỏe hơn](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/nhieu-loai-cay-xanh-trong-trong-nha-co-tac-dung-hoi-phuc-suc-khoe-nang-cao-suc-khoe-tinh-than#4-gip-ngi-bnh-mau-khe-hn)
  * [5. Lọc không khí](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/nhieu-loai-cay-xanh-trong-trong-nha-co-tac-dung-hoi-phuc-suc-khoe-nang-cao-suc-khoe-tinh-than#5-lc-khng-kh)


_**Không phải cây xanh nào cũng có thể đặt trong nhà. Theo chuyên trang sức khỏe Healthline (Mỹ), những loại cây xanh nên đặt trong nhà bao gồm: dây nhện, thiết mộc lan, trầu bà, thường xuân, lan ý, nha đam, lưỡi hổ,…**_
Dưới đây là một số tác dụng nổi bật của việc trồng cây xanh trong nhà.
## 1. Giúp giảm căng thẳng
Một nghiên cứu được công bố trên tạp chí  _Physiological Anthropology_ cho thấy trồng cây trong nhà hoặc văn phòng có thể khiến cơ thể cảm thấy thoải mái, dễ chịu hơn.
Trong nghiên cứu, những người tham gia được giao 2 nhiệm vụ: thay chậu cho cây trồng trong phòng làm việc và hoàn thành một công việc ngắn trên máy tính. Sau mỗi nhiệm vụ, các nhà nghiên cứu đo lường các yếu tố sinh học liên quan đến căng thẳng như nhịp tim và huyết áp.
Các nhà nghiên cứu phát hiện ra chăm sóc cây giúp những người tham gia giảm căng thẳng, trong khi làm việc trên máy tính khiến nhịp tim và huyết áp tăng đột biến dù họ đã quen với công việc này. Các nhà nghiên cứu kết luận rằng chăm sóc thực vật có thể làm giảm căng thẳng cả về thể chất và tinh thần.
## 2. Tăng khả năng tập trung, năng suất làm việc
Trong một nghiên cứu nhỏ với 23 sinh viên tham gia, các nhà nghiên cứu chỉ ra rằng những sinh viên học trong không gian có cây xanh chú ý nghe giảng và có khả năng tập trung cao hơn so với sinh viên học trong phòng học thông thường.
Nhiều nghiên cứu phát hiện ra đặt cây xanh trong không gian làm việc giúp tăng năng suất và khả năng sáng tạo. Một nghiên cứu vào năm 1996 cho thấy sinh viên trong phòng máy tính của trường làm việc nhanh hơn 12% và ít căng thẳng hơn khi đặt cây xanh gần nơi họ học.
## 3. Hỗ trợ điều trị tâm thần
Theo  _Healthline_ , chăm sóc cây xanh trong nhà có thể hỗ trợ cho quá trình điều trị các bệnh tâm thần. Các nhà nghiên cứu đã sử dụng liệu pháp chăm sóc cây xanh để tăng cảm giác hạnh phúc cho những người bị trầm cảm, lo lắng, mất trí nhớ và các bệnh tâm thần khác.
## 4. Giúp người bệnh mau khỏe hơn
Ngắm nhìn cây cối, hoa lá có thể giúp cơ thể hồi phục nhanh chóng hơn sau khi bị bệnh, bị thương hoặc phẫu thuật. Theo đó, một nghiên cứu vào năm 2002 cho thấy những người thường xuyên ngắm nhìn cây lá sau khi bị bệnh hoặc phẫu thuật thì cần ít thuốc giảm đau hơn, có thời gian nằm viện ít hơn so với những người không ngắm nhìn cây lá.
## 5. Lọc không khí
Năm 1989, Cơ quan Hàng không và Vũ trụ Mỹ (NASA) phát hiện cây trồng trong nhà có thể hấp thụ các chất độc hại từ không khí, đặc biệt là nơi có không gian kín, ít luồng không khí di chuyển.
Nhiều loại cây trồng trong nhà như trầu bà, nha đam, lan ý, dây nhện,… có khả năng sản xuất oxy cao, loại bỏ các chất độc hại trong không khí như formaldehyde, xylen, benzen, trichloroethylene...
  * [1. Giúp giảm căng thẳng](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/nhieu-loai-cay-xanh-trong-trong-nha-co-tac-dung-hoi-phuc-suc-khoe-nang-cao-suc-khoe-tinh-than#1-gip-gim-cng-thng)
  * [2. Tăng khả năng tập trung, năng suất làm việc](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/nhieu-loai-cay-xanh-trong-trong-nha-co-tac-dung-hoi-phuc-suc-khoe-nang-cao-suc-khoe-tinh-than#2-tng-kh-nng-tp-trung-nng-sut-lm-vic)
  * [3. Hỗ trợ điều trị tâm thần](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/nhieu-loai-cay-xanh-trong-trong-nha-co-tac-dung-hoi-phuc-suc-khoe-nang-cao-suc-khoe-tinh-than#3-h-tr-iu-tr-tm-thn)
  * [4. Giúp người bệnh mau khỏe hơn](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/nhieu-loai-cay-xanh-trong-trong-nha-co-tac-dung-hoi-phuc-suc-khoe-nang-cao-suc-khoe-tinh-than#4-gip-ngi-bnh-mau-khe-hn)
  * [5. Lọc không khí](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/nhieu-loai-cay-xanh-trong-trong-nha-co-tac-dung-hoi-phuc-suc-khoe-nang-cao-suc-khoe-tinh-than#5-lc-khng-kh)



## LỊCH SỬ VÀ Ý NGHĨA NGÀY QUỐC TẾ HẠNH PHÚC 20.3

Ngày Quốc tế hạnh phúc được lấy từ ý tưởng từ Bhutan, quốc gia vốn được đánh giá là hạnh phúc nhất thế giới dựa trên các yếu tố như sức khoẻ, tinh thần, giáo dục, môi trường, chất lượng quản lý và mức sống của người dân. Liên Hợp Quốc quyết định kỷ niệm ngày này theo đề xuất của Vương quốc Bhutan, một quốc gia nhỏ bé ở khu vực Nam Á, nằm sâu trong lục địa phía Đông dãy Himalaya. Bắt đầu từ những năm 1970, nhà vua của vương quốc này đã đưa ra một cách thức mới đánh giá sự thịnh vượng của xã hội, đó là thông qua chỉ số hạnh phúc quốc gia, bên cạnh các chỉ số về kinh tế thường được dùng để đánh giá về sự giàu có vật chất. Chỉ số này được tính toán dựa trên các yếu tố về sức khỏe, tinh thần, giáo dục, môi trường, chất lượng quản lý và mức sống của người dân.
Đại diện quốc gia Bhutan cho rằng, nhu cầu về Ngày Hạnh phúc này là đối với tất cả quốc gia và con người trên toàn thế giới để có những bước vượt lên trên sự khác biệt giữa các nước và con người trên toàn thế giới, và liên kết, đoàn kết toàn nhân loại. Việc Liên Hiệp Quốc chọn ngày 20/3 là Ngày Quốc tế Hạnh phúc, còn vì đây là ngày đặc biệt trong năm, khi mặt trời nằm ngang đường xích đạo, nên trong ngày này có độ dài ngày và đêm bằng nhau - là biểu tượng cho sự cân bằng, hài hòa của vũ trụ.
Cũng là biểu tượng của sự cân bằng giữa âm và dương, giữa ánh sáng và bóng tối, giữa ước mơ và hiện thực... Bởi vậy, ngày 20/3 - Ngày Quốc tế Hạnh phúc cũng truyền tải thông điệp rằng: Cân bằng, hài hòa là một trong những chìa khóa để mang đến hạnh phúc.
_"Đối với mỗi người khác nhau, hạnh phúc có thể mang nhiều ý nghĩa khác nhau. Tuy nhiên, chúng ta đều công nhận rằng, hạnh phúc nghĩa là làm việc để chấm dứt xung đột, nghèo đói và các điều kiện không may mắn khác và rất nhiều đồng loại của chúng ta hiện đang phải sống trong các điều kiện đó. Hạnh phúc không phải là điều phù phiếm, cũng không phải là điều gì xa xỉ. Hạnh phúc là khát khao sâu xa của mọi thành viên trong gia đình nhân loại. Hạnh phúc không nên từ chối một ai và phải là của tất cả mọi người. Khát vọng này ẩn chứa trong cam kết của Hiến chương Liên Hợp Quốc để thúc đẩy hòa bình, công bằng, nhân quyền, tiến bộ xã hội và mức sống được cải thiện"._
Việc tổ chức Ngày Quốc tế Hạnh phúc là để biểu thị mong muốn, niềm tin và quyết tâm phấn đấu vì một thế giới hòa bình, không có chiến tranh, không còn đói nghèo; một thế giới phát triển thịnh vượng và bền vững; một thế giới mà tất cả mọi người dù khác màu da, dân tộc, tôn giáo đều được hưởng trọn vẹn hạnh phúc. Hãy yêu thương và sẻ chia để tìm thấy cho mình và giúp những người quanh ta, trước hết là gia đình, là những người thân có nhiều giây phút hạnh phúc đích thực!

## 7 BÀI HỌC NÊN BIẾT CÀNG SỚM CÀNG TỐT

  * [1. Học cách điều chỉnh tâm trạng](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/7-bai-hoc-nen-biet-cang-som-cang-tot#1-hc-cch-iu-chnh-tm-trng)
  * [2. Học cách tự chăm sóc bản thân](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/7-bai-hoc-nen-biet-cang-som-cang-tot#2-hc-cch-t-chm-sc-bn-thn)
  * [3. Học cách từ bỏ](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/7-bai-hoc-nen-biet-cang-som-cang-tot#3-hc-cch-t-b)
  * [4. Học cách coi nhẹ được mất](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/7-bai-hoc-nen-biet-cang-som-cang-tot#4-hc-cch-coi-nh-c-mt)
  * [5. Học thiện lương](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/7-bai-hoc-nen-biet-cang-som-cang-tot#5-hc-thin-lng)
  * [6. Học quý trọng](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/7-bai-hoc-nen-biet-cang-som-cang-tot#6-hc-qu-trng)
  * [7. Học về quy luật của trời đất](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/7-bai-hoc-nen-biet-cang-som-cang-tot#7-hc-v-quy-lut-ca-tri-t)


## 1. Học cách điều chỉnh tâm trạng
Cuộc đời là của bạn, tâm trạng cũng là của bạn. Mình nhận ra rằng, sự việc có tích cực hay tiêu cực là do cách nhìn và cách đối diện nó của bạn. Bạn hoàn toàn có thể thay đổi được tâm trạng của mình mà phải không?
## 2. Học cách tự chăm sóc bản thân
Không ai có thể nâng đỡ, chăm sóc được bạn cả cuộc đời. Mẹ mình nói rằng: "trước khi con muốn chứng minh cho ai rằng con có thể sống tốt khi có 1 mình, thì con phải cho họ thấy con biết yêu và nâng niu chính bản thân con. Giá trị con ở đó đấy".
## 3. Học cách từ bỏ
Từ bỏ được nỗi buồn thì trong tim không còn gánh nặng. Từ bỏ được niềm vui xa hoa nhất thời thì tâm trí không bị u mê. Lớn lên, mình tập học được chấp nhận với sự thật dù buồn hay vui, đôi khi nó chính là động lực giúp mình tốt hơn mỗi ngày nữa.
## 4. Học cách coi nhẹ được mất
Trên thế giới này, kỳ thực ngoài sinh mệnh của mình ra thì không còn có gì quan trọng hơn cả. Mình luôn nghĩ trái đất luôn có quỹ đạo của nó, mình đánh mất điều này nhưng mình rồi sẽ nhận được điều khác. Hãy mỉm cười tận hưởng những gì đến với ta nhé.
## 5. Học thiện lương
Thiện lương là nền tảng, cốt lõi để làm người. Hồi còn nhỏ, bố mẹ nói rằng: Trước khi con muốn thành ai, hãy học tính lương thiện, học làm người là điều quan trọng nhất. Đừng vì danh lợi mà để mất đi bản tính của mình.
## 6. Học quý trọng
Đời người nhìn thì tưởng là xa nhưng thực ra lại rất ngắn. Hãy quý trọng tất cả mọi người xung quanh mình, đừng để lưu lại sự hối tiếc khi đã quá muộn bạn nhé.
## 7. Học về quy luật của trời đất
Sinh ra làm người là đáng quý, hãy biết quý trọng và bảo vệ sức khoẻ của mình và người thân. Trên đời mình nghĩ luôn có qua có lại. Khi bạn cho đi, bạn sẽ nhận lại được nhiều điều hơn thế. Vậy nên mình luôn cố gắng để bản thân hoàn thiện hơn mỗi ngày.
**Nguồn: Gia đình truyền hình**
  * [1. Học cách điều chỉnh tâm trạng](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/7-bai-hoc-nen-biet-cang-som-cang-tot#1-hc-cch-iu-chnh-tm-trng)
  * [2. Học cách tự chăm sóc bản thân](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/7-bai-hoc-nen-biet-cang-som-cang-tot#2-hc-cch-t-chm-sc-bn-thn)
  * [3. Học cách từ bỏ](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/7-bai-hoc-nen-biet-cang-som-cang-tot#3-hc-cch-t-b)
  * [4. Học cách coi nhẹ được mất](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/7-bai-hoc-nen-biet-cang-som-cang-tot#4-hc-cch-coi-nh-c-mt)
  * [5. Học thiện lương](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/7-bai-hoc-nen-biet-cang-som-cang-tot#5-hc-thin-lng)
  * [6. Học quý trọng](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/7-bai-hoc-nen-biet-cang-som-cang-tot#6-hc-qu-trng)
  * [7. Học về quy luật của trời đất](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/7-bai-hoc-nen-biet-cang-som-cang-tot#7-hc-v-quy-lut-ca-tri-t)



## “Liều thuốc Dopamine”: Cái gì càng hại, lại càng hấp dẫn

  * [Dopamine tiết ra nhiều hơn ở các kích thích không lành mạnh](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/lieu-thuoc-dopamine-cai-gi-cang-hai-lai-cang-hap-dan#dopamine-tit-ra-nhiu-hn-cc-kch-thch-khng-lnh-mnh)
  * [Bạn có nghiện 6 loại hoạt động sản sinh “dopamine cao” sau đây?](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/lieu-thuoc-dopamine-cai-gi-cang-hai-lai-cang-hap-dan#bn-c-nghin-6-loi-hot-ng-sn-sinh-dopamine-cao-sau-y)
  * [4 cách tập sống chậm để không bị “lậm” kích thích](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/lieu-thuoc-dopamine-cai-gi-cang-hai-lai-cang-hap-dan#4-cch-tp-sng-chm-khng-b-lm-kch-thch)


Hiểu đơn giản, dopamine là một chất dẫn truyền thần kinh được não tiết ra khi con người ta sung sướng hạnh phúc. Dopamine sẽ ra hiệu cho não ghi nhớ những ký ức tốt đẹp này trong đầu và khuyến khích ta lặp lại chúng. Ví dụ bạn ghiền ăn gà, và lần nào đi ngang tiệm gà rán bạn cũng muốn dừng lại mua để tiếp tục được ăn ngon miệng.
### Dopamine tiết ra nhiều hơn ở các kích thích không lành mạnh
Dopamine vốn là một phần trong bản năng sinh tồn, giúp ta nhận diện đâu là những hành vi tích cực cần phải được duy trì và phát huy, như ăn ngon, ở sạch, giữ tâm trạng vui vẻ.
Đáng tiếc thay ở đời sống hiện đại, ta tiếp xúc với hàng tá các kích thích “thượng vàng hạ cám” khác nhau, như caffeine, thuốc lá, sex, đồ ngọt,... Nghiên cứu từ PubMed Central cho thấy những kích thích có phần tiêu cực này sẽ khiến não sản sinh nhiều dopamine hơn, từ đó chúng trông mời gọi và hấp dẫn hơn các kích thích lành mạnh khác.
Một khi mất kiểm soát, ta sẽ vô thức lặp đi lặp lại những hoạt động hard-core này và biến chúng thành hành vi bốc đồng cưỡng chế (compulsive behavior). Nếu bạn từng 1 lần thấy mình dành hàng giờ chỉ để làm những việc vô nghĩa, thì 6 loại hoạt động sản sinh dopamine cao dưới đây sẽ giúp bạn lý giải hành vi của chính mình.
### Bạn có nghiện 6 loại hoạt động sản sinh “dopamine cao” sau đây?
Không cần phải dấn thân vào ăn chơi vô độ, nội việc chúng ta dành hàng giờ liền chỉ đọc comment cãi nhau của 2 người xa lạ trên Facebook, cũng được liệt vào những hành vi mang tính cưỡng chế (compulsive).
“Cưỡng chế” là khi bạn không thực sự muốn mình “dính” chặt vào hoạt động đó. Chỉ là cảm giác thỏa mãn khi não tiết dopamine đã buộc bạn phải ở lại tận 1-2 tiếng đồng hồ làm lại 1 công việc đến khi bạn thấm mệt và cảm thấy vô nghĩa.
Tiến sỹ Tâm thần học Cameron Sepah đã tổng hợp và chia chúng thành 6 loại hoạt động kích thích cao dưới đây. Không ít thì nhiều, bạn có thấy mình trong đó?
  * **Ăn uống vô độ (Compulsive eating):** Ăn nhiều vì stressed, sơ hở là nạp đường (trà sữa, nước ngọt,…), ăn vặt văn phòng thường xuyên.
  * **Nghiện mạng xã hội (Social media addiction):** Liên tục check thông báo, lướt TikTok/Reels không kiểm soát, bồn chồn nếu offline quá lâu.
  * **Bài bạc (Gambling):** Không chỉ là đánh bài ăn tiền, đây còn là các hoạt động cá độ, đánh đề, càng “lời” càng lao vào chơi tiếp.
  * **Ghiền mua sắm (Shopping addiction):** Biết hàng kém chất lượng vẫn mua vì rẻ, mua nhiều nhưng không xài, tiêu trên mức thu nhập.
  * **Tình dục (Sex):** Xem quá nhiều phim 18+, nghiện “tự sướng” và các hoạt động thân mật khác.
  * **Chất kích thích (Drug):** Caffeine, thuốc lá, khí cười, cần sa, và các chất bị liệt vào danh sách cấm khác.


Thật ra, bạn hoàn toàn bình thường nếu thấy mình trong tất cả 6 kích thích trên. Đây là phản xạ bản năng của con người, chỉ cần bạn đừng phạm pháp và đắm chìm vào chúng một cách vô độ để ảnh hưởng sức khỏe.
## 4 cách tập sống chậm để không bị “lậm” kích thích
Tin tốt là, khi bạn bắt đầu nhìn đời buồn chán, bạn cũng có lý do quay đầu để nắn bản thân trở về guồng sống cũ “healthy and balanced” hơn. Vì không lành mạnh, thì không còn cách nào để thoát ra.
Tôi cũng là một người sống vội, dễ mất kiên nhẫn khi phải đọc một quyển sách hàng giờ đồng hồ. Nhưng một buổi sáng nọ sau nhiều ngày căng não, tôi quyết định ra cafe nghỉ ngơi cùng một quyển sách trên tay. Và đó như là, lần đầu tôi thấy mình thực sự “sống” ở hiện tại: cảm nhận từng con chữ, lắng nghe tiếng thở phào, ngồi giữa không gian ngập nắng và bắt đầu viết lách.
Đây có lẽ là “sức mạnh” của những kích thích yếu: phát triển sức khỏe tinh thần, củng cố sức khỏe thể chất, giúp ta kiểm soát cảm xúc tốt hơn và làm việc hiệu quả hơn. Theo PsychCentral, dưới đây là 4 cách bạn có thể tập sống chậm và tìm lại cảm giác hạnh phúc:
**1. Đặt ra giới hạn:** Ngắt kết nối với wifi hay điện thoại những hôm cuối tuần công việc không cần đến, kiểm soát thời gian chỉ lướt web 1 tiếng mỗi ngày, gửi tiền vào tài khoản tiết kiệm để hạn chế chi tiêu.
**2. Viết lại cảm xúc trong ngày:** Chỉ ra được nguyên nhân cốt lõi vì sao bạn nghiện các kích thích mạnh. Có thể do bạn đang buồn bực điều gì hay rảnh rỗi thái quá? Viết ra được điều này sẽ giúp bạn nhận diện nỗi đau và tìm cách giải quyết thay vì để bản thân lún vào liều dopamine tạm thời.
**3. Tập một thói quen thay thế:** Thay vì dành cả ngày thứ 7 ở nhà bấm điện thoại, bạn có thể bắt đầu đăng ký tập gym, dành thời gian nghe podcast, đi vẽ tranh làm gốm, đăng ký đi trekking… Thay thế trong thời gian dài sẽ giúp ta quên và “cai” luôn cảm giác hard-core lúc trước.
**4. Rủ bạn cùng sống chậm:** Sự ảnh hưởng từ tương tác người - người cũng giúp ổn định và uốn nắn tinh thần. Chọn một hội nhóm với các thói quen sống lành mạnh, bạn sẽ lượm nhặt được những điều hay từ họ để bồi đắp cho những thiếu sót của bản thân.
  * [Dopamine tiết ra nhiều hơn ở các kích thích không lành mạnh](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/lieu-thuoc-dopamine-cai-gi-cang-hai-lai-cang-hap-dan#dopamine-tit-ra-nhiu-hn-cc-kch-thch-khng-lnh-mnh)
  * [Bạn có nghiện 6 loại hoạt động sản sinh “dopamine cao” sau đây?](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/lieu-thuoc-dopamine-cai-gi-cang-hai-lai-cang-hap-dan#bn-c-nghin-6-loi-hot-ng-sn-sinh-dopamine-cao-sau-y)
  * [4 cách tập sống chậm để không bị “lậm” kích thích](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/lieu-thuoc-dopamine-cai-gi-cang-hai-lai-cang-hap-dan#4-cch-tp-sng-chm-khng-b-lm-kch-thch)



## ️ Lấy niềm đau của bản thân làm trò đùa, trò đùa có thể gây tổn thương!

  * [Tự đùa cợt với nỗi đau có phổ biến?](https://bvnguyentriphuong.com.vn/bac-si-tu-van/lay-niem-dau-cua-ban-than-lam-tro-dua-tro-dua-co-the-gay-ton-thuong#t-a-ct-vi-ni-au-c-ph-bin)
  * [Tại sao ta tự cười trên nỗi đau?](https://bvnguyentriphuong.com.vn/bac-si-tu-van/lay-niem-dau-cua-ban-than-lam-tro-dua-tro-dua-co-the-gay-ton-thuong#ti-sao-ta-t-ci-trn-ni-au)
  * [Đối phó với áp lực của cuộc sống](https://bvnguyentriphuong.com.vn/bac-si-tu-van/lay-niem-dau-cua-ban-than-lam-tro-dua-tro-dua-co-the-gay-ton-thuong#i-ph-vi-p-lc-ca-cuc-sng)
  * [Ép buộc bản thân phải tích cực](https://bvnguyentriphuong.com.vn/bac-si-tu-van/lay-niem-dau-cua-ban-than-lam-tro-dua-tro-dua-co-the-gay-ton-thuong#p-buc-bn-thn-phi-tch-cc)
  * [Đùa một chút thì vui, nhưng đùa nhiều là biểu hiện của tự hại](https://bvnguyentriphuong.com.vn/bac-si-tu-van/lay-niem-dau-cua-ban-than-lam-tro-dua-tro-dua-co-the-gay-ton-thuong#a-mt-cht-th-vui-nhng-a-nhiu-l-biu-hin-ca-t-hi)
  * [Để không rơi vào trạng thái cực đoan](https://bvnguyentriphuong.com.vn/bac-si-tu-van/lay-niem-dau-cua-ban-than-lam-tro-dua-tro-dua-co-the-gay-ton-thuong#-khng-ri-vo-trng-thi-cc-oan)
  * [Tránh bẫy tích cực độc hại](https://bvnguyentriphuong.com.vn/bac-si-tu-van/lay-niem-dau-cua-ban-than-lam-tro-dua-tro-dua-co-the-gay-ton-thuong#trnh-by-tch-cc-c-hi)
  * [Thực hành chăm sóc bản thân](https://bvnguyentriphuong.com.vn/bac-si-tu-van/lay-niem-dau-cua-ban-than-lam-tro-dua-tro-dua-co-the-gay-ton-thuong#thc-hnh-chm-sc-bn-thn)
  * [Nhận thức vấn đề thực sự](https://bvnguyentriphuong.com.vn/bac-si-tu-van/lay-niem-dau-cua-ban-than-lam-tro-dua-tro-dua-co-the-gay-ton-thuong#nhn-thc-vn-thc-s)


**Hiệp Hưng Nguyễn**
## Tự đùa cợt với nỗi đau có phổ biến?
Self-defeating humour và Self-Deprecating humour (Tạm dịch: Tự châm biếm) mô tả việc một cá nhân tự biến bản thân thành đối tượng để hạ thấp, bôi bác và đùa cợt thông qua khiếu hài hước. Những chủ đề nhạy cảm như tính cách, ngoại hình, hay các vấn đề tâm lý, hôn nhân, cũng có thể bị đem ra làm nguyên liệu gây cười.
Trên thực tế, việc lôi bản thân ra đùa cợt đã không chỉ diễn ra trong những buổi chuyện trò với nhóm bạn thân. Hiện tượng này đã diễn ra với tần suất dày đặc trên các phương tiện truyền thông, cụ thể là trong các chương trình hài độc thoại, các tấm ảnh meme, hay thậm chí là những lời ta tự nói với chính mình.
Không khó để bắt gặp trò đùa tự hạ thấp dưới dạng những dòng trạng thái vu vơ như: “Khi bạn dọn phòng sạch đến mức thứ rác rưởi duy nhất còn lại là bản thân”, “Hôn nhân là mồ chôn tình yêu”, hay những tấm ảnh meme đùa cợt các vấn đề như bệnh tâm lý, ám ảnh ngoại hình,... cũng rất phổ biến.
## Tại sao ta tự cười trên nỗi đau?
### Đối phó với áp lực của cuộc sống
[Nhiều nghiên cứu](https://researchbank.swinburne.edu.au/file/f8813ec8-50bc-467f-8649-4f689821139b/1/Robyn%20Brown%20Thesis.pdf)
#### Nội dung trong file:

Lỗi khi xử lý file https://researchbank.swinburne.edu.au/file/f8813ec8-50bc-467f-8649-4f689821139b/1/Robyn%20Brown%20Thesis.pdf: EOF marker not found đã chỉ ra rằng khiếu hài hước là một cơ chế đối phó (coping mechanism) giúp ta đối mặt với căng thẳng hoặc tổn thương tâm lý. Việc biến những trải nghiệm tồi tệ trở thành điều gì đó khôi hài là một chiến thuật nhằm làm giảm trạng thái căng thẳng và lo âu. Khi kiểm soát được những cảm xúc tiêu cực, ta có thể duy trì sự ổn định tâm lý, từ đó giải quyết các vấn đề một cách hiệu quả hơn.
Ngoài ra, theo học thuyết về Cơ chế phòng vệ (Defense mechanism) của Sigmund Freud, có thể xếp cười đùa trên nỗi đau vào kiểu cơ chế Hình thành phản ứng ngược (Reaction formation). Thay vì cảm thấy bồn chồn, lo lắng trước vấn đề, chúng ta lại coi nó như một điều hài hước và thú vị. Chẳng hạn như khi quá lo lắng trước kỳ thi, ta hay đùa với nhau rằng “Cùng lắm thi trượt thì về quê chăn trâu”.
Trong trường hợp này, trò đùa chính là cách để chúng ta giải tỏa căng thẳng và lo âu trước những vấn đề bản thân gặp phải. Thái độ bỡn cợt và hài hước tạo ra một không gian an toàn và thoải mái. Từ đó chúng ta dễ dàng hơn để chia sẻ về những trải nghiệm tiêu cực mình gặp phải hơn.
### Ép buộc bản thân phải tích cực
Tích cực độc hại (toxic positivity) là một niềm tin, một kỳ vọng rằng bất kể tình huống xảy ra có đau đớn và khổ sở đến mức nào, chúng ta cũng nên nhìn nhận nó theo chiều hướng vui vẻ và tích cực.
Tích cực độc hại đang trở thành một phong trào nổi bật trong xã hội đương đại. Không khó để bắt gặp biểu hiện của nó ở khắp các phương tiện truyền thông đại chúng. Sách báo, phim ảnh, hay mạng xã hội, tất cả đều ngập tràn những thông điệp dạng “Hãy nhìn mọi thứ theo hướng tích cực” hay “Còn đầy người khổ hơn”.
Đùa cợt với những vấn đề của bản thân liên quan mật thiết đến xu hướng tích cực độc hại. Trong trường hợp này, hành vi đùa giỡn là một nỗ lực để đáp ứng kỳ vọng xã hội. Chúng ta cố ép bản thân phải nhìn nhận và chia sẻ mọi thứ theo hướng tích cực, vì đó là điều xã hội đang cổ vũ.
Sự áp đặt trạng thái tích cực khiến cho các cá nhân phải tìm cách che giấu, hoặc nói giảm nói tránh những bất ổn mà họ đang chịu đựng. Chúng ta đề cập những trải nghiệm tệ hại với thái độ cợt nhả và thiếu nghiêm túc, để giữ mọi thứ ở trạng thái tích cực. Biểu hiện ấy khiến chúng ta được nhìn nhận như một cá nhân vui vẻ và lạc quan - thứ mà xã hội kỳ vọng.
Điều này đặc biệt độc hại, bởi nó khiến chúng ta phớt lờ đi những cảm nhận thực sự của bản thân. Ngay cả khi cảm thấy thật tồi tệ với những sự kiện đang diễn ra, ta vẫn phải cố ép bản thân cảm thấy lạc quan bằng những trò đùa “dở khóc dở cười”.
## Đùa một chút thì vui, nhưng đùa nhiều là biểu hiện của tự hại
Ở mức độ cực đoan, đùa cợt về bản thân có thể là biểu hiện của sự tự hại (self-harm) hay lòng tự hận (self-hatred), vốn là các dấu hiệu của vấn đề tâm lý nghiêm trọng.
Theo tạp chí về sức khỏe tâm thần [Verywell Mind](https://www.verywellmind.com/why-people-self-sabotage-and-how-to-stop-it-5207635), hành vi tự hại xuất phát từ những trải nghiệm đau khổ trong quá khứ, những bất ổn trong hiện tại, hay các vấn đề tâm lý mà cá nhân đang phải đối mặt. Điều này khiến cho nhiều người cảm thấy họ không xứng đáng được yêu thương và tôn trọng.
Trong trường hợp này, ta tin rằng bản thân xứng đáng bị đem ra làm trò cười, xứng đáng phải chịu những lời bôi bác, chế giễu, hay thậm chí sỉ nhục. Những câu đùa giờ đây giống như một phương thức để bày tỏ cảm giác tự ti, căm ghét, hay lời chỉ trích bản thân.
Vì vậy, hành động lôi bản thân ra đùa cợt cũng cần được nhìn nhận với một thái độ thận trọng và nghiêm túc. Thay vì chỉ cùng cười trước những câu đùa, ta cũng cần chân thành đặt câu hỏi xem liệu ta có thể giúp gì cho họ hay không?
Rất có thể, đằng sau những tiếng cười vang là một cá nhân tổn thương đang cần được giúp đỡ.
## Để không rơi vào trạng thái cực đoan
Những trò đùa chế giễu bản thân, một mặt có thể giúp chúng ta giải tỏa căng thẳng, tạo ra ảnh hưởng tích cực đến cuộc sống. Mặt khác, cũng có thể là dấu hiệu cho những vấn đề tâm lý nghiêm trọng cần được nỗ lực giải quyết.
### Tránh bẫy tích cực độc hại
Cần tránh việc cố ép bản thân “nhìn nhận theo hướng tích cực” trong mọi trường hợp. Những cảm xúc tiêu cực là thứ không thể tránh khỏi trong cuộc sống.
Ngoài ra, những biểu hiện của tích cực độc hại cũng muôn hình vạn trạng, và chúng ta cũng cần tránh không để bản thân rơi vào những cái bẫy vô hình này.
### Thực hành chăm sóc bản thân
Những người thường xuyên lôi bản thân ra đùa cợt có thể cảm thấy mình không xứng đáng nhận được sự yêu thương và tôn trọng. Vì vậy, một điều quan trọng cần phải làm là tìm ra những cách thức phù hợp để cải thiện sức khỏe và học cách thương thân.
### Nhận thức vấn đề thực sự
Đùa cợt chỉ là cách ta chia sẻ vấn đề với người khác, đó không nhất thiết là giải pháp hiệu quả. Chúng ta cần nhận thức được vấn đề thực sự ta đang phải đối mặt để giải quyết triệt để nó, thay vì "đi đường vòng" với trò đùa.
Vì vậy, khi thấy bản thân có các dấu hiệu bất ổn, hãy cố gắng tìm đến sự hỗ trợ của các đường dây nóng, hay các chuyên gia để nhận được lời khuyên và phương pháp điều trị phù hợp.
Tìm kiếm sự giúp đỡ chưa bao giờ là điều đáng xấu hổ. Có như vậy, những trò đùa mới chứa đựng những niềm vui, chứ không còn ẩn chứa những tổn thương sâu sắc.
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [Tự đùa cợt với nỗi đau có phổ biến?](https://bvnguyentriphuong.com.vn/bac-si-tu-van/lay-niem-dau-cua-ban-than-lam-tro-dua-tro-dua-co-the-gay-ton-thuong#t-a-ct-vi-ni-au-c-ph-bin)
  * [Tại sao ta tự cười trên nỗi đau?](https://bvnguyentriphuong.com.vn/bac-si-tu-van/lay-niem-dau-cua-ban-than-lam-tro-dua-tro-dua-co-the-gay-ton-thuong#ti-sao-ta-t-ci-trn-ni-au)
  * [Đối phó với áp lực của cuộc sống](https://bvnguyentriphuong.com.vn/bac-si-tu-van/lay-niem-dau-cua-ban-than-lam-tro-dua-tro-dua-co-the-gay-ton-thuong#i-ph-vi-p-lc-ca-cuc-sng)
  * [Ép buộc bản thân phải tích cực](https://bvnguyentriphuong.com.vn/bac-si-tu-van/lay-niem-dau-cua-ban-than-lam-tro-dua-tro-dua-co-the-gay-ton-thuong#p-buc-bn-thn-phi-tch-cc)
  * [Đùa một chút thì vui, nhưng đùa nhiều là biểu hiện của tự hại](https://bvnguyentriphuong.com.vn/bac-si-tu-van/lay-niem-dau-cua-ban-than-lam-tro-dua-tro-dua-co-the-gay-ton-thuong#a-mt-cht-th-vui-nhng-a-nhiu-l-biu-hin-ca-t-hi)
  * [Để không rơi vào trạng thái cực đoan](https://bvnguyentriphuong.com.vn/bac-si-tu-van/lay-niem-dau-cua-ban-than-lam-tro-dua-tro-dua-co-the-gay-ton-thuong#-khng-ri-vo-trng-thi-cc-oan)
  * [Tránh bẫy tích cực độc hại](https://bvnguyentriphuong.com.vn/bac-si-tu-van/lay-niem-dau-cua-ban-than-lam-tro-dua-tro-dua-co-the-gay-ton-thuong#trnh-by-tch-cc-c-hi)
  * [Thực hành chăm sóc bản thân](https://bvnguyentriphuong.com.vn/bac-si-tu-van/lay-niem-dau-cua-ban-than-lam-tro-dua-tro-dua-co-the-gay-ton-thuong#thc-hnh-chm-sc-bn-thn)
  * [Nhận thức vấn đề thực sự](https://bvnguyentriphuong.com.vn/bac-si-tu-van/lay-niem-dau-cua-ban-than-lam-tro-dua-tro-dua-co-the-gay-ton-thuong#nhn-thc-vn-thc-s)



## Cảm xúc trong y tế

**BS Hải Yến**
**Cách nhìn nhận sự khác biệt !**
Trước hết, cần hiểu rõ không thể bắt, ép buộc người khác phải thay đổi quan điểm hoặc suy nghĩ của họ. Việc duy nhất mà ta có thể làm là thay đổi bản thân. Ta có thể thay đổi quan điểm của mình, nếu thấy vấn đề hợp lý, logic với cách suy nghĩ, hợp với cách nhìn nhận của ta. Bằng không, ta hoàn toàn có thể giữ quan điểm của mình, chấp nhận và tôn trọng quan điểm của người khác. Như vậy, ta vừa giữ được thái độ ôn hòa vừa cảm thấy thoải mái với mọi tình huống.
Giữ được tâm thái ôn hòa khi gặp những trở ngại liên quan đến giao tiếp, giống như giữ được bình tĩnh khi phải lái con tàu lúc trời sóng to, gió cả. Bạn có đủ bình tĩnh để thông cảm, chia sẻ với những lo âu, rối trí của các hành khách trên tàu hay không? Hay bạn cũng bị cuốn vào dòng xoáy của nỗi lo sợ và để cho sự việc quăng đâp mình? Bạn đủ sáng suốt để nhận thấy những mối hiểm nguy, những xoáy nước tránh cho tàu va vào đá ngầm? Hay bạn cũng lo lắng, bất an và chẳng còn phân biệt được gì giữa cơn cuồng nộ của biển khơi?
**Môi trường y tế?**
Là một môi trường đầy sóng gió, với các rủi ro giao tiếp luôn luôn chực chờ, không chỉ trong phiên trực phải xử lý cấp cứu, không chỉ trong phòng phẫu thuật, mà ở bất cứ nơi đâu, từ cổng bảo vệ cho đến phòng tài vụ, từ bãi gửi xe đến phòng kế hoạch tổng hợp. Bởi”cực chẳng đã” người ta mới phải vào bệnh viện, đi kèm bệnh tật là những lo âu, bất ổn về thể chất, gánh nặng tài chính và bất an về tâm trí. Và chúng ta không ở trong hoàn cảnh của họ, nhìn nhận vấn đề khác họ, ta nhìn thấy những cảnh bệnh tật nhiều đến mức trước mặt chỉ còn căn bệnh vô tri vô giác, chứ không phải người bệnh với đầy đủ "hỉ, nộ, ái, ố". Những công việc lặp đi lặp lại hàng ngày, chứng kiến hàng ngàn, hàng chục ngàn lượt bệnh nhân đôi khi làm ta trở nên miễn nhiễm trước các nỗi đau như một người máy vô cảm.
Trong chúng ta thế nào có người cũng đã từng thót tim khi phải tự tay tiêm một mũi cho người thân, quặn thắt ruột khi nhìn thấy máu chảy từ vết thương của người nhà? Nhớ đến cảm giác này bạn sẽ dễ dàng hiểu tâm trạng của bệnh nhân và người nhà họ khi vào bệnh viện. Vì chúng ta không đang đứng ở vị trí của người bệnh, đang không nhìn nhận vấn đề từ góc của họ, nên đôi khi những thái độ, lời nói, cử chỉ của ta vô tình đã chạm vào nỗi đau và làm tổn thương họ sâu sắc. Thế là ta tự châm ngay một mồi lửa để mọi thứ bùng nổ tới mức không cứu vãn được.
Chỉ khi giữ được tâm thái ôn hòa một cách vững chãi, mới có thể dễ dàng tách biệt ra khỏi hoàn cảnh, dễ dàng đứng lùi lại để nhìn nhận vấn đề một cách thấu đáo và dễ dàng hành xử một cách chân tình, chân thành và đầy thông cảm. Đúng là cả ngày mệt mỏi, gặp phải người bệnh quá lo lắng, hỏi đi hỏi lại một vấn đề, thật sự làm ta nản lòng, dễ nổi cáu. Nhưng nếu nhận ra được lý do họ hỏi là vì sự hoang mang, vô vọng khi đứng trước bệnh tật của mình, khi đó ta sẽ dễ dàng chấp nhận trả lời, giải thích lần nữa và lần nữa cho những câu hỏi lặp lại vì thông cảm cho nỗi lòng của họ.
Đúng là có những bệnh nhân cư xử và nói năng không lịch sự hoặc thô lỗ, có khi mang những mối quen biết ra để dọa và ra oai. Thay vì đáp trả tương tự cho bớt tức, để chứng minh ta cũng không sợ, nếu bình lặng trong lòng ta sẽ đủ tỉnh táo để nhận thấy họ là người đáng thương, đang ở hoàn cảnh khó khăn hơn ta, họ đang rất đau khổ và yếu ớt nên buộc phải dùng những công cụ bên ngoài để át đi nỗi lo sợ bên trong, bởi họ đang sợ ta sẽ không giúp họ nếu họ không có những biểu lộ hoặc hành vi mạnh mẽ đe dọa. Nếu không bị cuốn vào cơn giận dữ do hành vi thiếu kiểm soát của bệnh nhân, ta sẽ dễ cảm thông và có tấm lòng độ lượng hơn. Các lời nói, cử chỉ mang sự cảm thông của nhân viên y tế sẽ như cơn mưa rào, làm dịu mát những cái đầu bốc lửa, và ngay lập tức ta đã giúp con tàu ra khỏi vực xoáy, kiểm soát được hướng đi theo một dòng chảy an toàn hơn.
Chắc chắn sẽ có bạn nói, có nhiều sự việc, bệnh nhân bực tức khó chịu ở nơi khác và trút hết lên đầu mình. Đúng vậy, điều này cũng như bão đến bất ngờ, và một lần nữa tùy thuộc bản lĩnh của chúng ta, vì dù lý do từ đâu nếu không khéo léo xử trí, người lĩnh hậu quả không ai khác là chính chúng ta. Và như các cụ nói “được vạ thì má đã sưng”, cho nên nếu có thể hãy tự giúp mình khi mọi việc còn trong tầm kiểm soát.
**Điều chỉnh cách nhìn nhận hay đè nén cảm xúc?**
Khi gặp các tình huống căng thẳng, chúng ta không xử lý bằng cách chịu đựng, nhịn nhục hoặc đè nén cảm xúc cho qua, cách này chỉ khiến bạn tích lũy, chất chứa các cảm xúc tiêu cực, bất mãn, bực tức, uất ức trong lòng, để rồi dễ bộc lộ một cách vô thức các lời nói hoặc hành động thiếu thân thiện. Chỉ cần một sự việc nhỏ cũng khiến bạn mất bình tĩnh, và xung đột với các đối tượng nhạy cảm như bệnh nhân và thân nhân chỉ là vấn đề thời gian. Vào những lúc như vậy, chúng ta cần lùi ra xa hơn, bước lên cao một vài nấc để có góc nhìn rộng hơn, bao quát hơn, thấu hiểu hoàn cảnh một cách toàn diện và sẽ có giải pháp ứng đối phù hợp và cảm thông hơn cho những chủ thể có hoàn cảnh đang bế tắc hơn ta. Đây là cách giúp hóa giải và trung hòa tình huống khó khăn.
**Có thể áp dụng ngay lập tức một cách hiệu quả?**
Rất tiếc khi phải nói rằng không, bạn không thể chỉ đọc tài liệu, nghe thuyết trình, tham gia các buổi tập huấn là ngay lập tức bạn có thể áp dụng và thực hành. Đây là một dạng kỹ năng, các hoạt động nêu trên rất hữu ích, giúp bạn hiểu rõ bản chất sự việc và có được các hướng dẫn để tham khảo. Nhưng yếu tố thành công nằm ở chính bạn, ở việc bạn hiểu và chấp nhận sự thật khách quan đến đâu và mong muốn áp dụng đến như thế nào. Các bài tập thực hành nho nhỏ, sẽ giúp bạn ngày một tiến bộ, tự vỡ ra nhiều điều từ trải nghiệm thực tế và chiêm nghiệm các sự việc xung quanh và của bản thân.
Ví dụ, khi gặp một bệnh nhân sẵng giọng, nói trống không và có thái độ gay gắt. Lần đầu bạn có thể nghĩ tếu tếu rằng chắc sáng nay anh ta vừa bị vợ la trước khi ra khỏi nhà. Ý nghĩ hài hước như vậy giúp bạn cảm thấy tình huống trở nên đơn giản và dễ tha thứ cho anh bệnh nhân khó tính đã “giận cá chém thớt” hơn. Lần thứ 2, gặp tình huống tương tự, bạn có thể nghĩ rằng chắc chị này tháng này nhận lương trễ nên những việc chi tiêu của chị đang gặp khó khăn lại còn thêm bệnh tật, tốn kém và mất thời gian… Tùy theo hoàn cảnh cụ thể mà bạn có thể hình dung ra vô vàn các sự cố mà người đối diện đang gặp khó khăn để cảm thông cho họ và trung hòa cái bản năng muốn đáp trả ngang cơ trong mình. Dần dà, bạn sẽ dễ dàng vượt những chuyện khó chịu đó, tiếp theo bạn sẽ thấy mình dễ bỏ qua và rộng lượng hơn, không còn quá vướng bận vào những việc vụn vặt. Sẽ có lúc bạn gặp phải tình huống rất khó khiến bạn muốn nổ tung. Nhưng chỉ cần bạn dừng lại trong 1 đến 3 giây, thì cơn sóng cảm xúc khổng lồ sẽ không dổ ụp lên đầu bạn. Những lúc như vậy, một cách hữu hiệu là cố gắng dừng lại, thoát ra khỏi không gian đó càng nhanh càng tốt. Đơn giản là bạn lấy một lý do nào đó xin lỗi bệnh nhân để ra ngoài khoảng 5 phút (đi lấy hồ sơ, hoặc kiểm tra kết quả trong hồ sơ…) khi ra ngoài thì nhờ người khác giải quyết giúp. Người thứ 3, thường sẽ khách quan và sự tiếp xúc mới đa phần sẽ phần nào làm dịu cảm xúc nóng giận của bệnh nhân, và hầu hết dẽ dễ dàng đạt được thỏa thuận hơn.
Chỉ cần bạn hiểu thấu 2 điều: a/Góc nhìn của bạn và bệnh nhân khác nhau, nên hai bên sẽ diễn giải sự việc khác nhau; b/ Bạn chỉ có thể điều chỉnh bản thân, chứ bạn không thể điều chỉnh người khác. Khi hiểu rõ hai điều trên, bạn sẽ có nhiều cách để giải quyết các tình huống vô cùng phong phú phát sinh hàng ngày.

## ️ Tha thứ: bỏ qua cho người để giúp ích chính mình

  * [Bạn có thể học cách tha thứ nhiều hơn?](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/tha-thu-bo-qua-cho-nguoi-de-giup-ich-chinh-minh#bn-c-th-hc-cch-tha-th-nhiu-hn)
  * [Để tha thứ là một phần của cuộc sống](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/tha-thu-bo-qua-cho-nguoi-de-giup-ich-chinh-minh#-tha-th-l-mt-phn-ca-cuc-sng)
  * [Suy ngẫm và ghi nhớ](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/tha-thu-bo-qua-cho-nguoi-de-giup-ich-chinh-minh#suy-ngm-v-ghi-nh)
  * [Thông cảm với người khác](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/tha-thu-bo-qua-cho-nguoi-de-giup-ich-chinh-minh#thng-cm-vi-ngi-khc)
  * [Tha thứ sâu sắc](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/tha-thu-bo-qua-cho-nguoi-de-giup-ich-chinh-minh#tha-th-su-sc)
  * [Quyết định tha thứ](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/tha-thu-bo-qua-cho-nguoi-de-giup-ich-chinh-minh#quyt-nh-tha-th)
  * [Tha thứ cho chính mình](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/tha-thu-bo-qua-cho-nguoi-de-giup-ich-chinh-minh#tha-th-cho-chnh-mnh)
  * [Tài liệu tham khảo](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/tha-thu-bo-qua-cho-nguoi-de-giup-ich-chinh-minh#ti-liu-tham-kho)


Cho dù đó là một cuộc cãi vã đơn giản với bạn đời hay sự oán giận kéo dài đối với người thân, mâu thuẫn chưa được giải quyết có thể ảnh hưởng sâu rộng hơn bạn cảm nhận: nó có thể ảnh hưởng đến sức khỏe thể chất của bạn. Tuy nhiên, hành động tha thứ có thể mang lại lợi ích cho sức khỏe của bạn: giảm nguy cơ đau tim; cải thiện mức cholesterol và giấc ngủ; và giảm đau, giảm cao huyết áp, và giảm lo lắng, trầm cảm và căng thẳng. Các nghiên cứu cũng đã chỉ ra sự liên quan mật thiết hơn giữa sự tha thứ và sức khỏe khi tuổi tác tăng lên.
Theo bác sĩ [Karen Swartz](https://www.hopkinsmedicine.org/profiles/results/directory/profile/0006521/karen-swartz), Giám đốc Phòng khám tư vấn rối loạn tâm trạng tại Bệnh viện Johns Hopkins, sự tổn thương và thất vọng đi kèm một gánh nặng lớn về thể chất. Sự tức giận kinh niên đưa bạn vào chế độ “chiến đấu” hoặc “bay” (fight-or-flight mode) của hệ thần kinh thực vật, dẫn đến nhiều thay đổi về nhịp tim, huyết áp và phản ứng miễn dịch. Những thay đổi đó làm tăng nguy cơ trầm cảm, bệnh tim và tiểu đường và nhiều tình trạnh khác. Ngược lại, sự tha thứ sẽ làm giảm căng thẳng và giúp sức khỏe được cải thiện.
## **Bạn có thể học cách tha thứ nhiều hơn?**
Tha thứ không chỉ là nói ra vài lời. Đây là một quá trình tích cực, trong đó bạn đưa ra quyết định có ý thức để từ bỏ cảm giác tiêu cực, cho dù đối phương có xứng đáng hay không. Khi bạn giải phóng sự tức giận, oán giận và thù địch, bạn bắt đầu cảm thấy đồng cảm, thương cảm và đôi khi thậm chí là tình cảm với người đã làm bạn tổn thương.
Các nghiên cứu đã phát hiện rằng một số người có bản năng dễ tha thứ hơn. Những người này có xu hướng hài lòng hơn với cuộc sống, ít trầm cảm, lo lắng, căng thẳng, giận dữ và thù hận. Người giữ mãi mối hận thù có nhiều nguy cơ bị trầm cảm nặng và rối loạn căng thẳng sau chấn thương, cũng như các bệnh khác, nhưng điều đó không có nghĩa là họ không thể tự rèn luyện để hành động lành mạnh hơn. Trên thực tế, 62% người trưởng thành tại Mỹ nói rằng họ cần sự tha thứ nhiều hơn trong cuộc sống.
## **Để tha thứ là một phần của cuộc sống**
Tha thứ là một lựa chọn. Bạn đang chọn cung cấp sự từ bi và sự đồng cảm với người đã làm bạn bực mình.
### **Suy ngẫm và ghi nhớ**
Điều đó bao gồm các sự kiện liên quan, cách bạn phản ứng, cảm nhận và sự tức giận/tổn thương đã ảnh hưởng đến bạn như thế nào.
### **Thông cảm với người khác**
Ví dụ, nếu người bạn đời của bạn lớn lên trong một gia đình nghiện rượu, sự tức giận khi bạn nhìn thấy quá nhiều ly rượu trong nhà có thể dễ chấp nhận hơn. Nếu bạn biết một phụ nữ đã từng mất con vì bệnh tật, bạn sẽ thông cảm hơn cho thái độ hùng hổ của cô ta khi người con thứ hai mắc bệnh.
### **Tha thứ sâu sắc**
Tha thứ cho ai đó đơn giản chỉ vì bạn nghĩ rằng không có lựa chọn nào khác hoặc vì tôn giáo của bạn có thể là đủ để chữa lành tổn thương. Tuy nhiên, một nghiên cứu cho thấy những người tha thứ xuất phát từ việc hiểu rằng không ai là hoàn hảo có thể nối lại mối quan hệ bình thường với người kia, ngay cả khi người đó không bao giờ xin lỗi. Những người chỉ tha thứ để cứu vãn quan hệ thường sẽ bị tổn thương với một mối quan hệ xấu hơn.
### **Từ bỏ kỳ vọng**
Một lời xin lỗi từ bạn có thể sẽ không gợi ra lời xin lỗi từ đối phương, và không thay đổi mối quan hệ với người đó. Nếu không mong đợi, bạn sẽ không phải thất vọng.
### **Quyết định tha thứ**
Một khi bạn đưa ra lựa chọn tha thứ, hãy “đóng dấu” nó bằng hành động. Nếu bạn không thể nói chuyện với người đã làm mình buồn lòng, hãy viết về sự tha thứ của bạn trên một cuốn sổ hoặc nói điều đó với người mà bạn tin tưởng.
### **Tha thứ cho chính mình**
Hành động tha thứ còn bao gồm tha thứ cho cả chính mình. Chẳng hạn, nếu chồng hay vợ bạn ngoại tình, hãy nhận ra rằng chuyện đó không phản ánh giá trị của bạn.
## **Tài liệu tham khảo**
  1. <https://publichealthliteracy.org/>
  2. <https://www.psychologytoday.com/>
  3. <https://www.hopkinsmedicine.org/health/>
  4. <https://www.huffpost.com/>
  5. <https://edition.cnn.com/2019/06/05/health/forgiveness-health-explainer/index.html>


  * [Bạn có thể học cách tha thứ nhiều hơn?](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/tha-thu-bo-qua-cho-nguoi-de-giup-ich-chinh-minh#bn-c-th-hc-cch-tha-th-nhiu-hn)
  * [Để tha thứ là một phần của cuộc sống](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/tha-thu-bo-qua-cho-nguoi-de-giup-ich-chinh-minh#-tha-th-l-mt-phn-ca-cuc-sng)
  * [Suy ngẫm và ghi nhớ](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/tha-thu-bo-qua-cho-nguoi-de-giup-ich-chinh-minh#suy-ngm-v-ghi-nh)
  * [Thông cảm với người khác](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/tha-thu-bo-qua-cho-nguoi-de-giup-ich-chinh-minh#thng-cm-vi-ngi-khc)
  * [Tha thứ sâu sắc](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/tha-thu-bo-qua-cho-nguoi-de-giup-ich-chinh-minh#tha-th-su-sc)
  * [Quyết định tha thứ](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/tha-thu-bo-qua-cho-nguoi-de-giup-ich-chinh-minh#quyt-nh-tha-th)
  * [Tha thứ cho chính mình](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/tha-thu-bo-qua-cho-nguoi-de-giup-ich-chinh-minh#tha-th-cho-chnh-mnh)
  * [Tài liệu tham khảo](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/tha-thu-bo-qua-cho-nguoi-de-giup-ich-chinh-minh#ti-liu-tham-kho)



## Có những khi, điều bạn cần là một bắt đầu mới

Những người nói về tương lai đang lừa dối người khác; những người nói về quá khứ đang tự lừa dối chính mình.
Tất cả quá khứ hãy để gió cuốn đi, lật hoàn toàn sang một trang mới và sống tốt hiện tại. Những người không thể thoát ra khỏi quá khứ đang làm tổn thương chính mình.
Những người không thể thoát ra khỏi quá khứ sẽ không bao giờ có thể nắm lấy tương lai, họ chỉ luôn đắm chìm trong quá khứ, và sẽ không thể bắt đầu một cuộc sống mới.
Chỉ có buông bỏ quá khứ, chúng ta mới có thể sống tốt ở hiện tại và đón nhận tương lai.
Cuộc sống là một quá trình trưởng thành. Ai cũng có một quá khứ, cho dù quá khứ đó không thể nguôi ngoai hay đau đớn đến đâu thì đó cũng chỉ là sự trải nghiệm mà thôi.
Tất cả quá khứ, không chỉ mang đến cho bạn nỗi đau mà còn khiến bạn trưởng thành hơn, rèn giũa một bạn chín chắn hơn, giỏi giang hơn.
Chỉ khi đối mặt với quá khứ, chúng ta mới có thể thực sự buông bỏ quá khứ, thoát khỏi nỗi đau và dốc hết sức mình để bắt đầu một cuộc sống mới.
Trong cuộc sống, điều gì đến sẽ luôn đến, điều gì đã qua thì nên buông bỏ. Bình tĩnh đối mặt với mọi chuyện, đừng sợ tương lai, đừng nghĩ về quá khứ, hãy nắm bắt hiện tại rồi sẽ bình yên.
Chúng ta không thể thay đổi quá khứ, điều duy nhất chúng ta có thể làm là nắm bắt hiện tại và xứng đáng với tương lai của mình.
Càng lưu giữ nhiều kỷ niệm, bạn càng khiến bản thân tổn thương nhiều hơn. Ký ức càng chi tiết thì bạn càng dễ tạo ra một cái lồng suy nghĩ cho bản thân, bị mắc kẹt trong đó và càng chìm sâu vào trong, bạn càng không thể tự giải thoát cho mình.
Nếu bạn muốn không hối tiếc trong suốt quãng đời còn lại của mình, bạn phải là một người thấu đáo và học cách tạo động lục cho chính mình.
Chúng ta phải cắt bỏ những suy nghĩ phân tâm không cần thiết đó, thay đổi con người hiện tại, để cái tôi vốn bị thu mình trong quá khứ đứng lên và bước tiếp.
Thực ra, cách sống tốt nhất trên đời là buông bỏ quá khứ. Bước ra khỏi quá khứ, và hết mình để sống tốt hiện tại, đón nhận tương lai đầy khát khao.
Trong phần đời còn lại của mình, bạn cũng có thể buông bỏ quá khứ, đặt trái tim mình về con số không, và để cuộc sống của bước sang một trang mới.
Cuộn mình trong cảm xúc của quá khứ, đối với cuộc sống hiện tại, bạn sẽ mất tập trung, không thể quản lý cuộc sống của mình bằng trái tim của mình, và bạn sẽ chỉ nhận được nỗi đau, không có niềm vui và hạnh phúc. Sau đó, thời gian sẽ trôi qua trong đau đớn, thất bại, và tương lai sẽ chỉ trôi qua trong nháy mắt.
Hãy buông bỏ quá khứ khó chịu và tạo dựng tương lai bằng sự siêng năng. Con người không ngừng lớn lên, trưởng thành và trở nên hoàn thiện.
Không phải ai cũng bắt đầu đi đúng hướng của cuộc đời kể từ ngày xuống trần gian. Tất cả họ đều sẽ trải qua những giai đoạn khủng hoảng và khó khắn. Nhưng điều đó không có nghĩa là bạn trong tương lai chắc chắn sẽ giống như bạn trong quá khứ. Chỉ cần bạn sẵn sàng thay đổi, bạn chắc chắn sẽ trở nên tốt hơn, thành công hơn và là chính mình hơn.
Bạn không thể từ bỏ bản thân cũng như những nỗ lực của mình chỉ vì quá khứ không mấy tốt đẹp, đó là sự thể hiện vô trách nhiệm đối với tương lai của chính bạn. Cho dù trước kia bạn có như thế nào, cho dù là cực kỳ không chịu nổi, hoàn toàn bại trận, bạn cũng không được tuyệt vọng.
Thay vào đó, chúng ta nên buông bỏ những điều không hài lòng về bản thân trong quá khứ, thay đổi bằng sự chăm chỉ, siêng năng và tạo ra một tương lai tốt đẹp hơn. “Gieo nhân nào gặp quả ấy”, mồ hôi nước mắt cuối cùng sẽ mang lại kết quả mỹ mãn, đồng thời trở nên tốt hơn, có một tương lai tươi sáng.
Cho dù chuyện gì đã xảy ra trong quá khứ, chuyện gì đã xảy ra ngày hôm qua, thì ngày mai mặt trời vẫn sẽ mọc. Khi mặt trời mọc là một ngày mới, bạn nên dốc hết sức lực và nỗ lực của bản thân để đấu tranh cho tương lai thuộc về bạn.
Hãy rũ bỏ những ký ức đau buồn trong quá khứ, mỉm cười đối mặt với cuộc sống
Đôi khi những trải nghiệm tồi tệ có thể gây ra đau đớn. Và những nỗi đau này sẽ khiến con người ta tuyệt vọng, sống trong bóng tối và ký ức của nỗi đau, cuối cùng sống như một cái xác khộng hồn.
Sống một đời với những cảm xúc đau đớn, bạn sẽ không bao giờ cảm nhận được hạnh phúc và niềm vui trong cuộc sống.
May mắn và bất hạnh trong quá khứ từ lâu đã được đúc kết trước, thời gian không thể quay ngược trở lại. Điều duy nhất chúng ta có thể làm là quên đi những bất hạnh đó, đối mặt với cuộc sống bằng một thái độ lạc quan, đón nhận tương lai với một thái độ tích cực.
Những khoảng thời gian đau khổ đó là những mảng tối chỉ có thể tự mình vượt qua, là những đám mây chỉ có thể tự bay ra ngoài.
Dù quá khứ có cay đắng hay đau khổ thế nào, chúng ta đều nên học cách bỏ qua quá khứ và mỉm cười đối mặt với cuộc sống hiện tại.
Cuộc sống thực ra là một quá trình tiến về phía trước. Đã vậy, tại sao lại níu kéo quá khứ.
Cố chấp với quá khứ là một điều sai lầm. Nó chỉ khiến bạn lãng phí hiện tại và trì hoãn tương lai.
Đời người ngắn ngủi và chúng ta nên nhìn về phía trước. Dù quá khứ có thế nào đi nữa chúng ta cũng nên dùng tâm lý tốt nhất để sống cuộc sống hiện tại của mình. Mong các bạn hãy xem nhẹ quá khứ, sống thấu đáo hơn, biết trân trọng hiện tại, sống tốt hiện tại và đón nhận tương lai tươi sáng với thái độ lạc quan, yêu đời.
Buông bỏ quá khứ không phải là chuộc lỗi cho bản thân, mà là giải thoát bản thân khỏi nỗi đau, nắm bắt hiện tại và tương lai.

## 'Đưa tay đây mẹ xem nào. Hình gì xấu quắc!'

Mẹ mình hồi xưa là "tiểu thư" quận Phú Nhuận, gia đình khá giả lắm. Xong ông bà ngoại làm ăn thất bát, khiến kinh tế gia đình đi xuống. Tới mức mẹ phải đi phụ ông bà giữ xe ở cổng chùa. Không có tiền đóng lệ phí thi đại học, tốt nghiệp xong mẹ đi làm đủ thứ nghề.
Xong mình ra đời rồi tới em gái. Ba mình mất sớm nên cô tiểu thư quận Phú Nhuận đã nhọc nhằn nuôi hai đứa con lớn nên người. Mình với mẹ hay tâm sự lắm, trên trời dưới đất, học tập rồi tương lai.
Tới khoảng thời gian mình lên đại học, đi làm rồi chơi nhạc, ít khi có mặt ở nhà. Mẹ vẫn thương mình lắm, mình biết là vậy, dù cho những cuộc nói chuyện của hai mẹ con không còn nhiều nội dung như trước nữa. Ngày nào mẹ cũng nhắn cho mình mấy câu như:
"A lo Con dang o dau Con co ve nha khong De me biet nau com"
Nên là mình chốt hạ, hình xăm đầu tiên của mình sẽ là một kỷ niệm, một lời nhắc nhở cho mình. Dù mình có đi tới đâu thì cũng luôn phải nhớ về nhà, vì nhà là nơi an toàn nhất. Có mẹ và em gái mình là mình vui lắm rồi. Cơm tiệm nhà hàng, hàu nướng phô mai không có tuổi bằng món thịt ba rọi chiên của mẹ đâu.
"Đưa tay đây mẹ xem nào. Hình gì xấu quắc!"
Mẹ vừa cắn miếng bánh kem, mặt mẹ mếu máo, xong vui lắm. Nói vậy thôi chứ mình biết chắc là mẹ thương mình lắm. Chúc mừng sinh nhật mẹ!
**Nguồn: Nguyễn Hữu Minh Tân**

## Đừng bắt bé lớn phải làm gương cho bé nhỏ

Khi nhà có 2-3 đứa trẻ, cha mẹ thường mong đợi trẻ lớn phải ngoan, phải biết làm gương cho em. Thực ra, đây không phải là nhiệm vụ của trẻ, mà chính là của cha mẹ.
**CÔNG BẰNG LÀ CHÌA KHÓA ĐỂ NUÔI DẠY NHỮNG ĐỨA TRẺ BIẾT YÊU THƯƠNG NHAU.**
Trẻ được sinh ra sớm hơn không có nghĩa là trẻ phải làm hình mẫu cho ai, mà bản thân trẻ cũng đang phải nhìn vào hình mẫu khác. Đó chính là cha mẹ. Thực vậy, nghiên cứu dài hơn 80 năm tại ĐH Harvard cho thấy " Cha mẹ chính là người có ảnh hưởng quan trọng nhất đối với trẻ trong việc xây dựng và bắt chước hành vi".
Điều này có nghĩa rằng khi cha mẹ đối xử với tất cả các con một cách công bằng thì mỗi đứa trẻ sẽ học cách xây dựng tình yêu trên sự công bằng.
Vậy, đứa trẻ nhỏ có bị ảnh hưởng bởi anh chị của chúng không? Báo cáo của TS. Rogers, ĐH Texas, Mỹ cho thấy anh chị lớn có thể ảnh hưởng đến em của mình trong cách đưa ra quyết định ở độ tuổi teen. Tuy nhiên, điều này chỉ xảy ra khi mối quan hệ của những đứa trẻ được xây dựng trong yêu thương, công bằng ở độ tuổi nhỏ.
**LÀM SAO DẠY CÁC CON BIẾT YÊU THƯƠNG NHAU, DẪN DẮT NHAU PHÁT TRIỂN?**
**1. Tránh các lời nói gây chia rẻ trong những hoạt động hằng ngay, kiểu như:**
+ Ăn:
Những dạng nói tương tự như: "Tin ăn ngoan không, chả khóc gì! Chị Na ăn hư quá"
Cách sửa lại: đừng so sánh bất kì tính chất nào giữa các con vì mỗi đứa là một sự tuyệt vời của tạo hóa.
+ Ngủ
"Ngủ đi con, lăn lộn hoài để em ngủ nữa chứ"
Người mẹ vô tình lấy đứa em làm lí do để bắt đứa lớn hơn ngủ. Vô tình đưa lợi ích của đứa này làm điều kiện cho bất lợi của đứa khác.
Cách sửa lại: dù biết cũng cần cho bé lớn hiểu rằng em nhỏ sẽ cần chăm sóc nhiều hơn, nhưng nó không phải cách để cho trẻ biết kiểu dạng "ưu tiên", thay vào đó bạn chỉ cần nói rõ cho bé hiểu tại sao trẻ lại phải làm điều đó: VD: "Vì em còn nhỏ, dễ thức khi có tiếng động. Con giúp mẹ đừng làm ồn nhé! Được không!"
+ Chơi
Người bà vỗ về đứa nhỏ "Ngoan ngoan nào!" và quát đứa lớn "Na đưa con gấu cho em!" dù đó là đến lượt chơi của chị Na.
Cách sửa lại: nhường là từ không có trong tự điển của trẻ vì vậy bắt trẻ phải nhường là 1 điều khó, thay vào đó hãy tuân thủ trò chơi đến lượt.
+ Yêu thương
Những câu nói đùa tưởng chừng vô hại, nhưng lại làm chia rẻ lớn tình yêu thương.
Ví dụ, "Ngoan ngoan mẹ thương! Mẹ thương hơn chị Na luôn nhé!"
Hoặc người bà thường hay nói đùa "Mẹ mày đâu? Thế nó bỏ rơi mày rồi à, lại đây với bà bà thương!".
Cách sửa lại: nói khích hay nói đùa là cái mà cha mẹ nên tránh khi trò chuyện với trẻ. Tâm hồn non nớt các con lúc này đều tin là đúng vì trẻ chưa phân biệt được đâu là lời nói đùa hay thật trước 8 tuổi.
**2. Dạy trẻ hợp tác vui chơi cùng nhau.**
TS. Feinberg, ĐH Bang Penn, Mỹ từng nói rằng: cách làm giảm các xung đột xảy ra giữa các bé là hãy dạy chúng hợp tác cùng nhau trong vui chơi, giải quyết vấn đề, quan trọng là giải quyết xung đột xảy ra phải công bằng và lắng nghe trẻ, cho chúng nhận xét lỗi sai-đúng của bé còn lại.
Khi hợp tác vui chơi cùng nhau hoặc vì 1 kết quả chung, những con hổ nhỏ sẽ tự biến mất, nhường chỗ cho tinh thần hợp tác và đối mặt thử thách. VD. 2 bé có thể cùng chơi 1 trò chơi quy định luật chơi, phạt - thưởng công bằng dù ai lớn ai nhỏ.
Xếp hình puzzle cùng nhau là hoạt động có thể khuyến khích cho các bé 3-6 tuổi. Trẻ cần thống nhất để đưa ra vị trí đặt vào. Để dạy chúng thống nhất, hãy để chúng tự tranh luận vị trí và không có can thiệp của bạn. Nếu không thống nhất, hãy để mỗi đứa xếp vào theo ý để nhận ra sai lầm. Khi đứa nào nhận ra sai, thì hãy tự gỡ ra và đưa đứa khác.
**3. Làm gương cho trẻ trong cách đối xử công bằng, quan tâm và giúp đỡ nhau** khi đáp ứng với các bé, hoặc những người khác trong gia đình. Khi đứa trẻ được nuôi dưỡng trong gia đình có cha mẹ và các cô chú dì yêu thương nhau thì chúng cũng sẽ lớn lên biết yêu thương nhau.
**4. Ghi nhận, đánh giá cao những gì con đã cố gắng làm được**
Trueblood nói, một trong những hành động quan trọng nhất mà bố mẹ có thể làm là thực sự ghi nhận, thể hiện niềm tự hào và đánh giá cao khi con biết quan tâm, đối xử tốt với em. Bà cũng nói thêm, thay vì chỉ ra những gì bạn không thích, hãy thử tập trung nhiều nhất có thể vào những gì con làm mà bạn thấy là tích cực. Và bạn có thể để con nghe được những lời khen ngợi ấy khi nói chuyện với người khác hoặc trao đổi trực tiếp với con.
Bạn có thể nói cho con biết mình đã cảm thấy vui mừng, hạnh phúc ra sao khi bạn nhìn thấy con giúp em làm bài tập về nhà, động viên em khi thấy em buồn hay chia sẻ cho em mình ăn món mà em yêu thích.
Điều quan trọng là mình đừng đặt áp lực lên những đứa trẻ là cần phải làm mẫu cho em và cũng sẽ hoàn toàn bình thường nếu đứa con lớn không muốn trở thành một mẫu hình tích cực cho em như bố mẹ đang mong đợi. Vì điều quan trọng hơn hết là các em bé ấy lớn lên mạnh khỏe, hạnh phúc thay vì lo lắng xem liệu mình có đang làm đúng hay sai, phải vậy không?

## ️ Những “lời khuyên” khi động viên người khác cũng cần phải chú ý

  * [“Mọi chuyện rồi sẽ tốt đẹp lên/sẽ ổn hơn thôi”](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/nhung-loi-khuyen-khi-dong-vien-nguoi-khac-cung-can-phai-chu-y#mi-chuyn-ri-s-tt-p-lns-n-hn-thi)
  * [“Người khác còn gặp chuyện tệ hơn/còn khổ hơn nhiều”](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/nhung-loi-khuyen-khi-dong-vien-nguoi-khac-cung-can-phai-chu-y#ngi-khc-cn-gp-chuyn-t-hncn-kh-hn-nhiu)
  * [“Bạn phải tích cực lên/mạnh mẽ lên”](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/nhung-loi-khuyen-khi-dong-vien-nguoi-khac-cung-can-phai-chu-y#bn-phi-tch-cc-lnmnh-m-ln)
  * [Ngoài động viên, bạn có thể làm gì giúp họ?](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/nhung-loi-khuyen-khi-dong-vien-nguoi-khac-cung-can-phai-chu-y#ngoi-ng-vin-bn-c-th-lm-g-gip-h)


## “Mọi chuyện rồi sẽ tốt đẹp lên/sẽ ổn hơn thôi”
Đây có lẽ là lời khuyên mà ai gặp chuyện buồn cũng từng nghe qua. Bản chất của nó hướng người nghe suy nghĩ tích cực về một tương lai tươi sáng hơn, nhưng thực tế không phải lúc nào cũng như ý.
Ít nhất 3 người đã nói với tôi câu này vào thời điểm cuối năm ngoái, khi bà nội và em họ tôi qua đời chỉ cách nhau vài ngày. Dù khi đó rất tuyệt vọng, có thời điểm tôi thực sự đã tin tưởng vào điều đó, rằng thời gian sau đó mọi việc sẽ tốt đẹp hơn. Thế nhưng 5 tháng sau đó, tôi tiếp tục mất bố.
Nhiều người gặp vấn đề sức khỏe tâm lý cũng như vậy. Họ hiểu rằng vấn đề của họ không kết thúc trong một sớm một chiều. Và ở đời không ai học được chữ “ngờ”, biết đâu mọi việc đối với họ không tốt lên mà chỉ tệ đi?
_**Cách nói thay thế:**_ “Mình mong/hy vọng mọi chuyện sẽ ổn hơn với bạn”.
Chỉ cần thêm động từ “hy vọng” là bạn có thể biến câu nói trên thành một lời động viên chân thành thay vì khẳng định chắc chắn vào tương lai (mà bạn hay người nghe đều không thể đoán trước). Về phía người nghe, họ cũng tránh được cảm giác bị lừa dối nếu mọi việc diễn tiến theo chiều hướng xấu hơn.
## “Người khác còn gặp chuyện tệ hơn/còn khổ hơn nhiều”
Đây là kiểu lời khuyên được nhiều người ở thế hệ trước áp dụng khi con, em hoặc cháu đang gặp khó khăn. Đặc biệt có những người từng trải qua chiến tranh, nghèo đói hoặc biến cố lớn thường so sánh như vậy để người nghe thấy, nỗi khổ của họ “chưa là gì” so với nỗi khổ của người khác mà gắng sức vượt qua.
Trên thực tế, kiểu khuyên răn này phủ nhận hoàn toàn cảm xúc của người nghe, cho rằng nỗi buồn của họ không hợp lệ. Bởi khi con người gặp chuyện buồn vì bất kể lý do gì, não bộ đều giải phóng cortisol và những hormone căng thẳng khác. Quá trình này ở mọi người là như nhau, vì vậy việc so sánh nỗi buồn trở nên rất khập khiễng. Chưa kể, nếu biết nỗi buồn của mình không “xứng đáng” được công nhận, người nghe sẽ cảm thấy tổn thương nhiều hơn là được an ủi.
_**Cách nói thay thế:**_ “Mình luôn ở đây bên bạn/Mình luôn sẵn sàng lắng nghe bạn”.
Lắng nghe là biện pháp đơn giản và hiệu quả ai cũng có thể áp dụng, bất kể có từng trải qua đau buồn hay không. Câu nói này vừa cho thấy bạn công nhận nỗi buồn của người nghe, vừa mở ra không gian an toàn cho họ để giãi bày tâm sự khi cần.
## “Bạn phải tích cực lên/mạnh mẽ lên”
Đây lại là một lời khuyên kinh điển khiến người nghe tin rằng, tích cực là cách duy nhất giúp họ vượt qua mọi đau khổ. Tuy nhiên làm thế nào để tích cực hơn, thì có khi cả người nói lẫn người nghe đều không biết.
“Mạnh mẽ lên” cũng là một lời khuyên dễ phản tác dụng. Chẳng hạn trong gia đình có tang, người trẻ thường được kỳ vọng phải mạnh mẽ để làm chỗ dựa cho cha mẹ già và con nhỏ - những đối tượng được xem là dễ bị tổn thương hơn. Nhưng chính họ cũng vô cùng đau buồn và cần được giãi bày. Vì vậy câu nói này vô tình tạo áp lực cho người nghe, khiến họ kìm nén cảm xúc của mình. Lâu dần, điều này có thể dẫn tới trầm cảm và những hệ lụy nghiêm trọng hơn.
_**Cách nói thay thế:**_ “Bạn đã làm rất tốt/Bạn đã thật mạnh mẽ rồi”.
Nghiên cứu cho thấy, chấn thương tâm lý tác động mạnh đến thùy trán - cơ quan điều khiển những chuyển động lý trí của cơ thể. Kết quả là những việc tưởng chừng đơn giản như đánh răng hay tắm rửa bỗng trở nên vô cùng khó khăn.
Vì vậy trong bất kể nỗi đau nào, việc đánh bại được những suy nghĩ cực đoan và duy trì được nếp sống hàng ngày đã là một điều phi thường. Và một khi nhận thấy nỗ lực sống tiếp của mình được công nhận, người nghe sẽ cảm thấy an toàn và bình tĩnh để tìm ra giải pháp cho riêng mình.
## Ngoài động viên, bạn có thể làm gì giúp họ?
**_Thường xuyên hỏi thăm tình hình:_** Việc này giúp bạn nắm được tâm trạng họ, có điều gì bất ổn có thể xử lý kịp thời. Bên cạnh đó, người đang trải qua chấn thương tâm lý cũng thường bị xáo trộn nếp sinh hoạt. Trường hợp này bạn có thể nhắc họ ăn uống đầy đủ, ngủ đủ giấc để đảm bảo sức khỏe.
_**Hỗ trợ họ bằng nhiều cách:**_ Nếu ở gần, bạn có thể giúp họ một số việc nhà, lo thủ tục hậu sự cho người thân hoặc loại bỏ những món đồ khiến họ nhớ đến người yêu cũ.
**_Lắng nghe và ôm họ thật lâu:_** Trong nhiều trường hợp, nếu không biết nên nói gì thì bạn luôn có thể lắng nghe họ tâm sự. Và nếu ở gần, một cái ôm thật lâu sẽ là cách đơn giản nhất để khơi dậy hormone oxytocin, giúp họ cảm thấy được yêu thương và bình ổn tâm trạng hơn.
  * [“Mọi chuyện rồi sẽ tốt đẹp lên/sẽ ổn hơn thôi”](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/nhung-loi-khuyen-khi-dong-vien-nguoi-khac-cung-can-phai-chu-y#mi-chuyn-ri-s-tt-p-lns-n-hn-thi)
  * [“Người khác còn gặp chuyện tệ hơn/còn khổ hơn nhiều”](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/nhung-loi-khuyen-khi-dong-vien-nguoi-khac-cung-can-phai-chu-y#ngi-khc-cn-gp-chuyn-t-hncn-kh-hn-nhiu)
  * [“Bạn phải tích cực lên/mạnh mẽ lên”](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/nhung-loi-khuyen-khi-dong-vien-nguoi-khac-cung-can-phai-chu-y#bn-phi-tch-cc-lnmnh-m-ln)
  * [Ngoài động viên, bạn có thể làm gì giúp họ?](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/nhung-loi-khuyen-khi-dong-vien-nguoi-khac-cung-can-phai-chu-y#ngoi-ng-vin-bn-c-th-lm-g-gip-h)



## ️ Những cách suy nghĩ có thể khiến bạn căng thẳng và dễ dàng bế tắc

  * [1. Trắng đen rạch ròi ("Black and White” Thinking)](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/nhung-cach-suy-nghi-co-the-khien-ban-cang-thang-va-de-dang-be-tac#1-trng-en-rch-riblack-and-white-thinking)
  * [2. Quy chụp (Overgeneralizing)](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/nhung-cach-suy-nghi-co-the-khien-ban-cang-thang-va-de-dang-be-tac#2-quy-chp-overgeneralizing)
  * [3. Giảm nhẹ điều tốt đẹp (Disqualifying the positive)](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/nhung-cach-suy-nghi-co-the-khien-ban-cang-thang-va-de-dang-be-tac#3-gim-nh-iu-tt-p-disqualifying-the-positive)
  * [4. Quy về bản thân (Personalization)](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/nhung-cach-suy-nghi-co-the-khien-ban-cang-thang-va-de-dang-be-tac#4-quy-v-bn-thn-personalization)
  * [5. Tôi phải/Tôi nên (Shoulds)](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/nhung-cach-suy-nghi-co-the-khien-ban-cang-thang-va-de-dang-be-tac#5-ti-phiti-nn-shoulds)
  * [6. So sánh với người khác (Social comparison)](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/nhung-cach-suy-nghi-co-the-khien-ban-cang-thang-va-de-dang-be-tac#6-so-snh-vi-ngi-khc-social-comparison)
  * [7. Phóng đại và giảm nhẹ (Magnification and minimization)](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/nhung-cach-suy-nghi-co-the-khien-ban-cang-thang-va-de-dang-be-tac#7-phng-i-v-gim-nh-magnification-and-minimization)
  * [8. Màng lọc tâm trí (Mental filtering)](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/nhung-cach-suy-nghi-co-the-khien-ban-cang-thang-va-de-dang-be-tac#8-mng-lc-tm-tr-mental-filtering)
  * [9. Cảm tính (Emotional Reasoning)](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/nhung-cach-suy-nghi-co-the-khien-ban-cang-thang-va-de-dang-be-tac#9-cm-tnh-emotional-reasoning)
  * [10. Kết luận vô căn cứ (Jumping to conclusions)](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/nhung-cach-suy-nghi-co-the-khien-ban-cang-thang-va-de-dang-be-tac#10-kt-lun-v-cn-c-jumping-to-conclusions)


### **1. Trắng đen rạch ròi ("Black and White” Thinking)**
Kiểu tư duy này làm chúng ta đánh giá sự việc một cách đúng sai tuyệt đối, không trắng thì chỉ có thể là đen. Mọi thứ phải hoàn hảo, hoặc chỉ là một sự thất bại. Nhưng thực tế thì mọi việc đều có nhiều khía cạnh.
_Ví dụ: A có một người bạn thường hay giúp đỡ mình nhiều việc. Một lần, bạn đó từ chối giúp A. Thế là A lập tức có suy nghĩ rằng bạn ấy đã xem mình như người xa lạ, không còn muốn tiếp xúc với mình nữa._
### **2. Quy chụp (Overgeneralizing)**
Bạn chỉ dựa vào một sự việc hoặc một bằng chứng duy nhất để đi đến một kết luận chung. Khi vấp ngã một lần, bạn cho rằng điều đó sẽ lặp đi lặp lại mãi mãi.
_Ví dụ: Khi bị điểm kém ở một bài kiểm tra, bạn học sinh ấy cho rằng những bài sau cũng sẽ vậy và mình là đứa trời sinh dốt Toán._
### **3. Giảm nhẹ điều tốt đẹp (Disqualifying the positive)**
Thay vì lờ hẳn đi mặt tích cực, chúng ta có thể sẽ lý giải nó như là chuyện ăn may và gạt bỏ nó. Hội chứng kẻ giả mạo (impostor syndrome) là một ví dụ về dạng này.
_Ví dụ: Được đạt điểm cao, bạn cho rằng mình ăn may. Khi được thăng chức, bạn nghĩ do thiếu người chứ chẳng phải mình giỏi giang gì._
### **4. Quy về bản thân (Personalization)**
Với dạng suy nghĩ này, chúng ta có xu hướng quy hết trách nhiệm về mình, cả trong những tình huống không hề có sự liên quan nào.
_Ví dụ: Bạn bị giật điện thoại, thế là bạn đổ lỗi cho mình, nếu bạn không ra ngoài vào lúc đó, không chọn con đường đó, và không lấy điện thoại ra thì đã không bị mất._
### **5. Tôi phải/Tôi nên (Shoulds)**
Bạn vô thức đặt ra các quy tắc cư xử cho cả mình và người khác, nhưng nghịch lý là lại dẫn đến cảm giác thờ ơ và mất động lực. Thậm chí, bạn tức giận hoặc cảm thấy tội lỗi khi có ai đó phá vỡ các quy tắc này, kể cả bạn.
_Ví dụ: Gặp 1 chuyện rất buồn, bạn lập tức ép mình: “Tôi không được khóc!” hay “Tôi phải mạnh mẽ lên!” Và nếu không làm được, bạn lại tức giận và xấu hổ về mình._
### **6. So sánh với người khác (Social comparison)**
So sánh là điều tất yếu trong xã hội. Tuy nhiên, nếu việc này xuất hiện nhiều, ngày càng thiếu công bằng và bắt đầu khó kiểm soát thì có lẽ bạn nên tìm biện pháp để cân bằng.
_Ví dụ: So sánh thiếu công bằng là khi bạn so sánh quá trình của mình với thành tựu của người khác. Hoặc bạn so sánh thành tựu, khả năng của mình với thành tựu, khả năng của người khác nhưng bỏ qua các yếu tố như bối cảnh, điểm mạnh và yếu của từng người,..._
### **7. Phóng đại và giảm nhẹ (Magnification and minimization)**
Khi suy nghĩ theo hướng này, một trong hai trường hợp sẽ xảy ra: Bạn phóng đại tầm quan trọng của một điều không đáng kể (có thể là một lỗi lầm), hoặc xem nhẹ thành tích cá nhân.
_Ví dụ: Bạn được chọn làm sinh viên đại diện để phát biểu trong lễ tốt nghiệp. Do hồi hộp nên bạn nói vấp đôi chỗ. Khi được bạn bè khen ngợi bài phát biểu, bạn thấy xấu hổ vì nghĩ rằng mình đã phá hỏng buổi lễ do vài lỗi vấp váp của mình. Trong trường hợp này, bạn phóng đại lỗi sai nhỏ và xem nhẹ thành tích (bài phát biểu) của mình._
### **8. Màng lọc tâm trí (Mental filtering)**
Vốn được gọi với các tên 'trừu tượng có chọn lọc' (selective abstraction), là khi bạn chỉ tập trung vào chi tiết ngoài ngữ cảnh mà bỏ qua các khía cạnh khác của toàn bộ tình huống. Chi tiết đó thường mang tính tiêu cực, và những điều bị bỏ qua thường là yếu tố tích cực.
_Ví dụ: Bạn bận lòng vì sếp khó tính, hay la mắng, vì phải chạy deadline rất mệt mỏi mà quên rằng mình có những đồng nghiệp thân thiện và mức thu nhập ổn định._
### **9. Cảm tính (Emotional Reasoning)**
Có thể tóm gọn bằng câu nói: "Nếu mình cảm thấy vậy thì chắc chắn là vậy!" Bạn tin theo cảm xúc của mình vô điều kiện, lấn át cả lý trí.
_Ví dụ: Bạn nghĩ rằng mình nói chuyện rất chán, và bạn luôn đinh ninh như vậy._
### **10. Kết luận vô căn cứ (Jumping to conclusions)**
Bạn nhảy thẳng đến kết luận mà không qua bất kì căn cứ nào. Thay vào đó, bạn dựa vào việc:
  * Đọc tâm trí (Mind reading): Bạn cho rằng người khác sẽ hành động hoặc suy nghĩ theo cách nghĩ của bạn.
  * Dự đoán (Fortune telling): Hay đúng hơn là 'đoán mò', rằng tương lai đã được định sẵn rồi để né tránh khó khăn.


_Ví dụ: Bạn kết luận ai đó có ác cảm với bạn nhưng không buồn kiểm chứng. Hoặc bạn tin rằng mối quan hệ tiếp theo cũng sẽ tồi tệ như mối quan hệ trước, nên bạn không muốn phí thời gian thử hẹn hò nữa._
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [1. Trắng đen rạch ròi ("Black and White” Thinking)](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/nhung-cach-suy-nghi-co-the-khien-ban-cang-thang-va-de-dang-be-tac#1-trng-en-rch-riblack-and-white-thinking)
  * [2. Quy chụp (Overgeneralizing)](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/nhung-cach-suy-nghi-co-the-khien-ban-cang-thang-va-de-dang-be-tac#2-quy-chp-overgeneralizing)
  * [3. Giảm nhẹ điều tốt đẹp (Disqualifying the positive)](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/nhung-cach-suy-nghi-co-the-khien-ban-cang-thang-va-de-dang-be-tac#3-gim-nh-iu-tt-p-disqualifying-the-positive)
  * [4. Quy về bản thân (Personalization)](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/nhung-cach-suy-nghi-co-the-khien-ban-cang-thang-va-de-dang-be-tac#4-quy-v-bn-thn-personalization)
  * [5. Tôi phải/Tôi nên (Shoulds)](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/nhung-cach-suy-nghi-co-the-khien-ban-cang-thang-va-de-dang-be-tac#5-ti-phiti-nn-shoulds)
  * [6. So sánh với người khác (Social comparison)](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/nhung-cach-suy-nghi-co-the-khien-ban-cang-thang-va-de-dang-be-tac#6-so-snh-vi-ngi-khc-social-comparison)
  * [7. Phóng đại và giảm nhẹ (Magnification and minimization)](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/nhung-cach-suy-nghi-co-the-khien-ban-cang-thang-va-de-dang-be-tac#7-phng-i-v-gim-nh-magnification-and-minimization)
  * [8. Màng lọc tâm trí (Mental filtering)](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/nhung-cach-suy-nghi-co-the-khien-ban-cang-thang-va-de-dang-be-tac#8-mng-lc-tm-tr-mental-filtering)
  * [9. Cảm tính (Emotional Reasoning)](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/nhung-cach-suy-nghi-co-the-khien-ban-cang-thang-va-de-dang-be-tac#9-cm-tnh-emotional-reasoning)
  * [10. Kết luận vô căn cứ (Jumping to conclusions)](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/nhung-cach-suy-nghi-co-the-khien-ban-cang-thang-va-de-dang-be-tac#10-kt-lun-v-cn-c-jumping-to-conclusions)



## Đừng bao giờ nói rằng: trầm cảm sau sinh là không đáng sợ !

**Tác giả: Nguyễn Diệp Chi**
Đến giờ, vẫn chưa có một nghiên cứu chính thức nào chỉ dẫn nguyên nhân cụ thể của căn bệnh trầm cảm sau sinh. Nhưng thử nghĩ mà xem, trải qua ca vượt cạn đau đớn đến kiệt quệ, khi vết rạch, vết khâu vẫn còn tứa máu, có người mẹ nào được nghỉ ngơi? Họ lập tức lao vào cuộc chăm con với tất cả sức lực đang có. Rồi con khóc, con quấy, con không chịu ăn, chưa kể con ốm bệnh cả tuần, cả tháng triền miên. Ai chăm? Ngoài mẹ. Có những người phụ nữ đã gần như không ngủ, thậm chí bỏ bữa. Họ gắng gượng làm tất cả vì con cho đến khi cạn sức, không chỉ ở thể trạng mà còn kiệt quệ về tinh thần. Nếu có người thân, gia đình, người chồng bên cạnh quan tâm, chăm sóc, đồng hành, sẻ chia thì là may mắn. Nếu phải một mình gồng gánh thì sẽ đến lúc sức cùng, lực kiệt. Chưa kể, mệt mỏi và cố gắng đến thế rồi mà vẫn phải nghe những lời bấc tiếng chì dò xét, chê bôi "làm cái này chưa được, cái kia chưa chuẩn"; "mẹ chăm kiểu gì mà con bé thế, ốm suốt thế" ... Chưa kể phải chứng kiến những hành động vô tâm thớ lợ của những gã chồng mãi không chịu lớn. Nhiều người phụ nữ ngày đêm một mình còm cõi chăm con để chồng yên tâm đi làm, công việc không bị gián đoạn. Đêm đến không để chồng phải thức giấc vì nghĩ hôm sau chồng còn làm việc cả ngày dài. Bất kể lúc nào cũng nghĩ cho con, cho chồng trước nhất rồi mới tới bản thân mình. Đến lúc biết rõ mười mươi là chẳng có công to việc nhớn gì bận rộn, chẳng qua anh chồng đã có nhân tình ở ngoài. Nghĩa là khi người mẹ vò võ chăm con, khi những đớn đau trên thân thể vẫn chưa lành thì bố đứa trẻ đã mải mê với những cuộc vui miên man bên một người đàn bà mới. Thậm chí còn ngang nhiên, công khai và công kích vợ mình. Thử một lần đặt mình vào vị trí của người vợ, người mẹ bất hạnh ấy. Nếu sau đó họ có nghĩ quẩn làm gì, thì với mình, cũng đều là đáng thương hơn đáng trách…
Phụ nữ sau khi vượt cạn sinh con đều có thể bị trầm cảm. Tuỳ mức độ nặng nhẹ, tuỳ hoàn cảnh xung quanh quyết định trạng thái đó có tiến triển thành bệnh hay không. Với những biểu hiện bên ngoài có thể mắt thấy tai nghe, chỉ cần những người cùng chung sống chịu khó quan sát là biết vợ mình, con/em mình đang trải qua giai đoạn nào (có 3 giai đoạn mình sẽ đề cập ở phần sau). Nhưng, nhiều người vẫn còn thờ ơ, phớt lờ, thậm chí mặc định việc phụ nữ sau sinh dễ khóc, dễ cười, dễ nổi cáu hay lú lẫn là điều đương nhiên, có gì mà phải nghĩ ngợi và làm to chuyện.
Khi một sinh linh chào đời, người ta thường quan tâm, âu yếm, chiều chuộng đứa trẻ mà có khi quên mất người đã 9 tháng 10 ngày mang nặng và trải qua cuộc vượt cạn đau đớn cho hình hài ấy vẹn nguyên đến với cuộc đời. Nếu bạn là đàn ông, bạn vừa có được diễm phúc làm cha, hãy thật trân trọng người phụ nữ bên cạnh, hãy yêu thương nhiều hơn và nhiều hơn nữa, hãy quan tâm, sẻ chia bằng hết con tim mình. Khi ấy đừng rạch ròi phân định đàn ông làm việc đại sự, đàn bà cứt đái bỉm sữa, mà việc gì làm được – hãy tự giác, tự nguyện, chủ động và hăng hái làm. Cho vợ mình được nghỉ ngơi phút nào hay phút ấy. Mỗi ngày chỉ cần nghe đôi ba câu hỏi han ân cần, chỉ cần thấy vài hành động ấm áp, quan tâm thì cơn trầm cảm có lạnh lùng đến mấy cũng phải tan đi theo thời gian. Phụ nữ sau sinh đã xấu xí lại thêm cả khó chiều, một việc nhỏ nhặt cũng khiến họ cáu bẳn, giận giữ, lải nhải mãi không thôi. Đúng là thế thật. Nhưng, họ đã mang đến cho bạn một thiên thần xinh xắn, lật giở đời bạn sang một trang mới, trao cho bạn cái quyền làm bố thiêng liêng, mang đến cho cả đại gia đình niềm vui không gì sánh được, thì mấy biểu hiện nhỏ nhặt kia có đáng gì đâu? Hãy cứ cười xoà, hãy cứ xin lỗi kể cả khi bạn không hề có lỗi nếu người phụ nữ mới sinh bên bạn càu nhàu… Chẳng thiệt gì cũng chẳng mất mát cm nào cái hai chữ đàn ông danh giá. Phụ nữ sau sinh có thể lú lẫn mà quên đi nhiều thứ nhưng họ sẽ ghi lòng tạc dạ từng khoảnh khắc đau đớn, khó khăn trong cuộc đời mà người chồng vẫn ở bên cạnh, tay nắm chặt tay để sau này bù đắp cho bạn đấy. Những lời không hay, những hành động vô tâm của người ngoài thì có thể nín, nhịn, có thể “sao cũng được”, nhưng nếu điều ấy đến từ người đầu gối tay ấp – trong những tháng ngày rất cần có nhau thì quả thực là thất vọng nhiều lắm. Thất vọng chất chồng sẽ thành tuyệt vọng. Khi ấy, một đứa trẻ ra đời ngỡ là mở ra tương lai rạng ngời nhưng thực tế, lại khiến tất cả đóng sầm sau cánh cửa bế tắc.
Các bạn gái cũng hãy cân nhắc thật kỹ càng trước khi quyết định làm mẹ. Hãy sinh con khi và chỉ khi đã đủ trưởng thành, chín chắn, khi đã nhận thức rõ ràng về những mối quan hệ xung quanh, khi đã hiểu tường tận về trách nhiệm phải gánh vác, khi đã tôi rèn cho mình bản lĩnh để sẵn sàng đón nhận giông gió cuộc đời. Làm mẹ hạnh phúc lắm, nhưng đó chỉ là đích đến sau khi đã can đảm vượt qua muôn vàn khó khăn. Hãy trang bị cho mình một vốn sống thật đầy đặn, những sở thích, thói quen tích cực để khi buồn có thứ mà vịn vào. Hãy sống tử tế để được bên cạnh nhiều người bạn tốt. Để chồng không bao giờ là chỗ dựa duy nhất. Hãy tập chia sẻ nhiều hơn với gia đình, đâu chỉ khoe chuyện vui, phải can đảm nói cả những chuyện buồn, những khó khăn đang mắc phải. Chồng thực ra cũng chỉ là người đàn ông xa lạ mình yêu rồi quyết định chung sống chứ máu mủ ruột rà như bố mẹ, anh chị em mới là không gì chia cắt được. Nếu buồn, nếu không hạnh phúc, hãy trở về nhà, trở về bên vòng tay của bố mẹ, rồi ngẩng cao đầu, tự tin nuôi con khôn lớn. Mỗi người sẽ hạnh phúc theo cách mình chọn, đừng hạnh phúc theo cách số đông mặc định chọn cho mình.
Và các ông bố, bà mẹ ạ, khi cô con gái bất hạnh chẳng may một ngày ôm đứa bé thất thểu trở về từ cuộc hôn nhân thất bại thì xin hãy rộng cửa đón vào, đừng sợ dèm pha, đừng sợ mất danh dự. Bỏ con, bỏ cháu, thậm chí đuổi máu mủ ruột rà ra đi khi ấy mới thực là hành động đáng hổ thẹn. Vỗ về con cháu xong, hôm sau hãy nghĩ tới chuyện tính sổ thằng con rể ... zỏm đã từng thề thốt hứa hẹn trăm năm. Lúc đưa con mình đi thì kéo cả đoàn người ồn ã, đến khi về thì bỏ mặc con mình lủi thủi lạnh giá trong đêm. Những gã đàn ông như thế - thực ra là phủi tay, vứt ngay được rồi, chẳng phải tiếc gì đâu ạ. Sau này nhìn lại, sẽ cảm ơn chính mình đã quyết định kịp lúc, để những ngày sáng tươi hạnh phúc được tới sớm hơn.
Khi phụ nữ bị trầm cảm sau sinh, mọi diễn biến cảm xúc đều được đẩy lên ở mức độ cao hơn bình thường. Nổi lên là cảm giác bất an thường trực và nỗi sợ bị bỏ lại một mình. Có khi đang ngồi bình thường mà nước mắt cứ tứa ra lã chã. Hầu hết các sự việc đều bị họ nhìn nhận theo xu hướng tiêu cực. Các nhà tâm thần học đã chỉ rõ trầm cảm sau sinh trải qua các mức độ khác nhau, từ nhẹ đến nặng hoặc có thể tiến triển đến mức độ rất nặng tùy thuộc vào từng hoàn cảnh, điều kiện của sản phụ. Nhẹ nhất là trạng thái khóc lóc và ủ rũ (hội chứng Baby blues), trầm cảm sau sinh (Postpartum Major Depression) và cuối cùng là rối loạn tâm thần sau sinh (Postpartum Psychosis). Dưới đây là những thông tin khoa học về các giai đoạn trầm cảm sau sinh mình tổng hợp từ Tạp chí Sức khoẻ và đời sống. Thiết tha mong mọi người, nhất là những anh chồng, những ông bố trẻ kiên nhẫn đọc hết và nhớ kỹ để giúp đỡ, bảo vệ người mẹ của con mình.
**Trạng thái ủ rũ, khóc lóc (baby blues)**
Đây là trạng thái mà mẹ nào cũng từng trải qua. Nếu nó kéo dài đến hơn hai tuần thì hội chứng baby blues lúc này có thể đã chuyển sang hội chứng trầm cảm sau sinh. Trạng thái này chưa gọi là bệnh và không cần điều trị, chỉ cần sản phụ được nghỉ ngơi; nhận được sự hỗ trợ, quan tâm đủ đầy từ phía gia đình và bạn bè, nếu được kết nối với các bà mẹ khác thì càng tốt.
**Hội chứng trầm cảm sau sinh (Postpartum Major Depression)**
Hội chứng trầm cảm sau sinh chiếm khoảng 10% ở các bà mẹ mới sinh, hội chứng này có xu hướng phát triển sau 3 tuần và lâu hơn. Trong đó, rối loạn cảm xúc (Mood Disorders) thể hiện rõ nét và kéo dài nhất.
Các triệu chứng thường gặp là hay khóc, sự thiếu tập trung, khó khăn trong việc đưa ra các quyết định, cảm giác thiếu tự tin, buồn chán và xuất hiện ý nghĩ tự tử. Ngoài ra, còn có các triệu chứng tương tự như trong bệnh suy chức năng tuyến giáp, bao gồm: nhạy cảm với không khí lạnh, suy nghĩ chậm chạp, mệt mỏi, da khô, táo bón...
Những sản phụ có các triệu chứng của hội chứng trầm cảm sau sinh thường được điều trị bằng liệu pháp tâm lý, uống thuốc chống trầm cảm. Nếu kiên trì và điều trị hợp lý, hội chứng trầm cảm sau sinh thường khỏi trong vòng 6 tháng. Một số trường hợp nếu không tuân thủ quy tắc điều trị của bác sĩ, bệnh sẽ tái phát và diễn biến bệnh sẽ kéo dài hơn và trở thành hội chứng loạn thần sau sinh (Postpartum Psychosis).
**Hội chứng rối loạn tâm thần sau sinh (Postpartum Psychosis)**
Hội chứng này đôi khi còn được gọi là loạn thần sản khoa hoặc là trầm cảm loạn tâm thần sau sinh, thường gặp 1-2 trường hợp trên 1.000 phụ nữ.
Hội chứng này dễ gặp hơn ở những phụ nữ có tiền sử bản thân hoặc người thân trong gia đình có rối loạn cảm xúc lưỡng cực hoặc bệnh tâm thần phân liệt. Hầu hết các trường hợp sẽ bắt đầu trong vòng 2 tuần đầu tiên sau khi sinh và chiếm tỷ lệ cao nhất ở 1-3 tháng tiếp theo. Hội chứng rối loạn tâm thần sau sinh có thể xuất hiện sớm với các dấu hiệu như kích động, lú lẫn và có vấn đề về trí nhớ, hay cáu kỉnh, mất ngủ và lo lắng. Các triệu chứng muộn hơn của hội chứng rối loạn tâm thần sau sinh bao gồm: hoang tưởng, ảo giác, có những hành vi bất thường và xa lánh mọi người, đặc biệt là không quan tâm hoặc gây tổn thương cho chính bản thân và đứa trẻ.
Với những người có hội chứng rối loạn tâm thần sau sinh: đòi hỏi bắt buộc phải được đưa đến các bệnh viện tâm thần hoặc các bệnh viện có chuyên khoa tâm thần để điều trị nội trú. Những bệnh nhân này sẽ được điều trị phối hợp các loại thuốc chống trầm cảm, thuốc chống loạn thần và các thuốc chỉnh khí sắc. Những bệnh nhân có hội chứng loạn tâm thần sau sinh nếu không đáp ứng với thuốc thì liệu pháp shock điện (Electroconvulsive therapy) sẽ được áp dụng nhằm kiểm soát các dấu hiệu và triệu chứng của người bệnh.

## 3 câu chuyện xúc động về gia đình bạn nên đọc

**Câu chuyện thứ nhất: Hãy Làm Điều Gì Đó Trước Khi Quá Muộn Màng**
Một người đàn ông dừng lại ở cửa tiệm bán hoa để đặt hoa tặng mẹ của mình. Mẹ của ông ở xa cách đây hơn 200 dặm và ông sẽ nhờ cửa tiệm giao hoa đến tận tay cho bà. Khi ông bước ra khỏi xe, ông đột nhiên chú ý đến một cô gái trẻ đang khóc thút thít bên lề đường. Ông hỏi cô gái có sao không, cô trả lời, “Cháu muốn mua hoa hồng tặng mẹ. Nhưng cháu chỉ có 75 cent nhưng hoa hồng thì đến 2 dollar.
Người đàn ông mỉm cười và nói, “Đi với chú. Chú sẽ mua cho cháu một bông hồng.” Ông mua cho cô bé hoa hồng như đã hứa và đặt hoa giao đến tận nhà mẹ mình. Khi họ rời khỏi, ông ngỏ ý chở cô bé về nhà. Cô bé đồng ý để ông chở đến chỗ mẹ của mình. Cô chỉ cho ông đến một nơi vắng vẻ, phải đến khi dừng xe lại người đàn ông mới nhận ra đó là một nghĩa trang. Và cô gái đã đặt bông hoa ấy lên một ngôi mộ sạch sẽ.
Người đàn ông trở về cửa tiệm hoa, hủy gói giao hoa và ông ta đã mua hẳn một bó hoa to, lái xe đến thẳng nhà của mẹ mình, ngôi nhà cách nơi đấy hơn hai trăm dặm đường đi nhưng cuộc gặp gỡ cô gái đã cho ông hiểu rằng, nếu hôm nay ông không đến, có khi ngày mai ông sẽ chẳng còn cơ hội để đến nữa.
**_Cuộc đời rất ngắn ngủi bạn ạ. Hãy dành nhiều thời gian để yêu thương và quan tâm đến những người mà bạn quý mến. Hãy tận hưởng những khoảnh khắc với họ trước khi mọi chuyện đã quá muộn màng. Không có thứ gì trên đời quan trọng hơn gia đình cả, bạn nhé._**
**Câu chuyện thứ hai: Chỉ năm phút nữa thôi**
Ở một công viên nọ, một người phụ nữ ngồi cạnh một người đàn ông trên một băng ghế gần sân chơi. “Con trai tôi đó,” người phụ nữ chỉ vào một cậu bé đang chơi cầu trượt vận chiếc áo len màu đỏ. “Cậu bé nhìn mới đáng yêu làm sao”. Người đàn ông nói. “Còn kia là con gái của tôi, cô bé đang chạy xe đạp vận một cái đầm màu trắng đấy.”
Sau đó, người đàn ông nhìn vào đồng hồ và gọi cô bé. “Con chơi xong chưa Melissa?”. Melissa nài nỉ, “5 phút nữa thôi nha bố. Nha? Chỉ 5 phút thôi.” Người đàn ông gật đầu và cô bé lại tiếp tục chơi đùa cùng chiếc xe như cô đã mong muốn. Thời gian trôi qua và người đàn ông lại gọi con gái của mình: “Đi được chưa con?” Melissa lại nài nỉ, “Chỉ 5 phút nữa thôi nha bố. 5 phút thôi mà.” Người đàn ông lại mỉm cười và nói, “Được rồi”.
“Ông quả thật là một con người kiên nhẫn.”, người phụ nữ nói. Người đàn ông mới tiếp lời, “Tommy, anh trai của con bé đã mất trong một vụ tai nạn giao thông vì một gã tài xế say xỉn khi nó đang đạp xe ở một chỗ khá gần nơi này. Tôi đã không dành nhiều thời gian cho Tommy và bây giờ tôi sẵn sàng từ bỏ tất cả chỉ để có được 5 phút ở cạnh nó. Tôi đã thề sẽ không lặp lại sai lầm đó với Melissa. Con bé cứ nghĩ nó may mắn có thêm 5 phút để chơi. Nhưng sự thật đúng ra phải là, tôi mới là người may mắn khi có được thêm 5 phút để nhìn ngắm con bé hạnh phúc.
**_Cuộc sống luôn cần những lần đánh đổi và sự ưu tiên lớn lao nhất luôn luôn phải là gia đình. Hãy tận dụng thời gian quý báu của mình với những người mình thương yêu nhất bạn nhé._**
**Câu chuyện thứ ba: Cha Ơi, Đến Khi Nào Thì Ngón Tay Con Sẽ Mọc Lại**
Một người đàn ông đang đánh bóng chiếc xe hơi mới mua của mình thì cô con gái 4 tuổi của ông lại dùng đá để viết lên chiếc xe ấy. Điên tiết, ông ta cầm lấy bàn tay của đứa trẻ và đánh rất nhiều, và ông không nhận ra mình đang đánh bằng một cái mỏ lết. Lúc đến bệnh viện, cô bé phải cưa bỏ tất cả những ngón tay của mình vì vết thương quá nghiêm trọng.
Khi đứa trẻ nhìn thấy cha, cô bé tuyệt vọng hỏi “Cha ơi, đến khi nào thì ngón tay con sẽ mọc lại?”. Người cha đau đớn trong lặng câm. Ông trở lại chiếc xe hơi và tức giận đá vào nó. Phải đến lúc thấm mệt ông mới nhìn vào chỗ có những vết rạch mà con gái ông đã viết nên, cô bé đã viết.
“Con yêu cha.”
**_Hãy hiểu một điều rằng, cả sự tức giận lẫn tình yêu thương đều không có giới hạn. Nên nhớ, “Đồ vật là để sử dụng, nhưng con người là để yêu thương”. Đừng để sự nóng nảy tức thời làm bạn cả đời phải hối hận._**
**(Theo Qùa Tặng Cuộc Sống)**

## Chỉ cần em vẫn còn đây (Thơ)

_**Do dịch bệnh Covid, BS Trí Phạm đã mất đi người vợ trẻ của mình - cũng là một bác sĩ trẻ ở Hoa Kỳ. Thầy Minh Niệm đã lắng nghe những trăn trở và chia sẻ chân thành - mà viết tặng bài thơ này...**_
Dù cuộc đời không ngừng ném ra những cơn giông tố
dù cây bàng trước nhà vẫn đang rưng rưng tuôn dòng lá đổ
chỉ cần em vẫn còn đây...
Chỉ cần nhìn thấy em nở nụ cười rạng rỡ mỗi sớm mai
chỉ cần nhìn thấy em ngồi đó bình yên trong hơi thở
chỉ cần nhìn thấy nhau và vẫn nhớ
ta là gì của nhau...
Mạng sống con người cũng mong manh như cỏ dại tựa vào non cao
có thể nhiễm bệnh, có thể ra đi...chỉ sau một cơn gió lốc
không biết đây là hiện thực hay chỉ là giấc mộng?
ta đang mất quyền được sống
hay đến tận bây giờ mới nhận ra mình đã chết từ lâu...?
Từ bao giờ tôi và em đã không thể ngồi xuống cởi lòng với nhau?
từ bao giờ tôi và em kiêu hãnh trong vai người bận rộn?
từ bao giờ tôi và em đã ngừng khôn lớn?
chỉ thích gây cho nhau trắc trở
ngăn cách đôi bờ đúng sai...
Nếu đại dịch không quét qua địa cầu, không phủ lên màu hủy diệt nơi đây
thì chắc giờ này hai ta vẫn còn ôm ấp cái tôi tung tăng nhảy múa
nếu không bị mắc kẹt giữa hai miền phong tỏa
không phải nhọc nhằn từng hơi thở
thì không biết bao giờ mới bật lên được "kênh": bận lòng, thương nhớ, xót xa...
Nhưng tôi tài cán thế nào - sao để cho giông bão vùi nát một cành hoa?
hay do chính tôi đã dụ dẫn em vào trò chơi "đuổi hình bắt bóng"
để em chơi vơi giữa những cơn đau tuyệt vọng
để em cạn mòn bản năng vươn tìm sự sống
linh hồn hoang hoải, xác xơ...
Ứng với câu nói của Kiều ngày nào, "chỉ còn gặp lại trong giấc mơ
nếu bây giờ đôi ta không chịu nhìn nhau cho tận mặt"
tôi ngồi đây gọi tên em suốt buổi chiều nắng tắt
cõi lòng tôi giờ cũng đang trở nặng
cơn sang chấn ăn năn.
Chỉ cần em vẫn còn đây và hãy để tôi đương đầu với mọi khó khăn
hãy dể tôi thay em vào khu cách ly, thở bình oxy, chiến cùng virus
hãy để tôi ra đi, vì bao bệnh nhân cần bàn tay em phục dược
con thơ cần em, mới lớn lên được
hãy chơi lại trò đổi vai...

## Có khi nào lời chúc thành gánh nặng?

  * [Cơ thể phản ứng thế nào khi nhận những lời chúc?](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/co-khi-nao-loi-chuc-thanh-ganh-nang#c-th-phn-ng-th-no-khi-nhn-nhng-li-chc)
  * [Vì sao những lời chúc lại có thể làm cuộc sống khó khăn hơn?](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/co-khi-nao-loi-chuc-thanh-ganh-nang#v-sao-nhng-li-chcli-c-th-lm-cuc-sng-kh-khn-hn)
  * [Làm sao để lời chúc được trọn vẹn?](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/co-khi-nao-loi-chuc-thanh-ganh-nang#lm-sao-li-chc-c-trn-vn)


## Cơ thể phản ứng thế nào khi nhận những lời chúc?
Vào năm 1980, nhà tâm lý họcRichard Solomon đã đưa ra một ý tưởng mà ông gọi là “lý thuyết tiến trình đối thủ” (opponent process theory). Thuyết này cho rằng bất cứ khi nào bạn cảm nhận được một cảm xúc, bạn sẽ có cảm giác ngược lại ngay tiếp theo. Điều này sẽ giải thích tại sao sau khi vừa cảm thấy hạnh phúc, chúng ta lại cảm thấy hơi u ám.
George Koob, một nhà sinh lý học thì giải thích rằng tất cả chúng ta đều có một trạng thái cơ bản được gọi là cân bằng nội môi, một thiết lập để ta không quá vui hay quá buồn.
Khi trải qua một việc gì đó khiến bạn rất vui như nhận vô vàn lời chúc, khen ngợi khiến ta phấn khích cao độ thì cơ thể sẽ xoay chuyển sự cân bằng và não có thể cố gắng sửa chữa quá mức để phục hồi. Và nỗi buồn, căng thẳng ập đến.
Giáo sư tâm lý học[ Laurie Santos](https://www.today.com/health/it-possible-feel-happy-sad-same-time-t128850) của Đại học Yale, người đang giảng dạy một khóa học cực kỳ phổ biến về cách hạnh phúc, đồng ý rằng mọi người có thể cảm nhận được cả cảm xúc tích cực và tiêu cực cùng một lúc.
Các tình huống thường gây ra trạng thái này bao gồm các sự kiện buồn vui lẫn lộn như tốt nghiệp, đám cưới, được thăng chức và luân chuyển sang chỗ làm khác. Những tình huống khi bạn buồn vì rời đi, nhưng lại vui vì những cơ hội mới.
## Vì sao những lời chúc lại có thể làm cuộc sống khó khăn hơn?
Nếu nhận một lời khen hay lời chúc khiến bạn khó chịu, thì bạn không đơn độc. Trong một bài viết đăng trên Harvard Business, tác giả [Christopher Littlefield](https://hbr.org/2021/04/do-compliments-make-you-cringe-heres-why) thực hiện một khảo sát 400 người ở Boston và rút ra rằng, gần 70% số người liên quan đến cảm giác xấu hổ hoặc khó chịu khi được công nhận hoặc nhận được lời khen.
Đằng sau vẻ ngoài hạnh phúc thì không ít người khi nhận lời chúc lại phải đối diện với hội chứng trầm cảm tươi cười [(smiling depression](https://www.verywellmind.com/what-is-smiling-depression-4775918)). Bạn cảm thấy thế giới bên ngoài đang kỳ vọng quá nhiều về mình và phải luôn xây dựng một bộ mặt rạng rỡ dù trong lòng đang bất ổn.
Ngoài ra, khi ở trạng thái “con cưng”, là tâm điểm của những điều tốt đẹp, hoàn hảo nhất, chúng ta có thể rơi vào trạng thái áp lực về sự hoàn hảo từ xã hội (Socially prescribed perfectionism).
Các cá nhân chịu áp lực này có điểm chung là thường hay tự phê bình. Họ có gánh nặng phải trở thành người giỏi nhất và luôn sợ mình trở nên vô dụng, cuối cùng bị người khác từ chối.
Họ buộc chặt giá trị bản thân với những tiêu chuẩn thiếu thực tế mà gia đình, văn hoá công sở hoặc xã hội đặt ra, thông thường dẫn đến cảm giác tự ti và lo âu thường trực.
Theo Bác sĩ tâm lý [Milton Ericson](https://www.unk.com/blog/dangers-of-excessive-praise/) thì việc khen ngợi quá mức có thể gây nguy hiểm. Khi nhận được nhiều từ hoa mỹ thì một thứ tưởng như bình thường lại được nâng tầm, trở nên đặc biệt và thành khác thường.
Bạn có thể thấy điều này qua những lời tâng bốc như đám cưới thế kỷ, cặp đôi vàng hay những lời nói biến các đám cưới của người nổi tiếng trở nên kì lạ, gây tò mò.
## Làm sao để lời chúc được trọn vẹn?
Một lời chúc phúc tử tế, chân thành, chu đáo giống như một dạng ma thuật — nó có sức mạnh làm thay đổi một ngày của ai đó ngay lập tức và khiến họ cảm thấy dễ chịu.
Tuy vậy, lời chúc cũng cần có những giới hạn để người tiếp nhận không quá áp lực. Điều đầu tiên, chúng ta nên để ý về cách sử dụng ngôn ngữ.
Trong đó những lời chúc mang tính kỳ vọng có từ “phải” thường tạo ra nhiều áp lực hơn cho người nghe. Đơn cử như “Đẹp đôi thế này thì phải hạnh phúc nhé”, “Có năng lực mà, phải thành công nhé”…
Từ phía người tiếp nhận, bạn có thể chủ động kiểm soát số lượng thông tin mà mình nhận vào. Chẳng hạn như thông báo một sự kiện quan trọng cho số lượng người giới hạn.
Hoặc, bạn cũng có thể thông báo sau khi sự kiện đã diễn ra một thời gian. Điều này sẽ giúp bạn cảm thấy thoải mái hơn khi nhận vì bạn biết rằng nó đều đến từ những người hiểu mình.
Những thay đổi nhỏ này sẽ giúp những lời chúc trở nên dễ đón nhận hơn. Bên cạnh đó, bạn cũng nên để tâm hơn đến những điều tích cực. Bởi chỉ cần thiếu tiết chế, chúng có thể phản tác dụng rồi trở thành sự tích cực độc hại (toxic positivity), ảnh hưởng không tốt đến cuộc sống.
  * [Cơ thể phản ứng thế nào khi nhận những lời chúc?](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/co-khi-nao-loi-chuc-thanh-ganh-nang#c-th-phn-ng-th-no-khi-nhn-nhng-li-chc)
  * [Vì sao những lời chúc lại có thể làm cuộc sống khó khăn hơn?](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/co-khi-nao-loi-chuc-thanh-ganh-nang#v-sao-nhng-li-chcli-c-th-lm-cuc-sng-kh-khn-hn)
  * [Làm sao để lời chúc được trọn vẹn?](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/co-khi-nao-loi-chuc-thanh-ganh-nang#lm-sao-li-chc-c-trn-vn)



## Người lớn thật vô duyên! (Truyện ngắn)

Tôi bàng hoàng khi cô con gái 9 tuổi kết luận rằng: **Người lớn thật vô duyên!**
Và lý do con đưa ra xuất phát từ chính những câu nói của chính người lớn.
- - -
“Cháu cao mét mấy, nặng bao nhiêu cân?”
Mỗi ngày, hai đứa nhỏ nhà tôi nhận được rất nhiều câu hỏi về chiều cao, cân nặng, nhất là khi hai chị em nó - một đứa quá lớn và một đứa quá còi. Cô chị không thích những câu hỏi về cân nặng, nó thường lảng tránh, hoặc trả lời chung chung, hoặc cười trừ. Nó bảo với tôi: Rõ ràng, ai cũng biết con béo rồi, vậy còn hỏi về cân nặng để làm gì? Để cảm thấy hả hê vì họ không béo như con ạ? Có ai thích béo đâu mẹ, con cũng muốn giảm cân lắm, nhưng con giảm chưa được. Nhiều lúc con buồn lắm vì mọi người cứ bảo con ăn hết phần của em Bông nên béo ú còn em Bông thì gầy nhẳng. Rõ ràng là em Bông sinh non, lúc sinh ra đã bị viêm ruột, em ấy ăn bao nhiêu cũng không béo, họ đâu có nuôi con và em Bông mà suy đoán là con ăn hết phần của em.
- - -
“Học kỳ vừa rồi, có được giấy khen không?”
Không chỉ bị áp lực điểm số từ thầy cô, cha mẹ, nhiều khi trẻ bị áp lực từ chính những người chẳng hề thân quen. Ví như, người hàng xóm tận đẩu tận đâu, một vị khách lạ, một người họ hàng xa lên chơi, ai cũng thích hỏi trẻ học có giỏi không, có được giấy khen không, có nhiều điểm 10 không? Những đứa trẻ học giỏi thường vui vẻ trả lời ngay, nhưng những đứa trẻ học chưa giỏi sẽ cúi gầm mặt lí nhí trả lời hoặc không nói một lời nào. Đâu chỉ trẻ xấu hổ, bố mẹ của trẻ cũng xấu hổ lây nếu như chẳng may con mình không có điểm số tốt để khoe.
“Vô duyên – người lớn thật vô duyên” - cô con gái tôi bảo. “Trong lớp của con có 36 bạn, có 16 bạn học sinh giỏi toàn diện, 20 bạn còn lại không được, như vậy là hơn một nửa lớp không phải học sinh giỏi toàn diện, chắc chắn 20 bạn ấy sẽ không thích câu hỏi này đâu”.
- - -
“Chán đời, nhà toàn “Thị Nở””
- Mẹ ơi, Thị Nở là gì?
- À… Thị Nở là một nhân vật trong truyện ngắn “Chí Phèo” của nhà văn Nam Cao, người ta thường nói ai đó như Thị Nở để hàm ý rằng người phụ nữ đó không được xinh đẹp và duyên dáng cho lắm.
- Ôi trời ơi! Con và em Bông nhìn đâu đến nỗi nào, sao cô Hoa lại bảo hai chị em con là Thị Nở?
- À… (tôi lại phải giải thích thêm). Trong trường hợp này, họ không dùng với hàm ý đó mà muốn nói rằng nhà mình chỉ đẻ toàn con gái, không có con trai.
- Vô duyên. Là con gái thì đã sao, mẹ nhỉ? Chẳng phải cô Hoa cũng là con gái đó sao? Có ai bảo cô ấy là Thị Nở đâu chứ.
“Sao họ không tự đẻ lấy mà cứ đến nhà mình giục bố mẹ đẻ?”
“Mẹ bảo với chúng con rằng mẹ sẽ không đẻ em bé nữa vì sức khỏe mẹ không cho phép, với mẹ, hai chị em con là đủ. Vậy mà, suốt ngày người ta giục mẹ đẻ. Bố không giục, ông bà không giục, toàn những người ở đâu giục. Lạ kỳ mẹ nhỉ? Nếu họ thích em bé đến thế sao họ không tự đẻ lấy mà cứ đến nhà mình giục bố mẹ đẻ?
- - -
“Mày là con ông hàng xóm”
- Mẹ ơi, hôm nọ con thấy em Minh khóc đấy mẹ ạ.
- Ủa, sao em lại khóc hả con?
- Tại vì cô nào đấy bảo em ấy là con ông hàng xóm, chẳng giống bố gì cả.
- Là cô ấy nói đùa thôi con.
- Lại đùa, sao người lớn thích đùa thế hả mẹ? Em ấy khóc suốt, sau bố em ấy về dỗ mãi mới nín đấy. Em ấy bảo với con, em chỉ thích giống bố, xấu trai như bố cũng được, còn hơn xinh đẹp mà giống ông hàng xóm.
- - -
“Bố mày có dì hai rồi kìa”
- Mẹ ơi, dì hai là gì? Sao hôm nọ chú Hải bảo với con là bố mày suốt ngày đi làm về muộn, chắc là có dì hai rồi.
- À, tôi lúng túng, chú ấy nói đùa đấy con. Con đừng tin. Đấy là chú ấy nghĩ thế chứ sự thật không phải như thế.
Mặc dù tôi đã trấn an con, nhưng con bé vẫn cứ băn khoăn, suy nghĩ, nó muốn tìm hiểu dì hai là ai? Tại sao có dì hai thì lại nghiêm trọng đến thế? Và cho đến khi nó hiểu được ý nghĩa của câu nói này thì cảm thấy vô cùng tức giận. Đa phần trong mắt trẻ con, bố là thần tượng của chúng. Thần tượng ấy luôn mạnh mẽ, chiều chuộng chúng hết mực. Nói về khoản cho trẻ đi chơi thì quả đúng là các ông bố đôi khi còn siêng hơn các bà mẹ. Thế nên, họ rất được lòng bọn trẻ. Với trẻ, bố luôn luôn yêu thương chúng và mẹ chúng nhất trên trần đời, tuyệt đối không có chỗ cho dì hai, dì ba nào có thể chen chân. Người lớn đôi khi vô tình làm tổn thương niềm tin của trẻ bởi những câu đùa tọc mạch và vô duyên. Mà cứ cho là sự thật đúng là như thế đi, thì đó cũng không phải là cách hay để báo tin cho trẻ; việc trong gia đình của trẻ, hãy để cha mẹ trẻ tự đứng ra giải quyết, bạn đừng can dự.
Ngẫm đi, ngẫm lại, mấy câu người lớn hay nói với trẻ con nhiều lúc thật vô duyên. Họ nói theo thói quen, theo ý thích của mình mà không để ý đến thái độ và cảm xúc của trẻ. Có lẽ đã đến lúc, người lớn chúng ra ngưng vô duyên và bớt soi mói vào chuyện của người khác.

## “Con gái tôi là mẹ của con gái bạn, vậy tôi là gì của bạn?”

  * [Câu hỏi 1: “Con gái tôi là mẹ của bạn, vậy tôi là gì của bạn?”.](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/con-gai-toi-la-me-cua-con-gai-ban-vay-toi-la-gi-cua-ban#cu-hi-1-con-gi-ti-l-m-ca-bn-vy-ti-l-g-ca-bn)
  * [Câu hỏi 2: “Nếu thấy 500 ngàn rơi xuống bồn cầu, các bạn có nhặt lên không?”.](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/con-gai-toi-la-me-cua-con-gai-ban-vay-toi-la-gi-cua-ban#cu-hi-2-nu-thy-500-ngn-ri-xung-bn-cu-cc-bn-c-nht-ln-khng)


### _**Câu hỏi 1: “Con gái tôi là mẹ của bạn, vậy tôi là gì của bạn?”.**_
Câu hỏi khiến cả 3 ứng viên đều ngớ người trong phút chốc. Ứng viên thứ nhất có lẽ đầu chưa kịp “nảy số” nên không nghĩ ra được câu trả lời nào. Cô mỉm cười ngượng nghịu, từ chối trả lời một cách lịch sự và nhường cơ hội trả lời cho ứng viên nam tiếp theo.
Người này cũng bối rối, chưa nghĩ ra câu trả lời thỏa đáng nhưng vẫn đáp:_“Tôi nghĩ không có câu trả lời chính xác cho câu hỏi này. Nếu con gái tôi là mẹ của con gái bạn, thì bạn có thể là bố tôi”._ Chàng trai vừa nói xong liền bật cười và phía nhà tuyển dụng cũng thích thú cười theo.
Đến lượt Tiểu Biên, cô vừa suy ngẫm vừa đáp:_“Tôi cũng đồng ý với câu trả lời trước. Thực sự không có đáp án chính xác cho câu hỏi này. Bởi vì có nhiều giả thuyết khác nhau nên sẽ có 4 câu trả lời. Thứ nhất nếu tôi là phụ nữ và bạn cũng là phụ nữ thì tôi là mẹ của bạn. Thứ hai, nếu tôi là phụ nữ, bạn là đàn ông thì tôi là mẹ vợ của bạn. Thứ ba, nếu tôi là đàn ông và bạn là phụ nữ thì tôi là bố của bạn. Thứ tư, nếu tôi là đàn ông và bạn cũng là đàn ông thì tôi là bố vợ của bạn”._
Sau khi nghe Tiểu Biên nói, phía nhà tuyển dụng tỏ ra bất ngờ vì chỉ trong thời gian ngắn mà cô gái trẻ có thể suy luận, vạch ra các mối quan hệ nhanh đến như vậy. Để xem xét khả năng chịu áp lực và thất bại hay không? Nhà tuyển dụng đưa ra câu hỏi tiếp theo:
### _**Câu hỏi 2: “Nếu thấy 500 ngàn rơi xuống bồn cầu, các bạn có nhặt lên không?”.**_
Người phỏng vấn thứ hai đáp:  _“Nếu nó chỉ rơi trên bề mặt bồn cầu, tôi sẽ nhặt lên và lau sạch. Nhưng nếu nó bị ướt hoặc bị bẩn thì sẽ có rất nhiều vi khuẩn, vì vậy tôi sẽ không nhặt lên”._
Tiểu Biên sau khi suy nghĩ vài giây thì trả lời:
_“Hãy bắt đầu với cảnh tượng như này: Nếu bạn làm rơi tiền vào bồn cầu, 500 ngàn cũng là tiền và không khó để nhặt lên. Miễn là tiền được làm sạch thì nó vẫn sử dụng được như thường. Nhưng nếu có ai đó ném tiền vào bồn cầu, rồi bảo tôi nhặt lên với mục đích làm nhục thì tôi sẽ từ chối._
_Hãy đi tiếp đến ý nghĩa của việc này. Tiền rơi vào bồn cầu là tiền bẩn. Nếu như nó “bẩn” theo nghĩa bóng, là tiền phi nghĩa thì nếu nhặt được tôi cũng sẽ giao nộp chứ không cầm._
_Tiếp theo, hãy nói về chuyện phẩm giá. Nhìn bề ngoài thì việc nhặt tiền trong bồn cầu không có gì to tát. Tôi chỉ đang nhặt tiền mà thôi, chẳng vi phạm pháp luật, cũng không vi phạm đạo đức. Tôi chỉ tôn trọng đồng tiền mà thôi”._
Cuối cùng, phía nhà tuyển dụng đã quyết định nhận Tiểu Biên vào làm, sau khi xem xét năng lực làm việc, khả năng tư duy logic và khả năng chịu áp lực cũng như thất bại trong công việc.
  * [Câu hỏi 1: “Con gái tôi là mẹ của bạn, vậy tôi là gì của bạn?”.](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/con-gai-toi-la-me-cua-con-gai-ban-vay-toi-la-gi-cua-ban#cu-hi-1-con-gi-ti-l-m-ca-bn-vy-ti-l-g-ca-bn)
  * [Câu hỏi 2: “Nếu thấy 500 ngàn rơi xuống bồn cầu, các bạn có nhặt lên không?”.](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/con-gai-toi-la-me-cua-con-gai-ban-vay-toi-la-gi-cua-ban#cu-hi-2-nu-thy-500-ngn-ri-xung-bn-cu-cc-bn-c-nht-ln-khng)



## Tình yêu bất tử (truyện ngắn)

Câu chuyện xảy ra ở một bệnh viện nhỏ ở vùng quê hẻo lánh. Ở khoa hóa trị có một phụ nữ trẻ đang trong giai đoạn cuối của căn bệnh ung thư. Tuy luôn bị những cơn đau hành hạ nhưng chưa bao giờ người phụ nữ ấy quên trao cho chúng tôi một nụ cười biết ơn sau những lần điều trị. Những khi chồng cô tới thăm, mắt cô rạng ngời hạnh phúc.
Đó là một người đàn ông đẹp trai, lịch thiệp và cũng thân thiện như vợ mình. Tôi rất ngưỡng mộ chuyện tình của họ. Hằng ngày anh mang đến cho cô những bó hoa tươi thắm cùng nụ cười rạng rỡ, anh đến bên giường nắm lấy tay cô và trò chuyện. Những lúc quá đau đớn, cô khóc và trở nên cáu gắt, anh ôm chặt cô vào lòng, an ủi động viên cho đến khi cơn đau dịu đi. Anh luôn bên cô mỗi khi cô cần, anh giúp cô uống từng ngụm nước và không quên vuốt nhẹ đôi chân mày của cô. Mỗi đêm, trước khi ra về anh luôn đóng cửa để hai người có những giây phút bên nhau. Khi anh đi, chúng tôi thấy cô ấy đã ngủ say mà trên môi vẫn phảng phất nét cười.
Nhưng đêm ấy mọi chuyện đã thay đổi. Khi nhìn vào bảng theo dõi, kết quả cho thấy người vợ trẻ ấy sẽ không qua khỏi đêm nay. Mặc dù rất buồn nhưng tôi biết đó là cách tốt nhất cho cô ấy, từ nay cô sẽ không chịu những cơn đau thêm nữa.
Để bảng theo dõi trên bàn, tôi muốn đến phòng bệnh. Khi tôi bước vào phòng, cô mở mắt nhìn tôi hé môi cười một cách yếu ớt, nhưng hơi thở của cô nghe thật khó nhọc. Chồng cô ngồi bên cô mỉm cười nói: "Cho đến bây giờ món quà tuyệt vời nhất tôi dành cho cô ấy chính là tình yêu của tôi".
Và tôi đã khóc khi nghe điều đó, tôi nói nếu họ cần bất cứ điều gì thì đừng ngại. Và đêm ấy cô đã ra đi trong vòng tay người chồng yêu dấu. Tôi không biết làm gì hơn ngoài việc cố an ủi và chia sẻ nỗi đau này cùng chồng cô. Với khuôn mặt đẫm nước mắt, anh nghẹn ngào: "Xin hãy cho tôi ở bên cô ấy thêm một lúc".
Bỗng nhiên từ trong phòng vọng ra một giọng hát trầm ấm mà tôi chưa từng được nghe. Không chỉ riêng tôi mà tất cả mọi người đều bị cuốn hút bởi giọng hát của anh khi anh cất lời bài “Beautiful brown eyes”. Rồi giai điệu khúc ca nhỏ dần, anh mở cửa gọi tôi đến, nhìn sâu vào mắt tôi, ôm chầm lấy tôi rồi nói: "Tôi đã hát bài này mỗi đêm cho cô ấy nghe kể từ ngày chúng tôi quen nhau. Mọi ngày tôi vẫn thường cố giữ cho giọng mình thật nhỏ để khỏi làm phiền bệnh nhân khác. Và tôi chắc rằng đêm nay trên thiên đường cô ấy cũng vẫn nghe tôi hát. Tôi xin lỗi đã quấy rầy mọi người. Tôi chỉ không biết sống ra sao khi thiếu vắng cô ấy, nhưng mỗi đêm tôi vẫn tiếp tục hát. Chị có nghĩ rằng cô ấy nghe thấy tiếng tôi không?".
Tôi khẽ gật đầu mà nước mắt vẫn tuôn. Anh ôm tôi một lần nữa và cảm ơn tôi cùng tất cả mọi người. Đoạn anh quay bước, cúi đầu khẽ huýt sáo giai điệu thân quen.
Khi anh bước đi, tôi nhìn theo, thầm cầu nguyện cho cô ấy, cho anh và cho tôi một ngày nào đó cũng tìm được một tình yêu như thế.
**(Truyện sưu tầm)**

## Cúng mẹ (thơ)

Hắn là người thành đạt Gia cảnh rất đề huề Có con ngoan, vợ đẹp Cuộc sống vạn người mê.
Cứ mỗi lần giỗ mẹ Hắn thết cỗ linh đình Nào sơn hào, hải vị... Để chứng tỏ cái tình.
Trong một lần dọn dẹp Đem vứt bớt đồ thừa Hắn thấy quyển nhật ký Của mẹ mình năm xưa.
Tò mò nên hắn đọc Những con chữ quay cuồng Bởi những trang nhật ký Là những câu chuyện buồn:
Ngày... tháng... năm... mẹ tủi Con mắng mẹ: Già rồi Sao còn như con nít Làm cơm vãi khắp nơi!
Ừ! Bởi vì tuổi lắm Nên mắt kém, tay run Có làm rơi ít hột Âu cũng chỉ chuyện thường!
Khi con còn nhỏ dại Cũng làm vãi khắp nơi Mẹ quét, lau, gom lại... Đâu trách mắng nửa lời?
Ngày... tháng... năm... mẹ tủi Con mắng mẹ: Mặc đồ Sao lóng nga lóng ngóng Y hệt nhành cây khô!
Ừ! Tuổi già xương cứng Gân cũng chẳng dẻo dai Khó xở xoay, quay trở Sao cứ mắng mẹ hoài?
Khi con còn nhỏ dại Cứ hiếu động chân tay Mẹ mặc hoài mới được Đâu trách mắng nọ này?
Ngày... tháng... năm... mẹ tủi Con mắng mẹ: Điếc à? Trả lời rồi vẫn hỏi Cứ như trúng phải tà!
Ừ! Già nên nghễnh ngãng Nghe lúc được, lúc không Mẹ mới đi hỏi lại Mắng chi để tủi lòng?
Khi con còn nhỏ dại Hỏi đủ chuyện trên đời Mẹ kiên trì đáp lại Đâu mắng mỏ một lời?
Ngày... tháng... năm... mẹ tủi Con mắng mẹ: Bực mình! Cả đêm ho sù sụ Mất ngủ cả gia đình!
Ừ! Tuổi nhiều bệnh lắm Quy luật của tự nhiên Mẹ đâu mong như thế Mắng chi để tủi phiền?
Nhớ khi con nhỏ dại Đủ thứ bệnh mang vào Hàng năm trời khóc quấy Mẹ đâu trách câu nào?
Ngày... tháng... năm... mẹ tủi Cứ mỗi bận ăn cơm Mẹ phải ngồi góc khuất Bởi người mẹ không thơm.
Ừ! Kiếp này ta sống Con nít đến hai lần Mẹ già không tự liệu Tất cả cậy con làm!
Nhớ khi con nhỏ dại Tè, ị bậy khắp nơi... Mẹ lau chùi, tắm rửa Có bao giờ chê hôi?
Ngày... tháng... năm... ...
Ngày... tháng... năm... mẹ yếu Chắc chẳng thể... nữa rồi Những dòng này mẹ viết Là sau cuối trong đời:
Dù cho con lạnh nhạt Hay gắt gỏng bấc, chì Mẹ chỉ buồn đôi chút Chứ không trách cứ gì!
Con vẫn là con mẹ Bé bỏng và đáng yêu Dù cho theo năm tháng Con đã đổi thay nhiều...!
Hắn thẫn thờ nét mặt Nhìn lên phía bàn thờ: Ánh mắt bà âu yếm Qua lớp khói hương mờ!
Hắn nấc lên từng chặp: Con bất hiếu mẹ ơi

## Những câu chuyện về ALBERT EINSTEIN

• Vợ của Albert Einstein thường khuyên ông phải ăn mặc đàng hoàng hơn khi tới chỗ làm. Ông luôn phản bác lại rằng:
- Tại sao nhỉ? Mọi người ở đó đều biết tôi mà.
Khi Einstein tới dự một cuộc họp lớn, bà lại nài nỉ ông hãy mặc những bộ đồ đẹp đẽ hơn. Ông lại bảo:
- Tại sao chứ? Ở đấy có ai biết tôi đâu!
• Người ta thường yêu cầu Albert Einstein giải thích thuyết tương đối. Ông phân trần:
- Bạn giơ tay trên bếp lò, một phút dài như một giờ. Bạn ngồi với một cô nàng xinh đẹp, một giờ chỉ như một phút. Ấy chính là sự tương đối!
• Một hôm, hồi còn làm việc tại đại học Princeton, khi đang trên đường về, ông quên mất địa chỉ nhà mình. Tài xế taxi không nhận ra ông. Ông hỏi anh ta có biết nhà của Einstein không. Anh ta đáp rằng:
- Ai mà không biết địa chỉ của Einstein chứ nhỉ? Ai ở Princeton này chả rõ. Ông muốn gặp ông ấy à?
Và Einstein nói:
- Tôi là Einstein đây. Tôi quên địa chỉ nhà mình rồi, anh chở tôi về đó được không?
Tài xế chở ông về và còn chẳng lấy tiền cước xe.
• Có lần, Einstein đi tàu hỏa từ Princeton, người soát vé đi xuống để bấm vé của các hành khách. Khi anh ta tới chỗ Einstein, ông tìm trong túi áo vét, nhưng thể nào mò ra được tấm vé, ông chuyển sang túi quần, cũng không thấy. Ông lại tìm trong cặp, nhưng cũng không có luôn. Và rồi tiếp đến, ông tìm cả chiếc ghế bên cạnh mình. Vẫn chẳng thấy gì. Người soát vé nói:
- Tiến sĩ Einstein, tôi biết ngài mà. Chúng tôi đều biết ngài. Tôi chắc rằng ngài đã mua vé rồi. Xin đừng lo lắng gì cả!
Einstein gật đầu một cách lịch sự. Người soát vé tiếp tục đi tới những hàng ghế phía sau. Lúc sắp sang toa khác, anh ta quay lại và thấy nhà vật lý vĩ đại của chúng ta vẫn đang loay hoay quỳ xuống tìm tấm vé. Anh ta vội vã đi tới và bảo:
- Thưa tiến sĩ Einstein, xin đừng lo mà, tôi biết ngài là ai mà. Không vấn đề gì đâu. Ngài không cần vé đâu. Tôi tin là ngài đã mua vé rồi.
Einstein nhìn anh ta và nói:
- Anh bạn trẻ, tôi cũng biết tôi là ai mà. Nhưng tôi quên béng mất mình đang đi đâu rồi!
• Khi gặp Charlie Chaplin, Einstein nói:
- Tôi rất ngưỡng mộ nghệ thuật của ông, nhất là sự phổ quát trong ấy. Ông chẳng cần nói gì... Vậy mà cả thế giới vẫn hiểu được.
Charlie Chaplin đáp lời:
- Đúng vậy. Nhưng danh tiếng của ông còn vĩ đại hơn mà. Cả thế giới ngưỡng mộ ông, dù chẳng ai hiểu được ông nói gì!
(St)

## Một Sài Gòn cao thượng (truyện ngắn)

Tôi, một nữ sinh dưới quê lên theo một trường đại học ở Sài Gòn, ở trọ nhà anh họ tiết kiệm chi phí. Ngoài thời gian học trên giảng đường, lúc rảnh tôi phụ một tay ở quán hủ tiếu mì của anh ấy mở tại nhà, vừa đỡ một phần tiền học, vừa có thêm chút thu nhập.
Một lần, lúc quán không đông khách lắm, có hai cha con bán vé số dạo bước vô quán. Người cha bị mù. Người con dắt tay cha và cậu bé chỉ chừng bảy tám tuổi.
Vừa bước vô quán, cậu bé vui vẻ nói:
- Cha ơi, quán này hôm nay cho ăn từ thiện. Mình có thể ăn miễn phí đấy. Để con đi xếp hàng.
Rồi cậu dắt người cha mù lòa ngồi trên ghế.
Tôi chưa kịp lại gần thì cậu bé đã chạy lại bên tôi, chỉ tay lên bảng giá, ghé tai tôi thì thầm:
- Cô ơi, cô cho cháu hai tô hủ tíu mì thịt loại 30.000 đồng. Cháu có tiền và lát nữa cháu sẽ tiền. Cha cháu thèm ăn hủ tíu mì thịt từ lâu lắm mà không dám ăn. Vì cha tiếc tiền. Lát nữa cô cứ bảo quán hôm nay từ thiện miễn phí nhé.
Tôi nhìn cha con cậu bé quần áo thô ráp lam lũ bụi đường, nhìn đôi mắt mù lòa người cha, lại nhìn đôi mắt trong trẻo của cậu bé, trong lòng rưng rưng xúc động. Tôi bảo cậu:
- Hai cha con cứ ăn mì đi. Không cần trả tiền đâu. Hôm nay chị đãi.
Cậu bé quay lại chỗ ngồi. Tôi vô quầy nơi anh họ đang băm băm chặt chặt, kể vắn tắt lại câu chuyện và bảo 60.000 đồng tiền mì ấy, để lát nữa tôi trả. Anh họ bảo không cần đâu, anh mời họ cũng được mà.
Rồi anh họ làm hai tô hủ tíu mì thịt. Anh không làm hai tô thường loại 30.000 đồng mà làm hai tô đặc biệt. Quán anh họ tôi, tô đặc biệt chỉ nghĩa là mỗi thứ nhiều hơn một chút. Rồi tôi bưng ra cho hai cha con người mù bán vé số ấy.
Quán không đông khách lắm. Trong lúc hai cha con họ ăn, anh em tôi lẳng lặng quan sát. Tôi thấy người cha mù thỉnh thoảng lại lần lần sờ tô của cậu bé rồi gắp thịt sang tô cho cậu bé. Rồi cậu bé lại rình rình lúc người cha không để ý lại gắp thịt bỏ ngược lại tô của người cha mà không để người cha biết. Họ cứ vừa ăn vừa gắp qua gắp lại cho nhau như thế, một lúc khá lâu mới ăn hết tô hủ tíu mì thịt.
Ăn xong, cậu bé đỡ người cha mù đứng lên. Cậu lớn tiếng bảo:
- Cám ơn cô chú cho ăn từ thiện. Người cha mù cũng lập cập nói:
- Cám ơn cô chú!
Tôi cười đáp:
- Không có chi! rồi vẫy tay chào họ.
Thế rồi, hai cha con mù bán vé số dạo ấy dắt nhau rời đi. Tôi bảo anh họ:
- Thằng bé có hiếu quá!
Anh họ nhún vai, đùa:
- Người khổ đầy thiên hạ, làm sao mình giúp được hết? Lâu lâu làm phước thôi nhé, đừng làm phước hoài, có ngày anh dẹp quán.
Tôi cười không đáp, bụng thấy vui vui.
Tôi bưng hủ tíu cho một vài thực khách khác mới vô. Lúc này cha con người bán vé số mù dắt nhau đi đã khuất. Rồi tôi bắt đầu dọn dẹp bàn ăn chưa kịp dọn. Dọn tới bàn ăn hai cha con mù nọ, tôi chợt sững lại.
Tôi gọi anh họ tôi. Hai chúng tôi ngẩn ngơ bùi ngùi nhìn bàn ăn. Nơi đó, dưới một trong hai cái tô, kẹp lại một xấp tiền lẻ vuốt phẳng phiu ngay ngắn. Sau tôi đếm lại, đúng 60.000 tiền lẻ.
Là số tiền cậu bé bán vé số kẹp lại để thanh toán hai tô hủ tíu mì thịt.

## Ngôi chùa thứ mười một (truyện ngắn)

Sư cô Nhỏ là tên gọi của dân chợ xóm để phân biệt sư cô vừa nhỏ tuổi đời vừa vóc dáng nhỏ nhắn chuyên bán thức ăn sáng với những sư cô khác cũng hay ghé chợ để bán nhang hoặc rau nấm hoa trái vườn chùa.
Mỗi sáng sớm - khi Sư cô Nhỏ xuất hiện ở cổng chợ với cái giỏ bự thì ai cũng chợt thấy muốn cười. Nói là cười chào thì dĩ nhiên là quá đúng nhưng mà còn vì hình ảnh ngồ ngộ dễ thương.
Vậy, kỳ cục là sự tương phản giữa vóc dáng Sư cô nhỏ bé và cái giỏ to tướng nhìn như cảnh phim hoạt hình về chú thỏ ôm củ cà-rốt to đùng
- Mời dì ăn bánh bao chay.
- Dạ mời bác ăn bánh bao chay...
Ông bảo vệ chợ nghiêm mặt bắt bẻ:
- Nhìn là biết bánh bao chay rồi, chẳng lẽ Sư cô bán bánh bao mặn sao?
Sư cô Nhỏ đỏ mặt bối rối.
Mấy bà bán hàng gần đó nhao nhao trách ông bảo vệ đã không mua giùm thì thôi, lại còn trêu chọc Sư cô Nhỏ làm chi. Ông bảo vệ vẫn không thôi, tỉnh bơ tiếp tục:
- Nhìn cái bánh tròn đầy u lên một cục như vậy ai chẳng biết là bánh bao, cho nên chỉ cần nói “mời bác ăn bánh”, bỏ bớt chữ bao luôn.
Lần này thì ông bảo vệ bị hớ nặng, chơi chữ thì mấy bà bán hàng miệng mồm mấy cũng đành chịu thua ông bảo vệ vốn là giáo viên tiểu học về hưu, nhưng đụng tới hình dáng bánh trái thì làm sao qua mặt dân chợ là đàn bà được chứ. Phe đàn bà lập tức phản công ngay:
- Bánh cam cũng tròn quay và u một cục nghen ông.
- Bánh cống.
- Bánh ít trần.
- Bánh trôi nước.
- Bánh bông lan.
Đang giơ hai tay che đầu tỏ ý mình bị đánh hội đồng, ông bảo vệ rộng miệng cười chớp lấy cơ hội:
- Bông lan mà u một cục thì tui chưa thấy bao giờ, ai có cho tui một nhánh ngắm nghía thử.
Cả chợ í ó. Chơi chữ kiểu này là ăn gian. Họ nhao nhao đòi phạt ông phải mua hai cái bánh bao mới được. Ông bảo vệ thò tay vô túi móc tiền mua luôn năm cái và rút điện thoại ra nói oang oang “Trưa nay nhà mình khỏi nấu cơm nghen em”.
Ai nấy cười vui vẻ. Rồi thì ai cũng thò tay tới mâm bánh bao, người ít nhất cũng lấy hai cái.
Người ta thắc mắc sao cái giỏ nhìn to đùng mà số bánh bao bày ra không tương xứng, mới biết Sư cô Nhỏ lót rất nhiều lớp giấy báo và vải vụn như người ta độn giỏ đựng ấm trà để giữ cho bánh bao được nóng lâu.
Hỏi ra mới biết thêm điều nữa là Sư cô Nhỏ ở xa lắm, mỗi sáng phải đạp xe gần hai chục cây số mới ra tới chợ. Làm ngay một phép tính cộng đơn giản là ra mỗi ngày Sư cô Nhỏ phải đạp xe bốn chục cây số đi về, ờ, sáng sớm thì còn mát mẻ, buổi trưa nắng chang chang, và ngày mưa nữa.
- Sao Sư cô không bán ở chợ gần gần cho đỡ cực? - Một người ái ngại hỏi.
Sư cô Nhỏ bối rối, rồi nhỏ nhẹ:
- Dạ, chắc là trò có duyên với cô bác ở chợ này.
Câu nói khiến dân chợ nao nao trong lòng, rồi thở dài “Đường tu hành cũng lướng vướng duyên nợ như đường đời chớ có phải”.
Dân chợ nhiệt tình ủng hộ Sư cô Nhỏ nhưng thật lòng là ăn hoài một món bánh bao cũng ngán cho nên họ yêu cầu Sư cô Nhỏ đổi món.
Hôm sau, Sư cô Nhỏ bán bánh mì. Sinh chuyện.
Bánh bao thì chỉ có một mình Sư cô Nhỏ bán, còn bánh mì thì đã có tới ba xe bánh mì ở cổng trước cổng sau và góc chợ. Chuyện áo cơm...
Sư cô Nhỏ trở thành đối thủ của cả ba. Thì thà thì thào là bánh mì chay lạ miệng cũng ngon nhưng mà không được nóng giòn, chan sẵn nước lèo lại còn ủ kín nữa thì không bị mềm nhũn mới là lạ. Khách ủng hộ bánh mì chay cũng nói với Sư cô Nhỏ là bánh mì bị nhũn thì ăn không ngon.
Mấy ngày trôi qua rồi cả tháng cũng trôi qua, không thấy Sư cô Nhỏ tới chợ, người ta hỏi nhau rồi dò đoán lung tung.
Người thì nói có lẽ vì mùa mưa tới, chợ xa chùa quá cho nên bất tiện.
Người thì nói chắc là tại tụi mình chê bánh mì mềm khiến Sư cô Nhỏ mắc cỡ. Ừ, đúng rồi.
- Sư cô Nhỏ đang nghĩ như vầy nè - Ông bảo vệ lý lẽ - Khách mua vì ủng hộ là chính mà phụ lòng khách thì mặt mũi nào. Vậy đó.
- Tội lỗi tội lỗi quá chừng - Bà Hồng tạp hóa đập mạnh hai tay vô hai bên đầu mình - Ngày nào cũng gặp nhau giữa chợ cho nên mình quen thói chợ búa. Mua bánh của Sư cô Nhỏ thì đâu phải vì chuyện ăn uống mà lần hồi sao mình lại đòi đổi món, rồi chê bánh mì mềm, bây giờ thì còn cho là mình ủng hộ rồi bị phụ lòng... Trời ơi...
Ai nấy sực như tỉnh ra. Đúng là tội lỗi quá. Phải sám hối. Nhưng mà ... sám hối cái miệng suông đâu có được. Ai biết Sư cô Nhỏ ở chùa nào không? Không chính xác, chỉ nhớ là có lần Sư cô Nhỏ nói chùa xa chợ hai chục cây số.
Chắc là chùa của Sư cô Nhỏ nghèo lắm cho nên trụ trì mới để đệ tử nhỏ bé phải bươn chải giữa chợ đời. Ờ, muốn sáu giờ sáng tới chợ thì phải bắt đầu đạp xe lúc năm giờ và phải dậy sớm từ trước đó nữa để làm hàng... Trời, con cháu mình trạc tuổi đó vẫn còn nhõng nha nhõng nhẽo.
Nói năng một hồi lan man dài qua chuyện khác, ờ, kể ra cũng đáng ghen tỵ, đạo chẳng khác chi đời là mấy, có ai thấy chú tiểu hay quý thầy vất vả bán bánh bán nấm bán nhang không?
Ông bảo vệ phản ứng tức thì:
- Mấy bà bán hàng ở chợ ai cũng nhìn thấy, còn khi tui đi làm rẫy thì chỉ có giun dế biết mà thôi.
- Ờ há!
Rằm, dân chợ thường rủ nhau mua gạo và dầu đi cúng thập tự. Dân chợ có sẵn một danh sách các chùa nghèo vùng ven, đợt này cúng mười chùa hướng Đông thì đợt sau cúng mười chùa hướng Nam... Chọn cách đi như vậy thì vừa tiết kiệm chi phí xăng xe vừa thuận tiện thời gian.
Nhưng - lần này thì dân chợ chấp nhận tốn tiền xăng quyết tìm cho ra Sư cô Nhỏ.
Ông bảo vệ nhận nhiệm vụ thiết kế một cung đường hình tròn bán kính hai chục cây số lấy chợ làm tâm điểm. Gọi điện thoại hỏi han kỹ càng thì đếm được có mười một ngôi chùa nằm trên vòng tròn này.
Vậy, gạo và dầu mua về đã phân thành mười phần để cúng thập tự, không sao, hùn tiền thêm để mua thêm một phần nữa. Ờ, biết đâu... ờ... ông trời khiến thêm phần phát sinh này để mình gặp được ngôi chùa của Sư cô Nhỏ. A ha... được vậy thì vui biết mấy. Nhớ câu nói của Sư cô Nhỏ “Dạ, chắc là trò có duyên với cô bác ở chợ này”.
Đang bàn tán râm ran hy vọng bỗng điện thoại của bà Hồng tạp hóa nổi tiếng đanh đá reo vang, là cô con gái bận đi công tác bất ngờ nên nhờ bà bốn giờ chiều nay đón cháu ở nhà trẻ giùm.
Thọc mạnh cái điện thoại vô túi, bà Hồng nhăn nhó:
- Số tui xui rồi, bốn giờ chiều phải về đón cháu nội.
Ông bảo vệ làu bàu:
- Mấy bà lâu lâu đi cúng chùa một lần mà cứ ôm đồm chuyện gia đình theo là sao? Thử thong dong một lần đi.
Điện thoại của bà My tạp phẩm cũng đổ chuông, là ông chồng cáu kỉnh gọi hỏi đôi tất để đâu tìm hoài không thấy mà đã sát giờ đi họp rồi, bà My nổi cơn tức trút qua ông bảo vệ:
- Đàn bà mà được thong dong, nói nghe biết ngay... đúng là đồ đàn ông!
Cả xe cười rân.
Ông bảo vệ nhún vai ra vẻ thân phận mình là gươm lạc giữa rừng hoa cho nên đành chịu thua cái miệng ghen tỵ vô lý của mấy bà.
Trên đường đi tới ngôi chùa thứ mười một, chiếc xe hàng nhẹ hẫng vì chỉ còn một phần quà cuối cùng, tâm trạng mọi người thì nhiều nỗi hơn.
Đi qua từng ngôi chùa mà không thấy Sư cô Nhỏ, ai cũng hy vọng là nơi sắp tới sẽ gặp. Mới biết là sự vắng mặt của Sư cô Nhỏ để lại nhiều áy náy trong lòng.
Xe ngừng lại trước ngôi chùa nhỏ có bụi tre um tùm ngay cổng, bà My tặc lưỡi:
- Mình mà ở gần đây thì phụ một tay với quý Sư cô làm măng chua bán cho thiên hạ nấu canh chua ăn mê luôn.
- Sợ bà quá - Ông bảo vệ chắp tay vái dài - Tới chùa không nhìn thấy Phật mà lại thấy mấy mụt măng nằm dưới mặt đất.
Mọi người cười khúc khích đợi bà My độp lại một câu đích đáng nhưng không, bà My đang nhìn theo dáng áo nâu nhỏ nhắn thập thò sau cánh cửa nhìn ra.
Tất cả đồng loạt nhìn theo và bước nhanh lên thềm. Áo nâu rụt rè bước ra khỏi cánh cửa, hai tay khoanh lại lễ phép:
- Chào các bác các dì, thầy con hôm nay không có ở nhà.
Không phải Sư cô Nhỏ.
Khi đã thôi nghĩ tới và không chờ gặp nữa thì Sư cô Nhỏ hiện ra ngay trước đầu xe tải, ông tài xế bóp còi tin tin tin inh ỏi khiến mọi người đang ngủ gật gà đều giật mình nhìn ra.
Ô! Sư cô Nhỏ gầy gò kinh khủng.
Nhìn tình hình là hiểu liền, ông bảo vệ vội nhảy xuống khỏi xe trước tiên để giúp Sư cô Nhỏ dắt cái xe đạp và mấy trái bí đao ra khỏi cái vũng nằm giữa đường. Là bánh xe bị lủng đột ngột mà giỏ xe thì đựng mấy trái bí đao lắc lư khiến tay lái loạng choạng đâm sầm xuống vũng.
Mọi người nhìn quanh, chỉ là căn nhà nhỏ giữa vườn rau và một bệnh nhân, mùi thuốc Nam nồng nồng.
- Dạ, ba má trò mất sớm, chị nuôi trò từ nhỏ. Dạ... trò đang học tu ở chùa trên thành phố... Chị Hai phát bịnh, sư phụ cho trò về nhà chăm sóc tới khi nào chị khỏe thì trò về chùa lại.
Nhìn bệnh nhân nằm thiêm thiếp với khuôn mặt vàng vọt và hơi thở đứt quãng, bụng căng phồng, ai cũng ái ngại - một gánh quá nặng với tuổi mười sáu.
- Vậy mà tưởng Sư cô giận dân chợ nói năng lung tung - Bà Hồng nói.
- Dạ sao lại giận? - Đôi mắt Sư cô Nhỏ mở to - Trò đi bán hàng may mắn được cô bác ở chợ thương nhiều mà.
- Vậy sao Sư cô không tới chợ nữa?
- Dạ vì chị dạo này mệt nhiều - Sư cô Nhỏ thấp giọng như sợ người bệnh nghe thấy - Trò không đi đâu lâu được cho nên ở nhà trồng rau - Sư cô Nhỏ nhoẻn cười - Dạ có luống rau dền cũng lớn lớn rồi, để trò cắt rau mấy dì đem về luộc ăn cho vui.
Trong khi Sư cô Nhỏ đi ra vườn thì mọi người tụm đầu lại hội ý rất nhanh hay nói đúng hơn là không cần hội ý, tiền quỹ của chợ dành cho việc cúng chùa và làm từ thiện hiện đang còn bao nhiêu thì nhét hết dưới gối của người bệnh, đưa tận tay sợ Sư cô Nhỏ ngại ngùng.
Không phải ai hoàn cảnh ngặt nghèo cũng dễ dàng đưa tay nhận quà đâu, nhớ cái giỏ to đùng vì muốn giữ nóng mấy cái bánh bao là biết tính người.
Thêm một rằm nữa tới, dân chợ lại sửa soạn đi cúng thập tự. Lần này dĩ nhiên đi về hướng có ngôi nhà của chị em Sư cô Nhỏ.
Ngoài mười phần như thường lệ còn chuẩn bị thêm một phần đặc biệt cho Sư cô Nhỏ là một phong bì khá dày dặn, vậy, người có tính chi li nhất nghe kể về hoàn cảnh Sư cô Nhỏ cũng động lòng.
Mọi người vui vui nói với nhau, lần này tới ngôi chùa thứ muời một thì chắc chắn gặp Sư cô Nhỏ rồi. Nói xong vội che miệng lại, tội lỗi tội lỗi... sao dám so sánh căn nhà nhỏ giữa vườn rau với một ngôi chùa.
Buổi sáng trước rằm một ngày thì Sư cô Nhỏ xuất hiện ở chợ, yên sau xe đạp chất đầy rau. Ai cũng nhanh nhảu thò tay vô túi sẵn sàng trả tiền rau một cách hào phóng.
Sư cô Nhỏ bẽn lẽn giấu tay ra sau lưng:
- Dạ... chị Hai đã mãn kiếp rồi. Dạ... vườn còn mấy luống rau... để biếu mấy dì thôi... Dạ hôm nay trò xin chào mấy dì, ngày mai trò về chùa. Dạ... trò cảm ơn mấy dì nhiều lắm.
Bà Hồng nổi tiếng đanh đá là người ứa nước mắt đầu tiên, rồi tới bà My... Ai cũng sụt sịt.
Sau này, khi nhắc tới Sư cô Nhỏ, mấy bà trách móc ông bảo vệ thường ngày nói nhiều mà sao khi đó không nói được lời nào hay hay, ông bảo vệ lắc đầu “Tưởng lúc nào dùng lời cũng thấu sao?”.

## Tôn trọng nỗi buồn của người khác

Có một dạo tôi bị trầm cảm, và khi nói chuyện với chị tôi, chị ấy bảo, "Chắc phải có vấn đề gì đó thì em mới như vậy, hoặc là do em yếu hơn chị chứ chị còn trải qua nhiều chuyện hơn em nhưng giờ chị vẫn ổn. Em hãy nghĩ tích cực lên đi."
"Nghĩ tích cực đi", "Mới vấp ngã có chút mà đã vật vã như thế, sau này gặp chuyện lớn hơn thì làm thế nào?", "Sao em yếu đuối thế, có chút chuyện như vậy mà cũng không vượt qua được", "Chị còn trải qua nhiều chuyện tồi tệ hơn em nhưng chị vẫn vượt qua được đấy thôi. Đấy là do em, em phải mạnh mẽ hơn", "Sống sung sướng từ nhỏ quen rồi, giờ chịu có chút khổ cũng không chịu được". Đây là những câu tôi thường hay nghe được, không chỉ từ người thân mình mà còn từ những người xung quanh và đây cũng là những câu nói dễ gặp nhất ở phần comment dưới những câu chuyện chia sẻ nỗi buồn mà chúng ta thường hay thấy ở trên mạng.
Dù rằng những câu nói trên có xuất phát từ ý tốt muốn động viên, muốn khích lệ, hay muốn người nghe cảm thấy chuyện của họ không tệ đến mức đó thì trên thực tế những lời khuyên này lại mang hơi hướm đổ lỗi và khiến cho người nghe cảm thấy tồi tệ hơn mà thôi. Nếu người ta có thể chọn lựa vui lên thì chẳng ai buồn ngay từ ban đầu!
Mỗi người có một sức bật, độ dẻo dai tinh thần lẫn độ nhạy cảm hay khả năng chịu đựng tổn thương khác nhau dựa trên trải nghiệm, hoàn cảnh môi trường, bẩm sinh và cả di truyền. Đương nhiên tất cả các yếu tố này đều không thể lựa chọn hay nằm trong quyền điều khiển của một người. Thế nên việc kêu một người nghĩ tích cực đi hay đừng nhạy cảm quá, nó rất là vô nghĩa.
Trong 5 yếu tố tính cách thì yếu tố rối loạn thần kinh (neuroticism) cái bao gồm cả sự nhạy cảm có đến 40% là từ di truyền, cộng thêm sinh ra đã như vậy, rồi sau đó mới đến sức ảnh hưởng từ môi trường. Mà có một vài nghiên cứu còn cho rằng sức ảnh hưởng từ di truyền còn cao hơn sức ảnh hưởng từ môi trường đối với yếu tố rối loạn thần kinh (1). Không phải cứ muốn thấp là thấp, hoặc muốn không nhạy cảm là không nhạy cảm. Những người có chỉ số rối loạn thần kinh cao dễ mắc các dạng rối loạn cảm xúc như rối loạn trầm cảm hay rối loạn lưỡng cực.
Giả sử như tâm lý bạn là sợi dây thun và độ căng của nó là mức độ bạn chịu được stress và bạn không được chọn lựa chất liệu cho sợi dây thun đó. Nếu bạn may, có được sợi dây thun với chất liệu tốt (gene, môi trường, gia đình...) thì độ căng và độ đàn hồi của bạn sẽ tốt và dẻo dai. Nếu bạn không may có phải sợi dây thun tệ thì dù có bao nhiêu chất đổ vào củng cố thì độ căng của nó cũng chỉ có thể cải thiện thêm dc 1,2 cm trước khi nó đứt. Và nếu căng nhiều quá thì độ đàn hồi sẽ từ từ giảm đi, nghĩa là mức độ phục hồi sau stress sẽ càng yếu. Và có khi chỉ hơi căng một xíu thôi, vấn đề gây stress nhỏ thôi, cũng có thể khiến sợi dây thun đó bị đứt vì nó không còn độ đàn hồi nữa.
Bạn tôi từng kể tôi nghe rằng khi cô ấy đi tư vấn tâm lý thì được chuyên viên tư vấn bảo rằng. “Sao anh chị em của em cũng trải qua những sự kiện như vậy mà họ vẫn bình thường còn em thì lại mắc rối loạn tâm lý? Em có nghĩ đến điều đó chưa?” Đây là một câu hỏi rất vô tâm và hoàn toàn đi ngược lại với những quy tắc khi điều trị hay tư vấn tâm lý. Và điều đáng sợ ở đây là bởi vì nó nghe sơ qua thì có vẻ không sai thế nên chẳng ai buồn suy nghĩ sâu xa hay là chấp nhận sự khác biệt của một người.
Mỗi người đều có những trải nghiệm riêng, vấp ngã riêng và học được những bài học riêng cho mình. Không phải ai cũng có những trải nghiệm giống nhau hay học được những bài học giống nhau. Chúng ta có thể chia sẻ kinh nghiệm của mình nhưng đừng áp đặt hay bắt buộc những người khác phải giống mình hoặc thất vọng khi họ không làm được, hay coi thường những trải nghiệm của họ. Bởi vì khi đó chúng ta đã ngầm so sánh mình với họ. Bất cứ sự so sánh nào cũng khập khiễng, và dẫn đến kết quả một bên hơn, một bên kém. Và đồng thời sự so sánh cũng dẫn đến phán xét rồi đổ lỗi, hạn chế cách nhìn cũng như cách tiếp nhận thông tin.
Và nếu bạn không có lời gì tốt đẹp để nói hay chia sẻ thì hãy im lặng, hoặc thay vì nói những câu như ở đầu bài, bạn có thể nói: "Mình không biết phải nói gì, nhưng mình luôn ở đây lắng nghe cậu", "Có thể mình chưa hiểu được vấn đề của cậu, nhưng mà mình luôn sẵn sàng nghe cậu chia sẻ", "Cậu còn có mình ở đây, chúng ta sẽ cùng nhau vượt qua rắc rối này", "Có thể cậu không tin nhưng những gì cậu đang cảm nhận chỉ là tạm thời mà thôi. Mọi chuyện rồi sẽ ổn", "Mình có thể làm gì để cậu bớt buồn đây?". Dù không thể giải quyết được vấn đề của họ nhưng những câu có thể khiến cho người nghe cảm dễ chịu hơn,
Hãy tôn trọng sự khác biệt của một người, tôn trọng sự trầm cảm của người khác, tôn trọng nỗi buồn của họ. Điều này có thể chẳng ngăn được họ không bị bệnh hay không buồn nhưng nó sẽ khiến cho trải nghiệm của họ trở nên dễ chịu đựng hơn.
**Hải Đường Tĩnh Nguyệt Tham khảo:**[**http://bjp.rcpsych.org/content/97/408/441**](http://bjp.rcpsych.org/content/97/408/441)

## Bếp lửa (truyện ngắn)

Năm ấy má về, cái dáng thoăn thoắt bước trong đêm lạnh, trên đôi vai với chiếc quang gánh hiện rõ dưới ánh đèn đêm giao thừa. Phiên chợ tết chẳng còn ai, người người ở nhà chuẩn bị đón giao thừa bên gia đình, chỉ còn những chậu hoa cúc chưa bán kịp sót lại ngả nghiêng giữa một xó chợ trông thật tiêu điều. Như hàng năm, gánh hàng trái cây của má dù bán còn hay hết, má vẫn tranh thủ về lo nhà cửa, bếp núc và hàng trăm thứ việc, có lẽ đêm 30 là đêm cực nhất đối với má. Trong đôi thúng gánh là hai chậu cây quất trái say cành chín vàng mọng trĩu, tôi ôm đặt vào trước hành lang, gắn thêm vài dây đèn chớp trông thật rực rỡ với không khí xuân về, má lau bàn thờ đặt xuống đó một ít bánh mứt với cả trà, quay sang dặn tôi.
- Con đi xuống lấy cái dĩa, lên đây sắp 5 loại quả này để lên bàn thờ, xong rồi xuống bếp nhóm lửa lên, để luộc trứng kho thịt, và còn gói bánh tét rồi nấu nữa, nhanh lên trễ lắm rồi.
- Ủa sao lại là 5 quả hả má.
- Đó là mâm ngũ quả đó con, chỉ có trong ngày tết, trước hết mãng cầu, dừa, xoài, đu đủ và sung. Năm trước đã xếp lên bàn, giờ con quên rồi sao.
- Dạ. Má đi tắm đi, để con sắp lên bàn thờ rồi xuống nhóm lửa.
Ngoài sân từng cơn gió mang hơi thở của tiết xuân tháng giêng, lùa qua khe cửa se lành lạnh từ nhà trên tới nhà bếp. Những người anh đã quấn mền ngủ từ bao giờ tư thế nằm ngang nằm dọc chẳng hề ý tứ, tiếng ngáy đều đều nối tiếp trút vào đêm.
Tôi nhóm lên bếp lửa, thấy lòng mình rạo rực, cái giá lạnh cũng dần dần tan biến khỏi con người, miệng không còn đơ cứng, và những ngón tay cũng chẳng còn nhăn buốt. Mỗi năm giao thừa tôi thích được ở dưới bếp, để nấu bánh tét và nghe mẹ kể " những mùa xuân xưa rất nghèo, thèm tiếng sôi ùng ục của nước, thèm nghe mùi hương bánh tét được gói trong chiếc lá chuối với vị nếp chín thơm nồng, thèm nghe tiếng lửa bập bùng, chứ không phải tiếng bom rơi đạn nổ, khói lửa điêu tàn giăng kín quê hương, và những gì bây giờ đã có trước mắt, là thứ xa xỉ và là ước mơ của những thế hệ trước ". Đôi mắt má đăm chiêu rưng rưng theo tiếng nói nghẹn ngào.
Tôi nhìn cái dáng của má bên bếp lửa hồng, đôi bàn tay gầy guộc khéo léo gói từng chiếc bánh, những giọt mồ hôi ướt đẫm trên gương mặt, một hình ảnh quá quen thuộc lẫn ấm lòng của mấy chục cái xuân qua, đó là một thời khắc mà tôi vĩnh viễn không bao giờ quên được, má nấu luôn cả trời tuổi thơ của tôi nên mỗi dịp xuân về nghe hương vị nồng nàn, mùi thơm của nếp đã thấm vào hồn mê mang từ thuở lên bảy cho đến giờ. Ánh sáng của muôn nhà đang thức đón giao thừa, như chính má thức cặm cụi lo chu toàn để mùa xuân đủ đầy no ấm, dẫu nghèo hay sang vẫn là mùa xuân đẹp nhất, có má mùa xuân ngọt như hoa quả mật đời. Má quay sang tôi dặn dò.
- Lấy cái nồi bỏ trứng vào luộc đến chín thì vớt ra lột vỏ cho má kho thịt.
- Dạ chín rồi đó má.
- Xong rồi lên đi mặc thử bộ đồ xuống cho má coi đẹp không.
- Má có mua quần áo mới cho con hả.
- Ừ má để bên trong buồng, thử xong rồi cất đi để ngày mai mặc đi lễ chùa.
Tôi vui mừng chạy vào trong buồng, thấy bộ đồ mới tinh còn mùi thơm của vải, vội vàng ngắm nghía thích thú mặc vào, chiếc áo sơ mi trắng rộng thùng thình, cái quần tây cũng quá cỡ, mỗi năm má đều mua quần áo lớn hơn một ít, tôi lật đật chạy xuống bếp cho má coi.
- Ý trời ơi, đẹp quá bộ đồ vừa như khuôn.
- Cái gì mà vừa như khuôn, nó rộng như cái bao bố thế này mà.
- Thì sang năm thêm lớn, lại mặc vừa, chứ mua số nhỏ quá, sang năm lớn lên rồi lại bỏ. Đẹp rồi đó, lột ra cất đi.
Mỗi năm má đều nói câu này, có lẽ đó là câu nói huyền thoại của những người mẹ mỗi lần mua áo quần cho con. Tôi tháo bộ đồ mới cất xếp gọn gàng ngăn nắp, chạy xuống bếp quay quần bên má. Bên bếp lửa bập bùng, một số chiếc bánh má đã gói xong cho vào nồi, cái mùi hương này nó cứ nhắc tôi nhớ miên man về những khoảng trời xa xăm ngày ấy, chẳng nơi đâu ấm áp như nơi này, ngoài kia là những cơn lạnh thấu lòng, gió phảng phất se sắt vào da thịt, hàng cây trước ngõ cũng tái tê trong một đợt giao mùa. Tôi hiểu ra rằng không có mùa xuân nào ấm đẹp bằng chính nét xuân của quê nhà. Tôi ngồi nghe má kể chuyện bên bếp lửa, nồi thịt kho trứng sôi ùng ục lẫn hương vị bánh tét, thả vào đêm ba mươi làm người ta nôn nao nhớ về những tháng ngày, những tháng ngày ấy là khoảng trời hạnh phúc và êm đẹp ngọt ngào như miếng mứt dừa gặm nhấm trong dịp tết, như bếp lửa có dáng mẹ xua tan những đêm đông.
- Sao con không ngủ đi, sắp xong hết mọi việc rồi.
- Con muốn ở đây đón giao thừa với má.
- Trời ơi, lại đón giao thừa nữa, năm nào thằng hai, thằng ba, cũng ngủ say, miệng thì cứ nói tối nay đón giao thừa với má, mà về thì thấy tụi nó đã ngáy khò khò. Mấy năm nay chỉ có 2 mẹ con dưới cái bếp như thế này, người ta đón giao thừa là cả nhà sum vầy bên nhau, thôi đi ngủ đi có 2 người mà giao thừa gì, giao thiết gì.
- Thì như mọi năm ấy, gọi là đón giao thừa đi, con nôn tết quá nên không ngủ được.
- Ngày xưa khi má còn ở nhà ngoại, cứ mỗi đêm giao thừa, cả nhà sum họp đông vui lắm, nhưng chủ yếu quay quần bên bếp lửa, tiếng nói cười rộn ràng, thuở ấy nghèo nhưng tết rất ý nghĩa đối với văn hóa của người Việt Nam chúng ta, ra chợ đông kín người đi chơi, chùa chiền vui như lễ hội, giờ càng ngày thấy tết càng nhạt nhẽo.
- Con có thấy nhạt đâu, đối với con chỉ đơn giản thấy cái dáng của má bên bếp lửa nấu bánh là có cả một trời xuân hiện về vui tươi hạnh phúc về rồi.
- Cái thằng này, còn nhỏ mà y như ông già chín mươi.
- Mà mấy năm má đều mua chậu Cúc Vạn thọ, sao năm nay má lại mua quất.
- Ừ cho khác với mọi năm vậy mà.
- Sao tết người ta hay mua bông vạn thọ vậy má.
- Để má nói ý nghĩa, vì sao bông vạn thọ có trong dịp tết cho con nghe " vì cầu bình an và cũng chính là lòng hiếu thảo đối với cha mẹ ông bà. Những bông cúc vạn thọ là tượng trưng cho sự ấm áp của ánh mặt trời, là khát khao một cuộc sống sung túc, giàu sang " vạn thọ còn hiểu nôm na là tuổi thọ nhiều đó con.
- Sao năm nay má lại chọn cây quất, nó tượng trưng cho điều gì.
- Nó cũng có 1 ý nghĩa gần giống vậy, thường người ta sẽ chọn cây quất thật nhiều quả "trong quan niệm dân gian là biểu tượng cho sức khỏe, bình an, trường thọ và sự may mắn trong tình duyên, thể hiện sự sum vầy của nhiều thế hệ trong gia đình. Những cây quất lá xanh tốt, quả vàng chi chít thể hiện sự trù phú, hứa hẹn năm mới được mùa, ăn nên làm ra, dồi dào sức sống đó con"
- Con hiểu rồi. Vậy là nhà mình năm nay được mùa.
Má lắc đầu khẽ cười, nụ cười hòa lẫn vào tiếng củi cháy, những làn khói ảo huyền bao trùm không gian bếp, xuân đến xuân lại đi, và mỗi mùa xuân luôn đẹp trong đôi bàn tay của má, đã tô lên cuộc đời những gam màu hồi ức thật đẹp, nó thật bình dị và nhẹ nhàng như những sợi khói đã hít trong mũi và trôi vào cõi người, má ướp vào hồn hương vị tết nồng nàn, mỗi năm xao xuyến tôi trong căn nhà bếp đôi mắt cay nồng cứ nhớ những mùa xuân đã qua với hình dáng của má.
Má đã mang mùa xuân về cho cuộc đời tôi, bằng bếp lửa khói nồng, bằng những câu chuyện kể chẳng giữa bếp lửa chẳng còn mùa đông lạnh giá đanh phủ vùi lấy đời tôi. Tôi còn má có nghĩa là mùa xuân sẽ đến mỗi ngày, là tuổi thơ còn đây là hương vị tết say. Là những điều tuyệt vời đã có trên trái đất này.
Cho đến bây giờ tôi đã trưởng thành, mỗi năm tết về, vẫn thấy má như thuở ấy thắp lên cái bếp đầy ấm áp, ngọn lửa ấy chính là tấm lòng của má đã sưởi ấm cho cả nhà. Giờ mái tóc má đã bạc trắng, có phải những sợi khói của thời gian đã đọng lại không bao giờ bay đi, hương vị của ngày ấy vẫn còn đó, vẫn là tuổi hồng thưở nào quay quần bên má của những đêm giao thừa. Mùa xuân xin hãy cứ tới, nhưng đừng ban tặng cho má thêm bất cứ một tuổi nào. Nếu một mai má không còn nữa, hương vị tết sẽ nhạt mất, và cuộc đời tôi là những đợt lạnh trong ngõ gió heo may, hình dáng ấy sẽ không còn dưới bếp, bếp lạnh đến không ngờ nếu vắng đôi tay má, hương vị tuổi thơ sẽ không được lặp lại mỗi năm xuân về. Mùa xuân của tôi là bóng của má trong gian bếp.
Truyện ngắn của Quang Nguyễn

## Sử dụng ấm Tử Sa uống trà thêm nồng vị

CÁCH CHỌN ẤM TỬ SA
Người pha trà phải biết chọn kích thước và hình dáng của ấm trà, loại chất liệu và nhiệt độ nung sao cho phù hợp với loại trà và số lượng người được dùng. Và bởi vì ấm trà là thứ được sử dụng hàng ngày thì nó phải là loại dễ dàng sử dụng, bền và đẹp mắt.
Những người say mê Công Phu trà một cách nghiêm túc thường dành hàng giờ đồng hồ tranh luận về những ưu điểm của các ấm trà, nhưng hầu hết mọi người đều đồng ý với bốn quan điểm sau:
• Bất cứ loại trà nào cũng sẽ có hương vị tuyệt vời nếu pha trong ấm trà bằng đất nung và những chiếc ấm trà tốt nhất luôn là những chiếc ấm làm từ Tử Sa, một loại đất thuộc vùng Nghi Hưng của Trung Quốc.
• Tử Sa có độ xốp hoàn hảo và có khả năng xử lý nhiệt tốt giúp cải thiện hương vị của trà ngon hơn rất nhiều lần so với trà pha trong các ấm bằng thủy tinh, sứ hoặc gốm tráng men.
• Mỗi ấm trà Nghi Hưng chỉ nên được dùng với một loại trà nhất định.
• Những chiếc ấm được nung ở nhiệt độ cao sẽ có bề mặt mịn và mỏng, hoàn hảo để pha với bất cứ loại trà nào và đặc biệt là đối với trà xanh, bạch trà và trà Ô Long. Còn đối với các loại ấm được nung ở nhiệt độ thấp với bề mặt ít mịn và dày thì phù hợp với Hồng trà (hay còn gọi là “ Trà đỏ” ở Trung Quốc) và trà Phổ Nhĩ.
Ấm trà bằng Tử Sa của Trung Quốc không áp dụng kĩ thuật tráng men, khi làm thành ấm trà vẫn giữ nguyên vẹn tính chất xốp của nó với các lỗ nhỏ li ti trên bề mặt và khi pha trà, dầu trà sẽ thấm vào đó và tích tụ bên trong ấm theo thời gian, làm mịn vị của trà và thậm chí còn cải thiện chất lượng của trà bằng cách thêm vào đó “hương vị” độc đáo được tạo nên từ những khoán chất có trong trà đã tích tụ lâu bên trong ấm.
Có ý kiến cho rằng không nên dùng cùng một ấm trà để pha nhiều loại trà khác nhau trừ khi chúng cùng thuộc một dòng trà, tuy nhiên điều này cũng không được nhiều người đồng ý vì có nhiều loại trà cùng thuộc một dòng trà như nhau nhưng trong đó sẽ có vài loại trà mang hương vị đậm đà hơn và một thời gian sau hương vị của chúng có thể sẽ ảnh hưởng đến hương thơm và vị của loại trà khác.
Chiếc ấm trà sẽ trở thành người bạn đồng hành của bạn qua nhiều năm nên hãy chắc chắn rằng không có bất cứ vết trầy xước hay nứt nào trên ấm. Chiếc ấm nên có trọng lượng phù hợp và khiến bạn cảm thấy thoải mái khi cầm trên tay. Tay cầm và nắp ấm phải vừa với ngón tay của bạn và nắp ấm phải vừa vặn chính xác với miệng ấm, đồng thời kích cỡ miệng ấm cũng phải phù hợp với kích thước lá trà bạn sử dụng. Miệng ấm với kích cỡ nhỏ thường sẽ giữ hương thơm của trà trong ấm trong khi kích cỡ miệng ấm lớn sẽ khiến hương trà dễ dàng thoát ra ngoài. Vậy nên loại trà lá nhỏ hoặc lá cuộn với mùi thơm nhẹ sẽ thích hợp với ấm có miệng ấm nhỏ (Trà xanh, bạch trà, Ôlong). Ấm với kích thước miệng ấm lớn hơn sẽ phù hợp với các loại trà có lá to và mùi thơm ngát (Hồng trà, Phổ Nhĩ)
LÀM THẾ NÀO ĐỂ “KHAI ẤM” TỬ SA?
Những ấm trà mới thường được phủ một lớp sáp bóng lên bề mặt để bảo vệ lớp đất và làm chúng trông sáng bóng đẹp đẽ hơn (đồng thời cũng để giúp chúng trông như những chiếc ấm trà cổ đắt tiền). Lớp phủ này cần phải được loại bỏ trước khi chúng ta dùng ấm để pha trà. Dưới đây là các bước để loại bỏ lớp sáp phủ và cách “khai ấm”:
1. Chuẩn bị nước nóng để rửa bên trong và bên ngoài ấm. Mục đích để rửa sạch bụi bẩn trong quá trình vận chuyển, trưng bày, cầm nắm…
Lưu ý: Không dùng những loại giấy giáp hay cọ xoong để rửa và các loại hóa chất tẩy rửa để rửa ấm.
2. Cho đầy nước vào một nồi lớn sau đó lót một miếng vải vào bên trong. Nồi phải đủ lớn để ấm trà có thể ngập hoàn toàn bên trong.
3. Bọc nắp ấm bằng một miếng vải riêng và đặt vào nồi cùng với ấm trà. Miếng vải sẽ ngăn không để nắp và ấm va vào nhau làm nứt hay vỡ trong quá trình đun.
4. Đun nước sôi, đậy nắp và đợi trong 30 phút.
5. Sau 30 phút, tắt lửa và để nguội.
6. Lấy nắp và ấm ra khỏi miếng vải rồi rửa lại với nước ấm.
7. Nếu bạn muốn “khai ấm” như một dân chuyên nghiệp, bạn hãy cho nước vào nồi và đun sôi sau đó cho thêm từ 2 – 3 muỗng của loại trà mà bạn dự định sẽ dùng ấm đó để pha. Tắt lửa, đậy kín nắp nồi và ngâm trong vòng 30 phút. Sau đó lọc bỏ sạch sẽ lá trà ra khỏi nồi, tiếp theo đó bạn hãy lặp lại từ bước 2 đến bước 6 nhưng sẽ dùng nước trà này để nấu thay vì dùng nước lọc.
8. Ấm trà của bạn đã sẵn sàng để dùng.
Bạn hãy nhớ rằng, luôn phải rót lượng trà còn dư lên toàn bộ ấm vì điều này sẽ giúp chất trà thấm vào ấm, tạo nên hương vị độc đáo cùng màu sắc riêng của ấm. Nếu bạn muốn sử dụng cùng một chiếc ấm để pha loại trà khác, bạn chỉ cần khai lại ấm trà theo những bước trên.

## Con đón mẹ về

Con đón mẹ về nhà cho mẹ nghỉ ngơi
Bao nhiêu năm bươn chải mệt rồi phải không mẹ?
Ôm mẹ trong lòng tay hệt như mẹ bế con ngày bé
Con nhẹ nhàng đi như mới chập chững buổi đầu
Đón mẹ về với hàng xóm quê hương cho bớt đớn đau
Qua hết rồi những đêm trằn trọc không ngủ
Kết thúc hết rồi còn đâu nữa chứ
Mẹ của con… thanh thản về trời
Ngày tiễn mẹ đi không ngờ có hôm nay mẹ ơi
Trời vào thu mà lòng con băng giá
Chẳng kịp nói với mẹ: con yêu mẹ hơn tất cả
Chẳng đủ diễm phúc nằm ôm che chở buổi cuối đời
Tưởng chỉ là một cuộc dạo chơi
Vậy mà đáng thương chưa, con thành thằng mất mẹ
Tưởng hai tiếng mồ côi giản đơn mà người đời bày vẽ
Ai ngờ xót ruột xót gan quằn quại tận cùng
Đón mẹ về gắng gượng giấu hàng lệ rưng rưng
Không dám khóc sợ làm ồn mẹ ngủ
Quần áo mẹ còn thơm mùi hương cũ
Con biết đốt bao nhiêu nhang để bớt thương nhớ trong lòng
Đón mẹ về rồi… mẹ có vui không?
Bữa cơm hôm nay con làm mấy món mẹ thèm
Lần đầu vào bếp vụng về mẹ đừng có khen
Thằng mồ côi nào cũng vụng về mẹ ạ!
Cây khế trước sân nhà mình vừa đánh mất vài chiếc lá
Con cũng đánh mất báu vật quý giá đời mình!
(Sưu tầm)

## Thế giới này có rất nhiều người thông minh, nhưng lại có quá ít người có thể kiên trì đến cuối cùng

Cây tre mất 4 năm chỉ tăng thêm 3 cm. Nhưng từ năm thứ năm trở đi, nó sẽ phát triển mạnh mẽ với tốc độ 30 cm mỗi ngày và chỉ mất sáu tuần để phát triển lên 15 mét.
Đừng nghĩ 4 năm đầu tiên là vô ích, bởi thời gian đó rễ tre kéo dài hàng trăm mét vuông trong đất.
Làm người làm việc cũng tương tự như vậy.
Đừng lo lắng những nỗ lực của bạn tại thời điểm này không được đền đáp, bởi vì những thứ bạn bỏ ra đang là nền tảng vững chắc cho bạn sau này, như rễ tre vậy đó.
Đời người phải có tích lũy, có bao nhiêu người đã không thể kiên trì như tre chờ đến ngày có thể vượt qua 3 cm..?
Hai cây tre giống nhau, một cây dùng làm sáo, một cây dùng làm giá phơi đồ.
Một hôm, cây dùng làm giá phơi đồ mới hỏi cây dùng làm sáo: "Tại sao chúng ta sinh ra cùng một nơi, đều là tre trên núi. Nhưng tôi mỗi ngày đều phải dãi nắng dầm mưa,còn bạn lại rất đáng tiền?".
Sáo trả lời: "Bởi vì bạn chỉ chịu một nhát dao khi bị chặt ra,còn tôi đã trải qua hàng ngàn nhát dao,được người ta chế tạo cẩn thận.".
Giá phơi quần áo im lặng.
Đời người cũng như vậy,nếu có thể chịu được cực khổ,cô đơn,cọ xát vào thực tế, dám đảm đương và đứng lên chịu trách nhiệm cho cuộc đời mình,cuộc sống mới có giá trị.
Khi nhìn thấy vinh quang của người khác, bạn không cần phải ghen tức,bởi vì người khác trả giá nhiều hơn bạn.
Thật ra trên thế giới này có rất nhiều người thông minh,nhưng lại có quá ít người có thể kiên trì đến cuối cùng,thế nên số người chiến thắng chỉ là số ít.
Người càng thông minh, họ càng hiểu rõ khuyết điểm của mình và luôn cố gắng đến cùng.
Trưởng thành không phải là trải qua thất bại một lần, mà phải tích lũy nhiều lần,cả về trí tuệ lẫn kinh nghiệm sống.
THÀNH CÔNG CHỈ LÀ THỜI GIAN KHI BẠN HÀNH ĐỘNG, CỐ LÊN BẠN NHÉ.!!
(Sưu tầm)

## Tại sao khó có được hạnh phúc?

Là vì hạnh phúc của chúng ta đang đặt lên vai người khác, nhưng người khác không phải gánh trách nhiệm làm cho bạn hạnh phúc!
Mỗi người đều còn cuộc đời của họ, họ cũng có nhiệm vụ làm cho chính họ hạnh phúc. Là vợ, các chị thường định nghĩa hạnh phúc là chồng quan tâm đến mình, yêu mình, con cái hiếu thuận với mình, chiều mình, rộng hơn nữa thì là giàu có… Thế là khi không có được đức ông chồng toàn tâm toàn ý thì đau khổ, khi con học dốt chút cũng đau khổ… 
Nhiều khi các ông bà già rồi cũng không bao giờ hạnh phúc nổi là vì thấy con mình còn khó khăn, hoặc đứa nọ, đứa kia hư hỏng, cờ bạc, rượu chè, nghiện ngập. Vậy có phải là ta không hạnh phúc được là vì cứ mong muốn người khác đem đến hạnh phúc cho mình?
Lại nói về cảm giác hạnh phúc. Tôi có thể tin rằng một đứa trẻ cứ muốn gì là được đáp ứng, nó sẽ rất khó đạt được cảm giác này. Đầu tiên là nó đòi một cái xe đạp, bố mẹ cố gắng mua cho cái xe đạp rồi, thì đòi cái xe máy, có được cái xe máy cũng không hạnh phúc, cần phải có ô tô. Bố mẹ nó mong rằng nó sẽ hạnh phúc, vì hạnh phúc của con là hạnh phúc của bố mẹ. 
Như bác tôi nói thì hạnh phúc phải là thứ gì đó cao cả, phải làm cho tất cả những người xung quanh mình hạnh phúc, thì mới là hạnh phúc. Tôi thừa nhận hạnh phúc là thứ cao cả, nhưng vế thứ hai thì tôi không đồng ý. Bởi một người nếu không trải qua sự nỗ lực, để thành công thì chẳng bao giờ hạnh phúc cả. Nếu một người cứ luôn đòi hỏi người khác phải đáp ứng cái mà mình muốn, mình càng đáp ứng họ càng không thoả mãn, mà đã không thoả mãn thì cũng không hạnh phúc được. Ví dụ như người vợ, cứ muốn chồng phải thơm má mỗi sáng trước khi đi làm. Chồng làm rồi nhưng một hôm quên thế là người vợ cho rằng chồng không yêu mình nữa, sinh ra đau khổ. Lý do là vì hạnh phúc của người vợ phải do người chồng mang lại, khi người chồng không mang lại thì người vợ cứ đau khổ mãi. Rồi những người quan điểm là tôi bất hạnh là vì khó khăn chẳng có ai giúp tôi cả, thì cũng không thể hạnh phúc nổi, mỗi người đều có trách nhiệm với cuộc đời của chính mình. Họ thoả mãn với cuộc đời họ, đã là tốt lắm rồi, họ giúp mình được thì mình biết ơn, nhưng không giúp mình được thì mình vẫn phải hạnh phúc với cuộc đời của mình chứ, cớ gì lại phải là người này cho mình cái này, giúp mình cái kia mới hạnh phúc được. 
Bác tôi nói, ông bà tôi rất hạnh phúc, cái hạnh phúc hiển hiện lên nét mặt. Tôi không cho là như vậy, ông nội tôi thanh thản, là vì cả đời đã sống thanh liêm, còn hạnh phúc, mãn nguyện thì không hẳn, là vì đến lúc mất đi rồi, vẫn cứ phải đau đáu lo cho con cháu. Là vì con cháu không tự làm mình hạnh phúc được, nên ông bà cũng không hạnh phúc. Tôi viết bài này, dài dòng văn tự đến thế, không phải là vì cố gắng để chứng minh điều gì, càng không cầu mong thay đổi tư duy của ai. Tôi vẫn nói có hai thứ dở hơi nhất mà cả đời người ta cứ mất thời gian để làm, đó là: Cố gắng thay đổi người khác và cố gắng để người khác hiểu mình. Bao giờ cũng thế, chỉ có trải qua đau khổ, mất mát người ta mới chịu ngồi xuống và lắng nghe. Chỉ có trải qua tuyệt vọng, họ mới bắt đầu tĩnh tâm mà quan sát cuộc đời và bắt đầu nhận ra những sai lầm của chính mình. Vì sự trưởng thành, vì quá trình hoàn thiện bản thân luôn là một quá trình vĩ đại, người ta phải vật lộn với những tư tưởng trước nay người ta cho là đúng, người ta phải mở não ra để đón nhận cái mới, người ta phải dám thừa nhận mình sai để chịu thay đổi đi, đau đớn lắm, nhục nhã lắm, nhưng bước qua nó mới biết thế nào là cuộc đời đẹp như một đoá hoa. Còn không mãi mãi là sự bất mãn, mãi mãi là cảm giác “mình giỏi thế này mà vì sao may mắn cứ bỏ xa mình?”. 
Chính vì thế tôi thường hay có xu hướng cảm ơn đau khổ, cảm ơn những người đã quay lưng lại với mình, cảm ơn những người đối xử tệ bạc với mình, cảm ơn những lời cay đắng đã giúp mình mạnh mẽ hơn, để đạt được thành quả của sự nỗ lực. Ngày nhỏ, tôi vẫn thường ước gì bố mẹ tôi chỉ là bố mẹ nuôi thôi, còn bố mẹ đẻ là một ông bà tỷ phú nào đó, siêu giàu, một ngày đến rước tôi đi, đặt tôi vào một căn biệt thự, cho tôi đi siêu xe và hàng hiệu. Chỉ đến khi trưởng thành, tôi mới biết cảm ơn là bố mẹ đã không bao bọc tôi, đã đưa tôi vào đời từ rất sớm, cảm ơn vì gia đình mình không giàu có, để mình không được quyền ỉ lại. Bao giờ tôi cũng phải tạo cho mình một sức ép, nếu không nỗ lực hơn, không cố gắng hơn thì người ta sẽ lại xem thường mình mất. Cứ thế, từng bước, từng bước một tôi chạm đến gần hơn những mục tiêu của chính mình. Thứ hạnh phúc được hít thở khí trời mỗi sáng, cảm ơn tạo hoá đã cho mình sự sống, thứ hạnh phúc bình dị được uống trà, được đàm đạo, tán gẫu với bạn bè, được ngủ lâu hơn nếu như mình mệt, thứ hạnh phúc biết trân trọng từng giờ một trên đời, thứ hạnh phúc mà rất nhiều người cho là tầm thường, lại là thứ hạnh phúc mà cả đời người tìm kiếm. Nó ở ngay bên cạnh, ngay bên trong, nhưng để cảm nhận được nó, phải là những người đã trải qua đủ đau đớn, đã biết rộng mở trái tim mình, đã chịu thay đổi tư duy, đã thôi đòi hỏi, thôi trách móc…
Đúng thế, phần quà ấy, chỉ dành cho người xứng đáng!
Jaya Việt Nam - Hành trình tìm kiếm vẻ đẹp của những điều không hoàn mỹ

## Món nợ cuộc đời (truyện ngắn)

Tôi và Toàn là đôi bạn thân từ thời còn đi học.
Lớn lên mỗi đứa một nghề nhưng vẫn chơi bời qua lại thân thiết.
Tôi làm thợ may và kinh doanh quần áo. Nó làm công an ở trại giam nên cuộc sống cũng có đồng ra đồng vào. Có tiền đâm ra rửng mỡ chơi bời quá đà rồi cờ bạc và nghiện hút.
Rồi nó bị đuổi về còn mắc thêm cả nợ nần. Gia đình rơi vào cảnh rất là túng bấn. Thi thoảng nó vẫn đến vay tiền tôi tới bốn năm lần gì đó nhưng ko bao giờ trả được.
Vợ tôi biết chuyện cằn nhằn mãi, phần vì thương nó, phần vì nể tình bạn mà tôi vẫn cho vay.
Về sau vừa có ý nghe vợ vừa sợ phiền hà nên tôi cũng có phần lảng tránh nó.
Từ đó Toàn ít đến nhà tôi và cũng không bao giờ hỏi vay tiền tôi nữa.
Tình bạn cũng vì thế mà phai nhạt dần. Mỗi lúc gặp nhau chỉ chào hỏi lấy lệ không ân cần thân thiết như trước.
Một thời gian sau nó cũng cố gắng cai được nghiện và thoát ra khỏi cờ bạc.
Hàng ngày nó đi làm phụ hồ, công việc vất vả nhưng thu nhập chả được là bao nhiêu. Vợ con suốt ngày đau yếu nên cuộc sống nhà nó vẫn rất khó khăn.
Có lúc tôi muốn qua lại nhà nó nhưng cảm thấy ngượng vì dạo trước đã xa lánh nó. Hình như như vì không trả được tiền cho tôi nên Toàn thường tránh mặt không muốn gặp.
Mấy năm sau Toàn đưa vợ con vào Nam sinh sống. Từ đó chúng tôi không có dịp gặp nhau nữa nhưng thông qua bạn bè vẫn nằm được tình hình về nó. Đại loại cuộc sống của gia đình nó vẫn vất vả ko có gì đáng cải thiện, ở nơi đất khách quê người.
Bẵng đi một dạo nghe tin nó ốm, tôi cũng gọi điện hỏi thăm. Thực lòng tôi vẫn có chút lo lắng về nó.
Trong lòng cũng có chút dự đinh vào nam thăm nó. Ngặt một nỗi đường xá quá xa xôi kinh tế tôi lại ko có gì là dư dật.
Nấn ná mãi, bỗng một hôm tôi nhận được một cuộc điện thoại từ vợ Toàn. Vợ Toàn khóc nói :
- Nhà em bị ung thư phổi đã di căn chắc ko qua khỏi. Mấy ngày nay không ăn uống được gì. Bảo gì anh ấy cũng lắc đầu. Chỉ muốn gặp anh một lần cuối.
Nghe xong tôi choáng váng lặng người đi một lúc. Cả đêm xi xục ko ngủ. Sáng hôm sau dậy sớm bắt xe đi Hà Nội, đến ga hàng cỏ mua vé tàu Thống Nhất.
Thời đó còn nghèo đi máy bay còn là chuyện trên trời theo đúng cả nghĩa đen lẫn nghĩa bóng. Phương tiện tốt nhất chỉ có tàu hỏa.
Sau ba ngày, Tôi mới lặn lội tới nơi. Gia đình Toàn ở trong một nhà trọ chật chội ở ngoại ô Sài Gòn.
Sự có mặt của tôi hình như đã muộn. Toàn nằm đó, thân hình gầy gò teo tóp. Đầu trọc lốc không sợi tóc do truyền hoá chất. Chân đã nguội lạnh tới đầu gối, miệng không còn nói được nữa. Mắt nó nhìn tôi trân trân như muốn nói điều gì đó mà không nói được. Hai hàng lệ chảy dài xuống gò má.
Có lẽ tôi là người nó mong đợi gặp lần cuối trước khi từ giã cõi đời nên cố nán lại.
Toàn tắt thở ngay sau khi tôi đến được năm phút. Nhìn hình ảnh tiều tụy của đứa bạn, tôi ko sao cầm được nước mắt.
Mái nhà trên đầu tôi như sập xuống, đất dưới chân như nứt toác ra.
- Toàn ơi sao mày chết trong đau khổ thế này!
Đám ma của bạn tôi diễn ra nhanh chóng đơn giản. Nơi đất khách quê người không có nhiều bạn bè tới phúng viếng. Một nấm mồ bằng đất đắp lên là nơi đánh dấu nơi bạn tôi yên nghỉ, trong một nghĩa trang lạnh lẽo hoang vắng.
Dù mất mát đau thương đến đâu con người ta cũng ko thể đắm chìm trong đó, vẫn phải trở về với thực tại.
Hai ngày sau đám tang, tôi phải lên đường trở ra bắc.
Trước khi chia tay vợ Toàn đưa cho tôi một chiếc hộp. Cô ấy nói :
" Đây là tất cả những gì nhà em muốn nói với anh. Anh đừng mở nó ra ở đây về tới nhà hãy mở. Đó chính là di nguyện cuối cùng của anh ấy."
Tôi nhận món đồ rồi lên đường trở ra bắc. Sau mấy ngày tang lễ mất ngủ và đi đường mệt nhọc, về tới nhà Tôi lăn ra ngủ.
Hai ngày sau sực nhớ tới cái hộp. Tôi bồi hồi xúc động run run mở nó ra. Dẫu sao nó cũng là điều cuối cùng Toàn muốn nói với tôi.
Bên trong hộp là một phong bì gói giấy vuông vức. Tôi bóc ra đó là một số tiền Tôi đếm được tất cả là 7 600.000đ đúng bằng số tiền mà toàn đã vay tôi. Kèm theo một cuốn sổ tay nhỏ gi chép đầy đủ từng lần có cả ngày tháng mà toàn đã vay tiền tôi.
Dưới đáy hộp còn có một bức thư do chính tay Toàn viết.
Bức thư viết như sau :
_Hùng ơi! Tao biết khi mày đọc được những dòng này thì tao không còn ở trên cõi đời này nữa. Căn bệnh ung thư quái ác đã hành hạ tao rất đau đớn. Tao biết ngày phải xa bạn bè và vợ con đang đến rất gần._
_Tao rất ân hận vì đã không làm được người tốt. Làm khổ vợ con và bạn bè._
_Tao cũng rất có lỗi và xấu hổ với mày, đã vay mượn làm phiền mày rất nhiều mà không trả được. Tao biết mày rất tốt với tao nhưng còn vợ con và gia đình. Những đồng tiền ấy mày cũng phải lao động khó nhọc mới có được._
_Tao ko muốn gặp mày không phải là giận mày đâu mà là tao xấu hổ ko đủ can đảm để đối diện với mày._
_Tao đã cố hết sức làm lụng và tiết kiệm để dành được món tiền này._
_Trả được cho mày tao mới có thể yên nghỉ được. Những lần vay tiền mày đều là vợ con ốm. Tao có xấu xa mấy cũng không bao giờ dùng đồng tiền của mày để hút chích cờ bạc._
_Giờ đây tao rất hối hận nhưng đã muộn. Việc dùng nhiều ma túy đã khiến tao bị ung thư ko còn cứu chữa được nữa._
_Kiếp này tao mãi mãi là người bạn tốt của mày, nếu có kiếp sau mình cũng vẫn là bạn nhé. Mày nhớ tìm tao ở kiếp sau, thằng bạn có cái sẹo ở mông. Cái sẹo tao ngã xuống từ cây bưởi nhà ông Bình mà buổi trưa tao với mày đi ăn trộm bưởi đó, còn nhớ ko thằng bạn bùn tốt bụng... Vĩnh biệt mày nhé...!_
Tôi đọc tới đó mắt nhòa đi không nén được xúc động. Tôi bật khóc rất to như một đứa trẻ. Những người xung quanh đều ko hiểu tại sao tôi khóc. Cũng ko ai hiểu được tình cảm bạn bè giữa tôi và nó sâu nặng tới mức nào.
Tôi lại cảm thấy căm hận chính bản thân mình. Có lúc vì sự ích kỷ của bản thân vì đồng tiền mà mình trở nên dơ bẩn. Đồng tiền ko có tội nhưng vì mày mà tao đã mất đi một người bạn tốt.
Toàn ơi món tiền mày nợ, đã trả được cho tao. Mày yên nghỉ!
Nhưng món nợ tình bạn mày dành cho tao. Mãi mãi ko bao giờ tao trả hết được cho mày!

## Năm điều làm cho bạn bị kẹt và đau khổ

**Điều 1: theo đuổi những niềm tin và thói quen cũ không còn thích hợp cho ngày nay.**
Nhớ có lần tôi sang Mĩ và ghé thăm một người hàng xóm bên Việt Nam lúc đó là chủ một tiệm vàng ở Los Angeles. Gặp chú tôi mừng quá và nhắc lại chuyện xưa ở dưới quê, rồi hỏi chú có nhớ thằng Th ở xóm chợ không, nó đang ở Úc và mới tốt nghiệp đại học. Tưởng rằng chú ấy mừng biết một người đồng hương thành đạt, ai ngờ chú nói "Ủa, thằng Th hả? Nhớ chớ sao không? Chà, hồi đó nó chăn trâu mà giờ khá quá!" Thú thực là lúc đó tôi thấy như nghẹn lời, vì tôi thấy hình như chú vẫn tỏ ra khinh thường thằng chăn trâu, hay là chú nghĩ một thằng chăn trâu thì nó không có quyền học hành giỏi, không được thành đạt như chú. Tôi nghĩ chú vẫn sống trong quá khứ, và biết đâu cái quá khứ đó giữ chân chú không đi xa được.
Trong khoa học cũng vậy: có ý tưởng mới là rất quan trọng, vì nó giúp cho mình vượt lên chính mình. Thế nhưng trong thực tế nhiều người thích thu mình trong cái thế giới cũ, ý tưởng cũ, làm theo cách làm cũ, và dĩ nhiên là họ không đi xa được. Chỉ cần đọc qua tựa đề những luận án tiến sĩ, những đề tài nghiên cứu ở VN thì thấy ngay rằng nhiều người vẫn sống trong 'truyền thống'. Giới khoa học hay có câu "Nếu bạn hỏi câu hỏi cũ thì câu trả lời sẽ không bao giờ mới". Đó chính là lí do tại sao sau khi tốt nghiệp tiến sĩ, người ta khuyến khích bạn nên đi làm nghiên cứu hậu tiến sĩ ở một nơi khác, chớ không ở lại (vì sẽ gây ra tình trạng academic inbreeding).
**Điều 2: không chịu sống trong hiện tại mà sống trong quá khứ và tương lai.**
Quả thật trong cuộc sống có những người thích giữ khư khư niềm tin và lề lối cũ như chú hàng xóm tôi. Tôi sợ là con số này rất nhiều ở Việt Nam, nhứt là vùng quê. Họ nhân danh duy trì truyền thống để sống theo nề nếp cũ; họ nghĩ như ông bà mình từng số cả trăm năm trước, nên họ khó thích ứng trong thế giới mới.
Nhớ lần về quê và ghé qua thăm đứa em họ, nghe nó phàn nàn về chị dâu nó. Số là cô dâu (là cô giáo) hay thức dậy trễ hơn bà mẹ chồng, nên cô em họ tôi ... bực mình. Thật ra, thức sớm theo thói quen như bà mẹ chồng, tức là dì tôi, thì chính tôi cũng không làm được. Nhưng cô em tôi kì vọng rằng đã là dâu thì phải thức khuya dậy sớm. Tôi nói với cô em họ tôi rằng "em tự làm khổ em, mai mốt em làm dâu thì biết thôi", bề ngoài thì nó cười cười nhưng tôi nghĩ nó không thuyết phục với câu nói của tôi vì nó rất thích câu nói "ông bà mình hồi nào đến giờ vẫn vậy", và trong cái nhìn của nó hành vi của người chị dâu là một đe doạ đến truyền thống.
**Điều 3: ganh tị, so đo, chỉ trích cá nhân**
Không ít người Việt có thói tò mò, so đo, hay nói chung là ganh tị. Người Úc cũng có câu "sân cỏ nhà hàng xóm xanh hơn sân cỏ nhà mình" để chỉ thói xấu so đo này. Một nhà bình luận văn hoá nhận định rằng thói đố kị của người Việt là do tính tò mò và so đo: “Đặc điểm nổi bật của tính cách này là không muốn ai hơn mình, nên tìm mọi cách cào bằng tất cả, và ghét bỏ những người xuất sắc”. [1].
Quả thật, trong xã hội có những người rất bận tâm với ... người khác. Những người này có xu hướng không thích ai, thấy ai làm được cái gì họ hay mỉa mai, thậm chí tức tối. Tôi biết ngay cả trong giới khoa bảng, có người thấy đồng nghiệp công bố được một công trình trên tập san 'đình đám', họ liền tìm cách hạ thấp đồng nghiệp qua những bình luận vu vơ và phán đoán loại 'summary'. Những câu phán xét kiểu "Thằng đó dốt, biết làm gì", "Chắc là sai rồi", "Chắc ai đó giúp nó làm, chớ nó thì làm được gì", v.v. Đây là những người ganh đua thay vì tranh đua.
Người ganh đua thường sống trong đau khổ và họ không tiến xa được. Họ đau khổ vì phải dồn năng lượng, tâm trí và thời gian để chỉ trích người khác, nên thiếu năng lượng cho chính mình. Đối với người ganh tị, họ cảm thấy đau khổ trước sự thành công của người khác. Còn người tranh đua thì sẽ tiến xa hơn, vì họ sẽ dồn năng lượng để làm tốt hơn đồng nghiệp mình. Nhìn như vậy sẽ thấy xã hội phát triển là nhờ có những người tranh đua.
**Điểu 4: sống vì sự kì vọng của người khác mà không là chính mình.**
Mỗi con người trên hành tinh này là một cá nhân đặc thù (unique). Không ai giống mình, và mình cũng chẳng giống ai. Tôi là người Úc gốc Việt, tóc đen, da vàng, xuất thân từ một gia đình làm nghề nông. Bạn cũng có thể là một người Úc gốc Việt như tôi, nhưng bạn xuất thân từ một danh gia vọng tộc. Mỗi chúng ta có một lịch sử đặc thù, và tôi không thể là bạn cũng như bạn không thể nào giống tôi. Thành ra, Phật lúc nào cũng khuyên là "Be Yourself" (hãy là chính mình).
Nhưng khổ nỗi có những người không chịu là chính mình. Đây là những người sống theo ý của người khác. Họ rất bận tâm nghe ngóng những phê phán của người khác, và cố gắng chỉnh sửa mình để không bị phê phán. Họ sống theo kì vọng của người khác. Họ hay so sánh với người khác, và bằng mọi giá làm giống họ. Hậu quả sau cùng là họ không còn là họ, đánh mất đi "cái tôi" đặc thù. Những người này đau khổ suốt đời. Đúng như Richard Feynman nói: Nguyên nhân phổ biến nhứt cho hội chứng căng thẳng là phải đương đầu với những kẻ ngốc nghếch (The most common cause of stress nowadays is dealing with idiots.) Hãy sống theo lời khuyên của ông:
"Tôi không có trách nhiệm để sống đúng theo những gì người ta kì vọng tôi. Đó là sai lầm của họ, chớ không phải thất bại của tôi".
**Điều 5: bám lấy cái cũ mà không chịu thay đổi.**
Mấy tuần trước ở nơi tôi làm việc có một sự thay đổi về người lãnh đạo (chỉ là chức vụ tình nguyện) và gây ra những bàn tán xôn xao. Người thì tỏ thái độ không nể phục và biện minh bằng những chức vụ khoa bảng thấp trong quá khứ; người thì cho rằng với thành tích công bố khoa học như vậy thì làm sao làm gương cho người khác, v.v. Nói chung là ý kiến rất đa dạng nhưng không phục. Nhưng tôi nghĩ họ (những người bình phẩm) đang làm khổ mình, vì họ không chấp nhận đổi thay, vốn là qui luật của cuộc sống. Người lãnh đạo mới có thể không có thành tích lừng lẫy như thành viên trong nhóm, nhưng đó là quá khứ, còn hiện nay thì người đó là kẻ đứng đầu và mình phải chấp nhận thực tại.
Một nhà hiền triết đã nói rằng trong cõi đời này có một điều không bao giờ thay đổi, và đó chính là sự đổi thay (the only thing that does not change is change itself), mà triết lí Phật gọi là "Vô Thường". Hay nói như Hermann Hesse (tôi thích nhà văn này) là không ai bước vào một dòng sông 2 lần, bởi vì dòng sông lúc nào cũng chảy. Cuộc sống cũng như một dòng sông, và chúng ta không thể nào kì vọng sự vật bất biến, vì sự vật luôn đổi thay.
Chúng ta không kì vọng rằng đồng nghiệp mình đứng yên một chỗ, và cũng đừng ngạc nhiên khi thấy đồng nghiệp thành đạt hơn mình vì họ biết thích ứng với Vô Thường. Có những người Việt hay nói kiểu "Thằng đó hồi xưa không đáng xách dép cho tao", thế nhưng họ không nhìn lại chính mình là đang đứng một chỗ còn "thằng đó" thì đã bước ra khỏi cái vị trí xách dép từ lâu rồi.
Tương tự, cái suy nghĩ kiểu "Hòn ngọc Viễn Đông" hay "Thủ đô Văn Hiến" là -xưa rồi, đã qua lâu rồi, sẽ không bao giờ kéo lại được. Hay có người mơ mộng rằng năm 2045 cái 'hòn ngọc' đó sẽ toả sáng và sẽ là trung tâm thế giới. Đây là kiểu sống trong tương lai và quá khứ. Cái khổ là quá khứ thì đã qua rồi và tương lai thì chưa tới. Cái chúng ta đang có là hiện tại. Tôi lại nhớ đến câu nói của Richard Feynman: Bạn không có nghĩa vụ làm người của năm qua, tháng trước, hay thậm chí một ngày vừa qua. Bạn ở đây để tạo ra chính bạn một cách liên tục [2].
Tóm lại, 5 điều làm cho chúng ta đau khổ hay 'mắc kẹt' là (i) giữ lấy lề lối cũ; (ii) sống trong quá khứ; (iii) thói tọc mạch; (iv) không là chính mình; và (v) không chịu chấp nhận qui luật đổi thay của cuộc sống. Tất cả 5 điều này có thể tóm lược bằng 1 chữ: Vô Thường. Điều này có nghĩa là để sống thoải mái và hạnh phúc, chúng ta phải chấp nhận Vô Thường. Mà, định luật Vô Thường thì chịu sự chi phối của luật Nhân Quả.
Thành ra, sống theo qui luật Vô Thường có nghĩa là sống một cách tích cực (positive well being). Sống tích cực là làm điều thiện lành để tạo ra những thành quả ngọt ngào, hay nói ngắn gọn theo ông bà mình là "tu thân tích đức". Câu này rất dễ hiểu như vậy mà đa số chúng ta, nhứt là người trẻ, không để ý và hay vi phạm để đến khi luống tuổi thì mới nhận ra.
Sống tích cực có thể ... định lượng. Cách đây vài năm có một cuốn sách rất hay có tựa đề là "Born to be Good" chỉ cách sống hạnh phúc. Trong sách có khái niệm Tỉ số Jen (Jen Ratio, mà tôi hỏi tác giả có phải là Zen Ratio thì ông nói có thể). Tử số của tỉ số Jen là hành động tốt (như giúp người) hay nói chung là việc thiện. Mẫu số của tỉ số Jen những hành động chúng ta làm cho người khác đau khổ (có thể không cố ý), hay nói chung là gây tác hại. Tác giả khuyên là làm sao mỗi ngày tỉ số Jen của chúng ta trên 10 (tức hành vi tốt cao gấp 10 lần hành vị gây hại) là sẽ có cuộc sống viên mãn. Vậy từ hôm nay các bạn thử định lượng tỉ số Jen hàng ngày xem sao.
____
[1] [https://vietnamnet.vn/.../thoi-quen-toc-mach-chu-yeu-co-o...](https://vietnamnet.vn/vn/doi-song/thoi-quen-toc-mach-chu-yeu-co-o-nguoi-mien-bac-87482.html?fbclid=IwAR0DWgJ5C4jBpeOIpkhxuT-kLPBgpmFKRYKOP5hJK6G4uHJEH2d4Yeangts)
[2] “You are under no obligation to remain the same person you were a year ago, a month ago, or even a day ago. You are here to create yourself, continuously.”
[**Tác giả: GS. Nguyễn Văn Tuấn**](https://vnexpress.net/tac-gia/nguyen-van-tuan-1306.html)

## Tôi quyết định bỏ chồng (truyện ngắn)

Những ngày này, tôi đang bất mãn về cuộc hôn nhân của mình, người chồng sáng sáng ra khỏi nhà từ lúc tôi chưa ngủ dậy, tối khuya mới trở về, nhưng thu nhập chẳng khá khẩm gì, tình cảm thì cứ nhạt dần, không còn khái niệm tặng quà, cũng chẳng còn niềm vui mỗi khi chồng đi làm về…
Khi nghe nỗi niềm tâm sự của tôi, mấy cô bạn gái thân nghiêm túc phân tích vấn về rồi kết luận: “Sống với nhau nhạt nhẽo như vậy thì nên giải thoát sớm đi”.
Chia tay hội chị em, trên đường về nhà, tôi bắt đầu suy nghĩ về việc ly hôn.
Bước vào nhà, nhìn căn phòng đơn giản mấy năm rồi không có gì thay đổi, tôi bỗng cảm thấy chán chường khó tả. Đón con về, nó đánh đổ cả sữa xuống sàn nhà, rồi nó bày bừa đồ chơi khắp nơi khiến căn nhà đã chật chội càng thêm bừa bộn. Tôi chỉ lo thu dọn cái bãi chiến trường ấy cũng đủ mệt bở hơi tai.
Đang vội vàng nấu cơm thì chuông điện thoại réo rắt, chồng báo tối nay về muộn, cả tuần nay anh ấy không về nhà ăn tối lấy một bữa. Tôi bực mình, thò tay nắm hai quai nồi định bắc xuống bếp thì bị rớt, tay tôi bị bỏng rộp cả lên. Miếng nhựa chống bỏng ở quai nồi đã rụng ra từ lâu, tôi đã nói với chồng năm lần bảy lượt, nhưng mãi vẫn chưa sửa.
Tôi tắt bếp, bước vào phòng, soi vào gương, đôi mắt trong trẻo ngày nào nay bỗng trở nên mờ nhạt và lấm tấm nếp nhăn. Cuộc sống gia đình thật đáng sợ, đã bao lâu rồi tôi không chăm sóc cho bản thân mình, mọi thứ chỉ xoay quanh căn hộ bé xíu và cậu con 3 tuổi. Tôi cần phải thoát khỏi cuộc sống vô nghĩa này, nhanh chóng rời xa khỏi đây.
Hai tiếng sau chồng tôi về, không thấy có cơm trên bàn, chỉ thấy tôi ngồi một mình trong bóng tối.
– Sao chưa nấu cơm?
– Sao phải nấu cơm? Tôi nấu đủ rồi, từ nay trở đi sẽ không nấu nữa. Sống thế này tôi không chịu được. Chúng ta ly hôn thôi.
– Anh nghe nhầm phải không? Em nói lại xem nào!
Lúc này con trai tôi bỗng cất tiếng khóc, anh ta chạy vội vào trong phòng bế con và cho nó uống sữa, ngạc nhiên hỏi dồn: “Sao đang sống tử tế lại đòi ly hôn?”. Tôi cười khẩy.
Tối đó, tôi cố ý ngủ riêng. Theo kinh nghiệm của các cô bạn, ly hôn không đơn giản, nhiều thứ ràng buộc như tình cảm, tài sản, thói quen, vì thế nhất định phải có nghị lực mới làm được. Để có thể tiến hành thuận lợi, tôi cần thực hiện 3 điều:
Thứ nhất không nấu cơm nữa, tách sinh hoạt của hai người ra.
Thứ hai không ngủ chung, không cho cơ hội làm lành.
Thứ ba, kinh tế riêng rẽ.
Nằm trên ghế sofa mãi mà không sao ngủ được, tôi bật dậy viết đơn ly hôn. Tôi người Bắc, chồng người Nam, cùng nhau đến thành phố biển này, mua được căn nhà đứng tên tôi. Chồng tôi có một cửa hàng làm ăn có vẻ không khá lắm, nhưng dù sao đó cũng là tài sản của anh ta. Như vậy chia ra tôi sở hữu căn nhà, anh ấy lấy cửa hàng cũng là hợp lẽ. Con trai tôi nuôi, anh ta gửi tiền trợ cấp hàng tháng là ổn.
Hôm sau, khi đưa cho anh ta tờ đơn ly hôn:
– Tôi muốn tự do!
Anh ta ngây người ra, tôi sốt ruột giục:
– Anh ký đi! – nói xong tôi liền cảm thấy mình có phần hơi quá đáng, liền đổi giọng – Lẽ nào anh không thấy chúng ta là người của hai thế giới? Chia tay tốt cho cả anh lẫn tôi…
Một tuần sau, anh gọi điện cho tôi và nói:
– Anh ký rồi, chiều nay cùng ăn với nhau một bữa nhé. Vẫn chỗ cũ, anh sẽ đưa đơn cho em.
Hết giờ làm việc, tôi đi đến nhà hàng ven biển mà chúng tôi thường đến. Mấy hôm không gặp, trông anh gầy đi, ánh mắt ưu tư, râu đã được cạo nom sáng sủa hơn. Anh lặng lẽ đẩy cái phong bì đến trước mặt tôi, bỗng tôi thấy cay cay mắt, trong lòng có một cảm giác hoang mang khó tả.
– Đã đến rồi thì gọi chút gì ăn nhé, có thể đây sẽ bữa cơm cuối cùng của chúng ta.
Anh quay ra gọi người phục vụ:
– Cho một suất cơm thịt bò xào ớt, một bát canh ngao.
Đây đều là những món tôi thích nhất. Tôi ngồi im, anh bỗng nói với tôi:
– Bữa cơm cuối cùng này em có thể gọi cho anh món anh thích ăn không?
Tôi bỗng bối rối, tôi chẳng biết anh thích ăn món gì. Trước giờ anh đều rất dễ tính, món nào cũng ăn được, món nào cũng thấy ăn ngon lành.
– Anh thích món gì? Chẳng phải anh luôn ăn giống em hay sao?
Anh lại mỉm cười, nói chậm rãi:
– Thực ra, ngần ấy năm, anh luôn ăn những món mình không thích. Em quên rồi sao, anh là người miền Nam, anh thích chế biến kiểu miền Nam, hơi ngọt chút. Anh cũng thích ăn cay nhưng em không thích nên đành thôi.
Nghe anh nói, mặt tôi nóng bừng. Đúng là tôi chưa từng nghĩ đến việc hỏi anh thích ăn món gì. Lần đầu tiên biết anh thích ăn ngọt lại là lúc ly hôn, thật nực cười. Tôi muốn ứa nước mắt nhưng cố kìm lại.
– Anh quyết định rồi, nhà, cửa hàng, mọi đồ đạc trong nhà đều thuộc về em, anh chỉ mang theo mấy quyển sách và vài bộ quần áo thôi.
– Anh định đi đâu?
Hình như tôi thực sự chưa từng suy nghĩ nghiêm túc rằng chúng tôi sẽ sống như thế nào sau khi ly hôn.
– Bố mẹ và bạn bè anh ở miền Nam luôn giục anh về quê làm ăn. Nhưng do em thích biển nên anh chiều theo em. Ở đây gió biển mang mùi tanh của cá, ăn đồ biển anh cũng không thích, công việc cũng chẳng sáng sủa gì, đã làm em thiệt thòi…
– Anh nói gì thế? Em không phải ly hôn vì những thứ đó.
Tôi không ngăn được nước mắt.
– Ly hôn xong anh sẽ về Nam. Sau này em sống một mình nuôi con sẽ vất vả. Anh để lại tất cả cho em. Cửa hàng dạo này kinh doanh cũng khá hơn trước, em lấy tiền đó tích lại, đừng tiêu linh tinh, để phòng khi cần có cái mà tiêu.
– Vậy anh thì làm thế nào?
– Đàn ông quăng đâu chả sống, không như đàn bà con gái, cả tin lương thiện, dễ bị tổn thương.
Tôi bỗng trào nước mắt.
“Đừng khóc!” – Anh đặt tay lên vai tôi, cử chỉ quen thuộc, vậy mà không hiểu sao lúc sống bên nhau tôi lại không hề nhận thấy tình cảm của anh.
– Anh phải đi rồi. Em biết không, mỗi lần gia đình bên em tụ họp đông vui anh đều cảm thấy trống trải. Anh cũng rất nhớ ba mẹ, họ cũng già cả rồi…
Tôi bỗng thấy mình quá vô tâm. Anh là người đàn ông tốt, vậy mà đến tận giây phút này tôi mới biết sống với tôi, anh đã phải che giấu những cảm xúc không vui, những điều không hợp, chỉ vì tôi.
– Sao anh không nói những điều này sớm hơn?
– Anh muốn em sống vui vẻ, không phải bận lòng vì những việc vặt ấy.
Tôi thẫn thờ, một lúc sau tôi nói:
– Anh… Anh có thể không đi không?
Chúng tôi bước ra khỏi nhà hàng, bên ngoài gió biển rất mát, tôi ngồi sau xe của anh đi về nhà. Tôi ôm chặt lấy anh, cảm thấy thật hạnh phúc.
Sự việc vừa rồi đã cho tôi một bài học. Sau khi kết hôn, những lo toan chuyện cơm áo gạo tiền khiến người ta ngày càng không có thời gian quan tâm tới nhau, nhưng đó thực ra không phải vì họ đã thay lòng đổi dạ, mà bởi cuộc sống cần phải vậy. Nếu mỗi người biết nghĩ cho người kia một chút, bao dung và nhường nhịn lẫn nhau một chút, gia đình sẽ êm ấm, hạnh phúc.
Xã hội ngày nay ly hôn càng ngày càng dễ, chính vì thế, chúng ta càng cần trân trọng, giữ gìn những gì đang có của hôn nhân phải không các bạn?
(Sưu tầm)

## Chồng điên (truyện ngắn)

Đó là đêm mưa bão , chị bị sốt , anh chạy ngược chạy xuôi lo cho chị . Nửa đêm, nhắm tình hình không ổn, mặc trời mưa gió, anh bế chị vào viện. Vừa chạy vừa kêu tên chị mãi , không có tiền , vay mượn mãi chỉ đủ cho chỉ nằm trong một ngày . Sáng hôm sau anh phải đi bán máu để có tiền mua thuốc cho chị. Những ngày chị bệnh , anh phải một tay kiếm tiền , một tay nấu cháo , thuốc thang cho chị. Để có tiền anh phải làm việc nhiều hơn trong tình trạng mệt mỏi vì thức khuya dậy sớm và cũng vì bán máu. Ngày chị lành bệnh , cũng là ngày anh ngục ngã.
Anh bị ngã xe trên đường về vì hoa mắt.............. Tai nạn đó không lấy đi sinh mệnh của anh nhưng lấy đi của chị rất nhiều nước mắt khi anh trở thành một đứa trẻ lên ba. 
Tức là không biết gì cả , thích cười thích khóc, không hiểu mình đang nghĩ gì . Nghe tin anh bệnh như thế , cả nhà chị tìm mọi cách tác động tới chị để chị bỏ anh mà về sống với gia đình . Không nhẫn tâm bỏ anh lại một mình , chị bị gia đình từ bỏ . Không còn cách nào khác , chị đành cùng anh sống trong căn nhà lạnh lẽo. 
Thương anh quá chị đành bán đi miếng đất sinh nhai của hai vợ chồng để lấy tiền chữa trị cho anh . Chạy hết bệnh viện này tới bệnh viện khác , bệnh anh vẫn không khỏi. Không còn cách nào khác , chị đành gửi anh vào bệnh viện tâm thần . Một tuần sau, nước mắt chị lại trào ra khi nhìn thấy anh đứng trước nhà gọi chị . Dù anh đang là đứa trẻ lên ba nhưng anh vẫn nhớ đường về nhà tìm chị. 
Chị rụng rời chân tay ôm anh khóc không thôi..... 
Chị thề với lòng sẽ không đưa anh đi đâu cả...... 
Chị siết lấy anh cứ như sợ anh lại biến mất........ 
Vậy là từ đó, chị đi đâu anh ở đó. Anh ăn rất khỏe dáng người cao to. Nhìn đằng sau cứ như tràn trề sinh lực , nhưng chỉ khi nói chuyện với anh , mọi người mới vỡ lẽ. . Mỗi ngày sáng sáng anh lại gánh giỏ cá ra chợ cho chị bán, xong rồi lại đi lang thang. Đúng 11h anh lại đến gánh về cho chị. Anh hiền lành , thấy ai làm gì nặng cũng nhào vào giúp nên mọi người ở chợ rất thương . Họ vẫn thường cho anh bánh trái , ai khá hơn thì dúi cho chút tiền . Anh đều bỏ vào bọc, dành cho chị tất. 
Mọi người đùa với anh gì anh cũng chỉ cười dạ dạ . Nhưng ai đó không biết lỡ lời gì tới chị là anh sẵn sàng cho người đó một cú đấm . Có lần, anh nổi cơn đánh một người bán sống bán chết chỉ vì người ấy khen chị xinh. Chỉ đến khi chị đến ôm anh anh mới thôi. 
Ở cái chợ này , chả ai dám tranh chỗ bán với chị cả, vì mỗi lần có cãi nhau với chị hay là giành khách , anh cũng đều có mặt , đứng che chị lại, tay lăm lăm thanh gỗ sẵn sàng ăn thua với họ. 
Ai cũng ngán ngại, họ bảo chấp chi thằng điên nên họ bỏ qua điều đó. 
Từ ngày từ mặt chị, ba chị sinh tật uống rượu. Ngày càng nghiện, rồi ông mất. Được tin chị khóc ngất, thấy chị khóc anh cũng ôm chị vào lòng và khóc theo . Khóc song chị dẫn anh ra tiệm vàng bán sợi dây chuyền mà anh tặng khi quen cưới nhau. Thấy chị tháo sợi dây, anh giật lại . Anh biết chị rất thích nó nên không muốn cho chị bán. 
Chị cười 
Bán để cho má làm đám ma ba , sau này anh đi làm mua cho em cái khác lớn hơn , đẹp hơn. Anh mới chịu buông tay cười cười. Từ đó về sau anh chỉ đem cái bánh chai nước về cho chị chứ không thấy đưa chị tiền.
Không biết tại vì không uống thuốc hay lý do gì mà dạo này anh lại có thêm bệnh động kinh . Mỗi lần lên cơn co giật lại sùi bọt mép . Hết cơn anh lại đập phá những ai đứng gần đó nhưng khi chi ôm anh vào lòng anh đều trở lại bình thường. Người ta khuyên chị cho anh vào viện. Bác sĩ bảo anh đã chuyển sang tâm thần nặng. Đưa vào khu cách ly. Chị lừa anh, bảo dẫn anh đi chơi. Đưa vào đó anh cứ khóc, ôm chầm lấy chị mãi chị mới buông anh ra được. Nước mắt chảy dòng , chị phải cố chạy thật nhanh để không nghe tiếng anh gọi. 
Tháng nào chị cũng xuống thăm anh. Chẳng làm gì cả cứ nhìn anh, khóc đã đời rồi về. Anh cũng vậy gặp chị là đòi về. Nhiều lúc chị cũng muốn đưa anh về lắm nhưng không thể.
Rồi một hôm , bệnh viện thông báo là anh mất , trong một lần lên cơn anh đã đập đầu vào tường mà chết. 
Họ bảo trước lúc mất anh luôn miệng gọi tên chị. 
Chị ngất lên ngất xuống. 
Hôm làm thủ tục chôn cất anh. Chị được bệnh viện đưa túi đồ của anh, bên trong toàn là hình của chị. Dưới những bộ đồ có một cái hộp trong đó có một sợi dây chuyền bạc, cùng tờ giấy ghi nguệch ngoạc tên chị. Nước mắt chị chảy ròng. 
Minh Thúy

## Lá thư của Giám đốc Bệnh viện Nguyễn Tri Phương gửi đồng nghiệp

Thầy Minh Niệm & Cộng đồng Thiền tâm lý trị liệu Miền Tỉnh Thức thực hiện 
Dự án vì cộng đồng, hoàn toàn phi lợi nhuận

## Nếu...(st)

"Nếu có thể hãy thả lòng mình nhé
Sống vị tha mạnh mẽ giữa cuộc đời
Bởi vẫn biết cho đi là còn mãi
Tự bằng lòng tâm sẽ được thảnh thơi
Nếu có thể thả hồn nương theo gió
Biết bỏ buông mình sẽ có thật nhiều
Những niềm vui hạnh phúc dù bé nhỏ
Cuộc đời này thanh thản biết bao nhiêu
Nếu có thể giữ cho mình những phút
Khẽ khàng trôi không chút ầm ào
Giữa chợ đời lặng ru bình yên ngủ
Thả muộn phiền theo cánh gió lao xao ..."

## Tô bánh canh

Đầu hẻm 324 Tr. Bình Trọng, có một quán bán bánh canh, nhỏ bé, đơn sơ. Nhưng mỗi buổi sáng, người đến ăn khá đông, tấp nập ồn ào. Không biết quán bánh canh nầy có từ lúc nào. Quán ăn lề đường nên không có tên. Những khách quen của quán, vui vẻ đặt cho quán cái tên là Quán Cô Xinh. Quán chỉ có một cái bàn gỗ đơn sơ, trên đó để một số tô, chén. Bên cạnh là một lò lửa than, trên đó đặt một nồi bánh canh thơm ngát. Quán nép mình núp nắng bên hông vách tường của một cao ốc. Trước quán chỉ có hai cái bàn nhỏ cũ kỹ và năm bảy cái ghế. Nhiều khách hàng khi đến ăn bánh canh, họ mang theo cả ghế ngồi. Điều hành việc buôn bán, chỉ có một mình cô Xinh.
Một hôm, cô Xinh thấy một chú bé khoảng bảy, tám tuổi, ốm o, đứng nhìn cô phục vụ cho khách, với đôi mắt thèm thuồng. Cô hỏi nó: ”Em muốn mua bánh canh hả?” Nó trả lời ngay: ”Em không có tiền.” Nó vẫn đứng đó, mắt hau háu nhìn những tô bánh canh cô bưng ra cho khách. Cô hiểu, cô nói với nó: ”Cô cho em một tô bánh canh nhé.” Nó lắp bắp : ”Em không có tiền.” Cô Xinh vui vẻ nói: ”Cô cho em, cô không tính tiền đâu.” Khi cô Xinh đưa tô bánh canh cho thằng bé, cô cứ tưởng nó sẽ vui mừng húp vội tô bánh canh mà nó thèm thuồng. Nhưng cô ngạc nhiên thấy thằng bé không ăn, mà cẩn thận bưng tô bánh canh đi vào trong hẻm. Một lát sau, nó trở lại trả cái tô cho cô và lí nhí cám ơn cô. Cảnh nầy cứ diễn đi, diễn lại nhiều ngày như vậy.
Một hôm, cô Xinh tò mò hỏi nó: ”Em tên gì vậy, hình như em ở trong xóm nầy? Mà sao cô cho em bánh canh mà em không ăn ngay, em lại bưng đi đâu vậy?” Nó rụt rè thưa thật: ”Thưa cô, em tên là Tô, mỗi khi cô cho em bánh canh, em đem về ngay cho mẹ em ăn, vì mẹ em đang đói. Thường ngày, em đi ăn xin để nuôi mẹ em, nhưng không hiểu sao mấy hôm nay em chẳng xin được đồng nào, mẹ em đói lắm. Nếu không có tô bánh canh mà cô cho mỗi ngày, chắc mẹ em chết đói rồi !”
Khi nghe đứa bé kể hoàn cảnh của mẹ con nó, cô Xinh thấy cay cay nơi mắt, hai hàng nước mắt chảy dài xuống má. Cô bảo nó: ” Từ nay, mỗi ngày em ghé lại đây, cô gởi bánh canh cho mẹ em ăn nhé.”Thằng Tô cảm động nhìn cô và run run nói: ”Thưa cô, lần đầu tiên em gặp một người thương mẹ em như thế !”
Nhờ những tô bánh canh cô Xinh cho, mẹ Tô sống lay lắt qua ngày. Mấy năm sau, mẹ Tô qua đời. Năm ấy em mới 10 tuổi.
Khi mẹ Tô mất, lối xóm biết hoàn cảnh của em, nên họ góp tiền giúp em mua hòm cho mẹ.
...
Từ đó, ngày ngày nó đi lang thang ở thành phố để xin ăn, tối về ngủ trong những toa xe lửa cũ kỹ bỏ trống ở ga xe lửa Saigon, gần chợ Bến Thành. Ở đó cũng có nhiều đứa bé vô gia cư, ăn xin như nó, trú ngụ vào ban đêm. Chúng nó sống hoà thuận, không hề đánh nhau hay giành giật đồ của nhau. Chúng nó thương nhau, nương tựa nhau để sống.
Một hôm có một em báo tin: ” Ê tụi bây ơi, trưa mai ở Chùa có cho ăn cơm chay miễn phí!” Chúng nó nhao nhao lên: ”Chùa nào mà chơi ngon vậy ?” “Chùa Già Lam !”
Trưa hôm sau, chúng nó tụ tập đông đủ ở sân chùa chờ ăn cơm. Chúng nó được những người làm thiện nguyện, dẫn vô ngồi bàn và cho ăn uống no bụng. Ăn xong, chúng nó tự động biến đi trên khắp nẽo đường của thành phố Sài Gòn. Nhưng thằng Tô ở lại, nó giúp rửa chén bát cho chùa. Nó chăm chỉ, cùng với những người làm thiện nguyện ở chùa, rửa hằng lô chén bát. Nó không ngờ, ở một góc nhà ăn, vị thượng tọa trụ trì đang lẳng lặng quan sát thái độ làm việc của thằng bé ăn xin nầy. Trước khi nó định rời khỏi chùa, thầy trụ trì đến bên nó, mỉm cười hỏi nó: ”Em ở đâu đến đây, gia cảnh của em ra sao?” Tô lễ phép thưa với thầy: “Thưa thầy, cha mẹ con chết hết rồi, hàng ngày con đi ăn xin, tối về con ngủ trong những toa xe lửa bỏ trống ở ga Sài Gòn. Ngày nào con xin được năm ba đồng, thì mua được ổ bánh mì để ăn, ngày nào không xin được gì, thì nhịn đói!”
Thầy trụ trì hết sức xúc động khi biết được hoàn cảnh đáng thương của đứa bé ăn xin. Thầy vuốt tóc nó và thân mật nói: ”Thầy cho con ở lại trong chùa, con sẽ làm việc trong chùa như các chú tiểu khác nhé !”
Từ đó, nó từ giã xóm nhà “toa xe lửa” và ở hẳn trong chùa Già Lam. Thầy thấy nó dễ thương, lanh lợi lại siêng năng, thầy mến nó và cho nó đi học. Ngoài giờ học, nó tưới nước cho những cây cảnh trước sân chùa. Đặc biệt thầy giao cho nó nhiệm vụ đánh một hồi chuông mỗi ngày, lúc 7 giờ tối. Nó sống hiền hoà nên mọi người trong chùa ai cũng thương mến nó. Nó thông minh, lại siêng năng học hành, nên mấy năm sau nó tốt nghiệp Phổ Thông Cơ Sở.
Thầy vui mừng, khen ngợi nó; thầy khuyên nó nên tiếp tục sự học. Thầy bảo nó cứ thi vào Đại Học, biết đâu ơn trên sẽ phù hộ cho nó. Thầy hứa với nó, nếu con đậu vào Đại Học, thầy sẽ cho con một chiếc xe đạp để đi học.
Ơn trên đã đoái thương đến “hoàn cảnh khó nghèo” của một trẻ mồ côi bất hạnh, nên đã phù hộ cho nó đậu vào trường Đại Học Y Dược thành phố. Tô vui mừng báo tin thi đậu cho thầy biết, thầy xúc động ôm nó vào lòng và nói với nó: ”Thầy mừng cho con. Ngày mai con đi với thầy đến tiệm bán xe đạp, thầy mua cho con một chiếc để con đi học.” Khi nhận được chiếc xe đạp mới, Tô quá cảm động, vì đây là lần đầu tiên trong đời, nó nhận được một món quà giá trị như vậy.
Sau 7 năm cần cù học tập trong điều kiện thiếu thốn, Tô đã tốt nghiệp Bác Sĩ với thứ hạng cao. Tô được bổ nhiệm phục vụ ở Phòng Cấp Cứu của Bệnh Viện Đa Khoa Sài Gòn, phía đối diện với chợ Bến Thành. Biết hoàn cảnh của Tô khó khăn, nên bệnh viện cấp cho nó một phòng nhỏ để ở; nhưng nó thích sống ở chùa hơn.
Những ngày làm việc, Tô luôn luôn có mặt ở bệnh viện với tinh thần của một lương y. Tô thương mến, hiền hòa với tất cả bệnh nhân. Nó nhớ đến hoàn cảnh của mẹ con nó năm xưa, nên nó tận tình săn sóc cho những bệnh nhân nghèo. Đôi khi nó trả dùm tiền viện phí cho vài bệnh nhân khó khăn.
Một hôm, đang nghỉ trưa, cô y tá trực báo cho Tô biết có một bệnh nhân lớn tuổi mới nhập viện, bệnh tình có vẻ trầm trọng lắm. Bệnh nhân bị sốt cao, lại ho nhiều, thêm tức ngực, khó thở; bà được cho thở oxy và truyền nước biển ngay. Vì bệnh nhân bị ho nhiều nên Tô vội vã dùng ống nghe để kiểm tra phổi của bệnh nhân, xem có gì bất thường không. Khi Tô đọc hồ sơ bệnh án của bệnh nhân, mắt Tô hoa lên, tim đập mạnh. Tô nhận ra ngay đây là cô Xinh, chủ quán bánh canh năm xưa ở hẻm 324 đường Tr. Bình Trọng. Một vùng trời dĩ vãng ùa về trong tâm trí anh: anh nhớ đến con hẻm nghèo nàn của thời thơ ấu, nhớ đến người mẹ đau yếu, nhớ đến những tô bánh canh tình nghĩa mà cô Xinh đã cho mẹ anh ăn để kéo dài sự sống thêm mấy năm nữa. Giờ đây, ân nhân của mẹ con anh , là bệnh nhân đang nằm trước mặt anh. Với lòng biết ơn vô hạn, Tô bắt tay ngay vào việc định bệnh cho cô Xinh. Cứ hai ngày cô được chụp hình phổi một lần bằng quang tuyến X. Điện tâm đồ được đo mỗi ngày, và liên tục được truyền nước biển có pha trụ sinh. Cô đã được lấy máu để xét nghiệm v.v. Căn cứ vào hình chụp phổi cho bệnh nhân và một vài thử nghiệm khác, bệnh viện đã xác nhận cô bị sưng phổi, và phổi bên phải của cô có nước ở đáy phổi làm cho cô bị ho nhiều.
Khi đã tìm ra bệnh, thuốc gì tốt nhất, hiệu nghiệm nhất mà Tô được biết, anh đều đem ra dùng để trị bệnh cho bệnh nhân. Vì vậy, sau 10 ngày tích cực điều trị, bệnh nhân không còn sốt nữa, chỉ ho lai rai, nước ở phổi cũng đã biến mất. Sức khỏe của bệnh nhân tốt lên mỗi ngày. Cô đã có thể tự ngồi dậy được, và đi lui, đi tới chầm chậm trong phòng.
Một buổi chiều, khi không còn bệnh nhân cấp cứu nào nữa, Tô đến ngồi cạnh cô Xinh. Cô vui vẻ chào Tô: ”Chào Bác Sĩ, nhờ Bác Sĩ tận tâm chữa trị, nay tôi thấy khỏe lắm rồi.” Tô nhìn thẳng vào bệnh nhân và run run nói: ”Bà có nhận ra em là ai không ?” Bà Xinh ngơ ngác nhìn Tô rồi trả lời : ”Thưa Bác Sĩ, tôi không biết!” Tô cảm động, nắm tay bệnh nhân và nói: ”Thưa bà, khi bà mới nhập viện, em đã nhận ra bà là cô Xinh, người bán bánh canh ở hẻm 324 Tr. Bình Trọng năm xưa. Thưa bà, em là đứa bé gầy ốm năm nào, mỗi ngày được bà cho mẹ con em một tô bánh canh để sống qua ngày. Nhờ những tô bánh canh của bà cho, mẹ em đã sống thêm được mấy năm nữa.”
Bà bệnh nhân sửng sốt nhìn chàng và cảm động nói: ”Bác Sĩ là thằng bé ốm o năm xưa, sống ở hẻm đường Tr. Bình Trọng ư ? Tôi tỉnh hay mê đây!” Nó thân mật cầm tay bà Xinh và nói: ”Thưa bà, em chính là thằng Tô bé nhỏ, ốm yếu năm xưa, đã được cô Xinh cho hắn bánh canh mỗi ngày đó!”
Bà vui vẻ và cảm động nói với Tô:”Tôi cám ơn Bác Sĩ nhiều lắm.” Tô nhanh nhẹn trả lời bà: ”Em cám ơn bà mới đúng , vì nhờ những tô bánh canh tình nghĩa của bà, em mới có được ngày hôm nay. Thưa bà, khi bà được xuất viện, bà cho em ân huệ được đưa bà về nhà, và em xin tình nguyện sẽ chăm sóc sức khỏe cho bà suốt đời!”
Cầm tay bà Xinh, Tô tâm tình với bà :”Thưa bà , em tin Ông Trời có mắt, mới sắp đặt cho em có cơ hội được gặp lại bà, là ân nhân của mẹ con em!”
San Diego Tháng 8-2021
Bửu Uyển

## Duyên nợ

Chị lập gia đình lúc tuổi vừa đôi chín, anh kém hai.
Ba Mẹ chồng, chỉ có anh là con trai duy nhứt, nên cưng như vàng.
Nhà chị năm miệng ăn, trông vào mấy công ruộng bạc màu, chỉ đủ miếng cháo rau! Mùa hè năm đó, Cha chị vì muốn kiếm thêm ít tiền, theo người ta lên núi đập đá, tiền chưa kiếm được, nhưng bị đá rơi trúng lưng, tiêu hết cả gia sản, bệnh vẫn không khỏi! Ngày qua ngày, Cha chị chỉ có thể nằm trên giường, muốn chết mà không được!. Hai đứa em trai còn chưa đủ tuổi lớn. Nỗi khổ sở của gia đình, nỗi ai oán của Mẹ, khiến những tháng năm thời con gái của chị, mang gánh nặng trong lòng.
Nhà Ba Mẹ chồng chị vốn khá giã, ngặt nỗi con trai lắm bệnh tật! Mẹ chồng mê tín! tìm "Thầy" hỏi, "Thầy" phán: Gái hơn hai - trai hơn một, vợ chồng tuổi nầy hậu vận tốt!? Nghe lời "Thầy" và cũng muốn tìm người chăm sóc con trai lâu dài, gia đình đã đánh tiếng.
Một hôm, có bà mai đến nhà, thủ thỉ cùng Cha Mẹ chị :
- Gả con nhỏ đi, để có tiền chữa bệnh cho anh, lại đỡ đần được trong nhà.
Mẹ chị lắc đầu, có ai muốn đẩy đứa con gái thơ dại của mình vào lò lửa? Nhưng chị xin :
- Mẹ, cho con đi đi, số tiền sính lễ, có thể giúp Cha khỏi bệnh!
Tiếng kèn đón dâu thổi vang ngoài đầu ngõ, trước ngôi nhà nhỏ của chị. Cha chị nằm trên giường, tự đấm ngực mình :
- Trời ơi! Con gái, phải đánh đổi tuổi thanh xuân, chấp nhận lấy một người không xứng, chỉ vì cứu tôi và cứu gia đình này sao!?
Mẹ chị rướm lệ, tự tay cài lên tóc con gái cây trâm gài. Chị mặc áo đỏ, đi giày thêu, cúi lạy Cha, Mẹ mình, nước mắt chảy ra, trộn phấn má hồng! Từ đó, số phận cuộc đời chị, giao cả về tay một người chồng bệnh tật!
Hằng ngày, chị giúp Mẹ chồng trông coi ao vườn, làm xong việc nhà, thì sắc thuốc, giặt giũ cho chồng. Trong tim mình, chị chỉ coi chồng như một người em trai, cần sự giúp đỡ. Với sự chăm sóc chu đáo và tận tình của chị, bệnh tình anh có thuyên giảm rỏ rệt. Dần dà, tuy không nói ra, tình cảm anh dành cho chị ngày càng nhiều, vượt quá tình chị em.
Ba anh ở ngoài buôn bán, nhiễm phải thói cờ bạc, chẳng bao lâu thua sạch bách bao gia sản tích cóp khổ sở bấy lâu nay! Sau khi Ba Mẹ chồng chửi bới cãi vã ầm trời, Ba chồng chị dứt áo bỏ nhà ra đi, từ đó không ai gặp lại ông nữa.
Mẹ chồng và chị bàn nhau, mua ba mẫu ruộng làm kế sinh nhai. Không thể mướn người làm nữa rồi, Mẹ chồng con dâu xắn ống quần lên lội ruộng. Ngày còn ở nhà, chị từ nhỏ đã giúp Cha Mẹ làm ruộng, khổ sở gì chị cũng đã nếm trải qua, chỉ khổ cho bà Mẹ chồng làm không quen.
Một nhà vốn khá giả, bỗng chốc hóa bần cùng, đàn ông trong nhà, người đau yếu, người bỏ đi không tăm tích, bà Mẹ chồng vừa đau vừa hận, lại thêm việc ruộng nương nặng nhọc, khiến bà kiệt quệ, mắc bệnh, rồi không dậy nổi! Của cải lại tiếp tục đội nón ra đi!
Trước lúc lâm chung, Mẹ chồng kéo tay chị, gần như van xin :
- Chồng con chẳng may nhiều bệnh tật, Mẹ xin con cố gắng chăm sóc nó, nếu con muốn ra đi, hãy đợi lúc nó khỏe lại.
Chị nắm chặt tay anh. Từ đó, số mệnh của anh lại trong chị.
Chị là người phụ nữ trọng tình nghĩa, chưa từng hứa gì, nhưng vẫn cư xử với anh như cũ. Chị làm quần quật quên ngày đêm, để kiếm tiền thang thuốc cho anh. Cuộc sống của họ trôi qua khổ nhọc nhưng bình lặng.
Được một thời gian, chồng chị bệnh tình bình phục hẳn. Chú chồng chị, ở thành phố xa, buôn bán cũng khá, muốn giúp, nhắn cháu lên phụ việc. Chồng chị, cũng muốn tạo lập sự nghiệp, giúp chị bớt khổ cực.
Chị thu xếp hành lý cho anh. Anh nhìn chị :
- Chị ráng chờ tôi về.
Tim chị đập nhẹ, nhưng mặt vẫn bình thường, có điều khóe miệng ẩn một nụ cười hân hoan rất nhẹ, mà người khác khó nhìn thấy. Khóe cười ấy, như biểu lộ những việc làm của chị, đã được đáp đền lần đầu.
Biết chị để chồng đi xa, người trong làng thương tình bảo ban: "Đàn ông dễ đổi thay!?ở ngoài thế giới bao nhiêu xanh đỏ tím vàng, biết chồng mình có về nữa hay không!?".
Chị cũng không biết, im lặng, lòng nhũ thầm: "Giữ được chim ở, chứ ai giữ được chim bay? Dù sao thì mình cũng là một cô dâu được gả cưới đàng hoàng và nhất là câu nói trước ngày anh lên đường đi xa".
Thời gian chầm chậm trôi. Sau đôi ba năm, việc buôn bán thuận lợi, thấy anh đã khá vững vàng, người chú giúp vốn cho anh ra riêng, tự làm chủ lấy.
Anh, nay đã là một người đàn ông chửng chạc, có phong cách và khí chất, trở về quê với chị.
Còn chị, dãi nắng dầm sương, nhọc nhằn lao khổ, đã làm bay đi những nét đẹp thời trẻ, là một người đàn bà nhà quê đích thực. Trong lòng, chị chỉ coi anh là một đứa em trai thân yêu. Chị không dám ngờ, anh đã nói với chị, khi bước chân về đến nhà :
- EM, tôi đã TRƯỞNG THÀNH, giờ chúng ta có thể THÀNH THÂN cho tròn câu DUYÊN NỢ.
Chị nhìn anh, như đang nằm mơ, chị sợ mình đang nghe lầm. Anh cũng là một người đàn ông trọng tình trọng nghĩa như chị? Chị cúi đầu, tự đáy lòng dâng lên nụ cười rạng rỡ, cũng để rơi xuống những giọt nước mắt đẹp đẽ nhất đời người.
Anh nắm tay chị, họ cùng mỉm cười, đẹp như áng mây chiều êm ái nơi chân trời mùa hạ.
Sưu Tầm.

## Bài thơ: Mai tôi đi...

Khoảng tháng 1/2015 có bài thơ Mai Tôi Đi không đề tên tác giả được phổ biến khắp nơi - khiến nhiều người đọc sững sờ, về những lời tác giả sáng tác trong bài thơ, sao thấy buồn muốn khóc! 
Vì tác giả biết trước sự ra đi của mình trong nay mai - nên đã sáng tác bài thơ này bằng Tiếng Anh và cũng chính tác giả đã chuyển sang Việt Ngữ, phổ biến trên Facebook.
Nay tôi được biết tác giả là:
Thái Thúc Hoàng Minh con ruột của cố đạo diễn Thái Thúc Nha (Alfa Film) trước 1975
Tác giả bài thơ đã qua đời : Ngày 13 tháng 2 năm 2015-Tại Đà lạt. Tác giả Thái Thúc Hoàng Minh là cậu ruột của nữ ca sĩ Thanh Lan.
Nguyên văn bài thơ bằng tiếng Anh và tiếng Việt như sau...
**TOMORROW I'M GOING!**
**Tomorrow I'm going... It's no big a deal,**
**It happens all the time, like fallen leaves in the pảk**
**Like flowers driven by winds onto the side walk,**
**These are minor matters in the turbulent waters of life...**
**Death is hovering over my death bed,**
**Please spare me of comments, visitations, or prayers of peace**
**While my breathing is going to cease**
**And I'm lying, waiting to bid farewell.**
**These last dying moments... I wouldn't care less...**
**The hot and cold months on this planet.**
**No matter I'm rich or full of glory,**
**At the end I still return to dust and ashes...**
**My finite existence decisively comes to an end**
**And enters the yin and yang bỏderlands**
**I won't be bewildered at the frontier's gate**
**Earthly realm is on this side, the other an unimaginable and unknown fate**
**I only wish my soul always at peace,**
**Traveling lightly, I quicken my pace**
**Leaving behind those who push and pull,**
**While I finish my journey on earth's face...**
**My eyes are already closed...**
**Please don't shed tears of sympathy**
**Please, no flower wreaths, no offerings, nor condolences,**
**No videotaping, no picture taking for memories.**
**That would only bring stresses and strains to the surviving...**
**A quick look behind and life is just like a dream**
**I arrived naked and I'm leaving with empty hands**
**Many ups and downs, happy and sad moments piled high,**
**Now they're all cleared up...I'm stepping on board, the boat has arrived...**
**If you miss me... Please silently pray,**
**And consider a life has been liberated,**
**Be calm, relaxed, and gay,**
**I go first, you follow behind, we'll meet again...**
**MAI TÔI ĐI**
**Mai tôi đi... Chẳng có gì quan trọng,**
**Lẽ thường tình, như lá rụng công viên,**
**Như hoa rơi trước gió ở bên thềm,**
**Chuyện bé nhỏ giữa dòng đời động loạn...**
**Trên giường bệnh, Tử Thần về thấp thoáng,**
**Xin miễn bàn, thăm hỏi hoặc cầu an,**
**Khi xác thân thoi thóp trút hơi tàn,**
**Nằm hấp hối đợi chờ giờ vĩnh biệt.**
**Khoảnh khắc cuối... Đâu còn gì tha thiết...**
**Những tháng ngày hàn nhiệt ở trần gian.**
**Dù giàu sang hay danh vọng đầy tràn,**
**Cũng buông bỏ trở về cùng cát bụi...**
**Sẽ dứt điểm đời phù du ngắn ngủi,**
**Để đi vào ranh giới của âm dương,**
**Không bàng hoàng trước ngưỡng cửa biên cương,**
**Bên trần tục, bên vô hình cõi lạ...**
**Chỉ ước nguyện tâm hồn luôn thư thả**
**Với hành trang thanh nhẹ bước qua nhanh,**
**Quên đàng sau những níu kéo giựt dành,**
**Kết thúc cuộc lữ hành trên dương thế...**
**Mắt nhắm rồi... Xin đừng thương rơi lệ,**
**Đừng vòng hoa, phúng điếu hoặc phân ưu,**
**Đừng quay phim, chụp ảnh để dành lưu.**
**Gây phiền toái, nợ thêm người còn sống...**
**Ngoảnh nhìn lại, đời người như giấc mộng,**
**Đến trần truồng và đi vẫn tay không.**
**Bao trầm thăng, vui khổ đã chất chồng,**
**Nay rũ sạch... Lên bờ, thuyền đến bến...**
**Nếu tưởng nhớ... Xin âm thầm cầu nguyện,**
**Nên xem như giải thoát một kiếp người,**
**Cứ bình tâm, thoải mái với vui tươi,**
**Kẻ đi trước, người sau rồi sẽ gặp...**
**QH (St)**

## Phong thủy đời người (tản văn)

Con người thế gian, ai cũng mong muốn một cuộc đời may mắn, thuận lợi. Vì vậy, làm bất kể việc lớn nhỏ nào người ta đều xem phong thủy, đặc biệt là người phương Đông. Nhưng phong thủy tốt nhất ở ngay bên mình thì chúng ta lại thường bỏ quên mất!
Nếu bạn muốn mọi chuyện trong đời được may mắn, thuận theo ý nguyện thì nhất định phải dưỡng tốt phong thủy trên chính thân thể của mình!
Một người luôn nhớ ân huệ mà người khác đã làm cho mình, nhớ đến điểm tốt của người khác, đây được gọi là tụ tài khí.
Mỉm cười chính là ánh sáng chiếu rọi đường đi của một người. Khuôn mặt tươi cười là biểu hiện của bảo vật (vàng bạc thời xưa), khẳng định là tụ tài.
Nếu một người luôn nhớ đến điểm xấu của người khác, oán giận người khác, ghen tị với người khác thì đó chính là tụ âm, tức là tích tụ khí xấu, không tốt.
Ngọn nguồn của phong thủy chính là thể hiện ở việc hiếu thuận với cha mẹ, tổ tiên. Một khi đã hiếu thuận với bề trên thì thuận lợi và may mắn tự nhiên sẽ đến.
Trong gia đình, vợ chồng hòa thuận, âm dương cân bằng thì tự nhiên sự nghiệp sẽ thịnh vượng, gia đình hưng thịnh, gặp được quý nhân, mọi sự tất sẽ hưng. Một khi quý nhân đến thì tiểu nhân sẽ tự rời xa và gia đình hưng thịnh. Nếu vợ chồng bất hòa thì mọi sự tất sẽ suy.
Một người nếu không bỏ được thói quen xung đột, cãi vã với cha mẹ thì sẽ không thể thay đổi được vận mệnh của mình cho tốt lên. Một người con bất hiếu thì rất khó suy nghĩ cho người khác, và khi đó vận may sẽ khó hình thành.
Một người nếu như từ nhỏ đã hiếu thuận, không xung đột với cha mẹ anh em thì tương lai tất sẽ có tiền đồ. Bởi vì hiếu thuận với cha mẹ mỗi ngày chính là tích phúc đức mỗi ngày.
Một người hàng ngày đều xung đột với cha mẹ, không biết kiềm chế cảm xúc, đối đãi không tốt với thủ trưởng, đồng nghiệp thì công việc sẽ không thuận lợi, cả đời suy sụp liên tục, ở những thời khắc quan trọng thường sẽ thất bại.
Phong thủy tốt nhất chính là bản thân tu luyện tâm tính mà thành!
Nghiêm khắc yêu cầu bản thân, tạo phúc cho người khác, trở thành “ngôi sao may mắn” của người khác thì phúc đức của bản thân cũng tự nhiên đến, phong thủy tự nhiên cũng tốt.
Nếu là người có phúc thì nơi họ ở cũng là phúc địa, đất lành. Còn người ở nơi được cho là phúc địa, đất lành nhưng tâm tính không tốt thì cũng là vô ích.
Mọi người thường biết rằng phong thủy có thể dưỡng người, nhưng lại không biết được rằng người cũng có thể dưỡng phong thủy. Cho nên phúc phận của một người cũng cần phải tích lũy mới thành.
Lâm Tắc Từ từng nói rằng, một người nếu tâm tính bất thiện thì phong thủy là vô ích. Cho nên, tu dưỡng tâm tính chính là phong thủy tốt nhất của đời người!
(Minh Ho sưu tầm)

## Thư mẹ gửi con gái

**Dự án "Khu vườn tâm hồn" đồng hành cùng Hear &Heal**

## Sài Gòn, nhìn từ một nhà có F0

Hàng xóm F0 của tôi là một cụ già, không gia đình, không người thân, không quê quán, là người làm cho gia đình chủ này đã ngót nghét 60 năm. Những người như bà trong lòng xã hội Sài Gòn nhiều lắm, và hầu hết trong số họ, sống chết ở cùng với chủ, như một thành viên trong gia đình, không phân biệt.
Hai năm trước tôi chuyển về khu này, gặp thì thấy bà còn lanh lợi nhưng trí nhớ bị lẫn. Bà hỏi tôi mỗi một việc là "chú mua nhà này à?" mà có ngày bà sang hỏi đến 20 lần. Đến mức người nhà bà phát cáu phải gọi bà về.
Cách đây nửa năm bà bị ngã và bị liệt phải ngồi một chỗ. Cửa nhà luôn mở, bà ngồi tầng trệt, luôn ngó ra ngoài với ánh nhìn rất buồn. Chỉ ánh mắt thôi, còn tất tần tật ý niệm về thời gian cũng bị lãng quên theo trí nhớ. Đôi khi mới 9 giờ sáng, bà hỏi, "giờ mấy giờ chiều rồi con?". Hoặc thấy nhân viên tôi đi làm về, bà hỏi, đi chợ nấu bữa trưa à?
Cách đây 1 tuần, xét nghiệm toàn khu phố khi một nhà có người dương tính, người ta ngỡ ngàng vì ca này, người duy nhất trong ngôi nhà 9 người ấy, dương tính. Cô con dâu thì cho hay cô có đi chợ Tân Định nhưng cô âm tính. Anh con trai thì hay đi lại hút thuốc và có hút thuốc với gia đình có ca nhiễm. Nhưng anh cũng âm tính luôn.
Vậy chẳng biết cô vít nơi đâu, tự dưng rơi vào một bà cụ gần như cả năm nay không tiếp xúc với người ngoài, không có khả năng đi lại để dính cô vít nơi đâu.
Và điều đáng ngạc nhiên là một tuần đã trôi qua, trong nhà ấy, cũng chỉ có mỗi bà cụ già này là dương tính. Không ai lây nhiễm cả.
----------------------
Khi bà cụ bị được 3 ngày, gia đình đó rất hoảng. Nói gì thì nói, sống chung với một bệnh nhân với căn bệnh truyền nhiễm có thể nói là truyền nhiễm khủng nhất hiện nay, ai chẳng lo? Nhất là gia đình có một bà già bằng tuổi bà này, bệnh tật đầy mình và 3 đứa trẻ con...
Nhưng gia đình đó rơm rớm nước mắt thuyết phục đoàn chống dịch là thôi, đưa bà vào BV dã chiến, bà không đi lại được, rất khổ cho lực lượng chống dịch và khả năng tiếp xúc gần lây bệnh khá cao, lại lúc quá tải sợ bà cụ chết trong cô đơn...
"Má ở đây mấy chục năm rồi, cũng buồn vui với nhà tôi. Xin cho má được ở lại thêm mấy hôm cũng được, để gia đình tôi tiện chăm sóc. Khi nào má trở nặng, chúng tôi sẽ gọi báo"
Đúng lúc hệ thống y tế chống dịch ở Sài Gòn quá tải, không có chỗ cho bệnh nhân không triệu chứng, nên bà Mai chưa được đưa đi. Họ cửa đóng then cài kín mít, dũng cảm sống cùng dịch bệnh trong một căn nhà với sàn có hơn 20m2, 9 con người. Sau đó một hôm thì có kế hoạch thí điểm để F0 không triệu chứng chăm sóc ở nhà. Thế là bà Mai ở lại.
--------------------
Ông tổ dân phố gọi hỏi tôi thế nào khi phải sống cạnh gia đình có F0, tôi trả lời rằng tôi chẳng sợ gì cả.
Chỉ là mình sẽ khó cầm lòng, khi nhìn thấy một bà cụ tứ cố vô thân đi lên xe đến bệnh viện dã chiến và có thể đó là chuyến đi cuối cùng của đời bà. Ôi, chuyện không phải của nhà mình, mà bà cụ đi, có khi còn tốt cho mình hơn trong phòng chống dịch bệnh, nhưng tự dưng tôi thấy mắt mình nặng nặng khi tưởng tượng ra hình ảnh đó.
Và thế là tôi sống một cách bình thường cạnh F0 suốt hơn một tuần rồi. Tôi học cách sống cùng dịch bệnh một cách cẩn thận nhất từ tất cả mọi khâu, nhất là ăn uống và sinh hoạt. Tôi ổn.
---------------------
Hôm qua đứa cháu, cũng là nhân viên của tôi vô tình hỏi thăm bà cụ. Tôi có nói câu chuyện gia đình ấy chấp nhận sống chung với dịch bệnh để bà cụ không cô đơn buồn tủi những ngày cuối đời.
Thế rồi cháu tôi bảo, cậu không ra ngoài mấy ngày nay cậu không biết, dọc hè phố Sài Gòn, đặc biệt là chỗ gần Lăng Ông Bà Chiểu, có nhiều người trên vai có cái ba lô, ngồi trên vỉa hè chờ phát cơm. Họ còn trẻ lắm.
Có thể họ là những thanh niên đi làm về nhưng không kịp vào khu nhà trọ vì khu đó bị phong toả, thế thôi ở ngoài đường luôn đến đâu thì đến. Có thể là những người bị thất nghiệp, giờ rời Sài Gòn cũng không thể mà đi làm thì cũng chẳng ai thuê làm.
Nhưng họ không đói, vì vẫn còn đồng bào đùm bọc họ, đồng bào vượt qua khó khăn dịch bệnh để đưa cho họ những hộp cơm cứu rỗi những ngày tháng ngặt nghèo này...
**(Hoàng Nguyên Vũ)**

## Tiếng dội của xa xôi

Chắc là âm thanh, và những người làm ra những âm thanh đó không biết rằng tiếng dội của nó lại vang xa đến vậy, những mấy chục năm vẫn bền dai.
Nhất là ông già đã rón rén hết sức để đứa cháu gái không thức giấc, cái cửa vẫn kêu khi ông lách mình qua đi ra sông đổ đó. Mái dầm chách bủm đều từng nhát, tiếng những bẹ lá dừa nước cọ vào be xuồng dần xa. Trong bếp nước đã kêu ấm. Chắc là củi còn ướt nên trên đầu còn lại của thanh củi réo còn sôi. Bà già châm trà xong, múc gạo nấu nồi cháo trắng. Một con chuột nào chạy ngang vách bếp, bà già chỉ suỵt đuổi không rượt theo tới ổ vì sợ gây ồn. Gần sáng luôn là quãng thời gian con nít ngủ ngon.
Những âm thanh đầu ngày khẽ khàng như một người tịnh không dám thở, sau này đứa cháu gái chẳng hiểu sao chúng lại náo động mỗi khi nhớ về. Tiếng dép bà già lép xép tới đâu, bóng tối tan ra tới đó. Và tụi chim sẻ chim sâu tụ tập trước sân chờ nắm gạo xòe hoa từ tay bà, bầy gà vỗ cánh bay từ những cành cây xuống đất, bản lề cửa sổ cọt kẹt kêu hít không khí đẫm sương vào nhà. Bà già không cất tiếng kêu “dậy đi, con gái con đứa mà ngủ nướng” thì cô cháu cũng biết đã sáng trắng rồi. Đám con nít bên xóm bắt đầu chạy giỡn ngoài cây rơm.
Chỉ bảy trăm ngày trong đời thức dậy cùng với mặt trời ở xóm Chẹt, nhưng cái cảm giác miên viễn bất chấp ông bà già đã qua đời. Sẽ có những ông bà già khác dậy sớm châm trà, đuổi kiến, cố không gây ra tiếng động để giữ giấc ngủ của bọn trẻ con. Từng ấy âm thanh ngày mới ẩn nhẩn bền dai đi qua súng nổ pháo gầm của mấy cuộc chiến tranh. Những tiếng động của sự sống. Đứa cháu sinh ra trong yên tĩnh, may ra chỉ có tiếng gà gáy sáng mới khiến nó giật mình.
Nó phổng phao từng ngày với tôm cá ông già đặt đó dưới sông. Cùng với khí trời, nó hít thở cả tiếng làng quê xao động. Gàu nước xối lên đôi chân trần. Bà già cằn nhằn ông già để khăn tắm không đúng chỗ đúng nơi. Lửa reo dưới nồi bí hầm dừa sôi sục. Chó giỡn hớt bầy gà làm táo tác vách ngoài. Trao trảo kêu ngoài liếp, nháo nhác báo với bầy có buồng chuối chín cây. Tu hú ở cuối vườn rải từng tiếng một.
Bữa cơm sáng đúng lúc bên sông vẳng qua tuồng Kiếp nào có yêu nhau. Ngồi ở nhà đủ xa để không phải nghe băng chạy xè xè, loa rè. Cả tiếng đờn cũng rụng mất, đến bờ bên này chỉ còn những giọng ca như rơi rớt từ trời. Hôm nào ư ử xuống mùi theo Lệ Thủy cũng bị rầy “con gái con đứa gì vừa ăn vừa hát, coi không được”. Cháu ngoại thuộc làu cả tuồng, thuộc đến câu cô quận chúa Quế Minh nói lúc ôm xác người tình, bảo rằng em sẽ đưa anh về với cát vàng sa mạc, ở đó không còn ai giành giật anh của em. Lệ Thủy ca diễn thì khỏi chê, mê chết bỏ. Mê cái kiểu đàn - bà - trẻ - con nói liến thoắng giòn tan, đắm đuối khi yêu, thất tình thì nức nở thảm sầu. Cách cô nuốt nước mắt nước mũi thành tiếng hướt đó ít người có được. Mỹ Châu kiêu kỳ quá đau tình cũng không giống lắm, Phượng Liên hiền từ ung dung quá, giọng Út Bạch Lan thì sầu não đến yếu nhược, chẳng hợp với con nít.
Lâu lâu nghe lại những tiếng động nhà quê qua một màng ký ức, đứa cháu gái vẫn nghe trong vắt, như không bị đẩy ra xa bởi tuổi tác chất chồng. Như không phải dưới đáy của lớp lớp sóng âm khác mà nó nghe được suốt quãng thời gian đã sống, từ đứa trẻ trở thành bà già. Chúng tách biệt, không lẫn lộn với vùng nhớ khác. Xua không đi, bứt không rời. Lá khô va vào nhau theo nhịp chổi ráng quét sân. Vú sữa rớt sau cú đập cánh của chim đêm, có những trái còn xanh phải đứt cuống lìa cành, chúng lại sớm rã thành phân bón lại cho cây. Tàu cau rụng. Gà kêu ổ lúc xế trưa. Con mèo mướp trườn qua mảnh ngói vỡ. Nước chảy qua họng đìa buổi đỉnh triều cao. Gió qua đám lá làm thành âm thanh của một cơn mưa rào. Ở đó hình như cũng có mấy vụ cãi nhau, nhưng từ ngữ không chang chói gây đau. Và những khuya ông Bảy Xỉn đi qua nói oang oang nhà này của già Hai nè, chả có đứa con gái đẹp lắm nè, nhưng cổ lấy chồng rồi, nói tới đó Bảy Xỉn hát váng lên não nuột: “Em ơi nếu mộng không thành thì sao, mua bao thuốc chuột uống cho rồi đời”.
Tiếng chim bìm bịp thì nổi tiếng từ đời thuở nào rồi, từ một người đàn bà cất tiếng hò, “Bìm bịp kêu nước lớn ai ơi, buôn bán không lời chèo chống mỏi mê”. Nhưng tàu chuối khô bay tán loạn trong gió cũng làm bải hoải những ai phải rời bỏ nó.
Và ông già tợp hớp trà nguội khà ra một cái khoái trá đã đời cơn khát, giọng điệu càm ràm của bà già “con gái con đứa gì…”, đứa cháu khi ấy đâu có biết mấy chục năm sau tiếng dội vẫn còn vang.
Tản văn - Nguyễn Ngọc Tư

## Chăm sóc chậu hoa lan

Vị sư già trồng một chậu lan. Ông chăm sóc chậu hoa đẹp rất cẩn thận, ngày ngày nhổ cỏ và tưới nước cho cây. Một lần có việc phải ra ngoài, ông giao chậu lan cho một tiểu hòa thượng nhờ chăm sóc. Nghe lời dặn của sư phụ, tiểu hòa thượng rất chăm chút cho cây lan. Cây hoa cũng rất phát triển.
Không may thay, một hôm trời mưa to, gió thổi mạnh khiến chậu lan đổ ụp xuống đất. Tiểu hòa thượng nhìn thấy những chiếc lá dập nát thì vô cùng đau lòng, trong tâm cũng sợ bị khiển trách.
Vài ngày sau, vị sư già trở về, tiểu hòa thượng đã kể lại sự việc, lòng thấp thỏm lo âu vì nghĩ lần này, sư phụ sẽ rất giận. Thế nhưng, vị sư già chỉ im lặng. Tiểu hòa thượng vô cùng kinh ngạc, bèn tò mò hỏi: “Sư phụ, đây là chậu lan mà sư phụ rất quý và hết lòng chăm sóc mà?…”.
Vị sư già khẽ mỉm cười, nói với tiểu hòa thượng: “Ta trồng cây lan không phải để nuôi sự tức giận”.
Lời bàn: Câu trả lời đơn giản của vị sư đã cho thấy thái độ cởi mở đón nhận những điều khắc nghiệt của cuộc sống. Cái gì đã mất, thì cũng mất rồi. Lúc ấy, hỏa khí bừng bừng bốc lên, liệu có lấy lại được chăng? Vậy cớ gì phải nổi giận để nhọc thân, mệt trí? Nếu quả thật là lỗi lầm của tiểu hòa thượng, thì tiểu hòa thượng nhận lỗi và lưu tâm sửa sai là được rồi. Huống hồ, chậu lan vỡ là do ngoại tác.
Vị sư già trồng lan, chăm sóc lan, có lẽ là để tận hưởng những phút giây thanh nhàn khi tưới nước, nhổ cỏ, khi ngắm cây lớn lên, ngắm hoa lan nở. Đó là những giây phút tĩnh tại, nuôi dưỡng tâm hồn và sự thuần thiện khi dồn tâm huyết để nâng niu một sinh mệnh. Đó mới là mục đích, chứ không phải vị hòa thượng có chấp trước vào việc muốn sở hữu chậu cây đẹp. Nếu quả có tâm sở hữu ấy, hẳn khi chậu lan vỡ, ông đã không hành xử điềm tĩnh như vậy. Qua đây, tiểu hòa thượng và chúng ta đều nhận được một bài học thấm thía, cầm lên được thì buông xuống được, không cần tiếc nuối, cũng không cần giận dữ khi chuyện xấu xảy đến.

## Chiếc đòn gánh

Những người phụ nữ quê tôi không ai không biết đến chiếc đòn gánh vì ai cũng đã từng hơn một lần gánh nó trên vai. Quê tôi miền Trung nghèo lắm. Từ những bé gái mới lớn lam lũ giúp mẹ thổi cơm gánh nước, đôi vai nhỏ như oằn xuống với một cánh tay bấu vào thân đòn nặng trĩu còn tay kia dùng lấy thăng bằng gánh hai thùng nước sóng sánh - đến những bà mẹ già lập cập gánh những bó rau, bụi cải hay con gà con vịt thong dong ra chợ bán. Rồi những đứa em, người chị, hầu như cứ rãnh việc, buông tay ra là động đến chiếc đòn gánh. Gánh lúa, gánh phân, gánh mạ non, gánh nước … Toàn bộ công việc nặng nhọc đặt trên vai người phụ nữ. Đàn ông quê tôi lại ít thấy gánh gồng gì. Dĩ nhiên là họ làm những việc khác có khi còn nhọc nhằn hơn nhưng ít khi động đến chiếc đòn gánh …
Tôi nhớ như in lúc tôi còn là thằng bé sáu, bảy tuổi, chiều chiều ra đứng trên đầu cầu sông Kênh đón mẹ đi chợ về. Rướn người trên thành cầu sắt thật cao, tôi đưa mắt hướng về phía chợ. Hễ cứ thấy từ xa ai đó đang quang gánh bước đi là lòng tôi lại thấp thỏm mừng vì nghĩ đó là mẹ mình. Cái dáng tất bật, lam lũ của những người đàn bà quê tôi hầu như ai cũng giống nhau. Cho nên, tôi thường nhìn lầm. Tôi đợi từ xa và dõi mắt nhìn chằm chằm vào dáng đi vất vả cũng với hai cánh tay, một nắm trên thân đòn và một lấy thăng bằng, buông lỏng theo từng bước chân như chạy. Không lẫn vào đâu được, đúng là bước chân của mẹ tôi. Bước chân mẹ lạ lắm, có gì đó như lo toan, vội vã, nhẫn nhục, nhọc nhằn trong mỗi nhịp đi hối hả. Nhưng khi bóng người đàn bà kẽo kịt gánh gồng đến gần, thì lại không phải. Niềm vui biến mất, gương mặt buồn xo, tôi lại ngồi xuống thành cầu đợi mẹ tôi.
Cuối cùng thì mẹ cũng xuất hịên! Từ xa, nhận ra mẹ, tôi đã ba chân bốn cẳng chạy ùa tới mừng rỡ. Tôi chẳng quan tâm gì đến mồ hôi mồ kê trên gương mặt mẹ chảy ròng ròng vì mệt, vì nắng rát mà điều quan trọng nhất là nhìn vào hai cái mẹt đong đưa hai bên đòn gánh dưới cái quang bằng dây thép uốn tròn. Quà của tôi nằm ở đó! Khi thì là chiếc bánh mì, vài viên kẹo dẻo, một lóng mía ghim, có khi là mấy thứ đồ chơi rẻ tiền bằng nhựa … Thích nhất là được mẹ mua cho bánh bò ông ba tàu ngoài cổng chợ. Tôi mê bánh bò ông thì ít mà thích con gái ông thì nhiều! Chẳng là con ông học cùng lớp với tôi. Nó học giỏi nhì lớp, còn tôi hạng nhất. Bọn trẻ con thường cắp đôi tôi với con Lẻm, tên nó. Không biết nó nghĩ gì không chứ riêng tôi thì thích! Mà cũng lạ, không ai như tôi, mới học đến lớp hai, lớp ba mà đã biết mắc cỡ khi gặp nó … Nhưng đó là chuyện hồi con nít …
… Không cần đợi mẹ đồng ý, tôi đã lục mẹt lấy quà của mình vì biết mẹ chỉ mua cho tôi. Nhà có mấy chị em, ba mất sớm mà tôi là con trai duy nhất nên mẹ thương tôi hơn cả. Trăm lần như một, chiều nào mẹ đi chợ về, sau khi bán hết mớ rau cải, bầu bí trồng ở vườn nhà, thế nào mẹ cũng dành tiền ki cóp mua cho tôi ít quà. Tôi cầm gói bánh bò tung tăng chạy trước, mẹ gánh cặp mẹt đi sau. Không nhìn vào mắt mẹ nhưng biết chắc mẹ đang cười nhìn tôi hạnh phúc. Đôi gánh nhẹ hẫng trên vai mẹ và thỉnh thoảng mẹ còn nói vói theo nhắc yêu tôi: Ranh con, chạy vừa vừa chứ, té ngã bây giờ!
Tôi thật không biết chiếc đòn gánh do ai nghĩ ra và xuất hiện đầu tiên vào lúc nào nhưng quả thật, đó là một dụng cụ tuyệt vời để di chuyển vật nặng từ nơi nầy đến nơi khác bằng sức người ở quê tôi. Nó được làm bằng cây tre già ngâm nước càng lâu càng tốt, để tre dẻo, chắc và khỏi mục. Tôi đã thơ thẩn hàng giờ nhìn người ta đục đẽo chiếc đòn gánh. Thật cũng lắm công phu! Sau khi chỉ lấy đoạn gốc tre già ngâm nước chừng vài tháng, người ta làm hai chiếc máng ở hai thân đòn. Hai cái máng nầy phải giống nhau như một, giữa khắc một cái rãnh sâu dùng để móc quang vào cho khỏi lệch. Cái máng nầy cũng lắm chuyện. Gặp tay thợ đẽo giỏi, nó là hình tròn, hình ô van có khi còn được tạc vào dấu thập hoặc chữ vạn mà tôi không biết để làm gì. Có lẽ lấy hên mua may bán đắt khi gánh trên vai chiếc đòn gánh ấy chăng, hay chỉ là khắc lên cho đẹp … Chưa hết, còn phải gọt đẽo thân đòn cho thật thẳng, đoạn ở giữa mỏng hơn hai bên đầu làm đòn đong đưa cho nhẹ sức hơn khi gánh nặng … Khoảng hơn tiếng đồng hồ đẽo gọt thì chiếc đòn gánh ra đời. Nó có thể dùng hết đời nầy đến đời khác trong một gia đình quê tôi vì hiếm khi bị gãy. Đến khi nước bóng ở thân đòn nổi lên màu đen mun thì không biết chiếc đòn đã thấm biết bao nhiêu mồ hôi từ trên đôi vai những người đàn bà tần tảo …
Nhưng chiếc đòn gánh của mẹ tôi không chỉ có thế. Nó còn là một trời kỳ diệu. Nó mang đến tuổi thơ tôi những niềm vui háo hức tràn trề, cả những giấc mơ đẹp đẽ nhất trên đời. Còn gì sung sướng hơn khi được đặt ngồi vào một đầu quang, đầu bên kia là trái bầu trái bí mẹ gánh suốt dọc đường ra chợ. Tôi cứ ngồi im như thế trên suốt con đường làng, hấp háy đôi mắt hãnh diện nhìn quanh xem có đứa bạn học nào để mà vểnh mặt lên, tự hào được ngồi gánh mẹ. Tôi cũng không buồn khi thấy chỉ mấy con trâu, con bò dọc đường làng chào tôi kêu nghé ọ và những đứa trẻ chăn trâu nhìn theo cười chế giễu. Tôi biết chúng nó ganh tỵ vì không được ngồi gánh như tôi …Và vì tôi nặng hơn mấy trái bầu bí ở gánh bên kia nên mẹ phải đưa vai chệch về phía tôi để giữ thăng bằng. Mệt lắm nhưng mẹ vui. Tôi biết được điều ấy trên đôi mắt long lanh, hài lòng bừng lên trên mặt mẹ …
Đến gần chợ là tôi dứt khoát bảo mẹ cho xuống, có năn nỉ mấy cũng không chịu ngồi thêm. Tôi sợ con Lẻm, con ông ba tàu bán bánh bò đầu cổng chợ nhìn thấy. Vì sao sợ nó cười, tôi không biết nhưng rõ là tôi thích được nhìn nó xuất hiện với hai chiếc nơ xinh xắn, chạy lò cò trước cổng, mắt tròn xoe nhìn tôi và gật đầu chào. Tôi làm như ngó lơ, chạy lúp xúp theo mẹ, mắt liếc thật nhanh vào con Lẻm còn tay thì cứ cầm dây quang phía sau chiếc đòn gánh mà nhắc để khỏi mắc cỡ: Đi nhanh lên mẹ, con đói bụng lắm rồi …
Tuổi thơ tôi và chiếc đòn gánh mẹ như không hề rời nhau. Cũng có những hôm không bán được hàng, mẹ quảy gánh về mà không có quà cho tôi. Tôi cứ cầm lấy đòn gánh mẹ mà khóc tấm tức, dỗ mấy cũng không nín. Tôi nghĩ mẹ không thương tôi hoặc là quà của tôi mẹ đã cho ai mất rồi. Tôi chẳng nhìn lên mắt mẹ để thấy mẹ buồn như thế nào vì không tiền mua quà cho đứa con cưng. Có hôm mẹ tủi thân cứ nhìn tôi, ôm tôi mà khóc …
Nhưng cũng có lúc, chiếc đòn gánh với tôi là cả một cơn ác mộng! Tôi nhớ có lần đi hái trộm xoài non của bác Hai Trầu cạnh nhà. Bác Hai qua mét mẹ và chuyện đã xảy ra … Tôi mới bước chân về đến cửa, mẹ tìm hoài không thấy roi nên sẵn cây đòn gánh , mẹ phát vào mông tôi mấy cái. Dĩ nhiên là mẹ phát nhẹ thôi vì chiếc đòn gánh thì to bảng mà mông tôi thì nhỏ. Nhưng mà đau thấu trời xanh. Ghê thật là cái vị đòn làm bằng cây tre già ngâm nước! Nó thấm vào thấu bên trong, đau và nhức buốt hơn mọi loại roi nào khác. Tôi chỉ còn cách quỳ xuống đất nức nở mà xin lỗi mẹ vì đau và sợ ăn đòn tiếp . ..
Tối đó, mẹ vừa khóc vừa bôi dầu nhị thiên đường vào mông tôi đã nổi lên mấy vết hằn đỏ. Mẹ dằn vặt mình vì đã giận đánh con. Tôi làm bộ quay mặt vào tường không nhìn mẹ. Tôi giận, mẹ hỏi gì cũng không nói và thiếp đi lúc nào không hay. Khi thức dậy vẫn còn thấy mẹ ngồi chằm chằm nhìn tôi, nghẹn ngào: Mẹ đánh con bậy quá … Nhưng ai bảo con hư …Lúc ấy, với đôi mắt nhạt nhoè, tôi chỉ muốn ôm mẹ mà khóc.Vì hờn, tủi thân hay còn giận mẹ, tôi không biết. Nhưng tôi biết chắc một điều là mẹ yêu thương tôi vô bờ bến!
Chiếc đòn gánh của mẹ, với tôi còn là những kỷ niệm không thể nào quên! Khi tôi đã lớn, nhà nghèo, mẹ hàng ngày trĩu nặng nó trên vai - khi thì gánh phân, gánh gạo đi bán - khi thì gánh nươc , gánh hàng tảo tần nuôi tôi ăn học. Những năm tháng còn là sinh viên, mỗi dịp nghỉ hè về quê, tôi lại ra cầu sông Kênh đón mẹ đi chợ về. Nhưng mẹ giờ đã yếu lắm! Mẹ không còn gánh nặng được nhưng phải cố, vì tôi. Hình hài mẹ nhỏ quắt lại, đôi vai như muốn run lên theo bước chân, môi mắm chặt mỗi lần mẹ cố sức. Duy đôi mắt mẹ thì không hề thay đổi! Đôi mắt vẫn ánh lên niềm hạnh phúc và tự hào nhìn đứa con trai phổng phao, chững chạc sắp trưởng thành. Tôi đứng lặng trên cầu, rơm rớm nhìn vào thân thể và đôi vai gầy guộc của mẹ oằn xuống dưới mỗi bước đi …Tôi muốn lao vào ôm mẹ mình nhưng đã không làm như vậy. Cho mãi đến tận bây giờ, tôi vẫn ân hận trách mình vì điều ấy …
Ngày ấy, mẹ vẫn thường nói vui: Chính nhờ chiếc đòn gánh của mẹ nuôi con ăn học đấy! Mẹ mong khi mẹ không còn đụng đến nó nữa thì con đã trưởng thành …Còn giờ thì vì con - mẹ đâu, nó đó …
… Bây giờ tôi đã thành đạt. Sự nghiệp, công danh đến muộn nhưng cuối cùng cũng đến. Mẹ mừng hơn ai hết. Con Lẻm ông ba tàu bán bánh bò ngoài cổng chợ giờ là vợ sắp cưới của tôi. Ngày tôi lấy vợ, từ dưới quê mẹ lên thăm. Xuống bến xe đón mẹ, tôi thật ngỡ ngàng khi mẹ cứ hi hoáy tìm một vật gì để dưới gầm xe. Tìm mãi, sau cùng mẹ mới lôi được ra cây đòn gánh! Thì ra thói quen, mẹ mua cau trầu mừng đám cưới tôi và cứ nghĩ sẽ đến nhà tôi với đòn gánh trên vai và cặp quang sắt rỉ! Tôi buồn cười và hơi bực bội về sự lẩm cẩm của mẹ. Ai đời lên đến thành phố rồi mà còn đem theo nào quang nào gánh, dáng đi cứ tất bật, lo âu như ngày nào. Ngoài việc mướn xe chở cau trầu, tôi còn phải kêu thêm một chiếc xích lô chở riêng cặp quang và chiếc đòn gánh theo về vì không biết để đâu. Bảy mươi tuổi, có khi mẹ lẩn thẩn rồi cũng nên.Tôi nhủ thầm như vậy …
Mừng đám cưới tôi có mấy ngày, mẹ đòi về nằng nặc. Nhà không ai trông nom, vườn tược, gà heo không ai chăm sóc, mẹ bảo thế! Hầu như đêm nào ở nhà tôi mẹ cũng thức trắng, trằn trọc không ngủ. Mẹ lo những việc không đâu, nào ai biết được. Thỉnh thoảng mẹ lại ngồi dậy, húng hắng ho. Tôi làm sao dỗ giấc ngủ, lo lắng đòi mẹ uống thuốc nhưng mẹ bảo không sao. Me lo chuyện rau mọc nhiều không ai cắt bán, lo gà vịt không ai cho ăn, lo nước trong lu không ai gồng gánh … Đúng mẹ lẩm cẩm thật rồi!
Tôi và con Lẻm mời mẹ ở lại luôn trên thành phố với vợ chồng tôi nhưng mẹ nhất định không chịu. Mẹ ở không quen chốn đông đúc, ồn ào hơn nữa còn phải chăm mộ bà nội, ba con dưới quê, ở lâu làm sao được , mẹ nói cái lý của mẹ. Cái lý của các bà mẹ thì lúc nào cũng thuyết phục được bất kỳ ai trên đời chứ chẳng phải riêng tôi …
Ngày mẹ ra bến xe về quê ngoài quà mừng của vợ chồng tôi gửi bà con lối xóm vẫn là chiếc đòn gánh đã lên nước theo cùng. Nhìn dáng mẹ tất bật, hối hả, lòng tôi trào dâng niềm thương vô bờ bến nhưng biết làm sao giữ mẹ. Đến lúc nầy, mẹ mới móm mém cười, chắc là muốn chúng tôi đừng buồn khi chia tay:
- Đó, con thấy không? Nhờ đem theo đòn gánh mà khi về, mẹ mới mang hết mấy thứ quà con gửi cho lối xóm ... Không có nó, mình mẹ bê sao nổi!
Tôi nhận ra mẹ mình có lý. Một đời mẹ tảo tần đắm đuối vì con với chiếc đòn gánh cùng theo mẹ đi suốt bao năm trời gian khổ mãi cho đến khi con đã trưởng thành vẫn còn mãi lo âu …
Rồi mẹ tôi qua đời! Tuổi già và những căn bệnh triền miên không cho mẹ ở lại cùng tôi mãi. Cuộc chia ly đớn đau cuối cùng rồi cũng đến! Trong nỗi đau mất mẹ, tôi chỉ còn biết lặng người, xót tím tâm can.
Lúc nhập quan, khi người ta đưa hình hài nhỏ bé, khô quắt của mẹ vào quan tài, ngoài những bộ đồ cũ nát mẹ vẫn thường mặc khi còn sống cùng những vật dụng thường dùng, tôi chợt nhớ đến chiếc đòn gánh đã đi theo suốt đời cùng mẹ. Nó vẫn nằm đó, trong góc nhà kia, vẫn ánh lên thứ nước màu đen tuyền với cái thân đòn hình như cong lên vì vất vả. Chợt nghĩ về những ngày ấu thơ gian khổ, chợt nghĩ về tình yêu bao la, thắm thiết của mẹ, tôi trào dâng nước mắt …
Tôi nhớ đến lời mẹ tôi khi còn sống - mẹ đâu thì nó đó - chiếc đòn gánh ấy! Và cố thuyết phục mọi người xin đưa cây đòn theo cùng mẹ sang thế giới bên kia … Ai cũng cản tôi nhưng cuối cùng thì họ xiêu lòng. Vậy là trong quan tài mẹ tôi lại có thêm chiếc đòn gánh đã từng một thời bôn ba cùng mẹ.
Khi mọi người ra về sau lễ tang, còn một mình ngồi bên mộ mẹ, tôi đã khóc như chưa bao giờ được khóc như thế. Rồi cũng sẽ qua hết mọi khổ đau, hạnh phúc, mọi cao sang, quyền quý kể cả những vụn vặt thấp hèn trên đời nầy nhưng tôi biết, hình ảnh mẹ tôi và chiếc đòn gánh nhọc nhằn ngày xưa sẽ theo mãi tôi đến suốt quãng đời còn lại …
**Nguyễn Minh Phúc**

## ️ Cho những ngày giãn cách sẽ sớm qua...

Vì đại dịch Covid, mà cả Thành phố sống trong những ngày rất khác
Những con đường im lìm và vắng vẻ hơn bao giờ
Cả những con đường trong BV lúc này cũng vắng hoe
Khi đêm xuống - chỉ còn ánh sáng hắt từ những cột đèn đường...
...và những phòng bệnh đèn không bao giờ tắt - để người thầy thuốc giành giật từng bệnh nhân khỏi bệnh tật
Và tất cả sẽ cùng nhau cố gắng, 
sẽ cùng nhau yêu thương và nhẫn nại, 
để vượt qua thời khắc khó khăn này
Để một ngày - sẽ lại gặp nhau trong bình an
**_Với những góc chụp của BS Lâm Hoàng Phúc_**

## Thông cảm và tha thứ

Tại một quán ăn ở San Jose, có một cô hầu bàn phụ trách mang thức ăn lên cho chúng tôi, nhìn cô ấy trẻ trung tựa như một chiếc lá non.
Khi cô ấy bê cá hấp lên, đĩa cá bị nghiêng. Nước sốt cá tanh nồng rơi xuống chiếc cặp của tôi đặt trên ghế. Theo bản năng, tôi muốn nhảy dựng lên, nộ khí xung thiên. Thế nhưng, khi tôi chưa kịp làm gì thì đứa con gái yêu của tôi bỗng đứng dậy, nhanh chóng đi tới bên cạnh cô gái hầu bàn, nở một nụ cười dịu dàng tươi tắn, vỗ vào vai của cô bé và nói: “chuyện nhỏ thôi, không sao đâu”.
Cô hầu bàn vô cùng ngạc nhiên, luống cuống kiểm tra chiếc cặp của tôi, nói với giọng lúng túng: “Tôi… để tôi đi lấy khăn lau … ”.
Không thể ngờ rằng, con gái tôi bỗng nói: “Không sao, mang về nhà rửa là sạch thôi. Chị đi làm việc của chị đi, thật mà, không sao đâu.”
Khẩu khí của con gái tôi thật là nhẹ nhàng, cho dù người làm sai là cô hầu bàn.
Tôi trừng mắt nhìn con gái, cảm thấy bản thân mình như một quả khí cầu, bơm đầy khí trong đó, muốn phát nổ nhưng không nổ được, thật là khốn khổ.
Tối hôm đó, sau khi quay trở về khách sạn, lúc hai mẹ con nằm lên giường, nó mới dốc bầu tâm sự…
Con gái tôi phải đi học ở London 3 năm và để huấn luyện tính tự lập cho nó, chồng tôi quyết định không cho nó về nhà vào kỳ nghỉ, anh ấy muốn nó tự lập kế hoạch để đi du lịch, đồng thời cũng muốn nó thử trải nghiệm tự đi làm ở Anh Quốc.
Con gái tôi hoạt bát nhanh nhẹn. Khi ở nhà, mười đầu ngón tay không phải chạm vào nước. Những công việc từ nhỏ tới lớn cũng không đến lượt nó làm. Vậy mà khi rơi vào cuộc sống lạ lẫm tại Anh Quốc, nó lại phải đi làm bồi bàn để thể nghiệm cuộc sống.
Ngày đầu tiên đi làm, nó đã gặp phải rắc rối. Con gái tôi bị điều đến rửa cốc rượu trong nhà bếp. Ở đó có những chiếc cốc thủy tinh cao chân trong suốt, mỏng như cánh ve, chỉ cần dùng một chút lực nhỏ là có thể khiến chiếc cốc bị vỡ, biến thành một đống vụn thủy tinh.
Con gái tôi thận trọng dè dặt, như bước đi trên băng, không dễ dàng gì mà rửa sạch hết một đống lớn cốc rượu. Vừa mới thả lỏng không chú ý, nó nghiêng người một chút, va vào một chiếc cốc, chiếc cốc liền rơi xuống đất, “xoảng, xoảng” liên tục những âm thanh vang lên. Chiếc cốc hoàn toàn biến thành đống thủy tinh vụn lấp lánh trên mặt đất.
“Mẹ ơi, vào thời khắc đó, con có cảm giác bị rơi xuống địa ngục.” giọng nói của con gái tôi vẫn còn đọng lại sự hồi hộp lo lắng.
“Thế nhưng, mẹ có biết người quản lý ca trực đó phản ứng thế nào không? Cô ấy không hề vội vàng mà bình tĩnh đi tới, kéo con lên và nói: “Em gái, em không sao chứ?”
Sau đó, cô ấy quay đầu lại nói với những người khác: “Các bạn mau đến giúp cô gái này dọn dẹp sạch đống thủy tinh nhé!” Đối với con, ngay đến cả nửa câu trách móc cũng không có!”
Lại một lần nữa, khi con rót rượu, không cẩn thận, làm đổ rượu vang nho lên chiếc váy trắng của khách, khiến cho chiếc váy trở nên loang lổ. Cứ tưởng vị khách đó sẽ nổi trận lôi đình, nhưng không ngờ cô ấy lại an ủi con:
“Không sao đâu, rượu ấy mà, không khó giặt.”. Vừa nói, vừa đứng lên, nhẹ nhàng vỗ vào vai con, rồi từ từ đi vào phòng vệ sinh, không nói toang lên, cũng không làm ầm ĩ, khiến con tròn mắt như con chim yến nhỏ vì quá đỗi ngạc nhiên.
Giọng nói của con gái tôi, mang đầy tình cảm: “Mẹ à, bởi vì người khác có thể tha thứ lỗi lầm của con trước đây, nên mẹ hãy coi những người phạm sai lầm kia như con gái của mẹ, mà tha thứ cho họ nhé!”
Lúc này, không khí trở nên tĩnh lặng như màn đêm. Tròng mắt của tôi ướt đẫm lệ…
Tha thứ cho người khác chính là tha thứ cho chính mình. Như tác giả nổi tiếng Andrew Matthews từng viết:
“Bạn tha thứ cho mọi người vì chính lợi ích thân thiết của bạn. Nó sẽ làm cho bạn hạnh phúc hơn.”
____________________
Chúng ta cảm động khi được người khác tha thứ. Điều đó khiến chúng ta có thể thay đổi hành vi và lời nói của chính mình. Hãy để những thiện ý này lưu truyền mãi về sau … như thế, mỗi ngày của chúng ta, sẽ là mỗi ngày hạnh phúc và may mắn!
_**(Sưu tầm)**_

## KHOẢNG TRỐNG...(truyện ngắn)

Vợ của anh đã qua đời được 4 năm, anh vì không có cách nào có thể chăm sóc con, nên cảm thấy chán và mệt mỏi...
Một buổi tối khi anh trở về nhà, vì quá mệt mỏi nên chỉ chào hỏi đứa con ngắn gọn và không muốn ăn cơm, cởi xong bộ comple, liền lên giường nằm.
Đúng lúc đó, ầm một tiếng, bát mì tôm làm bẩn hết chăn và ga trải giường: hóa ra trong chăn có một bát mì tôm.
“Cái thằng này!” Anh ta liền vơ một chiếc móc quần áo chạy ra ngoài đánh cho đứa con trai đang ngồi chơi một trận.
Đứa con trai vừa khóc vừa nói:
- Cơm sáng đã hết rồi, đến tối, con chưa thấy bố về nên đi tìm đồ ăn. Con tìm thấy mì tôm trong tủ bếp, muốn nấu mì tôm ăn, nhưng bố dặn không được tùy tiện dùng bếp gas, nên con lấy nước nóng từ vòi tắm pha mì tôm, con pha một bát ăn, còn một bát để phần bố. Sợ mì tôm nguội nên mang vào giường ủ trong chăn, đợi bố về ăn cho nóng. Con mải chơi đồ chơi mới mượn được của bạn, nên khi bố về đã quên không nói với bố.
Anh không muốn đứa con thấy mình khóc, nên vội vã chạy vào nhà vệ sinh, mở vòi nước và khóc.
Khi đã ổn định tinh thần, anh mở cửa phòng con trai và nhìn thấy con trai trong bộ quần áo ngủ, nước mắt giàn giụa và tay đang cầm bức hình của mẹ nó.
Từ đó trở đi, anh chăm sóc con trai tận tâm hơn, khi con trai mới vào học cấp 1, anh đánh con một trận nữa.
Hôm đó, thầy giáo gọi điện về nhà báo con anh không đi học. Anh lập tức xin nghỉ về nhà, chạy đi tìm con khắp nơi. Sau vài tiếng đồng hồ, anh đến cửa hàng bán văn phòng phẩm và nhìn thấy đứa con đang đứng trước một đồ chơi điện tử. Thế là anh tức giận đánh con. Đứa con không một lời giải thích, chỉ nói: "Con xin lỗi!".
Một năm sau, anh nhận được điện thoại từ bưu điện, nói con trai anh đã bỏ một loạt các bức thư không viết địa chỉ vào hòm thư, cuối năm là lúc bưu điện bận rộn nhất, nên điều này gây ra rất nhiều khó khăn cho họ.
Anh lập tức đến bưu điện, mang những bức thư đó về ném trước mặt con trai nói:
- Sao mày làm những trò tai quái thế này hả?
Thằng bé vừa khóc vừa trả lời:
- Đây là những bức thư con gửi cho mẹ!
Mắt bố cay cay hỏi con:
- Thế sao một lúc gửi nhiều thư vậy?
Đứa con nói:
- Trước đây con còn thấp, không bỏ thư vào hòm thư được, nên con mang gửi hết những bức thư con viết từ trước đến giờ.
Ông bố nghe xong, tâm trạng rối bời không biết nói gì với con. Một lát sau ông bố nói:
- Mẹ con giờ ở trên Thiên đàng, sau này con viết thư xong, hãy đốt nó đi thì có thể gửi thư cho mẹ được đấy.
Đợi đứa con ngủ, anh mở những bức thư đó xem đứa con muốn nói gì với mẹ, trong đó có một bức thư khiến anh vô cùng xúc động.
“Mẹ thân yêu của con: Con nhớ mẹ lắm! Mẹ ơi, hôm nay ở trường con có một tiết mục mẹ cùng con biểu diễn, nhưng vì con không có mẹ, nên con không tham gia, con cũng không cho bố biết, vì sợ bố sẽ nhớ mẹ.
Thế là bố đi khắp nơi tìm con, nhưng con muốn bố nhìn thấy con giống như đang đi chơi, nên con đã cố ý đứng trước một đồ chơi điện tử.
Tuy bố đã mắng con, nhưng con đã kiên quyết không nói cho bố biết vì sao. Mẹ ơi, con ngày nào cũng thấy bố đứng trước ảnh mẹ ngắm rất lâu, con nghĩ bố cũng như con - rất nhớ mẹ đấy!
Mẹ ơi con sắp quên giọng nói mẹ rồi, con xin mẹ trong giấc mơ của con hãy để con được gặp mẹ một lần được không, để con nhìn thấy khuôn mặt của mẹ, nghe thấy giọng nói của mẹ, được không mẹ?
Con nghe mọi người bảo nếu ôm bức ảnh của người mình nhớ vào lòng rồi đi ngủ thì sẽ mơ thấy người đó, nhưng mà mẹ ơi, vì sao con tối nào cũng làm như thế, mà trong giấc mơ của con vẫn không gặp được mẹ?"
Đọc xong bức thư, ông bố òa khóc. Anh không ngừng tự trách mình: phải làm sao mà lấp được khoảng trống người vợ để lại đây?
• Lời bình:
- Chúng ta là những ông bố bà mẹ khi đã mang cuộc sống của đứa con đến với thế giới này có nghĩa là gánh trên vai trách nhiệm vô cùng to lớn.
- Khi đã là một người mẹ, không nên tăng ca quá nhiều, khi đã là một người bố, không nên uống quá nhiều rượu, đừng nên hút nhiều thuốc, phải chăm sóc tốt cho bản thân mới có thể yêu thương con hết lòng, tuyệt đối đừng nên vì muốn kiếm nhiều tiền mà hủy hoại sức khỏe của mình, không có sức khỏe thì những danh lợi kia có nghĩa lý gì.
- Và cũng đừng nghĩ rằng đợi đến khi bố mẹ có nhiều tiền thì sẽ như thế này như thế kia, nào ai biết sau này chuyện gì sẽ xảy ra, có thể sau một giây, mọi chuyện đã khác.
(Nguồn: St)

## THÀNH PHỐ NGÀY ĐI VẮNG

Tan rồi bóng khói
sau đêm hội pháo hoa
thành phố đã biến mất
trên những con đường vắng người,
hoa cháy thầm bên cửa khép
tiếng cười bên xóm mỏng
bàn chân qua ngõ nhón từng lát cong cong,
mỏng cả khói hương bay
mỏng tiếng chim sẻ chim sâu trong sớm mai này
Chợ vắng bóng người quang gánh chiều qua vẫn còn lam lũ qua đây,
nón lá trên tay tát cạn chiều. Và bóng tối đêm giao thừa bắt đầu sóng sánh
người đàn bà gánh thành phố đi về phía hẻm sâu nào?
Sáng nay vắng bặt tiếng rao,
không một ánh mắt lầm lũi,
không một bàn tay cầu xin thui thủi
thành phố trống như một ngôi làng rộng
và dân làng đã ra đồng
gặt hái mùa màng vàng rực ở chân mây
Những quán cóc bên đường ngủ say
không một người phu hồ nào gọi dậy
bằng mớ giọng lưu lạc
từ xa mù từ núi đồi đồng bãi
khói bếp quê nhà buộc dẳng dai vào nắm khói trong ngực trái
có lúc làm thành phố cay xè
sớm nay khói bay về đâu?
Sớm nay thành phố đi đâu
những chật chội ngột ngạt những chen chúc nhàu nát
những bụi ta nghẽn đặc mũi người
những rác ta chồng lấp rác người
những khinh ta vùi dập phận người
Thành phố đi vắng rồi theo bước người dầu dãi
Ta đứng chỗ con đường chiều qua lênh láng hội hè,
chỗ bàn chân ta từng bị giẫm bởi bàn chân người dưng gấp gáp
sớm nay,
ta nhìn thấy đường rơi hơi thở mình rơi
thành phố ơi!
_**(Thơ: Nguyễn Ngọc Tư**_
_**Ảnh: Phạm Anh Dũng)**_

## Đun ấm nước (Truyện ngắn)

Có câu chuyện đun ấm nước như thế này: 
Sư phụ hỏi: “Nếu muốn đun ấm nước nhưng phát hiện củi không đủ, con sẽ làm thế nào?”
Một đệ tử nói: “Con sẽ đi tìm”.
Một đệ tử đáp: “Con đi mượn tạm cho nhanh”.
Một đệ tử khác nói: “Là con, con sẽ đi mua”.
Sư phụ mỉm cười hỏi: “Thế sao các con không đổ bớt nước đi?”. 
Nếu bạn đang mệt mỏi, nghĩa là tham vọng đã nhiều hơn khả năng, khi mà nước nhiều..... hơn củi. Để hạnh phúc, hoặc là phải đi kiếm củi nhiều hơn, hoặc là đổ bớt nước. 
Kiếm củi chưa chắc sẽ có, nhưng nước thì chắc chắn có thể tự đổ bớt được. 
Cha mẹ thường đặt nhiều mong cầu vào con. Thử nhìn lại chính mình xem bản thân mỗi chúng ta có mang trong mình chính mong cầu từ cha mẹ, ông bà mình không? Từ bé chọn trường, lớn chọn nghề, chọn nơi ở, mua nhà hay thậm chí cả… chuyện dựng vợ gả chồng. Và đến lượt ta, ta mong cầu con giỏi giang, thành đạt, nhiều khi là ý ta, không phải ý con… 
Thực ra, người đi trước có kinh nghiệm, hướng con cái là cái tốt và đúng đắn. Những động viên khích lệ thậm chí đôi chút kỳ vọng, định hướng có mục đích giúp cho con cái thấy đích đến, đường hướng phấn đấu. Tuy nhiên, nếu sự định hướng không dựa trên khả năng năng lực của chính đứa trẻ thì đôi khi sau này chúng cũng gặp những bất hạnh trên con đường đi tìm chính mình. 
Không phải ai cũng đủ dũng cảm lựa chọn BỚT MONG CẦU để giảm áp lực lên con, cũng như khiến bản thân mình được nghỉ ngơi. Đặt mục tiêu vừa sức, thành tích học tập chọn mức phấn đấu đủ để các con nỗ lực, nếu thất bại thì đó là bài học. Với các trẻ nhỏ, sự mong cầu và kỳ vọng cũng cần lưu ý qua lời nói, hành động và lựa chọn. Mong cầu nhiều, đến khi mọi việc không như ý muốn, sẽ khiến bản thân cha mẹ nóng giận, mệt mỏi, đứa con cũng sẽ chịu đủ thứ áp lực. Cha mẹ và con cái một ngày đều không cảm thấy hạnh phúc. Đó chính là lúc hãy dừng lại, bỏ bớt mong cầu, bởi vì BIẾT ĐỦ sẽ HẠNH PHÚC.
Chúng ta vẫn biết có lúc mình mệt mỏi, không đủ sức để hoàn thành những mục tiêu, kế hoạch?
Nhưng liệu có phải ai cũng dũng cảm lựa chọn BUÔNG BỎ để cho cơ thể mình được nghỉ ngơi.
Đừng cố để rồi như ấm nước kia, nước nhiều - lửa ít nên mãi không thể sôi.
Cuộc sống là của bạn, lựa chọn là do bạn!
**_“Hạnh phúc là một sự chọn lựa, không phải là kết quả. Không có điều gì có thể khiến bạn hạnh phúc cho đến khi bạn chọn để có được hạnh phúc. Không ai có thể làm cho bạn hạnh phúc, chỉ có bạn chọn hạnh phúc. Hạnh phúc của bạn không đến từ bên ngoài, mà chỉ có thể đến từ bên trong”._**
(Sưu tầm)

## Còn gì để mang theo...

Con người ta hình như đến một tuổi nào đó sẽ ngộ ra rằng cuộc đời thật ra chẳng có gì quan trọng. Cuối cùng rồi như nhau cả. Bạn có thể có một cuộc đời sung sướng, hạnh phúc hay bạn đã phải lầm than, nghèo túng, khổ đau. Cuối con đường có khác gì nhau đâu. Lúc xuôi tay, quân vương hay kẻ cơ hàn đều là sự giã biệt. Có thể có kẻ sẽ có tiền hô hậu ủng, kèn trống vang trời. Có người bó trong chiếc chiếu rách đi giữa mưa rơi. Nhưng cả hai đều chẳng còn biết gì, tất cả đều đang làm cho người sống.
Đến một tuổi nào đó, người ra sẽ nghiệm thấy rằng cuộc đời chỉ là con số không to tướng. Sinh ra, lớn lên, già đi rồi mất hút. Mọi thứ danh vọng chỉ là trò hư ảo. Mọi thứ của cải làm ra cũng chỉ là thứ phù phiếm có rồi mất. Mọi thứ hoan lạc hay khổ ải cũng chỉ là gia vị của cuộc đời. Sinh ra thì phải sống, phải chiến đấu để tồn tại, phải khát vọng để vươn lên. Thế rồi, khi tuổi già đã tới, những bi kịch của tàn phai tác động đến mỗi người, sẽ thấy hoá ra mình đã bỏ cả tuổi thanh xuân để chạy theo toàn những thứ ảo vọng. Tranh dành nhau cái danh, lấn lướt nhau đoạt lợi. Được danh lợi rồi lại tham vọng nhiều hơn, lớn hơn. Cuối cùng cũng chỉ là một cuộc chơi, để rồi trắng tay lúc trở về cát bụi.
Đến một thời điểm nào đó của cuộc sống, nhìn lại đoạn đường ta đã đi, ta phát hiện ta chỉ để lại lắm điều lầm lỗi. Lầm lỗi với cha mẹ, với những người thân yêu. Lầm lỗi với bạn bè, với xã hội. Lầm lỗi với những người ta đã gặp, những người đã đi qua đời ta. Tất cả đều do cái tôi quá lớn của mỗi người. Không biết quên mình mà chỉ sống cho mình. Do vậy, những suy nghĩ và hành động ích kỷ cứ mãi quẩn quanh để đưa đến lỗi lầm tiếp nối nhau.
Sống đến tuổi nào đó, người ta mới hiểu được rằng tự thắng được mình mới là điều quan trọng. Tuổi trẻ háo thắng chỉ chăm chăm thắng người, hơn người. Cảm thấy tự mãn và sung sướng trong thắng lợi. Có biết đâu rằng cái thắng lợi mình có là cái thất bại và đớn đau cho người khác. Đâu có biết rằng chính cái thắng lợi ấy là chiếc bẫy tiếp theo của cuộc đời mình. Trong mọi hoàn cảnh, tự thắng chính mình là điều khó nhất. Làm được điều đó là ta đã có thể tự hào.
Đến một tuổi nào đó, người ta mới hiểu được rằng lắng nghe mới là điều cần thiết. Biết lắng nghe là biết thu thập cả thế giới cho riêng mình. Biết lắng nghe thì mới phân biệt được phải trái phân minh. Biết lắng nghe thì mới có chia sẻ. Muốn lắng nghe thì phải học im lặng. Con người ta chỉ mất vài năm để học nói, nhưng mất cả đời để học im lặng. Im lặng để lắng nghe. Không chỉ lắng nghe ngôn ngữ của con người, ta phải tập lắng nghe tiếng của thiên nhiên, tiếng của cỏ cây, giun dế, của gió, của nắng, của mưa bão. Tiếng sóng vỗ, tiếng chim kêu đều mang lại cho ta những cảm xúc của cuộc đời. Thiếu chúng nó, cuộc đời chỉ là khoảng trống vô vị.
Tới một tuổi nào đó, con người nên đến với thế nhân bằng những nụ cười. Hãy cười với nhau bằng tâm hồn mở tất cả các cửa, với tấm lòng thân thiện. Hãy chào nhau dù chỉ gặp một lần vì biết đâu ngày mai không còn cơ hội để gặp, không còn dịp để gởi nhau nụ cười. Sinh tử là ranh giới mỏng manh. Đời vốn vô thường. Già sẽ đưa đến tật bệnh, bệnh làm cho người ta héo úa, đau đớn khó chịu. Nếu lạc quan và trang bị nụ cười với mọi người, nỗi đau sẽ giảm đi, héo úa sẽ bớt đi, nụ cười chính là son phấn trang điểm cho tuổi già.
Đến một tuổi nào đó, con người sẽ hiểu được rằng điều cơ bản của con người là sự cô đơn. Con người sinh ra một mình và mất đi cũng chỉ một mình. Không ai sống thay ta và cũng chẳng ai chết thay ta. Gia đình, chồng vợ, con cái, bạn bè đều là người thân đấy, nhưng mỗi người có một cuộc sống, mỗi người có mỗi số phận và định mệnh riêng. Do vậy, mỗi người phải tự quyết định đời mình, không chờ đợi một ai có thể thay mình. Trong hành trình sống, con người là một thực thể cô độc, không ai hoán đổi được. Tới tuổi già chính là lúc gặm nhấm nỗi cô đơn nhiều nhất.
Tới một lúc nào đó, người ta hiểu được là sống là để làm cho đủ bốn bổn phận đối với cuộc đời. Bổn phận với quá khứ là trả hiếu với mẹ cha. Bổn phận với tương lai là nuôi dạy con cái. Bổn phận với cuộc sống là giúp đỡ kẻ hoạn nạn, yêu thương mọi người và cuối cùng là bổn phận lấp đầy đời mình bằng tiêu pha, sinh hoạt hàng ngày. Con người làm ra tiền dù ít hay nhiều cũng chỉ quẩn quanh từng đó bổn phận. Có kẻ làm không đủ thì là thiếu trách nhiệm. Thế cho nên làm người là làm tròn bổn phận. Tới tuổi già, làm xong bổn phận ta có thể ung dung để hưởng những ngày còn lại trong sự thanh thản.
Đến một lúc nào đó người ta sẽ có những nuối tiếc. Tiếc vì chưa làm được những điều muốn làm, chưa đến được những nơi muốn đến. Quỹ thời gian không còn, chuyến tàu sầm sập đến hoàng hôn. Chợt giật mình thời gian quá ngắn. Bởi thế nên muốn làm gì thì làm ngay, muốn đi đâu thì đừng lần lửa. Có ước muốn thì hãy thực hiện, kể cả việc trả thù một ai đó. Nhưng mà nếu tha thứ được thì nên tha thứ, nếu quên được thì nên quên.
Sống tập quên cái cần quên cũng là một thứ thuốc chữa tâm hồn. Nhớ nhiều chỉ vác nặng. Sống mà mang nặng quá chỉ khổ thân.
**Đỗ Duy Ngọc**

## Còn thời cưỡi ngựa bắn cung (Sách: Nếu biết trăm năm là hữu hạn)

**Dự án "Khu vườn tâm hồn" đồng hành cùng Hear &Heal**

## Sẽ cùng nhau chiến thắng đại dịch

**Sưu tầm từ nhiều nguồn**

## Chốn trú ẩn thanh bình

Dự án "Khu vườn tâm hồn" đồng hành cùng Hear&Heal
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh

## Không oán trách (truyện ngắn)

Tại một thành phố của nước Mỹ, có một vị khách trung niên bắt taxi đến sân bay.
Sau khi lên xe, vị này phát hiện ra chiếc xe mà mình đang đi không chỉ có vẻ ngoài bắt mắt mà bố trí trong xe cũng rất ngăn nắp, trang nhã. Tài xế ăn mặc rất chỉnh tề, lịch sự. Khi xe vừa chạy, ông ấy liền nhiệt tình hỏi hành khách xem độ ấm trong xe đã thích hợp chưa? Không lâu sau, ông lại hỏi hành khách muốn nghe nhạc hay radio? Hành khách lựa chọn nghe nhạc và một đoạn hành trình thoải mái của hai người bắt đầu.
Khi xe dừng trước một đèn đỏ, lái xe quay đầu lại và bảo cho vị khách biết trên xe có tờ báo buổi sáng và tạp chí định kỳ. Ngoài ra, phía trước còn có một tủ lạnh nhỏ, trong tủ lạnh có nước trái cây và cocacola, hành khách có thể tự lấy dùng, nếu muốn uống cà phê, bên cạnh cũng có bình thủy chứa cafe nóng.
- -
Người tài xế mở lời:
- “Tôi là một người dễ nói chuyện, nếu anh muốn nói chuyện phiếm thì tôi có thể nói cùng anh. Nếu anh muốn nghỉ ngơi hoặc ngắm phong cảnh, tôi sẽ yên lặng lái xe, không quấy rầy anh.”
Sự phục vụ đặc biệt này khiến vị khách thực sự ngạc nhiên, anh không khỏi nhìn vị tài xế thắc mắc, khó hiểu. Vị khách cất lời hỏi:
- “Từ bao giờ anh bắt đầu sự phục vụ này vậy?”
Trầm mặc một lát, vị tài xế nói:
- “Thực ra, khi mới bắt đầu, xe của tôi cũng không có cung cấp dịch vụ toàn diện như bây giờ. Tôi cũng chỉ giống những người khác, hay phàn nàn, thường xuyên càu nhàu khách, phàn nàn chính phủ bất tài, phàn nàn tình hình giao thông không tốt, phàn nàn xăng quá đắt đỏ, phàn nàn con cái không nghe lời, phàn nàn vợ không hiền thục… cuộc sống mỗi ngày quả thực là ảm đạm.
Nhưng một lần, tôi vô tình nghe được một cuộc đàm thoại về cuộc sống trong một tiết mục quảng cáo. Đại ý là nếu bạn muốn thay đổi thế giới, thay đổi cuộc sống của bạn, đầu tiên hãy thay đổi chính mình.
- Nếu bạn cảm thấy luôn không vừa lòng thì tất cả những chuyện phát sinh đều khiến bạn cảm thấy như gặp xui xẻo.
- Trái lại nếu bạn cảm thấy hôm nay là một ngày may mắn, như vậy hôm nay mỗi người bạn gặp phải, đều có thể là quý nhân của bạn.
Cho nên tôi tin rằng, nếu tôi muốn vui vẻ, phải thôi phàn nàn, phải thay đổi chính mình. Từ thời khắc đó, tôi quyết định sẽ đối xử tử tế với mỗi hành khách của mình.
Năm thứ nhất, tôi sửa sang xe trong ngoài sạch sẽ, trang trí mới hoàn toàn. Tôi luôn nở nụ cười với mỗi hành khách, kết quả là thu nhập năm đó của tôi tăng lên gấp đôi.
Năm thứ hai, tôi dùng lòng chân thành của mình để quan tâm chia sẻ niềm vui cũng như nỗi buồn của khách hàng. Đồng thời tôi cũng khoan dung và thăm hỏi khách hàng nhiều hơn. Thu nhập năm thứ hai của tôi tăng gấp đôi năm thứ nhất.
Đến năm thứ ba, cũng chính là năm nay tôi đã biến chiếc xe của mình thành một chiếc xe “5 sao” độc nhất này. Ngoài thu nhập tăng lên, hiện tại khách hàng mà tôi chở phần lớn đều là khách quen.
Đến nơi, tài xế xuống xe, ra phía sau giúp hành khách mở cửa, cũng đưa một tấm danh thiếp đẹp, nói:
-“Mong lần sau có thể tiếp tục phục vụ anh.”
Việc làm ăn của anh tài xế không hề bị ảnh hưởng khi nền kinh tế trở nên đình trệ. Anh đã thay đổi, không chỉ sáng tạo ra một nguồn thu nhập tốt, mà còn tạo nên một cuộc sống bình yên như vậy.
Trong cuộc sống hàng ngày, chúng ta thường gặp phải không ít người luôn mang trong lòng tâm oán trách. Họ oán trách cha mẹ không công bằng, oán trách công việc quá nhiều, oán trách bạn bè không hiểu mình, thậm chí trời mưa hay trời nắng cũng oán trách…
Họ không biết được rằng, oán trách là một loại cảm xúc xấu nhất khiến mối quan hệ căng thẳng và mâu thuẫn trở nên kịch liệt hơn. Nó không chỉ khiến cho sức khỏe của chính bản thân người ấy xấu đi mà còn khiến người thân bạn bè dần dần xa lánh họ.
Trong cuốn “A Complaint Free World” (Thế giới không có lời phàn nàn) có đoạn viết rằng: " Những người phàn nàn quanh năm cuối cùng có thể bị cô lập và bị mọi người xung quanh xa lánh. Oán giận là một loại độc dược. Nó có thể làm giảm nhiệt huyết, phá hủy ý chí, hạ thấp địa vị, hủy hoại cả tâm và thân của con người. Cho nên, oán trách vận mệnh chi bằng hãy cải biến vận mệnh, oán trách cuộc sống chi bằng hãy cải thiện cuộc sống"
- - -
Sưu tầm.

## Bạn tôi

Đang dừng đèn đỏ tôi chợt giật mình khi có tiếng vỗ bồm bộp vào cửa kính. Chưa kịp cau mày khó chịu thì một cái mặt đầy nếp nhăn ghé vào. Cái mặt khá đen bộ răng vàng khè nhưng ánh mắt thì lại lấp lánh và thân thiện. Ánh mắt thân quen của cậu bạn tôi ngày nào.
- Này mở cửa tao gửi cho cháu mấy quả bóng bay.
Tự dưng mắt tôi cay xè. Bạn tôi đó - nhìn nó vất vả như thế nhưng sự thơm thảo của tấm lòng thì bao người không bằng được. Tôi liền bảo:
- Sang cái quán chỗ kia. Có chỗ đỗ xe nói chuyện tí.
Nó ngồi trước mặt tôi. Mặt già nua khắc khổ, da đen sạm do đày ải cả ngày. Trời lạnh cái Áo khoác cũ bong cả chỉ. Vậy mà mồm thì liên tục líu lo.
- Lâu lắm không gặp mày. Hai đứa nhỏ lớn lắm rồi nhỉ. Chúng nó thích màu gì? Con lớn nhà mày thích màu tím. Tí nhét vào xe tao sẽ bọc ni lông không sẽ bục đâu.
Bạn tôi nó vẫn tốt như thế. Nó nhớ đến cả màu ưa thích của con gái tôi. Chân thật đến như thế. Nó vẫn nghèo đến như thế.
Nhưng nó vẫn hạnh phúc với cuộc sống của nó. Hoàn toàn hài lòng và không hề tính toán. Nó rộng rãi sởi lởi, một thời tuổi thơ tôi đã gắn bó cùng nó. Cùng bắt châu chấu, vớt rươi trên đồng làng. Cùng tắm sông, cưỡi trâu, đá bóng, săn chuột. Cùng nhau nướng ngô khoai, tôm cá trong những ngày giá lạnh. Gặp nó làm nhớ mùi quê, mùi khói đồng đến nao lòng. Nó học kém. Nó bảo chữ nghĩa nó không thích tao. Và tao cũng không thích nó. Tao chỉ thích tự do và làm điều mình thích. Học thì kém nhưng nó cực khéo tay. Nó đặt bẫy là chuột dính. Bẫy mèo cũng dính luôn. Có những bữa no và ngon ngày xưa phần nào cũng nhờ nó. Nhiều khi chỉ mấy củ xu hào mấy quả khế vài con tép với ít rau thơm. Là nó làm được đĩa nộm ngon mát đến ấm lòng. Đi chăn trâu bơi sang Vĩnh Bảo bị bọn trẻ bên ấy chặn đánh. Nó dũng mãnh như chiến binh bảo vệ hết bạn bè. Vậy mà cuộc sống không chiều nó. Lớn lên nó lấy vợ. Cái con vợ mà gặp bạn chồng mà cứ đầu mắt cuối mắt đong đưa. Nhìn là biết loại không ra gì rồi. Định góp ý thẳng thì thấy nó đang vui đang hạnh phúc. Nên không nỡ đành thôi. Quả nhiên sau một thời gian thì vợ nó theo trai bỏ con cho nó nuôi. Sau này nó lấy thêm cô vợ mới. Thì luôn ốm đau quặt quẹo. Nó chăm chỉ làm đủ nghề kiếm tiền.
Bán hàng rong, giao giấy vệ sinh... Nói chung cứ nghề gì ra tiền là nó làm. Gần Tết nó hay đi bán bóng bay. Bán những thứ bay bổng và màu sắc sặc sỡ trái ngược với cuộc sống vất vả của nó. Vậy mà nó luôn vui cười. Chỉ bạn bè nhìn nó đầy thông cảm và chia xẻ. Chả hiểu nó có suy nghĩ nó có biết là mình khổ không nữa. Mà gặp người quen là hồ hởi cho bóng bay ngay.
Vẫn toe toét cười như hạnh phúc lắm. Không rượu chè, cờ bạc. Thú vui của nó là đi làm về là chơi với con chó bắt chấy bắt rận cho nó trong gian nhà trọ chật chội.
Nó yêu chó từ bé. Chăm nuôi chó giỏi và chó rất khôn.
Tôi nhớ có lần tôi với nó đánh nhau với trẻ xóm trong. Hai thằng bị quây đánh tối tăm mặt mũi. Con chó nhà nó lao thẳng vào bọn trẻ xóm trong cắn xé loạn lên cứu cả hai đứa khỏi nhừ đòn. Sau vụ ấy hai đứa hì hục đi tát cá về nướng cho chó ăn để trả công cứu chủ.
Giờ nó ngồi trước mặt tôi vẫn mồm năm miệng mười.
- Hôm qua ngày nghỉ tao bán khá. Mày tin là bán bóng bay lãi tiền triệu một ngày không? Ngon ăn tao lấy thêm buộc mới. Vừa về thì bị bọn ghen ăn tức ở lừa cắt dây. Cả buộc bay lên trời. Phí thật.
Tôi hỏi.
- Mày vẫn nuôi chó đấy chứ?
Mặt nó chùng xuống.
- Mới bị bọn trộm chó bắt mất rồi. Con Ki nhà tao khôn lắm. Không bả được. Chúng nó dùng súng điện bắn trộm rồi bắt nó đi rồi. Thôi cũng là số kiếp nó. Tao nghèo khó chúng mày vẫn quan tâm vẫn coi tao là bạn là tao vui rồi.
Tôi rút ví lấy tiền ấn vào tay nó.
- Tao mua bóng bay. Mày có làm ra đâu. Tao mua cả số mà bị cắt bay đi mất.
Mặt nó đột nhiên méo xệch. Nước mắt trào ra. Tôi với nó nắm chặt tay. Hai thằng đàn ông mà đều khóc.
**Tác giả: Đinh Ba**

## THƯƠNG MÀU ÁO TRẮNG

Từ đâu tôi yêu màu trắng!
Màu áo lương tri từ những ngàn xưa 
Và tôi thương những buổi trưa 
Ai vội vã bữa cơm chưa tròn bụng 
Tôi từng nghĩ đời bác sĩ ung dung 
Áo blouse trắng sáng ngời tinh khiết 
Tôi nào đâu biết... 
Những bộn bề, trách nhiệm nặng vai 
Có những đêm trằn trọc suốt canh dài 
Sợ chợp mắt không kịp giờ cấp cứu 
Và hôm nay các anh đâu được ngủ 
Covid hoành hành đất nước đủ đau thương 
Vì an dân các anh phải lên đường 
Ngày hay đêm đâu còn phân định nữa 
Và xót lắm khi con còn mùi sữa 
Tiếng trẻ thơ nức nở giữa đêm hè 
Ôi xé lòng nhưng mẹ phải xa con 
Chọn hy sinh cho đất nước vẹn tròn 
"Y đức" tiếng vàng mẹ giữ sắt son 
Và ngày mai covid sẽ chẳng còn 
Có bảng son nào ghi danh công trạng! 
Nhưng trên môi nụ cười vẫn rạng 
Đã dốc hết lòng vì tính mạng người dân 
Và từ đây tôi yêu mến muôn phần 
Chiếc áo trắng cho người biết dấn thân 
Chiếc áo trắng chưa bao giờ chọn nghỉ 
Chiếc áo sáng ngời bền bỉ với thời gian 
Cầu cho ai mặc chiếc áo son vàng 
Sẽ bình an qua bao mùa dịch 
Và dù cho đổi bao mùa lịch 
Vẫn rạng ngời y đức tích trong tâm!
Huỳnh Cát Dung

## ️ Nâng cao sức khoẻ tinh thần trong mùa dịch (tài liệu)

"Dịch COVID-19 đang là một trong những vấn đề mang tính toàn cầu, tạo ra bầu không khí lo ngại ở nhiều nơi và trong nhiều lĩnh vực của đời sống. Nó không chỉ gây ra tổn thất về mặt sức khỏe thể chất mà còn ẩn chứa những tác động không nhỏ đến tinh thần mỗi cá nhân.
EdLab Asia phối hợp cùng Microsoft Việt Nam biên soạn và phổ biến “Sổ tay Nâng cao sức khoẻ tinh thần trong mùa dịch” nhằm giúp cho quý thầy cô giáo, quý vị phụ huynh và các bạn học sinh có thể bổ sung thêm các kiến thức thường thức về tâm lý học. 
Chúng tôi hi vọng ấn phẩm này sẽ giúp quý vị tự thân, và có thể giúp đỡ người khác nâng cao sức khoẻ tinh thần và cải thiện hiệu suất làm việc, học tập của bản thân.”
(Lời giới thiệu)
**Một số yếu tố nguy cơ đối với sức khỏe tinh thần trong mùa dịch Covid-19**
● Liên tục tiếp xúc với các thông tin tiêu cực 
● Nguy cơ bản thân hay người thân bị lây nhiễm bệnh 
● Chứng kiến các trường hợp nhiễm, hay nghi nhiễm gần nơi mình sống 
● Thiếu tương tác với người khác 
● Thay đổi lịch trình sinh hoạt 
● Không được đến trường lớp, nơi làm việc 
● Thiếu hoặc mất các hoạt động thể chất thường ngày 
● Không thể thực hiện các hoạt động yêu thích hay thói quen 
● Nguy cơ bị kỳ thị vì nghi nhiễm bệnh
...Tất cả chúng ta đều sẽ có lúc rơi vào tình trạng stress khi phải đối mặt với những khó khăn, thử thách, nguy hiểm trong cuộc sống. Đó có thể là khó khăn về học tập, công việc, tài chính, các mối quan hệ xã hội, hay về sức khỏe như tình hình dịch bệnh hiện nay. Những khó khăn này là cơ hội để chúng ta trưởng thành nếu như có thể ứng phó một cách hiệu quả, nhưng chúng cũng tiềm ẩn nhiều nguy cơ đối với sức khỏe thể chất và tinh thần nếu chúng ta chưa chuẩn bị kỹ cho mình những cách thức phản ứng phù hợp. Đứng trước một khó khăn gây stress, nghiên cứu chỉ ra rằng chúng ta có thể sử dụng một hay nhiều chiến lược ứng phó trong số 10 chiến lược ứng phó sau đây nhằm giải quyết vấn đề hoặc làm giảm tình trạng stress: 
**1. Giải quyết vấn đề:** Cố gắng nghĩ ra cách giải quyết, hỏi xin ý kiến và sự trợ giúp từ người khác, hay hành động để giải quyết vấn đề. 
**2. Điều hòa cảm xúc:** Cố gắng kiểm soát cảm xúc của mình, lấy lại bình tĩnh (hít thở, nghe nhạc, đi dạo, v.v.), kiềm chế và giải tỏa cảm xúc vào lúc thích hợp.
**3. Bộc lộ cảm xúc:** Giải tỏa cảm xúc của mình bằng cách chia sẻ, giải tỏa cảm xúc bằng hoạt động yêu thích, tìm kiếm sự cảm thông, thấu hiểu, và ủng hộ. 
**4. Chấp nhận:** Chấp nhận bản thân mình, học cách chấp nhận cuộc sống, chấp nhận mọi chuyện diễn ra theo cách của nó.
**5. Sao nhãng:** Tạm thời nghĩ sang chuyện vui vẻ, chuyển sự chú ý sang hoạt động khác (chơi thể thao, dọn dẹp), tạm thời tưởng tượng ra điều gì đó vui vẻ, thú vị. 
**6. Thay đổi nhận thức:** Tự nhủ rằng mọi chuyện đã có thể tệ hơn, hoặc chuyện này không có gì to tát, hay mọi chuyện cũng không quá tệ. 
**7. Suy nghĩ tích cực:** Tự nhủ rằng mình có thể vượt qua, rằng mọi chuyện sẽ tốt đẹp hơn thôi, tự nhủ rằng mình cũng học được điều gì đó.
**8. Chối bỏ:** Hành động như thể vấn đề chưa từng xảy ra, tự thuyết phục rằng chuyện này không có thật, cố gắng tin rằng vấn đề chưa từng xảy ra.
**9. Né tránh:** Cố gắng không cảm thấy những cảm xúc tiêu cực, cố gắng quên đi vấn đề, tránh xa những gì liên quan đến vấn đề.
**10. Mong ước:** Ước bản thân đã mạnh mẽ, mong rằng vấn đề sẽ tự động qua đi, ước rằng ai đó xuất hiện giúp mình...
Nghiên cứu chỉ ra rằng trong những trường hợp mà vấn đề không thể giải quyết được nữa, **việc cố gắng thay đổi nó chỉ càng làm tình trạng stress của chúng ta trở nên trầm trọng hơn**. Thay vào đó, hãy học cách chấp nhận, thay đổi nhận thức, và suy nghĩ theo hướng tích cực đối với sự việc. Bên cạnh đó, bộc lộ và chia sẻ cảm xúc với một ai đó sẵn lòng lẵng nghe cũng là một bước cần thiết để những thất vọng, buồn chán, hay uất ức đã dồn nén trong lòng được vơi bớt. 
Trường hợp vấn đề của bạn vẫn có thể cải thiện, dù phải bằng rất nhiều nỗ lực, hãy thử trả lời câu hỏi sau: Liệu bạn có đang ở trong trạng thái cơ thể khá khỏe mạnh, tinh thần tỉnh táo, và cảm xúc ổn định? Nếu câu trả lời là có, có vẻ như bạn đã **sẵn sàng để giải quyết vấn đề của mình rồi.**
Còn nếu không, có lẽ bạn cần cho phép bản thân mình nghỉ ngơi đôi chút để lấy lại trạng thái cơ thể ổn định, và tinh thần thư thái trước khi bắt tay vào giải quyết vấn đề. Hãy dành thời gian để giải tỏa những cảm xúc tiêu cực, tham gia vào những hoạt động mà mình yêu thích, hoặc suy nghĩ một cách tích cực hơn, và nhìn vấn đề ở một khía cạnh khác đi. Những bước chuẩn bị này chắc chắn sẽ giúp bạn làm tốt khi nỗ lực để giải quyết vấn đề. 
Nghiên cứu cho thấy việc áp dụng các chiến lược ứng phó theo những gợi ý trên đây sẽ đem giúp làm giảm stress, nâng cao hiệu suất công việc hay học tập. Ngược lại, việc ứng phó bằng cách**né tránh, chối bỏ, hay mong ước thường không phải là chiến lược khôn ngoan** vì nó làm tăng mức độ stress và làm suy giảm hiệu quả công việc
(Trích từ tài liệu)
Xin trải nghiệm toàn bộ tài liệu bổ ích này [tại đây](https://drive.google.com/file/d/1CGznXIba3jFOVDbgjKVQ9eOS6L64AoSL/view?usp=sharing)
**Và hãy cùng nhau vượt qua một mùa dịch theo cách bình an và ít tổn hại nhất có thể!**
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh

## Sức mạnh của tình yêu thương

.... Karen khi biết mình có thai, đã chuẩn bị tâm lý cho con trai Michael. 
Biết mình sắp có em gái, tuy mới 3 tuổi nhưng Michael cứ áp đầu vào bụng mẹ, hát cho em nghe hàng ngày. 
Thai kỳ diễn ra thật bình thường đối với Karen, một thành viên năng động của tổ chức từ thiện ở Morristown, Bang Tennessee. Bỗng những cơn đau chuyển dạ bắt đầu, năm phút một lần và rồi mỗi phút. Chuyển dạ hàng giờ nhưng Karen vẫn chưa sinh được...
Cuối cùng rồi em gái bé nhỏ của Michael cũng chào đời, nhưng bé lại ở trong tình trạng nguy kịch. Còi hú liên hồi, xe cấp cứu xé màn đêm khẩn cấp chuyển bé về trung tâm chăm sóc đặc biệt của bệnh viện St. Mary’s Hospital, Knoxville, Tennessee.
Thời gian như ngừng trôi. 
Bệnh tình của bé ngày càng trầm trọng. Chính các bác sĩ cũng trực tiếp nói chuyện với vợ chồng Karen: - Hy vọng mong manh lắm, gia đình nên chuẩn bị tinh thần cho tình trạng xấu nhất. Karen và chồng đã liên lạc với nghĩa trang địa phương để lo hậu sự cho con.
Mới hôm qua họ còn sửa chữa, trang hoàng phòng riêng cho con gái, vậy mà giờ đây họ phải lên kế hoạch làm đám tang cho con.
Michael vẫn vô tư nài nỉ bố mẹ cho mình vào bệnh viện thăm em, “Con muốn hát cho em nghe”. 
Cứ ngỡ là bé sẽ ra đi sau khi chào đời. May mắn sao, một tuần đã qua đi. Mọi người lo lắng bước vào tuần thứ hai. 
Michael vẫn kèo nài xin được hát cho em, nhưng trẻ con không được phép vào phòng chăm sóc đặt biệt. Karen quyết định sẽ dẫn con vào, cho dù y bác sĩ bệnh viện có tán thành hay không. Không cho con gặp em bây giờ thì có thể sẽ chẳng bao giờ nó gặp được đứa em nó đã hát cho nghe từ khi còn nằm trong bụng mẹ. 
Mặc cho Michael một bộ đồ khá rộng, Karen dẫn con vào phòng chăm sóc đặc biệt. Nhìn Michael cứ như cái giỏ đựng quần áo biết đi. Bất ngờ, hai mẹ con đụng đầu với cô y tá trưởng ngay cửa phòng:
-Trẻ con không được vào đây. Dẫn nó ra ngoài. 
Người mẹ trong Karen choàng tỉnh. Người phụ nữ thường ngày vốn hòa nhã, nhìn người y tá trưởng với ánh mắt lạnh như thép, miệng đanh lại : 
- Thằng bé chẳng phải đi đâu cho đến khi nó hát cho em nó nghe xong. 
Karen kéo Michael đến giường bệnh của em nó. Một giọng trong trẻo, tràn đầy tình thương yêu cất lên, Michael hát: 
- Em là ánh nắng, là tia nắng duy nhất của anh. Dù bầu trời toàn mây đen, em vẫn làm cho anh cảm thấy hạnh phúc… 
Ngay lập tức, bé gái có phản ứng, mạch đập đều đặn dần. Michael vẫn hát : 
- Em không biết rằng anh thương em biết dường nào. Xin đừng mang ánh nắng đi… Hơi thở rối loạn giờ đã nhẹ nhàng, đều đặn. Michael vẫn hát. 
- Cưng ơi, đêm nọ khi nằm ngủ, anh mơ thấy mình ôm em… 
Khuôn mặt em gái của Micheal bỗng trở nên thanh thản như đang ngủ. Karen ngạc nhiên và vui mừng không tả. 
Nước mắt ướt đẫm khuôn mặt người y tá trưởng. Michael vẫn hát: 
- Em là ánh nắng, là tia nắng duy nhất của anh. Xin đừng mang ánh nắng của anh đi… 
Kế hoạch chuẩn bị đám tang bị “đập tan”. Ngày hôm sau và ngày hôm sau nữa… rất nhanh, cô bé hồi phục và được về nhà... 
Tạp chí Phụ nữ đã đặt tên cho câu chuyện cảm động này là “Phép màu từ bài hát của người anh trai”. 
Ngay cả y bác sĩ, những người làm khoa học cũng gọi đó là “Phép màu”. 
Đừng bao giờ “buông tay” trong cuộc chiến giành lại những người mình yêu thương...!

## Chiếc giường của má

Má bị bệnh đau lưng, ngồi xuống đứng lên khó khăn, đi lại khom khom. Ngày đầu cậu Út chở má đi đến bệnh viện huyện. Bác sĩ khám đủ kiểu, cuối cùng mới dẫn má đi chụp X-quang, xong rồi đưa lên ánh sáng nhìn, kết luận: “Bệnh gai đôi cột sống, đốt thứ 4, thứ 5. Thoái hoá cột sống nhiều”. Bác sĩ kê toa, mua cả tháng thuốc về nhà uống, nhưng có điều vừa hết thuốc là đau trở lại. 
Có người khuyên nên uống thuốc bắc. Cậu Út nghe lời, chở má tới thầy lang. Thầy lang cầm tay má đăm chiêu bắt mạch, đo huyết áp, bán cho một tháng thuốc cầm về, căn dặn: “Sắc thuốc trong om đất, ba chén nước còn lại tám phân. Hết thuốc, quay lại...”. Thú thật, qua mấy tháng uống thuốc bắc má ăn được, ngủ được, da dẻ hồng hào, sức khỏe tốt hơn. Song cái bệnh đau lưng vẫn không thấy bớt. Lại có người bày đến nhà thầy Năm ở làng bên, uống thuốc kết hợp với châm cứu, ít tháng sẽ khỏi. Nhà thầy Năm không có bảng hiệu, không biết gọi là thầy thuốc bắc hay thầy thuốc nam, nhưng có nhiều bình ngâm rượu, đủ loại động vật, đủ loại thuốc. Thầy Năm khám qua loa, rồi bán thuốc, bảo về nhà sắc uống. Thêm nữa, hằng ngày phải chở má đi đến nhà thầy châm cứu. Suốt mấy tháng liền, mỗi lần châm cứu về má cảm giác lưng có nhẹ hơn, uống thuốc người có khỏe hơn, nhưng cái chính là bệnh đau lưng vẫn không khỏi.
Một trí thức khác ở trong xóm, phân tích: “Bệnh thoái hoá cột sống thuộc loại bệnh về xương, uống thuốc chỉ giảm đau thôi, không thể hết hẳn. Muốn điều trị tận gốc, phải vào bệnh viện lớn ở thành phố phẫu thuật..”. Mấy anh chị em trong nhà lo lắng bàn nhau, mỗi người đóng góp một ít tiền, đưa má vào bệnh viện. Ở viện, bác sĩ khuyên: “Phẫu thuật nếu may mắn có thể chữa dứt điểm, nhưng cũng có thể rủi ro như vết mổ lâu lành, dễ viêm nhiễm, gai thoái hoá có thể mọc lại. Hơn nữa bà cụ đã già rồi, phẫu thuật lớn như vậy sợ...!”. Anh chị em phân vân, chẳng biết toan tính thế nào, cuối cùng đành phải đưa má về quê để má sống chung với căn bệnh ấy. 
Ngày ba mất, má mới ở tuổi ba lăm, vẫn còn trẻ đẹp phơi phới. Cũng có nhiều người đàn ông góa vợ, muốn đến nhà phụ giúp má một tay, nhưng má quyết ở một mình, nuôi các con còn nhỏ. Hằng ngày, từ sáng sớm khi con còn đang ngủ, má quảy gánh đến ngã ba đầu làng ngồi đợi. Người trong làng có ai chở trái cây xuống chợ bán, má xin mua lại, gánh xuống chợ bán lẻ. Về sau, má đến tận nhà người ta, từ trái xoài, trái mít, trái mãng cầu, đến trái bầu, trái bí... mua tất tần tật cả vườn. Má gánh về nhà phân loại, rồi lại gánh ra chợ bán hoặc bỏ mối. Những lúc lời kha khá, má thường mua về cho các con khi bịch chè, lúc cái bánh. Chính vì vậy, chiều chiều các con hay ra đầu ngõ ngồi đợi. Mới thấp thoáng thấy bóng dáng má quảy gánh từ xa, mấy đứa đã ba chân bốn cẳng chạy đến giành đụng má trước. Suốt bao nhiêu năm qua, cuộc đời má gắn liền với cây đòn gánh. Ban đầu, cây đòn gánh vẫn còn sần sùi, ở trên vai má lâu ngày trở nên cong cong, bóng loáng. Hết cây đòn gánh này gãy, băng bó, chắp vá rồi gãy, lại đến cây đòn gánh khác. Trên đôi vai, da thịt của má tưởng chừng mềm mại, nhưng cứng cỏi vô cùng, không nhớ đã làm gãy bao nhiêu cây đòn gánh rồi. Giờ đây, các con lớn lên bao nhiêu thì lưng của má ngày càng khòm xuống bấy nhiêu.
Cuộc sống gia đình cũng đã khá hơn, rõ nét đáng kể nhất là ngôi nhà. Ngày trước, tất cả sống trong căn nhà tranh vách đất ở giữa khu rẫy. Căn nhà lúc mới làm xong, tuy không đẹp nhưng mùa đông ấm áp, mùa hè mát mẻ. Sau một thời gian mái tranh mục, mưa đến, nhà dột, dưới nền đất ướt nhẹp nhẹp. Lúc nắng lên, nền nhà loang lổ. Sống tạm bợ như thế mấy năm, dù trong túi không đủ tiền má vẫn quyết định xây lại thành căn nhà lợp tôn, tường gạch chưa tô, không có cánh cửa sổ, nền láng xi-măng. Hồi mới mở móng nhà, mấy ông thợ hồ thấy má hoàn cảnh khó khăn quá, bày: “Mua tôn cũ về, lấy dầu hắc trám lại mấy lỗ đinh sẽ không dột, giống như tôn mới...”. Ở thời gian đầu không sao, nhưng qua mùa hè trời nắng, dầu hắc chảy ra trống các lỗ đinh, trời mưa đến trong nhà lại dột khắp nơi. Đã thế, nước mưa từ ngoài cửa sổ tạt vào, anh chị em hối hả kiếm bạt che chắn, lấy thau, lấy thùng ra hứng nước vẫn không xuể. Mỗi khi mưa lớn đến, trong nhà hầu như chỗ nào cũng dột, nước chảy lên láng. Mấy năm sau, các con lớn dần, căn nhà lại trở nên chật chội, má lại sửa nhà lần nữa: xây thêm phòng, thay tôn mới, làm cửa sổ, láng gạch men. Căn nhà tuy chắp vá nhưng tạm hoàn chỉnh, mưa không dột, đêm tối ngủ ngon lành. Có điều, lúc mọi thứ vừa tạm yên ổn, chưa kịp thảnh thơi ngày nào thì má xuống sức, ngã bệnh đau lưng.
Hằng ngày, ngoài đi đứng khó khăn, buổi tối khi ngủ má phải nằm gối đầu rất cao. Lúc trước, bình thường má chỉ nằm một gối, song bẻ gấp gối lại cho cao hơn mới dễ ngủ. Sau má nằm hai gối, nhưng lưng vẫn đau, không ngủ được. Má thường nằm nghiêng và gần như ngủ ngồi. Cả đời má khổ sở, dành hết sức lực tuổi thanh xuân cho các con, không có gì cho riêng mình cả. Giờ đây má bị bệnh, mấy con thương má quá nhưng chẳng biết làm sao. Thấy má nằm trên chiếc giường tre cũ kỹ, mấy con ngỏ ý: “Để tụi con mua cho má cái giường mới nghen?”. Má không chịu: “Cái giường này má nằm lâu năm, quen rồi. Tụi bay ráng làm lo cho vợ, cho con ăn học ngon lành là má vui rồi!...”. Mấy đứa con nhìn nhau, im lặng. 
Anh Hai lấy vợ, chị Ba lấy chồng, cuộc sống vợ chồng trẻ ở quê tuy không giàu nhưng nhờ sức dài vai rộng nên cũng đủ ăn, đủ mặc. Anh Hai bí mật bàn với chị Ba, góp tiền, xuống thị trấn mua cho má chiếc giường thật lớn, ra (drap) nệm đều mới, êm ái để má nằm dễ ngủ hơn. Lúc mới mua giường về, má ngạc nhiên, giận dữ trách các con hoang phí, bắt mang đi trả lại. Sau thì má vui lắm, hết ngồi lên giường nhún nhún, rồi giang tay nằm ngả xuống, lăn qua lăn lại, đầy vẻ mãn nguyện. Má thường hay khoe với hàng xóm, còn dắt bạn già về phòng mình dẫn chứng: “Đó, sấp nhỏ mua cho tui cái giường đó. Tui không cho nhưng tụi nó cứ mua, bực ghê!...”. Bạn già của má ở quê đa phần đều nghèo, ai thấy chiếc giường to đẹp cũng thích thú, trầm trồ. Thấy má vui, trong lòng các con cũng đỡ xốn xang phần nào. 
Có điều, không hiểu sao nằm trên giường chừng mươi ngày, bỗng dưng má không chịu nằm nữa. Má xuống nằm dưới nền nhà, cạnh bên chiếc giường. Ban đầu cậu Út nghĩ chắc buổi trưa trời nóng, má nằm xuống nền nhà một lúc. Nhưng buổi tối má cũng vẫn nằm ở đó, mỗi khi cậu Út vô phòng thăm má lại vờ leo lên giường. Cậu Út ngạc nhiên, hỏi: “Sao má lại nằm dưới đất?”. Má ngó lơ đi chỗ khác, bảo: “Má nằm cho mát...”. Cậu Út lại gặng hỏi: “Buổi tối trời mát sao má cũng không lên giường nằm?”. Không biết nói thế nào nữa, má thành thật: “Tao không thích nằm trên cái giường ấy. Tụi bay mua cho tao cái ghế bố loại hai, ba trăm nghìn gì đó về cho tao nằm. Tao thích nằm ghế bố hơn...”. Cậu Út đem chuyện này nói với anh Hai, chị Ba. Anh chị về nhà nhỏ to khuyên nhủ má đủ điều, song má vẫn không chịu, lại nhờ cả bạn bè, người quen của má khuyên can nhưng má vẫn một mực khăng khăng: “Ghế bố là ghế bố!”. 
Anh Hai, chị Ba nhớ có một người mà má vô cùng kính trọng, có thể thuyết phục được, ấy là chú Bảy ở xóm dưới. Ngày xưa, ngoài buôn bán ở chợ, nhà có đất rẫy trồng mì, đầu vụ, má không có tiền thuê người ta cày, mới đến nhà chú Bảy xin cày nợ, đến khi thu hoạch sẽ trả. Nhưng khi mùa đến, giá mì rẻ quá, lỗ công lỗ vốn, má phải xin chú Bảy khất nợ. Thấy cảnh mẹ góa con côi khổ cực, chú Bảy cho luôn tiền cày. Sau này cảnh nhà đỡ hơn, vào những ngày lễ Tết, năm nào má cũng sai các con đến nhà chú Bảy biếu quà, khi thì ký trà, khi thì giỏ trái cây. Bao nhiêu năm đều đặn như thế, nếu tính tiền quà hơn gấp mấy lần tiền công cày ruộng năm nào, nhưng má vẫn luôn cảm thấy vẫn còn mắc nợ. Ấy là món nợ ân tình, các con không được quên. Anh Hai chở chú Bảy đến nhà thuyết phục má, nhưng khi chú Bảy về rồi má lại xuống nền đất nằm. Hết cách, cậu Út bực mình, gắt: “Má già rồi, trở nên lú lẫn, trái tính trái nết không à”. Má im lặng, không nói tiếng nào. 
Bệnh của má ngày càng nặng hơn, hầu như nằm một chỗ, lâu ngày cái lưng bắt đầu lở loét. Tuổi già không hoạt động, lưng đau nhức, lại thêm mất ngủ má xuống sức trầm trọng. Má bắt đầu ăn uống ít, nói năng khó khăn, không đủ sức nói chuyện nhiều nữa. Mấy con đưa má đến bệnh viện, thay phiên nhau chăm. Nhìn má nằm trên giường bệnh, mắt lim dim, bác sĩ chuyền nước biển, dây nhợ lòng thòng, mấy con xót dạ, giá mà san sẻ tuổi thanh xuân của mình cho má sống thêm dăm năm nữa, hạnh phúc biết bao! Qua mấy hôm sau, bỗng dưng buổi sáng má khỏe hẳn ra, đi đứng được, nói năng rõ ràng mạch lạc. Má còn sai con dìu đến cửa sổ bệnh viện, ngắm hàng cây, phố phường, con đường, dòng người qua lại, giống như người khỏe mạnh ngắm cảnh đẹp vậy. Sau má sai kêu con cháu vào trong bệnh viện, căn dặn từng đứa: “Ở quê mình có tục lệ khi chết, đồ đạc, vật dụng hàng ngày của người chết phải hỏa táng theo. Nếu sau này má có mất, tụi con nhớ đốt cái ghế bố nhỏ theo cho má nghen, đừng đốt cái giường lớn, phí lắm! Má mới nằm thử có mấy hôm, chưa thấm hơi người xem như là khách, không thể tính đó là giường của má được. Tụi con hãy để cái giường lớn đó cho thằng Út khi có vợ, con dâu nó nằm, nhớ nghen!...”. Hôm sau nữa, má ra đi... Lúc đưa linh cữu của má, mấy đứa con khóc hết nước mắt...
Đêm về, rồi đêm đến, cứ mỗi khi nằm trên cái giường êm ái và rộng rãi, cậu Út nhớ đến má, hối hận rơi nước mắt. Đến lúc chết rồi má vẫn chỉ lo nghĩ đến các con, má ơi!... 
Lê Đức Quang.

## Rau càng cua (Truyện ngắn)

Ở một làng nọ, có một gia đình nghèo, đông con, người cha, chủ gia đình thì không may mất sớm, mọi việc trong ngoài đều do người mẹ đảm đương, lo toan. Do không có đất canh tác, người mẹ hàng ngày phải chạy vạy, mua gánh, bán bưng ngoài chợ để kiếm tiền, kiếm gạo đấp đổi qua ngày với một bầy con đang tuổi ăn, tuổi lớn.
Sau buổi chợ, bà dùng số tiền lời ít ỏi mua vội chút cá mắm, thịt thà ế về rồi chạy qua các vườn hàng xóm, xin hái những đọt rau, đọt lá hoang dại để nấu một nồi canh to, kho vội nồi kho với nước mắm mặn nhiều hơn thịt, cá... Mấy mẹ con xúm nhau cùng ăn cơm trong cảnh nhà lụp xụp, tềnh toàng vì thiếu bàn tay mạnh mẽ của đàn ông.
Vào mùa mưa, khi rau càng cua mọc nhiều, bà thường qua nhà hàng xóm, có nhà tường, xin hái loại rau này về rửa sạch, bóp với giấm chua, bỏ thêm vài hạt đậu phộng rang vàng.. bày ra cho con ăn. Bọn trẻ rất thích món ăn đơn giản mà ngon miệng này, nhất là thằng con trai lớn, cũng là đứa con trai duy nhất trong sáu đứa con, nó rất mê món rau trộn giấm, chua chua, ngọt ngọt của mẹ nó.
Một hôm, sau buổi cơm với rau càng cua bóp giấm, nó nói với mẹ như người lớn:
- Ngộ quá hén mẹ, rau càng cua là món ăn của nhà nghèo mình mà sao nó chỉ mọc trên đất nhà giàu, đến rau lá mà cũng chỉ nịnh, thương nhà giàu thôi, nhà mình có bao giờ nó thèm mọc đâu, muốn ăn mẹ phải đi xin của người ta. Sau này lớn lên, con sẽ xây nhà tường để rau càng cua mọc ở nhà mình, mẹ khỏi đi xin nữa..
Bà mẹ rơm rớm nước mắt, ôm thằng con vào lòng, hôn lên mái tóc khét mùi nắng của nó và nhớ những ngày chồng bà còn sống, nhớ những hạnh phúc bà đã được hưởng khi còn bờ vai mạnh mẽ để nương tựa...rồi bà khóc, nước mắt lặng lẽ rơi lên mái tóc của thằng con. Thằng con không hay, vẫn nói với mẹ những ước mơ của một đứa trẻ nghèo, sớm mất cha...
Rồi thời gian trôi nhanh, bầy con của bà cũng đều đã lớn khôn, mấy đứa con gái, đứa lấy chồng xa, đứa lầy chồng gần. Còn thằng con trai cả của bà nhờ có chí quyết làm giàu từ nhỏ, chịu học hành, chịu thương chịu khó giờ trở thành một chủ doanh nghiệp lớn, thành đạt ở Sài gòn, cưới vợ là giám đốc một công ty, đối tác làm ăn là các công ty nước ngoài, đã giàu càng giàu hơn.
Thằng con trai bà đã giữ lời hứa, cất cho bà một ngôi nhà tường khang trang, to đẹp nhất xóm. Do công ăn chuyện làm túi bụi, thằng con trai ít khi có dịp về thăm mẹ, cả năm có một cái đám giỗ cha nó cũng không về được lần nào từ khi nó cưới vợ, nó nói với bà nó bận lắm, nhưng được cái tháng nào nó cũng gởi tiền về cho bà xoay xài thoải mái, không còn cảnh thiếu trước hụt sau như ngày nào. Lối xóm thấy bà như vậy, ai cũng khen bà có phước, có con làm ăn giàu có. Nghe vậy bà cũng cười, ra chiều vui lắm nhưng trong lòng bà héo hon mà đâu ai biết. Vật chất dư thừa nhưng tình cảm thiếu thốn, cũng chẳng vui vẻ nổi, bà ra vào thui thủi có một mình, có đứa con gái nhà cách mấy dây đất nhưng cả tuần nó mới ghé thăm chút rồi về, nó cũng bận bịu chuyện chồng con mà.
Thỉnh thoảng về chiều, nghe tiếng con bìm bịp kêu nước lớn, nước ròng, nằm trên vòng, bà thở dài..Giá mà được như ngày nào, mẹ con xúm xít bên nhau, với nồi cơm nóng, với tô canh tập tàng hái vội của hàng xóm. Nghèo mà được gần gũi con cái, hơn là dư ăn, dư mặc phải lủi thủi một mình..Rồi bà lại nghĩ, tình mẹ cha như nước trên nguồn, cứ đổ về xuôi, nước bao giờ chịu chảy ngược...thì thôi. Bà lại thiếp đi trong tiếng võng đong đưa, trong giấc mơ bà lại thấy mình ôm thằng con trai vào lòng, ngửi cái mùi tóc khét nắng của nó, bà lại mĩm cười, nụ cười hạnh phúc của một người mẹ nghèo..
Một hôm, sau mấy cơn mưa đầu mùa, rau càng cua mọc rất nhiều trước sân nhà bà ấy, nhưng cọng rau trắng đục, mọng nước, điểm xuyết những chùm hạt nho nhỏ, xanh xinh xinh..nhìn đám rau bà lại nhớ thằng con trai nơi chốn thị thành, không biêt nó bận bịu gì mà cả tháng nay cũng không gọi điện về thăm bà, rồi bà lại nhớ xưa nó rất mê món rau trộn giấm do bà làm. Nhớ vậy và sẵn có rau mới mọc đầu mùa, bà hái một vỏ xách đầy, gởi nhà cho đứa con gái rồi ra lộ đón xe đi Sài gòn thăm con.
Đương xa, nắng gắt, khi đến nhà con thì mớ rau càng cua đã héo mềm đi, bà nhờ cô giúp việc để rau vào tủ lạnh giúp rồi quày quả qua bên quán tạp hóa đầu đường mua đậu phông và giấm chua về để chế biến món rau mà con bà yêu thích, bà rất vui vì biết chắc con trai mình sẽ mê tít cho mà xem, mà gớm, cái con vợ của nó sao tệ quá, trong nhà không có nổi một giọt giấm ăn...bộ nó không biết nuôi giấm à, để sẵn về làm keo giấm nuôi và chỉ cho nó cách nuôi giấm luôn..ba khẻ mĩm cười hạnh phúc..
Không ngờ, buổi chiều đó con dâu bà đi làm về sớm, mang một số rau quả cao cấp mua ở siêu thị đem cất vào tủ lạnh, thấy bọc rau càng cua héo queo quắt, cô ta xách thảy vào thùng rác. Bà về tới, nghe thằng con trai cằn nhằn vợ: “Tại sao em ném rau của má vậy, từ quê xa xôi mà đem lên làm cho anh ăn đó..”, Con dâu bà trả lời:” héo hết rồi, ăn gì được, em mới mua rau ở siêu thị về đó..”.
Bà bước vào và giảng hòa, bà nói với với thằng con trai: “Thôi con, để mai mốt má đi sớm hơn, rau tươi sẽ ngon hơn.”.
Sáng hôm sau bà bắt xe về quê sớm, mặt buồn hiu, dạ cũng buồn hiu..Đám rau càng cua ngoài sân nhà bà vẫn lặng lẽ vươn những cọng rau giòn tươi, trắng mượt mà.
Mùa mưa năm sau, đám rau càng cua lại mọc, trắng nuột, điểm xuyết trên đầu nhánh những chùm hạt nhỏ xíu, xinh xinh.. Bà lại nhớ thằng con trai, bà tính lần này phải đi thật sớm, bắt chuyến xe đầu tiên, khuya không khí mát mẻ, rau chắc sẽ không héo nữa. Tính vậy, hai giờ khuya bà dậy, xách chiếc đèn pin ra rọi, hái một rổ đầy rau càng cua, bà chăm bẳm chỉ lựa hái những cọng rau to mập, tươi roi rói.., nó chỉ thích ăn những cọng to mập thôi, bà mĩm cười hạnh phúc...
Rồi bà trở vào nhà, tính để vào chiếc giỏ xách ... không may, bà bị trợt chân, té đập đầu xuống thềm, đầu trúng vào ngạch cửa, máu tuôn xối xả..bà lịm dần và chết lặng lẽ trong sương lạnh đêm khuya, không ai hay, ai biết. Máu bà lan cả một khoảnh nền nhà và tẩm đỏ cả rổ rau càng cua mới hái, màu đỏ máu hòa lẩn sắc trắng của rau phản chiếu óng ánh dưới anh đèn neon hiu hắt.
Ngày đám tang bà, thằng con trai khóc rất nhiều, anh ta đã hiểu vì sao mẹ bị nạn mà chết...những giọt nước mắt muộn màng không thể níu kéo mẹ của anh ta sống lại, để nghe anh ta kể những lời mơ ước như thuở hàn vi. Ngoài sân, những khóm càng cua vẫn lặng lẽ vươn lên trong bóng tối chập choạng..
Mấy ai biết và quý một loại rau hoang dại chốn quê mùa cũng như có mấy người con kịp biết quý tình mẹ lặng lẽ, bao năm vẫn mãi dõi theo từng bước chân của con ở đường đời, vui khi biết con thành công, hạnh phúc và đau buồn khi hay con va vấp, khổ đau. Mấy ai mà biết... Mấy ai mà biết...
**Hương Đức**

## Dự án đồng hành 'Khu vườn tâm hồn'

Trong những bộn bề dịch bệnh - việc điều trị không phải chỉ viên thuốc mà còn là tinh thần.
Vì thế, khi được sự ngỏ ý từ Ban truyền thông bệnh viện Nguyễn Tri Phương, với mong muốn đóng góp những "viên thuốc tinh thần" giúp xoa dịu nỗi lo mùa dịch bệnh, Hear & Heal đã cùng bệnh viện Nguyễn Tri Phương cho ra đời dự án kể chuyện cho bệnh nhân mang tên “Khu Vườn Tâm Hồn”.
Dự án ra đời nhằm mang lại một kênh thư giãn với những câu chuyện ngắn được đọc bởi các tình nguyện viên tận tâm, gửi đến bệnh nhân như một lời động viên, rằng bạn không đơn độc, chúng tôi vẫn luôn hiểu, quan tâm và cùng bạn vượt qua giai đoạn không dễ chịu này. Hy vọng những câu chuyện với cả tấm lòng sẽ đồng hành cùng quý độc giả và thính giả qua hết những khó khăn của dịch bệnh.
Hãy chia sẻ để những câu chuyện ý nghĩa và tấm lòng của các bạn tình nguyện viên đến được với người cần nhé!
Đón xem những câu chuyện được đăng tải hàng tuần tại:
Facebook: [facebook.com/hearandheal](https://facebook.com/hearandheal?__cft__\[0\]=AZWyYWGv4ZuS9mFyOZGmn5W8yKH-ynllnohrykHyWU4JwfvwXn3xPzuqhrxSg6BfK9CdErcXWUWN_11Otj8RA8YJWU558uBChw_cXpwbqrBimV-3l74oWt5tYkLWt1JD3r16TAocJL-HQmDRygaV_Tlq&__tn__=-UK-R)
Bạn muốn tham gia đọc truyện gửi đến bệnh nhân?
Xem hướng dẫn đăng ký tại: [asmi.vn/dangkydoctruyen](https://l.facebook.com/l.php?u=http%3A%2F%2Fasmi.vn%2Fdangkydoctruyen%3Ffbclid%3DIwAR272bIkQ03Vwhb-zyrOQLmOnhtpK4aQnGxIX4_R6tPbrP0XBWSqReqknUY&h=AT0iE92HXogmATM8VKbUdmXGRXidvAfrWuYN2nZFLwZOT0RXv2yj7SpTYBEyvGb4zXoKF4xsGaSg2YQhS3MmAuN-BmQ-wfI1Y8QpeaC8-eQkYzx7QhUblVWC4JaGNIfsMnlz&__tn__=-UK-R&c\[0\]=AT15RQB0zNIewNcTD6pX9J3-gyTzf3Y4Okt4AUVPKsZtUhQQJHTCksAvnP7gK7kRiS1PHPIoFhPqVmv9WCvqVEsYtVpjsT4nqIfUEV8hvPx2Db5PfRyjRksCxNLynWIVv5SeK-WbJnpuISJ45VGki-X1xOTMmqoAj2wY2leSkz8wVw)

## Bốn điều không thể...

Trong cuộc sống, có những cái chúng ta có thể làm lại, sửa lại, điều chỉnh lại nếu lỡ làm sai hoặc chưa như ý. Khi sửa, tất nhiên phải hao tốn nhiều thứ để sửa sai, tùy vào tính chất vấn đề mà cái hao tốn ấy là gì, bao nhiêu. Tuy mất thêm thời gian, công sức, nhiên vật liệu… nhưng ít ra, còn sửa được đã là quý!
Bên cạnh đó, còn rất những điều lỡ làm rồi thì không thể sửa, không thể “undo” để có thể coi việc lầm lỡ vừa rồi là một bài nháp rồi bước lui trở về vị trí ban đầu và làm lại tốt hơn từ kinh nghiệm thất bại. Trong vô số những điều có tính chất như vậy, chúng ta cần nhớ đến bốn điều không thể rút lui này:
_**Khi bạn ném một hòn đá**_ , bạn không thể rút lui lại được. Đây chỉ là hình tượng ẩn dụ rằng, đừng bao giờ ném đá ai, dù đó là người thế nào, đã gây đau khổ cho bạn ra sao. Việc này khó, nhưng nếu quyết tâm, bạn sẽ làm được. Khi ném đá người khác, bạn không được lợi ích gì phần mình, mà càng thêm ân oán với người kia. Dù ai đó có làm điều xấu xa, đê hèn tổn thương đến bạn, bạn có thể giận tím ruột bầm gan, trông có dịp là “trả lễ”, bạn cũng dặn lòng mình, không nên trả đũa. Hãy để họ tự tính với luật nhân-quả đủ rồi. Những cách “49 gặp 50”, hoặc “trạng chết chúa cũng băng hà” có thể làm cho bạn “hả dạ” nhất thời nhưng bạn đã làm cho tâm mình bị tổn thương lâu dài. Bạn không cần thiết giữ nọc độc sân giận trong tâm mình. Cảm xúc là nhất thời, và khi giận hờn ghét bỏ qua đi, bạn sẽ ân hận với việc mình đã làm. Lúc ấy đã muộn rồi, bạn sẽ phải nhận quả mình đã gieo. Nói xấu người khác không làm bạn tốt hơn. Hại người ta không thể khiến cho lợi lộc chạy về nhà bạn. Căm hờn người khác không thể cho bạn hạnh phúc, bình an. Vì sự bình an của chính mình, đừng đáp trả theo kiểu ăn thua đủ!
**_Lời nói_** , một khi đã thốt ra thì không thể rút lại được. Do vậy, cần vô cùng cẩn trọng khi nói ra điều gì. Khi còn ở trong suy nghĩ, bạn có khả năng quản lý ý tưởng, nhưng khi ra khỏi miệng, bạn hoàn toàn mất quyền kiểm soát với những gì bạn nói. Phần lớn nội dung bạn nói, ban đầu hoàn toàn khác, so với những gì bạn nghe trở lại, sau khi nó đi “du lịch” một vòng qua tai, qua miệng nhiều người. Liệu bạn có đủ tự tại trước sự đơm đặt, khen chê của người đời chưa? Do đó, hãy chánh niệm, chịu trách nhiệm về lời mình nói ra để không hối tiếc muộn màng. Khi có một ý tưởng muốn nói, bạn hãy cho luồng ý tưởng ấy đi qua năm cánh cửa “an ninh” có hệ thống soi chiếu. (1) Việc bạn sắp nói có đúng sự thật không; (2) điều ấy có chính đáng không; (3) nói điều này có phải từ thiện chí của mình không; (4) điều này có lợi ích cho người mình sắp nói không; và (5) đây có đúng là thời điểm thích hợp để nói không. Nếu không bị kẹt, nghẽn ở cửa an ninh nào, lời ấy bạn nên nói ra, vì nó an toàn và đem lại bình an cho bạn, lợi lạc cho người nghe. Chắc chắn sẽ còn không nhiều điều có thể đi qua hết năm cánh cửa “an ninh” này. Khi ấy, bạn sẽ cảm nhận được hạnh phúc của việc ít nói, nghe nhiều.
_**Cơ hội vuột qua**_ , bạn sẽ không bao giờ lấy lại được. Người thành công là người biết tận dụng tốt mọi cơ hội có được trong cuộc sống. Thật ra, cơ hội không phải là vị khách đến gõ cửa nhà bạn hay nhà ai đó, mà chúng có thể hiện diện khắp nơi, bất cứ khi nào. Cùng một sự kiện, có thể là cơ hội cho người này, lại là điều bình thường với người khác, và cũng có thể là chướng ngại cho ai đó. Gọi một điều nào đó là “cơ hội” khi điều ấy có thể trợ duyên, hỗ trợ cho bạn để bạn tận dụng tiếp sức cho việc mình đang làm suôn sẻ hơn, dễ dàng hơn và đem lại kết quả tốt đẹp hơn. Do đó, nếu tinh tế để nhìn thấy được những điều kiện hỗ trợ ấy, nghĩa là bạn đang nhận ra “đây là cơ hội” và nắm bắt kịp thời, không để lỡ mất. Do vậy, không phải cơ hội tự đến vào trao cho người này, không trao cho người khác, mà vấn đề là bạn có chủ động nhận ra và coi đó là cơ hội của mình hay không. Nói một cách chính xác, bằng sự nỗ lực không ngừng, học hỏi, mỗi người phải biết tạo ra cơ hội cho bản thân mình từ những khởi điểm tốt đẹp và thuận lợi ban đầu, có khi rất nhỏ. Đừng bao giờ coi thường và bỏ qua những may mắn dù nhỏ trong cuộc sống, vì đó chính là những cơ hội.
**_Thời gian trôi đi_** , không ai có thể lấy lại được. Tất cả mọi thứ trong cuộc sống của mình đều cần thời gian, ngắn dài tùy vào tính chất mỗi việc. Muốn có bữa ăn, cần thời gian để nấu nướng. Trồng một cây, cần thời gian để nó sống và cho ra sản phẩm. Muốn nhà cửa tươm tất, bạn cần dành thời gian chăm chút từng góc vườn cho đến mọi thứ trong nhà, từ nội thất phòng khách, phòng ngủ đến không gian nhà bếp. Muốn gia đình thật sự là tổ ấm, bạn phải dành thời gian nuôi dưỡng các mối quan hệ tình thân. Muốn hoàn thiện mình hơn, bạn cần dành thời gian học hỏi, đọc sách, tập các thao tác, rèn các kỹ năng… Tất cả đều cần thời gian, mà chúng ta chỉ có 24 tiếng mỗi ngày. Do vậy, hãy chọn lọc những gì cần làm, vì thời gian qua đi, không bao giờ lấy lại được. Tuổi trẻ, sức khỏe, sự minh mẫn, tinh thần, nhiệt huyết… đều chịu sự chi phối của thời gian. Biết sống với hiện tại, với những gì đã diễn ra ngay bây giờ và ở đây là nghệ thuật sử dụng thời gian một cách hiệu quả và tiết kiệm nhất.
Hãy sống hết lòng, sống như thể hôm nay là ngày cuối cùng của đời mình, bạn sẽ không hối tiếc, vì thời gian qua đi, không bao giờ lấy lại được.
Sống tỉnh giác bạn sẽ có đủ sự bình thản để cân nhắc về bốn vấn đề trên, bạn sẽ không hối tiếc về sau. ** _Một hòn đá ném đi, một lời nói thốt ra, một cơ hội chợt đến và thời gian qua đi là những thứ đi trên đường một chiều._** Hãy thận trọng suy nghĩ kỹ và chín trước khi hành động vậy.

## Vợ chồng nữ điều dưỡng trẻ cưới online mùa dịch Covid-19

“Đời người con gái ai không muốn 1 đám cưới hoàn hảo hả chị! Đám cưới có gia đình 2 bên, họ hàng và bạn bè thân thiết.” Nhưng cô dâu Lê Thị Thủy Trang, điều dưỡng khoa Phẫu thuật Gây mê Hồi sức, Bệnh viện Nguyễn Tri Phương, lại có một đám cưới đặc biệt mùa Covid-19, đám cưới online! 
**Đám cưới chỉ có 3 người**
“Đã là con gái thường hay mơ mộng màu hồng, làm sao như truyện cổ tích và như ngôn tình lãng mạn. Em từ nhỏ cũng suy nghĩ như mọi người. Nhưng lớn lên ai rồi cũng thay đổi mọi suy nghĩ. Vì biết hoàn cảnh và kinh tế không cho phép, nên làm sao cho gọn gàng mà vẫn đủ hai bên gia đình, họ hàng, anh chị em bạn bè,” Nữ điều dưỡng Thủy Trang chia sẻ. 
Cô dâu Thủy Trang và chú rể Hoàng Nguyên quen nhau được 1 năm. Thời gian ít hay nhiều, theo cô, không nói lên được điều gì cả. Quen ít cũng không được, quen lâu rồi đôi khi cũng chia tay. 
“Thời gian quen và yêu nhau, tụi em nhắn tin cho nhau, giống như là quen nhau lâu lắm rồi. Hai đứa nói đủ thứ chuyện, trên trời dưới đất, không biết thời gian qua bao lâu rồi; có hôm nhìn lại cũng gần 12 giờ đêm. Tụi em cảm thấy muốn được nói chuyện với nhau không dừng lại được. Đối với em, thời gian đó là vừa đủ để mong muốn về chung một nhà. Anh ấy yêu và hay chiều chuộng em. Em hy vọng tình cảm ấy sau này vẫn mãi như thế,” Cô nói. 
Nhà của Thủy Trang ở Côn Đảo còn nhà chồng ở Đắk Nông. Ban đầu, cả đôi bên gia đình bàn tính làm tiệc cưới đãi khách khoảng 300 người. Thế những khi cơn sóng thứ tư của dịch Covid-19 bùng phát trở lại, khu nhà xung quanh bị cách ly, phong tỏa, TPHCM giãn cách…, đôi vợ chồng trẻ quyết định làm đám cưới online. 
“Tụi em cũng muốn trở thành một gia đình để được chăm sóc nhau, yêu thương nhau, mà em cũng không biết dịch khi nào mới hết. Ba mẹ coi cho tụi em ngày lành tháng tốt, ngày 5/6/2021. Nên tụi em nói với gia đình về việc hai đứa em sẽ làm đám cưới online. Mọi người cũng tán thành vì hai bên đã biết mặt nhau rồi. Mọi người thấy thương tụi em và nói sau này sẽ bù cho tụi em,” Cô dâu trẻ hạnh phúc. 
Minh Thư, em chồng cô, lần đầu tiên tự tay bó hoa, trang điểm, kiêm luôn chụp hình. Chồng cô thổi bóng bóng, trang trí nhà cửa. Đám cưới chỉ có 3 người, đơn giản mà vui dạt dào. 
“Làm đám cưới online đó em nghĩ giống như là một thử thách ban đầu dành cho tụi em vậy. Khi làm đám cưới online, tụi em cũng hơi buồn một chút. Gia đình họ hàng ai cũng buồn. Nhưng dịch như vậy mình biết phải biet lam sao. Em lại làm trong ngành y, nên phải tuân thủ quy định của Nhà nước, ngành y tế và lãnh đạo bệnh viện,” Thủy Trang tâm sự. 
Thế nhưng, cô lại vui mừng bày tỏ khi đám cưới của cô được mọi người trên toàn đất nước Việt Nam chúc phúc cho vợ chồng trẻ. Đám cưới của họ trở thành một kỷ niệm khó phai, có một không hai. 
**Điều dưỡng, người xoa dịu nỗi đau bệnh nhân**
Trong một khóa tập huấn về tăng cường năng lực cho điều dưỡng trong chăm sóc, phòng ngừa lây nhiễm và ứng phó với dịch Covid-19, TS Satoko Otsu - Trưởng nhóm bệnh truyền nhiễm, Tổ chức Y tế Thế giới tại Việt Nam, nhấn mạnh, đại dịch Covid-19 đã nhắc nhở tất cả chúng ta về vai trò quan trọng của các điều dưỡng trong làm giảm nhẹ sự đau đớn và cứu sống người bệnh. Họ là những người trực tiếp thực hiện và đảm bảo chất lượng chăm sóc người bệnh bất kể trong điều kiện, hoàn cảnh nào.
Điều dưỡng luôn có mặt ở mọi trận tuyến từ khám sàng lọc, chăm sóc người bệnh tại khu cách ly, theo dõi những bệnh nhân nặng trong phòng hồi sức… Nhiều người đã rời xa gia đình, để lại con nhỏ, gác lại hạnh phúc riêng tư để lao vào cuộc chiến chống Covid-19. 
Theo BSCKII Võ Đức Chiến, Giám đốc Bệnh viện Nguyễn Tri Phương, trong cuộc chiến chống lại Covid-19, người chiến sĩ áo trắng ra trận hay người chiến sĩ áo trắng ở lại địa phương đều đang phải gồng gánh, không phải chỉ Covid-19 mà còn là những bệnh nhân mắc các bệnh tật khác đang điều trị tại bệnh viện. 
“Vẫn nói “sức người có hạn” nhưng vào những ngày tháng chống dịch Covid-19 này, chúng ta lại chứng minh với nhau rằng “ý chí của con người vô hạn.” Áp lực khủng khiếp của dịch bệnh đột nhiên ập đến, gần như chúng ta chưa được báo trước để chuẩn bị. Nhưng bằng cách này hoặc cách khác, chúng ta đã kịp động viên nhau để đoàn kết chống dịch. Chúng tôi biết ơn từng sự cố gắng, mỗi sự hy sinh của các nhân viên y tế. Ngày Covid-19 lùi xa, chúng ta sẽ rất tự hào khi nhìn lại quãng đường này!” BSCKII Võ Đức Chiến nhấn mạnh. 
Tất cả vì sự an toàn của người bệnh nói riêng và mọi người nói chung! Mỗi nhân viên y tế thật sự là những “siêu nhân không mặc áo choàng”, với tất cả tinh thần và trách nhiệm của nhân viên y tế cố gắng đem lại cuộc sống an lành cho người dân

## THƯ GỬI CHỒNG YÊU

Anh có biết chiều nay em nhớ lắm 
Cả tuần qua không thấy bóng anh đâu. 
Bởi anh đang chi viện ở tuyến đầu 
Bên đồng nghiệp cùng chung tay dập dịch. 
Đất nước mình ngày nào còn Covid 
Thì ta còn gác lại chuyện riêng tư. 
Nhớ về anh, em viết mấy dòng thư 
Để anh biết mẹ con em vẫn ổn. 
Thằng cu Tèo bữa nay như "người lớn" 
Nó bảo rằng bố ra tận Bắc Giang. 
Vào giữa vùng tâm dịch giúp bà con 
Thăm khám bệnh đẩy lùi con virus. 
Yêu anh lắm, bởi anh là thầy thuốc 
Khi dân cần....."là có , phải không anh ? 
Hết bão dông trời trở lại trong lành 
Qua đại dịch mình đoàn viên anh nhé ! 
Cố lên anh! Thằng cu Tèo với mẹ 
Ở Sài Gòn mà nhớ lắm Bắc Giang.
**-- Tác giả: NGUYỄN KỲ - Bà Rịa Vũng Tàu --**

## 40 năm tìm cây thuốc tặng người dưng

Tờ mờ sáng, ông Hớn trở mình thức dậy, xỏ dép bước ra sân, vừa đi vừa lấy tay chống đầu gối đang đau nhức vì bệnh khớp. Ông vơ những cây đinh lăng thành một bó lớn ôm vào người rồi dùng dao cắt từng đoạn ngắn cho đến khi nắng sớm rải đều khắp khoảng sân nhỏ.
"Già rồi nên hai khớp gối thường đau nhức, nhưng đau lúc bước đi thôi, nếu chỉ ngồi một chỗ cắt thuốc thì tôi ngồi cả ngày cũng được", ông lão 94 tuổi nói. Bên hông căn nhà nhỏ ở khóm Tân Phú, phường Mỹ Quý, thành phố Long Xuyên, hàng chục bao thuốc đã phơi khô, xếp ngay ngắn. Hơn 40 năm nay, căn nhà của ông là điểm tập trung các loại cây thuốc nam của những nhóm chuyên đi hái hay của người dân mang đến nhờ sơ chế trước khi tặng cho các phòng khám đông y từ thiện trong và ngoài tỉnh
Ông Hớn trước đây vốn là một nông dân và cũng là một thợ mộc lành nghề trong làng. Gần 50 năm trước, người vợ của ông đột nhiên bị bệnh rồi qua đời. Sau khi vợ mất, trong một lần đạp xe ở thành phố Long Xuyên, ông thấy một phòng khám đông y chuyên bắt mạch, tặng thuốc miễn phí cho người nghèo. Vào hỏi thăm, ông Hớn biết được hầu hết những vị thuốc ở đây đều do người dân trong vùng cất công đi tìm rồi mang đến tặng.
Lúc đó ông Hớn nghĩ: "Nếu biết đến phòng khám này sớm hơn chắc vợ đã không mất sớm như vậy. Mình không phải là lương y, không thể bắt mạch khám bệnh nhưng có sức khỏe, chỉ cần bỏ chút thời gian đi tìm cây thuốc như vậy là giúp đỡ được người nghèo rồi". Kể từ hôm đó, ông Hớn bắt đầu hỏi các lương y ở phòng khám, nghe họ chỉ dẫn và tự đi tìm những cây thuốc nam phổ biến, dễ tìm ở các khu vườn trong làng. Tìm được loại nào, ông mang về nhà cắt nhỏ, phơi khô, gói ghém cẩn thận rồi mang đi tặng ngay.
Dù phải một mình nuôi bốn người con nhưng cứ khi dành dụm được một số tiền nhỏ, người đàn ông lại tập hợp khoảng chục người bạn của mình gùi gạo lên núi, dựng trại, tỏa tìm các cây thuốc quý. Lúc bấy giờ, trước nhà vẫn còn là khoảng sân đất, để giữ vệ sinh, ông Hớn phải dùng những tấm lưới cá lót bên dưới để phơi thuốc. Khi cha đi làm, những người con được giao nhiệm vụ ở nhà phơi thuốc, canh chừng trời mưa.
Ông Trần Văn Sơn, 62 tuổi, con trai cụ Hớn kể: "Cha dặn chúng tôi trông chừng thuốc kỹ lắm, thấy trời chuyển mưa là ba bốn anh em gom lưới chạy vào nhà, chờ tạnh hẳn lại mang ra phơi lại. Có nhiều hôm phải chạy ra chạy vào ba bốn lần như thế".
Lương y Dương Văn Năng ở phòng khám từ thiện Chín Năng, huyện An Biên, Kiên Giang chia sẻ: "Phòng khám của tôi lấy cây thuốc của bác Hớn đã được ba năm nay. Tuy không phải là một cơ sở cung cấp cây thuốc chuyên nghiệp nhưng thuốc của bác Hớn rất chất lượng, phơi khô ráo, sạch sẽ. Mỗi tháng chỗ của tôi thường lấy khoảng 2 tấn cây thuốc khô đủ loại".
Hiện nay, ba trong bốn người con của ông Hớn cũng thường tham gia vào các nhóm đi tìm cây thuốc quanh địa bàn Long Xuyên, tiếp nối công việc thiện nguyện của cha mình.
Ông Trần Tứ Hải, Chủ tịch Hội Đông y phường Mỹ Quý, thành phố Long Xuyên cho biết: "Cụ Hớn là người lớn tuổi nhất và cũng là người có thâm niên lâu nhất ở địa phương làm công việc sưu tầm cây thuốc nam tặng phòng khám từ thiện. Trước đây cũng có nhiều người làm nhưng hiện tại chỉ còn mỗi cụ Hớn là còn gắn bó".
(Theo VNExpress)

## Sống là để cho đi

Tối hôm đó, Bệnh viện của tôi nhận một nhóm nạn nhân của một tai nạn xe hơi thảm khốc. Trên xe là bốn em học sinh đều ở lứa tuổi 17-18, cùng đi về với nhau sau sau bữa tiệc. Người lái xe 18 tuổi, say rượu và chạy xe quá tốc độ, lạc tay lái tông vào một chiếc xe tải đang đậu bên lề đường. Nhờ có thắt dây an toàn, người lái và em ngồi cạnh tuy bị thương nặng nhưng không nguy hiểm tính mạng. Riêng hai em ngồi sau, 1 nam 1 nữ bị thương rất nặng vì không thắt dây an toàn. Em trai bị chấn thương sọ não và chết ngay sau khi xe chở đến Bệnh viện. Em gái hôn mê bất tỉnh phải mổ gấp, không biết có cứu được hay không?
Thật đáng buồn, em trai tử vong là một em gốc Việt, 17 tuổi, vừa tốt nghiệp trung học và đang sắp rời nhà để vào một trường đại học danh tiếng. Các em còn lại đều người ngoại quốc.
Lúc đó tôi đang làm tại khu ICU (Intensive Care Unit). Bệnh nhân tôi được giao đêm đó là em gái 17 tuổi của tai nα̣n vừa kể trên. Một cô bé người ngoại quốc, đẹp hay không thì tôi không biết vì cả khuôn mặt lẫn cái đầu tóc vàng của em đều tím bầm, sưng to như trái dưa hấu vì những cú va chạm kinh khiếp. Em đang được mổ não khẩn cấp trong phòng mổ.
Tôi được kêu vào phòng họp gấp để nhận một nhiệm vụ quan trọng.
Sau khi được biết nhiệm vụ của mình là gì, tôi nhăn nhó phản đối, “Tại sao lại là tôi? Đây là nhiệm vụ của bác sĩ mà!”
“Tôi biết, nhưng người nhà của bệnh nhân không biết tiếng Mỹ rành lắm, cô đi theo thông dịch cho bác sĩ, và ráng van xin họ giúp chúng tôi,” bà y tá trưởng năn nỉ.
Sau một hồi bàn qua tính lại, tôi lê bước đi theo ông bác sĩ đến phòng chứa ҳác của em trai Việt Nam mới tử nạn, với nhiệm vụ là cùng bác sĩ, năn nỉ gia đình người chết hiến tặng những bộ phận còn tốt trong cơ thể của em cho Bệnh viện.
Một em trai 17 tuổi đang khỏe mạnh nhưng chết vì tai nạn, là một ứng cử viên rất ý nghĩa để làm người hiến tặng, vì hầu hết các bộ phận trong cơ thể em còn rất khỏe, rất trẻ, rất thích hợp để cứu sống các Bệnh nhân đang chờ đợi để được thay các bộ phận trong người. Đó là lý do Bệnh viện hết sức cầu xin gia đình.
Thời gian đó, đối với người Việt mình, khái niệm hiến tặng bộ phận cơ thể còn rất mới mẻ. Nếu không là cho người thân trong gia đình, hầu như rất ít ai hiến tặng cho những người không quen biết. Huống hồ gì, chuyện cha mẹ đồng ý hiến tặng các bộ phận trong cơ thể của con thì hình như chưa hề xảy ra. Có cha mẹ nào mà nỡ lòng nào làm như thế? Mất con đã đau đớn lắm rồi…
Chúng tôi gặp cha mẹ nạn nhân trong phòng đợi, trong khi người con đang được chờ quyết định để rút tất cả ống hỗ trợ bên trong, tôi bắt đầu trình bày lý do. Quả như tôi lường trước, cho dù có van xin, nài nỉ, giải thích cách mấy, bác sĩ và tôi chỉ nhận được những cái lắc đầu quầy quậy, ánh mắt oán ghét, và những lời xua đuổi.
Tôi lắp bắp xin lỗi rồi bước nhanh như chạy ra khỏi phòng.
Phòng ICU rất vắng lặng vì ở đây toàn những ca rất nặng. Những y tá cùng trực với tôi đêm đó ai cũng bận rộn với Bệnh nhân của mình nên chỉ có một mình tôi ngồi tại nurse station. Thường thì ở ICU, mỗi y tá lãnh hai Bệnh nhân trong một ca. Nhưng đêm nay tôi chỉ có một, vì một Bệnh nhân mới chuyển sang phòng thường. Bệnh nhân còn lại là cô gái đang trong phòng mổ, nên tôi cũng khá rảnh rỗi, cho đến khi ca mổ xong.
Tôi trở về khoa đúng lúc Bệnh nhân của tôi đã được giải phẫu xong và chuyển về phòng ICU. Bác sĩ bảo em được cứu sống nhưng đôi mắt sẽ bị mù vĩnh viễn vì chấn thương quá nặng. Chỉ có một hy vọng duy nhất là được thay đôi mắt khác em mới có thể thấy lại ánh sáng.
Ba mẹ em ngồi bên giường trong khi em vẫn đang nằm thiêm thiếp. Ông bà yên lặng chắp tay cầu nguyện. Tôi không biết làm gì hơn là ngồi xuống bên cạnh và góp lời cầu nguyện trong lòng.
Người mẹ buồn rầu nói, “Tội nghiệp chúng quá. Rồi đây Jane sẽ ra sao khi tỉnh dậy và biết là người yêu của nó đã chết?”
“Người yêu của Jane là anh Việt Nam ngồi chung xe hả bà?” tôi hỏi.
“Đúng vậy, chúng nó yêu nhau lắm. High school sweethearts mà. Hai đứa đều học giỏi và có tương lai. Thế mà, chỉ qua một đêm, một đứa ra đi vĩnh viễn, một đứa trở nên mù lòa.” Bà sụt sịt khóc.
Tôi ngập ngừng, “Bác sĩ nói con bà còn có hy vọng thấy lại ánh sáng, nếu…”
“Vâng tôi biết! Nhưng ở đâu ra có cặp mắt để thay kia chứ? Nếu đó là cặp mắt của một người còn sống cho con tôi, tôi biết chắc chắn nó sẽ không chịu nhận. Nó là cô gái rất tốt, không bao giờ muốn làm khổ ai.”
“Nhưng nếu đó là cặp mắt của một người vừa mới mất thì hoàn toàn có thể dùng được, chỉ có điều…” tôi bỏ dở câu nói vì tôi biết chuyện đó sẽ không bao giờ xảy ra. Đừng bao giờ nên hỏi cha mẹ cậu bé Việt Nam thêm một lần nữa.
Như đọc được ý nghĩ của tôi, bà mẹ thở dài, “Cô y tá ạ, tôi biết nỗi đau của người mẹ mất con nó khủng khiếp như thế nào. Tôi không dám đòi hỏi gì thêm. Số phận con gái tôi bị mù thì tôi sẽ hết lòng chăm sóc cho nó. Con gái tôi có nghị lực lắm, tôi tin nó sẽ vượt qua…” Xót xa nhưng cũng rất ҳúc động trước những lời nói của bà, tôi nhẹ nắm lấy tay bà. Vừa lúc đó, một ông cảnh sát đang rảo bước tới, trên tay cầm một bọc giấy. Ông hỏi tôi, “Người ta chỉ cho tôi là có một cô y tá người Việt ở đây. Cô nói được tiếng Việt chứ?”
“Dạ được. Ông cần gì không?”
“Tôi muốn nhờ cô đi với tôi đến gặp gia đình người tử nạn trong tai nạn xe chiều nay. Chiếc xe bị hỏng hoàn toàn. Trước khi xe tải kéo xe đi, chúng tôi kiểm tra trong xe và tìm thấy chiếc ví này rớt trong xe. Nó thuộc về người đã chết. Tôi muốn giao lại kỷ vật này cho thân nhân của cậu.”
Tôi tần ngần mở chiếc ví ra. Thật vậy, trong ví ngoài một ít tiền nhỏ chỉ có tấm bằng lái xe. 
Tấm bằng lái!
Tôi nhìn kỹ lại tấm bằng lái lần nữa. Trên bằng lái có tên, tuổi và hình chụp của cậu bé. Còn nữa, nằm ngay ngắn ở góc phải của tấm bằng là cái sticker nhỏ màu hồng, trên có dòng chữ “HIẾN TẶNG” màu đen in đậm nét.
Tim tôi đập thình thịch. Tôi chỉ vào chữ “DONOR” và nhờ vị cảnh sát xác minh lại.
Sau khi xác nhận là cậu bé Việt Nam chính thực đã ghi danh làm người “HIẾN XÁC”, nhưng đồng thời vị cảnh sát cũng thông báo rằng theo luật pháp, vì cậu bé mất khi cậu chưa đủ 18 tuổi, nên quyết định cuối cùng, cho hay không, cũng vẫn là quyết định của cha mẹ.
Phái đoàn gồm các bác sĩ, cảnh sát cùng với tôi sau khi đưa chiếc ví lại cho cha mẹ cậu và thông báo về tất cả những sự việc trên cho họ. Trong khi chờ gia đình cậu bé bàn thảo với nhau, chúng tôi đều lui ra ngoài đứng chờ.
5 phút, 10 phút trôi qua. Một bầu không khí yên lặng đến nghẹt thở.
Rồi cha mẹ cậu bé cũng bước ra. Người mẹ ôm mặt khóc, trong khi người cha nghẹn ngào nói với chúng tôi: “Thôi thì con tôi nó đã muốn như vậy, chúng tôi xin nghe theo ý nguyện của cháu. Xin Bệnh viện giúp cháu làm tròn tâm nguyện, hãy giúp đỡ tất cả những ai đang chờ được giúp.”
Tôi bật khóc vì quá ҳúc động. Tất cả những người có mặt lúc đó đều khóc và cảm ơn cha mẹ cậu bé đã làm quyết định đau đớn và khó khăn nhưng rất cao cả này. Cảm ơn ông bà, tôi thầm thì. Trên cao kia, tôi biết cậu bé đang nhìn xuống và mỉm cười.
Những ngày sau đó, có ít nhất là cả chục Bệnh nhân đang chờ thay thận, gan, tim, v.v… đã được cứu sống nhờ được ghép những bộ phận trong cơ thể cậu bé. Cô bạn gái cũng đã nhận được cặp mắt của cậu. Trên gương mặt trắng bóc và mái tóc vàng hoe, đôi mắt nâu trong veo luôn tỏa những tia sáng ấm áp dịu dàng. Đôi mắt như biết nói những lời yêu thương đến mọi người. Cậu bé đã ra đi mãi mãi, nhưng tình yêu quảng đại của em vẫn tiếp tục tồn tại.
Tôi về bàn với chồng, và vợ chồng tôi đã cùng đi đến quyết định ghi tên tình nguyện làm người “HIẾN XÁC.”
Nếu một mai có người nào phải ra đi trước, chúng tôi không muốn người thân mình ở lại phải suy nghĩ để làm những quyết định đau lòng thế cho mình.
Cát bụi rồi sẽ trở về với cát bụi. Thế thì tiếc làm chi cái xác thân tạm bợ này! Nếu sau khi mình ra đi mà vẫn còn có ích cho người khác thì đó chính là một niềm an ủi và hạnh phúc vô biên cho mọi người chúng ta rồi.

## Cô gái ung thư đăng ký hiến giác mạc trước khi chết

Khi ấy, ngày 26/3/2021, cô gái điều trị ung thư vú tại Bệnh viện Chợ Rẫy TP HCM, tiên lượng thời gian sống không còn nhiều nên xin về nhà ở Gia Lai những ngày cuối đời. Nhận được ý nguyện hiến giác mạc của cô gái trẻ, các bác sĩ Trung tâm Mắt và Trung tâm ghép tạng của Bệnh viện Trung ương Huế đã đến tận nhà để thăm hỏi. Cùng lúc, Bệnh viện Trung ương Huế tiến hành khám, chọn lọc những bệnh nhân phù hợp từ danh sách dài bệnh nhân chờ ghép giác mạc.
Một tuần sau, ngày 3/4, cô gái mất, người nhà báo tin cho Bệnh viện Trung ương Huế. Ê kíp bác sĩ của Trung tâm Mắt từ Huế di chuyển ngay trong đêm đến Gia Lai tiến hành lấy giác mạc cô gái và quay trở lại Bệnh viện Trung ương Huế để bảo quản.
Ít hôm sau, giác mạc của cô gái trẻ được ghép cho một bệnh nhân nữ 43 tuổi ở Quảng Bình, bị viêm loét giác mạc thủng hỏng mắt; và nam bệnh nhân 64 tuổi ở Thừa Thiên - Huế, hai mắt bị sẹo giác mạc nhiều năm.
Ngày 22/4, Bệnh viện Trung ương Huế tổ chức lễ ra viện cho hai bệnh nhân ghép giác mạc. Trước khi xuất viện, hai bệnh nhân này cũng đã làm đơn đăng ký hiến tạng sau khi chết, như một lời cảm ơn cô gái trẻ đã hiến tặng giác mạc giúp họ được nhìn thấy ánh sáng trọn vẹn.
(Theo VNexpress)

## Những âm điệu có thể giúp bạn thư giãn


## Sự tử tế sẽ đánh thức trái tim!

Vào một đêm khuya ở Brazil, một người phụ nữ chuyển dạ sinh đứa con thứ hai. Chị sống ở một ngôi làng xa xôi mà người chồng thì đi vắng; chỉ có cậu con trai bé nhỏ bên cạnh. Chị đã điện thoại đội cứu hộ gần nhất để nhờ sự giúp đỡ.
Nhưng tất cả các đội cứu hộ đang bận các trường hợp khẩn cấp khác; không có ai sẵn sàng trợ giúp. Nhận thấy cần phải hành động nhanh chóng; viên cảnh sát đã gọi người đứng đầu một tổ chức tình nguyện địa phương và cho anh ta biết tình hình.
**Tổ chức tình nguyện tham gia hỗ trợ sản phụ sinh em bé**
Người đàn ông tốt bụng đồng ý giúp ngay trong đêm. Anh nhảy lên xe Jeep của mình và lái xe đến làng để đưa người phụ nữ đến bệпh viện địa phương. Được kịp thời giúp đỡ; cô đã sinh một em bé khỏe mạnh, kháu khỉnh.
Lo lắng cho cậu bé phải ở nhà một mình trong đêm khuya; người đàn ông đứng đầu tổ chức tình nguyện đã gọi một trong những tình nguyện viên khác; và nhờ anh ta chăm sóc cậu bé.
Người tình nguyện viên này không nhiệt tình cho lắm; nên phải mất một lúc lâu mới sức thuyết phục được. Cuối cùng, anh ta gật đầu đồng ý đưa cậu bé đến một số người thân để họ chăm sóc.
Chậm rãi, anh ta rời sự thoải mái khỏi chiếc giường ấm áp và lái xe đến ngôi làng hẻo lánh. Vừa đi anh ta vừa nguyền rủa thời tiết suốt chặng đường.
Sau vài giờ cuối cùng cũng đến đích; anh ta đi vào trong để tìm cậu bé và bế cậu bé lên xe của mình.
**Câu nói của cậu bé làm ấm lại một trái tim**
Cậu bé cứ nhìn chằm chặp vào người đàn ông lạ mặt này trong xe. Cuối cùng cậu ta hỏi “Thưa ông, ông có phải là Chúa không?”
Nổi tiếng với sự lạnh lùng và thờ ơ; người đàn ông đã rất bất ngờ khi nghe câu hỏi này. Anh ta cáu kỉnh hỏi lại “Tại sao cháu hỏi như vậy?”
Cậu bé trả lời rằng khi mẹ cháu đến bệпh viện, bà đã nói với cháu rằng hãy dũng cảm ở nhà. Mẹ cháu còn nói thêm “Chỉ có Chúa mới có thể giúp chúng ta bây giờ!”
Lời nói ngây thơ của đứa trẻ đã mở một phần trái tim bị chôn vùi từ lâu của người đàn ông; và phần đẹp đẽ nhất của con người đã được giải phóng. Người đàn ông mặt đỏ bừng vì xấu hổ. Anh chưa bao giờ nghĩ rằng; một hành động nhỏ như vậy khiến anh trở thành Thượng đế trong mắt đứa trẻ. Dòng điện пóпg bỏng của sự xấu hổ làm tan chảy lớp băng quanh trái tim anh.
Một cách âu yếm, anh ấy vươn tay đặt tay lên đầu cậu bé và nói “Nhóc con, tôi không phải Chúa, tôi là bạn của cậu.”
Trong cuộc sống chúng ta, chỉ có lòng thiện lương như đứa trẻ mới có thể hóa giải được những trái tim băng giá.
Theo Nspirement

## Vết sẹo

Mẹ ruột chúng tôi mất sau khi sinh em trai út của tôi. Chị Như, chị hai tôi, lúc đó mới lên mười. Tôi, đứa con gái thứ hai, lên tám ốm quặt quẹo. Sau nữa, thằng Thành, năm tuổi, tròn như củ khoai ngơ ngác đi tìm mẹ suốt ngày.
Hai năm sau cha tôi tục huyền với người phụ nữ con nhà gia thế, một phụ nữ đẹp mới 27 tuổi. Chúng tôi gọi người này là "má". Cha đi làm từ sáng đến tối, giao phó toàn bộ việc chăm nom con cái cho má tôi. Má làm trăm thứ việc không mấy khi ngơi tay. Chị em tôi no đủ, sạch sẽ, nhà cửa chúng tôi gọn gàng, bữa cơm dọn lên lúc nào cũng nóng sốt.
Cha tôi chung sống với má sau được ba năm thì đau nặng rồi mất. Lúc sắp ra đi, cha không còn nói được chỉ nhìn má tôi rồi khóc. Má lúc đó trẻ quá, đẹp quá lại chẳng phải má ruột của chúng tôi...
Cha vừa nằm xuống được mươi ngày đã có người đến đòi xiết nhà, xiết đồ. Gia đình nhà má khăng khăng bắt má về gả chồng. Rồi một ngày kia má kêu bán nhà, trả hết nợ rồi lặng lẽ dắt díu chúng tôi đi. Đó là năm 1978. Chúng tôi ở đậu nhà người chị họ xa của má, gọi là dì tư Tím. Dì làm nghề ướp cá, bán cá, dì góa bụa và nghèo khó. Căn nhà của dì không khác hơn cái chòi canh dưa là mấy, vậy mà còn chứa thêm má và bốn đứa chúng tôi. Dì tư Tím đem biếu ba con gà mái dầu cho một người quen để xin cho má một chân hộ lý trong bệnh viện đa khoa.
Hằng ngày, má dậy từ 3g30 sáng, vào bệnh viện nấu nước, châm nước cho những bệnh nhân dậy sớm rửa mặt, pha sữa, pha trà để kiếm thêm chút tiền còm mua sách vở cho chị em tôi đi học. Sáu giờ má tất tả về nhà lo cho chúng tôi ăn sáng và đến trường. Bảy giờ má trở lại bệnh viện lau cầu thang, lau sàn, cọ rửa nhà vệ sinh, thay trải giường cho người bệnh, gom rác đem đi đốt… Sau năm giờ chiều, má còn nhận giặt thuê quần áo cho những bệnh nhân khá giả. Đến tám giờ tối má mới về đến nhà, mệt rã rời.
Hôm nào mưa gió má về sớm hơn. Má mua về cho chị em tôi mỗi đứa một trái bắp nướng hay một túi đậu nành rang thơm giòn. Mấy chị em nằm bên má trên một manh chiếu rách, nghe má kể chuyện đời xưa. Thằng út Tài sợ lạnh cứ ôm chặt má mà khen sao má ấm quá. Thằng Thành nhõng nhẽo đòi má gãi lưng. Cũng có khi má dạy chúng tôi những bài hò, bài vè để cả nhà thành một "dàn đồng ca" rất ăn ý, rất vui nhộn, mặc ngoài kia gió thổi mưa tuôn…
Mỗi năm vào ngày giỗ mẹ tôi, má làm một mâm cơm tươm tất. Rồi má thắp mấy nén nhang thơm, gọi hết bốn chị em tôi lại bên bàn thờ mà nói :
- "Đây là mẹ ruột của các con, người đã sinh ra và nuôi nấng các con. Tuy mẹ các con mất rồi nhưng ở trên trời mẹ các con vẫn luôn phù hộ cho các con mạnh khỏe".
Vào ngày giỗ ba, má cũng làm như vậy. Ngày ấy cũng như mãi tới bây giờ cũng vậy, tôi vẫn tin ba mẹ tôi ở trên trời nhìn thấy chúng tôi.
Có một sáng người ta đưa má về. Chân má bị phỏng nước sôi do một bệnh nhân chạy vấp vào má. Vết phỏng rất lớn. Do ăn uống thiếu thốn, sức đề kháng yếu nên chỗ phỏng trên chân má rất lâu không lành, cứ sưng lên đau nhức. Má mất ngủ nhiều, ốm rạc như con cò. Chị hai khóc, năn nỉ má cho đi đổ nước thay má mà má không cho đi. Rồi má nén đau, cố lê chân đi làm trở lại. Về sau vết bỏng ở chân má làm sẹo, một sẹo lồi nhăn nhúm chạy từ cổ chân đến hết mu bàn chân trái. Dáng má đi không còn tự nhiên nữa.
Dì tư Tím mua được một căn nhà ở gần chợ, bán rẻ căn nhà lá cho má con tôi. Năm đó chị hai tôi thi đậu vào Trường cao đẳng Sư phạm Cần Thơ. Thương má cực nhọc, chị định bỏ học đi làm thuê. Má cương quyết không cho. Chưa bao giờ má cương quyết như vậy. Thắp nén nhang trên bàn thờ ba, má khấn (cốt cho chị hai nghe) :
- "Con gái lớn của mình định bỏ học. Khi về nơi chín suối, em biết nhìn anh sao đây…"
Chị hai khóc, xin lỗi má rồi chấp nhận đi học. Hai năm sau tôi cũng vào đại học và cũng được má sắp soạn vali quần áo cho tôi rồi đưa đi. Mở cái vali ra nhìn mà thương má đứt ruột: ngoài quần áo, má còn bỏ vào kim chỉ, dầu gió, tem thư, bông băng, thuốc đỏ, thuốc cảm…
Dường như má có thể gói trọn sự thương yêu của má vào trong từng thứ một. Bốn năm, chị em tôi ra trường lênh đênh tìm việc thì cũng là lúc thằng Thành vào Đại học Luật SaiGon và năm sau nữa là thằng Tài vào Đại học Y Cần Thơ. Làm sao đong được sự vất vả, cực nhọc của má lúc ấy. Lưng má còng đi, tóc đã lốm đốm bạc, da tay chai sần.
Nhiều năm trôi qua má lần lượt dựng vợ gả chồng cho ba đứa con lớn. Thằng Tài vẫn ở với má và chưa có gia đình riêng. Giờ nó là bác sĩ ngoại khoa của bệnh viện mà xưa má làm hộ lý. Nó tâm sự rằng hễ đi trực đêm mà nghe tiếng rao "nước sôi đây" là giật mình thảng thốt tưởng như tiếng má, nghẹn thắt cả lồng ngực.
Những ngày rảnh rỗi, chị em tôi dẫn lũ con về với má cho má vui. Đám trẻ quấn quít với má không rời nửa bước. Đứa nhổ tóc sâu, đứa bóp tay, đứa bóp chân cho bà. Một lần bé Du con tôi xoa vào vết sẹo trên chân má mà nói :
- "Bà ngoại ơi, con bị phỏng tay có một chút đã đau ghê. Ngoại phỏng nhiều vậy chắc là khiếp lắm…"
Má tôi cười :
- "Lâu quá, ngoại quên mất rồi".
Một chiều mưa tôi về thăm má, nằm bên má tâm sự chuyện chồng con. Mưa ầm ào, mưa tầm tã, tôi kêu lạnh má liền kéo mềm đắp cho tôi, tôi thì lại đắp cho má y như lúc tôi còn nhỏ ngủ chung với má vậy. Chân tôi lạnh tôi tìm hơi ấm nơi chân má. Tôi chạm vào vết sẹo trên cổ chân má, cái vết sẹo đã thành thân thuộc với tôi vậy mà tự nhiên tôi rơi nước mắt.
Nghĩ lại, tôi có chồng có con, vợ chồng tôi luôn quấn quít đầm ấm… Còn má, má chỉ được hạnh phúc làm vợ trong ba năm lẻ. Trong những năm tháng dằng dặc sau này, chắc cũng có lúc má khát khao một hạnh phúc riêng tư, cũng có lúc má cô đơn, mệt mỏi mà không có ai chia sẻ. Má ơi, sự lựa chọn của má sao nghiệt ngã quá vậy!
Đã bao lần má kể cho các con tôi nghe những câu chuyện cổ tích về công chúa, về hoàng tử, về các cô tiên xinh đẹp… Một ngày kia con tôi lớn lên, tôi sẽ kể cho các con tôi nghe về "Bà Tiên" của chị em tôi, bà tiên tóc bạc, dáng đi hơi khập khiễng vì một vết sẹo dài… Truyện cổ tích má viết cho chúng tôi bằng cả sự nhọc nhằn, sự đau đớn, bằng nước mắt, mồ hôi và bằng cả cuộc đời của Má.
Lê Thuý Bảo Nhi

## Ứớc mơ cuối cùng

Người mẹ trẻ 26 tuổi nhìn xuống đứa con đang bị bệnh bạch cầu đến giai đoạn cuối. Mặc dù trái tim người mẹ tràn ngập đau khổ, cô vẫn có sự quả quyết mạnh mẽ…
Như mọi cha mẹ khác, cô rất muốn con lớn lên và đạt được mọi ước mơ của mình. Bây giờ thì chuyện đó không thể được nữa. Bệnh Bạch cầu không cho phép con cô thực hiện ước mơ của mình. Nhưng cô vẫn muốn tạo ra cho con một điều kỳ diệu. Cô nắm lấy tay con và hỏi: “BoBsy, con có Bao giờ nghĩ đến chuyện sẽ trở thành gì khi lớn lên không? Con có mơ ước về điều mà con sẽ làm trong cuộc đời mình?”
“Mẹ à, con vẫn ước mơ sẽ trở thành lính cứu hỏa khi con lớn lên”.
Người mẹ mỉm cười: “Hãy chờ xem chúng ta có thể làm cho ước mơ đó trở thành sự thật hay không nhé”.
Trong ngày hôm đó, cô đi đến đội cứu hỏa khu vực của Phoenix, Arizona. Ở đó cô gặp lính cứu hoả BoB, người được xem là có trái tim lớn hơn cả thành phố Phoenix. Cô giải thích ước mơ của con mình và xin cho con cô được đi một vòng trên xe cứu hỏa. Người lính cứu hỏa BoB nói: “Xem này, chúng tôi có thể làm hơn thế nữa. Nếu cô có thể chuẩn bị cho con vào 7 giờ sáng thứ Tư, chúng tôi sẽ cho cậu bé trở thành lính cứu hỏa danh dự của cả ngày. Cậu bé có thể tới trạm cứu hỏa, ăn cùng chúng tôi, chạy cùng chúng tôi tới tất cả các vụ cứu hoả trong ngày. Và nếu cô cho chúng tôi kích cỡ của con cô, chúng tôi sẽ làm cho cậu bé một bộ đồng phục lính cứu hỏa dành riêng cho cậu, với một cái mũ cứu hỏa – không phải là đồ chơi – với phù hiệu lính cứu hỏa Phoenix trên đó, một bộ áo nhựa màu vàng như của chúng tôi và ủng cao su. Tất cả đều được làm tại Phoenix nên chúng ta sẽ có rất nhanh thôi”.
Ba ngày sau người lính cứu hỏa BoB đến đón BoBsy, mặc cho cậu bộ đồng phục của lính cứu hỏa và đưa cậu từ giường bệnh đến chiếc xe cứu hỏa đang chờ. BoBsy ngồi ở ghế sau và giúp lái chiếc xe về đến trạm. Cậu bé cảm thấy như đang ở trên thiên đường. Hôm đó có 3 cú điện thoại gọi cứu hỏa và BoBsy đã tham dự cả 3. Cậu đi trên một chiếc xe cứu hỏa khác, một chiếc xe y tế, và cả trên chiếc xe của Chỉ huy lính cứu hỏa. Cậu còn được đài truyền hình địa phương quay phim.
Với giấc mơ trở thành sự thật, với tất cả tình yêu và sự quan tâm săn sóc mà mọi người dành cho, BoBsy vô cùng xúc động và hạnh phúc đến mức mà cậu đã sống thêm được 3 tháng – một thời gian dài hơn mức tất cả các Bác sĩ dự đoán.
Một đêm nọ, tất cả các dấu hiệu sự sống của cậu Bé tụt xuống một cách đột ngột. Người y tá trưởng nhớ đến ngày mà BoBsy sống như một lính cứu hỏa, cô gọi cho chỉ huy lính cứu hỏa và hỏi có thể gửi một người lính cứu hỏa trong đồng phục đến với cậu trong lúc này hay không.
Người chỉ huy trả lời: “Chúng tôi sẽ có mặt ở đó trong vòng 5 phút nữa. Cô có thể giúp chúng tôi một việc được không? Khi cô nghe tiếng và ánh chớp phát ra từ xe cứu hỏa chạy đến thì xin cô hãy thông Báo qua radio cho toàn Bệnh viện nghe rằng đó không phải là có Báo động cháy. Đó chỉ là đội cứu hỏa đến để chia tay với một trong trong những thành viên tuyệt vời nhất của mình. Và xin cô hãy mở cửa sổ của phòng cậu bé. Xin cám ơn”.
Khoảng 5 phút sau, chiếc xe cứu hỏa với cả móc và thang chạy đến Bệnh viện, dựng cái thang lên cho đến cửa sổ phòng BoBsy ở lầu 3, 14 lính cứu hỏa nam và 2 lính cứu hỏa nữ trèo qua thang vào phòng của BoBsy. Được mẹ cậu bé cho phép, họ ôm cậu và nói với cậu bé rằng họ rất yêu cậu.
Với hơi thở cuối cùng trong cuộc đời mình, BoBsy nhìn lên người chỉ huy và nói: “Thưa chỉ huy, vậy cháu là lính cứu hỏa thật sự phải không?”
“Phải, cháu là lính cứu hỏa thật sự”, người chỉ huy nói.
Với những lời nói đó, BoBsy mỉm cười và nhắm mắt lại mãi mãi.

## Cặp vợ chồng cùng nhau đi viện dưỡng lão

Trong căn phòng nhỏ ở viện dưỡng lão, hai ông bà mỗi người có một vali riêng, cất thứ họ quý trọng nhất. Chiếc vali của ông Thọ có một cuốn vở tự đóng, phác họa lại những bức ảnh của họ đã chụp sáu thập kỷ qua. Chiếc ở đầu giường bà Tú là một tập thư dầy cộp, được bọc cẩn thận trong tấm lụa và vài lớp túi nilon. Đây là những lá thư mà chồng gửi cho bà trong những khoảng thời gian họ phải xa nhau.
"Tương lai của chúng tôi giờ đặt trọn vào viện dưỡng lão này. Hàng ngày tìm niềm vui ở chính mình và góp phần vào làm vui cho tập thể các cụ ở đây", cặp vợ chồng già nói.
Sáu mươi lăm năm trước, ông Thọ là thầy giáo trường cấp 3 Việt Đức phải lòng cô giáo trẻ Đinh Thị Dục Tú ngay phút đầu gặp mặt. Để chinh phục "nàng", chàng trai trổ tài vẽ tranh và chơi nhạc bằng kèn harmonica. Song, điều khiến cô gái Hà Nội xiêu lòng là tính tình của ông. "Ông ấy vô cùng hiền", cụ bà 86 tuổi đúc kết về chồng.
Họ cưới nhau năm 1960. Sau vài năm không có con, người vợ đã đến gặp những danh y hàng đầu, uống đủ loại thuốc, cơ thể vốn đã nhỏ bé, vì ba lần làm thủ thuật mà chỉ còn chưa đầy 40 kg. Xót vợ, người chồng không cho chữa trị nữa với tuyên bố: "Không biết có con hạnh phúc đến mức nào nhưng nhìn mình đau tôi đang mất dần hạnh phúc".
Tình yêu, sự đồng cảm của chồng và gia đình hai bên dần khiến bà Tú chấp nhận không thể sinh nở. Tuy nhiên, bà vẫn luôn dằn vặt bởi suy nghĩ "không thể ích kỷ cướp đi hạnh phúc làm cha" của chồng. Vì yêu mà bà viết đơn ly dị. Cả năm lần đưa đơn đều bị xé vụn trong nước mắt. Lần cuối cùng, người chồng quả quyết: "Suốt đời này anh chỉ có em là vợ. Em làm thế là xúc phạm anh". Kể từ đó, họ không bao giờ đề cập đến chuyện sinh con hoặc ly hôn nữa.
Trải qua những khó khăn của chiến tranh hay thời bao cấp, cả hai ngày càng trân trọng tình yêu của mình. Có thời gian các trường phải sơ tán về nông thôn tránh chiến tranh phá hoại, đôi vợ chồng ở cách nhau 40 cây số. Chẳng có cuối tuần nào họ không đạp xe đến thăm nhau. Mỗi lần chào từ biệt, người này dúi vào tay người kia lá thư, dặn khi về tới nơi mới được mở.
Nhiều đêm cuối tuần, thầy giáo Thọ đèo vợ trên chiếc xe đạp cọc cạch, vượt qua những con đường đất tối om về căn phòng trọ nhỏ ở phố Hàng Cân. Họ trân trọng những lúc cùng nhau đi ăn phở "không người lái" hay một quả chuối bẻ đôi. "Vì gặp nhau trong gian khổ mà tình thương càng quyện chặt với tình yêu", ông Thọ kể.
Năm 1972, thầy giáo Nguyễn Ngọc Thọ chuyển sang làm phóng viên của Đài tiếng nói Việt Nam và tham gia đoàn nhà văn, nhà báo vào chiến trường Quảng Trị. Vào đến thành cổ, ông bị chảy máu dạ dày, phải cấp cứu dưới hầm địa đạo. Tác nghiệp xong quay ra thì địch ném bom ác liệt, xe ông bị trúng bom ở bến phà Xuân Sơn suýt chết.
"Sau hai tháng tôi gặp lại được chồng trong bệnh viện. Ông ấy gầy, đen, râu ria tua tủa. Tôi xót xa xen lẫn niềm vui, bởi sống sót trở về đã hạnh phúc rồi", bà Tú rơm rớm kể.
Thời trẻ, tình yêu của họ không thể tách rời, nhưng giai đoạn nghỉ hưu tình cảm của cặp vợ chồng mới thực sự thăng hoa nhất. Từ lúc xác định không có con cái, ông bà lên kế hoạch tìm niềm vui theo cách khác. Ông chăm chỉ làm thêm, dịch sách và dạy học tới khi nghỉ hưu đầu những năm 90 đã có một số tích lũy khá lớn.
Họ thực hiện ước mơ đi du lịch thế giới cùng nhau. Chuyến đi để lại ấn tượng sâu đậm nhất với cả hai là tới Ấn Độ và Nam Phi. "Chúng tôi ngồi trên thuyền đi trên sông Nile. Một bên là khung cảnh hoang sơ, hàng quán và người bán hàng ăn mặc theo kiểu cổ đại, một bên là các khách sạn hiện đại, nước sông trong vắt nhìn thấy đáy", bà Tú kể về chuyến đi năm 1992. Trong hai thập kỷ, cặp vợ chồng già đã đi qua ba châu lục, tới thăm 15 quốc gia. Đôi chân của họ chỉ dừng lại cách đây 5 năm khi sức khỏe không cho phép.
Một niềm vui khác lúc nghỉ hưu của họ là khiêu vũ. Khắp các sàn nhảy ở Hà Nội, mỗi lúc nhạc cất lên, cụ ông hóa thành người nam lịch thiệp, cụ bà thành người nữ đoan trang. Qua mỗi bước nhảy, họ tìm thấy sức khỏe, sự dẻo dai và cả thanh xuân.
Vào viện dưỡng lão đã nằm trong kế hoạch của vợ chồng ông Thọ từ khi xác định không có con. Bốn tháng trước họ làm tiệc từ biệt bạn bè và người thân. Cuộc chia tay không hụt hẫng hay nỗi buồn man mác mà là niềm vui về một thứ hạnh phúc viên mãn.
Đúc kết lại cuộc hôn nhân 61 năm, cặp vợ chồng già cho biết vợ chồng sống với nhau sẽ không thể tránh được lúc cơm chẳng lành canh chẳng ngọt nhưng tuyệt nhiên họ không bao giờ to tiếng hay để lại ấn tượng xấu trong lòng người kia. "Là người đàn ông không có quyền làm đau khổ phụ nữ, nhất là khi người phụ nữ ấy là vợ mình", ông Thọ âu yếm nhìn vợ nói.
Trong căn phòng nhỏ ở viện dưỡng lão, hai ông bà mỗi người có một vali riêng, cất thứ họ quý trọng nhất. Chiếc vali của ông Thọ có một cuốn vở tự đóng, phác họa lại những bức ảnh của họ đã chụp sáu thập kỷ qua. Chiếc ở đầu giường bà Tú là một tập thư dầy cộp, được bọc cẩn thận trong tấm lụa và vài lớp túi nilon. Đây là những lá thư mà chồng gửi cho bà trong những khoảng thời gian họ phải xa nhau.
"Tương lai của chúng tôi giờ đặt trọn vào viện dưỡng lão này. Hàng ngày tìm niềm vui ở chính mình và góp phần vào làm vui cho tập thể các cụ ở đây", cặp vợ chồng già nói.
(Theo VNExpress)

## Ở đây họ gọi nhau là 'cưng', nghe thương gì đâu

Năm 2010, tôi lại ghé TP.HCM. 
Tôi không thích một thành phố đông đúc và chen chúc người, cái nóng hầm hập phả lên làn da đến khó chịu. Chẳng đến mức túa mồ hôi nhưng cũng làm một đứa trẻ như tôi muốn rệu rã. Anh tài xế thỉnh thoảng ghé nhìn từ gương chiếu hậu, tò mò hỏi: "Em gái bị sao dzậy, dì?".
Mẹ cũng chẳng ngại ngần kể lại câu chuyện với một người lạ nhiệt tình. Anh tài xế vừa nghe vừa gật gù chép miệng: "Thiệt, mấy thằng ông trời giờ chạy xe ra đường có thèm dòm ai đâu. Nó ưng chạy sao nó chạy hà". Chốc lát lại tặc lưỡi thương xót: "Tội con nhỏ dễ sợ! Mới có mười tám chớ nhiêu...".
Suốt chặng đường nghe anh rôm rả trò chuyện, khi thì hỏi mẹ con tôi tới bệnh viện nào và ở lại bao lâu, đôi lúc im lặng để suy nghĩ điều gì đó rồi lại ồ lên khuyên mẹ nên đưa tôi tới nơi này nơi kia. Khi tới nơi, anh đậu xe lại bên đường, nhiệt tình xách theo mớ hành lý, đưa tôi và mẹ vào bệnh viện làm thủ tục giấy tờ.
Mẹ ái ngại và hối thúc anh rời đi, nhưng anh vẫn nhiệt tình chạy lăng xăng khắp nơi như anh con trai trong nhà vậy. Khi tôi đã nằm yên vị trên băng ca để chờ các thủ tục tiếp theo, anh mới vội vàng từ biệt mặc cho mẹ nài nỉ gửi anh thêm ít tiền vì đã làm lỡ của anh mấy cuốc xe. Bóng anh chìm vào đám đông, mẹ tôi bất chợt tặc lưỡi: "Cái thằng tính tình thiệt... cưng ghê".
Lúc ấy, tôi vẫn chưa biết được rằng ở thành phố này không phải chỉ riêng mình anh mà ai ai cũng đều có sẵn trong người cái sự hồn hậu và chân thành đến dễ cưng như thế.
Kể như chị y tá trưởng phòng bệnh tôi nằm vậy. Chị giống như một người thân trong nhà hơn cô y tá nơi bệnh viện. Cứ liên tục ghé qua cái phòng bệnh kê sáu chiếc giường trong một ngày, lặp đi lặp lại những điều nghe đã quen tai nhưng chẳng ai chán ghét. 
Hỏi người này tình hình vết mổ ra sao, có còn thấy đau ở chỗ nào. Tỉ mỉ dặn dò từng người trong phòng bệnh đủ thứ. Mỗi lần chích thuốc, như sợ làm đứa em đau, tôi lúc nào cũng nghe chị rỉ rả.
"Chị chích mà có đau thì cưng la lên cho chị hay nghen!".
"Có mệt ở đâu thì báo chị hay nghen!".
"Cưng phải ăn uống để lấy sức mổ nghen!".
Tôi yêu cái sự dễ thương mà ngày nào chị đều ghé qua giường bệnh, "cưng" tới "cưng" lui. Cũng yêu cái sự dịu dàng và tử tế của mấy vị y bác sĩ nơi đây khiến cho bệnh viện trở nên tràn ngập những thân quen và ấm áp.
Kể là mấy dì lớn tuổi mỗi ngày đều cẩn thận đến từng phòng gọi người nhà bệnh nhân ra lấy cháo, lấy cơm từ thiện. Hay bác xe ôm trước cổng chẳng khó chịu khi không bắt được khách mà còn tận tình chỉ dẫn tôi và mẹ lên chuyến xe nào, trước lúc mẹ con tôi lên xe rời đi vẫn còn giọng nói vang lên từ đằng xa nhắc nhở: "Cô bỏ cái dây chuyền vô trong áo khoác rồi kéo lên đi, hông mấy thằng "cô hồn" nó "đua" đó cô ơi".
Tôi nhìn mẹ, mẹ lại nhìn tôi, trộm cười. Người thành phố họ tử tế với nhau đến mức dung dị như thân quen lắm. Tôi và mẹ là khách lạ, thế nhưng họ cũng dành cho chúng tôi những điều rất thật và chân tình.
Năm mười tám ghé lại thành phố ấy, tôi mang theo vài vết thương và những sợ sệt. Sợ một thành phố lạ lẫm, sợ cái nhìn soi mói từ người lạ. Thế nhưng người thành phố lại vỗ về tôi một cách tử tế và dịu dàng. Họ gọi tôi là cưng, chép miệng thương cảm cho cô gái lạ. Vẫn với chất giọng đặc biệt ngày xưa ấy tôi đến, chỉ khác là giờ đây họ dùng nó để dỗ dành và ve vuốt những lo sợ trong tôi.
Thế nhưng người Sài Gòn lại là người quen, với đứa trẻ đã từng sợ sệt như tôi hay bất kỳ ai đều dành trọn những gì tử tế và nhiệt tình nhất. Có lẽ do vậy nên người ta ghé đến thành phố rồi lại chẳng nỡ rời đi. Giờ đây, nếu có ai hỏi về Sài Gòn, tôi sẽ chẳng đắn đo mà trả lời: người Sài Gòn dễ... cưng lắm. Bởi một lẽ, ở đây họ cưng nhau như cái cách gọi nhau là "cưng" vậy.
(**TUỔI TRẺ)**

## Người mẹ hiến tạng con, cứu 6 người

Tròn nửa năm kể từ ngày một phần cơ thể con tiếp tục sống cùng những người khác, bà Nhường đã biết danh tính năm trong số sáu người nhận được tạng của con mình, duy nhất chưa biết người nhận trái tim là ai. Bà đành viết lên mạng nhờ tìm thông tin:  _"Nếu ai biết hoặc người nào nhận trái tim vào trưa ngày 16 hoặc 17/9/2020 mong mọi người nhắn giúp tôi"._
Chiều 22/3, trong căn nhà hai tầng tại Phố Đông (Thanh Tùng, Thanh Miện), bà Nhường thay ga giường và phủi bụi tủ quần áo của người con trai tên Thắng đã mất. Từ ngày anh đi, chẳng có ai vào phòng nhưng cứ vài ngày bà lại dọn dẹp, vì tin con đang ở bên mình.
Thắng là tình yêu, hy vọng và cả chỗ dựa của bà Nhường, kể từ khi chồng và con gái thứ hai qua đời hai chục năm trước. "Hồi ông nhà tôi mất, thằng bé mới 11 tuổi. Có lần nó còn dặn tôi, trưa nắng mẹ đừng về cho vất vả, con tự làm cơm cúng bố được", người phụ nữ từng là hộ sinh tại Trung tâm y tế dự phòng, Bệnh viện huyện Thanh Miện, chia sẻ.
Anh tốt nghiệp Đại học Thủy lợi và công tác tại Công ty thủy lợi 1 (Bắc Ninh). Mỗi lúc mẹ giục lấy vợ, anh hứa hẹn: "Bố con mất sớm, mẹ lại vất vả với con bao năm nay. Lấy vợ rồi con sợ không chăm sóc tốt được cho mẹ nên 32 tuổi con mới lấy". Bà Nhường đinh ninh cuối năm 2020 con sẽ lấy vợ.
Sáng ngày 11/9/2020, người phụ nữ thất thập đang ngồi chơi với mấy bạn già trong xóm, lòng dự tính chiều sẽ nấu canh cua và xay nước rau má để tối con về. Bỗng nhiên, cú điện thoại từ người họ hàng khiến bà loạng choạng, vỡ vụn nỗi háo hức chờ con mỗi cuối tuần: "Đêm qua Thắng bị tai nạn, đang cấp cứu ở bệnh viện tỉnh".
Anh Thắng bị tai nạn giao thông lúc gần 11 giờ đêm hôm trước. Bốn ngày sau, chàng trai 32 tuổi không qua khỏi.
Lúc đó con gái cả của bà Nhường, chị Nguyễn Thanh Chung và họ hàng có nguyện vọng [hiến tạng](https://bvnguyentriphuong.com.vn/lieu-thuoc-tinh-than/7-mo-tang-cho-6-nguoi-benh-tu-mot-nguoi-hien). Ban đầu bà không đồng ý nhưng chị cố thuyết phục: "Mẹ nghĩ lại đi vì sau này có muốn hiến tạng cũng không còn cơ hội nữa đâu. Hiến bao nhiêu tạng là 'thêm bấy nhiêu em Thắng'. Em sẽ vẫn bên mẹ".
Lý lẽ này của người con gái lớn khiến bà Nhường đồng ý vì tin con mình có thể tái sinh trong nhiều cuộc đời khác. "Trước khi ký vào hồ sơ tôi đưa ra một nguyện vọng: Những tạng nào, người nào nhận hãy cho tôi biết cụ thể về họ tên và địa chỉ", bà chia sẻ.
Sáng ngày 16/9, gia đình được gặp mặt con lần cuối. Ngay sau đó, các bác sĩ đã thực hiện ca lấy tạng từ người cho chết não để ghép cho năm bệnh nhân khác nhau tại Bệnh viện trung ương quân đội 108, bao gồm: ghép hai lá phổi cho một bệnh nhân bị xơ phổi; ghép gan cho một bệnh nhân suy gan; ghép hai quả thận cho hai bệnh nhân bị suy thận mạn tính giai đoạn cuối; ghép đồng thời hai cẳng bàn tay cho một bệnh nhân bị tai nạn chất nổ.
Riêng tim của người đã mất được ghép cho một bệnh nhân ở Bệnh viện Việt Đức. Tang lễ của anh Thắng được tổ chức trong chiều hôm đó, có đại diện Bệnh viện Phổi, Bệnh viện 108, cùng một số người của các gia đình bệnh nhân được ghép tạng tiễn đưa. Câu chuyện chàng thanh niên chết não hiến tạng cứu sáu người được đăng tải nhiều trên báo đài.
Trung tướng Mai Hồng Bàng, giám đốc bệnh viện 108 cho biết: "Tháng 11/2020, bệnh viện nhận được đề nghị cung cấp thông tin về người nhận tạng của bà Nhường nhưng theo quy định của pháp luật, thông tin về người cho, nhận trong quá trình hiến, lấy, ghép tạng phải được bảo mật. Đại diện bệnh viện đã gặp gỡ, động viên và giải thích với gia đình. Ngày 24/11/2020, gia đình đã xin rút đơn".
Đang điều trị tại Bệnh viện 108 sau khi nhận hai tay, Nam, 18 tuổi (quê Thái Nguyên), xem bà Nhường như bà nội mình. Tai nạn chất nổ ba năm trước khiến cậu thiếu niên bị mất hai cẳng bàn tay nên gia đình đăng ký chờ được hiến tạng. Gần 1.000 ngày qua, cậu thiếu niên nuôi hy vọng mong manh một ngày nào đó phép màu đến với mình.
Hai bàn tay của con bà Nhường giờ nằm trên cơ thể Nam, bước đầu cậu đã có thể cầm nắm, có cảm giác nóng lạnh. Bàn tay này cũng đã nắm đôi bàn tay nhăn nheo của bà Nhường, đã vòng sau lưng ôm bà như đứa cháu quấn quýt nội mình.
"Lần đầu bà đến thăm, mặt bà nhìn em thì vui, nhưng ánh mắt thoáng buồn. Có lẽ bà nghĩ đến anh. Những lần sau tới bà vui hơn. Bà không còn kể chuyện về anh nữa mà hỏi em đã bình phục thế nào", Nam chia sẻ. Bà Nhường từng lên bệnh viện thăm Nam nhiều lần, có lần còn ở lại chăm sóc cậu vài ngày.
Bà Nhường cảm thấy được an ủi rất nhiều khi biết đôi tay của con ngày một tương thích với cơ thể cậu bé Nam, được mang ruốc tới thăm người đang mang thận của con, thi thoảng hỏi thăm bác nhận phổi, người mẹ già cũng mong được nói cảm ơn người đang ôm ấp trái tim của con mình...
(Theo VNExpress)

## 7 mô/tạng cho 6 người bệnh từ một người hiến

Người đàn ông ấy là là anh Dương Hồng Quý (43 tuổi, chủ một hiệu kim hoàn ở TP. Ninh Bình)
Anh Quý phát hiện mình mắc bệnh về mạch máu não từ tháng 11/2018. Khi biết mình không thể qua khỏi, anh Quý đã gọi các thành viên trong gia đình mình tới và đưa ra đề nghị được hiến tạng để cứu sống những người khác.
Khi anh Quý rơi vào tình trạng hôn mê sâu và được các bác sĩ tiên lượng không thể qua khỏi, vợ anh là chị Hoàng Thanh Phương và cả gia đình anh đã cùng liên hệ để xin được hiến tạng của anh cho y học.
Gia đình anh Quý đã kết nối với Hội Chữ thập đỏ tỉnh Ninh Bình, kết nối với gia đình thiếu tá Lê Hải Ninh (thiếu tá Lê Hải Ninh đã từng hiến đa tạng vào tháng 2/2018)̉ và sau đó liên hệ với Trung tâm Điều phối ghép tạng Quốc gia đề đạt nguyện vọng.
Sau khi tiếp nhận thông tin, Trung tâm được biết bệnh nhân Dương Hồng Quý đang nằm tại Bệnh viện Bạch Mai. Ban Lãnh đạo Trung tâm Điều phối ghép tạng Quốc gia đã quyết định phối hợp với Bệnh viện Bạch Mai, Bệnh viện Việt Đức để đưa bệnh nhân về Bệnh viện Việt Đức.
Anh Dương Hồng Quý đã tặng lại tim, gan, phổi và 2 thận cho 5 người bệnh nặng đang chờ đợi. Trong đó toàn bộ lá phổi được Bệnh viện Việt Đức ghép cho thiếu niên 17 tuổi ở Hải Dương mắc bệnh mô bào ở phổi giai đoạn cuối, cơ thể suy kiệt chỉ còn 30kg. Trái tim của anh được ghép cho nam bệnh nhân 60 tuổi bị giãn cơ tim giai đoạn cuối, nguy cơ cao tử vong trong vòng 1 tháng nếu không có tim ghép; Gan được ghép cho bệnh nữ 63 tuổi mắc u gan; 1 quả thận được ghép cho nam bệnh nhân 41 tuổi bị suy thận giai đoạn cuối, quả thận còn lại được chuyển vào Bệnh viện Nhi đồng 2, TPHCM ghép cho nam thiếu niên 15 tuổi. Mạch máu của anh Quý cũng được lưu trữ tại Ngân hàng mô ở Bệnh viện Việt Đức.
Trước khi các bác sĩ đưa anh đi, chị Phương (vợ anh Quý) đã cầm tay anh thật chặt và cúi xuống hôn anh. Bởi chị biết họ đã thực sự phải đến giờ phút chia ly.
Chiều 26/12/2018 một bệnh nhân bị suy gan cấp được các bác sĩ Trung tâm ghép tạng Bệnh viện Việt Đức tiến hành ca ghép gan. Người cho gan là một người sống. Các bác sĩ đã lấy nửa phần gan của người này để ghép cho bệnh nhân.
Ca phẫu thuật rất phức tạp do các mạch máu của phần gan lấy từ người hiến sống rất ngắn. Vì vậy, các bác sĩ phải sử dụng đoạn mạch máu của anh Quý đang lưu trữ ở Ngân hàng mô để nối dài mạch máu ghép gan cho bệnh nhân. Nhờ đó, ca phẫu thuật đã được thực hiện dễ dàng.
Như vậy, anh Quý là người Việt Nam đầu tiên hiến 6 mô/tạng để cứu 7 người.
Gia đình của anh Quý

## Cái giá của kinh nghiệm

Động cơ của một con tàu lớn bị hỏng và không ai có thể sửa chữa nó, vì vậy họ đã thuê một kỹ sư cơ khí với hơn 40 năm kinh nghiệm.
Anh kiểm tra động cơ rất kỹ lưỡng, từ trên xuống dưới. Sau khi nhìn thấy mọi thứ, người kỹ sư dỡ túi và rút ra một chiếc búa nhỏ.
Anh nhẹ nhàng gõ một cái gì đó. Chẳng bao lâu, động cơ đã hoạt động trở lại. Động cơ đã được sửa chữa!
7 ngày sau, kỹ sư đề cập rằng tổng chi phí sửa chữa con tàu khổng lồ là 20.000 đô la cho chủ tàu.
Chủ sở hữu: “Cái quái gì? Anh hầu như không làm gì cả. Hãy cho chúng tôi một hóa đơn chi tiết."
Đơn giản: “Gõ bằng búa: $ 2.
Biết gõ ở đâu và gõ như thế nào: $ 19.998”
Tầm quan trọng của việc đánh giá cao chuyên môn và kinh nghiệm của một người... Bởi vì đó là kết quả của những cuộc đấu tranh, thử nghiệm và thậm chí cả nước mắt.
Nếu tôi làm một công việc trong 30 phút, đó là bởi vì tôi đã dành 20 năm để học cách làm việc đó trong 30 phút. Bạn nợ tôi những năm tháng, không phải phút giây.
- - -
"Thầy thuốc già - con hát trẻ", thật ra cái điều mà không có bất cứ ai dạy tốt hơn và cũng không có ai lấy giá đắt hơn: kinh nghiệm!
Vì vậy, ngành y luôn tôn vinh những bậc đàn anh với tất cả sự kính trọng - đó là luật bất thành văn và bất biến!

## Chuyến taxi cuối cùng của đời người

Một đêm kia, có người gọi xe ở khu chung cư vào lúc 2 giờ 30 sáng. Tôi đến nơi, các dãy nhà đều chìm lẫn trong bóng đêm ngoại trừ ánh sáng mù mờ từ khung của sổ kéo màn kín. Trong trường hợp này, các người lái xe thường nhấn còi một hay hai lần và chờ khoảng một phút, nếu không thấy động tĩnh gì là họ lái xe đi…
Nhưng tôi cũng biết rất nhiều người nghèo không có xe cộ gì cả và tắc xi là phương tiện di chuyển duy nhất mà họ trông cậy trong những hoàn cảnh đặc biệt hay trong những giờ giấc bất thường…. Trừ khi linh cảm có gì nguy hiểm ngăn cản, tôi thường ra khỏi xe và đi đến tận cửa, tự nhủ biết đâu có người đang cần tôi giúp…
Nghĩ như thế tôi bước tới gõ cửa.
“Xin chờ một chút” giọng nói rõ ràng là của một người già nhưng vẫn có phần trong trẻo và tôi có thể nghe tiếng của các vật dụng dường như đang bị kéo đi trên sàn nhà… Vài phút sau, cửa mở, một bà cụ khoảng 80 tuổi đứng ngay trước mặt tôi. Cụ mặc chiếc áo đầm dài in hoa, đội cái mũ trắng xinh xắn với dải lụa gài chung quanh, trông giống y như một người nào đó từ cuốn phim của những năm 1940 chợt bước ra, với chiếc va ly vải bên cạnh. Sau lưng cụ, căn phòng chung cư trống trải như quanh năm không có ai cư ngụ, tất cả bàn ghế đều được phủ kín bằng những tấm trải giường. Liếc nhìn qua vai cụ, không có bất kỳ vật dụng nào trên quầy trong bếp hay trên tường cả và sát chân tường trong góc phòng tôi có thể thấy mấy cái thùng giấy đầy những ly tách và khung ảnh sắp xếp gọn gàng, ngăn nắp. – Phiền ông mang giúp tôi cái va ly này ra xe…
Tôi đem chiếc va ly cất ở thùng xe phía sau và quay trở lại giúp bà cụ. Cụ nắm cánh tay tôi và từng bước một, tôi dìu cụ xuống đường hướng về chiếc xe… Cụ luôn miệng nói cám ơn… “Không có chi, thưa cụ” – tôi nói, “cháu coi những người lớn tuổi như là mẹ của cháu vậy… ” – Cụ trả lời: “Ông tử tế lắm…. ”.
Sau khi giúp cụ yên ấm trên băng ghế sau, Tộι ngồi vào ghế lái và nổ máy xe. Cụ đưa cho tôi tờ giấy ghi địa chỉ nơi cụ muốn đến và hỏi tôi, rất nhỏ nhẹ:
– Ông có thể chạy ngang qua dưới phố cho tôi một chút không…
Liếc mắt vào tờ giấy ghi địa chỉ, tôi buột miệng:
– Nếu lái xuống phố thì đường xa hơn và lâu hơn nhiều…
– Cứ thong thả, ông à, không có gì vội vã cả, Tôi chỉ đi tới hospice thôi… (hospice: nhà dành cho những người sắp từ giã cuôc sống).
Tôi ngước mắt nhìn, qua tấm gương chiếu hậu, đôi mắt cụ long lanh trong bóng tối.
– Tôi không còn ai thân thích trên cõi đời này, và bác sĩ đã nói tôi cũng chẳng còn bao lâu nữa, hai hay ba tuần là nhiều…
Vói tay tắt cái máy ghi khoảng cách và tính tiền, tôi hỏi một cách nhỏ nhẹ:
– Thưa cụ muốn đi qua đường nào trước…
Trong hơn hai giờ kế tiếp, chúng tôi hầu như đi lanh quanh qua từng con đường trong các khu phố.
Cụ chỉ cho tôi toà nhà nhiều tầng mà một thời cụ đã làm người điều khiển thang máy.
Tôi lái xe qua một khu phố với những căn nhà nhỏ đã cũ nhưng xinh xắn, cụ nói với tôi ngày trước khi mới lập gia đình cụ đã ở trong khu này, và chỉ cho tôi căn nhà loang loáng dưới ánh đèn đêm…
Nhìn ánh mắt lưu luyến của cụ, tôi như thấy một trời quá khứ thương yêu đằm thắm của đôi vợ chồng trẻ.
Cụ ra hiệu cho tôi ngừng xe trước nhà kho của cửa tiệm bán giường tủ, bàn ghế, nhẹ nhàng bảo tôi trước đây chỗ này là một vũ trường sang trọng và nổi tiếng, cụ đã từng hãnh diện đến đây khiêu vũ lần đầu khi là một thiếu nữ mười sáu tuổi…
Trong giọng nói cụ tôi thấy thấp thoáng hình ảnh một thiếu nữ trẻ trung sáng ngời với bộ dạ phục xinh đẹp và nụ cười tươi tắn hân hoan… Đôi khi, cụ bảo tôi đậu xe trước một toà nhà nào đó hay ở một góc phố khuất nẻo không tên…. và cụ im lặng thẫn thờ trong bóng tối như đắm chìm với cả một dĩ vãng xa xăm bao la và sâu thẳm…
Khi trời chập choạng trong ánh sáng đầu tiên của ban ngày, cụ nói với tôi khẽ khàng như một hơi thở nhẹ:
– Thôi, mình đi…
Tôi lái xe trong im lặng đến khu nhà hospice. Đó là một dẫy nhà thấp, kín đáo, ngăn nắp và gọn gàng. Tôi vừa ngừng xe là đã có hai người xuất hiện với chiếc xe lăn như là họ đã chờ đợi từ lâu rồi. Tôi bước xuống mở thùng xe phía sau để lấy chiếc va ly nhỏ của cụ mang tới để ngay cửa chính, xong quay trở ra đã thấy cụ đã được đỡ ngồi ngay ngắn trên chiếc xe lăn.
– Bao nhiêu tiền vậy cháu? – Cụ vừa hỏi vừa mở cái bóp nhỏ…
– Cháu không lấy tiền bác đâu… – tôi trả lời.
– Nhưng cháu phải kiếm sống chứ…
– Đã có những khách hàng khác, thưa bác…
Gần như không tính toán so đo, tôi cúi xuống ôm lấy bờ vai cụ. Đáp lại, cụ ôm tôi thật chặt:
– Cám ơn cháu đã cho cụ già này khoảng thời gian thật quý giá và đầy ý nghĩa.
Tôi xiết chặt tay cụ và quay bước đi trong ánh sáng mờ nhạt của một ngày mới đến. Sau lưng tôi có tiếng cửa đóng. Tôi cảm thấy như cả một cuộc đời vừa được khép lại phía sau.
Tôi không có thêm người khách nào khác trong buổi sáng đó. Tôi chạy xe loanh quanh không có mục đích và dường như tôi cũng chẳng biết mình đi đâu nữa…
Suốt cả ngày hôm đó hầu như tôi không thể nói được với ai lời nào cả… Chuyện gì sẽ xảy ra nếu cụ già gặp phải một người tài xế đang ở cuối buổi làm, nóng nẩy chỉ muốn chóng xong việc để còn về nhà… Chuyện gì sẽ xẩy ra nếu tôi từ chối không nhận đón người khách là cụ hay tôi không bước xuống gõ cửa mà chỉ ngồi trên xe nhận kèn một lần rồi lái xe đi…
Tự nhiên, tôi bỗng nghiệm thấy trong quãng đời trẻ trung ngắn ngủi của mình, dường như là tôi chưa làm được chuyện gì có ý nghĩa hơn là chuyện tôi đã làm trong buổi sáng hôm ấy.
Chúng ta luôn luôn nghĩ rằng cuộc đời sẽ có những khúc quanh quan trọng, đánh dấu bằng những sự việc to lớn, dễ dàng ghi nhớ… Nhưng thật ra, đẹp nhất vẫn là những phút giây nhỏ bé bất ngờ nhưng có xúc cảm mãnh liệt khiến ta phải bàng hoàng đến tê dại cả tâm hồn…
Xin chia sẻ câu chuyện nhỏ này với các bạn, hy vọng vì thế cuộc đời chung quanh chúng ta sẽ ấm cúng và có ý nghĩa hơn.

## Bé gái 7 tuổi tình nguyện hiến tặng giác mạc

Chiều 22/2/2018, bé gái Nguyễn Hải An học sinh trường tiểu học Tân Mai (trú tại thôn Tân Mỹ, quận Nam Từ Liêm, Hà Nội) qua đời vì căn bệnh u thần kinh đệm cầu não lan tỏa – một căn bệnh hiếm ở trẻ em và điều trị vô cùng khó khăn. Sau hơn một tháng điều trị tại bệnh viện nhưng không qua khỏi, mẹ bé và gia đình đã quyết hiến tặng giác mạc của bé để trao ánh sáng cho những người khác. Nghĩa cử cao đẹp của bé Hải An và gia đình đã khiến nhiều người xúc động.
Trước khi bé Hải An qua đời, gia đình bé đã gọi điện đến Trung tâm điều phối quốc gia về ghép bộ phận cơ thể người với nguyện vọng xin hiến tạng để cứu người khác.
Tuy nhiên, quy định hiện hành chỉ nhận nguồn tạng hiến từ người đủ 18 tuổi trở lên, trong khi bé Hải An mới 7 tuổi. Nếu bé không thể tiếp tục sự sống thì chỉ có thể lấy hai giác mạc để đem lại ánh sáng cho hai người có bệnh lý giác mạc.
Là người trực tiếp đến nhận giác mạc của bé, bác sĩ Nguyễn Hữu Hoàng, Giám đốc Ngân hàng Mắt, Bệnh viện Mắt Trung ương (Hà Nội) cho biết, trong hơn 10 năm đi làm chưa bao giờ anh thấy xúc động như thế. Chứng kiến hình ảnh người mẹ đặt nụ hôn lên trán cô bé đã từ giã cõi đời sau khi nói “Con tặng lại ánh sáng cho bạn khác nhé”, bác sĩ Hoàng thấy sống mũi cay cay.
Trong lễ tang của bé ngày 24/2, Bộ trưởng Y tế Nguyễn Thị Kim Tiến đã gửi lời từ biệt. Bộ trưởng viết: “Bé đã làm được một điều khó tin nhưng là sự thật”.
Chiều 26/2, Bệnh viện Mắt Trung ương đã ghép giác mạc của bé Hải An hiến tặng cho một cụ bà 73 tuổi và một người đàn ông 42 tuổi.
Đặc biệt, điều khiến cho cộng đồng mạng xót xa và rơi nhiều nước mắt nhất, đó là sau khi lo xong xuôi hậu sự cho con, chị Dương – mẹ của bé Hải An bất ngờ đọc được những lời nhắn nhủ của con gái trong bảng ghi chú ở iPad. Bé viết nhiều, mỗi lời nhắn được bé chèn vào nhiều bài ghi chú khác nhau: “Mẹ yêu ơi, mẹ gặp lại con chưa?”, “Mẹ ơi, mẹ nghe thấy tiếng tim con đập chưa?, “Mẹ ơi, mẹ vẫn ổn chứ”, “Mẹ ơi, Bun đẻ chưa, mẹ nhớ cho Bun ăn nhé”, “Mẹ nhớ ăn nhiều rau xanh, uống nhiều nước, đừng dùng thuốc ngủ nhé”, “Mẹ ơi, con yêu mẹ, mẹ cười đi nhé!”. “Mẹ ơi, mẹ chờ con 500 năm nhé”, “Mẹ ơi, con yêu mẹ, mẹ phải hạnh phúc nhé…”.
Bé Hải An khi còn sống và mẹ

## ĐIỀU CHƯA HIỂU

##### Hắn, một người đàn ông thành đạt.
Năm ngoái, về thăm nhà, thấy Bố một mình thui thủi, cô đơn trong căn nhà trống vắng, vì Mẹ hắn đã khuất núi từ lâu, Hắn quyết định đưa Ông cụ lên thành phố ở với vợ chồng mình cho trọn đạo người con có hiếu.
Cứ tưởng rằng cụ sẽ vui,vì nhà hắn là một ngôi biệt thự rộng rãi, sang trọng, lại có khu vườn sầm uất bao quanh, đủ loại hoa trái. Vậy mà không phải thế!
Giáp Tết năm nay, Bố lại ...năn nỉ hắn để được trở về quê!
Hắn hoàn toàn KHÔNG HIỂU tại làm sao nữa?! Nên đã cố dọ hỏi :
-Hay là vợ con đối xử tệ bạc với cụ chăng!!
-Không, con dâu rất tốt, ngày nào cũng sai người làm lo ba bữa ăn thịnh soạn mà.
- Thế... Sao bố lại đòi về quê?
- À, tại ở đây buồn, không biết nói chuyện với ai ...và vì **BA ĐÔI DÉP** con ạ!
- À, Con chưa hiểu lý do thứ hai ...
- Ừ, con bây chừ là người thành phố, làm sao hiểu được...
- Thì Bố nói cho con hiểu được không ạ?
- Thế thì... Bố nói nhé : Cả một năm nay, Bố cố tập để mà quen cái chuyện phải thay dép ở 3 nơi:
**Phòng WC vệ sinh phải mang dép Lào!**
**Phòng khách thì phải thay dép Da!**
**Ra ngoài vườn thay dép Tổ Ong...!**
Mỗi lần quên, là có Vợ con cầm đôi dép phù hợp đưa và nhắc nhở : Bố ơi đổi dép!
- ?!?!!!!???
- Bố thật ngại ngùng! Nên suốt ngày tự nhắc: Vườn - Ong, Khách - Da, Tắm - Lào! Lúc nào cũng nghĩ rồi lẩm bẩm : "ong, da, lào- lào da ong!". Nhưng Không thể nào nhớ được!
Ngủ! Bố cũng mơ thấy mình lộn dép... Thôi cho Bố về quê, dù buồn, khổ nhưng tự do con ạ...
Ở nơi ấy, bố chỉ đi một đôi dép, dù trong nhà hay ngoài vườn... Khỏi suốt ngày bận tâm, rồi chẳng muốn đi lại luôn!
-Hưm... Lào, da, ong...lẩm bẩm riết rồi khùng luôn! 
Ông cụ pha trò, cười nhưng như mếu! Trông thật đáng thương.
- - -
À, hắn nhận ra mình có học , thành đạt, nhưng vẫn chưa hiểu một điều đơn giản là ** _Người già cần sự yêu thương, gần gũi, cảm thông hơn là nhà cao cửa rộng, cao lương mỹ vị gì cả!_**
Hắn, cứ tưởng mình có hiếu, nhưng thật sự là một kẻ vô tâm!
Và đã hối hận vô cùng, vội quì xuống trước mặt người đã sinh thành dưỡng dục mình nói :
-Xin Bố tha lỗi cho thằng con vô tâm này nhé! Từ nay, bố chẳng cần phải thay đổi dép gì cả!
Nếu thích, bố cứ đi chân trần ngay trong phòng ngủ! Con chỉ cần bố gần gũi con, chẳng cần qui định gì sất!
Rồi hắn nhào đến siết chặt đôi vai đang rung lên vì xúc động của người Bố.
Hắn dụi mặt vào ngực người đã thương yêu mình cả một đời để bốn dòng lệ hạnh phúc , trộn lẫn làm một!
Hắn chợt nhớ một câu nói thật hay : hạnh phúc tại tâm!

## LỜI HẸN ƯỚC

Họ gặp nhau trong một bệnh viện khi đang đi dạo. Cả hai đang ở độ tuổi 17. Trong một chớp mắt, bốn mắt nhìn nhau, hai trái tim non trẻ rộn lên một niềm xúc động sâu sắc. Họ đọc trong mắt nhau một nỗi thương cảm bi ai. Kể từ hôm đó họ không còn cô đơn nữa.
Đến một ngày cả hai được thông báo rằng bệnh tình của họ không có cách nào chữa trị nữa. Trước khi được gia đình đón về nhà, họ ngồi bên nhau một buổi tối, hẹn hò cùng nhau cố gắng vượt qua số phận. Họ hứa sẽ mỗi tuần viết cho nhau hai lá thư để chúc phúc và động viên nhau. Rồi hôm sau họ chia tay nhau.
Thấm thoắt đã ba tháng trôi qua. Cô gái ngày càng yếu ớt. Một hôm cô gái cầm trong tay bức thư của chàng trai gửi đến rồi thanh thản khép đôi bở mi, miệng thoáng mỉm cười mãn nguyện. Bà mẹ cuống cuồng gọi con, nhưng cô gái đã ra đi. Bà gỡ lá thư trong tay cô ra và đọc: ” … Khi số phận đã đùa giỡn với sinh mệnh của em, em không nên sợ hãi vì bên cạnh em luôn có anh và mọi người quan tâm đến em. Anh đang khoẻ dần lên, anh sẽ đến với em một ngày gần đây, em sẽ không cô đơn”.
Hôm sau bà mẹ mở tủ của con gái, phát hiện ra vài chục lá thư đều do con gái bà viết, bỏ sẵn vào phong bì, dán tem đàng hoàng. Phía trên tập thư là mẩu giấy cô con gái viết cho bà mẹ. “Mẹ ơi, đây là tập thư con viết cho một người bạn trai mà chúng con đã có lời hẹn ước đi cùng nhau suốt quãng đời còn lại. Nhưng con thấy mình yếu đi nhanh chóng, sợ không giữ được lời hứa ấy. Con đã viết sẵn những lá thư này, mỗi tuần mẹ gửi giúp con một lá cho anh ấy để anh ấy nghĩ con vẫn còn sống và đang động viên anh ấy vượt lên trên bệnh tật. Con chỉ mong anh ấy có đủ niềm tin để sống tiếp. Con gái của mẹ”.
Bà mẹ lần theo địa chỉ ghi trên bì thư để đến nhà chàng trai. Bà nhìn thấy trên bàn là một tấm ảnh của một thanh niên trẻ, tràn đầy sinh khí và sức sống được viền dải băng đen. Bà vô cùng ngạc nhiên khi biết chàng trai đã ra đi cách đây một tháng. Bà mẹ chàng trai nước mắt lưng tròng chỉ vào chồng thư đặt bên cạnh khung ảnh và kể rằng: “Con trai tôi đã mất cách đây một tháng, nhưng trước khi ra đi, nó dành ba ngày ba đêm để viết những lá thư này. Nó nhờ tôi mỗi tuần gửi cho cô bạn gái nào đó một lá. Nó bảo cô gái ấy cũng đang trông mong chờ đợi sự cổ vũ động viên của nó. Thế là cả tháng nay tôi thay con trai gửi những lá thư này đi, không biết cô gái ấy có nhận được không…”
Bà mẹ của cô gái lao đến ôm chầm lấy bà mẹ của chàng trai và khóc không thành tiếng. Khi hai bà mẹ đã hiểu ra tất cả, hai bà quyết định vẫn cứ hàng tuần gửi cho nhau một lá thư mà con họ đã để lại. Họ bảo làm như thế để “Vì một ước nguyện cao cả…”
(Không rõ tác giả)

## Tình anh em

Tiền trong nhà ngày trước cha mẹ để lại đã tiêu hết, người anh trai không đành lòng để em gái ở nhà đợi chết, cậu dùng chiếc xe kéo tự chế của mình đưa em tới một bệnh viện lớn trên thành phố.
Bác sĩ bị tình cảm của hai anh em làm cho cảm động, sau khi họp bàn các bác sĩ quyết định miễn phí làm phẫu thuật cấy ghép thận, người hiến thận tất nhiên là người anh trai câm của cô bé.
Sau đó bác sĩ lại dẫn cậu anh trai vào phòng làm việc, thẳng thắn nói với anh:
“Nếu hiến thận của cậu cho em gái, thì cô bé có thể sống, nếu không hiến, em gái cậu sẽ nhanh chóng qua đời. tuy nhiên nếu trong cuộc phẫu thuật có gì sai sót, thì tính mạng của cậu cũng có thể là không giữ được”.
Người anh trai câm, sắc mặt tái nhợt, trong lòng nặng trĩu, đầy những suy nghĩ, và có chút do dự. Một lúc sau anh ngẩng đầu nhìn bác sĩ và gật đầu vẫn tiếp tục làm cuộc phẫu thuật này cho em gái. Bác sĩ vui mừng vỗ vai anh, bảo anh về nhà đợi.
Không ngờ, buổi chiều ngày hôm đó, người anh trai câm liền mất tích. Vị bác sĩ hỏi Tiểu Tiểu:
“Rốt cuộc anh trai cháu đã đi đâu? Lúc đi có nói gì với cháu không?”
Tiểu Tiểu nói: “Anh nói với cháu, phải về nhà 1 chuyến”.
Bác sĩ thấy có chút kỳ lạ, nhớ đến sắc mặt tái nhợt khi ông nói với người anh trai câm về sự cố không may xảy ra trong phẫu thuật.
Ông cau mày nói:
“Sắp đến ngày phẫu thuật rồi, tại sao anh trai cháu còn về nhà làm gì?”
Tất cả đều đã chuẩn bị kỹ càng, chỉ cần đợi người hiến thận là xong, nhưng vào giờ phút này người anh trai câm lại bỗng dưng mất tích, khiến cả bệnh viện náo loạn.
Một ngày nữa lại trôi qua, người anh trai câm vẫn chưa xuất hiện. Tất cả ý tá, bác sĩ trong viện đều biết chuyện, tất cả mọi người đều không nói ra, nhưng trong lòng đều cho rằng anh nhất định vì sợ quá nên đã chuồn rồi.
Do lo lắng Tiểu Tiểu không chịu được sự đả kích này, bác sĩ và các y tá đều không dám nói trước mặt cô bé. Bất kể là như vậy, Tiểu Tiểu từ sắc mặt của mọi người cũng có thể đoán được ít nhiều, trên khuôn mặt của cô bé không còn những nụ cười vui tươi nữa, cả ngày cô bé đều khóc lóc.
Thời gian phẫu thuật cũng sắp đến, lúc đó, có một người vội vội vàng vàng chạy vào phòng bệnh. Thì ra đó chính là người anh trai câm đã mất tích mấy ngày qua của cô bé.
Tiểu Tiểu vừa nhìn thấy anh, dùng những động tác hình thái để nói chuyện với anh, một lúc sau cô bé bỗng khóc òa.
Mọi người có mặt trong phòng đều mơ hồ: “Rốt cuộc đã xảy ra chuyện gì?”, cuối cùng vì cảm xúc của cô bé lên cao quá mà cuộc phẫu thuật phải hoãn lại.
Vị bác sĩ tò mò hỏi Tiểu Tiểu: “Tất cả mọi người đều muốn biết, vừa rồi, cháu và anh trai đã nói gì với nhau vậy?”
Tiểu Tiểu lau nước mắt, nghẹn ngào nói:
“Cháu hỏi anh trai về nhà làm gì, vì bác sĩ đã miễn phí tiền viện phí và chi phí phẫu thuật rồi, anh nói với cháu là mấy ngày qua anh về nhà để vào rừng kiếm củi, gánh nước. Với số củi và nước đó cháu có thể dùng trong vòng nửa năm”.
Bác sĩ ngạc nhiên hỏi: “Anh trai cháu sao lại làm như vậy?”
Tiểu Tiểu vừa cười vừa khóc nói:
“Cháu cũng hỏi anh như vậy, anh nói để nếu có lỡ xảy ra chuyện gì trong lúc phẫu thuật, nếu anh có qua đời thì cháu cũng không phải lo về việc không có củi đốt và nước dùng”.
Khi đó mọi người mới hiểu những ngày qua không phải vì anh muốn bỏ rơi em gái ở lại, một mình chạy trốn, mà là vì anh muốn chuẩn bị chu đáo cho cuộc sống của người em sau cuộc phẫu thuật nếu như anh không còn ở bên. Biết chuyện ai nấy đều cảm động trước tình cảm của anh dành cho em gái.
Được làm anh em trong cùng một gia đình là phúc phận của mỗi người. Hãy luôn yêu thương quý mến nhau, vì không phải ai cũng có may mắn hạnh phúc đó. Tình cảm anh em là một trong những tình cảm quý giá mà ai cũng nên trân quý.

## Lỗi Lầm Và Ân Hận

Vào những ngày cuối năm 2002, trên các trang báo của Ý đã xuất hiện một thông báo tìm người rất đặc biệt:
"Ngày 17/5/1992, Ở bãi đậu xe đường số 5, khu thương nghiệp thành phố Avenue, một người phụ nữ da trắng bị một chàng trai da đen cưỡng hiếp. Không lâu sau, người phụ nữ kia đã sinh ra một bé gái da đen.
Hiện tại cô bé bị bệnh máu trắng, cần phải làm phẫu thuật cấy ghép tủy gấp, ba ruột của cô bé chính là niềm hy vọng duy nhất để cứu sống cô.
Hy vọng người năm xưa sau khi đọc được lời nhắn này, hãy mau chóng liên hệ với bác sĩ Andrew làm việc tại bệnh viện Elizabeth."
Bản tin đã nhanh chóng tạo ra một chấn động trong dư luận.Đây là một câu chuyện có thật, và nó sẽ có kết cục như thế nào? Đối diện với một kẻ cưỡng bức… bạn có tha thứ cho anh ta không?
Xin hãy xem tiếp…
Cô bé bị bệnh máu trắng liên quan đến một bí mật…Ở một khu dân cư thuộc thành phố Foyer nước Ý, Marda 35 tuổi là người phụ nữ luôn bị mọi người xì xào bàn tán, bởi cô và chồng cô Peter đều là người da trắng, nhưng trong hai đứa con của họ lại có một đứa là da đen.
Điều này đã khiến cho những người hàng xóm xung quanh không khỏi cảm thấy tò mò.
Marda luôn cười nói với họ rằng, do bà nội của mình là người da đen, ông nội là người da trắng, nên đứa con gái Monica mới xuất hiện sự lại giống như vậy.
Và bí mật đã không thể che đậy được nữa…
Mùa thu năm 2002, cô bé da đen Monica bị chẩn đoán mắc bệnh máu trắng, biện pháp chữa trị duy nhất là làm phẫu thuật cấy ghép tủy.
Hết thảy những người thân họ hàng hai bên đều đến bệnh viện làm xét nghiệm nhưng không có ai thích hợp cả.
Một buổi tối, bác sĩ Andrew đang trực ban thì có tiếng gõ cửa, là vợ chồng Marda.
Và ông đã được nghe bí mật mà hai vợ chồng họ chôn giấu bao năm nay.
“Chuyện xảy ra vào tháng 05/1992, lúc đó là 10h tối, trời mưa rất to. Marda vừa tan ca làm. Khi cô đi ngang qua một bãi đậu xe bị bỏ hoang, Marda nghe thấy sau lưng có tiếng bước chân; cô sợ hãi quay đầu lại nhìn, là một chàng trai da đen đang đứng phía sau cô. Anh ta tay cầm một khúc cây, đánh cô ngất đi, và làm nhục cô. Không lâu sau đó, Marda phát hiện mình đã mang thai. Họ đã vô cùng sợ hãi, lo sợ rằng đứa con này chính là của người da đen kia. Marda muốn phá bỏ cái thai, nhưng Peter đã ngăn cản cô bởi anh vẫn hy vọng đứa bé trong bụng chính là con của họ.
Cứ như vậy, họ đã thấp thỏm chờ đợi…Tháng 03/1993, Marda hạ sinh một bé gái, là da đen. Họ đã hoàn toàn tuyệt vọng, và quyết định sẽ đem đứa bé cho cô nhi viện, nhưng mỗi lần nghe thấy tiếng khóc của nó thì lại không nhẫn tâm.
Và cuối cùng họ quyết định sẽ nuôi nấng cô bé này như con gái….Mắt Peter bắt đầu nhòe đi, anh tiếp tục nói: Dù sao thì Marda cũng đã mang thai nó, đứa bé không có tội gì cả. Nó xứng đáng được sống và yêu thương.
Sống mũi bác sĩ Andrew cũng đã cay cay, ông im lặng một lúc rồi cuối cùng mở lời:
“Ông bà phải tìm được cha ruột của Monica, nói không chừng tủy xương của anh ta, hoặc tủy xương của con cái anh ta có thể thích hợp với Monica”.
“Nhưng… ông bà có bằng lòng để cho anh ta xuất hiện trong cuộc đời mình lần nữa hay không?”
Marda nói:“Vì Monica, chúng tôi bằng lòng tha thứ cho anh ta, nếu như anh ta chịu bước ra để cứu đứa bé, tôi hứa sẽ không khởi tố”.
Bác sĩ Andrew không khỏi chấn động sâu sắc bởi tấm lòng lòng thương con của người mẹ này.
Marda và Peter suy nghĩ hết lần này đến lần khác, quyết định dùng hình thức giấu tên, để đăng một bản tin tìm người trên báo.
Tháng 11/2002, trên hầu hết các tạp chí thành phố Foyer đều đăng một bản tin tìm người. Nhưng trong biển người mênh mông, huống hồ chuyện đã nhiều năm như vậy, biết đi đâu để tìm tên cưỡng dâm năm xưa?
Câu chuyện này đã làm cảm động rất nhiều người, một làn sóng hiến tủy lan khắp cả nước, không ít người tự nguyện làm xét nghiệm tủy để xem mình có thích hợp hay không.
Và điều đó đã cứu được rất nhiều bệnh nhân bị bệnh máu trắng, nhưng Monica lại không nằm trong số những người may mắn.
Bản tin cũng truyền đến tai những tội phạm da đen năm đó. Rất nhiều người đã tự nguyện trình báo để làm xét nghiệm xương tủy, hi vọng có thể hiến tủy cho Monica.
Cả những tù nhân da trắng cũng bị cảm động trước tình mẫu tử của Marda, họ bày tỏ sự quan tâm chân thành đến cô và cung cấp nhiều manh mối hỗ trợ cảnh sát và gia đình tìm ra kẻ cưỡng dâm năm xưa.
Nhưng đáng tiếc thay, họ vẫn không thể tìm ra cha ruột của Monica.
Hơn hai tháng trôi qua, người đàn ông da đen kia vẫn không xuất hiện… Marda và Peter vẫn hồi hộp lo lắng chờ đợi phép màu sẽ đến với con gái của họ.
Sau khi bản tin tìm người này xuất hiện trên trang báo ở thành phố Napoli, trong lòng ông chủ của một nhà hàng cao cấp là Achlia bắt đầu dậy sóng. Ngày 17/05/1992, trong cuộc đời anh đã trải qua một đêm mưa gió bão bùng tựa như ác mộng, anh rất có thể là người được nhắc đến trong câu chuyện trên.
Không ai có thể ngờ được rằng triệu phú Achlia của ngày hôm này từng là một người rửa chén thuê trong một nhà hàng ở thành phố Foyer. Cha mẹ mất sớm, anh phải nghỉ học, lăn lộn kiếm sống ngoài xã hội. Trớ trêu thay, ông chủ của anh lại là một kẻ phân biệt chủng tộc. Dẫu anh có cố gắng làm việc chăm chỉ thế nào thì vẫn luôn phải chịu sự đánh đập chửi mắng từ ông ta.
Đó là sinh nhật lần thứ 20 của Achlia. Anh dự định sẽ nghỉ làm sớm để đón mừng sinh nhật của mình, không ngờ trong lúc loay hoay đã vô tình làm rơi một cái đĩa, ông chủ túm chặt lấy cổ anh bắt anh phải nuốt hết những mảnh vỡ đó. Achlia phẫn nộ cho ông ta một đấm, rồi xông ra khỏi quán.
Anh quyết tâm báo thù người da trắng. Buổi tối hôm đó trời mưa tầm tã, trên đường dường như không có một bóng người đi lại, trên bãi đậu xe anh gặp Marda, căm phẫn dâng trào trong anh về sự phân biệt chủng tộc, lòng căm thù đối với người da trắng đã khiến anh phạm phải tội ác lớn nhất trong cuộc đời mà đến tận bây giờ anh vẫn không thể tha thứ cho chính mình: Anh đã cưỡng bức người phụ nữ vô tội đó.
Hối hận vô cùng, anh đã mua vé xe lửa đến thành phố Napoli, rời xa khỏi thành phố này trong đêm hôm đó, hy vọng có thể quên đi cảm giác tội lỗi mà anh đã gây ra.
Về sau, Achlia đã tìm được công việc thuận lợi ở nhà hàng của một người Mỹ, đôi vợ chồng đó rất quý sự cần cù của anh, còn đem cô con gái Lina gả cho anh, về sau còn giao cho anh quản lý toàn bộ công việc kinh doanh của nhà hàng.
Mấy năm trở lại đây, anh đã phát triển nhà hàng thành một nhà hàng cao cấp sang trọng. Anh và Lina cũng có với nhau ba đứa trẻ vô cùng đáng yêu. Đối với mọi người, Achlia thật sự là một ông chủ tốt, người chồng tốt và người cha tốt.
Achlia vẫn không sao quên được tội ác năm xưa.Anh luôn cầu nguyện Thượng Đế, xin Người hãy phù hộ người phụ nữ đã từng bị anh làm hại kia, hy vọng cô có thể bình an vô sự sống một cuộc sống hạnh phúc, và không bị tổn hại bởi tội lỗi anh đã gây nên.
Nhưng anh trước giờ chưa từng đem bí mật trong lòng này nói với bất kỳ ai. Buổi sáng hôm đó, Achlia đã đọc đi đọc lại bản tin đó đến mấy lần, trực giác mách bảo rằng anh chính là kẻ cưỡng gian được tìm trên tờ báo đó. Anh không bao giờ nghĩ rằng, người phụ nữ đáng thương đó đã mang thai và đã nuôi dưỡng đứa con vốn không thuộc về mình.
Cả ngày hôm đó, Achlia đã gọi điện thoại cho bác sĩ Andrew mấy lần, nhưng điện thoại còn chưa quay xong anh liền vội cúp máy. Trong lòng anh đang giãy giụa đau đớn. Nếu như đứng ra thừa nhận tất cả, mọi người sẽ biết được quá khứ xấu xa của anh, những đứa con sẽ không còn yêu thương anh nữa, anh sẽ mất đi gia đình hạnh phúc và người vợ xinh đẹp, cũng sẽ mất đi sự tôn trọng của xã hội đối với mình. Anh đã rất khó khăn để có một cuộc sống như ngày hôm nay, anh không thể để hạnh phúc tuột mất được.
Bữa tối hôm đó, mọi người trong nhà đều bàn luận về những tin tức có liên quan đến Marda trên báo chí như những lần trước.
Người vợ Lina nói:“Em thật sự rất khâm phục người phụ nữ này. Nếu như đổi lại là em, em sẽ không đủ can đảm để nuôi dưỡng con gái đã được sinh ra vì bị cưỡng hiếp. Em càng khâm phục chồng của cô ấy, anh ta quả thật là một người đàn ông đáng được tôn trọng, có thể chấp nhận một đứa con như thế”.
Achlia im lặng hồi lâu rồi hỏi:“Vậy em nhìn nhận kẻ cưỡng hiếp đó như thế nào?”
Lina căm phẫn nói:“Em tuyệt đối không thể tha thứ cho hắn ta được. Năm xưa đã làm sai rồi, vào thời khắc then chốt của bây giờ, hắn ta lại rụt cổ trốn tránh. Hắn ta thật đúng là quá đê tiện, quá ích kỷ, thật là quá ghê tởm! Hắn ta là con quỷ hèn nhát!”
Nghe Lina nói vậy, Achlia càng không dám nói ra sự thật với vợ.
Anh trằn trọc suốt đêm không sao ngủ được, cảm giác bản thân như bị đày đọa dưới địa ngục, những khung cảnh trong đêm mưa gió tội ác đó không ngừng xuất hiện trước mắt.
Anh dằn vặt tự hỏi:“Mình rốt cuộc là người tốt, hay là người xấu?”
Mấy ngày sau, Achlia không cách nào im lặng được nữa, tình thương của người cha đã bùng lên từ nơi sâu thẳm trong tâm hồn anh, anh muốn cứu con gái mình. Anh đã phạm sai lầm một lần rồi, bây giờ không thể phạm sai lầm tiếp nữa. Anh gọi cho bác sĩ Andrew bằng điện thoại công cộng.
Cũng trong tối hôm đó, anh lấy hết can đảm để nói với vợ tất cả. Lina bật khóc, cô không thể nào có thể chấp nhận được người chồng rất mực yêu thương cô lại chính là một tên tội phạm. Cô chạy ào ra khỏi cửa, lái xe đi suốt đêm trong vô vọng, cô chưa từng trải qua đêm nào khủng khiếp như vậy trong cuộc đời. Sau một đêm dằn vặt đau khổ, cô đã quyết định trở về. Achlia ra mở cửa, hai mắt đỏ hoe.
Lina kiên định nói:“Achlia, anh hãy đến chỗ bác sĩ Andrew! Em sẽ đi cùng với anh!”
Ngày 08/02/2003, vợ chồng Achlia đã đến bệnh viện Elizabeth và làm xét nghiệm ADN, kết quả anh thật sự chính là cha ruột của Monica.
Khi biết được người đàn ông da đen từng làm nhục mình cuối cùng đã dũng cảm bước ra, những giọt nước mắt hạnh phúc không ngừng lăn dài trên má Marda.
Cô đã căm hận trong suốt 10 năm, nhưng thời khắc này đây cô vô cùng cảm động. Tất cả đều được tiến hành cực kỳ bí mật, bệnh viện đã không tiết lộ thân phận của người trong cuộc cho báo chí mà chỉ thông báo với ký giả rằng đã tìm được cha ruột của Monica.
Thông tin này đã khiến người dân cả nước quan tâm, họ không ngừng gọi điện thoại và viết thư cho bác sĩ Andrew, nhờ ông gửi sự tha thứ và lòng tôn kính của họ đến người da đen này: “Anh ấy từng là tội nhân, nhưng giờ đây anh ấy là một anh hùng!”
Ngày 18/02, dưới sự sắp xếp bí mật, Marda gặp Achlia trong phòng khách của bệnh viện. Khi nhìn thấy Marda, bước chân Achlia nặng nề, sắc mặt tái nhợt. Marda và chồng bước đến, nắm chặt lấy tay anh, ba người nhìn nhau khóc không thành tiếng, nước mắt hòa lẫn vào nhau.
Rất lâu sau, Achlia nghẹn ngào nói:“Xin lỗi, xin lỗi, xin hãy tha thứ cho tôi! Câu nói này tôi đã chôn sâu trong lòng suốt hơn 10 năm nay rồi, hôm nay cuối cùng đã có cơ hội để nói với chị. Tôi thực sự hi vọng Monica và anh chị sẽ sống hạnh phúc bên nhau.
Tôi rất cảm ơn Monica, con bé đã cho tôi một cơ hội để chuộc tội và có thể sống thanh thản trong nửa đời còn lại. Đây chính là món quà mà con bé đã ban tặng cho tôi."
Marda nói:“Cảm ơn cậu đã có thể bước ra. Cúi xin Thượng Đế phù hộ, tủy xương của cậu đã cứu sống con gái tôi!”
Ngày 22/02/2003, thời khắc mà mọi người chờ đợi từ lâu cuối cùng đã đến, xương tủy của Achlia được cấy ghép vào trong thân thể của Monica.
Một tuần sau đó, Monica khỏe mạnh xuất viện. Vợ chồng Marda đã hoàn toàn tha thứ cho Achlia…

