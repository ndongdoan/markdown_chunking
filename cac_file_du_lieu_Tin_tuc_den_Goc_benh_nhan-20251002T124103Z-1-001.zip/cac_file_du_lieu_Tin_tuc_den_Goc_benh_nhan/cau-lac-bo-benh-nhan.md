## Buổi tư vấn trực tuyến dành cho Câu lạc bộ bệnh nhân loãng xương

Khoa Nội Cơ xương khớp, Bệnh viện Nguyễn Tri Phương trân trọng kính mời quý bệnh nhân tham gia buổi tư vấn trực tuyến dành cho Câu lạc bộ bệnh nhân loãng xương.
**Thời gian:** 10h00, Thứ Bảy ngày 05/07/2025
**Chủ đề:** Phòng ngừa và điều trị loãng xương hiệu quả
**Hình thức tham gia:** trên ứng dụng Zoom [**TẠI ĐÂY**](https://us06web.zoom.us/j/81852185221) hoặc bấm Đường dẫn Tham gia tại đây: <https://us06web.zoom.us/j/81852185221>
Tham gia miễn phí – Phù hợp cho mọi đối tượng quan tâm đến sức khỏe xương khớp.

## Các mức độ hẹp động mạch vành (ĐMV)

Bài viết này để dành cho những người bệnh hoặc gia đình mình có người bị hẹp động mạch vành trên phim chụp cắt lớp - một xét nghiệm cận lâm sàng được sử dụng khá rộng rãi những năm gần đây. Ngoài ra cũng để cho các bác sĩ không phải chuyên khoa tim mạch và nhũng bác sĩ trẻ hiểu bản chất để giải thích cho người bệnh của mình. _**(BS Nguyễn Lân Hiếu)**_
Chỉ định chụp cắt lớp động mạch vành chủ yếu trên các bệnh nhân đau ngực ổn định hoặc không đau ngực nhưng nhiều yếu tố nguy cơ như nam giới lớn tuổi, hút thuốc lá, đái tháo đường, rối loạn mỡ máu, tăng huyết áp, béo phì, gia đình nhiều người bị nhồi máy cơ tim, đột quỵ ... Các bệnh nhân bị đau ngực không ổn định (xin xem thêm bài phân biệt 2 nhóm này mà tôi đã chia sẻ trước đây) thường không có chỉ định chụp cắt lớp chẩn đoán mà cần theo lộ trình điều trị khẩn cấp hơn. Nói dễ hiểu nếu đã đau ngực vã mồ hôi đừng có đi chụp động mạch vành cắt lớp nữa vừa tốn tiền vừa nguy hiểm ạ.
Sau khi chụp cắt lớp các bác sĩ sẽ đưa ra nhiều thông số nhưng quan trọng nhất là vị trí hẹp, % mức độ và chiều dài chỗ hẹp, tình trạnh mạch máu sau chỗ hẹp, mức độ vôi hoá thành mạch, tuần hoàn bàng hệ ... Quyết định can thiệp thường dựa vào nhiều yếu tố, không hoàn toàn dựa vào mức độ hẹp mà phụ thuộc triệu chứng của bệnh nhân và kết quả các xét nghiệm đánh giá thiếu máu cơ tim.
Về lý thuyết sẽ chia làm các mức độ hẹp ĐMV như sau:
**1. Hẹp từ 50% trở lên (không kể hẹp ở vị trí lỗ vào ĐMV)** : được coi là có ý nghĩa lâm sàng, đặc biệt nếu bệnh nhân có triệu chứng như đau thắt ngực hoặc khó thở.
Trong trường hợp này, các xét nghiệm khác cần được thực hiện để đánh giá ảnh hưởng của hẹp đến mức độ thiếu máu cơ tim như: Nghiệm pháp gắng sức (với điện tim đồ hay siêu âm có tiêm thuốc tăng nhịp tim) nhằm mục đích làm tim đập thật nhanh để xem có thiếu máu phía sau chỗ hẹp hay không. Nếu nghiệm pháp này âm tính (vẫn đủ máu nuôi tim trong hoàn cảnh tim hoạt động mạnh nhất), không cần phải can thiệp mà chỉ dùng thuốc và thay đổi lối sống, chế độ ăn. Hàng năm Trung tâm Tim mạch BV ĐHY HN chúng tôi tiến hành hàng nghìn ca gắng sức và rất nhiều các bệnh nhân không phải đặt stent, yên tâm trở về sinh hoạt bình thường.
Các xét nghiệm khác phức tạp tốn kém hơn cũng có thể sử dụng là chụp Xạ hình cơ tim (Scintigraphy) hay Cộng hưởng từ 3.0 (MRI) có phần mềm đánh giá mức độ thiếu máu cơ tim ở các pha khác nhau... chủ yếu thực hiện ở các bệnh viện chuyên khoa tuyến cuối. Chính vì vậy ở nhóm này (hẹp từ 50-70%), tôi vẫn khuyên bệnh nhân chỉ cần làm nghiệm pháp gắng sức định kỳ. Tuỳ theo từng trường hợp, nếu quản lý tốt được yếu tố nguy cơ thông thường tôi sẽ đề nghị 2 -3 năm một lần .
**2. Hẹp từ 70% trở lên:** Thường được coi là "nhiều" và có khả năng cao cần can thiệp, đặc biệt nếu bệnh nhân có triệu chứng hoặc nếu hẹp xảy ra ở các vị trí quan trọng như đoạn đầu nhánh trái trước (LAD). Vậy nhưng những trường hợp không triệu chứng tôi vẫn khuyên nên làm thêm các xét nghiệm không chảy máu (nghiệm pháp gắng sức, Scintigraphy, MRI). Nếu kết quả các xét nghiệm này nghi ngờ +|- (thiếu máu cơ tim có nhưng không rõ ràng), trước khi đặt stent tôi vẫn yêu cầu làm thêm thủ thuật đo lưu lượng dự trữ vành (FFR) hoặc siêu âm trong lòng mạch (IVUS, OCT) để khẳng định sự cần thiết có nên đặt stent hay không (Các thăm dò chuyên sâu này xin để dịp khác sẽ chia sẻ với mọi người về nguyên lý cũng như hiệu quả.)
**3. Hẹp từ 90% trở lên:** Gần như chắc chắn cần can thiệp, do nguy cơ cao gây tắc nghẽn hoàn toàn và dẫn đến nhồi máu cơ tim.
Tuy nhiên cần lưu ý còn một trường hợp bác sĩ chẩn đoán đọc sai kết quả, đặc biệt khi động mạch vành vôi hoá, kỹ thuật chụp không đạt tiêu chuẩn và/hoặc máy CT Scanner thế hệ thấp... Chính vì vậy nhiều bệnh nhân hẹp 90% trên phim chụp khi được đưa vào phòng DSA luồn ống thông để chuẩn bị đặt, chụp lại hẹp không nghiêm trọng, được cho "xuống bàn" về điều trị nội khoa.
Để kết thúc, tôi xin nhấn mạnh mức độ hẹp động mạch vành trên phim chụp cắt lớp là quan trọng nhưng không phải quyết định tất cả. Hãy bình tĩnh gặp các bác sĩ chuyên khoa, mô tả chính xác và chi tiết các triệu chứng của mình, tuân thủ thực hiện các thăm dò chức năng tim (đặc biệt là nghiệm pháp gắng sức), các bạn và người thân của mình sẽ có được phương pháp điều trị hiệu quả và an toàn nhất.

## Hướng dẫn cai nghiện thuốc lá


## Rác thải nhựa và sự ảnh hưởng đến sức khỏe

Mỗi năm, thế giới thải ra khoảng 350 triệu tấn rác thải nhựa, từ túi ni-lông, chai nước, hộp đựng thức ăn đến bao bì sử dụng một lần. Chỉ 9% trong số này được xử lý bằng cách tái chế, tất cả phần còn lại được chôn lấp, hoặc đáng lo ngại hơn, bị đổ ra sông và trôi ra đại dương, gây ô nhiễm nghiêm trọng.
Khu vực Đông Nam Á, đặc biệt là sáu quốc gia gồm Philippines, Malaysia, Indonesia, Myanmar, Việt Nam và Thái Lan, đóng góp hơn 50% lượng rác thải nhựa đại dương trên toàn cầu.
Rác thải nhựa, đặc biệt là nhựa sử dụng một lần, khi phân hủy trong môi trường – nhất là trong nước – sẽ tạo ra vi nhựa (microplastic) và nano nhựa (nanoplastic):
- Vi nhựa: Các hạt nhựa có kích thước từ 1 micromet đến 5 mm
- Nano nhựa: Các hạt nhỏ hơn 1 micromet, có khả năng xâm nhập sâu vào tế bào và mô cơ thể.
Những hạt nhựa này không chỉ xuất hiện từ quá trình phân hủy mà còn được sản xuất trực tiếp trong các sản phẩm như mỹ phẩm. Ví dụ:
- Sản phẩm tẩy tế bào chết: Chứa các hạt microbead gây ô nhiễm nguồn nước.
- Kem chống nắng: Có thể chứa titan dioxide hoặc kẽm oxit dạng nano, đặc biệt nguy hiểm với dạng xịt do nguy cơ hít vào phổi.
- Son môi, phấn phủ, dầu gội: Thường chứa vi nhựa, làm tăng nguy cơ tiếp xúc qua da.
Vi nhựa hiện diện khắp nơi – từ không khí, nước uống đến thực phẩm. Nghiên cứu chỉ ra rằng 83% mẫu nước uống trên thế giới chứa vi nhựa, trong đó nước đóng chai có nguy cơ nhiễm cao hơn nước máy. Con người có thể tiếp xúc với vi nhựa qua:
- Đường tiêu hóa: Ăn uống thực phẩm hoặc nước nhiễm vi nhựa.
- Hô hấp: Hít phải vi nhựa trong không khí.
- Tiếp xúc qua da: Sử dụng mỹ phẩm chứa vi nhựa.
Vi nhựa và nano nhựa không chỉ gây ô nhiễm môi trường mà còn ảnh hưởng nghiêm trọng đến sức khỏe con người, làm tăng nguy cơ mắc các bệnh như:
- Da: Dị ứng, viêm da tiếp xúc.
- Hệ hô hấp: Viêm phổi, ung thư phổi.
- Hệ tiêu hóa: Ung thư đại tràng, ung thư tụy, hội chứng ruột kích thích.
- Các vấn đề nghiêm trọng khác: Rối loạn sinh sản, tổn thương DNA, và tăng nguy cơ mắc các bệnh ác tính.
Rác thải nhựa và vi nhựa là vấn đề toàn cầu, nhưng mỗi cá nhân có thể góp phần giảm thiểu tác động bằng cách:
- Hạn chế sử dụng nhựa dùng một lần: sử dụng cụ đựng thực phẩm như thủy tinh, kim loại, vật dụng có nguồn gốc tự nhiên
- Chọn mỹ phẩm không chứa vi nhựa
- Sử dụng nước uống từ nguồn đáng tin cậy và giảm phụ thuộc vào nước đóng chai.
- Lựa chọn thực phẩm an toàn: không ăn các loại thực phẩm hoặc thủy hải sản trên khu vực bị ô nhiễm hoặc loại hải sản ven biển gần đô thị. ...
**Nguồn**
1. Microbeads in exfoliating products: occurrence, abundance, and potential for water contamination in Ho Chi Minh City, Vietnam
2. The potential impact of nano- and microplastics on human health: Understanding human health risks.
_**Biên soạn: BS Lại Thị Bích Thủy**_

## LÀM SAO ĐỂ NGỦ NGON TRỞ LẠI

  * [ Mất ngủ là chuyện thường gặp, nhưng hoàn toàn có thể chữa trị](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/lam-sao-de-ngu-ngon-tro-lai#mt-ng-l-chuyn-thng-gp-nhng-hon-ton-c-th-cha-tr)
  * [ Làm gì để thoát khỏi mất ngủ?](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/lam-sao-de-ngu-ngon-tro-lai#lm-g-thot-khi-mt-ng)
  * [ Giữ gìn “vệ sinh giấc ngủ” để có những đêm ngon giấc](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/lam-sao-de-ngu-ngon-tro-lai#gi-gn-v-sinh-gic-ng-c-nhng-m-ngon-gic)
  * [ Tăng cường mối liên kết giữa giấc ngủ và không gian ngủ](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/lam-sao-de-ngu-ngon-tro-lai#tng-cng-mi-lin-kt-gia-gic-ng-v-khng-gian-ng)
  * [ Áp dụng nguyên tắc "20 phút" nếu không ngủ được](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/lam-sao-de-ngu-ngon-tro-lai#p-dng-nguyn-tc-20-pht-nu-khng-ng-c)
  * [ Thay đổi niềm tin tiêu cực về giấc ngủ](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/lam-sao-de-ngu-ngon-tro-lai#thay-i-nim-tin-tiu-cc-v-gic-ng)
  * [ “Dọn dẹp” tâm trí để thoát khỏi những suy nghĩ quay cuồng](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/lam-sao-de-ngu-ngon-tro-lai#dn-dp-tm-tr-thot-khi-nhng-suy-ngh-quay-cung)
  * [ Thư giãn cơ thể trước khi ngủ](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/lam-sao-de-ngu-ngon-tro-lai#th-gin-c-th-trc-khi-ng)
  * [ Cân nhắc thử nghiệm giới hạn thời gian ngủ](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/lam-sao-de-ngu-ngon-tro-lai#cn-nhc-th-nghim-gii-hn-thi-gian-ng)
  * [ Tìm kiếm sự trợ giúp chuyên môn khi cần thiết](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/lam-sao-de-ngu-ngon-tro-lai#tm-kim-s-tr-gip-chuyn-mn-khi-cn-thit)
  * [ Những điểm cốt lõi để tìm lại giấc ngủ ngon](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/lam-sao-de-ngu-ngon-tro-lai#nhng-im-ct-li-tm-li-gic-ng-ngon)
  * [ Về thuốc điều trị mất ngủ](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/lam-sao-de-ngu-ngon-tro-lai#v-thuc-iu-tr-mt-ng)


Mất ngủ có thể làm suy giảm nghiêm trọng chất lượng cuộc sống. Nó ảnh hưởng đến công việc, các mối quan hệ, làm giảm động lực tập thể dục hay duy trì chế độ ăn lành mạnh. Nhiều người mất ngủ dần từ bỏ những sở thích yêu thích, vì họ không còn đủ sức để theo đuổi nữa. Dần dần, họ rơi vào cảm giác bế tắc, bất lực, và không còn niềm vui trong cuộc sống.
###  Mất ngủ là chuyện thường gặp, nhưng hoàn toàn có thể chữa trị
Ước tính có khoảng một phần ba dân số từng trải qua ít nhất một triệu chứng mất ngủ. Theo một số nghiên cứu, khoảng 10% người trưởng thành đáp ứng các tiêu chí của mất ngủ mãn tính, khiến nó trở thành một trong những vấn đề y khoa phổ biến nhất. Dù tình trạng này rất phổ biến, việc tiếp cận các phương pháp điều trị dựa trên bằng chứng khoa học vẫn còn nhiều thách thức, khiến không ít người phải âm thầm chịu đựng mà không nhận được sự hỗ trợ cần thiết.
Mất ngủ vẫn chưa được hiểu đúng và đầy đủ, ngay cả trong giới y khoa. Nghiên cứu cho thấy trung bình một sinh viên y chỉ nhận được khoảng 2,5 giờ học về giấc ngủ trong suốt quá trình đào tạo. Vì thế, các dấu hiệu của mất ngủ thường bị bỏ sót hoặc xem nhẹ. Mặt khác, rất ít người thực sự tìm kiếm sự giúp đỡ khi gặp vấn đề về giấc ngủ. Họ không biết nên bắt đầu từ đâu. Lĩnh vực giấc ngủ hiện vẫn chưa có quy định chặt chẽ, điều đó có nghĩa là bất kỳ ai cũng có thể tự xưng là “chuyên gia giấc ngủ”, ngay cả khi họ không có bất kỳ nền tảng y khoa hay đào tạo chuyên môn nào. Những người bị mất ngủ thường tuyệt vọng tìm kiếm giải pháp, và chính điều đó khiến họ dễ bị cuốn vào những lời hứa hẹn suông hoặc các "liệu pháp thần kỳ" thiếu cơ sở khoa học.
Từ kinh nghiệm làm việc với bệnh nhân mất ngủ, tôi nhận thấy rằng hầu hết họ đã thử qua đủ loại thực phẩm chức năng, mẹo vặt và phương pháp điều trị từ những nguồn không chính thống trước khi tìm đến tôi. Nhiều người từng đi khám bác sĩ và được kê đơn thuốc ngủ. Mặc dù thuốc có thể mang lại sự nhẹ nhõm tạm thời, nhưng nó không giải quyết được nguyên nhân gốc rễ của mất ngủ, đồng thời tiềm ẩn nguy cơ phụ thuộc, nên bác sĩ thường chỉ kê đơn trong thời gian ngắn. Khi đã thử qua nhiều cách mà vẫn không ngủ ngon hơn, không ít người trở nên hoài nghi và mất dần niềm tin vào bất kỳ lời khuyên nào khác.
Tuy nhiên, tin vui là có những phương pháp điều trị mất ngủ đã được khoa học chứng minh hiệu quả. Trong số đó, liệu pháp nhận thức – hành vi dành cho mất ngủ (CBT-I) được xem là tiêu chuẩn vàng bởi các chuyên gia hàng đầu về rối loạn giấc ngủ. Đây là một liệu pháp tâm lý giúp người bệnh nhận diện và thay đổi những suy nghĩ cũng như thói quen vô tình làm trầm trọng thêm chứng mất ngủ.
Mất ngủ thường khởi phát từ một giai đoạn căng thẳng hoặc thay đổi lớn trong cuộc sống, có thể là do bệnh tật, sinh con, đổi việc, đổ vỡ tình cảm hay mất mát người thân, khiến giấc ngủ bị xáo trộn. Những đêm trằn trọc lại càng khiến ta lo lắng, và để đối phó, ta bắt đầu điều chỉnh thói quen ngủ: uống nhiều cà phê hơn, đi ngủ sớm hơn, uống rượu, dùng thực phẩm chức năng hỗ trợ giấc ngủ, ngủ gật trên ghế sofa… Trớ trêu thay, những thay đổi này lại vô tình làm vấn đề trầm trọng hơn. Trong CBT-I, những hành vi này được gọi là “yếu tố duy trì”, vì chúng tiếp tục kéo dài tình trạng mất ngủ ngay cả khi nguyên nhân ban đầu đã không còn.
CBT-I là một liệu pháp mang tính thực hành cao. Nhà trị liệu sẽ giúp người bệnh hiểu được cơ chế giấc ngủ, nhận diện và phá vỡ các vòng luẩn quẩn gây mất ngủ. Phương pháp này bao gồm việc điều chỉnh lịch trình ngủ, thay đổi thói quen xấu, thách thức những quan niệm sai lầm về giấc ngủ, học cách thư giãn và tuân theo các nguyên tắc vệ sinh giấc ngủ. Tôi thường nói với bệnh nhân của mình rằng hãy xem CBT-I như một khóa huấn luyện hơn là một liệu pháp, vì nó đòi hỏi sự kiên trì và nỗ lực từ chính họ. Nhưng càng đầu tư nghiêm túc, họ càng nhận được kết quả xứng đáng.
Khi hoàn thành liệu trình, nhiều người nói với tôi rằng họ "cảm thấy như được trở lại là chính mình" hay "như thể vừa lấy lại được cuộc đời". Họ nhận thấy đầu óc minh mẫn hơn, trí nhớ cải thiện, khả năng tập trung cao hơn và làm việc hiệu quả hơn. Họ không còn cáu kỉnh vì thiếu ngủ và có thể tận hưởng những mối quan hệ của mình một cách trọn vẹn. Nhiều người mô tả sự thay đổi này giống như ai đó vừa bật lên một công tắc ánh sáng trong cuộc đời họ.
Nếu bạn cảm thấy mình đang gặp phải các triệu chứng mất ngủ, việc tìm đến một chuyên gia có thể là giải pháp phù hợp. Nhưng nếu muốn tự mình bắt đầu thay đổi, bạn có thể tham khảo các chiến lược dựa trên CBT-I được hướng dẫn trong tài liệu này. Những bước đi nhỏ này có thể giúp bạn xoa dịu chứng mất ngủ và từng bước tìm lại những giấc ngủ ngon.
###  Làm gì để thoát khỏi mất ngủ?
Nhận diện những thói quen có thể đang khiến bạn trằn trọc mỗi đêm
Một trong những sai lầm phổ biến nhất của người bị mất ngủ là đi ngủ sớm với hy vọng có thêm thời gian để ngủ. Có thể bạn đã thử cách này nhiều lần, nhưng giấc ngủ vẫn chẳng khá hơn bao nhiêu, thậm chí có khi còn tệ hơn. Bạn tự nhủ: “Dù không ngủ được thì ít nhất mình cũng đang nghỉ ngơi, thế cũng tốt rồi, phải không?” Tiếc là không phải vậy. Nằm trên giường hàng giờ mà không ngủ được chỉ khiến bộ não dần liên kết chiếc giường với trạng thái tỉnh táo, khiến bạn ngày càng khó đi vào giấc ngủ hơn.
Một “chiêu” khác mà nhiều người thường tìm đến khi tuyệt vọng vì thiếu ngủ là uống rượu. Lầm tưởng: rượu giúp ngủ ngon. Sự thật: rượu có thể khiến bạn chìm vào giấc ngủ nhanh hơn, nhưng lại làm giảm chất lượng giấc ngủ nghiêm trọng. Cơ thể bạn không được phục hồi trọn vẹn, tim phải hoạt động vất vả hơn, và bạn dễ bị tỉnh giấc giữa đêm, khiến giấc ngủ chập chờn, đứt quãng.
Ban ngày, khi cảm thấy uể oải và thiếu sức sống, nhiều người tìm đến cà phê như một cứu cánh. Điều này hoàn toàn dễ hiểu, nhưng caffeine là một chất kích thích mạnh. Nó làm tăng hoạt động của não bộ và ức chế adenosine, một chất giúp cơ thể cảm thấy buồn ngủ. Vì vậy, uống cà phê hoặc tiêu thụ caffeine vào buổi chiều hay buổi tối có thể khiến bạn khó ngủ hơn vào ban đêm.
Một điều mà tôi thường nghe từ những người bị mất ngủ là họ “cố gắng ngủ”. Nhưng chính sự cố gắng ấy lại vô tình tạo ra áp lực tâm lý khủng khiếp. Những người có giấc ngủ lành mạnh không hề “cố” ngủ; họ cũng chẳng mảy may suy nghĩ về cách chìm vào giấc ngủ, nó cứ đến một cách tự nhiên. Nhưng với người bị mất ngủ, giấc ngủ trở thành một nỗi ám ảnh. Họ càng khao khát được ngủ, bộ não càng căng thẳng, giống như một người nghệ sĩ bị áp lực phải trình diễn thật tốt trước khán giả. Căng thẳng ấy kích hoạt phản ứng lo âu, khiến tâm trí trở nên bấn loạn và giấc ngủ càng lùi xa hơn.
Vì thế, dù biết là rất khó, nhưng học cách buông bỏ nỗi ám ảnh về giấc ngủ và ngừng gây áp lực cho chính mình lại chính là chìa khóa giúp bạn dễ dàng chìm vào giấc ngủ hơn.
###  Giữ gìn “vệ sinh giấc ngủ” để có những đêm ngon giấc
Những ai từng mất ngủ hẳn đã nghe nói đến khái niệm “vệ sinh giấc ngủ” – đây là lời khuyên phổ biến mà các chuyên gia y tế thường đưa ra. Tuy nhiên, trong liệu pháp nhận thức hành vi dành cho mất ngủ (CBT-I), vệ sinh giấc ngủ không phải là yếu tố quan trọng nhất, vì có nhiều phương pháp hiệu quả hơn để cải thiện giấc ngủ. Dẫu vậy, một số nguyên tắc căn bản vẫn đáng để mọi người lưu tâm. Tôi thường nói với bệnh nhân của mình rằng: hãy làm sạch giấc ngủ của bạn một cách kỹ lưỡng nhất có thể, loại bỏ tất cả những gì có thể cản trở giấc ngủ, giúp bạn có nền tảng tốt hơn để áp dụng những phương pháp cải thiện khác.
Nếu bạn đang gặp vấn đề với giấc ngủ, hãy nghiêm túc tuân thủ những nguyên tắc sau:
Không uống caffeine sau 2 giờ chiều.
Hạn chế tối đa (hoặc tốt nhất là tránh hẳn) rượu và nicotine, đặc biệt trong vòng 3 giờ trước khi ngủ.
Thiết lập một thói quen thư giãn kéo dài từ 60 đến 90 phút trước khi đi ngủ. Hãy để cơ thể và tâm trí được thả lỏng bằng những hoạt động nhẹ nhàng như đọc sách, thiền, nghe nhạc êm dịu, tắm nước ấm hoặc thực hiện các bước chăm sóc bản thân. Tránh xa email công việc, tắt thông báo điện thoại, đừng lên kế hoạch hay suy nghĩ chiến lược, không chơi game hay lướt mạng xã hội. Hãy nghĩ đến những gì nhẹ nhàng, thư thái và bình yên nhất.
Biến phòng ngủ thành nơi dành riêng cho giấc ngủ: Đầu tư vào chăn ga, nệm tốt nhất trong khả năng của bạn, giữ phòng tối, yên tĩnh (dùng nút bịt tai nếu cần) và duy trì nhiệt độ mát mẻ.
Đừng kiểm tra đồng hồ nếu bạn thức giấc giữa đêm.
Bổ sung đủ nước vào ban ngày, nhưng đừng uống quá nhiều ngay trước khi ngủ.
Duy trì giờ thức dậy cố định mỗi sáng, kể cả vào cuối tuần. Điều này giúp điều chỉnh đồng hồ sinh học của cơ thể.
Tiếp xúc với ánh sáng tự nhiên nhiều nhất có thể, đặc biệt là vào buổi sáng. Dù trời có âm u, ánh sáng tự nhiên vẫn có tác dụng. Nếu không thể ra ngoài, ngồi gần cửa sổ cũng là một lựa chọn thay thế.
###  Tăng cường mối liên kết giữa giấc ngủ và không gian ngủ
Một nguyên tắc quan trọng trong trị liệu mất ngủ là điều khiển kích thích, tức là giữ cho giường và phòng ngủ chỉ dành cho giấc ngủ (và sự thân mật), không phải cho các hoạt động khác. Nếu bạn bị mất ngủ, hãy tránh làm những việc như ăn uống, đọc sách, làm việc, xem TV, chơi game, kiểm tra tài khoản ngân hàng hay lập danh sách việc cần làm trong phòng ngủ.
Tại sao lại như vậy? Vì bộ não của chúng ta hoạt động theo nguyên tắc "phản xạ có điều kiện" (giống như thí nghiệm của Pavlov), tức là khi một môi trường liên tục gắn liền với một hành vi cụ thể, dần dần nó sẽ hình thành một liên kết mạnh mẽ. Chúng ta muốn khi vừa bước vào phòng ngủ, bộ não sẽ tự động sản sinh melatonin, hormone giúp cơ thể buồn ngủ. Điều chúng ta không muốn là khiến bộ não liên kết phòng ngủ với công việc, suy nghĩ, lo âu, tính toán hay các hoạt động kích thích khác.
Rất nhiều bệnh nhân hỏi tôi: "Tôi có thể đọc sách hay nghe nhạc trên giường không?" Câu trả lời là: trong quá trình điều trị mất ngủ, tốt nhất nên tránh. Hãy thực hiện những hoạt động này ở một không gian khác trước khi lên giường. Khi giấc ngủ đã ổn định trở lại, bạn có thể thử đọc sách hay nghe nhạc trên giường để xem có ảnh hưởng gì không.
###  Áp dụng nguyên tắc "20 phút" nếu không ngủ được
Nếu bạn trằn trọc trên giường quá lâu, hãy ra khỏi giường. Nguyên tắc đơn giản là: nếu sau khoảng 20 phút mà vẫn không ngủ được, hãy đứng dậy. Nếu không chắc mình đã thức bao lâu, hãy lắng nghe cơ thể, nếu cảm thấy bực bội, khó chịu, thao thức, thì có lẽ đã đến lúc nên rời giường.
Đi đến một không gian khác, một nơi ấm áp, thoải mái, ánh sáng dịu nhẹ và làm điều gì đó thư giãn nhưng không quá kích thích, chẳng hạn như đọc sách, giải ô chữ, nghe nhạc hoặc podcast. Tuyệt đối không được nằm xuống! Bạn không muốn bộ não của mình liên kết cảm giác buồn ngủ với ghế sofa; thay vào đó, hãy quay lại giường ngay khi cảm thấy mắt díp lại và cơ thể thực sự muốn ngủ.
Giữ cho giấc ngủ của bạn “sạch sẽ” và xây dựng những thói quen đúng đắn chính là bước đầu tiên để thoát khỏi cơn ác mộng mất ngủ và tìm lại những đêm an giấc.
###  Thay đổi niềm tin tiêu cực về giấc ngủ
Những gì bạn tin về giấc ngủ có thể góp phần kéo dài tình trạng mất ngủ. Tôi đã gặp rất nhiều người dần dần thuyết phục chính mình rằng họ không thể ngủ ngon và có lẽ sẽ chẳng bao giờ có lại giấc ngủ trọn vẹn. Nhiều người tin rằng chỉ có thuốc ngủ mới có thể giúp họ. Không ít người luôn tự nhủ rằng nếu không ngủ đủ giấc, họ sẽ không thể làm việc hiệu quả, dù thực tế họ vẫn duy trì công việc của mình suốt nhiều năm qua, ngay cả khi giấc ngủ bị rối loạn. Những ai mất ngủ lâu ngày thường có cảm giác mất kiểm soát hoàn toàn đối với giấc ngủ của mình và tin rằng họ chẳng thể làm gì để cải thiện nó.
Những suy nghĩ này hoàn toàn dễ hiểu. Mất ngủ khiến con người ta rơi vào trạng thái chán nản, bế tắc. Khi ngủ không đủ, tâm trạng và khả năng tư duy đều bị ảnh hưởng, khiến ta dễ suy nghĩ tiêu cực hơn, mất đi sự linh hoạt và trở nên bi quan về khả năng vượt qua khó khăn của chính mình.
Nếu bạn cảm thấy những niềm tin này đang cản trở giấc ngủ của mình, hãy thử thách thức chúng bằng cách tự vấn bản thân qua những bước sau (mẹo nhỏ: hãy làm bài tập này vào ban ngày để có tâm trí sáng suốt nhất):
Nhận diện: Ngay lúc này, tôi đang có những suy nghĩ nào về giấc ngủ? Chúng có thực sự đúng không?
Tìm hiểu nguyên nhân: Điều gì đang xảy ra khiến tôi suy nghĩ theo hướng này?
Thực hành lòng trắc ẩn với chính mình: Không có gì lạ khi mất ngủ khiến tôi cảm thấy như vậy. Tôi không cần trách móc bản thân.
Lùi lại một bước và tự hỏi: Liệu tôi có thể sai về điều này không? Có cách nào khác để nhìn nhận vấn đề không? Liệu tôi có đang phóng đại mọi chuyện?
Đánh giá lại: Bằng chứng thực tế là gì? Khi không còn mệt mỏi, căng thẳng hay bực bội, tôi sẽ nghĩ khác về chuyện này ra sao?
Nhìn lại nhu cầu của bản thân: Ngay lúc này, tôi có thể làm gì để cảm thấy tốt hơn một chút?
###  “Dọn dẹp” tâm trí để thoát khỏi những suy nghĩ quay cuồng
Rất nhiều người gặp phải tình trạng tâm trí chạy đua, ngay khi vừa thức dậy (hoặc thậm chí ngay cả khi nằm trên giường), hàng loạt suy nghĩ ập đến: những việc cần làm, những nỗi lo, những ký ức cũ… Điều này thường bắt nguồn từ áp lực ban ngày, khối lượng công việc lớn và việc không có đủ thời gian nghỉ ngơi thực sự.
Một cách giúp làm dịu những suy nghĩ này trước khi đi ngủ là “dọn dẹp não bộ”, một bài tập đơn giản nhưng có thể mang lại hiệu quả đáng kể. Bạn có thể thử thực hiện nó khoảng một giờ trước khi lên giường.
Hãy viết ra tất cả những gì đang xoay vần trong đầu bạn.
Không cần chi tiết hay sắp xếp gọn gàng, một danh sách ngắn gọn những điều bạn đang nghĩ đến là đủ.
Việc chuyển suy nghĩ từ tâm trí ra giấy giống như giải phóng không gian trong đầu, giúp bạn cảm thấy nhẹ nhõm hơn.
Đôi khi, nhìn thấy mọi thứ trên giấy sẽ giúp bạn có góc nhìn mới: "Mình không cần phải giải quyết chuyện này ngay bây giờ" hay "Hóa ra nó không tệ như mình tưởng".
###  Thư giãn cơ thể trước khi ngủ
Thư giãn cơ bắp theo phương pháp từng bước là một cách tuyệt vời để giúp cơ thể thả lỏng, từ đó làm dịu tâm trí và dễ dàng chìm vào giấc ngủ hơn. Đây là một kỹ thuật đơn giản mà bạn có thể thực hành ngay khi nằm lên giường.
Hãy thử làm theo các bước sau:
Chọn tư thế thoải mái nhất, tốt nhất là nằm ngửa để cơ thể được thả lỏng hoàn toàn.
Nhắm mắt lại, hít thở chậm rãi trong khoảng 30 giây, theo nhịp điệu tự nhiên của bạn.
Hình dung một luồng ánh sáng nhẹ nhàng quét dọc cơ thể, từ đỉnh đầu xuống tận đầu ngón chân. Khi làm điều này, hãy lắng nghe cơ thể mình, cảm nhận xem có nơi nào đang căng cứng hay không.
Khi phát hiện một nhóm cơ căng (vai, cổ, cơ mặt, tay, chân...), hãy tập trung vào đó. Nhẹ nhàng siết chặt nhóm cơ đó trong vài giây, vừa đủ để cảm thấy một chút khó chịu.
Cảm nhận sự căng cơ, sau đó từ từ thả lỏng, để cơ bắp mềm ra hoàn toàn. Chú ý đến sự thay đổi từ trạng thái căng cứng sang thư giãn.
Lặp lại bước trên một lần nữa, rồi tiếp tục quét cơ thể để tìm những vùng căng khác và làm tương tự.
Đặc biệt hiệu quả với đôi tay: Hãy nắm chặt hai bàn tay thành nắm đấm, giữ một lúc đến khi cảm thấy hơi căng, rồi nhẹ nhàng mở ra, để ý cảm giác thư giãn lan tỏa khắp lòng bàn tay.
Khi thực hiện bài tập này, đừng vội vã. Hãy tận hưởng từng nhịp thả lỏng, từng giây phút mà cơ thể bạn được buông bỏ mọi căng thẳng.
###  Cân nhắc thử nghiệm giới hạn thời gian ngủ
Giới hạn thời gian ngủ nghe có vẻ mâu thuẫn, nhưng thực chất đây là một phương pháp khoa học giúp cải thiện chất lượng giấc ngủ. Nguyên tắc của phương pháp này là giảm tổng thời gian nằm trên giường, từ đó tạo áp lực sinh học để cơ thể thực sự cần ngủ (còn gọi là "sleep drive"). Ban đầu, điều này có thể khiến bạn ngủ ít hơn, nhưng về lâu dài, giấc ngủ sẽ sâu và liền mạch hơn.
Tuy nhiên, phương pháp này đòi hỏi sự kiên trì trong vài tuần mới có kết quả, và do ảnh hưởng của việc thiếu ngủ tạm thời, nó không phù hợp với tất cả mọi người. Nếu không có sự hướng dẫn của chuyên gia, bạn chỉ nên thử nghiệm một cách nhẹ nhàng và an toàn.
Một cách đơn giản để áp dụng là:
Đi ngủ muộn hơn bình thường, nhưng vẫn thức dậy vào cùng một giờ mỗi sáng, kể cả khi bạn ngủ ít.
Chỉ tắt đèn và nhắm mắt khi thực sự cảm thấy buồn ngủ. Nhiều người mất ngủ thường cố nằm trên giường trước khi cơ thể sẵn sàng, điều này chỉ làm kéo dài thời gian trằn trọc.
###  Tìm kiếm sự trợ giúp chuyên môn khi cần thiết
Nếu chứng mất ngủ đang gây ra căng thẳng, rối loạn nhịp sống và ảnh hưởng đến chất lượng cuộc sống của bạn, đừng ngần ngại tìm đến sự hỗ trợ từ chuyên gia về giấc ngủ, đặc biệt là những người được đào tạo bài bản về trị liệu hành vi nhận thức dành cho mất ngủ (CBT-I).
Phần lớn các chuyên gia về giấc ngủ thường là bác sĩ y khoa, vì hầu hết các rối loạn giấc ngủ đều được điều trị bằng thuốc hoặc các phương pháp y học. Tuy nhiên, mất ngủ lại là một dạng rối loạn khác. Nó thường không bắt nguồn từ vấn đề thể chất mà chủ yếu xuất phát từ tâm lý – lo âu, căng thẳng, thói quen sinh hoạt không phù hợp hay thậm chí là những tổn thương tâm lý trong quá khứ. Vì vậy, những người bị mất ngủ có thể hưởng lợi rất nhiều từ sự hỗ trợ của các chuyên gia chuyên về trị liệu tâm lý.
Nếu bạn muốn tìm hiểu thêm về CBT-I, thuốc hỗ trợ giấc ngủ và các công cụ khác có thể kết hợp với những phương pháp tự cải thiện tại nhà, hãy tham khảo phần thông tin chi tiết ở cuối bài.
###  Những điểm cốt lõi để tìm lại giấc ngủ ngon
Mất ngủ có thể gây ảnh hưởng sâu rộng đến cuộc sống. Khi tình trạng trằn trọc kéo dài, nó không chỉ mang đến sự mệt mỏi, cáu kỉnh, mà còn làm suy giảm sức khỏe thể chất và tinh thần vào ban ngày.
Mất ngủ phổ biến nhưng hoàn toàn có thể chữa trị. Khoảng một phần ba người trưởng thành từng gặp phải các triệu chứng mất ngủ. CBT-I là một phương pháp trị liệu chuyên sâu giúp phá vỡ vòng luẩn quẩn duy trì chứng mất ngủ bằng những nguyên tắc tâm lý khoa học.
Nhận diện những hành vi có thể khiến mất ngủ trầm trọng hơn. Một số thói quen tưởng như có ích, như đi ngủ sớm hơn bình thường hay uống rượu để dễ ngủ, thực ra lại khiến giấc ngủ trở nên rối loạn hơn.
Duy trì vệ sinh giấc ngủ tốt. Hãy tránh caffeine và rượu vào cuối ngày, tạo một thói quen thư giãn trước khi ngủ và giữ cho phòng ngủ tối, yên tĩnh, thoải mái nhất có thể.
Kiểm soát các tác nhân kích thích trong phòng ngủ. Nếu bạn bị mất ngủ, hãy để chiếc giường chỉ dành cho việc ngủ – đừng biến nó thành nơi làm việc, lo lắng hay giải trí, để não bộ dần tạo mối liên kết giữa không gian phòng ngủ và giấc ngủ.
Thách thức những niềm tin tiêu cực về giấc ngủ. Khi mất ngủ kéo dài, bạn có thể cảm thấy vô vọng và tin rằng mình sẽ không bao giờ ngủ ngon trở lại. Nhưng những suy nghĩ này không phải là sự thật tuyệt đối, hãy thử đặt câu hỏi, nhìn nhận vấn đề một cách khách quan hơn.
Viết ra những suy nghĩ rối ren trước khi đi ngủ. Nếu tâm trí bạn lúc nào cũng tràn ngập lo lắng, hãy dành vài phút để ghi chép lại. Việc này giúp giải phóng bộ não khỏi những suy nghĩ lộn xộn, giúp bạn thư thái hơn trước khi chìm vào giấc ngủ.
Thực hành một kỹ thuật thư giãn trước giờ ngủ. Bài tập thư giãn cơ bắp theo từng bước (tensing and relaxing) có thể giúp cơ thể và tâm trí trở nên bình yên hơn.
Cân nhắc thử nghiệm giới hạn thời gian ngủ một cách thận trọng. Một cách tiếp cận nhẹ nhàng là chỉ lên giường khi bạn thực sự buồn ngủ và luôn thức dậy vào cùng một thời điểm mỗi sáng, bất kể đêm trước ngủ ra sao.
Tìm kiếm sự giúp đỡ chuyên môn nếu cần thiết. Nếu chứng mất ngủ đang ảnh hưởng nghiêm trọng đến cuộc sống của bạn, hãy tìm đến các chuyên gia về giấc ngủ được đào tạo chuyên sâu về CBT-I để có hướng điều trị phù hợp.
###  Về thuốc điều trị mất ngủ
Một lựa chọn khác là sử dụng thuố, đây vẫn là phương pháp phổ biến trong điều trị mất ngủ. Tuy nhiên, thuốc không thể giải quyết tận gốc nguyên nhân của chứng mất ngủ, mà chỉ giúp giảm bớt triệu chứng trong ngắn hạn. Ngoài ra, việc lạm dụng thuốc có thể dẫn đến tác dụng phụ không mong muốn và nguy cơ phụ thuộc về mặt tâm lý.
Tại Anh, "z-drugs" (nhóm thuốc an thần như zopiclone và zolpidem) thường được kê đơn cho những người mất ngủ. Ngoài ra, một số loại thuốc chống trầm cảm như mirtazapine cũng có thể được sử dụng để hỗ trợ giấc ngủ. Tuy nhiên, các nghiên cứu đã chỉ ra rằng việc sử dụng thuốc ngủ trong thời gian dài có thể làm tăng nguy cơ mắc các vấn đề sức khỏe khác, thậm chí khiến giấc ngủ rối loạn hơn. Nếu bạn đang cân nhắc dùng thuốc, hãy tham khảo ý kiến bác sĩ để hiểu rõ những lợi ích, rủi ro cũng như tác dụng phụ có thể gặp phải.
Những phương pháp khác – đâu là lựa chọn đáng tin cậy?
Hiện nay, trên thị trường có vô số sản phẩm và phương pháp được quảng bá là giúp cải thiện giấc ngủ – từ thực phẩm chức năng, trà thảo dược, máy phát âm thanh trắng đến các thiết bị hỗ trợ giấc ngủ. Ngành công nghiệp giấc ngủ là một thị trường lớn, bởi mất ngủ là vấn đề rất phổ biến. Tuy nhiên, cho đến nay, chỉ có CBT-I và thuốc điều trị mất ngủ là hai phương pháp được khuyến nghị chính thức trong điều trị chứng mất ngủ kéo dài.
Nếu bạn đang tìm kiếm một giải pháp bền vững, CBT-I vẫn là phương pháp hiệu quả và an toàn nhất, vì nó giúp bạn xây dựng lại mối quan hệ lành mạnh với giấc ngủ, thay vì chỉ tạm thời che giấu triệu chứng.
  * [ Mất ngủ là chuyện thường gặp, nhưng hoàn toàn có thể chữa trị](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/lam-sao-de-ngu-ngon-tro-lai#mt-ng-l-chuyn-thng-gp-nhng-hon-ton-c-th-cha-tr)
  * [ Làm gì để thoát khỏi mất ngủ?](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/lam-sao-de-ngu-ngon-tro-lai#lm-g-thot-khi-mt-ng)
  * [ Giữ gìn “vệ sinh giấc ngủ” để có những đêm ngon giấc](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/lam-sao-de-ngu-ngon-tro-lai#gi-gn-v-sinh-gic-ng-c-nhng-m-ngon-gic)
  * [ Tăng cường mối liên kết giữa giấc ngủ và không gian ngủ](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/lam-sao-de-ngu-ngon-tro-lai#tng-cng-mi-lin-kt-gia-gic-ng-v-khng-gian-ng)
  * [ Áp dụng nguyên tắc "20 phút" nếu không ngủ được](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/lam-sao-de-ngu-ngon-tro-lai#p-dng-nguyn-tc-20-pht-nu-khng-ng-c)
  * [ Thay đổi niềm tin tiêu cực về giấc ngủ](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/lam-sao-de-ngu-ngon-tro-lai#thay-i-nim-tin-tiu-cc-v-gic-ng)
  * [ “Dọn dẹp” tâm trí để thoát khỏi những suy nghĩ quay cuồng](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/lam-sao-de-ngu-ngon-tro-lai#dn-dp-tm-tr-thot-khi-nhng-suy-ngh-quay-cung)
  * [ Thư giãn cơ thể trước khi ngủ](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/lam-sao-de-ngu-ngon-tro-lai#th-gin-c-th-trc-khi-ng)
  * [ Cân nhắc thử nghiệm giới hạn thời gian ngủ](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/lam-sao-de-ngu-ngon-tro-lai#cn-nhc-th-nghim-gii-hn-thi-gian-ng)
  * [ Tìm kiếm sự trợ giúp chuyên môn khi cần thiết](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/lam-sao-de-ngu-ngon-tro-lai#tm-kim-s-tr-gip-chuyn-mn-khi-cn-thit)
  * [ Những điểm cốt lõi để tìm lại giấc ngủ ngon](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/lam-sao-de-ngu-ngon-tro-lai#nhng-im-ct-li-tm-li-gic-ng-ngon)
  * [ Về thuốc điều trị mất ngủ](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/lam-sao-de-ngu-ngon-tro-lai#v-thuc-iu-tr-mt-ng)



## Hướng dẫn về số bước chân mỗi người nên đi hàng ngày

Năm 2004, tác giả Tudor-Locke và Basset đã giới thiệu khái niệm về phân loại chỉ số bước chân cho người lớn mạnh khỏe.
  * < 5.000 bước/ngày là người “vận động hạn chế”
  * 5.000-7.499 bước/ngày là người “ít hoạt động”
  * 7.500-9.999 bước/ngày là người “hoạt động vừa phải”
  * ≥10.000-12.499 bước/ngày là người “hoạt động”
  * ≥12.500 bước/ngày là người “hoạt động nhiều”.


+ Hiệp hội Tim mạch Quốc gia Úc : Mục tiêu đề xuất cho người lớn khỏe mạnh là 10.000 bước mỗi ngày
+ Chương trình Giải thưởng Thể dục và Hoạt động Thể chất của Mỹ: Khuyến nghị 8.500 bước/ngày cho người lớn, 13.000 và 11.000 bước/ngày cho bé trai và bé gái
+ Nước Mỹ đang chuyển động: Khuyến khích đi bộ thêm 2.000 bước và ăn ít hơn 100 calo mỗi ngày để ngăn ngừa tăng cân
+ Diễn đàn béo phì quốc gia (Anh): Chỉ ra rằng 3.000 đến 6.000 bước/ngày là ít vận động, 7.000 đến 10.000 bước là hoạt động vừa phải và > 11.000 bước/ngày là hoạt động nhiều.
+ Cơ quan Y tế Công cộng Bắc Ireland: Tăng thêm 30 phút đi bộ hoặc 3000 bước mỗi ngày
+ Bộ Y tế, Lao động và Phúc lợi Nhật Bản : Khuyến cáo: "đối với những cá nhân có ý định tăng cường sức khỏe bằng hoạt động thể chất, mục tiêu là đi bộ hàng ngày từ 8.000 đến 10.000 bước. Báo cáo chỉ ra rằng 8.000 đến 10.000 bước/ngày tương đương với 60 phút đi bộ mỗi ngày
**Tóm lại,** tất cả các hướng dẫn đều công nhận “việc hoạt động thể chất ở bất kỳ mức độ nào đều tốt hơn là không có” và số bước chính xác thì còn phải dựa vào nhiều các yếu tố khác như tuổi tác, giới, bệnh lý kèm theo và chế độ ăn uống.
Tiếp đó, ngoài thời gian hoạt động cơ bản tối thiểu thì nên có thời gian hoạt động thể chất ở mức độ trung bình - mạnh. Hoạt động này được hiểu là đi bộ với tần suất ≥100 bước/phút liên tục trong ít nhất 10 phút.
Trung bình một người lớn khỏe mạnh có thể đi bộ từ khoảng 4.000 đến 18.000 bước/ngày và 10.000 bước/ngày là mục tiêu hợp lý. Số bước chân tối thiểu trong ngày để duy trì sức khỏe là 7000 – 8000 bước và trong đó tối thiểu có 3000 bước đi nhanh.
[_https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3197470/_](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3197470/)

## Câu lạc bộ Bệnh nhân Parkinson và rối loạn vận động 20/10/2024

Link đăng ký tham dự: [**TẠI ĐÂY**](https://bit.ly/CLBParkinsonBVNTP)
**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/)** - Đa khoa Hạng I Thành phố Hồ Chí Minh

## Các loại hình khám sức khỏe, tầm soát và chẩn đoán bệnh sớm bằng công nghệ cao trên Thế giới và tại Thành phố Hồ Chí Minh (cập nhật đến 2024)

Hiện nay trên thế giới có nhiều mô hình về khám và kiểm tra sức khỏe tổng quát ở các nước trên thế giới. Tùy thuộc vào điều kiện kinh tế, xã hội, văn hóa của từng quốc gia mà mô hình khám và tầm soát sức khỏe sẽ khác nhau. Trong đó, một mô hình khám sức khỏe và phát hiện bệnh sớm bằng công nghệ cao được nhiều người biết đến và sử dụng là mô hình khám sức khoẻ Ningen Dock. Mô hình này bắt đầu triển khai từ năm 1954 tại Nhật Bản và được xem như là một "Bệnh viện trong ngày chuyên về kiểm tra khám sức khoẻ", xuất hiện đầu tiên ở Tokyo, nay là Trung tâm quốc gia về sức khỏe và y học toàn cầu. Trong thời gian một hoặc hai ngày, khách hàng sử dụng dịch vụ khám sức khoẻ Ningen Dock sẽ trải qua một loạt các xét nghiệm, như xét nghiệm máu, xét nghiệm nước tiểu và phân, chụp X-quang, siêu âm và các chẩn đoán hình ảnh học cao cấp khác. Sau khi có đầy đủ kết quả xét nghiệm, bác sĩ sẽ giải thích kết quả cho khách hàng và đưa ra những lời khuyên về điều chỉnh lối sống để có thể duy trì sức khỏe của họ.
Hàng năm, Ningen Dock đã thu hút khoảng 3 triệu người sử dụng dịch vụ tại khoảng 1.500 cơ sở y tế trên khắp đất nước Nhật Bản. Tại Nhật Bản, có nhiều loại hình chọn lựa cho khác hàng khi đến với Ningen Dock, tuỳ vào số lượng dịch vụ kiểm tra sức khoẻ, mà thời gian khám sẽ khác nhau. Ningen Dock có thể phát hiện sớm nhiều bệnh khác nhau, nhưng một trong những mục tiêu chính của Ningen Dock là phát hiện sớm ung thư, nguyên nhân hàng đầu gây tử vong ở Nhật Bản. Ngoài ra còn chú trọng vào việc sử dụng các xét nghiệm khác nhau để có thể biết được chi tiết về tình trạng sức khoẻ hiện tại của khách hàng, kiểm tra tiền sử sức khoẻ của người thân, từ đó bác sĩ có thể tư vấn về lối sống để duy trì sức khoẻ ở trạng thái tốt nhất có thể, tư vấn các bệnh lý do lối sống gây ra (như cao huyết áp, tiểu đường, rối loạn mỡ máu, béo phì…) và cách phòng chống các bệnh tim mạch, đột quỵ, nhồi máu cơ tim, phát hiện sớm chứng suy giảm trí nhớ. Ngày nay, người Nhật tự hào là dân số có độ tuổi sống khoẻ cao nhất thế giới, trong đó phải kể đến vai trò của Ningen Dock. Trải qua “bảo trì sức khoẻ” theo mô hình Ningen Dock của Nhật Bản sẽ làm cho mọi người ý thức hơn về tình trạng thể chất của họ, giúp họ duy trì sức khỏe, từ đó có tác dụng làm chậm quá trình lão hóa. 
Tại Nhật, khám sức khỏe thông thường người dân sẽ được bảo hiểm chi trả nhưng khám theo mô hình Ningen Dock, bảo hiểm không chi trả. Tuy nhiên, ngày càng có nhiều doanh nghiệp sẵn sàng chia sẻ, chi trả khoảng 30% chi phí khám Ningen Dock cho cấp quản lý, nhân viên thâm niên. Số người sử dụng phương pháp Ningen Dock tăng dần qua mỗi năm. Trong đó có người nước ngoài, đặc biệt là người Việt Nam qua Nhật Bản tầm soát sức khỏe bằng phương pháp Ningen Dock tăng qua từng năm. Theo Global Health & Medicine, 2022; tính đến tháng 3 năm 2017, tổng số khách nước ngoài khám Ningen Dock tại Trung tâm Quốc gia về Sức khỏe và Y tế toàn cầu của Nhật Bản (NCGM) đã tăng gấp khoảng 10 lần so với năm trước đó. Số lượng người Việt kiểm tra tăng nhanh sau tháng 9 năm 2017. Điều này cũng có nghĩa là người Việt có xu hướng quan tâm đến sức khỏe của mình cũng tăng lên từng năm. Năm 2019, tại NCGM, số lượng người nước ngoài là 3.385, chiếm 28% tổng số người khám sức khỏe và chiếm hơn 50% tổng doanh thu của Trung tâm.
Hiện nay, ngoài Nhật Bản, mô hình khám sức khỏe và tầm soát bệnh Ningen Dock đã xuất hiện tại một số quốc gia như Trung quốc, Thái Lan, Singapore và Việt Nam. Các quốc gia khác cũng có mô hình tầm soát bệnh bằng công nghệ cao tương tự mô hình Ningen Dock hoặc các chương trình kiểm tra sức khỏe toàn diện như Hoa Kỳ (Executive Health Programs), Hàn Quốc (Health Screening Programs), Đài Loan (Health Examination Programs) và một số quốc gia châu Âu khác.
Đối với một đô thị loại đặc biệt như Thành phố Hồ Chí Minh, đến nay vẫn chưa có một trung tâm chuyên khám sức khỏe và tầm soát bệnh sớm bằng công nghệ cao. Hiện nay, các bệnh viện trên địa bàn Thành phố chủ yếu cung cấp các dịch vụ khám sức khỏe cơ bản theo quy định như khám sức khỏe cho người lao động, khám sức khỏe cho sinh viên, học sinh, khám sức khỏe lái xe, khám sức khỏe thuyền viên, khám sức khỏe cho người nước ngoài làm việc tại Việt Nam… Người dân có nhu cầu khám sức khỏe chuyên sâu hơn để tầm soát và phát hiện sớm bệnh đều phải tự đến các bệnh viện để thực hiện các xét nghiệm tầm soát, kiểm tra tình trạng sức khỏe. Bên cạnh đó, mặc dù Ngành y tế Thành phố được đánh giá cao về tay nghề, trình độ chuyên môn, thế nhưng hiện nay vẫn còn tình trạng người dân có điều kiện kinh tế ra nước ngoài và người nước ngoài đang sinh sống, làm việc tại Thành phố quay về quê hương để điều trị hoặc để được khám sức khỏe, tầm soát một số bệnh lý như ung thư, tim mạch…. Ước tính của Bộ Y tế cho thấy mỗi năm người Việt chi khoảng 2 tỉ USD cho mục đích này.
Năm 2018, Bệnh viện Chợ Rẫy đã thành lập Trung tâm kiểm tra sức khỏe Việt Nhật - HECI tại Khoa khám bệnh theo yêu cầu của Bệnh viện. Đây là đề án hợp tác giữa Bệnh viện Chợ Rẫy và Trường Đại học Quốc tế Y tế và Phúc lợi Nhật Bản theo phương thức hợp đồng hợp tác kinh doanh (BCC), trong đó, phía Nhật Bản đầu tư, mua sắm các trang thiết bị y tế hiện đại và đào tạo cho nhân viên y tế của Bệnh viện Chợ Rẫy để triển khai dịch vụ khám sức khỏe theo mô hình Ningen Dock. Trung tâm kiểm tra sức khỏe Việt Nhật – HECI cung cấp dịch vụ chất lượng cao với không gian tiện nghi, xét nghiệm bằng các trang thiết bị y tế hiện đại của Nhật Bản và có cơ chế hội chẩn kép với các chuyên gia Nhật Bản để đảm bảo kết quả chẩn đoán chính xác nhất. Trung tâm còn có hình thức đặt hẹn trước giúp khách hàng không phải chờ đợi; cung cấp 2 gói khám với tổng cộng 80 hạng mục xét nghiệm và chẩn đoán hình ảnh, phù hợp với nhiều đối tượng và thời gian thực hiện trong nửa ngày đến một ngày.
Trung tâm HECI đã chứng minh hiệu quả và thu hút người dân không chỉ ở Thành phố mà còn ở các tỉnh, thành và người nước ngoài đến sử dụng dịch vụ. Tuy nhiên, năng lực của Trung tâm chưa đủ để đáp ứng nhu cầu khám sức khỏe và tầm soát bệnh của người dân, thời gian chờ trung bình từ 03 đến 06 tháng. Do đó, việc thành lập một trung tâm khám sức khỏe và tầm soát bệnh bằng công nghệ cao với quy mô lớn hơn cho Thành phố là điều cần thiết. 
_Lu J. Ningen Dock: Japan's unique comprehensive health checkup system for early detection of disease. Glob Health Med. 2022 Feb 28;4(1):9-13. doi: 10.35772/ghm.2021.01109. PMID: 35291200; PMCID: PMC8884042._[_https://www.ncbi.nlm.nih.gov/pmc/articles/PMC8884042_](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC8884042)

## Statin - điều trị rối loạn lipid máu - người bệnh đái tháo đường cần biết

1. Điều trị rối loạn Lipid máu, cùng kiểm soát đường huyết và huyết áp là 3 trụ cột chính trong phòng ngừa biến chứng và tử vong tim mạch ở BN ĐTĐ
2. Thuốc điều trị rối loạn mỡ máu được lựa chọn là Statin vì nó (1) làm giảm LDL-C là nguyên nhân chính gây xơ vữa động mạch, và (2) làm giảm biến cố tim mạch cả trong dự phòng tiên phát (ở BN chưa có biến chứng tim mạch) và dự phòng thứ phát (ở BN đã có biến chứng tim mạch).
3. Điều trị Statin càng sớm càng tốt: Vì BN ĐTĐ được xếp vào nhóm nguy cơ tim mạch cao/ rất cao. Tất cả các BN ĐTĐ típ 2 ≥ 40 tuổi hoặc BN trẻ hơn nhưng có yếu tố nguy cơ tim mạch (béo, tăng huyết áp, rối loạn mỡ máu, biến chứng thận...) đều có chỉ định điều trị Statin
4. Điều trị Statin càng lâu càng tốt: Statin có bằng chứng hiệu quả bảo vệ tim mạch ở BN từ 40 - 75 tuổi, tuy nhiên với những người > 75 tuổi mà khỏe mạnh, dự kiến còn sống lâu thì vẫn được khuyên nên dùng tiếp Statin. Một số BN hay bỏ thuốc vì họ không nhìn được con số Lipid máu dễ dàng như đo huyết áp hay đo đường huyết mao mạch, và càng không thể nhìn được mảng xơ vữa ở mạch máu của họ.
5. Có uống thuốc nhưng phải đạt mục tiêu: Mục tiêu LDL-C phải < 2,6 hoặc < 1,8 hoặc < 1,4 mmol/L tùy BN đã có biến chứng tim mạch chưa, hay nguy cơ tim mạch cao hay trung bình. Ngay mục tiêu đơn giản nhất là < 2,6 mmol/L cũng thấp hơn rất nhiều so với ngưỡng ở người bình thường (ghi trên tờ giấy xét nghiệm) là < 3,4 mmol/L.
6. Liều thuốc Statin là rất quan trọng: Cũng giống như khi dùng thuốc huyết áp hay đái tháo đường, BN có thể cần dùng thuốc Statin liều cao để đạt được mục tiêu. Nếu đã dùng liều cao mà vẫn chưa đạt mục tiêu LDL-C thì cần phối hợp thêm thuốc hạ Lipid máu khác.
7. Khi đã đạt mục tiêu mỡ máu thì có được ngừng hay giảm liều thuốc không ? Không vì thuốc Statin có có thêm các tác dụng chống viêm, ổn định mảng xơ vữa, thậm chí làm giảm mảng xơ vữa. Nó được coi là thuốc bảo vệ tim mạch nên cần duy trì lâu dài ở BN đái tháo đường.
8. Khi suy thận vẫn cần uống thuốc: BN đái tháo đường có suy thận nghĩa là nguy cơ tim mạch cao hơn, mục tiêu LDL-C cần thấp hơn nên càng cần điều trị rối loạn Lipid máu. Hơn nữa các thuốc Statin đã được chứng minh có lợi ích trên thận.
9. Khi Triglyceride máu cao thì phải điều trị thuốc Fibrate nhưng cũng có thể vẫn cần điều trị thuốc Statin: Nếu Triglyceride máu > 11,2 mmol/L thì BN sẽ được cho điều trị ưu tiên bằng thuốc Fibrate để phòng ngừa viêm tụy cấp, nhưng nếu Triglyceride > 5,6 mmol/L và < 11,2 mmol/L thì có thể cho điều trị Fibrate nếu nguy cơ tim mạch thấp hoặc Statin nếu nguy cơ tim mạch cao. Lưu ý là Statin có tác dụng làm giảm Triglyceride khoảng 10-30%.
10. Tăng men gan không phải là chống chỉ định của Statin: Có lẽ nguyên nhân phổ biến nhất gây tăng men gan nhẹ ở BN đái tháo đường là gan nhiễm mỡ, và họ là BN cần được điều trị tích cực rối loạn lipid máu chứ không phải là thuốc bổ gan. Tỷ lệ thuốc Statin gây tăng men gan là rất thấp.
11. Không uống Statin cách ngày: Phần lớn các Statin được chỉ định uống vào buổi tối, nhưng với các Statin có tác dụng dài như Atorvastatin , Rosuvastatin, Pitavastatin thì có thẻ uống bất cứ lúc nào trong ngày nhưng không đủ để có tác dụng khi uống cách ngày.
12. Làm gì khi nghi ngờ không “dung nạp” với Statin: Khi bị mệt, đau cơ, yếu cơ hoặc các tác dụng phụ khác nghi do Statin thì nên báo Bác sĩ. Vì thuốc này rất quan trọng với BN đái tháo đường, việc ngừng thuốc có thể gây hậu quả không tốt, nên khi có các biểu hiện trên thì hướng xử trí có thể là giảm liều thuốc Statin xuống liều thấp nhất, đổi sang Statin khác, uống Statin 2-3 lần/ tuần, hoặc đổi sang thuốc điều trị rối loạn mỡ máu khác. Sau đó sẽ đánh giá để quyết định hướng điều trị tiếp.
Biên soạn: TS Nguyễn Quang Bảy

## NHỮNG ĐIỀU CẦN BIẾT KHI KHÁM CHỮA BỆNH

  * **Thời gian làm việc hành chính** : Sáng 7h30 đến 12h, chiều 13h đến 16h30 từ thứ 2 đến thứ 6. **Cấp cứu** : 24/7.


  * **Khám ngoài giờ:** Hiện nay BV đang triển khai khám ngoài giờ ngày thứ 7 (7h30-15h30), khám ngoài giờ ngày chủ nhật sẽ triển khai sớm nhất trong tương lai gần.


  * **Xét nghiệm theo yêu cầu:** xin xem hướng dẫn [**tại đây**](https://bvnguyentriphuong.com.vn/quy-trinh-kham-benh/huong-dan-dang-ky-xet-nghiem-theo-yeu-cau-tai-bv-nguyen-tri-phuong-tu-16102021) - trong giờ hành chính từ thứ 2-6; riêng thứ 7 từ 7h30-11h30.


  * **Khám, lấy máu, thay băng vết thương tại nhà** có thể tham khảo các gói dịch vụ cụ thể tại trang web bệnh viện ở thanh công cụ (Lưu ý chi phí được thông báo ở đây chưa bao gồm chi phí nhân công vì tùy vị trí thực tế).


​​​​​​​
  * Về **biểu giá viện phí** có thể tham khảo 


  * **Về danh mục kỹ thuật** có thể tham khảo[tại đây](https://bvnguyentriphuong.com.vn/ke-hoach-tong-hop/danh-muc-ky-thuat-benh-vien-nguyen-tri-phuong-2020)


​​​​​​​
  * Trường hợp **đăng ký lịch khám** , vui lòng cài app đặt hẹn GlobeDr (Bác sĩ toàn cầu) và thực hiện đăng ký theo hướng dẫn [tại đây.](https://youtu.be/rVwqvuxtZhQ)


​​​​​​​
  * **Thông tin về mức hưởng bảo hiểm** : về mức hưởng chính xác cần phải gặp trực tiếp nhân viên y tế tại khoa khám bệnh để giải đáp vì liên quan đến mã thẻ và điều kiện chuyển tuyến cũng như kiểm tra tình trạng thẻ trên phần mềm quản lý thẻ BHYT Việt Nam.


​​​​​​​(Cần lưu ý rằng: BHYT không chi trả cho khám sức khoẻ, khám tầm soát mà chi trả cho khám và điều trị bệnh)
​​​​​​​​​​​​​​
  * Các trường hợp cần giải đáp **thắc mắc về thủ tục khám chữa bệnh, khiếu nại về chất lượng dịch vụ** xin vui lòng gửi mail về địa chỉ: hopthu.bvnguyentriphuong@gmail.com (hoặc sử dụng chức năng gửi thư trên website của bệnh viện).


​​​​​​​
  * **Phí khám chữa bệnh dịch vụ** : có nhiều gói khám bệnh dịch vụ, 
    * Cơ bản nhất là 150.000đ trong đó có sử dụng cho cả trường hợp thu phí (đóng 100%) và BHYT (đóng chênh lệch 112.000đ)
    * Gói VIP: được quyền yêu cầu BS khám và được nhân viên chăm sóc khách hàng cùng đi đến các nơi trong quy trình khám
    * Gói cao cấp: bao gồm quyền lợi gói khám VIP cùng dịch vụ thực hiện tại chỗ (như lấy máu, đo điện tim, phát thuốc...)


​​​​​​​​​​​​​​
  * Một số mặt bệnh thường gặp, hướng dẫn quy trình khám có thể tham khảo thêm tư vấn của BS tại [kênh Youtube](https://youtube.com/bvntp) của BV.



## 50% bệnh nhân ung thư đại trực tràng khởi phát sớm có biểu hiện đau bụng và đại tiện ra máu

Trong một đánh giá gần đây được công bố trên JAMA Network Open , các dấu hiệu cảnh báo thường thấy ở những người mắc bệnh ung thư đại trực tràng khởi phát sớm
_**JAMA Network Open, 7(5), e2413157–e2413157.[DOI: 10.1001/jamanetworkopen.2024.13157](https://jamanetwork.com/journals/jamanetworkopen/fullarticle/2819248)**_
Ung thư đại trực tràng khởi phát sớm, được chẩn đoán ở những người dưới 50 tuổi, ở Hoa Kỳ có thể tăng 140% vào năm 2030.
Vì việc chẩn đoán chậm có thể xảy ra do nhiều lý do, như bác sĩ lâm sàng thiếu kiến thức về các triệu chứng ung thư đại trực tràng phổ biến, bệnh nhân xem nhẹ mức độ nghiêm trọng của các triệu chứng hoặc không thể nhận ra các dấu hiệu cảnh báo thường gặp
Nghiên cứu hiện tại xác định các triệu chứng và dấu hiệu xuất hiện phổ biến nhất ở bệnh nhân ung thư đại trực tràng khởi phát sớm và sau đó nhằm mục đích tìm hiểu mối liên quan giữa các triệu chứng và dấu hiệu này với nguy cơ ung thư đại trực tràng khởi phát sớm. Cuối cùng, họ đã điều tra khoảng thời gian từ khi xuất hiện những triệu chứng đầu tiên đến khi chẩn đoán ung thư đại trực tràng khởi phát sớm.
Kết quả chỉ ra rằng hơn 50% bệnh nhân ung thư đại trực tràng khởi phát sớm có biểu hiện đau bụng và đại tiện ra máu, hoặc có máu trong phân và 25% bệnh nhân có thói quen đại tiện thay đổi.
Đại tiện ra máu có liên quan đến nguy cơ mắc ung thư đại trực tràng tăng gấp 5 đến 54 lần, trong khi đau bụng có liên quan đến nguy cơ mắc ung thư đại trực tràng tăng từ 1,3 đến 6 lần. Hơn nữa, khoảng thời gian trì hoãn từ 4 đến 6 tháng kể từ khi xuất hiện một trong các triệu chứng đầu tiên cho đến khi chẩn đoán bệnh là phổ biến.
Trong khi một số nghiên cứu báo cáo rằng những người trẻ tuổi có thời gian chẩn đoán lâu hơn so với bệnh nhân ung thư đại trực tràng ở độ tuổi trung niên

## Các rối loạn tình dục mà nam giới có thể mắc phải

_*** RLTD nam giới được hiểu là tình trạng giao hợp không trọn vẹn, không đạt được những khoái cảm cao nhất.**_
***Các rối loạn thường gặp phải ở nam giới là:**
_Rối loạn cương dương (RLCD)_
- RLCD được định nghĩa là tình trạng không có khả năng đạt được và duy trì độ cương cần thiết để thực hiện giao hợp trọn vẹn. Mặc dù là bệnh lành tính nhưng RLCD gây ảnh hưởng nhiều đến sức khỏe, tâm lý cho người mắc phải. Cũng có nhiều bằng chứng cho thấy RLCD làm gia tăng nguy cơ các bệnh lý tim mạch, mạch máu, não,…
- RLCD có thể xuất phát từ nhiều nguyên nhân: thói quen tiêu khiển như hút thuốc lá, rượu bia, sử dụng nhiều các chất kích thích( ma túy…); ít những hoạt động thể lực; mắc các bệnh lí béo phì, tim mạch, tiểu đường, rối loạn chuyển hóa; từng có phẫu thuật lớn tại khung chậu( cắt toàn bộ tiền liệt tuyến) hoặc xạ trị, chấn thương dương vật hoặc do dùng các loại thuốc trong 1 thời gian dài (huyết áp, chống trầm cảm, loạn thần,..)
_Rối loạn xuất tinh ( RLXT)_
- Xuất tinh là một quá trình sinh lý phức tạp bao gồm 2 pha là bài tiết và phóng tinh được điều hòa bởi phức hợp thần kinh và nội tiết. Tất cả những ảnh hưởng tới cơ chế này đều có thể gây ra tình trạng rối loạn xuất tinh: xuất tinh sớm (XTS), xuất tinh chậm (XTC), xuất tinh máu (XTM), xuất tinh ngược dòng,…
- Hiện tượng XTS là tình trạng nam giới không làm chủ được thời gian xuất tinh, không kìm hãm được khoái cảm, khiến cho việc xuất tinh diễn ra sớm hơn mong đợi- đây là trường hợp RLXT thường gặp nhất. Nguyên nhân là từ các vấn đề về tâm lý - lo lắng về khả năng tình dục hoặc các vấn đề trong mối quan hệ với bạn tình như: sợ người khác biết, sợ có thai, thiếu kinh nghiệm,… hoặc các bệnh lý phối hợp như RLCD, viêm tuyến tiền liệt, cường giáp, bệnh mạn tính liên quan đến suy giảm tình dục. XTS gây cảm giác hụt hẫng, thất vọng cho cả nam giới lẫn bạn tình, tạo nên tâm lý tự ti, né tránh quan hệ tình dục ở nam giới.
- Ngược lại với XTS là hiện tượng XTC hoặc không xuất tinh. Theo hiệp hội Tâm thần Mỹ định nghĩa XTC là tình trạng bao gồm một trong hai triệu chứng sau: tình trạng xuất tinh chậm rõ, rất ít khi hoặc không có khả năng xuất tinh trong 75-100% các lần quan hệ, kéo dài ít nhất 6 tháng và gây nên những lo lắng cho bản thân. Nguyên nhân của XTC có thể là do rối loạn tâm lý, căng thẳng trong mối quan hệ, thiếu kỹ năng tâm lý-tình dục, kiểu thủ dâm; tổn thương thực thể (như tổn thương tủy sống hoặc tổn thương thần kinh lưng dương vật do can thiệp y tế); hoặc do dùng thuốc hạ áp, an thần; viêm nhiễm niệu đạo, tinh hoàn, tiền liệt tuyến.
- XT ra máu là tình trạng có máu trong tinh dịch.Nguyên nhân bao gồm: bất thường do bẩm sinh; tình trạng viêm nhiễm( niệu đạo,tinh hoàn, tiết niệu); bít tắc; các bệnh lý ác tính; dị dạng mạch máu; các chấn thương/tai biến y khoa và các bệnh lý hệ thống( huyết áp, bệnh hemophili, xơ gan, hội chứng chảy máu,..).
- XT ngược dòng: tình trạng hoàn toàn không có hoặc chỉ có một phần tinh dịch được xuất ra ngoài do tinh dịch đi ngược vào trong bàng quang qua cổ bàng quang. Bệnh nhân có thể có cảm giác cực khoái bình thường hoặc giảm. Các nguyên nhân của xuất tinh ngược dòng có thể chia làm nguyên nhân thần kinh; do dùng thuốc; do suy giảm chức năng của niệu đạo hoặc cổ bàng quang.
_Giảm ham muốn tình dục_
- Giảm ham muốn tình dục hay mất ham muốn tình dục là tình trạng giảm cảm hứng, giảm khao khát với các hoạt động tình dục. Tỷ lệ nam giới giảm ham muốn tình dục trên toàn thế giới đang dao động trong mức 3-28%.Tình trạng giảm ham muốn có thể là kết quả của các rối loạn về tâm lý hay sinh lý. Đây là trường hợp có liên quan đến giảm nồng độ hormone testosterone.
- Chứng rối loạn chức năng tình dục này còn bị ảnh hưởng bởi các vấn đề tâm lý như lo âu, trầm cảm; tuổi tác; bệnh tật như đái tháo đường, tăng huyết áp, suy thận, HIV, đột quỵ. Một số thuốc như thuốc chống trầm cảm và một mối quan hệ không suôn sẻ cũng sẽ dẫn đến sự giảm ham muốn trong tình dục của bạn.
**Bạn cần làm gì khi gặp phải các rối loạn tình dục đó?**
Việc chữa trị bằng y học tiên tiến cùng với việc xây dựng một thói quen ăn uống, sinh hoạt lành mạnh sẽ góp phần cải thiện được tình trạng bệnh như :
- Sinh hoạt điều độ, ăn uống khoa học, hạn chế sử dụng rượu bia, thuốc an thần và tuyệt đối không hút thuốc, dùng ma túy.
- Tham gia tập luyện thể dục thể thao thường xuyên, đều đặn mỗi ngày để cơ thể khỏe mạnh hơn.
- Giữ tinh thần lạc quan trong mọi trường hợp, tránh các suy nghĩ tiêu cực, gây buồn phiền,…
- Cởi mở chia sẻ vấn đề mắc phải với bạn đời của mình, với thầy thuốc để có hướng xử trí phù hợp.
Nam giới khi thấy mình có dấu hiệu, triệu chứng rối loạn tình dục nào nên đi khám để chẩn đoán chính xác nhất tình trạng đang mắc phải và có những biện pháp can thiệp kịp thời, không nên chủ quan hoặc ngại thăm khám.

## Chỉ số CAVI là gì ?

Thông qua việc đo huyết áp tứ chi (động mạch cánh tay 2 bên và động mạch chày ở cổ chân 2), tâm thanh đồ, điện tim đồ, từ đó xác định được 2 chỉ số:
– **ABI – Chỉ số cổ chân/ cánh tay** : giúp đánh giá, phát hiện sớm tình trạng hẹp hoặc tắc lòng động mạch nuôi tay và chân.
– **CAVI – Chỉ số tim mạch – cổ chân** : giúp đánh tình trạng xơ vữa gây hẹp hoặc tắc lòng động mạch vành nuôi tim.
Chỉ số CAVI giúp bác sỹ xác định tình trạng xơ cứng/xơ vữa động mạch từ đó ước tính được **“tuổi động mạch”** của người bệnh một cách chính xác nhất. Nếu tuổi động mạch của bạn cao hơn tuổi thật, điều đó có nghĩa là tình trạng xơ vữa động mạch của bạn đang tiến triển nhanh và có thể gây ra các biến cố ở tim – mạch máu cho bạn sớm hơn. Phương pháp này đặc biệt hữu ích, hiệu quả giúp chẩn đoán bệnh tắc nghẽn mạch vành ở những người bệnh cao tuổi không thể thực hiện nghiệm pháp gắng sức điện tâm đồ cũng như không thể chụp mạch vành do dị ứng/ nguy cơ dị ứng với thuốc cản quang. 
**Các đối tượng nguy cơ cao cần được đo xơ vữa động mạch**
  * Tuổi cao: tỷ lệ người mắc bệnh xơ vữa động mạch tăng lên theo độ tuổi, đặc biệt ở nhóm**≥****65 tuổi**
  * **50 – 64 tuổi** , có**ít nhất 1 yếu tố nguy cơ** như: tăng huyết áp, đái tháo đường, tăng lipid máu (mỡ máu cao), hút thuốc lá.
  * **Người bệnh đái tháo đường dưới** **50 tuổi** có kèm theo **ít nhất 1 yếu tố nguy cơ** như: tăng huyết áp, tăng lipid máu (mỡ máu cao), hút thuốc lá, bị đái tháo đường trên 10 năm.
  * Có triệu chứng đau, mỏi, chuột rút ở bàn chân/bắp chân/đùi/mông, khởi phát khi đi lại và giảm dần khi nghỉ ngơi (trong vòng vài phút) hoặc người bệnh đau chân cả khi nghỉ ngơi.
  * Người bệnh có **vết loét, vết thương, hoại tử ở chi dưới lâu liền**.
  * Có bệnh lý mạch máu do xơ vữa khác: Bệnh mạch vành, bệnh mạch não, mạch thận.
  * Theo dõi sau can thiệp mạch hoặc phẫu thuật bắc cầu nối động mạch chi dưới.


### **Chỉ số CAVI và các yếu tố nguy cơ tim mạch khác**
**_* Đái tháo đường_**
Các nghiên cứu nhận thấy CAVI cao hơn khi bệnh nhân có đái tháo đường. Phần lớn các nghiên cứu nhận thấy rằng đái tháo đường là một yếu tố mạnh mẽ làm tăng CAVI ở những người có tuổi.
Các nghiên cứu gần đây chứng minh liệu pháp Insulin làm giảm CAVI trong khi làm giảm mức glucose máu. Nagayama và cộng sự nhận thấy Glimepiride làm giảm CAVI theo sau tác dụng hạ mức glucose máu. Ohira và cộng sự thấy rằng tiêm Insulin cũng làm giảm CAVI đi cùng với giảm mức glucose máu. Những quan sát lâm sàng đó đã gợi ý rằng CAVI là một chỉ số sinh lí học nhạy cảm để theo dõi áp lực lên thành động mạch của mức glucose máu cao, có thể do nhiễm độc glucose. Mức glucose máu cao có thể điều chỉnh thành động mạch tăng độ cứng trong một thời gian tương đối ngắn, kết quả là làm tăng CAVI. Sự gia tăng này có thể đảo ngược, bởi vì việc kiểm soát mức glucose máu làm giảm CAVI trong một khoảng thời gian khá nhanh. Các nghiên cứu sâu hơn cần được tiến hành để làm sáng tỏ cơ chế rằng mức glucose cao hay nhiễm độc glucose thúc đẩy xơ cứng động mạch.
**_* Rối loạn chuyển hóa lipid máu_**
CAVI và rối loạn lipid máu không có mối tương quan chặt chẽ; tuy nhiên, Takaki thấy CAVI liên quan với mức LDL-Cholesterol cũng như tỉ lệ Cholesterol/HDL-Cholesterol. Tăng lipid máu tự nó không tức thì làm tăng
ĐCĐM. Sau khi tích lũy cholesterol trong các bể chứa, quá trình oxy hóa sinh ra các oxysterol là các chất có độc tính cao và thúc đẩy phản ứng viêm, theo sau bởi sự tấn công của xơ vữa động mạch; do đó, CAVI có thể tăng trong điều kiện tăng lipid đó.
Ảnh hưởng của các tác nhân làm giảm lipid máu đã được nghiên cứu. Miyashita và cộng sự thấy điều trị Pitavastatin làm giảm CAVI sau 1 năm. Eicosapentaenoic acid làm giảm CAVI liên quan với giảm amyloid A-LDL trong huyết thanh ở bệnh nhân có hội chứng chuyển hóa. Đơn liệu pháp Ezetimibe làm giảm CAVI ở bệnh nhân đái tháo đường type 2. Việc cải thiện độ cứng thành động mạch ảnh hưởng bởi tác nhân làm giảm lipid có thể vì một vài điều chỉnh chức năng thêm vào những biến đổi mô bệnh học của tổ chức .
**_* Hội chứng chuyển hóa, béo phì và giảm cân_**
Hội chứng chuyển hóa phổ biến khắp thế giới. sự tích tụ mỡ tạng đã dẫn tới làm rối loạn dung nạp glucose, tăng huyết áp và rối loạn lipid máu. Những điều kiện đó được cho là gây ra tăng đề kháng Insulin. CAVI cao có liên quan với béo phì và hội chứng chuyển hóa. Adiponectin, chất liên quan đến độ nhạy cảm của Insulin và được xem là một dấu ấn sinh học của hội chứng chuyển hóa, tương quan nghịch với CAVI. Những kết quả trên chỉ ra rằng CAVI có thể là một dấu ấn tốt của bệnh mạch máu lớn trong hội chứng chuyển hóa, là bởi có một vài dấu hiệu và triệu chứng khởi phát.
Giảm cân có tác dụng cải thiện hội chứng chuyển hóa và Satoh cùng cộng sự đã nhận thấy giảm cân nhờ chế độ ăn kiêng và luyện tập trong khoảng 3 tháng làm giảm dáng kể CAVI song song với tăng mức Adiponectin. CAVI có thể hữu ích để đánh giá và quản lí các yếu tố nguy cơ tim mạch ở những bệnh nhân có hội chứng chuyển hóa .
Kuzobuno và cộng sự thấy CAVI tăng cao ở những người hút thuốc[19]. Theo Noike và cộng sự, hút thuốc làm tăng CAVI nhưng điều thú vị là CAVI giảm sau khi ngừng hút thuốc. Sự đảo ngược của CAVI có thể ngụ ý rằng hút thuốc làm co các tế bào cơ trơn thành động mạch. CAVI có thể là một chỉ thị tốt để gia tăng động cơ cho những người đang có bỏ hút thuốc.
_*** Cavi và bệnh lí viêm mạch**_
Bệnh lí viêm của thành động mạch được biết là có liên quan với xơ vữa động mạch. Các nghiên cứu gần đây cho thấy CAVI tăng cao ở những bệnh nhân Lupus ban đỏ hệ thống, hội chứng viêm động mạch chủ và sự tăng CAVI đó được làm giảm bằng liệu pháp miễn dịch. Những kết quả đó chỉ ra rằng CAVI phản ánh sự có mặt của một phản ứng viêm của các động mạch trong toàn cơ thể. Cơ chế của hiện tượng này hiện chưa rõ. Các Cytokine của phản ứng viêm sinh ra trong thành động mạch kích thích co cơ trơn và tái cấu trúc thành mạch, tuy nhiên, điều này cần được nghiên cứu thêm. Wakabayashi và cộng sự thấy CAVI liên quan với các chất phản ứng giai đoạn cấp như Protein C phản ứng, Protein Amyloid A, sialic acid, fibrinogen và bạch cầu trong đái tháo đường type 2.

## Tập thể dục trước và sau bữa ăn một khoảng thời gian nhất định: hiệu quả hạn chế tình trạng đường huyết biến động

Trong một nghiên cứu vừa công bố trên tạp chí khoa học Nutrients, các tác giả từ Đại học Foro Italico ở Rome - Ý chỉ ra tập thể dục trước và sau bữa ăn một khoảng thời gian nhất định sẽ rất hiệu quả để hạn chế tình trạng đường huyết biến động.
Điều này đặc biệt quan trọng đối với bệnh nhân tiểu đường type 2, một vấn đề đang ảnh hưởng đến 463 triệu người trưởng thành toàn cầu, theo thống kê từ Tổ chức Y tế Thế giới (WHO) vào năm 2021.
Theo các tác giả, tập thể dục cải thiện lưu lượng máu trong các cơ hoạt động và huy động vi mạch, do đó làm tăng sự hấp thu glucose và giảm mức độ của nó trong máu.
Tuy nhiên, tình trạng dinh dưỡng tại thời điểm tập luyện là yếu tố quyết định sự biến động của lượng đường trong máu.
Hiệu quả của việc tập thể dục, đặc biệt là khi thực hiện 12-16 giờ trước khi ăn, sẽ ít hơn đáng kể đối với việc kiểm soát đường huyết cấp tính.
Vì vậy, tập thể dục nhịp điệu hoặc tập sức đề kháng cường độ vừa phải 20-45 phút trước bữa ăn là tốt nhất ngừa tăng đường huyết quá cao sau bữa ăn.
Tập thể dục trước bữa ăn gây ra sự nhạy cảm với insulin và quá trình oxy hóa chất béo bằng cách thúc đẩy quá trình phân giải glycogen, sau đó ổn định lượng đường trong máu và ngăn ngừa được hạ đường huyết mà người mắc tiểu đường cũng thường gặp.
Ít phút đi bộ với cường độ vừa phải hay đạp xe vào thời điểm khoảng 15-30 phút sau khi ăn rất có lợi với người bệnh tiểu đường lẫn người khỏe mạnh.
Như vậy, tập thể dục vào bất cứ thời điểm nào tương đối gần bữa ăn đều đem lại lợi ích tốt hơn cho người bệnh tiểu đường.
Cũng theo phân tích mới này, các buổi tập nên kéo dài khoảng 30-60 phút để đạt được hiệu quả.

## Vì sao chỉ có 7 đốt sống cổ nhưng có đến 8 đoạn tủy cổ?

Thực tế là có 7 đốt sống cổ nhưng có 8 đoạn tủy cổ. Điều này xảy ra vì tủy sống không kết thúc ở cùng một đốt sống nhưng bắt đầu từ một đốt sống cổ và kéo dài xuống đến đốt sống thứ 2 của xương sườn. Đây được gọi là đoạn tủy cổ đặc biệt và được gọi là đoạn tủy cổ thứ 1 hoặc đoạn tủy cổ C1. Sau đó, đoạn tủy cổ tiếp theo bắt đầu từ đốt sống cổ thứ 2 và kéo dài đến đốt sống cổ thứ 3, và vẫn tiếp tục xuống như vậy.
Lý do cho sự khác biệt này là do sự phát triển của tủy sống và đốt sống cổ trong quá trình hình thành bào thai. Khi tủy sống phát triển, nó kéo dài hơn so với đốt sống cổ, vì vậy nó phải "chồng" lên đoạn tủy cổ C1. Việc này làm cho việc xác định đoạn tủy cổ và vị trí của chúng trở nên khó khăn hơn so với các đoạn tủy ở phần khác của cột sống.
Đoạn tủy cổ đặc biệt này là một điểm quan trọng trong hệ thần kinh vì nó chứa nhiều thần kinh quan trọng điều khiển các cơ và các cơ quan trong đầu và cổ. Một số bệnh lý ở khu vực này có thể gây ra các triệu chứng như đau đầu, đau cổ, hoặc khó thở.
## Cấu tạo của tủy sống như thế nào?
Tủy sống được bao bọc trong ba lớp màng.
  * Màng ngoài gọi là màng cứng, màng giữa gọi là màng nhện, màng trong gọi là màng nuôi. Màng cứng rất chắc giúp bảo vệ tủy sống khỏi những va chạm với xương.
  * Ở giữa là màng nhện, mỏng và đàn hồi, chứa nhiều hệ thống mạch máu của tủy sống.
  * Màng nuôi ở trong cùng (còn gọi là màng não – tuỷ), mềm, dính chặt vào tuỷ sống, có nhiệm vụ nuôi dưỡng mô tuỷ sống.


Cắt ngang tủy sống, cấu tạo tủy sống có 3 phần:
  * Màng tuỷ sống bao bọc phía ngoài.
  * Phần chất xám và phần chất trắng.
  * Ở giữa có một lỗ nhỏ là ống tủy sống.


Tủy sống có 31 đôi dây thần kinh tủy. Mỗi dây thần kinh tủy bao gồm các nhóm sợi thần kinh cảm giác, được nối với tủy sống qua rễ cảm giác và nhóm thần kinh vận động được nối với các rễ vận động.

## Hướng dẫn cách dễ ngủ nhanh, ngon và sâu giấc

  * [1. Tạo thói quen ngủ đúng giờ](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/huong-dan-cach-de-ngu-nhanh-ngon-va-sau-giac#1-to-thi-quen-ng-ng-gi)
  * [3. Tránh sử dụng thiết bị điện tử trước khi ngủ](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/huong-dan-cach-de-ngu-nhanh-ngon-va-sau-giac#3-trnh-s-dng-thit-b-in-t-trc-khi-ng)
  * [4. Tránh ngủ trưa quá nhiều](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/huong-dan-cach-de-ngu-nhanh-ngon-va-sau-giac#4-trnh-ng-tra-qu-nhiu)
  * [5. Luyện tập thể dục trong ngày](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/huong-dan-cach-de-ngu-nhanh-ngon-va-sau-giac#5-luyn-tp-th-dc-trong-ngy)
  * [6. Đọc sách trước khi ngủ](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/huong-dan-cach-de-ngu-nhanh-ngon-va-sau-giac#6-c-sch-trc-khi-ng)
  * [7. Tránh thực phẩm giàu caffeine vào buổi tối](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/huong-dan-cach-de-ngu-nhanh-ngon-va-sau-giac#7-trnh-thc-phm-giu-caffeine-vo-bui-ti)
  * [8. Tập yoga và thiền](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/huong-dan-cach-de-ngu-nhanh-ngon-va-sau-giac#8-tp-yoga-v-thin)
  * [10. Thay đổi thói quen ăn uống](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/huong-dan-cach-de-ngu-nhanh-ngon-va-sau-giac#10-thay-i-thi-quen-n-ung)
  * [11. Điều chỉnh nhiệt độ phòng phù hợp](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/huong-dan-cach-de-ngu-nhanh-ngon-va-sau-giac#11-iu-chnh-nhit-phng-ph-hp)
  * [12. Thử dùng tinh dầu hoa oải hương](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/huong-dan-cach-de-ngu-nhanh-ngon-va-sau-giac#12-th-dng-tinh-du-hoa-oi-hng)
  * [13. Tìm tư thế ngủ thoải mái](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/huong-dan-cach-de-ngu-nhanh-ngon-va-sau-giac#13-tm-t-th-ng-thoi-mi)
  * [14. Nghe nhạc thư giãn](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/huong-dan-cach-de-ngu-nhanh-ngon-va-sau-giac#14-nghe-nhc-th-gin)
  * [15. Thử phương pháp thở 4-7-8](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/huong-dan-cach-de-ngu-nhanh-ngon-va-sau-giac#15-th-phng-php-th-478)
  * [16. Tắm nước ấm](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/huong-dan-cach-de-ngu-nhanh-ngon-va-sau-giac#16-tm-nc-m)
  * [17. Hạn chế uống nhiều nước trước khi đi ngủ](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/huong-dan-cach-de-ngu-nhanh-ngon-va-sau-giac#17-hn-ch-ung-nhiu-nc-trc-khi-i-ng)
  * [18. Uống melatonin hoặc thực phẩm chức năng chứa melatonin](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/huong-dan-cach-de-ngu-nhanh-ngon-va-sau-giac#18-ung-melatonin-hoc-thc-phm-chc-nng-cha-melatonin)
  * [19. Chọn chăn ga gối đệm thoải mái](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/huong-dan-cach-de-ngu-nhanh-ngon-va-sau-giac#19-chn-chn-ga-gi-m-thoi-mi)
  * [20. Tránh môi trường ồn ào](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/huong-dan-cach-de-ngu-nhanh-ngon-va-sau-giac#20-trnh-mi-trng-n-o)
  * [21. Tránh uống quá nhiều rượu ](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/huong-dan-cach-de-ngu-nhanh-ngon-va-sau-giac#21-trnh-ung-qu-nhiu-ru)
  * [22. Đừng suy nghĩ quá nhiều hay cố gắng ngủ](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/huong-dan-cach-de-ngu-nhanh-ngon-va-sau-giac#22-ng-suy-ngh-qu-nhiu-hay-c-gng-ng)


### **1. Tạo thói quen ngủ đúng giờ**
Khi bạn ngủ vào một thời điểm nhất định hàng ngày, não bộ sẽ “học” được thời điểm thích hợp để giải phóng hormone ngủ, như melatonin, giúp bạn dễ dàng chìm vào giấc ngủ và xây dựng được một chu kỳ sinh học ổn định.
Đây không chỉ là **cách dễ ngủ** dành cho người bình thường mà còn là phương pháp hữu hiệu trong việc hỗ trợ người bệnh điều trị chứng mất ngủ (insomnia).
### **2. Tắt đèn**
Ánh sáng, đặc biệt là ánh sáng xanh từ đèn huỳnh quang, có thể ức chế sự sản sinh melatonin, hóc-môn điều hòa chu kỳ ngủ – thức, khiến cơ thể khó rơi vào trạng thái ngủ.
Ngược lại, tắt đèn là  _cách để dễ ngủ_ bởi bóng tối có thể kích thích não bộ sản xuất ra melatonin một cách tự nhiên, giúp bạn chìm vào giấc ngủ dễ dàng hơn.
### **3. Tránh sử dụng thiết bị điện tử trước khi ngủ**
Tương tự như ánh sáng xanh từ đèn huỳnh quang, ánh sáng xanh đến từ màn hình thiết bị điện tử (điện thoại, TV, máy tính bảng,…) cũng có thể gây mất ngủ.
Nguyên nhân là vì bước sóng của ánh sáng xanh có thể “đánh lừa” não bộ, khiến hệ thần kinh nghĩ rằng bạn vẫn còn sinh hoạt trong môi trường ban ngày (có ánh sáng xanh từ ánh nắng mặt trời), nên không tiết ra melatonin để khiến bạn cảm thấy buồn ngủ.
Vì vậy, tránh sử dụng thiết bị điện tử trước khi ngủ là **cách dễ ngủ** được nhiều chuyên gia thần kinh khuyến nghị, đặc biệt là đối với người cao tuổi gặp tình trạng mất ngủ kéo dài.
### **4. Tránh ngủ trưa quá nhiều**
Ngủ trưa quá lâu làm giảm hoặc làm mất đi cảm giác buồn ngủ tự nhiên vào buổi tối, từ đó dẫn đến tình trạng mất ngủ. Theo [Hiệp hội Giấc ngủ Hoa Kỳ](https://www.sleepfoundation.org/sleep-hygiene/napping), một giấc ngủ trưa tối ưu chỉ nên kéo dài từ 20 – 30 phút.
Ngủ trưa, dù chỉ kéo dài trong 10 phút, cũng có thể giúp cải thiện tâm lý, giảm căng thẳng, tăng cường sự tỉnh táo và khả năng học tập. Ngược lại, một giấc ngủ trưa dài hơn 30 phút thường dễ khiến bạn cảm thấy quá choáng váng khi thức dậy.
Vì vậy, bạn không cần nhất thiết phải ngủ trưa quá lâu. Hạn chế thời gian ngủ trưa mới chính là  _cách ngủ nhanh_ , giúp bạn ngủ sâu giấc hơn vào buổi tối.
### **5. Luyện tập thể dục trong ngày**
Khi tập thể dục, cơ thể sản sinh endorphin, một loại hóc-môn giúp cải thiện tâm trạng, khiến não bộ cảm thấy thư giãn. Mặt khác, hoạt động thể chất cũng giúp bạn tăng cường sự mệt mỏi về mặt thể chất, làm cho cơ thể dễ dàng chìm vào giấc ngủ hơn khi đêm về.
Do đó, luyện tập thể dục trong ngày chính là **cách dễ ngủ** được nhiều người ưa thích và áp dụng. Tuy nhiên, bạn cần lưu ý, không nên luyện tập thể dục trong vòng 4 giờ trước khi ngủ, bởi tình trạng não bộ tỉnh táo quá mức sau khi vận động có thể khiến bạn bị mất ngủ.
### **6. Đọc sách trước khi ngủ**
Đọc sách là  _mẹo dễ ngủ_ được nhiều người áp dụng thành công bởi hoạt động này tạo ra một “hành trình tâm lý” nhẹ nhàng, giúp não bộ giảm bớt được những suy nghĩ và lo lắng thường nhật, từ đó dễ dàng chuyển từ trạng thái tỉnh táo sang trạng thái thư giãn và chìm vào giấc ngủ sâu.
### **7. Tránh thực phẩm giàu caffeine vào buổi tối**
Caffeine là chất kích thích hệ thần kinh, có thể ức chế các thụ thể adenosine trong não tổng hợp ra hóc-môn melatonin, khiến bạn tỉnh táo quá mức và ngăn cơn buồn ngủ ập đến.
Vì vậy, hạn chế tiêu thụ thực phẩm giàu caffeine vào buổi tối, chẳng hạn như trà, cà phê, ca cao,… là **cách dễ ngủ** được nhiều chuyên gia khuyến nghị.
### **8. Tập yoga và thiền**
Tập yoga và thiền là **cách dễ ngủ** được nhiều người ưa thích bởi chúng có tác dụng làm giảm căng thẳng, thư giãn tâm trí và cơ thể. Cả hai hoạt động này thúc đẩy não bộ tập trung vào hơi thở, giảm bớt tình trạng suy nghĩ quá mức, từ đó tạo ra một trạng thái tinh thần an bình, giúp bạn dễ dàng chìm sâu vào giấc ngủ.
### **9. Thử massage**
Massage là  _cách để ngủ nhanh_ vì hoạt động này kích thích cơ thể giải phóng serotonin, một loại hormone khiến chúng ta cảm thấy dễ chịu và an bình. Serotonin cũng là tiền thân của melatonin, một loại hóc-môn trực tiếp tạo nên cảm giác buồn ngủ, hỗ trợ điều trị bệnh mất ngủ một cách hiệu quả.
### **10. Thay đổi thói quen ăn uống**
Ăn uống quá no, ăn quá sát giờ ngủ hoặc ăn quá nhiều dầu mỡ, chất kích thích trước khi ngủ,… đều là những thói quen ăn uống có thể gây nên các vấn đề rối loạn tiêu hóa (đầy hơi, trào ngược thực quản,…) khiến bạn dễ bị mất ngủ.
Ngược lại, ăn uống vừa phải, hạn chế tiêu thụ thực phẩm chứa chất kích thích (cồn, caffeine,…) trước khi ngủ có thể giúp bạn tránh gặp phải vấn đề tiêu hóa, từ đó giảm cảm giác khó chịu và thức giấc trong đêm.
Mặt khác, tăng cường tiêu thụ thực phẩm giàu tryptophan vào ban ngày, chẳng hạn như sữa, chuối, các loại đậu, hạt,… được [chứng minh](https://pubmed.ncbi.nlm.nih.gov/25407790/) là có khả năng cải thiện khả năng sản xuất melatonin của não bộ vào ban đêm, giúp bạn chìm vào giấc ngủ dễ dàng hơn.
Vì vậy, thay đổi thói quen ăn uống cũng là **cách dễ ngủ** được nhiều chuyên gia dinh dưỡng khuyến nghị.
### **11. Điều chỉnh nhiệt độ phòng phù hợp**
Điều chỉnh nhiệt độ phòng phù hợp trước khi ngủ là  _cách để ngủ nhanh_ bởi cơ thể con người thường cảm thấy dễ chịu hơn trong môi trường mát mẻ, giúp não bộ cảm thấy thư giãn, từ đó thúc đẩy giấc ngủ sâu và liên tục.
### **12. Thử dùng tinh dầu hoa oải hương**
Sử dụng tinh dầu hoa oải hương được [chứng minh](https://www.sciencedirect.com/science/article/pii/S0965229922000346) là **cách dễ ngủ** có cơ chế hoạt động tương tự như việc dùng benzodiazepines, một dòng thuốc điều trị mất ngủ phổ biến hiện nay.
Cụ thể, chiết xuất từ tinh dầu hoa oải hương chứa nhiều hợp chất flavonoids, có thể lên các thụ thể benzodiazepine; từ đó, làm tăng nồng độ axit gamma-aminobutyric (GABA) trong não bộ, đặc biệt là ở vùng hạch hạnh nhân và hồi hải mã.
GABA là một chất ức chế thần kinh, tức chúng có thể làm giảm khả năng tế bào thần kinh tiếp nhận, tạo hoặc gửi thông điệp hóa học đến các tế bào thần kinh khác; từ đó, đem lại tác dụng “xoa dịu”, an thần và thư giãn.
Nhờ đó, ngửi hoặc xông tinh dầu hoa oải hương trước khi ngủ có thể giúp bạn cảm thấy an bình và dễ dàng chìm sâu vào giấc ngủ.
### **13. Tìm tư thế ngủ thoải mái**
Tìm một tư thế ngủ thoải mái giúp giảm căng thẳng và áp lực lên cơ thể, từ đó tạo điều kiện thuận lợi cho giấc ngủ. Khi cơ thể cảm thấy thoải mái và không bị đau nhức, não bộ cũng sẽ dễ dàng chuyển sang trạng thái thư giãn, hỗ trợ cải thiện tình trạng mất ngủ.
### **14. Nghe nhạc thư giãn**
Nghe nhạc thư giãn là  _cách ngủ nhanh_ được nhiều chuyên gia tại [Hiệp hội Giấc ngủ Hoa Kỳ](https://www.sleepfoundation.org/noise-and-sleep/music) khuyến cáo. Nguyên nhân là vì khi căng thẳng, cơ thể giải phòng nhiều hóc-môn cortisol. Nồng độ cortisol tăng cao có thể khiến não bộ tỉnh táo quá mức và dẫn đến tình trạng mất ngủ.
Trong khi đó, [nghiên cứu](https://pubmed.ncbi.nlm.nih.gov/21716581/) lại cho thấy, nghe nhạc có thể giúp bạn điều hòa lại nồng độ hóc-môn cortisol; từ đó, hỗ trợ cải thiện tình trạng mất ngủ một cách hiệu quả.
### **15. Thử phương pháp thở 4-7-8**
Tập thở theo phương pháp 4-7-8 là  _cách ngủ nhanh_ rất dễ để thực hiện. Đầu tiên, bạn cần hít vào bằng mũi (vừa hít vào vừa đếm đến 4); sau đó, giữ hơi thở (đếm đến 7) rồi thở ra thật chậm rãi bằng đường miệng (đếm đến 8).
Lặp lại kỹ thuật này nhiều lần trước khi ngủ giúp làm chậm nhịp tim, giảm căng thẳng và thúc đẩy sự thư giãn, tạo điều kiện cho cơ thể chuyển sang trạng thái ngủ một cách dễ dàng.
### **16. Tắm nước ấm**
[Nghiên cứu](https://www.ncbi.nlm.nih.gov/search/research-news/3495/) cho thấy, tắm nước ấm 1 – 2 giờ trước khi đi ngủ có thể giúp bạn thư giãn và chìm vào giấc ngủ nhanh hơn. Nguyên nhân là vì tắm nước ấm trước khi ngủ giúp cơ thể thả lỏng, giảm căng thẳng và cải thiện lưu thông máu.
Mặt khác, sau khi bước ra khỏi phòng tắm, sự chênh lệch nhiệt độ tạo ra cảm giác mát mẻ, sảng khoái, thúc đẩy não bộ thư giãn, chuẩn bị sẵn sàng cho giấc ngủ, từ đó hỗ trợ cải thiện chứng mất ngủ.
### **17. Hạn chế uống nhiều nước trước khi đi ngủ**
Hạn chế uống nước trước khi ngủ giúp làm giảm nguy cơ thức giấc giữa đêm để đi tiểu, từ đó duy trì giấc ngủ liên tục và sâu hơn. Điều này hỗ trợ cải thiện chất lượng ngủ và giảm tình trạng mất ngủ.
### **18. Uống melatonin hoặc thực phẩm chức năng chứa melatonin**
Melatonin là một loại hóc-môn được sản xuất bởi tuyến tùng trong não bộ, giúp điều chỉnh chu kỳ ngủ – thức tự nhiên của cơ thể.
Vì vậy, bổ sung melatonin từ những nguồn ngoại sinh như thực phẩm chức năng có thể hỗ trợ cải thiện chu kỳ ngủ, đặc biệt hiệu quả cho những người có tiền sử bị rối loạn giấc ngủ do chênh lệch múi giờ.
Tuy nhiên, việc sử dụng melatonin nên dựa trên sự tư vấn và chỉ định từ bác sĩ để đảm bảo an toàn và hiệu quả.
### **19. Chọn chăn ga gối đệm thoải mái**
Chọn chăn ga gối đệm thoải mái là **cách dễ ngủ** vì chúng tạo nền tảng vững chắc cho một giấc ngủ chất lượng. Cụ thể, độ mềm của đệm (nệm) giúp giảm áp lực lên cơ thể, còn độ mịn của chăn ga giúp gia tăng cảm giác thoải mái.
Mặt khác, việc lựa chọn chất liệu chăn ga thoáng mát như vải cotton, lụa phi bóng, lụa Tencel,… còn giúp duy trì nhiệt độ cơ thể lý tưởng, hỗ trợ chu kỳ ngủ sâu hơn và không bị gián đoạn.
### **20. Tránh môi trường ồn ào**
Tránh môi trường ồn ào trước và trong khi ngủ là **cách dễ ngủ** vì chúng giúp ngăn chặn sự kích thích không cần thiết đối với não bộ, giúp não bộ bớt căng thẳng,duy trì được giấc ngủ sâu và hỗ trợ cải thiện tình trạng mất ngủ.
### **21. Tránh uống quá nhiều rượu**
Uống quá nhiều rượu có thể làm gián đoạn giấc ngủ, đặc biệt ảnh hưởng đến pha REM – pha chuyển động mắt nhanh, có vai trò quan trọng trong việc phục hồi trí nhớ và giải tỏa cảm xúc.
Vì vậy, tránh rượu bia chính là  _cách ngủ ngon_ vì chúng giúp duy trì giấc ngủ sâu hơn, từ đó hỗ trợ cải thiện tình trạng mất ngủ và nâng cao chất lượng sức khỏe tổng thể.
### **22. Đừng suy nghĩ quá nhiều hay cố gắng ngủ**
Suy nghĩ quá nhiều hay cố gắng ngủ có thể tạo áp lực tâm lý, làm tăng căng thẳng và lo âu, ngăn cản việc chìm vào giấc ngủ tự nhiên. Ngược lại, việc giữ tâm trí thoải mái giúp cơ thể thư giãn, dễ dàng chuyển sang trạng thái ngủ một cách tự nhiên mà không cần gắng sức.
  * [1. Tạo thói quen ngủ đúng giờ](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/huong-dan-cach-de-ngu-nhanh-ngon-va-sau-giac#1-to-thi-quen-ng-ng-gi)
  * [3. Tránh sử dụng thiết bị điện tử trước khi ngủ](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/huong-dan-cach-de-ngu-nhanh-ngon-va-sau-giac#3-trnh-s-dng-thit-b-in-t-trc-khi-ng)
  * [4. Tránh ngủ trưa quá nhiều](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/huong-dan-cach-de-ngu-nhanh-ngon-va-sau-giac#4-trnh-ng-tra-qu-nhiu)
  * [5. Luyện tập thể dục trong ngày](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/huong-dan-cach-de-ngu-nhanh-ngon-va-sau-giac#5-luyn-tp-th-dc-trong-ngy)
  * [6. Đọc sách trước khi ngủ](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/huong-dan-cach-de-ngu-nhanh-ngon-va-sau-giac#6-c-sch-trc-khi-ng)
  * [7. Tránh thực phẩm giàu caffeine vào buổi tối](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/huong-dan-cach-de-ngu-nhanh-ngon-va-sau-giac#7-trnh-thc-phm-giu-caffeine-vo-bui-ti)
  * [8. Tập yoga và thiền](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/huong-dan-cach-de-ngu-nhanh-ngon-va-sau-giac#8-tp-yoga-v-thin)
  * [10. Thay đổi thói quen ăn uống](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/huong-dan-cach-de-ngu-nhanh-ngon-va-sau-giac#10-thay-i-thi-quen-n-ung)
  * [11. Điều chỉnh nhiệt độ phòng phù hợp](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/huong-dan-cach-de-ngu-nhanh-ngon-va-sau-giac#11-iu-chnh-nhit-phng-ph-hp)
  * [12. Thử dùng tinh dầu hoa oải hương](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/huong-dan-cach-de-ngu-nhanh-ngon-va-sau-giac#12-th-dng-tinh-du-hoa-oi-hng)
  * [13. Tìm tư thế ngủ thoải mái](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/huong-dan-cach-de-ngu-nhanh-ngon-va-sau-giac#13-tm-t-th-ng-thoi-mi)
  * [14. Nghe nhạc thư giãn](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/huong-dan-cach-de-ngu-nhanh-ngon-va-sau-giac#14-nghe-nhc-th-gin)
  * [15. Thử phương pháp thở 4-7-8](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/huong-dan-cach-de-ngu-nhanh-ngon-va-sau-giac#15-th-phng-php-th-478)
  * [16. Tắm nước ấm](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/huong-dan-cach-de-ngu-nhanh-ngon-va-sau-giac#16-tm-nc-m)
  * [17. Hạn chế uống nhiều nước trước khi đi ngủ](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/huong-dan-cach-de-ngu-nhanh-ngon-va-sau-giac#17-hn-ch-ung-nhiu-nc-trc-khi-i-ng)
  * [18. Uống melatonin hoặc thực phẩm chức năng chứa melatonin](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/huong-dan-cach-de-ngu-nhanh-ngon-va-sau-giac#18-ung-melatonin-hoc-thc-phm-chc-nng-cha-melatonin)
  * [19. Chọn chăn ga gối đệm thoải mái](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/huong-dan-cach-de-ngu-nhanh-ngon-va-sau-giac#19-chn-chn-ga-gi-m-thoi-mi)
  * [20. Tránh môi trường ồn ào](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/huong-dan-cach-de-ngu-nhanh-ngon-va-sau-giac#20-trnh-mi-trng-n-o)
  * [21. Tránh uống quá nhiều rượu ](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/huong-dan-cach-de-ngu-nhanh-ngon-va-sau-giac#21-trnh-ung-qu-nhiu-ru)
  * [22. Đừng suy nghĩ quá nhiều hay cố gắng ngủ](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/huong-dan-cach-de-ngu-nhanh-ngon-va-sau-giac#22-ng-suy-ngh-qu-nhiu-hay-c-gng-ng)



## Kỹ thuật phẫu thuật đặt điện cực kích thích não sâu, 'Cánh cửa mới' cho bệnh nhân Parkinson ở Việt Nam

  * [Đàn hát sau điều trị Parkinson](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/ky-thuat-phau-thuat-dat-dien-cuc-kich-thich-nao-sau-canh-cua-moi-cho-benh-nhan-parkinson-o-viet-nam#n-ht-sau-iu-tr-parkinson)
  * [Không cần điều trị ở nước ngoài](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/ky-thuat-phau-thuat-dat-dien-cuc-kich-thich-nao-sau-canh-cua-moi-cho-benh-nhan-parkinson-o-viet-nam#khng-cn-iu-tr-nc-ngoi)


## **Đàn hát sau điều trị Parkinson**
Sau nhiều lần hội chẩn, các bác sĩ BV Nguyễn Tri Phương quyết định điều trị căn bệnh Parkinson của ông L bằng kỹ thuật phẫu thuật đặt điện cực kích thích não sâu.
Sau phẫu thuật, các triệu chứng như run, chậm chạp và cứng đờ của ông L cải thiện rất tốt. Hiện ông L có thể tự làm những công việc hằng ngày.
“Tôi rất thích đàn hát nhung phải bỏ dở môn nghệ thuật này do mang trong người căn bệnh Parkinson quái ác. Nay thì tôi có thể vừa hát vừa đàn để thỏa mãn niềm đam mê” - ông L chia sẻ.
_Các bác sĩ đang điều trị cho bệnh nhân Parkinson bằng kỹ thuật đặt điện cực kích thích não sâu._
## **Không cần điều trị ở nước ngoài**
Kỹ thuật phẫu thuật đặt điện cực kích thích não sâu đã chứng minh được hiệu quả trị liệu cho bệnh nhân Parkinson. Kỹ thuật này cũng ghi nhận hầu như không có các biến chứng phẫu thuật, không có những tác dụng phụ khi kích thích điện.
Theo TS-BS Phạm Anh Tuấn, Trưởng bộ môn Ngoại thần kinh, khoa Y Trường ĐH Y Dược TP.HCM kiêm Trưởng khoa Ngoại thần kinh BV Nguyễn Tri Phương, ông L không phải trường hợp duy nhất được điều trị khỏi căn bệnh Parkinson bằng kỹ thuật phẫu thuật đặt điện cực kích thích não sâu. Từ năm 2012 đến nay, tổng cộng 115 bệnh nhân Parkinson đã được điều trị thành công bằng kỹ thuật nói trên.
“Trong đó, 39 trường hợp được thực hiện tại BV ĐH Y Dược TP.HCM và 76 trường hợp mắc Parkinson được thực hiện tại BV Nguyễn Tri Phương. Số bệnh nhân Parkinson được điều trị bằng kỹ thuật phẫu thuật đặt điện cực kích thích não sâu tăng dần qua từng năm” - TS-BS Tuấn nói.
_Công trình “Phẫu thuật kích thích não sâu điều trị bệnh Parkinson” nhận giải thưởng Nhân tài đất Việt năm 2023_
Từ những kết quả đạt được trong việc chữa bệnh Parkinson, TS-BS Tuấn cùng các cộng sự tại Trường ĐH Y Dược TP.HCM và BV Nguyễn Tri Phương đã xây dựng công trình nghiên cứu có tên “Phẫu thuật kích thích não sâu điều trị bệnh Parkinson”.
Cùng tham gia xây dựng công trình này còn có ThS-BS Nguyễn Anh Diễm Thúy (khoa Nội thần kinh BV Nguyễn Tri Phương).
“Kết quả của công trình nghiên cứu được báo cáo tại nhiều [h](https://plo.vn/tim-kiem/?q=h%E1%BB%99i%20ngh%E1%BB%8B%20khoa%20h%E1%BB%8Dc)ội nghị khoa học trong và ngoài nước. Điều đáng nói là công trình nghiên cứu này vừa nhận được giải ba (không có giải nhất) giải thưởng Nhân tài đất Việt năm 2023 dành cho lĩnh vực y dược” - BS Thúy chia sẻ.
Theo BS Võ Đức Chiến, Giám đốc BV Nguyễn Tri Phương (TP.HCM), Parkinson là chứng rối loạn vận động, không ít người bị lúc còn trẻ. Trước đây, điều trị bệnh Parkinson chủ yếu bằng thuốc. Đến một thời điểm nào đó, thuốc không còn tác dụng và rơi vào tình trạng “kháng trị”. Nếu tiếp tục sử dụng có nguy cơ ngộ độc thuốc, thậm chí tử vong.
Điều trị bệnh Parkinson bằng kỹ thuật phẫu thuật đặt điện cực kích thích não sâu mang lại hiệu quả cao. Trước đây, do BV Nguyễn Tri Phương chưa triển khai kỹ thuật này nên bệnh nhân Parkinson phải ra nước ngoài điều trị với chi phí rất cao. Nay thì bệnh nhân Parkinson yên tâm điều trị tại BV với chi phí phù hợp và mau được cải thiện.
Trong khi đó, TS-BS Trần Ngọc Tài, Phó Trưởng khoa Thần kinh BV ĐH Y Dược TP.HCM, đồng trưởng nhóm nghiên cứu, cho biết hiện êkíp của BV ĐH Y Dược TP.HCM và BV Nguyễn Tri Phương đang chuyển giao kỹ thuật này cho BV Hữu nghị Việt Đức (Hà Nội). Sau miền Bắc, sắp tới có thể chuyển giao kỹ thuật cho khu vực miền Trung như BV đa khoa Đà Nẵng, khu vực miền Tây Nam Bộ như BV đa khoa Trung ương Cần Thơ.
  * [Đàn hát sau điều trị Parkinson](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/ky-thuat-phau-thuat-dat-dien-cuc-kich-thich-nao-sau-canh-cua-moi-cho-benh-nhan-parkinson-o-viet-nam#n-ht-sau-iu-tr-parkinson)
  * [Không cần điều trị ở nước ngoài](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/ky-thuat-phau-thuat-dat-dien-cuc-kich-thich-nao-sau-canh-cua-moi-cho-benh-nhan-parkinson-o-viet-nam#khng-cn-iu-tr-nc-ngoi)



## Ăn kiêng có thể cải thiện sức khỏe và kiểm soát cân nặng một cách đáng kể.

Một nghiên cứu mới của các nhà nghiên cứu từ Đại học bang Arizona nhấn mạnh ăn kiêng để cải thiện sức khỏe và kiểm soát cân nặng một cách đáng kể.
_**Mohr, A. E., et al. (2024). Gut microbiome remodeling and metabolomic profile improves in response to protein pacing with intermittent fasting versus continuous caloric restriction. Nature Communications.[doi.org/10.1038/s41467-024-48355-5](https://doi.org/10.1038/s41467-024-48355-5).**_
Những người tham gia theo chế độ nhịn ăn gián đoạn và điều chỉnh lượng protein, lượng protein nạp vào đều đặn trong ngày, nhận thấy sức khỏe đường ruột, giảm cân và phản ứng trao đổi chất tốt hơn. Những lợi ích này lớn hơn đáng kể so với những lợi ích được thấy khi hạn chế lượng calo đơn giản.
Hệ vi sinh vật đường ruột bao gồm vi khuẩn, vi rút, nấm và các vi khuẩn khác. Với số lượng hàng nghìn tỷ sinh vật, hệ sinh thái phức tạp này đóng một vai trò quan trọng đối với các chức năng thiết yếu của cơ thể và sức khỏe tổng thể. Hệ vi sinh vật đường ruột giúp phân hủy thức ăn, sản xuất vitamin và thúc đẩy quá trình hấp thụ chất dinh dưỡng. Nó đóng một vai trò trong sự phát triển và chức năng của hệ thống miễn dịch bằng cách bảo vệ cơ thể chống lại các mầm bệnh có hại. Cuối cùng, hệ vi sinh vật đường ruột điều chỉnh mạnh mẽ quá trình trao đổi chất, tác động đến trọng lượng cơ thể, việc tích trữ chất béo và độ nhạy insulin.
Hạn chế calo, nhịn ăn gián đoạn (hạn chế tiêu thụ thực phẩm ở một số khoảng thời gian nhất định trong một số ngày) và điều chỉnh lượng protein (kiểm soát lượng protein ăn vào trong các bữa ăn cụ thể) đã được chứng minh là có ảnh hưởng đến trọng lượng và thành phần cơ thể
Những người tham gia tuân theo chế độ nhịn ăn gián đoạn và điều chỉnh lượng protein đã giảm đáng kể các triệu chứng đường ruột và tăng vi khuẩn có lợi trong đường ruột, đặc biệt là Christensenellaceae (những vi khuẩn này có liên quan đến việc cải thiện quá trình oxy hóa chất béo và sức khỏe trao đổi chất), đạt được mức giảm cân và giảm mỡ nhiều hơn với mức giảm trung bình là 8,81% trọng lượng cơ thể ban đầu trong suốt nghiên cứu, giảm được lượng mỡ tổng thể trong cơ thể, bao gồm mỡ bụng và mỡ bụng sâu, đồng thời nhận thấy tỷ lệ khối lượng nạc trong cơ thể tăng lên.

## Tên thuốc: tên hoạt chất, tên biệt dược, tên thương mại - và một số khái niệm khác



**Tên thuốc** do nhà sản xuất đặt riêng cho sản phẩm kinh doanh của mình, còn gọi là **tên thương mại** hay **biệt dược**.
  * Cùng 1 hoạt chất thuốc nhưng có thể có nhiều tên gọi, nhiều hình thức bào chế khác nhau (viên nén, viên nhộng, viên sủi, viên đặt, thuốc gói, gói thơm, sirup...).
    * Nếu tên thuốc trùng nhau thì phân biệt bằng hàm lượng, nếu hàm lượng trùng nhau thì phân biệt bằng hình thức thuốc. Ví dụ:
      * Efferalgan 500mg (viên sủi)
      * Efferalgan 500mg (tọa dược)
      * Efferalgan 250mg (tọa dược)
      * Efferalgan 250mg (tọa dược) Ấn Độ
      * Efferalgan 250mg (tọa dược) Việt Nam


**Tên hoạt chất:**
  * Còn gọi là tên thành phần thuốc.
  * Là tên của chất hóa học, hoạt chất của thuốc
  * Các hoạt chất thuốc đã được phân loại theo chuẩn quốc tế. **Ví dụ:** Thuốc Efferalgan, Alaxan, Panadol đều được sản xuất từ hoạt chất Acetaminophen.
  * Theo quy định của Bộ y tế, khi kê đơn thuốc phải có tên hoạt chất ghi kèm theo tên biệt dược. Ví dụ Efferalgan 500mg _(Acetaminophene)_.
  * Một thuốc có thể bao gồm một hay nhiều hoạt chất.
  * Ví dụ:
    * Thuốc Panadol có 1 hoạt chất là _Acetaminophene_
    * Thuốc bổ Multi vitamin gồm 3-20 hoạt chất.


### **Hàm lượng:**
  * Là lượng hoạt chất có trong 1 đơn vị sử dụng (một liều thuốc). Ví dụ: 500mg/viên.
  * Hàm lượng nên được thể hiện ở đơn vị đo lường nhỏ nhất. Ví dụ: 1000mg thay vì 1g.
  * Thuốc dung dịch thì hàm lượng được thay bằng nồng độ. Ví dụ Cồn Boric 1%, NaCl 0,9%


**Đơn vị đóng gói:**
  * Là đơn vị đếm khi đóng gói vận chuyển: hộp, thùng, gói, chai...
  * Cần phải chuyển đổi các đơn vị đóng gói này sang đơn vị nhỏ nhất (viên, ống, gói, lọ) khi nhập và xuất kho. Lý do: có chai Prednisone 5mg chứa 100 viên, cũng có chai 1000 viên thuốc.
  * Đơn vị đóng gói được dùng khi nhập hóa đơn thuốc từ nhà cung cấp vào kho thuốc.


**Đơn vị bán lẻ:**
  * Là đơn vị nhỏ nhất để tính thành đơn vị thuốc trong đơn thuốc và trong kinh doanh lẻ. Ví dụ: viên, chai, lọ, gói...
  * Các đơn vị này không thể chia nhỏ hơn để kinh doanh. Ví dụ: không thể bán vài giọt thuốc nhỏ mắt mà phải bán nguyên lọ thuốc nhỏ mắt, dù người dùng chỉ cần vài giọt.


**Đơn vị liều dùng:**
  * Là đơn vị được tính khi sử dụng trong đơn thuốc. Ví dụ: viên, gói, muỗng, giọt, miếng... Khi bác sĩ kê đơn thuốc nhỏ mắt thì kê 1 **lọ** , nhưng khi dùng thì tính bằng **giọt**.
  * Cách này thường gặp ở các loại thuốc cho trẻ em. Ví dụ: đơn vị bán lẻ là 1 chai thuốc si rô ho, đơn vị liều dùng là muỗng cà phê.
  * Tại các nước tiên tiến thì thuốc được sản xuất ở liều dùng nhỏ nhất. Tuy nhiên có nhiều loại thuốc có ngấn chia thành 2 hay 4 góc, có thể bẻ ra được. Do đó liều dùng có thể được chia nhỏ khi kê đơn.
    * Ví dụ: Mua 5 viên, mỗi ngày uống 3 lần, mỗi lần **1/2** viên. 


**Cách ghi tên thuốc:**
Mỗi tên thuốc gồm các thành phần sau:
**Quy tắc : [Tên biệt dược] - [hàm lượng] - [dạng bào chế]**
**Ví dụ: [Panadol] [500mg] [(viên sủi)]**
Hàm lượng có 2 thành phần số lượng và đơn vị phải viết dính liền (500mg thay vì 500 mg).
Đơn vị trong hàm lượng nên chọn đơn vị nhỏ nhất (500mg thay vì 0.5g)
Trong trường hợp các thuốc hoàn toàn giống nhau về tên, hàm lượng và dạng bào chế thì thêm nước sản xuất vào sau tên thuốc để phân biệt.
**Nguyên tắc:** **Không có 2 thuốc trùng tên nhau.**



## Tăng xông là gì? Phòng tránh tăng xông hiệu quả

  * [Tăng xông là gì?](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/tang-xong-la-gi-phong-tranh-tang-xong-hieu-qua#tng-xngl-g)
  * [Nguyên nhân bị lên tăng xông](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/tang-xong-la-gi-phong-tranh-tang-xong-hieu-qua#nguyn-nhn-b-ln-tng-xng)
  * [Những đối tượng dễ bị tăng xông](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/tang-xong-la-gi-phong-tranh-tang-xong-hieu-qua#nhng-i-tng-d-b-tng-xng)
  * [Chế độ ăn cho người tăng xông máu](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/tang-xong-la-gi-phong-tranh-tang-xong-hieu-qua#ch-n-cho-ngi-tng-xng-mu)
  * [Một số biện pháp phòng ngừa tăng xông](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/tang-xong-la-gi-phong-tranh-tang-xong-hieu-qua#mt-s-bin-php-phng-nga-tng-xng)


## **Tăng xông****là gì?**
**Tăng xông** , hay còn gọi là **tăng huyết áp** (hypertension), là tình trạng áp lực máu tác động lên thành mạch cao hơn mức bình thường, khiến chỉ số huyết áp đo được nằm cao hơn trên mức 140/90 mmHg.
Thông thường, nếu chỉ số huyết áp nằm cao hơn mức 120/80 mmHg, điều đó có nghĩa là hệ tuần hoàn của bạn đang có một sức cản lớn và tim phải làm việc “vất vả” hơn để đẩy máu đi khắp cơ thể.
Lúc này, bác sĩ có thể khuyến nghị bạn điều chỉnh lối sống (giảm cân, tập thể dục và cắt giảm lượng muối tiêu thụ) để cải thiện tình trạng **huyết áp cao** hiện có.
Tuy nhiên, nếu huyết áp của bạn thường xuyên nằm trên mức 140/90 mmHg, điều đó có nghĩa là bạn đã mắc bệnh huyết áp cao mãn tính.
Nếu không được can thiệp kịp thời, cơn  _lên tăng xông_ có thể làm tăng nguy cơ đau tim, đột quỵ, suy tim hoặc khởi phát biến chứng suy thận.
Lúc này, việc chỉ điều chỉnh lối sống là không đủ để kiểm soát các cơn **tăng xông** cấp tính, mà bạn còn cần phải kết hợp dùng thuốc do bác sĩ chỉ định để hạ huyết áp một cách nhanh chóng.
Để bạn dễ dàng đánh giá tình trạng sức khỏe của bản thân, Hội Tim mạch học Việt Nam đã đưa ra tiêu chí phân loại 5 mức độ **tăng xông** và tiền **tăng xông** như sau:
## **Nguyên nhân bị lên tăng xông**
Có nhiều nguyên nhân khác nhau gây **tăng xông**. Một số nguyên nhân có thể được kiểm soát thông qua việc điều chỉnh lối sống và chế độ ăn uống, trong khi một số khác có thể cần sự can thiệp y tế chuyên sâu từ bác sĩ. Cụ thể như sau:
  * **Yếu tố di truyền:** Bạn có nguy cơ cao  _bị tăng xông_ nếu có người thân trong gia đình cũng mắc phải căn bệnh này;
  * **Tuổi tác:** Nguy cơ tăng huyết áp tăng lên theo tuổi tác, đặc biệt ở những người trên 60 tuổi;
  * **Chế độ ăn uống:** Chế độ ăn giàu natri (muối), chất béo bão hòa và cholesterol có thể góp phần làm tăng huyết áp bằng cách gây ảnh hưởng tiêu cực đến hệ thống tim mạch;
  * **Thừa cân hoặc béo phì:** Cân nặng càng cao, cơ thể càng cần nhiều máu hơn để cung cấp oxy và chất dinh dưỡng nuôi tế bào, dẫn đến sự tăng áp lực lên thành mạch máu;
  * **Thiếu hoạt động thể chất:** Lối sống ít vận động có thể làm tăng nguy cơ **tăng xông** do xơ vữa thành mạch, giảm sức bền thành mạch hoặc sức mạnh cơ tim;
  * **Sử dụng rượu và thuốc lá:** Sử dụng nhiều rượu bia và hút thuốc lá có thể làm tăng nguy cơ  _bị tăng xông_ vì chúng ảnh hưởng xấu đến sức khỏe tim mạch và thận, hai cơ quan trực tiếp điều hòa huyết áp;
  * **Căng thẳng kéo dài:** Căng thẳng có thể gây **tăng xông** bằng cách thúc đẩy nhịp tim tăng nhanh;
  * **Các vấn đề sức khỏe khác:** Bệnh thận, bệnh tiểu đường, bệnh tim mạch và một số tình trạng sức khỏe khác cũng có thể gây ra tăng huyết áp.


## **Những đối tượng dễ bị tăng xông**
Những đối tượng dễ bị  _lên tăng xông_ (hay còn gọi là tăng huyết áp) thường bao gồm:
  * **Người lớn tuổi:** Rủi ro mắc bệnh tăng huyết áp tăng lên theo tuổi, đặc biệt sau tuổi 60. Theo [ước tính](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7021657/), có khoảng 60% dân số mắc  _bệnh tăng xông_ ở tuổi 60 và khoảng 65 – 75% dân số mắc  _bệnh tăng xông_ ở tuổi 70;
  * **Người có tiền sử gia đình bị tăng xông:** Nếu có người thân trong gia đình (cha mẹ, anh chị em) mắc bệnh tăng huyết áp, nguy cơ bạn mắc bệnh này cũng cao hơn.
  * **Người thừa cân hoặc béo phì:** Trọng lượng cơ thể cao hơn có thể làm tăng áp lực lên hệ thống mạch máu, dẫn đến nguy cơ **tăng xông**. Theo [Hiệp hội Tim mạch Hoa Kỳ](https://www.ahajournals.org/doi/10.1161/circresaha.116.305697), có đến 65 – 75% trường hợp tăng huyết áp nguyên phát hiện nay đều là người thừa cân – béo phì.
  * **Người ít vận động hoặc không tập thể dục:** Ít vận động khiến cơ tim không có cơ hội được rèn luyện để gia tăng sức bền và sức mạnh. Một hệ cơ tim có trương lực yếu cần phải hoạt động “vất vả” hơn để đẩy máu đi khắp cơ thể, dẫn đến nguy cơ **tăng xông** ;
  * **Người sử dụng rượu và thuốc lá:** Hút thuốc lá và sử dụng rượu quá mức có thể làm tăng nguy cơ tăng huyết áp;
  * **Người có chế độ ăn uống không lành mạnh:** Chế độ ăn giàu muối natri, chất béo bão hòa và cholesterol có thể làm tăng huyết áp vì chúng trực tiếp ảnh hưởng đến thể tích máu, lưu lượng máu, nhịp tim và độ đàn hồi của cơ trơn thành mạch máu;
  * **Người chịu căng thẳng kéo dài:** [Nghiên cứu](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3694268/) cho thấy, căng thẳng kéo dài, dù là tâm lý hay thể chất, đều có thể thúc đẩy cơ thể giải phóng hóc-môn catecholamine, dẫn đến làm gia tăng nhịp tim và lưu lượng máu qua tim; từ đó gây **tăng xông** ;
  * **Người mắc các bệnh lý khác:** **Tăng xông** có thể là một biến chứng / triệu chứng điển hình ở những người mắc bệnh thận, bệnh tiểu đường, bệnh tim mạch, Hội chứng Ngưng thở khi ngủ do tắc nghẽn,… và một số bệnh lý khác.


## **Chế độ ăn cho người tăng xông máu**
Chế độ ăn cho người  _tăng xông máu_ cần đáp ứng những nguyên tắc dinh dưỡng sau:
  * **Giảm muối:** Theo [Hiệp hội Tim mạch Hoa Kỳ](https://www.heart.org/en/health-topics/high-blood-pressure/changes-you-can-make-to-manage-high-blood-pressure/shaking-the-salt-habit-to-lower-high-blood-pressure), người bệnh có tiền sử **tăng xông** cần giới hạn hàm lượng muối ăn dưới 3.75g muối ăn / ngày, hoặc tối đa là không quá 5.75g muối / ngày để ngăn ngừa bệnh tiến triển nặng;
  * **Giảm chất béo bão hòa và chất béo trans:** Tiêu thụ quá mức hai loại chất béo này có thể khiến máu trở nên đặc hơn, làm tăng nguy cơ xơ vữa động mạch và khiến tim phải hoạt động “vất vả” hơn để bơm máu, từ đó gây tăng huyết áp;
  * **Kiểm soát cân nặng:** Ăn với lượng vừa phải để giảm nguy cơ thừa cân – béo phì, tác nhân có thể khiến tình trạng **tăng xông** tiến triển nặng;
  * **Giảm caffeine và rượu:** Hạn chế rượu bia và các thức uống chứa caffeine giúp điều hòa nhịp tim, duy trì lưu lượng máu bình thường và ổn định huyết áp;
  * **Ăn nhiều rau củ và trái cây:** Rau củ quả giàu vitamin và chất xơ, giúp tăng cường sức khỏe cho hệ thống tim mạch, thận – hai cơ quan trực tiếp điều hòa huyết áp;
  * **Uống đủ nước:** Uống hợp lý 1.5 – 2.0 lít nước cần thiết mỗi ngày giúp duy trì thể tích tuần hoàn máu và ổn định huyết áp hiệu quả.


## **Một số biện pháp phòng ngừa tăng xông**
Để phòng ngừa **tăng xông** , bạn cần kết hợp điều chỉnh chế độ ăn uống với việc thay đổi lối sống, cụ thể như sau:
  * **Duy trì cân nặng khỏe mạnh:** Thừa cân và béo phì chính là nguyên nhân hàng đầu gây tăng huyết. Ngược lại, duy trì cân nặng khỏe mạnh giúp làm giảm nguy  _tăng xông máu_ một cách đáng kể;
  * **Chế độ ăn uống cân đối:** Duy trì một chế độ ăn cân đối (giàu vitamin và chất xơ, ít muối và chất béo bão hòa) chính là “chìa khóa vàng” hỗ trợ kiểm soát  _bệnh tăng xông_ hiệu quả;
  * **Tập thể dục đều đặn:** Tập thể dục giúp điều hòa huyết áp bằng cách giảm độ cứng của thành mạch để máu có thể lưu thông dễ dàng hơn. Do đó, người có tiền sử  _tăng xông máu_ cần tập luyện thể lực ít nhất 30 phút mỗi ngày (khi cơn **tăng xông** chưa bộc phát) để hỗ trợ kiểm soát bệnh hiệu quả;
  * **Kiểm soát căng thẳng:** Thực hành các kỹ thuật giảm stress như thiền, yoga hoặc hít thở sâu giúp bạn điều hòa nhịp tim, từ đó hạn chế nguy cơ **tăng xông** do căng thẳng;
  * **Từ bỏ việc tiêu thụ chất kích thích:** Người có tiền sử **tăng xông** nên tránh tiêu thụ rượu bia và thuốc lá bởi cả hai đều có thể làm tăng nguy cơ **tăng xông** ;
  * **Kiểm tra sức khỏe định kỳ:** Kiểm tra huyết áp định kỳ giúp phát hiện và quản lý sớm các dấu hiệu **tăng xông** để có biện pháp can thiệp kịp thời.


  * [Tăng xông là gì?](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/tang-xong-la-gi-phong-tranh-tang-xong-hieu-qua#tng-xngl-g)
  * [Nguyên nhân bị lên tăng xông](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/tang-xong-la-gi-phong-tranh-tang-xong-hieu-qua#nguyn-nhn-b-ln-tng-xng)
  * [Những đối tượng dễ bị tăng xông](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/tang-xong-la-gi-phong-tranh-tang-xong-hieu-qua#nhng-i-tng-d-b-tng-xng)
  * [Chế độ ăn cho người tăng xông máu](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/tang-xong-la-gi-phong-tranh-tang-xong-hieu-qua#ch-n-cho-ngi-tng-xng-mu)
  * [Một số biện pháp phòng ngừa tăng xông](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/tang-xong-la-gi-phong-tranh-tang-xong-hieu-qua#mt-s-bin-php-phng-nga-tng-xng)



## Tăng nguy cơ đột quỵ do ngủ quá nhiều?

Nghiên cứu trên được tiến hành bởi tiến sĩ Yue Leng và đồng nghiệp ở Khoa Y tế Công cộng ở Đại học Cambridge, Anh và được công bố trên tạp chí  _Thần kinh học._
Theo Quỹ Giấc ngủ Quốc gia, người trưởng thành từ 18-64 tuổi nên ngủ từ 7-9 tiếng mỗi đêm. Nhưng nghiên cứu này cho thấy ngủ hơn 8 tiếng mỗi đêm có thể làm tăng 46% nguy cơ bị đột quỵ. Nghiên cứu bao gồm hơn 9000 người có độ tuổi trung bình là 62.
Đột quỵ xảy ra khi nguồn cung cấp máu tới não bị cản trở bởi các cục máu đông hoặc do mạch máu bị vỡ. Hơn 795.000 người ở Mỹ bị đột quỵ mỗi năm và đây là nguyên nhân gây ra khuyết tật hàng đầu ở quốc gia này.
“Thời gian ngủ kéo dài có nhiều khả năng là dấu hiệu sớm của nguy cơ bị đột quỵ, đặc biệt ở người cao tuổi, “ tiến sĩ Leng cho biết. “Dù vậy, không nên diễn giải nghiên cứu trên theo hướng hạn chế giấc ngủ để giảm nguy cơ bị đột quỵ.”
**Thời gian ngủ tăng có là dấu hiệu sớm của đột quỵ?**
Để tìm ra câu trả lời, nhóm nghiên cứu đã khảo sát 9.692 người có độ tuổi trung bình là 62 và chưa bao giờ bị đột quỵ. Trong thời gian theo dõi trung bình là 9,5 năm, cứ 4 năm một lần người tham gian nghiên cứu phải hoàn thành hai bảng câu hỏi về thời gian ngủ mỗi đêm. Trong thời gian theo dõi, 346 người bị đột quỵ.
So với người ngủ từ 6-8 tiếng mỗi đêm – được xem là thời gian ngủ “trung bình”, nhóm nghiên cứu phát hiện thấy người ngủ hơn 8 tiếng có nguy cơ bị đột quỵ cao hơn 46%. 
Ngoài ra, những người tăng thời gian ngủ từ 6-8 tiếng mỗi đêm lên hơn 8 tiếng trong thời gian theo dõi có nguy cơ bị đột quỵ cao hơn 4 lần so với người ngủ 6-8 tiếng mỗi đêm một cách thường xuyên.
Bình luận về nghiên cứu trên, tiến sĩ Alberto Ramos ở Trường Y, Đại học Miami Miller, Mỹ nói:
“Chuyển thời gian ngủ từ ngắn sang dài có thể dấu hiệu sớm của đột quỵ và những người trong tình trạng này cần có biện pháp để giảm nguy cơ đột quỵ như giảm huyết áp và mức cholesterol.”
Tiến sĩ Leng cho biết hiện tượng thời gian ngủ gia tăng ở người tham gia nghiên cứu cho thấy sự buồn ngủ và mệt mỏi quá mức là kết quả của việc sức khỏe bị suy giảm.
“Ngoài ra, tăng thời gian ngủ cũng làm biến đổi dòng chảy của máu trong não và do đó đóng vai trò làm dấu hiệu sớm gây ra đột quỵ. Tuy nhiên, cơ chế sinh học chính xác của hiện tượng này vẫn chưa rõ và cần thêm nghiên cứu để xác nhận,” bà nói.
**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/)** - Đa khoa Hạng I Thành phố Hồ Chí Minh

## Thang bậc nhu cầu của Maslow

Nhà tâm lý học **Abraham Maslow** (1908-1970) được xem như một trong những người tiên phong trong trường phái  _**Tâm lý học nhân văn**_(humanistic psychology), trường phái này được xem là thế lực thứ 3 (the Third Force) khi thế giới lúc ấy đang biết đến 2 trường phái tâm lý chính: Phân tâm học (Psychoanalysis) và Chủ nghĩa hành vi (Behaviorism).
Năm 1943, ông đã phát triển một trong các lý thuyết mà tầm ảnh hưởngcủa nó được thừa nhận rộng rãi và được sử dụng trong nhiều lĩnh vực khác nhau, bao gồm cả lĩnh vực giáo dục. Đó là **lý thuyết về Thang bậc nhu cầu** (_**Hierarchy of Needs**_) của con người.
Trong lý thuyết này, ông xếp các nhu cầu của con người theo một hệ thống trật tự cấp bậc, trong đó, các nhu cầu ở mức độ cao hơn muốn xuất hiện thì các nhu cầu ở mức độ thấp hơn phải được thỏa mãn trước.
Trong thời điểm đầu tiên của lý thuyết, Maslow đã sắp xếp các nhu cầu của con người theo **5 cấp bậc** :
– Nhu cầu cơ bản (basic needs) thường được gọi là nhu cầu sinh học – Nhu cầu về an toàn (safety needs) – Nhu cầu về xã hội (social needs) – Nhu cầu về được quý trọng (esteem needs) – Nhu cầu được thể hiện mình (self-actualizing needs)
Sau đó, vào những năm 1970 và 1990, sự phân cấp này đã được Maslow hiệu chỉnh thành **7 bậc và cuối cùng là 8 bậc:** – Nhu cầu cơ bản (basic needs) – Nhu cầu về an toàn (safety needs) – Nhu cầu về xã hội (social needs) – Nhu cầu về được quý trọng (esteem needs) – Nhu cầu về nhận thức (cognitive needs) – Nhu cầu về thẩm mỹ (aesthetic needs) – Nhu cầu được thể hiện mình (self-actualizing needs) – Sự siêu nghiệm (transcendence)
**Ưu, nhược điểm của tháp nhu cầu Maslow**

## Tổng quan về bệnh khí phế thũng

  * [Các yếu tố nguy cơ bệnh khí phế thũng](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/tong-quan-ve-benh-khi-phe-thung#cc-yu-t-nguy-c-bnh-kh-ph-thng)


Bệnh khí phế thũng thay đổi cấu trúc của phổi theo một số cách quan trọng
  * Bình thường phổi rất xốp và đàn hồi. Khi hít vào, thành ngực nở ra, làm phổi cũng nở ra. Tương tự như khi một miếng xốp đang bị bóp chặt khi được thả ra sẽ hút nước vào bên trong nó, phổi cũng hút không khí vào bên trong nó khi thành ngực nở ra. Không khí đi vào qua khí quản, các phế quản (hai ống dẫn khí chính đi vào phổi phải và phổi trái). Hai ống này tiếp tục chia ra thành những ống nhỏ hơn và nhỏ hơn nữa đến đơn vị nhỏ nhất được gọi là phế nang. Phế nang là cấu trúc nhỏ nhất trong phổi, nó là một túi khí được sắp xếp tương tự như một chùm nho. Phế nang nằm ở đầu tận của ống dẫn khí nhỏ nhất có tên là tiểu phế quản. Các phế nang và tiểu phế quản là những cấu trúc rất quan trọng của phổi giúp nó thực hiện tốt chức năng của mình. Đó cũng chính là những cấu trúc bị phá hủy trong bệnh khí phế thũng.
  * Miếng xốp hút nước được là do tất cả những lỗ nhỏ li ti bên trong nó nở ra cùng một lúc sau khi được vắt khô. Nếu những lỗ này lớn hơn, miếng xốp không thể hút nước nhiều được. Đó là do những lỗ lớn không thể tự nở lớn ra bằng với nhiều lỗ nhỏ hơn. Hãy tưởng tượng phổi cũng tương tự như vậy sẽ hiểu được dễ dàng hơn vì sao khí phế thũng lại gây suy giảm chức năng phổi. Phổi cần phải có tính đàn hồi để có thể dãn ra và co lại tốt. Cũng tương tự như miếng xốp, phổi cần rất nhiều phế nang (hàng trăm triệu) để hút đủ khí vào bên trong. Các phế nang càng ít và càng lớn hơn thì hiệu quả sẽ càng kém đi.


#### Phân loại
_Khí phế thũng nguyên phát: có 3 loại chính theo vị trí tổn thương._
  * Khí phế thũng trung tâm tiểu thuỳ hoặc trung tâm tuyến nang (còn gọi là khí phế thũng týp B, hoặc týp xanh hay phù tím: Blue Bloater) là một biến chứng thứ phát sau viêm phế quản mạn. Viêm phế quản mạn lan từ trên xuống tới các tiểu phế quản tận ở trung tâm tiểu thuỳ, các tiểu phế quản này vì không có sụn, nên nhanh chóng bị phá huỷ và giãn ra (do thường xuyên bị tăng áp lực ở thì thở ra), tạo thành các bóng khí thũng ở trung tâm tiểu thuỳ. Còn các phế nang ở ngoại vi tiểu thuỳ vẫn bình thường, các mao mạch phổi không bị phá huỷ. Cho nên khi thiếu ôxy, sẽ tạo nên các shunt giải phẫu (thông giữa động mạch và tĩnh mạch phổi, do VA/QC giảm). Hậu quả sẽ làm cao áp tiểu tuần hoàn, dẫn đến ứ huyết ở tim phải và trở thành tâm phế mạn. Trên lâm sàng thấy bệnh nhân vừa có phù, vừa có tím.
  * Khí phế thũng toàn tiểu thùy hoặc đa tuyến nang (còn gọi là khí phế thũng týp A, hoặc týp hồng thổi: Pink Puffer). Do thiếu hụt a1 kháng Proteaza, a1 antitr bệnh nhân phải làm động tác thổi để chống lại xu hướng đó (hồng thổi).
  * Khí phế thũng tuyến nang xa (còn gọi là khí phế thũng cạnh vách). Tổn thương các ống phế nang và túi phế nang ở ngoại vi tuyến nang. Thường ở ngoại vi phổi, sát màng phổi, hoặc dọc theo các vách liên tiểu thuỳ. Có thể có một hoặc nhiều bóng khí từ 1cm đến chiếm hết một bên lồng ngực.


_Khí phế thũng thứ phát:_
  * Khí phế thũng điểm (focal) hoặc khí phế thũng quanh tiểu phế quản: do tiểu phế quản bị giãn và bị xơ hoá. Thường ở người bị bệnh bụi phổi.
  * Khí phế thũng cạnh tổ chức xơ:Thường phát sinh cạnh các tổn thương xơ (thứ phát sau lao).


## Các yếu tố nguy cơ bệnh khí phế thũng
  * Hút thuốc: Khí phế thũng rất có thể phát triển ở người hút thuốc lá, xì gà và ống hút thuốc. Cũng là nhạy cảm và nguy cơ cho tất cả những người hút thuốc tăng với số năm và số lượng thuốc lá hút.
  * Tuổi. Mặc dù những tổn thương phổi xảy ra trong khí phế thũng phát triển dần dần, hầu hết những người có liên quan đến khí phế thũng thuốc lá bắt đầu có những triệu chứng của bệnh trong độ tuổi từ 40 và 60.
  * Tiếp xúc với khói thuốc. Hút thuốc gián tiếp, cũng gọi là khói thuốc lá thụ động, không hút thuốc mà vô tình hít vào từ người khác, thuốc lá hoặc xì gà. Khói thuốc xung quanh làm tăng nguy cơ bệnh khí thũng.
  * Nghề nghiệp tiếp xúc với khói, bụi. Nếu hít thở khói từ một số hóa chất, bụi từ ngũ cốc, gỗ, bông hoặc các sản phẩm khai thác mỏ, có nhiều khả năng phát triển bệnh khí thũng. Nguy cơ này thậm chí còn lớn hơn nếu hút thuốc.
  * Tiếp xúc với ô nhiễm trong nhà và ngoài trời. Thở các chất ô nhiễm trong nhà, chẳng hạn như khí thải từ nhiên liệu sưởi ấm, cũng như các chất gây ô nhiễm ngoài trời, ví dụ khói xe, tăng nguy cơ bệnh khí thũng.
  * Lây nhiễm HIV. Những người hút thuốc sống với HIV có nguy cơ khí phế thũng lớn hơn là người hút thuốc lá không có nhiễm HIV.
  * Rối loạn mô liên kết. Một số bệnh có ảnh hưởng đến các mô liên kết - các sợi cung cấp khuôn và hỗ trợ cho cơ thể - được kết hợp với khí phế thũng. Các bệnh này bao gồm laxa - da, một căn bệnh hiếm gặp gây ra lão hóa sớm và hội chứng Marfan, một rối loạn có ảnh hưởng đến nhiều cơ quan khác nhau, đặc biệt là tim, mắt, xương và phổi.


  * [Các yếu tố nguy cơ bệnh khí phế thũng](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/tong-quan-ve-benh-khi-phe-thung#cc-yu-t-nguy-c-bnh-kh-ph-thng)



## Uống vitamin tổng hợp mỗi ngày - Lợi ích và mối nguy cơ

  * [1. Lợi ích đối với da và tóc](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/uong-vitamin-tong-hop-moi-ngay-loi-ich-va-moi-nguy-co#1-li-ch-i-vi-da-v-tc)
  * [2. Vitamin tổng hợp chứa sắt giúp giảm nguy cơ thiếu máu](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/uong-vitamin-tong-hop-moi-ngay-loi-ich-va-moi-nguy-co#2-vitamin-tng-hp-cha-st-gip-gim-nguy-c-thiu-mu)
  * [3. Một loại vitamin tổng hợp có thể bổ sung năng lượng](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/uong-vitamin-tong-hop-moi-ngay-loi-ich-va-moi-nguy-co#3-mt-loi-vitamin-tng-hp-c-th-b-sung-nng-lng)
  * [4. Vitamin tổng hợp hỗ trợ trái tim khỏe mạnh](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/uong-vitamin-tong-hop-moi-ngay-loi-ich-va-moi-nguy-co#4-vitamin-tng-hp-h-tr-tri-tim-khe-mnh)
  * [5. Vitamin tổng hợp tốt cho bộ não và trí nhớ](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/uong-vitamin-tong-hop-moi-ngay-loi-ich-va-moi-nguy-co#5-vitamin-tng-hp-tt-cho-b-no-v-tr-nh)
  * [6. Vitamin tổng hợp đôi khi có thể ảnh hưởng tới các xét nghiệm y tế](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/uong-vitamin-tong-hop-moi-ngay-loi-ich-va-moi-nguy-co#6-vitamin-tng-hp-i-khi-c-th-nh-hng-ti-cc-xt-nghim-y-t)
  * [7. Lưu ý về dinh dưỡng trong chế độ ăn uống](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/uong-vitamin-tong-hop-moi-ngay-loi-ich-va-moi-nguy-co#7-lu-v-dinh-dng-trong-ch-n-ung)


Theo Viện Y tế Quốc gia Hoa Kỳ (NIH), vitamin tổng hợp là một loại thực phẩm bổ sung có sự kết hợp của vitamin và khoáng chất, đôi khi với số lượng gần với lượng khuyến nghị hàng ngày của bạn.
NIH nhấn mạnh rằng, mặc dù việc uống vitamin tổng hợp hàng ngày có thể hữu ích, nhưng điều quan trọng là không lạm dụng vitamin tổng hợp thay thế chế độ ăn uống cân bằng, lành mạnh.
Dưới đây là những tác dụng có lợi và một số bất lợi khi uống vitamin tổng hợp hàng ngày. Cần nhớ, trước khi sử dụng vitamin tổng hợp như một thói quen hàng ngày, tốt nhất nên tham khảo ý kiến bác sĩ hoặc chuyên gia chăm sóc sức khỏe của mình.
## 1. Lợi ích đối với da và tóc
Bạn có thể cảm nhận được mái tóc, làn da và móng khỏe mạnh hơn khi sử dụng đúng loại vitamin tổng hợp dành riêng cho da và tóc. Một số loại vitamin tổng hợp có chứa các chất dinh dưỡng cụ thể như biotin, vitamin E và kẽm - những vi chất đã được chứng minh là có tác dụng thúc đẩy tóc, da và móng khỏe mạnh.
## 2. Vitamin tổng hợp chứa sắt giúp giảm nguy cơ thiếu máu
Bệnh thiếu máu do thiếu sắt là một vấn đề khá phổ biến do không sản xuất đủ tế bào hồng cầu khỏe mạnh trong cơ thể. Việc chọn loại vitamin tổng hợp phù hợp có thể giúp bạn ngăn ngừa bệnh thiếu máu do thiếu sắt bằng cách giúp bạn đạt được mức chất sắt khuyến nghị.
Sắt là một khoáng chất quan trọng để sản xuất tế bào hồng cầu và vận chuyển oxy trong cơ thể. Đây là lý do tại sao vitamin tổng hợp chứa sắt có lợi cho những người có nguy cơ hoặc bị thiếu sắt và cũng giúp ngăn ngừa các triệu chứng thiếu máu như mệt mỏi, suy nhược và khó thở.
##  3. Một loại vitamin tổng hợp có thể bổ sung năng lượng
Nếu bạn mệt mỏi kéo dài mà không phải do bệnh lý, một loại vitamin tổng hợp có thể là động lực giúp bạn lấy lại được năng lượng. Các nghiên cứu đã cho thấy, uống vitamin tổng hợp cung cấp các vitamin B hòa tan trong nước thiết yếu mà chúng ta cần để giải phóng năng lượng bị mắc kẹt bên trong carbohydrate, chất béo và protein.
Năng lượng được giải phóng này giờ đây có thể cung cấp năng lượng cho các tế bào và cung cấp năng lượng cần để thực hiện các hoạt động hàng ngày của cơ thể. Vitamin B cũng khuyến khích chức năng cơ quan khỏe mạnh và sức khỏe nhận thức.
## 4. Vitamin tổng hợp hỗ trợ trái tim khỏe mạnh
Một chế độ ăn uống lành mạnh và duy trì thói quen vận động tốt cho tim. Ngoài ra một số loại vitamin như vitamin D3, vitamin K2, folate và vitamin B12 vì những loại vitamin này đều có tác dụng hỗ trợ sức khỏe tim mạch.
Vitamin B6, B9 và B12, cùng với B2 (riboflavin), giúp hỗ trợ sức khỏe tim mạch bằng cách cân bằng homocysteine. Homocysteine là một acid amin được tạo ra trong cơ thể có thể tích tụ theo thời gian và gây hại cho hệ thống tim mạch.
Biotin rất cần thiết để duy trì sức khỏe của các mô này và thường có trong vitamin tổng hợp nhằm cải thiện tình trạng của chúng. Vitamin E hoạt động như một chất chống oxy hóa, bảo vệ tế bào da khỏi bị hư hại, trong khi kẽm hỗ trợ sản xuất protein cần thiết cho tóc và sự phát triển của móng tay.
## 5. Vitamin tổng hợp tốt cho bộ não và trí nhớ
Các loại vitamin B thường có trong vitamin tổng hợp là những "chiến binh" bảo vệ não bộ của bạn. Cụ thể từng loại vitamin:
  * Vitamin B5 hay còn gọi acid pantothenic - là một đồng yếu tố tạo điều kiện thuận lợi cho việc tạo ra acetylcholine, chất dẫn truyền thần kinh liên quan đến trí nhớ.
  * Vitamin B6 và B9 phối hợp với nhau để giúp sản xuất serotonin và dopamine, chất dẫn truyền thần kinh giúp chúng ta cảm thấy dễ chịu.
  * Vitamin B12 hỗ trợ sức khỏe của vỏ myelin, một lớp phủ bảo vệ cùng với các tế bào não.


## 6. Vitamin tổng hợp đôi khi có thể ảnh hưởng tới các xét nghiệm y tế
Tuy hiếm khi xảy ra nhưng các chuyên gia y tế lưu ý rằng, một số loại vitamin tổng hợp có thể ảnh hưởng đến một số xét nghiệm y tế, dẫn đến kết quả không chính xác. Ví dụ, bổ sung vitamin C liều cao dễ ảnh hưởng đến một số xét nghiệm đường huyết, có khả năng cho kết quả sai. Tương tự như vậy, một số loại vitamin tổng hợp có chứa biotin có thể cản trở các xét nghiệm nội tiết tố, chẳng hạn như xét nghiệm chức năng tuyến giáp.
## 7. Lưu ý về dinh dưỡng trong chế độ ăn uống
Điều đầu tiên cần lưu ý là bạn phải luôn cố gắng ăn một chế độ ăn uống cân bằng, nhiều rau để cung cấp đủ các khoáng chất và chất dinh dưỡng cần thiết cho cơ thể. Cần hạn chế tối đa các loại thực phẩm chế biến sẵn hoặc siêu chế biến, do chúng chứa nhiều calo nhưng ít vitamin và khoáng chất.
  * [1. Lợi ích đối với da và tóc](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/uong-vitamin-tong-hop-moi-ngay-loi-ich-va-moi-nguy-co#1-li-ch-i-vi-da-v-tc)
  * [2. Vitamin tổng hợp chứa sắt giúp giảm nguy cơ thiếu máu](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/uong-vitamin-tong-hop-moi-ngay-loi-ich-va-moi-nguy-co#2-vitamin-tng-hp-cha-st-gip-gim-nguy-c-thiu-mu)
  * [3. Một loại vitamin tổng hợp có thể bổ sung năng lượng](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/uong-vitamin-tong-hop-moi-ngay-loi-ich-va-moi-nguy-co#3-mt-loi-vitamin-tng-hp-c-th-b-sung-nng-lng)
  * [4. Vitamin tổng hợp hỗ trợ trái tim khỏe mạnh](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/uong-vitamin-tong-hop-moi-ngay-loi-ich-va-moi-nguy-co#4-vitamin-tng-hp-h-tr-tri-tim-khe-mnh)
  * [5. Vitamin tổng hợp tốt cho bộ não và trí nhớ](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/uong-vitamin-tong-hop-moi-ngay-loi-ich-va-moi-nguy-co#5-vitamin-tng-hp-tt-cho-b-no-v-tr-nh)
  * [6. Vitamin tổng hợp đôi khi có thể ảnh hưởng tới các xét nghiệm y tế](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/uong-vitamin-tong-hop-moi-ngay-loi-ich-va-moi-nguy-co#6-vitamin-tng-hp-i-khi-c-th-nh-hng-ti-cc-xt-nghim-y-t)
  * [7. Lưu ý về dinh dưỡng trong chế độ ăn uống](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/uong-vitamin-tong-hop-moi-ngay-loi-ich-va-moi-nguy-co#7-lu-v-dinh-dng-trong-ch-n-ung)



## Giấc ngủ trưa rất quan trọng cho sức khỏe

**Một giấc ngủ trưa** ngắn có thể giúp giảm stress và tăng cường hệ miễn dịch ở những người chỉ ngủ hai tiếng vào đêm hôm trước, theo một nghiên cứu mới được công bố trên Tạp chí  _Nội tiết học Lâm sàng & Trao đổi chất_ của Hiệp hội Nội tiết Hoa Kỳ.
Theo Trung tâm Ngăn ngừa và Kiểm soát Dịch bệnh, thiếu ngủ được xem là một vấn đề sức khỏe phổ biến. Thiếu ngủ có thể làm giảm năng suất cũng như gây ra tai nạn giao thông và tai nạn nghề nghiệp. Ngoài ra, người thiếu ngủ cũng có nhiều khả năng bị các bệnh mãn tính như béo phì, tiểu đường, cao huyết áp và trầm cảm.
Theo chương trình Khảo sát Sức khỏe Quốc gia, hơn một phần ba người trưởng thành ngủ ít hơn 6 tiếng mỗi tối.
“Nghiên cứu của chúng tôi cho thấy một giấc ngủ trưa 30 phút có thể đảo ngược tác hại lên hormone do thiếu ngủ vào đêm hôm trước, “ tác giả nghiên cứu, tiến sĩ Brice Faraut ở Đại học Paris Descartes, Pháp cho biết. “Đây là nghiên cứu đầu tiên cho thấy ngủ trưa có thể khôi phục khả năng miễn dịch và thần kinh nội tiết trở lại mức bình thường.”
Các nhà nghiên cứu đã tiến hành một nghiên cứu cắt chéo ngẫu nghiên để đánh giá mối tương quan giữa hormone và giấc ngủ ở một nhóm gồm 11 người đàn ông khỏe mạnh từ 25 đến 32 tuổi. Những người này trải qua hai thử nghiệm về giấc ngủ trong phòng thí nghiệm nơi mà thức ăn và ánh sáng được kiểm soát chặt chẽ.
Trong thử nghiệm thứ nhất, những người tham gia chỉ được cho ngủ hai tiếng một đêm. Trong thử nghiệm thứ hai, các đối tượng có hai giấc ngủ trưa kéo dài 30 phút vào ngày thứ hai sau đêm thiếu ngủ.
Nhóm nghiên cứu đã phân tích nước tiểu và nước bọt của người tham gia để xác định xem thiếu vào ban đêm và ngủ trưa làm thay đổi mức hormone như thế nào. Sau một đêm thiếu ngủ, mức norepinephrine tăng 2,5 lần. Norepinephrine là hormone và chất dẫn truyền thần kinh sinh ra khi cơ thể phản ứng với stress. Norepinephrine làm tăng nhịp tim, huyết áp và lượng đường trong máu của cơ thể. Khi ngủ trưa vào ngày thứ hai sau đêm thiếu ngủ, mức norepinephrine của người tham gia không thay đổi.
Thiếu ngủ cũng ảnh hưởng đến mức interleukin-6, một loại protein có đặc tính kháng virut được thấy trong nước bọt. Mức protein này giảm sau một đêm thiếu ngủ nhưng trở lại bình thường khi ngủ trưa. Điều này cho thấy ngủ trưa có lợi cho hệ miễn dịch.
“Ngủ trưa có thể đảo ngược tác hại của thiếu ngủ vào ban đêm bằng cách giúp hệ miễn dịch và thần kinh nội tiết phục hồi,” tiến sĩ Faraut cho biết. Nghiên cứu này giúp phát triển các giải pháp hỗ trợ những người thường xuyên bị thiếu ngủ vào ban đêm như công nhân làm ca và làm việc vào ban đêm.”
**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/)** - Đa khoa Hạng I Thành phố Hồ Chí Minh

## Mách bạn những món ăn sáng nhanh gọn đơn giản tại nhà

  * [Bánh mì trứng ốp la](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/mach-ban-nhung-mon-an-sang-nhanh-gon-don-gian-tai-nha#bnh-m-trng-p-la)
  * [Bánh mì nướng bơ tỏi](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/mach-ban-nhung-mon-an-sang-nhanh-gon-don-gian-tai-nha#bnh-m-nng-b-ti)
  * [Yogurt với trái cây và hạt](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/mach-ban-nhung-mon-an-sang-nhanh-gon-don-gian-tai-nha#yogurt-vi-tri-cy-v-ht)
  * [Cháo trứng thịt băm](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/mach-ban-nhung-mon-an-sang-nhanh-gon-don-gian-tai-nha#cho-trng-tht-bm)
  * [Cơm chiên trứng](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/mach-ban-nhung-mon-an-sang-nhanh-gon-don-gian-tai-nha#cm-chin-trng)


## Bánh mì trứng ốp la
Bạn có thể tự làm các món ăn sáng nhanh gọn tại nhà như bánh mì ốp la bằng cách:
**Chuẩn bị (khẩu phần ăn 1 người)**
  * 1 ổ bánh mì
  * 1-2 trứng gà (tùy khẩu phần ăn của từng người)
  * Dưa leo


**Cách thực hiện:**
  * Tách vỏ và chiên nguyên quả trứng vào chảo để làm trứng ốp la
  * Để trứng chiên vào giữa bánh mì, thêm nước xì dầu, ớt tương, hạt tiêu, dưa leo rồi thưởng thức.


## Bánh mì nướng bơ tỏi
**Chuẩn bị**
  * Bánh mì baguette
  * Bơ lạt
  * Tỏi xay
  * Lá oregano khô.


**Cách làm**
  * Trộn bơ với tỏi xay
  * Phết hỗn hợp bơ tỏi lên mặt bánh mì đã cắt xéo, rắc thêm lá oregano khô
  * Nướng bánh trong lò ở 180 độ C đến khi bánh vàng đều.


Bạn có thể mua bánh mì sẵn tại cửa hàng hoặc làm bánh mì nướng bơ tỏi tại nhà.
## Yogurt với trái cây và hạt
Nhắc đến các món ăn sáng nhanh gọn, dễ làm thì không thể thiếu món yogurt ăn kèm với trái cây. Đây không chỉ là món dễ làm mà còn cực kỳ lành mạnh, tốt cho sức khỏe.
Bạn chỉ cần mua hũ sữa chua, cho thêm vài miếng trái cây tươi như kiwi, việt quất và các loại hạt như hạnh nhân, bột yến mạch,.. và thưởng thức.
## Cháo trứng thịt băm
Để đa dạng hóa thực đơn bữa sáng nhanh gọn, bạn có thể nấu cháo trứng thịt băm chỉ với vài nguyên liệu đơn giản như: gạo, thịt băm, trứng, hành tím.
  * Rửa sạch gạo rồi thêm 1 lít nước để nấu cháo
  * Ướp thịt băm với muối, hạt nêm rồi phi hành thơm để xào thịt
  * Khi cháo hơi đặc, bạn cho phần thịt băm đã xào vào cháo
  * Cuối cùng đập quả trứng gà vào tô cháo đang còn nóng, rắc thêm ít tiêu và hành lá là hoàn thành.


## Cơm chiên trứng
Bạn có thể làm các món ăn sáng nhanh gọn chỉ với nguyên liệu có sẵn trong bếp như cơm nguội, trứng, hành lá và gia vị để làm cơm chiên trứng.
**Cách thực hiện**
  * Rửa sạch tay, bóp cơm nguội cho tơi ra
  * Bắc chảo nóng, phi thơm hành rồi cho trứng xào tơi ra
  * Cuối cùng cho cơm trộn vào chiên dưới lửa lớn trong 5 phút, rồi rắc hành vào, nêm nếm vừa ăn.


  * [Bánh mì trứng ốp la](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/mach-ban-nhung-mon-an-sang-nhanh-gon-don-gian-tai-nha#bnh-m-trng-p-la)
  * [Bánh mì nướng bơ tỏi](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/mach-ban-nhung-mon-an-sang-nhanh-gon-don-gian-tai-nha#bnh-m-nng-b-ti)
  * [Yogurt với trái cây và hạt](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/mach-ban-nhung-mon-an-sang-nhanh-gon-don-gian-tai-nha#yogurt-vi-tri-cy-v-ht)
  * [Cháo trứng thịt băm](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/mach-ban-nhung-mon-an-sang-nhanh-gon-don-gian-tai-nha#cho-trng-tht-bm)
  * [Cơm chiên trứng](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/mach-ban-nhung-mon-an-sang-nhanh-gon-don-gian-tai-nha#cm-chin-trng)



## Nhóm thuốc nào hay gặp trong điều trị trào ngược dạ dày - thực quản

**Nhóm ức chế bơm Proton (PPI)**
Cơ chế tác động: Thuốc ức chế sự hoạt động của enzym H+ K+ ATPase, từ đó ức chế bài tiết acid dịch vị.
Một số thuốc phổ biến hiện nay
• Omeprazole: Liều chuẩn uống 20 mg/ngày. GERD kháng trị, uống 20 mg/lần x 2 lần/ngày.
• Pantoprazole: Liều chuẩn uống 40 mg/ngày. GERD kháng trị, uống 40 mg/lần x 2 lần/ngày.
• Esomeprazole: Liều chuẩn uống 40 mg/ngày. GERD kháng trị, uống 40 mg/lần x 2 lần/ngày.
• Rabeprazole: Liều chuẩn uống 20 mg/ngày. GERD kháng trị, uống 20 mg/lần x 2 lần/ngày.
• Lansoprazole: Liều chuẩn uống 30 mg/ngày. GERD kháng trị, uống 30 mg/lần x 2 lần/ngày.
• Dexlansoprazole: Liều chuẩn uống 60 mg/ngày. GERD kháng trị, uống 60 mg/lần x 2 lần/ngày.
**Nhóm trung hòa Acid và Alginate**
Thuốc trung hòa axit có thể nhanh chóng làm giảm triệu chứng trào ngược dạ dày thực quuản. Thường dùng:
• Muối nhôm (carbonat, hydroxyd, phosphat)
• Muối magnesi (carbonat, hydroxyd, trisilicat) như Maalox, Gastropulgite
Alginate là hoạt chất giúp tạo mảng trung tính ngăn dịch trào ngược hoặc thay cho thành phần dịch dạ dày trào lên đoạn dưới thực quản. Thường được dùng là Gaviscon.
**Nhóm thuốc kháng thụ thể Histamin H2**
Cơ chế tác động: Tranh chấp với thụ thể H2 tại tế bào thành, làm giảm tiết H+
Thuốc thường dùng:
• Ranitidine,
• Zantac
• Tagamet...
Thuốc có tác dụng nhanh hơn so với nhóm PPI, tuy nhiên dùng lâu dài có thể gây nhiều tác dụng phụ (vd: chứng vú to ở nam giới)
**Nhóm Prokinetics**
Cơ chế tác động: Tăng đào thải acid trong lòng thực quản, tăng nhu động cơ thực quản
Thuốc thường dùng
• Metoclopramide: Uống 10 – 15 mg x 4 lần/ngày.
• Domperidone: Uống 10 mg x 3 lần/ngày.
• Baclofen: Uống 10 – 20 mg x 2 – 3 lần/ngày.
Ngoài ra, nhóm thuốc chống trầm cảm cũng có thể được đưa vào để sử dụng như một biện pháp hỗ trợ điều trị các trường hợp lo âu, căng thẳng, stress.

## Chương trình câu lạc bộ bệnh nhân Parkinson và rối loạn vận động

**Trân trọng kính mời bệnh nhân - thân nhân có quan tâm tham gia chương trình ./.**

## Vì sao huyết áp giữa hai tay có thể khác nhau ?

Sinh lý bình thường huyết áp hai tay vốn dĩ không hoàn toàn bằng nhau, thường thì huyết áp (HA) tay phải sẽ cao hơn HA tay trái chứ không như dân gian ta nghĩ tay trái gần tim hơn nên HA cao hơn!
Tại sao vậy?
Vì giải phẫu động mạch dưới đòn phải xuất phát từ thân đm cánh tay đầu còn động mạch dưới đón trái xuất phát từ cung đmc. Chính vì vậy chiều dài đm dưới đòn phải ngắn hơn đm dưới đòn trái dẫn đến áp lực máu lên đm dưới đòn phải thường cao hơn đm dưới đòn trái.
Và huyết áp tay phải cho phép chênh lệch với tay trái là 5-10mmHg
Tuần vừa rồi, một bệnh nhân nam 50 tuổi tìm đến tôi khám với than phiền thỉnh thoảng thấy chếnh choáng khi thay đổi tư thế. Anh ta đã đi khám hai nơi, một nơi chẩn đoán huyết áp thấp 90/60mmHg, nơi khác chẩn đoán tiền tăng huyết áp 130/90mmHg và hai cái đơn trái ngược nhau, một đơn nâng huyết áp, một đơn hạ huyết áp nên anh ta không dám uống. Hoang mang và thiếu tin tưởng, anh ta đi kiểm tra lại. Liệu các đồng nghiệp của tôi có đo huyết áp sai không? Phải đo lại đã chứ. Đo lại huyết áp tay phải 90/60mmHg, vậy là đúng rồi huyết áp thấp làm thiếu máu não gây nên triệu chứng chếnh choáng khi thay đổi tư thế, có thể kê đơn cho về điều trị được rồi. Nhưng hãy khoan, có cái gì đó không ổn, hỏi lại anh ta nói nhiều tháng trước kiểm tra huyết áp đều bình thường tại sao bây giờ lại huyết áp thấp, nghe tim bình thường, tiếng tim đều và khỏe. Người này lại to cao thân hình rắn chắc do thường xuyên thể thao, cớ gì lại huyết áp thấp. Cẩn thận, đo lại huyết áp tay trái xem, kết quả 130/90mmHg, kiểm tra lần nữa huyết áp cả hai tay vẫn như vậy một bên thấp một bên cao. Kỳ lạ chưa, như vậy các đồng nghiệp của tôi đều đúng, chỉ có điều thầy bói xem voi thôi, chỉ đo huyết áp một bên tay rồi kết luận.
Bây giờ theo bạn, cớ gì mà huyết áp hai tay lại chênh lệch như vậy? cần làm gì tiếp theo. Thử xem tôi làm gì nhé! Trước hết đo huyết áp khoeo chân hai bên đã, cả hai bên đều là 140/90mmHg. OK vậy huyết áp bên tay phải thấp là bất thường, cần phải kiểm tra hệ thống động mạch. Đặt ống nghe trên hố thượng đòn và dọc động mạch cảnh gốc hai bên. Đây rồi, hố thượng đòn bên phải có tiếng thổi tâm thu 3/6. Nghe dọc động mạch chủ bụng, động mạch thận và động mạch chậu gốc hai bên bình thường. Vậy vấn đề là động mạch cánh tay đầu bên phải bị hẹp làm lượng máu lên động mạch cảnh để tới não và lượng máu ra động mạch cánh tay phải bị giảm gây ra triệu chứng thiểu năng tuần hoàn não hệ động mạch cảnh trong và huyết áp thấp ở cánh tay phải, tiếng thổi tâm thu xuất hiện ở vị trí hẹp. Với tuổi 50 và triệu chứng mới xuất hiện một hai tháng gần đây thì thường là do mảng vữa xơ động mạch. Siêu âm Doppler động mạch đã xác định điều đó, một mảng vữa xơ ở động mạch cánh tay đầu phải gần chỗ phân chia thành động mạch dưới đòn và động mạch cảnh gốc phải gây hẹp 70% đường kính động mạch. Được rồi, gửi bệnh nhân đi can thiệp mạch và đặt một stent vào đó là ốn. Thế đấy đừng đơn giản khi đo huyết áp, chú ý một tí sẽ dẫn bạn tới thành công.
Nhân đây tôi cũng chia sẻ luôn một trường hợp khác. Cách đây 21 năm (1992) trong một lần trực khoa, tôi được một bác sĩ bàn giao theo dõi một bệnh nhân nữ 25 tuổi bị tăng huyết áp. Huyết áp thường xuyên 180/100mmHg, dùng phối hợp ba thuốc hạ áp mà huyết áp chỉ xuống được chút ít xung quanh 140-160mmHg trong 1-2 giờ lại tăng lên. Đây là tăng huyết áp kháng trị chăng, ở một phụ nữ trẻ như vậy thì nguyên nhân gì, liệu có phải u tủy thượng thận không. Nhưng u tủy thượng thận thì huyết áp thường tăng từng cơn chứ không tăng liên tục như vậy, trong cơn nhịp tim nhanh, vã mồ hôi, sau cơn bệnh nhân mệt và đái nhiều, nhưng bệnh nhân này không như vậy. Đặt ống nghe, nghe dọc động mạch, cái gì vậy hố thượng đòn trái và dưới đòn trái có tiếng thổi tâm thu khá rõ. Gọi sinh viên đo huyết áp hai khoeo chân đều 100/60mmHg. Thế đấy huyết áp chi trên cao, chi dưới thấp, tiếng thổi tâm thu hố thượng đòn và dưới đòn trái, theo các bạn nguyên nhân của tăng huyết áp kháng trị ở bệnh nhân này là gì? Hẳn là các bạn nói ngay hẹp eo động mạch chủ, bây giờ thì dễ quá rồi còn gì. Hôm sau siêu âm Doppler động mạch đã khẳng định điều đó. Bệnh nhân được chuyển sang khoa ngoại để phẫu thuật, vấn đề đã được giải quyết chỉ bằng những động tác đơn giản trong lâm sàng là đo huyết áp và nghe động mạch. Vào thời gian đó 1992, tôi cũng đâu có nhiều kinh nghiệm trong lâm sàng, chỉ là một bác sĩ chuyên khoa cấp I mới về công tác ở khoa Tim-Thận-Khớp-Nội tiết được vài năm, cũng chẳng giỏi giang gì, nhưng lúc đó tôi mới đọc được trong một cuốn sách, người thầy là tác giả của cuốn sách khuyên rằng “khi đo huyết áp, cần phải đo ở cả hai tay và hai chân, nếu thấy bất thường đừng quên nghe dọc các động mạch lớn” thế là tôi áp dụng ngay. Mãi đến sau này học hết thạc sĩ, bác sĩ chuyên khoa cấp II nội chung rồi bảo vệ thành công luận án tiến sĩ chuyên ngành thận-tiết niệu rồi thành phó giáo sư thận-tiết niệu tôi vẫn không quên được trường hợp đó, và bây giờ sau 21 năm tôi lại áp dụng thành công. Sách đúng là người thầy tuyệt vời và đó cũng là điều tôi muốn chia sẻ cùng các bạn đồng nghiệp.
**PGS.TS. Hà Hoàng Kiệm**

## 5 nhu cầu của con người theo tháp Maslow

  * [Nhu cầu cơ bản của con người là gì?](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/5-nhu-cau-cua-con-nguoi-theo-thap-maslow#nhu-cu-c-bn-ca-con-ngi-l-g)
  * [5 Cấp bậc trong thuyết tháp nhu cầu Maslow](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/5-nhu-cau-cua-con-nguoi-theo-thap-maslow#5-cp-bc-trong-thuyt-thp-nhu-cu-maslow)
  * [1. Nhu cầu sinh lý (Physiological Needs)](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/5-nhu-cau-cua-con-nguoi-theo-thap-maslow#1-nhu-cu-sinh-l-physiological-needs)
  * [2. Nhu cầu đảm bảo an toàn (Safety Needs)](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/5-nhu-cau-cua-con-nguoi-theo-thap-maslow#2-nhu-cu-m-bo-an-ton-safety-needs)
  * [3. Nhu cầu xã hội (Love/ Belonging Needs)](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/5-nhu-cau-cua-con-nguoi-theo-thap-maslow#3-nhu-cu-x-hi-love-belonging-needs)
  * [4. Nhu cầu được kính trọng (Esteem Needs)](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/5-nhu-cau-cua-con-nguoi-theo-thap-maslow#4-nhu-cu-c-knh-trng-esteem-needs)
  * [5. Nhu cầu thể hiện bản thân (Self-Actualization Needs)](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/5-nhu-cau-cua-con-nguoi-theo-thap-maslow#5-nhu-cu-th-hin-bn-thn-selfactualization-needs)


## **Maslow là gì?**
Maslow là một nhà tâm lý học người Mỹ, tên đầy đủ là Abraham Harold Maslow (1908 - 1970). Abraham Maslow là một trong những nhà tâm lý học đáng chú ý nhất và nổi tiếng nhất với lý thuyết mô hình tháp "Nhu cầu của con người" (Hierarchy of Needs). Ông được xem là cha đẻ của chủ nghĩa nhân văn trong tâm lý học vì ông tập trung vào việc hiểu và giải quyết nhu cầu và khao khát của con người, đặc biệt là trong ngữ cảnh xã hội và tâm lý.
Theo lý thuyết của Abraham Maslow, con người có một số nhu cầu cơ bản và tất cả các nhu cầu này được sắp xếp thành 5 bậc thang, từ nhu cầu cơ bản nhất ở bậc dưới cùng cho đến nhu cầu cao cấp hơn ở bậc trên cùng:
  1. _Physiological Needs_
  2. _Safety Needs_
  3. _Love/ Belonging Needs_
  4. _Esteem Needs_
  5. _Self-Actualization Needs_


Những nghiên cứu về học thuyết nhu cầu của Maslow xây dựng đã ảnh hưởng đến nhiều lĩnh vực, đặc biệt là trong tâm lý học, giáo dục và quản lý tổ chức và được sử dụng rộng rãi để hiểu và đáp ứng các nhu cầu của con người trong cuộc sống và công việc hàng ngày.
## **Nhu cầu cơ bản của con người là gì?**
Nhu cầu là một yêu cầu hoặc điều gì đó mà con người cảm thấy thiết yếu, quan trọng hoặc muốn có để đáp ứng các nhu cầu tâm lý và vật chất. Nhu cầu có thể là cơ bản và cần thiết để duy trì sự tồn tại và sức khỏe, hoặc có thể là các nhu cầu cao cấp hơn như thỏa mãn và phát triển cá nhân.
Một số nhu cầu cơ bản của con người bao gồm:
  * Thức ăn, nước uống, nơi ở, quần áo
  * An toàn, bảo vệ
  * Tình yêu, sự quan tâm, sự đồng hành
  * Tự do, sự tôn trọng
  * Kiến thức, sự hiểu biết
  * Thẩm mỹ, sự sáng tạo


Phân loại 5 nhu cầu cơ bản của con người:
  1. **Nhu cầu sinh lý** : là những nhu cầu cần thiết cho sự sống của con người, bao gồm thức ăn, nước uống, nơi ở, quần áo,...
  2. **Nhu cầu an toàn:** là những nhu cầu cần thiết để bảo vệ con người khỏi những nguy hiểm, bao gồm an toàn về thể chất, an toàn về tinh thần, an toàn về tài chính,...
  3. **Nhu cầu xã hội:** là những nhu cầu cần thiết cho sự giao tiếp và tương tác với những người khác, bao gồm tình yêu, sự quan tâm, sự đồng hành, sự tôn trọng,...
  4. **Nhu cầu được tôn trọng** : là những nhu cầu cần thiết để cảm thấy tự tin, có giá trị và có năng lực, bao gồm sự tôn trọng từ bản thân, sự tôn trọng từ người khác và thành tích đạt được,...
  5. **Nhu cầu tự khẳng định:** là những nhu cầu cần thiết để phát triển và hoàn thiện bản thân, bao gồm sự tự do, sự sáng tạo, sự thành công,...


Nhu cầu có thể thay đổi tùy theo từng người, từng thời điểm và từng hoàn cảnh. Ví dụ, nhu cầu của một người trẻ tuổi có thể khác với nhu cầu của một người già, nhu cầu của một người sống trong thành phố có thể khác với nhu cầu của một người sống ở nông thôn, nhu cầu của một người có thu nhập cao có thể khác với nhu cầu của một người có thu nhập thấp.
Nhu cầu là một động lực quan trọng thúc đẩy hành vi của con người. Khi nhu cầu không được đáp ứng, con người sẽ cảm thấy khó chịu, căng thẳng và có thể dẫn đến những hành vi tiêu cực. Khi nhu cầu được đáp ứng, con người sẽ cảm thấy hài lòng, hạnh phúc và có thể dẫn đến những hành vi tích cực.
## **5 Cấp bậc trong thuyết tháp nhu cầu Maslow**
5 cấp bậc trong thang nhu cầu Maslow được phát triển theo thứ dưới lên trên, tương ứng với những nhu cầu cơ bản đến phức tạp. Maslow cho rằng, 4 nhu cầu đầu tiên xuất phát từ sự thiếu hụt nên sinh ra nhu cầu (Basic needs) nhằm đáp ứng những mong muốn này. Với nhu cầu thứ 5 - nhu cầu cao nhất, điều này không xuất phát từ sự thiếu hụt mà bắt nguồn từ những mong muốn tự nhiên của con người là phát triển bản thân (Meta needs).
### **1. Nhu cầu sinh lý (Physiological Needs)**
Nhu cầu sinh lý (Physiological Needs) là những nhu cầu cơ bản và thiết yếu nhất của con người, bao gồm các nhu cầu về thức ăn, nước uống, không khí, giấc ngủ, quần áo và mái ấm. Đây là những nhu cầu mà nếu không được đáp ứng đủ sẽ ảnh hưởng nghiêm trọng đến sức khỏe và sinh tồn của con người. Việc đáp ứng các nhu cầu sinh lý là điều kiện tiên quyết để con người có thể tồn tại và phát triển.
Nhu cầu sinh lý là cấp bậc dưới cùng. Theo Maslow, chỉ khi đáp ứng được tầng nhu cầu sinh lý này, mỗi người mới có thể đạt được những bậc tiếp theo trong mô hình tháp.
### **2. Nhu cầu đảm bảo an toàn (Safety Needs)**
Nhu cầu đảm bảo an toàn (Safety Needs) là nhu cầu được cảm thấy an toàn và được bảo vệ khỏi những nguy hiểm có thể xảy ra. Nhu cầu này bao gồm cả an toàn về thể chất, tinh thần và xã hội.
Nhu cầu đảm bảo an toàn là cấp bậc thứ 2 trong tháp nhu cầu Maslow. Nhu cầu này bao gồm:
  * **An toàn về mặt thể chất:** Gồm các nhu cầu như có một nơi ở an toàn, bảo vệ khỏi nguy cơ về thức ăn, nước uống, y tế và môi trường. Con người cần cảm thấy rằng họ và gia đình của họ được bảo vệ khỏi các nguy cơ về thảm họa và thiệt hại về tài sản.
  * **An toàn tinh thần:** Là những nhu cầu cảm thấy an toàn về mặt tinh thần và xã hội. Con người cần cảm thấy rằng họ không bị đe dọa bởi xung đột, bạo lực hoặc tình trạng tinh thần không ổn định. Họ muốn có một môi trường xã hội ổn định và an toàn để phát triển và thể hiện bản thân.
  * **An toàn về xã hội:** Là nhu cầu được bảo vệ khỏi những nguy hiểm về xã hội như bạo lực, bất công,...


Khi các nhu cầu sinh lý được đáp ứng, con người sẽ bắt đầu quan tâm đến các nhu cầu đảm bảo an toàn. Việc đáp ứng các nhu cầu đảm bảo an toàn sẽ giúp con người cảm thấy an tâm và thoải mái, từ đó có thể tập trung vào việc phát triển các nhu cầu cao hơn.
Việc đáp ứng các nhu cầu đảm bảo an toàn là điều cần thiết để con người có thể sống và phát triển một cách bình yên và hạnh phúc.
Trong một số tài liệu thuyết nhu cầu của maslow khác, hai nhu cầu này được gộp chung thành một nhóm.
### **3. Nhu cầu xã hội (Love/ Belonging Needs)**
Sau khi đã thỏa mãn các nhu cầu về thể chất, mỗi người sẽ mong muốn được đáp ứng những nhu cầu về tinh thần. Ở cấp bậc thứ 3 này, những nhu cầu thỏa mãn về tinh thần bắt đầu xuất hiện. Nhu cầu này là những mong muốn về việc mở rộng mối quan hệ như gia đình, tình yêu, bạn bè,... nhằm loại bỏ cảm giác cô đơn, buồn bã khi ở một mình, mang lại sự thân thuộc, gần gũi và sẻ chia.
Chẳng hạn: Một người mới đi làm sẽ quan tâm về mức lương để đáp ứng các nhu cầu về chỗ ở, ăn uống, mặc ấm,... sau đó xem xét môi trường làm việc đó có an toàn không, có được đóng bảo hiểm không. Khi những điều này được thỏa mãn, cá nhân đó sẽ mở rộng những mối quan hệ xã hội, với đồng nghiệp, khách hàng nhằm hòa nhập và thực hiện công việc hiệu quả hơn.
### **4. Nhu cầu được kính trọng (Esteem Needs)**
Nhu cầu được kính trọng trong tháp nhu cầu Maslow thể hiện mong muốn nhận được sự tôn trọng từ người khác. Khi ở cấp bậc này, mỗi người sẽ không ngừng nỗ lực, cố gắng để nhận được sự tôn trọng từ bên ngoài. Biểu hiện rõ nhất của nhu cầu này bao gồm:
  * Mong muốn về danh tiếng, sự tôn trọng từ bên ngoài: Bao gồm danh tiếng, địa vị, mức độ thành công
  * Lòng tự trọng với bản thân: Thể hiện ở một người coi trọng đạo đức bản thân, coi trọng phẩm giá. Nếu thiếu đi lòng tự trọng, con người sẽ thấy mặc cảm và lo lắng khi gặp khó khăn trong mọi việc.


Thực tế cho thấy, khi có được sự tôn trọng và công nhận từ bên ngoài, mỗi cá nhân sẽ cảm thấy tự tin, tôn trọng bản thân hơn. Với cấp độ này, mỗi cá nhân sẽ tự biết cố gắng phát triển bằng mọi cách để thăng tiến hơn trong công việc, cuộc sống.
### **5. Nhu cầu thể hiện bản thân (Self-Actualization Needs)**
Nhu cầu được thể hiện bản thân (Self-Actualization Needs) là cấp độ cao nhất trong tháp nhu cầu Maslow và biểu thị sự thăng tiến và phát triển cá nhân đạt đến đỉnh cao của tiềm năng của mỗi người. Vị trí này xuất hiện khi 4 cấp bậc kia đã được thỏa mãn, tuy nhiên có một sự khác biệt so với 4 nhu cầu trước đó, đó là nó không xuất hiện từ sự thiếu hụt mà bắt nguồn từ chính những mong muốn phát triển của mỗi người.
Nhu cầu thể hiện bản thân thường ở những người đã có những thành tựu, thành công nhất định trong cuộc sống. Khi muốn được người khác thấy được trí tuệ, tiềm năng và sự phát triển của mình, họ sẽ làm mọi việc để thỏa mãn đam mê cũng như tìm kiếm được những giá trị thực của bản thân.
Maslow tin rằng, để hiểu được mức độ của nhu cầu này, cá nhân đó không chỉ đạt được mong muốn của các cấp dưới mà còn phải làm chủ được những điều này. Có thể nói, mục đích con người khi muốn thỏa mãn nhu cầu ở đỉnh chóp này là để bảo đảm và duy trì 4 nhu cầu ở dưới.
  * [Nhu cầu cơ bản của con người là gì?](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/5-nhu-cau-cua-con-nguoi-theo-thap-maslow#nhu-cu-c-bn-ca-con-ngi-l-g)
  * [5 Cấp bậc trong thuyết tháp nhu cầu Maslow](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/5-nhu-cau-cua-con-nguoi-theo-thap-maslow#5-cp-bc-trong-thuyt-thp-nhu-cu-maslow)
  * [1. Nhu cầu sinh lý (Physiological Needs)](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/5-nhu-cau-cua-con-nguoi-theo-thap-maslow#1-nhu-cu-sinh-l-physiological-needs)
  * [2. Nhu cầu đảm bảo an toàn (Safety Needs)](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/5-nhu-cau-cua-con-nguoi-theo-thap-maslow#2-nhu-cu-m-bo-an-ton-safety-needs)
  * [3. Nhu cầu xã hội (Love/ Belonging Needs)](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/5-nhu-cau-cua-con-nguoi-theo-thap-maslow#3-nhu-cu-x-hi-love-belonging-needs)
  * [4. Nhu cầu được kính trọng (Esteem Needs)](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/5-nhu-cau-cua-con-nguoi-theo-thap-maslow#4-nhu-cu-c-knh-trng-esteem-needs)
  * [5. Nhu cầu thể hiện bản thân (Self-Actualization Needs)](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/5-nhu-cau-cua-con-nguoi-theo-thap-maslow#5-nhu-cu-th-hin-bn-thn-selfactualization-needs)



## 6 trên 10 người được hỏi: có mang điện thoại khi đi vệ sinh

Theo một nghiên cứu của NordVPN, cứ 10 người thì có 6 người, đặc biệt là những người trẻ tuổi, mang điện thoại của họ vào nhà vệ sinh khi họ tiếp tục công việc hoặc thú vui giải trí của mình. 61.6% người tham gia nghiên cứu thừa nhận đã kiểm tra các tài khoản mạng xã hội của họ như Facebook, Twitter và Instagram khi đang ngồi trên bồn cầu.
Nghiên cứu cho biết thêm rằng trong khi 33.9% số người được hỏi nói rằng họ cập nhật các vấn đề thông tin thời sự bằng cách sử dụng điện thoại thông minh trong phòng vệ sinh, thì 24.5% số người được hỏi nói rằng họ sử dụng thời gian đó để nhắn tin hoặc thậm chí gọi điện cho những người thân yêu của mình.
Mặc dù thói quen này có vẻ vô hại nhưng nó có thể gây ra những hậu quả nghiêm trọng cho sức khỏe của bạn. Tiến sĩ Hugh Hayden, một chuyên gia kiểm soát lây nhiễm, trong một cuộc trò chuyện với Yahoo Life UK, đã nhấn mạnh rằng điện thoại thông minh có thể chứa nhiều vi khuẩn gấp 10 lần so với bồn cầu. Đặc biệt, màn hình cảm ứng được coi là "con muỗi của thời đại kỹ thuật số" do khả năng mang bệnh truyền nhiễm của chúng.
Nguy cơ lây nhiễm chéo cao khi các cá nhân chạm vào các bề mặt dùng chung và sau đó sử dụng điện thoại thông minh của họ mà không vệ sinh đúng cách. Vi khuẩn và mầm bệnh có trên bệ ngồi toilet có thể dễ dàng chuyển sang bề mặt điện thoại, trở thành nguồn lây nhiễm.
Những vi khuẩn có hại này sau đó có thể xâm nhập vào cơ thể thông qua tiếp xúc với miệng, mắt hoặc mũi. Tiến sĩ Hayden cho biết: “Khi chúng ta chạm vào các bề mặt dùng chung, sau đó sử dụng màn hình điện thoại thông minh của mình, sẽ có nguy cơ lây nhiễm chéo, chính điện thoại sẽ trở thành nguồn lây nhiễm”.
Theo báo cáo của Yahoo Like UK, vi khuẩn có thể tồn tại trên màn hình điện thoại di động tới 28 ngày, khiến chúng trở thành nơi sinh sản tiềm năng của mầm bệnh. Báo cáo nói thêm rằng theo các tài liệu nghiên cứu trước đây, một số mầm bệnh phổ biến nhất được tìm thấy trên điện thoại di động là Staphylococcus. Những mầm bệnh này có thể gây ra các biến chứng sức khỏe khác nhau, từ nhiễm trùng đường tiết niệu đến nhiễm trùng đường hô hấp và da.
Vì vậy, việc sử dụng điện thoại thông minh trong nhà vệ sinh có thể dẫn đến những hậu quả nghiêm trọng cho sức khỏe của bạn và bạn phải ưu tiên vệ sinh hơn là giải trí trong nhà vệ sinh. Vi khuẩn và mầm bệnh có thể tồn tại trên màn hình điện thoại và xâm nhập vào cơ thể thông qua tiếp xúc với miệng, mắt hoặc mũi, gây ra nhiều vấn đề sức khỏe nghiêm trọng.
Để giảm nguy cơ lây nhiễm, hãy luôn vệ sinh điện thoại của bạn bằng cách sử dụng khăn ẩm hoặc khử trùng diệt khuẩn thích hợp. Ngoài ra, hãy tránh mang điện thoại vào nhà vệ sinh và tạo một thói quen sử dụng điện thoại tích cực để tránh bị ảnh hưởng tới sức khoẻ bởi chính món đồ theo bạn hàng ngày.

## Thực phẩm hỗ trợ bảo vệ lá gan khỏe mạnh.

**Các loại quả có múi**
Quả có múi như cam, quýt, chanh, bưởi... chứa nhiều vitamin, khoáng chất như vitamin C, bioflavonoid, axit citric, kali. Bổ sung chúng trong thực đơn hàng ngày giúp thúc đẩy quá trình trao đổi chất, hỗ trợ phục hồi các tế bào gan bị tổn thương. Chúng còn hỗ trợ đào thải các độc tố trong gan, tăng cường hệ miễn dịch và cải thiện chức năng gan.
Các loại quả này còn cung cấp nhiều chất xơ hòa tan, chứa ít calo và carbohydrate, giúp ổn định lượng đường trong máu và thúc đẩy nhu động ruột. Ăn một lượng vừa phải trước bữa ăn có thể hạn chế thèm ăn, hỗ trợ người thừa cân, béo phì giảm cân, cải thiện và ngăn ngừa bệnh gan nhiễm mỡ.
Nho có thể ăn tươi hoặc dùng làm rượu, thạch, mứt, nước ép, dầu hạt nho. Nho có chứa nhiều polyphenol như resveratrol, anthocyanin, flavonol và axit phenolic. Bác sĩ Minh Thùy dẫn một số nghiên cứu cho thấy nho có hiệu quả trong việc hạ men gan khi dùng một lượng phù hợp mỗi ngày, trong thời gian trên 12 tuần.
Nho tốt cho gan bởi loại quả này có hàm lượng dồi dào resveratrol và flavonol. Đây là những hợp chất chất chống oxy hóa mạnh mẽ, giúp giảm tình trạng viêm, góp phần bảo vệ và giảm các tác động bất lợi cho gan.
**Thanh long**
Thanh long chứa nhiều chất xơ, vitamin và khoáng chất như vitamin C, E; sắt; magie; cung cấp các hợp chất có lợi như polyphenol, carotenoid và betacyanin tốt cho sức khỏe. Loại quả này có chỉ số đường huyết thấp, nghĩa là nếu ăn một lượng vừa phải giúp lượng đường huyết tăng từ từ và ổn định. Điều này rất quan trọng đối với sức khỏe của gan vì lượng đường trong máu tăng đột ngột góp phần gây ra bệnh gan nhiễm mỡ. Gan nhiễm mỡ là một trong những nguyên nhân dẫn đến viêm gan và ung thư gan hàng đầu hiện nay.
Câu nói "Ăn một trái táo mỗi ngày, bạn không cần phải gặp bác sĩ" nhấn mạnh về lợi ích của việc ăn táo thường xuyên đối với sức khỏe. Không chỉ có hương vị thơm ngon, táo còn cung cấp nhiều dưỡng chất cần thiết cho cơ thể, bao gồm chất xơ, carbohydrate, vitamin C, kali, magie.
Táo bón thường xảy ra ở bệnh nhân xơ gan và có thể dẫn đến hậu quả nặng nề là hội chứng não gan. Một quả táo có thể cung cấp trung bình 20% chất xơ hàng ngày, hỗ trợ quá trình tiêu hóa, ngăn ngừa táo bón và củng cố hệ vi khuẩn có lợi cho đường ruột. Chất xơ trong táo giúp no lâu, hỗ trợ kiểm soát cân nặng, giảm huyết áp và mỡ máu, giảm nguy cơ đột quỵ và tiểu đường.
Bơ có hàm lượng chất béo cao, trung bình khoảng 22,5 g chất béo trong mỗi quả. Phần lớn chất béo này là chất béo không bão hòa đơn, là "chất béo tốt". Chất béo không bão hòa trong quả bơ giúp làm giảm lượng mỡ xấu trong cơ thể (cholesterol tỷ trọng thấp hay LDL-c) và tăng lượng mỡ tốt (cholesterol tỷ trọng cao hay HDL-c). HDL-c giúp làm sạch máu và thành động mạch bằng cách vận chuyển các cholesterol xấu đến gan để gan phân hủy và loại bỏ các chất béo này. Bơ có lợi cho những người bị gan nhiễm mỡ.
Bơ còn cung cấp hơn 20 loại vitamin và khoáng chất rất tốt cho sức khỏe. Nó có chứa folate, vitamin E, C, K có khả năng chống oxy hóa cao; giúp trung hòa các gốc tự do độc hại trong cơ thể; làm giảm tình trạng viêm. Loại quả này còn hỗ trợ loại bỏ chất béo xấu trong gan, góp phần giảm nguy cơ xơ gan và ung thư gan.
**Cà chua**
Cà chua chứa nhiều giá trị dinh dưỡng tốt cho sức khỏe như vitamin E, C; folate; hợp chất phenolic và chất xơ. Cà chua rất giàu lycopene - hợp chất chống oxy hóa, chống viêm và ngăn chặn tế bào ung thư, giúp giảm tình trạng gan nhiễm mỡ, viêm nhiễm và ung thư gan. Lycopene còn có ở một số thực phẩm khác như ổi, dưa hấu, bưởi, đu đủ và ớt đỏ ngọt; nhưng ở nồng độ thấp hơn nhiều so với cà chua. Bạn có thể dùng cà chua làm nguyên liệu trộn salad, làm nước ép, sinh tố, nước sốt hoặc chế biến các món ăn ưa thích.

## 22 câu hỏi và trả lời về đột quỵ não

  * [1. Đột quỵ là gì? ](https://bvnguyentriphuong.com.vn/hoi-dap/22-cau-hoi-va-tra-loi-ve-dot-quy-nao#1-t-qu-l-g)
  * [2. Các triệu chứng của đột quỵ là gì? ](https://bvnguyentriphuong.com.vn/hoi-dap/22-cau-hoi-va-tra-loi-ve-dot-quy-nao#2-cc-triu-chng-ca-t-qu-l-g)
  * [3. Khám nghiệm nào để kiểm tra các đối tượng có nguy cơ đột quỵ?](https://bvnguyentriphuong.com.vn/hoi-dap/22-cau-hoi-va-tra-loi-ve-dot-quy-nao#3-khm-nghimno-kim-tra-cc-i-tng-c-nguy-c-t-qu)
  * [4. Trong đột quỵ: Tại sao thời gian = tổn thương não? ](https://bvnguyentriphuong.com.vn/hoi-dap/22-cau-hoi-va-tra-loi-ve-dot-quy-nao#4-trong-t-qu-ti-sao-thi-gian-tn-thng-no)
  * [5. Chẩn đoán đột quỵ như thế nào?](https://bvnguyentriphuong.com.vn/hoi-dap/22-cau-hoi-va-tra-loi-ve-dot-quy-nao#5-chn-on-t-qu-nh-th-no)
  * [6. Đột quỵ thiếu máu cục bộ là gì? ](https://bvnguyentriphuong.com.vn/hoi-dap/22-cau-hoi-va-tra-loi-ve-dot-quy-nao#6-t-qu-thiu-mu-cc-b-l-g)
  * [7. Đột quỵ xuất huyết não là gì?](https://bvnguyentriphuong.com.vn/hoi-dap/22-cau-hoi-va-tra-loi-ve-dot-quy-nao#7-t-qu-xut-huyt-no-l-g)
  * [8. Đột quỵ thoáng qua (TIA – Transient Ischemic Attack) là gì?](https://bvnguyentriphuong.com.vn/hoi-dap/22-cau-hoi-va-tra-loi-ve-dot-quy-nao#8-t-qu-thong-qua-tia-transient-ischemic-attack-l-g)
  * [9. Nguyên nhân nào gây ra đột quỵ? ](https://bvnguyentriphuong.com.vn/hoi-dap/22-cau-hoi-va-tra-loi-ve-dot-quy-nao#9-nguyn-nhn-no-gy-ra-t-qu)
  * [10. Yếu tố nguy cơ do các bệnh mạn tính nào gây ra? ](https://bvnguyentriphuong.com.vn/hoi-dap/22-cau-hoi-va-tra-loi-ve-dot-quy-nao#10-yu-t-nguy-c-do-cc-bnh-mn-tnh-no-gy-ra)
  * [11. Các yếu tố nguy cơ do hành vi gây ra? ](https://bvnguyentriphuong.com.vn/hoi-dap/22-cau-hoi-va-tra-loi-ve-dot-quy-nao#11-cc-yu-t-nguy-c-do-hnh-vi-gy-ra)
  * [12. Các yếu tố nguy cơ do chế độ ăn uống gây ra?](https://bvnguyentriphuong.com.vn/hoi-dap/22-cau-hoi-va-tra-loi-ve-dot-quy-nao#12-cc-yu-t-nguy-c-do-ch-n-ung-gy-ra)
  * [13. Các yếu tố nguy cơ nằm ngoài tầm kiểm soát của bạn là gì?](https://bvnguyentriphuong.com.vn/hoi-dap/22-cau-hoi-va-tra-loi-ve-dot-quy-nao#13-cc-yu-t-nguy-c-nm-ngoi-tm-kim-sot-ca-bn-l-g)
  * [14. Điều trị khẩn cấp trong đột quỵ như thế nào? ](https://bvnguyentriphuong.com.vn/hoi-dap/22-cau-hoi-va-tra-loi-ve-dot-quy-nao#14-iu-tr-khn-cp-trong-t-qu-nh-th-no)
  * [15. Tổn thương lâu dài do đột quỵ gây ra? ](https://bvnguyentriphuong.com.vn/hoi-dap/22-cau-hoi-va-tra-loi-ve-dot-quy-nao#15-tn-thng-lu-di-do-t-qu-gy-ra)
  * [16. Phục hồi sau đột quỵ bằng trị liệu ngôn ngữ.](https://bvnguyentriphuong.com.vn/hoi-dap/22-cau-hoi-va-tra-loi-ve-dot-quy-nao#16-phc-hi-sau-t-qu-bng-tr-liu-ngn-ng)
  * [17. Phục hồi sau đột quỵ bằng vật lý trị liệu.](https://bvnguyentriphuong.com.vn/hoi-dap/22-cau-hoi-va-tra-loi-ve-dot-quy-nao#17-phc-hi-sau-t-qu-bng-vt-l-tr-liu)
  * [18. Phục hồi chức năng sau đột quỵ bằng liệu pháp trò chuyện. ](https://bvnguyentriphuong.com.vn/hoi-dap/22-cau-hoi-va-tra-loi-ve-dot-quy-nao#18-phc-hi-chc-nng-sau-t-qu-bng-liu-php-tr-chuyn)
  * [19. Phòng chống đột quỵ bằng thay đổi lối sống như thế nào?](https://bvnguyentriphuong.com.vn/hoi-dap/22-cau-hoi-va-tra-loi-ve-dot-quy-nao#19-phng-chng-t-qu-bng-thay-i-li-sng-nh-th-no)
  * [20. Phòng chống đột quỵ bằng thuốc? ](https://bvnguyentriphuong.com.vn/hoi-dap/22-cau-hoi-va-tra-loi-ve-dot-quy-nao#20-phng-chng-t-qu-bng-thuc)
  * [21. Phòng chống đột quỵ bằng phẫu thuật. ](https://bvnguyentriphuong.com.vn/hoi-dap/22-cau-hoi-va-tra-loi-ve-dot-quy-nao#21-phng-chng-t-qu-bng-phu-thut)
  * [23. Cuộc sống sau đột quỵ như thế nào?](https://bvnguyentriphuong.com.vn/hoi-dap/22-cau-hoi-va-tra-loi-ve-dot-quy-nao#23-cuc-sng-sau-t-qu-nh-th-no)


### **1. Đột quỵ là gì?**
Đột quỵ xảy ra khi một mạch máu bị vỡ hoặc thông thường nhất vẫn là hình thành sự tắc nghẽn trong mạch máu. Nếu không được điều trị sớm, các tế bào não sẽ bắt đầu nhanh chóng chết đi. Kết quả là bệnh nhân có thể tàn tật hoặc nghiêm trọng hơn là tử vong. Nếu bạn phát hiện người nhà bị đột quỵ, hãy nhanh chóng tìm kiếm sự hỗ trợ y tế, đừng bao giờ trì hoãn.
### **2. Các triệu chứng của đột quỵ là gì?**
– Đột ngột tê liệt hoặc yếu đi 1 bên của cơ thể (trái hoặc phải). – Đột ngột mất thị lực ở một hoặc cả 2 mắt và khó nuốt. – Đột ngột nhức đầu dữ dội với nguyên nhân không rõ. – Chóng mặt và mất thăng bằng đột ngột. – Nhầm lẫn một cách đột ngột, khó khăn trong việc nói và hiểu. (rối loạn ngôn ngữ) Lập tức gọi 115 hoặc người nhà đưa người thân đến cơ sở y tế nếu nhận thấy họ có các triệu chứng nêu trên.
### **3. Khám nghiệm nào để kiểm tra các đối tượng có nguy cơ đột quỵ?**
Thử nghiệm FAST (NHANH CHÓNG) sẽ là 1 bài kiểm tra giúp phát hiện các triệu chứng đột quỵ ở người thân của bạn: – Khuôn mặt (Face): Yêu cầu 1 nụ cười. Để kiểm tra xem có xệ 1 bên mặt khi cố gắng mỉm cười không? – Cánh tay (Arms): Yêu cầu giơ cả 2 tay lên, kiểm tra xem có hiện tượng 1 tay thấp không? – Lời nói (Speech): Yêu cầu nói và lặp lại một vài câu đơn giản xem có được không? Quan sát xem có hiện tượng nói lắp hoặc nói khó hiểu không? – Thời gian (Time): Thời gian rất quan trọng. Đối với bệnh nhân đột quỵ, thời gian của họ được tính bằng giây. Nếu có bất kỳ dấu hiệu nào nêu trên hãy liên hệ 115 hoặc người nhà đưa họ đến cơ sở y tế ngay lập tức.
### **4. Trong đột quỵ: Tại sao thời gian = tổn thương não?**
Đối với đột quỵ, thời gian của họ rất quý giá – tính bằng giây. Khi mạch máu bị tắc nghẽn, máu sẽ không đến được nơi bị tắc nghẽn (máu vận chuyển oxy và các chất dinh dưỡng), các tế bào sẽ bị ngưng cấp dưỡng và chết dần sau vài phút. Có một số loại thuốc tiêu huyết khối được dùng với vai trò hạn chế tổn thương não, nhưng chúng cần được dùng trong vòng 3h – 4,5h ở một số người – sau khi họ biểu hiện các triệu chứng ban đầu và nguyên nhân là do máu đông gây tắc mạch máu não. Một khi các mô ở não bắt đầu hoại tử, các bộ phận cơ thể do các mô này quản lý sẽ hoạt động không tốt. Đây là lý do tại sao nói đột quỵ là nguyên nhân hàng đầu gây ra tình trạng khuyết tật lâu dài.
### **5. Chẩn đoán đột quỵ như thế nào?**
Khi một người có các triệu chứng đột quỵ được đưa đến phòng cấp cứu (Emergency Room – ER), bước đầu tiên là xác định xem người đó đang xảy ra loại đột quỵ nào. Có 2 loại đột quỵ chính và việc điều trị là hoàn toàn khác nhau ở 2 loại này. Chụp CT sẽ giúp bác sĩ xác định xem nguyên nhân đột quỵ là do tắc mạch máu hay là do xuất huyết mạch máu. Các xét nghiệm bổ sung cũng có thể cần thiết để xác định vị trí cục máu đông gây tắc nghẽn hoặc xác định vị trí xuất huyết não ở bệnh nhân.
### **6. Đột quỵ thiếu máu cục bộ là gì?**
Đột quỵ thiếu máu cục bộ là loại đột quỵ phổ biến nhất. 10 trường hợp đột quỵ thì có 9 trường hợp là đột quỵ thiếu máu cục bộ. Thủ phạm là một cục máu đông làm tắc nghẽn mạch máu bên trong não. Cục máu đông này có thể hình thành ngay ở não hoặc di chuyển trong mạch máu từ nơi khác đến não.
### **7. Đột quỵ xuất huyết não là gì?**
Đột quỵ xuất huyết não thường ít gặp hơn nhưng khả năng gây tử vong cao hơn. Đột quỵ xuất huyết não xảy ra khi một mạch máu trong não suy yếu đi và vỡ ra. Hậu quả là bệnh nhân sẽ xuất huyết bên trong não và rất khó để ngăn chặn.
### **8. Đột quỵ thoáng qua (TIA – Transient Ischemic Attack) là gì?**
Thiếu máu cục bộ tạm thời còn được gọi là ” đột quỵ nhẹ- đột quỵ thoáng qua”, có thể xem đây là thoát chết trong gang tấc. Lưu lượng máu chảy đến một bộ phận não bị giảm đi tạm thời, gây ra các triệu chứng như một cơn đột quỵ thật sự. Khi lưu lượng máu được cung cấp đầy đủ lại bình thường, các triệu chứng mất đi. TIA là dấu hiệu cảnh báo rằng đột quỵ thật sự sẽ đến rất sớm trong tương lai. Điều quan trọng là bạn cần đến ngay bác sĩ và bệnh khi phát hiện mình có đột quỵ thoáng qua, để có các phương pháp điều trị nhằm làm giảm nguy cơ đột quỵ.
### **9. Nguyên nhân nào gây ra đột quỵ?**
Xơ vữa động mạch – xơ cứng động mạch là nguyên nhân phổ biến gây ra đột quỵ. Chất béo, cholesterol, canxi và các chất khác tích tụ thành các mảng và bám vào thành động mạch, từ đó làm cản trở sự lưu thông của máu. Cục máu đông nằm trong khoảng không gian hẹp của mạch máu và gây ra sự tắc nghẽn khi cản trở máu lưu thông, kết quả là dẫn đến đột quỵ thiếu máu cục bộ. Xơ vữa động mạch tạo điều kiện thuận lợi cho việc dễ dàng hình thành cục máu đông. Đột quỵ xuất huyết não thường là do huyết áp cao không kiểm soát khiến động mạch bị suy yếu và vỡ ra.
### **10. Yếu tố nguy cơ do các bệnh mạn tính nào gây ra?**
– Huyết áp cao – Cholesterol cao – Bệnh tiểu đường – Béo phì Nguy cơ đột quỵ sẽ giảm đi nếu bạn kiểm soát tốt các bệnh này.
### **11. Các yếu tố nguy cơ do hành vi gây ra?**
Một số hành vi làm tăng nguy cơ đột quỵ: – Hút thuốc lá – Tập thể dục quá ít – Sử dụng nhiều rượu, bia
### **12. Các yếu tố nguy cơ do chế độ ăn uống gây ra?**
Chế độ ăn uống không phù hợp cũng làm tăng đáng kể nguy cơ đột quỵ. Chế ăn nhiều trái cây, rau củ quả, hạt ngũ cốc và cá giúp làm giảm nguy cô đột quỵ.
### **13. Các yếu tố nguy cơ nằm ngoài tầm kiểm soát của bạn là gì?**
Một số yếu tố nguy cơ nằm ngoài tầm kiểm soát của bạn như sự lão hóa hoặc tiền sử gia đình có người bị đột quỵ. Giới tính cũng đóng 1 vai trò quan trọng, nam giới có nguy cơ đột quỵ cao hơn so với nữ giới. Tuy nhiên, ở phụ nữ xảy ra các ca đột quỵ gây tử vong cao hơn. Cuối cùng là yếu tố quan trọng nhất là chủng tộc. Các chủng tộc người Mỹ ở Bắc Phi, người Mỹ bản xứ và người bản địa Alaska có nguy cơ cao hơn so với các chủng tộc khác.
### **14. Điều trị khẩn cấp trong đột quỵ như thế nào?**
Đối với tình trạng đột quỵ do thiếu máu cục bộ, điều trị khẩn cấp tập trung vào dùng thuốc để phục hồi lưu lượng máu. Một loại thuốc tiêu huyết khối mang lại hiệu quả cao trong việc làm tan cục máu đông và làm giảm tổn thương lâu dài cho bệnh nhân, việc dùng các thuốc tiêu huyết khối phải càng nhanh càng tốt, thuốc phải được dùng trong vòng 3h sau khi bắt đầu các triệu chứng và chậm nhất 4,5h. Đột quỵ xuất huyết ra khó điều trị hơn, bác sĩ cần phải cố gắng kiểm soát huyết áp bệnh nhân, làm ngưng xuất huyết và phù não.
### **15. Tổn thương lâu dài do đột quỵ gây ra?**
Tuy đột quỵ gây ra các tổn thương lâu dài hay không thì phụ thuộc vào mức độ nghiêm trọng và phương pháp điều trị như thế nào để làm ổn định não nhanh chóng. Loại tổn thương do đột quỵ gây ra phụ thuộc vào vùng não nơi đột quỵ xảy ra. Các tổn thương do đột quỵ ra thường gặp là tê và/hoặc yếu ở cánh tay, chân; khó đi lại; các vấn đề liên quan đến thị lực và khó nuốt; các vấn đề liên quan đến rối loạn ngôn như như lời nói hoặc khó hiểu được lời người khác nói. Các tổn thương này có thể vĩnh viễn nhưng cũng đã có nhiều người phục hồi lại những khả năng của mình.
### **16. Phục hồi sau đột quỵ bằng trị liệu ngôn ngữ.**
Phục hồi chức năng là giai đoạn quan trọng nhất trong quá trình hồi phục sau đột quỵ. Nó giúp bệnh nhân phục hồi lại những kỹ năng đã mất và học cách bù đắp lại những thương tổn không thể hồi phục ở bản thân. Mục đích chính là giúp khôi phục tính độc lập ở bệnh càng nhiều càng tốt. Đối với những người gặp khó khăn do rối loạn ngôn ngữ thì việc trị liệu ngôn ngữ là cần thiết và quan trọng. Đối với những bệnh nhân khó nuốt, liệu pháp này là sự lựa chọn hợp lý.
### **17. Phục hồi sau đột quỵ bằng vật lý trị liệu.**
Các vấn đề liên quan đến thăng bằng và yếu cơ rất phổ biến sau đột quỵ. Mất thăng bằng và yếu cơ gây cản trở trong việc đi đứng và sinh hoạt thường ngày của bệnh nhân. Vật lý trị liệu là một cách hiệu quả để lấy lại sức mạnh, cân bằng và sự phối hợp. Đối với các hoạt động yêu cầu kỹ năng chính xác, như sử dụng dao và nĩa, viết và cài khuy ( cài nút) áo thì liệu pháp lao động có thể giúp ích.
### **18. Phục hồi chức năng sau đột quỵ bằng liệu pháp trò chuyện.**
Người sống sót sau đột quỵ và những người thân bên cạnh họ thường trải qua rất nhiều cảm xúc mãnh liệt khác nhau như sợ hãi, tức giận, lo lắng và đau buồn. Một nhà tâm lý học hoặc cố vấn sức khỏe tâm thần có thể hướng dẫn cho bạn các biện pháp đối phó với những cảm xúc này. Một bác sĩ chuyên khoa tâm lý có thể quan sát các triệu chứng của bệnh trầm cảm, căn bệnh thường xảy ra ở những người phục hồi sau đột quỵ.
### **19. Phòng chống đột quỵ bằng thay đổi lối sống như thế nào?**
Những người bị đột quỵ hoặc đột quỵ thoáng qua (TIA – Transient Ischemic Attack) có thể thực hiện các biện pháp này để ngăn ngừa tái phát: – Bỏ hút thuốc lá. – Tập thể dục đều đặn và duy trì trọng lượng cơ thể khỏe mạnh. – Hạn chế uống rượu, bia và lượng muối hấp thu vào cơ thể. – Có một chế độ ăn uống lành mạnh với nhiều rau, cá và các loại ngũ cốc nguyên hạt.
### **20. Phòng chống đột quỵ bằng thuốc?**
Đối với những đối tượng có nguy cơ đột quỵ cao, bác sĩ thường khuyên họ dùng thuốc để giảm nguy cơ đột quỵ. Thuốc chống kết tập tiểu cầu bao gồm aspirin, có tác dụng làm các tiểu cầu không dính vào nhau từ đó sẽ không hình thành cục máu đông. Thuốc chống đông máu, chẳng hạn như warfarin, có thể được sử dụng để dự phòng đột quỵ. Cuối cùng, nếu bạn bị huyết áp cao, bác sĩ kê toa thuốc để hạ huyết áp.
### **21. Phòng chống đột quỵ bằng phẫu thuật.**
Trong một số trường hợp, động mạch cảnh bị hẹp là nguyên nhân gây ra đột quỵ – các mạch máu nằm ở bên cổ có vai trò vận chuyển máu lên não. Những người đã từng bị đột quỵ thoáng qua hoặc hoặc đột quỵ nhẹ do động mạch cảnh bị hẹp có thể được phẫu thuật để cắt bỏ nội mạc động mạch cảnh – là một tiến trình phẫu thuật làm sạch các mảng vữa và làm thông các động mạch cảnh bị hẹp ở cổ.
Ngoài ra , bác sĩ có thể điều trị tắc nghẽn động mạch cảnh mà không cần can thiệp bằng phương pháp phẫu thuật trong một số trường hợp. Thủ thuật này gọi là thủ thuật nong mạch, bác sĩ sẽ đặt một ống thông vào động mạch và bơm một bóng nhỏ với mục đích là mở rộng diện tích động mạch đã bị mảng bám làm hẹp. Đồng thời, một ống kim loại có thể được chèn vào, gọi là ống stent, để giữ cho động mạch luôn mở rộng.
### **23. Cuộc sống sau đột quỵ như thế nào?**
Nhiều bệnh nhân đột quỵ có thể phục hồi lại khả năng tự chăm sóc bản thân. Những bệnh nhân được điều trị bằng thuốc tiêu huyết khối sớm và kịp thời, họ có thể khôi phục hoàn toàn. Những bệnh nhân có các thương tổn dẫn đến tình trạng khuyết tật có thể học cách hoạt động độc lập thông qua các liệu pháp. Tất cả các bệnh nhân đột quỵ lần thứ nhất sẽ trải qua một cơn đột quỵ lần thứ hai, tỷ lệ này chiếm khoảng từ 3%-4%.
  * [1. Đột quỵ là gì? ](https://bvnguyentriphuong.com.vn/hoi-dap/22-cau-hoi-va-tra-loi-ve-dot-quy-nao#1-t-qu-l-g)
  * [2. Các triệu chứng của đột quỵ là gì? ](https://bvnguyentriphuong.com.vn/hoi-dap/22-cau-hoi-va-tra-loi-ve-dot-quy-nao#2-cc-triu-chng-ca-t-qu-l-g)
  * [3. Khám nghiệm nào để kiểm tra các đối tượng có nguy cơ đột quỵ?](https://bvnguyentriphuong.com.vn/hoi-dap/22-cau-hoi-va-tra-loi-ve-dot-quy-nao#3-khm-nghimno-kim-tra-cc-i-tng-c-nguy-c-t-qu)
  * [4. Trong đột quỵ: Tại sao thời gian = tổn thương não? ](https://bvnguyentriphuong.com.vn/hoi-dap/22-cau-hoi-va-tra-loi-ve-dot-quy-nao#4-trong-t-qu-ti-sao-thi-gian-tn-thng-no)
  * [5. Chẩn đoán đột quỵ như thế nào?](https://bvnguyentriphuong.com.vn/hoi-dap/22-cau-hoi-va-tra-loi-ve-dot-quy-nao#5-chn-on-t-qu-nh-th-no)
  * [6. Đột quỵ thiếu máu cục bộ là gì? ](https://bvnguyentriphuong.com.vn/hoi-dap/22-cau-hoi-va-tra-loi-ve-dot-quy-nao#6-t-qu-thiu-mu-cc-b-l-g)
  * [7. Đột quỵ xuất huyết não là gì?](https://bvnguyentriphuong.com.vn/hoi-dap/22-cau-hoi-va-tra-loi-ve-dot-quy-nao#7-t-qu-xut-huyt-no-l-g)
  * [8. Đột quỵ thoáng qua (TIA – Transient Ischemic Attack) là gì?](https://bvnguyentriphuong.com.vn/hoi-dap/22-cau-hoi-va-tra-loi-ve-dot-quy-nao#8-t-qu-thong-qua-tia-transient-ischemic-attack-l-g)
  * [9. Nguyên nhân nào gây ra đột quỵ? ](https://bvnguyentriphuong.com.vn/hoi-dap/22-cau-hoi-va-tra-loi-ve-dot-quy-nao#9-nguyn-nhn-no-gy-ra-t-qu)
  * [10. Yếu tố nguy cơ do các bệnh mạn tính nào gây ra? ](https://bvnguyentriphuong.com.vn/hoi-dap/22-cau-hoi-va-tra-loi-ve-dot-quy-nao#10-yu-t-nguy-c-do-cc-bnh-mn-tnh-no-gy-ra)
  * [11. Các yếu tố nguy cơ do hành vi gây ra? ](https://bvnguyentriphuong.com.vn/hoi-dap/22-cau-hoi-va-tra-loi-ve-dot-quy-nao#11-cc-yu-t-nguy-c-do-hnh-vi-gy-ra)
  * [12. Các yếu tố nguy cơ do chế độ ăn uống gây ra?](https://bvnguyentriphuong.com.vn/hoi-dap/22-cau-hoi-va-tra-loi-ve-dot-quy-nao#12-cc-yu-t-nguy-c-do-ch-n-ung-gy-ra)
  * [13. Các yếu tố nguy cơ nằm ngoài tầm kiểm soát của bạn là gì?](https://bvnguyentriphuong.com.vn/hoi-dap/22-cau-hoi-va-tra-loi-ve-dot-quy-nao#13-cc-yu-t-nguy-c-nm-ngoi-tm-kim-sot-ca-bn-l-g)
  * [14. Điều trị khẩn cấp trong đột quỵ như thế nào? ](https://bvnguyentriphuong.com.vn/hoi-dap/22-cau-hoi-va-tra-loi-ve-dot-quy-nao#14-iu-tr-khn-cp-trong-t-qu-nh-th-no)
  * [15. Tổn thương lâu dài do đột quỵ gây ra? ](https://bvnguyentriphuong.com.vn/hoi-dap/22-cau-hoi-va-tra-loi-ve-dot-quy-nao#15-tn-thng-lu-di-do-t-qu-gy-ra)
  * [16. Phục hồi sau đột quỵ bằng trị liệu ngôn ngữ.](https://bvnguyentriphuong.com.vn/hoi-dap/22-cau-hoi-va-tra-loi-ve-dot-quy-nao#16-phc-hi-sau-t-qu-bng-tr-liu-ngn-ng)
  * [17. Phục hồi sau đột quỵ bằng vật lý trị liệu.](https://bvnguyentriphuong.com.vn/hoi-dap/22-cau-hoi-va-tra-loi-ve-dot-quy-nao#17-phc-hi-sau-t-qu-bng-vt-l-tr-liu)
  * [18. Phục hồi chức năng sau đột quỵ bằng liệu pháp trò chuyện. ](https://bvnguyentriphuong.com.vn/hoi-dap/22-cau-hoi-va-tra-loi-ve-dot-quy-nao#18-phc-hi-chc-nng-sau-t-qu-bng-liu-php-tr-chuyn)
  * [19. Phòng chống đột quỵ bằng thay đổi lối sống như thế nào?](https://bvnguyentriphuong.com.vn/hoi-dap/22-cau-hoi-va-tra-loi-ve-dot-quy-nao#19-phng-chng-t-qu-bng-thay-i-li-sng-nh-th-no)
  * [20. Phòng chống đột quỵ bằng thuốc? ](https://bvnguyentriphuong.com.vn/hoi-dap/22-cau-hoi-va-tra-loi-ve-dot-quy-nao#20-phng-chng-t-qu-bng-thuc)
  * [21. Phòng chống đột quỵ bằng phẫu thuật. ](https://bvnguyentriphuong.com.vn/hoi-dap/22-cau-hoi-va-tra-loi-ve-dot-quy-nao#21-phng-chng-t-qu-bng-phu-thut)
  * [23. Cuộc sống sau đột quỵ như thế nào?](https://bvnguyentriphuong.com.vn/hoi-dap/22-cau-hoi-va-tra-loi-ve-dot-quy-nao#23-cuc-sng-sau-t-qu-nh-th-no)



## Tại sao điều trị béo phì lại lắm gian nan ?

Béo phì là một bệnh do tình trạng tích trữ mỡ quá mức trong cơ thể. Theo phân loại của Bộ Y tế, người được xem là béo phì khi có chỉ số khối cơ thể (BMI) trên 25 kg/m2, nếu chỉ số BMI trên 35 kg/m2 thì được coi là béo phì mức độ trầm trọng. Vấn đề lớn nhất của những bệnh nhân này gồm thân hình quá khổ gây rất nhiều khó khăn, bế tắc trong cuộc sống và thường mang trên người rất nhiều bệnh tật do béo phì gây ra.
Nhiều bệnh nhân bị tiểu đường, huyết áp cao, khó thở, thoái hóa khớp... khi còn rất trẻ. Hầu hết bệnh nhân dành rất nhiều thời gian, tiền bạc cùng với mọi sự nỗ lực của mình để giảm cân nhưng không thể thành công. Chế độ ăn kiêng chỉ kéo dài được vài ngày, sau đó họ không thể chống cự cảm giác đói và ăn khối lượng nhiều hơn trước khi kiêng. Họ cũng khó tập luyện thể chất do cơ thể quá nặng và đau khớp.
Nhiều người bế tắc và lo lắng, tìm đến các loại thực phẩm chức năng dù hoàn toàn không biết thành phần của thực phẩm. Một số bệnh nhân đến trung tâm thẩm mỹ để hút mỡ hoặc tiêm các chất không rõ nguồn gốc vào cơ thể, dẫn đến những hậu quả khôn lường, ảnh hưởng rất lớn đến sức khỏe, kinh tế và cả hạnh phúc gia đình.
Chia sẻ của một bệnh nhân nữ, rằng biết cơ thể sẽ có rất nhiều bệnh khi quá béo, song không thể chịu đựng cơn đói. Chị triền miên sống trong căng thẳng, với vòng lẩn quẩn càng cố giảm ăn thì càng đói, ăn vào thì lại tăng cân ngay; lo lắng khiến cảm giác thèm ăn tăng vọt.
Có bệnh nhân nói chỉ thấy đồ ăn khi ngủ mơ, càng béo thì càng ngại vận động, ăn xong chỉ muốn nằm. Rất nhiều bệnh nhân rơi vào tình trạng bế tắc, tuyệt vọng sau nhiều năm giảm cân bất thành. Một số bệnh nhân có tâm lý muốn buông xuôi, mặc kệ cơ thể bệnh tật, chỉ ăn cho thỏa mãn cảm xúc của mình, từ đó đánh mất tương lai và cả cuộc đời. Đây cũng là chướng ngại lớn nhất trong quá trình giảm béo.
Người béo phì có ham muốn ăn uống luôn vượt quá tầm kiểm soát của bản thân. Đây không phải mong muốn của chính bệnh nhân. Thêm vào đó, người xung quanh không hiểu họ đang bị bệnh, rối loạn về tâm lý và quá trình chuyển hóa, nội tiết, trao đổi chất, nên không có thái độ cảm thông. Bước tư vấn tâm lý rất quan trọng, nhằm đưa bệnh nhân ra khỏi bế tắc, tâm trạng muốn buông xuôi, tuyệt vọng, tạo động lực và niềm tin về khả năng có thể chiến thắng béo phì, tránh mọi thái độ kỳ thị với người bệnh. Thầy thuốc cần xây dựng kế hoạch điều trị và mục tiêu một cách rõ ràng. Quan trọng nhất là cung cấp những kiến thức về bệnh béo phì và các phương pháp điều trị khoa học, có đủ tài liệu nghiên cứu lớn của thế giới và bằng chứng cụ thể về các trường hợp béo phì đã điều trị thành công.
Suốt quá trình giảm cân, người bệnh phải tăng cường luyện tập thể chất, duy trì đều đặn; sử dụng thuốc giảm cân dưới sự kiểm soát chặt chẽ của bác sĩ. Phương pháp phẫu thuật giảm cân bằng thu nhỏ dạ dày hoặc các phương pháp phẫu thuật khác trên đường tiêu hóa, được xem xét khi bệnh nhân béo phì trầm trọng. Bệnh nhân béo phì trầm trọng là những người có chỉ số BMI từ 35 trở lên, béo phì độ I, độ II có kèm theo các bệnh kết hợp; hoặc khi bệnh nhân đã áp dụng tất cả giải pháp khác không thành công.
Người béo phì cần chỗ dựa, điểm tựa tinh thần, người bạn đồng hành suốt đời, giúp họ vượt qua kỳ thị của xã hội, sự tự ti, thêm niềm tin và động lực chiến thắng béo phì. "Có thể quá trình này phải mất nhiều năm, nhưng công sức bỏ ra không vô nghĩa", các chuyên gia chia sẻ

## Điều gì khiến nhiệt độ cơ thể thay đổi ? Thân nhiệt bình thường có luôn giống nhau ?

Vùng dưới đồi ở não điều chỉnh nhiệt độ cơ thể. Nếu nhiệt độ cơ thể tăng cao hơn hoặc giảm xuống dưới mốc 37°C thì vùng dưới đồi sẽ hoạt động để điều chỉnh nhiệt độ. Nếu cơ thể quá lạnh, vùng dưới đồi sẽ gửi tín hiệu khiến cơ thể rùng mình, làm ấm cơ thể. Nếu cơ thể quá nóng, vùng dưới đồi sẽ gửi tín hiệu bắt đầu đổ mồ hôi, để nhiệt thoát ra khỏi cơ thể.
Nhiễm trùng gây ra hầu hết các cơn sốt. Sốt là cách phản ứng tự nhiên của cơ thể và chống lại nhiễm trùng. Sốt là khi nhiệt độ cơ thể từ 38°C. Các triệu chứng khác bao gồm:
  * Chán ăn
  * Ớn lạnh
  * Đau đầu
  * Cáu gắt
  * Đau cơ
  * Rùng mình
  * Đổ mồ hôi
  * Mệt mỏi


**Thân nhiệt**
Các chỉ số nhiệt độ cơ thể khác nhau tùy thuộc vào vị trí đo trên cơ thể. Ví dụ, đo nhiệt độ ở trực tràng cao hơn khi đo ở miệng, trong khi đo nhiệt độ ở nách có xu hướng thấp hơn. Chỉ số nhiệt độ cơ thể cũng có thể thay đổi tùy thuộc vào các yếu tố sau:
  * Tuổi tác
  * Thời điểm trong ngày, thường thấp nhất vào sáng sớm và cao nhất vào cuối buổi chiều
  * Hoạt động gần đây
  * Lượng thức ăn và chất lỏng bạn nạp vào


_Nhiệt độ bình thường ở người lớn_
Theo các đánh giá, nhiệt độ cơ thể trung bình của người trưởng thành là khoảng 36,59°C. Các nhà nghiên cứu cũng phát hiện ra rằng nhiệt độ cơ thể trung bình của người trưởng thành khi đo ở miệng rơi vào khoảng 36,24 - 37°C.
Nhiệt độ cơ thể trung bình có thể khác nhau tùy theo nhân khẩu học. Một nghiên cứu của gần 35.500 người cho thấy rằng người lớn tuổi có nhiệt độ thấp nhất và phụ nữ Mỹ gốc Phi có nhiệt độ cao hơn nam giới da trắng.
Các nhà nghiên cứu cũng phát hiện ra rằng một số tình trạng sức khỏe có thể ảnh hưởng đến nhiệt độ cơ thể. Ví dụ, những người có tuyến giáp hoạt động kém (suy giáp) thường có nhiệt độ thấp hơn, trong khi những người bị ung thư có nhiệt độ cao hơn.
_Nhiệt độ bình thường ở trẻ em_
Nhiệt độ cơ thể trung bình của trẻ em là khoảng 36,4°C, nhưng nhiệt độ này có thể thay đổi. Cũng như người lớn, trẻ có nhiệt độ trên 38°C có thể cho thấy trẻ bị sốt.
_Nhiệt độ bình thường ở trẻ sơ sinh_
Trẻ sơ sinh thường có nhiệt độ cơ thể cao hơn so với trẻ lớn hơn và người lớn. Nhiệt độ cơ thể trung bình của trẻ sơ sinh là khoảng 37,5°C. Nhiệt độ của trẻ sơ sinh cao hơn vì chúng có diện tích bề mặt cơ thể lớn hơn so với trọng lượng cơ thể. Cơ thể của trẻ cũng hoạt động trao đổi chất nhiều hơn, tạo ra nhiệt. Cơ thể trẻ sơ sinh không điều nhiệt tốt như cơ thể người lớn. Trẻ đổ mồ hôi ít hơn khi trời nóng, nghĩa là cơ thể trẻ giữ nhiệt nhiều hơn. Bên cạnh đó, trẻ cũng có thể khó hạ nhiệt hơn khi bị sốt.
_Nhiệt độ bình thường khi mang thai_
Khi mang thai, tỷ lệ trao đổi chất cơ bản sẽ tăng lên. Điều này có nghĩa là cơ thể tạo ra nhiều nhiệt hơn. Một nghiên cứu cho thấy nhiệt độ cơ thể đạt đỉnh ở 35,6 - 37,5°C vào khoảng tuần thứ 12 của thai kỳ. Nhiệt độ cơ thể trung bình đạt thấp nhất khoảng 35,3 - 37,3°C ngay sau tuần thứ 33.

## Cơ hội tầm soát chậm tăng trưởng chiều cao miễn phí cho trẻ dịp hè 2023

Để tham gia chương trình, từ ngày **05/06/2023 đến ngày 03/07/2023** , phụ huynh có thể gọi điện thoại đăng ký qua hotline:
  * **0335 116 057 hoặc 0932 714 440**
  * Trong khung giờ**8h - 17h.**


_***Lưu ý: Để được khám tầm soát, trẻ cần được đăng ký trước qua số hotline trên. Mỗi phụ huynh chỉ đăng ký 1 lần qua 1 trong 2 số hotline trên. Bộ phận tiếp nhận đăng ký sẽ có những câu hỏi sàng lọc để chọn đúng đối tượng tiếp nhận thăm khám, nâng cao hiệu quả chương trình tầm soát.**_
_Tầm soát chậm tăng trưởng chiều cao miễn phí cho trẻ là chương trình hỗ trợ cộng đồng thường niên của khoa Nội tiết bệnh viện Nguyễn Tri Phương_
Bắt đầu được triển khai từ năm 2017, tính đến nay, chương trình đã tầm soát miễn phí cho hơn 2000 trẻ. Tổng số trẻ được chẩn đoán thiếu GH là hơn 200 trẻ. Trong năm nay, chương trình diễn ra trong 4 tuần, dự kiến sẽ tiếp nhận khoảng hơn 400 trẻ đến thăm khám.
_Từ 4 tuổi trở đi, phụ huynh cần chú ý nhiều hơn đến tốc độ tăng trưởng chiều cao của trẻ._
Chương trình tầm soát được áp dụng cho trẻ trước tuổi dậy thì và sẽ bao gồm các bước kiểm tra chiều cao, cân nặng và khảo sát các triệu chứng chậm tăng trưởng để đưa ra những giải pháp điều trị phù hợp. Trẻ cũng được chụp X - Quang xương bàn tay miễn phí khi có chỉ định để được đánh giá tuổi xương. Từ đó, các bác sĩ sẽ tư vấn về vấn đề phát triển chiều cao của trẻ là bình thường hay bất thường. Những trường hợp nghi ngờ chậm tăng trưởng chiều cao sẽ được hướng dẫn các bước xử trí tiếp theo, bao gồm việc xét nghiệm máu để định lượng chính xác GH và một số hormone liên quan khác trong cơ thể. 
_Cung cấp những thông tin về tiền sử lúc sinh, tiền sử gia đình giúp bác sĩ có được những đánh giá sơ bộ về sự phát triển của trẻ_
Lưu ý, khi tham gia tầm soát, phụ huynh cần cung cấp những thông tin về tiền sử lúc sinh, tiền sử bệnh tật, tiền sử gia đình, tốc độ tăng trưởng chiều cao của trẻ trong 6 tháng trở lên để các bác sĩ có những đánh giá sơ bộ bước đầu. 
Thông thường, trẻ mới sinh có chiều cao 48-52cm, trong năm đầu bé tăng khoảng 20-25cm, sang năm thứ 2 tăng 12cm, năm thứ 3 tăng 10 cm, năm thứ 4 tăng 7cm. Từ 4 tuổi trở đi, phụ huynh cần chú ý nhiều hơn đến tốc độ tăng trưởng chiều cao của trẻ. Từ năm 4-11 tuổi, trẻ sẽ tăng trung bình 4-6cm/nămĐến tuổi dậy thì, bé gái tăng khoảng 6 - 10 cm mỗi năm. Bé trai tăng từ 6,5 - 11 cm mỗi năm. Trường hợp trẻ không đạt được các mốc tăng trưởng về chiều cao theo từng độ tuổi, cha mẹ nên nghĩ ngay đến việc cho trẻ đi khám và tầm soát chậm tăng trưởng chiều cao sớm. 
Có nhiều yếu tố chi phối sự phát triển chiều cao của trẻ, bao gồm: di truyền, dinh dưỡng, môi trường sống, chế độ sinh hoạt, thể dục thể thao, GH… Trong đó, yếu tố di truyền là không thể thay đổi được. Riêng trường hợp chậm tăng trưởng do thiếu GH, theo thống kê, trên thế giới, ước tính chỉ chiếm tỷ lệ khoảng 1/3000 - 1/4.000 nhưng đây là một trong những nguyên nhân quan trọng dẫn đến chậm tăng trưởng ở trẻ em và rất khó nhận biết. 
Nếu không được điều trị, trẻ thiếu GH có chiều cao trung bình chỉ từ 135 - 145 cm, thấp hơn nhiều so với chiều cao tối đa có thể đạt được. Điều này không chỉ ảnh hưởng đến công việc, cuộc sống sau này của trẻ mà còn có thể khiến tâm lý của trẻ bị ảnh hưởng vì sự mặc cảm, tự ti khi so với bạn bè đồng trang lứa. 
**Bác sĩ Trần Thị Ngọc Anh - Khoa Nội tiết, Bệnh viện Nguyễn Tri Phương cho biết:** _“Nếu xác định bệnh nhi bị thiếu GH và cần thiết điều trị, bác sĩ sẽ chỉ định bổ sung GH mỗi ngày. Trẻ thiếu GH được điều trị sớm (ngay từ lúc trẻ bắt đầu chậm tăng trưởng chiều cao) sẽ thấy rõ hiệu quả, trẻ sẽ phát triển gần như trẻ em bình thường khác. Trong một số trường hợp, điều trị sớm có thể giúp trẻ đạt chiều cao bình thường hoặc gần như bình thường theo di truyền từng trẻ. Giai đoạn vàng để điều trị chậm tăng trưởng chiều cao cho trẻ là trước tuổi dậy thì vì sau giai đoạn này, sụn xương trẻ sẽ đóng lại, việc điều trị sẽ không còn hiệu quả. Hiện tại, bệnh viện Nguyễn Tri Phương cũng đang điều trị cho khoảng hơn 80 trẻ chậm tăng trưởng do thiếu GH.”_
Trẻ được chẩn đoán chậm tăng trưởng do thiếu GH được chỉ định bổ sung GH. Mục tiêu của việc điều trị này là để thay thế sự thiếu hụt GH cho sự phát triển chiều cao, các hoạt động chuyển hóa và tình trạng sức khỏe nói chung. Sau 3-6 tháng điều trị, trẻ sẽ được đo lại chiều cao và xét nghiệm máu để đánh giá kết quả và điều chỉnh liều thuốc nếu cần. Trẻ đáp ứng với điều trị sẽ tăng chiều cao từ 8-12 cm/năm. Khi đến tuổi dậy thì, trẻ sẽ được đánh giá lại xem có tiếp tục bổ sung GH hay ngưng bổ sung. Để việc điều trị GH đạt hiệu quả, cần tiến hành đúng thời điểm, đúng liều lượng, tốt nhất trong khoảng độ tuổi 4-13 tuổi. Nếu qua thời gian này, các sụn xương của trẻ đóng lại, dùng hormone tăng trưởng không còn tác dụng.
Trên thực tế, nhiều trường hợp trẻ đến khám tại bệnh viện sau thời gian điều trị hoặc can thiệp dinh dưỡng không hiệu quả. Khi được xác định đúng nguyên nhân gây chậm cao do thiếu GH và tuân thủ theo phác đồ điều trị của bác sĩ, trẻ được cải thiện chiều cao đáng kể, nhiều phụ huynh rất hạnh phúc, bản thân trẻ cũng cảm thấy tự tin hơn.

## Ăn quá nhiều muối còn có thể gây đau đầu.

  * [Tiểu tiện thường xuyên](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/an-qua-nhieu-muoi-con-co-the-gay-dau-dau#tiu-tin-thng-xuyn)
  * [Thèm đồ ăn mặn](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/an-qua-nhieu-muoi-con-co-the-gay-dau-dau#thm-n-mn)


Lượng muối dư trong cơ thể dù không ảnh hưởng trực tiếp tới các hoạt động thể chất nhưng vẫn gây sự trì trệ tới quá trình vận động do cảm giác nặng nề, đầy hơi sau khi ăn quá mặn. Những triệu chứng dưới đây có thể xảy ra do ăn mặn:
## Đau đầu
Việc nạp quá nhiều natri trong muối sẽ khiến các mạch máu trong não giãn nở và có thể dẫn đến bị nhức đầu. Ngoài ra, việc mất nước do ăn quá nhiều muối còn gây ra các triệu chứng như buồn nôn, chóng mặt và nôn mửa và khiến cơn đau đầu trở nên dữ dội hơn.
Chuyên gia khuyến nghị nên uống nhiều nước lọc để thải bớt natri ra ngoài và giảm tình trạng đau đầu.
## Khát nước
Việc thừa muối do nồng độ natri quá cao gây ra tình trạng thiếu chất lỏng trong cơ thể. Hiện tượng khát nước và khô miệng là dấu hiệu của việc cơ thể đang cần bổ sung nước để trở lại trạng thái cân bằng.
Để khắc phục tình trạng này, cần bổ sung nước và điều chỉnh lại chế độ ăn hàng ngày để đảm bảo sức khỏe.
## Tiểu tiện thường xuyên
Khi nạp quá nhiều nước trong một thời gian ngắn, nhu cầu đào thải nước của cơ thể trở nên tăng cao dẫn đến việc số lần tiểu tiện cũng thay đổi.
Bên cạnh đó, việc ăn quá nhiều muối trong một thời gian dài sẽ làm tăng nguy cơ mắc các bệnh về thận, tim mạch và huyết áp.
## Thèm đồ ăn mặn
Thói quen bỏ thêm muối vào tất cả các món ăn ảnh hưởng xấu tới sức khỏe. Khi cơ thể đã thích nghi với thức ăn có nồng độ muối cao sẽ khó để có thể tiếp thu các loại món ăn khác có mùi vị nhạt hơn.
Để thoát khỏi thói quen xấu này, chuyên gia dinh dưỡng khuyến nghị cắt giảm từ từ lượng muối khỏi khẩu phần ăn, rồi thêm vào thực đơn các gia vị từ thảo mộc và thực vật. Khi đi ăn bên ngoài, hãy chọn những món ăn nhạt hoặc có thể yêu cầu người phục vụ cho ít muối hơn khi chế biến món ăn.
_**Theo Bộ Y tế, tại Việt Nam, kết quả điều tra toàn quốc năm 2015 cho thấy, trung bình một người trưởng thành tiêu thụ 9,4 gr muối trong 1 ngày, nghĩa là cao gấp đôi so với khuyến cáo.**_
Nên giảm muối bằng các cách: giảm lượng muối và gia vị mặn cho vào khi chế biến thức ăn. Hạn chế sử dụng và hạn chế lượng muối, gia vị, nước chấm đặt trên bàn ăn trong khi ăn, chấm nhẹ tay để bớt lượng muối mặn. Hạn chế lựa chọn hay sử dụng thực phẩm có nhiều muối để giảm đồ ăn mặn.
  * [Tiểu tiện thường xuyên](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/an-qua-nhieu-muoi-con-co-the-gay-dau-dau#tiu-tin-thng-xuyn)
  * [Thèm đồ ăn mặn](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/an-qua-nhieu-muoi-con-co-the-gay-dau-dau#thm-n-mn)



## Dễ ngủ và ngủ nhanh với một số kỹ thuật hỗ trợ

**Kỹ thuật 10 giây**
Kỹ thuật 10 giây là phương pháp đơn giản và hiệu quả, dựa trên nguyên tắc thư giãn và chánh niệm, giúp bạn chìm vào giấc ngủ nhanh chóng. Gồm các bước:
1. Chuẩn bị môi trường ngủ với một căn phòng tối, mát và yên tĩnh. Một môi trường ngủ lý tưởng là yếu tố quan trọng giúp bạn nhanh đi vào giấc ngủ.
2. Hít một hơi thật sâu và dồn sự chú ý vào hơi thở của mình. Mũi hít vào từ từ trong 4 giây, rồi chậm rãi thở ra bằng miệng trong 6 giây. Lặp lại một vài lần.
3. Trong khi thở sâu, cảm nhận cơ thể từ đầu đến chân, thả lỏng mọi căng thẳng.
4. Hình dung về một nơi yên tĩnh như một bãi biển yên bình hay một cánh rừng tươi tốt. Thu hút các giác quan của mình bằng cách tưởng tượng âm thanh của sóng vỗ, hương thơm của các loại cây...
5. Với mỗi lần thở ra, hãy để cơ thể và tâm trí của mình trong trạng thái tĩnh tại và yên bình, cho phép bản thân chìm vào giấc ngủ với cảm giác an toàn và được nâng đỡ.
Bằng cách thực hành kỹ thuật này thường xuyên, bạn có thể đạt được trạng thái thư giãn sâu chỉ trong vòng 10 giây và học được cách ngủ nhanh.
**Kỹ thuật 60 giây**
Kỹ thuật 60 giây được xây dựng dựa trên các nguyên tắc của kỹ thuật 10 giây và kết hợp thêm các bài tập thư giãn. Gồm các bước:
1. Chuẩn bị môi trường ngủ bằng cách đảm bảo căn phòng tối, mát và yên tĩnh.
2. Nằm ngửa, hai tay đặt bên hông và nhắm mắt lại. Hít một vài hơi thật sâu, để cơ thể ổn định trên nệm
3. Thả lỏng từng nhóm cơ trên cơ thể. Bắt đầu từ ngón chân và tiến lên, mỗi thời điểm tập trung vào từng khu vực một.
4. Khi bạn tiếp tục hít thở sâu, hãy hình dung mình đang ở trong một không gian yên bình, có thể cảm nhận sự ấm áp của mặt trời hay sự mềm mại của cỏ dưới chân.
5. Lặp lại một câu thần chú hoặc cụm từ nhẹ nhàng cho chính mình, chẳng hạn như “Tôi bình tĩnh và sẵn sàng để ngủ”. Bằng việc chuyển những suy nghĩ của bạn sang những lời khẳng định tích cực, sẽ giúp làm dịu những băn khoăn trong bạn. Đó là một trong những cách tốt nhất để chìm vào giấc ngủ.
**Kỹ thuật 120 giây**
Phương pháp này kết hợp các kỹ thuật thư giãn, bài tập thở và sự tưởng tượng có hướng dẫn để thúc đẩy vào giấc ngủ nhanh. Thực hiện các bước như sau:
1. Tạo môi trường ngủ thoải mái.
2. Nằm ngừa, hai tay thả lỏng hai bên. Hãy dành một chút thời gian để nhận thức về cơ thể của mình và giải phóng mọi căng thẳng đang tồn tại.
3. Hít vào một hơi thật sâu trong 4 giây, rồi nín thở trong 7 giây và thở ra từ từ. Lặp lại một vài lần.
4. Tập trung thư giãn cơ mặt, cơ quanh mắt, buông bỏ mọi căng thẳng.
5. Hình dung mình đang ở một nơi thanh bình như bãi biển đẹp, khu vườn đẹp...
6. Bắt đầu thư giãn từng bộ phận trên cơ thể một cách có hệ thống. Cảm nhận thư giãn mọi cơ trên cơ thể, bắt đầu từ ngón chân.
7. Khi bạn thư giãn, hãy giải tỏa tâm trí khỏi mọi suy nghĩ hay lo lắng. Nếu bất kỳ suy nghĩ nào xuất hiện, hãy nhẹ nhàng thừa chấp nhận nó và để nó qua đi.
8. Lặp lại một câu thần chú hoặc cụm từ để làm dịu chính mình như đã đề cập ở trên, hãy để những từ đó vang trong tâm trí, giúp củng cố cảm giác bình yên.
9. Tiếp tục hít thở sâu và nhịp nhàng. Điều chỉnh hơi thở của mình theo nhịp điệu yên bình của không gian mà bạn tưởng tượng.

## 8 CÂU HỎI VỀ BỆNH GAN NHIỄM MỠ (NAFLD)

  * [NAFLD và NASH là gì?](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/8-cau-hoi-ve-benh-gan-nhiem-mo-nafld#nafld-v-nash-l-g)
  * [Gan nằm ở đâu? Gan to là như thế nào](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/8-cau-hoi-ve-benh-gan-nhiem-mo-nafld#gan-nm-u-gan-to-l-nh-th-no)
  * [Tại sao những triệu chứng NAFLD và NASH quan trọng?](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/8-cau-hoi-ve-benh-gan-nhiem-mo-nafld#ti-sao-nhng-triu-chng-nafld-v-nash-quan-trng)
  * [Nguyên nhân của NAFLD là gì?](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/8-cau-hoi-ve-benh-gan-nhiem-mo-nafld#nguyn-nhn-ca-nafld-l-g)
  * [Làm thế nào để biết có nguy cơ mắc bệnh hay không?](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/8-cau-hoi-ve-benh-gan-nhiem-mo-nafld#lm-th-no-bit-c-nguy-c-mc-bnh-hay-khng)
  * [Nên làm gì nếu mắc NAFLD hoặc NASH?](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/8-cau-hoi-ve-benh-gan-nhiem-mo-nafld#nn-lm-g-nu-mc-nafld-hoc-nash)
  * [Có thể uống rượu nếu đang mắc NAFLD hoặc NASH không?](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/8-cau-hoi-ve-benh-gan-nhiem-mo-nafld#c-th-ung-ru-nu-ang-mc-nafld-hoc-nash-khng)
  * [Dùng thuốc Statin có an toàn không?](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/8-cau-hoi-ve-benh-gan-nhiem-mo-nafld#dng-thuc-statin-c-an-ton-khng)


## **NAFLD và NASH là gì?**
**_Bệnh gan nhiễm mỡ không do rượu (NAFLD)_** xảy ra khi lượng chất béo tích tụ bất thường trong gan. Rượu có thể gây ra những tổn thương tương tự cho gan. Nhưng NAFLD xảy ra cả khi không uống quá nhiều rượu. NAFLD làm tình trạng gan xấu đi, có thể gây ra viêm và sẹo tại gan, là nguyên nhân gây ra bệnh ** _Viêm gan nhiễm mở không do rượu (NASH)_**.
## **Gan nằm ở đâu? Gan to là như thế nào**
Gan nằm ở phần trên bên phải của bụng, thường được che chở bởi lòng ngực. Mép dưới của gan bình thường chỉ đến hạ sườn phải. Nếu gan nằm bên dưới vị trí này thì có khả năng gan đã bị to ra.
## **Tại sao những triệu chứng NAFLD và NASH quan trọng?**
NAFLD và NASH có thể không xuất hiện các triệu chứng cho đến khi phát hiện những biến chứng dai dẳng. Đôi khi, nó có thể gây ra tổn thương gan, ung thư gan và bệnh tim; chẳng hạn như nhồi máu cơ tim và suy tim. Nếu NAFLD và NASH được phát hiện sớm các phương pháp điều trị có sẳn có thể đảo ngược tình trạng bệnh và giúp ngăn ngừa các biến chứng nghiêm trọng.
## **Nguyên nhân của NAFLD là gì?**
Các yếu tố nguy cơ chính của NAFLD là hội chứng chuyên hóa, béo phì (đặc biệt ở bụng), kháng insulin, đái tháo đường và rối loạn lipid máu. Những tình trạng khác có thể xảy ra như loạn dưỡng mỡ (mất chất béo), bệnh thận mạn hay hội chứng buồng trứng đa nang cũng làm tăng nguy cơ NAFLD.
## **Làm thế nào để biết có nguy cơ mắc bệnh hay không?**
Bệnh có thể bị tăng nguy cơ nếu mắc các đặc điểm của hội chứng chuyển hóa (đường máu cao, triglyceride trong máu cao, tăng kích thước vòng eo, huyết áp cao), đái tháo đường và béo phì. Mắc càng nhiều các nguy cơ trên thì bạn càng có nguy cơ dẫn đến NAFLD. Bên cạnh đó, yếu tố di truyền cũng mang đến nguy cơ mắc bệnh, khi bạn có người thân trong gia đình có tiền sử bệnh. Để tim ra nguyên nhân chính xác, các trường hợp NAFLD và NASH cần được đánh giá và tư vấn bởi các bác sĩ chuyên khoa.
## **Nên làm gì nếu mắc NAFLD hoặc NASH?**
Hỏi chuyên gia chăm sóc sức khỏe để thảo luận về tình trạng của bạn và lập kế hoạch điều trị. Tập thể dục ít nhất 3 giờ mỗi tuần, thay đổi chế độ ăn uống, giảm cân (5-10%) và tránh uống rượu. Ngoài ra, việc tham khảo ý kiến của các chuyên gia dinh dưỡng nhằm cân bằng lại các loại thực phẩm bạn tiếp thu hằng ngày cũng là giải pháp tốt. Cần kiểm soát các tình trạng tìm ẩn, có thể bao gồm cả việc điều trị bằng thuốc.
## **Có thể uống rượu nếu đang mắc NAFLD hoặc NASH không?**
Mặc dù NAFLD không có nguyên nhân phát sinh từ rượu bia thế nhưng gan có thể sẽ bị ảnh hưởng khi uống nhiều rượu bia. Bởi nếu bạn không uống rượu, gan có thể tự phục hồi một cách tốt nhất. Khi gan được phục hồi tốt trong quá trình điều trị thì nếu muốn dùng rượu bia thì người bệnh nên được tham khảo ý kiến của bác sĩ.
## **Dùng thuốc Statin có an toàn không?**
Nếu có mức cholesterol cao, cần phải uống statin để giúp ngăn ngừa nhồi máu cơ tim và đột quỵ. Các loại statin sẽ an toàn với hầu hết bệnh nhân NAFLD nhưng để dùng thuốc này, người bệnh cần phải được thảo luận với bác sĩ điều trị.
  * [NAFLD và NASH là gì?](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/8-cau-hoi-ve-benh-gan-nhiem-mo-nafld#nafld-v-nash-l-g)
  * [Gan nằm ở đâu? Gan to là như thế nào](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/8-cau-hoi-ve-benh-gan-nhiem-mo-nafld#gan-nm-u-gan-to-l-nh-th-no)
  * [Tại sao những triệu chứng NAFLD và NASH quan trọng?](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/8-cau-hoi-ve-benh-gan-nhiem-mo-nafld#ti-sao-nhng-triu-chng-nafld-v-nash-quan-trng)
  * [Nguyên nhân của NAFLD là gì?](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/8-cau-hoi-ve-benh-gan-nhiem-mo-nafld#nguyn-nhn-ca-nafld-l-g)
  * [Làm thế nào để biết có nguy cơ mắc bệnh hay không?](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/8-cau-hoi-ve-benh-gan-nhiem-mo-nafld#lm-th-no-bit-c-nguy-c-mc-bnh-hay-khng)
  * [Nên làm gì nếu mắc NAFLD hoặc NASH?](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/8-cau-hoi-ve-benh-gan-nhiem-mo-nafld#nn-lm-g-nu-mc-nafld-hoc-nash)
  * [Có thể uống rượu nếu đang mắc NAFLD hoặc NASH không?](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/8-cau-hoi-ve-benh-gan-nhiem-mo-nafld#c-th-ung-ru-nu-ang-mc-nafld-hoc-nash-khng)
  * [Dùng thuốc Statin có an toàn không?](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/8-cau-hoi-ve-benh-gan-nhiem-mo-nafld#dng-thuc-statin-c-an-ton-khng)



## CÂU HỎI THƯỜNG GẶP VỀ BỆNH ĐÁI THÁO ĐƯỜNG (P1)

**_Hỏi: Glucose máu là gì?_**
**_Trả lời:_** Glucose máu chính là đường máu hay là đường huyết (đường trong máu) là năng lượng chính cho các tế bào sống và hoạt động. Mỗi một tế bào đều cần oxy và chất dinh dưỡng (glucose) để giữ cho hoạt động sống hằng ngày. Máu đảm nhận vai trò vận chuyển hai yếu tố quan trọng này đến tế bào để nuôi dưỡng cơ thể.
**_Hỏi: Tiền Đái tháo đường (ĐTĐ) là gì?_**
**_Trả lời:_**
Tiền ĐTĐ là tình trạng bệnh lý khi nồng độ Glucose máu cao hơn bình thường nhưng chưa đạt tiêu chuẩn chẩn đoán ĐTĐ, bao gồm những người rối loạn Glucose máu lúc đói, hoặc rối loạn dung nạp Glucose, hoặc tăng HbA1c.
Tiền ĐTĐ là giai đoạn trung gian giữa người bình thường và ĐTĐ type 2. Khoảng 5-10% người tiền ĐTĐ sẽ trở thành ĐTĐ hàng năm và tổng cộng 70% người tiền ĐTĐ sẽ thành ĐTĐ thực sự.
Tiền ĐTĐ liên quan với các yếu tố nguy cơ giống như bệnh ĐTĐ: thừa cân, béo phì, rối loạn Lipid máu, THA, ít hoạt động thể lực...
**_Hỏi: ĐTĐ là gì?_**
**_Trả lời:_** ĐTĐ là bệnh rối loạn chuyển hóa không đồng nhất, có đặc điểm tăng Glucose huyết do khiếm khuyết về bài tiết insulin, về tác động của insulin, hoặc cả hai. Tăng Glucose mạn tính trong thời gian dài gây nên những rối loạn chuyển hóa carbohydrate, Protein, Lipit, gây tổn thương ở nhiều cơ quan khác nhau, đặc biệt ở tim và mạch máu, thận, mắt, thần kinh.v.v…
**_Hỏi:_****_Cơ chế bệnh sinh của ĐTĐ type 2 là gì?_**
**_Trả lời:_**_Cơ chế bệnh sinh của ĐTĐ typ 2 là_ _kết hợp đề kháng Insulin và giảm tiết Insulin:_
_- Đề kháng Insulin là do:_
• Béo phì (nhất là béo bụng/ tăng mỡ tạng)
• Ít vận động
• Ít nhiễm ceton trừ khi có stress nặng
_- Giảm tiết Insulin là do:_
• Tế bào beta của tuyến tụy không tiết đủ insulin để bù trừ cho tình trạng đề kháng insulin.
• Tế bào beta suy giảm chức năng dần dần theo thời gian.
**_Hỏi: Đề kháng insulin là gì?_**
**_Trả lời:_** Kháng insulin là tình trạng bệnh lý, trong đó tế bào không đáp ứng tốt với insulin.Để dễ hiểu hơn, bạn hãy tưởng tượng rằng nếu tế bào giống như một nhà máy, thì glucose chính là nguồn nhiên liệu cung cấp năng lượng để nhà máy đó hoạt động. Tuy nhiên, nguồn nhiên liệu này muốn vận chuyển vào được bên trong thì cần có chìa khóa “insulin” để mở cửa của nhà máy. Glucose từ máu đi vào bên trong tế bào sẽ giúp hạ đường huyết. Kháng insulin là khi những “ổ khóa” hoặc “chìa khóa insulin” đã bị rỉ sét khiến cho rất khó khăn khi mở cánh cửa nhà máy để glucose có thể đi vào bên trong.
Tế bào thiếu năng lượng để hoạt động trong khi glucose trong máu lại dự thừa, lúc này tuyến tụy sẽ cố gắng để khắc phục bằng cách tăng sản xuất những chiếc “chìa khóa insulin” mới nhằm mở cách cửa tế bào nhanh chóng và hiệu quả hơn.
Theo thời gian, tình trạng kháng insulin nặng dần lên trong khi khả năng bù đắp bằng việc tăng sản xuất insulin lại chỉ có giới hạn. Hệ quả là đường huyết bắt đầu tăng, kéo theo các rối loạn chuyển hóa khác như rối loạn chuyển hóa chất béo, rối loạn chuyển hóa chất đạm; đây là nguyên nhân gây ra nhiều vấn đề nghiêm trọng về sức khỏe.
Nói một cách khác, hội chứng đề kháng insulin là tình trạng báo hiệu cho bệnh lý ĐTĐ type 2 sẽ đến trong một tương lai rất gần. Do đó, cần biết các dấu hiệu đề kháng insulin dưới đây để lập kế hoạch phòng bệnh cho bản thân.
**_Hỏi:_****_Kháng insulin nguy hiểm như thế nào?_**
**_Trả lời:_** Kháng insulin được đánh giá là một tình trạng sức khỏe nghiêm trọng, bởi nó làm tăng cao nguy cơ phát triển nhiều bệnh nguy hiểm bao gồm:
- Bệnh ĐTĐ type 2 (nguy cơ cao nhất)
- Bệnh tim mạch: Bệnh mạch vành, nhồi máu cơ tim, tai biến mạch máu não…
- Gan nhiễm mỡ
- Hội chứng buồng chứng đa nang
- Một số bệnh ung thư
Riêng đối với những người đã mắc các bệnh lý kể trên thì tình trạng kháng insulin là nguyên nhân khiến cho bệnh ngày một nặng lên. Chẳng hạn như đối với người bệnh ĐTĐ tuýp 2, kháng insulin là nguyên nhân chính làm cho đường huyết tăng cao và khó kiểm soát hơn theo thời gian.
**_Hỏi:**Dấu hiệu nhận biết cơ thể đang gặp phải tình trạng kháng insulin**_**
**_Trả lời:_** Ở nhiều người bệnh, dấu hiệu của kháng insulin là không rõ ràng, tuy nhiên một số người bệnh có thể sẽ xuất hiện các triệu chứng như:
- Hay cảm thấy đói
- Mệt mỏi thường xuyên
- Khó tập trung
- Tăng huyết áp
- Tăng cholesterol máu
- Tăng tích mỡ ở bụng
- Xuất hiện các vùng da tối màu ở các vị trí cơ thể có nhiều nếp gấp da như cổ, bẹn, nách…
Tình trạng kháng insulin càng nặng thì các triệu chứng càng rõ ràng
**_Có mấy loại ĐTĐ?_**
**_Trả lời:_**_Có 3 loại ĐTĐ_
**ĐTĐ type 1:** Do tế bào bêta của tuyến tụy bị phá hủy do nguyên nhân tự miễn hoặc không rõ nguyên nhân, gây nên thiếu insulin tuyệt đối. ĐTĐ type 1 chiếm khoảng 5-10% tổng số ca ĐTĐ.
**ĐTĐ type 2:** Do tế bào của cơ thể kháng với insulin, dẫn đến thiếu insulin tương đối (tức là insulin vẫn tiết ra với số lượng bình thường nhưng thiếu so với đòi hỏi của cơ thể).
**ĐTĐ thai kỳ** : Là tình trạng rối loạn đường huyết, đa phần ĐTĐ thai kỳ xảy ra ở phụ nữ mang thai ở tuần 24-28.
Đối với mẹ, ĐTĐ thai kỳ có thể gây tăng huyết áp, tiền sản giật, sản giật, hoặc ĐTĐtype 2 sau sinh.
Đối với thai nhi, ĐTĐ thai nghén có thể gây chứng khổng lồ, thai chết lưu, đẻ non, suy hô hấp, hạ glucose máu, khi lớn trẻ có thể bị béo phì hoặc ĐTĐtype2.
**_Hỏi: Tiêu chuẩn chẩn đoán ĐTĐ là gì?_**
**_Trả lời:_**_Tiêu chuẩn chẩn đoán ĐTĐ là_
- Glucose huyết tương tĩnh mạch (GHTTM) lúc đói (buổi sáng, sau nhịn đói qua đêm 8-12 tiếng) ≥ 7,0mmol/L  _hoặc_
- GHTTM 2 giờ trong nghiệm pháp dung nạp Glucose đường uống (NPDNG: ≥ 11,1mmol/l  _hoặc_
- HbA1c ≥ 6,5%  _hoặc_
- GHTTM bất kỳ ≥ 11,1 mmol/L
- Triệu chứng lâm sàng của tăng Glucose máu (nếu có).
**_10._****_Nguyên nhân của bệnh ĐTĐ type 2 là gì?_**
**_Trả lời:_** Hiện nay vẫn chưa tìm được nguyên nhân chính thức của bệnh ĐTĐ typ 2. Song người ta thấyđặc điểm lớn nhất trong bệnh ĐTĐ type 2 là có sự tương tác giữa yếu tố gen và yếu tố môi trường.
Yếu tố môi trường ở đây là nhóm các yếu tố có thể can thiệp để làm giảm tỷ lệ mắc bệnh.

## Các rủi ro khi quan hệ trong quá trình điều trị viêm đường tiết niệu

  * [Các rủi ro khi quan hệ trong quá trình điều trị viêm đường tiết niệu](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/cac-rui-ro-khi-quan-he-trong-qua-trinh-dieu-tri-viem-duong-tiet-nieu#cc-ri-ro-khi-quan-h-trong-qu-trnh-iu-tr-vim-ng-tit-niu)
  * [Gây đau và làm trầm trọng thêm các triệu chứng khác](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/cac-rui-ro-khi-quan-he-trong-qua-trinh-dieu-tri-viem-duong-tiet-nieu#gy-au-v-lm-trm-trng-thm-cc-triu-chng-khc)
  * [Làm tăng nguy cơ nhiễm các loại vi khuẩn mới](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/cac-rui-ro-khi-quan-he-trong-qua-trinh-dieu-tri-viem-duong-tiet-nieu#lm-tng-nguy-c-nhim-cc-loi-vi-khun-mi)
  * [Nguy cơ lây nhiễm cho bạn tình](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/cac-rui-ro-khi-quan-he-trong-qua-trinh-dieu-tri-viem-duong-tiet-nieu#nguy-c-ly-nhim-cho-bn-tnh)


Viêm đường tiết niệu (UTI) là tình trạng xảy ra khi bạn bị viêm ở bất cứ bộ phận nào thuộc hệ tiết niệu, từ thận, bàng quang đến niệu đạo. Các triệu chứng thường gặp của UTI bao gồm:
  * Buồn tiểu liên tục
  * Đau buốt khi đi tiểu
  * Đau vùng chậu


Những triệu chứng này khiến bạn khó chịu khi đi vệ sinh. Và nhiều người vẫn thường thắc mắc rằng viêm đường tiết niệu có quan hệ được không. Trên thực tế, căn bệnh này hoàn toàn không ngăn cản việc bạn quan hệ tình dục qua đường âm đạo.
## Các rủi ro khi quan hệ trong quá trình điều trị viêm đường tiết niệu
Bị viêm đường tiết niệu có quan hệ được không? Trên thực tế, quan hệ tình dục khi đang điều trị UTI có thể dẫn đến rất nhiều rủi ro, bao gồm:
### **Gây đau và làm trầm trọng thêm các triệu chứng khác**
Các kích thích từ bên ngoài vùng kín bằng ngón tay, đồ chơi tình dục hoặc dương vật cũng có khả năng gây áp lực lên các cơ quan tiết niệu. Bên cạnh đó, tình trạng viêm nhiễm cũng có thể cản trở quá trình dương vật đi sâu vào âm đạo. Những vấn đề này khiến bạn cảm thấy đau đớn và khó chịu hơn trong khi quan hệ.
### **Làm tăng nguy cơ nhiễm các loại vi khuẩn mới**
Hoạt động tình dục là một trong những nguyên nhân phổ biến làm vi khuẩn xâm nhập vào đường tiết niệu. 90% các ca nhiễm trùng đường tiểu bắt nguồn từ việc vi khuẩn E. coli xâm nhập vào niệu đạo.
Loại khuẩn này thường được tìm thấy trong đường tiêu hóa (GI) hoặc phân. Chúng có thể di chuyển từ hậu môn, đường tiêu hóa lên cơ thể bạn hoặc từ tay, miệng, bộ phận sinh dục hoặc đồ chơi tình dục của đối tác trong khi quan hệ.
Hơn nữa, nếu bạn đã từng bị viêm đường tiết niệu, việc quan hệ có thể khiến bạn bị tái nhiễm hoặc mắc thêm các loại vi khuẩn mới. Điều này làm kéo dài thời gian phục hồi và điều trị bệnh.
### **Nguy cơ lây nhiễm cho bạn tình**
UTI không phải là một bệnh lây qua đường tình dục (STI). Nó cũng không được coi là bệnh truyền nhiễm. Tuy nhiên, viêm đường tiết niệu có quan hệ được không thì câu trả lời là không nên. Bởi bạn có thể lây truyền vi khuẩn gây UTI cho vợ (hoặc chồng) của mình.
Ví dụ, vi khuẩn E. coli có thể di chuyển từ hậu môn của bạn đến cửa âm đạo hoặc dương vật. Khi quan hệ tình dục qua âm đạo, dương vật có thể đưa vi khuẩn vào cửa âm đạo, làm tăng nguy cơ nhiễm trùng.
  * [Các rủi ro khi quan hệ trong quá trình điều trị viêm đường tiết niệu](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/cac-rui-ro-khi-quan-he-trong-qua-trinh-dieu-tri-viem-duong-tiet-nieu#cc-ri-ro-khi-quan-h-trong-qu-trnh-iu-tr-vim-ng-tit-niu)
  * [Gây đau và làm trầm trọng thêm các triệu chứng khác](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/cac-rui-ro-khi-quan-he-trong-qua-trinh-dieu-tri-viem-duong-tiet-nieu#gy-au-v-lm-trm-trng-thm-cc-triu-chng-khc)
  * [Làm tăng nguy cơ nhiễm các loại vi khuẩn mới](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/cac-rui-ro-khi-quan-he-trong-qua-trinh-dieu-tri-viem-duong-tiet-nieu#lm-tng-nguy-c-nhim-cc-loi-vi-khun-mi)
  * [Nguy cơ lây nhiễm cho bạn tình](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/cac-rui-ro-khi-quan-he-trong-qua-trinh-dieu-tri-viem-duong-tiet-nieu#nguy-c-ly-nhim-cho-bn-tnh)



## Một vài nét về polyp túi mật

Polyp túi mật là hậu quả của quá trình tăng sinh quá mức các tế bào trong niêm mạc thành túi mật. Tỷ lệ polyp túi mật trong cộng đồng dao động từ 0,03 đến 9%. Tại khu vực Đông Á tỷ lệ này ở người trưởng thành dao động trong khoảng 4 đến 7%, còn ở Mỹ là 4,3-6,9%. Bệnh lý polyp túi mật chủ yếu gặp ở người trưởng thành, tỷ lệ gặp ở nam/nữ khoảng 1,15/1, rất hiếm gặp ở trẻ em. Mặc dù polyp không phải là ung thư túi mật, nhưng một tỷ lệ nhỏ polyp túi mật có khả năng tiến triển thành ung thư. Ung thư túi mật tuy hiếm gặp, nhưng khi đã có triệu chứng thường là ở giai đoạn muộn, tiên lượng bệnh xấu. Các triệu chứng ban đầu thường không đặc hiệu, mơ hồ, thậm chí trong nhiều trường hợp không có triệu chứng, do đó hầu hết các trường hợp polyp túi mật được phát hiện tình cờ. Một số bệnh nhân có buồn nôn, nôn mửa và thỉnh thoảng có đau vùng hạ sườn phải, nguyên nhân do các mảnh nhỏ cholesterol tách khỏi thành túi mật di chuyển qua ống cổ. Việc phát hiện polyp túi mật giai đoạn sớm khi không có triệu chứng chủ yếu nhờ các phương pháp chẩn đoán hình ảnh. Siêu âm bụng tổng quát là phương án hữu hiệu và thường được sử dụng nhất không chỉ vì dễ tiếp cận, giá rẻ mà phương pháp này cũng có độ nhạy và độ đặc hiệu rất cao trong chẩn đoán polyp túi mật. Bác sỹ siêu âm có thể mô tả vị trí, đếm số lượng và đo kích thước của polyp. Siêu âm cũng có thể phân biệt polyp thể cholesterol với các thể khác. Tuy nhiên, qua hình ảnh siêu âm khó có thể phân biệt được polyp là lành tính hay ác tính. Siêu âm thường chỉ phát hiện rõ khi polyp có đường kính từ 5 mm trở lên, các trường hợp sỏi dính chặt trên thành túi mật cũng có thể gây nhầm lẫn chẩn đoán. Trong các trường hợp polyp đường kính nhỏ hoặc nghi ngờ ác tính, có thể chụp CT scanner, cộng hưởng từ hoặc siêu âm nội soi để chẩn đoán xác định.
Dựa vào các đặc điểm giải phẫu bệnh cũng như chẩn đoán hình ảnh, polyp túi mật được chia thành 4 loại chính sau: Polyp thể cholesterol: Các nghiên cứu gần đây chỉ ra rằng hầu hết các polyp túi mật là lành tính và 60-90% là polyp thể cholesterol. Các polyp thể này thường có đường kính dưới 10 mm và là đa polyp (hình).
Việc hình thành polyp liên quan tới sự lắng đọng cholesterol trên thành túi mật. Siêu âm rất dễ phát hiện thể polyp này nhờ dấu hiệu “quả bóng gắn trên tường – Ball on the wall”, nghĩa là hình ảnh tăng sáng, tròn mịn. Cũng có khi nhìn thấy tinh thể cholesterol lóe sáng như ngôi sao trên bầu trời. Polyp thể viêm: Thể polyp này không phổ biến, chỉ chiếm khoảng 10%, bản chất là dạng mô sơ sẹo gây nên do các tổn thương viêm mạn tính trên thành túi mật. Các Polyp thể này có đường kính thường nhỏ hơn 10 mm, chân rộng và không gây ung thư nên người bệnh hoàn toàn yên tâm. Polyp thể u tuyến: Mặc dù là polyp lành tính nhưng đây được coi như một dạng tổn thương tiền ung thư. Polyp này có kích thước 5-20 mm, thường đứng đơn độc và có thể có liên quan với bệnh lý sỏi túi mật hoặc tình trạng viêm túi mật mạn tính. Đây là dạng u biểu mô lành tính hiếm gặp, thường được phát hiện tình cờ qua chẩn đoán hình ảnh hoặc sau khi cắt túi mật. Dạng này có thể có cuống hoặc không cuống và hầu hết xuất hiện cùng các trường hợp bệnh nhân có sỏi túi mật. Polyp thể phì đại cơ tuyến: Đây là loại polyp thường gặp ở người trưởng thành, tỷ lệ bắt gặp tăng dần theo độ tuổi. Ban đầu polyp thể này được mô tả là lành tính, tuy nhiên hiện tại nó được xếp vào loại tổn thương tiền ung thư do có một số trường hợp tiến triển thành ung thư đã được y khoa thế giới ghi nhận. Polyp này thường xuất hiện đơn độc và nằm ở đáy túi mật. 
## Nhận biết các polyp có nguy cơ ung thư hóa và hướng xử lý
Mặc dù hầu hết các polyp túi mật là lành tính, nhưng một tỷ lệ nhỏ các polyp này có khả năng tiến triển thành ung thư. Các nghiên cứu cho thấy, tỷ lệ ung thư hóa của các polyp túi mật phụ thuộc vào độ tuổi, kích thước, hình dạng và số lượng polyp. Cụ thể: Về độ tuổi: Các nghiên cứu đã cho thấy nguy cơ ác tính cao hơn ở những bệnh nhân polyp túi mật trên 50 tuổi. Về kích thước: Các polyp có đường kính ≥ 18 mm nguy cơ ác tính cao nên chỉ định mổ tuyệt đối, còn các polyp có đường kính dao động trong khoảng 11-17 mm có thể chuyển thành ác tính nên cần cân nhắc mổ. Đối với các polyp có đường kính ≤ 10 mm thường là lành tính nên có thể sống chung với nó. Với những polyp này chỉ cần theo dõi hàng năm bằng siêu âm ổ bụng để đánh giá xem nó có lớn hơn không và có hướng xử trí kịp thời. Tuy nhiên, một số nghiên cứu mới đây cho rằng nếu chỉ xét riêng đường kính polyp thì không đánh giá được chính xác nguy cơ ác tính, do vậy các nghiên cứu này đưa ra khuyến cáo nên phẫu thuật khi đường kính polyp trên 6 mm. Về hình dạng và số lượng: Các polyp không có cuống có nguy cơ ác tính cao hơn loại có cuống. Các polyp ác tính thường có xu hướng xuất hiện đơn lẻ, trong khi các polyp thể cholesterol lành tính thường là đa polyp. Tuy nhiên, chưa có bằng chứng cụ thể chứng minh polyp túi mật đơn độc có nguy cơ ác tính cao hơn đa polyp. Ngoài ra, sự xuất hiện kèm theo của sỏi túi mật cũng được xem như một dấu hiệu gây tăng nguy cơ ung thư hóa polyp túi mật. Tuy nhiên, cần lưu ý việc chẩn đoán qua siêu âm vì sỏi túi mật có thể gây khó khăn trong việc xác định các polyp nhỏ; viêm túi mật mạn tính là một trong các nguy cơ gây ác tính với các polyp túi mật. Do đó, nếu có viêm túi mật mạn tính thì polyp túi mật dù có kích thước hoặc hình thể nào cũng nên phẫu thuật cắt túi mật sớm.
Trên thực tế hầu hết các polyp lành tính nên không cần phải phẫu thuật cắt bỏ. Phẫu thuật cắt túi mật chỉ thực hiện trong các trường hợp polyp có đường kính ≥ 10 mm, tăng nhanh về kích thước, không có cuống hoặc cuống dài, bệnh nhân trên 50 tuổi, polyp có kèm theo sỏi túi mật, polyp trong các trường hợp bệnh nhân có viêm túi mật. Trường hợp bệnh nhân có các yếu tố nguy cơ, polyp có đường kính ≥ 6 mm nên chỉ định phẫu thuật. Đối với các trường hợp không phẫu thuật cần khám định kỳ theo dõi bằng siêu âm trong 6 hoặc 12 tháng một lần để phát hiện sớm, xử trí kịp thời các trường hợp có nguy cơ tiến triển thành ung thư

## Người tiểu đường nên ăn loại hoa quả nào?



Để kiểm soát đường máu trong mức cho phép, các chuyên gia dinh dưỡng khuyên người tiểu đường nên ăn các loại hoa quả dưới đây:
### Bưởi đỏ
Bưởi đỏ là trái cây người bệnh tiểu đường nên ăn. Trong bưởi chứa hơn 90% là nước, giàu vitamin C, chất xơ. Lượng đường trong quả bưởi tương đối thấp, chỉ số đường huyết là khoảng 25.
Bên cạnh đó, khi ăn bưởi bạn có thể cảm nhận được vị đắng tự nhiên, đó là từ hợp chất Naringenin. Chất này có khả năng tăng độ nhạy cảm của insulin. Vì vậy, ăn bưởi mỗi ngày có thể giúp điều hòa đường huyết ở người tiểu đường.
### Quả Dâu tây
Dâu tây là loại quả chứa rất nhiều vitamin đặc biệt là vitamin C, chất xơ và các chất chống oxy hóa khác. Ngoài ra, với chỉ số đường huyết thấp (khoảng 41), ít carbohydrat, dâu tây giúp người tiểu đường giảm cảm giác thèm tinh bột. Bạn cần ăn khoảng 200g (1 cốc) dâu tây mỗi ngày.
### Quả táo
Chỉ số đường huyết của táo là khoảng 38, táo cũng giàu vitamin C và chất xơ hòa tan tốt cho người tiểu đường. Ngoài ra, trong trái táo còn có chứa pectin – chất đóng vai trò quan trọng trong quá trình thải độc của cơ thể và giúp giảm nhu cầu insulin ở người tiểu đường.
### Quả bơ
Bơ giàu chất béo lành mạnh và kali tốt cho bệnh tiểu đường. Ăn bơ giúp người bệnh giảm lượng cholesterol xấu trong máu, giảm những nguy cơ biến chứng do bệnh tiểu đường. Bạn nên ăn nửa trái bơ một ngày và nên ăn tươi hoặc ăn cùng salad, không trộn thêm sữa hay đường.
### Kiwi
Kiwi là loại quả giàu vitamin C và khoáng chất, cung cấp các chất chống oxy hóa tốt cho bệnh nhân đái tháo đường. Ăn loại quả này cũng góp phần giảm lượng đường trong máu, bổ sung thêm chất xơ và ít tinh bột.
### Đu đủ
Nhiều nghiên cứu cho thấy, đu đủ chứa nhiều dinh dưỡng tốt trong việc kiểm soát đường máu ở người tiểu đường. Ngoài ra, đu đủ còn chứa nhiều enzym có lợi, giúp chuyển hóa các gốc tự do có hại, bảo vệ người tiểu đường khỏi nguy cơ biến chứng.
Vì vậy, đu đủ là một trong những loại trái cây được khuyên nên có mặt trong khẩu phần ăn của người tiểu đường.
### 
Cam là loại quả cực kì có lợi cho bệnh nhân tiểu đường. 87% dinh dưỡng trong trái cam là nước, chỉ số đường huyết cũng ở mức thấp khoảng 40. Cam giàu vitamin C và chất xơ, các chất chống oxy hóa hỗ trợ kiểm soát lượng đường trong máu và giúp bạn duy trì cân nặng phù hợp. Người tiểu đường nên ăn 1 trái cam mỗi ngày.
Ngoài ra, để bổ sung đủ vitamin và các yếu tố vi lượng, người bệnh đái tháo đường cũng có thể ăn các loại quả khác như: cherry, đào, lựu, ổi,…
Tóm lại, người tiểu đường có thể ăn nhiều loại trái cây. Tuy nhiên, cần ăn ở mức độ phù hợp và kết hợp những loại trái cây, thực phẩm khác giúp duy trì đường huyết ở mức ổn định.



## Tại sao tức giận, xúc động có thể kích phát hạ canxi máu?

✅Giải thích vì sao bệnh nhân biểu hiện các triệu chứng của hạ Ca trong khi kết quả canxi máu bệnh nhân ở giá trị bình thường:
- Đầu tiên chúng ta cần biết, ion Ca 2+ trong máu tổn tại dưới 2 dạng là Ca ion tự do và Ca ion gắn với protein huyết tương.
- Và trong xét nghiệm đối với ion canxi thì chúng ta có 2 xét nghiệm đó là: Ca ion tự do và Ca toàn phần. Trong đó:
• Canxi toàn phần = Ca ion tự do + Ca ion gắn với protein.
• Nếu chúng ta ghi xét nghiệm Ca thì phòng thí nghiệm sẽ mặc định làm xét nghiệm Ca toàn phần.
• Canxi ion tự do mới là dạng Ca hoạt động (quyết định chức năng)
• Còn canxi ion gắn với protein huyết tương thì là loại không hoạt động.
Do đó trong tình huống này bệnh nhân có biểu hiện của hạ Ca chính là do sự giảm đi của ion Ca ở dạng tự do.
✅Ca toàn phần ở bệnh nhân nhiễm kiềm không phản ánh chính xác về ion Ca tự do.
• Giải thích: Ion Ca gắn với protein phụ thuộc vào pH máu: Nếu pH máu kiềm sẽ làm tăng ion canxi gắn với protein huyết tương từ đó sẽ làm giảm ion canxi ở dạng tự do (giảm canxi hoạt động) từ đó có biểu hiện của các triệu chứng hạ Ca máu. Chứ tổng lượng Ca trong huyết tương không hề thay đổi (Ca toàn phần).
• Khi chúng ta giận hoặc là lo lắng thì chúng ta sẽ bị thở nhanh làm tăng đào thải CO2, đưa tới tình trạng nhiễm kiềm hô hấp và hạ canxi máu do giảm lượng canxi tự do trong máu.

## Cách phòng tránh hạ đường huyết và tụt huyết áp

  * [Phân biệt hạ đường huyết và tụt huyết áp.](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/cach-phong-tranh-ha-duong-huyet-va-tut-huyet-ap#phn-bit-h-ng-huyt-v-tt-huyt-p)
  * [Cách phòng tránh hạ đường huyết và tụt huyết áp](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/cach-phong-tranh-ha-duong-huyet-va-tut-huyet-ap#cch-phng-trnh-h-ng-huyt-v-tt-huyt-p)


## Phân biệt hạ đường huyết và tụt huyết áp.
Hạ đường huyết và tụt huyết áp thường có biểu hiện giống nhau, nhưng thực chất là biểu hiện của hai bệnh khác nhau. Hạ đường huyết là bệnh liên quan tới sự chuyển hóa trong cơ thể. Còn tụt huyết áp là bệnh lý liên quan tới tim mạch.
Hạ đường huyết là tình trạng lượng đường trong máu (glucose máu) giảm xuống dưới mức bình thường. Với người đái tháo đường thì lượng glucose máu dưới 70 mg/dl (3.9 mmol/L) được xem là hạ đường huyết. Tụt huyết áp là tình trạng huyết áp của người bình thường dưới mức bình thường (< 90/60 mmHg).
Phân biệt hạ đường huyết và tụt huyết áp:
Triệu chứng hạ đường huyết: cảm giác đói, đổ mồ hôi, run rẩy chân tay,run, chóng mặt, tim đập nhanh, đánh trống ngực, lờ đờ, buồn ngủ. rối loạn ý thức, động kinh, mất ý thức, có thể tử vong. Hạ đường huyết thường gặp ở những người đái tháo đường, người lao động nặng.
Triệu chứng tụt huyết áp: hoa mắt, chóng mặt, xây xẩm mặt mày, đứng không vững, sốt cao đột ngột, chân tay lạnh buốt nhưng không đổ mồ hôi, tim đập nhanh mạnh nhưng không đều, có thể ngất xỉu.
## Cách phòng tránh hạ đường huyết và tụt huyết áp
Hạ huyết áp:
  * Khi bị hạ huyết áp, bệnh nhân cần được nghỉ ngơi, dừng mọi công việc đang làm, bổ sung đường huyết bằng cách cho ăn những đồ ăn nhẹ như cháo loãng, súp hoặc uống một cốc nước đường. Với các trường hợp nặng hơn, cần gọi ngay bác sĩ để có thể tiêm bổ sung dung dịch ngọt.


  * Luôn luôn có sẵn đường hoặc các sản phẩm có đường như kẹo, bánh,socola, nước ngọt có đường.
  * Nếu hạ đường huyết do bệnh tiểu đường thì nên tuân theo lời chỉ dẫn của thầy thuốc trong việc dùng thuốc và ăn uống hằng ngày. Không bỏ bữa ăn, ăn đủ lượng cacbonhydrat, ăn thêm bữa phụ, ăn nhiều rau..
  * Nên tập thể dục thường xuyên, ít nhất 30 phút mỗi ngày.


Tụt huyết áp:
  * Cần uống một số loại đồ uống như nước trà gừng, nước sâm… hoặc ăn socola để cải thiện huyết áp tạm thời.
  * Bệnh nhân nằm nghỉ nơi thoáng mát, đầu hơi ngửa, hai chân nâng cao.
  * Nên thường xuyên tập thể dục ít nhất 30 phút mỗi ngày.
  * Ăn đủ các bữa ăn trong ngày, đặc biệt là bữa sáng. Cung cấp đầy đủ lượng nước cho cơ thể mỗi ngày.
  * Nếu người bị tăng huyết áp đang dùng thuốc thì phải đo huyết áp mỗi buổi sáng, tuân thủ phác đồ điều trị, dùng thuốc của bác sĩ.
  * Tránh xa các thức uống có cồn, không được đứng quá lâu


  * [Phân biệt hạ đường huyết và tụt huyết áp.](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/cach-phong-tranh-ha-duong-huyet-va-tut-huyet-ap#phn-bit-h-ng-huyt-v-tt-huyt-p)
  * [Cách phòng tránh hạ đường huyết và tụt huyết áp](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/cach-phong-tranh-ha-duong-huyet-va-tut-huyet-ap#cch-phng-trnh-h-ng-huyt-v-tt-huyt-p)



## Làm thế nào điều trị mụn trứng cá khoa học, hiệu quả

  * [1. Các vấn đề về điều trị mụn trứng cá](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/lam-the-nao-dieu-tri-mun-trung-ca-khoa-hoc-hieu-qua#1-cc-vn-v-iu-tr-mn-trng-c)
  * [2. Điều trị mụn trứng cá bằng thuốc](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/lam-the-nao-dieu-tri-mun-trung-ca-khoa-hoc-hieu-qua#2-iu-tr-mn-trng-c-bng-thuc)
  * [3. Cách trị mụn trứng cá không dùng thuốc](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/lam-the-nao-dieu-tri-mun-trung-ca-khoa-hoc-hieu-qua#3-cch-tr-mn-trng-c-khng-dng-thuc)


## **1. Các vấn đề về điều trị mụn trứng cá**
Đối với mụn trứng cá nặng nếu như không biết chăm sóc và**điều trị** đúng cách thì có thể để lại sẹo xấu, gây ảnh hưởng tâm sinh lý vĩnh viễn. Do đó cần nắm rõ các yếu tố sau nhằm góp phần đem lại hiệu quả tối ưu trong việc giải quyết các trường hợp này.
Điều trị mụn trứng cá là một quá trình liên tục. Tất cả những điều trị mụn trứng cá cần làm là phải ngăn những đợt mụn mới. Những vết tích do mụn trứng cá gây ra cần phải được chữa lành và được cải thiện theo thời gian. Nếu mụn trứng cá không có cải thiện sau 2 – 3 tháng điều trị, cần phải thay đổi phác đồ khác theo chỉ định của bác sĩ da liễu.
Đôi khi, mụn trứng cá có thể gây ra do những nguyên nhân khác như dùng mỹ phẩm, một số dung dịch hay một số thuốc dùng bằng đường uống. Cần phải cung cấp những thông tin gần đây về việc dùng thuốc trên da hay bằng đường uống cho bác sĩ da liễu của bạn.
## **2. Điều trị mụn trứng cá bằng thuốc**
### **Thuốc thoa**
Khá nhiều dung dịch hay kem bôi gây ra mụn trứng cá nhẹ hoặc làm da trở nên khô hơn, do đó cần đọc chỉ dẫn sử dụng một cách cẩn thận.
Các loại kem, gel, hay dung dịch bôi có chứa chất giống vitamin A, benzoyl peroxide, hay kháng sinh nhằm hạn chế tắc nghẽn lỗ chân lông và sự phát triển của vi khuẩn. Những chế phẩm này có thể gây khô da và tróc vẩy. Bác sĩ da liễu sẽ cho bạn những lời khuyên về cách sử dụng thuốc an toàn và làm thế nào để hạn chế tác dụng phụ.
**_Lưu ý_ :** Không dùng các loại kem trộn tự pha chế, các loại thuốc bôi có chứa chất corticoides như celestoderm, synalar, cortibion… vì sẽ làm tình trạng mụn nặng thêm sau thời gian ngắn thuyên giảm lúc đầu.
_Thoa các loại kem trộn là một cách trị mụn cực kỳ nguy hiểm_
Nếu bạn dự định sẽ mang thai, hay đang có thai hoặc cho con bú, nên thông báo cho bác sĩ trước khi bắt đầu dùng bất kỳ một thuốc trị mụn nào (kể cả thuốc bôi).
### **Đường uống**
  * Kháng sinh: Những kháng sinh dùng bằng đường uống như: tetracycline, doxycycline, minocycline hay erythromycine thường được kê toa. Đối với mụn trứng cá nặng có thể dùng thêm sulfamethoxazol/trimethoprime hoặc dapsone
  * Thuốc viên ngừa thai: Thuốc viên ngừa thai có thể cải thiện đáng kể tình trạng mụn trứng cá và được dùng theo một cách riêng trong điều trị mụn trứng cá. Điều quan trọng là cần phải biết những kháng sinh dùng bằng đường uống nào có thể làm giảm hiệu quả của thuốc ngừa thai uống. Vì thế, cần theo dõi một cách thận trọng tác dụng phụ khi dùng thuốc này.


## **3. Cách trị mụn trứng cá không dùng thuốc**
  * Can thiệp phẫu thuật đối với mụn trứng cá có thể được thực hiện bởi bác sĩ da liễu, nhằm loại bỏ những mụn mủ, mụn bọc, mụn đầu đen hay đầu trắng.
  * Bào da vi phẫu có thể được dùng để loại bỏ những lớp trên cùng của da nhằm làm cải thiện những bất thường trên bề mặt da.
  * Lột da nhẹ bằng hóa chất như: salicylic acid hay glycolic acid sẽ giúp giảm tắc nghẽn lỗ chân lông, mở những mụn đầu đen và đầu trắng, cũng như kích thích sự tạo da mới.
  * Tiêm corticosteroids có thể được sử dụng trong điều trị những mụn trứng cá nốt cục; cách này có thể giúp chúng biến mất nhanh hơn.


Trong những trường hợp mụn trứng cá nặng không đáp ứng với điều trị, isotretinoin có thể được dùng. Những bệnh nhân dùng isotretinoin cần phải biết những tác dụng phụ của thuốc này. Theo dõi thường xuyên trong những lần tái khám là cần thiết. Khi đang dùng thuốc này không được có thai, vì thuốc có thể gây quái thai.
  * [1. Các vấn đề về điều trị mụn trứng cá](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/lam-the-nao-dieu-tri-mun-trung-ca-khoa-hoc-hieu-qua#1-cc-vn-v-iu-tr-mn-trng-c)
  * [2. Điều trị mụn trứng cá bằng thuốc](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/lam-the-nao-dieu-tri-mun-trung-ca-khoa-hoc-hieu-qua#2-iu-tr-mn-trng-c-bng-thuc)
  * [3. Cách trị mụn trứng cá không dùng thuốc](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/lam-the-nao-dieu-tri-mun-trung-ca-khoa-hoc-hieu-qua#3-cch-tr-mn-trng-c-khng-dng-thuc)



## Trong cách đọc chỉ số huyết áp, con số nào quan trọng hơn?

  * [Cách đọc chỉ số huyết áp trên các loại máy đo](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/trong-cach-doc-chi-so-huyet-ap-con-so-nao-quan-trong-hon#cch-c-ch-s-huyt-p-trn-cc-loi-my-o)
  * [Cách đọc chỉ số huyết áp trên máy đo huyết áp điện tử](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/trong-cach-doc-chi-so-huyet-ap-con-so-nao-quan-trong-hon#cch-c-ch-s-huyt-p-trn-my-o-huyt-p-in-t)


Thông thường, trong cách đọc chỉ số huyết áp, chỉ số huyết áp tâm thu (số đầu tiên) sẽ được chú ý nhiều hơn vì đây là yếu tố nguy cơ chính của bệnh tim mạch đối với những người trên 50 tuổi. Ở hầu hết mọi người, huyết áp tâm thu tăng dần theo tuổi tác do sự tích tụ của mảng bám lên thành động mạch nhiều theo thời gian khiến thành động mạch xơ cứng lại. Sự tích tụ lâu dài của mảng bám (xơ vữa động mạch) sẽ làm tăng tỷ lệ mắc bệnh tim và mạch máu.
Tuy nhiên, chỉ số huyết áp tâm thu hoặc huyết áp tâm trương đều được sử dụng như điều kiện cần và đủ trong chẩn đoán và điều trị huyết áp cao. Theo các nghiên cứu gần đây, nguy cơ tử vong do bệnh tim thiếu máu cục bộ và đột quỵ tăng gấp đôi với mỗi 20 mmHg tâm thu hoặc 10 mmHg tâm trương tăng lên ở những người từ 40 đến 89 tuổi.
## Cách đọc chỉ số huyết áp trên các loại máy đo
Máy đo huyết áp cơ
Máy đo huyết áp cơ bao gồm vòng bít quấn quanh cánh tay, bầu bóp cao su và đồng hồ đo. Khi thao tác, bác sĩ sẽ dùng thêm một ống nghe để nghe mạch đập tại vị trí khuỷu tay.
Bạn sẽ được quấn vòng bít quanh cánh tay, ở vị trí bắp tay. Sau đó, nhân viên y tế bóp bóng cao su để vòng bít phồng lên, ép chặt vào bắp tay, ngăn chặn máu chảy xuống cánh tay. Khi áp suất trên đồng hồ chỉ khoảng 220 mmHg, van bóng cao su sẽ được xả ra. Kim chỉ áp suất vòng bít sẽ giảm xuống. Lúc này, người đo phải nhìn thật kĩ, kim sẽ tạm ngừng ở chỉ số huyết áp tâm thu trước, tại vị trí với thời điểm nghe thấy tiếng đập đầu tiên của dòng máu vào màng ống nghe, sau đó đến tâm trương, tại vị trí với thời điểm không còn nghe thấy tiếng đập của dòng máu. Khi đã ghi được cả hai chỉ số huyết áp, người đo xả sạch van rồi tháo vòng bít ra khỏi người được đo.
Cách đọc chỉ số huyết áp trên loại máy đo này khó hơn, cần phải được đào tạo và luyện tập nên thường chỉ dành cho các bác sĩ, điều dưỡng hay các nhân viên y tế, bởi nếu cách đo không chính xác sẽ rất dễ gây ra sai số.
### Cách đọc chỉ số huyết áp trên máy đo huyết áp điện tử
Máy đo điện tử dễ sử dụng hơn, phù hợp cho mọi người để đo huyết áp tại nhà.
Máy đo huyết áp điện tử cũng có một vòng bít quấn quanh cánh tay hoặc cổ tay. Để thổi phồng vòng bít, bạn chỉ cần nhấn nút “Star” trên máy đo thì vòng bít sẽ tự động được bơm căng và phồng lên. Sau khi vòng bít được bơm căng, áp suất sẽ tự động giảm dần.
Màn hình sẽ hiển thị chỉ số huyết áp tâm thu, tâm trương và cách đọc máy đo huyết áp điện tử như sau:
  * Chỉ số huyết áp tâm thu, hiển thị ở trên, kí hiệu là **SYS**
  * Chỉ số huyết áp tâm trương, hiển thị ở dưới, kí hiệu là **DIA**
  * Ngoài ra, ở một số máy đo huyết áp kỹ thuật số hiện đại còn thể hiện thêm chỉ số đo nhịp tim, kí hiệu là **PULSE**.


Sau khi hiển thị chỉ số huyết áp, vòng bít sẽ tự động xả hơi ra. Với nhiều loại máy, bạn cần đợi từ 15 đến 30 giây để thực hiện đo lần tiếp theo.
Máy đo huyết áp điện tử sẽ không chính xác nếu cơ thể bạn chuyển động khi đang đo. Ngoài ra, nhịp tim không đều sẽ làm cho kết quả đo kém chính xác hơn.
  * [Cách đọc chỉ số huyết áp trên các loại máy đo](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/trong-cach-doc-chi-so-huyet-ap-con-so-nao-quan-trong-hon#cch-c-ch-s-huyt-p-trn-cc-loi-my-o)
  * [Cách đọc chỉ số huyết áp trên máy đo huyết áp điện tử](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/trong-cach-doc-chi-so-huyet-ap-con-so-nao-quan-trong-hon#cch-c-ch-s-huyt-p-trn-my-o-huyt-p-in-t)



## Chứng ảo tưởng ở người sa sút trí tuệ

  * [1. Khái niệm chứng ảo tưởng](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/chung-ao-tuong-o-nguoi-sa-sut-tri-tue#1-khi-nim-chng-o-tng)
  * [2. Biểu hiện của chứng ảo tưởng ở người sa sút trí tuệ](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/chung-ao-tuong-o-nguoi-sa-sut-tri-tue#2-biu-hin-ca-chng-o-tng-ngi-sa-st-tr-tu)


## **1. Khái niệm chứng ảo tưởng**
Ảo tưởng (tên tiếng Anh là Illusion) là một tri giác không chính xác về một sự vật, hiện tượng, đây là tình trạng không rõ ràng về mặt cảm giác. Chúng có thể ở dạng hoang tưởng, khiến người đó cảm thấy bị đe dọa hoặc một người trải qua ảo tưởng có thể cảm thấy rằng họ đang bị theo dõi hoặc ai đó đang hành động chống lại họ. Họ có thể đi đến kết luận mà không có nhiều bằng chứng. Đây là triệu chứng phổ biến đối với những người sa sút trí tuệ.
Ví dụ, người mắc sa sút trí tuệ luôn nghĩ người khác nói xấu, tìm cách hãm hại mình. Do chứng mất trí nhớ ở sa sút trí tuệ, người đó có thể không còn khả năng kiểm soát những suy nghĩ bất thường trong suy nghĩ.
Nguyên nhân chủ yếu dẫn đến chứng ảo tưởng ở người sa sút trí tuệ là do họ không thể sắp xếp các thông tin và ký ức lại với nhau một cách chính xác, điều này có thể khiến họ đưa ra kết luận sai lầm và tin vào điều gì đó không đúng sự thật. Khi chứng bệnh sa sút trí tuệ ngày càng nghiêm trọng thì khả năng cao họ sẽ bị ảo tưởng.
Ảo tưởng phổ biến hơn ở chứng mất trí nhớ thể Lewy và có thể ảnh hưởng đến những người mắc bệnh Alzheimer và chứng mất trí nhớ mạch máu, đặc biệt là ở giai đoạn sau. Chúng ít phổ biến hơn ở những người mắc chứng mất trí nhớ giai đoạn đầu.
## **2. Biểu hiện của chứng ảo tưởng ở người sa sút trí tuệ**
Chứng ảo tưởng ở người sa sút trí tuệ có các biểu hiện bất thường liên quan đến hành vi và cảm xúc, thậm chí còn ảnh hưởng đến khả năng sinh hoạt hàng ngày.
  * Rối loạn về hành vi: các hành vi bất thường như tích trữ đồ đạc, cười một mình… Ví dụ nếu một người mắc chứng mất trí nhớ không thể tìm thấy một bộ quần áo cụ thể, điều này có thể khiến họ tin rằng nó đã bị đánh cắp. Sự lo lắng này cũng có thể dẫn đến việc họ giấu đồ đạc ở những nơi khác thường, từ đó dẫn đến việc nhiều đồ vật bị ‘mất tích’.
  * Rối loạn về cảm xúc: cảm xúc bất thường, đối với những người thân thì căm thù hoặc rất ghét, ngược lại đối với người dưng lại tin yêu. Ví dụ niềm tin rằng những người thân thiết nhất đang cố làm hại họ – điều này có thể bắt nguồn từ việc tin rằng một người bạn đang mang thức ăn cho họ vì muốn đầu độc họ, đến việc tin rằng đối tác không chung thủy.
  * Rối loạn về hoạt động sinh hoạt hàng ngày như khó ngủ, mất ngủ, căng thẳng, khó tập trung, không muốn tham gia bất kì hoạt động nào.
  * Bên cạnh đó người bệnh có thể xuất hiện ảo thanh như có tiếng nói trong bụng hoặc trong đầu mình. Một số trường hợp luôn cảm thấy mình bị theo dõi, truy sát, bị giết…


  * [1. Khái niệm chứng ảo tưởng](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/chung-ao-tuong-o-nguoi-sa-sut-tri-tue#1-khi-nim-chng-o-tng)
  * [2. Biểu hiện của chứng ảo tưởng ở người sa sút trí tuệ](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/chung-ao-tuong-o-nguoi-sa-sut-tri-tue#2-biu-hin-ca-chng-o-tng-ngi-sa-st-tr-tu)



## Trà lá vối uống có hại không ?

_**Cây lá vối còn có tên gọi khác là trâm nắp thuộc họ sim Myrtaceae. Trong dân gian, có hai loại cây lá vối phổ biến là vối kê và vối tẻ.**_
Cây vối có tốc độ sinh trưởng khá nhanh, có thể cao tới 12-15m khi trưởng thành. Cành cây vối có hình tròn, đôi khi có hình 4 cạnh, nhẵn. Lá vối có hình dạng khá đa dạng như trái xoan, bầu dục và có xu hướng giảm nhọn ở gần phía gốc cây. Lá vối có phiến lá dày, có hai đốm màu nâu. Cây vối có thời gian ra hoa từ tháng 5 tới tháng 7 hằng năm, quả vối hình cầu, có dịch và khi chín có màu tím giống như cây sim.
Cây lá vối được phân bố chủ yếu ở những vùng khí hậu nhiệt đới như Việt Nam, Lào, Ấn Độ, Trung Quốc,… Ở Việt Nam, cây vối xuất hiện nhiều ở các bờ ao, bờ suối tại các khu vực như các tỉnh miền núi phía Bắc, Thanh Hóa, Nghệ An, và một số tỉnh ở Tây Nguyên.
**Tác dụng của lá vối**
Cây vối chứa một số khoáng chất, vitamin và tinh dầu tạo nên mùi thơm nhẹ, dễ chịu. Ngoài ra, vối cũng chứa kháng sinh giúp tiêu diệt một số vi khuẩn có hại cho cơ thể. Trong nụ vối có chứa thành phần β – sitosterol giúp chuyển hóa cholesterol làm giảm mỡ máu. Trong vối cũng có các chất béo, tannin catechic, sterol và gallic.
Lá vối có vị hơi đắng và chát, chứa một số ít thành phần độc tố nhẹ. Nếu biết sử dụng đúng cách, các độc tố này sẽ mang lại tác dụng sát trùng, thanh lọc cơ thể điều hòa gan phổi rất tốt.
Cây lá vối có tính mát, vị đắng chát, có tác dụng thanh nhiệt, tiêu đờm, hạ khí, sát trùng, do vậy từ lâu được người dân dùng để làm trà uống giải khát.
Các bộ phận như vỏ thân, lá, nụ của cây vối đều được làm thuốc chữa bệnh. Lá vối tươi hay khô sắc đặc đều có tính chất sát trùng, rất thích hợp để rửa những mụn nhọt, lở loét, ghẻ, ngứa.
**Tác hại của lá vối**
Thông thường, uống nước lá vối hầu như không có tác hại gì trừ khi uống sai cách hoặc sai thời điểm. Nếu uống nước vối khi đói hoặc uống quá nhiều thì chính nước vối lại là nguyên nhân gây hại đến sức khỏe người dùng. 
Phụ nữ có thai cũng cần thận trọng khi dùng, không nên uống nước vối quá đặc làm ảnh hưởng tới hệ tiêu hóa. Cũng không nên uống quá nhiều nước vối.
Nên uống nước từ lá vối khô, nên hạn chế dùng lá vối tươi vì có chứa chất kháng khuẩn, kháng viêm, có thể gián tiếp tiêu diệt vi khuẩn có lợi, gây nên tình trạng hao huyết.
Không nên uống nước lá vối ngay sau bữa ăn vì có thể ảnh hưởng tới quá trình tiêu hóa.
Trẻ em không nên uống nước lá vối.
**Uống nước vối hại thận không?**
Nhiều tin đồn cho rằng uống nước vối hại thận. Tuy nhiên, trên thực tế các bác sĩ đã nghiên cứu và khẳng định rằng việc uống nước vối không gây hại thận.

## Điều nên làm ở bệnh nhân Parkinson

  * [Bạn đã từng được chẩn đoán mắc bệnh Parkinson – Hiện tại tình hình ra sao?](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/dieu-nen-lam-o-benh-nhan-parkinson#bn-tng-cchn-on-mc-bnh-parkinson-hin-ti-tnh-hnh-ra-sao)
  * [Gắn kết với Bác sĩ điều trị](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/dieu-nen-lam-o-benh-nhan-parkinson#gn-kt-vi-bc-s-iu-tr)
  * [Tập hợp thành nhóm, thành câu lạc bộ bệnh nhân](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/dieu-nen-lam-o-benh-nhan-parkinson#tp-hp-thnh-nhm-thnh-cu-lc-b-bnh-nhn)
  * [Luyện tập, luyện tập và luyện tập](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/dieu-nen-lam-o-benh-nhan-parkinson#luyn-tp-luyn-tp-v-luyn-tp)
  * [Thay đổi phương pháp tập luyện](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/dieu-nen-lam-o-benh-nhan-parkinson#thay-i-phng-php-tp-luyn)
  * [Đăng ký tham gia các thử nghiệm lâm sàng](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/dieu-nen-lam-o-benh-nhan-parkinson#ng-k-tham-gia-cc-th-nghim-lm-sng)
  * [Trở thành phát ngôn viên](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/dieu-nen-lam-o-benh-nhan-parkinson#tr-thnh-pht-ngn-vin)
  * [Tham gia vào đội ngũ hỗ trợ](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/dieu-nen-lam-o-benh-nhan-parkinson#tham-gia-vo-i-ng-h-tr)
  * [Lên kế hoạch cho tương lai](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/dieu-nen-lam-o-benh-nhan-parkinson#ln-k-hoch-cho-tng-lai)


### Bạn đã từng được chẩn đoán mắc bệnh Parkinson – Hiện tại tình hình ra sao?
Bệnh Parkinson là một bệnh thoái hóa hệ thần kinh ngày càng nặng dần, tuy nhiên hầu hết những người mắc bệnh Parkinson đều có thể có một cuộc sống tốt kéo dài nhiều năm nếu có kế hoạch chăm sóc thật tốt. Trong khi chưa có phương pháp nào được cho là “bảo vệ hệ thần kinh” hoặc “chữa lành bệnh” thì có một bằng chứng mạnh mẽ rằng bệnh nhân Parkinson có thể cải thiện chất lượng sống bằng cách dùng các biện pháp làm tăng cường thể chất và tinh thần của họ. Với sự hỗ trợ tích cực của các chuyên gia hàng đầu về thần kinh học và các chuyên gia rối loạn vận động trên khắp đất nước và cộng đồng, hội bệnh Parkinson và rối loạn vận động Việt Nam là cơ hội tốt để phát triển một đội ngũ quản lý chăm sóc sức khỏe. Hãy giữ tinh thần lạc quan và thực hiện đúng theo 10 điều sau mà bạn có thể làm ngay bây giờ.
### Gắn kết với Bác sĩ điều trị
Bác sĩ có thể kê toa một hoặc nhiều loại thuốc để điều trị các triệu chứng cho bạn. Quan trọng là bạn phải tuân theo nghiêm ngặt sự hướng dẫn của bác sĩ , nhưng phải thừa nhận rằng mỗi người sẽ có đáp ứng với thuốc trị Parkinson khác nhau. Hãy tự thực hiện các nghiên cứu riêng cho từng loại thuốc hiện có và thảo luận về các rủi ro và hiệu quả của mỗi loại với bác sĩ điều trị của bạn. Với một số người, nguy cơ tác dụng phụ vượt trên lợi ích. Bác sĩ cần sự hợp tác của bạn để tìm ra loại thuốc tốt nhất cho bạn.
### Tập hợp thành nhóm, thành câu lạc bộ bệnh nhân
“Nhóm” chăm sóc của bạn không chỉ gồm bác sĩ và điều dưỡng, mà cần phải có các chuyên gia về sức khỏe khác như chuyên viên về âm ngữ trị liệu, vật lý trị liệu và hướng nghiệp, có thể giúp bạn sống tốt hơn khi mắc bệnh Parkinson. Nhiều người mắc bệnh Parkinson đều nhận thấy những phương pháp này có thể giúp họ giảm bớt các triệu chứng, làm giảm đau, và nâng cao đời sống. Kể cả khi bệnh tiến triển sớm, chuyên gia vật lý trị liệu vẫn có thể thiết lập cơ sở để theo dõi và giúp bạn lên một chương trình tập luyện. Các bác sĩ chuyên khoa thần kinh cần cung cấp các khuyến cáo về việc điều trị và, nếu bạn cần, cung cấp thêm một giấy giới thiệu.
### Luyện tập, luyện tập và luyện tập
Trong khi tập thể dục góp phần trong việc trì hoãn sự tiến triển của bệnh và các triệu chứng vẫn còn đang được nghiên cứu, thì các nghiên cứu sinh đã liên tục đưa ra báo cáo rằng những người mắc bệnh Parkinson thường xuyên tập thể dục sẽ đáp ứng tốt hơn những người không tập thể dục. Rất nhiều chuyên gia đã khuyên rằng bạn nên tập thể dục ngoài trời với cường độ cao trong điều kiện môi trường thoải mái có thể đạt được lợi ích tối đa, nhưng các nghiên cứu sinh cũng đưa ra những lợi ích khác từ các hoạt động ít căng thẳng như đi bộ, nhảy tango và thái cự quyền (Tai chi). Như mọi lần, cần xin ý kiến bác sĩ điều trị trước khi bắt đầu bất kỳ chương trình luyện tập nào.
### Ăn uống hợp lý
Không chấp nhận bất kỳ chế độ ăn kiêng hoặc chế độ tăng cân nào đối với người bệnh Parkinson, nhưng hầu hết đều đồng tình với lời khuyên rằng một chế độ ăn kiêng lành mạnh cùng uống thật nhiều nước là rất quan trọng. Việc ăn uống lành mạnh có thể giúp cho xương chắc, giảm nguy cơ gãy xương nếu vô tình té ngã. Nó cũng giúp bạn tránh khỏi táo bón, triệu chứng luôn đi kèm với bệnh parkinson.
### 
Chúng ta đều biết một giấc ngủ ngon rất tốt cho thể chất và sức khỏe. Tuy nhiên, với những người bệnh Parkinson, giấc ngủ lại trở nên vô cùng quan trọng vì cơ thể cần nhiều thời gian để hồi phục và tự điều chỉnh lại. Rối loạn giấc ngủ là bệnh gắn liền với bệnh Parkinson, nhưng hãy nghỉ ngơi ngay khi bạn có thể.
### Thay đổi phương pháp tập luyện
Các phương pháp khác thay thế và bổ sung để điều trị bệnh Parkinson gồm yoga, Thái cực quyền, thiền, hoặc mát xa. Xin ý kiến bác sĩ điều trị hoặc bác sĩ đa khoa trước khi bắt đầu các khóa học. Cần tránh các học viên khuyên bạn điều trị bệnh Parkinson, những người khuyên bạn ngưng thuốc đột ngột hoặc những người đang bỏ uống thuốc (trừ khi bạn đã trao đổi trước với bác sĩ điều trị).
### Đăng ký tham gia các thử nghiệm lâm sàng
Nghiên cứu khoa học là chìa khóa để hiểu thêm về bệnh Parkinson, phát triển những phương pháp điều trị tốt hơn, làm chậm tiến độ phát bệnh, và cuối cùng là tìm ra cách để chữa bệnh. Bằng việc tham gia vào các cuộc thử nghiệm lâm sàng, bạn đã đóng một vai trò tích cực trong việc tự chăm sóc sức khỏe và có thể đến gần hơn với một phương pháp điều trị bệnh Parkinson mới trước khi nó được phổ biến rộng rãi. Đã có nhiều cuộc thử nghiệm lâm sàng dành cho những phương pháp mới có nhiều tiềm năng và những phương pháp điều trị được phát triển với chi phí thấp nhưng vẫn chưa thể hoàn thiện được vì quá ít người tình nguyện tham gia.
### Trở thành phát ngôn viên
Bạn sẽ trở thành một phát ngôn viên về bệnh Parkinson một khi bạn tham gia vào các hoạt động nhằm cải thiện cuộc sống của cộng đồng những người mắc bệnh Parkinson. Dù lĩnh vực bạn chọn là nâng cao nhận thức, gây quỹ, làm từ thiện, tình nguyện viên, tham gia mạng lưới của hội Parkinson với tư cách là một phát ngôn viên online hoặc thậm chí là hỗ trợ vay vốn, thì công việc của mỗi phát ngôn viên đều làm tăng tiếng nói cho toàn thể cộng đồng người bệnh Parkinson.
### Tham gia vào đội ngũ hỗ trợ
Hội Bệnh Parkinson và rối loạn vận động Việt Nam đã, đang và sẽ cung cấp rất nhiều chương trình cho những bệnh nhân Parkinson và các đội ngũ chăm sóc. Những chương trình này giúp các hộ gia đình giải quyết các vấn đề hàng ngày, tạo một diễn đàn để hội tụ những người mắc bệnh Parkinson và phục vụ như một nơi để kết bạn và trao đổi các kinh nghiệm lẫn nhau. Với những người mắc bệnh Parkinson, đội ngũ hỗ trợ của họ chính là cánh cổng dẫn vào một thế giới dành riêng cho người bệnh parkinson với sự ủng hộ nhiệt tình, sự giáo dục, và những dịch vụ có trong cộng đồng.
### Lên kế hoạch cho tương lai
Bệnh Parkinson có thể yêu cầu bạn phải lập một bản dự trù kinh phí cho tiền thuốc, sự thích nghi nhà ở, bảo hiểm và các nhu cầu chăm sóc sức khỏe liên quan khác. Bạn cũng có thể tìm một công việc cho mình. Các thông tin để lập kế hoạch tài chính và các công cụ đều có sẵn trên các trang mạng trực tuyến và từ các nhà hoạch định tài chính và bất động sản, các luật sư chăm sóc cho người già và những tư vấn viên người khuyết tật.
(Theo APDA)
  * [Bạn đã từng được chẩn đoán mắc bệnh Parkinson – Hiện tại tình hình ra sao?](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/dieu-nen-lam-o-benh-nhan-parkinson#bn-tng-cchn-on-mc-bnh-parkinson-hin-ti-tnh-hnh-ra-sao)
  * [Gắn kết với Bác sĩ điều trị](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/dieu-nen-lam-o-benh-nhan-parkinson#gn-kt-vi-bc-s-iu-tr)
  * [Tập hợp thành nhóm, thành câu lạc bộ bệnh nhân](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/dieu-nen-lam-o-benh-nhan-parkinson#tp-hp-thnh-nhm-thnh-cu-lc-b-bnh-nhn)
  * [Luyện tập, luyện tập và luyện tập](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/dieu-nen-lam-o-benh-nhan-parkinson#luyn-tp-luyn-tp-v-luyn-tp)
  * [Thay đổi phương pháp tập luyện](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/dieu-nen-lam-o-benh-nhan-parkinson#thay-i-phng-php-tp-luyn)
  * [Đăng ký tham gia các thử nghiệm lâm sàng](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/dieu-nen-lam-o-benh-nhan-parkinson#ng-k-tham-gia-cc-th-nghim-lm-sng)
  * [Trở thành phát ngôn viên](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/dieu-nen-lam-o-benh-nhan-parkinson#tr-thnh-pht-ngn-vin)
  * [Tham gia vào đội ngũ hỗ trợ](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/dieu-nen-lam-o-benh-nhan-parkinson#tham-gia-vo-i-ng-h-tr)
  * [Lên kế hoạch cho tương lai](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/dieu-nen-lam-o-benh-nhan-parkinson#ln-k-hoch-cho-tng-lai)



## 8 loại cây giúp cải thiện chức năng gan

Khi gan suy yếu, khả năng giải độc gan cho cơ thể sẽ giảm, nồng độ các chất độc trong cơ thể tăng lên rõ rệt và nguyên nhân gây nên nhiều bệnh lý như gan nhiễm mỡ, ung thư, tiểu đường, hôn mê gan, giảm trí nhớ, sạm da,... Các tế bào gan do không được bảo vệ sẽ dẫn đến bệnh xơ gan và ung thư gan, rối loạn chức năng gan.
**Giải độc gan: chìa khóa là cải thiện chức năng gan**
Hiểu rõ được tầm quan trọng của gan, nếu bạn thật sự là người quan tâm đến sức khỏe của mình. Hãy theo dõi những lợi ích sau đây nếu bạn thực hiện việc giải độc gan:
- Cải thiện chức năng và giảm vấn đề bệnh tật ở gan.
- Trợ giúp tiêu hóa, thúc đẩy sự trao đổi chất.
- Thanh lọc máu
- Làm sạch ống mật
- Kiểm soát dị ứng
- Giảm nguy cơ sỏi mật và làm giảm đau bụng do rối loạn túi mật
- Giảm các triệu chứng chữa bệnh như mệt mỏi, đau đầu, buồn nôn, chán ăn...
Cùng xem ngay những loại trái cây bên dưới có chức năng hỗ trợ thải độc gan tăng cường chức năng gan hiệu quả bạn nhé 

## Cao huyết áp có nên uống hoạt huyết dưỡng não không? Những đối tượng không thể sử dụng

Hiện nay, trên thị trường có rất nhiều các loại hoạt huyết dưỡng não, tuy nhiên đa phần chúng đều có các thành phần như:
  * Cao đinh lăng
  * Cao bạch quả
  * Ngưu tất, ích mẫu, xuyên khung, đan sâm
  * Đương quy, Sinh địa
  * Đậu tương lên men


### Cao huyết áp có nên uống hoạt huyết dưỡng não không?
Huyết áp cao là tình trạng liên quan đến áp lực của máu lên thành động mạch. Trong khi đó, viên uống hoạt huyết dưỡng não với tác dụng làm lưu thông tuần hoàn máu lên não. Do đó, việc người cao huyết áp uống hoạt huyết dưỡng nào cũng góp một phần giúp hỗ trợ điều trị bệnh.
Cụ thể, chiết xuất từ ngưu tất có trong thành phần của hoạt huyết dưỡng não chứa saponin và nhiều acid amin khác. Những hợp chất này có công dụng giảm cholesterol máu, hạ và ổn định huyết áp. Từ đó rất có ích trong việc giúp máu lưu thông đến các cơ quan quan trọng như não, tim và khắc cơ thể một cách dễ dàng.
Ngoài ra, hoạt huyết dưỡng não có tác dụng lên thần kinh giúp bạn cải thiện giấc ngủ, tránh tình trạng mất ngủ, giảm bớt căng thẳng, mệt mỏi. Đây cũng là một trong những yếu tố nguy cơ gây ra bệnh cao huyết áp. Vì vậy đối với người huyết áp cao kèm theo mất ngủ, viên uống hoạt huyết dưỡng não sẽ mang lại hiệu quả rất tốt.
Dù mang lại nhiều lợi ích, nhưng vì hoạt huyết dưỡng não có tác dụng lên hệ thần kinh trung ương nên không phải ai cũng có thể sử dụng. Với người bị cao huyết áp, có thể chia làm 2 đối tượng: Người dùng được hoạt huyết dưỡng não và người không dùng được.
**Những đối tượng có thể dùng**
Bệnh nhân cao huyết áp**có thể** dùng hoạt huyết dưỡng khi họ có vấn đề về tuần hoàn máu hoặc căn bệnh về thần kinh trung ương, cụ thể:
  * Người có vấn đề về giấc ngủ như: Mất ngủ, ngủ không ngon, thường xuyên stress.
  * Người có công việc là lao động trí óc, lưu lượng công việc nhiều và đòi hỏi sự tập trung cao độ.
  * Người mắc bệnh thiếu máu lên não, thường xuyên đau đầu.
  * Người lớn tuổi mắc bệnh suy giảm trí nhớ.


**Những đối tượng không thể sử dụng**
Những bệnh nhân cao huyết áp kèm theo một số tình trạng đặc biệt dưới đây sẽ tuyệt đối **không được** uống hoạt huyết dưỡng não:
  * Trẻ em dưới 12 tuổi.
  * Phụ nữ mang thai.
  * Người đang trong kỳ kinh nguyệt.
  * Người mẫn cảm với các thành phần của thuốc.
  * Người bị mắc các căn bệnh về rối loạn đông máu.
  * Người có trí tuệ kém, thiểu năng do bẩm sinh.


_**Tóm lại, cao huyết áp có nên uống hoạt huyết dưỡng não hay không còn phụ thuộc vào tình trạng bệnh của mỗi người xem có kèm theo triệu chứng nào đặc biệt không.**_

## PHÂN BIỆT X-RAYS, CT SCAN, MRI, PET SCAN , ULTRA SOUND (SIÊU ÂM)

  * [1. X-rays (X-quang ) là gì ?](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/phan-biet-x-rays-ct-scan-mri-pet-scan-ultra-sound-sieu-am#1-xrays-xquang-l-g-)
  * [2. CT scan là gì ?](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/phan-biet-x-rays-ct-scan-mri-pet-scan-ultra-sound-sieu-am#2-ct-scan-l-g-)
  * [4. PET scan là gì ?](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/phan-biet-x-rays-ct-scan-mri-pet-scan-ultra-sound-sieu-am#4-pet-scan-l-g-)
  * [5. Siêu âm, ultrasound là gì ?](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/phan-biet-x-rays-ct-scan-mri-pet-scan-ultra-sound-sieu-am#5-siu-m-ultrasound-l-g-)


## **1. X-rays (X-quang ) là gì ?**
Để hiểu X-quang là gì, trước hết hãy tìm hiểu khái niệm về “sóng điện từ trường” (electromagnetic wave, electromagnetic radiation).
Chung quanh chúng ta luôn luôn hiện hữu một không gian năng lượng dưới dạng điện từ trường, trong đó ánh sánh mặt trời, hay ánh sáng mà chúng ta thấy được cũng chỉ là một dạng sóng điện từ trường. Có nhiều loại sóng từ trường, từ yếu đến mạnh theo thứ tự, gồm có: sóng radio, sóng microwaves, sóng hồng ngoại (infared, IR, dùng trong các remote controls), ánh sáng thường, tia cực tím còn gọi là tia tử ngoại (ultraviolet light, UV), tia X-quang, và cuối cùng là gamma-rays. Như thế chỉ có 3 loại sóng mạnh hơn là ánh sáng thường. Sóng càng mạnh, độ “xuyên thủng” qua tế bào càng nhiều. Ba tia X-rays, UV, và Gamma đều được sử dụng trong y học để truy tầm hay chữa bệnh. Trong khi đó, ánh sáng thường trở xuống, khi đụng vật cản đa phần sẽ bị phản chiếu và ít ảnh hưởng đến cấu trúc hay làm hư hại vật thể bên trong. Mở ngoặc một tí cho vui, tôi nói “đa phần” ở đây vì sóng có thể tồn tại dưới dạng sóng (wave), năng lượng (energy), và vật chất (matter), vì thế năng lượng có khi một phần bị hấp thụ mà không phản chiếu ra. Có thể hiểu, cơ thể chúng ta, có lúc hiện hữu chỉ là một khối lượng sóng và năng lượng trong không gian điện từ trường.
## **2. CT scan là gì ?**
CT scan còn gọi là CAT scan, viết tắt của hai chữ “computed tomography”, được phát minh năm 1967 bởi một kỹ sư người Anh tên là Godfrey Hounsfield. CT cho ta thấy hình chụp của cơ thể theo dạng mặt cắt, một khối 3 chiều, thể hiện trên những mặt phẳng hai chiều. Mỗi một hình ảnh là tập hợp bởi nhiều tia X-rays, bắn đi từ nhiều hướng khác nhau vòng quanh cơ thể. Khi chụp hình bằng X-ray thường, tia sáng bắn đi một chiều nên hình ảnh chồng lên nhau. Thí dụ chụp hình phổi, ta thấy cả tim phổi xương sườn chồng lên nhau làm cho khó thấy rõ chỗ bị bệnh. CT scan dùng computer để tổng hợp hình X-rays từ nhiều góc độ khác nhau, để có thể để tạo ra hình chụp rõ ràng, giống như cơ thể được cắt ngang từng lát mỏng.
## **3. MRI là gì ?**
Một hạn chế của X-rays là nó xuyên qua cơ thể và mang theo phóng xạ (radiation) vì thế ngày nay MRI có nhiều lợi thế hơn. MRI viết tắt của ba chữ, Magnetic Resonance Imaging. MRI được sáng chế bởi Paul C. Lauterbur vào năm 1971, nhưng kỹ thuật không được hoàn thiện mãi cho đến những năm 1990’s Nguyên tắc của MRI là tạo ra một từ trường chung quanh phần cơ thể muốn chụp hình. Vì trong cơ thể chúng ta hầu hết là… nước, mà phân tử nước có chứa nguyên tử Hygrogen mang điện cực dương, còn gọi là proton. Khi bị kích động bởi từ trường, những hạt proton như bị “sắp hàng lại” và rung lên, phát ra sóng radio. Máy computer sẽ ghi nhận sóng radio nầy thành hình ảnh.
Như vậy, chung chung, MRI an toàn, và kỹ thuật càng ngày càng tiến bộ, độ chính xác nhiều hơn là CT.
## **4. PET scan là gì ?**
PET scan là chữ viết tắt của Positron Emission Tomography. PET scan là một thử nghiệm dùng chất phóng xạ để truy tầm những dấu hiệu bất bình thường trong cơ thể, hầu hết là truy tầm bệnh ung thư hay ung thư di căn. Tuỳ theo trường hợp, bệnh nhân sẽ được tiêm, uống, hay hít thở hơi có chất phóng xạ, gọi là radiotracer. Nguyên tắc là, các tế bào bất thường, như ung thư chẳng hạn, thường tụ tập thành khối u, và sử dụng nhiều máu, nhiều oxigen, ăn nhiều đường, tiêu hoá và sanh sản nhanh hơn tế bào thường. Như thể nhờ vào chất phóng xạ, những chỗ bất thường nầy sẽ hiện lên hình bất thường ở những tụ điểm. PET scan thường kết hợp với CT hay MRI, vì hai thử nghiệm trên chỉ phát hiện hình ảnh, thí dụ khối u chẳng hạn, trong khi đó PET sẽ cho biết khối u đó là ung thư hay không.
## **5. Siêu âm, ultrasound là gì ?**
Ultrasound, còn gọi là sonogram, là thử nghiệm dùng sóng âm thanh, siêu âm để tạo ra hình ảnh. Tương tự như sóng radar mà các loài dơi dùng để định hướng, hay ứng dụng dò tìm tàu ngầm, tìm máy bay cho trạm không lưu, hay tìm… cá cho dân đi câu! Thiết bị phát âm thanh sẽ bắn ra sóng âm thanh, khi đụng vật thể muốn dò tìm sẽ dội lại tạo ra hình ảnh. Nhiều hỏi siêu âm có an toàn không Xin trả lời là rất an toàn, vì nó chỉ là sóng âm thanh, không có phóng xạ gì cả. Chỉ là âm thanh mà chỉ có loài dơi hay những chú chó có thể nghe được mà thôi.
--------------------------------------------------------------
**Cre: BS Hồ Ngọc Minh**
  * [1. X-rays (X-quang ) là gì ?](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/phan-biet-x-rays-ct-scan-mri-pet-scan-ultra-sound-sieu-am#1-xrays-xquang-l-g-)
  * [2. CT scan là gì ?](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/phan-biet-x-rays-ct-scan-mri-pet-scan-ultra-sound-sieu-am#2-ct-scan-l-g-)
  * [4. PET scan là gì ?](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/phan-biet-x-rays-ct-scan-mri-pet-scan-ultra-sound-sieu-am#4-pet-scan-l-g-)
  * [5. Siêu âm, ultrasound là gì ?](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/phan-biet-x-rays-ct-scan-mri-pet-scan-ultra-sound-sieu-am#5-siu-m-ultrasound-l-g-)



## Tại sao trong một số bệnh, cơn đau như viêm tụy cấp, đau quặn thận lại nôn và bí trung đại tiện?

✍Trong một số bệnh, như viêm tụy cấp và đau quặn thận, các triệu chứng như nôn và bí trung đại tiện có thể xuất hiện do một số cơ chế sinh lý và y tế liên quan đến sự tổn thương và viêm nhiễm trong cơ thể. Dưới đây là giải thích cho hai bệnh lý này:
✅ Viêm tụy cấp: Viêm tụy cấp là tình trạng viêm nhiễm cấp tính của tụy, một cơ quan quan trọng nằm ở phần trên của hộp sọ, phía sau và dưới dạ dày. Trong viêm tụy cấp, vi khuẩn hoặc các tạp chất có thể gây tổn thương và viêm nhiễm tụy. Cơn đau trong viêm tụy cấp thường là rất cấp tính và gay gắt, thường xuất hiện ở phần trên và sau bên trái của bụng. Đau có thể lan ra cả hai bên của cơ thể. Một số bệnh nhân cũng có thể bị nôn và nôn mửa. Đây là do việc viêm nhiễm và sưng tấy trong tụy gây ra sự kích thích trên các dây thần kinh trong khu vực bụng, dẫn đến cảm giác mệt mỏi, buồn nôn và nôn mửa.
✅Đau quặn thận: Đau quặn thận thường là do sự tắc nghẽn của một hoặc nhiều niệu quản (ống dẫn nước tiểu từ thận đến bàng quang) hoặc do sự cản trở của các đá thận (sỏi thận). Khi có tắc nghẽn hoặc cản trở, dòng chảy nước tiểu bị gián đoạn và áp lực trong niệu quản và thận tăng lên. Điều này gây ra cơn đau quặn mạn tính ở vùng thắt lưng hoặc bên hông của cơ thể, thường lan rộng từ vùng thắt lưng trên đến xương chậu hoặc vùng bụng. Cơn đau thường có thể kéo dài và làm mất ngủ. Ngoài ra, sự kích thích và áp lực trong hệ thống niệu quản và thận cũng có thể gây ra cảm giác buồn nôn và nôn mửa, cũng như gây ra sự tăng hấp thụ nước và muối trong ruột, dẫn đến bí trung đại tiện.

## Thịt gà có tác dụng gì với sức sức khỏe? Gãy xương ăn được không

Thịt gà gồm có các loại thịt là ức, đùi, má đùi gà và cánh gà. Trong mỗi 100g của từng loại thịt gà lại có thể thành phần dinh dưỡng khác khau, cụ thể:
**Loại thịt gà** | **Thành phần dinh dưỡng**  
---|---  
Ức gà (không da, không xương)  | 
  * 165 calo
  * 3,6 gam chất béo.
  * 31 gram protein. 

  
Đùi gà (không da, không xương)  | 
  * 290 calo.
  * 26 gam protein.
  * 10,9 gam chất béo.

  
Má đùi gà (không xương)  | 
  * 172 calo.
  * 28,3 gram protein.
  * 5,7 gam chất béo.

  
Cánh gà (không da, không xương)  | 
  * 203 calo.
  * 30,5 gram protein.
  * 8,1 gram chất béo. 

  
_Mỗi loại thịt gà lại có giá trị dinh dưỡng khác nhau._
Ngoài các chất dinh dưỡng kể trên, trong thịt gà còn nhiều dưỡng chất tốt cho sức khỏe khác như: axit amin tryptophan, phốt pho, canxi, selenium, retinol, lycopene, vitamin B6, Niacin, alpha và beta-carotene… Các tác dụng của thịt gà với sức khỏe con người đó là: 
– Giảm cân và phát triển cơ bắp: Thịt gà giàu đạm nhưng ít chất béo nên giúp giảm cân lành mạnh và lâu dài đồng thời còn là thực phẩm được ưu tiên khi sử dụng khi muốn phát triển cơ bắp.
– Cải thiện tâm trạng, trầm cảm: Hàm lượng lớn axit amin tryptophan trong thịt gà có công dụng làm tăng nồng độ serotonin trong não nên có thể cải thiện tâm trọng và trầm cảm.
– Bảo vệ tim và ngăn ngừa các bệnh lý tim mạch: Sở dĩ thịt gà có tác dụng này vì có khả năng kiểm soát axit amin homocysteine – tác nhân gây ảnh hưởng tới sức khỏe tim mach. 
– Hỗ trợ phát triển răng và xương: Các khoáng chất canxi, phốt pho được tìm thấy trong thịt gà giúp hỗ trợ phát triển xăng và xương tối ưu, khỏe mạnh. Đồng thời ăn thịt gà còn giúp ngăn ngừa hiện tượng loãng xương cũng như các bệnh về răng. Ngoài ra, ăn thịt gà còn giúp phòng ngừa các bệnh liên quan với xương, bệnh viêm khớp hiệu quả.
– Tăng sức khỏe hệ miễn dịch: Khoáng chất selenium giúp tăng cường sức khỏe cho hệ miễn dịch và hoạt động trao đổi chất trong cơ thể diễn ra thuận lợi hơn, từ đó phòng ngừa bệnh tật hữu hiệu. Và thật may mắn khi trong thịt gà có khoáng chất này. 
– Thúc đẩy trao đổi chất: Nhờ có vitamin B6 nên khi ăn thịt gà còn giúp thúc đẩy hoạt động trao đổi chất và tiêu hóa thức ăn
– Chống lại ung thư: Vitamin Niacin trong thịt gà có khả năng chống lại ung thư. Vì vậy bạn nên bổ sung thịt gà vào chế độ ăn uống hàng ngày để ngăn chặn nguy cơ mắc các bệnh lý ung thư.
– Tốt cho mắt: Hàm lượng retinol, lycopene, alpha và beta-carotene dồi dào trong thịt gà rất tốt cho sức khỏe của mắt. 
Theo kinh nghiệm dân gian và các tài liệu Đông y, người bị gãy xương, người sau mổ và người có vết thương hở đều không nên ăn thịt gà vì có thể khiến tình trạng bệnh nghiêm trọng hơn. Tuy nhiên, đây chỉ là thông tin truyền miệng và chưa có nghiên cứu khoa học nào chứng minh.
Ngược lại, các nghiên cứu y học hiện đại lại cho rằng, bệnh nhân bị gãy xương, bệnh nhân sau mổ về xương khớp vẫn có thể ăn thịt gà nhưng chỉ nên ăn sau khi vết mổ đã lành. Loại thịt này rất giàu đạm và canxi nên giúp xương mau liền và phục hồi sức khỏe nhanh hơn.
**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/) **- Đa khoa Hạng I Thành phố Hồ Chí Minh

## Cấu tạo và chức năng của da

  * [Chức năng của da](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/cau-tao-va-chuc-nang-cua-da#chc-nng-ca-da)
  * [1. Chức năng của da: Bảo vệ](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/cau-tao-va-chuc-nang-cua-da#1-chc-nng-ca-da-bo-v)
  * [2. Chức năng của da: Điều chỉnh nhiệt](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/cau-tao-va-chuc-nang-cua-da#2-chc-nng-ca-da-iu-chnh-nhit)
  * [4. Chức năng nội tiết](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/cau-tao-va-chuc-nang-cua-da#4-chc-nng-ni-tit)


Cấu trúc, thành phần và các lớp của da.
  * **Biểu bì** : Lớp trên cùng
  * **Trung bì** : Lớp giữa
  * **Lớp dưới da** : Lớp dưới cùng hoặc lớp mỡ


### Lớp biểu bì
Là lớp đàn hồi ở bên ngoài liên tục được tái tạo, bao gồm:
  * **Keratinocytes** : Các tế bào sừng sản xuất keratin (protein dạng sợi dai). Tế bào này được hình thành do sự phân chia tế bào ở lớp đáy. Các tế bào mới liên tục di chuyển từ lớp thấp nhất của biểu bì lên các lớp trên cùng, chúng dần dần thành tế bào chết dẹt.
  * **Corneocytes:** Các tế bào sừng chết kết hợp với nhau tạo nên lớp ngoài cùng của lớp biểu bì được gọi là lớp sừng. Lớp bảo vệ này liên tục bị bào mòn hoặc bong ra.
  * **Melanocytes:**(Tế bào biểu bì tạo hắc tố) sản xuất sắc tố melanin bảo vệ da. Nhờ melanin mà chức năng của da chính là chống lại bức xạ cực tím, cũng như mang lại màu sắc cho da.


**Lớp trung bì**
Là lớp bên trong bao gồm:
  * **Các tuyến mồ hôi** : Sản xuất ra mồ hôi thông qua các ống dẫn mồ hôi đến lỗ trên lớp biểu bì được gọi là lỗ chân lông. Chúng đóng vai trò điều hòa nhiệt độ.
  * **Nang lông:** Đóng vai trò trong việc điều chỉnh nhiệt độ.
  * **Các tuyến bã nhờn** : Việc sản xuất bã nhờn giúp giữ cho lông không bị bám bụi bẩn và vi khuẩn. Bã nhờn và mồ hôi tạo nên lớp màng bề mặt.


### **Lớp hạ bì**
  * Lớp hạ bì được tạo thành từ mô liên kết và chất béo (chất cách nhiệt tốt).


## Chức năng của da
Da có những chức năng gì? Da có bốn chức năng chính:
### **1. Chức năng của da: Bảo vệ**
Da người có những chức năng gì? Da là tuyến phòng thủ đầu tiên, giúp chống lại môi trường bên ngoài. Lớp biểu bì liên tục bổ sung và loại bỏ hàng chục nghìn tế bào chết để bảo vệ cơ thể khỏi:
  * **Tác động cơ học** : Da đóng vai trò là hàng rào vật lý đầu tiên giúp chống lại mọi áp lực, tác động hoặc chấn thương. Khi tác động cơ học mạnh lên da, vết thương sẽ xuất hiện.
  * **Chất lỏng** : Do sự liên kết chặt chẽ của các tế bào ở lớp ngoài cùng biểu bì (lớp sừng), da có khả năng giữ chất lỏng và độ ẩm cần thiết, đồng thời bảo vệ cơ thể khỏi sự hấp thụ chất lỏng bên ngoài. Từ đó, chúng ta có thể tắm, bơi và đi bộ dưới mưa mà không cần lo lắng sự hấp thụ của bất kỳ chất có hại nào hay vấn đề mất nước quá mức qua da.
  * **Bức xạ** : Hắc sắc tố melanin trong lớp biểu bì giúp chống lại bệnh da liễu như ung thư da. Tuy vậy, để đảm bảo an toàn cho sức khoẻ da, chúng ta nên tránh tiếp xúc quá nhiều với ánh nắng mặt trời bằng cách sử dụng kem chống nắng và mặc quần áo phù hợp.
  * **Nhiễm trùng** : Lớp màng ẩm mỏng trên cùng da giúp ngăn chặn hầu hết các chất hoặc sinh vật lạ (như vi khuẩn, vi rút và nấm) xâm nhập vào da. Lớp biểu bì cũng có các tế bào Langerhans, giúp điều chỉnh các phản ứng miễn dịch đối với mầm bệnh tiếp xúc với da.


### **2. Chức năng của da: Điều chỉnh nhiệt**
Chức năng của da là giúp điều chỉnh nhiệt cho cơ thể, tuỳ vào điều kiện thời tiết và nhiệt độ bên ngoài:
  * Da điều chỉnh nhiệt độ thông qua các tuyến mồ hôi và mạch máu ở lớp hạ bì.
  * Việc tiết mồ hôi có thể làm giảm nhiệt độ cơ thể.
  * Giãn mạch (giãn các mạch máu nhỏ) ở lớp hạ bì cũng giúp cơ thể hạ nhiệt độ qua da.
  * Trong quá trình co mạch (co các mạch máu nhỏ), lớp hạ bì giữ lại mức nhiệt độ nhất định bên trong cơ thể.
  * Lớp mỡ dưới da còn đóng vai trò như một hàng rào cách nhiệt, giúp cơ thể không bị mất nhiệt và giảm tác động của nhiệt độ lạnh bên ngoài.


### **3. Cảm giác**
Đây là chức năng của da trên lớp hạ bì. Thông qua các đầu dây thần kinh ở lớp hạ bì, chúng ta cảm nhận được cảm giác nóng, lạnh, áp lực, tiếp xúc và đau khác nhau.
Những cảm giác này trên da đóng vai trò bảo vệ chúng ta khỏi vết thương do bỏng (bỏng độ một và độ hai). Tuy nhiên, trong trường hợp bỏng độ ba, bạn sẽ không cảm thấy đau nữa vì các đầu dây thần kinh trên da đã bị phá hủy.
### **4. Chức năng nội tiết**
Da là một trong những nguồn cung cấp vitamin D chính của cơ thể thông qua việc sản xuất Cholecalciferol (D3) ở hai lớp dưới cùng của biểu bì (lớp đáy và lớp gai).
  * [Chức năng của da](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/cau-tao-va-chuc-nang-cua-da#chc-nng-ca-da)
  * [1. Chức năng của da: Bảo vệ](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/cau-tao-va-chuc-nang-cua-da#1-chc-nng-ca-da-bo-v)
  * [2. Chức năng của da: Điều chỉnh nhiệt](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/cau-tao-va-chuc-nang-cua-da#2-chc-nng-ca-da-iu-chnh-nhit)
  * [4. Chức năng nội tiết](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/cau-tao-va-chuc-nang-cua-da#4-chc-nng-ni-tit)



## UỐNG TRÀ MÃNG CẦU , TRỊ ĐƯỢC UNG THƯ ?

Trong các nghiên cứu gần đây ,chất Annonaceous acetogenins(ACGs) ,từ Annona muricata ( hay còn gọi là mãng cầu xiêm), đã được phát hiện là một tác nhân chống ung thư và ung thư mới đầy hứa hẹn trong nhiều nghiên cứu.
Những acetogenin này đã được chứng minh là có độc tính chọn lọc đối với các loại tế bào ung thư khác nhau mà không gây hại cho các tế bào khỏe mạnh. 
Quả A. muricata dùng trong trị giun, sốt, tăng sữa cho mẹ sau khi sinh con, làm thuốc cầm tiêu chảy và lỵ ; quả chưa chín trộn với dầu ô liu được dùng chữa đau dây thần kinh, thấp khớp và đau khớp. Lá của nó được sử dụng trong y học cổ truyền để điều trị nhức đầu, tăng huyết áp, ho và hen suyễn và được sử dụng làm thuốc chống co thắt, an thần và điều hòa thần kinh cho bệnh tim.
Nhiều loài thực vật khác thuộc họ này cũng đã được báo cáo về khả năng gây độc tế bào của chúng. Mặc dù việc sử dụng quả chưa chín của A. muricata trong việc kiểm soát các tình trạng đau và rối loạn viêm nhiễm, nhưng không có nghiên cứu khoa học nào được thực hiện để xác định việc sử dụng dân gian được tuyên bố trong các tình trạng này. Do đó, nghiên cứu này được thực hiện để điều tra các đặc tính giảm đau và chống viêm của chiết xuất từ ​​quả đông khô của A. muricata ở loài gặm nhấm và cơ chế hoạt động có thể có của nó.
Kết quả từ nghiên cứu này cho thấy chiết xuất từ ​​mãng cầu xiêm ( A. muricata )có tác dụng giảm đau và chống viêm có thể qua trung gian tương tác với con đường opioidergic và ức chế các chất trung gian hóa học gây viêm.
NHƯNG Theo viện Nghiên cứu Ung thư Vương quốc Anh, "không có bằng chứng cho thấy mãng cầu Xiêm có tác dụng chữa bệnh ung thư" và do đó họ không hỗ trợ việc sử dụng nó trong điều trị ung thư. Một vụ kiện liên quan đến việc bán thuốc viên Triamazon tại Vương quốc Anh, một sản phẩm từ mãng cầu Xiêm, dẫn đến sự kết tội vì bốn tội danh liên quan đến việc bán một sản phẩm y tế không có giấy phép. Thẩm phán nói rằng loại thuốc này đã không được thử nghiệm trên con người, đã không được cấp phép để sử dụng trong thị trường Anh và có thể gây ra các triệu chứng tương tự như bệnh Parkinson từ hợp chất annonacin chứa trong hạt của mãng cầu xiêm là một chất độc thần kinh và nó có vẻ là nguyên nhân gây ra một bệnh thoái hóa thần kinh. Nhóm người duy nhất được biết bị ảnh hưởng trực tiếp sống trên đảo Guadeloupe ở biển Caribe và các vấn đề xảy ra có lẽ do việc tiêu thụ quá nhiều loại cây có chứa annonacin. Các rối loạn được gọi là tauopathy có liên hệ đến sự tích lũy bệnh lý của tau protein trong não. Những kết quả thực nghiệm đã xác nhận một cách chắc chắn lần đầu tiên rằng cây có chứa chất độc thần kinh annonacin chịu trách nhiệm về sự tích lũy này.
Ủy ban Thương mại Liên bang Hoa Kỳ xác định rằng "không có bằng chứng khoa học đáng tin cậy" để chắc chắn là chiết xuất của mãng cầu Xiêm được bán bởi Bioque Technologies "có thể ngăn ngừa, chữa lành, hoặc điều trị bất kỳ loại ung thư nào
**Nghiên cứu:**
<https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4259190/>
[https://pubmed.ncbi.nlm.nih.gov/16078200/](https://pubmed.ncbi.nlm.nih.gov/16078200/)

## Những nhóm thuốc thường có tại nhà thuốc

**1. NHÓM KHÁNG SINH** A. BETALACTAM Nhóm Penicilin : Amoxicilin, Ampicilin, Oxacilin. Dạng phối hợp: Amoxicillin + A.Clavulanit, Amoxicilin + Sulbactam, Ampicillin + Sulbactam. Nhóm Cephalosporin : + Thế hệ 1 : Cephalexin, Cephadroxil + Thế hệ 2: Cefaclor , Cefuroxim, Cefprozil + Thế hệ 3: Cefixim, Cefpodoxim, Cefditoren, Cefdinir. B. Nhóm Macrolid Azithromycin Erythromycin Roxythromyxin Clarithromycin Spiramycin Dang phối hợp : Spiramycin + Metronidazol C. Nhóm Quinolon Acid nalidixic Ofloxacin Ciprofloxacin Levofloxacin Moxifloxacin D. Nhóm Lincosamid Lincomycin Clidamycin E. Nhóm Cyclin Tetracyclin Doxycyclin Minocyclin F. Nhóm Aminoglycosid Tobramycin Neomycin Gentamycin G. Nhóm sulfamid Sulfaguanidin Sulfasalazin Sulfamethoxazol + Trimethoprim Sulfadiazin H. Nhóm Phenicol Cloramphenicol I. Nhóm 5 Nitro Imidazol Metronidazol Tinidazol Secnidazol J. Nhóm giun sán Mebedazol Albendazol K. Kháng nấm Nystatin Griseofulvin Ketoconazol Fluconazol Econazol Clotrimazol L. Kháng virus Acyclovir Tenofovir
**2. NHÓM GIẢM ĐAU KHÁNG VIÊM** Giảm đau hạ sốt : Paracetamol A. NSAID Ibuprofen Diclofenac Ketoprofen Piroxicam Meloxicam Celecoxib Etoricoxib Lornoxicam Nimesulide Nabumeton B. Corticoid Hydrocortison Triamcinolon Prednisolon Methylprednisolon Betamethason Dexamethason C. Kháng viêm dạng men Alpha chymotrypsil Seraopeptidase Bromelain
**3. DÃN CƠ VÂN** Mephenesin Tolperison Eperison Thiocolchicosid
**4. NHÓM KHÁNG HISTAMIN H1** Thế hệ 1: Chlorpheniramin Dexchlorpheniramin Diphenhydramin Dimehydrinat Cyproheptadin Alimemazin Cinnarizin Hydroxyzin Thế hệ 2: Cetirizin Levocetirizin Loratadin Desloratadin Fexofenadin
**5. THUỐC HO** A. HO KHAN Dextromethorphan Codein B. HO ĐÀM Thuốc tiêu nhầy: + Acetylcystein + Bromhexin + Ambroxol + Carbocistine Thuốc long đàm: Guaifenesin Terpinhydrat
**6. NHÓM HEN SUYỄN - PHẾ QUẢN** Montelukast Theophylin Salbutamol Terbutalin
**7. NHÓM TIÊU HOÁ** A. PPI Omeprazol Esomeprazol Lansoprazol Rabeprazol Pantoprazol Dexlansoprazol B. Antacid Kremil S Phosphalugel Maalox Trimafort Varogel C. Kháng H2 Cimetidin Famotidin Ranitidin Nizatidin D. Thuốc nhuận tràng Bisacodyl Lactulose Sorbitol Glycerin E. Thuốc trị tiêu chảy Loperamid Smecta Racecadotril F. Men vi sinh Biolac Enterogermina Lactomin
**8. NHÓM HUYẾT ÁP – TIM MẠCH** Nhóm ức chế men chuyển + Captopril + Lisinopril + Elanapril + Peridopril Nhóm ức chế ARB + Losartan + Candesartan + Telmisartan + Irbesartan + Valsartan Nhóm chẹn Beta + Atenolol + Propranolol + Bisoprolol + Metoprolol Thuốc lợi tiểu: + Hydrochlorothiazid + Furosemid + Indapamid + Torsemid + Spironolacton
**9. THUỐC TRỊ ĐÁI THÁO ĐƯỜNG** Metformin Glicazid Glimepiride Sitaglintin Saxagliptin Vildagliptin Acarbose
**10. THUỐC ĐIỀU TRỊ RỐI LOẠN LIPID HUYẾT** Atorvastatin Rosuvastatin Lovastatin Simvastatin Fenofbirat
**11. THUỐC NGỪA THAI** Ngừa thai tháng: Marvelon Mercilon Embevin 28 Ngừa khẩn cấp: Postinor Mifistad 10mg

## Thiết bị theo dõi giấc ngủ đeo tay hoạt động thế nào?

  * [Theo dõi chuyển động của bạn](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/thiet-bi-theo-doi-giac-ngu-deo-tay-hoat-dong-the-nao#theo-di-chuyn-ng-ca-bn)
  * [Theo dõi nhịp tim](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/thiet-bi-theo-doi-giac-ngu-deo-tay-hoat-dong-the-nao#theo-di-nhp-tim)
  * [Sử dụng Photoplethysmography (PPG) trong theo dõi HRV](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/thiet-bi-theo-doi-giac-ngu-deo-tay-hoat-dong-the-nao#s-dng-photoplethysmography-ppg-trong-theo-di-hrv)
  * [Pulse Ox trong thiết bị theo dõi giấc ngủ có thể đeo](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/thiet-bi-theo-doi-giac-ngu-deo-tay-hoat-dong-the-nao#pulse-ox-trong-thit-b-theo-di-gic-ng-c-th-eo)
  * [Thiết bị theo dõi giấc ngủ chính xác đến mức nào?](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/thiet-bi-theo-doi-giac-ngu-deo-tay-hoat-dong-the-nao#thit-b-theo-di-gic-ng-chnh-xc-n-mc-no)


## Theo dõi chuyển động của bạn
Ngủ liên quan đến nhiều thứ hơn là chỉ nhắm mắt lại. Có nhiều giai đoạn khác nhau của giấc ngủ: Giai đoạn một, giai đoạn hai, giai đoạn ba (ngủ sâu) và REM (chuyển động mắt nhanh).
Cơ bắp của bạn trở nên thư giãn hơn khi bạn trải qua các giai đoạn khác nhau, nghĩa là càng ngủ sâu, bạn càng ít di chuyển. Và cả thiết bị theo dõi giấc ngủ không tiếp xúc và có thể đeo được đều có thể suy ra mức độ bạn ngủ sâu dựa trên mức độ bạn di chuyển trong khi ngủ. Một bộ phận trong thiết bị theo dõi giấc ngủ được gọi là gia tốc kế sẽ giám sát chuyển động này.
## Theo dõi nhịp tim
Nhịp tim, thay đổi tùy thuộc vào các giai đoạn của giấc ngủ. Và các thiết bị theo dõi giấc ngủ, đặc biệt là thiết bị đeo, theo dõi mức độ giấc ngủ bằng chỉ số này.
Mặc dù các cơ và tứ chi của bạn không hoạt động trong giấc ngủ REM, nhưng nhiều hoạt động, chẳng hạn như mơ, vẫn diễn ra trong não. Kết quả là, cơ thể phải cân bằng các tác động của hệ thống thần kinh giao cảm và đối giao cảm. Hệ thống thần kinh giao cảm kiểm soát phản ứng của cơ thể để thư giãn, trong khi hệ thống thần kinh đối giao cảm kiểm soát phản ứng của cơ thể trước nguy hiểm (chiến đấu hoặc bỏ chạy).
Sự tồn tại đồng thời của các trạng thái trái ngược nhau này gây ra nhịp tim bất thường trong giấc ngủ REM. Điều này không giống như giấc ngủ sâu, khi nhịp tim đều đặn hơn vì không có nhiều điều xảy ra trong não. Vì vậy, bằng cách theo dõi HRV, thiết bị theo dõi giấc ngủ có thể cho biết bạn đang ở giai đoạn ngủ nào và bạn ngủ ngon ra sao.
### Sử dụng Photoplethysmography (PPG) trong theo dõi HRV
Thiết bị theo dõi giấc ngủ ghi nhận sự thay đổi nhịp tim sử dụng Photoplethysmography (PPG), một phương pháp kiểm tra lượng máu và sự lưu thông thông qua phản xạ ánh sáng. Những thiết bị theo dõi này có cảm biến PPG xác định các thay đổi trong quá trình lưu thông máu và sự thay đổi nhịp tim.
Các cảm biến PPG chiếu ánh sáng hồng ngoại lên da và theo dõi cách máu dưới da phản chiếu ánh sáng. Và thứ kiểm soát sự phản xạ ánh sáng là lượng máu chảy vào mao mạch. Vì vậy, bằng việc xem cách ánh sáng hồng ngoại phản xạ, thiết bị theo dõi giấc ngủ có thể lưu ý thời gian giữa mỗi nhịp tim và tìm ra chất lượng giấc ngủ.
## Pulse Ox trong thiết bị theo dõi giấc ngủ có thể đeo
Pulse Ox là một phương pháp không xâm lấn để xác định mức độ bão hòa oxy của một người. Mức độ bão hòa oxy thấp trong khi ngủ (thiếu oxy máu) có thể chỉ ra các triệu chứng ngưng thở khi ngủ, chẳng hạn như đổ mồ hôi ban đêm, đi tiểu đêm và nghẹt thở. Những điều này làm chất lượng giấc ngủ thấp hơn và ảnh hưởng đến sức khỏe.
Thiết bị theo dõi giấc ngủ sử dụng Pulse Ox để xác định mức độ bão hòa oxy sử dụng cảm biến để chiếu ánh sáng lên da. Sau đó, chúng đo lượng ánh sáng mà máu bên dưới da hấp thụ. Máy đo Pulse Ox Bluetooth sử dụng một cơ chế tương tự.
Cảm biến phóng ra hai bước sóng ánh sáng. Máu được oxy hóa hấp thụ một bước sóng, trong khi máu khử oxy hấp thụ bước sóng kia. Vì vậy, thiết bị theo dõi giấc ngủ có thể đeo của bạn sẽ đo độ bão hòa oxy trong máu bằng cách tính toán sự khác biệt về mức độ hấp thụ của cả hai bước sóng. Nếu mức độ bão hòa oxy thấp, chất lượng giấc ngủ của bạn có thể cũng sẽ như vậy.
**Yếu tố tiếng ồn và nhiệt độ**
Các ứng dụng theo dõi giấc ngủ có micro và nhiệt kế để thu thập mức độ tiếng ồn và nhiệt độ tương ứng. Thiết bị đeo cũng sử dụng cơ chế này để phân tích âm thanh mọi người tạo ra trong khi ngủ, chẳng hạn như tiếng ngáy và tiếng thở to. Những âm thanh này có thể khác nhau tùy thuộc vào giai đoạn giấc ngủ của một người.
Trong giấc ngủ REM, nhịp thở hơi thất thường do tất cả hoạt động của não bộ. Ngoài ra, hơi thở đều đặn hơn một chút trong giấc ngủ sâu. Trình theo dõi giấc ngủ có thể phát hiện chất lượng giấc ngủ bằng những âm thanh này.
## Thiết bị theo dõi giấc ngủ chính xác đến mức nào?
Thiết bị theo dõi giấc ngủ không hoàn toàn đáng tin cậy vì công nghệ của chúng có nhiều hạn chế. Ví dụ, thiết bị sử dụng chuyển động để theo dõi giấc ngủ có thể nhầm lẫn việc nằm yên hoàn toàn với việc ngủ. Ngoài ra, các yếu tố khác có thể ảnh hưởng đến sự thay đổi nhịp tim, tiếng ồn và nhiệt độ.
Vì vậy, trong khi bạn nên có một thiết bị theo dõi giấc ngủ hoặc tiếp tục sử dụng nếu bạn thấy nó hữu ích, thì đa ký giấc ngủ (polysomnography) là một phương tiện chính xác hơn để theo dõi chất lượng giấc ngủ. Đó là những gì các chuyên gia y tế sử dụng để chẩn đoán rối loạn giấc ngủ và kê đơn điều trị. Tuy nhiên, thiết bị theo dõi giấc ngủ vẫn là một cách tốt để ước tính bạn ngủ ngon như thế nào từ ngày này sang ngày khác.
  * [Theo dõi chuyển động của bạn](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/thiet-bi-theo-doi-giac-ngu-deo-tay-hoat-dong-the-nao#theo-di-chuyn-ng-ca-bn)
  * [Theo dõi nhịp tim](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/thiet-bi-theo-doi-giac-ngu-deo-tay-hoat-dong-the-nao#theo-di-nhp-tim)
  * [Sử dụng Photoplethysmography (PPG) trong theo dõi HRV](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/thiet-bi-theo-doi-giac-ngu-deo-tay-hoat-dong-the-nao#s-dng-photoplethysmography-ppg-trong-theo-di-hrv)
  * [Pulse Ox trong thiết bị theo dõi giấc ngủ có thể đeo](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/thiet-bi-theo-doi-giac-ngu-deo-tay-hoat-dong-the-nao#pulse-ox-trong-thit-b-theo-di-gic-ng-c-th-eo)
  * [Thiết bị theo dõi giấc ngủ chính xác đến mức nào?](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/thiet-bi-theo-doi-giac-ngu-deo-tay-hoat-dong-the-nao#thit-b-theo-di-gic-ng-chnh-xc-n-mc-no)



## Hóa học và vị giác

  * [ * Trong học thuyết Ngũ hành của phương Đông, Ngũ hành tương ứng với Ngũ vị, cụ thể là:](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/hoa-hoc-va-vi-giac#-trong-hc-thuyt-ng-hnh-ca-phng-ng-ng-hnh-tng-ng-vi-ng-v-c-th-l)
  * [ * Với các mùi vị cơ bản:](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/hoa-hoc-va-vi-giac#-vi-cc-mi-v-c-bn)


##  * Trong học thuyết Ngũ hành của phương Đông, Ngũ hành tương ứng với Ngũ vị, cụ thể là:
- Hành Kim - Màu trắng - Vị cay quy kinh Phế (Phổi) - các dược liệu có vị cay nồng chữa các bệnh về phổi. Ví dụ: Kinh giới có vị cay chữa các bệnh cảm mạo do lạnh. - Hành Mộc - Màu xanh - Vị chua quy kinh Can (Gan) - các dược liệu có vị chua chữa các bệnh liên quan tới gan. Ví dụ: Ngũ bội tử có vị chua giúp ra mồ hôi, giải độc gan. - Hành Thủy - Màu đen - Vị mặn quy kinh Thận - các dược liệu muốn bổ thận thường được trích (tẩm muối). Ví dụ: Đỗ trọng chế muối giúp ôn thận, tráng dương. - Hành Hỏa - Màu đỏ - Vị đắng quy kinh Tâm (Tim). Ví dụ: Khổ sâm có vị đắng (khổ = đắng), chống rối loạn nhịp tim. - Hành Thổ - Màu vàng - Vị ngọt quy kinh Tỳ (Dạ dày). Ví dụ: Hoàng kì sao vàng, hạ thổ để tăng vị ngọt, tăng tác dụng trên các bệnh tiêu hóa.
##  * Với các mùi vị cơ bản:
- Vị chua: vị chua (toan) là thuộc tính của các acid , cả vô cơ và hữu cơ. Thang đo pH, hằng số phân li acid, tính acid hay đệm năng của dung dịch acid đều không có mối quan hệ tuyến tính với vị chua. Vị chua được cho là phụ thuộc vào cả ion H⁺ phân li, H trong acid chưa phân li và cả anion tương ứng tác động vào. - Vị ngọt: là mùi vị được ưa thích nhất với con người, ngay từ trong bào thai thai nhi đã thích vị ngọt. Thang đo vị ngọt tiêu chuẩn sử dụng sucrose - saccharose hay đường kính làm chuẩn là 1. Các hợp chất ngọt nhất hiện nay đều thuộc về dẫn chất guanidine - với lugdoname là chất ngọt nhất - gấp 230.000 lần so với saccharose. - Vị mặn: NaCl là tiêu chuẩn của vị mặn. Vị mặn là mùi vị cuối cùng mà đứa trẻ cảm nhận được, 4 tháng sau khi sinh. Vị mặn phụ thuộc vào cả cation và anion trong các muối, trong đó anion càng lớn, vị mặn càng giảm đi. Khối lượng cation không ảnh hưởng tới mức độ mặn, tuy nhiên các cation nhỏ hơn có vị mặn trong khi cation lớn hơn thường có vị đắng. Độ mặn của các muối nhìn chung giảm theo thứ tự: NH₄⁺ > K⁺ > Ca⁺⁺ > Na⁺ > Li⁺ > Mg⁺⁺ (Mg⁺⁺ thường có vị đắng) - Vị đắng: Vị đắng thường gắn liền mật thiết với vị ngọt, một số chất vừa có vị đắng cũng lại có vị ngọt. Các alkaloid trong tự nhiên thường có vị đắng, và vị đắng cũng là thuộc tính của các chất có tính kiềm. Tiêu chuẩn của vị đắng được gắn liền với quinine với chỉ số là 1 - denatonium benzoate với chỉ số 1000 được coi là chất có vị đắng lớn nhất hiện nay, được thêm vào các chất độc để tránh hiện tượng nếm phải lượng lớn các độc chất này.
  * [ * Trong học thuyết Ngũ hành của phương Đông, Ngũ hành tương ứng với Ngũ vị, cụ thể là:](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/hoa-hoc-va-vi-giac#-trong-hc-thuyt-ng-hnh-ca-phng-ng-ng-hnh-tng-ng-vi-ng-v-c-th-l)
  * [ * Với các mùi vị cơ bản:](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/hoa-hoc-va-vi-giac#-vi-cc-mi-v-c-bn)



## Hội thảo: Giải pháp mới trong chẩn đoán và điều trị béo phì


## 4 kiểu phản ứng thường gặp với stress

  * [Cơ chế hoạt động của phản ứng căng thẳng](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/4-kieu-phan-ung-thuong-gap-voi-stress#c-ch-hot-ng-ca-phn-ng-cng-thng)
  * [Fight (Chống trả)](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/4-kieu-phan-ung-thuong-gap-voi-stress#fight-chng-tr)
  * [Flight (Bỏ chạy)](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/4-kieu-phan-ung-thuong-gap-voi-stress#flight-b-chy)
  * [Freeze (Đóng băng)](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/4-kieu-phan-ung-thuong-gap-voi-stress#freeze-ng-bng)
  * [Làm thế nào để điều hòa các phản ứng căng thẳng?](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/4-kieu-phan-ung-thuong-gap-voi-stress#lm-th-no-iu-ha-cc-phn-ng-cng-thng)


## Cơ chế hoạt động của phản ứng căng thẳng
Khi “đụng độ” mối nguy, não bộ sẽ tự động gửi tín hiệu đi khắp cơ thể để nhanh chóng vào tư thế ứng phó. Nơi tiếp nhận xử lý đầu tiên là hạch hạnh nhân (amygdala), bộ phận chuyên điều khiển những phản ứng cảm xúc và nỗi sợ. Sau đó, tín hiệu được đưa đến vùng dưới đồi (hypothalamus) và kích hoạt hệ thần kinh giao cảm (sympathetic system).
Quá trình này khiến tuyến thượng thận tăng cường giải phóng hormone adrenaline, noradrenaline và cortisol để duy trì mức cân bằng nội sinh. Kết quả nhịp tim và nhịp thở tăng nhanh, quá trình lưu thông máu chuyển từ hệ tiêu hóa sang các cơ xương.
Ngoài ra, khi não bộ tập trung năng lượng vào bộ phận xử lý cảm xúc, những vùng não phụ trách về ngôn ngữ và kiểm soát xung lực sẽ giảm hoạt động. Đây lý do bạn thường không thốt nên lời hay suy nghĩ lý trí khi cảm thấy bị đe dọa. Sự chú ý cao độ vào mối nguy trước mắt cũng khiến tầm nhìn của bạn bị thu hẹp, bỏ qua những yếu tố ngoại vi khi đánh giá sự việc.
Não bộ phản ứng “nóng vội” thực chất là để bảo vệ ta và giảm thiểu tổn hại. Với những người có tiền sử chấn thương tâm lý, khả năng dự đoán mối nguy của họ sẽ càng nhạy hơn vì luôn bị “giật dây” bởi những ký ức đau thương.
## Fight (Chống trả)
Đây là phản ứng khi một người đối mặt và chiến đấu trực tiếp với mối nguy. Theo nhà trị liệu Pete Walker, cơ chế này xuất phát từ niềm tin vô thức rằng quyền lực và quyền kiểm soát gắn liền với sự công nhận, tình yêu và mức độ an toàn. Đôi khi, phản ứng có thể chuyển hướng sang tấn công một cách hung hăng, bạo lực và độc tôn.
Ví dụ bạn vốn đã rất thất vọng vì bị điểm kém trong bài thi, nhưng về nhà lại bị mẹ mắng mỏ một tràng. Bạn cảm thấy giận dữ và đáp trả bằng cách cãi lớn với mẹ, quăng hết sách vở đi. Một số biểu hiện chống trả phổ biến bao gồm:
  * Nghiến răng, nắm chặt tay, đau bụng, người nóng ran.
  * Cảm giác muốn làm hại ai đó, thậm chí chính mình.
  * La hét, mắng mỏ hoặc chế giễu người khác.
  * Mong muốn tác động vật lý: đấm đá, tát hoặc đập vỡ đồ đạc.
  * Không lắng nghe người khác và chèo lái theo ý mình.
  * Cảm thấy hối hận hoặc xấu hổ sau khi bộc phát.


## Flight (Bỏ chạy)
“Ba mươi sáu kế, chạy là thượng sách” là câu nói tóm gọn cơ chế này. Khi não bộ xác định bạn không thể vượt qua tình thế căng thẳng, nó sẽ tìm cách tách bạn khỏi đó, khiến bạn tạm quên cảm giác khó chịu đang phải đương đầu.
Và “chạy trốn” không có nghĩa bạn phải thực sự vắt giò lên cổ mà chạy. Theo cơ chế thoát ly thực tại (escapism), bạn có thể “chạy” bằng vô số cách khác:
  * Làm việc vội vã, dở dang, trì hoãn dù bị deadline dí.
  * Bỏ nhà ra đi khi có bất đồng, đi du lịch khi căng thẳng.
  * Sợ cam kết trong các mối quan hệ, “ghost” người khác.
  * Dễ bị phân tâm, có nhiều thời gian “chết".
  * Làm việc hoặc tập thể dục quá độ để quên đi nỗi đau.
  * Cơ thể bồn chồn, không ngừng di chuyển.


## Freeze (Đóng băng)
Chế độ này được kích hoạt khi bạn chủ ý hoặc vô thức kìm nén những hoảng loạn bên trong, đồng thời tạm ngưng khả năng phản hồi và tương tác. Tê liệt cảm xúc là ví dụ “đóng băng” phổ biến, khi người ta trải qua biến cố quá lớn (như mất người thân hoặc thoát chết trong gang tấc). Những cú sốc này khiến hạch hạnh nhân bị quá tải, không xử lý cảm xúc kịp thời.
Một số nghiên cứu cho rằng, phản ứng này có thể là giai đoạn chuẩn bị cho những phản ứng tiếp theo. Nó cho bạn thêm thời gian để suy nghĩ, nhìn vấn đề toàn diện hơn và tránh những quyết định nóng vội.
Người mắc chứng lo âu xã hội (social anxiety disorder) và chứng câm chọn lọc (selective mutism) cũng thường có phản ứng này trong những tình huống bất lợi. Chẳng hạn ở nơi đông người, dây thanh quản của họ có thể bị tê liệt do sợ hãi cực độ và chỉ nói trở lại khi nỗi lo qua đi. Một số biểu hiện vật lý khác bao gồm:
  * Da nhợt nhạt, trắng bệch, nhịp tim giảm.
  * Cơ thể căng cứng, nặng nề, tê liệt, thậm chí ngất xỉu.
  * Đầu ốc trôi dạt, trống rỗng, lờ đờ.
  * Không có cảm nhận gì khi bị người khác xúc phạm, la mắng.


## Fawn (Xu nịnh)
Theo nhà trị liệu Pete Walker, phản ứng này thể hiện ở hành vi chiều lòng, cố gắng làm vừa ý người gây hại để bảo vệ bản thân. Về bản chất nó là một cơ chế tự vệ có thể học được, thường xảy ra ở người bị ngược đãi, hoặc có cha mẹ ái kỷ, không ghi nhận cảm xúc của con cái.
Ở trong những môi trường này, họ nhận thấy việc nghe lời và tuân lệnh người lớn là lá chắn duy nhất. Khi trưởng thành, họ dễ duy trì thói quen people-pleasing và mắc kẹt trong mối quan hệ đồng phụ thuộc. Nếu bị bạo hành, họ có thể tiếp tục fawn dù có người ngăn cản, do não họ mặc định đó là cách tốt nhất để giữ bản thân an toàn. Họ cũng thường có các biểu hiện như:
  * Không thể từ chối người khác.
  * Không có chính kiến, lệ thuộc vào người khác.
  * Xin lỗi quá thường xuyên.
  * Không có thời gian cho bản thân.
  * Không cam kết với những ranh giới cá nhân.
  * Cố tỏ ra tích cực, vui vẻ.


## Làm thế nào để điều hòa các phản ứng căng thẳng?
Về bản chất, các phản ứng căng thẳng là cơ chế giúp bạn tự vệ. Nhưng do diễn ra nhanh chóng & nằm ngoài khả năng kiểm soát của bạn, chúng có thể dẫn đến hệ quả ngoài ý muốn. Để điều hòa phản ứng căng thẳng & hạn chế các “tác dụng phụ”, bạn có thể áp dụng các mẹo sau:
**Kỹ năng quản lý công việc, thời gian:** Các kỹ thuật như ma trận Eisenhower, quy tắc 2 phút, thuyết 4 lò lửa, batching & blocking sẽ giúp bạn bổ nhỏ và kiểm soát những tác nhân gây áp lực.
**Kỹ thuật thư giãn:** Các bài tập nhẹ nhàng như yoga hay đi bộ có tác dụng điều hòa hơi thở, giãn cơ và thả lỏng tâm trí. Ngoài ra, việc thực hành chánh niệm cũng giúp kích hoạt lại các phản ứng logic của não bộ, nhìn nhận vấn đề và thay đổi suy nghĩ về stress.
**Đặt giới hạn cá nhân:** Bắt đầu từ việc xác định điều gì làm bạn thấy thoải mái và điều gì không. Sau đó, hãy sắp xếp mức độ được xâm phạm của các giới hạn đó từ thoải mái đến không thể chấp nhận được. Điều quan trọng là bạn cố gắng duy trì sự cam kết dài hạn với những ranh giới đã đặt.
  * [Cơ chế hoạt động của phản ứng căng thẳng](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/4-kieu-phan-ung-thuong-gap-voi-stress#c-ch-hot-ng-ca-phn-ng-cng-thng)
  * [Fight (Chống trả)](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/4-kieu-phan-ung-thuong-gap-voi-stress#fight-chng-tr)
  * [Flight (Bỏ chạy)](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/4-kieu-phan-ung-thuong-gap-voi-stress#flight-b-chy)
  * [Freeze (Đóng băng)](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/4-kieu-phan-ung-thuong-gap-voi-stress#freeze-ng-bng)
  * [Làm thế nào để điều hòa các phản ứng căng thẳng?](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/4-kieu-phan-ung-thuong-gap-voi-stress#lm-th-no-iu-ha-cc-phn-ng-cng-thng)



## Tràn dịch màng phổi do tim là gì?

**1. Tổng quan :**
Trong bệnh cảnh suy tim, tràn dịch màng phổi thường thường có nguyên nhân là do tăng áp suất mao mạch phổi. Trong một số trường hợp hiếm gặp hơn thì tràn dịch màng phổi còn liên quan đến suy tim phải đơn độc. Tràn dịch màng phổi trong suy tim thường là tràn dịch 2 bên, trong các trường hợp tràn dịch màng phổi 1 bên thì tràn dịch màng phổi phải thường gặp hơn.
Dịch màng phổi thường là dịch thấm (75%) và chỉ có khoảng 25% các trường hợp là dịch tiết. Các xét nghiệm liên quan đến natriuretic peptide như là NT-proBNP giúp chẩn đoán hoặc loại trừ nguyên nhân suy tim ở những bệnh nhân tràn dịch màng phổi chưa rõ nguyên nhân. Tiêu chuẩn Light giúp phân biệt dịch màng phổi là dịch thấm hay dịch tiết.
Suy tim nên luôn được nghĩ tới trong bất kỳ chẩn đoán phân biệt tràn dịch màng phổi nào. Trong một nghiên cứu trên 2388 bệnh nhân được chẩn đoán nguyên nhân thông qua chọc dịch màng phổi trong vòng 15 năm qua, thì các nguyên nhân chiếm tỉ lệ như sau: ung thư (28.5%), viêm phổi (19.5%), suy tim (18%) và lao phổi (9%). Độ tuổi trung bình của bệnh nhân mắc tràn dịch màng phổi do suy tim cao hơn nhiều so với các bệnh nhân mắc tràn dịch màng phổi do các nguyên nhân khác (79 tuổi so với 64 tuổi). Thật vậy, nguyên nhân suy tim chiếm hơn 1 nửa số bệnh nhân trên 80 tuổi mắc tràn dịch màng phổi (Theo một khảo sát của một tác giả tên Forcel và các cộng sự).
**2. Cơ chế gây ra tràn dịch màng phổi trong suy tim :**
a. Suy tim trái :
Trong suy tim trái, việc tăng áp lực nhĩ trái và thất trái khiến máu ứ đọng và đi ngược lại các mao mạch phổi, gây tăng áp lực thủy tĩnh ở các mao mạch này àdịch đi vào mô kẽ của phổi à dịch sau đó đi từ mô kẽ và thấm qua lá thành của màng phổi theo gradient áp lực à dịch ứ đọng lại trong khoang màng phổi vượt quá khả năng hấp thu của hệ thống bạch huyết àtràn dịch màng phổi.
Quá trình hình thành dịch màng phổi này diễn tiến khá chậm, cần khoảng 1 tháng để có thể ứ đọng được khoảng 1 lít dịch màng phổi. Phần đông các chuyên gia cho rằng tràn dịch màng phổi liên quan đến suy tim trái thường gặp hơn là suy tim phải.
b. Suy tim phải :
Trong một nghiên cứu gần đây cho thấy, suy tim phải đơn độc là nguyên nhân của 19 trên tổng số 147 bệnh nhân (13%) mắc tràn dịch màng phổi do suy tim có kèm theo tăng áp phổi (vô căn hoặc gia đình). Gần 2/3 số bệnh nhân này là tràn dịch màng phổi lượng ít, trong đó tràn dịch màng phổi 2 bên là 11 bệnh nhân (58%), tràn dịch màng phổi trái là 3 bệnh nhân (16%) và tràn dịch màng phổi trái là 5 bệnh nhân (26%).
Nguyên nhân hình thành dịch màng phổi được cho là do dịch cổ trướng ở những bệnh nhân có xơ gan do suy tỉm phải, dịch cổ trướng thoát ra khỏi ổ bụng qua cơ hoành và đi vào khoang màng phổi à tràn dịch màng phổi.
**Tài liệu tham khảo:**
Pleural Effusions from Congestive Heart Failure - José M. Porcel, MD

## Phòng khám tư vấn và điều trị giảm cân tại bệnh viện Nguyễn Tri Phương

  * [Bệnh béo phì được định nghĩa như thế nào?](https://bvnguyentriphuong.com.vn/kien-thuc-cho-nguoi-benh/phong-kham-tu-van-va-dieu-tri-giam-can-tai-benh-vien-nguyen-tri-phuong#bnh-bo-ph-c-nh-ngha-nh-th-no)
  * [1 Đối với người lớn](https://bvnguyentriphuong.com.vn/kien-thuc-cho-nguoi-benh/phong-kham-tu-van-va-dieu-tri-giam-can-tai-benh-vien-nguyen-tri-phuong#1-i-vi-ngi-ln)
  * [2 Đối với trẻ em](https://bvnguyentriphuong.com.vn/kien-thuc-cho-nguoi-benh/phong-kham-tu-van-va-dieu-tri-giam-can-tai-benh-vien-nguyen-tri-phuong#2-i-vi-tr-em)
  * [Thừa cân và bệnh béo phì gây ra những hậu quả gì?](https://bvnguyentriphuong.com.vn/kien-thuc-cho-nguoi-benh/phong-kham-tu-van-va-dieu-tri-giam-can-tai-benh-vien-nguyen-tri-phuong#tha-cn-v-bnh-bo-ph-gy-ra-nhng-hu-qu-g)


## Bệnh béo phì được định nghĩa như thế nào?
**Thừa cân và béo phì** được WHO - tổ chức y tế thế giới định nghĩa là sự tích tụ chất béo bất thường hoặc quá mức có thể làm giảm sức khỏe.
Chỉ số khối cơ thể (**BMI**) là một chỉ số đơn giản về cân nặng theo chiều cao thường được sử dụng để phân loại thừa cân và béo phì ở người trưởng thành.
### **1 Đối với người lớn**
Thừa cân là chỉ số BMI lớn hơn hoặc bằng 25 và béo phì là chỉ số BMI lớn hơn hoặc bằng 30.
### **2 Đối với trẻ em**
Đối với trẻ em dưới 5 tuổi: Thừa cân là cân nặng theo chiều cao lớn hơn 2 độ lệch chuẩn trên trung bình. Tiêu chuẩn tăng trưởng trẻ em của WHO; và béo phì là cân nặng theo chiều cao lớn hơn 3 độ lệch chuẩn trên trung bình Tiêu chuẩn tăng trưởng trẻ em của WHO.
Trẻ em từ 5 - 18 tuổi: Thừa cân là BMI theo tuổi lớn hơn 1 độ lệch chuẩn trên trung bình tham chiếu tăng trưởng của WHO; và béo phì lớn hơn 2 độ lệch chuẩn trên trung bình trên tham chiếu tăng trưởng của WHO.
## Thừa cân và bệnh béo phì gây ra những hậu quả gì?
BMI tăng là một yếu tố nguy cơ chính đối với các bệnh không truyền nhiễm như:
  * **Bệnh tim mạch** (chủ yếu là bệnh tim và đột quỵ), là nguyên nhân hàng đầu gây tử vong trong năm 2012;
  * Bệnh tiểu đường;
  * **Rối loạn cơ xương khớp** (đặc biệt là viêm xương khớp - một bệnh thoái hóa khớp rất cao);
  * Một số bệnh ung thư (bao gồm nội mạc tử cung, vú, buồng trứng, tuyến tiền liệt, gan, sỏi mật, thận và đại tràng).


Thừa cân ở trẻ em có liên quan đến nguy cơ mắc bệnh béo phì, tử vong sớm và tàn tật ở tuổi trưởng thành cao hơn. Nhưng ngoài việc tăng nguy cơ trong tương lai, trẻ béo phì còn gặp khó khăn về hô hấp, tăng nguy cơ gãy xương, tăng huyết áp, các dấu hiệu sớm của bệnh tim mạch, kháng insulin và ảnh hưởng tâm lý.
**[Phác đồ chẩn đoán và điều trị béo phì (Bộ Y Tế)](https://bvnguyentriphuong.com.vn/uploads/072022/files/Beophi-Q%C4%902892BYT.pdf)
#### Nội dung trong file:

0 
BỘ Y TẾ  
___________  
 
Số:         /QĐ-BYT CỘNG HOÀ XÃ HỘI CHỦ NGHĨA VIỆT NAM  
Độc lập - Tự do - Hạnh phúc  
________________________________  
Hà Nội, ngày     tháng    năm 202 2 
 
QUYẾT ĐỊNH  
Về việc ban hành tài liệu chuyên môn  
“Hướng dẫn chẩn đoán và điều trị bệnh béo phì ” 
 
BỘ TRƯỞNG BỘ Y TẾ  
Căn cứ Luật Khám bệnh, chữa bệnh năm 2009;  
Căn cứ Nghị định số 75/2017/NĐ -CP ngày 20 tháng 6 năm 2017 của Chính 
phủ quy định chức năng, nhiệm vụ, quyền hạn và cơ cấu tổ chức của Bộ Y tế;  
Theo đề nghị của Cục trưởng Cục Quản lý khám, chữa bệnh.  
QUYẾT ĐỊNH:  
Điều 1. Ban hành kèm theo Quyết định này tài liệu chuyên môn “ Hướng dẫn 
chẩn đoán và điều trị bệnh béo phì ”. 
Điều 2. Tài liệu chuyên môn “ Hướng dẫn chẩn đoán và điều trị bệnh béo 
phì” được áp dụng tại các cơ sở khám bệnh, chữa bệnh trong cả nước.  
Điều 3. Quyết định này có hiệu lực kể từ ngày ký, ban hành. Bãi bỏ bài 
“Bệnh béo phì” trong “Hướng dẫn chẩn đoán và điều trị bện h nội tiết – chuyển 
hóa” được ban hành tại Quyết định số 3879/QĐ -BYT ngày 30 tháng 09 năm 2014 
của Bộ trưởng Bộ Y tế.  
Điều 4. Các ông, bà: Chánh Văn phòng Bộ, Chánh thanh tra Bộ, Tổng Cục 
trưởng, Cục trưởng và Vụ trưởng các Tổng cục, Cục, Vụ thuộc Bộ Y tế,  Giám 
đốc Sở Y tế các tỉnh, thành phố trực thuộc trung ương, Giám đốc các Bệnh viện 
trực thuộc Bộ Y tế, Thủ trưởng Y tế các ngành chịu trách nhiệm thi hành Quyết 
định này./.  
 
Nơi nhận : 
- Như Điều 4;  
- Q. Bộ trưởng (để b/c);  
- Các Thứ trưởng;  
- Cổng thông tin điện tử Bộ Y tế; Website Cục KCB;  
- Lưu: VT, KCB.  KT. BỘ TRƯỞNG  
THỨ TRƯỞNG  
 
 
[d 
aky]  
 
 
Nguyễn Trường Sơn  
 
  
  
syt_sonla_vt_So Y te Son La_22/10/2022 22:04:031 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
   
 
 
 
 
 
 
 
HƯỚNG D ẪN CH ẨN ĐOÁN VÀ  
ĐIỀU TR Ị BỆNH BÉO PHÌ  
 
 
(Ban hành kèm theo Quy ết định số          /QĐ-BYT  
ngày      tháng     năm 202 2 của Bộ trưởng Bộ Y tế) 
 
 
 
 
 
 
 
 
Hà N ội, 2022  
 
 
 
 
syt_sonla_vt_So Y te Son La_22/10/2022 22:04:032 
 
CHỈ ĐẠO BIÊN SOẠN  
PGS.TS. Nguyễn Trường Sơn  
CHỦ BIÊN  
PGS.TS. Lương Ngọc Khuê  
GS.TS. Tr ần Hữu Dàng  
THAM GIA BIÊN SO ẠN VÀ TH ẨM Đ ỊNH 
TS. Nguy ễn Quang B ảy 
TS. Lê Văn Chi  
TS. Phan Hư ớng Dương  
PGS.TS. Nguy ễn Thị Bích Đào  
TS. Lâm Văn Hoàng  
TS. Nguy ễn Trọng Khoa  
TS. Nguy ễn Công Long  
TS. Tr ần Thừa Nguyên  
TS. Bùi Thanh Phúc  
PGS.TS. Đ ỗ Trung Quân  
GS.TS. Thái H ồng Quang  
PGS.TS. H ồ Thị Kim Thanh  
TS. Nghiêm Nguy ệt Thu  
GS.TS. Nguy ễn Hải Thủy 
PGS.TS. Nguy ễn Khoa Di ệu Vân  
Thư ký  
TS. Tr ần Thừa Nguyên  
ThS. Trương Lê Vân Ng ọc 
CN. Đ ỗ Thị Thư 
  syt_sonla_vt_So Y te Son La_22/10/2022 22:04:033 
MỤC LỤC 
 
 
1. ĐẠI CƯƠNG  ................................ ................................ ................................ ............  4 
2. NGUYÊN NHÂN SINH B ỆNH BÉO PHÌ  ................................ ..............................  4 
2.1. Nguyên nhân v ề dinh dư ỡng ................................ ................................ ...............  4 
2.2. Nguyên nhân di truy ền ................................ ................................ ........................  5 
2.3. Nguyên nhân n ội tiết ................................ ................................ ...........................  5 
2.4. Nguyên nhân mô b ệnh học ................................ ................................ .................  5 
2.5. Nguyên nhân do sử dụng thuốc ................................ ................................ ..........  5 
2.6. Nguyên nhân khác  ................................ ................................ ..............................  5 
3. SINH LÝ B ỆNH BÉO PHÌ ................................ ................................ .......................  5 
4. CHẨN ĐOÁN  ................................ ................................ ................................ ...........  6 
4.1. Chỉ số khối cơ th ể (BMI - Body mass index)  ................................ ......................  6 
4.2. Vòng b ụng................................ ................................ ................................ ...........  7 
4.3. Phương pháp DEXA h ấp thụ năng lư ợng kép  ................................ ....................  7 
5. CÁC D ẠNG BÉO PHÌ  ................................ ................................ .............................  8 
5.1. Béo phì d ạng nam (béo phì ph ần trên cơ th ể, béo phì ki ểu bụng, béo phì hình 
quả táo, béo phì trung tâm)  ................................ ................................ ...........................  8 
5.2. Béo phì d ạng nữ (béo phì ph ần dưới cơ th ể, béo phì hình qu ả lê) .....................  8 
5.3. Béo phì h ỗn hợp ................................ ................................ ................................ .. 8 
6. ĐIỀU TR Ị BÉO PHÌ  ................................ ................................ ................................ . 8 
6.1. Mục tiêu và nguyên t ắc chung  ................................ ................................ ............  8 
6.1.1.  Mục tiêu  ................................ ................................ ................................ .................  8 
6.1.2. Nguyên t ắc chung  ................................ ................................ ................................ .... 9 
6.2. Điều trị cụ thể ................................ ................................ ................................ ... 10 
6.2.1.  Tiết thực ................................ ................................ ................................ ..... 10 
6.2.2.  Chế độ vận động trong đi ều trị béo phì ................................ ......................  12 
6.2.3.  Tâm lý li ệu pháp trong đi ều trị béo phì................................ ......................  14 
6.2.4.  Thuốc ................................ ................................ ................................ .........  15 
6.2.5.  Điều trị phẫu thu ật trong béo phì  ................................ ...............................  17 
7. BÉO PHÌ Ở TRẺ EM VÀ THANH THI ẾU NIÊN  ................................ ................  23 
8. KẾT LU ẬN ................................ ................................ ................................ .............  23 
Phụ lục: Thuốc điều trị béo phì  ................................ ................................ ......................  24 
TÀI LI ỆU THAM KH ẢO ................................ ................................ ..............................  26 
 
 
 
 
 
 
 syt_sonla_vt_So Y te Son La_22/10/2022 22:04:034 
HƯỚNG D ẪN CH ẨN ĐOÁN VÀ ĐI ỀU TR Ị BỆNH BÉO PHÌ  
 
1. ĐẠI CƯƠNG  
Béo phì là tình tr ạng tích t ụ mỡ thừa hoặc bất thư ờng, có th ể ảnh hư ởng xấu đến sức 
khỏe. Ở nhiều nước trên th ế giới, tình tr ạng béo phì ngày  càng  gia tăng , đặc biệt trong 10 
năm tr ở lại đây. B ệnh béo phì có s ự thay đ ổi theo gi ới, tuổi, tình tr ạng kinh t ế, xã h ội, 
yếu tố chủng tộc. Tỷ lệ béo phì đang gia tăng nhanh t ại Việt Nam kho ảng 2,6% năm 2010 
lên đ ến 3,6% năm 2014 tương đương v ới tốc độ tăng trư ởng 38% .  
Nghiên c ứu đư ợc công b ố vào năm 2018 v ề bệnh không lây nhi ễm, ăn u ống và dinh 
dưỡng ở Việt Nam trong th ời gian t ừ 1975 – 2015 cho th ấy tần suất thừa cân, béo phì 
trên ngư ời lớn ở Việt Nam là 2 ,3% vào năm 1993 và tăng lên đáng k ể 15% vào năm 
2015, t ỷ lệ ở thành th ị gấp gần 2 lần so v ới nông thôn (22 ,1% so v ới 11,2%). Ngoài ra, 
nghiên c ứu cũng ghi nh ận lối sống của ngư ời Việt Nam thay đ ổi rất nhiều trong nh ững 
năm g ần đây như ít v ận động hơn, trong ch ế độ ăn có nhi ều mu ối, ăn nhi ều mì ăn li ền, 
uống nhi ều nước ngọt, ăn ít rau và h ải sản. M ột thống kê t ại Việt Nam 2021 cho k ết quả 
tương t ự với tỷ lệ thừa cân, béo phì ở Hà N ội và H ồ Chí Minh chi ếm 18% t ổng số lượng 
người thừa cân, béo phì trên toàn qu ốc. 
Rất đáng lưu ý là t ỷ lệ thừa cân, béo phì ở trẻ em tu ổi học đường 5-19 tu ổi tăng t ừ 8,5% 
năm 2010 lên thành 19,0% năm 2020, trong đó  tỷ lệ thừa cân béo phì khu v ực thành th ị 
là 26,8%, nông thôn là 18,3% và mi ền núi là 6,9%.  
Béo phì đư ợc các t ổ chức y tế bao g ồm Tổ chức Y t ế Thế giới (WHO) và Hi ệp hội Y 
khoa Hoa K ỳ (American Medical Association) công nh ận là m ột bệnh m ạn tính đòi h ỏi 
phải quản lý và đi ều trị lâu dài.  
Béo phì có tác đ ộng bất lợi lên t ất cả các v ấn đề sức khỏe, làm gi ảm thời gian s ống, gây 
ra nhi ều bệnh lý m ạn tính không lây như : đái tháo đư ờng, b ệnh lý tim m ạch, tăng lipid 
máu, h ội chứng ngưng th ở lúc ng ủ, làm gi ảm ch ất lượng sống,... Những bi ện pháp ngăn 
ngừa, điều trị thừa cân, béo phì và duy trì th ực hiện việc kiểm soát cân n ặng lâu dài có 
thể cải thiện tình tr ạng sức khỏe, giảm biến chứng cho ngư ời bệnh. 
Béo phì gây ra các v ấn đề trầm trọng đến sức khỏe, là thủ phạm gây hơn 200 b ệnh khác 
nhau, như b ệnh tim m ạch, đ ột quị, đái tháo đư ờng, thoái hóa kh ớp, gan nhi ễm m ỡ và  
nhiều bệnh ung thư, đ ặc biệt là ung thư đư ờng tiêu hóa …Tình tr ạng tự chữa béo phì 
không có hi ệu quả, nhiều biến cố nặng và t ốn kém  
2. NGUYÊN NHÂN SINH BỆNH  BÉO PHÌ  
2.1. Nguyên nhân v ề dinh dư ỡng 
a) Nguyên nhân dinh dư ỡng của béo phì là đa d ạng, ch ủ yếu do:  
- Tăng quá m ức lượng năng lư ợng ăn vào  
- Ăn quá nhi ều: nghĩa là ăn m ột lượng th ức ăn nhi ều hơn nhu c ầu của cơ th ể.  
b) Người ăn quá m ức có th ể do nhi ều nguyên nhân khác nhau như:  
+ Thói quen của gia đình  
+ Sự chủ quan c ủa ngư ời ăn nhi ều 
- Chế độ ăn “giàu” ch ất béo  
- Ở trẻ em: tiêu th ụ quá nhi ều chất ngọt làm tăng nguy cơ béo phì  syt_sonla_vt_So Y te Son La_22/10/2022 22:04:035 
- Nuôi con b ằng sữa mẹ ít hơn 3 tháng thư ờng đi kèm v ới tăng nguy cơ béo phì ở trẻ 
em khi đ ến trư ờng.  
2.2. Nguyên nhân di truy ền  
Tế bào m ỡ dễ dàng phân chia theo m ột trong hai cách:  
- Quá s ản: vừa tăng th ể tích, v ừa tăng s ố lượng tế bào m ỡ (tăng g ấp 3 - 4 lần), xảy ra 
cho tr ẻ em ho ặc tuổi dậy thì, khó đi ều trị. 
- Phì đ ại: tế bào m ỡ to ra do gia tăng s ự tích t ụ mỡ nhưng không tăng s ố lượng hay g ặp 
ở người lớn, tiên lư ợng tốt hơn.  
2.3. Nguyên nhân n ội tiết 
- Tổn thương h ạ đồi do ch ấn thương, b ệnh lý ác tính, viêm nhi ễm, suy sinh d ục, giảm 
gonadotropin.     
- Hội chứng béo phì - sinh d ục 
- Suy giáp  
- Cường thư ợng th ận 
- U tụy tiết insulin  
- Hội chứng bu ồng trứng đa nang  
2.4. Nguyên nhân mô b ệnh h ọc 
- Tăng s ản quá m ức số lượng tế bào m ỡ mà kích thư ớc tế bào m ỡ có th ể bình thư ờng.  
- Phì đ ại tế bào m ỡ mà số lượng tế bào m ỡ không tăng ho ặc chỉ tăng khi các t ế bào m ỡ 
phì to h ết cỡ. 
2.5. Nguyên nhâ n do sử dụng thuốc 
- Hormon steroide  
- Kháng tr ầm cảm cổ điển (3 vòng, 4 vòng, IMAO)  
- Benzodiazepine  
- Lithium  
- Thuốc chống lo ạn thần 
2.6. Nguyên nhân khác  
- Lối sống tĩnh t ại, lười hoạt động th ể lực 
- Bỏ hút thu ốc lá. C ần chủ động phòng th ừa cân , béo phì khi b ỏ thuốc lá 
- Hút thu ốc khi mang thai: con cái c ủa các bà m ẹ hút thu ốc khi mang thai có nguy cơ 
gia tăng tr ọng lư ợng đáng k ể về sau này.  
Tuy nhiên, bệnh nhân béo phì có th ể do có nhi ều nguyên nhân ph ối hợp 
3. SINH LÝ BỆNH BÉO PHÌ   
- Bilan năng lư ợng: Bilan năng lư ợng cân bằng nếu cung c ấp (th ức ăn) b ằng tiêu th ụ 
(vận động cơ, ho ạt động các cơ quan). Béo phì xu ất hiện do m ất cân b ằng này ho ặc 
do cung c ấp gia tăng ho ặc do tiêu th ụ giảm 
- Sự điều hòa th ể trọng: quá trình này thông qua nhi ều hormone , đặc biệt là leptin  syt_sonla_vt_So Y te Son La_22/10/2022 22:04:036 
- Yếu tố di truyền: Béo phì có y ếu tố gia đình: 69% ngư ời béo phì có cha ho ặc mẹ béo 
phì, 18% có c ả hai  
- Vai trò vùng dư ới đồi 
+ Các tác nhân alpha -adrenergic, kích thích sự  ăn làm tăng cân,  tác động lên nhân 
cạnh thất  
+ Các tác nhân be ta-adrenergic : ngược lại làm chán ă n 
- Beta-endorphine: các th ụ thể này làm d ễ sự tiết insulin, gây ăn nhi ều làm tăng cân . 
+ Naloxone: đối kháng beta -endorphine, làm giảm ăn nhất là các thức ăn có vị ngon  
+ Serotonine: đối kháng với alpha -adrenergic , làm giảm ăn . 
- Các hormone:  
+ Insulin là hormone làm tân sinh mỡ  
+ Glucagon tác dụng đối kháng insulin  
+ Enkephalin và catecholamin từ tuyến thượng thận cũng có vai trò trong điều hòa 
thể trọng  
+ Hormone sinh dục và thượng thận có vai trò trong phân bố mỡ  
- Vai trò c ủa stress: làm tăng b eta-endorphine và adrenal in ở người béo phì, t ừ đó làm 
tăng đư ờng huy ết, tác d ụng phối hợp của 2 hormone này thi ết lập sự liên h ệ giữa 
stress, béo phì và đái tháo đư ờng típ 2.  
- Thái đ ộ ăn uống: trung tâm đói và no do vùng dư ới đồi điều khi ển, thái đ ộ ăn uống 
có th ể bị thay đ ổi do t huốc, chẳng hạn thu ốc thần kinh (amphetamine) làm gi ảm ngon 
miệng, ch ống trầm cảm 3 vòng làm tăng s ự ngon mi ệng. Các y ếu tố tâm lý liên quan 
đến môi trư ờng như giáo d ục, đời sống gia đình, môi trư ờng công vi ệc...có th ể làm 
rối loạn thái đ ộ ăn uống, từ đó có thể làm ăn nhi ều hoặc chán ăn.  
- Thuốc: nhi ều loại thu ốc làm tăng cân như các thu ốc an th ần kinh, mu ối lithium, 
corticoid e, đồng hóa protein, sinh progesteron, và có khi osestrogene (làm tăng ngon 
miệng). 
4. CHẨN ĐOÁN  
4.1. Chỉ số khối cơ th ể (BMI - Body mass index ) 
Chiều cao đ ứng: đư ợc đo b ằng thư ớc. Ngư ời được đo đ ứng th ẳng trong tư th ế thoải mái, 
mắt nhìn v ề phía trư ớc, hai gót chân sát nhau ch ụm lại thành hình ch ữ V, đo m ột đường 
thẳng từ đỉnh đầu đến gót chân. K ết quả tính b ằng đơn v ị mét và sai s ố không quá 0,1 
cm.  
Trọng lư ợng cơ th ể: Cân n ặng: Ngư ời được đo m ặc quần áo m ỏng nh ẹ, bỏ guốc dép và 
đứng lên cân theo đúng v ị trí, ch ỉ số trên màn hình s ẽ báo tr ọng lư ợng cơ th ể. Đo tr ọng 
lượng cơ th ể chính xác đ ến 0,1 kg. Đơn v ị biểu thị trọng lư ợng: kg.  
BMI (kg/ m2) = Cân n ặng (kg)/ Chiều cao (m2) 
  syt_sonla_vt_So Y te Son La_22/10/2022 22:04:037 
Bảng 4.1. Đánh giá tình tr ạng th ừa cân, béo phì theo tiêu chu ẩn của WHO  
áp dụng cho người Châu Á  
 
BMI  (kg/m2) Phân lo ại 
< 18,5  Thiếu cân  
18,5 – 22,9 Bình thư ờng 
23-24,9 Thừa cân  
25 - 29,9 Béo phì đ ộ I 
≥ 30 Béo phì đ ộ II 
4.2. Vòng b ụng 
Dụng cụ sử dụng thư ớc dây chia v ạch do Vi ệt Nam s ản xuất đạt tiêu chu ẩn của Cục đo 
lường Vi ệt Nam.  
Cách đo: B ệnh nhân đứng th ẳng hai chân, hai bàn chân cách nhau 10cm, tr ọng lư ợng cơ 
thể đều trên hai chân, b ộc lộ vùng đo, cho b ệnh nhân th ở đều đặn, đo lúc th ở ra nh ẹ, tránh 
co cơ.  
Vòng b ụng: đư ợc đo ngang qua đư ờng gi ữa bờ trên xương ch ậu và b ờ dưới xương sư ờn 
cuối cùng. S ai số không quá 0,1 cm. K ết quả tính b ằng centi mét (cm).  
Đánh giá k ết quả: béo phì d ạng nam  (béo phì ph ần trên cơ th ể, béo phì ki ểu bụng, béo 
phì hình qu ả táo, béo phì trung tâm) khi vòng b ụng ≥ 90 cm ở nam và  ≥80 cm ở nữ. 
(Theo B ộ Y tế và H ội Nội tiết & Đái tháo đư ờng Việt Nam).  
4.3. Phương pháp DEXA h ấp thụ năng lư ợng kép  
Phương pháp h ấp thụ năng lư ợng kép được xem là “ tiêu chu ẩn vàng ” để đánh giá lượng 
mỡ cơ th ể. DEXA đã đư ợc sử dụng rộng rãi đ ể nghiên c ứu quá trình kh ử khoáng xương 
(bone demineralization) và loãng xương và th ể hiện một tiến bộ đáng k ể trong đánh giá 
lượng m ỡ cơ th ể vì nó d ễ sử dụng trong các môi trư ờng lâm sàng và đ ộ chính xác cao 
hơn giúp phân bi ệt mô n ạc và m ỡ so với các phương pháp trư ớc đó như đo kháng l ực 
dưới nước toàn thân (hydrodensitometry). DEXA đ ịnh nghĩa m ột công ngh ệ theo đó s ự 
suy gi ảm bức xạ ở 2 năng lư ợng đư ợc sử dụng để xác đ ịnh 2 thành ph ần của mô suy 
giảm, ho ặc xương và mô m ềm ho ặc mô n ạc và m ỡ. Nhiều chuyên gia cho r ằng DEXA là 
một trong nh ững "tiêu chu ẩn vàng" đ ể đánh giá m ỡ cơ th ể.  
Các nghiên c ứu có giá tr ị đã ch ỉ ra rằng đánh giá lư ợng m ỡ cơ th ể của DEXA thư ờng so 
sánh t ốt với mô hình 4 ngăn trong đó lư ợng m ỡ cơ th ể được ước tính t ừ các phép đo  mật 
độ cơ th ể  như đo kháng l ực dưới nước (hydrodensitometry), t ổng lư ợng nư ớc toàn cơ 
thể (thường bằng cách pha loãng deuterium) và các giá tr ị độ khoáng xương b ằng DEXA. 
Tuy nhiên, các nghiên c ứu cho th ấy DEXA có th ể đánh giá th ấp lượng m ỡ cơ th ể ở người 
có tỷ lệ mỡ cơ th ể thấp và đánh giá quá cao lư ợng m ỡ cơ th ể ở người tỷ lệ mỡ cơ th ể cao 
hơn ở cả người lớn và tr ẻ em.  
Gần đây, DEXA đã đư ợc sử dụng để đánh giá s ự phân b ố mỡ trong cơ th ể trong t ừng 
vùng. M ỡ bụng thư ờng đư ợc đo gi ữa thân đ ốt sống L1 và L 4 trên hình ảnh ch ụp DEXA. 
Nghiên c ứu đã ch ỉ ra rằng kh ối lượng m ỡ bụng đư ợc đo b ằng DEXA và CT có m ối tương 
quan cao, m ặc dù DEXA đánh giá th ấp một cách có h ệ thống kh ối lượng m ỡ bụng đo 
được trên CT. 256 Tuy nhiên, DEXA không th ể phân bi ệt mỡ dưới da v ới mỡ nội tạng. syt_sonla_vt_So Y te Son La_22/10/2022 22:04:038 
Đánh giá m ỡ cơ th ể của DEXA đòi h ỏi rất ít b ức xạ (1 μSv), vì v ậy cho phép đo l ặp đi 
lặp lại thích h ợp sử dụng trong môi trư ờng lâm sàng. Quá trình đo b ằng DEXA cũng r ất 
nhanh chóng và d ễ dàng, áp d ụng cho c ả người khỏe mạnh và ngư ời bệnh. Đánh giá 
lượng m ỡ cơ th ể của DEXA đòi h ỏi các thi ết bị chuyên d ụng có chi phí v ừa phải nhưng 
không quá l ớn để dễ dàng trang b ị trong m ột phòng khám béo phì. DEXA là m ột công 
cụ thích h ợp để đo lư ờng thành ph ần mỡ cơ th ể và sự phân ph ối mỡ nhưng đư ợc dành 
riêng cho m ục đích nghiên c ứu tại thời điểm hiện tại cho đ ến khi có thêm d ữ liệu về dự 
đoán nguy  cơ và hi ệu quả chi phí.  
5. CÁC DẠNG BÉO PHÌ  
5.1. Béo phì d ạng nam (béo phì ph ần trên cơ th ể, béo phì ki ểu bụng, béo phì hình 
quả táo, béo phì trung tâm)  
- Mỡ phân b ố nhiều ở bụng, thân, vai, cánh tay, c ổ, mặt. 
- Vẻ mặt hồng hào  
- Cơ v ẫn phát tri ển khác v ới hội chứng Cushing  
- Dạng béo phì này thư ờng xảy ra ở người ăn nhi ều. 
Béo phì d ạng nam thư ờng dễ dẫn đến các bi ến chứng về chuy ển hóa như  hội chứng 
chuy ển hóa,  tiền đái tháo đư ờng,đái tháo đư ờng típ 2, bệnh gút , bệnh tim, tăng huyết áp, 
bệnh túi m ật, ung thư  vú,...  
5.2. Béo phì d ạng nữ (béo phì ph ần dư ới cơ th ể, béo phì hình qu ả lê) 
- Mỡ phân b ố chủ yếu ở phần dưới của cơ th ể (khung ch ậu, vùng th ắt lưng, mông, đùi)  
- Da xanh  
- Cơ ít phát tri ển 
- Thường bị suy như ợc 
- Thường kèm suy tĩnh m ạch, rối loạn kinh nguy ệt ở nữ 
5.3. Béo phì h ỗn hợp 
Mỡ phân b ố khá đ ồng đều. Các trư ờng hợp quá béo phì thư ờng là béo phì h ỗn hợp. 
6. ĐIỀU TRỊ BÉO PHÌ  
6.1. Mục tiêu và nguyên t ắc chung  
6.1.1.  Mục tiêu  
- Mục tiêu chung: Vi ệc quản lý và đi ều trị béo phì có m ục tiêu r ộng hơn là gi ảm cân 
đơn thu ần mà còn c ần giảm nguy cơ các biến chứng và c ải thiện sức khỏe. Nh ững 
điều này có th ể đạt được bằng cách gi ảm cân v ừa phải, cải thiện hàm lư ợng dinh 
dưỡng trong ch ế độ ăn uống và k ể cả vận động và t ập thể dục mức độ trung bình. 
Điều trị tốt béo phì có th ể làm gi ảm nhu c ầu điều trị bệnh đồng m ắc. Đi ều trị thích 
hợp cho béo phì ngoài vi ệc kiểm soát cân n ặng nên bao g ồm điều trị các bi ến chứng: 
quản lý r ối loạn lipid máu, t ối ưu hóa ki ểm soát đư ờng huy ết ở bệnh nhân đái tháo 
đường típ 2, đi ều trị tăng huy ết áp, qu ản lý r ối loạn hô h ấp (như  hội chứng ngưng th ở 
khi ng ủ), chú ý đ ến kiểm soát cơn đau và nhu c ầu vận động trong viêm kh ớp, qu ản lý 
rối loạn tâm lý xã h ội, bao g ồm rối loạn cảm xúc, r ối loạn ăn u ống và gi ảm lòng t ự 
trọng,  và suy nghĩ tiêu c ực về hình ảnh cơ th ể. Bối cảnh kinh t ế xã hội của bệnh nhân 
cũng c ần được tính đ ến trong vi ệc thiết lập chi ến lược điều trị. syt_sonla_vt_So Y te Son La_22/10/2022 22:04:039 
- Mục tiêu gi ảm cân th ực tế: Giảm cân 5 –15% trong kho ảng th ời gian 6 tháng là th ực 
tế và đã đư ợc chứng minh mang l ại lợi ích s ức khỏe. Có th ể cân nh ắc giảm cân nhi ều 
hơn (20% trở lên) đ ối với những ngư ời có m ức độ béo phì cao hơn (BMI ≥ 35 kg/m2). 
Duy trì gi ảm cân và phòng ng ừa và đi ều trị các b ệnh đồng m ắc là hai tiêu chí chính 
để thành công.  
- Theo dõi ngư ời bệnh: Béo phì là m ột bệnh mạn tính. Ngư ời bệnh cần được theo dõi 
và tái khám thư ờng xuyên đ ể ngăn ng ừa tăng cân tr ở lại và đ ể theo dõi nguy cơ b ệnh 
tật cũng như đi ều trị các b ệnh đồng m ắc nếu xuất hiện (ví d ụ: đái tháo đư ờng típ 2, 
bệnh tim m ạch). 
6.1.2. N guyên t ắc chung  
- Can thi ệp lối sống là n ền tảng đảm bảo duy trì gi ảm cân bền vững, an toàn bao g ồm 
các bi ện pháp can thi ệp dinh dư ỡng, tập luy ện thể lực, thay đ ổi hành vi, h ỗ trợ tâm lý . 
- Điều trị bằng thu ốc khi can thi ệp lối sống trong 3 tháng không giúp gi ảm đư ợc 5% 
cân n ặng, ngư ời bệnh có BMI ≥ 25 kg/m2. 
- Phối hợp chặt chẽ của nhi ều chuyên khoa đ ể đạt được hiệu quả điều trị và duy trì giảm 
cân đ ạt yêu c ầu bền vững.  
- Phối hợp đa chuyên khoa là n ền tảng trong mô hình chăm sóc đi ều trị béo phì : Béo 
phì là m ột tình tr ạng ph ức tạp có ngu ồn gốc đa y ếu tố. Các y ếu tố sinh h ọc mà c ả tâm 
lý và xã h ội cùng tác đ ộng dẫn đến quá cân và các bi ến chứng liên quan. Qu ản lý béo 
phì không th ể chỉ tập trung vào vi ệc giảm cân (và BMI). Qu ản lý các b ệnh đồng m ắc, 
cải thiện chất lượng cu ộc sống và s ức khỏe của bệnh nhân béo phì c ũng đư ợc đưa vào 
mục tiêu đi ều trị. Quản lý béo phì toàn di ện nên đư ợc thực hiện bởi một đội ngũ thích 
hợp gồm nhi ều chuyên khoa và bao g ồm các chuyên gia khác nhau đ ể có th ể giải 
quyết các khía c ạnh khác nhau c ủa béo phì và các r ối loạn liên quan. Ngư ời bệnh nên 
hiểu rằng, vì béo phì là m ột bệnh mãn tính, nên vi ệc quản lý cân n ặng sẽ cần phải kéo 
dài su ốt đời. 
Xây d ựng nhóm các chuyên gia đa chuyên khoa: nh ững bác sĩ đư ợc đào t ạo đặc biệt về 
quản lý béo phí, chuyên gia dinh dư ỡng, nhà tr ị liệu hành vi, chu yên gia hư ớng dẫn vận 
động th ể lực, điều dưỡng về bệnh béo phì, bác sĩ ph ẫu thu ật. syt_sonla_vt_So Y te Son La_22/10/2022 22:04:0310 
 
Sơ đồ 6.1. Hư ớng dẫn theo dõi và đi ều trị bệnh béo phì  
6.2. Điều trị cụ thể 
6.2.1.  Tiết thực  
a. Nguyên t ắc điều trị tiết thực 
- Phải điều trị kiên trì, lâu dài, ph ối hợp nhi ều phương pháp  
- Phải điều trị tích c ực khi có tăng huy ết áp, suy tim … 
- Điều trị phải giảm cân m ột cách t ừ từ, bền vững đáp ứng nhu c ầu của ngư ời bệnh 
b. Chế độ ăn gi ảm năng lư ợng 
- Giảm tổng lư ợng năng lư ợng (calo) ăn vào nên là y ếu tố chính c ủa bất kỳ can thi ệp 
giảm cân nào . 
- Điều chỉnh hành vi ăn u ống cá nhân và ph ải thay đ ổi dần dần, cộng với sự hỗ trợ của 
gia đình, xã hội, môi trư ờng sống … 
- Chế độ ăn cân đ ối giữa các ch ất sinh nhi ệt, không quá nhi ều glucid, t ỷ lệ thay đ ổi tùy 
cá th ể theo b ệnh lý m ắc kèm, thói quen ăn u ống 
- Cung c ấp đầy đủ các vitamin c ần thiết: vitamin tan trong d ầu, kali, s ắt, acid amin  
- Hạn chế số bữa ăn trong ngày (3 b ữa là đ ủ), hạn chế ăn lo ại glucid h ấp thu nhanh và 
các ch ất béo bão hoà, mu ối dưới 5g/ngày  
- Kiêng rư ợu 
 
syt_sonla_vt_So Y te Son La_22/10/2022 22:04:0311 
Bảng 6.1. Phân b ố các ch ất dinh dư ỡng mỗi ngày  
 
Chất dinh dư ỡng Tỷ lệ phân b ố 
Lipid  < 30%   tổng calori  
Protid  15 - <20%  tổng calori  
Glucid  50 - 55% tổng calori  
Muối <5g 
Calci  Theo nhu c ầu dinh dư ỡng khuy ến ngh ị 
Chất xơ 20-30g 
Bảng 6. 2. Phân lo ại tiêu th ụ năng lư ợng dựa trên m ức độ lao đ ộng và gi ới tính  
 
Mức độ lao đ ộng/ 
 
Nhu c ầu năng 
lượng (kcal)  Lao đ ộng 
nhẹ 
 Lao đ ộng 
vừa 
 Lao đ ộng 
nặng 
Nam  Nhân viên văn 
phòng (giáo viên, 
luật sư, bác s ỹ, 
kế toán, giáo 
viên... ), nhân 
viên bán hàng, 
người thất 
nghiệp. Công nhân công 
nghiệp nhẹ, sinh 
viên, công nhân 
xây d ựng, nông 
dân, ngư dân, 
quân đ ội không 
trong  thời gian 
chiến đấu. Nông dân trong v ụ 
thu ho ạch, công nhân 
lâm nghi ệp, lao đ ộng 
thể lực đơn gi ản, 
chiến sỹ quân đ ội 
trong chi ến đấu/ 
luyện tập, công nhân 
mỏ, luyện thép, v ận 
động viên th ể thao 
trong th ời gian luy ện 
tập. 
30 kcal/kg  35 kcal/kg  45 kcal/kg  
Nữ Nhân viên văn 
phòng, giáo viên, 
nội trợ (không 
phải chăm sóc tr ẻ 
nhỏ), hầu hết các 
nghề khác.  Công nhân công 
nghiệp nhẹ, nhân 
viên bán hàng, 
sinh viên, ph ụ nữ 
nội trợ đang 
chăm sóc tr ẻ nhỏ. Nông dân trong v ụ 
thu ho ạch, vũ công, 
vận động viên th ể 
thao trong th ời gian 
luyện tập. 
25 kcal/kg  30 kcal/kg  40 kcal/kg  
Cách tính th ực đơn dành cho ngư ời béo mu ốn giảm cân đư ợc tính theo cân n ặng lý tưởng: 
Cân n ặng lý tư ởng (CNLT) = (chi ều cao)2 (m2) × 22  
Chế độ ăn: 
Lao đ ộng nh ẹ = CNLT × (20 -25 calo)  
Lao đ ộng trung bình = CNLT × (25 - 30 calo)  
Lao đ ộng nặng = CNLT × (30 -35 calo)  syt_sonla_vt_So Y te Son La_22/10/2022 22:04:0312 
Mục tiêu là gi ảm cân t ừ từ khoảng 2 - 3 kg/tháng. Ph ối hợp giáo d ục với chế độ ăn cho 
bệnh nhân, ph ải theo dõi thư ờng xuyên cân n ặng và có bi ện pháp h ỗ trợ tâm lý cho b ệnh 
nhân.  
Tăng cư ờng vận động và t ập thể dục: áp d ụng tùy theo tu ổi và các bi ến chứng đã có ở 
bệnh nhân hay không, t ập thể lực rất hữu ích m ặc dù tiêu t ốn năng  lượng tương đ ối ít 
trong khi t ập luy ện. 
Phải chia ch ế độ ăn làm 2 giai đ ọan: giai đo ạn giảm cân và giai đoạn duy trì.  
Điều trị béo phì chưa có bi ến chứng ch ủ yếu dựa vào ki ểm soát ch ế độ ăn. 
6.2.2.  Chế độ vận động trong điều trị béo phì  
a. Hướng dẫn tập luy ện: 
Cần thăm dò tim m ạch trư ớc khi b ắt đầu chương trình v ận động, nh ất là v ới ngư ời lớn 
tuổi, có y ếu tố nguy cơ tim m ạch. 
Để buổi tập an toàn và hi ệu quả, nên th ực hiện đủ 3 giai đo ạn:  
- Khởi động (5 -10 phút): làm nóng cơ th ể với những động tác đơn gi ản, cư ờng độ thấp. 
Khởi động các kh ớp từ trên xu ống dư ới. 
- Tập luy ện: thực hiện các bài t ập vận động từ 20 đến 30 phút.  
- Làm ngu ội (5-10 phút): thư giãn, th ả lỏng cơ th ể với những động tác ch ậm rãi, đưa 
cơ th ể về trạng thái ban đ ầu. 
b. Cường độ tập luy ện: 
Tập luy ện hoạt động thể chất sức bền (aerobic ) là m ột biện pháp thi ết yếu trong các 
chương trình gi ảm cân cho ngư ời béo phì. Nên th ực hiện các bài t ập cường độ trung bình 
ít nhất 150 phút m ỗi tuần, 3 đ ến 5 lần một tuần, bắt đầu bằng bài t ập cường độ thấp và 
tăng d ần cường độ và số lượng tập thể dục theo m ức độ thể dục cá nhân. T ập luy ện đề 
kháng nên đư ợc áp d ụng trong các chương trình gi ảm cân đ ể tăng kh ối lượng cơ và thúc 
đẩy giảm mỡ cơ th ể, và đư ợc đề nghị thực hiện bằng các bài t ập sử dụng các nhóm cơ 
lớn 2-4 lần một tuần. 
Dùng công th ức tính nh ịp tim khi t ập để xác đ ịnh m ức độ phù h ợp của cường độ tập 
luyện: 
Nhịp tim khi t ập = (220 - tuổi) x (từ 50% đến 70%) 
Ví dụ: một ngư ời 40 tu ổi được xem là v ận động phù h ợp nếu khi t ập luy ện nhịp tim đ ạt 
mức: (220 - 40) x 0 ,5 = 90 lần/phút.  
Người bệnh cũng có th ể tự đánh giá m ức độ vận động đã phù h ợp chưa qua gi ọng nói: 
khi tập luy ện không th ấy hụt hơi, v ẫn trò chuy ện được nhưng không th ể hát đư ợc. 
c. Thời gian t ập luy ện: 
Có th ể tập vào b ất kỳ thời điểm nào trong ngày, mi ễn là phù h ợp với nếp sinh ho ạt của 
mình.  
Mỗi ngày trung bình 30 - 40 phút. Ho ặc vận động nhi ều lần trong ngày, m ỗi lần tối thiểu 
10 phút. Nên v ận động tối thiểu 5 ngày/tu ần, tốt hơn nên t ập đều đặn mỗi ngày.  
d. Loại hình t ập luy ện: 
Nên l ựa chọn các lo ại hình t ập luy ện có tính nh ịp nhàng đ ều đặn, thời gian kéo dài như: 
đi bộ, đạp xe, bơi l ội, dưỡng sinh…  syt_sonla_vt_So Y te Son La_22/10/2022 22:04:0313 
Tuy v ậy, có th ể tập bất cứ loại hình nào phù h ợp với sức khỏe, tuổi tác, s ở thích và đi ều 
kiện sống. 
Nếu có bi ến chứng ở mắt, tim , thận, bàn chân, nên h ỏi ý ki ến bác sĩ v ề loại hình luy ện 
tập thích h ợp. Thông thư ờng trong các trư ờng hợp này lo ại hình luy ện tập phù h ợp nhất 
là đi b ộ. 
Nếu không có đi ều kiện tập liên t ục 30 phút, có th ể chia ra 2 -3 lần/ngày, m ỗi lần 5-10 
phút. Mi ễn sao t ập đều đặn. 
Luyện tập để tăng cư ờng sức khỏe thể chất và tinh th ần, ngoài công vi ệc hàng ngày. Ví 
dụ một bà n ội trợ đi ch ợ nấu ăn, quét d ọn nhà c ửa sẽ tiêu hao m ột số năng lư ợng, nhưng 
vẫn cần duy trì luy ện tập thể lực mỗi ngày.  
      Bảng 6.3. Tham kh ảo năng lư ợng kcalo tiêu th ụ được sau 30 ph út tập thể dục 
 
Cân n ặng (kg)  50 60 70 80 90 100 
Hoạt động trong phòng t ập 
Aerobic: trung bình  149 177 206 234 263 291 
Đạp xe: 16 km/h  163 195 226 258 289 321 
Chạy: 10km/h  260 310 360 410 460 510 
Máy leo thang: trung bình  158 190 222 253 285 317 
Giãn  duỗi / yoga Hatha  106 127 148 169 190 211 
Đi bộ: bình thư ờng 4km/h  78 93 108 123 138 153 
Đi bộ: nhanh 7km/h  149 177 206 234 263 291 
Tập tạ: trung bình  79 95 111 127 143 158 
Thể thao       
Cầu lông  119 143 166 190 214 238 
Bi-a 66 79 92 106 119 132 
Nhảy 145 174 203 232 261 290 
Nhảy dây  264 317 370 422 475 528 
Bóng đá  185 222 259 296 333 370 
Bơi l ội 25 m/phút  123 146 170 193 217 240 
Thái c ực quy ền 106 127 148 169 190 211 
Quần vợt 185 222 259 296 333 370 
e. Một số lưu ý  trong v ận động 
- Nhiều ngư ời có cuộc sống tĩnh t ại, có r ất ít k ỹ năng ho ạt động th ể lực và r ất khó đ ể 
thúc đ ẩy hoạt động của họ. Vì v ậy, các đ ối tượng này đư ợc khuy ến cáo nên b ắt đầu 
với chế độ vận động. Gi ảm thời gian tĩnh t ại là phương pháp ti ếp cận mới nhằm tăng 
cường ho ạt động. B ệnh nhân đư ợc khuy ến khích tham gia các ho ạt động th ể lực hàng 
ngày, ví d ụ như nên đi c ầu thang b ộ hơn là đi thang máy ho ặc thang cu ốn. Khuy ến 
khích các ho ạt động th ể lực tại các đ ịa điểm an toàn như: công viên, nhà thi đ ấu, bể syt_sonla_vt_So Y te Son La_22/10/2022 22:04:0314 
bơi, câu l ạc bộ sức khỏe,… Tuy nhiên, n ếu không d ễ thực hiện, thì t ận dụng kho ảng 
không t ại nhà v ới các thi ết bị như: xe đ ạp tại chỗ hay th ảm lăn ho ặc các hình th ức vận 
động phù h ợp. 
- Điều cần thiết là tránh ch ấn thương khi v ận động cư ờng độ cao. Nh ững ngư ời béo  phì 
nặng cần bắt đầu với bài tập đơn gi ản sau đó tăng d ần đều. Th ầy thu ốc phải quy ết 
định ch ọn bài kiểm tra thể lực nào là c ần thiết trước khi ch ọn một chế độ vận động 
cho b ệnh nhân. Quy ết định này nên đư ợc dựa vào tu ổi tác, tri ệu chứng và các y ếu tố 
nguy cơ n ổi trội. 
- Đối với hầu hết ngư ời bệnh nhân béo phì, ho ạt động th ể lực nên đư ợc bắt đầu một 
cách ch ậm rãi và tăng d ần. Ho ạt động kh ởi đầu có th ể là đi b ộ hay bơi ch ậm. Tuỳ 
thuộc vào th ời gian m ắc bệnh, tr ọng lư ợng gi ảm đư ợc, thể trạng,… bệnh nhân có th ể 
được tham gia các ho ạt động nặng hơn, ví d ụ như: đi b ộ- tập thể hình, đi xe đ ạp, bơi 
thuyền, ch ạy, nh ảy aerobic, nh ảy dây,…Vi ệc chạy bộ với cường độ cao có th ể dẫn 
đến chấn thương. Các môn th ể thao đ ối kháng, ví d ụ như: qu ần vợt, bóng chuy ền,…là 
hình th ức hoạt động thích thú cho nhi ều ngư ời nhưng ph ải cẩn thận để tránh ch ấn 
thương, đ ặc biệt ở người già.  
- Chế độ điều trị có th ể thay đ ổi nhằm phù h ợp với các hình th ức khác c ủa hoạt động 
thể lực, tuy nhiên, đi b ộ đặc biệt vẫn được ưa chu ộng vì tính an toàn và tính kh ả thi. 
Hiệu quả điều trị được nâng lên n ếu bệnh nhân không dùng các th ức ăn cao năng 
lượng. 
- Bệnh nhân nên nh ờ các chuyên gia s ức khỏe lên k ế hoạch và l ập thời khóa bi ểu mỗi 
1 tuần, đồng th ời ghi nh ận các thông s ố sức khỏe khi v ận động. 
6.2.3.  Tâm lý liệu pháp trong điều trị béo phì  
- Tâm lý li ệu pháp có th ể được áp d ụng không ch ỉ như m ột can thi ệp hành vi đư ợc lập 
trình đ ể kiểm soát cân n ặng, mà còn cho m ục đích thay đ ổi hành vi liên quan đ ến 
lượng th ức ăn và ho ạt động th ể chất. 
- Điều trị béo phì t ừ lâu đã đư ợc biết đến là hi ệu quả hơn k hi các can thi ệp về lối sống 
bao g ồm cả liệu pháp hành vi đư ợc thực hiện. Do đó, t ất cả những ngư ời béo phì nên 
trải qua li ệu pháp hành vi, cùng v ới liệu pháp dinh dư ỡng và tăng cư ờng ho ạt động 
thể chất. Các phương pháp c ụ thể được sử dụng trong li ệu pháp hành vi bao g ồm tự 
giám sát, c ủng cố, kiểm soát kích thích, hành vi thay th ế và sự tái tạo nhận thức. 
- Khi đi ều trị bệnh béo phì, đi ều rất quan tr ọng là ch ẩn đoán và đi ều trị bất kỳ rối loạn 
ăn uống nào đang có.  
- Khi đi ều trị béo phì, ph ải chấm dứt hoặc giảm hút thu ốc và u ống rư ợu. Nh ững ngư ời 
béo phì nên đư ợc khuyên b ỏ hút thu ốc. Rư ợu có th ể sinh năng lư ợng kho ảng 7,0 kcal 
mỗi gam. Ngoài ra, h ầu hết rượu được uống vào đư ợc chuy ển thành axetat, c ản trở 
chất béo ngo ại vi phân h ủy và s ử dụng. V ề mặt lâm sàng, rượu làm tăng huy ết áp và 
uống quá nhi ều làm tăng nguy cơ tăng triglycerid máu, kháng insulin, đái tháo đư ờng 
típ 2, h ội chứng chuy ển hóa và béo b ụng. Do đó, vi ệc kiểm soát vi ệc uống rư ợu quá 
mức là r ất quan tr ọng đối với việc ngăn ng ừa và ki ểm soát b ệnh béo phì và h ội chứng 
chuy ển hóa . 
- Hỗ trợ tâm lý b ệnh nhân b ằng cách chuy ện trò ho ặc sinh ho ạt nhóm bên c ạnh các  lời 
khuyên v ề điều chỉnh ch ế độ ăn. B ệnh nhân thư ờng bị trầm cảm, lo l ắng th ất bại trong 
điều trị. syt_sonla_vt_So Y te Son La_22/10/2022 22:04:0315 
6.2.4.  Thuốc  
a. Nguyên t ắc chung  khi s ử dụng thu ốc 
- Khuyến cáo m ục tiêu  chính là giảm 5-10% cân n ặng trong 6 tháng sau khi b ắt đầu 
điều trị.  
- Thay đ ổi hành vi s ức khỏe là n ền tảng trong đi ều trị béo phì. Tuy nhiên thay đ ổi hành 
vi sức khỏe đơn thu ần thư ờng không đ ủ để đạt được mục tiêu đi ều trị béo phì. Thay 
đổi hành vi s ức khỏe nhìn chung ch ỉ giảm 3-5% cân n ặng, và thư ờng không duy trì 
được trong th ời gian dài.  
- Thuốc điều trị béo phì nên đư ợc xem xét đ ể giảm cân n ặng và c ải thiện chuy ển hóa 
và/ho ặc các ch ỉ số sức khỏe khi li ệu pháp thay đ ổi hành vi s ức khỏe đơn thu ần tỏ ra 
không hi ệu quả, không đ ủ hoặc không đ ạt được lợi ích b ền vững.  
- Trong trư ờng hợp không đ ạt được mục tiêu gi ảm cân thông qua can thi ệp lối sống ở 
bệnh nhân có ch ỉ số BMI ≥ 25 kg/m2, cần xem xét đi ều trị bằng thu ốc. Hai lo ại thuốc 
được phê duy ệt trong đi ều trị béo phì bao g ồm: orlistat và liraglutide 3,0 mg.  
- Các thuốc khác không đư ợc phê duy ệt cho  điều trị béo phì . 
b. Những cân nh ắc khi s ử dụng thu ốc điều trị béo phì  
- Các y ếu tố cần xem xét đ ể quyết định lựa chọn loại thuốc phù h ợp cho ngư ời thừa cân 
hoặc béo phì:  
+ Nguyên nhân gây bệnh . 
+ Yếu tố tâm lý xã hội, cảm xúc và ý thích góp phần vào tình trạng bé o phì: nên 
được chẩn đoán và xử trí nếu có thể . 
+ Cơ chế tác dụng, tác dụng phụ, bất lợi, tính an toàn và khả năng dung nạp của mỗi 
thuốc phải được xem xét trong bối cảnh bệnh đồng mắc và các thuốc hiện đang 
điều trị của người bệnh.  
+ Chi phí thuốc cũng như đ ường dùng (uống hay tiêm dưới da) và tần suất sử dụng 
có thể là rào cản cho sự tuân trị: cần được thảo luận.  
+ Rà soát những thuốc đang dùng có thể là tác nhân làm tăng cân: xem xét dùng 
thuốc thay thế nếu phù hợp.  
- Nếu không đ ạt được tình tr ạng gi ảm cân có ý nghĩa lâm sàng v ới thuốc:  cần đánh giá 
lại những yếu tố khác góp ph ần dẫn đến thất bại của việc dùng thu ốc, bao g ồm: 
+ Liều dùng không phù hợp hoặc không tuân trị  
+ Những rào cản của việc thay đổi hành vi sức khỏe  
+ Những vấn đề về tâm lý xã hội hoặc y tế  
- Mỗi cá nhân đáp ứng đi ều trị khác nhau v ới từng lo ại thuốc. Cân nh ắc thay đ ổi thuốc 
hoặc liệu pháp đi ều trị béo phì khác n ếu không đ ạt được hiệu quả giảm cân trên lâm 
sàng đáng k ể sau ba tháng dùng li ều đủ/tối đa, dung n ạp được và không có b ằng ch ứng 
về nguy ên nhân khác gây th ất bại.  
- Khuyến cáo ngưng thu ốc điều trị béo phì n ếu không đ ạt được giảm ≥ 5% cân n ặng 
sau ba tháng dùng li ều điều trị. Tuy nhiên, thu ốc cũng có th ể được sử dụng để duy trì 
sự giảm cân đ ạt được bằng m ột liệu pháp thay đ ổi hành vi s ức khỏe trư ớc đó ho ặc 
một chế độ ăn năng lư ợng rất thấp. syt_sonla_vt_So Y te Son La_22/10/2022 22:04:0316 
- Thuốc điều trị béo phì đư ợc dự định là m ột phần của chi ến lược điều trị lâu dài. Tăng 
cân tr ở lại sau khi ngưng các đi ều trị tích c ực được chứng minh trong các th ử nghiệm 
lâm sàng  đối với các thuốc điều trị béo phì.  
- Không khuy ến cáo dùng thu ốc điều trị béo phì trên ph ụ nữ mang thai và cho con bú, 
hoặc phụ nữ đang chu ẩn bị có thai. Không có d ữ liệu sẵn thông tin v ề thời điểm ngưng 
thuốc điều trị béo phì trư ớc khi th ụ thai. 
c. Thuốc được phê duy ệt cho đi ều trị béo phì  
- Orlistat  
+ Cơ chế: Orlistat, một dẫn xuất của lipstatin bán tổng hợp, được phê duyệt là thuốc 
điều trị béo phì. Đây là một chất ức chế mạnh có chọn lọc men lipase tụy, vì vậy 
ức chế sự thoái giáng triglyceride trong thức ăn thành acid béo tự do có kh ả năng 
hấp thụ. Orlistat không tác động đặc hiệu lên cơ chế no hoặc thèm ăn.  
+ Liều dùng:  120 mg, ba lần mỗi ngày (uống trong hoặc sau ăn 1 giờ) để giảm cân 
hoặc giảm nguy cơ tăng cân trở lại ở người bệnh có BMI ≥ 30 kg/m2 hoặc BMI ≥ 
27 kg/m2 kèm theo bệnh đồng mắc (ví dụ : tăng huyết áp, đái tháo đường  típ 2, rối 
loạn lipid máu, mỡ thừa ở tạng).  
+ Tác dụng phụ: Orlistat có nhiều tác dụng bất lợi trên dạ dày ruột, bao gồm đi cầu 
phân  có mỡ , trung tiện  và tăng thải phân. Orlistat có thể làm ảnh h ưởng đến sự 
hấp thụ vitamin tan trong chất béo (A, D, E, K).  
+ Chống chỉ định : ở người có hội chứng kém hấp thu mạn tính hay ứ mật. Một vài 
bệnh nhân có thể xuất hiện sỏi oxalate niệu với mức độ tăng dần khi dùng orlistat; 
bệnh thận oxalate với suy thận đã được ghi nhận. Một số trường hợp hiếm gặp có 
tổn thương gan nặng hoặc suy gan cấp.  
+ Lưu ý: Vì orlistat có thể làm ảnh hưởng đến sự hấp thu vitamin K, chỉ số INR 
(international normalized ratio) nên được theo dõi sát khi dùng kèm thuốc kháng 
đông đường uống.  Orlistat có thể ảnh hưởng sự hấp thu levothyroxine và/hoặc 
muối iodine, người bệnh đang dùng levothyroxine nên được theo dõi sự thay đổi 
chức năng tuyến giáp. Giảm nồng độ cyclosporine huyết tương đã được ghi nhận 
khi uống kèm orlistat; vì vậy, theo dõi n ồng độ cyclosporine thường xuyên hơn 
được khuyến cáo. Orlistat có thể ảnh hưởng đến sự hấp thu thuốc chống co giật, 
vì vậy người bệnh đang dùng thuốc chống co giật nên được theo dõi những thay 
đổi có thể xảy ra về tần số và/hoặc mức độ nặng của tình trạng co giật.  Ngoài ra, 
vì orlistat  thường gây  ra tác dụng phụ  ở dạ dày ruột nên cũng làm  hạn chế việc sử 
dụng thuốc trong điều trị béo phì.  
- Liraglutide  
+ Cơ chế: Liraglutide là glucagon -like peptide 1 (GLP -1) analog người, sử dụng 
hàng ngày dưới dạng tiêm dưới da tác động trung ương lên neuron pro -
opiomelanocortin (POMC)/CART nhằm tăng cảm giác no, giảm cảm giác đói, với 
tác dụng giảm sự làm trống dạ dày thoáng qua.  
+ Liều d ùng: Liraglutide được phê duyệt ở Việt Nam năm 2021 trong điều trị béo 
phì mạn tính ở liều 3,0mg mỗi ngày, ở người bệnh có hoặc không có đái tháo 
đường  típ 2. Liều khởi đầu khuyến cáo của liraglutide là 0 ,6mg mỗi ngày, tăng 
dần 0 ,6 mg sau mỗi tuần cho đến khi đạt được liều mục tiêu 3 ,0 mg.  syt_sonla_vt_So Y te Son La_22/10/2022 22:04:0317 
+ Tác dụng phụ : thường gặp nhất của liraglutide là buồn nô n do giảm thoáng qua sự 
trống dạ dày. Người bệnh có thể gặp táo bón, tiêu chảy, ợ nóng và/hoặc nôn. Chỉnh 
liều chậm hơn có thể giúp giảm nhẹ tác dụng phụ dạ dày ruột nếu c ó. Nguy cơ 
xuất hiện sỏi mật với liraglutide cao hơn 1.4% so với giả dược.  
+ Chống chỉ định trên bệnh nhân có tiền sử cá nhân hoặc gia đình có ung thư tuyến 
giáp thể tủy hoặc tiền sử cá nhân đa u tuyến nội tiết típ 2 do có sự tăng nguy cơ 
ung thư tuyến giáp thể tủy trong nghiên cứu trên loài gặm nhấm.  
+ Lưu ý: Liraglutide làm chậm sự trống dạ  dày, có thể ảnh hưởng đến sự hấp thu 
các thuốc đường uống dùng đồng thời.  
Thông tin về thuốc điều trị bệnh béo phì chi tiết trong Phụ lục kèm theo.  
6.2.5.  Điều trị phẫu thuật trong béo phì  
Chỉ định của phẫu thu ật giảm cân khi thất bại với các đi ều trị không ph ẫu thu ật ở người 
bệnh có BMI ≥ 35 kg/m2 hay BMI≥ 30 kg/m2 kèm b ệnh lý đ ồng m ắc liên quan béo phì,  
Mỗi phương pháp ph ẫu thu ật béo phì đ ều có ưu như ợc điểm riêng. Tùy t ừng trư ờng hợp 
bệnh nhân c ụ thể phẫu thu ật viên s ẽ tư vấn và l ựa chọn phẫu thu ật phù h ợp. 
a. Phẫu thu ật đặt vòng th ắt dạ dày 
Vào năm 1976 Wilkinson báo cáo k ỹ thuật đặt vòng th ắt dạ dày l ần đầu tiên tuy nhiên 
vòng th ắt không có bu ồng ch ỉnh, ph ẫu thu ật thắt đai d ạ dày có bu ồng ch ỉnh đư ợc Kuzmac 
và Forsell đ ồng th ời báo cáo vào năm 1990. Vòng th ắt dạ dày có 1 bu ồng ch ỉnh đư ợc đặt 
dưới da và n ối với đai d ạ dày b ởi dây d ẫn. Bu ồng ch ỉnh này giúp tùy ch ỉnh đai d ạ dày.  
 
 
Hình 6.1. Phẫu thu ật đặt vòng th ắt dạ dày 
Phẫu thu ật đặt vòng th ắt có ưu đi ểm đơn gi ản, dễ thực hiện, thời gian ph ẫu thu ật ngắn, ít 
biến chứng. Tuy nhiên c ần phải theo dõi lâu dài sau m ổ. Bệnh nhân c ần theo dõi hàng 
tháng trong ít nh ất 3 tháng đ ầu tiên sau m ổ. Bệnh nhân cũng c ần được theo dõi và ch ỉnh 
đai tùy thu ộc mức độ giảm cân trong th ời gian dài. Ph ẫu thu ật đặt vòng th ắt có ưu đi ểm 
rất dễ phục hồi, dễ trả lại giải phẫu đường tiêu hóa.  
Dây d ẫn Buồng ch ỉnh 
“Túi” d ạ dày trên 
vòng th ắt 
Vòng th ắt 
Phần dạ dày 
dưới vòng th ắt syt_sonla_vt_So Y te Son La_22/10/2022 22:04:0318 
Cơ ch ế của việc giảm cân trong ph ẫu thu ật đặt vòng th ắt dạ dày là do vi ệc đặt một vòng 
thắt ở tâm v ị dạ dày do đó lư ợng th ức ăn đưa và o cơ th ể sẽ giảm đi. M ặt khác vi ệc tạo 
một túi ở phía tâm v ị dạ dày v ới áp l ực của vòng th ắt dạ dày cũng tác đ ộng kích ho ạt cơ 
chế tạo cảm giác no ở các b ệnh nhân đư ợc phẫu thu ật giúp làm gi ảm nhu c ầu ăn c ủa bệnh 
nhân.  
b. Phẫu thu ật tạo hình d ạ dày ống đứng 
Năm 2000 McMahon th ực hiện kỹ thuật phẫu thu ật tạo hình d ạ dày ống đứng đầu tiên t ại 
Leeds . 
Phẫu thu ật tạo hình d ạ dày ống đứng làm h ẹp và làm gi ảm thể tích c ủa dạ dày do đó làm 
giảm lượng th ức ăn đưa vào cơ th ể. 
 
Hình 6.2. Kỹ thuật tạo hình dạ dày ống đứng 
Phẫu thu ật tạo hình d ạ dày ống đứng có ưu đi ểm là ph ẫu thu ật không quá ph ức tạp, thời 
gian ph ẫu thu ật ngắn. Do ph ần còn l ại của dạ dày giãn ra sau m ổ nên sau 4 năm có nh ững 
bệnh nhân tăng cân tr ở lại. Một trong nh ững phi ền toái sau m ổ là trào ngư ợc dạ dày thực 
quản. Ở một số bệnh nhân trào ngư ợc nhi ều đến mức phải phẫu thu ật nối tắt sau đó. 
Những bệnh nhân có thoát v ị hoành ho ặc có ti ền sử trào ngư ợc dạ dày th ực quản không 
nên ch ỉ định ph ẫu thu ật này.  
c. Phẫu thu ật nối tắt dạ dày 
Năm 1966 Mason phát tri ển kỹ thuật nối tắt dạ dày. Ph ẫu thu ật của Mason đư ợc thực 
hiện bằng cách c ắt đôi d ạ dày theo chi ều ngang, ru ột non đư ợc đưa lên n ối với phần trên 
của dạ dày. 
 
Hình  6.3. Phẫu thu ật nối tắt dạ dày 
syt_sonla_vt_So Y te Son La_22/10/2022 22:04:0319 
Phẫu thu ật nối tắt dạ dày có nh ững bi ến chứng sau m ổ khi theo dõi trong th ời gian dài 
như thi ếu hụt vitamin và các vi ch ất, loét mi ệng nối hay thoát v ị nội. Tăng cân tr ở lại 
cũng có th ể xuất hiện do giãn d ạ dày và ru ột non.  
d. Phẫu thu ật phân lưu m ật tụy 
Năm 1976, t ại Genoa Scopinaro đã phát tri ển kỹ thuật phân lưu m ật tụy (biliopancreatic 
diversion BPD). K ỹ thuật này bao g ồm cắt gần toàn b ộ dạ dày, phân lưu d ịch m ật và t ụy 
làm gi ảm hấp thu th ức ăn. Khác v ới phẫu thu ật nối tắt hỗng-hồi tràng, k ỹ thuật phân lưu 
mật tụy không có đ ầu ruột non t ận tự do. Ph ần ruột non đư ợc nối với hồi tràng cách góc 
hồi manh tràng 50 cm. Trong vài tháng đ ầu sau m ổ lượng th ức ăn c ủa bệnh nhân có th ể 
không thay đ ổi, nhưng cân n ặng vẫn giảm do gi ảm hấp thu ở ruột. 
 
Hình 6.4. Phẫu thu ật phân lưu m ật tụy 
Phẫu thuật phân lưu m ật tụy ưu th ế hơn so với các ph ẫu thu ật giảm béo khác, tuy nhiên 
phẫu thu ật này có như ợc điểm là có nhi ều biến chứng hơn , bệnh nhân d ễ bị thiếu hụt vi 
chất vitamin, rò, loét mi ệng nối và thoát v ị nội.  
e. Phẫu thu ật đảo dòng tá tràng  
Hess phát tri ển kỹ thuật đảo dòng tá tràng t ừ kỹ thuật phân lưu m ật tụy của Scopinaro. 
DeMeester phát tri ển kỹ thuật này đ ể điều trị luồng trào ngư ợc dịch m ật từ tá tràng lên 
thực quản. DeMeester nh ận thấy bảo tồn cơ th ắt môn v ị làm gi ảm biến chứng loét mi ệng 
nối tá tràng - ruột non. D ạ dày đư ợc tạo hình b ằng cách c ắt theo chi ều dọc, kỹ thuật này 
hiện nay đư ợc áp d ụng ph ổ biến trong ph ẫu thu ật tạo hình d ạ dày ống đ ứng (sleeve 
gastrectomy). Vi ệc tạo hình d ạ dày theo chi ều dọc cũng giúp gi ảm tỷ lệ loét mi ệng nối 
do làm gi ảm thể tích d ạ dày. 
syt_sonla_vt_So Y te Son La_22/10/2022 22:04:0320 
 
Hình 6.5. Phẫu thu ật đảo dòng tá tràng  
Phẫu thu ật đảo dòng tá tràng có hi ệu quả giảm cân cao tuy nhiên phương pháp này có 
nhiều biến chứng sau m ổ. Phẫu thu ật giảm béo d ựa trên gi ảm hấp thu th ức ăn nên sau m ổ 
bệnh nhân có nh ững rối loạn thiếu hụt vitamin và vi ch ất nặng cần bổ sung.  
f. Phẫu thu ật nối tắt dạ dày v ới 1 mi ệng nối (mini gastric bypass)  
Kỹ thuật này đư ợc thực hiện lần đầu tiên b ởi Rutledge vào năm 1998 t ại Mỹ. Với kỹ 
thuật này ph ẫu thu ật viên s ẽ tạo một ống dạ dày d ọc bờ cong nh ỏ và đưa ru ột non lên n ối 
với ống dạ dày này theo ki ểu omega, mi ệng nối dạ dày ru ột cách góc Treitz 200 cm tùy 
thuộc vào BMI c ủa bệnh nhân.  
 
Hình 6.6. Phẫu thu ật nối tắt dạ dày v ới 1 mi ệng nối (mini gastric bypass)  
Phẫu thu ật nối tắt dạ dày v ới một miệng nối là m ột phẫu thu ật hiệu quả tuy nhiên khi theo 
dõi lâu dài ph ẫu thu ật có các bi ến chứng như thi ếu hụt vitamin, vi ch ất, rò, loét mi ệng 
nối (1% đ ến 6%), thoát v ị nội. 
syt_sonla_vt_So Y te Son La_22/10/2022 22:04:0321 
g. Phẫu thu ật khâu g ấp nếp dạ dày:  
Phẫu thu ật khâu g ấp nếp dạ dày đư ợc thực hiện lần đầu tiên b ởi Talebpour t ại Iran vào 
năm 2002. Ph ần bờ cong l ớn dạ dày đư ợc khâu g ấp nếp lại dọc theo chi ều dài b ằng ch ỉ 
không tiêu. Vi ệc khâu t ạo nếp gấp có th ể bắt đầu từ phía tâm v ị hay phía môn v ị. 
 
Hình 6.7.  Phẫu thu ật khâu g ấp nếp dạ dày 
Phương pháp này có ưu đi ểm là không có miệng nối, không ph ải cắt bỏ dạ dày nên t ỷ lệ 
biến chứng viêm phúc m ạc hay rò d ạ dày r ất thấp hoặc gần như không có. Ngoài ra do 
không ph ải sử dụng dụng cụ khâu n ối tiêu hóa t ự động nên chi phí cho cu ộc mổ sẽ thấp 
hơn so v ới các phương pháp khác. Tuy nhiên  tỷ lệ tăng cân tr ở lại do d ạ dày giãn ra cũng 
gặp sau m ổ lên tới 31% sau 3 năm theo Talebpour và c ộng sự. 
Đối với hiệu quả cải thiện các b ệnh ph ối hợp như đái tháo đư ờng, tăng huyết áp hay r ối 
loạn mỡ máu thì hi ệu quả của phẫu thu ật này th ấp hơn so v ới các phương pháp ph ẫu thu ật 
khác.  
h. Phẫu thu ật tạo hình d ạ dày 
 
Hình  6.8. Phẫu thu ật tạo hình d ạ dày 
Phẫu thu ật tạo hình d ạ dày đư ợc Mason phát tri ển từ những năm 1980, ph ẫu thu ật này 
được thực hiện bởi một đai vòng quanh d ạ dày ở phần thấp với một cửa sổ được tạo ra 
syt_sonla_vt_So Y te Son La_22/10/2022 22:04:0322 
bởi dụng cụ cắt nối tự động ở phần thân v ị sát b ờ cong nh ỏ dạ dày. Phẫu thu ật này có 
hiệu quả tương t ự như ph ẫu thu ật đặt vòng th ắt dạ dày nhưng ph ức tạp hơn và có nhi ều 
biến chứng như nôn, trào ngư ợc, loét đai…  
i. Đặt bóng d ạ dày (intragastric ballon  - IRB)  
Đây là m ột phương pháp đi ều trị béo phì t ạm thời và xâm l ấn tối thiểu, ban đ ầu được phát 
triển sau khi quan sát th ấy sự hiện diện của khối choáng ch ỗ dẫn đến giảm cân thông qua 
tăng c ảm giác no. Đây là m ột phương pháp n ội soi, nó đư ợc định vị giữa điều trị thuốc 
và ph ẫu thu ật, hiện đang là li ệu pháp đi ều trị béo phì xâm l ấn tối thiểu đư ợc sử dụng 
nhiều nhất. Bóng trong d ạ dày ho ạt động như m ột thiết bị lấy đầy không gian trong lòng 
dạ dày, làm gi ảm dung tích d ạ dày và gây c ảm giác no. Có nhi ều thiết bị IRB khác nhau, 
có th ể chứa chất lỏng hay không khí, có th ể điều chỉnh th ể tích hay không, nhưng không 
có sự khác bi ệt đáng k ể về giảm cân gi ữa những thi ết bị này.  
 
Hình 6.9. K ỹ thuật đặt bóng d ạ dày 
Nhiều nghiên c ứu đã ch ỉ ra hiệu quả của đặt bóng d ạ dày trong vi ệc giảm cân ng ắn hạn, 
với những cải thiện đáng k ể về các b ệnh đồng m ắc liên quan đ ến béo phì. Đ ặt bóng d ạ 
dày có ch ỉ định rộng rãi, t ừ những người thừa cân (ch ỉ số khối cơ th ể BMI ≥ 27 kg/m²),  
đến những ngư ời béo phì không đáp ứng các tiêu chí cho phẫu thu ật giảm béo  và cho 
người siêu béo phì (BMI ≥ 50 kg/m²), như m ột tiền đề cho ph ẫu thu ật giảm béo. D ựa trên 
những dự liệu an toàn t ốt, đặt bóng d ạ dày cũng có th ể được sử dụng ở những bệnh nhân 
béo phì đ ủ điều kiện phẫu thu ật giảm béo nhưng có nguy cơ cao b ị các tác d ụng phụ của 
phẫu thu ật hoặc không mu ốn trải qua th ủ thuật.  
syt_sonla_vt_So Y te Son La_22/10/2022 22:04:0323 
j. Một số nhận xét v ề việc áp dụng các phương pháp ph ẫu thu ật điều trị béo phì  
Phẫu thu ật tạo hình d ạ dày ống đứng chi ếm tỷ lệ cao nh ất trong các phương pháp ph ẫu 
thuật giảm béo giai đo ạn 2015 -2018 tăng 30,8%, ti ếp theo là ph ẫu thu ật nối tắt dạ dày, 
phẫu thu ật đặt vòng th ắt dạ dày có t ỷ lệ giảm còn 1/3 so v ới các giai đo ạn trư ớc, ph ẫu 
thuật phân lưu m ật tụy tăng s ố lượng gấp đôi trong giai đo ạn 2015 -2018.  
Trong giai đo ạn 2005 đ ến 2009 t ại châu Á có 6 598 b ệnh nhân đư ợc phẫu thu ật giảm béo 
trong đó ph ẫu thu ật đặt vòng th ắt dạ dày chi ếm tỷ lệ cao nh ất 35,9%, ph ẫu thu ật nối tắt 
dạ dày ru ột chiếm tỷ lệ 24,3%, ph ẫu thu ật tạo hình d ạ dày ống đứng chi ếm tỷ lệ 19,5%, 
phẫu thu ật nối tắt dạ dày v ới một miệng nối chiếm tỷ lệ 15,4%.  
Tại Hàn Qu ốc vào năm 2013 có 1686 ca ph ẫu thu ật giảm béo đư ợc thực hiện trong đó 
phẫu thu ật đặt vòng th ắt dạ dày chi ếm tỷ lệ 67,2%, ph ẫu thu ật tạo hình d ạ dày hình ống 
đứng chi ếm tỷ lệ 14,2%, ph ẫu thu ật nối tắt dạ dày h ỗng tràng chi ếm tỷ lệ 12,8%, các 
phương pháp khác chi ếm tỷ lệ 3,3%. Vào năm 2016 t ỷ lệ này t ại Hàn Qu ốc thay đ ổi như 
sau: ph ẫu thu ật tạo hình d ạ dày ống đứng chi ếm tỷ lệ 43,6%, ph ẫu thu ật nối tắt dạ dày 
chiếm tỷ lệ 13,5%, ph ẫu thu ật đặt vòng th ắt dạ dày chi ếm kho ảng 40%.  
7. BÉO PHÌ Ở TRẺ EM VÀ THANH THIẾU NIÊN  
Béo phì ở trẻ em và thanh thi ếu niên đang gia tăng nhanh chóng do thay đ ổi chế độ ăn 
uống, môi trư ờng sống, gi ảm ho ạt động th ể lực. Đây là một bệnh mãn tính khó đi ều trị 
và dễ dàng phát tri ển thành béo phì ở người lớn, đòi h ỏi một chế độ ăn uống lành m ạnh 
và lối sống năng đ ộng trong su ốt cuộc đời. Do đó, nên thi ết lập chính sách nh ằm phát 
hiện và đi ều trị sớm. 
Để đánh giá tình tr ạng béo phì  ở trẻ em và thanh thi ếu niên, đi ều quan tr ọng là  đánh giá xu 
hướng béo phì theo t ốc độ tăng trư ởng và tình tr ạng phát tri ển thông qua vi ệc kiểm tra thư ờng 
xuyên.  Đối với trẻ em từ 2 tuổi trở lên và thanh thi ếu niên, BMI phân bi ệt theo tu ổi và gi ới 
tính và thư ờng đư ợc gọi là BMI theo tu ổi. Tuổi được tính b ằng tháng.  
Bảng 7.1. Phân lo ại tình tr ạng cân n ặng dựa trên BMI theo tu ổi  
và bách phân v ị tương ứng 
 
Phân lo ại Bách phân v ị 
Thiếu cân  < 5 
Bình thư ờng 5 - < 85 
Thừa cân  85 - < 95 
Béo phì  95 
Điều trị béo phì ở trẻ em và thanh thi ếu niên điều quan tr ọng là duy trì cân n ặng thích 
hợp dựa trên vi ệc thay đ ổi lối sống. Orlistat và Liraglutide 3,0 mg là thu ốc được Cục 
Quản lý Th ực phẩm và Dư ợc phẩm Hoa K ỳ (FDA) và Cơ quan dư ợc phẩm Châu Âu 
(EMA) p hê duy ệt để sử dụng cho nh ững ngư ời trên 12 tu ổi. 
8. KẾT LUẬN  
Béo p hì là m ột căn b ệnh làm tăng gánh n ặng về kinh t ế xã hội do tăng nguy cơ m ắc các 
bệnh đi kèm liên quan đ ến béo phì. Vi ệc quản lý đư ợc béo phì là đa y ếu tố, các phương 
pháp đi ều trị béo phì bao g ồm các can thi ệp toàn di ện về lối sống như li ệu pháp dinh 
dưỡng, hoạt động th ể chất, liệu pháp tâm lý và s ử dụng thu ốc.  
  syt_sonla_vt_So Y te Son La_22/10/2022 22:04:0324 
Phụ lục:  Thuốc điều trị bệnh béo phì  
 
 
Nội dung  Orlistat  Liraglutide  
Đường dùng  Uống Tiêm dư ới da 
Liều lượng, s ố lần 120 mg x 3 l ần/ngày  3,0mg/ngày  
Tác đ ộng giảm % cân n ặng 
tại thời điểm 1 năm,  trừ giả 
dược Giảm 2,9% Giảm 5,4% 
Tác đ ộng dài h ạn trên cân 
nặng, tr ừ giả dược  Giảm 2,8kg t ại thời điểm 
4 năm  Giảm 4,2% t ại thời điểm 
3 năm 
% bệnh nhân đ ạt giảm ≥ 5% 
cân n ặng tại thời điểm 1 năm  54% (so v ới 33% ở giả 
dược) 63,2% (so v ới 27,1% ở 
giả dược) 
% bệnh nhân đ ạt giảm ≥ 10% 
cân n ặng tại thời điểm 1 năm  26% (so v ới 14% ở giả 
dược) 33,1% (so v ới 10,6% ở 
giả dược) 
Hiệu quả duy trì gi ảm cân 
trước đó Tăng cân l ại ít hơn 2,4kg 
so với giả dược trong hơn 
3 năm  Giảm thêm  6% cân n ặng 
trừ giả dược lúc 1 năm 
Tác đ ộng trên ti ền đái tháo 
đường  Giảm 37,3% nguy cơ di ễn 
tiến đến đái tháo đư ờng 
típ 2 trong hơn 4 năm Giảm 79% nguy cơ di ễn 
tiến đến đái tháo đư ờng 
típ 2 trong hơn 3 năm  
Tác đ ộng trên huy ết áp t ại 
thời điểm 1 năm, tr ừ giả dược Giảm 1,9 mmHg HATT  
Giảm 1,5 mmHg HATTr  Giảm 2,8 mmHg HATT  
Giảm 0,9 mmHg HATTr  
Tác đ ộng trên lipid t ại thời 
điểm 1 năm, tr ừ giả dược Giảm 0,27 mmol/L 
Cholesterol toàn ph ần 
Giảm 0,21 mmol/L LDL  
Giảm 0,02 mmol/L HDL  
Giảm 0,00 mmol/L TG Giảm 2,3% Cholesterol 
toàn ph ần  
Giảm 2,4% LDL  
Tăng1,9% HDL  
Giảm 3,9% non -HDL  
Giảm 9,3% TG  
Tác đ ộng trên nh ịp tim t ại 
thời điểm 1 năm, tr ừ giả dược Không thay đ ổi Tăng 2,4 nh ịp/phút 
Tác đ ộng trên HbA1C ở bệnh 
nhân đái tháo đư ờng tại thời 
điểm 1 năm, tr ừ giả dược Giảm 0,4% Giảm 1,0% 
Tác đ ộng trên viêm gan 
nhiễm mỡ không do rư ợu  
(Nonalcoholic 
steatohepatitis - NASH)  Không c ải thiện Cải thiện 
Tác đ ộng trên bu ồng tr ứng đa 
nang  (Polycystic Ovary 
Syndrome – PCOS)  Chưa nghiên c ứu  Giảm 5,2kg cân n ặng trừ 
giả dược lúc 6 tháng; 
không có d ữ liệu trên chu 
kì kinh nguy ệt 
Tác đ ộng trên thoái hoá kh ớp 
(Osteoarthritis - OA) Chưa nghiên c ứu  Chưa nghiên c ứu  
Tác đ ộng trên ngưng th ở khi 
ngủ (Obstructive Sleep 
Apnea – OSA)  Chưa nghiên c ứu  Giảm Ch ỉ số ngưng th ở- 
giảm thở (Apnea -
Hypopnea Index -AHI) 
đến 6/giờ syt_sonla_vt_So Y te Son La_22/10/2022 22:04:0325 
Nội dung  Orlistat  Liraglutide  
Chống ch ỉ định  
 - Tắc mật 
- Hội chứng rối loạn 
hấp thu m ạn tính  
- Có thai  - Tiền sử viêm t ụy 
- Tiền sử bản thân hay 
gia đình m ắc ung thư 
tuyến giáp th ể tủy, 
- Tiền sử bản thân m ắc 
hội chứng MEN2  
- Có thai  
Tác d ụng ph ụ thường gặp Tiêu phân l ỏng, m ỡ, trung 
tiện nhiều Buồn nôn, táo bón, tiêu 
chảy, nôn  
Tác d ụng ph ụ hiếm gặp - Suy gan  
- Sỏi thận 
- Tổn thương th ận cấp Viêm t ụy do s ỏi đường 
mật 
Tương tác thu ốc - Vitamin tan trong m ỡ 
- Levothyroxine  
- Cyclosporine  
- Kháng đông u ống, 
chống co gi ật Có th ể ảnh hư ởng đến sự 
hấp thu thuốc do ch ậm 
làm tr ống dạ dày 
 
 
  syt_sonla_vt_So Y te Son La_22/10/2022 22:04:0326 
TÀI LIỆU THAM KHẢO  
Tiếng Vi ệt 
1. Bộ Y tế (2020), "Hư ớng dẫn chẩn đoán và đi ều trị đái tháo đư ờng típ 2”, Ban hành 
theo quy ết định số 5481/QĐ -BYT ngày 30 tháng 12 năm 2020  
2. Bộ Y tế (2021), K ết quả Tổng đi ều tra dinh dư ỡng toàn qu ốc 2017 – 2020, Bộ Y tế 
công b ố kết quả Tổng đi ểu tra Dinh dư ỡng năm 2019 -2020 - Tin n ổi bật - Cổng thông 
tin B ộ Y tế (moh.gov.vn)  
3. Hội Nội tiết- Đái tháo đư ờng Vi ệt Nam (2016), Ch ẩn đoán và đi ều trị một số bệnh 
nội tiết- chuy ển hóa, Nhà xu ất bản Y h ọc. 
Tiếng Anh  
4. Agrawal S. (2016). Obesity, Bariatric and M etabolic Surgery, Springer Cham 
Heidelberg New York Dordrecht London.  
5. American Diabetes Association.12 Older adults: Standards of medical care in 
diabetes - 2021, Diabetes Care 2021; 44 (Suppl.1):S168 -S179  
6. Barlow SE and the Expert Committee. Expert committe e recommendations regarding 
the prevention, assessment, and treatment of child and adolescent overweight and 
obesity: summary report.  Pediatrics  2007;120 Supplement December 2007:S164 —
S192.  
7. Bo-Yeon Kim , Seon Mee Kang , Jee-Hyun Kang  et al,  Committee of Clinical Practice 
Guidelines, Korean Society for the Study of Obesity (KSSO) . 2020 Korean Society 
for the Study of Obesity Guidelines for the Management of Obesity in Korea. J Obes 
Metab Syndr. 2021 Jun 30;30(2):81 -92. doi: 10.7570/jomes21022.  
8. Chanoine JP, Hampl S, Jensen C, Boldrin M, Hauptman J. Effect of orlistat on weight 
and body composition in obe se adolescents: a randomized controlled trial. JAMA 
2005;293: 2873 -83.  
9. Chiu CJ, Birch DW, Shi X, Karmali S. Outcomes of the adjustable gastric band in a 
publicly funded obesity program. Can J Surg. 2013 Aug;56(4):233 -6. doi: 
10.1503/cjs.002712. PMID: 2388 3492; PMCID: PMC3728241.  
10.  Cote AT, Harris KC, Panagiotopoulos C, et al. Childhood obesity and cardiovascular 
dysfunction.  J Am Coll Cardiol  2013; 62 (15):1309 –1319.  
11.  Gallagher, D. A Guide to Methods for Assessing Childhood Obesity. Washington 
(DC): Nationa l Collaborative on Childhood Obesity Research. June 2020.  
12. General Department of Preventive Medicine, Ministry of Health, 2016 National 
Survey on the risk factors of non communicable diseases (STEPS) Viet Nam 2015.  
13. Korea Disease Control and Prevention Agenc y. Growth charts for children and 
adolescents. Cheongju: Korea Disease Con trol and Prevention Agency; 2017.  
14.  Matson KL, Fallon RM. Treatment of obesity in children and adolescents. J Pediatr 
Pharmacol Ther 2012;17:45 -57. 
15. Marceau P, Biron S, Marceau S, Hou ld FS, Lebel S, Lescelleur O, Biertho L, Kral 
JG. Biliopancreatic diversion -duodenal switch: independent contributions of sleeve 
resection and duodenal exclusion. Obes Surg. 2014 Nov;24(11):1843 -9. doi: 
10.1007/s11695 -014-1284 -0. PMID: 24839191.  syt_sonla_vt_So Y te Son La_22/10/2022 22:04:0327 
16. Meneses E,  Zagales I, Fanfan D, Zagales R, McKenney M, Elkbuli A. Surgical, 
metabolic, and prognostic outcomes for Roux -en-Y gastric bypass versus sleeve 
gastrectomy: a systematic review. Surg Obes Relat Dis. 2021 Dec;17(12):2097 -2106. 
doi: 10.1016/j.soard.2021.06.0 20. Epub 2021 Jul 7. PMID: 34642101.  
17. Ohta M. et al (2019). Bariatric/Metabolic Surgery in the Asia -Pacific Region: 
APMBSS 2018 Survey. Obes Surg, 29(2), 534 -541. 
18. Rutledge R. and Walsh T.R. (2005). Continued excellent results with the mini -gastric 
bypass: s ix-year study in 2,410 patients. Obesity surgery, 15(9), 1304 -1308.  
19. Sarela A.I. et al (2012). Long -term follow -up after laparoscopic sleeve gastrectomy: 
8–9-year results. Surgery for Obesity and Related Diseases, 8(6), 679 -684 
20. Sean Wharton  et al. Obesity i n adults: a clinical practice guideline. CMAJ August 04, 
2020; 192 (31) E875 -E891. DOI:  7 
21. Scopinaro N. et al (1998). Biliopancreatic diversion. World j ournal of surgery, 22(9), 
936-946 
22. Tackling obesity in ASEAN - Prevalence, impact, and guidance on interventions, The 
Economist Intelligence Unit Limited 201 7 
23. WHO -WPR World Health Organization. Regional Office for the Western 
Pacific.  (2000) . The Asia-Pacific perspective : redefining obesity and its 
treatment.  Sydney : Health Communications Australia.  6 
24. World Health Organization. Report of a WHO Consultation on Obesity. June 1997. 
Available at: http://whqlibdoc.who.int/hq/1998/WHO_NUT_NCD_98.1_(p1 -
158).pdf  
 syt_sonla_vt_So Y te Son La_22/10/2022 22:04:03**
Sự khởi phát sớm hơn của bệnh tiểu đường loại 2, bệnh tim và mạch máu, trầm cảm liên quan đến tình trạng béo phì ở trẻ em, thanh thiếu niên và người lớn. Người béo phì càng lâu thì các yếu tố nguy cơ liên quan đến béo phì càng trở nên đáng kể. Các bệnh mãn tĩnh có liên quan đến béo phì khó điều trị. Chính vì thế, việc phòng ngừa là vô cùng quan trọng. Ngăn ngừa béo phì sẽ hạn chế nguy cơ:
  * Bệnh tiểu đường tuýp 2
  * Bệnh huyết áp cao
  * Bệnh tim mạch
  * Chứng ngưng thở lúc ngủ
  * Bệnh túi mật
  * Các vấn đề sức khỏe tình dục
  * Bệnh gan nhiễm mỡ không do rượu
  * Viêm xương khớp.


Tập trung ngăn ngừa nguy cơ béo phì và tập thói quen sống lành mạnh có thể làm chậm hoặc ngăn chặn sự phát triển của các bệnh trên. Để giúp người bệnh có thể thành công hơn trong ngăn chặn và cải thiện tình trạng béo phì, Bệnh viện Nguyễn Tri Phương đã thành lập phòng khám tư vấn và điều trị giảm cân
  * [Bệnh béo phì được định nghĩa như thế nào?](https://bvnguyentriphuong.com.vn/kien-thuc-cho-nguoi-benh/phong-kham-tu-van-va-dieu-tri-giam-can-tai-benh-vien-nguyen-tri-phuong#bnh-bo-ph-c-nh-ngha-nh-th-no)
  * [1 Đối với người lớn](https://bvnguyentriphuong.com.vn/kien-thuc-cho-nguoi-benh/phong-kham-tu-van-va-dieu-tri-giam-can-tai-benh-vien-nguyen-tri-phuong#1-i-vi-ngi-ln)
  * [2 Đối với trẻ em](https://bvnguyentriphuong.com.vn/kien-thuc-cho-nguoi-benh/phong-kham-tu-van-va-dieu-tri-giam-can-tai-benh-vien-nguyen-tri-phuong#2-i-vi-tr-em)
  * [Thừa cân và bệnh béo phì gây ra những hậu quả gì?](https://bvnguyentriphuong.com.vn/kien-thuc-cho-nguoi-benh/phong-kham-tu-van-va-dieu-tri-giam-can-tai-benh-vien-nguyen-tri-phuong#tha-cn-v-bnh-bo-ph-gy-ra-nhng-hu-qu-g)



## Những loại thức uống giải nhiệt ngày nắng nóng

  * [Chanh sả hạt chia](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/nhung-loai-thuc-uong-giai-nhiet-ngay-nang-nong#chanh-s-ht-chia)


## **Trà bí đao**
Cho tất cả nguyên liệu (trừ đường và lá nếp ra) vào nồi cùng 3 lít nước, đun lửa vừa trong vòng 1 giờ. Khi nấu xong, cho lá nếp vào đun tiếp 5 phút. Sau đó, mình thêm đường phèn, chờ nguội, cho vào chai cất trong tủ mát dùng dần.
Trong thời tiết nắng nóng, làm một ly trà bí đao thanh mát, ngọt dịu, mình như được thanh lọc cơ thể, sảng khoái tuyệt vời. Có thể nói, đây được xem là thức uống rất được nhiều người ưa chuộng bởi vì nhờ vào khả năng giải nhiệt rất tốt, giúp cơ thể giảm tình trạng nóng
## **Chanh sả hạt chia**
Bước đầu: nấu 1 lít nước với 150 gram sả tươi đã rửa sạch, sau đó để nguội rồi pha chế cùng 100 ml siro đường (tuỳ khẩu vị uống ngọt mà mọi người điều chỉnh), cùng với 30 ml nước cốt chanh, thêm vài nhánh sả, lá bạc hà, 4-5 muỗng hạt chia (đã được ngâm nước), 4 lát chanh... và cuối cùng là đá viên
## **Trà đào cam sả**
Dùng 150 gram sả tươi nấu trong 1 lít nước. Để trà đào cam sả thơm ngon hơn, có thể dùng thêm hỗn hợp với 2 túi trà lọc hương đào (ngâm trong 100 ml nước sôi khoảng 5 phút rồi vắt bỏ túi lọc) sau đó cho vào 1 bình lớn cùng siro đào, 100 ml nước sả, 100 ml nước trà đào (túi lọc), 100 ml nước cam tươi, 60 ml siro đường, vài nhánh sả, lát cam, đá viên, khuấy đều rồi rót ra ly thưởng thức
**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/) **- Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [Chanh sả hạt chia](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/nhung-loai-thuc-uong-giai-nhiet-ngay-nang-nong#chanh-s-ht-chia)



## Danh sách cơ sở khám bệnh, chữa bệnh công bố khám sức khỏe lái xe đã thực hiện liên thông dữ liệu giấy khám sức khỏe lái xe phục vụ Đề án 06 (cập nhật đến ngày 19/3/2023)

Nhằm thực hiện chỉ đạo của Thủ tướng Chính phủ về việc liên thông dữ liệu giấy khám sức khỏe lái xe phục vụ Đề án ‘‘Phát triển ứng dụng dữ liệu dân cư, định danh và xác thực điện tử phục vụ chuyển đổi số quốc gia giai đoạn 2022 -2025, tầm nhìn đến năm 2030’’ (gọi tắt là Đề án 06) để phục vụ dịch vụ công trực tuyến cấp đổi, cấp lại giấy phép lái xe của ngành giao thông vận tải, theo hướng dẫn của Bộ Y tế, kể từ ngày 01/01/2023 tất cả cơ sở khám bệnh, chữa bệnh công bố đủ điều kiện khám sức khỏe lái xe phải triển khai liên thông dữ liệu khám sức khỏe lái xe đối với các trường hợp giấy khám sức khỏe lái xe có kết luận ‘‘Đủ điều kiện sức khỏe lái xe hạng… ’’ .
Tính đến ngày 19/03/2023, theo nguồn tin tổng hợp từ [Sở Y tế Thành phố Hồ Chí Minh](https://nghiepvuy.medinet.gov.vn/quan-ly-chat-luong/tphcm-danh-sach-co-so-kham-benh-chua-benh-cong-bo-kham-suc-khoe-lai-xe-da-thuc-c4837-67341.aspx), hiện đã có có 39 cơ sở khám bệnh, chữa bệnh trên địa bàn Thành phố đã được công bố khám sức khỏe lái xe có thực hiện liên thông dữ liệu giấy khám sức khỏe lái xe phục vụ Đề án 06.
Danh sách các đơn vị công bố khám sức khỏe lái xe đã thực hiện liên thông dữ liệu giấy khám sức khỏe lái xe phục vụ Đề án 06.

## Một số phơi nhiễm phổ biến nhất với hóa chất và chất độc công nghiệp

  * [MICROPLASTICS - VI NHỰA](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/mot-so-phoi-nhiem-pho-bien-nhat-voi-hoa-chat-va-chat-doc-cong-nghiep#microplastics-vi-nha)
  * [BISPHENOL A (BPA)](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/mot-so-phoi-nhiem-pho-bien-nhat-voi-hoa-chat-va-chat-doc-cong-nghiep#bisphenol-a-bpa)
  * [DIOXINS AND POLYCHLORINATED BIPHENYLS (PCBS)](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/mot-so-phoi-nhiem-pho-bien-nhat-voi-hoa-chat-va-chat-doc-cong-nghiep#dioxins-and-polychlorinated-biphenyls-pcbs)
  * [PER- AND POLYFLUOROALKYL SUBSTANCES (PFAS)](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/mot-so-phoi-nhiem-pho-bien-nhat-voi-hoa-chat-va-chat-doc-cong-nghiep#per-and-polyfluoroalkyl-substances-pfas)


###### **MICROPLASTICS - VI NHỰA**
"Microplastic" là một thuật ngữ được sử dụng để mô tả các mảnh nhỏ hoặc hạt nhựa bị phân hủy hoặc hạt vi nhựa từ các sản phẩm chăm sóc cá nhân hoặc gia đình, có chiều dài dưới 5 mm.
Chất thải nhựa đang tích tụ ở mức đáng báo động và có sức tàn phá khủng khiếp — đến năm 2050, ước tính tính theo trọng lượng, sẽ có nhiều nhựa hơn cá trong các đại dương. Điều đó sẽ dẫn đến hàng trăm nghìn tấn vi nhựa và hàng nghìn tỷ hạt này trong biển. Một nghiên cứu gần đây đã chứng minh rằng vi nhựa có trong máu ở phần lớn 22 người tham gia khỏe mạnh.
Kể từ những năm 1950, việc tiếp xúc với nhựa đã được chứng minh là thúc đẩy quá trình hình thành khối u trong các nghiên cứu trên động vật và các nghiên cứu trong ống nghiệm đã chứng minh độc tính của vi nhựa ở cấp độ tế bào. Tuy nhiên, người ta vẫn chưa biết rõ liệu bản thân nhựa có độc hại hay nó chỉ đơn giản đóng vai trò là chất mang cho các chất độc môi trường khác tích lũy sinh học.
Theo Tasha Stoiber, một nhà khoa học cấp cao của Nhóm Công tác Môi trường (EWG), "Vi nhựa đã được phát hiện rộng rãi trong cá và hải sản, cũng như các sản phẩm khác như nước đóng chai, bia, mật ong và nước máy." EWG cho biết hiện tại không có lời khuyên chính thức nào về việc tiêu thụ cá để tránh tiếp xúc với vi nhựa.
Áp lực cũng đang gia tăng đối với lệnh cấm microbead trong các sản phẩm chăm sóc cá nhân.
Cho đến khi những lệnh cấm như vậy được đưa ra, bạn nên tránh đồ nhựa sử dụng một lần, ưu tiên sử dụng túi tote có thể tái sử dụng.
###### **PHTHALATES**
Phthalates là hóa chất được sử dụng để làm cho nhựa mềm và bền, cũng như để tạo hương thơm. Chúng thường được tìm thấy trong các đồ gia dụng như nhựa vinyl (ví dụ: sàn nhà, rèm tắm) và nước hoa, chất làm mát không khí và nước hoa.
Phthalates được biết đến là hóa chất gây rối loạn nội tiết tố, việc tiếp xúc với chất này có liên quan đến sự phát triển não bộ và tình dục bất thường ở trẻ em, cũng như làm giảm mức testosterone ở nam giới. Phơi nhiễm được cho là xảy ra khi hít phải, nuốt phải và tiếp xúc với da; tuy nhiên, các nghiên cứu về việc nhịn ăn chứng minh rằng phần lớn phơi nhiễm có thể liên quan đến thực phẩm.
Để tránh tiếp xúc với phthalate, các khuyến nghị bao gồm tránh sử dụng nhựa polyvinyl clorua (đặc biệt là hộp đựng thức ăn, bọc nhựa và đồ chơi trẻ em), có thể nhận dạng bằng mã tái chế số 3, cũng như các sản phẩm làm mát không khí và các sản phẩm có mùi thơm.
Cơ sở dữ liệu Skin Deep của EWG cung cấp một nguồn tài nguyên quan trọng về các sản phẩm chăm sóc cá nhân không chứa phthalate.
Bất chấp áp lực từ các nhóm vận động người tiêu dùng, Cục Quản lý Thực phẩm và Dược phẩm Hoa Kỳ vẫn chưa cấm phthalates trong bao bì thực phẩm.
###### **BISPHENOL A (BPA)**
**_BPA LÀ MỘT CHẤT PHỤ GIA HÓA HỌC ĐƯỢC SỬ DỤNG ĐỂ SẢN XUẤT NHỰA POLYCARBONATE CỨNG VÀ TRONG, CŨNG NHƯ EPOXY VÀ GIẤY IN NHIỆT. BPA LÀ MỘT TRONG NHỮNG HÓA CHẤT CÓ KHỐI LƯỢNG LỚN NHẤT, VỚI KHOẢNG 6 TỶ POUND ĐƯỢC SẢN XUẤT MỖI NĂM. BPA THƯỜNG ĐƯỢC TÌM THẤY TRONG NHIỀU CHAI NHỰA TRONG SUỐT VÀ CỐC SIPPY, CŨNG NHƯ TRONG LỚP LÓT CỦA THỰC PHẨM ĐÓNG HỘP._**
**_VỀ MẶT CẤU TRÚC, BPA HOẠT ĐỘNG NHƯ MỘT CHẤT TƯƠNG TỰ ESTROGEN VÀ CÓ LIÊN QUAN ĐẾN BỆNH TIM MẠCH, BÉO PHÌ VÀ RỐI LOẠN CHỨC NĂNG TÌNH DỤC NAM GIỚI. KỂ TỪ NĂM 2012, BPA ĐÃ BỊ CẤM TRONG CỐC SIPPY VÀ BÌNH SỮA TRẺ EM, NHƯNG CÓ MỘT SỐ TRANH LUẬN VỀ VIỆC LIỆU CÁC CHẤT THAY THẾ (BISPHENOL S VÀ BISPHENOL F) CÓ AN TOÀN HƠN HAY KHÔNG; CHÚNG DƯỜNG NHƯ CÓ TÁC DỤNG NỘI TIẾT TỐ TƯƠNG TỰ NHƯ BPA._**
Cũng như với phthalates, phần lớn lượng tiêu hóa được cho là có liên quan đến thực phẩm. BPA đã được tìm thấy trong hơn 90% dân số nghiên cứu đại diện ở Hoa Kỳ.
Hướng dẫn khuyên bạn nên tránh sử dụng nhựa polycarbonate (có thể nhận dạng bằng mã tái chế số 7), cũng như tránh xử lý các loại giấy in nhiệt như vé và biên lai, nếu có thể. Thực phẩm và đồ uống nên được đựng trong thủy tinh hoặc thép không gỉ. Nếu phải sử dụng nhựa, hãy chọn loại nhựa không chứa polycarbonate và polyvinyl clorua, đồng thời không bao giờ được hâm nóng thức ăn và đồ uống trong hộp hoặc bao bì bằng nhựa. Nên tránh thực phẩm đóng hộp, đặc biệt là cá ngừ đóng hộp và súp đặc. Nếu mua các sản phẩm đóng hộp, lý tưởng nhất là chúng không chứa BPA.
###### **DIOXINS AND POLYCHLORINATED BIPHENYLS (PCBS)**
Dioxin chủ yếu là sản phẩm phụ của các hoạt động công nghiệp; chúng được giải phóng sau khi đốt, đốt rác và hỏa hoạn. PCB, có cấu trúc hơi liên quan đến dioxin, trước đây được tìm thấy trong các sản phẩm như chất chống cháy và chất làm mát. Dioxin và PCB thường được nhóm vào cùng một loại dưới thuật ngữ chung là "các chất ô nhiễm hữu cơ khó phân hủy" vì chúng phân hủy chậm và tồn tại trong môi trường ngay cả sau khi lượng khí thải đã được hạn chế.
Tetrachlorodibenzodioxin, có lẽ là loại dioxin nổi tiếng nhất, là một chất gây ung thư đã biết. Dioxin cũng có liên quan đến một loạt các hệ lụy sức khỏe trong quá trình phát triển, miễn dịch, hệ thống sinh sản và nội tiết. Mức độ phơi nhiễm PCB cao hơn cũng có liên quan đến việc tăng nguy cơ tử vong do bệnh tim mạch.
Đáng chú ý, lượng phát thải dioxin đã giảm 90% kể từ những năm 1980 và Cơ quan Bảo vệ Môi trường Hoa Kỳ (EPA) đã cấm sử dụng PCB trong sản xuất công nghiệp từ năm 1979. Tuy nhiên, dioxin và PCB trong môi trường vẫn xâm nhập vào chuỗi thức ăn và tích tụ trong chất béo.
Cách tốt nhất để tránh phơi nhiễm là hạn chế tiêu thụ thịt, cá và sữa, đồng thời cắt bỏ da và mỡ từ thịt. Mức độ dioxin và PCB được tìm thấy trong thịt, trứng, cá và sữa cao hơn khoảng 5-10 lần so với thực phẩm có nguồn gốc thực vật. Nghiên cứu đã chỉ ra rằng cá hồi nuôi có khả năng là nguồn protein bị nhiễm PCB nhiều nhất trong chế độ ăn uống của Hoa Kỳ; tuy nhiên, các hình thức nuôi trồng thủy sản bền vững và trên đất liền mới hơn có thể tránh được sự phơi nhiễm này.
**Pesticides**
Sự phát triển của nền nông nghiệp độc canh hiện đại ở Hoa Kỳ trong thế kỷ qua đã trùng hợp với sự gia tăng đáng kể trong việc sử dụng thuốc trừ sâu công nghiệp. Trên thực tế, hơn 90% dân số Hoa Kỳ có thuốc trừ sâu trong nước tiểu và máu, bất kể họ sống ở đâu. Phơi nhiễm được cho là có liên quan đến thực phẩm.
Khoảng 1 tỷ pound thuốc trừ sâu được sử dụng hàng năm ở Hoa Kỳ, bao gồm gần 300 triệu pound glyphosate, đã được các cơ quan Châu Âu xác định là chất có thể gây ung thư. EPA vẫn chưa đưa ra kết luận này, mặc dù vấn đề hiện đang được khởi kiện.
Một thử nghiệm đoàn hệ tiến cứu lớn ở châu Âu đã chứng minh nguy cơ ung thư thấp hơn ở những người có tần suất tiêu thụ thực phẩm hữu cơ cao. Ngoài nguy cơ ung thư, nồng độ thuốc trừ sâu trong máu tương đối cao được gọi là beta-hexachlorocyclohexane (B-HCH) có liên quan đến tỷ lệ tử vong do mọi nguyên nhân cao hơn. Ngoài ra, việc tiếp xúc với DDE - một chất chuyển hóa của DDT, một loại thuốc trừ sâu clo được sử dụng nhiều trong những năm 1940-1960 vẫn tồn tại trong môi trường ngày nay - đã được chứng minh là làm tăng nguy cơ mắc chứng mất trí nhớ kiểu Alzheimer cũng như suy giảm nhận thức tổng thể.
Bởi vì những loại thuốc trừ sâu clo hóa này thường hòa tan trong chất béo, chúng dường như tích tụ trong các sản phẩm động vật. Do đó, những người ăn chay được phát hiện có mức B-HCH thấp hơn. Điều này đã dẫn đến khuyến nghị rằng người tiêu dùng sản phẩm nên ưu tiên sản phẩm hữu cơ hơn thông thường, nếu có thể. Ở đây cũng vậy, EWG cung cấp một nguồn tài nguyên quan trọng cho người tiêu dùng về thuốc trừ sâu trong sản phẩm.
###### **PER- AND POLYFLUOROALKYL SUBSTANCES (PFAS)**
PFAS là một nhóm các hợp chất flo hóa được phát hiện vào những năm 1930. Thành phần hóa học của chúng bao gồm liên kết carbon-florua bền vững, giúp chúng tồn tại bền vững trong môi trường dẫn đến việc chúng được gọi là "hóa chất vĩnh viễn".
PFAS đã được phát hiện trong máu của 98% người Mỹ và trong nước mưa ở những địa điểm xa xôi như Tây Tạng và Nam Cực. Ngay cả mức độ phơi nhiễm thấp cũng có liên quan đến việc tăng nguy cơ ung thư, bệnh gan, nhẹ cân và rối loạn nội tiết tố.
Các đặc tính của PFAS cũng làm cho chúng bền ở nhiệt độ rất cao và không thấm nước. Đáng chú ý, hóa chất này đã được 3M sử dụng để sản xuất Scotchgard cho thảm và vải và Dupont đã sử dụng để sản xuất Teflon cho lớp chống dính của nồi và chảo. Mặc dù axit perfluorooctanoic (PFOA) đã bị loại bỏ khỏi dụng cụ nấu chống dính vào năm 2013, nhưng PFAS - một họ gồm hàng nghìn hợp chất tổng hợp - vẫn phổ biến trong bao bì thức ăn nhanh, quần áo chống thấm nước và vết bẩn, bọt chữa cháy và các sản phẩm chăm sóc cá nhân. PFAS được thải ra môi trường trong quá trình phân hủy các sản phẩm tiêu dùng và công nghiệp này, cũng như từ quá trình đổ thải từ các cơ sở xử lý chất thải.
Đáng báo động, EWG lưu ý rằng có tới 200 triệu người Mỹ có thể tiếp xúc với PFAS trong nước uống của họ. Vào tháng 3 năm 2021, EPA thông báo rằng họ sẽ điều chỉnh PFAS trong nước uống; tuy nhiên, các quy định vẫn chưa được hoàn thiện. Hiện tại, tùy thuộc vào từng tiểu bang để kiểm tra sự hiện diện của nó trong nước. EWG đã biên soạn một bản đồ về tất cả các địa điểm ô nhiễm PFAS đã biết.
Để tránh hoặc ngăn ngừa phơi nhiễm từ PFAS, các khuyến nghị bao gồm lọc nước máy bằng bộ lọc thẩm thấu ngược hoặc than hoạt tính, cũng như tránh thức ăn nhanh và thức ăn mang đi, nếu có thể, và các sản phẩm tiêu dùng được dán nhãn là "chống nước", "chống vết bẩn". kháng" và "không dính."
Để chứng minh mức độ nguy hại của các hóa chất này, EPA gần đây đã sửa đổi các lời khuyên sức khỏe suốt đời của họ đối với PFAS, chẳng hạn như PFOA, thành 0,004 phần nghìn tỷ, nhỏ hơn 10.000 lần so với giới hạn trước đó là 70 phần nghìn tỷ. EPA cũng đã đề xuất chính thức chỉ định một số hóa chất PFAS là "chất nguy hiểm".
  * [MICROPLASTICS - VI NHỰA](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/mot-so-phoi-nhiem-pho-bien-nhat-voi-hoa-chat-va-chat-doc-cong-nghiep#microplastics-vi-nha)
  * [BISPHENOL A (BPA)](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/mot-so-phoi-nhiem-pho-bien-nhat-voi-hoa-chat-va-chat-doc-cong-nghiep#bisphenol-a-bpa)
  * [DIOXINS AND POLYCHLORINATED BIPHENYLS (PCBS)](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/mot-so-phoi-nhiem-pho-bien-nhat-voi-hoa-chat-va-chat-doc-cong-nghiep#dioxins-and-polychlorinated-biphenyls-pcbs)
  * [PER- AND POLYFLUOROALKYL SUBSTANCES (PFAS)](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/mot-so-phoi-nhiem-pho-bien-nhat-voi-hoa-chat-va-chat-doc-cong-nghiep#per-and-polyfluoroalkyl-substances-pfas)



## Muối hồng là gì? Tác dụng của muối hồng

  * [Muối hồng là gì?](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/muoi-hong-la-gi-tac-dung-cua-muoi-hong#mui-hng-l-g)
  * [Muối hồng có gì khác?](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/muoi-hong-la-gi-tac-dung-cua-muoi-hong#mui-hng-c-g-khc)
  * [Muối hồng có tác dụng gì?](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/muoi-hong-la-gi-tac-dung-cua-muoi-hong#mui-hng-c-tc-dng-g)


## **Muối hồng là gì?**
Muối hồng Himalaya được chiết xuất từ mỏ muối Khewra tại Pakistan, một trong những mỏ muối lâu đời nhất thế giới. Tương tự như muối ăn, muối hồng chứa chủ yếu là natri clorua. Song, quá trình sản xuất tự nhiên giúp cho muối hồng Himalaya chứa nhiều khoáng chất và nguyên tố vi lượng hơn.
Tác dụng của muối hồng cũng như màu sắc của loại muối này là nhờ vào 84 loại khoáng chất và nguyên tố vi lượng, chẳng hạn như: kali, canxi, magiê, sắt, kẽm… Tuy vậy, màu hồng đậm nhạt đặc trưng của muối Himalaya chủ yếu phụ thuộc nhiều vào hàm lượng chất sắt.
## **Muối hồng có gì khác?**
  * **Nguồn gốc:** Muối hồng Himalaya được chiết xuất từ mỏ muối Khewra ở Pakistan. Muối trắng thường được chiết xuất từ biển hoặc mỏ muối ở khắp nơi trên thế giới.
  * **Độ tinh khiết:** Muối hồng là loại muối chưa tinh chế và không có chứa chất phụ gia, chất tẩy trắng hay chất bảo quản. Muối trắng thường được tinh chế và loại bỏ các tạp chất.
  * **Độ mặn:** Muối hồng Himalaya có vị mặn nhẹ nhàng hơn muối trắng thông thường. Ngoài ra, muối hồng có thể có hương vị khác biệt do có chứa nhiều khoáng chất.
  * **Hàm lượng khoáng chất:** Muối hồng Himalaya có nồng độ khoáng chất và nguyên tố vi lượng cao hơn so với muối trắng thông thường.
  * **Giá cả:** Với quá trình sản xuất và thu hoạch khó khăn, muối hồng thường có giá cao hơn muối trắng thông thường.


### **Muối hồng có tác dụng gì?**
Những tác dụng của muối hồng được công nhận bao gồm:
  * Giúp co bóp và thư giãn cơ bắp
  * Duy trì cân bằng khoáng chất và nước trong cơ thể
  * Ngăn ngừa mất nước
  * Gửi xung động hệ thần kinh
  * Ngăn ngừa huyết áp thấp


  * [Muối hồng là gì?](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/muoi-hong-la-gi-tac-dung-cua-muoi-hong#mui-hng-l-g)
  * [Muối hồng có gì khác?](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/muoi-hong-la-gi-tac-dung-cua-muoi-hong#mui-hng-c-g-khc)
  * [Muối hồng có tác dụng gì?](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/muoi-hong-la-gi-tac-dung-cua-muoi-hong#mui-hng-c-tc-dng-g)



## Cảnh báo về dịch cúm A H5N1


## Xương sống (Cột sống)

**I . HÌNH THÁI SINH LÝ :**
1. Cột sống gồm 33 – 34 đốt sống hợp thành, chia ra
- 7 đốt sống cổ C1 – C7 ( C: Cervicalis )
- 12 đốt sống lưng D1 – D12 ( D : Dozsalis )
- 5 đốt sống thắt lưng L1 – L5 ( L :Lombalis )
- 5 đốt sống hông S1 – S5 ( S : Sacrilis )
- 4 (hoặc 5) đốt sống cụt Coccyx (Coccyx )
Các đốt xương hông (S) và các đốt xương cụt (Coccyx ) dung hợp lại thành một liên tảng nhỏ. Giữa các đốt sống từ C2 đến S1 đều có đĩa đệm.
2.Cấu tạo chung cũa một đốt xương sống :
Thân đốt sống : hình trụ , có mặt trên và mặt dưới , hơi lõm ở giữa và có vành xương đặc ở xung quanh. Đốt sống có hai mảnh cung và hai cuống cung , cùng với thân đốt tạo thành lỗ đốt sống. Hai bờ trên và dưới của mỗi cuống có khuyết sống trên và khuyết sống dưới. Khi hai đốt sống khớp nhau thì các khuyết đó tạo thành lỗ gian để các dây thần kinh gai sống chui ra .
Các mỏm đốt sống :
* Mỏm gai từ giữa mặt sau của cột sống chạy ra sau và xuống dưới .
* Mỏm ngang nối giữa cuống và nhánh đi ngang qua phía ngoài .
* Mỏm khớp: hai mỏm khớp trên và hai mỏm khớp dưới có 1 diện khớp nối đốt sống liền nhau .
* Lỗ đốt sống: được giới hạn phía trước bởi thân đốt sống, ở hai bên và phía sau bởi cung đốt sống, khi các đốt khép lại thành cột sống thì các lỗ sống tạo thành ống sống .
**II. ĐẶC ĐIỂM CỦA TỪNG ĐỐT SỐNG :**
**1. Các đốt sống cổ:** Thân dẹp, bề ngang phía trước dày hơn phía sau, đỉnh của mỏm gai tách thành hai củ, mỏm gai ngang dính vào thân, vào cuống, có một lổ ngang để mạch đốt sống chui qua, mạch trên của mỏm ngang có rãnh thần kinh gai sống .
- Lỗ đốt sống hình tam giác và rộng hơn các lỗ đốt sống khác, để chữa đoạn phình cổ của tuỷ gai và thích ứng với tiến độ di động lớn của đoạn sống cổ .
- Đầu gai và thân đốt ngang nhau .
Đặc điểm riêng :
- C1 là đốt đội (Atlat ), sờ khó thấy, là đốt nâng đỡ hộp sọ, có hình tròn dẹp, thân đốt không rõ và lỗ đốt rất rộng, đảm bảo cho hộp sọ có thể quay chuyển được dễ dàng.
- C2 có hình khuyên tròn, phía trên và trước khuyên nầy lồi lên một mõm gọi là mõm xương khế là mỏm răng của đốt trục (Axis): dày, khoẻ nhất, sờ thấy rõ.
Đốt trục C2 khớp với đốt trục C1 giúp cho hộp sọ chuyển động: quay phải, quay trái , cúi, ngữa dễ dàng.
- C3 đưa về phía trước .
- C4 đưa về phía trước sâu nhất.
- C5 chuyển ra sau .
- C6 là đốt lồi trên ( động mạch chủ )
- C7 là đốt lồi dưới,cao nhất và mỏm gai không chẻ đôi .
**2 . Các đốt sống lưng :**
Các đốt sống lưng do cần tiếp xúc với các đầu xương sườn nên mỗi đốt xương có thêm bốn diện khớp. Thân đốt khá dày. Mỏm gai dày và đuôi gai đốt trên thả sâu cuống ngang thân đốt dưới.
- D1 nằm dưới C7, khi quay đầu, đốt động là C7, đốt không động là D1 .
- D2 dưới D1.
- D3 nằm trên đường thẳng nối hai bờ trong, phía trên của hai xương bả vai.
Từ D1 trở xuống cột sống có xu thế cong về phía sau .
- D4 là điểm nhô cao lên ra phía sau.
- D4 đến D7, các đốt thẳng.
- D7 ngang đường nối hai góc dưới xương bả vai .
- Từ D8 trở xuống cột sống có hình cong lướt và D10 là điểm nhô lên. Khi cúi thì D10 nhô cao, khi oằn lưng thì D10 đưa ra phía trước nhất .
- Tiếp xuống D11 và D12 .
**3. Các đốt sống thắt lưng:**
Các đốt sống thắt lưng so với các đốt sống lưng thì to, khoẻ hơn nhiều để chịu toàn bộ sức nặng của cơ thể. Các mõm gai ngắn, rộng và ngang.Thân đốt sống to, không tiếp khớp với xương sườn nên các mõm ngang dài và nhọn. Lổ đốt hình tam giác .
- L1 dưới D12 .
- L2 nằm trên đường thẳng nối hai đầu xương sườn cụt ( nơi có eo lưng bắt đầu thắt lại ).
- L4 nằm trên đường thẳng nối hai bờ trên xương hông (xương mào chậu)
(Ở nam giới: L4 và L5 đưa về phía trước –lõm; Nữ giới: L4 và L5 thẳng, đều - bằng ) .
4. Các đốt sống hông:
- Từ S1 – S5 cột sống dung hợp thành một liên tảng lớn có xu hướng đưa về phía sau. Điểm cao nhất là S5 .
5. Xương cụt: Các xương cụt thành một liên tảng nhỏ đưa về phía trước.
**Chú ý: căn cứ vào mỏm gai đốt sống, để xác định sự bình thường hay không bình thường của đốt sống.**
**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/) **- Đa khoa Hạng I Thành phố Hồ Chí Minh

## 8 điều cần chú ý khi đi vệ sinh mà nhiều người thường xuyên mắc phải

**1. Đi vệ sinh hơn 10 phút**
Do đường ruột phải chịu nhiều áp lực trong quá trình đại tiện, nếu thời gian đại tiện quá dài và cứ như vậy trong thời gian dài dễ khiến niêm mạc ruột bị chảy xệ, từ đó gây nguy cơ táo bón, mắc bệnh trĩ và sa dạ con. Vì vậy, một lần đi vệ sinh nên trong vòng 10 phút.
**2. Nhịn tiểu quá lâu**
Nhịn tiểu quá lâu có thể dễ dàng kích thích quá mức dây thần kinh phế vị, làm trống bàng quang quá nhanh, dễ làm hạ huyết áp, làm chậm nhịp tim, khiến não thiếu lượng máu, dễ gây ngất khi đi tiểu. Lúc này nếu không được cấp cứu càng sớm càng dễ gây nguy hiểm đến tính mạng.
**3. Rặn đại tiện quá nhiều**
Đại tiện mà phải rặn quá nhiều sẽ làm tăng áp lực ổ bụng, huyết áp tăng cao đột ngột gây xuất huyết não, tăng tiêu thụ oxy của cơ tim. Tình trạng này dễ dẫn đến rối loạn nhịp tim, nhồi máu cơ tim và đau thắt ngực, thậm chí có thể dẫn đến đột tử.
**4. Đứng dậy quá nhanh**
Nếu người mắc bệnh tim mạch đã ngồi xổm lâu trong nhà vệ sinh, sau khi đại tiện xong lập tức đứng dậy dễ gây thiếu máu não thoáng qua sẽ dẫn đến các nguy cơ như hoa mắt, chóng mặt, té ngã. Đặc biệt là đối với những người trung niên và cao tuổi.
**5. Xả bồn cầu không có nắp**
Nếu không đậy nắp khi xả bồn cầu rất dễ khiến vi khuẩn nhân cơ hội xâm nhập vào không khí. Vì vậy nên đậy nắp xuống trước khi xả nước.
**6. Chơi điện thoại và đọc sách**
Hầu hết mọi người thích đọc sách hoặc chơi với điện thoại di động trong khi đi vệ sinh trong một thời gian dài. Nhưng ngồi xổm quá lâu dễ cản trở sự lưu thông của máu tĩnh mạch vùng chậu, làm giãn nở mạch máu và gây ra bệnh trĩ. Lâu ngày còn có thể gây táo bón, thậm chí gây ung thư đường ruột.
Ngoài ra, ngồi toilet lâu sẽ dẫn đến lượng máu lên não không đủ, nhất là khi vừa ngủ dậy, dễ dẫn đến chóng mặt, ngã, đặc biệt là người già, người yếu, người bệnh mãn tính càng dễ bị tai nạn.
**7. Lau vùng kín từ sau ra trước**
Đừng bỏ qua hành động nhỏ này, lau từ sau ra trước dễ gây viêm nhiễm đường tiết niệu cho nữ, nên cách lau đúng là lau từ trước ra sau.
**8. Ngồi xuống ngay sau khi đi tiểu**
Niệu đạo của nam giới tương đối dài, cơ thắt trong và ngoài của niệu đạo sau khi đi tiểu sẽ đóng lại, trong niệu đạo của tuyến tiền liệt sẽ hình thành một khoang kín. Nếu bạn ngồi xuống ngay lập tức, áp suất trong khoang kín sẽ tăng lên, dễ gây trào ngược nước tiểu còn sót lại, dễ gây viêm tuyến tiền liệt.

## Cấu trúc giải phẫu của phổi

Phổi là cơ quan chính của hệ hô hấp, là một cặp cơ quan xốp , chứa đầy không khí nằm ở 2 bên lồng ngực; có tính chất đàn hồi, xốp và mềm.
Phổi được bao bọc trong 1 thanh mạc gồm 2 lá được gọi là màng phổi. Mỗi người có 2 lá phổi và cấu tạo bởi các thùy. Lá phổi phải lớn hơn phổi trái. ở người trưởng thành phổi có thể chứa 4500 – 5000ml không khí
Hình thể ngoài
Phổi có dạng một nửa hình nón, được treo trong khoang màng phổi bởi cuống phổi và dây chằng phổi
• Có ba mặt – hai bờ - một đỉnh.
- Mặt ngoài: lồi, áp vào thành ngực -> Có ấn xương sườn. Có rãnh chếch ở 2 bên bắt đầu từ ngang mức gian sườn 3 ở phía sau chạy xuống đáy phổi, chia phổi ra thành các thuỳ phổi.
Mặt các thuỳ phổi áp vào nhau gọi là mặt gian thuỳ. Trên bề mặt phổi có các tiểu thuỳ phổi - đơn vị cơ sở của phổi.
Phổi phải có rãnh ngang nên phổi phải có ba thuỳ là thùy trên, thùy giữa và thùy dưới. Phổi trái chỉ có khe chếch, nên phổi trái chỉ có hai thuỳ là thùy trên và thùy dưới
- Mặt trong ( Mặt trung thất): hơi lõm , gồm 2 phần :
+ Phần cột sống
+ Phần trung thất
Đặc điểm
+ giới hạn nên trung thất giữa
+ Rốn phổi có hình là chiếc vợt bóng bàn . Đây là nơi các thành phần cuống phổi đi qua , bao gồm ĐM phổi, phế quản chính , hai TM phổi, ĐM và TM phế quản , hạch bạch huyết , các dây thần kinh, có dây chằng tam giác.
+ Mặt trong phổi (P) có rãnh tĩnh mạch đơn, còn phổi (T) có rãnh động mạch chủ
+ Phía trên rốn phổi có rãnh động mạch dưới đòn và rãnh thân tĩnh mạch cánh tay đầu.
ở phổi phải : có một chỗ lõm gọi là ấn tim
ở phổi trái : ấn tim rất sâu nên gọi là hố tim , có khuyết tim
- Mặt hoành : ở phía dưới và nằm sát lên vòm hoành , qua vòm hoành với các tạng của ổ bụng, điển hình là gan
- Bờ trước : ranh giới giữa mặt sườn và mặt trung thất chùm lên trên màng ngoài tim
- Bờ dưới: bao lấy mặt hoành. Gồm 2 đoạn
+ Đoạn cong : ngăn cách mặt sườn và mặt hoành
+ Đoạn thẳng : ngăn cách mặt trong và mặt hoành
- Đỉnh phổi : Nhổ lên khỏi xương sườn 1 khoảng 3 cm
Hình thể trong
- Bao gồm cây phế quản, động mạch phổi, tĩnh mạch phổi, động mạch và tĩnh mạch phế quản, bạch huyết của phổi và thần kinh của phổi.
- Phế quản
Phế quản chính ( chui vào lỗ rốn phổi ) -> phế quản thùy -> phế quản phân thùy -> phế quản hạ thùy-> Phế quản tiểu thùy ( tiểu thùy phổi là một đơn vị cơ sở của phổi)
Phế quản gồm một lớp sụn , một lớp cơ mỏng, trong cùng là lớp niêm mạc.
- Động mạch phổi
Thân ĐM phổi bắt đầu từ lỗ ĐM phổi tâm thất phải, chạy lên trên và ra sau đến bờ sau quai ĐM chủ thì chia thành ĐM phổi (T) và ĐM phổi (P).
ĐM phổi trái : chếch sang trái, bắt chéo mặt trước phế quản chính trái→ chui vào rốn phổi → đi ra ngoài rồi phía sau thân phế quản.
ĐM phổi phải: dài và lớn hơn ĐM phổi T. Đi ngang từ trái→ phải
ĐM và TM phế quản:
Đây là thành phần dinh dưỡng của phổi
Động mạch phế quản được tách ra từ ĐM chủ sau hoặc trước của phế quản chính
Máu động mạch phế quản này là máu giàu oxy, trái ngược với máu giàu CO2 trong động mạch phổi. Nó nuôi dưỡng các mô nâng đỡ của phổi bao gồm mô liên kết, vách và phế quản lớn và nhỏ. Sau máu phế quản và động mạch này đi qua mô nâng đỡ nó đổ vào tĩnh mạch phổi và đi vào tâm nhĩ trái, thay vì đưa vào tâm nhĩ phải. Do đó, lưu lượng chảy vào tâm nhĩ trái và công suất tâm thất trái lớn hơn khoảng 1-2% công suất tâm thất phải.
Tĩnh mạch phế quản đổ vào các tĩnh mạch đơn, một số ít nhanh nhỏ sẽ đổ vào tĩnh mạch phổi.
- Bạch huyết của phổi
Bao gồm nhiều bạch huyết chảy trong nhu mô phổi và đổ vào các hạch bạch huyết phổi ở chỗ chia đôi các phế quản
Các hạch bạch huyết đổ vào các hạch phế quản phổi nằm ở rốn phổi
Đổ vào hạch khí dưới và hạch khí trên
- Thần kinh của phổi
Được tạo bởi các sợi thần kinh giao cảm và các nhánh dây thần kinh lang thang.
Hệ thần kinh giao cảm: xuất phát từ đám rối phổi
Hệ phó giao cảm: các nhánh của dây thần kinh lang thang
Màng phổi
Cấu tạo gồm 2 lá: màng phổi tạng và màng phổi thành. Giữa 2 lá màng phổi là hai ổ màng phổi
1. Màng phổi tạng
Mỏng, trong suốt bao phủ toàn bộ bề mặt của phổi, ngoại trừ rốn phổi và dính chặt vào nhu mô phổi, lách cả vào các khe gian thùy
ở rốn phổi, màng phổi tạng quặt ra để liên tiếp với màng phổi thành.
2. Màng phổi thành
Phủ lên toàn bộ các thành của khoang chứa phổi. Bao gồm:
+ màng phổi sườn: áp sát vào mặt trong lồng ngực, ngăn cách với thành ngực bởi lớp mô liên kết mỏng gọi là mạc nội ngực
+ màng phổi trung thất
+ màng phổi hoành
+ đỉnh màng phổi : phần mạc nội ngực ở đây được gọi là màng trên màng phổi. Đỉnh màng phổi được các dây chằng treo đỉnh màng phổi cố định vào cột sống cổ, xương sườn, xương đòn.

## Một số thuốc hay dùng trong điều trị bệnh lý thần kinh

**1. Thuốc ngủ :**
Barbuturic, các dẫn xuất của Barbuturic, nhóm phenobacbital.
— Tác dụng: gây ngủ, chống co giật, tăng tác dụng của các thuốc giảm đau.
— Chỉ định:
+ Mất ngủ kéo dài.
+ Điều trị bệnh động kinh.
— Chống chỉ định: suy gan, thận, phụ nữ có thai.
— Ngộ độc: biểu hiện chóng mặt, mất thăng bằng, dị ứng, quen thuốc.
— Điều trị ngộ độc:
+ Rửa dạ dày bằng thuốc tím 1%.
+ Uống than hoạt có tác dụng hấp thu thuốc.
+ Truyền glucose đẳng trương, NaHCO3 (Natribicacbonat) 1,4%.
+ Các thuốc trợ tim.
— Liều dùng
+ Gacdenal (luminal, neonal, phenobacbital)
+ Dạng thuốc: Viên 0,01; 0,05; 0,1; 0,2. Ống 0,1; 0,2; 0,3.
+ Liều uống viên: 0,1 x 1 viên/ngày uống tối.
+ Liều tiêm ống: 0,1 x 1 ống/ngày tiêm bắp thịt, buổi tối trước khi ngủ.
+ Liều tối đa: 0,6g/24 giờ.
Ngoài ra còn tác dụng chống co giật trong điều trị động kinh.
+ Noctran: (hợp chất của dipotasium clorazepate 10mg, acepromagine 0,75mg và aceprometazine 7,5mg).
. Liều dùng: 1/2 – 1 viên/ngày, uống tối, trước khi ngủ.
. Không dùng cho trẻ em và bệnh nhân nhược cơ.
+ Stilnox: 10mg, gây ngủ nhanh
. Liều dùng: viên 10mg x 1 viên/ngày, uống tối, trước khi ngủ.
. Không dùng cho trẻ em và bệnh nhân nhược cơ.
+ Doriden (Thuỵ Sỹ): viên 0,25, gây ngủ, chống say tàu xe, an thần.
Liều dùng: viên 0,25 x 1 – 2 viên/ngày, uống tối trước khi ngủ, trước khi đi tầu, xe.
+ Noxyron (Hungary): viên 0,25, ống 25mg gây ngủ, an thần, thức dậy không có cảm giác mệt.
. Liều dùng: viên 0,25 x 1 – 2 viên/ngày, uống tối trước khi ngủ; ống 25mg x 1 ống tiêm bắp thịt, buổi tối.
**2. Thuốc trấn tĩnh an thần**
— Tác dụng: trấn tĩnh thần kinh, gây ngủ nhẹ, tăng tác dụng của các thuốc giảm đau.
— Thuốc:
+ Rotunda: được chiết xuất từ củ bình vôi.
. Tác dụng: an thần, gây ngủ.
. Liều dùng: viên 30mg x 2 – 4 viên/24 giờ, chia làm 2 lần.
+ Aminazin:
. Tác dụng : an thần mạnh.
. Liều dùng: viên 0,025 x 1 – 2 viên/ 1 lần x 1 – 2 lần/ngày; ống 0,025 x 1 – 2 ống/1 lần x 1 – 2 lần/ngày (tiêm bắp thịt sâu).
. Tác dụng phụ: mạch nhanh, tụt huyết áp ở tư thế đứng; dùng liều cao, kéo dài có thể tổn thương gan, thận.
+ Lexomil 6mg:
. Tác dụng: an tĩnh, chống lo âu.
. Liều dùng: viên 6mg x 1/2 – 1 viên/ngày, uống tối.
. Chống chỉ định: không dùng cho bệnh nhược nhược cơ.
+ Seduxen (diazepam):
. Tác dụng: an tĩnh, chống co giật, gây giãn cơ.
. Liều dùng: viên 5mg x 1 – 2 viên/ngày dùng buổi tối; ống 10 mg x 1 ống/ngày, tiêm bắp thịt, buổi tối.
. Chống chỉ định: không dùng cho bệnh nhân nhược cơ.
+ Dogmatil (Sulpiride):
. Tác dụng: an tĩnh, chống lo âu, trầm cảm, các bệnh cơ thể tâm sinh.
. Liều dùng: viên 50mg, uống 1 – 2 viên/lần x 2 lần trong ngày (sáng, chiều).
+ Atarax:
. Tác dụng: giảm triệu chứng lo âu căng thẳng, kháng histamin.
. Liều dùng: viên 25mg, uống 1 – 4 viên/ngày (sáng, tối).
+ Haloperidol:
. Tác dụng: điều trị cho bệnh nhân tâm thần, chống hoang tưởng, ảo giác.
. Liều dùng: viên 1,5mg, uống 1 viên/1 lần x 1 – 2 lần/ngày; ống 1,5mg, tiêm bắp thịt 1 ống/1 lần/24h, buổi tối, trước khi ngủ.
. Nếu bị ngộ độc biểu hiện: cứng hàm lưỡi, co cứng các cơ cổ, đi lại khó khăn, nói khó, nếu có các biểu hiện trên thì dừng thuốc.
. Bệnh nhân nghiện rượu không dùng hai nhóm thuốc này.
**3. Thuốc điều trị Parkinson**
— Artan (taihexyphenidil):
+ Tác dụng: chống co cứng tốt hơn chống run.
+ Liều : viên 2mg x 1 viên/ngày (có thể 2 – 3 viên/ngày), dùng từ liều thấp đến liều cao.
+ Chống chỉ định:
. Bệnh loét dạ dày, phụ nữ có thai, phụ nữ cho con bú, trẻ dưới 12 tuổi, hội chứng trầm cảm trong bệnh tâm thần.
. Tăng nhãn áp (Glocom).
. U tiền liệt tuyến.
. Mất trương lực cơ ở ruột, bàng quang.
— Parlodel (Bromocritn 2,5mg):
+ Tác dụng: chống run, co cứng cơ.
+ Liều dùng: viên 2,5mg, uống từ 1/2 – 4 viên/24h, tối đa 40mg/24h. Dùng liều thấp tăng dần đến khi có tác dụng điều trị.
— Levodopa (L-dopa):
+ Chỉ định: bệnh Parkinson và hội chứng Parkinson.
+ Chống chỉ định: kết hợp với IMAO, suy thận, suy tim, phụ nữ có thai, rối loạn tâm thần.
+ Liều dùng: viên 0,25mg x 1 – 4 viên/ngày, chia nhiều lần.
— Modopar (Thuỵ Sỹ):
+ Viên nang chứa 200mg levodopar và 50mg besirazide
+ Liều dùng: 1/2 – 4 viên/ngày, chia 2 lần.
— Sinemet (Mỹ):
+ Viên chứa 250mg levodopa và 25mg carbidopa
+ Chỉ định: như levodopa
+ Liều dùng: 1 – 4 viên/ngày, tăng dần liều.
**4. Thuốc giảm đau hạ nhiệt**
— Có tác dụng giảm đau hạ nhiệt là chính ngoài ra có tác dụng chống viêm,
— Chống chỉ định: không dùng cho bệnh nhân viêm loét dạ dày, tá tràng.
— Nhóm Acid acetyl salisilic:
+ Aspirin (Acid acetyl Salisilic):
. Liều: viên 0,5 uống 0,25 – 0,5g/lần x 2 – 3 lần/ngày, sau khi ăn.
+ Aspirin pH8: có tác dụng giảm đau, ít ảnh hưởng đến niêm mạc dạ dày.
. Liều: uống 1 viên/1 lần x 2 lần trong ngày, sau khi ăn.
+ Aspisic:
. Dạng bột: gói 250mg, 500mg.
. Tác dụng: giảm đau, ít có tác dụng lên niêm mạc dạ dày.
. Liều: uống 150mg ữ 500m/1 lần x 2 lần/trong ngày, sau khi ăn .
— APC:
+ Thành phần của viên APC gồm:
Aspirin 0,2.
Phenacetil 0,2.
Cafein chia 2 lần, sau khi ăn.
+ Nhóm Paracetamol: giảm đau, hạ sốt.
+ Viên: 0,50 uống 2 viên/lần x 2 – 3 lần/ngày, sau khi ăn; ít ảnh hưởng đến niêm mạc dạ dày.
+ Pamin: hạ nhiệt nhanh.
+ Liều dùng: 1 – 2 viên/lần x 1 – 2 lần/ngày.
+ Efferalgan codein.
+ Viên sủi pha trong nước, uống 1 viên/lần x 2 – 3 lần/ngày.
— Analgin:
+ Tác dụng giảm đau.
+ Viên 0,5 uống 1 viên/lần x 2 – 3 lần/ngày, sau khi ăn.
— Antipirin:
+ Tác dụng giảm đau, hạ sốt.
+ Viên 0,5 uống 1 – 2g/ngày cho người lớn, sau ăn
— Phenaxetin:
+ Tác dụng như Aspirin, hạ nhiệt nhanh.
+ Viên 0,25 uống 1 – 2 viên/ngày.
— Piramydon:
+ Giảm đau, hạ nhiệt nhanh.
+ Viên 0,25 uống 2 – 3 viên/lần x 1 – 2 lần/ngày
— Seda:
+ Gồm phenacitil + pyramidon + canhkina + glifana.
+ Viên 0,2 uống 2 viên/1 lần x 2 lần/ngày.
— Pamin:
+ Hạ nhiệt nhanh.
+ Viên uống 1 – 2 viên/lần x 1 – 2 lần/ngày.
**5. Thuốc chống viêm, giảm đau**
— Tác dụng chống viêm trên cơ sở đó làm giảm đau; không dùng cho các bệnh nhân viêm loét dạ dày, tá tràng.
— Phenylbutazon: chống viêm, chống đau khớp.
+ Liều: viên 0,1 uống 1 viên/1 lần x 3 lần/ngày x 7 – 10 ngày, sau khi ăn.
+ Điều trị viêm đa khớp dạng thấp, viêm khớp cùng chậu.
+ Chú ý: thuốc hay gây dị ứng.
— Butafel:
+ Liều: viên 0,2 uống 4 – 6 viên/ngày, chia hai lần sáng, chiều, sau khi ăn.
— Volltaren (Diclofenac):
+ Viên 25mg, 50mg, ống 75mg.
+ Liều:
. Viên 0,25 uống 2 – 3 viên/ngày x 7 – 10 ngày, sau khi ăn.
. Ống 0,75 x 1 ống/ngày x 5 ngày, sau khi ăn.
— Indomethacyn:
+ Viên 0,025.
+ Uống 2 – 3 viên ngày x 7 – 10 ngày, sau khi ăn.
— Tilcotil:
+ Viên 0,25mg.
+ Uống 1 – 2 viên/ngày x 7 – 10 ngày, sau khi ăn.
+ Lọ 250mg tiêm bắp thịt 1 lọ/ngày x 5 – 7 ngày.
— Mobic (Meloxicam):
+ Viên 7,5mg x 1 viên/ngày x 7 – 10 ngày, sau khi ăn.
+ Ống 1,5ml chứa 15mg Meloxicam (chỉ dùng khi có đơn của bác sĩ).
— Không dùng cho trẻ em và các bệnh nhân có bệnh lý gan, thận.
**6. Thuốc chống trầm cảm**
Điều trị các trạng thái trầm cảm, suy nhược thần kinh.
— Melipramin (imipramin, amitriptilin)
+ Viên 25mg.
+ Liều dùng: lúc đầu dùng 1 – 2 viên/ngày, sau đó tăng dần mỗi ngày 1 viên, có thể dùng tới 4 viên/ngày, dùng buổi sáng, ban ngày.
+ Không kết hợp với các thuốc an thần, gây ngủ.
— Stablon:
+ Viên 1,25mg.
+ Liều dùng: uống 1 – 2 viên/lần x 2 – 3 lần/ngày, uống trước khi ăn, dùng kéo dài từ 4 – 6 tháng.
— Asthenal:
+ Dùng trong trạng thái suy nhược thần kinh, trạng thái trầm cảm nhẹ, chỉ dùng buổi sáng.
+ Liều 1 – 2 viên/lần/ngày.
**7. Thuốc điều trị động kinh**
— Gardenal (luiminal, sevenal)
+ Điều trị động kinh cơn lớn.
+ Liều dùng:
. Viên 0,1 x 1 – 2 viên/24 giờ.
. Ống 0,1 x 1 – 2 lần/24 giờ, tiêm bắp thịt.
Liều tối đa 0,6g/24 giờ.
— Sodanton (dihydan, hydantoin):
+ Điều trị động kinh cơn lớn, cơn nhỏ, cơn động kinh cục bộ, cơn tâm thần vận động.
+ Liều dùng:
. Người trưởng thành viên 0,1 uống 2 – 4 viên/ngày, chia 2 lần.
. Trẻ em: 4 – 7 mg/1kg thể trọng/ngày.
. Chú ý: dùng kéo dài có thể gây phì đại lợi.
— Tegretol:
+ Điều trị động kinh cơn lớn, cơn nhỏ, cơn động kinh cục bộ.
+ Liều dùng:
. Người trưởng thành viên 0,2 x 1 – 2 viên/ngày.
. Trẻ em: 2 – 3mg/1kg thể trọng/ngày.
. Ngộ độc gây dị ứng ngoài da, hội chứng Lyen.
— Depakin:
+ Điều trị động kinh cơn lớn, cơn nhỏ, cơn động kinh cục bộ.
+ Liều dùng:
. Viên 200mg x 1 – 2 viên/ngày.
. Viên 500mg x 1 viên/ngày.
. Tối đa 1500mg/ngày.
. Trẻ em: 20 – 30mg/1kg thể trọng/ngày.
— Ethosuximid:
+ Điều trị động kinh cơ nhỏ.
+ Liều: viên 250mg, uống 1 – 4 viên/ngày, chia 2 lần.
**8. Nhóm thuốc tăng cường dinh dưỡng và bảo vệ tế bào não**
— Stugron:
. Viên 25mg.
+ Tác dụng: ức chế co mạch, tăng tuần hoàn não và động mạch vành, kháng histamin mạnh.
+ Liều dùng: 2 – 4viên/ngày, chia 2 lần.
— Cavinton:
. Viên 5mg, ống 10mg.
+ Tác dụng: làm tăng tiêu thụ oxygen của tế bào não, tăng oxy hoá glucose, tăng AMP vòng và ATP cho não.
+ Liều dùng:
. 2 – 4 viên/ngày.
. 1- 2 ống/ngày, tiêm bắp thịt, hoặc pha vào dịch truyền glucose, ringerlactac.
. Chú ý dùng cho phụ nữ có thai và huyết áp thấp.
— Duxin (amitrine 30mg, raubasine 10mg):
+ Tác dụng: làm giầu oxy trong máu, được chỉ định điều trị trong suy tuần hoàn não, thiếu máu não cục bộ, rối loạn tiền đình, ốc tai, thiếu máu động mạch võng mạc.
+ Liều dùng: 2 viên/ngày, chia 2 lần.
+ Chú ý khi dùng cho phụ nữ có thai.
— Tanakan (ginkco bihoha).
+ Viên 40mg, dung dịch 40mg cao nguyên chất/1ml.
+ Tác dụng: điều trị chóng mặt, giảm trí nhớ, rối loạn cảm xúc, sau đột qụy não, chống các gốc tự do.
+ Liều dùng: + Viên: 3 viên/ngày chia 3 lần.
+ Dung dịch: 3ml/ngày chia 3 lần.
— Lucidiril:
+ Viên 250mg, lọ 250mg.
+ Tác dụng: chống giảm oxy não, tăng sử dụng glucose ở môi trường kỵ khí.
+ Liều dùng:
. Viên 2 – 4 viên/ngày, chia 2 lần.
. Lọ: 2 – 4 lọ/ngày chia 2 lần, tiêm bắp thịt hoặc pha dịch truyền tĩnh mạch.
— Piracetam (Notropin, Ucetam):
+ Tác dụng: tăng cường tuần hoàn não, tăng sử dụng glucose trong não, làm tăng ATP.
+ Chỉ định: trong đột quỵ não, chấn thương sọ não, chóng mặt, lo âu, chống lão hoá.
+ Liều dùng:
. Viên: uống 4 – 6 viên ngày, chia 2 – 3 lần.
. Ống: 1g, 2g, 3g, 12g; pha dịch truyền tĩnh mạch 4 – 12g/ngày.
— Cerebrolysin:
+ Ống 10ml.
+ Chỉ định: đột quỵ nhồi máu não, chấn thương sọ não, sa sút trí tuệ.
+ Liều dùng: 3 – 10ml/ngày, truyền tĩnh mạch. Dùng 1 đợt 15 ngày, 6 tháng sau có thể dùng tiếp liều trên.
— Nhóm Citicolin (recogmin, gliatilin, necolin, kemodyl…):
+ Tác dụng:
. Làm hoạt hoá quá trình sinh tổng hợp phospholipid để tham gia cấu tạo màng tế bào và acetylcholin, là chất dẫn truyền thần kinh – cơ.
. Tăng tổng hợp dopamin, bảo vệ tế bào thần kinh trong trường hợp giảm oxy máu và thiếu máu não cục bộ, cải thiện quá trình ghi nhớ trong sa sút trí tuệ.
. Chỉ định: đột quỵ não, chấn thương sọ não, sa sút trí tuệ.
. Chống chỉ định: phụ nữ có thai, cho con bú.
. Liều dùng: 500 – 1000mg/ngày, pha dịch truyền hay tiêm bắp.
**9.Thuốc điều trị đau nửa đầu (Hội chứng Migraine)**
— Tamik (Dyhydroegotamine):
+ Viên 3mg.
+ Chỉ định: cơn đau đầu Migraine, suy giảm tuần hoàn chi thể.
+ Chống chỉ định: co thắt mạch máu ngoại vi.
+ Liều dùng: uống 2 viên/ngày, chia 2 lần sau khi ăn.
— Egotamine Tartrat :
+ Chỉ định: cắt cơn đau đầu Migraine.
+ Chống chỉ định: phụ nữ có thai, suy thận, xơ cứng động mạch.
+ Liều dùng: uống 1 viên/lần x 2 – 3 viên/ngày, không 5 – 6 viên/tuần.
— Sibelium (flunalizine):
+ Viên 5mg.
+ Chỉ định: chống phòng ngừa đau 1/2 đầu, điều trị hoa mắt, chóng mặt, ù tai do rối loạn tiền đình.
+ Chống chỉ định: trầm cảm, Parkinson.
+ Liều dùng: 2 viên/ngày, uống buổi tối.
**10. Các thuốc khác**
— Thuốc cầm máu: hemocaprol, trasamin, nimotop.
— Thuốc tăng cường dẫn truyền thần kinh:
+ Nyvalin: ống 2,5mg, 5mg, 7,5mg. Tiêm 1 ống/ngày, bắp thịt sau khi ăn.
— Thuốc chống nhược cơ:
+ Prostigmin ống 1/2mg x 1 – 4 ống/ngày, tiêm bắp thịt, chia 2 lần trước khi ăn 30 phút.
+ Mytelase viên 10mg x 1 – 4 viên/ngày, chia 2 lần, uống trước khi ăn 30 phút.
+ Mestilon viên 60mg x 1 – 2 viên/ngày, chia 2 lần, uống trước khi ăn 30 phút.
— Thuốc giãn cơ vân:
+ Mydocalm viên 50g x 2 – 4/ngày,uống, chia 2 lần sáng, chiều, uống sau khi ăn.
+ Myonal viên 50mg x 2 – 3 viên/ngày,uống, chia 2 lần sáng chiều, uống sau khi ăn.
+ Decontractyl viên 250mg x 6 – 12 ngày, chia 3 lần sáng, chiều, tối, uống sau khi ăn.
+ Coltranyl
. Viên 4mg x 4 – 8 viên/ngày, chia 2 lần sáng, chiều, uống sau khi ăn.
. Ống 4mg, tiêm bắp thịt 1 – 2 ống/ngày
— Các vitamin nhóm B: vitamin B1, B6, B12, bcomplex, becozyme, becofort, nevramin, homtamin, vicaps, metylcobal, ancopir…
— Thuốc phong bế hệ thần kinh: novocain, lidocain.

## HỘI XUÂN QUÝ MÃO 2023 “DINH DƯỠNG DÀNH CHO BỆNH NHÂN ĐÁI THÁO ĐƯỜNG”

Theo Hiệp hội đái tháo đường thế giới, hiện đang 537 triệu người trưởng thành (20-79 tuổi) phải chung sống với bệnh tiểu đường và được dự đoán sẽ tăng lên 643 triệu vào năm 2030 và 783 triệu vào năm 2045. Tại Việt Nam, theo kết quả điều tra của Bộ Y tế năm 2021 cho thấy tỷ lệ mắc đái tháo đường ở người trưởng thành ước tính là 7,1%, tương đương với khoảng gần 5 triệu người đang mắc bệnh đái tháo đường. Trong đó, số đã được chẩn đoán chỉ chiếm khoảng 35% và số đang được quản lý, điều trị tại các cơ sở y tế chiếm 23,3%. Theo dự báo, số mắc đái tháo đường của Việt Nam cũng như toàn thế giới sẽ tiếp tục tăng nhanh trong những năm tới.
Trong bối cảnh đó, nhằm giáo dục truyền thông sức khoẻ cho bệnh nhân đái tháo đường hiểu thêm về bệnh, chủ động chăm sóc sức khoẻ và phòng ngừa biến chứng, Bệnh viện Nguyễn Tri Phương tổ chức HỘI XUÂN QUÝ MÃO 2023, với sự tài trợ của Công ty TNHH Nipro Sales Việt Nam, Công ty Cổ phần Công nghệ Y tế DIAB dành riêng cho bệnh nhân đái tháo đường. Với mục tiêu cung cấp những kiến thức khoa học, thực tế và hướng kỹ năng xây dựng chế độ dinh dưỡng, vận động giúp người bệnh Đái tháo đường phòng ngừa biến chứng, gạt đi những nỗi lo về bệnh, vui sống mỗi ngày, hội xuân mang đến các hoạt động hấp dẫn, kết hợp giữa cung cấp kiến thức và hướng dẫn thực hàng như: 
  * Miễn phí kiểm tra chỉ số đường huyết mao mạch
  * Tư vấn trực tiếp cùng các bác sĩ chuyên khoa nội tiết
  * Hướng dẫn chế độ dinh dưỡng, vận động
  * Cuộc thi “Bữa ăn dinh dưỡng”
  * Tham gia thử thách kiểm tra thể lực và yoga
  * Cùng nhiều phần quà đến từ Nipro Sales Việt Nam và DIAB thông qua các hoạt động xen kẽ trong chương trình.


**Thời gian:** 6 giờ 30 – 11 giờ 00, ngày 07 tháng 01 năm 2023.
**Địa điểm:** Bệnh viện Nguyễn Tri Phương - 468 Đ. Nguyễn Trãi, Phường 8, Quận 5, Thành phố Hồ Chí Minh. 
Cuộc thi “Bữa ăn dinh dưỡng” sẽ sự tham gia thực hiện trực tiếp của các sĩ nội tiết, chuyên gia dinh dưỡng Bệnh viện Nguyễn Tri Phương, Bệnh viện Nhân dân 115, Bệnh viện Nhân dân Gia Định, Bệnh viện Nguyễn Trãi, Bệnh viện Trưng Vương, nhằm hướng dẫn xây dựng và chế biến bữa ăn dành cho người đái tháo đườngBên cạnh đó, sự tham gia của TS. BS Lý Đại Lươ- Giảng Viên Khoa Y, Đại học Quốc Gia TP.HCM và BSCKII. Nguyễn Thị Diễm Ngọc - Giảng viên bộ môn Nội tiết, Đại học Y dược TP.HCM, BSCKI. Lâm Vạn Phong – Trưởng khoa dinh dưỡng Bệnh viên Nguyễn Tri Phương nhằm tư vấn, giải đáp các thắc mắc giúp cộng động hiểu thêm về bệnh, chủ động chăm sóc sức khoẻ và phòng ngừa biến chứng liên quan bệnh lý Đái tháo đường. 

## Hỏi đáp: Táo bón – Nguyên nhân và cách phòng ngừa

  * [Nguyên nhân gây bệnh táo bón](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/hoi-dap-tao-bon-nguyen-nhan-va-cach-phong-ngua#nguyn-nhn-gy-bnh-to-bn)
  * [Hậu quả của táo bón](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/hoi-dap-tao-bon-nguyen-nhan-va-cach-phong-ngua#hu-qu-ca-to-bn)
  * [Cách xử trí khi mắc táo bón](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/hoi-dap-tao-bon-nguyen-nhan-va-cach-phong-ngua#cch-x-tr-khi-mc-to-bn)


Táo bón là bệnh lý đường tiêu hóa và liên quan mật thiết đến sự tiêu hóa thức ăn. Một người bình thường có thể đi ngoài từ 1-3 lần/ngày đêm hoặc trên 3 lần/tuần. Khi quá 3 ngày chưa đi ngoài hoặc đi ngoài dưới 3 lần trong một tuần có thể gọi là mắc bệnh táo bón.
## **Nguyên nhân gây bệnh táo bón**
Táo bón có nhiều nguyên nhân gây ra, đa số các trường hợp đều do ăn uống.
Với trẻ em, nếu một chế độ ăn ít rau, trái cây, uống ít nước trong khi ăn uống nhiều thức ăn nhanh, giàu chất béo hoặc ăn nhiều bánh, kẹo, nước giải khát có đường,… có thể gây táo bón thường xuyên. Ngoài ra, trẻ bị táo bón có thể do dùng thường xuyên sữa bột hoặc có thói quen nhịn đi đại tiện hoặc bồng bế suốt ngày trẻ không được vận động.
Với người lớn có nhiều nguyên nhân dẫn đến táo bón, trong đó chế độ dinh dưỡng không hợp lý do kiêng khem quá mức hoặc ăn ít hoặc chán không muốn ăn là nguyên nhân phổ biến. Lúc này chất cặn bã ít, phân ít nên không tạo được phản xạ co bóp của đại tràng để đi đại tiện, đặc biệt với người cao tuổi. Ngoài ra, ăn ít rau, ít chất xơ và uống ít nước (do ngại đi tiểu) cũng là những nguyên nhân dẫn đến táo bón ở người lớn. Một số người quen ăn những loại thức ăn có nhiều chất béo như bơ, sữa, đường tinh chế, thích ăn nhiều chất cay, nóng, uống nhiều rượu, bia (làm giãn mạch, mất nước) và lượng nước đưa vào trong cơ thể hàng ngày không đủ sự cần thiết để tiêu hóa thức ăn càng khiến hiện tượng táo bón dễ xảy ra.
Một số người tuổi càng cao chức năng sinh lý càng bị giảm sút, ví dụ như cơ hoành, cơ vùng xương chậu bị yếu đi làm hạn chế nhu động của ruột từ đó lực đẩy của ruột suy giảm vì vậy, việc đẩy phân ra ngoài khó khăn, làm ứ trệ làm cho phân lưu lại lâu trong đại trực tang sẽ gây táo bón.
## **Hậu quả của táo bón**
**Táo bón không được xử trí kịp thời có thể dẫn đến nhiều biến chứng nguy hiểm.**
Táo bón không được xử trí kịp thời có thể dẫn đến nhiều hậu quả khôn lường:
– Nếu táo bón kinh niên nguyên nhân là do sự xáo trộn về sinh lý của ruột già thì ảnh hưởng trên cơ thể tương đối ít nhưng khiến cho người bệnh khó chịu, kém vui, thỉnh thoảng cảm thấy đau nhức đầu.
– Có thể làm nhiễm trùng đường ruột gây sưng ruột.
– Táo bón không phải là bệnh hiểm nghèo nhưng nếu để kéo dài sẽ xảy ra những biến chứng nguy hiểm, không đáng có như tắc ruột, xoắn ruột, sa trực tràng, xuất hiện cơn thiếu máu cục bộ (do phải rặn lâu), trĩ, ung thư ruột…
## **Cách xử trí khi mắc táo bón**
Ở những thời gian đầu ta có thể áp dụng một số biện pháp nhỏ để cải thiện tình hình như:
– Trước khi đi ngủ, uống một cốc sữa ấm trước khi đi ngủ.
– Uống 1 lít nước ấm và đi bộ khoảng vài phút ngay lập tức vào buổi sáng.
– Uống nước chanh pha với nước ấm từ 2 – 3 lần/ngày.
– Bổ sung nhiều rau, củ quả để tăng cường chất xơ.
– Chỉ ăn khi đói, không nên ăn thành nhiều bữa và mỗi bữa ăn nên cách nhau 4 tiếng.
– Luyện tập đều đặn.
– Ngủ đủ giấc. Thiếu ngủ cũng chính là một trong số những thủ phạm gây nên căn bệnh táo bón.
– Hạn chế ăn những đồ ăn khô như đậu tương, lạc…
– Không nên ăn quá nhiều loại thức ăn trong một bữa ăn.
– Tránh xa thuốc lá, cà phê và trà đặc.
Trong trường hợp bệnh không được cải thiện, người bệnh có thể dùng thuốc, tuy nhiên cần có sự chỉ định của bác sĩ.
**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/) **- Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [Nguyên nhân gây bệnh táo bón](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/hoi-dap-tao-bon-nguyen-nhan-va-cach-phong-ngua#nguyn-nhn-gy-bnh-to-bn)
  * [Hậu quả của táo bón](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/hoi-dap-tao-bon-nguyen-nhan-va-cach-phong-ngua#hu-qu-ca-to-bn)
  * [Cách xử trí khi mắc táo bón](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/hoi-dap-tao-bon-nguyen-nhan-va-cach-phong-ngua#cch-x-tr-khi-mc-to-bn)



## Hồng cầu sau khi phá hủy sẽ thế nào?

Hồng cầu không có nhân và các bào quan cần thiết cho sự duy trì của tế bào, vì vậy đời sống hồng cầu thường ngắn. Trong máu ngoại vi, hồng cầu sống khoảng 120 ngày. Các hồng cầu già bị thực bào và phá hủy ở gan, lách và tủy xương. Mỗi ngày có khoảng 230 tỷ hồng cầu bị phá hủy mỗi ngày.
Mỗi phân tử Hb gồm một phân tử globin( gồm 4 chuỗi polypeptid) và nhân hem.
Khi hồng cầu bị tiêu hủy, Hb bị phá vỡ các thành phần của chúng được tái tuần hoàn và sử dụng lại trong cơ thể.
- Các chuỗi peptid phân giải thành các acid amin, có thể được dùng để tổng hợp protein trong các tế bào khác
- Phần hem: được giải phóng thành sắt (Fe3+) và biliverdin
+ Sắt được giải phóng vào huyết tương, được transferin vận chuyển đến các kho dự trữ hoặc đến tủy xương để tạo hồng cầu mới.
+ Biliverdin bị khử thành bilirubin và được giải phóng vào huyết tương rồi vận chuyển đến gan.
- Vận chuyển Bilirubin
  * Bilirubin mới được tạo ra được gọi là Bilirubin gián tiếp (dạng tự do, không liên hợp)
  * Bilirubin gián tiếp (Bilirubin GT)
  * Không tan trong nước => Không đào thải qua thận => Không bao giờ xuất hiện trong nước tiểu
  * Gắn kết với albumnin huyết tương để di chuyển trong máu (1 phân tử albumin gắn được 2 phân tử Bil GT)


- Chuyển hóa Bilirubin
  * Thu nạp Bilirubin
  * Tại màng tế bào gan có các protein Y và Z (được gọi là các ligandine) giúp đưa Bilirubin GT vào bên trong lười nội bào tương của tế bào gan
  * Liên hợp
  * Sau khi được thu nạp, Bilirubin GT được liên hợp với acid glucuronic, dưới tác dụng của men Glucuronyl transferase => trở thành Bilirubin trực tiếp (dạng liên hợp) và có thể hòa tan được trong nước


- Bài tiết:
  * Bilirubin trực tiếp (Bilirubin TT) được vận chuyển đến màng tế bào gan phía tiếp giáp đường mật => được bài tiết chủ động theo dịch mật xuống ruột non
  * Chuyển hóa tại ruột
  * Bilirubin TT không được tái hấp thu tại ruột. Dưới tác động của vi khuẩn đường ruột tại ruột già, Bilirubin TT được chuyển hóa thành Urobilinogen không màu
  * Urobilinogen tiếp tục diễn tiến theo 3 hướng
  * Hấp thu vào tĩnh mạch cửa về gan, được gan thu nhận và bài tiết vào lại đường mật => xuống ruột (chu trình gan ruột)
  * Hấp thu vào TM cửa vào tuần hoàn chung => đến thận và được thải ra nước tiểu. Urobilinogen bị oxy hóa thành Urobilin tạo màu vàng cho nước tiểu.


=> Nước tiểu bình thường có sự hiện diện của Urobilinogen với số lượng rất ít
Phần lớn Urobilinogen tiếp tục tồn tại trong lòng ruột => được chuyển hóa thành Stercobilinogen rồi Stercobilin tạo màu vàng cho phân
Bilirubin rất độc với hệ thần kinh. Khi bị tích lũy trong cơ thể nó có thể làm tổn thương các tế bào thần kinh. Tăng biliribin trong máu gây vàng da, vàng mắt và niêm mạc. Tăng bilirubin trong máu hay gặp ở trẻ sơ sinh do một số hồng cầu bị vỡ giải phóng bilirubin trong khi gan của đứa trẻ chưa đủ bài xuất bilirubin thông qua phản ứng kết hợp với acid glucuronic.
"**Rất may bilirubin là một sắc tố nhạy cảm với ánh sáng và bị phân hủy khi tiếp xúc với ánh sáng có bước sóng gần tia cực tím. Vì thế trẻ bị vàng da sơ sinh khi tiếp xúc với ánh ánh có bước sóng thích hợp trong lồng kính, bilirubin được giữ lại ở nồng độ thấp cho đến khi gan của đứa trẻ đủ khả năng bài xuất bilirubin**"

## Đồ uống có đường và các bệnh có liên quan đến chuyển hóa

Đồ uống có đường là các loại nước giải khát có cho thêm đường tự do. Đồ uống có đường bao gồm nhiều loại như nước ngọt có ga, trà có đường, nước tăng lực, nước uống thể thao, nước đóng chai có hương vị, nước hương vị sữa, sữa uống, sữa chua uống, nước trái cây với dưới 100% trái cây.
Sự gia tăng về chủng loại, sự tiện lợi, cũng như giá thành vừa phải của các loại đồ uống có đường hiện nay được cho là một trong những nguyên nhân của “dịch” thừa cân, béo phì – một rối loạn của con người ở thời đại mới. Trong khi đó, thừa cân, béo phì là yếu tố nguy cơ của hàng loạt các bệnh có liên quan đến chuyển hóa như đái tháo đường tuýp 2, gout, rối loạn mỡ máu, rối loạn huyết áp và các bệnh tim mạch, sức khỏe xương và gây gia tăng tỷ lệ tử vong. Hiện nay, trên 70% gánh nặng bệnh tật ở Việt Nam là từ các bệnh không lây nhiễm như tăng huyết áp, đái tháo đường, ung thư, bệnh phổi tắc nghẽn mạn tính [1]. Theo Tổ chức Y tế thế giới, các yếu tố nguy cơ có thể thay đổi của các bệnh không lây nhiễm bao gồm ăn uống không hợp lý, đặc biệt với chế độ ăn nhiều muối, ít hoạt động thể lực, hút thuốc lá/thuốc lào và uống rượu, bia [2]. Trong số các thực hành ăn uống không hợp lý, tiêu thụ các đồ uống có đường là một yếu tố nguy cơ gia tăng bệnh không lây nhiễm thông qua một loạt các rối loạn về chuyển hóa.
**Đồ uống có đường và đái tháo đường tuýp 2**
Người uống 1-2 lon nước ngọt mỗi ngày có thể tăng 26% nguy cơ bị đái tháo đường tuýp 2 so với người hiếm khi uống các loại nước này [3]. Các nguy cơ này thậm chí còn cao hơn ở người trưởng thành hay người Châu Á. Việc tăng tiêu thụ nước ngọt có đường, bao gồm cả nước ngọt có đường và nước 100% trái cây, ở mức khoảng 100ml/ngày trong vòng 4 năm làm tăng 16-18% nguy cơ đái tháo đường tuýp 2 [4]. Nếu thay thế nước ngọt có đường bằng nước lọc, cà phê (đen) hoặc trà có thể giảm 2-10% nguy cơ đái tháo đường tuýp 2 [5].
Nước ngọt có đường làm gia tăng nguy cơ đái tháo đường tuýp 2 thông qua một số cơ chế mà trong đó, một nửa nguy cơ được cho là từ việc tăng BMI (chỉ số khối cơ thể, tính bằng trọng lượng cơ thể theo kg chia cho chiều cao theo m bình phương) [6]. Ngoài ra, các loại đường tự do trong nước ngọt (fructose, sucrose…) có thể gây ra tình trạng gan nhiễm mỡ và tăng đường huyết sau ăn, dẫn tới tăng viêm nhiễm, kháng insulin, giảm chức năng tế bào beta tại tụy, dẫn tới đái tháo đường tuýp 2 [3, 7]. Một yếu tố quan trọng khác là chỉ số đường huyết (glycaemic index - GI), chỉ số này biểu hiện tỷ lệ hấp thu đường bột từ thức ăn vào cơ thể [8]. Các chế độ ăn hoặc thực phẩm có GI thấp làm giảm đáp ứng với glucose và insulin, trong khi đó các chế độ ăn hoặc thực phẩm có GI cao ví dụ như đồ uống có đường, làm tăng kích thước tế bào mỡ [9]. Các bữa ăn hay thực phẩm có GI cao còn có tác dụng kích thích việc ăn uống nhiều hơn mức bình thường [10], làm gia tăng hơn nguy cơ thừa cân, béo phì và đái tháo đường tuýp 2.
**Đồ uống có đường****với các rối loạn và biến chứng tim mạch**
Một nghiên cứu theo dõi 40.000 nam giới trong 2 thập kỷ cho thấy những người uống trung bình 1 cốc nước ngọt mỗi ngày có nguy cơ bị đau tim hoặc tử vong do đau tim cao hơn những người hiếm khi hoặc không uống nước ngọt khoảng 20% [11]. Nguy cơ này còn ở mức 40% đối với nữ giới [12]. Đồ uống có đường cũng làm tăng 12% nguy cơ bị đột quỵ và 22% nguy cơ nhồi máu cơ tim [13]. Những người hay uống đồ uống có đường thường có xu hướng tăng cân nhiều hơn những người không uống hoặc ít uống. Thậm chí, dù có chế độ ăn lành mạnh hay cân nặng hợp lý thì cũng chỉ giảm được không đáng kể các nguy cơ có liên quan tới tiêu thụ nước ngọt. Điều này có thể một phần giải thích cho cơ chế của việc tiêu thụ nước ngọt với các nguy cơ bệnh tim mạch là gián tiếp thông qua tình trạng thừa cân, béo phì hoặc nạp vào quá nhiều năng lượng. Ngoài ra, tác động của tải lượng đường huyết cao sau khi uống các đồ uống có đường lên đường huyết, cholesterol và các yếu tố gây viêm cũng góp phần gây tăng huyết áp, rối loạn mỡ máu, xơ vữa động mạch, thuyên tắc mạch...và các biến chứng về tim mạch.
**Đồ uống có đường****với bệnh gout**
Lượng đường từ nước giải khát được cho là có tác động lên gen SLC2A9, là kiểu gen có ảnh hưởng đến sự bài tiết acid uric qua thận [14]. Đường, đặc biệt là đường trắng, sucrose hay các loại siro nhiều đường fructose có thể là nguyên nhân gây tăng acid uric hay tăng insulin máu [15]. Tăng insulin máu được cho là yếu tố nguy cơ tiềm tàng của béo phì và hội chứng chuyển hóa [16]. Nghiên cứu cho thấy những người uống nước ngọt ở mức ≥2 lon/ngày có nguy cơ bị gout cao gấp 2,39 lần so với người uống nước ngọt <1 lần/tháng [17]. Ở những người có BMI≥30 nguy cơ này là 6,4 lần so với người có BMI <30. Như vậy, nước ngọt không những tác động đến sự phát triển của bệnh gout thông qua cơ chế gen mà còn tác động gián tiếp thông qua thừa cân, béo phì và các hậu quả của thừa cân, béo phì, trong đó có gout.
**Đồ uống có đường và ung thư**
Đồ uống có đường hoặc có chất làm ngọt nhân tạo được xác định làm tăng lần lượt 19% và 27% các ung thư có liên quan tới béo phì như ung thư gan, dạ dày, thận, thực quản, buồng trứng… [18]. Có nhiều cơ chế được giải thích cho mối liên quan giữa uống đồ uống có đường với các loại ung thư. Có thể việc tiêu thụ đồ uống có đường gây ung thư thông qua cơ chế tăng cân, dẫn tới thừa cân, béo phì và hàng loạt các bệnh chuyển hóa kể trên, từ đó phát triển ung thư. Đường tự do trong đồ uống cũng được xác định làm thúc đẩy các yếu tố viêm và quá trình gây viêm như làm tăng nồng độ protein phản ứng C (CRP) trong máu, một chỉ dấu sinh học của chứng viêm và làm tăng nguy cơ ung thư [19]. Một nghiên cứu gần đây từ nhóm nghiên cứu NutriNet-Santé cũng báo cáo mối liên quan giữa đồ uống có đường với nguy cơ ung thư, và việc giảm lượng đường ăn vào có tác dụng rõ rệt trong việc giảm những nguy cơ này [20].
Như vậy, đồ uống có đường, nếu được tiêu thụ không hợp lý có thể là nguyên nhân của một loạt các rối loạn có liên quan đến chuyển hóa. Các rối loạn này có thể bao gồm đái tháo đường tuýp 2, tăng huyết áp, rối loạn mỡ máu và các biến chứng tim mạch, gout, ung thư. Hơn nữa, các rối loạn này thường mạn tính, gây hậu quả nghiêm trọng về sức khỏe, ảnh hưởng tới chất lượng sống của cá nhân và sự thịnh vượng của gia đình cũng như sự phát triển của xã hội. Vì thế, không nên nhìn nhận đồ uống có đường đơn giản là một thức uống giải khát tiện dụng mà người dân nên được hướng dẫn, giáo dục để tiêu thụ đồ uống có đường một cách hợp lý nhằm bảo vệ sức khỏe.
**TÀI LIỆU THAM KHẢO**
1. Bộ Y tế. (2021).  _Hội thảo xây dựng Kế hoạch quốc gia phòng, chống bệnh không lây nhiễm và các rối loạn sức khỏe tâm thần giai đoạn 2021-2025_. Truy cập từ: https://moh.gov.vn/tin-noi-bat/-/asset_publisher/3Yst7YhbkA5j/content/hoi-thao-xay-dung-ke-hoach-quoc-gia-phong-chong-benh-khong-lay-nhiem-va-cac-roi-loan-suc-khoe-tam-than-giai-oan-2021-2025.
2. WHO. (2012).  _Noncommunicable diseases. Fact sheet_ 2011. Truy cập ngày 03/9/2012 từ: <http://www.who.int/mediacentre/factsheets/fs355/en/index.html>.
3. Malik, V.S., Popkin B.M., Bray G.A., et al. (2010).  _Sugar-sweetened beverages and risk of metabolic syndrome and type 2 diabetes: a meta-analysis._ Diabetes care. **33**(11):2477-2483.
4. Drouin-Chartier, J.-P., Zheng, Y., Li, Y., et al. (2019).  _Changes in consumption of sugary beverages and artificially sweetened beverages and subsequent risk of type 2 diabetes: results from three large prospective US cohorts of women and men._ Diabetes Care. **42**(12):2181-2189.
5. Diabetologia. (2015).  _Replacing one serving of sugary drink per day by water or unsweetened tea or coffee cuts risk of type 2 diabetes, study shows._ ScienceDaily. Retrived from https://www.sciencedaily.com/releases/2015/04/150430191138.htm
6. Malik, V.S., Barry, M.P., George, A.B., et al. (2010).  _Sugar-Sweetened Beverages, Obesity, Type 2 Diabetes Mellitus, and Cardiovascular Disease Risk._ Circulation. **121**(11) 1356-1364.
7. Greenwood, D., Threapleton, D.E., Evans, C.E.L., et al. (2014).  _Association between sugar-sweetened and artificially sweetened soft drinks and type 2 diabetes: systematic review and dose–response meta-analysis of prospective studies._ British Journal of Nutrition. **112**(5):725-734.
8. James, J. and D. Kerr. (2005).  _Prevention of childhood obesity by reducing soft drinks._ International Journal of Obesity. **29**(2):S54-S57.
9. Morris, K.L. and M.B. Zemel. (1999).  _Glycemic index, cardiovascular disease, and obesity._ Nutrition reviews. **57**(9):273-276.
10. Ludwig, D.S., et al. (1999).  _High glycemic index foods, overeating, and obesity._ Pediatrics. **103**(3):e26-e26.
11. De Koning L, M.V., Kellogg MD, Rimm EB, Willett WC, Hu FB. (2012).  _Sweetened beverage consumption, incident coronary heart disease, and biomarkers of risk in men._ Circulation. **125**(14):1735-41.
12. Fung TT, M.V., Rexrode KM, Manson JE, Willett WC, Hu FB. (2009).  _Sweetened beverage consumption and risk of coronary heart disease in women._ The AJCN. **89**(4):1037-42.
13. Narain, A., C.S. Kwok, and M.A. Mamas. (2016).  _Soft drinks and sweetened beverages and the risk of cardiovascular disease and mortality: a systematic review and meta-analysis._ Int J Clin Pract. **70**(10):791-805.
14. Batt, C., Phipps-Green, A.J., lack, M.A., et al. (2014).  _Sugar-sweetened beverage consumption: a risk factor for prevalent gout with SLC2A9 genotype-specific effects on serum urate and risk of gout._ Annals of the Rheumatic Diseases. **73**(12):2101-2106.
15. Johnson, R.J., Perez-Pozo, S.E., Sautin, Y. Y. et al. (2009).  _Hypothesis: could excessive fructose intake and uric acid cause type 2 diabetes?_ Endocrine reviews. **30**(1):96-116.
16. Johnson, R.J., Segal, M.S., Sautin, Y., et al. (2007).  _Potential role of sugar (fructose) in the epidemic of hypertension, obesity and the metabolic syndrome, diabetes, kidney disease, and cardiovascular disease._ AJCN. **86**(4):899-906.
17. Choi, H.K., W. Willett, and G. Curhan. (2010).  _Fructose-rich beverages and risk of gout in women._ JAMA. **304**(20):2270-2278.
18. Hodge, A.M., et al.,  _Consumption of sugar-sweetened and artificially sweetened soft drinks and risk of obesity-related cancers._ Public Health Nutrition, 2018. **21**(9): p. 1618-1626.
19. Tamez, M., Bassett, J.K., Milne, R.L, et al. (2018).  _Soda intake is directly associated with serum C-reactive protein concentration in Mexican Women._ J Nutr. **148**(1):117-124.
20. Chazelas, E., Srour, B., Desmetz, E., et al. (2019).  _Sugary drink consumption and risk of cancer: results from NutriNet-Santé prospective cohort._ BMJ. **366**.

## Hỏi đáp: Xoắn ruột có nguy hiểm không?

  * [Xoắn ruột là gì?](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/hoi-dap-xoan-ruot-co-nguy-hiem-khong#xon-rut-l-g)
  * [Nguyên nhân gây xoắn ruột](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/hoi-dap-xoan-ruot-co-nguy-hiem-khong#nguyn-nhn-gy-xon-rut)
  * [Triệu chứng xoắn ruột](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/hoi-dap-xoan-ruot-co-nguy-hiem-khong#triu-chng-xon-rut)
  * [Xoắn ruột có nguy hiểm không?](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/hoi-dap-xoan-ruot-co-nguy-hiem-khong#xon-rut-c-nguy-him-khng)
  * [Chẩn đoán và điều trị xoắn ruột như thế nào?](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/hoi-dap-xoan-ruot-co-nguy-hiem-khong#chn-on-v-iu-tr-xon-rut-nh-th-no)


Xoắn ruột có nguy hiểm không là quan tâm của rất nhiều người. Nếu bạn đang quan tâm đến vấn đề này hãy cùng chúng tôi tìm hiểu qua bài viết dưới đây nhé!
## **Xoắn ruột là gì?**
Xoắn ruột gây tắc nghẽn đường ruột và ứ đọng thực phẩm, làm giảm lưu lượng máu đến ruột, gây viêm, hoại tử phúc mạc có thể nguy hiểm đến tính mạng.
-Ở trẻ em, xoắn ruột có thể xảy ra do bất thường bẩm sinh.
-Ở người lớn, xoắn ruột chủ yếu do lạm dụng thuốc nhuận tràng và thuốc điều trị tâm thần hoặc không xác định được nguyên nhân gây bệnh.
**Xoắn ruột có nguy hiểm không là quan tâm của rất nhiều người**
### **Nguyên nhân gây xoắn ruột**
Nguyên nhân gây xoắn ruột chủ yếu do:
– Do bẩm sinh: Khi thai nhi xoay và cố định ruột trong cuối thai kỳ.
– Trẻ sơ sinh hoặc trẻ nhỏ từng phải phẫu thuật ổ bụng hoặc có khối u cũng có nguy cơ bị xoắn ruột cao.
– Chứng quay ruột bất thường ở trẻ nhỏ.
– Ở người lớn, xoắn ruột chủ yếu do lạm dụng thuốc nhuận tràng và thuốc điều trị tâm thần hoặc không xác định được nguyên nhân gây bệnh.
Để biết chính xác nguyên nhân gây xoắn ruột, người bệnh cần được thăm khám bởi bác sĩ chuyên khoa. Căn cứ trên kết quả khám lâm sàng và cận lâm sàng, bác sĩ sẽ đưa ra chẩn đoán chính xác nhất về nguyên nhân gây bệnh, đánh giá đúng mức độ xoắn ruột và đưa ra phương án điều trị phù hợp nhất cho người bệnh.
### **Triệu chứng xoắn ruột**
Đầy bụng, chướng bụng, căng bụng, đầy hơi
Chuột rút
Nôn mửa, dịch màu vàng hoặc màu xanh
Rối loạn đại tiện với biểu hiện táo bón nặng hoặc tiêu chảy; bí hoàn toàn đại tiện và trung tiện. Đại tiện ra máu hoặc màu nâu, đen
Trẻ nhỏ quấy khóc, bỏ bú, da xanh tím tái, khóc không dỗ được, khóc thét thành từng cơn…
Đau bụng kéo dài và đau tăng dần theo thời gian
Bệnh nhân bị sốc rất nhanh với các biểu hiện như mạch nhanh, huyết áp hạ, lo sợ, hốt hoảng…
Các triệu chứng của xoắn ruột thường thể hiện rất rầm rộ. Các bác sĩ khuyến cáo, khi có các triệu chứng xoắn ruột nêu trên, bệnh nhân cần nhập viện khẩn cấp để được thăm khám và cấp cứu kịp thời, tránh biến chứng nguy hiểm.
### **Xoắn ruột có nguy hiểm không?**
Xoắn ruột là một trong những cấp cứu nội, ngoại khoa nguy hiểm, có thể đe dọa đến tính mạng của người bệnh nếu chậm trễ đến bệnh viện. Thời điểm tốt nhất để điều trị xoắn ruột là trước 6 giờ tính từ khi các triệu chứng xuất hiện. Sau khoảng thời gian 6 giờ, người bệnh có thể phải cắt bỏ ruột thậm chí tử vong vì hoại tử ruột.
#### **Chẩn đoán và điều trị xoắn ruột như thế nào?**
**Chẩn đoán:**
Bắc sĩ hỏi bệnh sử và tiến hành khám thực thể.
Người bệnh được chỉ định chụp cắt lớp vi tính (CT Scan), chụp X-quang để phục vụ việc chẩn đoán, đánh giá tình trạng xoắn ruột.
Xét nghiệm công thức máu toàn bộ (CBC) và bảng chuyển hóa toàn diện (CMP).
Xét nghiệm Lipase, phân tích nước tiểu (UA).
Thụt bari, các xét nghiệm với đường tiêu hóa trên và ruột non…
#### **Điều trị:**
-Đưa người bệnh đến bệnh viện càng sớm càng tốt để được thăm khám và điều trị kịp thời, đúng cách, tránh những biến chứng nguy hiểm của bệnh.
Tuyệt đối không tự mua thuốc giảm đau cho người bệnh dùng vì có thể gây khó khăn cho việc chẩn đoán của bác sĩ. Cấp cứu kịp thời có thể khiến người bệnh không phải cắt bỏ ruột, chức năng ruột vẫn phục hồi sau cấp cứu.
Xoắn đại tràng có thể được giải nén mà không cần phẫu thuật, trong khi đó, xoắn ruột non thường phải phẫu thuật để tháo xoắn và sau đó đính ruột vào thành bụng để ngăn ngừa tái phát.
**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/) **- Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [Xoắn ruột là gì?](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/hoi-dap-xoan-ruot-co-nguy-hiem-khong#xon-rut-l-g)
  * [Nguyên nhân gây xoắn ruột](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/hoi-dap-xoan-ruot-co-nguy-hiem-khong#nguyn-nhn-gy-xon-rut)
  * [Triệu chứng xoắn ruột](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/hoi-dap-xoan-ruot-co-nguy-hiem-khong#triu-chng-xon-rut)
  * [Xoắn ruột có nguy hiểm không?](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/hoi-dap-xoan-ruot-co-nguy-hiem-khong#xon-rut-c-nguy-him-khng)
  * [Chẩn đoán và điều trị xoắn ruột như thế nào?](https://bvnguyentriphuong.com.vn/cau-lac-bo-benh-nhan/hoi-dap-xoan-ruot-co-nguy-hiem-khong#chn-on-v-iu-tr-xon-rut-nh-th-no)



## Đầy hơi kéo dài lâu ngày phải làm sao?

## **Đầy hơi lâu ngày có nguy hiểm không ?**
Đầy bụng, đầy hơi khó tiêu thực chất là một trong những triệu chứng phổ biến của rối loạn tiêu hóa xuất phát từ bệnh dà dày.
Nguyên nhân dẫn đến tình trạng này chính là do thói quen ăn uống thiếu khoa học: nhai không kĩ, ăn nhanh, ăn nhiều tinh bột, nhiều chất béo, nhiều gia vị cay nóng, nằm ngay sau khi ăn , …
Theo các bác sĩ, chứng đầy hơi khó tiêu nếu do thói quen ăn uống không lành mạnh thì không nguy hiểm, chỉ cần điều chỉnh lại chế độ ăn uống là triệu chứng sẽ hết sau một vài ngày.
Tuy nhiên nếu đầy hơi lâu ngày không khỏi, thì đó là vấn đề đáng lo, vì rất có thể bạn đã bị các bệnh tiêu hóa như:
Trào ngược dạ dày
Đại tràng co thắt
Loét dạ dày tá tràng
Bệnh dạ dày, đặc biệt là viêm loét dạ dày, nếu không điều trị, viêm loét dạ dày sẽ dẫn đến xuất huyết dạ dày và nghiêm trọng hơn là ung thư dạ dày.
Giãn thực quản, giãn thực quản lâu ngày sẽ khiến thực quản tổn thương
Ngoài ra nếu tình trạng đầy hơi kéo dài còn khiến bạn bị đau thắt ngực, đau toàn vùng bụng, hoặc buồn nôn.
Vì vậy khi có triệu chứng đầy hơi, ăn không tiêu kéo dài vài ngày, chúng ta nên đến bệnh viện hoặc phòng khám chuyên khoa tiêu hóa để được khám và điều trị kịp thời, tránh biến chứng do đầy hơi lâu ngày gây ra.
**Cách chữa chứng đầy hơi khó tiêu**
Vậy bị đầy hơi lâu ngày chúng ta phải làm sao để loại bỏ được tình trạng này?
Để giảm các triệu chứng đầy hơi trước hết người bệnh cần điều chỉnh lại chế độ ăn uống hàng ngày: ăn chậm, nhai kĩ; hạn chế tối đa các thực phẩm nhiều dầu mỡ, cay nóng, nhiều tinh bột; uống nhiều ước và ăn nhiều trái cây, rau xanh.
Sử dụng men tiêu hóa: thường khi bị đầy hơi đa số mọi người sẽ sử dụng một số loại men tiêu hóa để giảm chứng đầy hơi khó tiêu
Áp dụng các bài thuốc dân gian như uống nước chanh gừng mật ong, uống trà gừng mật ong, ăn gừng thái lát, uống trà bạc hà nóng, chườm bụng bằng túi nước nóng….
**Uống nước chanh gừng mật ong giảm triệu chứng đầy hơi khó tiêu**
Đi khám bệnh tại các bệnh viện hoặc phòng khám chuyên khoa tiêu hóa.
Các bác sĩ khuyến cáo, khi gặp chứng đầy hơi khó tiêu kéo dài nhiều ngày người bệnh cần đến ngay các bệnh viên hoặc phòng khám chuyên khoa tiêu hóa để thăm khám bệnh. Tuyệt đối không được tự ý mua các loại thuốc Đông, Tây y để điều trị vì trên thực tế đã có rất nhiều trường hợp bệnh nhân đầy hơi do xuất huyết dạ dày nhưng không đi khám mà tự tự mua thuốc điều trị tại nhà nên đã bị đe dọa nghiêm trọng đến tính mạng.
Để chẩn đoán chính xác nguyên nhân gây đầy hơi lâu ngày, các bác sĩ sẽ chỉ định làm các xét nghiệm cần thiết.
**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/) **- Đa khoa Hạng I Thành phố Hồ Chí Minh

## ️ Tài liệu tư vấn về quy trình khám sức khỏe và kiến thức dinh dưỡng

[**Xem toàn bộ tài liệu tư vấn tại đây**](https://bvnguyentriphuong.com.vn/uploads/072022/files/Tailieu_BENH%20VIEN%20NGUYEN%20TRI%20PHUONG_final.pdf)
#### Nội dung trong file:

NHỮNG ĐIỀU CẦN BIẾT
KHI ĐI KHÁM CHỮA BỆNH
TẠI BỆNH VIỆN NGUYỄN TRI PHƯƠNG
- Lưu hành nội bộ -BỆNH VIỆN NGUYỄN TRI PHƯƠNG
Năng động - Thân thiện - P hát triển
Với	truyền	thống	gần	120	năm	hình	thành	và	phát	triển.	Hiện	tại	Bệnh	viện	Nguyễn	Tri	Phương	
là	bệnh	viện	Hạng	I	trực	thuộc	Sở	Y	tế	TP.	Hồ	Chí	Minh	với	qui	mô	trên	1.000	giường	bệnh,	
Bệnh	viện	đã	thực	sự	trở	thành	địa	chỉ	khám	chữa	bệnh	đáng	ti	n	cậy	của	của	nhân	dân	thành	
phố	Hồ	Chí	Minh	và	khu	vực	lân	cận.	Mọi	hoạt	động	của	Bệnh	viện	đều	tập	trung	hướng	đến	
mục	ti	êu	“năng	động	-	thân	thiện	-	phát	triển”.
Lãnh	đạo	và	đội	ngũ	Y	bác	sĩ	luôn	tâm	niệm	“đặt	lợi	ích,	sức	khỏe	của	người	bệnh	là	mục	ti	êu	
hàng	đầu	và	cải	ti	ến	chất	lượng	liên	tục	và	lấy	sự	đánh	giá	của	người	bệnh	làm	kim	chỉ	nam;	
chăm	sóc	người	bệnh	tận	tâm,	luôn	luôn	lắng	nghe,	thấu	hiểu	và	chia	sẻ	với	thái	độ	thân	thiện,	
chuẩn	mực.”
Với	phương	châm	lấy	người	bệnh	là	“trung	tâm”,	Bệnh	viện	hiểu	rằng	khi	khám	chữa	bệnh,	tâm	
lý	của	người	bệnh	và	thân	nhân	người	bệnh	luôn	lo	lắng,	bất	an.	Để	tạo	thuận	lợi	cũng	như	
cung	cấp	kịp	thời	một	số	thông	ti	n	cơ	bản	về	quy	trình	khám	chữa	bệnh	và	một	số	khuyến	cáo	
về	dinh	dưỡng,	Bệnh	viện	biên	soạn	cuốn	“Những	điều	cần	biết	khi	đi	khám,	chữa	bệnh	tại	
Bệnh	viện	Nguyễn	Tri	Phương”.
Hy	vọng	rằng,	cuốn	cẩm	nang	này	sẽ	cung	cấp	những	thông	ti	n	hữu	ích	cho	tất	cả	nhân	dân	
khi	đến	khám	điều	trị	tại	Bệnh	viện.
Với	truyền	thống	gần	120	năm	hình	thành	và	phát	triển.	Hiện	tại	Bệnh	viện	Nguyễn	Tri	Phương	
LỜI TỰA
MỤC LỤC
01
02THÔNG TIN BỆNH VIỆN NGUYỄN TRI PHƯƠNG
NHỮNG ĐIỀU CẦN BIẾT VỀ DINH DƯỠNG TRONG 
MỘT SỐ BỆNH LÝ1. GIỚI	THIỆU	BỆNH	VIỆN
2. QUY	TRÌNH	KHÁM	BỆNH
2.1. QUY	 TRÌNH	 KHÁM	 BỆNH	 ĐỐI	 VỚI	 NGƯỜI	 BỆNH	
CÓ	THẺ	BHYT
2.2. QUY	TRÌNH	KHÁM	BỆNH	BHYT	CHO	NGƯỜI	BỆNH	CÓ	THẺ	
KHÁM	BỆNH	THÔNG	MINH
2.3. QUY	TRÌNH	KHÁM	BỆNH	NGƯỜI	BỆNH	THU	PHÍ	+	NGƯỜI	
BỆNH	KHÁM	DỊCH	VỤ
3. DỊCH	VỤ	KHÁM	BỆNH,	XÉT	NGHIỆM,	THAY	BĂNG	TẠI	NHÀ	CỦA	
BỆNH	VIỆN	NGUYỄN	TRI	PHƯƠNG
3.1. NHỮNG	ĐIỀU	CẦN	BIẾT	VỀ	DỊCH	VỤ	KHÁM	BỆNH,	XÉT	
NGHIỆM	TẠI	NHÀ	BỆNH	VIỆN	NGUYỄN	TRI	PHƯƠNG
3.2. DỊCH	VỤ	TẠI	NHÀ	CỦA	BỆNH	VIỆN	NGUYỄN	TRI	PHƯƠNG
3.3. ĐẶT	LỊCH	KHÁM	BỆNH,	XÉT	NGHIỆM	TẬN	NHÀ	TẠI	BỆNH	
VIỆN	NGUYỄN	TRI	PHƯƠNG?
4. HƯỚNG	DẪN	ĐẶT	HẸN	VỚI	BỆNH	VIỆN	NGUYỄN	TRI	PHƯƠNG
1. DINH	DƯỠNG	TĂNG	CƯỜNG	SỨC	KHỎE	KHI	MẮC	COVID-19
2. CHẾ	ĐỘ	ĂN	ĐỦ	NĂNG	LƯỢNG,	ĐẠM,	BỔ	SUNG	VI	CHẤT	Ở	
BỆNH	NHÂN	LỚN	TUỔI
3. CHẾ	ĐỘ	ĂN	MAU	LÀNH	VẾT	THƯƠNG
4. CHẾ	ĐỘ	ĂN	NƯƠNG	NHẸ	ĐƯỜNG	TIÊU	HÓA
5. ĂN	GIẢM	MUỐI,	GIẢM	ĐƯỜNG,	BÉO	BÃO	HÒA2
4
4
5
6
7
7
7
8
9
12
15
17
19
20
11THÔNG TIN
 BỆNH VIỆN NGUYỄN TRI PHƯƠNG
BỆNH VIỆN NGUYỄN TRI PHƯƠNG
Năng động - Thân thiện - P hát triển
468	Nguyễn	Trãi,	Phường	8,	Quận	5,	TP.	Hồ	Chí	Minh
(028)	39234332	-	73077307
1GIỚI THIỆU BỆNH VIỆN
1.1. NĂNG LỰC BỆNH VIỆN NGUYỄN TRI PHƯƠNG
1.2. HUY ĐỘNG NGUỒN “TRI THỨC” VIỆN - TRƯỜNG•	Thành	lập	từ	năm	1903,	đến	nay	BV	
Nguyễn	Tri	Phương	(TPHCM)	đã	trải	
qua	hơn	trăm	năm	hình	thành	và	phát	
triển.	BV	Nguyễn	Tri	Phương	đã	và	
đang	“năng	động	-	thân	thiện	-	phát	
triển”	chuyển	mình,	trở	thành	bệnh	
viện	hiện	đại,	đáp	ứng	nhu	cầu	phát	
triển	của	xã	hội.
•	Không	chỉ	sự	năng	động	và	phát	triển	chuyên	môn	qua	phương	thức	kết	
hợp	Viện	-	Trường,	huy	động	đội	ngũ	chuyên	gia	của	nhiều	chuyên	khoa	
đến	tham	gia	giảng	dạy	sinh	viên	y	khoa,	khám	chữa	bệnh	và	tham	gia	
công	tác	quản	lý,	BV	Nguyễn	Tri	Phương	còn	góp	phần	xây	dựng	hình	
ảnh	du	lịch	kết	hợp	với	y	tế	như	chủ	trương	của	UBND	TPHCM	và	Sở	Y	
tế	TPHCM	trong	thời	gian	qua.
•	Như	việc	xây	dựng	thành	công	Trung	tâm	Lọc	máu	Chất	lượng	cao	(ti	êu	
chuẩn	Nhật	Bản)	đã	giúp	nâng	cao	chất	lượng	sống	của	bệnh	nhân	bị	
bệnh	thận	mạn	tí	nh.	Điều	quan	trọng	là	đã	tạo	nên	địa	chỉ	ti	n	cậy	cho	
các	bệnh	nhân	nước	ngoài	có	bệnh	thận	mạn	tí	nh	thêm	yên	tâm	khi	đến	
Việt	Nam	du	lịch.
•	Bệnh	viện	còn	có	đầy	đủ	các	chuyên	khoa	bao	gồm	cả	chuyên	khoa	
chuyên	sâu,	có	05	mã	ngành	đào	tạo	CME	do	Bộ	Y	tế	cấp	cho	các	
chuyên	khoa	như:	Lọc	máu	-	Thần	kinh	-	Chấn	thương	Chỉnh	hình	-	Hô	
hấp.	Bệnh	viện	Nguyễn	Tri	Phương	cũng	là	nơi	đầu	ti	ên	của	cả	nước	
triển	khai	kỹ	thuật	đặt	điện	cực	vào	não	sâu	(DBS)	để	điều	trị	Parkinson	
do	khoa	Ngoại	thần	kinh	phụ	trách.
2•	Bệnh	viện	duy	trì	đầy	đủ	các	chuyên	khoa	Nội	-	Ngoại	-	Sản	-	Nhi	và	hệ	
thống	các	chuyên	khoa	lẻ,	các	chuyên	khoa	cận	lâm	sàng	bao	quát	nhu	
cầu	khám	và	điều	trị	đồng	thời	cũng	đầy	đủ	năng	lực	để	phát	triển	kỹ	
thuật	chuyên	sâu.
•	Từ	lâu,	đã	có	nhiều	chuyên	khoa	nhận	được	sự	tí	n	nhiệm	của	bệnh	nhân	
như	Nội	ti	m	mạch,	Nội	thận	-	Lọc	máu,	Nội	ti	ết,	Nội	thần	kinh	có	cả	
phòng	khám	chuyên	khoa	tâm	thần,	Cơ	xương	khớp,	Ngoại	thần	kinh,	
Chấn	thương	chỉnh	hình,	Tai	mũi	họng...
•	Bên	cạnh	đó,	BV	cũng	có	những	đơn	vị	
khám	-	điều	trị	chuyên	sâu	như	Đơn	vị	
ung	bướu	-	Ngoại	Tổng	hợp,	Đơn	vị	quản	
lý	Hen	và	COPD,	Đơn	vị	vi	sinh	-	Xét	
nghiệm,	Đơn	vị	Da	liễu	-	Thẩm	mỹ	da...
•	Các	chuyên	khoa	cận	lâm	sàng	cũng	không	
ngừng	phát	triển	hiện	đại,	trong	đó	có	thể	
kể	đến	khoa	Nội	soi	với	những	kỹ	thuật	
can	thiệp	chuyên	sâu,	khoa	Chẩn	đoán	
hình	ảnh	đầy	đủ	các	kỹ	thuật	cần	thiết...
•	Bệnh	viện	cũng	không	ngừng	đưa	vào	ứng	dụng	những	kỹ	thuật	ti	ên	
ti	ến	trong	chuyên	môn	như	việc	áp	dụng	trí	tuệ	nhân	tạo	đánh	giá	độ	
mê	tại	khoa	Gây	mê	hồi	sức	và	không	ngừng	cải	tạo	hệ	thống	cơ	sở	vật	
chất	đáp	ứng	điều	trị	tại	các	khoa	nhiều	bệnh	nặng	như	Hồi	sức	tí	ch	
cực	-	Chống	độc...
•	Phương	châm	Đông	-	Tây	y	kết	hợp	thể	hiện	rõ	qua	nhiều	hoạt	động	
khám	và	điều	trị	đa	dạng	tại	khoa	Y	học	cổ	truyền	-	Phục	hồi	chức	năng	
-	Vật	lý	trị	liệu,	cũng	sự	phương	châm	điều	trị	toàn	diện	được	thực	hiện	
bởi	sự	phối	hợp	nhịp	nhàng	giữa	nội	khoa	và	ngoại	khoa	trong	điều	trị	
nhiều	bệnh	lý:	Parkinson,	thoái	hóa	khớp,	thoái	hóa	cột	sống...
•	Trong	thời	gian	đến,	
bên	cạnh	khối	điều	
trị	các	bệnh	lý,	bệnh	
viện	 cũng	 sẽ	 đẩy	
mạnh	 về	 điều	 trị	
thẩm	mỹ	toàn	diện	
bao	 gồm	 những	
chuyên	gia	về	Thẩm	
mỹ	 ngoại	 khoa	 -	
Thẩm	mỹ	nội	khoa	
và	Da	liễu.1.3. DUY TRÌ MÔ HÌNH ĐA KHOA TOÀN DIỆN
3STT LƯU ĐỒ DIỄN GIẢI TRÁCH NHIỆM
1
2, 3
4
5
6Quẹt thẻ Bảo 
hiểm (hoặc phần 
mềm VssID) tại 
quầy Chăm sóc 
khách hàng.
Theo số thứ tự 
được gọi, bệnh 
nhân sẽ được 
đăng ký khám 
BHYT và phân 
vào phòng khám.
Khám và chẩn 
đoán bệnh.
Nhân viên 
phòng TCKT.
Nhân 
viên khoa DượcBộ phận Chăm 
sóc khách hàng.
Khoa khám bệnh.
Bác sĩ trực 
thuộc khoa.
Phòng TCKT.
Khoa DượcLẤY SỐ 
THỨ TỰ
PHÒNG 
KHÁM
THANH 
TOÁNQUYẾT 
ĐỊNH
LÃNH 
THUỐC
KẾT THÚCCÓ KQ 
CẬN LÂM 
SÀNG
CHỈ ĐỊNH 
CẬN LÂM 
SÀNGĐÓNG 
TIỀN 
KHÁM 
DỊCH VỤ
ĐÓNG 
HỒ SƠ 
BỆNH 
ÁN VÀ 
CẤP TOA 
THUỐCĐĂNG KÝ 
KHÁM BẢO 
HIỂM MUA 
SỔ KHÁM 
BỆNH ĐĂNG KÝ 
KHÁM BHYT 
DỊCH VỤ2.1. QUY TRÌNH KHÁM BỆNH ĐỐI VỚI NGƯỜI BỆNH  
        CÓ THẺ BHYT
2QUY TRÌNH KHÁM BỆNH
4STT LƯU ĐỒ DIỄN GIẢI TRÁCH NHIỆM
1
2, 3
4
5
6Người bệnh sử 
dụng thẻ khám 
bệnh thông minh 
để đăng ký vào 
phòng khám.
Người bệnh 
sẽ đăng ký 
được vào các 
phòng khám 
chuyên khoa.
Khám và chẩn 
đoán bệnh.
Nhân viên 
phòng TCKT.
Nhân viên
khoa DượcBệnh nhân tự 
đăng ký, nhân 
viên chăm sóc 
khách hàng sẽ 
hỗ trợ khi người 
bệnh có yêu cầu.
Khoa khám bệnh.
Bác sĩ trực 
thuộc khoa.
Phòng TCKT.
Khoa DượcKIOS ĐĂNG KÝ 
KHÁM BỆNH
PHÒNG 
KHÁM
THANH 
TOÁNQUYẾT 
ĐỊNH
LÃNH 
THUỐC
KẾT THÚCCÓ KQ 
CẬN LÂM 
SÀNG
CHỈ ĐỊNH 
CẬN LÂM 
SÀNGĐÓNG 
TIỀN 
KHÁM 
DỊCH VỤ
ĐÓNG 
HỒ SƠ 
BỆNH 
ÁN VÀ 
CẤP TOA 
THUỐCĐĂNG KÝ 
KHÁM BẢO 
HIỂM MUA 
SỔ KHÁM 
BỆNH ĐĂNG KÝ 
KHÁM BHYT 
DỊCH VỤ2.2. QUY TRÌNH KHÁM BỆNH BHYT CHO NGƯỜI BỆNH  
        CÓ THẺ KHÁM BỆNH THÔNG MINH
5STT LƯU ĐỒ DIỄN GIẢI TRÁCH NHIỆM
1
2, 3
4
5
6Bệnh nhân sẽ 
được đăng ký 
khám và phân 
vào phòng khám.
Khám và chẩn 
đoán bệnh.
Nhân viên 
phòng TCKT.
Nhân viên
khoa DượcBộ phận tài 
chính kế toán
Bác sĩ trực 
thuộc khoa.
Phòng TCKT.
Khoa DượcMUA SỔ ĐĂNG KÝ 
KHÁM BỆNH
PHÒNG 
KHÁM
THANH TOÁN 
TIỀN THUỐCQUYẾT 
ĐỊNH
LÃNH THUỐC
KẾT THÚCCÓ KQ 
CẬN LÂM 
SÀNG
THANH 
TOÁN CẬN 
LÂM SÀNG
CHỈ ĐỊNH 
CẬN LÂM 
SÀNGĐÓNG 
HỒ SƠ 
BỆNH 
ÁN VÀ 
CẤP TOA 
THUỐC
2.3. QUY TRÌNH KHÁM BỆNH NGƯỜI BỆNH THU PHÍ  
        + NGƯỜI BỆNH KHÁM DỊCH VỤ
6•	Nhằm	phục	vụ	như	cầu	của	
đông	đảo	người	bệnh	về	dịch	vụ	
y	tế	ti	ện	ích,	giảm	thời	gian	chờ	
đợi,	thuận	ti	ện	hơn	với	những	
bệnh	nhân	khó	di	chuyển,	nhà	
neo	người,	bệnh	viện	đã	triển	
khai	nhiều	dịch	vụ	tại	nhà.
•	Chỉ	một	cuộc	điện	thoại,	nhân	viên	sẽ	đến	tận	nhà	để	lấy	mẫu,	kết	quả	
đến	tay	người	khám	ngay	trong	ngày.	Không	còn	cảnh	xếp	hàng,	không	
còn	những	mệt	mỏi	phiền	hà	vì	ảnh	hưởng	công	việc.	Nhất	là	khi	dịch	
bệnh	COVID-19	khiến	mọi	người	không	muốn	ra	khỏi	nhà,	đến	những	
nơi	đông	người.
•	Đồng	thời,	gia	đình	và	người	bệnh	có	thể	yên	tâm	về	chất	lượng	xét	
nghiệm.	Bởi	khoa	Xét	nghiệm	của	bệnh	viện	đã	được	nâng	cấp	đạt	
chuẩn	an	toàn	sinh	học	cấp	2	-	ứng	dụng	5S	để	giúp	sự	sắp	xếp	hợp	lý,	
bảo	đảm	sạch	sẽ	và	ngăn	nắp.	An	toàn	sinh	học	cấp	2	là	ti	êu	chuẩn	cho	
khoa	xét	nghiệm	của	các	bệnh	viện	loại	1	của	TPHCM,	gồm	nhiều	ti	êu	
chuẩn	giúp	bảo	đảm	an	toàn	cho	nhân	viên	y	tế	và	chất	lượng	của	mẫu	
xét	nghiệm	cho	bệnh	nhân.
•	Theo	đó,	với	dịch	vụ	lấy	mẫu	xét	nghiệm	tại	nhà,	bệnh	viện	có	thể	thực	
hiện	từ	cơ	bản	(đường	máu,	mỡ	máu,	men	gan,…)	đến	chuyên	sâu	(marker	
ung	thư,	xét	nghiệm	miễn	dịch…),	luôn	đảm	bảo	chính	xác	nhất	và	nhanh	
chóng	nhất	để	rút	ngắn	thời	gian	chờ	đợi,	giá	cả	hợp	lý	niêm	yết	rõ	ràng.
•	Mặt	khác,	những	kết	quả	xét	nghiệm	này	sẽ	được	Bệnh	viện	Nguyễn	Tri	
Phương	lưu	trữ	và	truy	xuất	khi	người	bệnh	có	nhu	cầu.
•	Dịch	vụ	khám	tại	nhà	bao	gồm	khám	tổng	quát	và	
khám	chuyên	khoa.	Trong	đó,	khám	tổng	quát	là	
với	các	trường	hợp	người	bệnh	lớn	tuổi,	yếu	hoặc	
có	vấn	đề	khó	di	chuyển,	không	có	vấn	đề	sức	
khoẻ	nào	cần	đặc	biệt	chú	ý,	muốn	được	bác	sĩ	
đến	khám,	tầm	soát	và	tư	vấn	các	vấn	đề	về	sức	
khoẻ	nói	chung.3.1. NHỮNG ĐIỀU CẦN BIẾT VỀ DỊCH VỤ KHÁM BỆNH, XÉT  
        NGHIỆM TẠI NHÀ BỆNH VIỆN NGUYỄN TRI PHƯƠNGDỊCH VỤ KHÁM BỆNH, XÉT NGHIỆM, 
THAY BĂNG TẠI NHÀ CỦA BỆNH VIỆN 
NGUYỄN TRI PHƯƠNG
3
3.2. DỊCH VỤ TẠI NHÀ CỦA BỆNH VIỆN NGUYỄN TRI PHƯƠNG
7	−Vết	thương	nhiễm	khuẩn:	thuờng	có	tình	trạng	viêm	như	sưng	-	nóng	
-	đỏ	-	đau	và/hoặc	kèm	theo	các	dấu	hiệu	khác	của	nhiễm	khuẩn	như	
chảy	nước,	chảy	mủ,	bốc	mùi	hôi...	Vết	thương	nhiễm	khuẩn	dù	xảy	
ra	ở	một	vết	thương	đơn	giản	hay	phức	tạp,	đều	cần	được	theo	dõi	
cẩn	thận.	Do	đó,	khi	đến	khám	tại	nhà,	nhân	viên	y	tế	chăm	sóc	vết	
thương	sẽ	có	đánh	giá	tiên	lượng;	và	nếu	như	cần	thiết	sẽ	bạn	nên	
nhập	viện	để	đảm	bảo	sức	khoẻ	của	mình	khi	có	khuyến	cáo.
	−Vết	thương	phức	tạp	thường	rộng	hoặc	nếu	mổ	là	vết	mổ	thì	thường	
dài>5cm	hoặc	nhiều	đường	cắt.	Vết	thương	phức	tạp	đòi	hỏi	nhiều	
hơn	về	công	sát	khuẩn,	vật	tư	y	tế	tiêu	hao	(bông,	gạc...).	Nếu	có	
nhiễm	khuẩn	sẽ	đòi	hỏi	việc	chăm	sóc	phải	kéo	dài	hoặc	cần	dùng	
thuốc	bổ	sung;	trong	một	số	trường	hợp	sẽ	cần	có	bác	sĩ	đến	trực	
tiếp	thăm	khám	 và	kê	đơn	phù	hợp.
	−Vết	thương	đơn	giản	thuờng	là	vết	cắt	ngắn,	nhỏ	hoặc	nếu	vết	mổ	thì	
thường	là	vết	cắt	gọn	dạng	một	đường	thẳng	không	quá	5cm,	không	
dấu	hiệu	nhiễm	trùng	(tấy	đỏ,	mưng	mủ...).	Vết	thương	đơn	giản	đòi	
hỏi	vấn	đề	sát	trùng	cũng	như	dụng	cụ	tiêu	hao	(băng,	gạc...)	không	
quá	nhiều,	nên	chi	phí	chăm	sóc	 và	thay	băng	cũng	không	quá	cao.
	−Với	dịch	vụ	lấy	mẫu	xét	nghiệm	tại	nhà,	bệnh	viện	xây	dựng	nhiều	gói	
khám	khác	nhau	để	theo	dõi	các	vấn	đề	về	tim	mạch,	gan,	tuyến	giáp,	
bệnh	khớp,	giun	sán,	nội	tiết	tố...	Thông	thường,	nếu	bạn	lấy	mẫu	xét	
nghiệm	buổi	sáng	thì	buổi	chiều	có	kết	quả.	Nhân	viên	y	tế	sẽ	trả	kết	
quả	tận	nhà.
•	Một	là	truy	cập	website	http://khamtainha-bvntp.com/.	 Sau	đó	điền	đầy	
đủ	thông	tin	cá	nhân	(họ	tên,	số	điện	thoại,	email,	địa	chỉ),	nhu	cầu	(khám	
tại	nhà,	lấy	mẫu	xét	nghiệm	tại	nhà,	thay	băng,	dịch	vụ	khác	và	nhấn	
đăng	ký.	Nhân	viên	y	tế	Bệnh	viện	Nguyễn	Tri	Phương	sẽ	xác	nhận	thông	
tin	và	liên	hệ	lại	với	bạn.
•	Hai	là	gọi	điện	đến	tổng	đài	của	Bệnh	viện	(028	7307	7307)	để	xin	gặp	
bộ	phận	phụ	trách.•	Khám	chuyên	khoa	là	khi	bệnh	nhân	đã	điều	
trị	ổn	định	một	hay	nhiều	bệnh	lý	cụ	thể,	
muốn	có	bác	sĩ	có	chuyên	khoa	đến	thăm	
khám,	tư	vấn,	điều	trị	về	vấn	đề	sức	khoẻ.	
Hiện	nay,	Bệnh	viện	Nguyễn	Tri	Phương	cung	
cấp	khám	chuyên	khoa	tại	nhà:	Tim	mạch,	
Nội	tiết,	Hô	hấp,	Thận,	Tiêu	hoá,	Ngoại	Chấn	
thuơng	chỉnh	hình,	Ngoại	 Tổng	quát…
•	Với	dịch	vụ	thay	băng	tại	nhà:
3.3. ĐẶT LỊCH KHÁM BỆNH, XÉT NGHIỆM TẬN NHÀ TẠI
        BỆNH VIỆN NGUYỄN TRI PHƯƠNG
8•	Bệnh	viện	Nguyễn	Tri	Phương	chính	là	đối	tác	lớn	
hiện	tại	của	GlobeDr.	Từ	ngày	11.01.2021,	khi	người	
dùng	có	nhu	cầu	muốn	ĐẶT	HẸN	khám	bệnh	hay	
tái	khám	tại	bệnh	viện	có	thể	thực	hiện	qua	ứng	
dụng	GlobeDr.
•	Khi	đặt	hẹn	với	bệnh	viện	Nguyễn	Tri	Phương	qua	
ứng	dụng,	bạn	có	thể:
−Trong	giai	đoạn	đầu,	người	dân	có	thể	đặt	hẹn	các	dịch	vụ	Khám	lần	
đầu	và	Tái	khám	tại	bệnh	viện.	Nhưng	tương	lai,	còn	hứa	hẹn	có	thể	
thực	hiện	với	nhiều	loại	hình	khám	bệnh	khác	nhau	như	khám	tại	nhà,	
khám	ngoài	giờ,	khám	dịch	vụ	VIP,	lấy	mẫu	xét	nghiệm	tại	nhà…
−Khi	đặt	hẹn,	được	lựa	chọn	Chuyên	khoa	khám	-	ngày	khám	–	buổi	
khám	–	giờ	khám	(tùy	thuộc	vào	loại	hình	đặt	hẹn).
•	Để	ti	ến	hành	đặt	hẹn	khám	bệnh	với	bệnh	viện	Nguyễn	Tri	Phương,	bạn	
thực	hiện	các	bước	sau:
HƯỚNG DẪN ĐẶT HẸN VỚI BỆNH VIỆN 
NGUYỄN TRI PHƯƠNG
4
9•	Để	tiến	hành	thanh	toán	đặt	hẹn	khám	bệnh	với	bệnh	viện	Nguyễn	Tri	
Phương,	bạn	thực	hiện	các	bước	sau:
CÁC PHƯƠNG THỨC THANH TOÁN:CÁC BƯỚC THỰC HIỆN
THANH TOÁN TẠI ĐIỂM GIAO DỊCHTHANH TOÁN BẰNG VÍ PAYOO HOẶC TÀI KHOẢN NGÂN HÀNG
ỨNG DỤNG
PAYOOTHẺ NỘI ĐỊA
(Vietcombank,	BIDV,	
VietinBank,	Sacombank,...)
THẺ QUỐC TẾ
(Visa,	Mastercard,	 JCB)
Quét	mã	QR	nhận	được	 với	ví	điện	tử	hoặc	ứng	dụng	ngân	hàngTHANH TOÁN BẰNG MÃ QR
20.000+  cửa hàng liên kết với   phục vụ cả ngoài giờ hành 
chính, thứ 7 và chủ nhật
10•	Sau	khi	đặt	hẹn	thành	công,	đến	đúng	ngày	hẹn	và	buổi	hẹn,	bạn	hãy	đến	
Lầu	1	khu	A	–	khoa	Khám	bệnh	dịch	vụ,	tại	quầy	đăng	ký	đặt	cạnh	quầy	
hướng	dẫn	để	được	hướng	dẫn	 và	cung	cấp	dịch	 vụ	tốt	nhất.
•	Chúng	tôi	hy	vọng	rằng,	với	
sự	hợp	tác	giữa	GlobeDr	
và	Bệnh	viện	Nguyễn	Tri	
Phương	sẽ	mang	lại	sự	
thuận	tiện	hơn	cho	đông	
đảo	người	dân.	Trong	quá	
trình	sử	dụng,	có	thể	gặp	
phải	những	vấn	đề	ngoài	
ý	muốn,	vì	vậy	chúng	tôi	
mong	sẽ	nhận	được	sự	đóng	
góp	từ	người	dùng	để	quy	trình	đặt	hẹn	được	vận	hành	trơn	tru,	hoàn	
thiện	hơn.
•	Việc	thanh	toán	tiền	khám	bệnh	qua	GlobeDr	App	sẽ	góp	phần	hạn	chế	
sử	dụng	tiền	mặt	và	đỡ	mất	thời	gian	phải	đóng	tiền	trực	tiếp	tại	bệnh	
viện.	Khi	khách	hàng	đã	đóng	tiền	mà	không	sử	dụng	các	dịch	vụ	khám	
bệnh,	vui	lòng	phản	ảnh	trong	vòng	30	ngày	để	hệ	thống	có	thể	thực	
hiện	quy	trình	hoàn	trả	lại	tiền.	Mọi	thông	tin	chi	tiết	về	khám	bệnh	và	
dịch	vụ	khách	hàng	của	Bệnh	viện	Nguyễn	Tri	Phương	có	thể	tham	khảo	
tại	trang	https://bvnguyentriphuong.com.vn/.	
•	Mọi	thắc	mắc	cần	giải	đáp	hay	gặp	phải	các	vấn	đề	kỹ	thuật,	xin	vui	lòng:
	−Gọi	đến	Tổng	đài	CSKH	của	GlobeDr,	số	điện	thoại	(028)	7300	6880	
để	được	hỗ	trợ,	hoặc
	−Inbox	vào	trang	https://www.facebook.com/Bacsitoancau,	hoặc
	−Inbox	vào	trang	https://www.facebook.com/BVNTP/
11Chế	 độ	 dinh	 dưỡng	 tốt	
kết	hợp	với	vận	động	giúp	
duy	trì	khối	cơ	và	nâng	cao	
miễn	dịch,	tăng	cường	sức	
khỏe	chung,	giảm	nguy	cơ	
mắc	bệnh	và	mau	hồi	phục	
bệnh.	Hệ	thống	y	tế	giảm	
gánh	nặng	về	nguồn	lực	và	
chi	phí,	tạo	điều	kiện	tốt	
chăm	sóc	sức	khỏe	cho	
người	dân.
•	Đảm	bảo	đủ	các	và	đa	dạng	các	
nhóm	thực	phẩm	bao	gồm:	nhóm	
ti	nh	bột,	nhóm	sữa	và	chế	phẩm	
sữa,	nhóm	dầu	mỡ,	nhóm	rau	củ,	
nhóm	thịt	cá,	nhóm	trứng,	nhóm	
các	loại	hạt,	nhóm	rau	củ	màu	
vàng-xanh	thẫm.
•	Không	bỏ	bữa:	Ăn	đủ	3	bữa	chính	và	tăng	cường	thêm	các	bữa	phụ.
•	Không	kiêng	khem	thực	phẩm	nếu	không	có	dị	ứng	thực	phẩm	hoặc	
theo	lời	khuyên	riêng	của	bác	sĩ
•	Với	người	mắc	bệnh:	cần	thực	hiện	đúng	chế	độ	dinh	dưỡng	phù	hợp	
bệnh	lý	theo	sự	tư	vấn	của	cán	bộ	dinh	dưỡng	(ti	ết	chế	dinh	dưỡng	viên),	
hoặc	bác	sỹ.
•	Uống	đủ	nước	và	thực	hiện	uống	
nước	đúng	cách:	cầ	n	uống	30-
35ml	nước/	kg	cân	nặng	(Ví	dụ:	
Một	người	50	kg	cần	uống	gần	2	
lít	nước	trong	ngày).	Uố	ng	từ	từ,	
từ	ng	ngụm	nhỏ	và		chia	đề	u	trong	
ngà	y,	ngay	cả		khi	không	khá	t.	
Không	uống	nước	nhiều	trước	
khi	đi	ngủ,	không	uống	nước	
ngọt,	rượu	bia	thay	nước	lọc.
DINH DƯỠNG TĂNG CƯỜNG SỨC KHỎE 
KHI MẮC COVID-19
1NHỮNG ĐIỀU CẦN BIẾT VỀ DINH DƯỠNG 
TRONG MỘT SỐ BỆNH LÝ
DINH DƯỠNG HỢP LÝ
12
13•	Mức	năng	lượng	1500-	1600	kcal/ngày
• Thực đơn chế độ cơm:
	−Trường	hợp	người	bệnh	bổ	sung	thêm	1	cốc	sữa	250	ml	(sữa	năng	
lượng	chuẩn	1ml/1	kcal)	thì	ăn	giảm:	nửa	bát	con	cơm,	5-6	miếng	
thịt	lợn	nhỏ	và	1	thìa	cafe	dầu	 ăn	5ml.THỰC ĐƠN CƠM MẪU CHO NGƯỜI CÂN NẶNG 50-55 KG
BỮA SÁNG
	−Phở	thịt	gà	gồm:	1	chén	bánh	phở	150g	(phở	ngang	miệng	chén),	thịt	
gà	40g	(4	miếng	cắt	lát	mỏng	to	bằng	hai	ngón	tay),	giá	trụng	nửa	
chén,	1	muỗng	cà	phê	dầu	 ăn	5ml.
BỮA TRƯA
	−Cơm,	thịt	gà	rang	gừng,	rau	xào	gồm:	cơm	240g	(2	chén	cơm	lưng),	
thịt	gà	110g	(4	miếng	gà	cả	xương	to	bằng	ba	ngón	tay),	rau	150g	(1	
chén	rau,	rau	ngang	miệng	chén),	dầu	 ăn	1,5	muỗng	cà	phê	7ml
BỮA TỐI
	−Cơm,	cá	phi	lê	chiên	xù,	thịt	heo	luộc,	rau	luộc	gồm:	cơm	240g	(2	
chén	cơm	lưng),	cá	rô	phi	50g	(2	miếng	to	bằng	3	ngón	tay),	thịt	heo	
40g	(4	miếng	cắt	lát	mỏng	to	bằng	hai	ngón	tay),	rau	150g	(rau	đầy	
ngang	miệng	chén),	dầu	 ăn	7mlBỮA PHỤ SÁNG
	−Quả	lê	110g	(nửa	quả	nhỏ)
BỮA PHỤ CHIỀU
	−Quả	na	103g	(nửa	quả	 vừa)
• Bên cạnh chế độ ăn hợp lý, xây dựng lối sống, tập luyện sinh hoạt lành 
mạnh (HCDC)
	−	Vận	động	thường	xuyên	(chỉ	cần	30	phút/	ngày	bằng	bất	cứ	cách	nào	
bạn	thích,	ví	dụ:	đi	bộ,	tập	thể	dục 	tại	nhà,	tập	ngoài	sân)
	−Ngủ	đủ	giấc	(7-8	giờ/	đêm)	nên	đi	ngủ	trước	10	giờ	và	thức	dậy	sau	
5	giờ	sáng
	−Giữ	tinh	thần	lạc	quan,	tập	hít	thở	đều	trước	khi	ngủ	để	giảm	
căng	thẳng.
	−Rửa	tay	thường	xuyên	bằng	xà	phòng,	nước	sát	khuẩn	và	tránh	đưa	
tay	lên	mắt,	mũi,	miệng
	−Không	hút	thuốc	lá.	Hạn	chế	và	ngưng	uống	rượu	bia.
14Người	lớn	tuổi	dễ	bị	suy	dinh	dưỡng	
hơn	người	trẻ	tuổi	do	mắc	các	bệnh	mạn	
tí	nh	và	kèm	theo	nhiều	vấn	đề	liên	quan	
đến	ti	êu	hóa.	Chăm	sóc	dinh	dưỡng	phù	
hợp	giúp	người	bệnh	cải	thiện	cân	nặng,	
tăng	khối	cơ,	tăng	cường	miễn	dịch	và	
hồi	phục	bệnh,	nâng	cao	chất	lượng	
cuộc	sống.
• Bệnh nhân lớn tuổi thường gặp nhiều vấn đề liên quan đến dinh dưỡng: 
Giảm	vị	giác,	lạt	miệng,	có	cảm	giác	không	đói,	chán	ăn;	Ăn	kém	đi	do	
mệt,	thở	khó,	sốt,	đau;	Nhai	khó	do	thiếu	răng,	nuốt	đau,	nuốt	khó;	
• Làm cho người bệnh dễ bị: Thiếu	hụt	dinh	dưỡng,	sụt	cân	nhanh	và	
nhiều;	Suy	dinh	dưỡng	nặng,	yếu	sức	(suy	kiệt);	Thiếu	hụt	vi	chất,	gây	
loãng	xương,	dễ	bị	gãy	xương	do	té	ngã;	Chậm	hồi	phục,	nằm	viện	kéo	
dài	và	tăng	chi	phí	điều	trị
• Chăm sóc dinh dưỡng phù hợp và sớm giúp người bệnh: Cải	thiện	cân	
nặng,	khối	cơ;	Tăng	cường	miễn	dịch,	sức	cơ,	sức	khỏe	chung	và	hồi	
phục	bệnh.
• Nguyên tắc dinh dưỡng: Cung	cấp	đủ	năng	lượng,	chất	đạm	và	vi	chất	
cho	cơ	thể
−Ăn	đủ	đạm:	200-250g	thịt/	ngày,	hoặc	300g	cá	hoặc	tôm/	ngày
−	Không	bỏ	bữa:	Ăn	đủ	3	bữa	chính	và	1-3	cử	phụ	
−	Nên	ăn	dầu	thực	vật	(dầu	mè,	dầu	
nành,	oliu...)	và	cá	béo.	Hạn	chế	ăn	
mỡ	heo	bò	gà,	da,	lòng	(gan,	óc	...).	
−	Nên	ăn	thực	phẩm	cung	cấp	bột	
đường	từ	ti	nh	bột	như	gạo	còn	
cám,	khoai	củ,	ngũ	cốc…	Hạn	chế	
ăn	thực	phẩm	ngọt	như	bánh	kẹo,	
mứt,	chè,	kem…	
−	Chú	ý	dùng	thực	phẩm	tươi,	đặc	biệt	rau	và	trái	cây,	ăn	khoảng	300-
500	gram	một	ngày.	Ăn	lạt	nếu	có	tăng	huyết	áp,	suy	ti	m,	suy	thận…	
−	Uống	đủ	nước	nếu	không	có	chỉ	định	hạn	chế	nước	từ	bác	sĩ.	Uống	
1,5	–	2	lít/	ngày,	từ	nước	đun	sôi	để	nguội,	nước	trà,	nước	canh	trong	
bữa	ăn,	sữa…
CHẾ ĐỘ ĂN ĐỦ NĂNG LƯỢNG, ĐẠM, BỔ 
SUNG VI CHẤT Ở BỆNH NHÂN LỚN TUỔI
2
VÌ SAO CẦN CHĂM SÓC DINH DƯỠNG Ở NGƯỜI LỚN TUỔI?
15
•	Cung	cấp	canxi	từ	bữa	ăn	hàng	ngày	giúp	phòng	ngừa	loãng	xương:	Cá	
biển	(3-5	lần/	tuần),	Đậu	hũ	(2-3	lần/	tuần),	Trứng	(1-3	lần/	tuần),	Sữa	
(1-2	lần/	tuần),	Yaourt	(1-2	lần/	tuần),	Phô	mai	(1-3	lần/	tuần),	Rau	củ	
quả	(3	lần/	tuần),	Mè	(1-2	lần/	tuần)
•	Ăn	đủ	vitamin	D:	giúp	tăng	cường	hấp	thu	canxi	và	cải	thiện	độ	chắc	
khỏe	của	xương.	Sử	dụng	thực	phẩm	giàu	vitamin	D	như:	cá,	gan	cá,	
trứng	cá,	lòng	đỏ	trứng.	Tập	thể	dục	mỗi	ngày	đều	đặn	30	phút	và	phơi	
nắng	giúp	xương	chắc	khỏe	và	tổng	hợp	thêm	vitamin	D.
•	Những	thực	phẩm	làm	tăng	thải	canxi	
qua	nước	ti	ểu	và	giảm	hấp	thu	canxi:	
thực	phẩm	chứa	nhiều	muối	như:	tương,	
chao,	khô,	mắm…	giảm	nêm	gia	vị	mặn	
(muối,	nước	mắm,	nước	tương…);	Nước	
ngọt	có	gas;	Rượu,	bia,	trà,	cà	phê.
•	Nếu	người	lớn	tuổi	ăn	ít	hơn	một	nửa	số	cử	ăn	và	số	lượng	thức	ăn	so	
với	lúc	bình	thường,	kèm	theo	thời	gian	kéo	dài	trên	1	tuần,	thì	nên	đi	
gặp	bác	sĩ	để	khám	bệnh	và	tư	vấn	chế	độ	ăn	và	cách	ăn	phù	hợp.
THỰC ĐƠN MỀM KÈM SỮA CHO NGƯỜI KHOẢNG 45-50 KG
BỮA SÁNG
−Bún	mọc	gồm:	Bún	170g	(1,5	chén	lưng);	Mọc	(mộc	nhĩ	1	cái	tai	nhỏ,	
nấm	hương	1	cái,	50g	thịt	bằng	khoảng	5	viên	mọc	vừa);	1	muỗng	cà	
phê	dầu	ăn	5ml,	ăn	kèm	rau	thơm,	hành	lá.
BỮA TRƯA
−Phở	bò	gồm:	Phở	170g	(1,5	chén	lưng),	Thịt	bò	50g	(8	miếng	thái	mỏng	
to	bằng	2	ngón	tay),	Rau	thơm,	hành	lá,	1	muỗng	cà	phê	dầu	ăn	5ml.
BỮA TỐI
−Cháo	gà	bí	ngô	gồm:	Gà	40g	(4	miếng	cắt	lát	mỏng	to	bằng	hai	ngón	
tay);	2	chén	cháo	đặc	400ml	(gạo	2	nắm	tay);	Bí	ngô	10g	(2	miếng	to	
bằng	2	ngón	tay);	1	muỗng	cà	phê	dầu	ăn	5ml.BỮA PHỤ SÁNG
−Sữa	chua	có	đường	01	hộp	100g;	xoài	chín	100g	(1	má	xoài,	quả	vừa)
BỮA PHỤ TỐI
−1	ly	sữa	bột	200ml	(1	kcal/1ml)	hoặc	1	chai	sữa	nước	pha	sẵn	200-235ml.BỮA PHỤ CHIỀU
−Trái	cây	như	thanh	long	180g	(nửa	quả	vừa)
16
Sau	khi	phẫu	thuật	hoặc	bị	vết	thương	do	tai	nạn,	bạn	cần	thay	đổi	chế	độ	
ăn	để	đẩy	nhanh	tốc	độ	hồi	phục,	giúp	mau	lành	vết	thương	và	có	thể	quay	
về	với	cuộc	sống	bình	thường	nhanh	chóng.
LƯU Ý VỀ CHẾ ĐỘ ĂN MAU LÀNH VẾT THƯƠNG
Khi	có	vết	thương	do	phẫu	thuật	hoặc	tai	
nạn,	cơ	thể	tăng	nhu	cầu	năng	lượng	rất	
nhiều,	giúp	cơ	thể	chống	lại	vi	khuẩn,	tăng	
tái	tạo	lại	mô	và	lành	vết	thương.	Nhu	cầu	
năng	lượng	khác	nhau	giữa	mỗi	người,	tuy	
nhiên	không	thấp	hơn	lượng	ăn	lúc	khỏe.	
Năng	lượng	cơ	thể	lấy	từ	ti	nh	bột,	chất	
đạm	và	chất	béo,	nên	cần	ăn	tăng	cường	
cả	3	nhóm	thực	phẩm	này.Đủ năng lượng1
Góp	phần	quá	trình	tạo	collagen,	kích	thích	hình	thành	lớp	da	mới.	Vit	C	có	
nhiều	trong	trái	cây	có	vị	chua	và	rau	có	màu	xanh:	Ổi,	cam,	chanh,	dâu	tây,	
khoai	tây,	cà	chua,	bông	cải,	ớt	chuông	và	các	loại	rau	khác.Giàu Vitamin C3
Chất	chống	oxy	hóa	tự	nhiên	và	kích	thích	quá	trình	tạo	mới	collagen,	mau	
lành	vết	thương.	Vit	A	có	nhiều	trong	trứng,	sữa,	các	loại	củ	quả	có	màu	
vàng	hoặc	cam,	rau	có	màu	xanh	đậm.Giàu Vitamin A4
Kích	thích	quá	trình	chữa	lành	vết	thương,	góp	phần	vào	tăng	cường	hệ	
miễn	dịch,	và	chống	nhiễm	trùng.	Kẽm	có	nhiều	trong	thịt	đỏ,	hải	sản.Giàu kẽm5
Chống	nhiễm	trùng	và	tăng	nhanh	tổng	hợp	đạm,	giúp	lành	vết	thương	
nhanh	hơn.	Có	nhiều	trong	thịt	gà,	thịt	bò,	cá,	tôm,	sữa	và	đậu	nành.Arginine6
3CHẾ ĐỘ ĂN MAU LÀNH VẾT THƯƠNG
Đóng	vai	trò	quan	trọng	trong	việc	làm	
nguyên	liệu	để	hồi	phục	vết	thương,	nếu	
thiếu	đạm	việc	lành	vết	thương	sẽ	chậm	Giàu đạm2
chạp,	không	hiệu	quả,	khả	năng	teo	cơ	các	vùng	khác	để	huy	động	nguyên	
liệu	đến	vết	thương,	gây	giảm	miễn	dịch,	kéo	dài	thời	gian	nằm	viện.	Nên	ăn	
ít	nhất	200gr	thịt/cá	trong	một	ngày.
17•	4	chén	cháo	+	1-2	cử	sữa	chuẩn	hoặc	3	chén	cơm	+	1-2	cử	sữa	chuẩn.
•	Trái	cây	như	cam,	xoài	chín,	nho,	chuối,	na,	dưa	hấu	…	khoảng	200gr/ngày.
•	Rau	củ	tươi	các	loại	khoảng	300gr/ngày.
•	Rau	quả,	trái	cây	cung	cấp	nhiều	vitamin,	khoáng	chất,	chất	chống	oxi	
hóa	cho	cơ	thể.
•	Trường	hợp	người	bệnh	bổ	sung	thêm	1	cốc	sữa	250	ml	(sữa	năng	lượng	
chuẩn	1ml/1	kcal)	thì	ăn	giảm:	nửa	chén	cơm,	5-6	miếng	thịt	heo	cắt	lát	
mỏng	và	1	muỗng	cafe	dầu	ăn	5ml.Thực đơn cho người 55 - 60 kg, cần mức năng lượng cao 
1800 - 2000 kcal/ngày
BỮA SÁNG
−Bún	thịt	nạc	gồm:	bún	2	chén	lưng,	Thịt	nạc	60g	(6	miếng	cắt	lát	mỏng	
to	bằng	hai	ngón	tay),	Dầu	ăn	1	muỗng	cà	phê	5ml,	rau	trụng	1	chén.
BỮA TRƯA
−Cơm,	cá	trắm	kho,	chả	lá	lốt,	rau	luộc	gồm:	Cơm	280g	(khoảng	gần	2	
chén	đầy),	Cá	trắm	70g	(1	khúc	trung	bình),	Thịt	40g	(2	muỗng	canh	
đầy),	Rau	150g	(1	chén	lưng),	Dầu	ăn	1,5	muỗng	cà	phê	7ml
BỮA TỐI
−Cơm,	thịt	ba	chỉ	kho,	đậu	luộc,	rau	xào	gồm:	Cơm	280g	(khoảng	gần	
2	chén	đầy),	Thịt	ba	chỉ	60g	(6	miếng	cắt	lát	mỏng	to	bằng	hai	ngón	
tay),	Đậu	phụ	70g	(1	bìa	vừa),	Rau	150g	(1	chén	lưng),	Dầu	ăn	1,5	
muỗng	cà	phê	7mlBỮA PHỤ SÁNG
−Quả	táo	tây	100g,	khoảng	nửa	quả	kích	thước	trung	bình	(7x4cm)
BỮA PHỤ CHIỀU
−110g	dưa	hấu	(1	chén	lưng)CHẾ ĐỘ ĂN CẦN ĐẠT ĐỦ NĂNG LƯỢNG, ĐẠM, VITAMIN 
VÀ KHOÁNG CHẤT
18Khi	mắc	bệnh	viêm	dạ	dày,	viêm	ruột,	viêm	đại	tràng…,	đường	ti	êu	hóa	của	
bạn	bị	tổn	thương,	giảm	chức	năng,	gây	các	triệu	chứng	như:	nôn	ói,	ti	êu	
chảy,	ợ	hơi,	ợ	chua…	dẫn	đến	sụt	cân	và	suy	nhược	cơ	thể.	Chế	độ	ăn	nương	
nhẹ	đường	ti	êu	hóa	giúp	cung	cấp	bữa	ăn	dễ	ti	êu,	giảm	gánh	nặng	đường	
ruột	mà	vẫn	đủ	dinh	dưỡng,	giúp	người	bệnh	phục	hồi.
•	Ăn	nhiều	bữa	trong	ngày:	bạn	nên	ăn	6-7	bữa	trở	lên	trong	ngày,	mỗi	
bữa	ăn	không	quá	100	ml	(=	½	chén),	giúp	dễ	ti	êu	hóa	hơn,	tránh	nôn	ói	
ngay	sau	ăn.
•	Nhai	kỹ	thức	ăn	giúp	hệ	ti	êu	hóa	không	phải	làm	việc	nhiều,	mau	lành.
•	Uống	nhiều	nước	mỗi	ngày	1,5	–	2	lít,	có	thể	nhiều	hơn	khi	có	ti	êu	chảy.	
Uống	đủ	nước	tránh	khô	miệng,	ăn	không	ngon,	khó	ti	êu,	táo	bón	và	
giúp	dễ	ngủ	hơn.
• Lựa chọn thực phẩm giúp dễ ăn, dễ ti  êu hóa, đủ dinh dưỡng:
−Thực	phẩm	ít	mùi	vị	như:	cơm	nát,	bánh	mỳ,	các	loại	khoai	củ,	cháo,	
bánh	quy,	bánh	bông	lan,	sắn	dây	khuấy	chín...
−Thực	phẩm	giàu	đạm	(thịt,	cá	nạc	nên	chế	biến	luộc,	hấp,	om	thì	
dễ	hấp	thu).
−Sữa,	trứng	có	tác	dụng	đệm	trung	hòa	acid	trong	dạ	dày:	Sữa	bò,	sữa	
hộp,	bơ,	phô	mai.	Nếu	có	ti	êu	chảy	thì	tạm	ngưng	dùng	sữa.
−Rau	củ	dùng	rau	non,	mềm	như	rau	đay,	rau	mồng	tơi,	rau	dền	luộc…	
hoặc	nấu	dạng	súp,	các	loại	rau	củ	phải	ăn	chín
−Ăn	trái	cây	chín,	mềm,	mọng	nước	như	xoài	chín,	thanh	long	chín,	bơ	
chín,	lựu,	dâu	tây,...
• Điều nên tránh, vì kích thích đường ti  êu hóa, gây khó ti  êu, chướng bụng:
−Các	loại	thịt	nguội	chế	biến	sẵn:	Dăm	bông,	lạp	xưởng,	xúc	xích	và	
các	loại	nước	sốt,	nước	thịt	cá	đậm	đặc,	hạn	chế	nước	hầm	thịt
−Những	thức	ăn	nhiều	mùi	vị,	chất	thơm	như	thịt	quay,	rán,	nướng,	
thịt	ướp	muối,	cá	ướp	muối	và	những	thức	ăn	xào	rán	nhiều	dầu	mỡ
−Sữa	chua,	quả	chua,	đu	đủ	chín,	chuối	ti	êu,	táo,	nho,	dưa	hấu,	kiwi.
−Gia	vị,	dấm	tỏi,	ti	êu	ớt,	dưa	cà,	hành	muối.
−Những	thức	ăn	cứng,	dai	gây	cọ	sát	niêm	mạc	dạ	dày	như:	Thịt	nhiều	
gân,	sụn,	rau	có	nhiều	xơ	già,	quả	sống…
−Hạn	chế	các	loại	rau	sinh	hơi	như,	súp	lơ	xanh,	bắp	cải,	củ	hành,	cải	
hoa,	dưa	leo,	ti	êu,	bắp,	củ	cải,	dưa	cải,	dưa	chuột,	măng	tây,	đậu	khô.
−Nước	uống	có	gas,	bia,	cà	phê.
4CHẾ ĐỘ ĂN NƯƠNG NHẸ ĐƯỜNG TIÊU HÓA
CÁC HƯỚNG DẪN VỀ CHẾ ĐỘ ĂN
195ĂN GIẢM MUỐI, GIẢM ĐƯỜNG, BÉO BÃO HÒA
Để	ngăn	ngừa	các	bệnh	mãn	tí	nh	như	bệnh	ti	m	mạch,	rối	loạn	chuyển	
hóa,	tăng	huyết	áp,	bệnh	ti	ểu	đường	type	2	và	thừa	cân,	béo	phì	nên	ăn	
ít	chất	béo	bão	hòa,	muối,	đường,	rượu.	Đọc	thêm	để	hiểu	hơn	về	những	
khuyến	cáo	này.
5.1. KIỂM SOÁT LƯỢNG MUỐI GIÚP KIỂM SOÁT TỐT HUYẾT ÁP
•	Nên	ăn	dưới	5g	muối/	ngày	(tương	đương	01	muỗng	cà	phê	gạt),	5g	
muối	bằng:
5gr	muối	(1	muỗng	cà	phê)	=	35	gr	xì	dầu	(7	muỗng	cà	phê)	=	8gr	bột	
canh	(1,5	muỗng	cà	phê)	=	11	gr	hạt	nêm	(2	muỗng	cà	phê	hạt	nêm)	=	
26gr	nước	mắm	(5	muỗng	canh	nước	mắm)
• Mẹo giảm ăn mặn đơn giản mà hiệu quả: 
−Tăng	cường	ăn	các	thực	phẩm	tươi,	thường	xuyên	ăn	các	món	luộc.
−Hạn	chế	ăn	các	thực	phẩm	chế	biến	sẵn,	chứa	nhiều	muối	như	mì	ăn	
liền,	giò	chả,	bánh	snack,	thức	ăn	nhanh…
−Giảm	các	món	kho,	rim,	rang,	dưa	cà	muối,	không	
nên	rưới	nước	mắm,	nước	sốt	khi	ăn
−Đọc	 hàm	 lượng	 muối	 trên	 nhãn	 thực	 phẩm	
trước	khi	mua
−Không	nên	cố	uống	hết	chén	nước	canh,	nước	của	
các	món	bún,	phở,	miến,	đặc	biệt	khi	ăn	ở	hàng	quán
−Khi	nấu	nướng,	nếu	phối	hợp	được	các	gia	vị	như	
ti	êu,	ớt,	chanh…	món	ăn	sẽ	ngon	hơn	mà	không	cần	
phải	dùng	nhiều	muối.
• Nên ăn 50% lượng đường trong tổng 
khẩu phần ăn
−Chọn	thức	phẩm	có	chỉ	số	đường	(GI	
Glycemix	index)	thấp,	GI	dưới	70
(Link tham khảo: htt  ps:/ /bvnguyentriphuong.
com.vn/dinh-duong/chi-so-duong-huyet-
cua-thuc-pham )
−Ưu	ti	ên	sử	dụng	các	loại	đường	phức	hợp	
như	gạo	lức,	bún,	phở,	khoai,	bắp…
−Hạn	chế	đường	đơn	như	đường	mía,	nước	
ngọt,	mật	ong,	kẹo…5.2. KIỂM SOÁT LƯỢNG ĐƯỜNG GIÚP KIỂM SOÁT
        ĐƯỜNG HUYẾT VÀ CÂN NẶNG
20•	Nên	dùng	chất	béo	có	nguồn	gốc	thực	vật	như	dầu	ô	–	liu,	dầu	nành,	
dầu	mè,	dầu	gấc,	dầu	gạo.	Không	nên	dùng	dầu	dừa,	dầu	cọ,	bơ,	mỡ,	phủ	
tạng.	Không	nên	ăn	đồ	chiên	ngập	dầu
• Cần tham vấn bác sĩ để chọn loại hình thích hợp
	−Bạn	nên	tập	thể	dục	ít	nhất	5	lần	trong	tuần,	mỗi	lần	ít	nhất	20-30	
phút	như	đi	nhanh,	chạy 	bộ,	đi	xe	đạp,	thể	dục 	nhịp	điệu,	tập	tạ…
	−Khi	tập	nên	chú	 ý:
	ҴKhởi	động	làm	ấm	cơ	thể	trước	khi	tập,	làm	tăng	từ	từ	nhịp	tim,	
hô	hấp,	nhiệt	độ	cơ	thể,	bắt	đầu	các	động	tác	kéo	căng,	mức	độ	
và	cường	độ	thấp;
	ҴNếu	bạn	có	vấn	đề	về	tim	mạch,	khi	tập	nếu	thấy	đau	ngực,	khó	
thở,	chóng	mặt	nên	ngưng	và	hỏi	ý	kiến	của	bác	sĩ	điều	trị.	Sau	khi	
tập	xong	nên	tập	thư	giãn,	nhịp	tim	và	huyết	áp	trở	về	gần	bình	
thường	giúp	cơ	thể	hồi	phục	tốt	hơn.
•	Để	tính	toán	khẩu	phần	ăn	và	gia	giảm	gia	vị	phù	hợp	cho	từng	loại	bệnh	
lý	thường	cần	có	sự	hướng	dẫn	của	chuyên	viên	dinh	dưỡng.	Người	
bệnh	nhập	viện	có	các	bệnh	lý	như	tăng	huyết	áp,	đái	tháo	đường,	suy	
thận…,	nên	đăng	ký	suất	ăn	bệnh	lý	của	bệnh	viện,	hoặc	gặp	bác	sĩ	dinh	
dưỡng	để	được	hướng	dẫn	cách	ăn	uống	và	chế	biến	để	phù	hợp	với	
từng	đối	tượng	bệnh.•	Hạn	chế	hoặc	ngưng	uống	rượu
•	Nữ	nên	uống	ít	hơn	1	lon	bia/	ngày,	
nam	nên	uống	ít	hơn	1,5	lon	bia/	ngày.5.3. KIỂM SOÁT CHẤT BẼO BÃO HÒA GIÚP BẢO VỆ MẠCH  
        MÁU, PHÒNG NGỪA BỆNH TIM MẠCH
5.5. VẬN ĐỘNG, TẬP THỂ DỤC HÀNG NGÀY GIÚP KIỂM  
        SOÁT CÂN NẶNG, THOÁI MÁI TINH THẦN5.4. RƯỢU
Biên soạn nội dung “Những điều cần biết về dinh dưỡng trong một số bệnh lý”:
 BSCKI. Lâm Vạn Phong – BS. Vương Thị Thanh Nhàn, Khoa Dinh dưỡng, Tiết chế - BV Nguyễn Tri Phương
TÀI LIỆU THAM KHẢO
1. Cổng thông tin điện tử Bộ Y tế (2021), Chế độ dinh dưỡng cho F0 điều trị tại nhà theo hướng dẫn chuẩn của Bộ Y tế, năm 
2021, https:/ /moh.gov.vn/hoat-dong-cua-dia-phuong/-/asset_publisher/gHbla8vOQDuS/content/che-o-dinh-duong-cho-f0-
ieu-tri-tai-nha-theo-huong-dan-chuan-cua-bo-y-te
2. Viện Dinh dưỡng (2021), Vai trò và nguyên tắc chế độ dinh dưỡng hợp lý trong dự phòng Covid-19, http:/ /viendinhduong.vn/
vi/tin-tuc---su-kien-noi-bat/vai-tro-va-nguyen-tac-che-do-dinh-duong-hop-ly-trong-du-phong-covid-19.html
3. Trung tâm kiểm soát bệnh tật TPHCM (HCDC) (2021), Chế độ dinh dưỡng cho người nhiễm covid-19 cách ly tại nhà.
4. Trung tâm kiểm soát bệnh tật TPHCM (HCDC) (2021), F0, F1 ở nhà cần lưu ý những gì để nâng cao sức khỏe? https:/ /hcdc.vn/
category/van-de-suc-khoe/covid19/tai-lieu-truyen-thong/f0-f1-o-nha-can-luu-y-nhung-gi-de-nang-cao-suc-khoe-532da29f01e
5ecb48a5c7b7af9d949a0.html#:~:text=%2D%20S%E1%BB%AD%20d%E1%BB%A5ng%20h%E1%BB%A3p%20l%C3%BD%20
v%C3%A0,c%E1%BA%A3%20mu%E1%BB%91i%20trong%20th%E1%BB%B1c%20ph%E1%BA%A9m).
5. Viện Dinh dưỡng (2018) Chế độ ăn giảm muối và các bệnh mạn tính không lây, http:/ /viendinhduong.vn/vi/tin-tuc/che-do-an-
giam-muoi-va-cac-benh-man-tinh-khong-lay.html
6. Viện Dinh dưỡng (2017) Chế độ ăn trong viêm loét dạ dày, tá tràng, http:/ /viendinhduong.vn/vi/dinh-duong-tiet-che/che-do-
an-trong-viem-loet-da-day-ta-trang.html
7. Bệnh viện Chợ Rẫy, Những điều cần biết cho bệnh nhân nội trú, “Hướng dẫn chăm sóc dinh dưỡng cho bệnh nhân lớn tuổi”.
215959
ENS-C-141-22
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh

## Câu lạc bộ Cơ xương khớp

**Chủ đề:** **“CÁC BỆNH LÝ THƯỜNG GẶP Ở CỔ TAY VÀ BÀN TAY”.**
Thời gian: 8h00 sáng thứ bảy ngày 20/08/2016
Địa điểm: Hội trường A, Lầu 5, BV Nguyễn Tri Phương, Số 468 Nguyễn Trãi, F8. Q.5, TpHCM
Vào cửa tự do.
Nội dung chương trình
8:00 – 8:30 Đón tiếp đại biểu và khách tham dự.
8:30 – 9:00 Bệnh lý về khớp bàn tay – cổ tay
9:00 – 9:30 Bệnh lý về gân, bao gân, và ống cổ tay
9:30 – 9:45 Các loại u cổ tay, bàn tay
9:45 – 10:00 Vật lý trị liệu bàn tay
10:00 – 11:00 Giải đáp thắc mắc, Thăm khám miễn phí
Trân trọng kính mời./.
**B ệnh viện Nguyễn Tri Phương** - Bệnh viện Đa khoa Hạng I Thành phố Hồ Chí Minh
  * 468 Nguyễn Trãi, Phường 8, Quận 5, Tp. Hồ Chí Minh
  * Hotline: (84-028) 39234332
  * Mạng xã hội **Facebook** : [**Bệnh viện Nguyễn Tri Phương**](https://www.facebook.com/BVNTP/)
  * Đăng ký (Subcribe) kênh **Youtube** : [https://youtube.com/bvntp](https://youtube.com/bvntp?fbclid=IwAR3q_UvPI4OZAebT1uQGPKKwk3RmCzAFLkBJm9lb7EwIz0EHtgiLhKM5bxU)
  * Quan tâm Zalo Official: [zalo.me/1744466261097093886](https://zalo.me/1744466261097093886?fbclid=IwAR3E-fLqdh-x1cYSvuDY6E5Eyxfjo5ZSs4p0hDWAyBG-ROlTkxXkXvdEWAY)



## Hướng dẫn đặt xét nghiệm thực hiện tại nhà

Bước 1: truy cập trang web [khamtainha-bvntp.com](http://khamtainha-bvntp.com/?fbclid=IwAR1acGT9VhRW-a6NILOJpHe3kRNpxJCwoQQafAi5rzrfM9iYGYp2fgT3dj4)
Bước 2: chọn thẻ "Đăng ký xét nghiệm"
Bước 3: thực hiện khai báo các trường bắt buộc và chọn lựa các xét nghiệm cần thực hiện
Bước 4: bấm nút gửi (submit) khi đã hoàn thành để gửi toàn bộ các thông tin cho chúng tôi 
Bước 5: vui lòng chờ nhận cuộc gọi xác nhận từ nhân viên y tế bệnh viện Nguyễn Tri Phương
(Bạn cũng có thể nhắn tin trên fanpage của BV thông báo đã đặt lịch để chúng tôi có thể hỗ trợ nhanh hơn!)
Theo dõi các thông tin của BV trên facebook [tại đây](https://www.facebook.com/BVNTP)
Theo dõi các video về y tế của BV tại [kênh truyền thông](https://www.youtube.com/channel/UCRlRfMJl5emGJvWjuoJK7sg)./.

## Những tiến bộ và phát triển của BV trong năm 2020


## Dịch vụ y tế tại BV Nguyễn Tri Phương


## ️ Sinh hoạt của Câu lạc bộ bệnh nhân Động kinh

Buổi sinh hoạt của Câu lạc bộ bệnh nhân Động kinh với chủ đề Quản lí bệnh động kinh hiệu quả vào 8h-11h ngày 13/02/2022 sẽ giúp người tham dự hiểu thêm về bệnh động kinh, đặc biệt là các phương pháp điều trị bệnh động kinh hiện có, từ đó giúp người bệnh hiểu rõ hơn về bệnh và nâng cao chất lượng cuộc sống
Đăng kí tham dự qua link: <https://docs.google.com/forms/d/e/1FAIpQLSeExe-mNELWw1xrxoH7ZY47R6s6qX0M_Emun6Br3Y7h_uXeAQ/viewform>
hoặc quét mã QRcode
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh

