## ️ Bệnh di truyền đơn gen lặn là gì?

Tính tới thời điểm hiện tại, khoảng 5000 rối loạn di truyền đã biết được di truyền theo kiểu Mendelian (**di truyền đơn gen** – do một gen quyết định). Chủ yếu trong số đó là các rối loạn trội trên nhiễm sắc thể (NST) thường, lặn trên NST thường và rối loạn liên kết nhiễm sắc thể X, có nguy cơ mắc bệnh cao hơn so với nguy cơ liên quan đến tuổi tác. Với di truyền trội, nếu bố hoặc mẹ mắc bệnh, sẽ di truyền cho con với tỉ lệ 50%. Với bệnh di truyền lặn, một cặp vợ chồng mang gen (là người khỏe mạnh, không biểu hiện bệnh) có nguy cơ 25% sinh con mang đồng hợp tử lặn sẽ mắc bệnh. Rối loạn lặn liên kết **nhiễm sắc thể** X, nếu mẹ là người mang gen, 50% con trai có nguy cơ mắc bệnh.
Theo công bố quốc tế của Viện Di truyền Y học TP.HCM trên tạp chí di truyền quốc tế Human Mutation (IF 4.8), 9 bệnh lặn đơn gen phổ biến gồm tan máu bẩm sinh thể Alpha và Beta, thiếu men G6PD, rối loạn chuyển hóa đường galactose, không dung nạp đạm (Phenylketon niệu), rối loạn chuyển hóa đồng Wilson; vàng da ứ mật do thiếu hụt men citrin; rối loạn phát triển giới tính ở nam do thiếu men 5 alpha-reductase và bệnh Pompe có tỷ lệ người lành mang gen bệnh khá cao, 1/100 người bình thường. 
Đa phần các bệnh này có ảnh hưởng nghiêm trọng đến chất lượng cuộc sống của trẻ nếu không can thiệp kịp thời, nhưng rất ít bố mẹ quan tâm và có đủ thông tin về các bệnh này. Nhiều chuyên gia về sản khoa, di truyền đều có chung nhận định: Nhận thức về bệnh lặn đơn gen vẫn là "vùng tối" tại Việt Nam.
Riêng với bệnh tan máu bẩm sinh (Thalassemia), Việt Nam có khoảng trên 12 triệu người mang gen bệnh và hơn 20.000 người bệnh mức độ nặng cần phải điều trị cả đời.
Song song đó, các nghiên cứu khoa học và thống kê cho thấy 80% số trẻ em bị rối loạn di truyền được sinh ra bởi cha mẹ hoàn toàn khỏe mạnh, không có tiền sử bệnh. Nghĩa là dù cha mẹ khỏe mạnh vẫn có thể mang gen đột biến trong cơ thể ở trạng thái lặn và khi kết hôn, sẽ có 25% nguy cơ sinh con mắc bệnh lặn đơn gen. 
Trong trường hợp nghiêm trọng nhất, trẻ có thể sẽ tử vong ngay trong thai kỳ, sức khỏe của người mẹ cũng bị ảnh hưởng theo. 25% mắc bệnh sẽ lặp đi lặp lại với các cặp vợ chồng cùng mang một gen bệnh lặn.
Không giống như **xét nghiệm di truyền tế bào trước sinh** dựa trên tuổi mẹ, xét nghiệm gen trước sinh không phải là một **xét nghiệm sàng lọc**. Với tính chất riêng của từng trường hợp, việc lập kế hoạch trước là điều cần thiết. Có thể có hai chiến lược khác nhau: xét nghiệm di truyền gián tiếp và trực tiếp.
Xét nghiệm di truyền trực tiếp liên quan đến việc xác định hoặc loại trừ (các) đột biến có liên quan và giả định kiến ​​thức về các đột biến hiện có ở bệnh nhân chỉ định.
Xét nghiệm di truyền gián tiếp liên quan đến việc chứng minh hoặc loại trừ cái gọi là haplotype nguy cơ cao ở thai nhi. Xét nghiệm di truyền gián tiếp sử dụng nguyên tắc liên kết di truyền và yêu cầu kiểm tra các thành viên trong gia đình để tìm các dấu hiệu đa hình mà các alen có liên quan chặt chẽ với bệnh trong gia đình. Về lý thuyết, tất cả những gì cần thiết trong thông tin di truyền trong gia đình là vị trí của gen liên quan. Sự không chắc chắn trong chẩn đoán nảy sinh khi có sự không đồng nhất trong vị trí gen, ví dụ khi các đột biến ở các gen khác nhau dẫn đến cùng một bệnh. Thêm vào đó, khi một gen tái tổ hợp với một điểm đánh dấu liên kết cũng gây ra tình trạng chẩn đoán không rõ. Mức độ tin cậy của xét nghiệm di truyền gián tiếp phụ thuộc vào tính chính xác của các mối quan hệ đã nêu trong phả hệ.
Trong một xét nghiệm**chẩn đoán trước sinh** dương tính, đặc biệt là bệnh di truyền trội trên NST thường, phải lưu ý đến khả năng biểu hiện thay đổi và tính thấm của bệnh. Khả năng biểu hiện của một đột biến xảy ra khi kiểu hình được biểu hiện thay đổi về mức độ nặng nhẹ khác nhau ở các thành viên khác nhau của cùng một gia đình.
Tính thấm giảm có nghĩa là thiếu biểu hiện của đột biến. Trong tình huống này, kiểu hình có thể bình thường mặc dù bị đột biến. Biểu hiện thay đổi và tính thấm giảm có thể được giải thích bởi các yếu tố thay đổi phần lớn chưa được biết đến. Vì lý do này, điều quan trọng là phải thảo luận những vấn đề này trong quá trình tư vấn di truyền.
Tóm lại, xét nghiệm di truyền mang một ý nghĩa vô cùng quan trọng, vì thế bạn nên chọn các cơ sở y tế uy tín, có đầy đủ trang thiết bị máy móc hiện đại để thăm khám nhằm mang đến kết quả chính xác nhất cũng như có hướng điều trị kịp thời.
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh

## ️ Hội chứng Klinefelter ảnh hưởng thế nào?

  * [Biến chứng của hội chứng Klinefelter](https://bvnguyentriphuong.com.vn/benh-di-truyen/hoi-chung-klinefelter-anh-huong-the-nao#bin-chng-ca-hi-chng-klinefelter)
  * [Phòng ngừa hội chứng Klinefelter](https://bvnguyentriphuong.com.vn/benh-di-truyen/hoi-chung-klinefelter-anh-huong-the-nao#phng-nga-hi-chng-klinefelter)


**Nguyên nhân gây lên hội chứng****Klinefelter**
Hội chứng Klinefelter xảy ra do một lỗi ngẫu nhiên khiến nam giới sinh ra có nhiễm sắc thể giới tính phụ. Đó không phải là một hội chứng di truyền.
Mỗi người có 46 nhiễm sắc thể, trong đó nữ giới mang hai nhiễm sắc thể X(XX), nam mang nhiễm sắc thể giới tính X và Y(XY).
Hội chứng Klinefelter có thể được gây ra bởi:
  * Thêm một nhiễm sắc thể X trong mỗi tế bào (XXY), nguyên nhân phổ biến nhất
  * Một nhiễm sắc thể X được thêm ở một số tế bào (hội chứng khảm Klinefelter), với ít triệu chứng hơn.
  * Có nhiều hơn một nhiễm sắc thể X. Trường hợp này rất hiếm,


**Triệu chứng hội chứng****Klinefelter**
Do bênh không thể chẩn đoán dược cho đến khi trưởng thành hoặc nó không bao giờ được chẩn đoán nên các dấu hiệu và triệu chứng Klinefeler rất khác nhau và nó cũng thay đổi triệu chứng theo đội tuổi.
  * **Giai đoạn sơ sinh**


Giai đoạn này trẻ sẽ có dấu hiệu phát triển chậm khi bò, đi, nói chậm hoặc nói hơn so với trẻ bình thường. Sức đề kháng cơ thể yếu,có thể có hiện tượng thoát vị và tình trạng tinh hoàn không trượt xuống bìu.
  * **Giai đoạn trẻ em**


Giai đoạn này trẻ em thường có dấu hiệu kém phát triển trong học tập như khó đọc, viết, đánh vấn, làm toán. Trong giai đoạn này khả năng vận động là rất kém ngay cả trong việc đi vệ sinh. Những trẻ gặp hội chứng này sẽ thường gặp các vấn đề xã hội dẫn đến nhút nhát, không tự tin, thiếu tập trung, rối loạn cảm xúc,..
  * **Giai đoạn thiếu niên**


Người mắc hội chứng Klinefelter thường thay đổi về thể chất, thường chậm hơn so với những người cùng độ tuổi chẳng hạn như cánh tay và chân dài hơn, ngực rộng lớn hơn so với những cậu bé cùng trang lứa khác, xương yếu hơn, hông rộng, lông trên các bộ phận mọc chậm, dương vật và tinh hoàn nhỏ, cơ bắp ít…..
  * **Giai đoạn trưởng thành**


Phần lớn bệnh nhân là người trưởng thành thường gặp vấn đề sinh sản(vô sinh) do bộ phân sinh dục không phát triển dẫn đến ham muốn tình dục thấp hoặc không có
Tuy nhiên, các vấn đề sức khỏe khác nhau giữa các bệnh nhân mắc hội chứng Klinefelter vẫn có thể điều trị nhanh hoặc chậm. 
### **Biến chứng của hội chứng Klinefelter**
Những bất thường nhiễm sắc thể trong hội chứng này có thể làm tăng nguy cơ mắc các vấn đề sức khỏe khác như sau:
  * Hệ thống miễn dịch bị suy giảm, là tình trạng hệ thống miễn dịch tấn công các tế bào hoặc mô trong cơ quan của bệnh nhân cho đến khi gây ra các bệnh khác nhau như lupus, viêm khớp…
  * Bệnh tim và tắc mạch
  * Ung thư vú.
  * Rối loạn nội tiết như tiểu đường.
  * Loãng xương thường xảy ra ở những bệnh nhân có hormone testosterone thấp trong một thời gian dài.
  * Vấn đề sức khỏe tâm thần (trầm cảm kéo dài).


**Phương pháp chẩn đoán****Klinefelter**
Bác sĩ, chuyên gia y tế sẽ kiểm tra thông tin chung về tình hình sức khỏe các triệu chứng và kiểm tra thể chất cơ bản trọng tâm vẫn sẽ là kiểm tra vú, bộ phận sinh dục và tinh hoàn.
Kiểm tra nhiễm sắc thể hoặc kiểm tra lượng hormone từ máu hoặc nước tiểu.
Những người mắc chứng klinefelter thường có dấu hiệu bất thường về thể chất khi bước vào tuổi sinh sản, 
**Hướng điều trị****Klinefelter**
Không có cách điều trị hội chứng này, nhưng một số vấn đề liên quan đến tình trạng này có thể được điều trị nếu cần thiết như :ngôn ngữ, tim mạch, khả năng sinh sản, thể trạng, thể chất… Liệu pháp thay thế testosterone là một phương pháp thường được sử dụng để làm giảm các triệu chứng trong hội chứng klinefelter. Việc sử dụng loại hormone này trong một thời gian dài liên tục ở người lớn có thể làm giảm nguy cơ mắc bệnh loãng xương. Tuy nhiên việc này chỉ tăng khả năng ham muốn tình dục nhưng không thể khắc phục chứng vô sinh.
### **Phòng ngừa hội chứng Klinefelter**
**Hội chứng Klinefelte** r không thể phòng ngừa. Bởi nó là một căn bệnh gây ra bởi sự bất thường di truyền. Người mẹ mang thai sau 35 tuổi, tốt hơn nên tham khảo ý kiến ​​Bác sĩ trước khi mang thai để lên kế hoạch sinh con và đánh giá nguy cơ tiềm ẩn. Và trong trường hợp đứa trẻ có một số triệu chứng bất thường tương tự như các triệu chứng của hội chứng Klinefelter, thì nên đến gặp bác sĩ để chẩn đoán. Nếu trẻ được điều trị kịp thời, trẻ sẽ phát triển khỏe mạnh và giảm các biến chứng.
**Nam giới mắc phải hội chứng Klinefelter có thể có con không?**
- Câu trả lời là có thể. Với sự phát triển của y tế ngày nay, chúng ta có thể khám tư vấn chế độ dinh dưỡng để bổ sung hormone nam giới cùng với những phương pháp hỗ trợ sinh sản khác.
- Trên thực tế thì một số nam giới trẻ mắc hội chứng**Klinefelter** vẫn có thể có một lượng nhỏ tinh trùng khi xuất tinh. Vì vậy các bác sĩ vẫn có thể trích xuất số tinh trùng đó để thực hiện **thụ tinh ống nghiệm (IVF).**
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [Biến chứng của hội chứng Klinefelter](https://bvnguyentriphuong.com.vn/benh-di-truyen/hoi-chung-klinefelter-anh-huong-the-nao#bin-chng-ca-hi-chng-klinefelter)
  * [Phòng ngừa hội chứng Klinefelter](https://bvnguyentriphuong.com.vn/benh-di-truyen/hoi-chung-klinefelter-anh-huong-the-nao#phng-nga-hi-chng-klinefelter)



## ️ Nhũng bệnh di truyền phổ biến

Đột biến gene, đột biến nhiễm sắc thể chính là nguyên nhân gây ra những bệnh di truyền về gene ở người. Không ít trường hợp một gia đình có hai, ba thế hệ cùng mắc một loại bệnh. Ông bà, cha mẹ mang gene bệnh truyền lại cho con cháu. Nếu không được phòng tránh, hay phát hiện và điều trị kịp thời, bệnh có thể làm mất nòi giống, là nỗi đau thương tâm cho nhiều thế hệ.
Tuy nhiên, tùy từng loại bệnh mà mức độ di truyền khác nhau. Và không phải tất cả con cháu đời sau đều mắc bệnh. Do đó, hiểu về tiền sử gia đình, phòng tránh sớm các nguy cơ mắc bệnh di truyền có thể giúp mọi người phòng bệnh cho con cái hoặc theo dõi, phát hiện và điều trị sớm.
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh

## Bệnh tim bẩm sinh ở trẻ em: Nhận biết và điều trị kịp thời

  * [Những biểu hiện nghi ngờ bé mắc bệnh tim bẩm sinh](https://bvnguyentriphuong.com.vn/benh-di-truyen/benh-tim-bam-sinh-o-tre-em-nhan-biet-va-dieu-tri-kip-thoi#nhng-biu-hin-nghi-ng-b-mc-bnh-tim-bm-sinh)
  * [Các loại dị tật tim bẩm sinh ở trẻ em](https://bvnguyentriphuong.com.vn/benh-di-truyen/benh-tim-bam-sinh-o-tre-em-nhan-biet-va-dieu-tri-kip-thoi#cc-loi-d-tt-tim-bm-sinh-tr-em)
  * [Nhóm tim bẩm sinh không có luồng thông](https://bvnguyentriphuong.com.vn/benh-di-truyen/benh-tim-bam-sinh-o-tre-em-nhan-biet-va-dieu-tri-kip-thoi#nhm-tim-bm-sinh-khng-c-lung-thng)
  * [Nhóm tim bẩm sinh có luồng thông từ trái sang phải](https://bvnguyentriphuong.com.vn/benh-di-truyen/benh-tim-bam-sinh-o-tre-em-nhan-biet-va-dieu-tri-kip-thoi#nhmtim-bm-sinh-c-lung-thng-t-tri-sang-phi)
  * [Nhóm tim bẩm sinh có luồng thông từ phải sang trái](https://bvnguyentriphuong.com.vn/benh-di-truyen/benh-tim-bam-sinh-o-tre-em-nhan-biet-va-dieu-tri-kip-thoi#nhm-tim-bm-sinh-c-lung-thng-t-phi-sang-tri)
  * [Bệnh tim bẩm sinh ở trẻ em điều trị như thế nào?](https://bvnguyentriphuong.com.vn/benh-di-truyen/benh-tim-bam-sinh-o-tre-em-nhan-biet-va-dieu-tri-kip-thoi#bnh-tim-bm-sinh-tr-em-iu-tr-nh-th-no)


Hiện nay trình độ phát hiện và phẫu thuật tim bẩm sinh rất tốt. Có thể phát hiện sớm bệnh tim bẩm sinh ở trẻ em khi siêu âm thai. Nhưng có nhiều bé phát hiện trễ, khiến việc điều trị cũng gặp nhiều khó khăn. Vì vậy, ba mẹ hãy tham khảo những thông tin dưới đây để nhận biết sớm các dấu hiệu bệnh tim bẩm sinh ở trẻ em và có biện pháp xử trí kịp thời tốt nhất cho con.
## **Những biểu hiện nghi ngờ bé mắc bệnh tim bẩm sinh**
_bệnh tim bẩm sinh ở trẻ em_
Bệnh tim bẩm sinh ở trẻ em, trẻ thường có những biểu hiện sau:
  * Tím đầu ngón tay, ngón chân, tím môi, tím lưỡi, đặc biệt là khi bé khóc hoặc lao động quá sức.
  * Bé khó thở khi bú
  * Thở rên
  * Khi nghe tim có tiếng thổi bất thường
  * Không tăng cân hay sụt cân từ khi còn nhỏ
  * Trẻ lớn thì mệt khi vận động mạnh


Khi con có các biểu hiện nghi ngờ bệnh tim bẩm sinh nêu trên, nên cho bé đi khám để bác sĩ kiểm tra và chẩn đoán đúng, chẩn đoán sớm cho con.
Hiện nay siêu âm tim, điện tim có thể giúp đánh giá các chỉ số bất thường về tim của bé. Từ đó các bác sĩ sẽ lấy căn cứ để chẩn đoán tiếp và phát hiện sớm cho con.
Trẻ bị tim bẩm sinh không lên cân nên đi khám dinh dưỡng vì rất khó chỉnh chế độ dinh dưỡng. Đặc biệt việc sử dụng một số thuốc để điều trị các bệnh mà bé mắc phải cũng cần phải theo chỉ định của bác sĩ để không làm ảnh hưởng đến bệnh tim bẩm sinh của con.
## **Các loại dị tật tim bẩm sinh ở trẻ em**
_Hình ảnh giải phẫu tim. (ảnh minh họa)_
Các dị tật tim bẩm sinh ở trẻ em được chia thành nhiều loại, từ đơn giản đến phức tạp. Ngày nay người ta thường phân loại các dị tật tim bẩm sinh dựa theo ảnh hưởng của nó đối với các luồng máu chảy trong cơ thể của trẻ gồm:
## **Nhóm tim bẩm sinh không có luồng thông**
Với nhóm này, thường trẻ không bị tím, lượng máu lên phổi bình thường hoặc giảm. Bao gồm Hẹp động mạch phổi, Hẹp động mạch chủ, Hẹp eo động mạch chủ.
## **Nhóm tim bẩm sinh có luồng thông từ trái sang phải**
Có lỗ thông đưa máu đi từ**c** ác buồng tim bên trái sang tim bên phải. Trong nhóm tim bẩm sinh này, lưu lượng máu đi qua phổi sẽ gia tăng (tăng tuần hoàn phổi) và thường không gây ra triệu chứng tím (trừ khi luồng thông đã bị đảo chiều do áp lực mạch máu phổi gia tăng cao hơn áp lực mạch máu của hệ thống).
## **Nhóm tim bẩm sinh có luồng thông từ phải sang trái**
Có lỗ thông đưa máu đi từ các buồng tim bên phải sang tim bên trái, thường gây ra triệu chứng tím và lưu lượng máu đi qua phổi có thể tăng (tăng tuần hoàn phổi) hay giảm (giảm tuần hoàn phổi).
## **Bệnh tim bẩm sinh ở trẻ em điều trị như thế nào?**
_Hiện nay y học phát triển, bệnh tim bẩm sinh ở trẻ em có nhiều phương pháp can thiệp mang lại hiệu quả cao cho trẻ. (ảnh minh họa)_
Ngày nay, với sự phát triển của ngành Tim mạch học can thiệp, đối với một số bệnh tim bẩm sinh ngoài việc phải phẫu thuật để sửa chữa các dị tật ở tim, các Bác sĩ Tim mạch Nhi khoa có thể đưa các thiết bị/dụng cụ vào tim từ các mạch máu như động mạch/tĩnh mạch đùi hay dưới đòn qua da để bít các lỗ thông trong tim hay nong và sửa chữa các van bị hẹp mà không cần phải mở lồng ngực cho trẻ.
**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/) **- Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [Những biểu hiện nghi ngờ bé mắc bệnh tim bẩm sinh](https://bvnguyentriphuong.com.vn/benh-di-truyen/benh-tim-bam-sinh-o-tre-em-nhan-biet-va-dieu-tri-kip-thoi#nhng-biu-hin-nghi-ng-b-mc-bnh-tim-bm-sinh)
  * [Các loại dị tật tim bẩm sinh ở trẻ em](https://bvnguyentriphuong.com.vn/benh-di-truyen/benh-tim-bam-sinh-o-tre-em-nhan-biet-va-dieu-tri-kip-thoi#cc-loi-d-tt-tim-bm-sinh-tr-em)
  * [Nhóm tim bẩm sinh không có luồng thông](https://bvnguyentriphuong.com.vn/benh-di-truyen/benh-tim-bam-sinh-o-tre-em-nhan-biet-va-dieu-tri-kip-thoi#nhm-tim-bm-sinh-khng-c-lung-thng)
  * [Nhóm tim bẩm sinh có luồng thông từ trái sang phải](https://bvnguyentriphuong.com.vn/benh-di-truyen/benh-tim-bam-sinh-o-tre-em-nhan-biet-va-dieu-tri-kip-thoi#nhmtim-bm-sinh-c-lung-thng-t-tri-sang-phi)
  * [Nhóm tim bẩm sinh có luồng thông từ phải sang trái](https://bvnguyentriphuong.com.vn/benh-di-truyen/benh-tim-bam-sinh-o-tre-em-nhan-biet-va-dieu-tri-kip-thoi#nhm-tim-bm-sinh-c-lung-thng-t-phi-sang-tri)
  * [Bệnh tim bẩm sinh ở trẻ em điều trị như thế nào?](https://bvnguyentriphuong.com.vn/benh-di-truyen/benh-tim-bam-sinh-o-tre-em-nhan-biet-va-dieu-tri-kip-thoi#bnh-tim-bm-sinh-tr-em-iu-tr-nh-th-no)



## Cách điều trị bệnh tim bẩm sinh

**Bệnh tim bẩm sinh là những dị tật về tim, xuất hiện trong quá trình hình thành quả tim từ trong bào thai. Có nhiều cách điều trị bệnh tim bẩm sinh khác nhau. Theo đó, phát hiện bệnh sớm sẽ giúp điều trị hiệu quả.**
Bệnh tim bẩm sinh là những dị tật về tim được hình thành từ trong bào thai. Phần lớn bệnh lý tim bẩm sinh hiện nay y học vẫn chưa tìm được nguyên nhân. Bệnh tim bẩm sinh là bệnh lý nguy hiểm, đe dọa trực tiếp đến sức khỏe và tính mạng của trẻ nhỏ. Do đó, bệnh tim bẩm sinh cần được phát hiện và điều trị sớm nhất có thể.
_Tim bẩm sinh là một trong những bệnh tim mạch phổ biến ở trẻ nhỏ_
Thống kê của bộ Y tế cho hay, mỗi năm Việt Nam có khoảng 10.000 trẻ chào đời bị bệnh tim bẩm sinh, trong đó 50% số trẻ có nguy cơ tử vong;có khoảng 5.000 trẻ bị tim bẩm sinh được phẫu thuật mỗi năm, số còn lại phải chờ hoặc tử vong trước khi đến lượt lên bàn mổ.
Theo các chuyên gia tim mạch, các yếu tố nguy cơ từ những người mẹ nghiện rượu; sử dụng thuốc không tuân thủ chỉ định của bác sĩ trong thai kỳ; mắc bệnh đái tháo đường; bị nhiễm virus Rubella; thường xuyên tiếp xúc với các hóa chất độc hại; rối loạn di truyền… có thể làm tăng nguy cơ mắc bệnh tim bẩm sinh ở thai nhi.
_Các bệnh về tim bẩm sinh ở trẻ em cần được phát hiện và điều trị sớm_
Dưới sự hỗ trợ của công nghệ y khoa hiện đại, siêu âm tim thai giúp phát hiện sớm các dị tật về tim. Đây được xem là phương pháp chẩn đoán không xâm lấn, cho kết quả đáng tin cậy trong việc phát hiện bệnh tim bẩm sinh. Tuy nhiên, các dị tật về tim bẩm sinh lại thường là những dị tật bị bỏ sót nhất trong siêu âm tiền sản. Bệnh tim bẩm sinh nếu không được phát hiện và điều trị sớm, trẻ sẽ tử vong. Việc phát hiện bệnh sớm có ý nghĩa quan trọng trong việc điều trị bệnh tim bẩm sinh
## **Điều trị bệnh tim bẩm sinh như thế nào?**
Có nhiều cách điều trị bệnh tim bẩm sinh khác nhau như: Sử dụng thuốc, phẫu thuật tim, can thiệp bằng phương pháp thông tim… Tùy từng trường hợp bệnh nhân mà các bác sĩ sẽ chỉ định những cách điều trị khác nhau.
Với những trường hợp phát hiện bệnh tim bẩm sinh từ trong bào thai, những trường hợp cần thiết, bác sĩ sẽ cho thai nhi sử dụng thuốc chống rối loạn nhịp để điều trị trong tử cung của người mẹ. Trường hợp bệnh nặng và có những yếu tố bất thường, các bác sĩ sẽ chỉ định chấm dứt thai kỳ để bảo vệ sức khỏe cho thai phụ. Phát hiện tim bẩm sinh từ trong thai kỳ giúp bác sĩ có hướng điều trị như đặt Stent ống động mạch, nong vách liên nhĩ, prostaglandin… ngay sau khi trẻ chào đời.
**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/) **- Đa khoa Hạng I Thành phố Hồ Chí Minh

## Các bệnh tim mạch bẩm sinh dị tật hay gặp nhất

Các bệnh tim mạch bẩm sinh là dị tật liên quan đến cấu trúc của tim, xuất hiện từ những tuần đầu thai nhi trong giai đoạn hình thành quả tim. Các bệnh tim mạch bẩm sinh là dị tật hay gặp nhất và là nguyên nhân gây tử vong hàng đầu trong số các dị tật bẩm sinh.
**Dấu hiệu nhận biết các bệnh tim bẩm sinh thường gặp**
Theo các bác sĩ tim mạch, trẻ bị bệnh tim bẩm sinh có thể không có triệu chứng lâm sàng. Hầu hết trẻ được phát hiện bệnh khi được bác sĩ khám bệnh và nghe thấy một tiếng thổi bất thường tại tim. Nhiều trường hợp, trẻ cần làm một số xét nghiệm thăm dò để loại trừ bệnh tim bẩm sinh.
_Các bệnh tim mạch bẩm sinh là dị tật liên quan đến cấu trúc của tim, xuất hiện từ những tuần đầu thai nhi trong giai đoạn hình thành quả tim._
Những người bị dị tật tim bẩm sinh có thể có triệu chứng của suy tim sung huyết. Bệnh nhân có thể có các triệu chứng, như: Tim đập nhanh, khó thở đặc biệt khó thở khi gắng sức. Trẻ sơ sinh có thể biểu hiện bằng bú kém, chậm tăng cân. Ngoài ra, người bệnh có thể có biểu hiện phù ở chân, bụng hoặc quanh hốc mắt. 
Nguyên nhân là do quả tim không có khả năng bơm máu một cách đầy đủ cho phổi hoặc các cơ quan khác gây ứ dịch ở tim, phổi hoặc các bộ phận khác của cơ thể. Một số bệnh tim bẩm sinh gây triệu chứng tím da, niêm mạc, gốc móng tay. Người bệnh dễ bị mệt, khó thở đặc biệt khi bú hoặc quấy khóc.
_Yếu tố di truyền và yếu tố môi trường có vai trò trong hình thành các dị tật tim bẩm sinh trong giai đoạn bào thai._
**Nguyên nhân gây các bệnh tim mạch bẩm sinh**
  * Yếu tố di truyền và yếu tố môi trường có vai trò trong hình thành các dị tật tim bẩm sinh trong giai đoạn bào thai.
  * Yếu tố môi trường được xem là có góp phần gây ra các dị tật tim bẩm sinh. Theo đó, những phụ nữ bị Rubella, cúm trong 3 tháng đầu thai kỳ có nguy cơ cao sinh con bị dị tật tim bẩm sinh. Người mẹ lạm dụng rượu hoặc các chất kích thích khác, tiếp xúc với hoá chất độc hại (thuốc trừ sâu) khi mang thai cũng làm tăng nguy cơ con bị mắc tim bẩm sinh.
  * Người mẹ mắc một số bệnh mạn tính như: đái tháo đường cũng làm tăng nguy cơ bị dị tật tim bẩm sinh ở con.
  * Một số loại thuốc làm tăng nguy cơ mắc dị tật tim bẩm sinh như: Thuốc điều trị mụn trứng cá như isotretionin, thuốc thalidomide, một số thuốc chống động kinh. Nếu người mẹ sử dụng thuốc trimethoprim – sulphonamid (Biseptol) để điều trị nhiễm khuẩn tiết niệu trong 3 tháng đầu thai kỳ cũng làm tăng nguy cơ mắc dị tật tim bẩm sinh ở trẻ sơ sinh.


**Một số bệnh tim bẩm sinh thường gặp và cách điều trị**
  * _Còn ống động mạch_
  * _Thông liên thất, thông liên nhĩ_
  * _Hẹp eo động mạch chủ_
  * _Bất thường van tim_
  * _Tứ chứng Fallot_
  * _Hội chứng thiểu sản thất trái…_


**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/) **- Đa khoa Hạng I Thành phố Hồ Chí Minh

## ️ Rối loạn đa gen (gene) là gì

Các nhà nghiên cứu nhận ra rằng hầu hết bệnh tật đều do thành phần di truyền học nào đó gây nên. Một vài rối loạn như bệnh thiếu máu hồng cầu hình liềm và bệnh xơ nang xuất hiện do một số đột biến trên gen đơn lẻ. Có nhiều nguyên nhân gây ra các rối loạn di truyền, tuy nhiên cơ chế rất phức tạp. Những vấn đề liên quan đến bệnh lý phức tạp như bệnh tim, tiểu đường tuýp 2 và béo phì không phải chỉ do nguyên nhân di truyền gây nên, mà dường như có sự kết hợp của nhiều yếu tố bao gồm gen và tác động của môi trường bên ngoài. Các tình trạng do nhiều yếu tố tác động kết hợp được gọi là các rối loạn phức hợp hay còn gọi là các rối loạn đa yếu tố kết hợp.
Trong rối loạn đa vật liệu di truyền, một số gen có thể ảnh hưởng đến sự tiến triển của một căn bệnh, nhưng không có một gen nào tự mình gây ra căn bệnh. Vì lý do này, các nhà nghiên cứu gen phải nghiên cứu cách biểu hiện và tương tác của nhiều gen. Bởi vì rối loạn đa nguyên thường nhạy cảm với các tương tác từ các tác động môi trường đa dạng, nên chúng phức tạp hơn nhiều so với rối loạn một gen. Bệnh tim là ví dụ cho một bệnh mạn với đa gen và sự tương tác với môi trường. Hãy xem xét rằng các yếu tố nguy cơ chính đối với bệnh tim bao gồm mỡ máu tăng cao, béo phì, tiểu đường và cao huyết áp. Mỗi yếu tố nguy cơ này đều có rất nhiều nguyên nhân cơ bản về di truyền và môi trường mà không hoàn toàn được hiểu.
Nghiên cứu về dinh dưỡng của bộ gen liên quan đến phối hợp nhiều phát hiện liên quan đến các yếu tố nguy cơ và giải thích sự tương tác của một số gen, con đường sinh hóa và dinh dưỡng của chúng. Sự hình thành sau đó hướng dẫn các bác sĩ và chuyên gia dinh dưỡng để tạo ra các biện pháp can thiệp y tế và chế độ ăn uống thích hợp để đạt được những lợi ích sức khỏe lớn nhất. Tìm những lựa chọn tốt nhất cho mỗi người là mộ sự thách thức lớn do có khả năng tương tác gen và các yếu tố môi trường và hàng triệu những biến thể của gen người khiến mỗi cá thể trở nên độc nhất.
Để tìm hiểu thêm về cách các cá nhân phản ứng với chế độ ăn kiêng, các nhà nghiên cứu kiểm tra sự khác biệt về di truyền giữa con người. Sự khác biệt di truyền phổ biến nhất liên quan đến những thay đổi trong một căn cứ nucleotide duy nhất nằm trong một vùng đặc biệt của một sợi DNA - thymine thay thế cytosine, ví dụ. Các biến thể như vậy được gọi là đa dạng nucleotide đơn (SNPs), và chúng thường xảy ra trong toàn bộ bộ gen. Nhiều SNP (phát âm thường gặp là “snips”) không ảnh hưởng đến hoạt động tế bào. Trên thực tế, SNP chỉ đáng kể nếu chúng ảnh hưởng đến chuỗi axit amin của một protein theo cách thay đổi chức năng của nó và nếu chức năng đó là quan trọng đối với sức khỏe của người đó. Trong những trường hợp này, SNPs có thể tiết lộ câu trả lời hấp dẫn cho những phát hiện chưa giải thích trước đây. Hãy xem xét, ví dụ, rằng những người có SNP tương đối phổ biến có LDL thấp hơn khi ăn một chế độ ăn giàu axit béo bão hòa đa dương - và LDL cao hơn với lượng nạp ít - so với những người không có SNP. Những phát hiện này cho thấy rõ cách ăn kiêng (trong trường hợp này, chất béo đa bão hòa) tương tác với gen (trong trường hợp này, gen chuyển hóa lipid với SNP) để ảnh hưởng đến sự phát triển của một căn bệnh (thay đổi lipid máu có liên quan đến bệnh tim). Họ cũng giúp giải thích tại sao một số can thiệp chế độ ăn kiêng lại có tác dụng cho một số người tốt hơn những người khác.
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh

## ️ Tìm hiểu về chứng thoát vị hoành bẩm sinh

  * [Nguyên nhân gây thoát vị hoành bẩm sinh](https://bvnguyentriphuong.com.vn/benh-di-truyen/tim-hieu-ve-chung-thoat-vi-hoanh-bam-sinh#nguyn-nhn-gy-thot-v-honh-bm-sinh)
  * [Triệu chứng thường gặp khi bị thoát vị hoành bẩm sinh](https://bvnguyentriphuong.com.vn/benh-di-truyen/tim-hieu-ve-chung-thoat-vi-hoanh-bam-sinh#triu-chng-thng-gp-khi-b-thot-v-honh-bm-sinh)
  * [Phương pháp điều trị thoát vị hoành bẩm sinh ở trẻ](https://bvnguyentriphuong.com.vn/benh-di-truyen/tim-hieu-ve-chung-thoat-vi-hoanh-bam-sinh#phng-php-iu-tr-thot-v-honh-bm-sinh-tr)


## **Nguyên nhân gây thoát vị hoành bẩm sinh**
Nguyên nhân chính xác gây thoát vị hoành bẩm sinh vẫn chưa được kết luận cụ thể. Tuy nhiên bệnh có thể gặp với dạng là dị tật bẩm sinh.
Thoát vị hoành là một dị tật bẩm sinh nguy hiểm và gây tử vong nhanh chóng
Cơ hoành là cấu trúc cân cơ có hình vòm ngăn cách giữa ổ bụng và lồng ngực. Cơ hoành được hình thành vào tuần thứ 8-10 của thời kỳ bào thai. Trong quá trình hình thành cơ hoành không được hoàn thiện sẽ tạo thành khe hở. Theo đó lồng ngực và ổ bụng không được ngăn cách hoàn toàn và các tạng trong ổ bụng như dạ dày, ruột, lách, gan có thể đi lên lồng ngực qua khe hở của cơ hoành gây ra bệnh thoát vị hoành.
Thoát vị hoành bẩm sinh chủ yếu gặp ở bên trái, ít gặp ở bên phải và rất hiếm khi bị ở cả hai bên.
### **Triệu chứng thường gặp khi bị thoát vị hoành bẩm sinh**
Trẻ bị thoát vị hoành thường có biểu hiện suy hô hấp (khó thở) sớm và nặng sau sinh.
Trẻ bị thoát vị hoành bẩm sinh sẽ có biểu hiện khó thở, quấy khóc, ảnh hưởng tới sức khỏe
Ngoài ra, trẻ bị thoát vị hoành còn có triệu chứng bụng lép (do một số tạng trong ổ bụng đi lên lồng ngực).
Một số trường hợp có biểu hiện muộn, trẻ hay bị viêm phổi, khó thở và chỉ tình cờ phát hiện được thoát vị hoành khi chụp phim X-quang.
### **Phương pháp điều trị thoát vị hoành bẩm sinh ở trẻ**
Khi thấy các dấu hiệu không ổn về sức khỏe, cha mẹ cần đưa bé tới ngay các cơ sở y tế, bệnh viện để được thăm khám và chẩn đoán chính xác bệnh.
Trẻ bị thoát vị hoành cần được xử trí ban đầu bằng cách đặt nội khí quản trợ giúp thở và đặt ống thông dẫn lưu dạ dày liên tục (để dẫn lưu hơi do trẻ nuốt vào trong dạ dày làm giảm chèn ép phổi).
Phẫu thuật là phương pháp chính được áp dụng để cải thiện tình trạng bệnh cho trẻ
Sau đó trẻ cần được phẫu thuật mổ giải phóng chèn ép phổi và khâu phục hồi cơ hoành.
Theo nghiên cứu, dù được phẫu thuật và điều trị thoát vị hoành bẩm sinh nhưng những trẻ từng bị bệnh này có thể gặp phải một số bệnh lý đường hô hấp như:
  * Bệnh phổi mạn tính, tăng áp lực động mạch phổi dai dẳng, lồng ngực nhỏ biến dạng, giảm chức năng hô hấp của cơ hoành.
  * Dễ mắc bệnh trào ngược dạ dày thực quản
  * Trẻ cũng có nguy cơ bị tắc ruột, xoắn ruột
  * Trẻ bị thoát vị hoành cũng hay gặp những vấn đề về ăn uống và chậm tăng trưởng
  * Hậu quả của thiếu oxy nặng, tăng CO2, bệnh phổi mạn tính… có thể gây tổn thương não bộ dẫn đến chậm phát triển tinh thần vận động.
  * Trẻ cũng có khả năng bị suy giảm thính lực


Vì thế sau khi điều trị thoát vị hoành bẩm sinh cho trẻ, các bậc cha mẹ cần theo dõi sức khỏe định kỳ. Cần đưa trẻ đi kiểm tra để điều chỉnh phương pháp chữa trị và hỗ trợ phù hợp, giúp cải thiện thính lực, tinh thần… Đồng thời giảm biến chứng sau mổ.
**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/) **- Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [Nguyên nhân gây thoát vị hoành bẩm sinh](https://bvnguyentriphuong.com.vn/benh-di-truyen/tim-hieu-ve-chung-thoat-vi-hoanh-bam-sinh#nguyn-nhn-gy-thot-v-honh-bm-sinh)
  * [Triệu chứng thường gặp khi bị thoát vị hoành bẩm sinh](https://bvnguyentriphuong.com.vn/benh-di-truyen/tim-hieu-ve-chung-thoat-vi-hoanh-bam-sinh#triu-chng-thng-gp-khi-b-thot-v-honh-bm-sinh)
  * [Phương pháp điều trị thoát vị hoành bẩm sinh ở trẻ](https://bvnguyentriphuong.com.vn/benh-di-truyen/tim-hieu-ve-chung-thoat-vi-hoanh-bam-sinh#phng-php-iu-tr-thot-v-honh-bm-sinh-tr)



## ️ Gen và ung thư di truyền: Những điều cần biết

  * [Mối liên hệ giữa ung thư và di truyền](https://bvnguyentriphuong.com.vn/khoa-kham-benh/gen-va-ung-thu-di-truyen-nhung-dieu-can-biet#mi-lin-h-gia-ung-th-v-di-truyn)
  * [Những loại ung thư nào có thể di truyền?](https://bvnguyentriphuong.com.vn/khoa-kham-benh/gen-va-ung-thu-di-truyen-nhung-dieu-can-biet#nhng-loi-ung-th-no-c-th-di-truyn)
  * [Ung thư đại trực tràng](https://bvnguyentriphuong.com.vn/khoa-kham-benh/gen-va-ung-thu-di-truyen-nhung-dieu-can-biet#ung-th-i-trc-trng)
  * [Ung thư tuyến tiền liệt](https://bvnguyentriphuong.com.vn/khoa-kham-benh/gen-va-ung-thu-di-truyen-nhung-dieu-can-biet#ung-th-tuyn-tin-lit)
  * [Các bệnh ung thư di truyền khác](https://bvnguyentriphuong.com.vn/khoa-kham-benh/gen-va-ung-thu-di-truyen-nhung-dieu-can-biet#cc-bnh-ung-th-di-truyn-khc)
  * [Những gen nào có vai trò trong ung thư di truyền?](https://bvnguyentriphuong.com.vn/khoa-kham-benh/gen-va-ung-thu-di-truyen-nhung-dieu-can-biet#nhng-gen-no-c-vai-tr-trong-ung-th-di-truyn)
  * [Gen sinh ung thư](https://bvnguyentriphuong.com.vn/khoa-kham-benh/gen-va-ung-thu-di-truyen-nhung-dieu-can-biet#gen-sinh-ung-th)
  * [Gen ức chế khối u](https://bvnguyentriphuong.com.vn/khoa-kham-benh/gen-va-ung-thu-di-truyen-nhung-dieu-can-biet#gen-c-ch-khi-u)
  * [Xét nghiệm di truyền](https://bvnguyentriphuong.com.vn/khoa-kham-benh/gen-va-ung-thu-di-truyen-nhung-dieu-can-biet#xt-nghim-di-truyn)


Thông thường, cơ thể gửi tín hiệu để cho các tế bào biết khi nào thì ngừng phân chia hoặc chết đi. Nếu có những thay đổi di truyền đối với hành vi của tế bào, chúng sẽ bỏ qua những tín hiệu này và tiếp tục sinh sản. Các tế bào này có thể lây lan vào mô xung quanh và có thể gây ra các khối u.
Trong ung thư, các tế bào phát triển và phân chia với tốc độ nhanh bất thường. Ung thư có thể phát triển do sự thay đổi gen của tế bào. Những thay đổi này có thể do di truyền hoặc do các yếu tố môi trường gây ra.
## **Mối liên hệ giữa ung thư và di truyền**
Theo Viện Ung thư Quốc gia Hoa Kỳ (NCI), ung thư là một bệnh di truyền, có nghĩa là những thay đổi đối với gen của ai đó có thể dẫn đến ung thư. Những thay đổi này có thể do di truyền, có nghĩa là chúng xảy ra trong gia đình. Ngoài ra, những thay đổi xảy ra trong suốt cuộc đời của một người nào đó do các yếu tố môi trường hoặc lỗi khi các tế bào phân chia.
Các đột biến mắc phải, hoặc những thay đổi đối với gen, là nguyên nhân phổ biến nhất của bệnh ung thư. Chúng thường do:
  * Sử dụng thuốc lá
  * Tiếp xúc với bức xạ UV
  * Một số vi-rút
  * Sự lão hóa


## Những loại ung thư nào có thể di truyền?
Các nhà nghiên cứu đã liên kết các đột biến dòng mầm với hơn 50 hội chứng ung thư di truyền. Những hội chứng này có thể làm cho một người có nhiều khả năng phát triển một số loại ung thư. Sau đây là một số loại ung thư chính có thể có tính di truyền:
### Ung thư vú
Ung thư vú là loại ung thư phổ biến thứ hai ở phụ nữ sau ung thư da. Các nghiên cứu tại Hoa Kì cho thấy, các bác sĩ chẩn đoán khoảng 12,9% phụ nữ bị ung thư vú.
Các triệu chứng ung thư vú ở phụ nữ bao gồm:
  * Sưng vú
  * Đau vú hoặc núm vú
  * Sưng hạch bạch huyết
  * Núm vú tụt vào trong
  * Tiết dịch từ núm vú
  * Da ở vú bị lõm xuống


Mặc dù ung thư vú thường phát triển ở phụ nữ, nhưng nam giới cũng có thể phát triển bệnh này. Hiệp hội Ung thư Hoa Kỳ ước tính rằng các bác sĩ sẽ chẩn đoán khoảng 2.650 trường hợp ung thư vú mới ở nam giới ở Hoa Kỳ vào năm 2021.
Các triệu chứng ở nam giới có thể bao gồm:
  * Hình thành một khối u thường không đau trong mô vú
  * Da ở vú bị lõm
  * Tụt núm vú
  * Đóng vảy hoặc đỏ da xung quanh vú
  * Chảy dịch núm vú


Các yếu tố khác nhau ảnh hưởng đến tiên lượng ung thư vú, bao gồm cả giai đoạn mà các bác sĩ phát hiện và điều trị nó. Tỷ lệ sống sót sau 5 năm tương đối tổng thể là 90% đối với phụ nữ.
Tuy nhiên, tỷ lệ sống sót sẽ phụ thuộc vào nhiều yếu tố. Hiện nay tỷ lệ sống sót đã có thể được cải thiện với những tiến bộ trong khoa học y tế.
Các yếu tố có thể ảnh hưởng đến tỷ lệ sống sót bao gồm:
  * Tuổi tác
  * Sức khỏe tổng quát
  * Tình trạng khối u
  * Đáp ứng với điều trị


### Ung thư đại trực tràng
Các triệu chứng của ung thư đại trực tràng bao gồm:
  * Đau bụng
  * Máu trong phân
  * Tụt cân không rõ nguyên nhân
  * Mệt mỏi và suy nhược cơ thể
  * Thay đổi thói quen đại tiện (táo bón hay tiêu chảy)


Tỷ lệ sống sót sau 5 năm đối với bệnh ung thư đại tràng là 63%, đối với ung thư trực tràng, tỷ lệ sống 5 năm là 67%.
### Ung thư tuyến tiền liệt
Sau ung thư da, ung thư tuyến tiền liệt là bệnh ung thư phổ biến nhất ở nam giới. Đây là nguyên nhân thứ hai gây tử vong do ung thư ở nam giới ở Hoa Kỳ sau ung thư phổi.
Một số triệu chứng của ung thư tuyến tiền liệt bao gồm:
  * Máu trong nước tiểu
  * Máu trong tinh dịch
  * Rối loạn cương dương
  * Các vấn đề về tiểu tiện, chẳng hạn như dòng chảy yếu hoặc tăng số lần đi tiểu
  * Yếu ở chân hoặc bàn chân
  * Mất kiểm soát bàng quang
  * Đau ở hông, cột sống hoặc xương sườn


Tỷ lệ sống sót sau 5 năm tương đối tổng thể đối với ung thư tuyến tiền liệt là 98%.
## **Các bệnh ung thư di truyền khác**
Các bệnh ung thư khác có thể di truyền bao gồm:
  * Ung thư buồng trứng
  * Ung thư tuyến tụy
  * Ung thư nội mạc tử cung
  * Ung thư dạ dày
  * Ung thư tế bào hắc tố 


## Những gen nào có vai trò trong ung thư di truyền?
Có nhiều loại gen khác nhau, nhưng không phải tất cả chúng đều gây ra ung thư di truyền. 
### Gen sinh ung thư
Proto-oncogenes là gen giúp tế bào phát triển. Khi tế bào đột biến hoặc tái tạo quá nhiều lần, nó sẽ trở thành “gen gây ung thư”. Các tế bào này ở trạng thái kích hoạt liên tục, liên tục tạo ra các tế bào. Loại đột biến gen này thường không di truyền mà chủ yếu mắc phải.
### Gen ức chế khối u
Những gen này sửa chữa các lỗi trong DNA, làm chậm quá trình tái tạo tế bào và gửi tín hiệu báo cho tế bào chết. Khi các gen này bị ảnh hưởng, chúng không thể sửa lỗi và các tế bào không còn được kiểm soát. Các tế bào tiếp tục phân chia và tái tạo trong một thời gian dài dẫn đến sự phát triển của khối u.
Dưới đây là một số ung thư di truyền phổ biến nhất và các gen đột biến liên quan đến chúng.
**Hội chứng/ Ung thư** |   
---|---  
Ung thư vú và buồng trứng di truyền (HBOC) |  BRCA1, BRCA2  
Lynch; còn được gọi là “Ung thư đại tràng không đa polyp di truyền” (HNPCC) |  EPCAM, MLH1, MSH2, MSH6, PMS2  
Li-Fraumeni |   
Ung thư dạ dày |   
Peutz-Jegher |  STK11  
Nốt ruồi không điển hình / Đa u hắc tố (FAMMM) |  CDKN2A (p16INK4a)  
PTEN Hội chứng khối u Hamartoma (PHTS) |   
Polyposis gia đình; Hội chứng Gardner và Turcot  
## Điều trị
Phương pháp điều trị ung thư di truyền cũng giống như các bệnh ung thư khác. Tùy thuộc vào loại và giai đoạn ung thư, các lựa chọn điều trị có thể bao gồm:
  * Hóa trị liệu
  * Phẫu thuật
  * Xạ trị
  * Liệu pháp nhắm mục tiêu
  * Liệu pháp miễn dịch
  * Cấy ghép tế bào gốc hoặc tủy xương
  * Liệu pháp hormone


Bệnh nhân nên thảo luận về các lựa chọn điều trị với bác sĩ để xem liệu pháp điều trị nào phù hợp với bản thân.
## **Xét nghiệm di truyền**
Xét nghiệm di truyền có thể cho một cá nhân biết liệu họ có tăng nguy cơ phát triển một số bệnh ung thư hay không. Các xét nghiệm giúp tìm kiếm các đột biến gen đối với bệnh ung thư, bao gồm:
  * Ung thư vú
  * Ung thư buồng trứng
  * Ung thư đại tràng
  * Ung thư tuyến giáp
  * Ung thư tuyến tiền liệt
  * Ung thư tuyến tụy
  * Melanoma
  * Sarcoma
  * Ung thư thận
  * Ung thư dạ dày


Mặc dù không phải ai bị đột biến gen cũng sẽ bị ung thư. Tuy nhiên, xét nghiệm di truyền giúp nhiều người có thể hiểu được những nguy cơ của bản thân và điều chỉnh lối sống phù hợp.
Với nhận thức được nâng cao, mọi người có thể nhận thấy các triệu chứng sớm hơn và bắt đầu điều trị sớm hơn nếu ung thư phát triển.
## **Chẩn đoán**
Xét nghiệm di truyền không chẩn đoán ung thư. Thay vào đó, nó cho biết những đối tượng có nguy cơ phát triển ung thư cao hơn. Một kết quả xét nghiệm di truyền dương tính vẫn khống thể chắc chắn rằng người đó sẽ phát triển bệnh ung thư.
Trước khi một cá nhân khỏe mạnh thực hiện xét nghiệm di truyền, có thể thực hiện xét nghiệm di truyền đối với một thành viên trong gia đình bị ung thư trước. Xét nghiệm này nhằm để xem liệu họ có mang gen nguy cơ ung thư có thể được di truyền hay không.
Nếu người bị ung thư có kết quả xét nghiệm dương tính, thì các thành viên khỏe mạnh trong gia đình có thể tiến hành xét nghiệm di truyền dự đoán để xem họ có cùng gen hay không.
**Liên hệ với bác sĩ**
Nên thảo luận với bác sĩ xem xét nghiệm di truyền có phù hợp với họ hay không nếu họ có tiền sử cá nhân hoặc gia đình mắc bệnh ung thư. Các yếu tố có thể gợi ý mối liên hệ di truyền bao gồm ung thư:
  * Ung thư được chẩn đoán ở độ tuổi sớm bất thường
  * Ung thư xuất hiện ở cả hai cơ quan trong một cặp như phổi hoặc thận
  * Phát triển cùng một loại ung thư ở một số người thân cấp một (cha mẹ, con cái, anh chị em ruột)
  * Xuất hiện ung thưu bất thường, chẳng hạn như ung thư vú ở nam giới


**Tóm lược**
Tất cả các bệnh ung thư đều có liên kết di truyền, thông qua các gen di truyền hoặc các đột biến gây ra trong suốt cuộc đời của một người.
Những người có tiền sử gia đình mắc bệnh ung thư có thể thực hiện xét nghiệm di truyền để tìm xem họ có nguy cơ mắc một số bệnh ung thư cao hơn hay không.
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [Mối liên hệ giữa ung thư và di truyền](https://bvnguyentriphuong.com.vn/khoa-kham-benh/gen-va-ung-thu-di-truyen-nhung-dieu-can-biet#mi-lin-h-gia-ung-th-v-di-truyn)
  * [Những loại ung thư nào có thể di truyền?](https://bvnguyentriphuong.com.vn/khoa-kham-benh/gen-va-ung-thu-di-truyen-nhung-dieu-can-biet#nhng-loi-ung-th-no-c-th-di-truyn)
  * [Ung thư đại trực tràng](https://bvnguyentriphuong.com.vn/khoa-kham-benh/gen-va-ung-thu-di-truyen-nhung-dieu-can-biet#ung-th-i-trc-trng)
  * [Ung thư tuyến tiền liệt](https://bvnguyentriphuong.com.vn/khoa-kham-benh/gen-va-ung-thu-di-truyen-nhung-dieu-can-biet#ung-th-tuyn-tin-lit)
  * [Các bệnh ung thư di truyền khác](https://bvnguyentriphuong.com.vn/khoa-kham-benh/gen-va-ung-thu-di-truyen-nhung-dieu-can-biet#cc-bnh-ung-th-di-truyn-khc)
  * [Những gen nào có vai trò trong ung thư di truyền?](https://bvnguyentriphuong.com.vn/khoa-kham-benh/gen-va-ung-thu-di-truyen-nhung-dieu-can-biet#nhng-gen-no-c-vai-tr-trong-ung-th-di-truyn)
  * [Gen sinh ung thư](https://bvnguyentriphuong.com.vn/khoa-kham-benh/gen-va-ung-thu-di-truyen-nhung-dieu-can-biet#gen-sinh-ung-th)
  * [Gen ức chế khối u](https://bvnguyentriphuong.com.vn/khoa-kham-benh/gen-va-ung-thu-di-truyen-nhung-dieu-can-biet#gen-c-ch-khi-u)
  * [Xét nghiệm di truyền](https://bvnguyentriphuong.com.vn/khoa-kham-benh/gen-va-ung-thu-di-truyen-nhung-dieu-can-biet#xt-nghim-di-truyn)



