[[[PLACEHOLDER_HEADING]]]# Bảo vệ bệnh viện kịp thời trả lại túi xách thất lạc cho người dân

Vào sáng ngày 03/9/2025, tại khu vực Khoa Tim mạch Can thiệp, một người dân trong quá trình làm thủ tục đã vô ý để quên túi xách. Trong túi có nhiều giấy tờ tùy thân, một khoản tiền mặt và một số vật dụng cá nhân.
Ngay khi phát hiện sự việc, lực lượng bảo vệ của bệnh viện đã lập tức tiến hành kiểm tra, lập biên bản và thực hiện các bước xác minh theo quy định. Sau đó, toàn bộ túi xách cùng tài sản bên trong đã được trao trả nguyên vẹn cho người để quên.
Hành động kịp thời và tinh thần trách nhiệm của đội ngũ bảo vệ không chỉ giúp người dân tránh được những rủi ro, phiền toái trong cuộc sống, mà còn góp phần củng cố niềm tin của người bệnh và thân nhân vào môi trường khám chữa bệnh an toàn, văn minh và thân thiện.
???? Đây là minh chứng cụ thể cho cam kết của bệnh viện trong việc nâng cao chất lượng dịch vụ và xây dựng hình ảnh một cơ sở y tế tận tâm, chuyên nghiệp, luôn đặt sự an toàn và lợi ích của người bệnh lên hàng đầu.
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh

[[[PLACEHOLDER_HEADING]]]# CẢNH BÁO: Không cho trẻ ăn thực phẩm không rõ nguồn gốc, không nhãn mác

Tối ngày 19/8/2025, Khoa Nhi Bệnh viện Nguyễn Tri Phương đã tiếp nhận và xử trí 2 bệnh nhi nhập viện trong tình trạng hoảng loạn sau khi ăn phải kẹo không có bao bì, không nhãn mác rõ ràng.
Theo lời người nhà, túi thực phẩm do một người quen từ nước ngoài mang về gồm nhiều loại bánh kẹo, trong đó có một số viên kẹo dẻo đặt trong túi zipper không có bao bì. Cả nhà cùng ăn, nhưng chỉ hai bé ăn loại kẹo này. Sau khoảng 30 phút, cả hai xuất hiện các triệu chứng chóng mặt, nhức đầu, buồn nôn, run tay chân, hoảng loạn, dễ kích động và được đưa đến Khoa Cấp cứu.
Kết quả xét nghiệm cho thấy hai bệnh nhi dương tính với chất kích thích Marijuana (Cần sa). Rất may, sau khi được xử trí kịp thời, hiện sức khỏe các bé đã ổn định, tỉnh táo và hết các triệu chứng.
Qua vụ việc này, Bệnh viện khuyến cáo phụ huynh tuyệt đối không cho trẻ sử dụng thực phẩm, bánh kẹo không có nhãn mác, không rõ nguồn gốc xuất xứ. Nhiều loại kẹo, bánh (lạ) có thể chứa thành phần gây hại, thậm chí trộn chất kích thích nguy hiểm, dễ dẫn đến ngộ độc, rối loạn tâm thần, gây hậu quả nghiêm trọng cho sức khỏe trẻ em.
**Khuyến nghị:**
Chỉ sử dụng thực phẩm, bánh kẹo có bao bì, nhãn mác rõ ràng, nguồn gốc tin cậy.
Kiểm soát chặt đồ ăn thức uống mà trẻ được cho/tặng từ người khác.
Khi trẻ có dấu hiệu bất thường sau ăn uống, cần đưa ngay đến cơ sở y tế gần nhất để được xử trí kịp thời.
Bảo vệ sức khỏe trẻ nhỏ bắt đầu từ những lựa chọn an toàn trong từng bữa ăn, món quà!
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh

[[[PLACEHOLDER_HEADING]]]# BVNTP cùng tham gia hỗ trợ chuyên môn tại đặc khu Côn Đảo


[[[PLACEHOLDER_HEADING]]]# Bệnh viện Nguyễn Tri Phương tổ chức khám, chữa bệnh và cấp thuốc miễn phí cho diện chính sách và người dân khó khăn phường An Đông

Ngày 16 tháng 8 năm 2025 – Sáng nay, tại Khoa Khám bệnh - lầu 1 khu A – Bệnh viện Nguyễn Tri Phương, chương trình **“Khám, chữa bệnh và cấp phát thuốc miễn phí cho diện chính sách và người dân có hoàn cảnh khó khăn”** trên địa bàn phường An Đông đã được tổ chức thành công tốt đẹp, mang lại nhiều ý nghĩa thiết thực.
Chương trình do **Phòng Chỉ đạo tuyến** chủ trì, phối hợp cùng **Hội Chữ thập đỏ** , **Đoàn Thanh niên Bệnh viện** và các khoa, phòng chuyên môn. Đây là hoạt động nằm trong chuỗi công tác chăm sóc sức khỏe cộng đồng, hướng đến đối tượng chính sách và những người dân đang gặp khó khăn trong đời sống.
Theo kế hoạch, chương trình đã tiếp nhận và thăm khám cho **100 người dân** thuộc diện chính sách và hộ nghèo tại địa phương. Các bác sĩ đến từ nhiều chuyên khoa như Nội tiết, Nhi, Cơ xương khớp, Lão khoa, Nội thần kinh… đã trực tiếp thăm khám, tư vấn và hướng dẫn người dân cách chăm sóc sức khỏe. Song song đó, **Khoa Dược** phối hợp cùng Hội Chữ thập đỏ cấp phát đầy đủ cơ số thuốc theo chỉ định, đảm bảo an toàn và hiệu quả.
Ngoài hoạt động khám và phát thuốc, **chương trình** cũng chuẩn bị nhiều phần quà ý nghĩa gửi tặng người dân, tạo nên bầu không khí ấm áp, sẻ chia. Công tác tổ chức, từ khâu tiếp nhận, đo huyết áp, hỗ trợ cận lâm sàng, đến hướng dẫn di chuyển và phát thuốc, đều được triển khai đồng bộ, chu đáo.
Đặc biệt, chương trình đã nhận được sự hưởng ứng và tình cảm chân thành từ bà con phường An Đông. Nhiều người dân bày tỏ niềm vui và gửi lời cảm ơn đến tập thể y bác sĩ Bệnh viện Nguyễn Tri Phương vì đã quan tâm, chăm sóc sức khỏe cho cộng đồng, nhất là những người còn nhiều khó khăn trong cuộc sống.
Sự thành công của chương trình là kết quả từ sự phối hợp nhịp nhàng giữa các khoa, phòng cùng tinh thần thiện nguyện của toàn thể cán bộ, nhân viên y tế. Đây cũng là minh chứng sinh động cho tinh thần **“lá lành đùm lá rách”** , thể hiện trách nhiệm xã hội của Bệnh viện Nguyễn Tri Phương trong hành trình chăm sóc và bảo vệ sức khỏe cộng đồng.
Trong thời gian tới, bệnh viện sẽ tiếp tục mở rộng nhiều hoạt động tương tự tại các địa bàn khác, nhằm mang dịch vụ y tế đến gần hơn với người dân, đặc biệt là những đối tượng yếu thế trong xã hội.

[[[PLACEHOLDER_HEADING]]]# Hội thảo quốc tế về Ứng dụng đặt điện cực não sâu ghi điện não đồ (SEEG) trong phẫu thuật động kinh

Trong hai ngày 21 – 22/8/2025, Bệnh viện Nguyễn Tri Phương đã tổ chức thành công Hội thảo quốc tế về Ứng dụng đặt điện cực não sâu ghi điện não đồ (SEEG) trong phẫu thuật động kinh, thu hút sự tham gia của nhiều chuyên gia thần kinh, ngoại thần kinh và điện sinh lý học trong và ngoài nước.
Hội nghị đã mang đến những bài báo cáo chuyên sâu từ các chuyên gia hàng đầu như PGS.TS. Hsiang-Yu Yu và PGS.TS. Cheng-chia Lee (Bệnh viện Cựu Chiến binh Đài Bắc, Đài Loan), cùng sự chia sẻ kinh nghiệm từ các bác sĩ Bệnh viện Nguyễn Tri Phương. Các nội dung tập trung vào nguyên tắc thiết kế SEEG, lựa chọn quỹ đạo điện cực, vai trò của kích thích trong SEEG và kết quả bước đầu trong phẫu thuật động kinh tại Việt Nam.
Phát biểu tại hội thảo, TS.BS Lê Cao Phương Duy, Phó Giám đốc Bệnh viện Nguyễn Tri Phương nhấn mạnh: Thành công của chương trình là kết quả của quá trình không ngừng học tập, nghiên cứu và hợp tác quốc tế. Đây sẽ là nền tảng vững chắc để bệnh viện tiếp tục phát triển chuyên sâu, mang lại lợi ích thiết thực cho người bệnh.
Đặc biệt, điểm nhấn của chương trình là ca phẫu thuật thị phạm ứng dụng SEEG, do TS.BS. Phạm Anh Tuấn – Trưởng khoa Ngoại Thần kinh Bệnh viện Nguyễn Tri Phương – phối hợp cùng các chuyên gia quốc tế thực hiện. Đây là cơ hội quý báu để đội ngũ bác sĩ trong nước trực tiếp quan sát và học hỏi toàn bộ quy trình, từ chuẩn bị, đặt điện cực cho đến ghi nhận và phân tích dữ liệu điện não.
Kỹ thuật SEEG được đánh giá là một trong những bước tiến quan trọng trong phẫu thuật động kinh, giúp xác định chính xác vùng sinh động kinh, từ đó nâng cao hiệu quả và độ an toàn cho người bệnh. Việc làm chủ kỹ thuật này mở ra cơ hội cải thiện chất lượng điều trị động kinh tại Việt Nam, đồng thời đánh dấu bước tiến lớn trong quá trình hội nhập và phát triển chuyên môn của y tế nước nhà.
Với sự chuẩn bị chu đáo và nội dung chuyên môn đặc sắc, hội nghị và ca mổ thị phạm SEEG đã để lại ấn tượng mạnh mẽ, góp phần khẳng định vị thế của Bệnh viện Nguyễn Tri Phương trong lĩnh vực ngoại thần kinh và điều trị động kinh.
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh

[[[PLACEHOLDER_HEADING]]]# Lễ ký kết hợp tác toàn diện giữa BV Nguyễn Tri Phương - Agribank CN Bình Thạnh và trao tài trợ an sinh y tế

Tham dự buổi lễ có đại diện lãnh đạo Agribank khu vực miền Nam, Agribank Chi nhánh Bình Thạnh, đại diện Quỹ Bầu Ơi, Công ty Cổ phần Điện gió Phước Hữu cùng Ban Giám đốc, cán bộ nhân viên Bệnh viện Nguyễn Tri Phương. Sự hiện diện và đồng hành của các đơn vị là nguồn động viên to lớn để bệnh viện tiếp tục hoàn thành sứ mệnh chăm sóc sức khỏe cộng đồng. 
Trong khuôn khổ chương trình: 
  * Agribank Chi nhánh Bình Thạnh và Bệnh viện Nguyễn Tri Phương đã thực hiện ký kết hợp tác toàn diện, hướng tới mục tiêu nâng cao chất lượng dịch vụ y tế, đẩy mạnh ứng dụng công nghệ trong thanh toán không dùng tiền mặt và mở rộng các hoạt động an sinh xã hội. 
  * Agribank đã trao tặng dự án Robot hỗ trợ bệnh nhân với tổng giá trị 970 triệu đồng, góp phần cải thiện hiệu quả khám chữa bệnh và chăm sóc người bệnh. 
  * Quỹ Bầu Ơi và Công ty Cổ phần Điện gió Phước Hữu đã trao tặng 50 xe lăn và 50 phần quà đến các bệnh nhân có hoàn cảnh khó khăn. 


Sau lễ ký kết, đoàn đã trực tiếp đến các khoa để trao tận tay 50 phần quà cho bệnh nhân, mang đến những giây phút xúc động và đầy tình nhân ái.
Phát biểu tại buổi lễ, đại diện Bệnh viện Nguyễn Tri Phương bày tỏ lòng tri ân sâu sắc đến Agribank Chi nhánh Bình Thạnh, Quỹ Bầu Ơi, Công ty Cổ phần Điện gió Phước Hữu cùng các đơn vị đồng hành. Những nghĩa cử cao đẹp và sự chung tay vì cộng đồng của quý đơn vị đã góp phần lan tỏa tinh thần nhân văn, tiếp thêm niềm tin và nghị lực cho người bệnh trong hành trình chữa trị.
Buổi lễ đã diễn ra trong không khí trang trọng, ấm áp và thành công tốt đẹp. Đây sẽ là tiền đề mở ra nhiều cơ hội hợp tác bền chặt giữa các đơn vị, đồng thời khẳng định cam kết của Bệnh viện Nguyễn Tri Phương trong việc nâng cao chất lượng dịch vụ y tế và chăm lo an sinh xã hội.
Bệnh viện Nguyễn Tri Phương trân trọng cảm ơn và kính chúc sức khỏe, thành công đến các mạnh thường quân, quý đại biểu và toàn thể quý khách đã hiện diện, đồng hành trong chương trình.
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh

[[[PLACEHOLDER_HEADING]]]# Giao lưu chia sẻ kinh nghiệm các hoạt động công tác xã hội giữa Bệnh viện Nguyễn Tri Phương và Bệnh viện Nhân dân Gia Định

Sáng ngày 13/8/2025, Bệnh viện Nguyễn Tri Phương hân hạnh đón tiếp Đoàn công tác Bệnh viện Nhân dân Gia Định đến tham quan và học tập kinh nghiệm trong lĩnh vực công tác xã hội tại môi trường bệnh viện công.
Buổi giao lưu diễn ra trong bầu không khí thân tình, cởi mở. Lãnh đạo và cán bộ phụ trách công tác xã hội của hai bệnh viện đã cùng nhau trao đổi, chia sẻ những mô hình, giải pháp hiệu quả trong việc hỗ trợ người bệnh, nâng cao chất lượng dịch vụ y tế và phát huy vai trò cầu nối giữa bệnh viện – người bệnh – cộng đồng.
Trong thời gian vừa qua, công tác xã hội tại Bệnh viện Nguyễn Tri Phương đã triển khai bài bản, toàn diện và đạt hiệu quả rõ rệt, tập trung vào 6 hoạt động chính:
  * Hỗ trợ khẩn cấp tại khoa Cấp cứu – kịp thời giúp người bệnh trong tình huống khó khăn đột xuất.
  * Hỗ trợ viện phí – giảm gánh nặng tài chính cho bệnh nhân nội trú có hoàn cảnh khó khăn.
  * Bữa cơm trên tường – cung cấp suất ăn miễn phí hàng ngày.
  * Gian hàng chia sẻ yêu thương – nơi trao tặng và đổi các vật phẩm thiết yếu.
  * Hỗ trợ chi phí sinh hoạt thiết yếu – giúp bệnh nhân duy trì cuộc sống trong thời gian điều trị.
  * Chuyến xe nghĩa tình – hỗ trợ phương tiện đưa đón bệnh nhân về quê hoặc đến bệnh viện


Đây là minh chứng rõ rệt cho cam kết của Bệnh viện Nguyễn Tri Phương trong việc xây dựng môi trường chăm sóc toàn diện, đáp ứng nhu cầu y tế, tâm lý và xã hội của người bệnh.
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh

[[[PLACEHOLDER_HEADING]]]# HỆ SINH THÁI HỖ TRỢ NGƯỜI BỆNH KHÓ KHĂN

Các mô hình hỗ trợ bao phủ toàn bộ các hình thức hỗ trợ người bệnh khó khăn và tận dụng các phương tiện hỗ trợ điều hành với công nghệ 4.0: 
  * Hỗ trợ khẩn cấp nhập viện: Người bệnh có hoàn cảnh khó khăn (NBHCKK) khi nhập viện cấp cứu sẽ được Quỹ Tâm Nguyện Việt ứng 5.000.000đ viện phí. NBHCKK có thể yên tâm nhập viện điều trị, bệnh viện cũng có thể đẩy nhanh các thủ tục và thực hiện một số xét nghiệm bên ngoài Bệnh viện (ví dụ: xét nghiệm tìm độc chất…)
  * Bữa cơm dinh dưỡng: Bệnh viện kết nối với chương trình Dĩa cơm trên tường (lan tỏa trên mạng xã hội facebook) và bếp ăn tình thương (Công ty P.Dussmann, 100% vốn của Đức) để trao suất ăn hàng ngày cho bệnh nhân tại căntin bệnh viện. Bữa ăn tại bệnh viện đảm bảo cả về vệ sinh an toàn thực phẩm và chức năng hỗ trợ điều trị từng loại bệnh lý riêng biệt.
  * Hỗ trợ viện phí: Kinh phí hỗ trợ được kết nối từ các nguồn quỹ sẵn có và nhiều nguồn xã hội hóa của các tổ chức từ thiện (Từ Tâm, Tâm nguyện Việt, Chia sẻ - Sharing…), thực hiện kết nối qua các group viber, zalo để các tổ chức hoặc các mạnh thường quân nhanh chóng nắm bắt tình hình thực tế của người bệnh. 
  * Hỗ trợ chi phí chi tiêu khác cho NBHCKK khi nằm viện được hỗ trợ từ Nhóm CLB Tình người Sài Gòn hỗ trợ hàng tháng.
  * Chuyến xe nghĩa tình: Nghĩa tử là nghĩa tận, những ca tử vong hoặc bệnh nặng xin về được xe công xa đưa về tận nhà dù khó khăn hay không khó khăn, dù vị trí địa lý có xa xôi trắc trở đến đâu.
  * Gian hàng chia sẻ yêu thương: Những sản phẩm quần áo, vật dụng… được vận động quyên góp và bán lại với những giá rất rẻ năm ngàn, mười ngàn…và cả giá không đồng (0đ). Tất cả số tiền hoạt động từ gian hàng yêu thương sẽ nhập quỹ hỗ trợ người bệnh khó khăn để chia sẻ về viện phí. Sự kêu gọi và ý nghĩa hoạt động được lan tỏa trên các kênh truyền thông của bệnh viện (trang tin điện tử, facebook, zalo offical, youtube, lotus). Mỗi nhân viên y tế hoặc bất cứ ai trong xã hội đều có thể là người cho đi, là người giúp đỡ bệnh nhân có hoàn cảnh khó khăn trong quá trình khám và điều trị tại BV Nguyễn Tri Phương.
  * Gian hàng chia sẻ yêu thương đã giúp nâng dậy tâm hồn của mỗi nhân viên hay mỗi người trong cộng đồng quan tâm cũng như tạo điều kiện cho tất cả mọi người đều có cơ hội để giúp đỡ người khác dù từ vật dụng nhỏ nhất mà mình chưa có nhu cầu sử dụng sự sẻ chia dù ít hay nhiều tùy khả năng của mình trong mỗi ngày.
  * Bằng những phương tiện truyền thông của thời đại 4.0, việc hỗ trợ bệnh nhân được nhanh hơn (các group viber, zalo…) và thông tin chính thống được lan tỏa hơn (facebook, youtube, lotus…) để cả cộng đồng cùng tham gia.



[[[PLACEHOLDER_HEADING]]]# Hội nghị Dược lâm sàng năm 2025 tại Bệnh viện Nguyễn Tri Phương

Vào lúc **08h30 – 11h30, Thứ Tư, ngày 10/9/2025** , tại **Hội trường A – Lầu 5, Bệnh viện Nguyễn Tri Phương** , đã diễn ra **Hội nghị Dược lâm sàng năm 2025**.
Đến tham dự hội nghị có sự hiện diện của **TS. BS Lê Cao Phương Duy - Phó Giám đốc Bệnh viện** , **Ths. BS. CKII Lương Công Minh - Phó Giám đốc bệnh viện** cùng các báo cáo viên: 
  * DS. CKII Nguyễn Thu Thảo - Trưởng khoa Dược, Bệnh viện Nguyễn Tri Phương.
  * TS. DS Võ Thị Hà - Phó Trưởng khoa Dược, Bệnh viện Nguyễn Tri Phương.
  * DS. CKII Trương Thúy Quỳnh - Phó Trưởng khoa Dược, Bệnh viện Nhiệt Đới
  * và một số Dược sĩ Lâm Sàng cùng các báo cáo viên, nhân viên y tế khác.


Phát biểu khai mạc hội nghị, **TS.BS. Lê Cao Phương Duy****- Phó Giám đốc Bệnh viện** đã nhấn mạnh vai trò ngày càng quan trọng của Dược lâm sàng trong công tác chăm sóc, điều trị toàn diện cho người bệnh.
Hội nghị đã tập trung thảo luận nhiều chủ đề có giá trị thực tiễn và gắn liền với hoạt động chuyên môn, bao gồm:
  * Thực trạng sử dụng thảo dược trên bệnh nhân tăng huyết áp ngoại trú.
  * Chăm sóc dược cho người bệnh tim mạch.
  * Vai trò của Dược lâm sàng trong quản lý sử dụng kháng sinh – kháng nấm.
  * Theo dõi nồng độ vancomycin theo chiến lược AUC/MIC.
  * Quản lý giảm đau và phòng ngừa huyết khối tĩnh mạch.


Hội nghị là dịp để đội ngũ dược sĩ lâm sàng và cán bộ y tế **cùng chia sẻ kinh nghiệm, cập nhật kiến thức mới** và **thúc đẩy hoạt động Dược lâm sàng tại cơ sở** , góp phần nâng cao hiệu quả điều trị, an toàn người bệnh và chất lượng dịch vụ y tế.
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh

[[[PLACEHOLDER_HEADING]]]# THÔNG BÁO LỊCH NGHỈ LỄ QUỐC KHÁNH 2025

Bệnh viện Nguyễn Tri Phương trân trọng thông báo đến lịch nghỉ lễ Quốc Khánh 2025 như sau:
  * **Thứ Hai (01/09/2025) đến thứ Ba (02/09/2025): Nghỉ lễ Quốc Khánh**
  * **Thứ Tư (03/09/2025): Hoạt động bình thường**


**Hoạt động khám ngoài giờ thứ 7 ngày 30.8.2025 không bị ảnh hưởng**
Kính chúc kỳ nghỉ lễ Quốc Khánh vui vẻ và ý nghĩa!
Trân trọng!

[[[PLACEHOLDER_HEADING]]]# Bảo vệ bệnh viện hỗ trợ thu hồi và trao trả 2 trường hợp điện thoại bị đánh rơi

Ngày 03/08/2025, tại Khoa Chấn thương chỉnh hình - Bệnh viện Nguyễn Tri Phương, thân nhân bệnh nhân trong lúc di chuyển đã sơ ý làm rơi điện thoại xuống hố thang máy A1. Sau khi nhận được trình báo, Đội bảo vệ bệnh viện đã nhanh chóng phối hợp với tổ thợ và kỹ thuật viên thang máy tiến hành xuống hố thang để hỗ trợ thu hồi thiết bị. Chiếc điện thoại sau đó đã được trao trả cho người đánh rơi.
Tiếp theo, vào sáng ngày 04/08/2025, tại khu vực ghế chờ trước phòng khám A12 – Khoa Khám bệnh, lực lượng bảo vệ phát hiện một chiếc điện thoại màu trắng bị bỏ quên. Ngay sau đó, đội bảo vệ đã lập biên bản và tiến hành xác minh, liên hệ để trao trả cho chủ sở hữu.
Hai trường hợp trên thể hiện tinh thần trách nhiệm, phối hợp kịp thời của Đội bảo vệ trong công tác hỗ trợ, đảm bảo an ninh – tài sản cho người bệnh và thân nhân tại bệnh viện.
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh

[[[PLACEHOLDER_HEADING]]]# Xét nghiệm sàng lọc bệnh lao trước khi nhập cảnh vào Nhật Bản (JPETS) triển khai tại BV Nguyễn Tri Phương

  * [Đối tượng khám sàng lọc bệnh lao trước khi nhập cảnh Nhật Bản](https://bvnguyentriphuong.com.vn/thong-tin-benh-vien/xet-nghiem-sang-loc-benh-lao-truoc-khi-nhap-canh-vao-nhat-ban-jpets#i-tng-khm-sng-lc-bnh-lao-trc-khi-nhp-cnh-nht-bn)
  * [Cách thức thực hiện khám sàng lọc bệnh lao](https://bvnguyentriphuong.com.vn/thong-tin-benh-vien/xet-nghiem-sang-loc-benh-lao-truoc-khi-nhap-canh-vao-nhat-ban-jpets#cch-thc-thc-hin-khm-sng-lc-bnh-lao)
  * [Lưu đồ thực hiện](https://bvnguyentriphuong.com.vn/thong-tin-benh-vien/xet-nghiem-sang-loc-benh-lao-truoc-khi-nhap-canh-vao-nhat-ban-jpets#lu-thc-hin)


**Xét nghiệm sàng lọc bệnh lao trước khi nhập cảnh vào Nhật Bản (JPETS)** là yêu cầu công dân từ 1 số quốc gia có ý định nhập cảnh và lưu trú trung dài hạn tại Nhật Bản phải xuất trình giấy tờ chứng minh không mắc bệnh lao thông qua kết quả kiểm tra như kết quả chụp X-quang ngực, v.v. tại hệ thống phòng khám chỉ định trước khi đến Nhật Bản.
## Đối tượng khám sàng lọc bệnh lao trước khi nhập cảnh Nhật Bản
Việc sàng lọc bệnh lao sẽ áp dụng đối với công dân đến từ Philippines, Việt Nam, Indonesia, Nepal, Myanmar và Trung Quốc (*1) có ý định nhập cảnh và lưu trú tại Nhật Bản với tư cách là “người lưu trú trung /dài hạn” (*2) (không bao gồm người có giấy phép tái nhập cảnh), hoặc những người nhập cảnh, lưu trú theo _**Thông báo hoạt động đặc định số 53 và số 54**_ (Người làm việc từ xa ở nước ngoài và vợ/chồng hoặc con của người làm việc từ xa ở nước ngoài).
(*1) Đối với trường hợp các nước Indonesia, Myanmar và Trung Quốc, chưa xác định thời gian bắt đầu do vẫn đang điều chỉnh (*2) “Người lưu trú trung và dài hạn” là những cá nhân được quy định tại Điều 19-3 của Luật Quản lý xuất nhập cảnh và Công nhận Người tị nạn (là người nước ngoài có tư cách lưu trú đang sinh sống tại Nhật Bản, không bao gồm những người thuộc một trong các nhóm sau: (1) người được cấp thời hạn lưu trú không quá ba tháng; (2) người được cấp tư cách lưu trú ngắn hạn; (3) người được cấp tư cách lưu trú Ngoại giao hoặc Công vụ; và (4) người được Bộ Tư pháp quy định là tương đương với người được nêu từ (1) đến (3)).
## Cách thức thực hiện khám sàng lọc bệnh lao
  1. Người thuộc đối tượng khám sàng lọc bệnh lao cần khám sức khỏe và chụp X-quang ngực (hoặc xét nghiệm nước bọt theo quyết định của bác sĩ nếu có vấn đề đáng lo ngại) tại các cơ sở y tế chỉ định (danh sách [**tại đây**](https://www.mhlw.go.jp/content/001471856.pdf)
[[[PLACEHOLDER_FILE]]] Nội dung trong file:

Designated Panel Clinics MGA NAKATALAGANG PANEL CLINIC िनधा  रत ानल  िनकह  PHÒNG KHÁM ĐƯỢC CHỈ ĐỊNH指定健診医療機関
Designated Panel Clinics
指定健診医療機関
The Philippines
Pilipinas
フィリピン
〈Manila〉
IOM Manila Health Centre
Address: Trafalgar Plaza Building, 105 H.V. Dela Costa St., Brgy. Bel-air, Makati City 1227 Metro Manila,
Philippines
Telephone:(+63) 9175934688 (+63) 9199934667
Website: https://philippines.iom.int/manila-health-centre
Nationwide Health Systems Aux, Inc.
Address: 2nd Floor Zeta II Annex Bldg 191 Salcedo Street Legaspi Village, Makati City, 1229, Philippines
Telephone:(+63) 288100785
Website: https://nhsgroup.ph/makati.html
St. Luke's Medical Center Extension Clinic
Address: 1177 J. Bocobo Street, Ermita, Manila
Telephone:(+63) 285210020
Website: https://www.slec.ph
〈Baguio〉
Nationwide Health Systems Baguio, Inc.
Address: Unit 10-12, 2nd Floor City Hub Building, 92 Upper General Luna Road, Corner Leonard Wood
Road
Telephone:(+63) 9271815150 (+63) 9177148963
Website: https://nhsgroup.ph/baguio.html
〈Davao〉
Nationwide Health Systems Davao, Inc.
Address: 2nd floor Central Lab Tower E. Quirino Ave. Brgy 10-A Poblacion District, Davao City, 8000,
Philippines
Telephone:(+63) 822965136
Website: https://nhsgroup.ph/davao.htmlDesignated Panel Clinics MGA NAKATALAGANG PANEL CLINIC िनधा  रत ानल  िनकह  PHÒNG KHÁM ĐƯỢC CHỈ ĐỊNH指定健診医療機関
〈Cebu〉
Nationwide Health Systems Cebu, Inc.
Address: Units C103 C104 B108 Tango Plaza Bldg., Queen's Road, Kamputhaw, Cebu City Philippines
Telephone:(+63) 322386053
Website: https://nhsgroup.ph/cebu.htmlDesignated Panel Clinics MGA NAKATALAGANG PANEL CLINIC िनधा  रत ानल  िनकह  PHÒNG KHÁM ĐƯỢC CHỈ ĐỊNH指定健診医療機関
Nepal
नेपाल 
ネパール
〈Kathmandu ／काठमाडौं〉
CIWEC Hospital Pvt. Ltd.
िसवेकह  टल ा=िल=काठमा ौ
Address: Lainchour, Kathmandu, Nepal *Opposite the British Embassy
िसवेकह  टल ा.ली.,लैनचौरकपुरधारामाग ,काठमा ा
Telephone:(+977) 14524111 (+977) 9847758380
Website: https://www.ciwechospital.com
Grande International Hospital
 ा ीइ रनेशनलह  टल
Address: Dhapasi, Kathmandu, Nepal
धापासी, काठमाडौं, नेपाल 
Telephone:(+977) 15159266 (+977) 9801202531
Website: https://www.grandehospital.com
IOM Migration Health Assessment Center
आइओएममाइ ेसनहे एसे े से रकाठमाडौं
Address: Lazimpat Sadak, Panipokhari, Ward-3, Kathmandu, Nepal *Opposite the Embassy of Japan
लािज ाटसडक,पानीपोखरीवाड -३
Telephone:(+977) 15970001 (+977) 9801004586
Website: https://nepal.iom.int/health-assessment
Nepal Mediciti Hospital Registered as Ashwins Medical College & Hospital Pvt. Ltd.
आि  ्मेिडकलकलेजए ह  टल ा.िल(नेपालमेिडिसिट)
Address: Sainbu, Bhaisepati-18, Lalitpur
सैवु,भैसीपाटीलिलतपुर
Telephone:(+977) 14217766
Website: https://www.nepalmediciti.com
Norvic International Hospital & Medical College Ltd
Address:Thapathali, Kathmandu, 44600, Nepal
Telephone:(+977) 15970032
Website: https://norvichospital.comDesignated Panel Clinics MGA NAKATALAGANG PANEL CLINIC िनधा  रत ानल  िनकह  PHÒNG KHÁM ĐƯỢC CHỈ ĐỊNH指定健診医療機関
Siddhi Poly Clinic Health Service
िस ीपोिल  िनकहे सिभ स
Address: Dillibazaar, Charkhal, Kathmandu, Nepal.
चारखाल,िड ीबजार,िथरबमसडक,काठमा ौं।
Telephone:(+977) 14547604
Website: https://www.siddhilab.com.np
Travel And Mountain Medicine Centre
ट ाभलए माउ ेन मेिडिसन से र
Address: KALDHARAMARG 20356, KATHMANDU, BAGMATI 44600, NEPAL
का धारामाग २०३५६,काठमाडौं,नेपाल
Telephone:(+977) 14963614
Website: https://tmmcnepal.com
〈Pokhara ／पोखरा〉
CIWEC Hospital Pvt Ltd, Pokhara Nepal
िसवेकह  टल ा=िल=पोखरा
Address: 14th Street, Lakeside, Pokhara, 33700, Nepal
िसवेकह  टल ा.ली.   टनं१४,लेकसाइड,पोखरा
Telephone:(+977) 61451111 (+977) 61457053
Website: https://ciwechospital.com
〈Damak／दमक〉
IOM Migration Health Assessment Center Damak
आइ ओ एम  माइ ेसनहे एसे े से र दमक
Address: Devkota Chowk-6, New Vegetable Market, Jhapa, Nepal
देवकोटाचोक,दमक‒११झापा,नेपाल
Telephone:(+977) 15970001 (+977) 9801004586
Website: https://nepal.iom.int/health-assessmentDesignated Panel Clinics MGA NAKATALAGANG PANEL CLINIC िनधा  रत ानल  िनकह  PHÒNG KHÁM ĐƯỢC CHỈ ĐỊNH指定健診医療機関
Viet Nam
Việt Nam
ベトナム
〈Hanoi／Hà Nội〉
DYM MEDICAL CENTER HANOI
DYM MEDICAL CENTER HÀ NỘI 
Address: Basement B1, Epic Tower, Alley 19 Duy Tan Street, Cau Giay Ward, Hanoi City, Vietnam
Tầng hầm B1, tòa Epic Tower, ngõ 19 Duy Tân, Phường Cầu Giấy, Tp. Hà Nội, Việt Nam 
Telephone: (+84) 2477710170
Website: https://dymmedicalcenter.com.vn/
Family Medical Practice, Hanoi
Phòng Khám Gia Đình Hà Nội 
Address: 298 I KIM MA STREET, KIM MA PROVINCE, BA DINH DISTRICT, HANOI CITY, VIETNAM.
298 I - Kim Mã - Ba Đình - Hà Nội 
Telephone: (+84) 2438430748
Website: https://www.vietnammedicalpractice.com/
IOM Migration Health Assessment Centre - Ha Noi City
Trung tâm Khám Sức khỏe Di cư của IOM - Thành Phố Hà Nội 
Address: 10thFloor, Keangnam Landmark 72 Tower, Pham Hung St, Me Tri Ward, Nam Tu Liem Dist, Ha
Noi City.
Tầng 10, Keangnam Landmark 72 Tower, Đường Phạm Hùng, Phường Mễ Trì, Quận Nam Từ Liêm, Thành 
phố Hà Nội. 
Telephone: (+84) 24 37366258 (+84) 966319066 (Hotline)
Website: https://vietnam.iom.int/vi/trung-tam-kham-suc-khoe-di-cu
Raffles Medical – Hanoi
Phòng khám Raffles Medical tại Hà Nội 
Address: 51 Xuan Dieu Str., Tay Ho Dist., Vietnam, Hanoi
Số 51 đường Xuân Diệu, phường Quảng An, quận Tây Hồ, TP. Hà Nội, Việt Nam 
Telephone: (+84) 2439340666
Website: https://en.rafflesmedical.vn/Designated Panel Clinics MGA NAKATALAGANG PANEL CLINIC िनधा  रत ानल  िनकह  PHÒNG KHÁM ĐƯỢC CHỈ ĐỊNH指定健診医療機関
TRANSPORT HOSPITAL JOINT STOCK COMPANY
BỆNH VIỆN GIAO THÔNG VẬN TẢI 
Address: No 169, Huynh Thuc Khang street, Lang ward, Hanoi City
Số 169, phố Huỳnh Thúc Kháng, phường Láng, Hà Nội  
Telephone: (+84) 2437664751
Website: https://giaothonghospital.vn
〈Ho Chi Minh City ／Thành phố Hồ Chí Minh〉
Care1 Executive Health Care Center by HCM City Family Medical Practice
Trung Tâm Chăm Sóc Sức Khoẻ  Care1 
Address: Manor 1 Building, 91 Nguyen Huu Canh Street, Ward 22, Binh Thanh District, Ho Chi Minh City,
Vietnam
Tòa nhà The Manor 1 - 91 Nguyễn Hữu Cảnh, Phường 22, Quận Bình Thạnh, Tp. Hồ Chí Minh, Việt Nam 
Telephone: (+84) 2835140757
Website: https://www.vietnammedicalpractice.com/care1/en
DYM MEDICAL CENTER PHU MY HUNG
DYM MEDICAL CENTER PHÚ MỸ HƯNG 
Address: Unit 3A01, The Grace Tower, 71 Hoang Van Thai, Tan My Ward, Ho Chi Minh City, Vietnam
Phòng 3A01, Tòa nhà The Grace, 71 Hoàng Văn Thái, Phường Tân Mỹ, Tp. Hồ Chí Minh, Việt Nam 
Telephone: (+84) 2877710170
Website: https://dymmedicalcenter.com.vn/
DYM MEDICAL CENTER SAIGON
DYM MEDICAL CENTER SÀI GÒN
Address: Unit B103, Basement 1, mPlaza Saigon Building, 39 Le Duan, Sai Gon Ward, Ho Chi Minh City,
Vietnam
Phòng B103, Tầng hầm 1, tòa nhà mPlaza Saigon, số 39 Lê Duẩn, Phường Sài Gòn, Tp. Hồ Chí Minh, 
Việt Nam 
Telephone: (+84) 2835210170
Website: https://dymmedicalcenter.com.vn/
FAMILY MEDICAL PRACTICE DIAMOND PLAZA MEDICAL CENTER
PHÒNG KHÁM GIA ĐÌNH CHI NHÁNH DIAMOND PLAZA 
Address: DIAMOND PLAZA BUILDING, 34 LE DUAN, SAIGON WARD, HO CHI MINH CITY
TÒA NHÀ DIAMOND PLAZA, 34 ĐƯỜNG LÊ DUẨN, PHƯỜNG SÀI GÒN, THÀNH PHỐ HỒ CHÍ MINH 
Telephone: (+84) 2838227848
Website: https://www.vietnammedicalpractice.com/Designated Panel Clinics MGA NAKATALAGANG PANEL CLINIC िनधा  रत ानल  िनकह  PHÒNG KHÁM ĐƯỢC CHỈ ĐỊNH指定健診医療機関
IOM Migration Health Assessment Centre - Ho Chi Minh City
Trung tâm Khám Sức khỏe Di cư tại IOM -Thành phố Hồ Chí Minh 
Address: 1B Pham Ngoc Thach St, Ben Nghe Ward, Dist.1, Ho Chi Minh City.
1B Phạm Ngọc Thạch, Phường Bến Nghé, Quận 1, Thành phố Hồ Chí Minh 
Telephone: (+84) 2838222057
Website: https://vietnam.iom.int/vi/trung-tam-kham-suc-khoe-di-cu
Military Hospital 175
Bệnh viện Quân y 175 
Address: 786 Nguyen Kiem street, Ward Hanh Thong, Ho Chi Minh City
786 Nguyễn Kiệm, P. Hạnh Thông, TP. Hồ Chí Minh 
Telephone: (+84) 932287338 (+84) 946979969
Website: https://benhvien175.vn/
Nguyen Tri Phuong Hospital Clinic
Phòng khám bệnh viện Nguyễn Tri Phương 
Address: 468 Nguyen Trai Street, An Dong Ward, Ho Chi Minh City
468 đường Nguyễn Trãi, phường An Đông, Thành phố Hồ Chí Minh 
Telephone: (+84) 2839234332
Website: https://bvnguyentriphuong.com.vn/
Priority Healthcare Clinic (HCMC)
Address: Tan Da Court, 86 Tan Da Street, Cho Lon Ward, Ho Chi Minh City
Tòa nhà Tản Đà, 86 Tản Đà, Phường Chợ Lớn, Thành Phố Hồ Chí Minh, Việt Nam 
Telephone: (+84) 2836201596
Website: https://priorityhealth.vn/
Raffles Medical Ho Chi Minh Clinic
Phòng khám Raffles Medical tại TP. Hồ Chí Minh 
Address: 285B Dien Bien Phu, Ward Vo Thi Sau, District 3, Ho Chi Minh City
285B Điện Biên Phủ, Phường Võ Thị Sáu, Quận 3, TP. Hồ Chí Minh 
Telephone: (+84) 2838240777
Website: https://en.rafflesmedical.vn/Designated Panel Clinics MGA NAKATALAGANG PANEL CLINIC िनधा  रत ानल  िनकह  PHÒNG KHÁM ĐƯỢC CHỈ ĐỊNH指定健診医療機関
〈Da Nang ／Đà Nẵng〉
Family General Hospital
Address: 73 Nguyen Huu Tho street, Hoa Thuan Tay ward, Hai Chau district, Da Nang city, 550000,
VietNam
Telephone: (+84) 833632333
Website: https://familyhospital.vn/
Family Medical Practice Danang
Address: 96 - 98 Nguyen Van Linh street, Nam Duong ward, Hai Chau district, Da Nang city, Viet Nam
Telephone: (+84) 2363582699
Website: https://www.vietnammedicalpractice.com/) ở các quốc gia trong diện yêu cầu.
  2. Giấy chứng nhận không mắc bệnh lao sẽ được Phòng khám cấp khi người nộp đơn không mắc bệnh lao.
  3. Người nộp đơn sẽ phải nộp Giấy chứng nhận không mắc bệnh lao khi nộp đơn xin Giấy chứng nhận tư cách lưu trú (hoặc khi nộp đơn xin thị thực tại cơ quan ngoại giao Nhật Bản ở nước ngoài trong trường hợp họ nộp đơn xin thị thực mà không có Giấy chứng nhận tư cách lưu trú).


_**[Một số lưu ý]**_
  * Người nộp đơn sẽ phải xuất trình hộ chiếu hợp lệ để xác minh danh tính của mình.
  * Tại Bệnh viện Nguyễn Tri Phương: Chi phí sàng lọc bệnh lao sẽ thu theo gói (đã bao gồm toàn bộ chi phí).
  * Số ngày dự kiến để cấp Giấy chứng nhận không mắc bệnh lao có thể khác nhau tùy theo điều kiện hoạt động cụ thể.
  * Về nguyên tắc, Giấy chứng nhận không mắc bệnh lao sẽ có hiệu lực trong 180 ngày kể từ ngày chụp X-quang ngực. (Thời hạn có hiệu lực có thể giảm xuống còn 90 ngày tùy thuộc vào một số trường hợp cụ thể. Phòng khám sẽ thông tin cụ thể trong từng trường hợp.)
  * Người nộp đơn phải giữ bản sao Giấy chứng nhận không mắc bệnh lao vì có thể được yêu cầu xuất trình giấy này ngay cả sau khi nhập cảnh vào Nhật Bản.


## Lưu đồ thực hiện
_(＊1) Là các quốc gia có nguồn khách du lịch tới Nhật trong đó có nhiều người từng mắc lao (＊2) Những người lưu trú trên 3 tháng với mục đích học tập, làm việc, v.v. (＊3) Được Chính phủ Nhật Bản chỉ định. Cơ sở y tế chỉ định của quốc gia được yêu cầu khám sàng lọc bệnh lao sẽ là cơ sở y tế trong quốc gia đó được chính phủ Nhật Bản quy định nhằm đảm bảo chất lượng khám bệnh, xét nghiệm.**Phòng khám được chỉ định:** ・Sau khi được thăm khám, kiểm tra và chụp x-quang ngực, nếu thấy có dấu hiệu bệnh cá nhân đó sẽ cần phải làm xét ngiệm tiếp theo. ・Tải kết quả xét nghiệm lên Hệ thống quản lý thông tin JPETS (Hệ thống trực tuyến cho việc sàng lọc bệnh lao trước khi nhập cảnh vào Nhật Bản). ・Cấp Giấy chứng nhận không mắc bệnh lao nếu không có bệnh lao hoạt động._
Muốn tìm hiểu thêm thông tin, truy cập tại đường dẫn: **<https://jpets.mhlw.go.jp/vi/>**
**Dự kiến triển khai tại Bệnh viện Nguyễn Tri Phương: từ tháng 9.2025**
**Email nhận đăng ký: khamxuatcanh@bvnguyentriphuong.com.vn**
**Phòng khám tại Bệnh viện Nguyễn Tri Phương: lầu trệt khu A, cạnh nhà giữ xe 2 bánh**
  * [Đối tượng khám sàng lọc bệnh lao trước khi nhập cảnh Nhật Bản](https://bvnguyentriphuong.com.vn/thong-tin-benh-vien/xet-nghiem-sang-loc-benh-lao-truoc-khi-nhap-canh-vao-nhat-ban-jpets#i-tng-khm-sng-lc-bnh-lao-trc-khi-nhp-cnh-nht-bn)
  * [Cách thức thực hiện khám sàng lọc bệnh lao](https://bvnguyentriphuong.com.vn/thong-tin-benh-vien/xet-nghiem-sang-loc-benh-lao-truoc-khi-nhap-canh-vao-nhat-ban-jpets#cch-thc-thc-hin-khm-sng-lc-bnh-lao)
  * [Lưu đồ thực hiện](https://bvnguyentriphuong.com.vn/thong-tin-benh-vien/xet-nghiem-sang-loc-benh-lao-truoc-khi-nhap-canh-vao-nhat-ban-jpets#lu-thc-hin)



[[[PLACEHOLDER_HEADING]]]# Tập huấn Quản lý chất lượng bệnh viện năm 2025: Trang bị kỹ năng – Nâng tầm quản lý

Từ tháng 6 đến tháng 7 năm 2025, Bệnh viện Nguyễn Tri Phương đã tổ chức thành công lớp học “Quản lý chất lượng bệnh viện” dành cho lãnh đạo các khoa, phòng và thành viên mạng lưới quản lý chất lượng tại bệnh viện. Khóa học gồm 9 buổi học chuyên sâu, dưới sự chủ nhiệm và hướng dẫn trực tiếp của Giáo sư – Bác sĩ Nguyễn Văn Tập, chuyên gia đầu ngành đến từ Trường Đại học Nguyễn Tất Thành.
Trong bối cảnh ngành y tế đang đẩy mạnh chuyển đổi chất lượng dịch vụ và hướng đến người bệnh, khóa học này được thiết kế nhằm nâng cao năng lực quản lý và cải tiến chất lượng cho đội ngũ nhân sự nòng cốt tại bệnh viện. Nội dung chương trình tập trung vào bốn trọng điểm chính:
  * Nắm vững các tiêu chuẩn quản lý chất lượng bệnh 
  * Áp dụng tư duy và kỹ thuật cải tiến liên tục vào thực tiễn khoa phòng
  * Phát triển kỹ năng lãnh đạo và giám sát chất lượng dịch vụ y tế
  * Đảm bảo an toàn người bệnh và nâng cao mức độ hài lòng của người dân


Đặc biệt, sau khi hoàn thành khóa học, các khoa/phòng đã xây dựng và trình bày các đề án cải tiến chất lượng, bám sát thực tế hoạt động chuyên môn và quản lý tại đơn vị. Các đề án tập trung giải quyết các vấn đề cụ thể như: giảm thời gian chờ thủ thuật, cải tiến luồng bệnh nhân, tăng cường giám sát tuân thủ kiểm soát nhiễm khuẩn, cải tiến quy trình lấy mẫu cận lâm sàng…
Thông qua khóa tập huấn, không chỉ kiến thức và kỹ năng được củng cố, mà còn tạo ra mạng lưới chia sẻ kinh nghiệm nội bộ, giúp lan tỏa tinh thần cải tiến chất lượng đến mọi nhân viên y tế trong bệnh viện.
Lớp học là một bước tiến cụ thể trong chiến lược xây dựng bệnh viện chất lượng – an toàn – lấy người bệnh làm trung tâm mà Bệnh viện Nguyễn Tri Phương đang không ngừng nỗ lực triển khai.
**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/) **- Đa khoa Hạng I Thành phố Hồ Chí Minh

[[[PLACEHOLDER_HEADING]]]# Sở Y tế công bố kết quả đánh giá chất lượng đối với BV Nguyễn Tri Phương

**Bệnh viện Nguyễn Tri Phương** nhận được kết quả kiểm tra, đánh giá chất lượng bệnh viện năm 2024 từ Sở Y tế Thành phố Hồ Chí Minh, khẳng định vị thế là một trong những cơ sở y tế có chất lượng cao trong khám chữa bệnh và sự hài lòng của người bệnh.
Theo công văn số 6224/SYT-NVY được Sở Y tế ban hành ngày 06 tháng 06 năm 2025 , Bệnh viện Nguyễn Tri Phương đã đạt được những kết quả đáng khích lệ sau đợt kiểm tra diễn ra vào ngày 04 tháng 4 năm 2025.
**Kết quả đánh giá chi tiết như sau:**
  * **Điểm chất lượng bệnh viện chung:** Đạt **4,16/5 điểm**.
  * **Điểm quy đổi theo thang điểm 1000:** Đạt **857,990/1000 điểm**.
  * **Mức độ hài lòng của người bệnh:**
    * Người bệnh nội trú: **4,54/5 điểm** , thể hiện sự tin tưởng và hài lòng rất cao.
    * Người bệnh ngoại trú: **4,17/5 điểm**.
  * **Mức độ hài lòng của nhân viên y tế:** Đạt **3,93/5 điểm**.
  * Bệnh viện cũng được đánh giá **Đạt** về các Tiêu chuẩn chất lượng cơ bản.


Những điểm số này là minh chứng cho sự nỗ lực không ngừng của tập thể y bác sĩ, nhân viên y tế tại Bệnh viện Nguyễn Tri Phương trong việc nâng cao chất lượng chuyên môn, cải tiến quy trình và đặt người bệnh làm trung tâm trong mọi hoạt động.
Bên cạnh những kết quả tích cực, Bệnh viện Nguyễn Tri Phương cũng nghiêm túc tiếp thu các khuyến nghị từ Đoàn kiểm tra của Sở Y tế. Bệnh viện cam kết sẽ nhanh chóng rà soát và hoàn thiện hơn nữa hoạt động khám sức khỏe, đảm bảo tuân thủ chặt chẽ các quy định mới nhất theo Nghị định số 96/2023/NĐ-CP và Thông tư số 32/2023/TT-BYT nhằm mang lại sự an toàn và trải nghiệm tốt nhất cho người dân.
Bệnh viện Nguyễn Tri Phương sẽ tiếp tục thực hiện tốt sứ mệnh chăm sóc sức khỏe cho cộng đồng, không ngừng đổi mới và nâng cao chất lượng dịch vụ y tế.

[[[PLACEHOLDER_HEADING]]]# Bệnh viện Nguyễn Tri Phương trao trả tài sản đánh rơi cho người bệnh

Chiều ngày 16/7/2025, vào lúc 16 giờ 10 phút, trong lúc làm nhiệm vụ tuần tra tại khuôn viên bệnh viện, lực lượng an ninh Bệnh viện Nguyễn Tri Phương đã phát hiện và nhặt được một chiếc điện thoại di động màu xanh bị đánh rơi.
Ngay sau đó, bộ phận an ninh đã tiến hành kiểm tra, bảo quản tài sản và phối hợp xác minh thông tin chủ sở hữu thông qua số điện thoại liên lạc. Đến ngày 17/7/2025, chiếc điện thoại đã được trao trả lại cho người đánh rơi sau khi xác minh đầy đủ các thông tin liên quan.
Đây là một trong nhiều hoạt động thể hiện tinh thần trách nhiệm, sự tận tâm và minh bạch trong công tác đảm bảo an ninh – trật tự tại bệnh viện. Bệnh viện Nguyễn Tri Phương kêu gọi người dân, bệnh nhân và thân nhân khi đến khám chữa bệnh cần nâng cao ý thức giữ gìn tài sản cá nhân, đồng thời sớm thông báo với lực lượng chức năng nếu phát hiện hoặc đánh rơi tài sản để được hỗ trợ kịp thời.
**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/) **- Đa khoa Hạng I Thành phố Hồ Chí Minh

[[[PLACEHOLDER_HEADING]]]# Bảo vệ Bệnh viện Nguyễn Tri Phương phát hiện và trao trả điện thoại đánh rơi cho người bệnh

Ngày 14/07/2025, tại khu vực Khoa Khám bệnh – Bệnh viện Nguyễn Tri Phương, nhân viên bảo vệ trong lúc thực hiện nhiệm vụ đã phát hiện một chiếc điện thoại thông minh hiệu Realme bị đánh rơi trên ghế.
Ngay sau khi phát hiện, bảo vệ đã nhanh chóng lập biên bản ghi nhận sự việc, báo cáo lãnh đạo bệnh viện và phối hợp cùng bộ phận liên quan để xác minh, tìm kiếm chủ sở hữu hợp pháp của tài sản. Sau khi hoàn tất các bước kiểm tra và xác nhận thông tin, chiếc điện thoại đã được trao trả lại cho người bệnh theo đúng quy trình.
Hành động trung thực và tinh thần trách nhiệm của nhân viên bảo vệ được lãnh đạo bệnh viện ghi nhận và biểu dương. Đây là một trong những nỗ lực của toàn thể cán bộ, nhân viên bệnh viện trong việc xây dựng môi trường y tế an toàn, thân thiện và đáng tin cậy cho người bệnh.

[[[PLACEHOLDER_HEADING]]]# Tổ chức Hội thi tay nghề Điều dưỡng – Hộ sinh – Kỹ thuật y năm 2025

**Bệnh viện Nguyễn Tri Phương Tổ chức Hội thi tay nghề Điều dưỡng – Hộ sinh – Kỹ thuật y năm 2025: Nâng cao chất lượng chăm sóc người bệnh vì sự hài lòng của cộng đồng**
Hôm nay
Hội thi tay nghề không chỉ là một sự kiện thường niên mà còn mang ý nghĩa sâu sắc đối với sự phát triển chuyên môn và chất lượng dịch vụ y tế của Bệnh viện Nguyễn Tri Phương. Với mục tiêu tạo phong trào thi đua học tập trong đội ngũ ĐD-HS-KTY, cuộc thi khuyến khích mỗi cá nhân không ngừng rèn luyện, nâng cao kỹ năng thực hành và kỹ năng giao tiếp. Điều này trực tiếp góp phần cải thiện chất lượng chăm lượng chăm sóc và nâng cao sự hài lòng của người bệnh, vốn là yếu tố cốt lõi trong sứ mệnh của bệnh viện.
Bên cạnh đó, Hội thi còn là cơ hội để Ban Giám đốc và các cấp quản lý đánh giá khách quan quá trình rèn luyện, mức độ hoàn thành nhiệm vụ và sự phát triển nghề nghiệp của đội ngũ ĐD-HS-KTY. Từ đó, bệnh viện có thể đưa ra các kế hoạch đào tạo, bồi dưỡng phù hợp, đảm bảo đội ngũ y tế luôn đạt chuẩn và đáp ứng tốt nhất nhu cầu chăm sóc sức khỏe của cộng đồng.
Đối tượng dự thi năm nay bao gồm ĐD-HS-KTY có hợp đồng lao động từ ngày 01/01/2015 đến 31/12/2024. Nội dung thi đa dạng, tập trung vào các kỹ năng cốt lõi như nhận định tình trạng người bệnh, chẩn đoán điều dưỡng, can thiệp chăm sóc, thực hiện các quy trình kỹ thuật cơ bản (tiêm thuốc, truyền dịch, truyền máu, đo dấu hiệu sinh tồn, thay băng vết thương, thông tiểu, hút đàm, đặt ống cho ăn) và tư vấn-giáo dục sức khỏe. Các thí sinh Kỹ thuật y từ các khoa xét nghiệm, Chẩn đoán hình ảnh, Giải phẫu bệnh, Y học cổ truyền – Vật lý trị liệu – Phục hồi chức năng sẽ thi theo kế hoạch riêng của từng khoa.
Cuộc thi được tổ chức theo hình thức "chạy trạm" với 5 trạm thi, mỗi trạm 06 phút, đòi hỏi thí sinh phải thể hiện sự thành thạo và linh hoạt trong các kỹ năng. Quy trình chấm thi chặt chẽ với 2 giám khảo độc lập cho mỗi trạm, đảm bảo tính công bằng và chính xác trong đánh giá.
Hội thi tay nghề điều dưỡng của Bệnh viện Nguyễn Tri Phương không chỉ là một cuộc thi, mà còn là một minh chứng cho cam kết không ngừng nâng cao chất lượng dịch vụ, hướng tới sự hài lòng và sức khỏe tối ưu cho người bệnh.
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh

[[[PLACEHOLDER_HEADING]]]# Thông cáo về việc thay đổi thông tin địa chỉ Bệnh viện

**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh

[[[PLACEHOLDER_HEADING]]]# Thắt chặt hợp tác Viện – Trường giữa Đại học Y Dược TP.HCM và Bệnh viện Nguyễn Tri Phương

Sáng ngày 06 tháng 8 năm 2025, Đoàn công tác của Trường Đại học Y Dược TP. Hồ Chí Minh đã có buổi làm việc chính thức tại Bệnh viện Nguyễn Tri Phương nhằm thúc đẩy mối quan hệ hợp tác toàn diện giữa hai đơn vị trong các lĩnh vực: đào tạo, nghiên cứu khoa học và chăm sóc sức khỏe nhân dân.
Dẫn đầu đoàn công tác là PGS.TS.BS. Phùng Nguyễn Thế Nguyên – Hiệu trưởng Trường Đại học Y, thuộc Đại học Y Dược TP.HCM. Cùng tham dự có ThS.BS. Nguyễn Hoài Phong – Trưởng Phòng Quản trị Tổng hợp Trường Đại học Y, thuộc Đại học Y Dược TP.HCM và TS.BS. Phạm Anh Tuấn – Đại diện của Nhà trường tại Bệnh viện Nguyễn Tri Phương.
Về phía Bệnh viện Nguyễn Tri Phương, tiếp và làm việc với đoàn có ThS.BS.CKII Võ Đức Chiến – Giám đốc Bệnh viện, BS.CKII Lương Công Minh – Phó Giám đốc Bệnh viện, cùng Ban Quản lý hoạt động đào tạo và lãnh đạo các khoa, phòng liên quan.
Buổi làm việc diễn ra trong không khí cởi mở, xây dựng và đầy tinh thần hợp tác. Hai bên đã cùng nhau trao đổi, thảo luận các nội dung hợp tác chiến lược, hướng đến mục tiêu hợp tác Viện – Trường bền vững, qua đó góp phần nâng cao chất lượng đào tạo thực hành, nghiên cứu khoa học và hiệu quả chăm sóc người bệnh.
Cuộc gặp gỡ không chỉ thể hiện cam kết đồng hành lâu dài giữa Nhà trường và Bệnh viện, mà còn mở ra những cơ hội phát triển mới, phù hợp với yêu cầu đổi mới của ngành y tế và đáp ứng nhu cầu ngày càng cao của xã hội.
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh

[[[PLACEHOLDER_HEADING]]]# Bệnh viện Nguyễn Tri Phương bước đầu thiết lập hợp tác với Bệnh viện DR. Sitanala General trong lĩnh vực phẫu thuật thần kinh

Sáng ngày 07/08/2025 , Đoàn Y Bác sĩ của Bệnh viện Dr. Sitanala General (Indonesia) đã có buổi làm việc chính thức tại Bệnh viện Nguyễn Tri Phương nhằm thúc đẩy mối quan hệ hợp tác trong lĩnh vực điều trị phẫu thuật thần kinh. 
Dẫn đầu đoàn là Bác sĩ Afrizal Hasan - Tổng Giám đốc Bệnh viện Dr. Sitanala General cùng với bác sĩ Ni Ketut Rupini - Giám đốc Kế hoạch, Tài chính và Vận hành, và các lãnh đạo bộ phận chức năng trong bệnh viện.
Về phía Bệnh viện Nguyễn Tri Phương, tiếp và làm việc với đoàn có BS CKII Võ Đức Chiến - Giám đốc Bệnh viện, BS CKII Lương Công Minh - Phó Giám đốc Bệnh viện cũng với PGS TS Phạm Văn Bùi - cố vấn chuyên môn của bệnh viện và TS BS Phạm Anh Tuấn - Trưởng khoa Ngoại Thần kinh. 
Bệnh viện Nguyễn Tri Phương (TP. Hồ Chí Minh) và Bệnh viện DR. Sitanala General (Indonesia) đã chính thức ký ghi nhớ về quan hệ hợp tác trong đó ưu tiên trước hết về lĩnh vực phẫu thuật thần kinh. Ghi nhớ hợp tác hướng đến việc nâng cao chất lượng chuyên môn và hiệu quả điều trị thông qua các chương trình trao đổi chuyên sâu giữa hai đơn vị. 
Theo nội dung ký kết, hai bệnh viện sẽ phối hợp triển khai một số mục tiêu trọng điểm như: 
  * Phát triển dịch vụ phẫu thuật thần kinh tiên tiến thông qua trao đổi chuyên môn, chuyển giao công nghệ và chia sẻ nguồn lực y tế. 
  * Tổ chức các chương trình nâng cao năng lực, bao gồm đào tạo, hội thảo chuyên đề và hoạt động chia sẻ kiến thức dành cho đội ngũ bác sĩ, điều dưỡng và kỹ thuật viên chuyên ngành. 
  * Hợp tác điều trị các ca phẫu thuật thần kinh phức tạp, bao gồm việc xây dựng phác đồ điều trị chung, hỗ trợ hội chẩn xuyên quốc gia và thực hiện chuyển viện khi cần thiết.
  * Thúc đẩy nghiên cứu khoa học và đổi mới sáng tạo trong lĩnh vực phẫu thuật thần kinh, nhằm không ngừng cải tiến kỹ thuật, nâng cao chất lượng lâm sàng và tối ưu hóa kết quả điều trị cho người bệnh.


Việc hợp tác giữa hai bệnh viện được kỳ vọng sẽ tạo ra bước tiến quan trọng trong hoạt động chuyên môn, đồng thời góp phần thúc đẩy giao lưu y tế quốc tế và nâng cao vị thế chuyên ngành phẫu thuật thần kinh tại khu vực Đông Nam Á.
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh

[[[PLACEHOLDER_HEADING]]]# Bệnh viện Nguyễn Tri Phương: Bảo vệ phát hiện và trả lại tài sản đánh rơi cho bệnh nhân

Sáng sớm ngày 02/6/2025, vào khoảng 6 giờ 30 phút, trong quá trình tuần tra định kỳ tại khuôn viên Bệnh viện Nguyễn Tri Phương, một nhân viên thuộc bộ phận bảo vệ đã phát hiện một chiếc bóp bị đánh rơi tại khu vực Khoa Chấn thương chỉnh hình.
Trong chiếc bóp có chứa một số tiền mặt và các giấy tờ tùy thân quan trọng. Ngay sau khi phát hiện, nhân viên bảo vệ đã lập biên bản tạm giữ tài sản, đồng thời nhanh chóng báo cáo sự việc đến Ban Lãnh đạo bệnh viện.
Với tinh thần trách nhiệm và nghiệp vụ chuyên môn, lực lượng bảo vệ đã tiến hành xác minh và xác định chủ nhân của chiếc bóp là ông L.M.Mẫn, hiện đang là bệnh nhân điều trị tại Khoa Chấn thương chỉnh hình. Sau khi hoàn tất thủ tục xác minh, tài sản đã được bàn giao lại cho ông Mẫn trong tình trạng nguyên vẹn.
Hành động kịp thời và trung thực của nhân viên bảo vệ đã góp phần lan tỏa hình ảnh đẹp về tinh thần trách nhiệm và đạo đức nghề nghiệp trong môi trường y tế. Đây cũng là minh chứng cho công tác đảm bảo an ninh trật tự tại bệnh viện luôn được thực hiện nghiêm túc và hiệu quả.
**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/) **- Đa khoa Hạng I Thành phố Hồ Chí Minh

[[[PLACEHOLDER_HEADING]]]# Bệnh viện Nguyễn Tri Phương trao trả tài sản đánh rơi cho thân nhân người bệnh

Trong hai ngày 07/04 và 14/04/2025, Bệnh viện Nguyễn Tri Phương đã tiến hành trao trả hai tài sản đánh rơi cho thân nhân người bệnh, thể hiện tinh thần trách nhiệm và sự tận tâm trong công tác chăm sóc và hỗ trợ người bệnh.
Cụ thể, vào ngày **07/04/2025** , một chiếc bóp được nhân viên bệnh viện phát hiện tại khu vực Khoa Khám bệnh. Ngay sau khi nhận được thông tin, phòng Bảo vệ phối hợp với bộ phận hành chính và các khoa liên quan đã tiến hành rà soát, liên hệ và xác minh thông tin. Nhờ đó, chiếc bóp đã được trao trả cho thân nhân người bệnh bị thất lạc trong cùng ngày, với đầy đủ giấy tờ và tài sản bên trong.
Tiếp đó, vào ngày **14/04/2025** , một **chiếc điện thoại di động** được phát hiện đánh rơi tại khu vực lối đi giữa các khoa và nhân viên bàn giao cho bộ phận bảo vệ. Qua quá trình phối hợp xác minh giữa các đơn vị chức năng trong bệnh viện, điện thoại đã được hoàn trả đúng cho thân nhân người bệnh sau vài giờ.
Hành động nhanh chóng, minh bạch và chu đáo trong việc xử lý các trường hợp tài sản đánh rơi là minh chứng rõ nét cho **tinh thần “đặt người bệnh làm trung tâm”** mà Bệnh viện Nguyễn Tri Phương luôn hướng đến. Đồng thời, đây cũng là lời nhắc nhở chung về việc chủ động bảo quản tài sản cá nhân khi đến bệnh viện để tránh những sự cố đáng tiếc.
**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/) **- Đa khoa Hạng I Thành phố Hồ Chí Minh

[[[PLACEHOLDER_HEADING]]]# Thay đổi địa chỉ đóng trú của Bệnh viện Nguyễn Tri Phương

Theo nội dung sắp xếp hành chính cấp xã tại thành phố Hồ Chí Minh giai đoạn 2023-2025, Bệnh viện Nguyễn Tri Phương sẽ đổi địa chỉ đóng trú là:
**468 Nguyễn Trãi, Phường 7(trước đây là phường 8), Quận 5.**
Bệnh viện kính báo để quý bệnh nhân, quý khách hàng được rõ!
Về nội dung công văn liên quan, có thể xem [**tại đây.**](https://bvnguyentriphuong.com.vn/uploads/112023/files/1278-15_signed.pdf)
[[[PLACEHOLDER_FILE]]] Nội dung trong file:



[[[PLACEHOLDER_HEADING]]]# BS CK2 Võ Đức Chiến nhận quyết định tái bổ nhiệm Giám đốc BV Nguyễn Tri Phương cho đến khi nghỉ hưu

Được sự thống nhất của Ban Thường vụ Đảng ủy, Ban Giám đốc Sở Y tế Thành phố Hồ Chí Minh, Bệnh viện Nguyễn Tri Phương tổ chức Lễ công bố quyết định bổ nhiệm lại Giám đốc Bệnh viện Nguyễn Tri Phương vào ngày 24/01/2025
**Về phía Sở Y tế** : BV trân trọng đón tiếp
1. PGS.TS.BS. Tăng Chí Thượng, Thành ủy viên, Bí thư Đảng ủy, Giám đốc Sở Y tế Thành phố Hồ Chí Minh
2. ThS. Trần Thị Hồng Huyên, Đảng ủy viên, Trưởng phòng Tổ chức cán bộ Sở Y tế Thành phố Hồ Chí Minh
3. Ông Nguyễn Trọng Khang, Phó Trưởng banTổ chức Đảng ủy Sở Y tế Thành phố Hồ Chí Minh 
Trong thời gian thực hiện quy trình bổ nhiệm lại Giám đốc Bệnh viện, **TS.BS. Lê Cao Phương Duy, Phó Giám đốc Bệnh viện** được Ban Thường vụ, Ban Giám đốc Sở Y tế phân công điều hành hoạt động của Bệnh viện, trong thời gian điều hành, **TS.BS. Lê Cao Phương Duy** đã hoàn thành xuất sắc nhiệm vụ được phân công, và nhận được sự đánh giá, ghi nhận cao từ lãnh đạo Sở Y tế.
**Sau khi BS CK2 Võ Đức Chiến** nhận quyết định tái bổ nhiệm,**PGS.TS.BS. Tăng Chí Thượng** đã có những lời phát biểu chỉ đạo và giao nhiệm vụ cho Giám đốc Bệnh viện, đồng thời cũng gửi lời chúc mừng năm mới Xuân Ất Tỵ 2025 đến tập thể BV Nguyễn Tri Phương vào dịp những ngày rất cận tết này.
Thay mặt lãnh đạo BV, BS CK2 Võ Đức Chiến đã tiếp thu những điều gửi gắm của Giám đốc Sở Y tế thành phố Hồ Chí Minh về những nhiệm vụ trọng tâm cần quan tâm để hòa nhịp cùng kỷ nguyên vươn mình của dân tộc, trong đó chú trọng đến 03 gọng kiềng:
- Công tác tự chủ tài chính thật hiệu quả
- Vươn mình đến các tiêu chuẩn quốc tế - để nâng cao chất lượng nội lực đồng thời thu hút nguồn bệnh từ nước ngoài
- Phát triển y tế chuyên sâu, xứng tầm với những định hướng của Ngành Y tế Thành phố
_**Quyết định tái bổ nhiệm:**_

[[[PLACEHOLDER_HEADING]]]# Sổ sức khỏe điện tử trong Ứng dụng VNeID

Sổ sức khỏe điện tử VNeID là một tiện ích của ứng dụng VNeID được thiết kế để lưu trữ và quản lý thông tin sức khỏe cá nhân của công dân Việt Nam. Đây là một bước tiến quan trọng trong việc chuyển đổi số trong lĩnh vực y tế, giúp tiết kiệm chi phí và nâng cao hiệu quả quản lý sức khỏe.
Tiện ích sổ sức khỏe điện tử (SKĐT) VNeID được xây dựng bởi Bộ công an phối hợp với Bộ Y tế, BHXH Việt Nam và UBND các địa phương... tích hợp dữ liệu từ Cơ sở dữ liệu quốc gia về bảo hiểm y tế (BHYT), giúp thuận tiện hơn trong việc quản lý và thanh quyết toán chi phí khám, chữa bệnh. Đây là một phần trong nỗ lực số hóa của chính phủ để cải thiện trải nghiệm khám chữa bệnh và giảm thiểu thủ tục giấy tờ.
Căn cứ theo Quyết định số 2733/QĐ-BYT của Bộ Y tế hướng dẫn thí điểm triển khai sổ sức khỏe điện tử trên ứng dụng VNeID, sổ SKĐT VNeID có giá trị tương đương với sổ giấy và có thể được dùng thay thế sổ giấy khi người dân đi khám chữa bệnh tại các cơ sở y tế, cơ sở khám chữa bệnh công lập và tư nhân, bao gồm cả hình thức khám chữa bệnh ngoại trú, nội trú và khám từ xa.
**Những lợi ích khi sử dụng Sổ sức khỏe điện tử VNeID**
Sử dụng Sổ SKĐT VNeID sẽ giúp mang lại nhiều tiện ích cho người dân, giúp cải thiện trải nghiệm khám chữa bệnh và quản lý sức khỏe cá nhân. 
(1) Lưu trữ thông tin hồ sơ sức khỏe cá nhân toàn diện: Bao gồm các thông tin cá nhân và lịch sử khám chữa bệnh, tiền sử mắc bệnh, tiêm chủng, dị ứng, kết quả xét nghiệm và tóm tắt bệnh án... Điều này sẽ giúp người dân dễ dàng theo dõi và quản lý hồ sơ sức khỏe của mình.
(2) Tiết kiệm chi phí và thời gian: Giảm thiểu chi phí do in ấn, lưu trữ giấy tờ y tế và tiết kiệm thời gian cho cả bệnh nhân và nhân viên y tế trong việc tra cứu và cập nhật thông tin khám chữa bệnh.
(3) Thuận lợi hơn trong khám chữa bệnh: Người dân có thể xuất trình Sổ SKĐT VNeID thay cho sổ giấy khi đi khám chữa bệnh. Ngoài ra, bạn cũng có thể xuất trình giấy chuyển tuyến và giấy hẹn khám trên VNeID khi cần thiết.
(4) Tăng cường hiệu quả chẩn đoán và điều trị: Bác sĩ và nhân viên y tế có thể khai thác thông tin trong hồ sơ sức khỏe một cách nhanh chóng và chính xác, hỗ trợ chẩn đoán và điều trị hiệu quả hơn.
(5) An toàn và bảo mật thông tin: Thông tin sức khỏe cá nhân được bảo mật cao, chỉ có người dùng và các cơ sở y tế được phép truy cập.
Ngoài các thông tin về sức khỏe cá nhân, VNeID còn tích hợp các giấy tờ cá nhân khác như giấy tờ tùy thân, lý lịch tư pháp, giúp định danh công dân trên môi trường kỹ thuật số. Sổ sức khỏe điện tử VNeID không chỉ giúp người dân quản lý sức khỏe cá nhân một cách hiệu quả mà còn góp phần nâng cao chất lượng khám chữa bệnh, dịch vụ y tế.
**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/)** - Đa khoa Hạng I Thành phố Hồ Chí Minh

[[[PLACEHOLDER_HEADING]]]# ĐOÀN CÔNG TÁC BỘ Y TẾ THĂM VÀ CHÚC MỪNG BỆNH VIỆN NGUYỄN TRI PHƯƠNG NHÂN KỶ NIỆM 70 NĂM NGÀY THẦY THUỐC VIỆT NAM (27/2/1955 - 27/2/2025)

**ĐOÀN CÔNG TÁC BỘ Y TẾ THĂM VÀ CHÚC MỪNG BỆNH VIỆN NGUYỄN TRI PHƯƠNG NHÂN KỶ NIỆM 70 NĂM NGÀY THẦY THUỐC VIỆT NAM (27/2/1955 - 27/2/2025)**
Nhân dịp kỷ niệm 70 năm Ngày Thầy thuốc Việt Nam (27/2/1955 - 27/2/2025), sáng ngày 15/2/2025, Đoàn công tác Bộ Y tế do Thứ trưởng Bộ Y tế Đỗ Xuân Tuyên dẫn đầu đã đến thăm và chúc mừng tập thể lãnh đạo, y bác sĩ, nhân viên y tế tại Bệnh viện Nguyễn Tri Phương, TP. Hồ Chí Minh.
Tham gia đoàn công tác còn có:
  * TS. Dương Huy Lương, Phó Cục trưởng Cục Khám chữa bệnh;
  * TS. Nguyễn Lương Tâm, Phó Cục trưởng Cục Y tế dự phòng;
  * BS.CKII Đào Văn Sinh, Trưởng Đại diện Văn phòng Bộ Y tế tại TP. Hồ Chí Minh;
  * ThS. Nguyễn Tuấn Anh, Thư ký Đoàn công tác;
  * BS.CKII Bùi Nguyễn Thành Long, Phó Trưởng phòng Nghiệp vụ Y, Sở Y tế TP. Hồ Chí Minh.


Hình 1:TS. Dương Huy Lương, Phó Cục trưởng Cục Khám chữa bệnh giới thiệu đoàn công tác Bộ Y tế
**Ghi nhận những thành tựu y tế**
Phát biểu tại buổi gặp mặt, Thứ trưởng Bộ Y tế Đỗ Xuân Tuyên đánh giá cao những thành tựu nổi bật của Bệnh viện Nguyễn Tri Phương trong công tác điều trị, nghiên cứu và chăm sóc sức khỏe nhân dân. Đặc biệt, bệnh viện đã triển khai thành công nhiều kỹ thuật cao, tiên phong trong lĩnh vực y tế, góp phần nâng cao chất lượng dịch vụ khám chữa bệnh:
  * **Ghép thận:** Đang chuyển giao kỹ thuật, tiến tới làm chủ hoàn toàn quy trình ghép thận, mang lại hy vọng cho bệnh nhân suy thận giai đoạn cuối.
  * **Phẫu thuật kích thích não sâu:** Công nghệ hiện đại giúp điều trị bệnh Parkinson và các rối loạn vận động, giành Giải thưởng Nhân tài Đất Việt năm 2023, khẳng định năng lực y học tiên tiến của bệnh viện.
  * **Lọc máu tiêu chuẩn Nhật Bản:** Ứng dụng công nghệ lọc máu hiện đại, cải thiện đáng kể chất lượng sống cho bệnh nhân suy thận.
  * **Hệ sinh thái vì người bệnh khó khăn** : Tạo điều kiện hỗ trợ y tế nhân đạo, đảm bảo mọi bệnh nhân đều được tiếp cận dịch vụ y tế chất lượng cao.
  * **Cùng nhiều kỹ thuật tiên tiến khác**


**Chuyển đổi số – Bước tiến đột phá trong quản lý và điều trị**
Năm 2023 đánh dấu bước chuyển mình của Bệnh viện Nguyễn Tri Phương trong lĩnh vực chuyển đổi số y tế, đặc biệt là việc triển khai thành công Bệnh án điện tử.
Thứ trưởng Bộ Y tế Đỗ Xuân Tuyên đánh giá cao những nỗ lực của bệnh viện trong công cuộc chuyển đổi số, nhấn mạnh đây là xu hướng tất yếu trong y tế hiện đại, giúp nâng cao chất lượng dịch vụ và cải thiện trải nghiệm của người bệnh.
Hình 2: Thứ trưởng Bộ Y tế Đỗ Xuân Tuyên phát biểu tại buổi gặp mặt
**Tiếp tục phát huy vai trò tiên phong trong giai đoạn mới**
Trong bối cảnh đất nước bước vào thời kỳ phát triển mạnh mẽ, đồng chí Thứ trưởng Bộ Y tế đã trích dẫn phát biểu quan trọng của Tổng Bí thư Tô Lâm:
_“Kỷ nguyên vươn mình của dân tộc là kỷ nguyên phát triển bứt phá, tăng tốc dưới sự lãnh đạo của Đảng, xây dựng thành công nước Việt Nam xã hội chủ nghĩa, giàu mạnh, dân chủ, công bằng, văn minh, phồn vinh, hạnh phúc; đuổi kịp, tiến cùng, sánh vai với các cường quốc năm châu.”_
Lời khẳng định này cũng chính là động lực để ngành y tế nói chung và Bệnh viện Nguyễn Tri Phương nói riêng tiếp tục đổi mới, sáng tạo và phát triển bền vững. Với phương châm**"Năng động - Thân thiện - Phát triển"** , bệnh viện cần không ngừng nâng cao chất lượng khám chữa bệnh, phát triển nguồn nhân lực và đầu tư vào kỹ thuật tiên tiến, đáp ứng nhu cầu chăm sóc sức khỏe ngày càng cao của nhân dân.
**Kêu gọi tinh thần đoàn kết – Cùng vượt qua thách thức**
Bên cạnh những thành công, bệnh viện cũng đối mặt với nhiều thách thức trong xây dựng nguồn nhân lực y tế, điều kiện cơ sở vật chất và áp lực tài chính. Để tiếp tục giữ vững vị thế tiên phong, lãnh đạo Bộ Y tế kêu gọi toàn thể cán bộ, nhân viên y tế phát huy tinh thần đoàn kết, trách nhiệm, tận tâm với người bệnh, xứng đáng với bề dày truyền thống hơn 120 năm mà bao thế hệ nhân viên đã tạo nên thương hiện bệnh viện ngày hôm nay.
Hình 3: BS.CKII Võ Đức Chiến – Giám đốc Bệnh viện phát biểu tại buổi gặp mặt
Đáp lời của Thứ trưởng Đỗ Xuân Tuyên, BS.CKII Võ Đức Chiến – Giám đốc Bệnh viện cam kết tập thể bệnh viện sẽ cùng nhau vững bước, đồng lòng vượt qua những khó khăn hiện tại, tận dụng mọi cơ hội để phát triển mạnh mẽ hơn, không ngừng nâng cao chất lượng khám chữa bệnh, xứng đáng với niềm tin của nhân dân.
**Lời chúc mừng nhân Ngày Thầy thuốc Việt Nam 27/2**
Kết thúc buổi gặp mặt, Đoàn công tác Bộ Y tế và Sở Y tế TP. Hồ Chí Minh đã trao tặng bó hoa tươi thăm và gửi lời chúc mừng năm mới cùng lời tri ân sâu sắc đến toàn thể cán bộ, y bác sĩ, nhân viên bệnh viện. Đây là dịp quan trọng để tôn vinh những người khoác áo blouse trắng – những người không ngừng cống hiến cho sự nghiệp chăm sóc sức khỏe nhân dân.
Hình 4: Đoàn công tác Bộ Y tế tặng hoa và gửi lời chúc mừng Ngày Thầy thuốc Việt Nam
Hình 5: Đoàn công tác Bộ Y tế chụp hình cùng lãnh đạo và các nhân viên bệnh viện
Buổi gặp mặt diễn ra trong không khí trang trọng, ấm áp, là nguồn động viên tinh thần lớn lao để Bệnh viện Nguyễn Tri Phương tiếp tục phấn đấu, hoàn thành sứ mệnh chăm sóc sức khỏe nhân dân và vững bước trên con đường phát triển bền vững.
**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/)** - Đa khoa Hạng I Thành phố Hồ Chí Minh

[[[PLACEHOLDER_HEADING]]]# Bv Nguyễn Tri Phương đã được Sở y tế xếp cấp chuyên môn kỹ thuật là cấp chuyên sâu

Xem toàn văn bản

[[[PLACEHOLDER_HEADING]]]# Tuyên bố về Bảo vệ dữ liệu cá nhân

  * [1) DỮ LIỆU CÁ NHÂN](https://bvnguyentriphuong.com.vn/thong-tin-benh-vien/tuyen-bo-ve-bao-ve-du-lieu-ca-nhan#1-d-liu-c-nhn)
  * [2) THU THẬP, SỬ DỤNG VÀ TIẾT LỘ](https://bvnguyentriphuong.com.vn/thong-tin-benh-vien/tuyen-bo-ve-bao-ve-du-lieu-ca-nhan#2-thu-thp-s-dng-v-tit-l)
  * [3) BẢO VỆ DỮ LIỆU CÁ NHÂN CỦA BẠN](https://bvnguyentriphuong.com.vn/thong-tin-benh-vien/tuyen-bo-ve-bao-ve-du-lieu-ca-nhan#3-bo-v-d-liu-c-nhn-ca-bn)
  * [4) LƯU TRỮ DỮ LIỆU CÁ NHÂN CỦA BẠN](https://bvnguyentriphuong.com.vn/thong-tin-benh-vien/tuyen-bo-ve-bao-ve-du-lieu-ca-nhan#4-lu-tr-d-liu-c-nhn-ca-bn)
  * [5) NGHĨA VỤ CỦA BẠN](https://bvnguyentriphuong.com.vn/thong-tin-benh-vien/tuyen-bo-ve-bao-ve-du-lieu-ca-nhan#5-ngha-v-ca-bn)
  * [6) QUYỀN CỦA BẠN](https://bvnguyentriphuong.com.vn/thong-tin-benh-vien/tuyen-bo-ve-bao-ve-du-lieu-ca-nhan#6-quyn-ca-bn)
  * [7) CÁCH THỨC LIÊN LẠC VỚI CHÚNG TÔI](https://bvnguyentriphuong.com.vn/thong-tin-benh-vien/tuyen-bo-ve-bao-ve-du-lieu-ca-nhan#7cch-thc-lin-lc-vi-chng-ti)


**Chúng tôi** nhận thức được tầm quan trọng của dữ liệu cá nhân mà bạn đã giao phó cho chúng tôi và bản **Tuyên bố về Bảo vệ dữ liệu cá nhân** này nhằm thông báo và giúp bạn hiểu mục đích thu thập, sử dụng, tiết lộ, xử lý và bảo vệ dữ liệu cá nhân của bạn. 
Chúng tôi cam kết bảo vệ dữ liệu cá nhân của bạn và sẽ quản lý và xử lý dữ liệu cá nhân của bạn theo yêu cầu của **Nghị định 13/2023/NĐ-CP** về Bảo vệ dữ liệu cá nhân do Chính phủ nước Cộng Hòa Xã Hội Chủ Nghĩa Việt Nam ban hành ngày 17 tháng 4 năm 2023.
#### 1) DỮ LIỆU CÁ NHÂN
“Dữ liệu cá nhân” đề cập đến bất kỳ loại thông tin nào gắn liền với một cá nhân hoặc được sử dụng để nhận dạng một người cụ thể.
  * Dữ liệu cá nhân cơ bản bao gồm dữ liệu bạn cung cấp cho mục đích đăng ký, ví dụ: tên, thông tin nhân khẩu học, số căn cước công dân, quốc tịch, thông tin tài chính và bất kỳ thông tin cá nhân nào khác do bạn hoặc người thân của bạn cung cấp sẽ được thu thập khi bạn đến khám hoặc điều trị y tế.
  * Dữ liệu cá nhân nhạy cảm bao gồm tất cả thông tin y tế, đặc điểm di truyền, xu hướng tình dục và nhiều thông tin khác nữa.


“Xử lý” đề cập đến bất kỳ hoạt động nào ảnh hưởng đến Dữ liệu cá nhân, chẳng hạn như: thu thập, ghi âm, phân tích, xác nhận, lưu trữ, chỉnh sửa, công bố, kết hợp, truy cập, truy xuất, thu hồi, mã hóa, giải mã, sao chép, chia sẻ, truyền tải, cung cấp, chuyển giao, xóa và hủy dữ liệu cá nhân hoặc các hành động liên quan khác.
#### 2) THU THẬP, SỬ DỤNG VÀ TIẾT LỘ
Bằng việc tự nguyện cung cấp dữ liệu cá nhân của bạn để được chăm sóc y tế, điều này được xem như là bạn đã đồng ý cho Bệnh viện Nguyễn Tri Phương (sau đây gọi tắt là BV) thu thập, sử dụng, tiết lộ và xử lý Dữ liệu cá nhân của bạn như được định nghĩa ở trên cho các mục đích liên quan trực tiếp đến việc cung cấp dịch vụ chăm sóc y tế cho bạn, bao gồm việc giới thiệu đến các chuyên viên y tế, tổ chức y tế và các mục đích liên quan khác.
Chúng tôi có thể thu thập dữ liệu cá nhân của bạn bằng nhiều cách khác nhau
  * Thông qua việc hoàn thành các phiếu như phiếu đăng ký, phiếu nhập viện, phiếu chấp thuận
  * Khi bạn được bác sĩ của chúng tôi khám, trải qua một thủ thuật hoặc một cuộc khảo sát, được theo dõi bằng thiết bị theo dõi y tế
  * Từ bên thứ ba như công ty bảo hiểm, người sử dụng lao động, người thân
  * Khi hình ảnh của bạn được camera giám sát của chúng tôi ghi lại
  * Khi bạn tham dự các sự kiện như diễn đàn hoặc hội thảo công cộng
  * Khi bạn sử dụng dịch vụ của chúng tôi được cung cấp thông qua công nghệ trực tuyến
  * Khi bạn duyệt xem các trang web của chúng tôi 
  * Khi bạn thanh toán hoặc cung cấp thông tin chi tiết để hỗ trợ thanh toán


Dữ liệu cá nhân cũng được thu thập từ nhân viên và ứng viên nộp đơn xin việc hoặc ký hợp đồng với BV và từ các nhà thầu/nhà thầu phụ hoặc đối tác kinh doanh khác.
Chúng tôi chỉ sử dụng, tiết lộ và/hoặc chuyển Dữ liệu cá nhân của bạn cho các mục đích mà bạn đã được thông báo và chấp thuận hoặc được cho phép/yêu cầu theo quy định pháp luật hiện hành, cụ thể là:
  * Cung cấp dịch vụ y tế bao gồm chia sẻ dữ liệu cá nhân của bạn với các chuyên viên y tế, và các tổ chức y tế khác
  * Liên lạc với bên cung cấp bảo hiểm của bạn hoặc bên thứ ba thanh toán
  * Lập hóa đơn và nhận thanh toán cho các dịch vụ được cung cấp cho bạn
  * Liên lạc với bạn, bao gồm cung cấp cho bạn thông tin về các dịch vụ hiện có tại BV
  * Quản lý hoạt động kinh doanh và tuân thủ các chính sách và quy định nội bộ theo yêu cầu của pháp luật
  * Lập các báo cáo về hoạt động hoặc các báo cáo liên quan khác theo yêu cầu của pháp luật


Chuyển Dữ liệu cá nhân của bạn ra ngoài Việt Nam
  * Nếu chúng tôi chuyển dữ liệu cá nhân của bạn tới một quốc gia ngoài Việt Nam, chúng tôi sẽ đảm bảo rằng tổ chức hoặc quốc gia đó có tiêu chuẩn bảo vệ dữ liệu cá nhân có thể phù hợp với luật pháp Việt Nam;
  * Chúng tôi cũng đảm bảo thực hiện các quy trình cần thiết liên quan đến việc chuyển Dữ liệu cá nhân của công dân Việt Nam ra nước ngoài phù hợp với luật pháp Việt Nam.


#### 3) BẢO VỆ DỮ LIỆU CÁ NHÂN CỦA BẠN
Chúng tôi rất coi trọng vấn đề bảo mật của bệnh nhân. Để bảo vệ dữ liệu cá nhân của bạn không bị truy cập, thu thập, sử dụng, tiết lộ, sao chép, sửa đổi trái phép hoặc bất kỳ rủi ro tương tự nào, chúng tôi đã nỗ lực áp dụng các quy trình và biện pháp hành chính, vật lý và kỹ thuật phù hợp như cập nhật phần mềm chống vi-rút, mã hóa tài liệu và hệ thống, đồng thời hạn chế quyền truy cập vào bất kỳ dữ liệu cá nhân nào.
Thời gian bắt đầu và kết thúc xử lý Dữ liệu cá nhân: Việc xử Lý sẽ bắt đầu khi nhận được Dữ liệu cá nhân của bạn và sẽ kết thúc khi hoàn tất xử Lý.
Những hậu quả và thiệt hại không mong muốn có thể xảy ra: Một số quyền của bạn với tư cách là chủ thể dữ liệu chỉ có thể bị ảnh hưởng trong một số trường hợp bất khả kháng và không thể đoán trước như mất điện, lỗi phần cứng, sự cố phần mềm, sự cố bảo mật, truy cập bất hợp pháp vào hệ thống và thiết bị máy tính, thiên tai, bão, lũ lụt và các trường hợp khác được coi là bất khả kháng. Chúng tôi đảm bảo thường xuyên thực hiện các biện pháp nhằm giảm thiểu hoặc loại bỏ những rủi ro hoặc thiệt hại đó.
#### 4) LƯU TRỮ DỮ LIỆU CÁ NHÂN CỦA BẠN
Dữ liệu cá nhân của bạn sẽ được lưu trữ theo qui định của Bộ Y tế và các cơ quan quản lý nhà nước khác về việc lưu trữ dữ liệu của bệnh nhân.
Chúng tôi sẽ lưu trữ dữ liệu cá nhân của nhân viên/nhà thầu/đối tác kinh doanh trong một khoảng thời gian hợp lý theo nghĩa vụ pháp lý và mục đích kinh doanh.
Đối với bất kỳ dữ liệu cá nhân nào khác được BV thu thập, chúng tôi sẽ xem xét theo định kỳ để xác định xem dữ liệu đó có còn cần thiết hay không và sẽ chỉ lưu trữ dữ liệu đó với điều kiện là mục đích thu thập dữ liệu vẫn còn cần thiết và cho đến khi nó không còn cần thiết cho bất kỳ mục đích kinh doanh hoặc pháp lý nào khác.
#### 5) NGHĨA VỤ CỦA BẠN
Bạn cần đảm bảo rằng tất cả dữ liệu cá nhân cung cấp cho chúng tôi là đầy đủ, đúng sự thật và chính xác.
#### 6) QUYỀN CỦA BẠN
Bạn có thể truy cập dữ liệu cá nhân của bạn mà chúng tôi hiện đang nắm giữ. Chúng tôi sẽ xử lý yêu cầu của bạn theo quy định của pháp luật và sẽ cung cấp cho bạn dữ liệu cá nhân có liên quan trong thời gian hợp lý sau khi bạn yêu cầu. Bạn có thể bị tính phí khi chúng tôi xử lý yêu cầu truy cập của bạn.
Bạn có thể rút lại sự chấp thuận của mình đối với việc thu thập, sử dụng, Xử lý và tiết lộ Dữ Liệu Cá Nhân của bạn mà chúng tôi đang nắm giữ bằng cách gửi thông báo trước với thời gian hợp lý, sử dụng mẫu theo quy định, cho chúng tôi. Bạn có thể yêu cầu sửa Dữ Liệu Cá Nhân của bạn. Xin lưu ý là chúng tôi có nghĩa vụ đánh giá yêu cầu của bạn và theo quy định của pháp luật thì một số yêu cầu dưới đây sẽ không được chấp nhận:
  * Yêu cầu xóa và chỉnh sửa hồ sơ bệnh án
  * Yêu cầu xóa dữ liệu của cá nhân và/hoặc các giao dịch liên quan, trong khi BV có nghĩa vụ lưu trữ hồ sơ cá nhân và các giao dịch nhằm tuân thủ nghĩa vụ pháp lý
  * Yêu cầu che giấu, không cung cấp, cung cấp không đầy đủ hoặc cung cấp sai Dữ liệu cá nhân cho cơ quan nhà nước có thẩm quyền hoặc bên thứ ba khác.


#### 7) CÁCH THỨC LIÊN LẠC VỚI CHÚNG TÔI
Nếu bạn có bất kỳ câu hỏi nào về Tuyên Bố Bảo Vệ Dữ Liệu của chúng tôi hoặc muốn liên hệ với chúng tôi liên quan đến dữ liệu cá nhân của bạn, vui lòng liên hệ với chúng tôi theo địa chỉ mail [**truyenthong** @bvnguyentriphuong.com.vn](https://bvnguyentriphuong.com.vn/).
  * [1) DỮ LIỆU CÁ NHÂN](https://bvnguyentriphuong.com.vn/thong-tin-benh-vien/tuyen-bo-ve-bao-ve-du-lieu-ca-nhan#1-d-liu-c-nhn)
  * [2) THU THẬP, SỬ DỤNG VÀ TIẾT LỘ](https://bvnguyentriphuong.com.vn/thong-tin-benh-vien/tuyen-bo-ve-bao-ve-du-lieu-ca-nhan#2-thu-thp-s-dng-v-tit-l)
  * [3) BẢO VỆ DỮ LIỆU CÁ NHÂN CỦA BẠN](https://bvnguyentriphuong.com.vn/thong-tin-benh-vien/tuyen-bo-ve-bao-ve-du-lieu-ca-nhan#3-bo-v-d-liu-c-nhn-ca-bn)
  * [4) LƯU TRỮ DỮ LIỆU CÁ NHÂN CỦA BẠN](https://bvnguyentriphuong.com.vn/thong-tin-benh-vien/tuyen-bo-ve-bao-ve-du-lieu-ca-nhan#4-lu-tr-d-liu-c-nhn-ca-bn)
  * [5) NGHĨA VỤ CỦA BẠN](https://bvnguyentriphuong.com.vn/thong-tin-benh-vien/tuyen-bo-ve-bao-ve-du-lieu-ca-nhan#5-ngha-v-ca-bn)
  * [6) QUYỀN CỦA BẠN](https://bvnguyentriphuong.com.vn/thong-tin-benh-vien/tuyen-bo-ve-bao-ve-du-lieu-ca-nhan#6-quyn-ca-bn)
  * [7) CÁCH THỨC LIÊN LẠC VỚI CHÚNG TÔI](https://bvnguyentriphuong.com.vn/thong-tin-benh-vien/tuyen-bo-ve-bao-ve-du-lieu-ca-nhan#7cch-thc-lin-lc-vi-chng-ti)



[[[PLACEHOLDER_HEADING]]]# Thứ trưởng Bộ Y tế Trần Văn Thuấn thăm và chúc Tết Ất Tỵ 2025

Theo Thứ trưởng Trần Văn Thuấn, ngành y tế cả nước đã hoàn thành xuất sắc nhiệm vụ; đạt và vượt nhiều chỉ tiêu kinh tế - xã hội được giao trong năm 2024; như giường bệnh đạt 34/vạn dân, 14 bác sĩ/vạn dân, tỷ lệ dân số tham gia BHYT là 94%; triển khai hiệu quả toàn diện trên mọi lĩnh vực phòng, chống dịch bệnh; trong lĩnh vực khám chữa bệnh, nhiều kỹ thuật cao chưa từng có như ghép tim, ghép phổi… 
Thứ trưởng Bộ Y tế đã ghi nhận và biểu dương thành tích của bệnh viện trong thời gian qua, và mong muốn đơn vị tiếp tục phát huy hơn nữa trong công tác khám, chữa bệnh, chăm sóc sức khỏe cho người dân.
Thứ trưởng Trần Văn Thuấn cũng cho biết, Bộ Y tế rất quan tâm ứng dụng công nghệ thông tin trong lĩnh vực khám chữa bệnh, nhất là hoàn thành sớm việc thay thế bệnh án giấy bằng bệnh án điện tử ở các cơ sở y tế, trong đó có Bệnh viện Nguyễn Tri Phương.
Báo cáo hoạt động của bệnh viện, BS.CKII Võ Đức Chiến, Bí thư Đảng ủy Bệnh viện Nguyễn Tri Phương, cho biết, thế mạnh của bệnh viện trong điều trị là nội - ngoại thần kinh, nội tiết, chấn thương chỉnh hình, tiêu hóa, lọc máu, chạy thận. Đặc biệt, Bệnh viện Nguyễn Tri Phương đã hoàn thành mục tiêu thực hiện bệnh án điện tử toàn viện, vào tháng 11/2023, đã được Cục Khoa học Công nghệ công nhận và được Bộ Y tế công bố trên trang web của Cục Khám chữa bệnh. 
Đặc biệt, cũng trong dịp này, Bệnh viện Nguyễn Tri Phương đã tổng kết hoạt động hỗ trợ bệnh nhân có hoàn cảnh khó khăn, tri ân các nhà hảo tâm, đồng thời ra mắt “Quỹ giờ vàng”.
“Quỹ giờ vàng ra đời nhằm hỗ trợ các bệnh nhân nhập viện do đột quỵ, nhồi máu cơ tim nhưng có hoàn cảnh khó khăn; mong mỏi giúp đỡ nhiều bệnh nhân tiếp cận nhanh hơn với các dịch vụ y tế cần thiết mà không phải đắn đo, suy nghĩ. Ngay khi ra mắt, quỹ từ thiện Thành Ngọc đã hỗ trợ cho Quỹ giờ vàng 150 triệu đồng cùng sự chung tay của nhiều nhà hảo tâm khác”, BS.CKII Võ Đức Chiến cho biết. 
Đơn cử như mới đây bệnh nhân Nguyễn M. P. (58 tuổi, TP.HCM) cách nhập viện một giờ, đột ngột thấy đau ngực khi đang chạy xe với cảm giác như bị bóp nghẹt. Khi vào Cấp cứu, Bệnh viện Nguyễn Tri Phương, bệnh nhân được chẩn đoán là nhồi máu cơ tim cấp. Hoàn cảnh gia đình của bệnh nhân rất khó khăn, đang ở nhà thuê ở quận 8. 
Anh Nguyễn Hữu Thảo, Điều dưỡng trưởng khoa Tim mạch Can thiệp, Bệnh viện Nguyễn Tri Phương, cho biết thêm “Nhập viện trong tình trạng cấp cứu như vậy, bệnh nhân không có bảo hiểm y tế, hoàn cảnh gia đình lại vô cùng khó khăn, chỉ đóng được 5 triệu đồng. Vì vậy, khoa Tim mạch Can thiệp đã báo cáo và được lãnh đạo Bệnh viện, Hội chữ thập đỏ Bệnh viện cùng các nhà hảo tâm, công ty hỗ trợ các vật tư y tế, dụng cụ và tổng chi phí điều trị là 33 triệu đồng cùng 1 stent để đặt vào động mạch vành phải”. 
Bệnh viện Nguyễn Tri Phương là một trong những bệnh viện đa khoa hạng I của TP.HCM với quy mô 26 khoa Lâm sàng, 800 giường bệnh; được Sở Y tế TP.HCM xếp cấp chuyên sâu trong kỹ thuật chuyên môn. Mỗi năm, Bệnh viện Nguyễn Tri Phương tiếp nhận khám và điều trị trung bình gần 600.000 lượt bệnh nhân ngoại trú, 50.000 lượt bệnh nhân nội trú. 
Hội Chữ thập đỏ Bệnh viện Nguyễn Tri Phương đã xây dựng hệ sinh thái dành cho bệnh nhân có hoàn cảnh khó khăn từ viện phí, dinh dưỡng, đĩa cơm trên tường, chuyến xe nghĩa tình, gian hàng chia sẻ yêu thương, nâng đỡ tinh thần, chi phí sinh hoạt tối thiểu… Tổng số tiền từ các quỹ từ thiện dành cho Hệ sinh thái chăm lo cho bệnh nhân có hoàn cảnh khó khăn từ năm 2017 đến nay là khoảng 5,7 tỷ đồng. 
Năm 2023, Chủ tịch Nước CHXH Chủ nghĩa Việt Nam đã trao tặng Huân chương Lao động Hạng III cho hội Chữ thập đỏ Bệnh viện Nguyễn Tri Phương vì những thành tích xuất sắc trong công tác xã hội, nhân đạo, góp phần vào sự nghiệp xây dựng chủ nghĩa xã hội và bảo vệ Tổ quốc.

[[[PLACEHOLDER_HEADING]]]# Xếp hạng là bệnh viện hạng I đối với Bệnh viện Nguyễn Tri Phương giai đoạn 2025-2030

Xem toàn bộ quyết định [**tại đây**](https://bvnguyentriphuong.com.vn/uploads2025/files/QD%20so%202018%20BV%20NTP\(1\).pdf)
Như vậy, cho đến tháng 2.2025 - về xếp hạng, **Bệnh viện Nguyễn Tri Phương**
  1. Là bệnh viện hạng I tại thành phố Hồ Chí Minh, trực thuộc Sở Y Tế
  2. Là bệnh viện đạt cấp chuyên sâu (Cấp khám chữa bệnh chuyên sâu thực hiện nhiệm vụ khám bệnh, điều trị ngoại trú, nội trú chuyên sâu; đào tạo thực hành chuyên sâu; nghiên cứu, đào tạo liên tục chuyên sâu; chuyển giao kỹ thuật trong khám chữa bệnh.)



[[[PLACEHOLDER_HEADING]]]# Bệnh viện Nguyễn Tri Phương - 1 trong 14 điểm thi trực thuộc Sở Y tế Thành phố, cuộc thi Thầy thuốc giỏi chuyên môn, vững BHYT

Sáng ngày 31 tháng 5 năm 2024, Sở Y tế TP.Hồ Chí Minh phối hợp Bảo hiểm xã hội TP.Hồ Chí Minh đã tổ chức Hội thi “Thầy thuốc giỏi chuyên môn, vững bảo hiểm y tế” lần thứ 1 năm 2024 nhằm chào mừng ngày bảo hiểm y tế Việt Nam 1.7.2024. Hội thi đã quy tụ hơn 1600 thí sinh tham dự đến từ 22 tỉnh thành với 38 điểm thi (trong đó có 14 điểm thi tại các bệnh viện trực thuộc Sở y tế TP. Hồ Chí Minh).
Đến tham dự và phát biểu khai mạc PGS. TS. BS Tăng Chí Thượng – Giám đốc Sở Y tế TP. Hồ Chí Minh cho biết "Hội thi Thầy thuốc giỏi chuyên môn, vững bảo hiểm y tế" là một cuộc thi nhằm tôn vinh và nâng cao trình độ chuyên môn của các thầy thuốc, đồng thời cũng tăng cường hiểu biết về công tác khám chữa bệnh và bảo hiểm y tế; cập nhật những quy định, văn bản quy phạm pháp luật trong lĩnh vực KCB BHYT trên địa bàn. Đồng thời, tạo sự sắn kết, phối hợp chặt chẽ giữa cơ quan BHXH và ngành Y tế thành phố qua đó nâng cao hiệu quả công tác KCB BHYT, sử dụng quỹ BHYT và đảm bảo quyền, lợi ích hợp pháp của người tham gia và thụ hưởng chính sách BHYT.
Ông Lò Quân Hiệp – Giám đốc Bảo hiểm xã hội TP. Hồ Chí Minh đã gửi lời cảm ơn đến Ban Giám đốc Sở Y tế Tp.HCM, các Sở Y tế các tỉnh thành bạn và các bệnh viện đã tạo điều kiện và hỗ trợ để cuộc thi diễn ra theo đúng kế hoạch.

[[[PLACEHOLDER_HEADING]]]# Giới thiệu về dự án PPP tại khu vực 2 bệnh viện Nguyễn Tri Phương

**_Kính mời các nhà đầu tư có quan tâm có thể liên hệ trực tiếp phòng Hành chính quản trị của Bệnh viện để có thêm thông tin về dự án_**
Xem file đầy đủ [**tại đây**](https://bvnguyentriphuong.com.vn/uploads/112023/files/HFICPPT%20BV%20NTP.pdf)
[[[PLACEHOLDER_FILE]]] Nội dung trong file:

CÔNG TY ĐẦU TƢ TÀI CHÍNH NHÀ NƢỚC 
THÀNH PHỐ HỒ CHÍ MINH  
HOCHIMINH CITY FINANCE AND INVESTMENT 
STATE -OWNED COMPANY  
 
Dự án Xây dựng Khu khám điều trị dịch vụ tại Khu 2 của 
Bệnh viện Nguyễn Tri Phƣơng  
 
2 
I. TỔNG QUAN DỰ ÁN  
3 Quy mô dự án 
- Dự kiến 300 giƣờng  bệnh  gồm 02-04 
tầng hầm và 15 tầng cao. 
- Diện  tích khu đất: 7.367,2m2; 
- Diện  tích xây dựng : 2.325,0 m2; 
- Diện  tích sàn xây dựng : 46.223 m2; 
- Diện  tích sàn tầng hầm:  15.117m2; 
- Hệ số sử dụng  đất: 6,27 lần. Địa điểm  Số 493 Nguyễn  Trãi,  Phƣờng  7, Quận  5, TPHCM . 
Hiện trạng  Hiện  nay do nhu cầu chăm  sóc sức khỏe,  nâng  cao 
năng  lực chẩn  đoán,  điều trị, phòng  ngừa  và quản  lý 
bệnh  tật, giúp ngƣời  bệnh  tiếp cận hơn với các kỹ 
thuật  y học cao và hiện đại với chi phí hợp lý, Bệnh  
viện Nguyễn  Tri Phƣơng  xúc tiến “Dự án Đầu tƣ Xây 
dựng  Khu khám  điều trị dịch vụ tại Khu 2 của Bệnh  
viện Nguyễn  Tri Phƣơng ” trên khu đất hiện hữu. 
Mục tiêu 
đầu tƣ  - Xây dựng  Khu khám  điều trị dịch vụ với các trang  
thiết bị hiện đại đồng  bộ, đội ngũ thầy thuốc  tận tâm, 
chuyên  sâu; 
- Nhà tang lễ: dự kiến gồm 16 phòng  tang lễ; Nhà 
thiêu  xác công  nghệ  cao; 
- Chuỗi  các dịch vụ tiện ích cho ngƣời  bệnh : Khu vực 
Trung  tâm thƣơng  mại, ăn uống,  dịch vụ thƣ giãn giải 
trí, giữ xe, ... 
Hình thức 
đầu tƣ  Hình  thức đối tác công  tƣ (PPP)  theo Nghị  định số 
63/2018 /NĐ-CP ngày  04/5/2018  của Chính  phủ về 
đầu tƣ theo hình thức đối tác công  tƣ. 
Loại  hợp 
đồng  PPP Hợp đồng  Xây dựng  – Kinh  doanh  – Chuyển  giao 
(BOT) . 
1. Thông tin c ơ bản của dự án:  
4  I. TỔNG QUAN DỰ ÁN  
Cơ sở pháp lý dự 
án - Ngày  21/02/2018 , Ủy ban nhân  dân Thành  phố có Công  văn số 
713/UBND -DA về lập Đề xuất dự án Xây dựng  khu khám  điều trị dịch 
vụ tại khu 2 của Bệnh  viện Nguyễn  Tri Phƣơng  theo hình thức đối tác 
công  tƣ-PPP. Theo  đó, giao HFIC  tự cân đối kinh phí nghiên  cứu, lập đề 
xuất dự án đúng  quy định.  
- Ngày  27/7/2018 , Sở Kế hoạch  & Đầu tƣ có Công  văn số 
5537 /SKHĐT -PPP gửi Ủy ban nhân  dân Thành  phố về việc gia hạn thời 
gian lập Báo cáo nghiên  cứu tiền khả thi dự án. 
Tổng mức đầu tƣ  Dự kiến khoảng  3.500.000.000.000 đồng . 
Vốn tự có dự kiến: 30% TMĐT,  Vốn vay dự kiến: 70% TMĐT  
Tiến  độ thực  hiện 
dự án  
 Hiện  HFIC  cùng  với Bệnh  viện Nguyễn  Tri Phƣơng  đang  tìm kiếm  các 
đối tác tiềm năng,  chú trọng  các đối tác là các tổ chức  Nhật  Bản thuộc  
lĩnh vực y tế, tài chính  có uy tín để thành  lập liên danh  thực hiện các 
bƣớc  chuẩn  bị đầu tƣ Dự án.  1. Thông tin dự án:  CÔNG TY ĐẦU TƢ TÀI CHÍNH NHÀ NƢỚC THÀNH PHỐ HỒ CHÍ 
MINH  5 
 I. TỔNG QUAN DỰ ÁN  
1. Thông tin dự án:  6 
 I. TỔNG QUAN DỰ ÁN  
1. Thông tin dự án:  7 
II. PH ƢƠNG ÁN ĐẦU TƢ  
2. Mô hình quản trị Doanh nghiệp dự án  
Điều  hành  quản  lý chuyên  
môn, Phối hợp điều phối 
nguồn  nhân  lực… BỆNH VIỆN   
HỘI ĐỒNG QUẢN TRỊ  
BAN KIỂM SOÁT  
 GIÁM ĐỐC KHỐI CHUYÊN MÔN  GIÁM ĐỐC KHỐI TÀI CHÍNH , 
QUẢN TRỊ  
PHÒNG HÀNH CHÍNH QUẢN TRỊ  KHOA KHÁM BỆNH  
PHÒNG KINH DOANH  
PHÒNG VẬT TƢ THIẾT BỊ  KHOA NGOẠI TỔNG QUÁT  
KHOA PHỤ SẢN  
KHOA CHẤN THƢƠNG CHỈNH HÌNH  Quản  trị tài chính   
doanh  nghiệp  kinh  doanh  Quản  trị chuyên  môn  khám  
chữa  bệnh  
Hợp đồng quản trị 
chuyên môn  DOANH NGHIỆP DỰ ÁN  
TỔNG GIÁM ĐỐC  •Đảm  bảo ổn định và tăng nguồn thu nhập cho CBVC bệnh  viện Bệnh viện Nguyễn  Tri 
Phƣơng . 
•Nhà nƣớc  không  cần phải bỏ ra một khoản  chi phí lớn cho công  tác duy tu, bảo trì, bảo 
dƣỡng  cho toàn bộ công  trình  
•Nhà nƣớc sẽ gia tăng nguồn thu đáng kể thông qua các loại thuế nhƣ thuế GTGT, …   
•Nâng cao năng lực của bệnh viện, trở thành bệnh viện hiện đại, chuẩn quốc tế với trang thiết bị 
tiên tiến, đáp ứng nhu cầu đào tạo, nghiên cứu khoa học cũng nhƣ khám chữa bệnh chuyên sâu.  
•Mang  lại lợi nhuận  cho Nhà đầu tƣ tham  gia dự án và Bệnh  viện Nguyễn  Tri Phƣơng . 
•Góp phần hoàn thiện và nâng cao chất lƣợng dịch vụ ngành y tế  
8 II. PH ƢƠNG ÁN ĐẦU TƢ  
4. Hiệu quả kinh tế - xã hội của dự án  9 III. QUY TRÌNH THỰC HIỆN DỰ ÁN PPP  
Bƣớc 1  Bƣớc 2  Bƣớc 3  
Lập, thẩm 
định báo cáo 
nghiên cứu 
tiền khả thi . Quyết định 
chủ trƣơng 
đầu tƣ . Công bố dự án  
trên mạng đấu 
thầu quốc gia.  
Bƣớc 4  Bƣớc 5  Bƣớc 6  
Lựa chọn nhà thầu thực hiện dự án  
Chuẩn bị mặt bằng xây dựng  
Lập, thẩm định & phê duyệt thiết 
kế xây dựng  
Giám sát thực hiện hợp đồng dự án 
và chất lƣợng công trình  
Quản lý & kinh doanh công trình 
dự án  Lập, thẩm định và 
phê duyệt báo cáo 
nghiên cứu khả 
thi; thiết kế, dự 
toán (nếu có)  Lựa chọn nhà 
đầu tƣ  
Thành lập doanh nghiệp dự 
án PPP và ký kết hợp đồng.  Triển khai thực hiện 
dự án . Quyết toán và chuyển 
giao công trình .

[[[PLACEHOLDER_HEADING]]]# Lễ Công bố và trao Quyết định phân công phụ trách quản lý, điều hành hoạt động, thực hiện các giao dịch tài chính và thực hiện nhiệm vụ của Giám đốc Bệnh viện Nguyễn Tri Phương (Hạng I) trực thuộc Sở Y tế

Ngày 04/9/2024, Bệnh viện Nguyễn Tri Phương đã tổ chức Lễ Công bố và trao Quyết định phân công phụ trách quản lý, điều hành hoạt động, thực hiện các giao dịch tài chính và thực hiện nhiệm vụ của Giám đốc Bệnh viện Nguyễn Tri Phương (Hạng I) trực thuộc Sở Y tế đối với TS.BS. Lê Cao Phương Duy, Phó Giám đốc Bệnh viện kể từ ngày 03 tháng 9 năm 2024 cho đến khi có quyết định của cấp có thẩm quyền về việc bổ nhiệm lại chức vụ Giám đốc Bệnh viện theo quy định.
Tham dự buổi lễ có PGS.TS.BS. Tăng Chí Thượng, Thành ủy viên, Bí thư Đảng ủy, Giám đốc Sở Y tế TP.HCM; ThS. Trần Thị Hồng Huyên, Trưởng phòng Phòng Tổ chức cán bộ, Sở Y tế; Đảng ủy, Ban Giám đốc Bệnh viện Nguyễn Tri Phương và viên chức quản lý thuộc các khoa, phòng chức năng.
Phát biểu chỉ đạo và giao nhiệm vụ, PGS.TS.BS. Tăng Chí Thượng, Giám đốc Sở Y tế chúc mừng và tin tưởng rằng với nhiệm vụ mới được phân công, TS.BS. Lê Cao Phương Duy sẽ tiếp tục nêu cao tinh thần trách nhiệm, cùng tập thể viên chức, người lao động Bệnh viện Nguyễn Tri Phương phát huy tinh thần đoàn kết, đổi mới, sáng tạo, phấn đấu hoàn thành xuất sắc các nhiệm vụ được giao, góp phần tích cực trong sự nghiệp bảo vệ, chăm sóc và nâng cao sức khỏe cho nhân dân. 
PGS.TS.BS. Tăng Chí Thượng cũng đánh giá cao những đóng góp và thành tích của Bệnh viện Nguyễn Tri Phương trong thời gian qua. Bên cạnh đó, Đảng ủy, Ban Giám đốc Bệnh viện cần tập trung nghiên cứu các giải pháp hữu hiệu để chỉ đạo, kiểm tra, giám sát các hoạt động liên quan đến thu, chi của Bệnh viện. Chú trọng khơi dậy tính năng động, sáng tạo, chung tay của toàn thể viên chức, người lao động Bệnh viện trong việc đề xuất các sáng kiến, giải pháp, mô hình, ứng dụng, cách làm hay trong hoạt động quản lý kinh tế tại Bệnh viện; đẩy mạnh chuyển đổi số và ứng dụng công nghệ thông tin trong quản lý bệnh viện, đặc biệt trong hoạt động tài chính – kế toán.
Phát biểu nhận nhiệm vụ, TS.BS. Lê Cao Phương Duy gửi lời cảm ơn đến lãnh đạo Sở Y tế đã tín nhiệm phân công nhiệm vụ. Đồng thời, tiếp thu ý kiến chỉ đạo của Đồng chí Giám đốc Sở Y tế, trong nhiệm vụ mới được phân công, TS.BS. Lê Cao Phương Duy cho biết sẽ cố gắng hết sức, cùng Đảng ủy, Ban Giám đốc và toàn thể viên chức, người lao động Bệnh viện khắc phục những khó khăn, hạn chế; duy trì và phát huy những thành quả đạt được trong thời gian qua, phấn đấu hoàn thành xuất sắc các nhiệm vụ được giao./.

[[[PLACEHOLDER_HEADING]]]# Diễn tập Phòng Cháy Chữa Cháy tại Bệnh viện Nguyễn Tri Phương 2024

Nhằm thực hiện công tác phòng cháy chữa cháy theo quy định của Nhà nước và tăng cường khả năng ứng phó cứu nạn, cứu hộ.
Ngày 23/11/2024, Bệnh viện Nguyễn Tri Phương phối hợp với Đội Cảnh sát Phòng Cháy Chữa Cháy và Cứu Nan Cứu Hộ Công an Quận 5 tổ chức buổi diễn tập phương án Phòng cháy chữa cháy (PCCC) và cứu nạn cứu hộ (CNCH) với tình huống giả định.
Khi tình huống giả định cháy xảy ra, lực lượng chữa cháy của Bệnh viện Nguyễn Tri Phương đã tiến hành thao tác báo động, cắt điện khu vực bị cháy, gọi điện cho đội Cảnh sát PCCC 114 báo cháy và Công an Quận 5. Đội PCCC Bệnh viện Nguyễn Tri Phương sử dụng các phương tiện chữa cháy tại chỗ (bình CO2, bình bột chữa cháy AB), hệ thống ống nước chữa cháy của tòa nhà, xả ống, lắp vòi phun, nối ống và mở van xả nước để dập lửa đồng thời vận hành hệ thống máy bơm chữa cháy của tòa nhà. Lực lượng tại chỗ cũng đã tiến hành giải cứu và sơ cứu người bị nạn, di chuyển tài sản ra khỏi khu vực cháy. 
Song song đó, Đội Cảnh sát PCCC quận 5 cũng đã điều xe chữa cháy, xe bơm chuyên dụng cùng các chiến sĩ cảnh sát PCCC phối hợp với lực lượng chữa cháy ở cơ sở triển khai đội hình, nhanh chóng dùng vòi phun nước. Bệnh viện đã huy động 02 xe cứu thương và các nhân viên y tế tiếp nhận các nạn nhân bị thương, tổ chức sơ cấp cứu, vận chuyển tài sản. Sau gần 30 phút đám cháy giả định đã được khống chế và dập tắt hoàn toàn, toàn bộ người bị nạn đã được giải cứu.
Thành công của buổi diễn tập đã góp phần nâng cao ý thức PCCC cho đội ngũ cán bộ, viên chức và người lao động của Bệnh viện và xây dựng các kỹ năng thoát hiểm khi có hỏa hoạn xảy ra, đồng thời tăng cường khả năng thường trực, sẵn sàng ứng phó, xử lý các tình huống cháy, nổ và cứu nạn cứu hộ của lực lượng PCCC tại chỗ của Bệnh viện Nguyễn Tri Phương.
Video diễn tập: 
**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/)** - Đa khoa Hạng I Thành phố Hồ Chí Minh

[[[PLACEHOLDER_HEADING]]]# Introduction of Nguyen Tri Phuong Hospital (2024)

With the efforts for more than 120 years (1903-2024), Nguyen Tri Phuong Hospital has been recognized as a first rank general hospital in Ho Chi Minh City, which has greatly contributed to improve the quality of health care, thereby creating a credibility and trust not only for city people but also for the Southern ones.

[[[PLACEHOLDER_HEADING]]]# Thông báo hoàn tiền người bệnh

Bệnh viện Nguyễn Tri Phương trân trọng thông báo và kính mời quý bệnh nhân có tên trong danh sách dưới đây đến phòng Tài chính kế toán bệnh viện Nguyễn Tri Phương để được hoàn trả chi phí chênh lệch đã thu trong quá trình khám chữa bệnh tại bệnh viện Nguyễn Tri Phương.
Để thực hiện thủ tục hoàn tiền, quý bệnh nhân vui lòng mang theo các giấy tờ sau:
  * thẻ căn cước công dân
  * thẻ Bảo hiểm y tế.
  * sổ khám bệnh (nếu có).


Nếu có thắc mắc, xin vui lòng liên hệ phòng Tài chính kế toán – Bệnh viện Nguyễn Tri Phương.
(Tổng đài bệnh viện: 028.7307.7307 – bấm số nội bộ: 5200)
Trân trọng./.
**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/)** - Đa khoa Hạng I Thành phố Hồ Chí Minh

[[[PLACEHOLDER_HEADING]]]# Chức năng, nhiệm vụ, quyền hạn và cơ cấu tổ chức của bệnh viện Nguyễn Tri Phương

Xem toàn bộ nội dung [**tại đây**](https://bvnguyentriphuong.com.vn/uploads/112023/files/2994-qd_signed%20Quy%20dinh%20chuc%20nang%20nhiem%20vu%20cua%20Benh%20vien%20Nguyen%20Tri%20Phuong.pdf)
[[[PLACEHOLDER_FILE]]] Nội dung trong file:



[[[PLACEHOLDER_HEADING]]]# Thông báo về nghỉ lễ 2/9/2024

**Bệnh viện Nguyễn Tri Phương thông báo việc nghỉ lễ Quốc khánh (02/9) đối với viên chức, người lao động như sau:**
 _**I. Thời gian nghỉ lễ Quốc khánh (02/9) đối với viên chức, người lao động:**_
Viên chức, người lao động nghỉ lễ Quốc khánh năm 2024 từ thứ Bảy ngày 31/8/2024 đến hết thứ Ba ngày 03/9/2024 Dương lịch. Đợt nghỉ này bao gồm:
- 02 ngày nghỉ lễ Quốc khánh.
- 02 ngày nghỉ hằng tuần. Để người lao động được nghỉ liên tục, Bệnh viện xin thông báo sẽ không khám ngoài giờ thứ 7 ngày 31/8/2024
 _**II. Các khoa, phòng và đơn vị thực hiện một số nội dung sau:**_
Khoa, phòng và đơn vị:
Khoa Khám bệnh: Niêm yết công khai thời gian nghỉ để người dân được biết.
Phòng Hành chính quản trị: Niêm yết công khai thời gian nghỉ Lễ trước cổng Bệnh viện để người dân biết; Kiểm tra hệ thống điện, nước và công tác vệ sinh trong khuôn viên Bệnh viện; Chỉ đạo Đội bảo vệ theo sự phân công, tăng cường công tác tuần tra canh gác, thực hiện nghiêm chế độ giao ca. Đảm bảo an ninh trật tự, an toàn phòng cháy chữa cháy và treo cờ Tổ quốc.
Phòng Tổ chức cán bộ:
Phòng Kế hoạch tổng hợp: Thực hiện chế độ báo cáo số liệu cấp cứu, khám chữa bệnh theo quy định.

[[[PLACEHOLDER_HEADING]]]# Lịch nghỉ lễ Giỗ tổ Hùng Vương, ngày Chiến Thắng (30/4), ngày Quốc tế lao động (01/5)

**Lịch nghỉ lễ Giỗ Tổ Hùng Vương năm 2024:**
  * Thời gian nghỉ lễ: 01 ngày – Thứ Năm ngày 18/04/2024.
  * Thời gian làm việc trở lại: Thứ Sáu ngày 19/4/2024.


**Lịch nghỉ lễ 30/4 – 01/5 năm 2024:**
  * Thời gian nghỉ lễ: 05 ngày – Thứ Bảy ngày 27/04/2024 đến hết Thứ Tư ngày 01/05/2024.
  * Thời gian làm việc trở lại: Thứ Năm ngày 02/5/2024.
  * Thời gian làm bù: thứ 7 ngày 04/5/2024


Trong thời gian nghỉ Lễ, **hoạt động khám chữa bệnh cấp cứu và nội trú duy trì bình thường 24/7.**
*** Ngày thứ 7 (27/4/2024) BV vẫn duy trì hoạt động khám ngoài giờ.**
**Kính báo./.**

[[[PLACEHOLDER_HEADING]]]# Hội nghị Khoa học Kỹ thuật thường niên lần thứ 22

_Kính chào Quý Thầy Cô, Quý Đại biểu, Quý Đồng nghiệp,_
Hơn 20 năm qua, Bệnh viện Nguyễn Tri Phương đã tổ chức Hội nghị Khoa học kỹ thuật thường niên như một ngày hội khoa học nhằm báo cáo kết quả của những nghiên cứu, những kỹ thuật chẩn đoán và điều trị tiêu biểu. Hội nghị cũng là cơ hội để các nhân viên y tế lắng nghe và chia sẻ kiến thức, kinh nghiệm của các chuyên gia đầu ngành đến từ các trường Đại học và Bệnh viện uy tín tại thành phố Hồ Chí Minh.
Tiếp nối thành công đó, **Hội nghị Khoa học kỹ thuật thường niên lần thứ 22 – Năm 2024** sẽ được diễn ra trong **02 ngày, ngày 14 và ngày 15 tháng 11** năm 2024 tại Bệnh viện Nguyễn Tri Phương, với hơn 50 bài báo cáo đến từ gần 50 chuyên gia trong và ngoài bệnh viện. Các chủ đề báo cáo bao gồm lĩnh vực nội khoa, ngoại khoa, dược, điều dưỡng, cận lâm sàng, và quản lý bệnh viện. Đặc biệt năm nay, Hội nghị sẽ có 02 phiên báo cáo chuyên sâu về lĩnh vực phẫu thuật tiêu hóa và bệnh lý thần kinh. Chúng tôi tin rằng những kiến thức được chia sẻ và trao đổi trong từng phiên báo cáo sẽ không chỉ góp phần làm giàu kiến thức cho người thầy thuốc mà còn đem lại nhiều lợi ích quý giá trong công tác khám và điều trị đối với người bệnh.
Hân hạnh được đón tiếp Quý vị tại **Hội nghị khoa học kỹ thuật lần thứ 22 - Năm 2024** của Bệnh viện Nguyễn Tri Phương, để cùng nhau tạo nên những ngày hội khoa học thành công và có ý nghĩa.
Trân trọng.
Thông tin chi tiết vui lòng liên hệ:
Phòng Kế hoạch tổng hợp, Bệnh viện Nguyễn Tri Phương
Điện thoại: (028) 73077307 – Số nội bộ: 3100
Email: khth_ntp@bvnguyentriphuong.com.vn
**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/)** - Đa khoa Hạng I Thành phố Hồ Chí Minh

[[[PLACEHOLDER_HEADING]]]# Giải thưởng nhân tài Đất Việt đối với phẫu thuật kích thích não sâu tại BV Nguyễn Tri Phương

Tại Việt Nam, bệnh viện Nguyễn Tri Phương là cơ sở y tế đầu tiên thực hiện việc đầu tư trang thiết bị hiện đại và cử BS Phạm Anh Tuấn sang Pháp học tập về phẫu thuật này từ năm 2011. Tháng 4/2012, khoa Ngoại Thần Kinh – BV Nguyễn Tri Phương, với sự hỗ trợ từ GS Jean Paul Nguyễn - một phẫu thuật viên từ Pháp, ca phẫu thuật kích thích não sâu đầu tiên đã được thực hiện. 
Sau giai đoạn chuyển giao của GS. Jean Paul Nguyen, TS. BS. Phạm Anh Tuấn đã tiến hành rất nhiều ca phẫu thuật đặt điện cực kích thích não sâu, mang lại hiệu quả tích cực, góp phần cải thiện chất lượng sống của những bệnh nhân mắc bệnh lý Parkinson.
Công trình “Phẫu thuật kích thích não sâu điều trị bệnh Parkinson”, do TS. Phạm Anh Tuấn - Trưởng khoa Ngoại Thần Kinh BV Nguyễn Tri Phương, Chủ nhiệm bộ môn Ngoại Thần Kinh, khoa Y, ĐHYD TP. HCM làm chủ nhiệm đề tài với sự tham gia của các cộng sự:
- Từ bệnh viện Nguyễn Tri Phương: ThS. Nguyễn Anh Diễm Thúy và BS CKII Lê Thái Bình Khang.
- Từ trường ĐHYD và bệnh viện ĐHYD TP. HCM: TS. Trần Ngọc Tài, TS. Nguyễn Minh Anh, TS. Lê Viết Thắng, ThS. Đào Duy Phương, ThS. Nguyễn Thanh Lâm, ThS. Võ Thành Nghĩa.
Vừa qua, đề tài nghiên cứu trên đã vinh dự được trao giải III - giải thưởng “Nhân Tài Đất Việt”- lĩnh vực Y Dược năm 2023. Nếu như trước đây, để được phẫu thuật đặt điện cực kích thích não sâu, người bệnh phải ra nước ngoài phẫu thuật với chi phí rất cao. Việc triển khai phẫu thuật đặt điện cực kích tích não sâu tại Việt Nam giúp làm giảm chi phí điều trị cho bệnh nhân, làm tăng khả năng tiếp cận của người bệnh. 
Hiện nay, bệnh viện Nguyễn Tri Phương cũng đang hỗ trợ bệnh viện Hữu Nghị Việt Đức, đào tạo nhân sự cho bệnh viện Quân Y 103 triển khai kỹ thuật này.

[[[PLACEHOLDER_HEADING]]]# Lịch nghỉ tết âm lịch 2024 của BV Nguyễn Tri Phương


[[[PLACEHOLDER_HEADING]]]# Thông báo về nghỉ lễ 2/9/2023

Căn cứ Bộ Luật Lao động số 45/2019/QH14 ngày 20 tháng 11 năm 2019, có hiệu lực thi hành từ ngày có hiệu lực thi hành từ ngày 01 tháng 01 năm 2021; 
Căn cứ Thông báo số 5034/TB-LĐTBXN ngày 07 tháng 12 năm 2022 của Bộ Lao động - Thương binh và Xã hội về việc nghỉ Tết Âm lịch và nghỉ Lễ Quốc khánh năm 2023 đối với cán bộ, công chức, viên chức và người lao động; 
Bệnh viện Nguyễn Tri Phương thông báo việc nghỉ Lễ Quốc khánh (2/9) đối với viên chức, người lao động như sau: 
**I. Thời gian nghỉ Lễ Quốc khánh (2/9) đối với viên chức, người lao động:**
Viên chức, người lao động nghỉ lễ Quốc khánh (2/9) năm 2023 từ thứ Sáu ngày 01/9/2023 đến hết thứ Hai ngày 04/9/2023 Dương lịch. 
Đợt nghỉ này bao gồm: 
- 02 ngày nghỉ lễ Quốc khánh. 
- 01 ngày nghỉ hằng tuần. 
- 01 ngày nghỉ bù ngày nghỉ hằng tuần theo quy định tại khoản 3 Điều 111 Bộ luật Lao động. 
**II. Các khoa, phòng và đơn vị thực hiện một số nội dung sau:**
Khoa, phòng và đơn vị liên quan: Bố trí, sắp xếp các bộ phận làm việc và trực gác hợp lý để giải quyết công việc liên tục, bảo đảm tốt công tác khám bệnh, chữa bệnh vào các ngày nghỉ. 
Khoa Khám bệnh: Niêm yết công khai thời gian nghỉ để người dân được biết. 
Phòng Hành chính quản trị: Kiểm tra hệ thống điện, nước và công tác vệ sinh trong khuôn viên Bệnh viện; Chỉ đạo Đội bảo vệ theo sự phân công, tăng cường công tác tuần tra canh gác, thực hiện nghiêm chế độ giao ca, đảm bảo an ninh trật tự, an toàn phòng cháy chữa cháy. 
Phòng Tổ chức cán bộ: Thông báo đến toàn thể viên chức và người lao động thực hiện lịch nghỉ lễ Quốc khánh (2/9) năm 2023. Nhắc nhở các khoa, phòng đảm bảo nhân sự trực theo quy định. 
Phòng Kế hoạch tổng hợp: Thực hiện chế độ báo cáo số liệu cấp cứu, khám chữa bệnh theo quy định.
định. 

[[[PLACEHOLDER_HEADING]]]# Khoa Nội thần kinh - Bv Nguyễn Tri Phương nhận Giải thưởng bạch kim trong điều trị đột quỵ của hội Đột Quỵ Thế Giới (WSO)

RES-Q là nghiên cứu sổ bộ đầu tiên trên toàn cầu với mục đích cải thiện chất lượng đơn vị Đột Quỵ. Đây là một phần của Chương trình Cải thiện Chất lượng điều trị Đột quỵ của Hội Đột quỵ Châu Âu. RES-Q cũng được chấp thuận bởi Hội Đột Quỵ Thế Giới.
Khoa Nội thần kinh bệnh viện Nguyễn Tri Phương bắt đầu tham gia quản lý chất lượng bằng RES-Q vào năm 2019. Đến quý 3 năm 2019, khoa vinh dự được nhận giải thưởng vàng về điều trị đột quỵ do Hội Đột quỵ thế giới trao tặng và liên tục trong nhiều quý sau đó. 
Khoa Nội thần kinh chủ động triển khai và làm tốt liên kết nhóm giữa các chuyên ngành liên quan trong điều trị đột quỵ cấp, đặc biệt trong “thời gian vàng”. Đặc biệt, vào tháng 5 năm 2023, khoa nhận được chứng nhận quý I năm 2023 đạt chuẩn bạch kim trong điều trị đột quỵ của hội Đột Quỵ Thế Giới (WSO). Để được nhận chuẩn Bạch kim, khoa đã đạt 8 tiêu chí do WSO đề ra về điều trị tái thông mạch máu, chăm sóc và điều trị đột quỵ cấp. 
Không dừng lại ở đó, khoa luôn nỗ lực phấn đấu nâng cao chất lượng điều trị, mang lại hiệu quả điều trị tốt nhất cho bệnh nhân.
Trong quý 2 vừa qua, khoa tiếp tục vinh dự nhận được giải thưởng bạch kim. Đây là giải thưởng bạch kim lần thứ 2 liên tiếp của khoa.
Thành công của khoa Nội thần kinh còn đến từ sự hợp tác và hỗ trợ nhiệt tình của các đồng nghiệp khoa Cấp cứu, khoa Chẩn đoán hình ảnh và khoa Ngoại thần kinh.
Bệnh viện Nguyễn Tri Phương nói chung và Khoa Nội thần kinh nói riêng, trân trọng cảm ơn bệnh nhân và thân nhân đã tin tưởng và lựa chọn điều trị tại bệnh viện Nguyễn Tri Phương.
**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/) **- Đa khoa Hạng I Thành phố Hồ Chí Minh

[[[PLACEHOLDER_HEADING]]]# Thông báo về lịch nghỉ Tết dương lịch 2024


[[[PLACEHOLDER_HEADING]]]# Tuần lễ hội nghị khoa học chào mừng kỷ niệm 120 năm thành lập Bệnh viện Nguyễn Tri Phương

**Kính thưa Quý Thầy Cô, Quý Đại biểu, Quý Đồng nghiệp,**
Hơn 10 năm qua, Hội nghị Khoa học kỹ thuật thường niên đã được Bệnh viện Nguyễn Tri Phương tổ chức như một ngày hội khoa học nhằm báo cáo kết quả của những nghiên cứu, những kỹ thuật chẩn đoán và điều trị tiêu biểu. Hội nghị cũng là cơ hội để các nhân viên y tế lắng nghe và chia sẻ kiến thức, kinh nghiệm của các chuyên gia đầu ngành đến từ các trường Đại học và Bệnh viện uy tín tại thành phố Hồ Chí Minh.
Tiếp nối thành công đó, đồng thời đánh dấu chặng đường 120 năm hình thành và phát triển của Bệnh viện Nguyễn Tri Phương (1903 – 2023), Hội nghị Khoa học kỹ thuật thường niên năm 2023 thay vì tổ chức trong 01 ngày như trước, sẽ được diễn ra trong 02 ngày 21 và ngày 24 tháng 11 năm 2023 tại Bệnh viện Nguyễn Tri Phương, với hơn 50 bài báo cáo đến từ gần 50 chuyên gia trong và ngoài bệnh viện. Các chủ đề báo cáo bao gồm lĩnh vực nội khoa, ngoại khoa, dược, điều dưỡng, cận lâm sàng, và quản lý bệnh viện. Đặc biệt năm nay, Hội nghị sẽ có 02 phiên báo cáo chuyên sâu về lĩnh vực phẫu thuật tiêu hóa và bệnh tự miễn. Chúng tôi tin rằng những kiến thức được chia sẻ và trao đổi trong từng phiên báo cáo sẽ không chỉ góp phần làm giàu kiến thức cho người thầy thuốc mà còn đem lại nhiều lợi ích quý giá trong công tác khám và điều trị đối với người bệnh.
Hân hạnh được đón tiếp Quý vị tại Tuần lễ Hội nghị khoa học kỹ thuật năm 2023 của Bệnh viện Nguyễn Tri Phương để cùng nhau tạo nên những ngày hội khoa học thành công và có ý nghĩa. 
**Trân trọng.**
**TM Ban tổ chức**
**Trưởng ban**
**BS. CKII Võ Đức Chiến**
**Giám đốc Bệnh viện**
Để xem chi tiết từng hội thảo, vui lòng tham khảo [**tại đây**](https://bvnguyentriphuong.com.vn/uploads/112023/files/CH%C6%AF%C6%A0NG%20TR%C3%8CNH%20HN%20KHKT%202023%20-%20BV%20NGUY%E1%BB%84N%20TRI%20PH%C6%AF%C6%A0NG%20-%20b%E1%BA%A3n%20email.pdf)
[[[PLACEHOLDER_FILE]]] Nội dung trong file:

TUẦN LỄ HỘI NGHỊ KHOA HỌC KỸ THUẬT
Chào mừng 120 năm thành lập Chào mừng 120 năm thành lập  
20 23
8h00 ngày 21/11 & 24/11/2023
Hội trường Lầu 5
19 0 3
468 Nguyễn Trãi, P8, Q5, TP.HCM 028) 39234332 - 73077307 www.bvnguyentriphuong.com.vn
BỆNH VIỆN NGUYỄN TRI PHƯƠNG
Năng động - Thân thiện - Phát triển        Tiếp nối thành công đó, đồng thời đánh dấu chặng đường 120 năm hình thành và
phát triển của Bệnh viện Nguyễn Tri Phương (1903 – 2023), Hội nghị Khoa học kỹ
thuật thường niên năm 2023 thay vì tổ chức trong 01 ngày như trước, sẽ được diễn ra
trong 02 ngày 21 và ngày 24 tháng 11 năm 2023 tại Bệnh viện Nguyễn Tri Phương,
với hơn 50 bài báo cáo đến từ gần 50 chuyên gia trong và ngoài bệnh viện. Các chủ
đề báo cáo bao gồm lĩnh vực nội khoa, ngoại khoa, dược, điều dưỡng, cận lâm sàng,
và quản lý bệnh viện. Đặc biệt năm nay, Hội nghị sẽ có 02 phiên báo cáo chuyên sâu
về lĩnh vực phẫu thuật tiêu hóa và bệnh tự miễn. Chúng tôi tin rằng những kiến thức
được chia sẻ và trao đổi trong từng phiên báo cáo sẽ không chỉ góp phần làm giàu
kiến thức cho người thầy thuốc mà còn đem lại nhiều lợi ích quý giá trong công tác
khám và điều trị đối với người bệnh.
468 Nguyễn Trãi, P8, Q5, TP.HCM 028) 39234332 - 73077307 www.bvnguyentriphuong.com.vn
BỆNH VIỆN NGUYỄN TRI PHƯƠNG
Năng động - Thân thiện - Phát triển
Lời tựa
      Hơn 10 năm qua, Hội nghị Khoa học kỹ thuật thường niên đã được Bệnh viện
Nguyễn Tri Phương tổ chức như một ngày hội khoa học nhằm báo cáo kết quả của
những nghiên cứu, những kỹ thuật chẩn đoán và điều trị tiêu biểu. Hội nghị cũng là cơ
hội để các nhân viên y tế lắng nghe và chia sẻ kiến thức, kinh nghiệm của các chuyên
gia đầu ngành đến từ các trường Đại học và Bệnh viện uy tín tại thành phố Hồ Chí
Minh.
TM Ban Tổ chức
Trưởng ban
 
 BS. CKII Võ Đức Chiến
 Giám đốc Bệnh viện Nguyễn Tri Phương         Hân hạnh được đón tiếp Quý vị tại Tuần lễ Hội nghị khoa học kỹ thuật năm
2023 - Chào mừng 120 năm thành lập bệnh viện của Bệnh viện Nguyễn Tri Phương
để cùng nhau tạo nên những ngày hội khoa học thành công và có ý nghĩa.
Trân trọng.Kính thưa Quý Thầy Cô, Quý Đại biểu, Quý Đồng nghiệp,468 Nguyễn Trãi, P8, Q5, TP.HCM 028) 39234332 - 73077307 www.bvnguyentriphuong.com.vn
Quét mã QR
để đăng ký tham dựTUẦN LỄ HỘI NGHỊ KHOA HỌC KỸ THUẬT
Chào mừng 120 năm thành lập Chào mừng 120 năm thành lập  
Hội trường A
Hội trường A
Hội trường A109:00 - 12:30    Khai mạc chương trìnhĐón khách và tiếp nhận đăng ký 08:00 - 08:30    
PHẪU THUẬT TIÊU HÓA - GAN MẬT TỤY - UNG THƯ
09:00 - 12:00 BỆNH TỰ MIỄN08:30 - 09:00    Hội trường A
Hội trường A
Hội trường A08:20 - 09:20    Khai mạc chương trìnhĐón khách và tiếp nhận đăng ký 07:30 - 08:00
PHIÊN TOÀN THỂ08:00 - 08:20 Hội trường A
Hội trường A
Hội trường B09:30 - 12:00    PHIÊN NỘI KHOA
09:30 - 12:00 DƯỢC - XÉT NGHIỆM - ĐIỀU DƯỠNG  
& QUẢN LÝ BỆNH VIỆN  Hội trường A109:30 - 12:00 PHIÊN NGOẠI KHOA
20 23
19 0 3
PHIÊN 21/11
09:00 - 12:30, ngày 21/11/2023
Hội trường A1
Bệnh viện Nguyễn Tri Phương
CHỦ TỌA
Section 1 (9h-10h30): Phẫu thuật tiêu hoá nâng caoPGS.TS.BS Phạm Văn Bùi, 
Cố vấn chuyên môn 
BV Nguyễn Tri Phương
TS.BS Lê Cao Phương Duy
Phó Giám đốc, Chủ tịch HĐ KHCN
BV Nguyễn Tri PhươngTS.BS Trần Công Duy Long
Phó Trưởng khoa Ngoại Gan - Mật - Tụy
BV ĐHYD TP.HCM
Bộ môn Ngoại Tổng quát, ĐHYD TP.HCM 
09:00 – 09:30
09:30 – 09:40
09:40 – 09:50
09:50 – 10:00
10:00 – 10:10
10:10 – 10:20
10:20 – 10:30Kỹ thuật nạo hạch dọc thần kinh quặt ngược trong phẫu thuật triệt để ung thư
thực quản                                                                  Lecturer: PGS.TS.BS Lâm Việt Trung
Phẫu thuật nội soi ngực bụng cắt thực quản điều trị ung thư không cần mở bụng
nhỏ                                                                                        Speaker: BSCKI Lê Ngọc Trung
Phẫu thuật nội soi hoàn toàn cắt đại tràng phục hồi lưu thông trong ổ bụng               
Speaker: BSCKII Đào Văn Cam 
Phẫu thuật nội soi cắt D3, D4 tá tràng 
Speaker: ThS.BS Trần Quốc Hạnh
Phẫu thuật nội soi nạo hạch mở rộng trong điều trị ung thư đại tràng – Quy trình
kỹ thuật BV Nguyễn Tri Phương                                          Speaker: TS.BS Lê Huy Lưu
Ứng dụng eVAC xử trí áp xe vùng chậu do xì miệng nối đại tràng ống hậu môn
sau mổ ung thư trực tràng thấp                            Speaker: ThS.BS Phan Lê Anh Minh
Thảo luận
PGS.TS.BS Lâm Việt Trung
Phó Giám đốc BV Chợ Rẫy
Phó Chủ nhiệm bộ môn Ngoại Tổng quát,
ĐHYD TP.HCM
468 Nguyễn Trãi, P8, Q5, TP.HCM 028) 39234332 - 73077307 www.bvnguyentriphuong.com.vnPHIÊN 21/11
09:00 - 12:30, ngày 21/11/2023
Hội trường A1
Bệnh viện Nguyễn Tri Phương
Section 2 (10h40-12h): Gan mật tuỵ - Ung bướu 
10:40 – 11:10
11:10 – 11:20
11:20 – 11:30
11:30 – 11:40
11:40 – 11:50
11:50 – 12:00
12:00 – 12:30Cập nhật chiến lược và kỹ thuật mới trong phẫu thuật điều trị ung thư biểu mô tế
bào gan                                                                     Lecturer: TS.BS Trần Công Duy Long
Phẫu thuật nội soi cắt tụy trung tâm: Giải pháp cho các tổn thương lành tính
vùng cổ thân tụy?                                                          Speaker: BS Huỳnh Quang Nghệ
Phẫu thuật nội soi xử trí biến thể mới của nang đường mật
Speaker: TS.BS Huỳnh Thanh Long
Ứng dụng in 3D trong chọn giải pháp lấy bỏ Schwannoma kẹp giữa mạng lưới
mạch máu phức tạp vùng thân tạng và mạc treo tràng trên bằng phẫu thuật nội
soi                                                                                   Speaker: TS.BS Đặng Trần Khiêm
Hội chẩn đa mô thức – Giải pháp tối ưu hoá việc chẩn đoán và điều trị ung thư
Speaker: Ths.BSCKI Phạm Minh Tuấn
Khảo sát tỉ lệ di căn hạch và đặc điểm mô bệnh học ở bệnh nhân ung thư đại
tràng tại BV Nguyễn Tri Phương                                       Speaker: BS Diệp Đình Được
Thảo luận - Bế mạc
CHỦ TỌA
PGS.TS.BS Phạm Văn Bùi, 
Cố vấn chuyên môn 
BV Nguyễn Tri Phương
TS.BS Lê Cao Phương Duy
Phó Giám đốc, Chủ tịch HĐ KHCN
BV Nguyễn Tri PhươngTS.BS Trần Công Duy Long
Phó Trưởng khoa Ngoại Gan - Mật - Tụy
BV ĐHYD TP.HCM
Bộ môn Ngoại Tổng quát, ĐHYD TP.HCM 
PGS.TS.BS Lâm Việt Trung
Phó Giám đốc BV Chợ Rẫy
Phó Chủ nhiệm bộ môn Ngoại Tổng quát,
ĐHYD TP.HCM
468 Nguyễn Trãi, P8, Q5, TP.HCM 028) 39234332 - 73077307 www.bvnguyentriphuong.com.vnPHIÊN 21/11
09:00 - 12:00, ngày 21/11/2023
Hội trường A2
Bệnh viện Nguyễn Tri Phương
BS CK2 Võ Đức Chiến
Giám đốc BV Nguyễn Tri PhươngCHỦ TỌA
BS CK2 Nguyễn Đình Thông
Trưởng khoa Cơ xương khớp
BV Nguyễn Tri Phương
Section 1 (9h00-10h30): Bệnh tự miễn
09:00 – 09:15
09:15 – 09:30
09:30 – 09:45
09:45 – 10:00
10:00 – 10:30
10:30 – 10:45Ca lâm sàng:
Bệnh phổi mô kẽ do xơ cứng bì
BS CK1 Huỳnh Thị Phước Dung
Ca lâm sàng: 
Viêm ruột do Lupus
Ths BS Nguyễn Thị Nhã Đoan
Ca lâm sàng: Tổn thương thận trên
bệnh nhân Lupus ban đỏ hệ thống
Ths BS CK1 Nguyễn Nhựt Minh
Ca lâm sàng:
Lupus thần kinh trung ương - APS
BS CK1 Nguyễn Thị Kim Hường
Tổng quan bệnh tự miễn
PGS TS. BS Nguyễn Đình Khoa
TeabreakPGS.TS.BS Nguyễn Đình Khoa
Phó chủ tịch hội THK Việt Nam
Trưởng khoa CXK - BV Chợ Rẫy
10:45 – 11:00
11:00 – 11:15
11:15 – 11:30
11:30 – 12:00Section 2 (10h45-12h): Viêm mạch
Ca lâm sàng: 
Viêm mạch tăng Eosinophile
ThS.BS Nguyễn Thị Minh Nguyệt
Ca lâm sàng: 
Viêm mạch dạng thấp
BS CKI Trương Như Hảo
Ca lâm sàng:
Viêm đa nút động mạch
BSNT Phạm Minh Tùng 
Thảo luận - Bế mạc
468 Nguyễn Trãi, P8, Q5, TP.HCM 028) 39234332 - 73077307 www.bvnguyentriphuong.com.vnTeabreak
PHIÊN 24/11
07:30 - 09:20, ngày 24/11/2023
Hội trường A
Bệnh viện Nguyễn Tri Phương
CHỦ TỌA & BÁO CÁO VIÊN
Nội dung chương trình Nội dung chương trìnhBS CK2 Võ Đức Chiến
Giám đốc BV Nguyễn Tri PhươngTS.BS Lê Cao Phương Duy
Phó Giám đốc, Chủ tịch HĐ KHCN
BV Nguyễn Tri Phương
08:00 – 08:20
08:20 – 08:35
08:35– 08:50
08:50 – 09:05
09:05 – 09:20
09:20 – 09:30Thực trạng công tác xã hội trong bệnh viện và những thách thức
BS.CKII Võ Đức Chiến
Cập nhật điều trị suy tim theo các khuyến cáo mới nhất
TS.BS Lê Cao Phương Duy 
Giá trị thang điểm đánh giá suy yếu nhanh dành cho thầy thuốc không chuyên
khoa Lão                                                                                     PGS.TS.BS Nguyễn Văn Trí 
Phẫu thuật kích thích não sâu điều trị bệnh lý rối loạn vận động tại BV NTP
Kết quả 10 năm triển khai                                                             TS.BS Phạm Anh Tuấn 
Khai mạc hội nghị                                                                              BS.CKII Võ Đức ChiếnPGS.TS.BS Nguyễn Văn Trí
Chủ tịch Hội Lão Khoa TP. HCM
Chủ nhiệm bộ môn Nội, trường ĐH
Nguyễn Tất Thành
TS.BS Phạm Anh Tuấn 
Trưởng khoa Ngoại thần kinh 
BV Nguyễn Tri Phương
PGS.TS.BS Phạm Văn Bùi
Cố vấn chuyên môn 
BV Nguyễn Tri Phương
468 Nguyễn Trãi, P8, Q5, TP.HCM 028) 39234332 - 73077307 www.bvnguyentriphuong.com.vnPHIÊN 24/11
09:30 - 12:00, ngày 24/11/2023
Hội trường A
Bệnh viện Nguyễn Tri Phương
CHỦ TỌA
TS.BS Lê Cao Phương Duy
Phó Giám đốc, Chủ tịch HĐ KHCN
BV Nguyễn Tri Phương
TS.BS Trần Quang Khánh
Trưởng khoa Nội tiết 
BV Nguyễn Tri Phương
Nội dung chương trình Nội dung chương trình
09:30 – 09:45
09:45 – 10:00
10:00 – 10:15
10:15 – 10:30  
10:30 – 10:45
10:45 – 11:00
11:00 – 11:15Tỷ lệ bệnh ĐM ngoại biên chi dưới chẩn đoán bằng chỉ số huyết áp cổ chân -
cánh tay gắng sức ở bệnh nhân đái tháo đường típ 2 và các yếu tố liên quan
TS.BS Trần Quang Khánh 
Lao dương vật: nhân một trường hợp                            TS.BS Phan Vương Khắc Thái 
Dự phòng tổn thương niêm mạc dạ dày - tá tràng ở những bệnh nhân có yếu tố
nguy cơ cao                                                                         ThS.BS Nguyễn Thị Nhã Đoan 
Lựa chọn kháng đông đường uống trên bệnh nhân rung nhĩ cao tuổi
    TS.BS Lê Cao Phương Duy 
Ca lâm sàng: U tủy thượng thận trên bệnh nhân u sợi thần kinh típ 1
BS Đoàn Mạnh Dũng
Vai trò của tầm soát sớm biến chứng thận cho bệnh nhân đái tháo đường tuýp 2
BS.CKII Phan Văn Ngọc 
Nghiên cứu kết quả và một số yếu tố ảnh hưởng của phương pháp đặt stent
trong điều trị tổn thương thân chung ĐM vành trái tại bệnh viện Nguyễn Tri
Phương                                                                                        TS.BS Lê Cao Phương Duy 
11:15 – 11:30 Bệnh lý hô hấp và trào ngược dạ dày thực quản                           TS.BS Trần Văn Thi 
11:30 – 12:00Thảo luận - Bế mạc
PGS.TS.BS Nguyễn Văn Trí
Chủ tịch Hội Lão Khoa TP. HCM
Chủ nhiệm bộ môn Nội, trường ĐH
Nguyễn Tất Thành
TS.BS Trần Văn Thi
Trưởng khoa Nội Hô hấp
BV Nguyễn Tri Phương
468 Nguyễn Trãi, P8, Q5, TP.HCM 028) 39234332 - 73077307 www.bvnguyentriphuong.com.vnPHIÊN 24/11
09:30 - 12:00, ngày 24/11/2023
Hội trường A1
Bệnh viện Nguyễn Tri Phương
CHỦ TỌA
TS.BS Nguyễn Đình Xướng
Nguyên Phó giám đốc bệnh viện
Nguyễn Tri Phương
PGS.TS.BS Lâm Huyền Trân
Nguyên Trưởng khoa Tai Mũi Họng
BV Nguyễn Tri Phương
Phó Chủ tịch Hội Tai Mũi Họng TP.HCM
09:30 – 09:45
09:45 – 10:00
10:00 – 10:15
10:15 – 10:30  
10:30 – 10:45
10:45 – 11:00
11:00 – 11:15Nội dung chương trình Nội dung chương trình
PGS.TS.BS Phạm Văn Bùi
Cố vấn chuyên môn 
BV Nguyễn Tri Phương
Chuyển gân cơ lưng rộng dưới hỗ trợ của nội soi khớp vai điều trị rách lớn chóp
xoay không thể khâu : báo cáo loạt ca lâm sàng.                  BS.CKII Phạm Thế Hiển  
TS.BS Phạm Anh Tuấn 
Trưởng khoa Ngoại thần kinh 
BV Nguyễn Tri Phương
Động kinh thái dương kháng thuốc do xơ hóa hải mã       Ths.BS Nguyễn Huệ Đức 
Kết quả điều trị sỏi thận bằng phương pháp lấy sỏi thận qua da
 TS.BS Võ Phước Khương 
Đánh giá kết quả sớm phẫu thuật cắt gan điều trị ung thư biểu mô tế bào gan
trong 5 năm (2017-2022)                                                        TS.BS Huỳnh Thanh Long 
Đánh giá kết quả vi phẫu thuật lấy nhân đệm trên bệnh nhân thoát vị đĩa đệm
thắt lưng – cùng có mảnh rời                                                       Ths.Bs Võ Thành Nghĩa 
Đặc điểm lâm sàng, hình ảnh học, kết quả sớm điều trị vi phẫu thuật u não di căn
tại bệnh viện Nguyễn Tri Phương                                                            BS Lê Anh Khoa 
Sử dụng vạt da mạch xuyên mũ chậu nông kèm xương mào chậu trong điều trị
vết thương khuyết xương bàn bàn chân do tai nạn : nhân 1 trường hợp
BS.CKII Võ Châu Duyên 
11:15 – 11:30Đánh giá tình trạng khô mắt sau phẫu thuật phaco tại bệnh viện Nguyễn Tri
Phương                                                                                          BS.CKII Đặng Trung Hiếu 
11:30 – 12:00Thảo luận - Bế mạc
468 Nguyễn Trãi, P8, Q5, TP.HCM 028) 39234332 - 73077307 www.bvnguyentriphuong.com.vnPHIÊN 24/11
09:30- 12:00 ngày 24/11/2023
Hội trường B
Bệnh viện Nguyễn Tri Phương
Nội dung chương trình Nội dung chương trình
09:30 – 09:45
09:45 – 10:00
10:00 – 10:15
10:15 – 10:30  
10:30 – 10:45Tình hình đề kháng kháng sinh của Klebsiella Pneumoniae tại bệnh viện Nguyễn
Tri Phương giai đoạn 2019 – 2022                                     CN.XN Nguyễn Quang Huy 
Đánh giá kết quả ban đầu sử dụng Remdesivir trên bệnh nhân Covid-19 bệnh
viện Nguyễn Tri Phương                                                                          DS. Từ Mỹ Hương 
Giá trị chẩn đoán lâm sàng của xét nghiệm nhanh phát hiện kháng nguyên Ns1
và xét nghiệm nhanh phát hiện kháng thể IgM đặc hiệu virus Dengue trong
huyết tương người bệnh sốt xuất huyết Dengue           CNXN Trần Hoàng Lệ Dung 
Đánh giá tình hình sử dụng kháng sinh trên người bệnh Covid-19 điều trị nội trú
tại bệnh viện Nguyễn Tri Phương                                           DS.CKI Nguyễn Thu Thảo 
Chi phí điều trị của bệnh nhân đái tháo đường nhập viện vì cơn tăng đường
huyết tại khoa Nội tiết Bệnh viện Nguyễn Tri Phương  BS Nguyễn Thị Diễm Ngọc CHỦ TỌA
BS.CKII Đỗ Tuấn Linh
Phó Giám đốc 
BV Nguyễn Tri Phương
PGS.TS.BS Lê Thị Kim Nhung 
Trưởng Khoa Y Trường Đại học
Nguyễn Tất Thành ĐD.CKI Trần Thị Hồng Huệ
Điều dưỡng trưởng
Bệnh viện Nguyễn Tri Phương TS.BS Nguyễn Minh Hà
Trưởng khoa Xét nghiệm 
Bệnh viện Nguyễn Tri Phương
09:30 – 09:45
09:45 – 10:00
10:00 – 10:15
10:15 – 10:30  Khảo sát tác dụng tồn dư thuốc dãn cơ Rocuronium sau phẫu thuật nội soi ổ
bụng tại Bệnh viện Nguyễn Tri Phương, thành phố Hồ Chí Minh
CNĐD.GMHS Nguyễn Thị Mỹ Xuyên
Khảo sát tài liệu truyền thông liên quan dinh dưỡng tại bệnh viện Nguyễn Tri
Phương năm 2022                                                                          BS.CKI Lâm Vạn Phong 
Kết quả quản lý dịch vụ khám chữa bệnh đáp ứng trải nghiệm của người bệnh
điều trị nội trú tại bệnh viện Nguyễn Tri Phương và một số yếu tố ảnh hưởng
Ths. BS Hồ Huỳnh Uy Tài 
Thảo luận - Bế mạc
468 Nguyễn Trãi, P8, Q5, TP.HCM 028) 39234332 - 73077307 www.bvnguyentriphuong.com.vn

[[[PLACEHOLDER_HEADING]]]# BÁO CÁO KẾT QUẢ KIỂM TRA, ĐÁNH GIÁ CHẤT LƯỢNG BỆNH VIỆN NĂM 2022

Qua công tác kiểm tra đánh giá chất lượng bệnh viện năm 2021 cho kết quả kiểm tra như sau:
# **_Kết quả tự kiểm tra, đánh giá:_**
## **Tóm tắt:**

[[[PLACEHOLDER_HEADING]]]# Trao trả tài sản đánh rơi của thân nhân bệnh nhân ngày 15/01/2024

Vào ngày 15/01/2024, Nhân viên an ninh bệnh viện được trình báo về một túi xách nhỏ màu trắng đánh rơi tại Khoa Thận Lọc Máu. Qua nghiệp vụ của mình, Bộ phận an ninh đã trình báo lên Ban Giám đốc và tiến hành xác minh chủ sở hữu của tài sản là của chị N.T. Vĩ.
Sau khi liên hệ được chị Vĩ, Bộ phận an ninh đã trao trả lại túi xách cùng các tài sản bên trong cho chị.
Rạng sáng ngày 12/06/2023, Khi đang tuần tra an ninh bệnh viện tại khu vực khoa Chấn thương chỉnh hình, Bộ phận an ninh bệnh viện phát hiện một điện thoại để ở khu vực hành lang và không người trông coi. Sau khi lập biên bản và trình báo lên Ban Giám đốc, Bộ phận an ninh đã tiến hành xác minh chủ sở hữu đó là anh N.Q.Tiến và đã trao trả lại cho anh.
**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/) **- Đa khoa Hạng I Thành phố Hồ Chí Minh

[[[PLACEHOLDER_HEADING]]]# 120 năm - BV Nguyễn Tri Phương: trân quý một chặng đường

Bệnh viện Nguyễn Tri Phương tọa lạc tại số 468 đường Nguyễn Trãi, Quận 5, TP.HCM, là một bệnh viện công lập đa khoa trực thuộc Sở Y tế TP.HCM - đồng thời cũng là nơi thực tập của các trường Đại học y dược chuyên ngành. 
Hiện nay, Bệnh viện Nguyễn Tri Phương có đầy đủ các khoa lâm sàng, cận lâm sàng và các loại trang thiết bị - máy móc hiện đại với số giường bệnh thực kê là 800. Trong suốt quá trình hoạt động, tập thể bác sĩ, cán bộ, nhân viên Bệnh viện Nguyễn Tri Phương luôn không ngừng cố gắng nâng cao chuyên môn và chất lượng phục vụ, cũng như công tác huấn luyện đào tạo. 
Trải qua một chặng đường 120 năm trưởng thành và phát triển, đặc biệt trong những năm gần đây, Bệnh viện Nguyễn Tri Phương đã có sự tiến bộ vượt bậc nhờ vào công sức đóng góp không nhỏ của các thế hệ lão thành ngành y phục vụ tại bệnh viện; với sự quan tâm của các cấp lãnh đạo Thành ủy TP.HCM, UBND TP.HCM, đặc biệt là những chỉ đạo chuyên môn kỹ thuật trực tiếp từ Bộ Y tế, Sở Y tế TP.HCM; cùng sự nỗ lực của Đảng ủy, Ban Giám đốc, đội ngũ y bác sĩ và toàn thể cán bộ công nhân viên của bệnh viện; sự đồng hành của các mạnh thường quân để ngày càng nâng cao chất lượng khám, điều trị và chăm sóc người bệnh một cách toàn diện và chuyên sâu. 
Hy vọng với những chia sẻ trong sản phẩm này cũng sẽ góp phần kể cho các bạn nghe về hành trình tiếp nối và phát triển của Bệnh viện Nguyễn Tri Phương, theo thời gian, đã và đang không ngừng cố gắng hoàn thiện vì bệnh nhân thân yêu. 
Trân trọng./.
**Bệnh viện xin chân thành cảm ơn**
- **CÔNG TY CỔ PHẦN TƯ VẤN VÀ TRUYỀN THÔNG ĐẤT VIỆT (DATVIET MEDIA)**
**- Cùng các nghệ sĩ**
Đã thương yêu, đồng hành cùng Bệnh viện trong quá trình sản xuất ra sản phẩm ý nghĩa này!

[[[PLACEHOLDER_HEADING]]]# Kế hoạch về việc tăng cường công tác y tế, đảm bảo công tác khám chữa bệnh và phòng chống dịch bệnh trong dịp Tết nguyên đán Giáp Thìn 2024


[[[PLACEHOLDER_HEADING]]]# Cơ hội tầm soát chậm tăng trưởng chiều cao miễn phí cho trẻ dịp hè 2023

Để tham gia chương trình, từ ngày **05/06/2023 đến ngày 03/07/2023** , phụ huynh có thể gọi điện thoại đăng ký qua hotline:
  * **0335 116 057 hoặc 0932 714 440**
  * Trong khung giờ**8h - 17h.**


_***Lưu ý: Để được khám tầm soát, trẻ cần được đăng ký trước qua số hotline trên. Mỗi phụ huynh chỉ đăng ký 1 lần qua 1 trong 2 số hotline trên. Bộ phận tiếp nhận đăng ký sẽ có những câu hỏi sàng lọc để chọn đúng đối tượng tiếp nhận thăm khám, nâng cao hiệu quả chương trình tầm soát.**_
_Tầm soát chậm tăng trưởng chiều cao miễn phí cho trẻ là chương trình hỗ trợ cộng đồng thường niên của khoa Nội tiết bệnh viện Nguyễn Tri Phương_
Bắt đầu được triển khai từ năm 2017, tính đến nay, chương trình đã tầm soát miễn phí cho hơn 2000 trẻ. Tổng số trẻ được chẩn đoán thiếu GH là hơn 200 trẻ. Trong năm nay, chương trình diễn ra trong 4 tuần, dự kiến sẽ tiếp nhận khoảng hơn 400 trẻ đến thăm khám.
_Từ 4 tuổi trở đi, phụ huynh cần chú ý nhiều hơn đến tốc độ tăng trưởng chiều cao của trẻ._
Chương trình tầm soát được áp dụng cho trẻ trước tuổi dậy thì và sẽ bao gồm các bước kiểm tra chiều cao, cân nặng và khảo sát các triệu chứng chậm tăng trưởng để đưa ra những giải pháp điều trị phù hợp. Trẻ cũng được chụp X - Quang xương bàn tay miễn phí khi có chỉ định để được đánh giá tuổi xương. Từ đó, các bác sĩ sẽ tư vấn về vấn đề phát triển chiều cao của trẻ là bình thường hay bất thường. Những trường hợp nghi ngờ chậm tăng trưởng chiều cao sẽ được hướng dẫn các bước xử trí tiếp theo, bao gồm việc xét nghiệm máu để định lượng chính xác GH và một số hormone liên quan khác trong cơ thể. 
_Cung cấp những thông tin về tiền sử lúc sinh, tiền sử gia đình giúp bác sĩ có được những đánh giá sơ bộ về sự phát triển của trẻ_
Lưu ý, khi tham gia tầm soát, phụ huynh cần cung cấp những thông tin về tiền sử lúc sinh, tiền sử bệnh tật, tiền sử gia đình, tốc độ tăng trưởng chiều cao của trẻ trong 6 tháng trở lên để các bác sĩ có những đánh giá sơ bộ bước đầu. 
Thông thường, trẻ mới sinh có chiều cao 48-52cm, trong năm đầu bé tăng khoảng 20-25cm, sang năm thứ 2 tăng 12cm, năm thứ 3 tăng 10 cm, năm thứ 4 tăng 7cm. Từ 4 tuổi trở đi, phụ huynh cần chú ý nhiều hơn đến tốc độ tăng trưởng chiều cao của trẻ. Từ năm 4-11 tuổi, trẻ sẽ tăng trung bình 4-6cm/nămĐến tuổi dậy thì, bé gái tăng khoảng 6 - 10 cm mỗi năm. Bé trai tăng từ 6,5 - 11 cm mỗi năm. Trường hợp trẻ không đạt được các mốc tăng trưởng về chiều cao theo từng độ tuổi, cha mẹ nên nghĩ ngay đến việc cho trẻ đi khám và tầm soát chậm tăng trưởng chiều cao sớm. 
Có nhiều yếu tố chi phối sự phát triển chiều cao của trẻ, bao gồm: di truyền, dinh dưỡng, môi trường sống, chế độ sinh hoạt, thể dục thể thao, GH… Trong đó, yếu tố di truyền là không thể thay đổi được. Riêng trường hợp chậm tăng trưởng do thiếu GH, theo thống kê, trên thế giới, ước tính chỉ chiếm tỷ lệ khoảng 1/3000 - 1/4.000 nhưng đây là một trong những nguyên nhân quan trọng dẫn đến chậm tăng trưởng ở trẻ em và rất khó nhận biết. 
Nếu không được điều trị, trẻ thiếu GH có chiều cao trung bình chỉ từ 135 - 145 cm, thấp hơn nhiều so với chiều cao tối đa có thể đạt được. Điều này không chỉ ảnh hưởng đến công việc, cuộc sống sau này của trẻ mà còn có thể khiến tâm lý của trẻ bị ảnh hưởng vì sự mặc cảm, tự ti khi so với bạn bè đồng trang lứa. 
**Bác sĩ Trần Thị Ngọc Anh - Khoa Nội tiết, Bệnh viện Nguyễn Tri Phương cho biết:** _“Nếu xác định bệnh nhi bị thiếu GH và cần thiết điều trị, bác sĩ sẽ chỉ định bổ sung GH mỗi ngày. Trẻ thiếu GH được điều trị sớm (ngay từ lúc trẻ bắt đầu chậm tăng trưởng chiều cao) sẽ thấy rõ hiệu quả, trẻ sẽ phát triển gần như trẻ em bình thường khác. Trong một số trường hợp, điều trị sớm có thể giúp trẻ đạt chiều cao bình thường hoặc gần như bình thường theo di truyền từng trẻ. Giai đoạn vàng để điều trị chậm tăng trưởng chiều cao cho trẻ là trước tuổi dậy thì vì sau giai đoạn này, sụn xương trẻ sẽ đóng lại, việc điều trị sẽ không còn hiệu quả. Hiện tại, bệnh viện Nguyễn Tri Phương cũng đang điều trị cho khoảng hơn 80 trẻ chậm tăng trưởng do thiếu GH.”_
Trẻ được chẩn đoán chậm tăng trưởng do thiếu GH được chỉ định bổ sung GH. Mục tiêu của việc điều trị này là để thay thế sự thiếu hụt GH cho sự phát triển chiều cao, các hoạt động chuyển hóa và tình trạng sức khỏe nói chung. Sau 3-6 tháng điều trị, trẻ sẽ được đo lại chiều cao và xét nghiệm máu để đánh giá kết quả và điều chỉnh liều thuốc nếu cần. Trẻ đáp ứng với điều trị sẽ tăng chiều cao từ 8-12 cm/năm. Khi đến tuổi dậy thì, trẻ sẽ được đánh giá lại xem có tiếp tục bổ sung GH hay ngưng bổ sung. Để việc điều trị GH đạt hiệu quả, cần tiến hành đúng thời điểm, đúng liều lượng, tốt nhất trong khoảng độ tuổi 4-13 tuổi. Nếu qua thời gian này, các sụn xương của trẻ đóng lại, dùng hormone tăng trưởng không còn tác dụng.
Trên thực tế, nhiều trường hợp trẻ đến khám tại bệnh viện sau thời gian điều trị hoặc can thiệp dinh dưỡng không hiệu quả. Khi được xác định đúng nguyên nhân gây chậm cao do thiếu GH và tuân thủ theo phác đồ điều trị của bác sĩ, trẻ được cải thiện chiều cao đáng kể, nhiều phụ huynh rất hạnh phúc, bản thân trẻ cũng cảm thấy tự tin hơn.

[[[PLACEHOLDER_HEADING]]]# Đoàn kiểm tra số 2 của Sở Y Tế kiểm tra hoạt động cải cách thủ tục hành chính tại bệnh viện Nguyễn Tri Phương

Vào sáng ngày 07/07/2023, Bệnh viện Nguyễn Tri Phương đã đón đoàn kiểm tra số 2 của Sở Y Tế thành phố Hồ Chí Minh đến làm việc trực tiếp tại đơn vị và đánh giá về công tác cải cách thủ tục hành chính theo công văn số 5240/SYT-TCCB ngày 30/6/2023 của Sở Y Tế
Đánh giá chung của Đoàn kiểm tra là bệnh viện Nguyễn Tri Phương đã có cố gắng thực hiện cải cách thủ tục hành chính, và đánh giá cao sự quan tâm đôn đốc của cá nhân đồng chí Giám đốc bệnh viện đối với công tác này
Tổng điểm đoàn đánh giá dành cho BV Nguyễn Tri Phương là **84/100 đ** , xếp loại: **tốt ./.**

[[[PLACEHOLDER_HEADING]]]# Họp mặt kỷ niệm 76 năm ngày Thương binh - Liệt sĩ 27/7

Chiều 27/7/2023, Bệnh viện Nguyễn Tri Phương (Bệnh viện) tổ chức buổi gặp mặt tri ân đối với cán bộ, nhân viên đang công tác tại Bệnh viện, là con em gia đình thương binh, liệt sĩ và người có công với cách mạng nhân dịp kỷ niệm 76 năm ngày Thương binh – Liệt sĩ (27/7/1947 – 27/7/2023).
Buổi họp mặt có sự tham dự của BS.CKII Võ Đức Chiến – Bí thư Đảng ủy, Giám đốc Bệnh viện, các Đồng chí thành viên Ban Giám đốc, đại diện Hội Cựu chiến binh, đại diện Công đoàn và Đoàn Thanh niên Bệnh viện, cùng toàn thể viên chức, người lao động là con em của gia đình thương binh, liệt sĩ.
Trong không khí thiêng liêng hướng về Ngày Thương binh – Liệt sĩ (27/7), các đại biểu tham dự buổi gặp mặt đã cùng nhau ôn lại ý nghĩa lịch sử của ngày kỷ niệm, một ngày có ý nghĩa nhân văn sâu sắc, là dịp để toàn Đảng, toàn dân và toàn quân ta kính cẩn tưởng nhớ, tri ân các bậc cách mạng tiền bối, anh hùng liệt sĩ, những người con ưu tú của dân tộc đã dũng cảm chiến đấu, anh dũng hy sinh; biết ơn các thương binh đã cống hiến một phần xương máu của mình trong sự nghiệp đấu tranh giải phóng dân tộc, thống nhất đất nước, cũng như trong công cuộc xây dựng và bảo vệ Tổ quốc.
Phát biểu tại buổi lễ, BS.CKII Võ Đức Chiến – Bí thư Đảng ủy, Giám đốc Bệnh viện thay mặt cho Ban lãnh đạo, tập thể viên chức, người lao động Bệnh viện Nguyễn Tri Phương, gửi lời thăm hỏi ân cần và bày tỏ lòng biết ơn sâu sắc tới các gia đình có công với Cách mạng, đồng thời cũng đánh giá cao những cống hiến, đóng góp cũng như tinh thần trách nhiệm của các viên chức, người lao động là con em gia đình thương binh, liệt sĩ trong thời gian qua. Đồng thời, khẳng định Đảng ủy, Ban Giám đốc Bệnh viên sẽ tạo mọi điều kiện thuận lợi để các đồng chí có thêm động lực, không ngừng phấn đấu học tập, tu dưỡng, rèn luyện, làm tốt sứ mệnh bảo vệ và chăm sóc sức khỏe nhân dân.

[[[PLACEHOLDER_HEADING]]]# Công bố đơn vị đào tạo lần thứ 7 đối với BV Nguyễn Tri Phương

Xem toàn bộ công bố [**tại đây**](https://bvnguyentriphuong.com.vn/uploads/072022/files/2761_Cong%20bo%20BV%20Nguyen%20Tri%20Phuong%20dap%20ung%20yeu%20cau%20la%20CSTH%20trong%20dao%20tao%20khoi%20nganh%20suc%20khoe_Lan%207.pdf)

[[[PLACEHOLDER_HEADING]]]# Hội nghị Tiếp xúc, đối thoại giữa Đảng ủy, Ban Giám đốc Bệnh viện Nguyễn Tri Phương với các đoàn thể chính trị - xã hội trực thuộc năm 2023

Ngày 02/8/2023, Đảng ủy Bệnh viện Nguyễn Tri Phương tổ chức Hội nghị Tiếp xúc, đối thoại giữa Đảng ủy, Ban Giám đốc Bệnh viện với các đoàn thể chính trị - xã hội trực thuộc năm 2023. 
Chủ trì Hội nghị về phía Đảng ủy Bệnh viện có đồng chí Võ Đức Chiến – Bí thư Đảng ủy, Giám đốc Bệnh viện; Ban Giám đốc, cấp ủy 15 chi bộ, ngoài ra Hội nghị còn có sự hiện diện của Ban Chấp hành Công đoàn bệnh viện, Đoàn Thanh niên, Hội Cựu chiến Binh Bệnh viện, Trưởng, phó các khoa, phòng và tổ trưởng công đoàn.
**_Đồng chí_**** _Võ Đức Chiến_**** _– Bí thư Đảng ủy, Giám đốc Bệnh viện_**** _chủ trì hội nghị_**
Với tinh thần khẩn trương, nghiêm túc và trách nhiệm, Hội nghị tiếp xúc, đối thoại trực tiếp đã tiếp nhận 12 lượt ý kiến từ đại diện cấp ủy, Đoàn Thanh niên, Công đoàn của các đơn vị trực thuộc Đảng bộ bệnh viện. Các ý kiến đề xuất kiến nghị tập trung vào các lĩnh vực: Cải thiện thu nhập cho nhân viên Y tế; xem xét chế đội độc hại, phụ cấp phù hợp với tình hình thực tế; việc phát triển đảng viên từ đoàn viên ưu tú và lãnh đạo quản lý; tăng cường truyền thông giữa người bệnh và nhân viên y tế…
_**Các đại biểu trao đổi ý kiến tại Hội nghị**_
_**Các đại biểu trao đổi ý kiến tại Hội nghị**_
Trên cơ sở các câu hỏi, kiến nghị của đại diện Cấp ủy chi bộ, Đoàn thanh niên và Công đoàn tại các khoa, phòng đã được các đồng chí chủ trì Hội nghị, lãnh đạo các phòng chức năng của bệnh viện, Đảng ủy bệnh viện trực tiếp trả lời, giải đáp thắc mắc tại Hội nghị.
**_Đồng chí_**** _Võ Đức Chiến_**** _– Bí thư Đảng ủy, Giám đốc Bệnh viện_**** _phát biểu kết thúc Hội nghị_**
Phát biểu kết thúc Hội nghị, đồng chí Võ Đức Chiến – Bí thư Đảng ủy, Giám đốc Bệnh viện lưu ý Trưởng các khoa, phòng và cấp ủy chi bộ các vấn đề sau để kịp thời triển khai: tăng cường đổi mới sáng tạo, cải tiến theo tinh thần Kết luận số 14-KL/TW ngày 22/9/2021 của Bộ Chính trị về chủ trương khuyến khích và bảo vệ cán bộ năng động, sáng tạo vì lợi ích chung; đẩy mạnh công tác kiểm tra nội bộ tại các đơn vị, nâng cao hiểu biết về pháp luật trước các quy định của nhà nước về công tác đấu thầu đối với lĩnh vực y tế để tránh các vi phạm không mong muốn xảy ra; tăng cường học tập trao đổi lẫn nhau để từ đó phát hiện ra các mô hình mới, sáng kiến mới, phát huy nhân rộng thực hiện trong Bệnh viện; thực hiện tốt Thông tư 03/2023/TT-BYT hướng dẫn vị trí việc làm, định mức số lượng người làm việc, cơ cấu viên chức theo chức danh nghề nghiệp trong đơn vị sự nghiệp y tế công lập do Bộ trưởng Bộ Y tế ban hành; sửa đổi, thông qua một số nội dung sửa đổi, bổ sung trong Quy chế chi tiêu nội bộ cho phù hợp với tình hình hiện tại; làm tốt công tác phát triển Đảng.

[[[PLACEHOLDER_HEADING]]]# THÔNG BÁO TRIỆU TẬP THÍ SINH PHỎNG VẤN SÁT HẠCH KỲ TIẾP NHẬN VIÊN CHỨC NĂM 2023

Tải Thông báo [Tại đây](https://bvnguyentriphuong.com.vn/uploads/072022/files/Th%C3%B4ng%20b%C3%A1o%20tri%E1%BB%87u%20t%E1%BA%ADp%20th%C3%AD%20sinh%20%C4%91%E1%BB%A7%20%C4%91i%E1%BB%81u%20ki%E1%BB%87n%20ph%E1%BB%8Fng%20v%E1%BA%A5n%20s%C3%A1t%20h%E1%BA%A1ch%20K%E1%BB%B3%20ti%E1%BA%BFp%20nh%E1%BA%ADn%20v%C3%A0o%20l%C3%A0m%20vi%C3%AAn%20ch%E1%BB%A9c%20n%C4%83m%202023.pdf)
[[[PLACEHOLDER_FILE]]] Nội dung trong file:



[[[PLACEHOLDER_HEADING]]]# Bệnh viện Nguyễn Tri Phương đạt chuẩn bạch kim trong điều trị đột quỵ của hội Đột Quỵ Thế Giới (WSO).

_**Mục đích của giải thưởng:**_ - Do Đột quỵ là bệnh gây tỉ lệ lệ tử vong và tàn phế cao, để lại gánh nặng cho gia đình và xã hội. - Hội đột quỵ thế giới mong muốn nâng cao chất lượng điều trị đột quỵ trên toàn cầu nên đưa ra các tiêu chuẩn xếp loại và trao các giải thưởng điều trị đột quỵ cho các bệnh viện bao gồm các giải thưởng: Diamond Status, Platinum Stastus, Golden Stastus
Căn cứ để trao giải thưởng: Để được nhận chuẩn Bạch kim trong điều trị đột quỵ, cần đạt 8 tiêu chí do WSO đề ra, về hệ thống cấp cứu, về nhân lực, trang thiết bị, tiêu chuẩn vàng trong điều trị nhồi máu não, tái thông mạch máu; được chẩn đoán và can thiệp kịp thời… Giải thưởng được trao hàng quý trong năm bằng hình thức **Chứng nhận giải thưởng**
Việc cứu chữa cho bệnh nhân đột quỵ não được ví như một cuộc “chạy đua” với thời gian vì “thời gian là não”. Hiểu rõ điều đó, để có được “thời gian vàng”, ngoài việc nâng cao y thuật, y đức, các thầy thuốc Bệnh viện Nguyễn Tri Phương đã chủ động triển khai, làm tốt liên kết nhóm giữa các chuyên ngành liên quan (Cấp cứu, Chẩn đoán Hình ảnh, Nội thần kinh, Ngoại Thần kinh, Nhóm Đột quỵ) cũng như các bác sĩ của các bệnh viện tuyến trước. Qua đó nâng cao được tỷ lệ các bệnh nhân đột quỵ cấp được điều trị trong khung giờ vàng. 

[[[PLACEHOLDER_HEADING]]]# Hội nghị sơ kết công tác xây dựng Đảng 06 tháng đầu năm 2023 của Đảng bộ Bệnh viện Nguyễn Tri Phương

**Ngày 31/7/2023, Đảng bộ Bệnh viện Nguyễn Tri Phương đã tổ chức Hội nghị sơ kết công tác xây dựng Đảng 06 tháng đầu năm và triển khai phương hướng nhiệm vụ trọng tâm 6 tháng cuối năm 2023.**
Tham dự Hội nghị, về phía Sở Y tế có đồng chí Phạm Ngọc Nam - Ủy viên Ban chấp hành Đảng bộ, Trưởng ban Tuyên giáo Đảng ủy Sở Y tế; đồng chí Lê Thị Ngọc Ánh – Chuyên viên Dân vận Đảng ủy Sở Y tế. Về phía Bệnh viện, có đồng chí Võ Đức Chiến – Bí thư Đảng ủy, Giám đốc Bệnh viện cùng toàn thể các đồng chí trong Ban Chấp hành Đảng bộ, Ban Giám đốc, cán bộ chủ chốt, Cấp ủy các chi bộ và đảng viên Đảng bộ Bệnh viện đến tham dự Hội nghị.
_Đồng chí_ Võ Đức Chiến _– Bí thư Đảng ủy, Giám đốc Bệnh viện trình bày Báo cáo_
Tại Hội nghị, đồng chí Võ Đức Chiến – Bí thư Đảng ủy, Giám đốc Bệnh viện trình bày Báo cáo Sơ kết công tác xây dựng Đảng 6 tháng đầu năm và phương hướng nhiệm vụ 6 tháng cuối năm 2023 của Đảng bộ Bệnh viện. Qua báo cáo, Đảng ủy Bệnh viện quyết tâm nỗ lực cao hoàn thành tốt công tác lãnh đạo, điều hành các mặt hoạt động của Bệnh viện theo đúng quy định và chỉ đạo của Thành ủy, Ủy ban nhân dân Thành phố, Sở Y tế; nâng cao chất lượng trong công tác quản lý, khám, chữa bệnh, bệnh án điện tử; tăng cường công tác xã hội hóa, các hoạt động dịch vụ để đảm bảo kinh tế y tế, nâng cao đời sống, thu nhập cho viên chức, người lao động nhằm tự chủ chi thường xuyên tại Bệnh viện.
_Đồng chí Phạm Ngọc Nam - Ủy viên Ban chấp hành Đảng bộ, Trưởng ban Tuyên giáo Đảng ủy Sở Y tế_ _phát biểu chỉ đạo hội nghị_
Phát biểu chỉ đạo tại Hội nghị, đồng chí đồng chí Phạm Ngọc Nam - Ủy viên Ban chấp hành Đảng bộ, Trưởng ban Tuyên giáo Đảng ủy Sở Y tế ghi nhận những kết quả đạt được trong 6 tháng đầu năm 2023 của Đảng bộ Bệnh viện, đồng thời cũng định hướng cho Đảng bộ Bệnh viện thực hiện một số nhiệm vụ như: xây dựng kết nối với các trường đại học, tạo môi trường cho nhân viên, bác sĩ, điều dưỡng trong Bệnh viện cùng nhau gắn kết, cùng học tập và nghiên cứu ra nhiều sản phẩm góp phần trong công tác khám, chữa bệnh; định hướng phát triển Trung tâm chuyên khoa sâu theo tinh thần Nghị quyết 31 Bộ Chính trị và Nghị quyết 98 Quốc hội, đẩy mạnh hợp tác công tư có hiệu quả, quan tâm nâng cao đời sống vật chất, tinh thần cho cán bộ nhân viên, làm tốt công tác phát triển Đảng, duy trì nề nếp sinh hoạt Đảng, kiểm tra, giám sát thường xuyên, tuyên truyền Quy định số 85-QĐ/TW ngày 7/10/2022 của Ban Bí thư về việc cán bộ, đảng viên thiết lập và sử dụng trang thông tin điện tử cá nhân trên Internet, mạng xã hội;... Đồng chí cũng hoan nghênh Bệnh viện cử bác sĩ tham gia khám, chữa bệnh ở xã đảo Thạnh An, huyện Cần Giờ và các chương trình khác…, đề nghị Bệnh viện quan tâm chế độ chính sách cho bác sỉ trẻ tham gia khám, chữa bệnh tại xã đảo Thạnh An. Tập trung làm tốt công tác quy hoạch, đào tạo cán bộ, đặc biệt là cán bộ trẻ, phối hợp với Sở Y tế thực hiện kế hoạch luân chuyển cán bộ lãnh đạo, quản lý giai đoạn 2023 – 2025 và nhiệm kỳ 2025 – 2030.
_Đồng chí_ Võ Đức Chiến _– Bí thư Đảng ủy, Giám đốc Bệnh viện tiếp thu ý kiến chỉ đạo_
Đồng chí Võ Đức Chiến– Bí thư Đảng ủy, Giám đốc Bệnh viện thay mặt Đảng bộ Bệnh viện tiếp thu ý kiến chỉ đạo của đồng chí Phạm Ngọc Nam và cảm ơn đến sự quan tâm, tạo điều kiện của các đồng chí Lãnh đạo Sở Y tế; Đảng bộ Bệnh viện sẽ tiếp tục phát huy những kết quả đạt được nhằm hoàn thành tốt nhiệm vụ được cấp trên giao.
Hội nghị sơ kết công tác xây dựng Đảng 06 tháng đầu năm và triển khai phương hướng nhiệm vụ 6 tháng cuối năm 2023 đã diễn ra thành công tốt đẹp. Dưới sự chỉ đạo của Đảng bộ Sở Y tế và Ban chấp hành Đảng bộ Bệnh viện, cán bộ, viên chức, người lao động tiếp tục đoàn kết, chung sức, không ngừng nỗ lực thực hiện các nhiệm vụ được giao, góp phần xây dựng Bệnh viện ngày càng phát triển vững mạnh về mọi mặt.
_Các đại biểu tham dự hội nghị_

[[[PLACEHOLDER_HEADING]]]# Sở Y tế Thành phố Hồ Chí Minh ban hành tiêu chí đánh giá mức độ hoàn thành nhiệm vụ đối với các BV trực thuộc

**Xem toàn bộ:[Tiêu chí đánh giá mức độ hoàn thành nhiệm vụ đối với các BV trực thuộc SYT Tp.HCM](https://bvnguyentriphuong.com.vn/uploads/072022/files/5240-syt-tccb_signed.pdf)
[[[PLACEHOLDER_FILE]]] Nội dung trong file:

**

[[[PLACEHOLDER_HEADING]]]# Công an Thành phố Hồ Chí Minh hỗ trợ định danh VNeID ngay tại BV Nguyễn Tri Phương

Ứng dụng VNeID của Bộ Công an là ứng dụng được tích hợp cùng các tiện ích của thẻ Căn cước công dân điện tử; bảo đảm chính xác, tiện lợi và thông tin của công dân được bảo mật. Người dân sau khi kích hoạt tài khoản định danh điện tử mức 1/mức 2 thành công có thể đăng nhập và sử dụng các chức năng, tiện ích trên ứng dụng VNeID như: Giải quyết dịch vụ công trực tuyến: thông báo lưu trú, đăng ký thường trú, tạm trú, khai báo tạm vắng… sẽ tự điền thông tin vào các biểu mẫu (form) đăng ký mà không phải khai báo, điền thông tin nhiều lần giúp tiết kiệm được nhiều thời gian, chi phí cho các loại biểu mẫu kê khai, giảm nhiều khâu thủ tục cần giải quyết.
Vì đặc thù của bệnh viện hoạt động ca kíp khẩn trương, cường độ cao, cùng với sự thấu hiểu và trách nhiệm của mình, Công an Thành phố Hồ Chí Minh đã quyết định mở điểm hỗ trợ định danh VNeiD ngay tại Bệnh viện trong 02 ngày 19-20/6/2023
**Đối tượng được hỗ trợ trong hoạt động này bao gồm:**
**- Nhân viên y tế và người thân**
**- Học viên, sinh viên đang tham gia đào tạo, thực hành tại BV**
**- Lực lượng lao động khác có mặt tại BV (bảo vệ, lao công...)**
**- Thân nhân và bệnh nhân có nhu cầu**
**Địa điểm thực hiện: Hội trường A2 - lầu 5 - khu A**
**Thời gian: 08.00-16.00 mỗi ngày, hoạt động xuyên trưa**
Xin trân trọng cảm ơn sự hỗ trợ đầy trách nhiệm của lực lượng chức năng đối với Bệnh viện Nguyễn Tri Phương./.

[[[PLACEHOLDER_HEADING]]]# BÁO CÁO KẾT QUẢ KIỂM TRA, ĐÁNH GIÁ CHẤT LƯỢNG BỆNH VIỆN NĂM 2021

  * [Biểu đồ các khía cạnh chất lượng bệnh viện:](https://bvnguyentriphuong.com.vn/thong-tin-benh-vien/bao-cao-ket-qua-kiem-tra-danh-gia-chat-luong-benh-vien-nam-2021#biu-cc-kha-cnh-cht-lng-bnh-vin)
  * [Nhược điểm và vấn đề tồn tại](https://bvnguyentriphuong.com.vn/thong-tin-benh-vien/bao-cao-ket-qua-kiem-tra-danh-gia-chat-luong-benh-vien-nam-2021#nhc-im-v-vn-tn-ti)


Qua công tác kiểm tra đánh giá chất lượng bệnh viện năm 2021 cho kết quả kiểm tra như sau:
# **_Kết quả tự kiểm tra, đánh giá:_**
## **Tóm tắt:**
## **Biểu đồ các khía cạnh chất lượng bệnh viện:**
**Ưu điểm chất lượng bệnh viện:**
- Tham gia tích cực công tác phòng, chống dịch COVID-19 và điều trị người bệnh. - Bệnh viện chú trong nâng cáo các hoạt động nghiên cứu khoa học có các nghiên cứu đăng tạp chí trong nước và quôc tế, cac đè tài khoa học cấp Bộ, thành phố. - Thực hiện nội kiểm. ngoại kiểm các trang thiết bị khoa xét nghiệm tương dối đầy đủ và có kiểm soát sai số chặt chẽ, có đề tài nghiệm thu só sánh chính xác các chỉ số huyết thanh học bằng thị giác và phân tích tự động quyết định nghiệm thu. - Ứng dụng CNTT trong quản lý Bệnh viện, quản lý người bệnh và trả kết quả xét nghiệm
## **Nhược điểm và vấn đề tồn tại**
- Hệ thống nhà chứa rác y tế và quy trình xử lý chất thải cần được tiếp tục cải tiến - Phiếu ATPT chưa đúng quy định. - Việc phân luồng sàng lọc cần bố trí hợp lý hơn, phân luồng người nghi nhiễm và người không có triệu chứng. - Cần cải tiến công tác kiểm soát nhiễm khuẩn: pha chế dung dịch khử khuẩn, ngâm rửa dụng cụ...   
---  
# **Xác định các vấn đề ưu tiên cải tiến chất lượng**
- Tiếp tục cải tiến chất lượng, chú trọng hài lòng người bệnh và nhân viên y tế. - Tiếp tục trang bị các điều kiện cơ sở vật chất phục vụ bệnh nhân, hệ thống xử lý chất thải, phòng mổ - Hoàn thiện hệ thống thanh toán không dùng tiền mặt. - Tăng thêm các chỉ số chất lượng để đánh giá các cải tiến - Phát triển Trung tâm y tế chuyên sâu và kỹ thuật mới - Duy trì hoạt động nghiên cứu khoa học theo hướng hội nhập quốc tế - Áp dụng phần mềm quản lý nghiên cứu khoa học và sáng kiến cải tiến 
# **_Kết luận, cam kết của bệnh viện cải tiến chất lượng_**
Duy trì những hoạt động bệnh viện đã triển khai, khắc phục những nội dung góp ý nhận xét của đoàn. Chú ý cải tiến chất lượng tại các khoa phòng đảm bảo phát triển đồng bộ, nhằm nâng cao hài lòng người bệnh và nhân viên y tế. Đầu tư trang thiết bị y tế phù hợp yêu cầu phất triển chuyên môn, phát triển hệ thống quản lý bằng công nghệ thông tin, ứng dụng công nghệ thông tin
  * [Biểu đồ các khía cạnh chất lượng bệnh viện:](https://bvnguyentriphuong.com.vn/thong-tin-benh-vien/bao-cao-ket-qua-kiem-tra-danh-gia-chat-luong-benh-vien-nam-2021#biu-cc-kha-cnh-cht-lng-bnh-vin)
  * [Nhược điểm và vấn đề tồn tại](https://bvnguyentriphuong.com.vn/thong-tin-benh-vien/bao-cao-ket-qua-kiem-tra-danh-gia-chat-luong-benh-vien-nam-2021#nhc-im-v-vn-tn-ti)



[[[PLACEHOLDER_HEADING]]]# Thay đổi mẫu con dấu của Bệnh viện Nguyễn Tri Phương từ 28/3/2023


[[[PLACEHOLDER_HEADING]]]# Thông báo nghỉ tết dương lịch 2023


[[[PLACEHOLDER_HEADING]]]# Khai trương triển khai thí điểm thực hiện thông báo lưu trú qua phần mềm ASM tại Bệnh viện Nguyễn Tri Phương

- Thực hiện Kế hoạch số 908/KH-UBND ngày 14/3/2023 của UBND thành phố về việc triển khai thực hiện Đề án Phát triển ứng dụng dữ liệu dân cư, định danh và xác thực điện tử phục vụ chuyển đổi số quốc gia giai đoạn 2022 – 2025, tầm nhìn đến năm 2030 (gọi tắt là Đề án 06) năm 2023 trên địa bàn thành phố, đồng thời đưa các nội dung của Đề án 06 đi vào cuộc sống của người dân.
- Nhằm tạo điều kiện thuận lợi cho người dân, nhất là các trường hợp bệnh nhân, người nuôi bệnh tại các cơ sở Y tế trong việc thực hiện khai báo lưu trú theo quy định của Luật cư trú năm 2020.
Sau một thời gian trao đổi, chủ động phối hợp để hoàn thành công tác chuẩn bị các nội dung có liên quan, ngày 07/4/2023, Ban Chỉ đạo thực hiện Đề án 06 thành phố phối hợp với Bệnh viện Nguyễn Tri Phương tổ chức khai trương triển khai thí điểm thực hiện thông báo lưu trú qua phần mềm ASM tại Bệnh viện Nguyễn Tri Phương. 
Tham dự buổi lễ khai trương hôm nay, có lãnh đạo Cục Cảnh sát QLHC về TTXH – Bộ Công an, Đ/c Thiếu tướng Lê Minh Hiếu – Phó Cục trưởng. Ngoài ra còn có đại diện lãnh đạo Sở Y tế , đại diện lãnh đạo Sở Thông tin và truyền thông , đại diện lãnh đạo Sở Văn hoá và Thể thao thành phố, đại diện lãnh đạo Ban Chỉ đạo Đề án 06 Quận 5

[[[PLACEHOLDER_HEADING]]]# Phòng ngừa các đối tượng lừa đảo (thông cáo tháng 3 năm 2023)


[[[PLACEHOLDER_HEADING]]]# Hội thảo: Mô hình nguyên lý bệnh viện thông minh trong hệ thống y tế thông minh

**CHƯƠNG TRÌNH HỘI THẢO**
8:30 Phát biểu chào mừng hội thảo 
BS. CKII Võ Đức Chiến – GĐ BV Nguyễn Tri Phương 
8:40 Giới thiệu đề tài nghiên cứu 
GS. TS. Đặng Vạn Phước – Trưởng Khoa Y ĐHQG Tp. Hồ Chí Minh
8:50 Trình bày nội dung đề tài và các kết quả đã đạt được: 
TS. Trương Minh Chương – Phó Trưởng Khoa Quản Lý Công Nghiệp – ĐHBK Tp. Hồ Chí Minh.
9:20 Phát biểu nội dung thảo luận - BS Nguyễn Thế Dũng – Nguyên GĐ Sở Y Tế - Cố vấn khoa học cho đề tài.
9:30 Tham luận về cách triển khai bệnh án điện tử tại BV Nguyễn Tri Phương 
ThS. Lê Trúc Phương – Trưởng Bộ Môn Quản lý Bệnh viện – Kinh tế Y tế - Khoa Y ĐHQG Tp. HCM.
9:45 Thảo luận và đóng góp ý kiến của các đại biểu
11:15 Kết luận hội thảo – BS. Võ Đức Chiến
11:30 Kết thúc
**Tài liệu hội nghị**

[[[PLACEHOLDER_HEADING]]]# Thông báo nghỉ lễ 2/9/2022

Nội dung đề cập tại Thông báo 133/TB-UBND ngày 10/8/2022 về việc treo cờ Tổ quốc và nghỉ lễ Quốc khánh 02/9/2022.
Theo Thông báo này, cán bộ, công chức, viên chức và người lao động của các cơ quan hành chính, sự nghiệp, tổ chức chính trị, tổ chức chính trị - xã hội nghỉ lễ Quốc khánh từ ngày 1/9 đến hết ngày 2/9/2022.
Các cơ quan, đơn vị bố trí sắp xếp các bộ phận làm việc hợp lý để giải quyết công việc liên tục, đảm bảo tốt công tác phục vụ tổ chức, Nhân dân và công tác phòng, chống dịch bệnh.
Các cơ quan, đơn vị, tổ chức không thực hiện lịch nghỉ cố định 2 ngày thứ Bảy, Chủ Nhật hằng tuần thì căn cứ vào điều kiện thực tế, chương trình, kế hoạch cụ thể của đơn vị để bố trí lịch nghỉ phù hợp, đúng quy định pháp luật.
Các cơ quan, đơn vị, xí nghiệp, trường học, bệnh viện, các đơn vị lực lượng vũ trang và hộ dân treo cờ Tổ quốc từ ngày 1/9 đến hết ngày 2/9/2022.
Như vậy, cán bộ, công chức, viên chức và NLĐ của các cơ quan hành chính, sự nghiệp, tổ chức chính trị, tổ chức chính trị - xã hội nghỉ lễ Quốc khánh từ ngày 1/9 đến hết ngày 2/9/2022.
**Căn cứ như trên, BV Nguyễn Tri Phương thông báo lịch nghỉ lễ 02/9/2022:**

[[[PLACEHOLDER_HEADING]]]# Nghỉ lễ Giỗ Tổ Hùng Vương, Lễ ngày Giải phóng Miền Nam thống nhất đất nước 30/4 và ngày Quốc tế lao động 01/5

Bệnh viện Nguyễn Tri Phương thông báo việc nghỉ lễ Giỗ Tổ Hùng Vương, Lễ ngày Giải phóng Miền Nam thống nhất đất nước 30/4 và ngày Quốc tế lao động 01/5 như sau:
Thời gian nghỉ lễ: 05 ngày liên tục theo quy định từ ngày 29/04/2023 đến hết ngày 03/05/2023
  * Ngày 29/04/2023: Giỗ Tổ Hùng Vương (mùng 10/3 âm lịch)
  * Ngày 30/04/2023: Ngày Giải phóng Miền Nam thống nhất đất nước
  * Ngày 01/05/2023: Ngày Quốc tế lao động
  * Ngày 02/05/2023: Nghỉ bù cho ngày 30/4 vào Chủ nhật
  * Ngày 03/05/2023: Nghỉ bù cho ngày Giổ tổ vào thứ bảy.


Sau thời gian trên, từ ngày 04/05/2023, Khoa Khám Bệnh và các khoa/phòng chức năng hoạt động trở lại bình thường.
**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/) **- Đa khoa Hạng I Thành phố Hồ Chí Minh

[[[PLACEHOLDER_HEADING]]]# Thông báo về nghỉ tết âm lịch 2023


[[[PLACEHOLDER_HEADING]]]# Hội nghị KHKT thường niên BV NTP năm 2022

  * Thời gian: 7.30-11.30 ngày 15/12/2022
  * Địa điểm: Hội trường A - lầu 5, Bệnh viện Nguyễn Tri Phương


**Mã QR dùng để tải nội dung hội nghị**

[[[PLACEHOLDER_HEADING]]]# Bệnh viện Nguyễn Tri Phương trong quá trình chuẩn bị triển khai kỹ thuật ECMO

Hiện chưa có các thuốc điều trị đặc hiệu cho bệnh nhân nhiễm COVID-19. Các biện pháp điều trị đang áp dụng có vai trò hỗ trợ người bệnh vượt qua giai đoạn tấn công của bệnh và chờ đợi miễn dịch của cơ thể hình thành để có thể khống chế virus. Do vậy các biện pháp điều trị hỗ trợ là rất quan trọng đối với các bệnh nhân nhiễm COVID-19. Một trong các biện pháp hỗ trợ quan trọng nhất đó là hỗ trợ **suy hô hấp** khi bệnh diễn biến nặng.
Tổ chức y tế thế giới WHO đã công bố một phác đồ điều trị tạm thời **COVID-19** đồng thời vẫn đang tiếp tục hiệu chỉnh dựa trên các nghiên cứu mới và các báo cáo từ nhiều trung tâm đang điều trị cho người bệnh với nhan đề "Quản lý lâm sàng **nhiễm trùng đường hô hấp** cấp tính nghiêm trọng khi nghi ngờ nhiễm trùng coronavirus. Trong đó có nói về vai trò của ECMO, cụ thể trong tài liệu hướng dẫn của WHO có đưa ra một tuyên bố: "Xem xét chuyển bệnh nhân bị suy hô hấp nặng mặc dù đã được áp dụng chiến lược thông khí bảo vệ phổi đến các cơ sở có thể triển khai ECMO cho bệnh nhân".
Tương tự vậy, Trung tâm kiểm soát dịch bệnh Hoa Kỳ (CDC) cũng đã xuất bản hướng dẫn điều trị lâm sàng bệnh nhân COVID-19 với có hoặc không có hội chứng suy hô hấp cấp tính (ARDS). Trong đó có nêu: Nếu một cơ sở có đủ chuyên môn về thì **ECMO** nên được chỉ định theo tiêu chuẩn của ARDS trong việc hỗ trợ bệnh nhân bị **nhiễm trùng** đường hô hấp dưới do virus COVID-19. 
Tuy nhiên cũng cần nhấn mạnh rõ ràng rằng tại thời điểm này, có rất ít kinh nghiệm với việc sử dụng ECMO để hỗ trợ bệnh nhân COVID-19 do tính chất dịch bệnh mới nổi của COVID-19. Vì vậy rất cần những sự chuyển giao kinh nghiệm và chuyên môn liên quan về ECMO giữa các BV.
Với vai trò của tuyến trung ương, BV Chợ Rẫy đã và đang là "tuyến đầu của lực lượng tuyến đầu" trong phòng chống dịch COVID-19. Vì vậy, nhưng chia sẻ từ chuyên gia của BV Chợ Rẫy là rất quý giá. Đại diện cho tập thể nhân viên, BS CKII Võ Đức Chiến - Giám đốc BV nhấn mạnh sự cảm ơn chân thành đối với buổi chia sẻ kinh nghiệm quý báu này.
Là chuyên gia đến từ BV Chợ Rẫy, đồng thời cũng là giảng viên của Trường ĐH Y Dược Tp.HCM, TS.BS Huỳnh Quang Đại đã có bài báo cáo chia sẻ những vấn đề liên quan đến kỹ thuật EMCO trong thực hành lâm sàng.
Hy vọng trong thời gian sớm nhất, kỹ thuật ECMO sẽ được triển khai thuần thục tại BV Nguyễn Tri Phương để đem lại nhiều lợi ích nhất cho người bệnh.
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh

[[[PLACEHOLDER_HEADING]]]# Chặng đường 100 năm phát triển của BV Nguyễn Tri Phương

Năm 1903, BV Nguyễn Tri Phương là một trạm y tế được thành lập để khám chữa bệnh miễn phí cho bà con người Hoa, đến năm 2003 đã là một BV có 550 giường điều trị nội, ngoại trú; khoảng 20 khoa phòng chuyên môn, nghiệp vụ; thực hiện mổ được các ca mổ siêu phẫu, đại phẫu, phẫu thuật thần kinh; điều trị được hầu hết các loại bệnh, giảm tối đa tình trạng chuyển viện và tỉ lệ tử vong chỉ còn 1,25%.
Tài liệu ghi chép về quãng đường 100 năm hình thành - phát triển là sản phẩm quý giá về lịch sử của bệnh viện. Đây là tài liệu đã được dày công tìm tòi, biên soạn từ các lãnh đạo của bệnh viện qua nhiều thời kỳ.
Những bức ảnh tư liệu quý giá đã giúp ghi lại - và để luôn nhớ về lịch sử phát triển dày dặn của một cơ sở Bệnh viện hạng I ngày hôm nay.
Xin trân trọng giới thiệu tài liệu [100 năm BV Nguyễn Tri Phương](https://drive.google.com/file/d/1MDDmirpmuvTwb50q0Fj0DLc1ZHh0Sz3Z/view?usp=sharing)./.
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh

[[[PLACEHOLDER_HEADING]]]# Nhân viên y tế BV Nguyễn Tri Phương chi viện cho tỉnh Bạc Liêu chống dịch Covid-19

_Căn cứ Kế hoạch số 87/KH-YTGR ngày 18 tháng 8 năm 2021 của Trung tâm Y tế thị xã Gía Rai về việc chuẩn bị sẵn sàng khi có yêu cầu trưng dụng đơn vị để điều trị COVID-19 mức độ vừa;_
_Căn cứ Kế hoạch dự thảo ngày 31 tháng 10 năm 2021 của Trung tâm Y tế thị xã Gía Rai về việc thu dung, điều trị bệnh nhân COVID-19 tầng 2, tầng 3 tại Trung tâm Y tế thị xã Gía Rai;_
_Căn cứ tình hình dịch COVID-19 trên địa bàn các tỉnh miền Tây đang diễn biến phức tạp với chuỗi lây nhiễm, nhiều nguồn lây, nhiều biến chủng với tốc độ lây nhiễm nhanh; Tình hình thực tế tại bệnh viện Nguyễn Tri Phương._
Thực hiện theo tinh thần hỗ trợ công tác thu dung, điều trị bệnh nhân COVID-19
Với quan điểm "Không ai an toàn cho đến khi tất cả mọi người đều an toàn" và tinh thần "Chống dịch nhanh chóng - hiệu quả - quyết liệt", tin rằng sự hỗ trợ từ các nhân viên y tế BV Nguyễn Tri Phương sẽ sớm cùng các đồng nghiệp tại địa phương đẩy lùi dịch bệnh.

[[[PLACEHOLDER_HEADING]]]# Lãnh đạo Thành phố ghé thăm và chúc tết tập thể BV Nguyễn Tri Phương

Chiều ngày 18/01/2022, Đoàn đại biểu Thành ủy, Hội đồng nhân dân, Ủy ban nhân dân, Ủy ban Mặt trận Tổ quốc Việt Nam Thành phố Hồ Chí Minh do đồng chí Võ Văn Hoan, Thành ủy viên, Phó Chủ tịch Ủy ban nhân dân Thành phố Hồ Chí Minh làm Trưởng đoàn đã đến thăm, chúc Tết Bệnh viện Nguyễn Tri Phương nhân dịp Tết nguyên đán Nhâm Dần năm 2022.
Đến thăm, chúc Tết Bệnh viện Nguyễn Tri Phương - Thành ủy viên, Phó Chủ tịch tịch Ủy ban nhân dân Thành phố Võ Văn Hoan trân trọng bày tỏ lòng trân quý, sự cảm kích và gửi lời cảm ơn đến đội ngũ nhân viên y tế, đã không ngại nguy hiểm kề vai sát cánh cùng Thành phố trong thời gian chống dịch và gửi lời cảm ơn sâu sắc đến đấng sinh thành của các nhân viên y tế đã động viên, chia sẻ, gánh vác trách nhiệm gia đình để họ yên tâm lên đường chống dịch. Đồng thời, ghi nhận và đánh giá cao những nỗ lực của đội ngũ y tế Bệnh viện đã thực hiện tốt các nhiệm vụ được giao, góp phần giúp cùng ngành y tế Thành phố, giúp Thành phố Hồ Chí Minh hoàn thành tốt nhiệm vụ và phát triển.
Nhân dịp này, Thành ủy viên, Phó Chủ tịch tịch Ủy ban nhân dân Thành phố Võ Văn Hoan chúc đội ngũ nhân viên y tế Bệnh viện cùng gia đình năm mới bình an, hạnh phúc, an khang thịnh vượng.

[[[PLACEHOLDER_HEADING]]]# ️ PVTrans tặng BV Nguyễn Tri Phương một số phòng khám - điều trị hậu Covid

Theo các số liệu thống kê, tính đến thời điểm tháng 1/2022, toàn TP.HCM có trên 300.000 người từng nhiễm SARS-CoV-2 khỏi bệnh được xuất viện.
Đặc biệt, 2/3 số người nhiễm COVID-19 sau một thời gian dài khỏi bệnh vẫn phải đối mặt với hàng loạt triệu chứng và di chứng kéo dài như mệt mỏi, khó thở, ho kéo dài, giảm sự tập trung, bị huyết khối, xơ phổi…
Các bất thường này, theo đánh giá của các chuyên gia, không chỉ liên quan đến hệ hô hấp mà còn ảnh hưởng lên hệ tim mạch, huyết học, thần kinh, tiêu hóa, nội tiết, rối loạn tâm lý, rối loạn giấc ngủ, suy giảm nhận thức...
Các rối loạn đa dạng này được xem là di chứng của COVID-19 hay hậu COVID-19. Và ở các bệnh nhân COVID-19 mức độ nặng hoặc nguy kịch, những di chứng để lại càng ảnh hưởng nghiêm trọng đến cả sức khỏe thể chất và tinh thần.
Với dự án các phòng khám và điều trị "Di chứng COVID-19", Bệnh viện mong muốn sẽ là nơi khám, tầm soát và điều trị toàn diện các di chứng của bệnh; đồng thời đánh giá nhu cầu can thiệp về dinh dưỡng, vật lý trị liệu - phục hồi chức năng cho bệnh nhân sau mắc COVID-19. Nhất là những người từng bị COVID-19 mức độ nặng, nguy kịch hoặc suy giảm sức khỏe sau khi khỏi bệnh.
Tính đến hết năm 2021, tại TP.HCM có gần 500.000 ca mắc (chiếm khoảng 5% dân số), trong đó có khoảng 300.000 người xuất viện, do đó nhu cầu chăm sóc sức khỏe hậu COVID-19 rất lớn. Tuy vậy tại Việt Nam chưa ghi nhận một cách đầy đủ về tình hình hậu COVID-19 trên cộng đồng.
Sở Y tế TP.HCM xác định hậu COVID-19 đang là một trong những mối quan tâm chính của ngành y tế trong năm 2022, đồng thời sẽ xây dựng chiến lược, mô hình quản lý điều trị phù hợp.
BV Nguyễn Tri Phương tin rằng món quà từ PVTrans thông qua dự án này sẽ phù hợp với nhu cầu của cộng đồng; đồng thời sẽ đóng góp hiệu quả vào định hướng chung của Ngành Y tế Thành phố trong chiến lược phòng chống Covid-19.
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh

[[[PLACEHOLDER_HEADING]]]# Đảng ủy bệnh viện Nguyễn Tri Phương tổ chức Hội nghị sơ kết giữa nhiệm kỳ 2020 - 2025

Trong nửa đầu nhiệm kỳ, Đảng bộ BV đã triển khai thực hiện nhiệm vụ chính trị gắn với thực hiện Nghị quyết Đại hội Đảng bộ BV lần IX và các Chương trình hành động của BCH Đảng bộ SYT thực hiện Nghị quyết Đại hội Đảng bộ Sở Y tế lần thứ IX, nhiệm kỳ 2020-2025.
Hội nghị sơ kết lần này là nghe báo cáo đánh giá kết quả thực hiện nghị quyết giữa nhiệm kỳ 2020-2025, đánh giá tình hình, ưu điểm, khuyết điểm và nguyên nhân, gắn kiểm điểm việc lãnh đạo thực hiện các nhiệm vụ chính trị của Đảng bộ với thực hiện Điều lệ Đảng, các nghị quyết của Trung ương, nhất là Nghị quyết Trung ương 4 khóa XII “về tăng cường xây dựng, chỉnh đốn Đảng; ngăn chặn, đẩy lùi sự suy thoái về tư tưởng chính trị, đạo đức, lối sống, những biểu hiện “tự diễn biến”, “tự chuyển hóa” trong nội bộ và Chỉ thị 05-CT/TW ngày 15/5/2016 của Bộ Chính trị về đẩy mạnh việc học tập và làm theo tư tưởng, đạo đức, phong cách Hồ Chí Minh; Nghị quyết Đại hội Đảng bộ Thành phố lần thứ XI, nhiệm kỳ 2020 – 2025; Nghị quyết Đại hội Đảng bộ Sở Y tế lần thứ IX, nhiệm kỳ 2020 – 2025 và Nghị quyết Đại hội Đảng bộ Bệnh viện Nguyễn Tri Phương lần thứ IX, nhiệm kỳ 2020 - 2025. Bên cạnh đó là báo cáo về các chủ trương, biện pháp của Trung ương, Thành ủy và Đảng ủy Sở để giữ vững, nâng cao tư tưởng chính trị, đạo đức, lối sống của cán bộ, đảng viên, viên chức trong bệnh viện góp phần xây dựng Đảng bộ trong sạch vững mạnh, củng cố lòng tin của người bệnh.
**Về phía Đảng ủy Sở Y tế** , hội nghị có sự tham gia của:
1.Đồng chí Hoàng Thị Diễm Tuyết - Ủy viên Thường vụ Đảng ủy Sở Y tế;Bí thư Đảng ủy – Giám đốc Bệnh viện Hùng Vương
2.Đồng chí Phạm Ngọc Nam - Ủy viên Ban chấp hành Đảng ủy Sở Y tế;Trưởng Ban Tuyên giáo Đảng ủy Sở Y tế
3. Đồng chí Lê Thị Ngọc Ánh - Chuyên viên Ban Tuyên giáo Đảng ủy Sở Y tế.
**Về phía Đảng ủy bệnh viện** , có sự tham gia của:
1.Đồng chí Võ Đức Chiến – Bí thư Đảng ủy – GĐBV
2.Đồng chí Nguyễn Trung Thành – Phó Bí thư Đảng ủy
Cùng các đồng chí là đảng viên 11 chi bộ trực thuộc Đảng bộ bệnh viện Nguyễn Tri Phương.
Những vấn đề được cấp ủy cấp trên đặt ra cho Đảng bộ BV Nguyễn Tri Phương phải chú ý hơn nữa trong thời gian còn lại của nhiệm kỳ 2020 - 2025 như sau:
  * Tiếp tục quan tâm công tác phát triển Đảng viên mới và tách chi bộ độc lập
  * Đeo bám các dự án phát triển chuyên môn (kỹ thuật ECMO, ghép thận...) và cải tạo cơ sở vật chất để không ngừng nâng cao chất lượng khám chữa bệnh
  * Quan tâm cả đời sống vật chất và đời sống tinh thần của nhân viên y tế để hạn chế làn sóng nghỉ việc - tránh ảnh hưởng chất lượng công tác chăm sóc người bệnh
  * Công tác lãnh đạo chính trị luôn đạt sự thống nhất trong tập thể Đảng ủy và Ban Giám đốc - nhất là các hoạt động nhạy cảm như đấu thầu và mua sắm
  * Chú ý hơn đến quy tắc ứng xử của viên chức và người lao động của BV trên mạng xã hội, đảm bảo thông tin trên mạng internet phải có tính chính xác, hiệu quả.



[[[PLACEHOLDER_HEADING]]]# Thông báo tổ chức hội nghị khoa học kỹ thuật thường niên năm 2021

**THÔNG TIN CHƯƠNG TRÌNH**
- Thời gian: Thứ năm, ngày 23/12/2021
- Hình thức tổ chức: Tham gia trực tiếp và trực tuyến
- Địa điểm: Bệnh viện Nguyễn Tri Phương
- Đối tượng: Dự kiến 250 Bác sỹ, Dược sĩ, Điều dưỡng, Kỹ thuật viên bệnh viện Nguyễn Tri Phương (Luôn đảm bảo giãn cách) và 300 bác sỹ bệnh viện bạn trên toàn thành phố thông qua đường link online.
**Kính mời tham gia./.**

[[[PLACEHOLDER_HEADING]]]# Lãnh đạo UBND Quận 5 dến thăm và chúc tết

Năm 2021 với nhiều khó khăn do Covid gây ra nhưng cũng chứng kiến nhiều sự hỗ trợ quý báu hai chiều giữa BV Nguyễn Tri Phương và lực lượng quản lý cũng như lực lượng y tế tại địa phương
Lãnh đạo UBND Quận 5 đã có những lời chúc tết chân tình, thấu hiểu và động viên sự vất vả của lực lượng nhân viên y tế tại BV. 
BS Võ Đức Chiến - Giám đốc BV cũng đã gửi trao những món quà thân tình và tình cảm thân thương đến lãnh đạo UBND Quận 5
Trong không khí tết đến, xuân về - tất cả sẽ cùng hướng đến một năm 2022 an yên hơn và nhiều thành công hơn trong sự hợp tác bền chặt - nghĩa tình!

[[[PLACEHOLDER_HEADING]]]# Đảng bộ BV Nguyễn Tri Phương tổ chức tổng kết hoạt động 2021 và đề ra phương hướng 2022

Ngày 23 tháng 02 năm 2022, Ban Chấp hành Đảng bộ Bệnh viện Nguyễn Tri Phương long trọng tổ chức Hội nghị kỷ niệm 67 năm ngày Thầy thuốc Việt Nam (27/02/1955 – 27/02/2022) và Hội Nghị tổng kết công tác lãnh đạo thực hiện nhiệm vụ chính trị và xây dựng Đảng năm 2021, triển khai nhiệm vụ trọng tâm 2022.
Ngày 27/02 được lấy thành Ngày Thầy thuốc Việt Nam, là dịp để cán bộ, nhân viên y tế ghi nhớ và thực hiện lời Bác dạy, để nhân dân ta thể hiện sự tôn trọng, tôn vinh và cảm ơn các thầy thuốc. Đặc biệt, thời gian qua sự bùng phát của đại dịch COVID-19 với biến chủng mới, lây lan rất nhanh và nguy hiểm hơn đã tác động tiêu cực đến sản xuất kinh doanh, sinh kế và đời sống nhân dân. Dưới sự lãnh đạo của Đảng và Nhà nước, sự vào cuộc của cả hệ thống chính trị, các bộ, ngành, cấp ủy, chính quyền các địa phương, các đoàn thể, các lực lượng tuyến đầu chống dịch, nhất là chứng kiến những nghĩa cử cao cả, đẹp đẽ, những đức hy sinh, những trái tim nhiệt huyết, những tấm lòng nhân ái tỏa sáng… của đội ngũ y, bác sĩ, cán bộ và nhân viên y tế, thầy thuốc trên cả nước, họ không chỉ có trái tim nhân ái, nhân hậu mà còn trí tuệ thông minh, nghị lực kiên cường, sự chịu đựng bền bỉ, nhất khi cuộc chiến diễn ra rất gay go…
Ngay từ khi mới ra đời, dưới sự lãnh đạo của Đảng Cộng sản Việt Nam và Chủ tịch Hồ Chí Minh, Đoàn Thanh niên cộng sản Hồ Chí Minh đã phát huy vai trò xung kích, sẵn sàng hy sinh thân mình để hoàn thành nhiệm vụ của Đảng giao cho, xứng đáng là đội dự bị tin cậy của Đảng. Ở bất cứ giai đoạn cách mạng nào, những nỗ lực phấn đấu, đóng góp của các thế hệ cán bộ, đoàn viên, thanh niên trong cả nước nói chung và Đoàn cơ sở Bệnh viện Nguyễn Tri Phương nói riêng đã được Đảng, Nhà nước ghi nhận và đánh giá cao. Cùng với sức trẻ của Đoàn thanh niên, tổ chức Công đoàn cơ sở Bệnh viện Nguyễn Tri Phương đã không ngừng lớn mạnh, triển khai nhiều chương trình thiết thực, tạo khí thế thi đua sôi nổi trong đội ngũ cán bộ công chức viên chức để tham gia thực hiện thắng lợi Nghị quyết của Đảng bộ Bệnh viên Nguyễn Tri Phương; qua đó xây dựng lực lượng nòng cốt giới thiệu nguồn quần chúng ưu tú sang Đảng để tiếp tục bồi dưỡng, xem xét, kết nạp vào Đảng Cộng sản Việt Nam.
Đồng chí Võ Đức Chiến đã trình bày tổng kết công tác lãnh đạo thực hiện nhiệm vụ chính trị và xây dựng Đảng năm 2021, triển khai nhiệm vụ trọng tâm 2022. 100% Đảng viên đã thống nhất với báo cáo tổng kết công tác lãnh đạo thực hiện nhiệm vụ chính trị và xây dựng Đảng năm 2021, triển khai nhiệm vụ trọng tâm 2022. 
Đồng chí Trần Văn Xồi cũng đã có những đóng góp, chỉ đạo sâu sát đối với hoạt động tiếp theo của Đảng bộ BV như chú trọng hơn nữa vấn đề phát triển Đảng, nhanh chóng khôi phục sau thời gian bị Covid-19 ảnh hưởng nhưng phải chắn chắn - bền vững và đồng thời luôn chú trọng việc xây dựng, hoàn thiện đội ngũ kế thừa. 

[[[PLACEHOLDER_HEADING]]]# Xuân Tri Ân - Tết Đoàn Tụ

_**Thương gửi quý đồng nghiệp,**_
Năm 2021 thật sự là một năm đầy biến động và khó khăn. Gần 5 tháng, toàn dân và ngành y tế cả nước nói chung, hay TP.HCM nói riêng, đã chật vật chống lại kẻ thù mà chúng ta không bao giờ nhìn thấy bằng mắt thường ( SARS-CoV-2) nhưng đã gây ra nhưng mất mát không thể nào quên trên vùng đất thân thương này. Mỗi khi nhìn lại và suy ngẫm đến những tổn thất đau thương về người và vật chất vừa qua để càng thấy rằng: sức khỏe là đều quý nhất phải không các bạn? 
Bên cạnh những khó khăn, chúng ta - đội ngũ y bác sĩ và nhân viên y tế cả nước nói chung và bệnh viện NTP trên mọi mặt trận, cũng đã gặt hái được nhiều điều đáng trân quý - chúng ta yêu thương và trân trọng sự sống của bệnh nhân nhiễm SARS-CoV-2 từng giây phút. Những hy sinh, động viên của các thành viên trong gia đình mỗi nhân viên y tế cũng như cộng đồng vừa qua là động lực để mỗi chúng ta càng phải yêu thương gia đình nhiều hơn, yêu thương đồng nghiệp và những người xung quanh thêm sâu sắc hơn. 
Trong đại dịch, mỗi chúng ta quyết định chọn lý trí hơn là tình cảm; và toàn bộ nhân viên y tế cả nước hay toàn thể nhân viên BV.NTP đã tạm gác lại người thân và gia đình của mình mà lao vào trận tuyến chống dịch cốt mong sao số bệnh nhân tử vong ít nhất và cộng đồng sớm an toàn. Thời gian cao điểm, Bệnh viện Nguyễn Tri Phương đã tiếp nhận điều trị cho từ 300 - 400 bệnh nhân mắc Covid-19 mỗi ngày hay tham gia tại bệnh viện thu dung, trung tâm hồi sức Covid-19, hỗ trợ chia sẻ kinh nghiệm với bệnh viện Covid-19 của tỉnh bạn và ngay cả chích vắc xin cho cộng đồng, trực sàng lọc tại cửa ngỏ thành phố… Ngôi nhà Nguyễn Tri Phương của chúng ta trên 1300 nhân viên cùng lao vào trận chiến trong đó gần 600 nhân viên cũng đã mắc Covid-19. Tôi xin lỗi vì đã chưa thể bảo vệ được vẹn toàn cho các bạn và gia đình.
Thành quả của các bạn cũng như sự sẻ chia và đồng lòng của cả cộng đồng đã góp phần giúp cho thành phố ổn định như hôm nay. Dịch Covid-19 đã được kiểm soát giúp cho mọi người đón Tết cổ truyền, đón Xuân Nhâm Dần an toàn như đã từng trên vùng đất thân thương này- một Thành phố Hồ Chí Minh NĂNG ĐỘNG – NGHĨA TÌNH. Tôi xin cám ơn các bạn, người thân các bạn và cộng đồng. 
Đại dịch tạm lắng, chúng ta cảm nhận được giá trị lớn lao nhất của cuộc đời chính là tình yêu thương, sự sẻ chia và đồng lòng của mỗi người cũng như cả cộng đồng. Như lời Bác Hồ từng căn dặn: “Dễ trăm lần không dân cũng chịu, khó vạn lần dân liệu cũng xong.”
Đã qua hai mùa Tết thấp thỏm vì Covid-19, TPHCM có cơ hội hồi sinh và tìm lại sức mạnh của chính mình. Riêng tại BV.NTP nội lực của chúng ta không những không mất đi, mà kiến thức y khoa và sức mạnh của tập thể y bác sĩ càng được mài giũa qua trận chiến chống Covid-19 để làm nên chiến thắng hiện nay và tương lai trong công tác khám chữa bệnh. 
Không chỉ vậy, các bạn và cộng đồng cũng đã luôn ủng hộ, chung tay vì bệnh nhân với những nội dung như hỗ trợ điều trị tại cấp cứu, viện phí nằm viện, bữa ăn tình thương,chuyến xe nghĩa tình, gian hàng chia sẻ yêu thương, món hàng “0” đồng… giúp người bệnh, thân nhân và nhân viên gặp hoàn cảnh khó khăn đón Tết. Đó là hành động đầy tính nhân văn. 
Trong thời khắc đầu năm mới, Xuân Nhâm Dần 2022 vô cùng ấm cúng này, tôi thay mặt Ban Giám đốc Bệnh viện Nguyễn Tri Phương, xin trân trọng tri ân từng thành viên của ngôi nhà chung BV. Nguyễn Tri Phương, bệnh viện “Năng động – Thân thiện – Phát triển”, tri ân người thân của các bạn, các tổ chức và các cá nhân trong cộng đồng đã là những hậu phương vững chắc để mỗi người trở thành những chiếc khiên bất bại với Covid-19 và chung sức chung lòng vì sự nghiệp cứu người. 
Chúng tôi tự hào vì có các bạn trong ngôi nhà chung này. Năm Nhâm Dần mỗi chúng ta sẽ cùng nhau tiếp tục xây dựng bệnh viện Nguyễn Tri Phương luôn là bệnh viện Năng động - Thân Thiện - Phát triển và là điểm đến tin yêu của mọi người. Xin cám ơn và trân trọng những hy sinh của các bạn trong những ngày đầu năm mới để vào trực tại bệnh viện, khu điều trị Covid-19 tại BV.NTP hay Trung tâm hồi sức Covid-19 với tinh thần không chủ quan vì sức khỏe và sự sống của bệnh nhân. Nhờ đó chúng ta đã một lần nữa góp phần đem lại sự đoàn tụ cho mọi nhà, mừng Xuân đón Tết!
Suy ngẫm đầu xuân trong bối cảnh đáng nhớ này của người dân thành phố tôi xin viết tặng bài thơ để gửi đến các bạn: 
**_CHÚC_** cho Mạnh khỏe - An nhiên,
**_MỪNG_** cho COVID đã yên xuân này!
**_NĂM_** Nhâm Dần sẽ vươn vai,
**_MỚI_** trong tuệ giác, tương lai vững vàng.
TP.Hồ Chí Minh, Mồng 2 Tết, Nhâm dần (2.2.2022)
**BS VÕ ĐỨC CHIẾN**
**Giám đốc BỆNH VIỆN NGUYỄN TRI PHƯƠNG**

[[[PLACEHOLDER_HEADING]]]# Bệnh viện Nguyễn Tri Phương triển khai khám ngoài giờ

Ghi nhận thực tế về nhu cầu khám và điều trị bệnh tại bệnh viện Nguyễn Tri Phương ngày càng tăng khiến cho tình trạng khoa khám bệnh trong giờ hành chính thường quả tải. Hơn nữa nhiều người bệnh có nhu cầu khám và điều trị ngoài giờ, nhất là những người bệnh trong độ tuổi đi làm, đi học nên khó sắp xếp thời gian khám giờ hành chính.
Tạo sự giãn cách cần thiết phù hợp với tình hình mới do dịch bệnh Covid-19.
Góp phần đa dạng hóa các loại hình dịch vụ tại Bệnh viện.
Bệnh viện Nguyễn Tri Phương kính báo về kế hoạch chuẩn bị triển khai khám ngoài giờ (bao gồm BHYT và dịch vụ) từ tháng 06/2021.
Rất mong sẽ tăng thêm sự hài lòng của quý khách hàng và bệnh nhân đối với hoạt động khám chữa bệnh tại Bệnh viện.
Những thông tin liên quan chúng tôi sẽ cập nhật sớm nhất./.

[[[PLACEHOLDER_HEADING]]]# Thông báo về hoạt động của BV từ ngày 01/10/2021

Từ sau 30.9, TPHCM sẽ nới lỏng có lộ trình nhiều hoạt động nhằm phục hồi kinh tế, đồng thời vẫn kiểm soát tốt dịch bệnh. Trong đó, các cơ sở khám bệnh, chữa bệnh công lập, ngoài công lập, cơ sở kinh doanh dược, mỹ phẩm, vật tư, trang thiết bị y tế được hoạt động nếu đáp ứng đủ tiêu chí phòng chống dịch.
**Dưới đây là các nhóm cơ sở được phép hoạt động:**
**_Bệnh viện, phòng khám đa khoa, phòng khám chuyên khoa_**
1. Bệnh viện đa khoa và chuyên khoa.
2. Bệnh xá thuộc lực lượng Công an nhân dân.
3. Phòng khám đa khoa.
4. Phòng khám chuyên khoa, bao gồm:
- Phòng khám nội tổng hợp
- Phòng khám chuyên khoa thuộc hệ nội: Tim mạch, hô hấp, tiêu hóa, nhi và chuyên khoa khác thuộc hệ nội
- Phòng khám tư vấn sức khỏe hoặc phòng tư vấn sức khỏe qua các phương tiện công nghệ thông tin, viễn thông
- Phòng khám chuyên khoa ngoại
- Phòng khám chuyên khoa phụ sản
- Phòng khám chuyên khoa nam học
- Phòng khám chuyên khoa răng - hàm - mặt
- Phòng khám chuyên khoa tai - mũi - họng
- Phòng khám chuyên khoa mắt
- Phòng khám chuyên khoa thẩm mỹ
- Phòng khám chuyên khoa phục hồi chức năng
- Phòng khám chuyên khoa tâm thần
- Phòng khám chuyên khoa ung bướu
- Phòng khám chuyên khoa da liễu
- Phòng khám chuyên khoa y học cổ truyền; Phòng chẩn trị y học cổ truyền... (xem đầy đủ tại [Danh mục cơ sở y tế, khám chữa bệnh tại TPHCM được hoạt động sau 30.9](https://laodong.vn/y-te/danh-muc-co-so-y-te-kham-chua-benh-tai-tphcm-duoc-hoat-dong-sau-309-958865.ldo))
**Như vậy BV Nguyễn Tri Phương xin thông báo - bên cạnh những hoạt động hiện tại sẽ có những thay đổi trong hoạt động khám chữa bệnh của BV từ 01/10/2021 sẽ như sau:**
- Khôi phục lại hoạt động của Khoa Phẫu thuật tạo hình thẩm mỹ (Cổng 2 - mặt đường Nguyễn Trãi)
- Khôi phục lại hoạt động của phòng khám Da liễu - Thẩm mỹ da (tầng trệt khu A)
- Khôi phục lại hoạt động của phòng khám Y Học cổ truyền và Vật lý trị liệu
- _**Khôi phục lại hoạt động khám ngoài giờ (buổi tối) và khám ngoài giờ (có sử dụng BHYT) ngày thứ 7**_
Xem thêm: [**Những hướng dẫn chung khám chữa bệnh trong thời gian giãn cách vì Covid**](https://bvnguyentriphuong.com.vn/hoi-dap/nhung-huong-dan-chung-kham-chua-benh-trong-thoi-gian-gian-cach-vi-covid)
Tất cả các hoạt động của Bệnh viện tuân thủ nguyên tắc **"Bình thường mới"** tức là
- Dịch Covid được tạm thời được khống chế - không phải đã hết dịch trong cộng đồng: **Nguyên tắc** **5K phải luôn được nghiêm túc thực hiện**
- Tiếp tục duy trì xét nghiệm sàng lọc Covid đối với tất cả bệnh nhân có triệu chứng nghi ngờ
- Xét nghiệm sàng lọc Covid đối với các bệnh nhân khám ngoại trú khi xét thấy cần thiết 
- Khi nhập viện vẫn chỉ 01 người nuôi bệnh (trừ khi có những lý do khác phù hợp)
- Khi khám bệnh nếu cần người giúp nâng đỡ: chỉ 01 người đi theo (có xe lăn ở phòng CTXH sẵn sàng hỗ trợ người bệnh khó di chuyển)
Kính báo./.

[[[PLACEHOLDER_HEADING]]]# Sự ghi nhận những cố gắng của BV Nguyễn Tri Phương trong phòng chống dịch Covid-19

Thực hiện Quyết định số 2669/QĐ-UBND ngày 27/7/2021 của Ủy ban nhân dân Thành phố, Bệnh viện Nguyễn Tri Phương đã chuyển một phần công năng thành Bệnh viện dã chiến điều trị bệnh nhân Covid-19 Nguyễn Tri Phương. Tính đến ngày 30/9/2021, Bệnh viện đã tiếp nhận, điều trị 2.410 trường hợp, chuyển bệnh nhân Covid-19 sang thu dung 865 trường hợp, xuất viện 831 trường hợp. Với những trang thiết bị y tế hiện đại được trang bị và được tài trợ, cùng với sự tận tâm, trách nhiệm của đội ngũ nhân viên y tế, Bệnh viện đã cấp cứu, điều trị thành công nhiều bệnh nhân Covid-19 nặng - nguy kịch giúp mang lại niềm vui cho cá nhân, gia đình người bệnh. Đây cũng chính là niềm hạnh phúc của tập thể lãnh đạo và đội ngũ y bác sĩ của Bệnh viện để tiếp tục cuộc chiến gian khó này.
Bên cạnh đó, chung tay cùng Thành phố, cùng ngành y tham gia công tác phòng, chống dịch, Bệnh viện đã tăng cường nhân sự tham gia thực hiện nhiệm vụ:
  * Đo thân nhiệt của người dân tại Quốc lộ 50; 
  * Hỗ trợ vận chuyển, điều trị, chăm sóc bệnh nhân Covid-19 tại Bệnh viện dã chiến Củ Chi, Trung tâm cách ly tập trung Khu B Ký túc xá Đại học Quốc gia Thành phố Hồ Chí Minh, Bệnh viện điều trị Covid-19 Cần Giờ, Bệnh viện hồi sức Covid, Bệnh viện dã chiến số 5, Trung tâm cấp cứu 115…; 
  * Thực hiện lấy mẫu xét nghiệm cộng đồng nhằm phát hiện nhanh những bệnh nhân Covid để kịp thời truy vết, khoanh vùng tránh để dịch lây lan; 
  * Tích cực triển khai tiêm ngừa vắc xin cho các cơ quan hành chính, sự nghiệp, các tổ chức, …giúp cho công chức, viên chức, nhân viên các đơn vị, tổ chức nhanh chóng có được kháng thể chống bệnh và có thể tiếp tục tham gia công tác góp phần ổn định Thành phố. 


Với những kết quả mang lại trong việc triển khai phòng chống dịch Covid-19, Bệnh viện Nguyễn Tri Phương gửi lời chân thành cảm ơn đến những tấm lòng vàng đã chia sẻ, ủng hộ trang thiết bị, đồ bảo hộ, nhu yếu phẩm,… cho tập thể Bệnh viện. Đây là nguồn động viên cổ vũ có giá trị tinh thần rất lớn để nhân viên y tế tiếp tục thực hiện công tác tiếp nhận, cấp cứu, điều trị thật tốt nhằm giúp giảm tỷ lệ tử vong cho bệnh nhân Covid-19 nặng đang điều trị.

[[[PLACEHOLDER_HEADING]]]# Những lời tâm sự cùng nhân viên Bệnh viện Nguyễn Tri Phương

BV.NGUYỄN TRI PHƯƠNG, ngày 19 tháng 07 năm 2021 
“MỘT NGƯỜI VÌ MỌI NGƯỜI - MỌI NGƯỜI VÌ MỘT NGƯỜI”
CHÚNG TA CHỈ AN TOÀN KHI TẤT CẢ ĐỀU AN TOÀN
CHÚNG TA BÌNH YÊN KHI CỘNG ĐỒNG ĐỀU BÌNH YÊN
_**Kính gửi quý anh chị em đồng nghiệp cùng toàn thể nhân viên BV NTP, cũng như các bạn nhân viên của các đơn vị dịch vụ, đối tác đang cùng làm việc và hỗ trợ bệnh viện Nguyễn Tri Phương của chúng tôi**_
Chúng ta không thể không thừa nhận chúng ta đang phải đương đầu với cuộc chiến Covid-19 lần thứ tư đang rất phức tạp và nguy hiểm dựa trên số bệnh nhân mắc và các ca tử vong. Hiện nay, Việt Nam đã có mặt trong top 10 các nước châu Á về số ca mắc và tử vong vì Covid-19 trên bảng tổng kết của Worldometter.
Những ngày này tại BV Nguyễn Tri Phương, ngôi nhà chung của chúng ta thật bận rộn với nhiều lý do:
  * Vì ½ diện tích bệnh viện phải chuyển công năng thành khu điều trị Covid do áp lực điều trị để giảm tử vong bệnh nhân nhiễm Covid nặng, chăm sóc toàn bộ việc ăn uống cho số bệnh nhân này cũng như nhân viên y tế cùng việc bảo đảm vệ sinh phòng bệnh, môi trường…;
  * Vì số ca F0 ngoài cộng đồng đến khám chữa bệnh ngày càng tăng;
  * Vì số nhân viên y tế thuộc khu phong tỏa ngày càng nhiều khiến lực lượng bị mỏng đi, thêm vào đó là số nhân viên bị nhiễm do tham gia nhiệm vụ;
  * Vì phải đảm bảo tính hiệu quả của các hoạt động điều trị bệnh nhân cũng như các hoạt động khác như truy vết, tiêm chủng, tham gia các bệnh viện dã chiến, BV thu dung, …


Và còn vô số những hoạt động khác để chiến đấu với kẻ thù “Giấu mặt”- virus Sars-Cov 2!
Nhưng nếu chúng ta không bảo vệ cộng đồng, thì ngay cả mạng sống những người thân quen của chúng ta cũng sẽ khó bảo toàn vì sự lây lan của đại dịch Covid-19.
Chưa lúc nào như lúc này, các bạn nhân viên y tế phải đối mặt với những khó khăn như:
  * Điều kiện làm việc có bất tiện hơn.
  * Chỗ ăn nghỉ có eo hẹp hơn.
  * Cường độ công việc và tinh thần tâm lý có căng thẳng hơn…


Dù sao đi nữa, tôi vẫn tin rằng tất cả chúng ta đều tự hào với ngành nghề mà chúng ta đã chọn và mục đích tốt đẹp mà chúng ta đang theo đuổi: đó là mỗi người chúng ta được an toàn trong một cộng đồng an toàn.
Ở vai trò là người đứng đầu Bệnh viện, tôi rất biết ơn về mỗi sự hy sinh và mỗi sự chịu khó của từng nhân viên y tế. Trong từng hoàn cảnh, các đồng nghiệp đều phát huy tinh thần trách nhiệm cao để trở thành những chiếc khiên mạnh mẽ bảo vệ cộng đồng. 
Tôi tin rằng cộng đồng không thể quên được hình ảnh thật xúc động của những người chiến sĩ trên mặt trận y tế đang chiến đấu thầm lặng trong những bộ quẩn áo ướt sũng vì mồ hôi sau những lần lấy mẫu, những bàn tay sần da vì sử dụng găng tay y tế kéo dài, sự kiên trì hàng giờ đồng hồ để an ủi những bệnh nhân không thể ở bên gia đình của họ.
Thật cám ơn khi các bạn đã cùng gánh vai để mạo hiểm mạng sống của mình cho rất nhiều người qua những hy sinh cao cả đáng trân trọng của mình.
Nhưng còn gia đình mình thì sao? 
Nhân viên y tế chúng ta cũng là con người bằng xương bằng thịt với những nỗi lo âu, căng thẳng khi nghĩ đến gia đình của mỗi chúng ta đang trong giai đoạn giãn cách này sẽ như thế nào, ai sẽ chăm sóc cha, mẹ, vợ, chồng,… khi họ đang phải trực chiến, chăm sóc bệnh nhân Covid-19, đối mặt với những nguy cơ, những cú sốc tinh thần. Các bạn ơi, có bao điều chúng ta đang trăn trở.
Chiều nay tôi cũng gặp phải 1 câu chuyện về 1 gia đình nhiễm Covid: 2 anh chị chủ nhà trong khu phong tỏa bị phát hiện nhiễm Covid và đã được đưa đến Bv thu dung sau đó mẹ và con mình cũng phát hiện bị nhiễm Covid nhưng mẹ thì có triệu chứng nặng phải nhập bệnh viện trung tâm cùng với cháu nội. Mẹ có diễn tiến SHH nặng rồi tử vong trong khi không có 1 người thân bên cạnh, rồi vì dịch bệnh nên được NVYT của bệnh viện xem như người thân của chính mình đã tiến hành khâm liệm và hỏa tảng (khi được đồng thuận của người thân qua điện thoại vì họ cũng đang trong khu phong tỏa) thật nhanh theo quy định phòng dịch. Thật ngậm ngùi đúng không các bạn! Không ai biết ai ngay cả trong phút lâm chung của một người ngay trong thời bình mà chẳng gặp một người thân nào quả thật là kinh khủng!
Tôi vô cùng đồng cảm mỗi khi nhìn thấy vẻ mặt bất lực của anh em đứng trước nhiều trường hợp bệnh nhân tiến triển nặng rồi mất đi trong khi số ca nhiễm bệnh đang tiếp tục tăng theo cấp số nhân. Thật vậy, TP.HCM đang thống kê mỗi ngày có hơn 1000 ca, rồi 2000 ca, rồi 4000 ca. Và ngay tại BV, chúng ta đã từng tận mắt chứng kiến cảnh đồng nghiệp của mình bị nhiễm Covid-19 trong quá trình phục vụ… Vì thế, việc nhân viên y tế chúng ta đang kiệt sức là điều thật dễ hiểu. Nhiều bệnh viện đang quá tải vì phải phân chia lực lượng để hỗ trợ các công tác khác như lấy mẫu, xét nghiệm, chích ngừa vacxin cho cộng đồng, chăm sóc và điều trị bệnh nhân Covid-19, lại còn việc chăm sóc và điều trị các bệnh nhân mắc các bệnh cấp tính hay mạn tính không nhiễm Covid (vì mô hình bệnh viện tách đôi) … Tuy nhiên, hơn bao giờ hết, lúc này người dân đang rất cần được chăm sóc y tế!
Các bạn ơi, những ngày đầu tập tễnh bước chân vào giảng đường y khoa, hình ảnh người “nhân viên y tế” với một trọng trách cao cả là mang đến tia hy vọng, đôi khi thật hiếm hoi, cho mọi gia đình - luôn theo ta từng bước đi. Đặc biệt trong bối cảnh hiện nay, rất nhiều gia đình đang “tan vỡ” vì Covid-19 đang diễn tiến kéo dài và phức tạp. 
Vì thế, các bạn thật sự là người ơn của cộng đồng và xin đừng bao giờ từ bỏ vì khó khăn và các bạn ơi, mọi người dân đang rất cần bạn! 
Tôi vững tin chúng ta sẽ lại cùng nhau LÀM ĐƯỢC và vượt qua mọi thử thách.
Xin được tri ân từng đóng góp và mong rằng trong thời gian sắp đến, từng nhân viên y tế của BV Nguyễn Tri Phương sẽ giữ vững tinh thần cũng như trách nhiệm của người cán bộ y tế, để đem lại bình yên cho Thành phố và đất nước yêu quý của chúng ta!
Cảm ơn các bạn rất nhiều vì đã dũng cảm chiến đấu với đại dịch để giữ cho tất cả chúng ta được AN TOÀN ! 
Thật không có từ ngữ có thể diễn tả vai trò của các bạn quan trọng như thế nào! Tôi hy vọng rằng các bạn sẽ KHÔNG CHỦ QUAN để giảm thiểu các nguy cơ ảnh hưởng đến sức khỏe bản thân và gia đình.
Tôi biết những dòng chữ ít ỏi này không thể diễn tả hết những tình cảm chân thành của một người đại diện lãnh đạo Bệnh viện, cũng là một người dân của TP.HCM. Tôi cùng gia đình xin bày tỏ lòng biết ơn đối với tất cả các bạn, những chiến sĩ trên mặt trận y tế đang bảo vệ Thành phố chúng ta an toàn khỏi đại dịch này. 
Một lần nữa, xin cám ơn các bạn đã và đang phục vụ cộng đồng với lòng kiên nhẫn, tính trách nhiệm và sự tận tụy quên mình ngày này qua ngày khác, tuần này qua tuần khác vì sự an nguy của người bệnh và toàn thể cộng đồng.
XIN CÁM ƠN CÁC BẠN!
BS VÕ ĐỨC CHIẾN 
GIÁM ĐỐC BV.NGUYỄN TRI PHƯƠNG 

[[[PLACEHOLDER_HEADING]]]# Thông báo nghỉ lễ giỗ tổ Hùng Vương, 30/4 và 01/5

1. Lịch nghỉ lễ nhân ngày giỗ tổ Hùng Vương: 01 ngày 21/4/2021
2. Lịch nghỉ dịp lễ Ngày Chiến thắng (30/4) và Ngày Quốc tế lao động (01/5) năm 2021 được thực hiện như sau: Nghỉ từ thứ Sáu ngày 30/4 đến hết thứ 2 ngày 03/5/2021 (04 ngày nghỉ liên tục)
Hoạt động cấp cứu: 24/24

[[[PLACEHOLDER_HEADING]]]# BV công bố là đơn vị đào tạo thực hành của ĐH Y Phạm Ngọc Thạch (tiến sĩ nội khoa)


[[[PLACEHOLDER_HEADING]]]# Thông báo về việc khôi phục hoạt động khám ngoài giờ

Sau thời gian ổn định công tác tổ chức khám chữa bệnh trong tình hình mới, BV Nguyễn Tri Phương xin kính báo khôi phục các hoạt động sau:
  * **Khám ngoài giờ ngày thứ 7 từ ngày 16/10/2021**
  * **Khám ngoài giờ buổi tối dự kiến từ tháng 11/2021**


Một số lưu ý trong hoạt động khám chữa bệnh để phù hợp với **"tình hình mới"** :
**A. Khi khám ngoài giờ cần thực hiện XN nhanh Covid, khi có kết quả Âm tính sẽ vào phòng khám**
**B. Không cần thực hiện tầm soát Covid với những trường hợp** có
**C. Luôn tuân thủ 5K:** ngồi/đứng dãn cách - luôn đeo khẩu trang - không nói chuyện to - khai báo y tế trước khi vào bệnh viện và thường xuyên vệ sinh tay khi có thể
Kính báo./.

[[[PLACEHOLDER_HEADING]]]# Cho những ngày chiến đấu còn dài…

Kính gửi quý anh chị em đồng nghiệp
Tp.HCM đã bắt đầu với những ngày nóng hơn, nóng vì thời tiết và nóng cả ở những bản tin về Covid-19 cập nhật mỗi ngày (…” thành phố đã ghi nhận tổng cộng 133 ca dương tính với nCoV tính từ 27.5…..” . Cho những ngày chiến đấu còn dài…” …hãy đợi cho qua Tết …”, “…hãy đợi qua hè “….
Trong cái nóng ấy, những chiến sĩ áo trắng sẽ càng cực khổ hơn khi luôn phải trong bộ quần áo bảo hộ đầy bí bách mà tốc độ làm việc thì không ngưng nghỉ ở các chiến địa phòng chống dịch của thành phố. Đêm qua tuy tôi không cùng đi với các bạn đến Quận Gò Vấp, nhưng trong 2 ngày qua tôi luôn dõi theo các anh chị em khi đang ở các điểm lấy mẫu suốt qua Zalo (với tên gọi đặt trên ZALO là nhóm 10, nhóm 11 - Phòng chống dịch... ).
Thương làm sao khi nhận tin các bạn lúc:
**Nhóm 10** : 01giờ42 phút sáng chủ nhật 30.5.2021 “…Giờ bên em mới xong .Hết môi trường rồi. Mọi người đều rất đuối vì từ lúc làm đến giờ chưa ăn uống nghĩ ngơi ….1 phút nào ….” Và các bạn về tới bệnh viện Nguyễn Tri Phương là lúc 03 giờ 10 phút mà vẫn nhắn tin báo cáo kết thúc trong ngày “ Cả nhóm đã về tới BV ạ”.
**Nhóm 11** : 01 giờ 51 sáng chủ nhật 30.5.2021 “Báo cáo nhóm 11 vừa kết thúc thành công“ rồi mãi đến 03 giờ 10 phút thì các bạn về tới BV “về tới BV cùng ngồi ăn bữa sáng đơn giản “ ( bánh bao mà đơn vị Gò Vấp đã có chuẩn bị ). 
Tôi trằn trọc và thấm mệt đi vào giấc ngủ đầy khó nhọc với bao nỗi trăn trở khi thành phố đã chìm rất sâu vào đêm khuya… Chúng ta vẫn nói “sức người có hạn” nhưng rõ ràng vào những ngày tháng này chúng ta lại chứng minh với nhau rằng “ý chí của con người thì vô hạn” phải không các bạn?!
_**Đó là ý chí chiến đấu phòng chống dịch với tất cả tinh thần và trách nhiệm của nhân viên y tế khi xã hội cần.**_
_**Đó là ý chí cố gắng đem lại cuộc sống an lành cho người dân.**_
_**Đó là ý chí chống dịch như chống giặc mà mỗi người chiến sĩ không thể lùi bước.**_
Mỗi chiến sĩ áo trắng ra trận thì mỗi chiến sĩ áo trắng ở địa phương cũng phải cố gắng gồng gánh, bởi bệnh tật không phải chỉ có mình Covid mà những người bệnh tại bệnh viện đang trông đợi vào chúng ta! Trận địa tấn công phải quyết liệt nhưng trận địa phòng thủ cũng phải chặt chẽ vì nếu Covid tấn công được vào các BV thì rất nhiều sinh mạng sẽ bị cướp đi vì họ là những người bất lợi nhất!
Không ai là không quan trọng và mỗi chúng ta đều quyết định quan trọng đến chiến thắng sau cùng trước đại dịch Covid-19 này.
Là những người lãnh đạo của BV – chúng tôi ghi nhận và biết ơn từng sự cố gắng, mỗi sự hy sinh của các nhân viên y tế. Dịch bệnh đến không báo trước và sự biến chủng tạo những áp lực khủng khiếp mà chúng ta chưa bao giờ được báo trước để chuẩn bị. Nhưng bằng cách này hoặc cách khác, chúng ta đã kịp động viên nhau để đoàn kết chống dịch. Ngày Covid lùi xa, chúng ta sẽ rất tự hào khi nhìn lại quãng đường này!
Chúng tôi vẫn luôn dõi theo từng nhóm nhân viên ra trận để xét nghiệm tầm soát, hay các bạn tham gia canh gác cửa ngõ của Thành phố hay các bạn tham gia tại Bệnh viện Dã chiến theo điều động của Sở Y Tế, từng ê kíp nhân viên nhận bệnh – tầm soát nguy cơ hay làm nhiệm vụ tại bệnh viện . Tất cả vì sự an toàn của người bệnh nói riêng và cả Thành phố nói chung, ở đó mỗi nhân viên y tế thật sự là những “siêu nhân không mặc áo choàng”. Chúng tôi một lần nữa cảm ơn vì sự sẵn sàng với sứ mệnh của từng nhân viên y tế, xin cám ơn các bạn: 11 nhóm phòng chống dịch (và chắc chắn thời gian tới bắt buộc phải tăng hơn nữa), Nhóm tiếp ứng BV dã chiến Củ chi và Nhóm gác chốt Quốc lộ 50. 
Đồng lòng của toàn xã hội và sự ủng hộ của tất cả mọi người cùng lực lượng y tế, chúng ta hoàn toàn có niềm tin sẽ chiến thắng đại dịch. Chúng ta – những nhân viên y tế của bệnh viện Nguyễn Tri Phương với phương châm Năng động – Thân thiện – Phát triển, sẽ cùng nhau góp sức để giúp Thành phố Hồ Chí Minh trở lại bình yên !
Trân trọng
Võ Đức Chiến – Giám đốc BV Nguyễn Tri Phương

[[[PLACEHOLDER_HEADING]]]# Thông báo thời gian nghỉ lễ 2/9/2021

## Theo quy định mới tại Bộ luật Lao động 2019 có hiệu lực từ năm 2021, người lao động chính thức có 2 ngày nghỉ lễ Quốc khánh (ngày 2/9 dương lịch và 1 ngày liền kề trước hoặc sau).
Do ngày Quốc khánh 2021 rơi vào thứ năm (2.9.2021), nên cán bộ công chức, viên chức, người lao động của các đơn vị hành chính, sự nghiệp, tổ chức chính trị - xã hội sẽ được nghỉ 4 ngày, tức từ thứ năm ngày 2.9 đến chủ nhật ngày 5.9.
Trong đó, 2 ngày nghỉ lễ dịp Quốc khánh và 2 ngày là ngày nghỉ hằng tuần.
**Bệnh viện Nguyễn Tri Phương** - Bệnh viện Đa khoa Hạng I Thành phố Hồ Chí Minh

[[[PLACEHOLDER_HEADING]]]# Toàn thể nhân viên BV Nguyễn Tri Phương đã hoàn thành tầm soát Covid-19

Thực hiện công văn của Sở Y tế Thành phố Hồ Chí Minh về việc xét nghiệm tầm soát Covid-19 cho nhân viên y tế, cụ thể tại công văn 769/SYT-NVY:
BV Nguyễn Tri Phương đã hoàn thành việc tầm soát cho hơn 1.300 nhân viên y tế và học viên tham gia lấy chứng chỉ hành nghề tại BV. Kết quả ngày 06/3/2021 sau khi hoàn thành cho nhóm xét nghiệm cuối cùng: toàn bộ các mẫu đều ÂM TÍNH./.

[[[PLACEHOLDER_HEADING]]]# Những tiến bộ và phát triển của BV trong năm 2020


[[[PLACEHOLDER_HEADING]]]# Thông báo hoàn tiền thu không đúng quy định năm 2019

**Download**
Thông báo hoàn tiền thu không đúng quy định năm 2019[ tải file tại đây](https://drive.google.com/drive/folders/18Zky9wTqi2OWcTg8HKeimRRNF360nZNZ?usp=sharing)

[[[PLACEHOLDER_HEADING]]]# Lời cảm ơn nhân ngày Thầy thuốc Việt Nam


[[[PLACEHOLDER_HEADING]]]# Dịch vụ y tế tại BV Nguyễn Tri Phương


[[[PLACEHOLDER_HEADING]]]# Thông báo không tổ chức hoạt động mừng Ngày thầy thuốc Việt Nam

Trong bối cảnh dịch bệnh COVID-19 trên cả nước còn diễn biến phức tạp, để tập trung nguồn lực cho công tác phòng chống dịch, thực hiện chỉ đạo của Bộ Y tế tại Công văn số 1015/BYT-VPB1 ngày 18/02/2021 về việc không tổ chức Lễ kỷ niệm 66 năm ngày Thầy thuốc Việt Nam (27/2/1955 – 27/2/2021), BV Nguyễn Tri Phương xin thông báo sẽ không tổ chức các sự kiện chúc mừng ngày Thầy thuốc Việt Nam.
Đồng thời, BV Nguyễn Tri Phương cũng TRÂN TRỌNG tri ân đến những đồng nghiệp ở tuyến đầu và tâm dịch, đã - đang mỗi ngày mỗi giờ giữ bình yên cho xã hội trước Covid!
Trong tình hình dịch bệnh diễn biến khó lường, chúng ta hãy cùng nhau thực hiện tốt các biện pháp phòng bệnh theo thông điệp 5K cũng như tăng cường khai báo y tế trên hệ thống online trước khi đến BV. Giảm tải cho nhân viên y tế và tăng sự an toàn cho mình - món quà quý nhất cho ngày 27/2!
Tính năng khai báo online và hệ thống QR code đều có tại trang web của BV, được đặt sẵn ở trang chủ!

[[[PLACEHOLDER_HEADING]]]# Lời chúc tết từ Ban giám đốc BV


[[[PLACEHOLDER_HEADING]]]# THÔNG BÁO VỀ LỄ TẤT NIÊN 2020

Ngày 30/01/2021 và 06/02/2021 theo như kế hoạch từ đầu tháng 1/2021, BV Nguyễn Tri Phương mong muốn tổ chức 02 buổi lễ tất niên để cảm ơn quý đối tác và quý cán bộ, quý nhân viên đã đồng hành cùng nhau qua năm 2020 nhiều khó khăn.
Tuy nhiên, vì diễn biến về COVID trở nên phức tạp, lãnh đạo Thành phố và Sở Y Tế đã có nhiều chỉ đạo phòng chống dịch trong đó nhấn mạnh về 5K (Khẩu trang – Khai báo – Không tụ tập – Giữ khoảng cách – Khử khuẩn). 
Để đảm bảo sự an toàn phòng chống dịch, mặc dù gần như đã hoàn tất tất cả các nội dung chuẩn bị, BV Nguyễn Tri Phương vẫn phải quyết định hủy tổ chức 02 lễ tất niên theo dự kiến. Thay mặt toàn thể Ban tổ chức, Ban Giám đốc BV rất tiếc và xin cáo lỗi vì những tình hình bất khả kháng.
Cũng qua đây, Ban Giám đốc Bệnh viện xin kính chúc những điều may mắn nhất đến với mọi người cũng như cầu mong năm 2021 sẽ có nhiều điều thuận lợi, thành công hơn cho tất cả chúng ta.
- - -
Giám đốc BV Nguyễn Tri Phương
BS CK2 Võ Đức Chiến

[[[PLACEHOLDER_HEADING]]]# Hội đồng đạo đức của BV được cấp mã hoạt động từ Bộ Y Tế


[[[PLACEHOLDER_HEADING]]]# Công bố đánh giá chất lượng bệnh viện năm 2020

Điểm chất lượng bệnh viện đạt được của năm 2020 là **3.87 điểm** (trên thang điểm tối đa là 5 điểm) và cao hơn số điểm của năm 2019. 
Đánh giá bệnh viện đã có tiến bộ, cải tiến chất lượng hơn so với năm trước.
##  **nh viện Nguyễn Tri Phương** - Bệnh viện Đa khoa Hạng I Thành phố Hồ Chí Minh
  * 468 Nguyễn Trãi, Phường 8, Quận 5, Tp. Hồ Chí Minh
  * Hotline: (84-028) 39234332
  * Mạng xã hội **Facebook** : [**Bệnh viện Nguyễn Tri Phương**](https://www.facebook.com/BVNTP/)
  * Đăng ký (Subcribe) kênh **Youtube** : [https://youtube.com/bvntp](https://youtube.com/bvntp?fbclid=IwAR3q_UvPI4OZAebT1uQGPKKwk3RmCzAFLkBJm9lb7EwIz0EHtgiLhKM5bxU)
  * Quan tâm Zalo Official: [zalo.me/1744466261097093886](https://zalo.me/1744466261097093886?fbclid=IwAR3E-fLqdh-x1cYSvuDY6E5Eyxfjo5ZSs4p0hDWAyBG-ROlTkxXkXvdEWAY)



[[[PLACEHOLDER_HEADING]]]# THÀNH TỰU Y TẾ TRONG NĂM 2020

  1. **Ghép thận nhân tạo**


Với mong mỏi triển khai kỹ thuật mới về ghép thận, Bệnh viện Nguyễn Tri Phương đã có ký hợp đồng nhận chuyển giao kỹ thuật ghép thận từ BV.Trung Ương Huế. Trong lộ trình này tại BV.NTP vừa thực hiện ghép thận thành công với sự hỗ trợ chuyên môn của ê kíp ghép thận gồm các Giáo sư, Bác sĩ đến từ bệnh viện Trung ương Huế. 
Phẫu thuật ghép được phối hợp chặt chẽ giữa các ê kíp hồi sức gây mê, các chuyên khoa nội theo dõi hậu ghép và chuyên khoa ngoại của cả 2 bệnh viện Nguyễn Tri Phương và Trung ương Huế. Tổng thời gian phẫu thuật gồm lấy và ghép thận kéo dài khoảng 4 giờ 30 phút. Ngay sau kết nối mạch máu thận ghép với mạch máu người nhận, bệnh nhân đã có những giọt nước tiểu đầu tiên với sự vui mừng phấn khởi của toàn thể ê kíp phẩu thuật. 
Sau ghép, tình trạng bệnh nhân ổn định dần , dưới sự chăm sóc tận tình và thông tin kịp thời giữa chuyên gia của BV.NTP và BV.TW Huế đến nay bệnh nhân có chức năng thận ghép rất tốt và đã hoàn toàn ổn định từ ngày thứ 5 sau ghép. Bệnh nhân tự tiểu bình thường, khỏe, ăn ngủ ngon hơn, chức năng thận trở về giới hạn bình thường với độ lọc cầu thận ước tính khoảng 90ml/phút và các thông số khác cũng đều trong giới hạn bình thường
  1. **Ứng dụng công nghệ nhận dạng khuôn mặt để chống nhầm lẫn người bệnh tại khoa Phẫu thuật gây mê hồi sức (PTGMHS)**


Hệ thống sử dụng camera để thu nhận hình ảnh khuôn mặt người bệnh và nhân viên y tế, sau đó sử dụng các thuật toán trí tuệ nhân tạo để nhận diện người bệnh và nhân viên y tế có đúng với hình ảnh được lưu trữ trước hay không? Nếu không đúng thì phát cảnh báo để nhân viên y tế kiểm tra lại nhằm loại trừ trường hợp nhầm lẫn người bệnh.
Xây dựng, triển khai: Hệ thống bao gồm các camera được lắp đặt tại cửa ra vào khoa PTGMHS, phần mềm nhận dạng khuôn mặt, phần mềm đưa hình ảnh người bệnh và nhân viên y tế.
Vận hành: Bệnh nhân trước khi được chuyển lên khoa PTGMHS, điều dưỡng dùng app trên điện thoại nhập thông tin hành chánh bệnh nhân (thông tin được chuyển từ phần mềm quản lý bệnh viện HIS), sau đó chụp lại hình bệnh nhân. Thông tin hình ảnh của bệnh nhân được luu xuống CSDL của hệ thống nhận diện. Khi vận chuyển bệnh nhân lên khoa PTGMHS, tại cửa vào của khoa PTGMHS có gắn camera, camera này sẽ tự động quét và check trong CSDL, nếu chính xác là bệnh nhân, sẽ thông báo trên màn hình thông tin bệnh nhân. Phần mềm đồng thời cũng thực hiện tính năng nhân diện khuôn mặt nhân viên để thực hiện chức năng điểm danh nhân viên tại khoa PTGMHS.
  1. **Kiểm soát tình trạng thay đổi độ sâu trong gây mê bằng phương pháp trí tuệ nhân tạo**


Nghiên cứu này đề xuất một phương pháp mới để xác định chuyển tiếp của các trạng thái gây mê khác nhau của người bệnh liên quan đến phẫu thuật. Một chỉ số mới PDoA đã được phát triển để phát hiện sự thay đổi trạng thái gây mê. Dựa trên chỉ số PDoA, chúng ta sẽ đánh giá mức độ gây mê sâu của người bệnh chính xác, rõ ràng và được dự báo theo 5 cấp độ gây mê như sau: mất ý thức, mê nhẹ, mê vừa, mê sâu và tỉnh mê. Đồng thời, kiểm soát tốt hơn quá trình gây mê như là tránh gây mê nông hoặc quá sâu, ngăn ngừa tỉnh mê trong khi phẫu thuật và rút ngắn thời gian tỉnh mê. Kết quả này có thể áp dụng để tối ưu hóa liều lượng thuốc gây mê, nhằm đem lại sự an toàn cho người bệnh trong gây mê và phẫu thuật. Ngoài ra, giá trị cá nhân hóa (PR) có thể thay đổi đối với từng người bệnh trong nhóm có cùng thông số như tuổi, giới tính, cân nặng, chỉ số BMI và dấu hiệu lâm sàng. Do đó, áp dụng điều này để điều chỉnh lượng thuốc mê sử dụng chính xác, an toàn và hiệu quả hơn cho người bệnh. 
Kết quả của nghiên cứu này mang lại tiềm năng về một phương pháp mới để giám sát quá trình chuyển đổi trạng thái gây mê và xác định sự đáp ứng của mỗi cá nhân đối với sự dẫn mê bằng thuốc mê tĩnh mạch nhằm giảm nguy cơ thức tỉnh trong mổ của bệnh nhân và giảm liều thuốc mê.
  1. **Ứng dụng công nghệ trí tuệ nhân tạo trong nhận diện hình ảnh X Quang phổi nghi lao để tăng cường phát hiện lao trong cộng đồng**


Hệ thống chụp phim X Quang phổi của BV hiện nay đang sử dụng hệ thống quản lý dữ liệu chẩn đoán hình ảnh PACS của đơn vị đại học bách khoa. Kết nối phần mềm PACS với ứng dụng trí tuệ nhân tạo qXr v3.0 do công ty Qure.ai (Ấn Độ) phát triển để giúp tầm soát 01 lần nữa những phim phổi (kết hợp với BS Chẩn đoán hình ảnh để đọc) nhằm không bỏ sót phim X Quang nghi lao
* Giới thiệu về qXr v3.0 
Xây dựng, triển khai: Hệ thống phần mềm qXr v3.0 có thể phát hiện các dấu hiệu bất thường trên phim X-quang ngực. Nó có thể được dùng để phân biệt phim bình thường từ các phim bất thường, nhằm hỗ trợ trước khi đọc phim, hoặc hoạt động như là một công cụ kiểm tra phim chụp. qXR bao gồm các mô thức lập trình có thể phát hiện tổng cộng 29 dấu hiệu trên phim Xquang ngực, từ đó gợi ý các tổn thương nghi lao cho BS CĐHA xem và kết luận (1). Hệ thống qXr rà soát 01 lần nữa tất cả các phim được kết luận không có tổn thương nghi lao và khuyến nghị các phim nghi lao (2)
Vận hành: Tất cả các phim được nghi ngờ có tổn thương nghi lao ở (1) và (2) sẽ chuyển về BS đang theo dõi điều trị để mời bệnh nhân tham gia xét nghiệm GeneXxpert từ mẫu đàm (chi phí được tổ chức FIT hỗ trợ 100%)

[[[PLACEHOLDER_HEADING]]]# BỆNH VIỆN NGUYỄN TRI PHƯƠNG TỔ CHỨC NGÀY HỘI VỆ SINH TAY

Trong dịch bệnh COVID-19 vẫn còn đang phức tạp thì vấn đề tuân thủ rửa tay đã quan trọng nay còn thiết yếu hơn. Theo Tổ chức y tế thế giới (WHO) vệ sinh tay là biện pháp đơn giản, rẻ tiền làm giảm 30% vi khuẩn gây bệnh, có hiệu quả góp phần đáng kể làm giảm nhiễm khuẩn bệnh viện, hạn chế tình trạng lây lan của các mầm bệnh.
Hàng năm, Hội đồng Kiểm soát nhiễm khuẩn (KSNK) và khoa KSNK phát động phong trào vệ sinh tay nhằm nhắc nhở NVYT tại bệnh viện quan tâm đến VST **“Việc làm nhỏ - Lợi ích lớn”** theo chủ đề hàng năm của thế giới. Năm 2020, theo khuyến cáo của WHO, bệnh viện khởi xướng ngày hội vệ sinh tay 15/10/2020 với chủ đề “** _TẤT CẢ CHĂM SÓC SẠCH – NẰM TRONG BÀN TAY BẠN_** _”._
Ngày lễ phát động thu hút sự tham gia đông đảo của NVYT, lãnh đạo các khoa phòng của BV cùng đồng thuận ký cam kết tuân thủ vệ sinh tay. Trong dịp này Ban giám đốc đã khen thưởng các khoa phòng thực hiện tốt công tác vệ sinh tay nhằm khích lệ tinh thần của NVYT.
  * Theo dõi fanpage chính thức của **BV-NTP** để biết thêm các thông tin tại 
  * Tham khảo thêm các video dành cho cộng đồng trên kênh **Youtube** của **BV-NTP** tại 



[[[PLACEHOLDER_HEADING]]]# HỘI NGHỊ KHOA HỌC KỸ THUẬT THƯỜNG NIÊN CỦA BỆNH VIỆN LẦN THỨ 8

**_Chương trình hội thảo:_**
**Ngày thứ tư****18****tháng 11 năm 2020**  
---  
**Thời gian** |  **Nội dung** |  **Báo cáo viên**  
07g30 – 08h00 |  Đón tiếp đại biểu  
08h00 – 08h15 |  Khai mạc hội nghị |  BSCKII Võ Đức Chiến  
**PHIÊN TOÀN THỂ**  
8h15 – 8h35 |  Vai trò của công nghệ 4.0 trong quản lý bệnh viện, thực tiễn từ hoạt động BV Nguyễn Tri Phương năm 2020 |  BSCKII Võ Đức Chiến  
8h35 – 8h55 |  Bước tiến mới trong bảo vệ thận cho bệnh nhân đái tháo đường type 2 sau 20 năm |  PGS.TS.BS Phạm văn Bùi  
8h55 – 9h10 |  Quản lý Bệnh viện trong trạng thái bình thường mới |  TS Trương Minh Chương  
9h10 – 10h00 |  Giới thiệu sản phẩm của các công ty – Giải lao  
**HỘI TRƯỜNG A: NỘI KHOA**  
10h00 – 10h15 |  Cập nhật về điều trị chống huyết khối cho bệnh nhân hội chứng vành cấp không ST chênh lên và bệnh lý động mạch ngoại biên theo ESC 2020 |  TS.BS Lê Cao Phương Duy  
10h15 – 10h30 |  Nghiên cứu đánh giá hiệu quả phẫu thuật nối thông động tĩnh mạch để chạy thận nhân tạo |  ThS.BS Nguyễn Thanh Vân  
10h30 – 10h45 |  Kết cục thân và tim mạch trên người bệnh đái tháo đường type 2 theo dõi 5 năm tại bệnh viện quận |  PGS.TS Lê Tuyết Hoa (ĐHYK PNT)  
10h45 – 11h00 |  Nghiên cứu kết quả của can thiệp động mạch vành qua da thì đầu có kết hợp hút huyết khối ở bệnh nhân nhồi máu cơ tim cấp có ST chênh lên |  TS.BS Lê Cao Phương Duy  
11h00 – 11h15 |  Triển vọng cải thiện tiên lượng và chất lượng sống cho bệnh nhân suy tim: cập nhật ESC 2020 |  BSCK2 Nguyễn Quang Dũng  
11h15-11h30 |  Kiểm soát tình trạng thay đổi độ sâu trong gây mê bằng phương pháp trí tuệ nhân tạo |  PGS.TS Nguyễn Văn Chinh  
**HỘI TRƯỜNG A2: NGOẠI KHOA**  
10h00 – 10h15 |  Kết quả điều trị gãy cột sống lưng - thắt lưng do loãng xương bằng phẫu thuật nẹp vít qua cuống cung kết hợp bơm xi măng sinh học |  TS.BS Phạm Anh Tuấn  
10h15 – 10h30 |  Kết quả điều trị đục bao sau thứ phát sau mổ phaco bằng Laser YAG tại bệnh viện Nguyễn Tri Phương |  BSCKII Đặng Trung Hiếu  
10h30 – 10h45 |  Đánh giá kết quả bước đầu áp dụng phương pháp lấy sỏi thận qua da đường hầm nhỏ tại bệnh viện Nguyễn Tri Phương |  TS.BS Võ Phước Khương  
10h45 – 11h00 |  Kết quả nội soi tái tạo dây chằng chéo sau bằng kỹ thuật tất cả bên trong với tăng cường chỉ bền trong mảnh ghép |  BSCKII Trần Công Quốc Bửu  
11h00 – 11h15 |  Kết quả bước đầu phẫu thuật nội soi cắt bán phần dưới dạ dày nạo hạch D2 điều trị ung thư dạ dày |  BSCKII Trần Văn Hiệp  
11h15-11h30 |  Đặc điểm tổn thương đường mật do cắt túi mật nội soi có tai biến và kết quả sửa chữa trong 05 năm (2015-2019) tại Bệnh viện Nguyễn Tri Phương |  TS.BS Huỳnh Thanh Long  
11h30-11h45 |  Ứng dụng vạt da cân có cuống mạch nuôi là nhánh xuyên của động mạch mông trên và động mạch thắt lưng trong điều trị loét cùng cụt độ III, IV |  TS.BS Nguyễn Văn Thanh  
**HỘI TRƯỜ****NG B: CẬN LÂM SÀNG - ĐIỀU DƯỠNG - DƯỢC**  
10h00 – 10h15 |  Khảo sát nhu cầu tư vấn sử dụng thuốc bởi dược sĩ của bệnh nhân ngoại trú tại bệnh viện Nguyễn Tri Phương |  ThS.DS Tôn Thị Thanh Thảo  
10h15 – 10h30 |  Thực trạng việc đăng ký suất ăn dinh dưỡng tại bệnh viện Nguyễn Tri Phương năm 2020 |  CNĐD Chung Châu Mỹ  
10h30 – 10h45 |  Thực trạng người bệnh bị tai nạn giao thông đến cấp cứu bệnh viện Nguyễn Tri Phương từ tháng 03/2020 đến tháng 06/2020 |  ĐD Nguyễn Thị Lan Minh  
10h45 – 11h00 |  Khảo sát tương tác thuốc trên bệnh nhân ngoại trú được kê từ 5 thuốc trở lên tại bệnh viện Nguyễn Tri Phương |  ThS.DS Nguyễn Thế Anh  
11h00 – 11h15 |  Khảo sát hiệu quả “Phiếu yêu cầu sử dụng kháng sinh” tại bệnh viện Nguyễn Tri Phương |  BSCKII Võ Đức Chiến  
11h15-11h30 |  Khảo sát sự hiểu biết về COVID-19 của người dân đến khám chữa bệnh tại bệnh viện Nguyễn Tri Phương |  ThS.BS Lương Công Minh  
**HỘI TRƯỜNG D: SÁNG KIẾN**  
10h00 – 10h15 |  Giá treo áo chì kiêm tấm che chắn tia X cho bệnh nhân chụp X Quang |  KTV Lưu Quốc Trung  
10h15 – 10h30 |  Phần mềm theo dõi đặt sonde JJ |  CN Trần Nguyên Vũ  
10h30 – 10h45 |  Cải tiến thời gian sử dụng Simethicone làm sạch bọt trong nội soi đường tiêu hóa |  BS Đặng Lê Bích Ngọc  
10h45 – 11h00 |  Bảng nam châm cố định kim phẫu thuật |  ĐD Trương Huệ Phương  
11h00 – 11h15 |  Phễu và ống dẫn nước thải ngoài máy thận nhân tạo |  ĐD Nguyễn Chí Lập  
11h15-11h30 |  Tự điều chế hồng cầu mẫu A và hồng cầu mẫu B |  KTV Nguyễn Thị Hương  
Chúng tôi sẽ liên tục cập nhật nếu có bất kỳ sự thay đổi nào
Trân trọng kính mời tham gia!

[[[PLACEHOLDER_HEADING]]]# TRAO TẶNG KỶ NIỆM CHƯƠNG 'VÌ SỰ NGHIỆP XÂY DỰNG TỔ CHỨC CÔNG ĐOÀN' CHO BS CK2 VÕ ĐỨC CHIẾN

Hôm nay, ngày 12 tháng 08 năm 2020, Tổng Liên đoàn Lao động Việt Nam đã đến và trao tặng Kỷ niệm chương**"Vì sự nghiệp xây dựng tổ chức Công đoàn"** theo Quyết định số: 1004/QĐ-TLĐ cho **[Bác sĩ Chuyên khoa II Võ Đức Chiến](https://www.facebook.com/BVNTP/photos/a.2584766368503387/2584841228495901) - Giám đốc Bệnh viện Nguyễn Tri Phương.**
Phần thưởng cao quý này ghi nhận những đóng góp xây dựng to lớn của [Bác sĩ Chuyên khoa II Võ Đức Chiến](https://www.facebook.com/BVNTP/photos/a.2584766368503387/2584841228495901) cho sự phát triển của tổ chức Công đoàn Việt Nam./.
  * Theo dõi fanpage chính thức của **BV-NTP** để biết thêm các thông tin tại 
  * Tham khảo thêm các video dành cho cộng đồng trên kênh **Youtube** của **BV-NTP** tại 



[[[PLACEHOLDER_HEADING]]]# CẬP NHẬT TÌNH HÌNH QUYÊN GÓP PHÒNG CHỐNG DỊCH COVID-19 

Cập nhật tình hình quyên góp hỗ trợ phòng chống dịch COVID
1. Nhóm từ thiện " Chia sẻ - Sharing của Bà Mai Thị Hạnh , Phu Nhân Nguyên Chủ Tịch Nước Trương Tấn Sang " : hiện nay được trên 660.000.000đ.
2. Quỹ Từ tâm: 200.000.000đ
3. Công ty đầu tư Đất Trí: 100.000.000đ
4. Nhóm bạn hữu của BS Võ Đức Chiến - BV Nguyễn Tri Phương, người thân và VOV đang tiếp tục tiến hành quyên góp: hiện đang hơn 50.000.000 đ.
5. Các mạnh thường quân chuyển khoản trực tiếp: 51.150.000đ
**Như vậy tổng số tiền quyên góp đã được trên 1tỷ đồng**
Hiện nay các khoản tài trợ sẽ được cập nhật thêm và rất mong tiếp tục nhận được những tấm lòng chia sẻ
Mọi hỗ trợ xin gởi vào tài khoản:
  * Tên chủ tài khoản: BỆNH VIỆN NGUYỄN TRI PHƯƠNG.
  * Số tài khoản: 0251002787729
  * Ngân hàng: Vietcombank ( VCB ) - CN Bình Tây.
  * Nội dung chuyển khoản: Ho tro chong COVID Da Nang Quang Nam


(Trong trường hợp muốn thực hiện chuyển khoản qua ví điện tử như Momo, Zalopay, Viettelpay... xin vui lòng nhắn tin cho page "Bệnh viện Nguyễn Tri Phương [tại đây](http://facebook.com/BVNTP) để chúng tôi có thể hướng dẫn và thực hiện đối soát cần thiết)
Kế hoạch sử dụng: Hỗ trợ áo quần phòng mổ và phòng hộ phòng chống NCovid-19 cho bệnh viện Đà Nẵng và Quảng Nam.
Chân thành cám ơn đến từng tấm lòng! Bác sĩ Võ Đức Chiến - Chủ tịch hội chữ thập đỏ Bv. Nguyễn Tri Phương

[[[PLACEHOLDER_HEADING]]]# TRI ÂN NHỮNG TẤM LÒNG CÙNG HƯỚNG VỀ ĐÀ NẴNG, QUẢNG NAM

Dưới đây chúng tôi xin đưa liệt kê những khoản quyên góp mà BV đã nhận được thông qua Nhóm từ thiện "Chia sẻ - Sharing của Bà Mai Thị Hạnh , Phu Nhân Nguyên Chủ Tịch Nước Trương Tấn Sang"
Xin trân trọng biết ơn từng sự đóng góp quý báu!

[[[PLACEHOLDER_HEADING]]]# CẬP NHẬT TÌNH HÌNH QUYÊN GÓP PHÒNG CHỐNG DỊCH COVID-19

Cập nhật tình hình quyên góp hỗ trợ phòng chống dịch COVID
1. Nhóm từ thiện " Chia sẻ - Sharing của Bà Mai Thị Hạnh , Phu Nhân Nguyên Chủ Tịch Nước Trương Tấn Sang " : hiện nay được trên 300.000.000đ.
2. Quỹ Từ tâm: 200.000.000đ
3. Công ty đầu tư Đất Trí: 100.000.000đ
4. Nhóm bạn hữu của BS Võ Đức Chiến - BV Nguyễn Tri Phương, người thân và VOV đang tiếp tục tiến hành quyên góp: hiện đang hơn 50.000.000 đ.
Hiện nay các khoản tài trợ sẽ được cập nhật thêm và rất mong tiếp tục nhận được những tấm lòng chia sẻ
Mọi hỗ trợ xin gởi vào tài khoản:
  * Tên chủ tài khoản: BỆNH VIỆN NGUYỄN TRI PHƯƠNG.
  * Số tài khoản: 0251002787729
  * Ngân hàng: Vietcombank ( VCB ) - CN Bình Tây.
  * Nội dung chuyển khoản: Ho tro chong COVID Da Nang Quang Nam


(Trong trường hợp muốn thực hiện chuyển khoản qua ví điện tử như Momo, Zalopay, Viettelpay... xin vui lòng nhắn tin cho page "Bệnh viện Nguyễn Tri Phương [tại đây](http://facebook.com/BVNTP) để chúng tôi có thể hướng dẫn và thực hiện đối soát cần thiết)
Kế hoạch sử dụng: Hỗ trợ áo quần phòng mổ và phòng hộ phòng chống NCovid-19 cho bệnh viện Đà Nẵng và Quảng Nam.
Chân thành cám ơn đến từng tấm lòng!
Bác sĩ Võ Đức Chiến - Chủ tịch hội chữ thập đỏ Bv. Nguyễn Tri Phương

[[[PLACEHOLDER_HEADING]]]# Buổi lễ trao Quyết định bổ nhiệm Phó Giám đốc Bệnh viện Nguyễn Tri Phương (hạng I) trực thuộc Sở Y tế

Phát biểu tại Hội nghị BS.CKII. Nguyễn Hoài Nam, mong muốn tân Phó Giám đốc - Bệnh viện Nguyễn Tri Phương phối hợp cùng Ban Giám đốc và tập thể viên chức, người lao động của Bệnh viện Nguyễn Tri Phương; lãnh đạo, chỉ đạo hoạt động của Bệnh viện để hoàn thành tốt nhiệm vụ do Đảng ủy, Ban Giám đốc Sở Y tế và cấp trên giao.
Nhận nhiệm vụ mới, TS.BS Lê Cao Phương Duy sẽ cố gắng và mong muốn nhận được hỗ trợ của lãnh đạo Sở Y tế, cũng như sự ủng hộ của Đảng ủy, Ban Giám đốc và tập thể Bệnh viện để bản thân tiếp tục phấn đấu và hoàn thành tốt nhiệm vụ.

[[[PLACEHOLDER_HEADING]]]# KẾ HOẠCH HỖ TRỢ CÁC BỆNH VIỆN TẠI ĐÀ NẴNG – QUẢNG NAM PHÒNG CHỐNG DỊCH COVID-19

Bằng nhiều kênh vận động, sự ủng hộ của các nhà tài trợ đã lần lượt được gửi đến Hội Chữ Thập Đỏ bệnh viện, cho đến thời điểm hiện tại (ngày 12/08/2020), số tiền quyên góp đã lên đến hơn 1 tỷ đồng. Chủ tịch Hội Chữ Thập Đỏ bệnh viện Nguyễn Tri Phương – BS CKII Võ Đức Chiến xin chân thành gửi lời cảm ơn đến tất cả các nhà quyên góp đã cùng nhau chung tay, góp sức để chống lại dịch bệnh.
Với số tiền quyên góp to lớn như vậy, Hội Chữ Thập Đỏ bệnh viện đã cùng nhau lên kế hoạch hỗ trợ các bệnh viện tại Đà Nẵng và Quảng Nam như sau:
**Tổng số tiền quyên góp hiện tại: 1.143.450.000 đồng.**
**_1. Bộ quần áo phòng dịch đã tiệt trùng:_**
Dự tính sẽ mua sắm được 8000 bộ quần áo phòng dịch với số tiền quyên góp: 940.950.000 đồng.
**_2. Bộ đồ vải lót mổ đã tiệt trùng:_**
Dự tính sẽ mua sắm được 1000 bộ đồ vải lót mổ với số tiền quyên góp: 202.500.000 đồng.
**_3. Những bộ đồ bảo hộ sẽ được chuyển đến các bệnh viện:_**
  * **Bệnh viện C Đà Nẵng:** 1580 bộ quần áo phòng dịch, 200 bộ đồ vải lót mổ.
  * **Bệnh viện Đà Nẵng:** 1580 bộ quần áo phòng dịch, 200 bộ đồ vải lót mổ.
  * **Bệnh viện Hòa Vang:** 1610 bộ quần áo phòng dịch, 200 bộ đồ vải lót mổ.
  * **Bệnh viện Phổi Đà Nẵng:** 1610 bộ quần áo phòng dịch, 200 bộ đồ vải lót mổ.
  * **Bệnh viện Đa khoa Trung ương Quảng Nam:** 1620 bộ quần áo phòng dịch, 200 bộ đồ vải lót mổ.


Việc quyên góp ủng hộ đang ngày càng được phổ biến rộng rãi nên số tiền hỗ trợ cũng tăng dần lên sau đó, Hội Chữ Thập Đỏ bệnh viện xin cố gắng hết sức mình để đưa những món đồ bảo hộ được gửi đến sớm nhất cho những chiến sĩ đang chiến đấu với dịch bệnh tại các bệnh viện ở Đà Nẵng và Quảng Nam.
Trên đây chỉ là kế hoạch được bệnh viện dựng nên dựa trên mức hỗ trợ được tính đến thời điểm hiện tại (ngày 12/08/2020), với mong muốn có thể đóng góp nhiều hơn nữa giúp đất nước ta nhanh chóng chiến thắng bệnh dịch, chúng tôi xin lan tỏa lời kêu gọi cùng chung tay của tất cả tấm lòng trong xã hội!
Mọi hỗ trợ xin gởi vào tài khoản sau đây: 
  * _Tên chủ tài khoản_ : **BỆNH VIỆN NGUYỄN TRI PHƯƠNG.**
  * S _ố tài khoản:_ **0251002787729**
  * _Ngân hàng:_ **Vietcombank ( VCB ) - CN Bình Tây**.
  * _Nội dung chuyển khoản:_ **Ho tro chong COVID Da Nang Quang Nam**


_(Trong trường hợp muốn thực hiện chuyển khoản qua ví điện tử như Momo, Zalopay, Viettelpay... xin vui lòng nhắn tin cho[fanpage](https://www.facebook.com/BVNTP) để chúng tôi có thể hướng dẫn và thực hiện đối soát cần thiết)._
Xin trân trọng biết ơn từng sự đóng góp quý báu!

[[[PLACEHOLDER_HEADING]]]# TIẾP LỬA CHO VÙNG TÂM DỊCH

Hội Chữ thập đỏ bệnh viện Nguyễn Tri Phương đang vận động nguồn kinh phí để hỗ trợ cho các bệnh viện tại Đà Nẵng và Quảng Nam trong những hoạt động chống dịch COVID-19
Bằng nhiều kênh vận động - hiện tại chúng tôi đã huy động được hơn 350.000.000đ (Ba trăm năm mươi triệu đồng). Tuy nhiên, với mong muốn có thể đóng góp nhiều hơn nữa giúp nhanh chóng chiến thắng bệnh dịch, chúng tôi xin lan tỏa lời kêu gọi cùng chung tay của tất cả tấm lòng trong xã hội!
Mọi hỗ trợ xin gởi vào tài khoản sau đây: Tên chủ tài khoản: BỆNH VIỆN NGUYỄN TRI PHƯƠNG. Số tài khoản: 0251002787729 Ngân hàng: Vietcombank ( VCB ) - CN Bình Tây. Nội dung chuyển khoản: Ho tro chong COVID Da Nang Quang Nam
(Trong trường hợp muốn thực hiện chuyển khoản qua ví điện tử như Momo, Zalopay, Viettelpay... xin vui lòng nhắn tin cho page "Bệnh viện Nguyễn Tri Phương" [tại đây](https://www.facebook.com/BVNTP/) để chúng tôi có thể hướng dẫn và thực hiện đối soát cần thiết)
Kế hoạch sử dụng: Hỗ trợ áo quần phòng mổ và phòng hộ phòng chống NCovid-19 cho bệnh viện Đà Nẵng và Quảng Nam.
Chân thành cám ơn đến từng tấm lòng! Bác sĩ Võ Đức Chiến - Chủ tịch hội chữ thập đỏ Bv. Nguyễn Tri Phương

[[[PLACEHOLDER_HEADING]]]# KHAI TRƯƠNG GIAN HÀNG YÊU THƯƠNG

21/9/2020 gian hàng " Chia sẽ yêu thương" của bệnh viện Nguyễn Tri Phương chính thức được khai trương, đặt bên cạnh phòng Công tác xã hội (khối nhà A, ở sân).
Các mặt hàng đa phần còn rất mới, thậm chí có nhiều đồ mới hoàn toàn nhưng lại được bán với giá cực kì nhẹ nhàng 10-20-50k cho những ai có nhu cầu. Phương châm hoạt động của gian hàng " người có cho đi, người cần đến chọn", và tất cả kinh phí thu được đều đưa vào quỹ hỗ trợ bệnh nhân khó khăn.
Bệnh viện xin cám ơn sự chia sẻ, quyên góp của các mạnh thường quân, của các cô chú, anh chị em, các bạn bè đã ủng hộ chương trình và đã có những đóng góp thầm lặng cho gian hàng của yêu thương.
Gian hàng không phải chỉ tổ chức vài ngày mà sẽ luôn diễn ra mỗi ngày ở cả hai khâu thu nhận đồ quyên góp, cũng như bán lại các sản phẩm quyên góp để gây quỹ. Rất mong gian hàng sẽ tiếp tục nhận được sự ủng hộ, chia sẻ với tinh thần cho đi khi dư thừa và xin hãy mua lại những thứ khi cần thiết.
Về mạnh thường quân, có sự tham gia của:
  * Ông Lê văn Khoa – Nguyên PCT UBND TP.HCM; đại diện quỹ Từ Tâm
  * Nhóm từ thiện CHIA SẺ SHARING của Bà Mai Thị Hạnh – Phu nhân Nguyên CT Nước Trương Tấn Sang và ACE của nhóm tham dự.
  * QUỸ TÂM NGUYỆN VIỆT với tham dự: 
    * Bà Hồ Thị Mộng Thu – PGĐ thường trực quỹ.
    * Bà Phan Thị Ngọc Khương – Điều phối viên quỹ.
  * CLB Tình Người MIFACO Tp. Hồ Chí Minh, đại diện: bà Hà Thị Đoan Trang 
  * VOV TP. HỒ CHÍ MINH: Nhà báo Nguyễn Ca – GĐ kênh sức khỏe an toàn thực phẩm – Đài tiếng nói VN tại TP. HCM.
  * Ông Yung Cam Meng –CT Hội Đồng Quản Trị Công Ty Cp Siêu Thanh
  * Bà Hà Muối 
  * Bà Lê Mỹ Hạnh 
  * Ông Phan Thanh Phong – Giám Đốc Cty An Thịnh Phát
  * Sư Huệ Tuyến, chùa Vĩnh Nghiêm
  * Ông Nguyễn Hồng Nam


Về khách mời và đại biểu, có sự tham gia của:
  * Hội Chữ Thập Đỏ Thành phố Hồ Chí Minh: Đồng chí Trần Trường Sơn – Chủ tịch
  * Đồng chí Quách Thị Liêm Hai – Ban dân vận Thành ủy 
  * Đồng chí Trần Văn Xồi - Phó bí thư Đảng ủy Sở Y Tế.


Ngoài ra có sự tham gia của nhiều báo đài và các đại diện của các Bệnh viện bạn

[[[PLACEHOLDER_HEADING]]]# BÃI GIỮ XE MÁY THÔNG MINH ĐƯA VÀO HOẠT ĐỘNG

Bệnh viện Nguyễn Tri Phương đã cho cải tạo nâng cấp nhà để xe hai bánh gồm 3 tầng: Tầng trệt, tầng 1 và tầng 2.
Tổng diện tích 3 tầng rộng 1.950 m2 ước tính chứa được 2.700 chiếc xe gắn máy.
Bãi giữ xe thông minh bằng công nghệ thẻ từ là một trong những giải pháp bãi đỗ xe cơ bản, toàn diện tại Bệnh viện Nguyễn Tri Phương. Hệ thống đã được ứng dụng ở hầu hết các bãi đỗ xe khác nhau trong bệnh viện, mang lại hiệu quả cao cho quản lý ra vào tại bãi đỗ xe.
Hệ thống quản lý bãi gửi xe thông minh tại bệnh viện sử dụng công nghệ kiểm soát ra vào bằng thẻ từ dành cho hệ thống phương tiện xe máy sử dụng các thiết bị công nghệ thay thế sức con người. Mang đến sự nhanh gọn và chính xác trong quản lý an ninh bãi xe.
Hiện tất cả các vị trí giữ xe cho bệnh nhân bên ngoài bệnh viện đều được tập trung gửi tại bãi xe mới của bệnh viện.
Quý bệnh nhân, thân nhân bệnh nhân đến thăm, khám tại Bệnh viện Nguyễn Tri Phương xin vui lòng gửi xe tại vị trí lối ra vào bãi xe của bệnh viện nằm tại khu E trên trục đường Nguyễn Tri Phương cạnh phòng xét nghiệm theo yêu cầu của bệnh viện (gần ngã 4 Nguyễn Tri Phương – An Dương Vương).

[[[PLACEHOLDER_HEADING]]]# BOEHRINGER INGELHEIM ĐỒNG HÀNH CHỐNG DỊCH

Công ty đã trao tặng cho bệnh viện
  * 100 bộ đồ phòng hộ
  * 30 nhiệt kế hồng ngoại
  * 500 khẩu trang y tế



[[[PLACEHOLDER_HEADING]]]# CÁCH CÀI ĐẶT VÀ SỬ DỤNG ỨNG DỤNG KHAI BÁO SỨC KHỎE TOÀN DÂN

Bộ Thông tin và Truyền thông phối hợp với Bộ Y tế vừa ra mắt ứng dụng hỗ trợ **phòng chống dịch COVID-19**. Với ứng dụng này, người dân có thể tự khai báo y tế tại nhà bằng điện thoại và máy tính bảng thông minh. Hai ứng dụng được Bộ TT&TT và Bộ Y tế phối hợp ra mắt gồm: **NCOVI** dành cho người dân Việt Nam và **Vietnam Health Declaration** dành cho người nhập cảnh vào Việt Nam.
Ứng dụng cho phép người dùng khai báo thông tin sức khỏe hiện tại để có thể được hỗ trợ nhanh nhất từ cơ quan y tế. Người dùng được cập nhật thời gian thực tình trạng dịch bệnh khu vực xung quanh mình sinh sống hoặc những khu vực đang có dịch để chủ động tránh những địa điểm không an toàn. Ngoài ra, người dân có thể xem các thống kê, thông tin về dịch bệnh được cập nhật liên tục, các hướng dẫn cách phòng trách bệnh dịch hiệu quả và an toàn từ các chuyên gia y tế. 
Hiện ứng dụng (app) chính thức trợ giúp người dân theo dõi sức khỏe đã có trên Google Play. Còn trên AppStore thì đang chờ Apple phê duyệt.
Phó Thủ tướng Vũ Đức Đam nhấn mạnh, với ứng dụng này, thông tin người dân cung cấp được Nhà nước quản lý chặt chẽ và chỉ được sử dụng để chống dịch, tuyệt đối không sử dụng vào các mục đích thương mại, không xâm phạm đời tư của người dân.
Để cài đặt, người dân click vào [đường dẫn tải](https://play.google.com/store/apps/details?id=com.vnptit.innovation.ncovi&fbclid=IwAR3wVhcIfVAP6nsaUS90jclq0LZ-DeeYCtvwmNl50tooQiM80mOBZ4StotM "đường dẫn tải") ứng dụng trợ giúp theo dõi sức khoẻ [ở đây](https://play.google.com/store/apps/details?id=com.vnptit.innovation.ncovi&fbclid=IwAR3wVhcIfVAP6nsaUS90jclq0LZ-DeeYCtvwmNl50tooQiM80mOBZ4StotM "ở đây").
Thứ trưởng Bộ Y tế Nguyễn Thanh Long cho biết ứng dụng này sẽ giúp ngành y tế phản ứng nhanh hơn với các thông tin do người dân cung cấp. Đây là sự hỗ trợ quan trọng cho ngành y tế trong phòng, chống dịch bệnh COVID-19

[[[PLACEHOLDER_HEADING]]]# BV NGUYỄN TRI PHƯƠNG ĐƯỢC GIÁM SÁT VỀ THỬ NGHIỆM LÂM SÀNG

Tiếp theo công văn số 513/K2ĐT-KHCN ngày 04/06/2020 của Cục Khoa học công nghệ và Đào tạo, thực hiện ý kiến chỉ đạo của Lãnh đạo Bộ về việc kiểm tra các nghiên cứu phát triển sản phẩm (thuốc hóa dược, vắc xin, trang thiết bị và kỹ thuật, phương pháp mới) theo đúng các quy định hiện hành về Đạo đức trong nghiên cứu y sinh học và Thực hành lâm sàng tốt (GCP), Cục Khoa học công nghệ và Đào tạo (Cục HCN&ĐT) có kế hoạch kiểm tra, giám sát hoạt động nghiên cứu y sinh học tại các cơ sở nghiên cứu theo các nội dung sau:
1. Rà soát, đánh giá cơ sở vật chất, trang thiết bị, nguồn lực tiến hành nghiên cứu thử nghiệm lâm sàng theo quy định tại Thông tư 29/2018/TT-BYT và Thông tư 55/2015/TT-BYT và hoạt động của Hội đồng đạo đức cấp cơ sở theo quy định tại Thông tư 04/2020/TT-BYT 2. Rà soát, đánh giá hồ sơ, đề cương, CRF, ICF, việc ghi nhận, xử trí và báo cáo trường hợp AE, SAE, các quy trình nghiên cứu (SOP), hồ sơ tài liệu nguồn, các thay đổi bổ sung và dự kiến các hoạt động trong thời gian tới của các nghiên cứu y sinh học đang triển khai tại cơ sở, hệ thống và quy trình báo cáo biến cố bất lợi, quản lý nguy cơ trong thử lâm sàng tại cơ sở. 3. Chỉ đạo, rà soát các hoạt động nghiên cứu nhằm đảm bảo tính an toàn, khoa học và tuân thủ theo GCP.

[[[PLACEHOLDER_HEADING]]]# HOẠT ĐỘNG TẦM SOÁT TĂNG TRƯỞNG CHO TRẺ EM 

Hoạt động sẽ có kênh đăng ký riêng dành riêng như thông tin đính kèm
Những nội dung chi tiết về hoạt động chúng tôi sẽ đưa tin trong thời gian sớm nhất./.

[[[PLACEHOLDER_HEADING]]]# PHÓNG SỰ ĐÁNH GIÁ PHÒNG CHỐNG DỊCH COVID-19


[[[PLACEHOLDER_HEADING]]]# Lễ bế giảng lớp Trung cấp lý luận chính trị - Hành chính hình thức vừa làm vừa học (niên khóa 2018-2020)

Đến dự buổi Lễ bế giảng có đồng chí Võ Đức Chiến, Bí thư Đảng ủy, Giám đốc Bệnh viện Nguyễn Tri Ph ương, đồng chí Nguyễn Tấn Phát, Bí thư Đảng ủy, Giám đốc Học viện Cán bộ Thành phố Hồ Chí Minh, Trưởng phó các khoa, phòng thuộc Bệnh viện Nguyễn Tri Phương và Học viện cán bộ Thành phố Hồ Chí Minh, cùng 76 học viên là cán bộ, viên chức, người lao động Bệnh viện Nguyễn Tri Phương.
Báo cáo tổng kết lớp học đã nêu rõ mục đích của khóa học nhằm nâng cao trình độ lý luận chính trị và kỹ năng thực thi công việc. Trong quá trình học tập, các học viên được trang bị và giới thiệu đầy đủ các nội dung chương trình theo yêu cầu đặt ra. Sau khóa học, các học viên được nâng cao bản lĩnh chính trị và trình độ chuyên môn, áp dụng được những kiến thức tiếp thu được vào thực tiễn công việc, tạo bước thay đổi căn bản về chất, từng bước nâng cao năng lực công tác, tinh thần, thái độ phục vụ, đảm bảo chỉ số hài lòng của nhân dân, góp phần nâng cao chất lượng nguồn nhân lực tại Bệnh viện nói riêng và của ngành y tế thành phố nói chung.
Phát biểu tại buổi Lễ bế giảng, đồng chí Võ Đức Chiến, Bí thư Đảng ủy, Giám đốc Bệnh viện Nguyễn Tri Phương chúc mừng và đánh giá cao sự nỗ lực rèn luyện, phấn đấu của cán bộ, viên chức, người lao động của Bệnh viện để có kết quả tốt đẹp trong điều kiện vừa phải hoàn thành công việc, vừa tham gia học tập. Bên cạnh đó, đồng chí cũng kỳ vọng và nhắn nhủ với đội ngũ cán bộ, viên chức, người lao động tiếp tục cống hiến công sức cho Bệnh viện để phục vụ tốt cho người bệnh theo đúng chủ đề của Bệnh viện “Năng động - Thân thiệt - Phát triển”. Đồng thời, đồng chí cũng cảm ơn Học viện Cán bộ Thành phố Hồ Chí Minh đã phối hợp và tổ chức thành công lớp Trung cấp lý luận chính trị - Hành chính.
Đưa tin: **Nguyễn Thị Ngọc Mai**

[[[PLACEHOLDER_HEADING]]]# BỆNH VIỆN NGUYỄN TRI PHƯƠNG VINH DANH CÁC GIẢI THƯỞNG QUỐC TẾ

Khoa Chấn thương Chỉnh hình của Bệnh viện Nguyễn Tri Phương được công nhận là Trung tâm Xuất sắc (ICE) của kỹ thuật mổ thay khớp háng superpath và thay khớp gối với kỹ thuật medical pivot theo chuẩn Mỹ. Hai kỹ thuật này đã được Tổ chức Micropot – một trong những tổ chức y khoa thế giới với các chuyên gia hàng đầu của Mỹ chuyên về khớp, đánh giá chất lượng phục hồi bệnh nhân sau khi mổ tốt nhất và xuất sắc. 
Khoa Nội Thần kinh đã triển khai Mô hình chăm sóc đột quỵ - Đơn vị Đột quy (Stroke Unit) trong điều trị đột quỵ giai đoạn cấp cũng như xây dựng quy trình chuẩn trong điều trị tái thông cho bệnh nhân đột quỵ hay nhồi máu não cấp… Cần nhấn mạnh đây là yếu tố quyết định chất lượng điều trị, giảm tỷ lệ tử vong và tàn phế, nâng cao chất lượng sống cho bệnh nhân sau hồi phục. 
BS. CKII Võ Đức Chiến, Giám đốc Bệnh viện Nguyễn Tri Phương, cho biết thêm, với chứng nhận Internation Center of Excellence, bệnh viện sẽ được chọn là nơi giảng dạy thay khớp háng và khớp gối với 2 kỹ thuật trên cho khu vực Đông Nam Á và châu Á. Đặc biệt các bác sĩ khoa Chấn thương Chỉnh hình của bệnh viện sẽ được chọn làm giảng viên và mổ biểu diễn cho các học viên trong lớp học quốc tế. Các kỹ thuật theo tiêu chuẩn quốc tế là mục tiêu hướng đến của tất cả các bệnh viện trong nước, nhằm giúp bệnh nhân trong nước tiếp cận được với các phương pháp điều trị hiện đại, hiệu quả, tiết kiệm chi phí và thời gian đi lại, cũng như được chăm sóc, tái khám thuận tiện sau phẫu thuật, hướng tới nâng cao chất lượng điều trị trong khám chữa bệnh, cải thiện chất lượng sống tốt cho bệnh nhân. Bên cạnh đó, việc được vinh danh về chất lượng điều trị Đột quỵ đang thể hiện sự phát triển đáng mừng của y hiệu Bệnh viện Nguyễn Tri Phương - "Năng động - Thân thiện - Phát triển".

[[[PLACEHOLDER_HEADING]]]# ĐẢNG BỘ BV NGUYỄN TRI PHƯƠNG THỰC HIỆN SƠ KẾT 6 THÁNG ĐẦU NĂM 2020

Thực hiện chương trình kế hoạch công tác năm 2020, và chỉ đạo của Đảng uỷ bệnh viện về việc tổ chức hội nghị sơ kết công tác Đảng 6 tháng đầu năm, xây dựng phương hướng nhiệm vụ 6 tháng cuối năm 2020. Đánh giá kết quả đã đạt được trên những mặt công tác cũng như chỉ ra những tồn tại, hạn chế và giải pháp khắc phục, từ đó xây dựng phương hướng nhiệm vụ công tác 6 tháng cuối năm 2020
Cuộc họp ghi nhận sự tham gia đầy đủ và nghiêm túc của tất cả các Đảng viên trong Đảng bộ Bệnh viện. Chương trình hội nghị bao gồm:
  1. Đón tiếp đại biểu
  2. Chào cờ, tuyên bố lý do giới thiệu đại biểu.
  3. Báo cáo sơ kết công tác xây dựng Đảng 6 tháng đầu năm và phương hướng nhiệm vụ 6 tháng cuối năm 2020.
  4. Báo cáo công tác kiểm tra Đảng 6 tháng đầu năm và phương hướng nhiệm vụ 6 tháng cuối năm 2020. (đồng chí Nguyễn Trung Thành – Phó Bí thư Đảng ủy)
  5. Tổng hợp ý kiến góp ý của 11 chi bộ. Hội nghị thảo luận lấy ý kiến góp ý các văn kiện Đại hội XIII của Đảng và dự thảo Báo cáo chính trị Đại hội XI Đảng bộ thành phố Hồ Chí Minh.
  6. Ý kiến đóng góp của đảng viên.
  7. Phát biểu của lãnh đạo cấp trên.
  8. Biểu quyết thông qua báo cáo sơ kết công tác Đảng 6 tháng đầu năm và phương hướng, nhiệm vụ của 6 tháng cuối năm 2020.
  9. Biểu quyết thông qua báo cáo, ý kiến góp ý các văn kiện Đại hội XIII của Đảng và dự thảo Báo cáo chính trị Đại hội XI Đảng bộ thành phố Hồ Chí Minh.
  10. Bế mạc (chào cờ)



[[[PLACEHOLDER_HEADING]]]# ĐẢNG ỦY BV NGUYỄN TRI PHƯƠNG ĐƯỢC KIỂM TRA GIÁM SÁT VỀ THỰC HIỆN CT05

Đại diện phía Đảng ủy Sở Y tế tp.HCM gồm có:
- Đồng chí Phạm Kiều Hưng
- Đồng chí Bùi Văn Tùng
- Đồng chí Nguyễn Trung Dân
- Đồng chí Nguyễn Trần Tú Khanh
- Đồng chí Lại Phước Thanh Huy
Về phía BV Nguyễn Tri Phương có đầy đủ 07 đồng chí trong cấp ủy tham gia tiếp đoàn cũng như đại diện những tấm gương tiêu biểu đã được khen thưởng về vấn đề làm theo lời Bác năm 2019.
Cuộc kiểm tra trong tinh thần cởi mở, nghiêm túc đã nhìn nhận những vấn đề còn tồn tại trong hồ sơ - kế hoạch và những điều rút kinh nghiệm trong thời gian sắp đến./.

[[[PLACEHOLDER_HEADING]]]# Bệnh viện Nguyễn Tri Phương dùng máy quét có thể đo nhiệt độ từ xa trong công tác phòng chống dịch COVID-19

**_Giới thiệu ứng dụng :_**
  * Quản lý vào ra qua nhận diện khuôn mặt Face-RS với chức năng cảnh báo thân nhiệt.
  * Sự kết hợp của camera nhiệt và hệ thống nhận diện khuôn mặt Face-RS nhằm sàng lọc sốt thông qua hình ảnh nhiệt.
  * Thiết bị được sử dụng như một bước sàng lọc hàng loạt cấp độ đầu tiên. Để xác định chính xác những người có nhiệt độ cơ thể quá mức bình thườn. Hệ thống đo nhiệt độ từ xa không tiếp xúc trong khoảng cách từ 2m – 5m sai số cực nhỏ 0,1~0.3℃.
  * Nhận diện khuôn mặt thông minh và thông báo nhiệt độ cơ thể người theo ngưỡng thiết lập báo động.
  * Kiểm tra lịch sử dữ liệu. Truy xuất người ra vào dựa trên báo cáo sự kiện theo điều kiện tìm kiếm được thiết lập, đưa ra các hình thức báo cáo, kiểm soát vào ra, tìm kiếm dữ liệu thông qua thời gian thực.


**_Đánh giá hiệu quả ứng dụng_**
  1. Giải quyết áp lực công việc cho nhân viên y tế và đẩy nhanh luồng người di chuyển. Kiểm tra thân nhiệt cùng lúc được nhiều người.
  2. Giao diện tiếp xúc khách thân thiện (không trực tiếp lấy thân nhiệt từng người ), khách sẽ dễ chịu vì hoàn toàn không trực diện với nhân viên y tế lấy thân nhiệt như phương pháp thủ công.
  3. Hạn chế việc tiếp xúc gần nhưng đảm bảo tính chính xác cao, đo được thân nhiệt nhiều người trong khu vực
  4. Có thể trích xuất dữ liệu từ hệ thống có cả hình ảnh gương mặt và thời gian thực hiện đo thân nhiệt, cũng góp phần cho công tác an ninh khi cần thiết truy xuất. Dễ dàng có hệ thống cho nhà quản lý giúp phòng chống dịch hiệu quả
  5. Hệ thống có giao diện hoàn toàn bằng tiếng việt, thân thiện, dễ sử dụng cho nhân viên bảo vệ nên dễ dàng tập huấn, triển khai



[[[PLACEHOLDER_HEADING]]]# SỞ Y TẾ ĐÁNH GIÁ TỐT VỀ HỆ THỐNG KIOS KHAI BÁO Y TẾ TẠI BV NGUYỄN TRI PHƯƠNG

<https://vnexpress.net/benh-vien-tp-hcm-dung-ki-ot-khai-bao-y-te-4080231.html?fbclid=IwAR3qOyTQhXgkrn1Ji7fsvHfARVTrVze_dDf4NRs-paZb6oJd5YqnmiimP70>
"Triển khai ứng dụng công nghệ thông tin để khai báo y tế thay thế cho khai báo thủ công trên giấy tại BV Nguyễn Tri Phương đáng được ghi nhận và giới thiệu nhân rộng vì tính tiện ích và hiệu quả của nó cho cả người khai báo và người quản lý công tác khai báo." - SYT Tp.HCM
[https://tuoitre.vn/ki-ot-khai-bao-y-te-giup-truy-tim-dau-vet-nguoi-nghi-nhiem-covid-19-trong-benh-vien-20200405163223839.htm](https://tuoitre.vn/ki-ot-khai-bao-y-te-giup-truy-tim-dau-vet-nguoi-nghi-nhiem-covid-19-trong-benh-vien-20200405163223839.htm?fbclid=IwAR38XVeRZm1Qsa6LlRifiM9JI7loB_c6zr7Pv9Y28yd-cIsFGrms5Ugei2I)
"Người khai báo dễ dàng sử dụng bàn phím ảo trên màn hình để khai báo; đội bảo vệ và phòng công tác xã hội dễ dàng nhận được tín hiệu báo động khi kiôt phát hiện trường hợp nghi ngờ để kịp thời hướng dẫn người vừa khai báo đến phòng khám sàng lọc; phòng kế hoạch tổng hợp dễ dàng thống kê, báo cáo tình hình người đến bệnh viện có khai báo y tế, kết quả khai báo..."- Tuổi trẻ đánh giá
<https://voh.com.vn/tin-tp-ho-chi-minh/trien-khai-phan-mem-khai-bao-y-te-tai-benh-vien-nguyen-tri-phuong-359703.html?fbclid=IwAR1QbYw_OODV8T5fnqCA3BdkAtjTHI8bAGCbbtdOjdC9skK3EBYoTB8tFNk>
"Việc kiểm soát bằng các tờ khai y tế bằng giấy sẽ bị quá tải và nhiều hạn chế khác nhưng công nghệ kỹ thuật số này có thể thực hiện theo dõi các mối liên hệ chặt chẽ với người nghi nhiễm hoặc nhiễm COVID-19 nếu đến bệnh viện. Như vậy, việc truy tìm dấu vết để xác định ổ dịch sẽ rất thuận lợi và giúp cho việc dập dịch hiệu quả hơn."-VOH đánh giá

[[[PLACEHOLDER_HEADING]]]# HOẠT ĐỘNG KHÁM TẠI NHÀ - TRONG THỜI GIAN CÁCH LY PHÒNG CHỐNG DỊCH COVID-19

Theo hướng dẫn 1946/SYT-NVY của Sở Y tế thành phố Hồ Chí Minh  Tham khảo công văn 687/BHXH-GĐ1 của BHXH thành phố Hồ Chí Minh Đối với đối tượng không có thẻ BHYT: BV sẽ tổ chức khám - phát thuốc tại nhà cho những người >=60 tuổi theo cơ chế hoạt động dịch vụ. Khuyến khích người nhà nhận thuốc thay cho bệnh nhân (người nhận cần có chứng minh nhân dân của người bệnh, chứng minh nhân dân của bản thân và toa thuốc của BS kê) hoặc có thể tự mua tại các nhà thuốc đạt chuẩn. Nếu cần lấy máu xét nghiệm: BS khám sẽ cho chỉ định và BV sẽ thực hiện lấy máu tại nhà theo cơ chế hoạt động dịch vụ. Đối với đối tượng có thẻ BHYT: Bệnh nhân >=60 và <80: tổ chức khám - phát thuốc tại nhà theo cơ chế hoạt động dịch vụ. Thuốc được nhận là thuốc BHYT. Khuyến khích người nhà nhận thuốc thay cho bệnh nhân (người nhận cần có chứng minh nhân dân của người bệnh, BHYT của người bệnh và chứng minh nhân dân của bản thân khi đến nhận thuốc). Nếu cần lấy máu xét nghiệm: BS cho chỉ định và BV sẽ thực hiện lấy máu tại nhà theo cơ chế hoạt động dịch vụ. Đối với đối tượng có thẻ BHYT: Bệnh nhân >=80: tổ chức khám - phát thuốc tại nhà, theo các chính sách của người bệnh có BHYT. Mở và đóng hồ sơ như 01 lần khám BHYT bình thường. Nếu cần xét nghiệm: thực hiện xét nghiệm tại theo các chính sách của người bệnh có BHYT.
Vì lượng bệnh đông, nên chúng tôi sẽ ưu tiên tư vấn qua điện thoại trong trường hợp cần thiết và hỗ trợ cấp phát thuốc tại nhà, rất mong quý bệnh nhân thông cảm và chia sẻ với những bất tiện này để phòng chống dịch bệnh được hiệu quả nhất.
Xin vui lòng liên hệ số điện thoại tổng đài của BV để được hướng dẫn, hỗ trợ (02873077307 - 02839234349)

[[[PLACEHOLDER_HEADING]]]# KỶ NIỆM 90 NĂM THÀNH LẬP ĐẢNG CỘNG SẢN VIỆT NAM

Trong buổi lễ, Đảng ủy bệnh viện đã nhận danh sách đoàn viên ưu tú từ Ban chấp hành Công Đoàn và Đoàn thanh niên Bệnh viện
Đồng thời buổi lễ đã chứng kiến việc khen thưởng các chi bộ trong sạch và các đồng chí Đảng viên xuất sắc trong năm 2019

[[[PLACEHOLDER_HEADING]]]# Hướng dẫn phòng và kiểm soát lây nhiễm dịch Corona

Vui lòng xem toàn văn bản [tại đây](https://drive.google.com/open?id=1WLncEj_tE1yDp4ChlwcStOYpdfPNwmmR)./.

[[[PLACEHOLDER_HEADING]]]# “Hỏi - đáp về chủng virus Corona mới 2019”

Tài liệu được dịch và tổng hợp dựa trên tài liệu của: - Tổ chức Y tế Thế giới (WHO) - Trung tâm Kiểm soát và Phòng ngừa Dịch bệnh Hoa Kỳ (CDC) - Trung tâm Kiểm soát và Phòng ngừa Dịch bệnh châu Âu (ECDC) -------------------------------
Toàn văn tài liệu xin xem [tại đây](https://drive.google.com/open?id=1ap1cM8dWc8y1fA6C-G84_wS5HjBZcZLz)./.

[[[PLACEHOLDER_HEADING]]]# HỆ THỐNG KHAI BÁO Y TẾ VÀ SÀNG LỌC BỆNH NHÂN NGHI NHIỄM COVID-19 TẠI BỆNH VIỆN NGUYỄN TRI PHƯƠNG.

Việc sử dụng phần mềm sẽ tiện lợi hơn cho người bệnh trong khai báo đồng thời giảm thiểu tiếp xúc giữa người và người – điều này có lợi cho phòng dịch COVID-19. Ứng dụng được phát triển bởi BV Nguyễn Tri Phương, sẵn sàng được triển khai vào thực tế trong công tác quản lý người bệnh, thân nhân người bệnh và người liên hệ công tác hàng ngày đến bệnh viện. 
100% người dân ( bao gồm mọi đối tượng) khi đến cổng bệnh viện sẽ phải đăng ký vào ứng dụng để khai báo các thông tin y tế: tên tuổi, địa chỉ, yếu tố dịch tể liên quan , các các triệu chứng gợi ý nghi nhiễm COVID19 … Những mối liên hệ với người khác, như người thân trong gia đình với người bị nhiễm COVID19 … cũng sẽ được ghi lại và sẽ có những cảnh báo ngay .
Những thông tin mà phần mềm khai báo y tế được triển khai bao gồm:
THÔNG TIN HÀNH CHÍNH: Họ tên, Năm sinh, Giới tính, Điện thoại, Địa chỉ. Đồng thời phần mềm có chụp lưu lại hình ảnh của người khai báo – là một cách để nhanh chóng xác định khi cần
MỤC ĐÍCH ĐẾN BỆNH VIỆN: phần mềm khai thác rõ mục đich đến bệnh viện như khám bệnh hay nuôi bệnh (bệnh nhân nào, ở khoa nào) hoặc liên hệ công tác (gặp ai, ở khoa phòng nào). Điều này giúp khi cần thiết rất dễ dàng xác lập lại sơ đồ dịch tễ.
KHAI BÁO DỊCH TỄ: những vấn đề cần khai thác về dịch tễ theo hướng dẫn của Bộ Y Tế đã được soạn sẵn theo cấu trúc câu hỏi có/không hoặc điền ngắn. Những câu hỏi giúp người bệnh rất dễ dàng lựa chọn hoặc trả lời. Đồng thời phần mềm lưu lại tất cả câu trả lời này và giúp nhà quản lý rất dễ dàng xuất ra theo dạng dữ liệu tổng hợp để hỗ trợ cho thống kê dịch tễ.
TÍNH GIÁM SÁT BẮT BUỘC: người sử dụng phải khai báo đầy đủ tất cả các câu hỏi mới có thể chấm dứt quy trình và nhận phiếu đã sàng lọc. Điều này giúp tránh việc bỏ sót câu hỏi và nguy cơ khai báo thiếu, từ đó đảm bảo tính chặt chẽ trong điều tra bắt buộc về thông tin dịch tễ để phòng chống dịch COVID-19.
TÍNH PHÂN LOẠI RÕ: người bệnh khi có yếu tố dịch tễ sẽ lập tức được yêu cầu bắt buộc thực thiện tiếp mẫu 2 (khu vực A.27 theo quy định). Việc phân loại được soạn sẵn theo hướng dẫn của Bộ Y Tế và có từng mẫu hoàn thành khai báo riêng để giúp phân biệt dễ dàng. 
Đánh giá ứng dụng ban đầu tại BV:
  1. Ứng dụng giúp bệnh viện có thể quản lý được các yếu tố dịch tễ của tất người đến tại bệnh viện. Điều này quan trọng để hỗ trợ việc ra quyết định cách ly và xét nghiệm xác định, hoặc công tác truy tìm các mối liên hệ với người nhiễm hoặc nghi nhiễm COVID19 từ đó khoanh vùng, cách ly theo hướng dẫn của Bộ Y Tế
  2. Nhà quản lý nhờ phần mềm sẽ nhanh chóng trích xuất thông tin phục vụ nghiên cứu dịch tễ hoặc thu thập dữ liệu y tế góp phần xây dựng Big Data của ngành y tế sau này.
  3. Hỗ trợ công tác khai báo y tế thêm nhanh chóng dễ dàng, tạo sự thuận tiện cho người dân, đồng thời giảm thiểu việc giao tiếp gần giữa người và người để phòng chống dịch COVID-19



[[[PLACEHOLDER_HEADING]]]# NĂNG LỰC KHOA NGOẠI THẦN KINH - BỆNH VIỆN NGUYỄN TRI PHƯƠNG

Khoa Ngoại Thần kinh được thành lập từ năm 2007 theo mô hình kết hợp Viện-Trường giữa Đại học Y dược TPHCM và Bv Nguyễn Tri Phương. Kể từ khi thành lập được sự đầu tư rất lớn của bệnh viện, Khoa đã từng bước phát triển và trở thành một trong những khoa lâm sàng trọng điểm của bệnh viện. Hiện nay Khoa là cơ sở thực hành của sinh viên và học viên sau đại học của Đại học Y dược TPHCM, Đại học Nguyễn Tất Thành, Đại học Hùng Vương, Đại học Hồng Bàng.
Các bác sĩ chuyên khoa của chúng tôi rất tinh thông trong các lĩnh vực chuyên sâu như: u não, bệnh lý mạch máu não, bệnh lý cột sống, chấn thương sọ não-cột sống, đột quỵ, bệnh lý đau mạn tính, phẫu thuật thần kinh chức năng. Chúng tôi đã thành lập các đơn vị chuyên sâu trong điều trị như: đơn vị phẫu thuật cột sống, can thiệp thần kinh, điều trị đau. **Số ca phẫu thuật của chúng tôi luôn tăng dần kể từ khi hoạt động, hiện nay mỗi năm chúng tôi thực hiện phẫu thuật trên 1000 các trường hợp bệnh lý thần kinh.**
Được bệnh viện đầu tư tất cả trang thiết bị hiện đại hổ trợ cho việc chẩn đoán và phẫu thuật các bệnh lý thần kinh: MRI 1.5 Tesla, MSCT 128 lát cắt, hệ thống phẫu thuật có dẫn đường Navigation, hệ thống cắt hút siêu âm trong phẫu thuật u não CUSA, khung định vị phẫu thuật Stereotaxy, kính hiển vi phẫu thuật, hệ thống chụp mạch máu số hóa xóa nền DSA.
Phát triển rất nhiều các phẫu thuật xâm lấn tối thiểu trong các bệnh lý não và cột sống.
**Là cơ sở đầu tiên tại Việt Nam triển khai thành công phẫu thuật đặt điện cực kích thích não sâu trong điều trị bệnh Parkinson, phẫu thuật kích thích tủy sống trong điều trị đau mạn tính. Đến nay, chúng tôi đã thực hiện thành công 35 ca phẫu thuật điều trị bệnh Parkinson, run vô căn và loạn trương lực cơ**
Tất cả các bệnh nhân (có BHYT hay không có BHYT) đều đựợc tiếp nhận điều trị tại Khoa theo một qui trình khoa học chặt chẽ. Hằng ngày với chế độ thăm bệnh hội chẩn (round visit), bệnh nhân và thân nhân sẽ biết được tình trạng bệnh tật cũng như được các bác sĩ giải thích các biện pháp điều trị, mổ xẻ.
## **4.Các loại phẫu thuật được thực hiện tại bệnh viện:**
**I.Chấn thương thần kinh:** Phẫu thuật chấn thương sọ não và chấn thương cột sống
**II.Các bệnh lý não**
  1. Phẫu thuật lấy máu tụ trong một số trường hợp tai biến mạch máu não
  2. Phẫu thuật vi phẫu các u trong não.
  3. Phẫu thuật vi phẫu các bệnh lý mạch máu não (túi phình mạch máu não, dị dạng mạch máu)
  4. Phẫu thuật điều trị động kinh đối với những bệnh nhân có tổn thương ở não (u não, dị dạng mạch máu).
  5. Can thiệp nội mạch điều trị các túi phình mạch máu não, dò động mạch cảnh-xoang hang, dị dạng mạch máu não
  6. Phẫu thuật điều trị bệnh lý não úng thủy, các nang nước trong não, rò dịch não tủy
  7. Phẫu thuật tạo hình khuyết sọ.
  8. Phẫu thuật nội soi u lấy u tuyến yên.
  9. Phẫu thuật thần kinh có dẫn đường (navigation)
  10. Phẫu thuật sinh thiết u não bằng khung định vị trong không gian 3 chiều (stereotaxy)
  11. Phẫu thuật điều trị apxe não


**III. Các bệnh lý cột sống:**
1. Vi phẫu thuật lấy nhân thoát vị đĩa đệm, thay đĩa đệm nhân tạo
2. Phẫu thuật trượt thân đốt sống bằng phương pháp PILF, TILF
3. Vi phẫu thuật u tủy sống
4. Phẫu thuật hẹp ống sống cổ bằng phương pháp tạo hình bản sống (laminoplasty)
5. Phẫu thuật gãy mỏm nha C2
6. Phẫu thuật dị tật Arnold-Chiari, rỗng ống tủy (syringomyelia), tủy bám thấp
7. Phẫu thuật điều trị lao cột sống
8. Phẫu thuật nội soi lấy nhân đệm
9. Phẫu thuật bắt vis qua da trong bệnh lý trượt đốt sống
10. Phẫu thuật bơm cement tạo hình thân sống (vetebroplasty)
11. Tiêm thấm ngoài màng cứng điều trị đau cột sống
**IV. Bệnh lý thần kinh ngoại biên:**
1. Chèn ép thần kinh ngoại biên: Hội chứng ống cổ tay, chèn ép thần kinh trụ
2. U dây thần kinh ngoại biên
**V. Phẫu thuật thần kinh chức năng:**
1. Phẫu thuật kích thích não sâu (DBS) trong điều trị bệnh Parkinson
2. Phẫu thuật điều trị đau dây thần kinh số V
  1. Phẫu thuật điều trị co giật nữa mặt
  2. Phẫu thuật kích thích tủy sống điều trị đau mạn tính
  3. Phẫu thuật động kinh


**5.Liên hệ với chúng tôi:**
Khoa Ngoại Thần kinh, lầu 1 khu D, hoặc phòng khám số 26 Khoa Khám bệnh, Bv Nguyễn Tri Phương, 468 Nguyễn Trãi, Q 5, TPHCM
Điện thoại: 0932368906
Web: www.bvnguyentriphuong.com.vn
Email: khoangoaithankinh@gmail.com
Một số hình ảnh
Hệ thống Navigation và hình ảnh mổ có sử dụng Navigation
Phẫu thuật vi phẫu 
Phẫu thuật điều trị bệnh Parkinson
Phẫu thuật nội soi não thất
Hội chẩn giữa các bs trong khoa
Các khối u não lớn đã phẫu thuật tại bv
Phẫu thuật Parkinson

[[[PLACEHOLDER_HEADING]]]# Hướng dẫn đặt xét nghiệm thực hiện tại nhà

Bước 1: truy cập trang web [khamtainha-bvntp.com](http://khamtainha-bvntp.com/?fbclid=IwAR1acGT9VhRW-a6NILOJpHe3kRNpxJCwoQQafAi5rzrfM9iYGYp2fgT3dj4)
Bước 2: chọn thẻ "Đăng ký xét nghiệm"
Bước 3: thực hiện khai báo các trường bắt buộc và chọn lựa các xét nghiệm cần thực hiện
Bước 4: bấm nút gửi (submit) khi đã hoàn thành để gửi toàn bộ các thông tin cho chúng tôi 
Bước 5: vui lòng chờ nhận cuộc gọi xác nhận từ nhân viên y tế bệnh viện Nguyễn Tri Phương
(Bạn cũng có thể nhắn tin trên fanpage của BV thông báo đã đặt lịch để chúng tôi có thể hỗ trợ nhanh hơn!)
Theo dõi các thông tin của BV trên facebook [tại đây](https://www.facebook.com/BVNTP)
Theo dõi các video về y tế của BV tại [kênh truyền thông](https://www.youtube.com/channel/UCRlRfMJl5emGJvWjuoJK7sg)./.

[[[PLACEHOLDER_HEADING]]]# Nhân viên y tế không đơn độc trong cuộc chống dịch bệnh

Ngày 18/02/2020, Hòa thượng Thích Huệ Đăng (người nghiên cứu và phát triển Sâm Ngọc Linh) đã đến thăm và tặng cho bệnh viện Nguyễn Tri Phương 100 hộp Sâm có tác dụng bồi bổ tăng cường sức khỏe
Trong trận chiến với dịch bệnh, những cán bộ nhân viên y tế cảm thấy ấm lòng hơn khi được sự quan tâm và động viên từ quý Thầy và công ty
Sâm Ngọc Linh cũng là loại nhân sâm thứ 20 được tìm thấy trên thế giới. Theo kết quả nghiên cứu từ năm 1978 của [Bộ Y tế Việt Nam](https://vi.wikipedia.org/wiki/B%E1%BB%99_Y_t%E1%BA%BF_\(Vi%E1%BB%87t_Nam\) "Bộ Y tế \(Việt Nam\)"), phần [thân rễ](https://vi.wikipedia.org/wiki/Th%C3%A2n_r%E1%BB%85 "Thân rễ") của cây sâm Ngọc Linh Việt Nam chứa 26 hợp chất [saponin](https://vi.wikipedia.org/wiki/Saponin "Saponin")[cấu trúc hóa học](https://vi.wikipedia.org/w/index.php?title=C%E1%BA%A5u_tr%C3%BAc_h%C3%B3a_h%E1%BB%8Dc&action=edit&redlink=1 "Cấu trúc hóa học \(trang chưa được viết\)") đã biết và 24 saponin có cấu trúc mới không có trong các loại sâm khác, trong khi sâm Triều Tiên có khoảng 25 saponin.Những kết quả nghiên cứu, phân lập thành phần hóa học mới nhất được công bố còn kéo dài danh sách saponin của sâm Ngọc Linh hơn nữa, lên tổng cộng 52 loại.Như vậy, sâm Việt Nam là một trong những loại sâm có hàm lượng saponin nhiều nhất, tương tự một số cây sâm quý đã từng được nghiên cứu sử dụng từ lâu trên thế giới.Hợp chất hóa học đa dạng và tác dụng thực tiễn đối với sức khỏe của con người khiến sâm Ngọc Linh hiện nay được bán trên thị trường với giá càng ngày càng cao,thậm chí còn cao hơn sâm Triều Tiên nhiều lần

[[[PLACEHOLDER_HEADING]]]# HỘI NGHỊ KHOA HỌC KỸ THUẬT LẦN XVII NĂM 2019 

**DOWNLOAD**
HỘI NGHỊ KHOA HỌC KỸ THUẬT LẦN XVII NĂM 2019 [TẢI FILE TẠI ĐÂY](https://drive.google.com/open?id=1yJQnHwouV9ddpoG2PXeo_PD1SnDNCAU7)

[[[PLACEHOLDER_HEADING]]]# BỆNH VIỆN VÀ TỔ CHỨC REI CÙNG KẾT HỢP ĐÀO TẠO

Cô Merrily Madero và TS. Cheryl Meredith sẽ chia sẻ kiến thức, kinh nghiệm về phương pháp lãnh đạo với các Cán bộ, Nhân viên của Bệnh viện theo chủ đề **_‘‘Be the leader that others will follow’’_**
Để có được những hoạt động ý nghĩa như thế này, BV không quên cảm ơn cô Trần Phương Liên - Giám đốc REI tại Việt Nam

[[[PLACEHOLDER_HEADING]]]# TỔ CHỨC THÀNH CÔNG CUỘC THI VIÊN CHỨC NĂM 2019

Xin chúc các thí sinh đều đạt được kết quả thi như mong muốn./.

[[[PLACEHOLDER_HEADING]]]# TỔNG HỢP CÁC THÔNG TIN VỀ CÚM CORONA

Bộ Y tế Canada và Tổ chức Y tế Thế giới (WHO) thông báo cho công chúng rằng cúm (virus Corona) lần này là nghiêm trọng. Phương pháp phòng ngừa là giữ cho cổ họng ẩm, đừng để cổ họng bị khô. Do đó, đừng để khát nước vì một khi màng trong cổ họng của bạn bị khô, virus sẽ xâm nhập vào cơ thể bạn trong vòng 10 phút. Người lớn nên uống nước ấm 50-80cc, và 30-50cc cho trẻ, tuỳ theo độ tuổi. Bất cứ khi nào bạn cảm thấy cổ họng bị khô, đừng chờ đợi, hãy giữ nước trong tay. Đừng uống nhiều cùng một lúc vì nó không giúp ích gì, thay vào đó hãy tiếp tục giữ ẩm cho cổ họng. Cho đến cuối tháng 3, tránh đến những nơi đông người, đeo khẩu trang khi cần thiết đặc biệt là trên tàu hỏa hoặc phương tiện giao thông công cộng. Tránh thực phẩm chiên hoặc cay và nạp thêm vitamin C cho cơ thể Các triệu chứng / được mô tả là: 1. sốt cao 2. Ho kéo dài sau khi sốt 3. Trẻ em dễ mắc bệnh 4. Người lớn thường cảm thấy khó chịu, đau đầu và chủ yếu liên quan đến hô hấp 5. Rất dễ lây qua tiếp xúc
NGUY CƠ KHI SỬ DỤNG KÉO DÀI HOẶC TÁI SỬ DỤNG KHẨU TRANG N95
Khẩu trang N95 lọc được 95% vi sinh vật lây truyền qua đường không khí. Khi việc sử dụng N95 thường xuyên hơn, do nguồn lực cung cấp khẩu trang N95 còn hạn chế, giá thành cao, nhân viên y tế thường sử dụng kéo dài và thậm chí sử dụng lại nhiều lần khẩu trang này. Hướng dẫn sử dụng của nhà sản xuất thường yêu cầu phải bỏ khẩu trang ngay sau mỗi lần sử dụng, nhưng một số hãng cho phép sử dụng lại theo chính sách kiểm soát nhiễm khuẩn của từng cơ sở y tế.
Nguy cơ đáng kể nhất khi sử dụng lại khẩu trang là lây truyền vi sinh vật qua đường tiếp xúc do chạm vào bề mặt của khẩu trang bị ô nhiễm. Một nghiên cứu cho thấy trong 1 ca trực một điều dưỡng trung bình chạm 25 lần vào mặt, mắt hoặc khẩu trang N95 khi sử dụng kéo dài. Các vi sinh vật gây bệnh đường hô hấp trên bề mặt khẩu trang có thể lây truyền cho người mang khẩu trang do tay người đeo chạm vào khẩu trang đã bị nhiễm và sau đó chạm vào niêm mạc mắt mũi miệng của mình.
Các nghiên cứu đã cho thấy rằng một số mầm bệnh đường hô hấp có thể tồn tại trên khẩu trang trong thời gian dài, hơn 99,8% vi sinh vật bị giữ lại trên khẩu trang N95 sau khi nhân viên y tế xử lý các chất tiết đường hô hấp hoặc tiếp xúc người bệnh ho hoặc hắt hơi. Khẩu trang N95 cũng có thể bị nhiễm các vi khuẩn tồn tại lâu trong môi trường (ví dụ, Staphylococcus aureas kháng methicillin, enterococci kháng vancomycin, Clostridium difficile, norovirus, v.v.). Những vi khuẩn này cũng có thể lây nhiễm sang bàn tay của người mang khẩu trang và truyền bệnh cho chính họ hoặc cho người khác thông qua truyền tiếp xúc trực tiếp hoặc gián tiếp.
Mức độ ô nhiễm của khẩu trang khi sử dụng kéo dài và tái sử dụng có thể tuỳ thuộc vào loại thủ thuật nhân viên thực hiện, vào mức độ kiểm soát môi trường. Ví dụ, khi nhân viên y tế thực hiện các thủ thuật tạo khí dung như nội soi phế quản, hút đờm hoặc đặt nội khí quản, khẩu trang sẽ bị ô nhiễm cao. Trong khi đó, nếu kiểm soát được bệnh nhân nguồn (ví dụ như yêu cầu bệnh nhân đeo khẩu trang), sử dụng các biện pháp thông khí, sẽ làm giảm mức độ ô nhiễm bề mặt của khẩu trang.Ngoài nguy cơ truyền bệnh do tiếp xúc với khẩu trang bị ô nhiễm, việc sử dụng kéo dài hoặc sử dụng lại còn có nguy cơ giảm khả năng bảo vệ của khẩu trang N95.
Do đó, chỉ sử dụng khẩu trang N95 khi cần thiết và nên bỏ đi sau mỗi lần sử dụng. Nhiễm nCoV chủ yếu lây truyền qua đường tiếp xúc và giọt bắn, chỉ lây qua không khí khi người bệnh có suy hô hấp, cần làm những thủ thuật tạo khí dung như thở máy, hút đàm..Chỉ cần mang khẩu trang N95 khi tiếp xúc với bệnh nhân nhiễm nCoV đã có biểu hiện viêm phổi nặng, suy hô hấp. Đối với bệnh nhân chỉ có các triệu chứng sốt, viêm long đường hô hấp nhẹ, chỉ cần mang khẩu trang y tế hoặc kháng khuẩn hoặc N90-92. Trong cộng đồng, chỉ cần mang khẩu trang y tế đạt chuẩn (3-4 lớp, trong đó có lớp lọc và bán thấm) khi đến chỗ đông người, thiếu thông khí, khi tiếp xúc người bệnh.
(Hội Kiểm Soát Nhiễm Khuẩn TPHCM)

[[[PLACEHOLDER_HEADING]]]# NHỮNG ĐIỀU CẦN LÀM NGAY ĐỂ PHÒNG CHỐNG NGUY CƠ MẮC CHỦNG VIRUS CORONA MỚI (NCOV)


[[[PLACEHOLDER_HEADING]]]# HỘI NGHỊ QUỐC TẾ 

Hiện nay, trên thế giới, số hóa đã tạo ra sự chuyển đổi mạnh mẽ trong ngành y tế, làm cho quá trình chăm sóc sức khỏe ngày càng chất lượng - hiệu quả - hiệu năng. Số hóa đã làm cho hệ thống thông tin y tế trở thành nền tảng để triển khai các nội dung của cách mạng công nghiệp lần thứ 4 như trí tuệ nhân tạo, internet kết nối, dữ liệu lớn, chuỗi khối, điện toán đám mây,… làm cho bệnh viện ngày càng thông minh. Tại Việt Nam, Bộ Y tế cũng đã đề ra lộ trình thực hiện bệnh án điện tử và bệnh viện thông minh.
Tuy nhiên, việc xây dựng bệnh viện thông minh đang đặt ra những thách thức mới trong công tác quản lý bệnh viện, từ hệ thống quản lý bệnh viện đến việc đầu tư xây dựng hạ tầng công nghệ thông tin, triển khai bệnh án điện tử, bảo mật và an toàn thông tin, hệ thống lưu trữ và truyền tải hình ảnh y khoa, các ứng dụng trí tuệ nhân tạo đến việc thích ứng với hạ tầng số hóa của người làm công tác quản lý.
Để có thể đưa ra các khuyến nghị góp phần định hướng cho việc xây dựng bệnh viện thông minh ở Việt Nam, được sự đề xuất và hỗ trợ của Khoa Quản lý Công nghiệp - Trường Đại Học Bách Khoa Thành phố Hồ Chí Minh, Hội sẽ phối hợp với Khoa Quản Lý Công Nghiệp – Trường Đại Học Bách Khoa Thành Phố Hồ Chí Minh tổ chức hội nghị quốc tế “INFORMATICS về sức khoẻ lần I, hướng tới BỆNH VIỆN THÔNG MINH” gọi tắt là HEALTHINFO I”, để các nhà quản lý cũng như các nhà nghiên cứu có cơ hội cùng nhau thảo luận ở cả hai lĩnh vực nghiên cứu và thực hành quản lý bệnh viện trong bối cảnh đó.
Chi tiết vui lòng xem[ tại đây](http://healthinformatics.medihub.vn/#welcome)./.

[[[PLACEHOLDER_HEADING]]]# LỄ KỶ NIỆM 10 NĂM THÀNH LẬP KHOA GÂY MÊ HỒI SỨC

Nhiều hoạt động văn nghệ diễn ra thể hiện sự công phu, đầu tư. Và thật bất ngờ về sự chỉn chu của các tiết mục văn nghệ, dù đến từ những diễn viên không chuyên nhưng sự chuyên nghiệp và kỹ lưỡng trong đầu tư đã giúp không khí sôi nổi rộn ràng ngay từ phút đầu
Những bó hoa tươi thắm được trao tặng để ghi nhận một chặng đường đầy tự hào
Xin trân trọng chúc mừng sự phát triển không ngừng của một tập thể vững mạnh của bệnh viện!!!

[[[PLACEHOLDER_HEADING]]]# TÁI BỔ NHIỆM GIÁM ĐỐC BỆNH VIỆN

Quyết định số: 3814/QĐ-UBND ngày 06/09/2019 của Ủy Ban Nhân Dân Thành Phố Hồ Chí Minh về việc bổ nhiệm lại Giám đốc Bệnh viện Nguyễn Tri Phương
Đại diện Ban Lãnh đạo Sở Y tế - GS.TS Nguyễn Tấn Bỉnh đánh giá cao những đóng góp của BS Võ Đức Chiến đối với sự phát triển của BV Nguyễn Tri Phương
BS Võ Đức Chiến đã nhận nhiệm vụ tiếp tục cầm lái đưa bệnh viện đi lên trong sự đồng thuận, tin tưởng và ủng hộ cao của tập thể nhân viên BV Nguyễn Tri Phương

[[[PLACEHOLDER_HEADING]]]# Kỷ niệm 10 năm thành lập khoa CTCH và Hội nghị toàn quốc nội tiết 

Bệnh viện Nguyễn Tri Phương đã trân trọng tổ chức lễ kỷ niệm 10 năm thành lập Khoa Chấn Thương Chỉnh Hình đồng thời vinh danh sự cống hiến của TS.BS Tăng Hà Nam Anh vì sự đóng góp to lớn trong sự phát triển của khoa ở trên cương vị đầu tàu
Về tham dự buổi lễ, có cả những lời chúc mừng từ PGS.TS Nguyễn Thi Hùng, nguyên Giám đốc bệnh viện, là người được chứng kiến sự đi lên chập chững của khoa CTCH từ ngày đầu
Song song với hoạt động này, nhận được sự tin tưởng của nhiều đồng nghiệp, BV Nguyễn Tri Phương song song tổ chức hội nghị Nội tiết toàn quốc với báo cáo viên là nhiều nhà chuyên môn có uy tín trong và ngoài nước

[[[PLACEHOLDER_HEADING]]]# Khắc phục tình trạng thiếu máy thở bằng giải pháp thông minh

Vì nhu cầu này khá cao nên các bệnh viện lớn luôn trong tình trạng thiếu máy thở, nhất là những cao điểm lễ, Tết hay vào mùa dịch bệnh. Vậy nên, để quản lý, sử dụng và điều phối một cách hiệu quả được xem là một yêu cầu về tính cấp thiết.
Tháo gỡ bài toán khó này, Bệnh viện Nguyễn Tri Phương đưa ra sáng kiến “Ứng dụng IoT để quản lý và điều phối máy giúp thở giữa các khoa trong toàn bệnh viện”. Đây cũng là giải pháp y tế thông minh trên nền tảng công nghệ thông tin.
ĐÀI TIẾNG NÓI NHÂN DÂN TPHCM đã quan tâm và đưa tin về cải tiến này của BV
Xem toàn bộ bài phỏng vấn do VOH thực hiện [tại đây](https://voh.com.vn/suc-khoe/khac-phuc-tinh-trang-thieu-may-tho-bang-giai-phap-thong-minh-344334.html?fbclid=IwAR2ttsk71q35ygtkQgXk2WlpSUgonx77_299nP3xZwsYM2Bmbhe2TtfjmAs)./.

[[[PLACEHOLDER_HEADING]]]# Bệnh viện trăm tuổi chuyển mình 

Đi lên từ một bệnh viện truyền thống công lập lâu đời, những khó khăn là khó tránh khỏi. Hạn chế lớn nhất của bệnh viện là cơ sở vật chất chưa đáp ứng nhu cầu khám chữa bệnh rất lớn của người dân. Tuy nhiên, Bệnh viện đã khắc phục những hạn chế đó bằng việc không ngừng xây dựng và củng cố một đội ngũ cán bộ công nhân viên năng động, tận tâm.
Đặc biệt, điều thể hiện sự năng động của một bệnh viện tuyến cuối của Thành phố là ở cách thức phát huy mô hình viện – trường. Nghĩa là bệnh viện trở thành nơi đào tạo thực hành và nghiên cứu cho sinh viên, học viên sau đại học từ các trường đại học y khoa trên địa bàn thành phố, và ngược lại, các giảng viên vừa tham gia quá trình chăm sóc – điều trị người bệnh đồng thời đưa những kiến thức được cập nhật, những nghiên cứu mới vào trong các hoạt động khoa học – kỹ thuật của Bệnh viện.
Không những vậy, bệnh viện Nguyễn Tri Phương còn góp phần xây dựng hình ảnh du lịch kết hợp với y tế, như chủ trương của Sở Y tế và UBND TP.HCM trong thời gian qua. Việc thành công kết hợp với tổ chức TUC từ Nhật Bản để xây dựng thành công trung tâm lọc máu chất lượng cao đã giúp nhiều bệnh nhân bị bệnh thận mạn ở nước ngoài thêm yên tâm khi đến Việt Nam du lịch. Chính những điều đó tạo nên khía cạnh năng động của bệnh viện.
Ngoài việc kêu gọi được các quỹ từ thiện cùng tham gia vào các hoạt động của hội chữ thập đỏ để hỗ trợ, giúp đỡ người bệnh có điều kiện khó khăn có thể được khám chữa bệnh, bệnh viện còn tổ chức các bữa ăn tình thương với chất lượng được đảm bảo từ công ty cung cấp suất ăn với 100% vốn của Đức. Điều đặc biệt nữa là mỗi nhân viên của bệnh viện đều là hội viên của Hội chữ thập đỏ nên bất cứ cá nhân nào cũng ý thức, đóng góp và phát động từ thiện trong và ngoài bệnh viện.
Năm 2018 bệnh viện đã hỗ trợ 40 triệu đồng cứu bệnh nhân neo đơn bị suy tim, kêu gọi hơn 50 triệu đồng góp phần điều trị cho bệnh nhân có nhiều bệnh lý nội khoa phức tạp và nhiều chiến dịch thiện nguyên lớn nhỏ khác.
Lãnh đạo bệnh viện cho biết giữ vững phát triển là tiêu chí chung của hầu hết các đơn vị, tổ chức; tuy nhiên với Nguyễn Tri Phương sự phát triển luôn dựa trên sự kế thừa, trong đó chất lượng đội ngũ y, bác sĩ là yếu tố tiên quyết với cái tâm làm nghề luôn được vun bồi. Cũng trong năm 2018, bệnh viện đã đoạt giải nhất cuộc thi “đặc nhiệm Blouse trắng” với những phần thi ứng xử nhanh nhạy và khéo léo từ việc vận dụng y đức, chuyên môn…đã cho thấy rõ hiệu quả của việc nâng cao chất lượng đội ngũ nhân lực của bệnh viện trong thời gian qua.
Khoa xét nghiệm của bệnh việc đã được nâng cấp đạt chuẩn an toàn sinh học cấp 2 – ứng dụng 5S để giúp sự sắp xếp thêm hợp lý, đảm bảo sạch sẽ và ngăn nắp. An toàn sinh học cấp 2 là tiêu chuẩn cho khoa xét nghiệm của các bệnh viện loại 1 của thành phố HCM, gồm nhiều tiêu chuẩn giúp đảm bảo an toàn cho nhân viên y tế và chất lượng của mẫu xét nghiệm.
Riêng năm 2018, TS BS Tăng Hà Nam Anh, Trưởng khoa Chấn thương Chỉnh hình BV Nguyễn Tri Phương TP.HCM đã áp dụng thành công phương pháp mổ không đau an toàn, ít tai biến và chi phí thấp.
Bệnh viện cũng đã mở phòng tư vấn bệnh lý đái tháo đường và tăng huyết áp. Đây là góc tư vấn giúp bệnh nhân chung sống tốt với căn bệnh mãn tính đái tháo đường và tăng huyết áp.
Hy vọng năm 2019 BV sẽ chuyển mình với rất nhiều đề án phía trước: hợp tác công - tư, du lịch y tế...

[[[PLACEHOLDER_HEADING]]]# Khen thưởng các chiến sĩ thi đua 2018 và trao tặng huân chương vì sự nghiệp y tế

Xin trân trọng chúc mừng các tấm gương đã miệt mài cống hiến

[[[PLACEHOLDER_HEADING]]]# Chương trình tầm soát và điều trị bệnh lý mạch máu bàn chân đái tháo đường

Chương trình tầm soát sẽ diễn ra tại Khoa Nội tiết bệnh viện Nguyễn Tri Phương (lầu 3, khu A) bắt đầu từ tháng 3/2019
Bệnh viện mong muốn thông qua chương trình này sẽ giúp đẩy mạnh hơn công tác điều trị biến chứng ở bàn chân đái tháo đường - vốn là một vấn đề còn nhiều phức tạp đối với người bệnh hiện nay./.

[[[PLACEHOLDER_HEADING]]]# Hoạt động tầm soát và điều trị bệnh lý tăng huyết áp và đái tháo đường đang diễn ra tại BV Nguyễn Tri Phương

Hoạt động hướng đến người bệnh, tầm soát và tư vấn miễn phí bệnh lý tăng huyết áp và đái tháo đường tại BV Nguyễn Tri Phương
Đội ngũ y bác sĩ bệnh viện Nguyễn Tri Phương luôn sẵn sàng phục quỵ quý bà con cô bác

[[[PLACEHOLDER_HEADING]]]# NGƯỜI TỐT VIỆC TỐT


[[[PLACEHOLDER_HEADING]]]# Tổ chức REI đồng hành cùng nhiều hoạt động của bệnh viện

Trong quá trình hợp tác với tổ chức REI từ năm 2012 đến nay Giám đốc REI là ông Brian-Teel đã đưa các bác sĩ của đoàn REI đến trao đổi chuyên môn, huấn luyện và đào tạo cho các bác sĩ Tai Mũi Họng của Bệnh viện Nguyễn Tri Phương, đồng thời tạo điều kiện cho bác sĩ Trưởng khoa Liên Chuyên Khoa tu nghiệp tại Mỹ.
Giáo sư Bruce-Leipzig đã nhiều lần đến thăm, huấn luyên và tặng trang thiết bị dụng cụ phẫu thuật cho bệnh viện, trong điều kiện bệnh viện còn thiếu trang thiết bị, nhằm phục vụ bệnh nhân được tốt hơn.
Bệnh viện Nguyễn Tri Phương luôn tỏ lòng cảm ơn sâu sắc đến những đóng góp và giúp đỡ hết sức quý báu này./.

[[[PLACEHOLDER_HEADING]]]# TÌM NGƯỜI THÂN CHO BỆNH NHÂN

Lúc 18h53, ngày 22 tháng 02 năm 2019. Bệnh nhân được người dân phát hiện nằm bên đường, sủi bọt mép nên gọi cấp cứu 115 và Công An Phường 9 Quận 5 đưa vào cấp cứu tại Bệnh viện Nguyễn tri Phương **(_không giấy tờ tùy thân)_**
Chẩn đoán bệnh: Xuất huyết dưới màng cứng 2 bán cầu – Xuất huyết dưới nhện vỏ não – Động kinh. Hiện tại bệnh nhân nhắm mở mắt tự nhiên, không tiếp xúc.
_Ai là người thân hoặc biết thông tin liên quan đến bệnh nhân vui lòng liên hệ số điện thoại_ : **_028.3836.2419 – Phòng Công Tác Xã Hội, Bệnh viện Nguyễn Tri Phương, 468 Nguyễn Trãi, Phường 8, Quận 5 Tp.HCM_**

[[[PLACEHOLDER_HEADING]]]# Bộ trưởng Bộ Y Tế đến thăm và chúc tết Bệnh viện

Báo cáo với Bộ trưởng, BS CKII Võ Đức Chiến - giám đốc, đã khái lược những điểm nổi bật trong thời gian vừa qua:
1. Trong năm 2018, 02 nhà vệ sinh chất lượng cao tại khu vực khám bệnh của BV đã giúp vấn đề vệ sinh công cộng không còn là nỗi ám ảnh của người bệnh
2. BV NTP đã và đang đẩy mạnh mảng đào tạo - nghiên cứu khoa học nhờ các yếu tố sau:
a. Kết hợp chặt chẽ viện - trường giúp tăng cường công tác đào tạo, bản thân bv cũng là cơ sở đào tạo - huấn luyện hiệu quả cho nhiều đối tượng học viên cả trong và ngoài nước 
b. Trên cơ sở 06 mã CME (đào tạo liên tục) được BYT cấp phép đào tạo để làm phong phú nhiều hoạt động đào tạo
c. Kết hợp nhiều hội chuyên môn (Hội Lọc Máu tp.HCM, Hội Nột tiết tp.HCM...) để có những kết nối hiệu quả với các chuyên gia trong và ngoài nước trong công tác đào tạo
3. BV rất mong chờ sự thành công và đưa vào hoạt động của các dự án trong năm 2019
a. Khí sạch y tế khu vực Phòng mổ và Hồi sức chống độc
b. Dự án cải tạo nhà giữ xe 02 bánh
c. Dự án cải tạo khu B,C,D (nguồn ngân sách) và E (nguồn vay kích cầu)
4. Những hoạt động BV mong muốn được người dân biết đến nhiều hơn
a. Dịch vụ khám chữa bệnh tại nhà 
b. Dịch vụ lấy mẫu xét nghiệm tại nhà
c. Khu vực thực hiện xét nghiệm - chẩn đoán hình ảnh - thăm dò chức năng theo yêu cầu
5. Kế hoạch dài hơi: bệnh viện mong muốn sẽ thành công: dự án PPP tại khu vực G,H hiện tại nhờ sự đồng hành của các cấp lãnh đạo giúp bệnh viện hơn 100 tuổi sẽ thật sự chuyển mình
Bộ trưởng đã có nhiều đánh giá cao đối với những sự phát triển của BV, và gửi lời yêu cầu lãnh đạo Sở Y Tế tp.HCM cần có những cơ chế phù hợp khuyến khích BV phát triển như có lộ trình tự thu tự chi hợp lý, tăng cường xin thêm các nguồn hỗ trợ từ ngân sách nhà nước cho BV...
Bộ trưởng cũng đã đích thân có những bao lì xì may mắn để gửi lời chúc tốt đẹp đến toàn thể nhân viên bệnh viện

[[[PLACEHOLDER_HEADING]]]# Chương trình khám và tầm soát miễn phí bệnh Tăng huyết áp và Đái tháo đường

- Tăng huyết áp là căn bệnh thầm lặng không biểu hiện bất kỳ triệu chứng nào. Điều gì sẽ xảy ra nếu bạn không điều trị tăng huyết áp! Dễ dẫn đến tình trạng đột quỵ, tim mau yếu hơn, cơn đau thắt ngực ngày một nhiều và nặng hơn Tuy nhiên nếu được chẩn đoán kịp thời, người bệnh đái tháo đường và tăng huyết áp hoàn toàn có thể sống khỏe mạnh, lạc quan nhờ tuân thủ lối sống lành mạnh.
Công việc và gia đình đều rất quan trọng, nhưng không có sức khỏe thì tất cả đều trở nên vô nghĩa.
Thay vì chờ biến chứng ác tính đến gõ cửa, hãy chủ động đăng ký tầm soát huyết áp miễn phí cho bản thân và gia đình ngay tại: **BỆNH VIỆN NGUYỄN TRI PHƯƠNG**
### Chương trình khám và tầm soát miễn phí bệnh Tăng huyết áp và Đái tháo đường
**Thời gian:** 7-11:30 sáng 5/7/2019
**Địa điểm:** Hội trường A - Lầu 5, BV NGUYỄN TRI PHƯƠNG
Trân trọng kính mời Cô Bác Anh Chị tham gia và chia sẻ thông tin chương trình đến người thân! Ban tổ chức xin chân thành cảm ơn!

[[[PLACEHOLDER_HEADING]]]# Chương trình hỗ trợ phát triển quốc tế của Chính phủ Australia

Học bổng Chính phủ Australia là một cấu thành quan trọng trong chương trình trợ giúp của Chính phủ Australia dành cho Việt Nam và nhằm đáp ứng các nhu cầu về phát triển và về nguồn nhân lực ưu tiên của Việt Nam.
Australia sẽ dành cho Việt Nam các suất học bổng toàn phần cho các công dân Việt Nam xin học bậc sau đại học (Thạc sỹ) tại các trường đại học uy tín của Australia trong năm 2019.
Các ứng viên sẽ được xét duyệt dựa trên trình độ chuyên môn, năng lực cá nhân, thành tích học tập và quan trọng nhất là khả năng đóng góp cho sự phát triển của Việt Nam.
Các ứng viên là nam, nữ, đặc biệt người dân tộc thiểu số, từ các tỉnh và vùng nông thôn, nếu đáp ứng các tiêu chí tuyển chọn được khuyển khích nộp đơn xin học bổng.
Những ứng viên thuộc diện khó khăn – người khuyết tật và người ở những huyện nghèo theo qui định được xem xét đặc biệt.
Vui lòng tham khảo thêm thông tin tại: <http://www.australiaawardsvietnam.org>

[[[PLACEHOLDER_HEADING]]]# 25/9/2018- Tăng cường hài lòng người bệnh tại bệnh viện

Nhiều ghế đá đã được đặt thêm ở khu vực ngồi chờ, một khu nhà vệ sinh xây mới tách biệt nam và nữ dành cho khu khám bệnh ngoại trú, khu vực cho thân nhân của bệnh nhân khoa Hồi sức Chống độc (BV Nguyễn Tri Phương) đang có kế hoạch chỉnh trang… Quản lý chất lượng bệnh viện “Xanh - Sạch - Đẹp” từ những chi tiết nhỏ nhất hướng tới sự hài lòng của người bệnh.
Từ khi quyết định 1313/QĐ-BYT hướng dẫn quy trình khám bệnh tại bệnh viện của Bộ Y tế được ban hành, các cơ sở y tế đã tích cực triển khai nhiều hoạt động cải thiện môi trường khoa phòng, khu vực khám bệnh của bệnh viện; cải tiến quy trình, rút ngắn thời gian chờ khám bệnh.
Khu nhà vệ sinh của bệnh viện thuộc khu khám bệnh ngoại trú đã được cải tạo, sửa mới gồm hai khu riêng biệt dành cho nam và nữ, cùng với nhà vệ sinh dành cho người khuyết tật. Nhà vệ sinh được trang bị xông tinh dầu, hệ thống bồn rửa tay, xà phòng rửa tay, giấy vệ sinh, máy sấy… và ứng dụng 01 thiết kế học được từ các chuyến tham quan ở nước bạn: tấm chắn ở bồn tiểu nam để tăng cường vệ sinh. Nhà vệ sinh luôn có nhân viên lau dọn, tránh cho sàn nhà bị ngập nước, vấy bẩn, hay có mùi hôi.
Khoa xét nghiệm đã được nâng cấp đạt chuẩn an toàn sinh học cấp 2 - ứng dụng 5S để giúp sự sắp xếp thêm hợp lý, đảm bảo sạch sẽ và ngăn nắp. An toàn sinh học cấp 2 là tiêu chuẩn cho khoa xét nghiệm của các bệnh viện loại 1 của thành phố HCM, gồm nhiều tiêu chuẩn giúp đảm bảo an toàn cho nhân viên y tế và chất lượng của mẫu xét nghiệm.
Khoa khám bệnh phục vụ ngày thứ 7 dành cho cả đối tượng BHYT - tiến đến sẽ khám 24/7 để nâng cao khả năng tiếp cận dịch vụ y tế cho bệnh nhân. Khoa khám bệnh cũng có khu vực khám dịch vụ nhằm đa dạng hoá các loại hình phục vụ cũng như các đối tượng phục vụ, nâng cao sự hài lòng của người bệnh.
Cải thiện chất lượng bệnh viện chính là thông qua nhiều hoạt động nhằm nâng cao chất lượng khám, chữa bệnh và đạt được sự hài lòng của người bệnh. Người bệnh được chăm sóc an toàn, thoải mái khi tới khám và điều trị tại bệnh viện là mục tiêu lớn nhất của việc quản lý chất lượng bệnh viện hiện nay.
Để xem toàn bộ bài viết vui lòng truy cập : <https://m.suckhoedoisong.vn/tang-cuong-quan-ly-chat-luong-benh-vien-nang-cao-su-hai-long-nguoi-benh--n148798.html>
Ban Truyền Thông 

[[[PLACEHOLDER_HEADING]]]# Khối u trong mũi khiến thiếu niên thường xuyên chảy máu cam

Bệnh nhân quê Hải Phòng, chảy máu mũi, nghẹt mũi suốt vài tháng nay, cứ nghĩ do nóng trong người nên chảy máu cam. Uống thuốc không hết chảy máu, bệnh nhân lên bệnh viện Hà Nội kiểm tra, bác sĩ không phát hiện bất thường. Lần này vào TP HCM thăm chị gái, bệnh nhân bất ngờ chảy máu mũi ồ ạt, cấp cứu tại Bệnh viện Nguyễn Tri Phương.
Bác sĩ Nguyễn Phước Hiền, Khoa Tai Mũi Họng - Mắt, Bệnh viện Nguyễn Tri Phương cho biết kết quả nội soi ghi nhận có khối choán chỗ màu đỏ hồng lấp đầy hoàn toàn hốc mũi phải bệnh nhân, chạm vào dễ chảy máu. Hình ảnh cắt lớp vi tính thấy khối choán chỗ vòm mũi họng có tăng sinh mạch máu. Bệnh nhân được chẩn đoán bệnh lý u sợi mạch vòm họng. 
Kết quả nội soi và cắt lớp vi tính xác định bệnh nhân mắc u sợi mạch vòm họng hiếm gặp. Ảnh: Lê Phương.
Phó giáo sư Lâm Huyền Trân, Trưởng Khoa Tai Mũi Họng - Mắt cùng hội chẩn để đưa ra phương án điều trị. Mổ bóc tách u sợi mạch vòm họng là một đại phẫu của các bác sĩ tai mũi họng. Nếu mổ hở bệnh nhân cần phải hạ huyết áp chỉ huy về 0. Khi đó để hạn chế máu lưu thông về vùng mặt, kíp mổ phải giải quyết khối u trong vòng 1-5 phút.
Trường hợp này khối u kích thước lớn bám chắc vào xương mũi, lan dần xuống vùng họng, gây chèn ép khiến bệnh nhân khó thở nên có thể dẫn đến nhiều biến cố trên bàn mổ. Cuối cùng các bác sĩ quyết định mổ nội soi bóc tách u, không cần phải hạ huyết áp chỉ huy. Trải qua hơn 4 giờ phẫu thuật, kíp mổ đã bóc trọn vẹn khối u. Nhờ mổ nội soi, bệnh nhân tránh sẹo lớn vùng mặt, giảm nguy cơ mất máu và hạn chế mất xương vùng mặt.
Bệnh nhân hồi phục sau hai tuần điều trị. Ảnh: Lê Phương.
Bác sĩ Đặng Trung Hiếu, Phó Khoa Tai Mũi Họng - Mắt cho biết u sợi mạch vòm họng là bệnh hiếm gặp, nam nhiều hơn nữ và thường biểu hiện ở tuổi dậy thì. Bệnh thường gây nghẹt mũi, chảy máu mũi tái phát, dai dẳng. Dù là u lành tính nhưng theo thời gian, kích thước khối u có thể phát triển lớn lên, dọa vỡ gây xuất huyết ồ ạt, nguy cơ ảnh hưởng đến tính mạng.
Chảy máu mũi là triệu chứng dễ bị bỏ qua, có thể là dấu hiệu cảnh báo nhiều bệnh nặng cần can thiệp sớm. Khi chảy máu mũi có chiều huớng tái phát, dai dẳng, cần nhanh chóng khám ở bác sĩ tai mũi họng để được tư vấn và thăm khám kỹ càng.
Gia đình bệnh nhân khá khó khăn, mồ côi cha, mẹ làm ruộng, đang đi học nên không đủ tiền điều trị. Bác sĩ Võ Đức Chiến, Giám đốc Bệnh viện Nguyễn Tri Phương đã kêu gọi Quỹ Từ Tâm hỗ trợ khoảng 50 triệu đồng điều trị cho bệnh nhân.
**Lê Phương**

[[[PLACEHOLDER_HEADING]]]# TP.HCM: Áp dụng thành công kỹ thuật mổ không đau an toàn

Khoa Chấn thương Chỉnh hình – BV Nguyễn Tri Phương TP.HCM đã áp dụng thành công mô hình đa mô thức trong gây mê nhằm giúp giảm đau trước, trong và sau cuộc mổ đối với các bệnh nhân cần phẫu thuật[ thay khớp](http://congan.com.vn/doi-song/suc-khoe/tphcm-ap-dung-thanh-cong-ky-thuat-mo-khong-dau-an-toan_41423.html) gối hoặc khớp háng.
Theo TS BS Tăng Hà Nam Anh, Trưởng khoa Chấn thương Chỉnh hình (BV Nguyễn Tri Phương), mô hình giảm đau đa mô thức trong xu hướng gây mê hiện đại này bao gồm sử dụng phối hợp thuốc kháng viêm, giảm đau trước, trong và sau cuộc mổ, gây tê tủy sống, gây tê ngoài màng cứng bằng thuốc tê phối hợp liều nhỏ thuốc giảm đau cho phẫu thuật chi dưới kết hợp với chườm lạnh và tập vật lí trị liệu massage sau mổ, đặc biệt trong phẫu thuật thay khớp gối và khớp háng trong chuyên khoa chấn thương chỉnh hình.
Với phương pháp này, bệnh nhân trải qua cuộc [mổ không đau](http://congan.com.vn/doi-song/suc-khoe/tphcm-ap-dung-thanh-cong-ky-thuat-mo-khong-dau-an-toan_41423.html) an toàn, ít tai biến và chi phí thấp. Ảnh minh họa
Đau trong và sau khi phẫu thuật thay khớp háng hay khớp gối là nỗi ám ảnh của bệnh nhân và là một trong những nguyên nhân khiến bệnh nhân không muốn thay khớp lần 2 dù kết quả thay khớp rất tốt.
Trong khi đó, gây mê làm vô cảm toàn thân thường đối mặt với nhiều tai biến – biến chứng của việc đặt nội khí quản, nhiều thuốc dùng trong gây mê, liệt ruột kéo dài, nằm bất động lâu… bất lợi cho bệnh nhân lớn tuổi. Theo thống kê, tỷ lệ sốc phản vệ do thuốc gây mê khoảng 1/10.000 – 1/20.000 trong đó do thuốc ngủ là 7,4%, thuốc giãn cơ 62%, nhựa 16,5%, thay thế huyết tương 3,6%...
Bên cạnh đó, tuổi cao là một trong những yếu tố làm tăng nguy cơ bệnh tật. Những biến đổi sinh lý bệnh trong quá trình tích tuổi và bệnh lý kèm theo về nội khoa như: tăng huyết áp, thiếu máu cơ tim, tiểu đường, tắc nghẽn phổi (COPD) mạn tính, suy thận mạn, thiếu máu, suy dinh dưỡng… còn thường làm nguy cơ gây mê – phẫu thuật gia tăng đáng kể.
Chính vì vậy, việc áp dụng kỹ thuật giảm đau đa mô thức này rất phù hợp với bệnh nhân lớn tuổi vừa giảm liều thuốc gây tê vừa đảm bảo duy trì giảm đau ngay từ trong và sau mổ 3 ngày.
Từ tháng 8/2014 đến 9/2016, Khoa Chấn thương Chỉnh hình đã áp dụng phương thức điều trị giảm đau đa mô thức cho 351 bệnh nhân có chỉ định phẫu thuật thay khớp háng hay thay khớp gối nhân tạo.
Với phương pháp này, bệnh nhân trải qua cuộc mổ không đau an toàn, ít tai biến và chi phí thấp. Tỷ lệ thành công trong mổ không đau sau mổ là 96,3%. Đau nhẹ sau mổ 3,7%. Một số biến chứng không nghiêm trọng có thể gặp phải như mạch chậm, rét run, bí tiểu…
Phương pháp đa mô thức này đã góp phần giảm thiểu tỷ lệ biến chứng tắc mạch và tỷ lệ tử vong cho người bệnh đến 30% so với phương pháp vô cảm toàn thân.
351 bệnh nhân[ phẫu thuật không đau](http://congan.com.vn/doi-song/suc-khoe/tphcm-ap-dung-thanh-cong-ky-thuat-mo-khong-dau-an-toan_41423.html), mềm cơ tốt, an toàn, tạo điều kiện thuận lợi cho cuộc mổ thành công. Sau mổ, vì không đau nghiêm trọng, nên bệnh nhân nhanh chóng tiếp cận với sự luyện tập cơ – khớp, giúp nhiều cho bệnh nhân trong suốt quá trình tập vật lý trị liệu. Bệnh nhân nhanh chóng phục hồi chức năng vận động khớp sau mổ, góp phần giảm tỷ lệ đau mạn tính sau mổ. Chi phí toàn bộ 3 ngày điều trị khoảng 500.000 đồng, thấp hơn gấp 3 – 4 lần so với gây mê toàn thân hay dùng kỹ thuật giảm đau khác.
Ngô Đồng

[[[PLACEHOLDER_HEADING]]]# Lớp chia sẻ kinh nghiệm về nghiên cứu khoa học 

Để giúp cho các nhân viên Bệnh viện Nguyễn Tri Phương thuận lợi hơn trong công tác nghiên cứu khoa học, cụ thể là:
- Cách tính cỡ mẫu cho nghiên cứu
- Cách đặt giả thiết trong nghiên cứu
PGS.TS Đỗ Văn Dũng đã đến chia sẻ những kinh nghiệm để có thể thiết kế nghiên cứu một cách khoa học và hiệu quả
Lớp học diễn ra đã đạt được mục tiêu ban đầu, nhận được nhiều phản hồi tích cực của học viên tham gia.
Nghiên cứu khoa học đóng vai trò quan trọng trong việc nâng cao chất lượng khám chữa bệnh, tìm ra những vấn đề cần đầu tư nghiên cứu để phân bổ nguồn lực về con người và trang thiết bị nhằm đem lại hiệu quả cao nhất. "Luôn coi trọng chất lượng của nghiên cứu khoa học để cải tiến không ngừng, đó là quan điểm lâu nay của Ban Giám Đốc bệnh viện" - trích lời của TS.BS Nguyễn Đình Xướng - phó giám đốc bệnh viện tại lớp học.
Trong tương lai, bệnh viện sẽ tiếp tục đầu tư vào mảng nghiên cứu, và không ngừng tạo cơ hội giúp các nhân viên có thể thực hiện các nghiên cứu ngày càng hiệu quả và khoa học hơn./.
BS Lương Công Minh - phòng Quản Lý Chất Lượng

[[[PLACEHOLDER_HEADING]]]# Tri ân mạnh thường quân và sinh hoạt về kỹ năng giao tiếp tại bệnh viện tháng 9/2018.

Thời gian qua, Bệnh viện Nguyễn Tri Phương được nhiều mạnh thường quân tin tưởng đồng hành cùng trong việc chăm sóc, giúp đỡ cho bệnh nhân nghèo gặp khó khăn trong điều trị.
Để ngỏ lời tri ân các mạnh thường quân, bệnh viện Nguyễn Tri Phương đã tổ chức kết hợp cùng chia sẻ những góc nhìn về y đức trong hoạt động nâng cao kỹ năng giao tiếp ứng xử tại bệnh viện năm 2018. Đến với hoạt động này, Bệnh viện được đón tiếp đại diện từ Quỹ Từ Tâm, Quỹ Tâm Nguyện Việt và thượng tọa Thích Thiện Thuận.
Cũng trong hoạt động này, thượng thọa Thích Thiện Thuận đã chia sẻ y đức dưới góc nhìn Phật giáo. Bằng những chia sẻ dí dỏm, vui tươi mà cũng rất đời - rất người, thượng tọa đã đem lại nhiều sự sẻ chia và lòng thấu cảm nơi nhân viên y tế. Một góc nhìn nhân văn và từ ái của Phật giáo đã giúp tô đẹp hơn những khía cạnh về y đức trong đời sống hôm nay.
Tin, ảnh: Ban truyền thông bệnh viện./.

[[[PLACEHOLDER_HEADING]]]# TẦM SOÁT CHẬM TĂNG TRƯỞNG CHIỀU CAO MIỄN PHÍ

**Phụ huynh có nhu cầu tầm soát chậm tăng trưởng chiều cao ở trẻ, có thể đăng ký theo 2 cách:**
- Trực tiếp đăng ký và khám miễn phí tại bệnh viện vào các buổi sáng thứ Bảy và Chủ nhật trong thời gian tổ chức chương trình
- Gọi điện thoại theo hotline **0915.324.754**(giờ hành chính: 8h-16h từ thứ Hai đến Thứ Sáu hằng tuần).
**Trẻ tham gia tầm soát sẽ được khám những gì?**
- Trẻ sẽ được khám lâm sàng và chụp X-Quang xương bàn tay khi có chỉ định để được đánh giá tuổi xương. Từ đó, các bác sĩ sẽ tư vấn về vấn đề phát triển chiều cao của trẻ. Những trường hợp nghi ngờ chậm tăng trưởng chiều cao sẽ được hướng dẫn các bước xử trí tiếp theo.
[**TS.BS**](http://ts.bs/)**Trần Quang Khánh**
_Trưởng khoa nội tiết bệnh viện Nguyễn Tri Phương & Chủ nhiệm bộ môn nội tiết Đại Học Y Dược Thành Phố Hồ Chí Minh_
_Đang thăm khám và tư vấn cho bệnh nhân chậm tăng trưởng chiều cao_
**Vì sao nên tầm soát chậm tăng trưởng chiều cao ở trẻ trước dậy thì?**
- Thông thường, trẻ mới sinh có chiều cao 48-52cm, trong năm đầu bé tăng khoảng 20-25cm, sang năm thứ 2 tăng 12cm, năm thứ 3 tăng 10 cm, năm thứ 4 tăng 7cm. Từ năm 4-11 tuổi, trẻ sẽ tăng trung bình 6cm/năm. Đến tuổi dậy thì, bé gái sẽ tăng khoảng từ 6-10cm/năm, bé trai từ 6,5-11cm/năm. Nếu trẻ không đạt mức tăng trưởng chiều cao bình thường đó, cha mẹ nên nghĩ ngay đến việc cho trẻ đi khám và tầm soát chậm tăng trưởng chiều cao sớm.
- Có nhiều nguyên nhân dẫn đến chậm tăng trưởng chiều cao ở trẻ có thể kể đến như: Thiếu nội tiết tố tăng trưởng hay còn gọi là hormone tăng trưởng; Suy tuyến giáp; Tiền sử gia đình; Thai nhi suy dinh dưỡng; Trẻ sinh ra nhẹ cân; Hội chứng Turner; Hội chứng Down; Một số loại thiếu máu, Bệnh mãn tính (Thận, tim, tiêu hóa, hoặc bệnh phổi), hậu quả của việc sử dụng 1 loại thuốc khi mang thai của bà mẹ, Dinh dưỡng kém... Trong đó, tỉ lệ thiếu hormone tăng trưởng ước tính chỉ chiếm khoảng 1/4.000 - 1/10.000 trẻ nhưng đây là một trong những nguyên nhân quan trọng dẫn đến chậm tăng trưởng ở trẻ em. 
- Thiếu hormone tăng trưởng xảy ra khi cơ thể gặp vấn đề về sản xuất và phóng thích hormone tăng trưởng không đủ, dẫn đến một tình trạng gọi là thiếu hormone tăng trưởng. Thiếu hormone tăng trưởng có thể do bẩm sinh hoặc mắc phải do tổn thương tuyến yên, chấn thương đầu nặng, u não hoặc nhiễm trùng dạng viêm màng não và viêm não… Thiếu hormone tăng trưởng có thể bẩm sinh hoặc mắc phải, xảy ra ở bất kỳ thời điểm nào. Trong một số trường hợp việc thiếu hormone tăng trưởng không xác định được nguyên nhân.
- Hormone tăng trưởng là yếu tố quan trọng cho sự phát triển toàn diện của trẻ em và là hormone đóng vai trò quyết định về chiều cao trong giai đoạn phát triển của trẻ. Ở Việt Nam, trong những năm gần đây, việc chuẩn hóa quy trình chẩn đoán và điều trị chậm tăng trưởng chiều cao bằng hormone tăng trưởng đã bắt đầu được quan tâm và ngày càng phát triển. Ngoài ra, việc điều trị bằng hormone tăng trưởng không chỉ áp dụng cho trường hợp trẻ chậm tăng trưởng chiều cao do thiếu hormone tăng trưởng mà còn được chỉ định trong các trường hợp gây ra do những nguyên nhân khác như: hội chứng Turner, bệnh thận mãn, trẻ sinh ra nhỏ hơn so với tuổi thai… Việc điều trị bằng hormone tăng trưởng có thể giúp trẻ cải thiện được chiều cao.
- Khi điều trị thay thế bằng hormone tăng trưởng, để đạt được hiệu quả tối ưu thì việc điều trị đúng thời điểm, đúng liều lượng là rất quan trọng. Trẻ nên được phát hiện sớm và được điều trị trước tuổi dậy thì. Tốt nhất là điều trị trong khoảng độ tuổi từ 4-13 tuổi. Nếu qua “thời gian vàng” này, các sụn xương của trẻ sẽ đóng lại, dẫn đến việc dùng hormone tăng trưởng sẽ không còn tác dụng. Do đó, các bậc phụ huynh nên cho trẻ tầm soát sớm để điều trị kịp thời.

[[[PLACEHOLDER_HEADING]]]# Khen tặng nhiều tập thể xuất sắc 2017 và trao huy chương 30 năm tuổi Đảng

Bệnh viện Nguyễn Tri Phương đã chứng kiến việc trao huy chương 30 năm tuổi Đảng cho đồng chí Phan Văn Nghiệm - Phó Giám Đốc bệnh viện, ghi nhận một quãng thời gian đầy tự hào của đồng chí đã gắn bó và phấn đấu cho lý tưởng cách mạng.
Đồng thời, Giám đốc Bệnh viện cũng đã trao nhiều bằng khen vì thành tích hoạt động xuất sắc trong năm 2017 cho các khoa, phòng.
Xin trân trọng chúc mừng tất cả cá cá nhân, tập thể vì những thành tích đáng ngợi khen.
Ban truyền thông BV Nguyễn Tri Phương

[[[PLACEHOLDER_HEADING]]]# HỘI NGHỊ KHOA HỌC KỸ THUẬT THƯỜNG NIÊN BỆNH VIỆN NGUYỄN TRI PHƯƠNG LẦN THỨ XVI NĂM 2018

**DOWNLOAD**
HỘI NGHỊ KHOA HỌC KỸ THUẬT THƯỜNG NIÊN BỆNH VIỆN NGUYỄN TRI PHƯƠNG LẦN THỨ XVI NĂM 2018 [tải file tại đây.](https://drive.google.com/open?id=19KaHUZyZIzzFv38jMfPt3fenJ6AWCqVE)

[[[PLACEHOLDER_HEADING]]]# Khai trương phòng tư vấn bệnh lý đái tháo đường và tăng huyết áp

Chăm sóc sức khỏe toàn diện là mục tiêu mà BV NTP luôn theo đuổi. Toàn diện ở đây nghĩa là việc chăm sóc sức khỏe bao hàm cả khám – chẩn đoán – điều trị – tư vấn – giáo dục lối sống – chiến lược theo dõi định kỳ. Bệnh không lây đã và đang ngày càng nhiều hơn, trong đó có 02 bệnh phổ biến được nhắc đến rất nhiều thông qua các chương trình truyền thông sức khỏe, đó là bệnh đái tháo đường và tăng huyết áp. Vì lý do đó, vấn đề chăm sóc sức khỏe toàn diện đối với hai bệnh lý này ngày càng quan trọng
Bệnh đái tháo đường là một bệnh mạn tính gần như theo bệnh nhân suốt đời. Trước đây, bệnh nhân mắc bệnh thường ở tuổi đã khá cao (50 - 60 tuổi) và mất sau khi mắc bệnh khoảng chừng 10, 15 năm. Tuy nhiên, hiện nay, tuổi bệnh nhân mắc bệnh đái tháo đường ngày càng trẻ, không ít bệnh nhân ở độ tuổi 40 hoặc trẻ hơn. Đồng thời, theo tuổi thọ ngày càng cao, quãng thời gian sốngcùng bệnh ngày càng kéo dài theo - lên tới hơn 20 năm. Điều này cũng đặt ra vấn đề tư vấn cho bệnh nhân trở nên ngày càng quan trọng, vì hơn bất cứ bác sĩ nào, bệnh nhân sẽ là người nắm rõ nhất những vấn đề của chính họ và quản lý tốt nhất biến chứng sớm nếu được cung cấp đầy đủ thông tin.
Với tất cả những nhu cầu đó, Bệnh viện Nguyễn Tri Phương đã phối hợp với công ty Servier để xây dựng phòng tư vấn đái tháo đường và tăng huyết áp, từ đó tăng cường khả năng tiếp cận của bệnh nhân đối với các thông tin y tế chính thống cũng như sự tư vấn chuyên nghiệp hơn từ nhân viên y tế.
BS Võ Đức Chiến - Giám đốc Bệnh viện - bày tỏ mong muốn thời gian sắp đến sẽ còn nhiều phòng tư vấn được thành lập để đem lại nhiều hơn nữa những lợi ích thiết thực và tăng sự hài lòng cho người bệnh. 
Tin và ảnh: BS Lương Công Minh - Phòng Quản Lý Chất Lượng./.
[new88.net](http://new88.net/)

[[[PLACEHOLDER_HEADING]]]# Bệnh viện Nguyễn Tri Phương đưa nội dung rửa tay vào tiêu chí thi đua của các khoa/phòng

Nhận định về tầm quan trọng của việc vệ sinh tay, BS. Lê Văn Tuân – Trưởng Văn phòng Tổ chức Y tế Thế giới tại TP. HCM cho biết hiện nay các bệnh truyền nhiễm gây dịch đang vào mùa với số ca mắc cao và Ngành Y tế cũng đã có bài học kinh nghiệm trong vụ dịch cúm A/H1N1 năm 2009 và vụ dịch sởi tại Bệnh viện Nhi Trung ương năm 2014 với gần 1300 ca mắc, hơn 100 ca tử vong mà hầu hết là do lây nhiễm chéo trong bệnh viện. Nếu nhân viên y tế tuân thủ việc rửa tay và thực hiện phòng chống nhiễm khuẩn sẽ đề phòng và ngăn chặn được các vụ dịch này. Điều này cũng được chứng minh nếu các cơ sở y tế thực hiện việc rửa tay tại 5 thời điểm sẽ làm giảm 50% số ca nhiễm trùng.Nhằm nâng cao chất lượng khám chữa bệnh tại Bệnh viện Nguyễn Tri Phương thông qua việc làm giảm tỉ lệ nhiễm khuẩn bệnh viện, góp phần nâng cao ý thức, hành vi của nhân viên y tế tại bệnh viện về công tác vệ sinh tay, ngay từ đầu năm 2018, Khoa Kiểm soát Nhiễm khuẩn Bệnh viện Nguyễn Tri Phương đã thực hiện chiến dịch “Rửa tay góp phần giảm nhiễm khuẩn bệnh viện” với nhiều hoạt động khác nhau như huấn luyện - tuyên truyền (lồng ghép vào buổi huấn luyện về kiểm soát nhiễm khuẩn) để phòng ngừa nhiễm khuẩn trong ngoại khoa, hướng dẫn về kiểm soát nhiễm khuẩn cho bệnh nhân lọc thận với đối tượng là nhân viên y tế trong và ngoài bệnh viện. Ngoài ra, trong các buổi họp hội đồng thân nhân bệnh nhân, Bệnh viện cũng đã lồng ghép nội dung tuyên truyền hướng dẫn công tác vệ sinh tay đến thân nhân bệnh nhân. Bệnh viện cũng luôn tạo điều kiện thuận lợi cho nhân viên y tế, thân nhân bệnh nhân có thể vệ sinh tay một cách tốt nhất như bố trí các chai dung dịch vệ sinh tay tại các vị trí thuận tiện (hành lang bệnh viện, phòng bệnh cũng như các giường bệnh nặng), gắn bảng hướng dẫn vệ sinh tay tại các bồn rửa tay. Khoa Kiểm soát nhiễm khuẩn còn tiến hành khảo sát ý kiến của nhân viên y tế về các dung dịch vệ sinh tay đang được sử dụng tại bệnh viện, để từ đó có thể đề xuất để Bệnh viện chọn lựa được những dung dịch vệ sinh tay tốt, đáp ứng được nhu cầu giúp nhân viên y tế được thuận lợi, thoải mái khi vệ sinh tay.
Nhận định về tầm quan trọng của việc vệ sinh tay, BS. Lê Văn Tuân – Trưởng Văn phòng Tổ chức Y tế Thế giới tại TP. HCM cho biết hiện nay các bệnh truyền nhiễm gây dịch đang vào mùa với số ca mắc cao và Ngành Y tế cũng đã có bài học kinh nghiệm trong vụ dịch cúm A/H1N1 năm 2009 và vụ dịch sởi tại Bệnh viện Nhi Trung ương năm 2014 với gần 1300 ca mắc, hơn 100 ca tử vong mà hầu hết là do lây nhiễm chéo trong bệnh viện. Nếu nhân viên y tế tuân thủ việc rửa tay và thực hiện phòng chống nhiễm khuẩn sẽ đề phòng và ngăn chặn được các vụ dịch này. Điều này cũng được chứng minh nếu các cơ sở y tế thực hiện việc rửa tay tại 5 thời điểm sẽ làm giảm 50% số ca nhiễm trùng.
BS. CK2. Nguyễn Hữu Hưng – Phó Giám đốc Sở Y tế đã gửi đến Ban giám đốc cùng toàn thể nhân viên Bệnh viện với mong muốn trong bối cảnh tình hình dịch bệnh hiện nay đang diễn ra trên diện rộng thì Ngày hội vệ sinh tay không chỉ là dịp để chạy theo phong trào mà sẽ là công tác thường xuyên, liên tục của Bệnh viện để tăng cường sự tuân thủ của nhân viên y tế. Việc nhận thức đúng ích lợi của việc vệ sinh tay trong công tác khám chữa bệnh sẽ mang lại nhiều lợi ích. Việc rửa tay không chỉ là thường xuyên mà còn phải đúng cách và đúng thời điểm. Mới đây, Sở Y tế đã có cuộc khảo sát khoảng 90 bệnh viện công lập và ngoài công lập thì hơn 90% bệnh viện có trang bị các dung dịch vệ sinh tay. Tuy nhiên, có khoảng 16% phòng cấp cứu hoặc phòng chăm sóc đặc biệt của một số bệnh viện chưa đặt các dung dịch rửa tay nhanh, hoặc có nhưng rất ít. Qua đó, BS. Nguyễn Hữu Hưng cũng nhắc nhở Bệnh viện Nguyễn Tri Phương nên thường xuyên lưu ý và kiểm tra dung dịch rửa tay nhanh ở các khoa phòng này. Nếu xác định đây là công tác quan trọng, Bệnh viện cũng nên tổ chức kiểm tra đánh giá thường xuyên để xem các khoa/phòng có thực hiện thường xuyên không, khi có kết quả phải công khai tỷ lệ tuân thủ của các khoa/phòng để có kế hoạch điều chỉnh kịp thời.

[[[PLACEHOLDER_HEADING]]]# BV. Nguyễn Tri Phương: Hỗ trợ 40 triệu đồng, cứu mạng một phụ nữ neo đơn bị suy tim

Suckhoedoisong.vn - BS. CKII Nguyễn Liên Nhựt - Phó khoa Tim mạch (BV. Nguyễn Tri Phương TP.HCM) cho biết, chị Võ Thị Ngọc Lan (48 tuổi, thuê trọ ở Q. 8) nhập viện do phù phổi, nhồi máu cơ tim, suy tim, huyết áp tăng rất cao 260/120mmHg.
Đây là lần thứ hai bệnh nhân vào viện, trước đó, nhiều lần bệnh nhân nhập cấp cứu BV. Quận 10 và BV. Nhân dân 115 vì nhồi máu cơ tim, phù phổi cấp. Do hoàn cảnh neo đơn và vô cùng khó khăn, nên bệnh nhân không đủ điều kiện can thiệp mạch vành.
Nằm trong phòng Cấp cứu Khoa Tim mạch, BV. Nguyễn Tri Phương, chị Ngọc Lan cho biết chị vốn bị bệnh đái tháo đường từ những năm 1997. Cách đây 6 tháng trong một lần rửa chén cho một nhà hàng, chị đột nhiên mệt, lên cơn đau tim và ngất xỉu, được nhân viên hỗ trợ đưa vào BV Nhân dân 115. Tại đây chị được chẩn đoán bị nhồi máu cơ tim, tắc mạch vành, cần phải can thiệp cứu chữa, chi phí thanh toán sau bảo hiểm khoảng hơn 40 triệu đồng. Không tiền điều trị, chị quay về với căn phòng trọ và tiếp tục làm thuê công nhật cho các nhà hàng.
Bệnh nhân còn quá trẻ, nếu không can thiệp mạch vành, bệnh nhân này từ từ đi đến suy tim giai đoạn cuối rồi có thể tử vong.
“Cách giải quyết triệt để nhất là chụp mạch vành và can thiệp mạch vành bằng cách nong để tái tưới máu trở lại. Vấn đề quan trọng là bệnh nhân rất nghèo, không có gia đình. Những lần trước, chúng tôi cũng muốn can thiệp nhưng bệnh nhân bỏ về vì không có tiền. Đi các bệnh viện khác cũng vậy. Một ca can thiệp mạch vành như vậy ước tính khoảng 70 - 80 triệu đồng”, BS. Liên Nhựt cho biết.
Do đó, ban giám đốc và các bác sĩ khoa Nội tim mạch BV. Nguyễn Tri Phương cùng quỹ Từ Tâm đã quyết định hỗ trợ bệnh nhân nghèo 40 triệu đặt stent phủ thuốc. Bệnh nhân này bị cao huyết áp, đái tháo đường lâu năm, lại bị hẹp tắc ở nhiều nơi, các bác sĩ quyết định can thiệp nhánh mạch vành quan trọng nhất. Sau khi can thiệp đặt stent mạch vành, chị Lan hết khó thở, những triệu chứng suy tim được cải thiện, các chỉ số sinh hiệu dần ổn định. Sau khi xuất viện, chị phải thăm khám uống thuốc định kỳ mỗi tháng, kiểm soát tốt huyết áp, đường máu nhằm ngăn ngừa nguy cơ tái hẹp.
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh

[[[PLACEHOLDER_HEADING]]]# ️ Suýt chết vì sặc nguyên múi mít vào đường thở

Bệnh nhân có tiền sử tai biến mạch máu não, nằm một chỗ. Sau khi người nhà cho ăn nguyên một múi mít ướt, sau đó bệnh nhân bị nghẹn, gồng người, thở hước.
BV Nguyễn Tri Phương tiếp nhận một trường hợp hóc dị vật đường thở nghiêm trọng. Bệnh nhân Trần Văn S. (1956, Bình Chánh) vốn có tiền sử bị tai biến mạch máu não, nằm một chỗ, ăn uống do người nhà chăm sóc. Tuy nhiên, do thiếu kỹ năng chăm sóc, nên sáng ngày 23/1, người nhà cho bệnh nhân ăn nguyên một múi mít ướt, sau đó bệnh nhân bị nghẹn, gồng người, thở hước.
Ngày 25/1/2018, TS. BS. Trần Văn Thi, Trưởng Khoa Nội Hô hấp (BV Nguyễn Tri Phương) vừa cảnh báo như trên.
Ngay lập tức người nhà đưa vào cấp cứu tại BV Bình Chánh. Tại đây các bác sĩ chẩn đoán hốc dị vật đường thở, đặt nội khí quản trợ giúp thở và chuyển lên BV Nguyễn Tri Phương. Bệnh nhân nhập viện trong tình trạng lơ mơ, bóp bóng qua nội khí quản, suy hô hấp nặng.
“Chúng tôi tiếp tục bóp bóng đồng thời chụp MSCT ngực để xác định vị trí dị vật. Bác sĩ điều trị Phan Vĩnh Khang đã tiến hành nội soi phế quản, thấy múi mít nằm gọn trong phế quản, bít lòng phế quản. Đây là mít ướt nên thường khó lấy hơn mít khô vì nó nhão, nên bác sĩ điều trị phải phối hợp kỹ thuật vừa gắp vừa hút để lấy dị vật ra ngoài,” BS. Thi cho biết.
_Múi mít gây tắc nghẽn đường thở khiến bệnh nhân suy hô hấp ngay lập tức_
Hiện tại, sau khi lấy được dị vật ra thì phổi đã suy hô hấp, thể trạng suy kiệt, đề kháng rất kém, bệnh nhân vẫn lơ mơ, nhưng oxy máu cải thiện hơn.
Các chuyên gia khuyến cáo dị vật đường thở rất thường gặp, dễ xảy ra trên các đối tượng có rối loạn tri giác như say rượu, bệnh nhân tai biến phản xạ nuốt không tốt, khi cho ăn uống không đúng cách dễ sặc vào phổi. Các loại dị vật thường rất nguy hiểm nếu bị sặc vào phổi. Nếu dị vật nhỏ bệnh nhân thường ho sặc sụa và dễ bỏ qua giai đoạn đó. Đối với dị vật lớn, bệnh nhân có thể bị rơi vào suy hô hấp ngay.
_Bệnh nhân Trần Văn S. được chăm sóc tại khoa Nội Hô hấp, BV Nguyễn Tri Phương_
Điều may mắn là bệnh nhân S. vào viện sớm nên có thể lấy dị vật ra nhanh chóng, không “rơi rớt”. Tuỳ tính chất, dị vật như hạt có ngạch (quả sapoche hay còn gọi là hồng xiêm) khi lấy có thể xước, dính vào niêm mạc đường dẫn khí, dẫn đến nguy cơ tổn thương cao; hoặc các loại hạt tròn nhỏ (đậu phụng) để lâu sẽ mũn, nguy cơ không lấy hết được gây ra các ổ nhiễm trùng, tắc đường dẫn khí nhỏ, tình trạng viêm phổi tái đi tái lại nhiều lần.
Bên cạnh đó, TS. BS. Thi khuyến cáo, các bệnh nhân bị tai biến cần được chăm sóc và cho ăn uống đúng cách, như bệnh nhân này, phản xạ nuốt kém lại nằm liệt, người nhà cho ăn nguyên một múi mít rất dễ gây sặc. Vì vậy, thức ăn nên cắt nhỏ, làm mềm, thậm chí ở dạng loãng giúp bệnh nhân ăn uống được, hấp thu đầy đủ dưỡng chất tránh suy kiệt.
**An Quý**

[[[PLACEHOLDER_HEADING]]]# BV Nguyễn Tri Phương miễn phí hoàn toàn cho bệnh nhân vụ cháy Carina

“Ngay từ trong đêm cấp cứu, bệnh viện còn cung cấp đồ ăn, nước uống và sữa cho các nạn nhân ngoài công tác điều trị, chăm sóc thuốc men. Sau vụ cháy, bệnh viện liên tục tiếp nhận thêm 43 lượt cư dân Carina tới khám bệnh trong tuần đầu tiên sau vụ cháy và cũng miễn phí hoàn toàn,” BS. Linh cho biết.
_BV Nguyễn Tri Phương điều trị hoàn toàn miễn phí cho bệnh nhân của vụ thảm cháy Carina._
Ban Giám đốc BV Chợ Rẫy cũng đã có chỉ đạo tạm thời chưa thu tạm ứng hay viện phí của các bệnh nhân của vụ thảm cháy Carina, kể cả bệnh nhân đã xuất viện.
Cập nhật tình hình mới nhất của các bệnh nhân trong vụ cháy Carina điều trị tại BV Chợ Rẫy vào chiều ngày 3/4 như sau hiện tại, còn 6 bệnh nhân nằm điều trị gồm: 3 bệnh nhân tại khoa Phỏng (2 ca theo dõi phỏng hô hấp - Phạm Thái Hồng Nghĩa, Nguyễn Huỳnh Phước ), chiến sĩ PCCC Trần Tuấn Thanh.Tại khoa Hồi sức Cấp cứu còn 3 bệnh nhân: Lê Phan Trọng Nhân (tỉnh, thở oxy qua mở khí quản, sinh hiệu ổn), Trần Yến Minh (thở oxy qua mở khí quản), bệnh nhân Đào Thị Kim Long (đang thở máy ).
* Cũng trong ngày 3/4, thông tin từ ban đầu từ BV Chợ Rẫy cho biết, 2 bệnh nhân trong vụ tai nạn hàng loạt trên đường cao tốc Long Thành- Dầu Giây vừa được chuyển đến khoa Cấp cứu của BV Chợ Rẫy. Bệnh nhân Nguyễn Thị Ngọc Dung (sinh năm 1984) bị chấn thương sọ não, bệnh nhân Đinh Thị Mùi (sinh năm 1943) gãy xương đùi trái. Được biết, ghi nhận ban đầu tại hiện trường vụ tai nạn giao thông liên hoàn trên cao tốc Long Thành - Dầu Giây, hàng loạt xe ở cả hai chiều bị va chạm, ít nhất 8 xe tông vào nhau, và nhiều người bị thương cần đưa đi cấp cứu; trong đó va chạm nặng nhất là 1 xe bồn cùng 1 xe khách 48 chỗ. Theo các cơ quan chức năng, tai nạn có thể do người dân đốt đồng hai bên đường khiến khói bao phủ, che phủ tầm nhìn của các lái xe.
An Quý
Nguồn: **Suckhoedoisong.vn**

[[[PLACEHOLDER_HEADING]]]# Dịch vụ lấy mẫu xét nghiệm tại nhà

Hiện tại, vì tình trạng quá tải, bệnh nhân khi muốn lấy mẫu xét nghiệm tại bệnh viện thường phải chờ đợi trong một quãng thời gian nhất định, và chưa thật sự thoải mái. Một số bệnh nhân vì khó di chuyển, gia đình ít người chăm sóc nên mỗi lần đi đến cơ sở y tế lấy máu cũng khá vất vả, khó khăn.
Thấu hiểu nhu cầu và mong muốn của nhân dân về dịch vụ y tế tiện ích, Bệnh viện Nguyễn Tri Phương triển khai dịch vụ lấy mẫu xét nghiệm tại nhà. Sử dụng dịch vụ này, chỉ một cuộc điện thoại, nhân viên sẽ đến tận nhà để lấy mẫu, kết quả đến tay khách hàng ngay trong ngày. Không còn cảnh xếp hàng, không còn những mệt mỏi phiền hà vì ảnh hưởng công việc, và sự tiện lợi, an toàn, chính xác luôn được đặt lên hàng đầu. Ngoài ra đội ngũ nhân viên lành nghề, tận tâm của bệnh viện hạng I của Thành phố Hồ Chí Minh, hệ thống phòng xét nghiệm đạt chuẩn, giá cả hợp lý niêm yết rõ ràng, BV Nguyễn Tri Phương luôn mong muốn đem lại sự phục vụ tốt nhất cho bệnh nhân – khách hàng.
Dịch vụ lấy mẫu xét nghiệm tại nhà này xóa đi những e ngại, nỗi niềm người đi xét nghiệm, nhất là người già, trẻ nhỏ hay những người bận rộn. Thay vì e ngại chờ đợi, khách hàng khi sử dụng dịch vụ sẽ hài lòng về sự tiết kiệm thời gian, thái độ phục vụ của đội ngũ cán bộ trẻ năng động và tận tâm. Kết quả xét nghiệm từ cơ bản (đường máu, mỡ máu, men gan,…) đến chuyên sâu (marker ung thư, xét nghiệm miễn dịch…) luôn đảm bảo chính xác nhất và nhanh chóng nhất để rút ngắn thời gian chờ đợi. 
Nếu bạn cần kết quả xét nghiệm cho đợt tái khám sắp tới, theo dõi điều trị qua xét nghiệm nào đó hay đơn giản là muốn kiểm tra thông số sức khỏe của mình và người thân nhưng lại không thể đến bệnh viện, hãy gọi cho dịch vụ lấy mẫu xét nghiệm tại nhà của Bệnh viện Nguyễn Tri Phương! Chúng tôi luôn sẵn sàng phục vụ.
Số Điện thoại: Điều dưỡng Nguyễn Bá Trọng – 0902768728; Kỹ Thuật Viên Nguyễn Tú Anh – 0986274927
Form đăng ký online: 
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh

[[[PLACEHOLDER_HEADING]]]# Hầu hết nạn nhân vụ cháy chung cư ở Sài Gòn bị bỏng hô hấp nặng

##  [Cháy chung cư ở Sài Gòn, 13 người tử vong](https://vnexpress.net/tuong-thuat/thoi-su/chay-chung-cu-o-sai-gon-13-nguoi-tu-vong-3726671.html#ctr=related_news_click "Cháy chung cư ở Sài Gòn, 13 người tử vong") / [Nhân chứng vụ cháy 13 người chết: 'Chúng tôi bất lực tìm lối thoát'](https://vnexpress.net/tin-tuc/thoi-su/nhan-chung-vu-chay-13-nguoi-chet-chung-toi-bat-luc-tim-loi-thoat-3726690.html#ctr=related_news_click "Nhân chứng vụ cháy 13 người chết: 'Chúng tôi bất lực tìm lối thoát'")
Bác sĩ Phạm Thị Vân Thanh, Khoa Nội soi Bệnh viện Chợ Rẫy cho biết 10 bệnh nhân bỏng đường hô hấp rất nặng, gần như bỏng hô hấp 100%. Các bác sĩ đã nội soi để hút khói bụi đường hô hấp cho 5 bệnh nhân ngay từ 2h sáng, ba bệnh nhân sẽ xử trí hô hấp trong sáng nay để giải phóng đường thở. Bệnh nhân nặng nhất là nam thanh niên 35 tuổi, sau khi nội soi đang được hồi sức tích cực.
Hiện các bệnh nhân đã được giải phóng 80% đường thở, thở máy theo dõi, sau đó tiếp tục nội soi kiểm tra. Bác sĩ Thanh liên tục đứng nội soi cho các nạn nhân. 
Một nạn nhân được nội soi hô hấp tại phòng cấp cứu Bệnh viện Chợ Rẫy. Ảnh:_Lê Phương._  
---  
Tại Bệnh viện Nhi đồng 1, theo bác sĩ Đinh Tấn Phương, Trưởng Khoa Cấp cứu, có 10 em bé được đưa vào viện cấp cứu sau vụ cháy. Trong đó một bé 3 tuổi và một bé 10 tuổi bị suy hô hấp được Bệnh viện Quận 6 chuyển đến Nhi đồng 1 trong tình trạng nguy kịch. 8 bệnh nhi còn lại, bé nhỏ nhất chỉ mới 3 tháng tuổi, đang được theo dõi. Tất cả các bé đều bị ngạt khói, hít khói dẫn đến ngộ độc khí. 
Thông tin ban đầu từ người nhà, khi xảy ra cháy, các bé được người lớn bồng bế đưa ra ngoài hành lang để thoát ra ngoài nên bị hít phải khói, ngạt khói. Một thai phụ bị thương được đưa vào Bệnh viện Hùng Vương cấp cứu. 
Bệnh viện Nguyễn Tri Phương tiếp nhận cấp cứu 11 nạn nhân, tất cả đều trong tình trạng ho nhiều, khó thở, tức ngực. Bệnh viện cũng đang giữ 8 thi thể nạn nhân vụ cháy. 5 thi thể khác được chuyển đến Bệnh viện An Bình. Hiện 2 thi thể đã được xác nhận danh tính. 
Đại diện Trung tâm Cấp cứu 115 TP HCM cho biết đã huy động 8 xe cấp cứu từ các trạm vệ tinh 115 và các bệnh viện để hỗ trợ sơ cứu nạn nhân vụ cháy chung cư Carina Plaza quận 8. Các nạn nhân vào cấp cứu tại bệnh viện Nguyễn Tri Phương, Chợ Rẫy, Triều An, Bệnh viện Quận 6, Nhi đồng 1... Theo Sở Y tế TP HCM, đến hơn 9h sáng 23/3, số nạn nhân được đưa vào các bệnh viện cấp cứu là 59 người. 
Các bác sĩ khuyên trong trường hợp có hỏa hoạn, điều cần thiết phải làm là tránh hít khói. Trong phòng có thể dùng vật ướt chèn kín những khe cửa để ngăn khói không vào nhà gây tổn thương, mở toang những cửa không có khói vào. Nếu hành lang thông thoáng mới chạy ra hướng hành lang. Trường hợp bé bị ngạt khí gây thiếu ôxy não, ngưng tim ngưng thở thì cần được hồi sức cấp cứu hà hơi thổi ngạt.
2h sáng 23/3, chung cư Carina Plaza gồm 6 block cao 14-20 tầng ở quận 8 TP HCM phát cháy từ tầng hầm để xe. Dân cư hoảng loạn leo lên các tầng cao tìm cách thoát thân. 13 người chết trong hỏa hoạn.
**Lê Phương**
**Nguồn:** https://suckhoe.vnexpress.net

