## Trao quyền không chỉ là một nhiệm vụ quản lý – mà là một phép thử lãnh đạo

Bất công vẫn xảy ra khi quyền lực được phân phối theo cảm tính. Và đáng tiếc là: 3 kiểu người sau lại thường được trao quyền nhất.
**Người “rất ngoan”, rất vâng lời – nên dễ được cất nhắc**
Họ luôn đúng giờ, luôn nói dạ vâng, luôn vui vẻ làm theo.
Sếp thấy dễ chịu và trao quyền, vì nghĩ: “Cậu này đáng tin.”
Nhưng sếp không biết rằng: họ chỉ làm tốt trong giới hạn được bảo kê.
Giao quyền rồi mà vẫn phải kèm cặp từng li, kiểm duyệt từng chút, thì đó không phải là “được việc”. Trong khi đó, người thực sự chủ động, có tư duy phản biện lại dễ bị coi là “khó bảo” nên bị gạt ra ngoài.
**Người giỏi kể chuyện – nhưng dở kết quả**
Người này luôn biết cách “update tình hình” khiến bạn tin là họ đã nỗ lực hết sức.
Thành công thì kể lể chi tiết từng bước mình làm. Thất bại thì trình bày mạch lạc hàng loạt lý do khách quan.
Nghe rất logic. Rất có lý. Và sếp... gật đầu thông cảm.
Nhưng sếp không nhận ra: người có năng lực thực sự thì đang cắn răng sửa lỗi hệ thống, gánh hộ hậu quả trong im lặng.
**Người giống… một phiên bản trẻ của sếp**
Nguy hiểm nhất là khi sếp thấy “thằng này giống mình hồi trẻ” và bắt đầu nâng đỡ, trao quyền.
Không hẳn là sai. Nhưng hãy coi chừng: Bạn đang trao quyền dựa trên cảm xúc, sự đồng cảm, hoặc sự tự hào… hơn là một hệ tiêu chuẩn công bằng.
Và chính lúc ấy, người làm được - nhưng không “giống sếp” - sẽ thấy: năng lực không còn là yếu tố quyết định.
Khi đó, đội ngũ bắt đầu “làm cho sếp thích”, chứ không làm để tốt hơn.
_**Trao quyền không chỉ là một nhiệm vụ quản lý – mà là một phép thử lãnh đạo.**_
Có thể sếp nghĩ mình đang rất khách quan.
Nhưng mỗi quyết định trao quyền đều để lộ hệ giá trị mà sếp thật sự hướng tới: thông qua thứ sếp khen ngợi, bỏ qua, hay ngầm coi là “chuẩn”.
Vấn đề không nằm ở việc sếp chọn ai. Mà ở việc sếp đã loại ai ra khỏi cơ hội – chỉ vì họ không dễ khiến sếp hài lòng.

