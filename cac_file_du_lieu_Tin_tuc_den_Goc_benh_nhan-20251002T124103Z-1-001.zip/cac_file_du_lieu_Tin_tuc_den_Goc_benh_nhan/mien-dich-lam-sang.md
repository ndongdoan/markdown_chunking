## ️ Chăm sóc hệ đề kháng của chính mình

  * [Hệ miễn dịch thực ra là gì?](https://bvnguyentriphuong.com.vn/mien-dich-lam-sang/cham-soc-he-de-khang-cua-chinh-minh#h-min-dch-thc-ra-l-g)
  * [1. Chúng ta ăn uống cũng ảnh hưởng đến hệ miễn dịch](https://bvnguyentriphuong.com.vn/mien-dich-lam-sang/cham-soc-he-de-khang-cua-chinh-minh#1-chng-ta-n-ung-cng-nh-hng-n-h-min-dch)
  * [2. Chúng ta tập luyện cũng ảnh hưởng đến hệ miễn dịch](https://bvnguyentriphuong.com.vn/mien-dich-lam-sang/cham-soc-he-de-khang-cua-chinh-minh#2-chng-ta-tp-luyn-cng-nh-hng-n-h-min-dch)
  * [3. Chúng ta ngủ nghỉ có liên quan gì đến hệ miễn dịch?](https://bvnguyentriphuong.com.vn/mien-dich-lam-sang/cham-soc-he-de-khang-cua-chinh-minh#3-chng-ta-ng-ngh-c-lin-quan-g-n-h-min-dch)
  * [4. Chúng ta vui buồn, có cảm xúc thì liên quan gì đến hệ miễn dịch?](https://bvnguyentriphuong.com.vn/mien-dich-lam-sang/cham-soc-he-de-khang-cua-chinh-minh#4-chng-ta-vui-bun-c-cm-xc-th-lin-quan-g-n-h-min-dch)


## Hệ miễn dịch thực ra là gì?
Đó là một hệ thống quân đoàn bao gồm một số bộ phận, một số tế bào và một số loại protein đặc biệt cùng hỗ trợ nhau bảo vệ cơ thể khỏi sự xâm nhập của các loại vi khuẩn, virus, hay bất kỳ chất lạ nào.
Hệ thống này phân ra thành nhiều hàng rào từ ngoài da vào tận các tế bào. Do đó nó có thể chống lại bất cứ tác nhân nào, từ lớn như côn trùng, bụi,... cho đến nhỏ như vi khuẩn, virus,... Hiệu ứng được bảo vệ mà hệ miễn dịch tạo ra có thể hiểu như một vòng bảo vệ vô hình đang bao bọc xung quanh cơ thể.
Có thể thấy hệ miễn dịch không hề xa xăm hay bí ẩn gì cả, nó là da, thịt, máu của chúng ta mà thôi. Vậy làm sao để giúp hệ miễn dịch mạnh lên được? Có cần phương pháp đặc biệt nào không?
## 1. Chúng ta ăn uống cũng ảnh hưởng đến hệ miễn dịch
Nếu hỏi chúng ta ăn gì để khỏe mạnh, có lẽ câu trả lời sẽ đến dễ dàng hơn so với hỏi ăn gì để tốt cho hệ miễn dịch. Chúng ta vẫn thường nghĩ rằng cần phải có một số loại thực phẩm, chất hóa học đặc biệt nào đó để phục vụ riêng cho hệ miễn dịch. Sự thật không phức tạp đến vậy đâu.
Như chúng ta đã tìm hiểu ở trên, hệ miễn dịch cũng là những bộ phận và tế bào trong cơ thể của chúng ta, do đó cũng tuân theo một quy tắc dinh dưỡng thông thường, đó là ăn đủ.
Đầu tiên là phải đủ năng lượng. Hệ miễn dịch sẽ suy yếu nếu bạn cố ý bỏ đói cơ thể. Ngay cả những lực sĩ tham dự các giải đấu thể hình cũng công nhận rằng khi phải ăn kiêng để đạt được thể hình dự thi, hệ miễn dịch cũng bị ảnh hưởng rất nhiều, bằng chứng là họ dễ mắc cảm cúm, tiêu chảy, ngộ độc,... những tình huống mà khi ở trạng thái bình thường hệ miễn dịch có thể dễ dàng chống trả.
Tiếp theo đó là đủ chất dinh dưỡng, đây là lý do mà bữa ăn của chúng ta cần phải đa dạng và được thay đổi thường xuyên. Chất dinh dưỡng ở đây có thể phân thành nguyên tố đa lượng và vi lượng.
Đa lượng bao gồm tinh bột, đạm và chất béo. Để giúp chúng ta đảm bảo sức khỏe trong mùa dịch bệnh, bạn có thể tham khảo chế độ dinh dưỡng 4-5-1 được Bộ Y Tế khuyến nghị.
Còn nguyên tố vi lượng thì bao gồm các khoáng chất và vitamin, và cơ thể chỉ yêu cầu một lượng rất nhỏ (do vậy mà được gọi là vi lượng). Tuy cần ít, nhưng nếu thiếu thì có thể ảnh hưởng rất lớn đến cơ thể. Thường những chất vi lượng cũng được cung cấp đầy đủ khi chúng ta ăn đa dạng thực phẩm.
Nếu có lo lắng về việc không cung cấp đủ chất, bạn có thể đọc bài viết về các loại thực phẩm bổ sung để tăng cường cho hệ miễn dịch.
## 2. Chúng ta tập luyện cũng ảnh hưởng đến hệ miễn dịch
oạt động luyện tập thể dục thể thao, hay đơn giản chỉ là thói quen vận động cũng đóng góp rất nhiều cho hiệu quả của hệ miễn dịch, bất kể là tập luyện cơ bắp hay hệ tuần hoàn.
Đó là vì cơ bắp phát triển sẽ kéo theo lượng tế bào máu, mô, cơ cũng tăng theo, hiểu đơn giản là tăng quân số cho đoàn quân miễn dịch.
Còn hệ tuần hoàn hiệu quả sẽ giúp cơ thể vận chuyển máu (chính là phương tiện đi lại của các tế bào phụ trách miễn dịch) thật nhanh chóng, hiệu quả đến tất cả các cơ quan trong cơ thể, kịp thời ứng cứu khi có các nhân tố lạ xâm nhập.
Một hệ tuần hoàn khỏe còn giúp nuôi dưỡng các cơ quan tốt hơn, từ đó cũng tạo nên hệ miễn dịch khỏe mạnh hơn.
## 3. Chúng ta ngủ nghỉ có liên quan gì đến hệ miễn dịch?
Giấc ngủ là một phần cực kỳ quan trọng đối với sức khỏe của chúng ta, nó gây ra ảnh hưởng ngay lập tức mỗi khi có những xáo trộn. Và tất nhiên việc nó có liên quan đến hệ miễn dịch cũng không phải là điều quá ngạc nhiên.
Cụ thể, một số nghiên cứu đã chỉ ra rằng có những giai đoạn hoạt động khác nhau của hệ miễn dịch. Ví dụ số lượng tế bào lympho sẽ hoạt động mạnh nhất vào thời điểm chúng ta đang ngủ. Do đó hoạt động tái tạo, hồi phục của nhiều cơ quan cũng được thúc đẩy rất mạnh mẽ trong khi cơ thể nghỉ ngơi.
Mối liên hệ này hoạt động như thế nào còn cần nhiều nghiên cứu để chứng minh. Tuy nhiên việc đảm bảo một giấc ngủ sâu, đều đặn và ổn định chắc chắn là một yếu tố không thể thiếu để giữ hệ miễn dịch khỏe mạnh.
## 4. Chúng ta vui buồn, có cảm xúc thì liên quan gì đến hệ miễn dịch?
Cảm xúc của chúng ta nhìn dưới góc độ tế bào chính là sự giải phóng các hormone, và hormone lại có ảnh hưởng đến hoạt động của toàn bộ cơ thể.
Nhiều nghiên cứu đã cho thấy rằng cảm xúc của chúng ta có ảnh hưởng đến hoạt động của hệ miễn dịch, về cả mặt tích cực và tiêu cực. Những đợt áp lực ngắn có thể kích thích hoạt động phản hồi miễn dịch mạnh mẽ hơn. Tuy nhiên tình trạng căng thẳng kéo dài thì lại khiến hệ miễn dịch ngày càng suy yếu.
Điều này thể hiện rõ ở các nghiên cứu cho thấy những bệnh nhân có vấn đề tâm lý được điều trị bằng các biện pháp tâm lý không dùng thuốc. Nếu tình trạng tâm lý tốt hơn thì hoạt động của hệ miễn dịch trong cơ thể cũng cải thiện rõ rệt.
Có một điểm chúng ta cần lưu ý trong thời điểm này là cảm giác cô đơn ảnh hưởng rất lớn đến hoạt động của hệ miễn dịch, cũng như sức khỏe tổng thể của chúng ta. Đây cũng là lý do mà những người sống một mình có nguy cơ mắc bệnh cao hơn so với những người sống cùng gia đình, hay có các mối quan hệ thân mật, bạn bè hỗ trợ. Và khi chúng ta bị bắt buộc phải ngừng việc gặp gỡ, giao tiếp với người thân, chúng ta đi từ cảm giác bực bội cho đến mệt mỏi và thậm chí là sa sút về sức khỏe.
Do đó, bằng cách này hay cách khác, hãy cố gắng sử dụng công nghệ hỗ trợ để duy trì các mối quan hệ thân thiết trong đời sống. Từ đồng nghiệp, bạn bè cho đến gia đình, họ hàng. Đôi lúc những lời hỏi han, quan tâm có thể mang đến sức mạnh thể chất thật sự cho bạn và người thân đấy.
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [Hệ miễn dịch thực ra là gì?](https://bvnguyentriphuong.com.vn/mien-dich-lam-sang/cham-soc-he-de-khang-cua-chinh-minh#h-min-dch-thc-ra-l-g)
  * [1. Chúng ta ăn uống cũng ảnh hưởng đến hệ miễn dịch](https://bvnguyentriphuong.com.vn/mien-dich-lam-sang/cham-soc-he-de-khang-cua-chinh-minh#1-chng-ta-n-ung-cng-nh-hng-n-h-min-dch)
  * [2. Chúng ta tập luyện cũng ảnh hưởng đến hệ miễn dịch](https://bvnguyentriphuong.com.vn/mien-dich-lam-sang/cham-soc-he-de-khang-cua-chinh-minh#2-chng-ta-tp-luyn-cng-nh-hng-n-h-min-dch)
  * [3. Chúng ta ngủ nghỉ có liên quan gì đến hệ miễn dịch?](https://bvnguyentriphuong.com.vn/mien-dich-lam-sang/cham-soc-he-de-khang-cua-chinh-minh#3-chng-ta-ng-ngh-c-lin-quan-g-n-h-min-dch)
  * [4. Chúng ta vui buồn, có cảm xúc thì liên quan gì đến hệ miễn dịch?](https://bvnguyentriphuong.com.vn/mien-dich-lam-sang/cham-soc-he-de-khang-cua-chinh-minh#4-chng-ta-vui-bun-c-cm-xc-th-lin-quan-g-n-h-min-dch)



## Test lẩy da với thuốc

TEST LẨY DA VỚI THUỐC
**I.****ĐỊNH NGHĨA**
Test lẩy da với thuốc kỹ thuật dùng 1 giọt dung dịch được nhỏ lên bề mặt da sau đó dùng kim châm vào giọt dung dịch qua lớp thượng bì rồi lẩy nhẹ dùng để xác định tình trạng phản ứng quá mẫn với các loại thuốc. Đọc kết quả sau 30-60 phút so với chứng âm.
**II.****CHỈ ĐỊNH**
- Bệnh nhân có chỉ định thuốc có khả năng gây dị ứng cho bệnh nhân
**III.****CHỐNG CHỈ ĐỊNH**
- Bệnh nhân đang có tình trạng dị ứng cấp tính
- Bệnh nhân đang có tổn thương vùng da định thử test
- Chú ý: Bệnh nhân đang dùng các thuốc kháng histamine hoặc corticoid bôi da có thể làm phản ứng bị âm tính
**IV.****CHUẨN BỊ**
**1.****Người thực hiện**
Bác sĩ và kỹ thuật viên
**2.****Dụng cụ**
- Hộp chống sốc, phương tiện cấp cứu
- Bơm tiêm 
- Chứng âm: dung dịch nước muối sinh lý, chứng dương: histamin
- Dụng cụ đựng kim sau khi sử dụng
- Bông vô trùng & cồn sát trùng 
- Thước kẻ nhựa trong chia vạch mm để đo đường kính nốt sẩn
- Bút bi
- Sổ sách ghi chép sơ đồ thử test cho bệnh nhân.
**3.****Người bệnh**
- Phải được tư vấn trước khi thực hiện quy trình điều trị.
**4.****Hồ sơ bệnh án**
- Mỗi người bệnh có phiếu theo dõi riêng.
**V.****CÁC BƯỚC TIẾN HÀNH**
**1.****Kiểm tra hồ sơ bệnh án**
- Kiểm tra các thông tin về bệnh nhân, chỉ định thử test…
- Ghi chép phiếu theo dõi.
**2.****Thực hiện kỹ thuật**
- Vị trí thực hiện: mặt trước cẳng tay.
- Dùng bơm tiêm loại 1 ml, kim nhỏ ngắn 1-2 cm.
- Nhỏ 1 giọt dung dịch nhỏ mỗi loại thuốc lên ô nhỏ sẵn trên da sau đó dùng đầu kim tiên gây vết chích hoặc vết xước tại ô đó , mỗi chỗ cách nhau ít nhất 3cm.
- Đọc kết quả sau 30-60 phút.
· Âm tính – Giống như chứng âm tính
· Nghi ngờ +/- Ban sẩn đường kính < 3mrn
· Dương tính nhẹ + Đường kính ban sẩn 3-5mm, ngứa, xung huyết
· Dương tính vừa ++ Đường kính ban sẩn 6-8mrn, ngứa, ban đỏ
· Dương tính mạnh +++ Đường kính ban sẩn 9-12mm, ngứa, chân giả
· Dương tính rất mạnh ++++ Đường kính >12mm, ngứa nhiều, nhiều chân giả
- Tư vấn và trả kết quả cho bệnh nhân.
**VI.****THEO DÕI**
- Có thể xảy ra sốc phản vệ sau thử cần chuẩn bị thuốc để cấp cứu

## ️ Thói quen xấu làm suy yếu hệ miễn dịch

  * [Lạm dụng thuốc kháng sinh](https://bvnguyentriphuong.com.vn/mien-dich-lam-sang/thoi-quen-xau-lam-suy-yeu-he-mien-dich#lm-dng-thuc-khng-sinh)
  * [Có ít mối quan hệ xã hội](https://bvnguyentriphuong.com.vn/mien-dich-lam-sang/thoi-quen-xau-lam-suy-yeu-he-mien-dich#co-it-mi-quan-h-xa-hi)
  * [Thiếu ngủ – Thói quen xấu làm suy yếu hệ miễn dịch](https://bvnguyentriphuong.com.vn/mien-dich-lam-sang/thoi-quen-xau-lam-suy-yeu-he-mien-dich#thiu-ng-thi-quen-xu-lm-suy-yu-h-min-dch)
  * [Kìm nén cảm xúc](https://bvnguyentriphuong.com.vn/mien-dich-lam-sang/thoi-quen-xau-lam-suy-yeu-he-mien-dich#km-nn-cm-xc)
  * [Không uống đủ nước](https://bvnguyentriphuong.com.vn/mien-dich-lam-sang/thoi-quen-xau-lam-suy-yeu-he-mien-dich#khng-ung-nc)
  * [Quá lười vận động ](https://bvnguyentriphuong.com.vn/mien-dich-lam-sang/thoi-quen-xau-lam-suy-yeu-he-mien-dich#qu-li-vn-ng)
  * [Hút thuốc thụ động – Thói quen xấu làm suy yếu hệ miễn dịch](https://bvnguyentriphuong.com.vn/mien-dich-lam-sang/thoi-quen-xau-lam-suy-yeu-he-mien-dich#ht-thuc-th-ng-thi-quen-xu-lm-suy-yu-h-min-dch)
  * [Thiếu những suy nghĩ hài hước](https://bvnguyentriphuong.com.vn/mien-dich-lam-sang/thoi-quen-xau-lam-suy-yeu-he-mien-dich#thiu-nhng-suy-nghhi-hc)
  * [Bệnh viện Nguyễn Tri Phương - Đa khoa Hạng I Thành phố Hồ Chí Minh](https://bvnguyentriphuong.com.vn/mien-dich-lam-sang/thoi-quen-xau-lam-suy-yeu-he-mien-dich#bnh-vin-nguyn-tri-phnga-khoahng-i-thnh-ph-h-ch-minh)


Hệ miễn dịch của mỗi người không giống nhau, có người khỏe mạnh, có những người lại rất nhạy cảm với bệnh tật. Theo một tạp chí Khoa học của Hoa Kỳ đã công bố thì có 10 thói quen phá hủy hệ thống miễn dịch mà bạn nên tránh. 
## **Lạm dụng thuốc kháng sinh**
Các nhà nghiên cứu New York sau khi thực hiện một loạt các kiểm tra đã đưa ra nhận định: Lạm dụng thuốc kháng sinh có thể gây tổn hại khả năng miễn dịch bẩm sinh của đường ruột, nguyên do là sự đề kháng kháng sinh của vi khuẩn bị nhiễm trùng. Từ đó ảnh hưởng đến hệ thống miễn dịch tự nhiên của cơ thể.
_Lạm dụng thuốc kháng sinh làm suy yếu hệ miễn dịch_
## **Có ít mối quan hệ xã hội**
Nghiên cứu tìm thấy rằng, những người có mối quan hệ hạn hẹp dễ bị bệnh hơn những người có quan hệ rộng rãi. Các chuyên gia cho rằng, thường xuyên liên lạc với bạn bè, gửi tin nhắn, trò chuyện có thể ngăn ngừa cảm lạnh.
## **Thiếu ngủ – Thói quen xấu làm suy yếu hệ miễn dịch**
Thiếu ngủ có thể dẫn đến giảm khả năng miễn dịch và hạn chế số lượng các ‘tế bào sát thủ’ giúp chống lại các vi khuẩn. Nghiên cứu của Đại học Chicago tìm thấy rằng, những người chỉ ngủ 4 giờ mỗi đêm, kháng thể cơ thể chống lại cúm giảm 50% so với những người trọn giấc 7-8 giờ một đêm.
## **Kìm nén cảm xúc**
Đại học California tại Los Angeles nghiên cứu thấy rằng, các cặp vợ chồng tham gia biết cách thảo luận và chia sẻ các vấn đề gia đình sẽ không chỉ giúp củng cố mối quan hệ gia đình tốt hơn mà còn giúp cải thiện huyết áp, nhịp tim, số lượng tế bào bạch cầu, tăng cường hệ miễn dịch.
## **Không uống đủ nước**
Uống nước đầy đủ có tác dụng duy trì màng nhầy đường hô hấp, giữ ẩm, khiến cho các virus cảm lạnh gặp khó khăn trong việc sinh sản khi xâm nhập vào cơ thể và có thể tăng cường miễn dịch. Mỗi người được khuyến cáo nên cung cấp cho cơ thể 40ml/kg trọng lượng. Trẻ em cũng được khuyến khích uống nhiều nước hơn để tăng cường hệ miễn dịch.
_Uống quá ít nước có thể gây suy yếu hệ miễn dịch_
## **Quá lười vận động**
30 phút vận động hàng ngày như đi bộ nhanh và tập thể dục aerobic giúp cải thiện số lượng tế bào bạch cầu, cải thiện chức năng hệ thống miễn dịch. Trong khi đó, đi xe ô tô thường xuyên hạn chế khả năng vận động của con người khiến cho nguy cơ suy giảm miễn dịch tăng lên.
## **Hút thuốc thụ động – Thói quen xấu làm suy yếu hệ miễn dịch**
Hút thuốc và hút thuốc thụ động đều gây hại cho sức khỏe nói chung và hệ miễn dịch nói riêng. Theo số liệu thống kê, mỗi năm có khoảng 3.000 người Mỹ bị tử vong vì ung thư phổi do hút thuốc thụ động.
## **Thiếu những suy nghĩ hài hước**
Nghiên cứu y học của Loma Linda University School cho thấy rằng, việc xem các video hài hước trong 1 giờ có thể cải thiện đáng kể hệ thống miễn dịch. Bởi vì tiếng cười giúp giảm kích thích tố căng thẳng, tăng hoặc kích hoạt các tế bào miễn dịch nhất định, nhờ đó cải thiện khả năng miễn dịch hiệu quả.
## **[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/) **- Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [Lạm dụng thuốc kháng sinh](https://bvnguyentriphuong.com.vn/mien-dich-lam-sang/thoi-quen-xau-lam-suy-yeu-he-mien-dich#lm-dng-thuc-khng-sinh)
  * [Có ít mối quan hệ xã hội](https://bvnguyentriphuong.com.vn/mien-dich-lam-sang/thoi-quen-xau-lam-suy-yeu-he-mien-dich#co-it-mi-quan-h-xa-hi)
  * [Thiếu ngủ – Thói quen xấu làm suy yếu hệ miễn dịch](https://bvnguyentriphuong.com.vn/mien-dich-lam-sang/thoi-quen-xau-lam-suy-yeu-he-mien-dich#thiu-ng-thi-quen-xu-lm-suy-yu-h-min-dch)
  * [Kìm nén cảm xúc](https://bvnguyentriphuong.com.vn/mien-dich-lam-sang/thoi-quen-xau-lam-suy-yeu-he-mien-dich#km-nn-cm-xc)
  * [Không uống đủ nước](https://bvnguyentriphuong.com.vn/mien-dich-lam-sang/thoi-quen-xau-lam-suy-yeu-he-mien-dich#khng-ung-nc)
  * [Quá lười vận động ](https://bvnguyentriphuong.com.vn/mien-dich-lam-sang/thoi-quen-xau-lam-suy-yeu-he-mien-dich#qu-li-vn-ng)
  * [Hút thuốc thụ động – Thói quen xấu làm suy yếu hệ miễn dịch](https://bvnguyentriphuong.com.vn/mien-dich-lam-sang/thoi-quen-xau-lam-suy-yeu-he-mien-dich#ht-thuc-th-ng-thi-quen-xu-lm-suy-yu-h-min-dch)
  * [Thiếu những suy nghĩ hài hước](https://bvnguyentriphuong.com.vn/mien-dich-lam-sang/thoi-quen-xau-lam-suy-yeu-he-mien-dich#thiu-nhng-suy-nghhi-hc)
  * [Bệnh viện Nguyễn Tri Phương - Đa khoa Hạng I Thành phố Hồ Chí Minh](https://bvnguyentriphuong.com.vn/mien-dich-lam-sang/thoi-quen-xau-lam-suy-yeu-he-mien-dich#bnh-vin-nguyn-tri-phnga-khoahng-i-thnh-ph-h-ch-minh)



## ️ Chẩn đoán và điều trị dự phòng hen phế quản (Diagnosis And Long - Term Management Of Asthma)

**ĐẠI CƯƠNG**
HPQ là hội chứng viêm mạn tính đường hô hấp có sự tham gia của nhiều loại tế bào gây viêm cùng các kích thích khác làm tăng phản ứng phế quản, gây nên tình trạng co thắt phù nề, tăng xuất tiết phế quản, làm tắc nghẽn phế quản, biểu hiện lâm sàng bằng cơn khó thở khò khè, chủ yếu là khó thở ra, những biểu hiện này có thể hồi phục tự nhiên hoặc do dùng thuốc.
Dịch tễ học: HPQ là bệnh viêm mạn tính đường hô hấp có xu hướng ngày càng gia tăng ở nước ta và trên thế giới. Theo kết quả nghiên cứu của WHO (1995), thế giới có khoảng 160 triệu người mắc hen, con số này hiện nay là 300 triệu người. Đến năm 2025, dự báo số người mắc hen sẽ là 400 triệu, ở Việt Nam tỷ lệ mắc hen khoảng 3,9 % dân số.
**CHẨN ĐOÁN**
Chẩn đoán hen không khó vì đặc trưng là cơn khó thở và tái diễn nhiều lần.
**Chẩn đoán xác định HPQ**
_**Theo hướng dẫn của GINA 2011 có thể nghĩ đến hen khi có một trong những dấu hiệu hoặc triệu chứng sau đây:**_
Tiếng thở khò khè, nghe phổi có tiếng ran rít khi thở ra đặc biệt ở trẻ em.
Tiền sử có một trong các triệu chứng sau:
Ho thường tăng về đêm.
Khó thở, khò khè tái phát.
Nặng ngực.
Các triệu chứng nặng lên về đêm làm người bệnh thức giấc.
Các triệu chứng xuất hiện hoặc nặng lên theo mùa.
Trong tiền sử có mắc các bệnh chàm, sốt mùa, hoặc trong gia đình có người bị hen và các bệnh dị ứng khác.
Các triệu chứng xuất hiện hoặc nặng lên khi có các yếu tố sau phối hợp: tiếp xúc với lông vũ, các hóa chất bay hơi, mạt bụi nhà, phấn hoa, khói thuốc lá, khói than, mùi bếp dầu, bếp ga, một số thuốc (aspirin và NSAID, thuốc chẹn bêta giao cảm), nhiễm khuẩn, nhiễm virus đường hô hấp, gắng sức, thay đổi nhiệt độ, cảm xúc mạnh.
Đáp ứng tốt với thuốc giãn phế quản.
Test phục hồi phế quản với thuốc kích thích 2 dương tính biểu hiện bằng FEV1 tăng trên 12% hoặc 200ml sau khi hít thuốc giãn phế quản.
Test da với dị nguyên dương tính hoặc định lượng kháng thể IgE đặc hiệu tăng.
**Một số thể lâm sàng của HPQ**
Hen dị ứng: thường gặp ở những cá thể có cơ địa dị ứng, cơn hen thường liên quan đến DN hoặc theo mùa hoa. Các xét nghiệm kháng thể IgE tăng, BC ái toan tăng, test lẩy da với DN dương tính. Trong tiền sử cá nhân và gia đình thường có bệnh dị ứng, mắc bệnh khi còn trẻ.
Hen không dị ứng: ở những người không có cơ địa dị ứng, cơn hen không liên quan đến DN. Nguyên nhân mắc bệnh thường do viêm nhiễm đường hô hấp. Các xét nghiệm máu bình thường, test da với DN âm tính.
Hen thể ho đơn thuần (Cough variant asthma) thường xảy ra khi vận động quá sức. Với người hen muốn tập mạnh có thể dự phòng cơn khó thở bằng các thuốc kích thích bêta - 2 (β2) tác dụng ngắn hoặc dài trước khi tập.
Hen nghề nghiệp (Occupational asthma): cơn hen xảy ra khi tiếp xúc với dị nguyên nghề nghiệp: bụi bông, len, hóa chất, lông vũ v.v…
Hen ban đêm: cơn khó thở chỉ xảy ra về đêm.
**Chẩn đoán phân biệt**
Viêm phế quản: ho, sốt, khó thở, nghe phổi có ran ẩm, ít ran rít, ran ngáy.
Bệnh phổi tắc nghẽn mạn tính (COPD): khó thở thường xuyên, ho khạc đờm kéo dài, gặp ở tuổi trung niên, có tiền sử hút thuốc lá, test phục hồi phế quản với kích thích β2 âm tính.
U phế quản, u phổi, polyp mũi.
**ĐIỀU TRỊ DỰ PHÒNG**
**Mục tiêu điều trị:** 6 mục tiêu do GINA đề ra:
Hạn chế tối đa xuất hiện triệu chứng (giảm hẳn các triệu chứng nhất là về đêm).
Hạn chế đến mức thấp nhất các đợt hen cấp.
Giảm tối đa các cơn hen nặng phải đến bệnh viện cấp cứu.
Bảo đảm các hoạt động bình thường cho người bệnh.
Giữ lưu lượng đỉnh (PEF) gần như bình thường (>80%).
Không có tác dụng không mong muốn của thuốc.
**Các biện pháp phòng tránh yếu tố kích phát cơn hen**
Hướng dẫn người bệnh biết cách phòng tránh các yếu tố kích phát và làm nặng cơn hen. Các biện pháp cụ thể (theo GINA 2011) như sau:
Với dị nguyên bọ nhà: không dùng các vật dụng trong nhà có khả năng bắt bụi cao như thảm, rèm treo, loại bỏ các vật dụng không cần thiết trong phòng, giặt chăn ga gối đệm hàng tuần và dùng điều hoà không khí nếu có thể.
Dị nguyên từ lông súc vật: Không nuôi các con vật ở trong nhà , không dùng chăn gối nhồi lông thú.
Dị nguyên từ gián: Lau nhà thường xuyên, phun thuốc diệt côn trùng, khi phun thuốc bệnh nhân không đượ c ở trong nhà .
Phấn hoa và nấm mốc bên ngoài : Đóng cửa sổ và cửa ra vào , hạn chế ra ngoài khi phấn hoa rụng nhiều.
Nấm mốc trong nhà : tạo đủ ánh sáng và giảm độ ẩm trong nhà, lau sạch các vùng ẩm thấp, mang khẩu trang khi dọn dẹp các đồ đạc cũ.
Thuốc: hạn chế sử dụng các thuốc NSAID và thuốc chẹn bêta giao cảm không chọn lọc.
Các biện pháp khác: tránh hoạt động gắng sức, tránh dùng bia rượu, thuốc lá, các thực phẩm chứa các chất phụ gia có gốc sulfite, tránh súc động mạnh, tránh những nơi môi trường bị ô nhiễm (bụi, khói, hoá chất).
**Điều trị bằng thuốc**
Các thuốc dự phòng hen (bảng 1)
**Bảng 1: Các thuốc dự phòng hen thường dùng**
**Thuốc** |  **Liều lượng** |  **Tác dụng phụ**  
---|---|---  
**Glucocorticoid dạng hít** **(ICS)** Beclomethasone Budesonide Fluticasone propionate |  Bắt đầu bằng liều tuỳ thuộc và o mức độ nặng của bệnh , khi đạt được sự kiểm soát giảm liề u dần 3 - 6 tháng một lần cho đến một liều thấp nhất vẫn kiểm soát được hen . |  Khản giọng, nấm miệ ng , ho kéo dài, chậ m phát triển ở trẻ em...  
**Thuốc kích thích β2 TD kéo dài (LABA)**  
**_Dạng thuốc xịt_** Formoterol Salmeterol **_Viên phóng thích chậm:_** Salbutamol Terbutalin Bambuterol. |  Hít bột 12 µg 2 lần/ngày, bình xịt định liều MDI 2 liều/lầ n x 2 lần/ngày. Hít bột 50 µg 1lần/ngày, bình xịt định liều MDI 2 liều/lầ n x 2 lần /ngày. 4mg 2 viên/ngày. 10mg 1 lần/ngày. 10mg 1 lần/ngày |  Một vài hoặc rất ít tác dụng phụ hơn dạng uống . Có thể liên quan đến tăng nguy cơ cơn cấp và tử vong do hen Nhịp nhanh, lo lắng, run cơ, giảm kali máu.  
**_Thuốc kết hợp ICS/LABA_**  
Fluticasone / Salmeterol Budesonide / Formoterol |  Dạng hít bột 100, 250, 500µg / 50µg 1liều / lần x 2 lần /ngày. Bình xịt định liều 50, 125, 250µg / 25 µg 2 liều/lần x 2 lần / ngày. Dạng hít bột 100, 200 /6µg 1 liều / lần x 2 lần /ngày. Bình xịt định liều 80, 160 / 4,5 µg 2 liều / lần x 2 lần / ngày. Liệu pháp SMART 160/4,5 1 liều buổi sá ng, 1 liều buổi tối , 1 liều khi khi thở. |  Phối hợp TD phụ của 2 thành phần  
**_Theophylline phóng thích chậm._** Viên 100, 200, 300mg |  Liều bắt đầu 10mg/kg/ngày, tố i đa 800mg/ngày chia 1 - 2 lần. |  Buồn nôn , nôn, liều cao có thể gây co giật , nhịp nhanh, loạn nhịp.  
**_Kháng Leukotrien_** Montelukast (M) |  Người lớn: M 10mg 1lần/ngày . |  Với liều hàng ngày ít TD  
Pranlukast (P) Zafirlukast (Z) |  P 450mg 2 lần/ngày Z 20mg2 lần/ngày Trẻ em: M 5mg 1lần/ngày trước khi ngủ. (6 - 14tuổi) M 4mg (2 - 5tuổi) Z 10mg 2 lần/ngày (7 - 11 tuổi). |  phụ. Tăng men gan với Zafirlukast và Zileuton, một số ít trường hợp viêm gan, tăng bilirubin máu với Zileuton, suy gan với Zafirlukast.  
**_Bảng 2: Liều tương đương của các loại ICS theo GINA 2011_**
**Thuốc** |  **Người lớn (** µ**g/ngày)** |  **Trẻ em > 5 tuổi (**µ**g/ngày)**  
---|---|---  
|  **Trung bình** |  |  **Trung bình**  
_Beclomethasone dipropionate_ |  200 - 500 |  >500 - 1000 |  >1000 - 2000 |  100 - 200 |  >200 - 400 |  > 400  
_Budesonide_ |  200 - 400 |  >400 - 800 |  >800 - 1600 |  100 - 200 |  >200 - 400 |  > 400  
_Ciclesonide_ |  80 - 160 |  >160 - 320 |  > 320 - 1280 |  80 - 160 |  >160 - 320 |  > 320  
_Fluticasone priopionate_ |  100 - 250 |  >250 - 500 |  > 500 - 1000 |  100 - 200 |  >200 - 500 |  > 500  
_Mometasone_ _furoate_ |  ≥400 |  ≥800 |  ≥400  
_Triamcinolone acetonide_ |  400 - 1000 |  >1000 - 2000 |  >2000 |  400 - 800 |  >800 - 1200 |  >1200  
Tiếp cận xử trí dựa trên mức độ kiểm soát
**_Bảng 3: Phân loại mức độ kiểm soát hen theo GINA_**
**Đặc tính** |  **Kiể m soát****(Tất cả các đặc tính dưới đây)** |  **Kiểm soát một phần (Bất kỳ triệu chứng nào trong bất kỳ tuần nào)** |  **Không****kiểm soát**  
---|---|---|---  
Triệu chứng ban ngày. |  Không (< 2 lần/ tuần) |  Hơn 2 lần/tuần |  3 đặc tính của phần hen kiểm soát một phần trong bất kỳ tuần nào.  
Giới hạn hoạt động . |  Không |  Bất kỳ  
Triệu chứng/thức giấc về đêm. |  Không |  Bất kỳ  
Nhu cầu dùng thuốc cắt cơn. |  Không (< 2/tuần) |  > 2/tuần  
Chức năng phổi (PEF hay FEV1). |  Bình thường |  < 80% GTLT hoặc GT tốt nhất (nếu biết trước).  
Đợt kịch phát hen. |  Không |  ≥1 lần/năm  
**Giáo dục sức khoẻ về hen - Kiểm soát môi trường sống**  
---  
**Kích thích**  
nhanh theo nhu cầu |  Kích thích β 2 TD nhanh theo nhu cầu  
Các thuốc dự phòng |  Chọn 1 |  Chọn 1 |  Thêm 1 hoặc hơn |  Thêm 1 hay 2  
ICS liều thấp |  ICS liều thấp + LABA |  ICS liều vừa/cao + LABA |  Carticoid uống liều thấp nhất  
Thuốc kháng leukotrien |  ICS liều vừa hay cao |  Thuốc biến đối leukotrien |  Thuốc kháng IgE  
ICS liều thấp + Thuốc kháng leukotrien |  Theophylline phóng thích chậm  
ICS liều thấp + Theophylline phóng thích chậm  
**Cách khởi đầu điều trị hen**
Bước 2 là điều trị khởi đầu cho hầu hết các trường hợp người bệnh hen đến khám có triệu chứng hen dai dẳng mà chưa điều trị corticosteroid.
Người bệnh đến khám lần đầu cho thấy hen không kiểm soát nghĩa là có ≥ 3 tiêu chí trong cột hen kiểm soát một phần (Bảng 2) thì điều trị bắt đầu từ bước 3.
**Cách tăng bước điều trị hen**
Tình trạng hen chưa được kiểm soát trong vòng 1 tháng cần xem xét tăng bước điều trị.
Nếu xuất hiện cơn hen cấp: chỉ định tăng bước điều trị ngay.
Tăng liều ICS: Tăng gấp 2 lần thường không có hiệu quả. Tăng gấp 4 lần liều ICS (trong 7 - 14 ngày) có hiệu quả tương đương với corticoid uống.
Nếu cần, có thể dùng corticoid uống trong vòng 5 - 7 ngày.
**Cách giảm bước điều trị hen**
Khi hen đã được kiểm soát và duy trì trong 2 - 3 tháng thì có thể xem xét giảm bước điều trị.
Nếu đang dùng LABA+ICS liều trung bình, cao → giảm liều ICS 50% mỗi 3 tháng, nhưng vẫn giữ nguyên liều LABA.
Nếu đang dùng LABA+ICS liều thấp → ngừng LABA
Nếu đang dùng thuốc kiểm soát khác ngoài LABA+ICS liều trung bình, cao →giảm liều ICS 50% mỗi ba tháng nhưng vẫn duy trì liều thuốc kiểm soát khác.
Nếu đang dùng thuốc kiểm soát khác ngoài LABA+ICS liều thấp → ngừng thuốc kiểm soát khác.
Nếu đang dùng ICS liều trung bình, cao →giảm 50% mỗi ba tháng .
Nếu đang liều ICS liều thấp → chuyển sang dùng liều ngày một lần.
Nếu đang dùng ICS liều thấp nhất trong 12 tháng liên tiếp không xảy ra các đợt cấp → cân nhắc ngừng điều trị thuốc. Tiếp tục theo dõi đề phòng.
**Theo dõi điều trị hen**
Ghi nhật ký triệu chứng hen hàng ngày: để đánh giá mức độ kiểm soát bệnh với điều trị hiện tại.
Theo dõi trị số lưu lượng đỉnh (PEF) hàng ngày: đo PEF 2 lần mỗi ngày (sáng và chiều) bằng lưu lượng đỉnh kế. Khi PEF giảm dưới 80% giá trị tốt nhất của người bệnh hoặc dao động sáng chiều lớn hơn 20%, chứng tỏ hen chưa được kiểm soát tốt, cần tái khám hoặc tình trạng hen đang xấu đi và cần được điều trị sớm.
Tái khám định kỳ: khi hen đã được kiểm soát, người bệnh nên khám đình kỳ 1 - 3 tháng một lần.
Người bệnh cần đến cơ sở y tế cấp cứu ngay khi có các dấu hiệu của cơn hen nặng như khó thở khi nghỉ ngơi, nói ngắt quãng, thở nhanh > 30 lần/phút, mệt lả, kiệt sức, đáp ứng chậm với thuốc giãn phế quản, diễn biến nặng dần, không cải thiện sau 2 giờ dùng glucocorticoid uống.
**TÀI LIỆU THAM KHẢO**
Phan Quang Đoàn (2013). Hen phế quản.  _Dị ứng - Miễn dịch lâm sàng_. NXB Giáo dục Việt Nam(tái bản lần thứ nhất), 19 - 52.
GINA 2011. Chapter 2 - Diagnosis and clasification, 16 - 22, Chapter 3 - Asthma - medications, 27 - 40.
Powel J, Gibson P.G (2003). Inhales corticosteroid does in asthma evidence based approach.  _Med J_ , 178(5), 223 - 5.
Rabe J.F., Pizzichine E., Stallerg B., Romeo S., Balanzat A.M., Atienza T, et al (2006). Budesonide/formoterol in a single inhaler for maintenance and relief in mild to moderate asthma a randomized, double - blind trial.  _BMJ_ , 129(2), 246 - 56.
Ringdail N, Eliraz A, Pruzinec R, Weber HH. Mulder PG, Akveld M et al (2003). The Salmeterol/ fluticasone combination is more effective than fluticasone plus oral motelukast in asthma.  _Respir Med_ , 97(3), 234 - 41.
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh

## Sự khác nhau về cơ chế tác dụng của Histamin và Corticoid trong điều trị dị ứng

  * [1, Cơ chế dị ứng:](https://bvnguyentriphuong.com.vn/mien-dich-lam-sang/su-khac-nhau-ve-co-che-tac-dung-cua-histamin-va-corticoid-trong-dieu-tri-di-ung#1-c-ch-d-ng)
  * [2. Các thuốc điều trị dị ứng phổ biến :](https://bvnguyentriphuong.com.vn/mien-dich-lam-sang/su-khac-nhau-ve-co-che-tac-dung-cua-histamin-va-corticoid-trong-dieu-tri-di-ung#2-cc-thuc-iu-tr-d-ng-ph-bin-)


Chắc hẳn là chúng ta đều ít nhiều đã gặp hoặc mắc dị ứng trong cuộc sống thường ngày. Và với dược sỹ thì đều biết khi dị ứng thì chúng ta dùng phổ biến 2 nhóm thuốc là kháng histamin, corticoid. Vậy cách chống dị ứng của 2 nhóm thuốc này khác nhau như thế nào thì đôi khi có một số bạn vẫn chưa rõ. Bài viết sau hy vọng sẽ giúp ích cho chúng ta
## 1, Cơ chế dị ứng:
- Dị ứng là do cơ thể giải phóng ra histamin? - Đúng
- Histamin hình thành trong cơ thể chúng ta như thế nào?
- Tại sao lại giải phóng ra histamin khi cơ thể tiếp xúc với phấn hoa, nọc kiến, nọc ong, thuốc… (gọi là các nguyên nhân dị ứng hay dị nguyên)?
- Histamin được cơ thể tổng hợp từ 1 acid amin thiết yếu là histidin. Chúng được tổng hợp nhiều nhất trong các tế bào mast (hay là dưỡng bào). Những tế bào này có nhiều ở cạnh vùng mạch máu dưới da, ở sâu trong niêm mạc mũi, kết mạc, thành tế bào dạ dày,….
- Khi cơ thể tiếp xúc với tác nhân lạ qua đường hô hấp, đường tiêu hóa, đường máu, đường ngoài da, cơ thể chúng ta nhận ra đấy là dị nguyên thì những kháng thể(IgE) trên bề mặt tế bào mast sẽ bắt những dị nguyên này lại trên bề mặt. Quá trình bắt giữ dị nguyên sẽ hoạt hóa 1 enzym trong tế bào mast là phospholipase C. Chính phospholipase C lại là tác nhân hoạt hóa 1 loạt cơ chế phức tạp để mở kênh Canxi làm Ca2+ đi vào trong tế bào làm tế bào mast vỡ ra và giải phóng histamin. Nếu tiếp xúc dị nguyên bằng đường hít( như phấn hoa) thì thường các tế bào mast ở niêm mạc mũi vỡ ra giải phóng histamin gây triệu chứng nhiều nhất là hắt hơi, sổ mũi, ngứa mũi.
Nếu dị nguyên tiếp xúc qua da (như côn trùng cắn, lông sâu, hóa chất…) thì thường tế bào mast ở mạch máu dưới da giải phóng histamin gây nên triệu chứng đỏ da, ngứa da, da nổi sẩn mề đay, càng gãi thì dị nguyên càng lan rộng ra. Nếu nặng như ong đốt nhiều có thể dị nguyên đi vào máu gây vỡ tế bào mast ở khắp nơi trong cơ thể gây nên triệu chứng của sốc phản vệ: ở phế quản gây co thắt khó thở, ở các mạch máu gây giãn mạch toàn thân nên huyết áp tụt mạnh, ở dạ dày gây tăng mạnh tiết dịch vị gây nôn, đau. Ở da có thể gây mẩn đỏ, ngứa toàn thân…
Dị nguyên qua đường máu có thể gây bất cứ triệu chứng nào từ co thắt phế quản, biểu hiện ngoài da, tụt huyết áp…
## 2. Các thuốc điều trị dị ứng phổ biến :
*** Kháng histamin:**
- Là thuốc về cơ chế tranh chấp với histamin tại các receptor. Trong phản ứng dị ứng khi histamin giải phóng ra khỏi tế bào mast nó sẽ gắn vào các receptor và gây ra tác dụng sinh lý. Có 4 receptor của histamin là H1, H2, H3, H4 nhưng nhiều nhất là H1, H2. Receptor H1 có nhiều ở tế bào niêm mạc mũi, kết mạc, tế bào thành mạch dưới da. Receptor H2 có nhiều ở tế bào niêm mạc dạ dày, ở các tế bào mạch máu dưới da cũng có 1 ít (do đó nhiều khi dị ứng ngoài da nặng người ta vẫn dùng cả kháng H2 như cimetidin kết hợp với kháng H1).
- Thuốc kháng Histamin có thể đẩy histamin ra khỏi receptor nên làm histamin tuy giải phóng ra khỏi tế bào mast nhưng lại không phát huy được tác dụng sinh lý do đó chống được dị ứng. Trong cơn dị ứng cấp thì ưu tiên dùng các kháng histamin để có tác dụng nhanh.
*** Nhóm thuốc corticoid:**
- Cơ chế chống dị ứng của corticoid là nó ức chế enzym phospholipase C của tế bào mast làm cho không hoạt hóa được chuỗi phản ứng kích hoạt để mở kênh Ca2+, do đó tế bào mast không bị vỡ và không giải phóng histamin (mặc dù dị nguyên vẫn gắn vào IgE trên mặt tế bào). Như vậy có thể thấy corticoid là thuốc chống dị ứng mạnh, tuy nhiên trong cơn dị ứng cấp thì nó phát huy tác dụng chậm hơn các thuốc kháng histamin vì trong cơn dị ứng cấp corticoid chỉ ngăn chặn tế bào mast không bị vỡ thêm chứ không ngăn được lượng histamin giải phóng từ các tế bào mast đã vỡ ra gây tác dụng sinh lý. Do đó nếu phát hiện sớm biểu hiện dị ứng hoặc sốc thì corticoid có tác dụng rất tốt, nhưng nếu để muộn quá thì tác dụng nó giảm đi đáng kể.
  * [1, Cơ chế dị ứng:](https://bvnguyentriphuong.com.vn/mien-dich-lam-sang/su-khac-nhau-ve-co-che-tac-dung-cua-histamin-va-corticoid-trong-dieu-tri-di-ung#1-c-ch-d-ng)
  * [2. Các thuốc điều trị dị ứng phổ biến :](https://bvnguyentriphuong.com.vn/mien-dich-lam-sang/su-khac-nhau-ve-co-che-tac-dung-cua-histamin-va-corticoid-trong-dieu-tri-di-ung#2-cc-thuc-iu-tr-d-ng-ph-bin-)



## Xét nghiệm ANA là gì? Vai trò trong chẩn đoán bệnh tự miễn

  * [1. Tự kháng thể là gì và xét nghiệm ANA là gì?](https://bvnguyentriphuong.com.vn/mien-dich-lam-sang/xet-nghiem-ana-la-gi-vai-tro-trong-chan-doan-benh-tu-mien#1-t-khng-th-l-g-v-xt-nghim-ana-l-g)
  * [2. Nguyên lý thực hiện xét nghiệm ANA như thế nào?](https://bvnguyentriphuong.com.vn/mien-dich-lam-sang/xet-nghiem-ana-la-gi-vai-tro-trong-chan-doan-benh-tu-mien#2-nguyn-l-thc-hin-xt-nghim-ana-nh-th-no)
  * [3. Xét nghiệm ANA được chỉ định khi nào? Bác sĩ có thể yêu cầu xét nghiệm ANA nếu bạn có các triệu chứng khiến nghi ngờ đến các bệnh lý tự miễn, chẳng hạn như:](https://bvnguyentriphuong.com.vn/mien-dich-lam-sang/xet-nghiem-ana-la-gi-vai-tro-trong-chan-doan-benh-tu-mien#3-xt-nghim-ana-c-ch-nh-khi-nobc-s-c-th-yu-cuxt-nghim-ananu-bn-c-cc-triu-chng-khin-nghi-ng-n-cc-bnh-l-t-min-chng-hn-nh)
  * [4. Cách thức thực hiện xét nghiệm ANA như thế nào?](https://bvnguyentriphuong.com.vn/mien-dich-lam-sang/xet-nghiem-ana-la-gi-vai-tro-trong-chan-doan-benh-tu-mien#4-cch-thc-thc-hin-xt-nghim-ana-nh-th-no)


## 1. Tự kháng thể là gì và xét nghiệm ANA là gì?
Hệ thống miễn dịch tạo ra các loại protein đóng vai trò bảo vệ cơ thể, được gọi là kháng thể. Kháng thể được sản xuất trực tiếp bởi các tế bào bạch cầu (tế bào B). Nhiệm vụ của các **kháng thể** là nhận ra và chống lại các sinh vật truyền nhiễm (vi trùng) khi xâm nhập vào trong cơ thể. Khi một kháng thể nhận ra các protein ngoại lai của một sinh vật truyền nhiễm, tức là **kháng nguyê****n** , chúng sẽ huy động thêm các tế bào miễn dịch khác cũng như kích hoạt phản ứng viêm để chống lại sự lây nhiễm.
Đôi khi những kháng thể này cũng mắc sai lầm, nhận diện các protein bình thường tự nhiên trong cơ thể thành các vật ngoại lai và nguy hiểm. Các kháng thể này sẽ được gọi là tự kháng thể. Tự kháng thể kích hoạt một dòng thác viêm, khiến cơ thể tự tấn công vào chính mình. Các tự kháng thể thường nhắm mục tiêu vào những protein bình thường trong nhân của tế bào được gọi là **kháng thể kháng nhân** (ANA - antinuclear antibodies).
Hầu hết trong cơ thể của chúng ta đều có tự kháng thể nhưng thường với số lượng rất nhỏ. Sự hiện diện của một lượng lớn các chất tự kháng thể hoặc ANA có thể là căn nguyên của một lý **bệnh tự miễn**.
Cụ thể là các ANA báo hiệu cơ thể bắt đầu tấn công chính mình và dẫn đến các bệnh tự miễn như lupus ban đỏ hệ thống, xơ cứng bì, hội chứng Sjögren, bệnh viêm đa cơ hay **viêm da cơ** , bệnh mô liên kết hỗn hợp, **viêm gan tự miễn**... Khi đó, tự kháng thể làm tổn thương các mô trong cơ thể nếu có thành phần protein đặc hiệu với chúng như khớp, da, cơ và các mô liên kết nói chung, khiến hệ cơ quan mất chức năng và biểu hiện bệnh lý.
## 2. Nguyên lý thực hiện xét nghiệm ANA như thế nào?
Có nhiều phương pháp khác nhau được sử dụng để kiểm tra ANA.
Phương pháp xét nghiệm ANA thường được ứng dụng là **xét nghiệm ANA** huỳnh quang hoặc FANA. Trong đó, các tự kháng thể sẽ được cho gắn huỳnh quang, nếu có sự hiện diện sẽ hiện lên dưới kính hiển vi và sẽ được xác định với cường độ của huỳnh quang.
Độ nhạy và độ đặc hiệu của xét nghiệm ANA là khá tốt để được chỉ định thành xét nghiệm ban đầu cực kỳ phổ biến nhằm xác định khả năng mắc phải bệnh lupus nói riêng hay một tình trạng tự miễn bất kỳ nói chung. Vì hầu hết các bệnh nhân bị lupus đều có ANA dương tính (hơn 95%), một kết quả xét nghiệm ANA âm tính có thể hữu ích trong việc loại trừ chẩn đoán này.
##  3. Xét nghiệm ANA được chỉ định khi nào? Bác sĩ có thể yêu cầu **xét nghiệm ANA** nếu bạn có các triệu chứng khiến nghi ngờ đến các bệnh lý tự miễn, chẳng hạn như:
  * Đau khớp
  * Đau cơ
  * Mệt mỏi toàn thân
  * Sốt tái phát
  * Sốt kéo dài không rõ nguyên nhân
  * Phát ban
  * Da nhạy cảm với ánh sáng
  * Tê và ngứa ran ở tay hoặc chân
  * **Rụng tóc không rõ nguyên nhân**


## 4. Cách thức thực hiện xét nghiệm ANA như thế nào?
Bạn thường không cần phải chuẩn bị gì đặc biệt khi thực hiện **xét nghiệm ANA.**
Đây là một xét nghiệm máu thông thường như các xét nghiệm khác, tức điều dưỡng hay kỹ thuật viên phòng xét nghiệm sẽ lấy một ít máu tại tĩnh mạch nền ở tay bạn, cho vào ống nghiệm với chất bảo quản thích hợp. Sau đó, ống nghiệm chứa bệnh phẩm sẽ được cho vào máy và phân tích, xử lý hoàn toàn tự động. Bạn hay thân nhân sẽ được hẹn trả kết quả trong vòng vài giờ sau đó.
Vì đây giống như các kỹ thuật lấy máu khác nên gần như không có nguy cơ gây nguy hại gì đáng kể. Bạn có thể bị đau hay để lại một vết bầm nhỏ sau khi lấy máu
  * [1. Tự kháng thể là gì và xét nghiệm ANA là gì?](https://bvnguyentriphuong.com.vn/mien-dich-lam-sang/xet-nghiem-ana-la-gi-vai-tro-trong-chan-doan-benh-tu-mien#1-t-khng-th-l-g-v-xt-nghim-ana-l-g)
  * [2. Nguyên lý thực hiện xét nghiệm ANA như thế nào?](https://bvnguyentriphuong.com.vn/mien-dich-lam-sang/xet-nghiem-ana-la-gi-vai-tro-trong-chan-doan-benh-tu-mien#2-nguyn-l-thc-hin-xt-nghim-ana-nh-th-no)
  * [3. Xét nghiệm ANA được chỉ định khi nào? Bác sĩ có thể yêu cầu xét nghiệm ANA nếu bạn có các triệu chứng khiến nghi ngờ đến các bệnh lý tự miễn, chẳng hạn như:](https://bvnguyentriphuong.com.vn/mien-dich-lam-sang/xet-nghiem-ana-la-gi-vai-tro-trong-chan-doan-benh-tu-mien#3-xt-nghim-ana-c-ch-nh-khi-nobc-s-c-th-yu-cuxt-nghim-ananu-bn-c-cc-triu-chng-khin-nghi-ng-n-cc-bnh-l-t-min-chng-hn-nh)
  * [4. Cách thức thực hiện xét nghiệm ANA như thế nào?](https://bvnguyentriphuong.com.vn/mien-dich-lam-sang/xet-nghiem-ana-la-gi-vai-tro-trong-chan-doan-benh-tu-mien#4-cch-thc-thc-hin-xt-nghim-ana-nh-th-no)



## ️ Dị ứng sữa: nhận biết triệu chứng để tránh đe dọa tính mạng

**Dị ứng sữa là gì?**
Tình trạng hệ miễn dịch của cơ thể phản ứng với protein trong sữa động vật được gọi là dị ứng sữa. Nguyên nhân hàng đầu gây dị ứng ở trẻ vẫn là dị ứng sữa, mặc dù trẻ có thể dị ứng với bất kỳ thực phẩm nào.
Một trong những loại dị ứng sữa thường gặp nhất là dị ứng sữa bò, bên cạnh đó cơ thể còn dị ứng với sữa của các động vật khác như sữa dê, sữa cừu, sữa trâu…
Cơ thể có thể dị ứng với một hoặc nhiều loại protein khác nhau, trong đó tác nhân dị ứng phổ biến nhất là alpha protein S1-casein có trong sữa bò.
Phần lớn sữa công thức, sữa bột trên thị trường hiện nay đều là sản phẩm của sữa bò. Do đó, tỷ lệ trẻ dị ứng với sữa công thức và sữa bột cũng tăng lên từ nhu cầu sử dụng các chế phẩm làm từ sữa bò.
Sau khi uống sữa vài phút đến vài giờ, các dấu hiệu dị ứng sữa có thể mới bắt đầu xảy ra. Các triệu chứng nhẹ như phát ban sẽ xảy ra trước, tiếp đến là các triệu chứng nặng nề như khó thở, khò khè, rối loạn tiêu hóa, nghiêm trọng hơn là tình trạng sốc phản vệ do dị ứng sữa, đe dọa tính mạng của bệnh nhân.
Cần phân biệt dị ứng sữa với tình trạng không dung nạp glucose vì hai tình trạng này có triệu chứng tương tự nhau, nhưng thực chất cơ chế lại hoàn toàn khác nhau.
  * Dị ứng sữa là cơ thể phản ứng với thành phần có trong sữa động vật
  * Còn không dung nạp glucose là do cơ thể thiếu men tiêu hóa lactose, dẫn đến lactose của sữa không được ruột chuyển hóa.


**Nguyên nhân gây dị ứng sữa**
Nguyên nhân gây ra tình trạng dị ứng sữa trên bệnh nhân là protein có trong thành phần sữa động vật. Dị ứng sữa ở trẻ nhỏ chính là do sữa bò. Trong sữa bò có 2 loại protein chính sẽ gây dị ứng là:
  * Casein: có trong phần rắn của sữa.
  * Whey: có trong phần lỏng của sữa sau khi lắng.


Cơ thể của trẻ sẽ phản ứng với 1 hoặc cả 2 loại protein này, dẫn đến tình trạng dị ứng xảy ra. Trong một số thực phẩm chế biến khác cũng tìm thấy loại protein này.
Các nghiên cứu cũng chỉ ra rằng người dị ứng sữa bò cũng có khả năng cao bị dị ứng với sữa động vật khác như dê, trâu, cừu, nhưng ít khả năng bị dị ứng với sữa đậu nành.
**Cơ chế dị ứng sữa**
Hệ miễn dịch của cơ thể có thể xem protein trong sữa là có hại nên sẽ tăng cường sản xuất kháng thể IgF khống chế các protein này.
Sau này nếu các protein sữa gây dị ứng lại tiếp tục xuất hiện trong cơ thể thì cơ thể sẽ nhanh chóng nhận diện bởi kháng thể IgE đồng thời hệ thống miễn dịch của cơ thể cũng sẽ được kích hoạt, giải phóng histamin và các chất trung gian hóa học khác, gây tình trạng dị ứng trên lâm sàng với các biểu hiện từ nhẹ đến nặng.
**Triệu chứng dị ứng sữa**
Sau khi uống sữa hoặc sử dụng các sản phẩm chế biến từ sữa trong vòng vài phú đến vài giây thì triệu chứng dị ứng sữa mới xảy ra. Tùy thuộc vào mức độ phản ứng miễn dịch của từng người mà mức độ trầm trọng của các triệu chứng có thể khác nhau ở mỗi bệnh nhân.
Các triệu chứng sớm của dị ứng sữa:
  * Phát ban
  * Khò khè
  * Nôn mửa
  * Sốc phản vệ: phản ứng nghiêm trọng nhất của cả dị ứng nói chung và dị ứng sữa nói riêng. Nguyên nhân là do đường thở bị thu hẹp, triệu chứng nguy hiểm sẽ là co thắt, phù nề đường hô hấp gây khó thở, huyết áp tụt, ngứa, mặt đỏ bừng… Không cấp cứu kịp thời sẽ đe dọa tính mạng bệnh nhân.


Các triệu chứng muộn của dị ứng sữa
  * Tiêu chảy, có lẫn máu trong phân
  * Co thắt bụng, bụng đau quặn
  * Ho, khó thở, khò khè.
  * Chảy nước mũi, chảy nước mắt.
  * Da nổi mẩn, ngứa ngáy khó chịu.


**Đối tượng nguy cơ dị ứng sữa**
  * Dị ứng sữa xảy ra ở trẻ em nhiều hơn người lớn. Nguy cơ dị ứng sữa sẽ giảm dần khi hệ tiêu hóa trưởng thành.
  * Trẻ có cơ địa dị ứng với bất kỳ một tác nhân nào đều là đối tượng nguy cơ của dị ứng sữa.
  * Trẻ bị viêm da dị ứng mạn tính có nhiều khả năng dị ứng với sữa.
  * Tiền sử gia đình: nguy cơ dị ứng ở trẻ sẽ tăng lên nếu trong gia đình có người bị dị ứng sữa, đặc biệt là bố, mẹ có tiền sử dị ứng thực phẩm, chàm, mề đay, hen phế quản…


**Phòng ngừa bệnh dị ứng sữa**
Người bị dị ứng sữa cần tránh xa sữa và những loại thực phẩm làm từ sữa
Bệnh nhân dị ứng sữa thì cần phải tránh xa sữa và các loại thực phẩm làm từ sữa. Cần lưu ý là có rất nhiều thực phẩm chứa sữa, nếu bệnh nhân không chú ý thì rất dễ bị dị ứng khi sử dụng các loại thực phẩm này.
Lối sống cũng như các biện pháp xử trí dị ứng sữa tại nhà có ý nghĩa nhất định.
Cần tư vấn, hỗ trợ người có tiền sử dị ứng sữa để có thể phòng tránh cũng như đối phó với dị ứng sữa.
**Các biện pháp chẩn đoán bệnh dị ứng sữa**
**_Khai thác triệu chứng lâm sàng, bệnh sử, tiền sử dị ứng_**
Sau khi thu thập thông tin, các bác sĩ sẽ có hướng chẩn đoán bệnh và chỉ định xét nghiệm phù hợp để chắc chắn về chẩn đoán.
**_Các xét nghiệm dị ứng cần thực hiện:_**
  * Thử nghiệm chích da: nếu vùng da thử nghiệm sưng, đỏ trong vòng 15-20 phút, thì chứng tỏ đã xảy ra phản ứng dị ứng sữa.
  * Xét nghiệm máu: nhằm tìm kiếm kháng thể IgE – loại kháng thể được tạo ra khi cơ thể tiếp xúc với các chất gây dị ứng.


**_Xét nghiệm thành phần_**
Xét nghiệm thành phần là một loại xét nghiệm máu mới,
Đây là một loại xét nghiệm máu mới, người bệnh được thử nghiệm với các protein đặc biệt có trong sữa như casein, whey, lactalbumin. Điều này có thể giúp xác định nguy cơ dị ứng với các thành phần của sữa.
**_Thử nghiệm thực phẩm_**
Chỉ khi điều kiện cấp cứu đầy đủ mới nên thực hiện thử nghiệm thực phẩm.
**Các biện pháp điều trị bệnh dị ứng sữa**
  * Trường hợp dị ứng sữa nhẹ: cần điều trị dị ứng sữa bằng thuốc kháng sinh histamin với bệnh nhân nhằm giảm nhẹ triệu chứng của bệnh, giảm khó chịu cho người bệnh.
  * Trường hợp sốc phản vệ do dị ứng sữa: cần đưa bệnh nhân đến phòng cấp cứu nhanh nhất có thể để bệnh nhân được xử trí khẩn cấp với các biện pháp hồi sức tích cực. Trong trường hợp này, Adrenalin cũng được chỉ định để đối phó với tình trạng xấu trên bệnh nhân.


**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/) **- Đa khoa Hạng I Thành phố Hồ Chí Minh

## ️ Dị ứng thức ăn (Food Allergy)

**ĐẠI CƯƠNG**
Phản ứng bất lợi do thức ăn được đĩnh nghĩa là tất cả các phản ứng xảy ra sau ăn.
Dị ứng thức ăn được định nghĩa là các phản ứng xảy ra sau ăn do đáp ứng bất thường của hệ miễn dịch với thành phần của thức ăn, có thể thông qua IgE, không IgE hoặc phối hợp cả hai.
Tình trạng không dung nạp thức ăn là các phản ứng xảy ra sau ăn không thông qua cơ chế miễn dịch.
**ĐẶC ĐIỂM LÂM SÀNG VÀ CẬN LÂM SÀNG**
**Lâm sàng**
Biểu hiện lâm sàng của dị ứng thức ăn rất đa dạng và phức tạp phụ thuộc vào nhiều yếu tố như tuổi, loại thức ăn, cơ chế bệnh sinh.
Biểu hiện lâm sàng các phản ứng dị ứng thức ăn nhanh loại I, qua trung gian IgE. Phản ứng dị ứng thức ăn trung gian IgE thường khởi phát nhanh, từ một vài phút tới 2 giờ sau ăn, một số trường hợp phản ứng có thể muộn hơn khoảng 4 - 6 giờ. Các biểu hiện lâm sàng hay gặp như mày đay, phù mạch, VMDƯ, SPV.
_**Mày đay và phù mạch** :_ Mày đay cấp và phù mạch là hai biểu hiện lâm sàng trên da hay gặp nhất của dị ứng thức ăn, thường xuất hiện sau ăn một vài phút tới 1 giờ. Mày đay mạn do thức ăn rất hiếm gặp.
_**Viêm mũi/ VKM dị ứng:**_ triệu chứng VKM, viêm mũi thường xuất hiện kèm theo các triệu chứng toàn thân, ít xảy ra đơn độc. Bệnh nhân thường có ngạt mũi, ngứa mũi, chảy nước mũi, ho, thay đổi giọng nói, đôi khi có cả tiếng rít khi thở, đỏ mắt, ngứa mắt, chảy nước mắt, một vài phút tới 1 giờ sau ăn. Một số công nhân làm việc tại xưởng sản xuất thức ăn sẽ xuất hiện bệnh _nghề nghiệp như VMDƯ, HPQ._
_**Biểu hiện tại đường tiêu hóa:** _các triệu chứng lâm sàng dạ dày ruột do dị ứng thức ăn thông qua IgE bao gồm buồn nôn, nôn, đau bụng, thường xuất hiện sau một vài phút tới 2 giờ sau ăn, tuy nhiên triệu chứng của đường tiêu hóa thấp như tiêu chảy thường xuất hiện muộn hơn từ 2 đến 6 giờ.
_**SPV****do thức ăn:**_ chiếm tới 50% các trường hợp SPV tại phòng cấp cứu, thường gặp do lạc, các loại đậu, thủy hải sản. SPV do thức ăn có thể xuất hiện hai pha với các biểu hiện như tụt huyết áp, rối loạn nhịp tim, mày đay, ban đỏ, phù Quincke, khó thở..., có thể gây tử vong nếu không được phát hiện và điều trị kịp thời.
_**SPV****do thức ăn sau hoạt động thể lực:** _gặp nhiều ở người trưởng thành, phần lớn liên quan tới một hoặc hai loại thức ăn cụ thể như bột mỳ, hải sản. Người bệnh sẽ xuất hiện triệu chứng sốc nếu hoạt động thể lực sau ăn 15 - 30 phút, nhưng sẽ không có triệu chứng nếu không có hoạt động thể lực.
_**Hội chứng miệng dị ứng do thức ăn** :_ gặp ở 40 % người bệnh VMDƯ do phấn hoa, nguyên nhân được cho là do các protein bị cắt đứt do nhiệt trong quá trình nấu chín thức ăn và có phản ứng chéo với các dị nguyên phấn hoa. Triệu chứng như ngứa trong khoang miệng, sưng môi, sưng lưỡi, cổ họng đau, ngứa sau ăn thức ăn tươi, hoa quả, rau củ chưa nấu chín… xuất hiện chỉ một vài phút sau khi ăn. Khoảng 10% người bệnh có triệu chứng toàn thân, trong đó, 12% có SPV. Triệu chứng lâm sàng thường không xuất hiện khi ăn thức ăn được nấu chín.
_**Viêm da dị ứng** :_ có liên quan mật thiết với dị ứng thức ăn, 40% trẻ em viêm da dị ứng có mẫn cảm với thức ăn.
_**HPQ****:**_ thường gặp ở những người làm việc lâu dài tại các nhà máy sản xuất thực phẩm.
_**Biểu hiện lâm sàng các phản ứng dị ứng thức ăn không qua trung gian IgE:**_ thường là các phản ứng dị ứng bán cấp hoặc mạn tính, triệu chứng chủ yếu biểu hiện tại đường tiêu hóa.
_**Viêm ruột do thức ăn:**_ thường gặp ở trẻ nhỏ dưới 9 tháng tuổi, nhất là trong nhóm 1 tuần đến 3 tháng tuổi, với các triệu chứng mạn tính như nôn, tiêu chảy, phân đen, kém hấp thu sau ăn như sữa bò, đậu nành, ít gặp ở trẻ được nuôi bằng sữa mẹ. Phần lớn trẻ bị bệnh sẽ dung nạp với thức ăn sau 3 tuổi.
_**Viêm trực tràng do thức ăn:** _thường gặp ở tháng đầu sau sinh, biểu hiện chủ yếu là có hồng cầu trong phân, thường gây ra do sữa bò, đậu nành, hiếm khi do thức ăn khác.
_**Bệnh Celiac:**_ đặc trưng bởi tình trạng ruột non nhạy cảm với gluten có trong thức ăn do yếu tố di truyền, thường khởi phát muộn từ 10 - 40 tuổi, gặp ở khoảng 0.5 - 1% dân số. Các loại ngũ cốc như lúa mì, lúa mạch, và lúa mạch đen chứa nhiều gluten là những nguyên nhân thường gặp nhất. Bệnh biểu hiện chủ yếu tại đường tiêu hóa như đau bụng, rối loạn tiêu hóa, kém hấp thu, tiêu chảy, nôn, đi ngoài ra máu. Người bệnh cũng có thể bị chậm phát triển về thể chất và trí tuệ, bất thường vệ hệ răng, xương, viêm khớp, tăng men gan, thiếu sắt... Bệnh có biểu hiện lâm sàng đa dạng nhưng không đặc hiệu nên thường khó chẩn đoán.
_**Bệnh phổi nhiễm sắt do thức ăn (hội chứng Heiner):**_ hiếm gặp, biểu hiện viêm phổi ở trẻ nhỏ tái diễn nhiều lần, giảm sắt huyết thanh, tăng thâm nhiễm sắt tại phổi. Sữa bò là nguyên nhân hay hặp nhất.
**_Các biểu hiện lâm sàng rối loạn đường tiêu hóa tăng bạch cầu ái toan:_ **đặc trưng bởi các triệu chứng rối loạn chức năng đường tiêu hóa sau ăn kèm theo tăng BC ái toan tại đường tiêu hóa trên mô bệnh học.
Viêm thực quản tăng bạch cầu ái toan: Bệnh gặp ở trẻ với biểu hiện nôn, khó nuốt, đau bụng, thất bại khi điều trị bằng các thuốc chống bài tiết acid, một số người bệnh có bệnh lý dị ứng kèm theo như VDDƯ, VMDƯ. Thức ăn hay gặp như sữa bò, đậu nành, ngô, lúa mì, và thịt bò.
Viêm dạ dày - ruột tăng bạch cầu ái toan: gặp ở mọi lứa tuổi với biểu hiện nôn, đau bụng, tiêu chảy, kém hấp thu, giảm cân, đa số người bệnh có các bệnh lý dị ứng kèm theo như VDDƯ, HPQ, VMDƯ.
**Cận lâm sàng**
Xét nghiệm cơ bản:
Đánh giá toàn trạng và các bệnh lý phối hợp
Xét nghiệm đặc hiệu:
Xác định nguyên nhân dị ứng thức ăn và mức độ nghiêm trọng của bệnh.
_**Xét nghiệm lẩy da với dị nguyên thức ăn:**_ Đây là phương pháp đơn giản thường được sử dụng để đánh giá các dị nguyên thức ăn nghi ngờ gây dị ứng qua trung gian kháng thể IgE, xét nghiệm này rất có giá trị nếu âm tính vì giá trị xét nghiệm âm tính rất cao trên 95%, tuy nhiên giá trị xét nghiệm dương tính lại khá thấp khoảng 50%, do đó không thể chẩn đoán xác định khi chỉ dựa vào xét nghiệm lẩy da dương tính **với thức ăn nghi ngờ.**
_**Định lượng IgE đặc hiệu với dị nguyên thức ăn:**_ Đây là xét nghiệm sàng lọc dị ứng thức ăn rất có ý nghĩa trên lâm sàng, tuy nhiên chi phí cao. Cũng giống như xét nghiệm lẩy da, giá trị xét nghiệm âm tính rất cao, có ý nghĩa trong việc chẩn đoán loại trừ dị ứng thức ăn, nhưng giá trị chẩn đoán dương tính lại thấp, độ nhạy của xét nghiệm này thấp hơn xét nghiệm lẩy da. Nồng độ IgE đặc hiệu có tương quan với mức độ biểu hiện lâm sàng.
_**Xét nghiệm áp với dị nguyên thức ăn:**_ xét nghiệm này nhằm đánh giá các dị nguyên thức ăn nghi ngờ gây dị ứng không qua trung gian IgE.
_**Xét nghiệm kích thích với thức ăn:**_ xét nghiệm kích thích mù đôi, có đối chứng vẫn được xem là tiêu chuẩn vàng trong chẩn đoán dị ứng thức ăn.
**CHẨN ĐOÁN**
**Chẩn đoán xác định**
**Tiền sử:** Tiền sử người bệnh dị ứng thức ăn được xem là công cụ chẩn đoán hữu hiệu nhất trong chẩn đoán dị ứng thức ăn, bác sỹ hỏi bệnh để làm sáng tỏ tình trạng dị ứng thức ăn của người bệnh dưa vào các câu hỏi như:
Thời gian xảy ra phản ứng dị ứng, hay chậm sau ăn, thời gian cụ thể?
Phản ứng xảy thường kết hợp với loại thức ăn nào?
Trong cùng bữa ăn đó có bao nhiều người có phản ứng tương tự, hay chỉ có người bệnh có triệu chứng?
Người bệnh xuất hiện phản ứng tương tự bao nhiêu lần trước khi đến khám, mức độ phản ứng có phụ thuộc vào lượng thức ăn không?
Thức ăn sau khi ăn gây ra phản ứng dị ứng là thức ăn chín hay thức ăn vẫn còn tươi, sống?
Thức ăn được ăn cùng thời điểm với thức ăn nghi ngờ dị ứng?
Thông tin chi tiết về thực phẩm mà người bệnh đã ăn: Đôi khi bác sỹ không thể chẩn đoán dị ứng thức ăn dựa vào tiền sử, khi đó bác sỹ cần yêu cầu người bệnh ghi chép lại thông tin về thành phần bữa ăn chi tiết và thời gian cũng như các triệu chứng dị ứng xảy ra sau ăn.
Chế độ ăn uống loại bỏ thức ăn nghi ngờ gây ra phản ứng dị ứng: Dưới sự hướng dẫn và quan sát theo dõi của bác sỹ người bệnh không ăn thức ăn nghi ngờ, nếu sau khi người bệnh loại bỏ không ăn các thức ăn này, các triệu chứng biến mất, bác sỹ có thể định hướng được chẩn đoán thức ăn gây ra phản ứng dị ứng, và sau đó người bệnh được cho ăn trở lại loại thức ăn đó mà có phản ứng dị ứng xảy ra thì có thể chẩn đoán xác định được, tuy nhiên đây là phương pháp mạo hiểm do phản ứng nghiêm trọng có thể xảy ra, nên chỉ được áp dụng tại các trung tâm y tế lớn, có đủ trang thiết bị cũng như nguồn nhân lực cấp cứu, dưới sự theo dõi chặt chẽ của bác sĩ chuyên khoa.
**Dựa vào xét nghiệm:** Sau khi hỏi tiền sử, thông tin chi tiết về chế độ ăn liên quan tới các phản ứng dị ứng, chế độ ăn loại bỏ thức ăn nghi ngờ mà vẫn chưa chẩn đoán xác định được thức ăn gây ra phản ứng dị ứng, bác sỹ có thể sử dụng các xét nghiệm hỗ trợ trong chẩn đoán như xét nghiệm trên da, định lượng IgE đặc hiệu với thức ăn trong máu, và có thể cân nhắc làm xét nghiệm kích thích với thức ăn.
**ĐIỀU TRỊ**
Chế độ ăn không có thức ăn gây dị ứng:
Đây là phương pháp điều trị hiệu quả nhất trong dị ứng thức ăn, thức ăn gây dị ứng phải được loại bỏ khỏi khẩu phần ăn của người bệnh, người bệnh cần đọc kỹ các thành phần trong thức ăn trước khi ăn các thực phẩm chế biến sẵn, hoặc tự chẩn bị thức ăn cho riêng mình.
Điều trị triệu chứng do phản ứng dị ứng với thức ăn:
Có nhiều loại thuốc để điều trị triệu chứng do phản ứng dị ứng với thức ăn, tuy thuộc vào mức độ nghiêm trọng của phản ứng dị ứng, loại phản ứng dị ứng.
**Kháng histamine:** là thuốc quan trọng điều trị các triệu chứng lâm sàng như ngứa, mày đay - phù Quincke, triệu chứng viêm mũi - kết mạc, triệu chứng của dạ dày
Kháng histamine H1 thế hệ 1: diphenhydramine, hydroxyzine, loratadine, fexofenadine, desloratadine... (Liều dùng tham khảo bài Các thuốc kháng histamin H1)
Kháng histamine H2: raniditine 1 - 2mg/kg/ lần liều tối đa 75 - 150 mg, uống hoặc tiêm tĩnh mạch.
**Corticosteroid****đường toàn thân:** được chỉ định trong những trường hợp phản ứng dị ứng nặng, có thể dùng đường uống hoặc đường tĩnh mạch liều methylprednisolone 0,5 - 1 mg/kg/ ngày, liều tối đa là 80mg, giảm liều khi triệu chứng cải thiện.
**Adrenaline****:** là thuốc quan trọng nhất trong điều trị SPV do thức ăn.
Trẻ em nặng 10 - 25kg: adrenaline 0,15mg tiêm bắp
Trẻ em nặng > 25kg, adrenaline 0.3mg tiêm bắp
Người lớn, adrenaline (1:1.000) 0,01mg/kg/ lần, tối đa 0.5mg/ lần
Adrenaline cần nhắc lại sau mỗi 5 - 15 phút nếu cần
**Thuốc giãn phế quản**
Salbutamol MDI trẻ em 4 - 8 nhát xịt, người lớn 8 nhát xịt
Hoặc dạng khí dung trẻ em 1.5ml, người lớn 3ml, nhắc lại sau mỗi 20 phút nếu cần
**Các thuốc co mạch khác khi điều trị thất bại với Adrenaline:** Glucagon có thể được sử dụng với liều 20 - 30 µg /kg ở trẻ em, 1 - 5mg hoặc truyền tĩnh mạch liều 5 - 15 µg/ phút ở người lớn.
**Thở oxy khi có suy hô hấp**
**Truyền dịch**
**DỰ PHÒNG**
Trẻ em phải được nuôi bằng sữa mẹ ít nhất 4 - 6 tháng tuổi.
Tiêm vác xin an toàn ở trẻ dị ứng thức ăn.
Giáo dục cho người bệnh, và gia đình cũng như thầy cô tại trường học của người bệnh thông tin về bệnh, cách phòng tránh và điều trị cấp cứu ban đầu khi có phản ứng dị ứng xảy ra.
Xây dựng và cung cấp cho người bệnh, gia đình người bệnh danh sách thức ăn dị ứng.
Phát hiện và điều trị các bệnh dị ứng kèm theo như hen, VMDƯ, dị ứng thuốc.
Hướng dẫn cách sử dụng thuốc epinephrine dạng bơm tiêm tự động cho người bệnh, gia đình người bệnh nếu có phản ứng SPV xảy ra.
**TÀI LIỆU THAM KHẢO**
James J.M, Burks W, Eigenmann P (2012).  _Food Allergy_. Saunders, Toronto.
Sicherer S.H, Sampson H.A (2010). Food allergy.  _J Allergy Clin Immunol_ , 125, S116 - 25.
Boyce J.A, Assa’ad A, Burks A.W et al (2010). Guidelines for the Diagnosis and Management of Food Allergy in the United States: Report of the NIAID - Sponsored Expert Panel.  _J Allergy Clin Immunol,_ 126,S1 - S58.
Sampson H.A, Burks A.W (2008). Adverse Reactions to Foods. Middleton's Allergy Principles & Practice, 7th edition, Mosby, 1139 - 1169.
Sampson H.A (2004). Update on food allergy _. J Allergy Clin Immunol_ , 113, 805 - 19.
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh

## ️ Dị ứng thức ăn là gì? Cơ chế gây dị ứng thức ăn

  * [1 Dị ứng thức ăn là gì?](https://bvnguyentriphuong.com.vn/mien-dich-lam-sang/di-ung-thuc-an-la-gi-co-che-gay-di-ung-thuc-an#1d-ng-thc-n-l-g)
  * [2 Nguyên nhân dị ứng thức ăn](https://bvnguyentriphuong.com.vn/mien-dich-lam-sang/di-ung-thuc-an-la-gi-co-che-gay-di-ung-thuc-an#2nguyn-nhnd-ng-thc-n)
  * [3 Biểu hiện của dị ứng thức ăn](https://bvnguyentriphuong.com.vn/mien-dich-lam-sang/di-ung-thuc-an-la-gi-co-che-gay-di-ung-thuc-an#3biu-hin-ca-d-ng-thc-n)
  * [3.1 Dị ứng thức ăn qua trung gian IgE](https://bvnguyentriphuong.com.vn/mien-dich-lam-sang/di-ung-thuc-an-la-gi-co-che-gay-di-ung-thuc-an#31-d-ng-thc-n-qua-trung-gian-ige)
  * [3.2 Dị ứng thức ăn không qua trung gian IgE](https://bvnguyentriphuong.com.vn/mien-dich-lam-sang/di-ung-thuc-an-la-gi-co-che-gay-di-ung-thuc-an#32-d-ng-thc-n-khng-qua-trung-gian-ige)
  * [4 Các xét nghiệm cận lâm sàng](https://bvnguyentriphuong.com.vn/mien-dich-lam-sang/di-ung-thuc-an-la-gi-co-che-gay-di-ung-thuc-an#4cc-xt-nghim-cn-lm-sng)
  * [5 Chẩn đoán dị ứng thức ăn](https://bvnguyentriphuong.com.vn/mien-dich-lam-sang/di-ung-thuc-an-la-gi-co-che-gay-di-ung-thuc-an#5chn-on-d-ng-thc-n)
  * [6 Điều trị dị ứng thức ăn](https://bvnguyentriphuong.com.vn/mien-dich-lam-sang/di-ung-thuc-an-la-gi-co-che-gay-di-ung-thuc-an#6iu-tr-d-ng-thc-n)
  * [6.1 Không ăn thực phẩm bị hoặc nghi ngờ bị dị ứng](https://bvnguyentriphuong.com.vn/mien-dich-lam-sang/di-ung-thuc-an-la-gi-co-che-gay-di-ung-thuc-an#61-khng-n-thc-phm-b-hoc-nghi-ng-b-d-ng)
  * [6.2 Điều trị triệu chứng do phản ứng dị ứng với thức ăn](https://bvnguyentriphuong.com.vn/mien-dich-lam-sang/di-ung-thuc-an-la-gi-co-che-gay-di-ung-thuc-an#62-iu-tr-triu-chng-do-phn-ng-d-ng-vi-thc-n)
  * [Tài liệu tham khảo](https://bvnguyentriphuong.com.vn/mien-dich-lam-sang/di-ung-thuc-an-la-gi-co-che-gay-di-ung-thuc-an#ti-liu-tham-kho)


## 1 Dị ứng thức ăn là gì?
**Dị ứng thức ăn** là các phản ứng miễn dịch bất thường của cơ thể với một vài loại thực phẩm nhất định. Loại thức ăn này vì một lý do nào đó mà bị hệ miễn dịch của cơ thể nhận nhầm là tác nhân có hại và bắt đầu kích thích phản ứng lại chúng gây ra tình trạng dị ứng.
Phản ứng dị ứng thức ăn có thể thông qua IgE, không IgE hoặc cả hai.
## 2 Nguyên nhân dị ứng thức ăn
Nguyên nhân gây ra tình trạng dị ứng thức ăn thường là do trong các loại thực phẩm có chứa nhiều histamin và những chất hóa học trung gian làm giãn mao mạch, thoát huyết tương,... Kết quả là làm các chất đọng lại trong cơ thể và gây phù nề.
Theo nghiên cứu, những chất thường dễ gây ra dị ứng thức ăn là protein có nguồn gốc động vật hoặc thực vật. Bởi các loại protein này thường bền với nhiệt, khi nấu ở thiệt độ cao, chúng vẫn giữ được cấu trúc ban đầu hoặc các enzyme tiêu hóa không phân hủy được các protein này nên dễ gây dị ứng. 
Khi hệ thống miễn xác nhận nhầm các chất trong thức ăn là có hại, chúng sẽ giải phóng ra kháng thể IgE nhằm vô hiệu hóa các chất này gây ra tình trạng dị ứng.
Một số phản ứng dị ứng không qua trung gian IgE thường biểu hiện trên đường tiêu hóa.
## 3 Biểu hiện của dị ứng thức ăn
Dị ứng thức ăn có biểu hiện rất đa dạng và phức tạp phụ thuộc vào độ tuổi, loại thức ăn, tình trạng sức khỏe,...
### 3.1 Dị ứng thức ăn qua trung gian IgE
Các dấu hiệu dị ứng phổ biến nhất khi bị dị ứng thức ăn qua trung gian IgE là:
**Dị ứng thức ăn nổi mề đay** : Biểu hiện lâm sàng trên da hay gặp nhất, thường xuất hiện sau ăn một vài phút tới 1 giờ và biến mất sau một thời gian nhất định.
Viêm mũi/viêm kết mạc dị ứng: Thường xuất hiện kèm theo các triệu chứng toàn thân. Bệnh nhân thường cảm thấy ngạt mũi, ngứa mũi, chảy nước mũi, ho,... kèm theo đỏ mắt, ngứa mắt, chảy nước mắt,... Tình trạng này thường xảy ra sau khi ăn một vài phút tới 1 giờ. 
Biểu hiện tại đường tiêu hóa: Các triệu chứng hay gặp bao gồm buồn nôn, nôn, đau bụng,... xuất hiện sau ăn 1 phút đến 2 giờ. Có thể tiêu chảy sau 2 - 6 giờ sau đó.
Sốc phản vệ do thức ăn: Tình trạng này chiếm tới 50% các trường hợp sốc phản vệ tại phòng cấp cứu. Bệnh nhân thường có dấu hiệu khó thở, tụt huyết áp nhanh, rối loạn nhịp tim, mất ý thức và có thể tử vong nếu không nhanh chóng được cấp cứu. Các tác nhân thường dễ gây sốc phản vệ là lạc, đậu, hải sản,...
Viêm da dị ứng: Có tới 40% trẻ em bị viêm da dị ứng là do mẫn cảm với đồ ăn.
Hen phế quản: Hay gặp ở những công nhân làm việc lâu trong nhà máy sản xuất thực phẩm.
### 3.2 Dị ứng thức ăn không qua trung gian IgE
​Kiểu dị ứng thức ăn không qua trung gian IgE thường là phản ứng dị ứng bán cấp hoặc mạn tính, có các triệu chứng chủ yếu trên đường tiêu hóa.
Viêm ruột: Hay gặp ở trẻ nhỏ dưới 9 tháng tuổi, đặc biệt là từ 1 tuần đến 3 tháng. Các triệu chứng điển hình là nôn, tiêu chảy, phân đen, kém hấp thu sau ăn,... Không gặp ở những trẻ được nuôi bằng sữa mẹ. Phần lớn trẻ bị bệnh sẽ dung nạp với thức ăn sau 3 tuổi.
Viêm trực tràng: Hay gặp ở tháng đầu sau sinh với biểu hiện chủ yếu là có hồng cầu trong phân. Thường là do cho trẻ uống sữa bò, đậu nành.
Bệnh Celiac: Do ruột non nhạy cảm với gluten có trong thức ăn. Hay gặp ở người từ 10 - 40 tuổi do yếu tố di truyền. Tỉ lệ mắc chiếm tới 0,5 - 1% dân số. Các loại ngũ cốc như lúa mì, lúa mạch,... chứa nhiều gluten là những tác nhân thường gặp nhất. Bệnh biểu hiện chủ yếu tại đường tiêu hóa như đau bụng, rối loạn tiêu hóa, tiêu chảy, nôn, đi ngoài ra máu,... 
Bệnh phổi nhiễm sắt: Hiếm gặp, nguyên nhân chủ yếu là do uống sữa bò. Biểu hiện cụ thể là giảm Sắt huyết thanh, tăng thâm nhiễm sắt tại phổi, viêm phổi tái diễn nhiều lần ở trẻ nhỏ.
Viêm thực quản tăng bạch cầu ái toan: Hay gặp ở trẻ với triệu chứng nôn, khó nuốt, đau bụng,... Loại thức ăn hay gặp là sữa bò, đậu nành, ngô, lúa mì, và thịt bò.
Viêm dạ dày- ruột tăng bạch cầu ái toan: Có thể gặp ở mọi lứa tuổi với biểu hiện nôn, đau bụng, tiêu chảy, kém hấp thu, giảm cân,... có kèm theo viêm da dị ứng, hen phế quản, viêm mũi dị ứng.
## 4 Các xét nghiệm cận lâm sàng
Xét nghiệm cơ bản để đánh giá toàn trạng và các bệnh lý phối hợp.
Xét nghiệm đặc hiệu để xác định nguyên nhân dị ứng thức ăn và mức độ bệnh.
Xét nghiệm lẩy da với dị nguyên thức ăn: Đây là phương pháp đơn giản để đánh giá khi nghi ngờ dị ứng qua trung gian kháng thể IgE.
Định lượng IgE đặc hiệu với dị nguyên thức ăn: Xét nghiệm sàng lọc dị ứng thức ăn, tuy nhiên chi phí cao.
Xét nghiệm áp với dị nguyên thức ăn: Nhằm đánh giá khi nghi ngờ dị ứng thức ăn không qua trung gian IgE.
Xét nghiệm kích thích với thức ăn: Tiêu chuẩn vàng trong chẩn đoán dị ứng thức ăn.
_Xét nghiệm lẩy da với dị nguyên thức ăn_
## 5 Chẩn đoán dị ứng thức ăn
Để biết được tiền sử dị ứng, bác sĩ có thể hỏi bệnh nhân các câu hỏi như sau:
Thời gian xảy ra phản ứng dị ứng cụ thể sau khi ăn?
Thường gặp sau khi ăn loại thực phẩm nào?
Có ai có triệu chứng tương tự sau khi ăn không?
Đã từng xất hiện phản ứng tương tự trước đây chưa, mức độ phản ứng có phụ thuộc vào lượng thức ăn không?
Thực phẩm đã ăn có được nấu chín không hay còn tươi sống?
Các loại thức ăn ăn cùng thời điểm với thức ăn nghi ngờ gây dị ứng?
Việc chẩn đoán không thể chỉ dựa vào tiền sử bệnh, khi đó bác sĩ cần dựa vào các xét nghiệm cận lâm sàng hoặc cho bệnh nhân thử nghiệm ăn các loại thực phẩm nghi ngờ dưới sự giám sát chặt chẽ và có chuẩn bị cấp cứu kịp thời.
## 6 Điều trị dị ứng thức ăn
### 6.1 Không ăn thực phẩm bị hoặc nghi ngờ bị dị ứng
Đây vừa là cách điều trị vừa là các phòng tránh tốt nhất cho người bị dị ứng thức ăn. Người có cơ địa dễ dị ứng nến tránh ăn thực phẩm lạ, thực phẩm dễ gây dị ứng. Khi ăn đồ ăn bên ngoài, đồ ăn đóng hộp,... nên tìm hiểu kĩ thành phần trong thức ăn. Tốt nhất là nên tự chuẩn bị đồ ăn cho mình.
### 6.2 Điều trị triệu chứng do phản ứng dị ứng với thức ăn
**Dị ứng thức ăn bao lâu thì hết**? Thông thường, phản ứng dị ứng thường xảy ra sau khi ăn từ nửa giờ đến 1 giờ. Nếu điều trị sớm và đúng phương pháp, các triệu chứng có thể hết sau 2 - 3 ngày.
Tùy thuộc vào mức độ dị ứng và triệu chứng cụ thể, bệnh nhân có thể được chỉ định sử dụng thuốc theo **phác đồ điều trị dị ứng thức ăn** như sau:
​Kháng histamin: điều trị triệu chứng ngứa, mày đay, viêm mũi - kết mạc,...
  * ​Kháng H1: Diphenhydramine, Hydroxyzine, Loratadine, Fexofenadine, Desloratadine,... 
  * Kháng H2: Raniditine,...


Corticosteroid đường toàn thân: dùng trong những trường hợp phản ứng dị ứng nặng theo đường uống hoặc tiêm tính mạch. Liều dùng Methylprednisolone là 0,5-1 mg/kg/ngày, liều tối đa là 80mg/ngày. Giảm liều khi triệu chứng các triệu chứng được cải thiện.
## Tài liệu tham khảo
  1. [Food allergy](https://www.mayoclinic.org/diseases-conditions/food-allergy/symptoms-causes/syc-20355095), Mayo Clinic. Truy cập ngày 17 tháng 9 năm 2021.
  2. [Food Allergies](https://www.fda.gov/food/food-labeling-nutrition/food-allergies), U.S Food & Drugs. Truy cập ngày 17 tháng 9 năm 2021.
  3. [Current Options for the Treatment of Food Allergy](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4970423/), NCBI. Truy cập ngày 17 tháng 9 năm 2021.


**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [1 Dị ứng thức ăn là gì?](https://bvnguyentriphuong.com.vn/mien-dich-lam-sang/di-ung-thuc-an-la-gi-co-che-gay-di-ung-thuc-an#1d-ng-thc-n-l-g)
  * [2 Nguyên nhân dị ứng thức ăn](https://bvnguyentriphuong.com.vn/mien-dich-lam-sang/di-ung-thuc-an-la-gi-co-che-gay-di-ung-thuc-an#2nguyn-nhnd-ng-thc-n)
  * [3 Biểu hiện của dị ứng thức ăn](https://bvnguyentriphuong.com.vn/mien-dich-lam-sang/di-ung-thuc-an-la-gi-co-che-gay-di-ung-thuc-an#3biu-hin-ca-d-ng-thc-n)
  * [3.1 Dị ứng thức ăn qua trung gian IgE](https://bvnguyentriphuong.com.vn/mien-dich-lam-sang/di-ung-thuc-an-la-gi-co-che-gay-di-ung-thuc-an#31-d-ng-thc-n-qua-trung-gian-ige)
  * [3.2 Dị ứng thức ăn không qua trung gian IgE](https://bvnguyentriphuong.com.vn/mien-dich-lam-sang/di-ung-thuc-an-la-gi-co-che-gay-di-ung-thuc-an#32-d-ng-thc-n-khng-qua-trung-gian-ige)
  * [4 Các xét nghiệm cận lâm sàng](https://bvnguyentriphuong.com.vn/mien-dich-lam-sang/di-ung-thuc-an-la-gi-co-che-gay-di-ung-thuc-an#4cc-xt-nghim-cn-lm-sng)
  * [5 Chẩn đoán dị ứng thức ăn](https://bvnguyentriphuong.com.vn/mien-dich-lam-sang/di-ung-thuc-an-la-gi-co-che-gay-di-ung-thuc-an#5chn-on-d-ng-thc-n)
  * [6 Điều trị dị ứng thức ăn](https://bvnguyentriphuong.com.vn/mien-dich-lam-sang/di-ung-thuc-an-la-gi-co-che-gay-di-ung-thuc-an#6iu-tr-d-ng-thc-n)
  * [6.1 Không ăn thực phẩm bị hoặc nghi ngờ bị dị ứng](https://bvnguyentriphuong.com.vn/mien-dich-lam-sang/di-ung-thuc-an-la-gi-co-che-gay-di-ung-thuc-an#61-khng-n-thc-phm-b-hoc-nghi-ng-b-d-ng)
  * [6.2 Điều trị triệu chứng do phản ứng dị ứng với thức ăn](https://bvnguyentriphuong.com.vn/mien-dich-lam-sang/di-ung-thuc-an-la-gi-co-che-gay-di-ung-thuc-an#62-iu-tr-triu-chng-do-phn-ng-d-ng-vi-thc-n)
  * [Tài liệu tham khảo](https://bvnguyentriphuong.com.vn/mien-dich-lam-sang/di-ung-thuc-an-la-gi-co-che-gay-di-ung-thuc-an#ti-liu-tham-kho)



## ️ Dị ứng thuốc (Drug Allergy)

**VÀI NÉT ĐẠI CƯƠNG**
Định nghĩa: Dị ứng thuốc là phản ứng quá mức, bất thường, có hại cho người bệnh khi dùng hoặc tiếp xúc với thuốc (sự kết hợp dị nguyên với kháng thể dị ứng hoặc lymoho bào mẫn cảm) do đã có giai đoạn mẫn cảm. Dị ứng thuốc thường không phụ thuộc vào liều lượng, có tính mẫn cảm chéo, với một số triệu chứng và hội chứng lâm sàng đặc trưng, thường có biểu hiện ngoài da và ngứa. Nếu dùng lại thuốc đã gây dị ứng thì phản ứng dị ứng sẽ xảy ra nặng hơn và có thể tử vong.
Dị ứng thuốc chiếm khoảng 10 - 15% các phản ứng có hại do thuốc
Mọi loại thuốc đều có thể gây ra những phản ứng dị ứng, tuy nhiên, thuốc kháng sinh, thuốc chống co giật, chống viêm không steroid và các thuốc điều trị gout là những thuốc có tỷ lệ gặp cao nhất gây ra các phản ứng dị ứng.
**BIỂU HIỆN LÂM SÀNG CỦA DỊ ỨNG THUỐC**
**Phân loại dị ứng thuốc theo lâm sàng:**
Các phản ứng dị ứng nhanh: xảy ra trong vòng 1 giờ sau lần dùng thuốc cuối cùng, biểu hiện lâm sàng là mày đay, phù mạch, VMDƯ, co thắt phế quản và SPV.
Các phản ứng dị ứng muộn xảy ra hơn 1 giờ sau lần dùng thuốc cuối cùng cùng. Biểu hiện lâm sàng chủ yếu là ban dạng dát sẩn, mày đay, phù mạch, hồng ban nhiễm sắc dạng cố định, hồng ban đa dạng, đỏ da toàn thân, viêm da bong vảy, hội chứng AGEP, DRESS, hội chứng Stevens - Johnson và hội chứng hoại tử tiêu thượng bì nhiễm độc (hội chứng Lyell).
**Bảng 1: Các biểu hiện lâm sàng thường gặp của dị ứng thuốc**
**Vị trí** |  **Biểu hiện lâm sàng**  
---|---  
Toàn thân |  SPV, sốt, viêm mạch, sưng hạch, bệnh huyết thanh...  
Mày đay, phù mạch, sẩn ngứa, viêm da tiếp xúc, mẫn cảm ánh sáng, đỏ da toàn thân, hồng ban nhiễm sắc cố định, hội chứng Stevens - Johnson, Lyell.  
Phổi |  Khó thở, viêm phế nang  
Viêm gan, tổn thương tế bào gan  
Viêm cơ tim  
Thận |  Viêm cầu thận, hội chứng thận hư  
Ban xuất huyết giảm tiểu cầu, thiếu máu tán huyết, giảm bạch cầu trung tính.  
**MỘT SỐ HỘI CHỨNG DỊ ỨNG THUỐC**
**Sốc phản vệ**
Nhiều loại thuốc có thể gây SPV, thường gặp là kháng sinh, huyết thanh, NSAID, thuốc gây tê gây mê...
SPV là tai biến dị ứng nghiêm trọng nhất, dễ gây tử vong. Biểu hiện lâm sàng của SPV thường đột ngột sau khi dùng thuốc từ vài giây đến 20 - 30 phút, đạt đỉnh cao khoảng 1 giờ, khởi đầu bằng cảm giác lạ thường (bồn chồn, hoảng hốt, sợ chết...). Sau đó là sự xuất hiện đột ngột các triệu chứng ở một hoặc nhiều cơ quan như tim mạch, hô hấp, tiêu hoá, da...với những biểu hiện: mạch nhanh nhỏ khó bắt, huyết áp tụt hoặc không đo được; nghẹt thở, tác thở; mày đay, ngứa toàn thân; đau quặn bụng, ỉa đái không tự chủ và có thể tử vong sau ít phút.
**Mày đay**
Các loại thuốc đều có thể gây mày đay, hay gặp nhất là kháng sinh, huyết thanh, vắc xin, NSAID...
Mày đay thường là biểu hiện hay gặp và ban đầu của phần lớn các trường hợp dị ứng thuốc. Sau khi dùng thuốc vài phút, chậm có thể hàng ngày, người bệnh có cảm giác nóng bừng, râm ran một vài chỗ trên da như côn trùng đốt, sau đó xuất hiện những sẩn phù màu hồng hoặc đỏ đường kính vài milimet đến vài centimet, ranh giới rõ, mậtºChắc, hình tròn hoặc bầu dục, xuất hiện ở nhiều nơi, có thể chỉ khu trú ở đầu, mặt cổ, tứ chi hoặc toàn thân. Ngứa là cảm giác khó chịu nhất, xuất hiện sớm, thường làm người bệnh mất ngủ, càng gãi càng làm sẩn to nhanh hoặc xuất hiện những sẩn phù khác. Đôi khi kèm theo có khó thở, đau bụng, đau khớp, chóng mặt, buồn nôn, sốt cao. Mày đay dễ tái phát trong thời gian ngắn, ban vừa mất đi đã xuất hiện trở lại.
**Phù mạch dị ứng (phù Quincke)**
Các nguyên nhân thường gặp là kháng sinh, huyết thanh, NSAID...
Thuật ngữ phù Quincke hiện nay ít dùng, phù mạch dị ứng thường xuất hiện nhanh sau khi dùng thuốc vài phút, vài giờ hoặc hàng ngày. Biểu hiện ở da và tổ chức dưới da của người bệnh có từng đám sưng nề, đường kính từ 2 - 10cm, thường xuất hiệnở những vùng da có tổ chức lỏng lẻo: môi, cổ, quanh mắt, bụng, bộ phận sinh dục... Nếu phù mạch ở gần mắt, làm mắt híp lại, ở môi làm môi sưng to biến dạng, màu sắc của phù mạch bình thường hoặc hồng nhạt, đôi khi phối hợp với mày đay. Trường hợp phù mạch ở họng, thanh quản, người bệnh có thể nghẹt thở; ở ruột, dạ dầy, gây nôn, buồn nôn, đau quặn bụng; ở não, gây đau đầu, lồi mắt, động kinh; ở tử cung gây đau bụng, ra máu âm đạo giống doạ sẩy thai ở phụ nữ có thai...
**Chứng mất bạch cầu hạt**
Thường gây ra do các thuốc sulfamid, penicillin liều cao, streptomycin, chloramphenicol, pyramidon, analgin, thuốc kháng giáp trạng tổng hợp...
**Bệnh cảnh lâm sàng điển hình:** sốt cao đột ngột, sức khoẻ giảm sút nhanh, loét hoại tử niêm mạc mắt, miệng, họng, cơ quan sinh dục; viêm phổi, viêm tắc tĩnh mạch, nhiễm khuẩn huyết, dễ dẫn tới tử vong.
**Bệnh huyết thanh**
Chủ yếu gây ra do tiêm huyết thanh hoặc các protein dị thể như ACTH, insulin…hoặc một số loại thuốc như sulfamid, penicillin, thuốc chống lao (PAS, isoniazid, streptomycin), griseofulvin, phenylbutazon, bacbituric và tetracyclin (oxytetracyclin).
Bệnh xuất hiện từ ngày thứ 2 đến ngày thứ 14 sau khi dùng thuốc, người bệnh mệt mỏi, mất ngủ, buồn nôn, mày đay, đau khớp, sưng nhiều hạch, sốt cao 38 - 39ºC, gan to. Nếu phát hiện kịp thời, ngừng ngay thuốc, các triệu chứng trên sẽ mất dần.
**Viêm da dị ứng tiếp xúc**
Viêm da dị ứng tiếp xúc thường do thuốc và hoá chất gây ra chủ yếu là thuốc bôi và mỹ phẩm
Viêm da dị ứng tiếp xúc thực chất là chàm (eczema), thương tổn cơ bản là mụn nước kèm theo có ngứa và tiến triển qua nhiều giai đoạn. Bệnh thường xảy ra ít giờ sau tiếp xúc với thuốc, biểu hiện ngứa dữ dội, nổi ban đỏ, mụn nước, phù nề ở chỗ tiếp xúc với thuốc.
**Đỏ da toàn thân**
Thường gây ra do các thuốc như penicillin, ampicillin, streptomycin, sulfamid, chloramphenicol, tetracyclin, các thuốc an thần, NSAIDs...
Đỏ da toàn thân là tình trạng đỏ da diện rộng trên ≥ 90% diện tích cơ thể hoặc toàn thân như tôm luộc, gồm 2 giai đoạn: đỏ da và bong vẩy trắng. Bệnh xuất hiện 2 - 3 ngày, trung bình 6 - 7 ngày, đôi khi 2 - 3 tuần lễ sau khi dùng thuốc. Người bệnh ngứa khắp người, sốt cao, rối loạn tiêu hoá, nổi ban và tiến triển thành đỏ da toàn thân, trên da có vẩy trắng, kích thước không đều, các kẽ tay kẽ chân nứt chảy nước vàng, đôi khi bội nhiễm có mủ.
**Hồng ban nút**
Thường gây ra do các thuốc penicillin, ampicillin, sulfamid...
Hồng ban nút hay xuất hiện sau dùng thuốc 2 - 3 ngày, biểu hiện sốt cao, đau mỏi toàn thân, xuất hiện nhiều nút to nhỏ nổi lên mặt da, nhẵn đỏ, ấn đau, vị trí ở giữa trung bì và hạ bì, tập trung nhiều ở mặt duỗi của các chi, đôi khi xuất hiện trên thân mình và ở mặt, lui dần sau một vài tuần, chuyển màu giống ban xuất huyết.
**Hồng ban nhiễm sắc cố định**
Thường gây ra do tetracyclin, aspirin, phenylbutazol, bacbituric...
Bệnh xuất hiện vài giờ hoặc vài ngày sau khi dùng thuốc. Người bệnh sốt nhẹ, mệt mỏi, trên da xuất hiện nhiều ban màu sẫm ở tứ chi, thân mình, môi và sẽ xuất hiện ở chính vị trí đó nếu những lần sau lại dùng thuốc đó.
**Ban dạng mụn mủ cấp tính**
Có thể gây ra do các thuốc sulfamid, terbinafin, quinolon, hydroxychloroquin, diltiazem, pristinamycin, ampicillin, amoxicillin...
AGEP là thể dị ứng hiếm gặp (~ 1:100 000 người bệnh điều trị),90% gây ra do thuốc. Dấu hiệu lâm sàng quan trọng là sự xuất hiện nhanh của rất nhiều mụn mủ vô khuẩn rải rác trên da, thường 3 đến 5 ngày sau dùng thuốc. Người bệnh có biểu hiện sốt, tăng bạch cầu trong máu, đôi khi có tăng bạch cầu ái toan, nhưng không tổn thương các niêm mạc.
**Phản ứng dị ứng thuốc toàn thể có tăng bạch cầu ái toan (DRESS hoặc DiHS)**
Thường gây ra do sulfamid, phenobarbital, sulfasalazin, carbamazepin, phenytoin, dapson, allopurinol, diltiazem, oxicam, NSAIDs, Atenolol, muối vàng, azathioprin, isoniazid, captopril, ethambutol, doxycyclin...
Là một thể dị ứng thuốc nặng, có tỉ lệ tử vong cao. Biểu hiện lâm sàng với các triệu chứng: mệt mỏi, sốt cao 39 - 40ºC, viêm họng, nổi hạch, ban đỏ và tổn thương nội tạng, thường xuất hiện 1 đến 8 tuần sau khi tiếp xúc với thuốc.
Khoảng 50% người bệnh có biểu hiện viêm gan, 30% người bệnh tăng BC ái toan, 10% viêm thận và khoảng 10% viêm phổi, đôi khi có rụng tóc.
**Hồng ban đa dạng**
Thường gây ra do các thuốc sulfamid, antipirin, tetracyclin, phenolbarbital...
Biểu hiện với hội chứng nổi ban đỏ, sẩn, mụn nước, bọng nước, thường có ban hình bia bắn, tiến triển cấp tính. Bệnh bắt đầu một vài ngày sau khi dùng thuốc, sốt nhẹ, mệt mỏi, đau khớp, sau 2 - 3 ngày xuất hiện ban sẩn, có thể có mụn nước và bọng nước nếu là "thể hoàn toàn trên da". "Thể cấp tính" khi người bệnh sốt cao, rét run, đau lưng, đau khớp, phát ban có bọng nước tập trung thành từng đám, sau lan ra toàn thân, niêm mạc, miệng.
**Hội chứng Stevens - Johnson**
Nguyên nhân thường gặp là penicillin, streptomycin, tetracyclin, sulfamid chậm, thuốc chống co giật, thuốc an thần, NSAIDs...
Đặc trưng của hội chứng này là loét các hốc tự nhiên (số lượng thường trên 2 hốc, hay gặp ở mắt và miệng) và có nhiều dạng tổn thương da thường là bọng nước, diện tích da tổn thương < 10% diện tích da cơ thể.. Sau khi dùng thuốc vài giờ đến hàng tuần, người bệnh thấy mệt mỏi, ngứa khắp người, có cảm giác nóng ran, sốt cao, nổi ban đỏ, bọng nước trên da, các hốc tự nhiên (mắt, miệng, họng, bộ phận sinh dục) dẫn tới viêm loét, hoại tử niêm mạc các hốc này, có thể kèm theo tổn thương gan thận, thể nặng có thể gây tử vong.
**Hội chứng Lyell - Hội chứng hoại tử tiêu thượng bì nhiễm độc**
Thường gây ra dosulfamid chậm, penicillin, ampicillin, streptomycin, tetracyclin, analgin, phenacetin, thuốc chống động kinh, thuốc đông dược...
Là tình trạng nhiễm độc hoại tử da nghiêm trọng nhất, đặc trưng bởi dấu hiệu Nikolski dương tính (dễ tuột da), tỷ lệ tử vong cao. Bệnh diễn biến vài giờ đến vài tuần sau khi dùng thuốc, người bệnh cảm thấy mệt mỏi, bàng hoàng, mất ngủ, sốt cao, trên da xuất hiện các mảng đỏ, đôi khi có các chấm xuất huyết, vài ngày sau, có khi sớm hơn, lớp thượng bì tách khỏi da, khẽ động tới là trợt ra từng mảng (dấu hiệu Nikolski dương tính). Diện tích da tổn thương > 30% diện tích da cơ thể. Cùng với tổn thương da có thể viêm gan, thận, tình trạng người bệnh thường rất nặng, nhanh dẫn tới tử vong.
**CHẨN ĐOÁN DỊ ỨNG THUỐC**
Để chẩn đoán dị ứng thuốc cần phải trả lời 3 câu hỏi sau: (1) Đó có phải là một phản ứng dị ứng thuốc không? (2) Theo cơ chế nào? (3) Thuốc nào gây nên phản ứng dị ứng?
**Chẩn đoán xác định**
_**Dựa vào lâm sàng:**_
Đối với SPV: Chẩn đoán SPV khi có 1 trong 3 tiêu chuẩn được trình bày trong bảng 2
**Bảng 2: Tiêu chuẩn chẩn đoán SPV**
1/ Xuất hiện đột ngột (từ vài phút đến vài giờ ) các triệu chứng ở da, niêm mạc (ban đỏ, ngứa, phù môi - lưỡi - vùng họng hầu) và có ít nhất 1 trong 2 triệu chứng sau: Triệu chứng hô hấp (khó thở, khò khè, ho, giảm ôxy máu) Tụt HA hoặc các hậu quả của tụt HA: ngấ t, đá i ỉa không tự chủ .  
---  
2/ Xuất hiện đột ngột (vài phút–vài giờ) 2 trong 4 triệu chứng sau đây khi người bệnh tiếp xúc với dị nguyên hoặc các yếu tố gây phản vệ khác: Các triệu chứng ở da, niêm mạc. Các triệu chứng hô hấp. Tụt HA hoặc các hậu quả của tụt HA. Các triệu chứng tiêu hoá liên tục (nôn, đau bụng)  
3/ Tụt huyết áp xuất hiện vài phút đến vài giờ sau khi tiếp xúc với 1 dị nguyên mà người bệnh đã từng bị dị ứng. Trẻ em: giảm ít nhất 30% HA tâm thu hoặc tụt HA tâm thu so với tuổi. Người lớn: HA tâm thu < 90 mm Hg hoặ c giả m 30% giá trị HA tâm thu.  
Đối với các dạng dị ứng thuốc khác: cần dựa vào các dấu hiệu sau:
Có quá trình tiếp xúc với dùng thuốc (hít, bôi, uống, tiêm,truyền...)
Có biểu hiện bất thường sau tiếp xúc với thuốc
Có các triệu chứng, hội chứng của dị ứng thuốc, lưu ý có triệu chứng trên da và ngứa sau tiếp xúc với thuốc.
Có tiền sử dị ứng đặc biệt là tiền sử dị ứng thuốc
_**Dựa vào xét nghiệm:**_
__Đối với SPV:__ Định lượng nồng độ tryptase huyết thanh trong vòng từ 2 đến 4 giờ sau khi SPV. Việc định lượng nồng độ tryptase đặc biệt quan trọng nếu nghi ngờ SPV trong quá trình gây mê, khi mà những dấu hiệu của SPV có thể gây nên ngừng tim và không có các triệu chứng ở da.
__Đối với những phản ứng dị ứng khác:__
Xét nghiệm công thức máu có thể thấy bạch cầu lympho kích thích và bạch cầu ưa acid (gần 40% người bệnh MPE, gần 30% người bệnh AGEP kết hợp với giảm bạch cầu, và trên 70% người bệnh DiHS hoặc DRESS).
Xét nghiệm sinh hóa máu: định lượng các enzyme của gan (ALT, AST, ALP và GGT) nhằm phát hiện tổn thương gan trong các hội chứng nặng do thuốc: hội chứng DiHS hoặc DRESS hoặc viêm gan hoặc viêm đường mật, SJS, TEN...
**Xác định thuốc gây dị ứng**
**_Đối với những phản ứng dị ứng nhanh:_**
Test kích thích với thuốc gây dị ứng được xem như một tiêu chuẩn vàng cho chẩn đoán thuốc gây dị ứng nhanh.
__Test lẩy da và test trong da__ đều có thể thực hiện. Test penicillin được sử dụng rộng rãi. Các tinh chất (ví dụ như amoxicillin) cũng có thể được sử dụng. Độ nhạy của các xét nghiệm này trên 70%. Các thuốc khác có thể dùng xét nghiệm test lẩy da hoặc test trong da, nhưng tỷ lệ dương tính giả cao (như quinolon).
__Định lượng kháng thể IgE đặc hiệu__ có độ nhạy khá thấp khoảng 40%, nhưng có giá trị trong chẩn đoán và phân biệt với những phản ứng giả dị ứng (phản ứng giả dị ứng độ nhạy lên tới 70% đối với NSAIDs).
_**Đối với những phản ứng dị ứng muộn:**_
__Test áp da:_ _thường dùng trong chẩn đoán nguyên nhân của viêm da tiếp xúc, MPE, DiHS/DRESS và AGEP, độ nhạy khoảng gần 50% và phụ thuộc vào bệnh. Đây là một test đáng tin cậy để chẩn đoán dị ứng abacavir.
__Xét nghiệm chuyển dạng tế bào lympho (LTT):__ có giá trị chẩn đoán cao nhưng thực hiện phức tạp. Độ nhạy của LTT phụ thuộc vào cơ chế sinh bệnh học của phản ứng dị ứng thuốc, thường > 90% đối với DiHS hoặc DRESS, nhưng lại thấp hơn đối với SJS hoặc TEN.
**ĐIỀU TRỊ DỊ ỨNG THUỐC**
**Điều trị SPV:**
**_Nguyên tắc:_**
Khẩn cấp, tại chỗ, dùng ngay adrenalin
**_Xử trí cấp cứu ban đầu:_**
Thực hiện đồng thời, linh hoạt các bước trong bảng 3.
**Bảng 3: Các bước xử trí cấp cứu ban đầu SPV**
Ngừng ngay tiếp xúc với dị nguyên: theo mọi đường vào cơ thể.  
---  
Dùng ngay adrenalin: adrenalin là thuốc quan trọng nhất không có chống chỉ định tuyệt đối trong cấp cứu SPV.  
Liều adrenalin khởi đầu: dung dịch adrenalin 1/1.000, ống 1mg/1ml, tiêm bắp ở mặt trước bên đùi: 0,5 - 1 ml ở người lớn, 0,01 ml/kg, tối đa không quá 0,3 ml /lần ở trẻ em. Tiêm nhắc lại sau mỗi 5 - 15 phút/lần (có thể sớm hơn 5 phút nếu cần), cho đến khi huyết áp trở lại bình thường (Huyết áp tâm thu > 90 mmHg ở trẻ em lớn hơn 12 tuổi và người lớn; > 70 mmHg +(2 x tuổi) ở trẻ em 1 - 12 tuổi; > 70 mmHg ở trẻ em 1 - 12 tháng tuổi).  
Đặt người bệnh nằm ngửa, đầu thấp, chân cao.  
Thở ôxy 6 - 8 lít/phút cho người lớn, 1 - 5 lit/phút cho trẻ em  
Thiết lập ngay đường truyền tĩnh mạch riêng: Dung dịch truyền tốt nhất trong cấp cứu SPV là Natriclorua 0,9%, truyền 1 - 2 lít ở người lớn, 500 ml ở trẻ em trong 1 giờ đầu.  
Gọi hỗ trợ của đồng nghiệp hoặc các chuyên khoa Cấp cứu, Hồi sức tích cực (nếu cần).  
**_Xử trí tiếp theo_**
__Adrenalin truyền tĩnh mạch:__ nếu tình trạng huyết động vẫn không cải thiện sau 3 lần tiêm bắp adrenalin (có thể sau liều tiêm bắp adrenalin thứ hai)
Liều adrenalin truyền tĩnh mạch khởi đầu: 0,1µg/kg/phút (khoảng 0,3mg/giờ ở người lớn), điều chỉnh tốc độ truyền theo huyết áp, nhịp tim và SpO2 đến liều tối đa 2 - 4mg/giờ cho người lớn. Ví dụ cách dùng adrenalin như sau: Adrenalin (1mg/ml) 2 ống + 500ml dd glucose 5% (dung dịch adrenalin 4µg/ml). Tốc độ truyền với liều adrenalin 0,1 µg/kg/phút theo hướng dẫn sau:
**Cân nặng (kg)** |  **Tốc độ truyền** |  **Cân nặng** |  **Tốc độ truyền**  
---|---|---|---  
**ml/ giờ** |  **Giọt/ phút** |  **(kg)** |  **ml/ giờ** |  **Giọt/ phút**  
Nếu có máy truyền dịch: Truyền adrenalin tĩnh mạch 0,1µg/kg/phút (khoảng 0,3mg/ giờ ở người lớn), điều chỉnh tốc độ truyền theo huyết áp, nhịp tim và SpO2 đến liều tối đa 2 - 3mg/giờ cho người lớn.Nếu không đặt được truyền adrenalin tĩnh mạch có thể dùng dung dịch adrenalin 1/10.000 (pha loãng 1/10) tiêm qua ống nội khí quản hoặc tiêm qua màng nhẫn giáp với liều 0,1ml/kg/lần, tối đa 5ml ở người lớn và 3ml ở trẻ em.
__Đảm bảo tuần hoàn, hô hấp__
Ép tim ngoài lồng ngực, bóp bóng Ambu có oxy nếu ngừng tuần hoàn.
Mở khí quản ngay nếu có phù nề thanh môn (da xanh tím, thở rít).
__Các thuốc khác__
Diphenhydramin (dimedrol): ống 10mg, tiêm bắp hoặc tiêm tĩnh mạch. Có thể tiêm nhắc lại mỗi 4 - 6 giờ.
Methylprednisolon: lọ 40 mg tiêm bắp hoặc tiêm tĩnh mạch 2 lọ ở người lớn, 1 lọ ở trẻ em 6 tuổi - 12 tuổi, ½ lọ ở trẻ em < 6 tuổi và ¼ lọ ở trẻ em < 6 tháng tuổi, có thể tiêm nhắc lại mỗi 4 - 6 giờ.
Thuốc giãn phế quản phối hợp, nếu còn co thắt phế quản hoặc khó thở không cải thiện sau dùng adrenalin:
Salbutamol100µg 2 - 4 nhát, 4 - 5 lần/ giờ hoặc salbutamol ống 5mg hoặc ipratropium 0,5mg khí dung qua mask cho người lớn, ống 2,5mg cho trẻ em, 4 - 5 lần/ giờ hoặc
Salbutamol hoặc terbutalin truyền tĩnh mạch 0,1 µg/kg/phút. Điều chỉnh liều dùng theo diễn biến tình trạng hô hấp, hoặc Terbutalin 0,5 mg x 1 ống tiêm dưới da
Aminophyllin truyền tĩnh mạch chậm 1mg/kg/giờ
Kháng histamin H2: Ranitidin 50mg tiêm tĩnh mạch chậm ở người lớn. Ở trẻ em dùng liều 1mg/kg.
Các thuốc co mạch: có thể dùng phối hợp thêm trong một số trường hợp tụt huyết áp không đáp ứng với adrenalin.
Glucagon: sử dụng trong trường hợp tụt huyết áp và nhịp chậm không đáp ứng với adrenalin (người bệnh đang dùng thuốc chẹn beta giao cảm). Liều dùng: 1 - 5mg tiêm tĩnh mạch trong 5 phút (trẻ em: 20 - 30µg/kg, tối đa 1mg), duy trì truyền tĩnh mạch 5 - 15 µg/phút tuỳ theo đáp ứng lâm sàng.
**_Chú ý:_**
Điều dưỡng, nữ hộ sinh có thể sử dụng adrenalin tiêm bắp theo phác đồ khi bác sỹ không có mặt.
Tùy theo điều kiện và chuyên khoa mà sử dụng các thuốc và phương tiện cấp cứu hỗ trợ khác
Người bệnh SPV cần được theo dõi ở bệnh viện đến 72 giờ sau khi huyết động ổn định.
**Điều trị một số thể lâm sàng khác** (mày đay, phù Quincke, bệnh huyết thanh, đỏ da toàn thân, các loại hồng ban...).
Ngừng ngay việc tiếp xúc với thuốc (tiêm, uống, nhỏ mắt và nhỏ, xịt mũi...).
Hai loại thuốc chính để điều trị các hội chứng này:
_**Glucocorticoid:**_ methylprednisolon, mazipredon, betamethason, dexamethason, prednisolon... Liều dùng phụ thuộc vào thể lâm sàng và loại thuốc glucocorticoid: liều ban đầu tương đương prednisolon 1 - 2 mg/kg/24 giờ.
_**Kháng histamin H1:**_ có thể sử dụng một trong các thuốc diphenhydramin, levocetirizin, desloratadin, fexofenadin, cetirizin, loratadin, chlopheniramin, phenergan... Liều dùng tùy theo tuổi và cân nặng.
**Điều trị hội chứng Stevens - Johnson và Lyell**
Ngừng ngay việc tiếp xúc với thuốc (tiêm, uống, bôi, nhỏ mắt và nhỏ, xịt...)
Như điều trị bỏng:
Bồi phụ nước, điện giải, dinh dưỡng và chống nhiễm khuẩn
_**Bồi phụ nước:**_ cần cung cấp đủ dịch: glucose 5%, dung dịch Lactate Ringer hoặc NaCl 0,9% từ 500 ml - 2000 ml/ ngày, qua đường tĩnh mạch, thời gian truyền tùy vào tình trạng của người bệnh.
_**Bồi phụ các chất điện giải:** _dựa vào điện giải đồ
_**Dinh dưỡng:**_ nếu chưa loét trợt đường tiêu hóa, cần cho ăn súp đủ số lượng và dinh dưỡng (giàu protein) qua miệng hoặc xông dạ dày. Nếu có loét trợt đường tiêu hóa: cho qua dịch truyền, cần thiết có thể truyền plasma tươi, albumin, dung dịch axit béo đến khi các rối loạn về dinh dưỡng được cải thiện.
_**Chống nhiễm khuẩn:** _tại chỗ kết hợp với toàn thân:
_Chăm sóc da:_ nên dùng những phương pháp đơn giản, bảo tồn, quan trọng là phải tránh làm tuột da người bệnh. Sát trùng chỗ da bị loét bằng nitrat bạc 0.5% hoặc chlorhexidin 0.05%. Băng bó bằng gạc với mỡ citrat bạc, polyvidoneiodin, hoặc các hydrogel. Cân nhắc sử dụng các loại da sinh vật che phủ khi lớp da người bệnh bị bong tróc diện rộng.
_Chăm sóc mắt:_ phòng ngừa di chứng, biến chứng. Dùng đũa thủy tinh đầu dẹt để tách khi mí mắt bị loét, dính. Dùng nước mắt nhân tạo hoặc dung dịch NaCl 0,9% tra, rửa mắt nhiều lần hàng ngày.
_Vệ sinh các hốc tự nhiên_ hàng ngày bằng dung dịch NaCl 0,9%. Glycerin Borat bôi môi chống căng chảy máu. Cần loại bỏ các mảng cứng ở trong lỗ mũi và miệng, xịt vào miệng chất sát trùng vài lần mỗi ngày.
Sau khi khai thác kỹ tiền sử dị ứng thuốc, có thể cân nhắc dùng ** _thuốc kháng sinh_** khác nhóm hoặc không có mẫn cảm chéo với thuốc đã gây dị ứng.
**Điều trị dị ứng thuốc:**
_**Corticoid:** _Corticoid là thuốc cơ bản trong điều trị dị ứng thuốc nói chung và hai hội chứng Stevens - Johnson và Lyell. Cần sử dụng đúng liều, đúng chỉ định, đủ thời gian và lưu ý đến tai biến của thuốc.
Liều lượng: liều ban đầu tương đương prednisolon 1 - 2 mg/kg/24 giờ.
Nếu có tổn thương nặng nội tạng như: não, tim mạch, suy đa phủ tạng..., có thể dùng corticoid liều rất cao: methylprednisolon 500 - 1000 mg truyền tĩnh mạch trong 3 ngày, sau đó chuyển sang liều thông thường.
_**Kháng histamin H1:** _dùng đường tiêm giai đoạn đầu khi có tổn thương niêm mạc miệng và đường tiêu hóa, sau đó chuyển sang đường uống.
**Điều trị triệu chứng và biến chứng**
Điều trị triệu chứng: hạn chế tối đa số lượng thuốc, chỉ dùng khi cần.
Điều trị biến chứng: lưu ý tổn thương mắt. Những tổn thương giác mạc mạn tính có thể ghép biểu mô giác mạc, sau đó ghép giác mạc khi biểu mô đó ổn định (ghép giác mạc lớp, ghép giác mạc xuyên hoặc ghép giác mạc nhân tạo). Có thể mang kính áp tròng thấm khí làm giảm chứng sợ ánh sáng, cải thiện thị giác và làm lành những chỗ khuyết biểu mô giác mạc.
**TIÊN LƯỢNG VÀ TIẾN TRIỂN**
**Tiên lượng và biến chứng:** rất khó lường.
_**Tiên lượng SPV:**_ tỉ lệ tử vong khoảng 1% các trường hợp.
_**Tiên lượng hội chứng Stevens - Johnson và Lyell:**_ Theo chỉ số SCORTEN
Hội chứng Stevens - Johnson: tỉ lệ tử vong khoảng 10%, tiến triển nặng khi có biến chứng mất nước, protein, điện giải qua da, nhiễm khuẩn. Ngoài ra, có thể để lại sẹo ở mắt gây dính mống mắt, đường tiêu hoá, khí quản và cơ quan sinh dục.
Hội chứng Lyell: tỉ lệ tử vong khoảng 20 - 40%, tiên lượng nặng nề do tổn thương da và nội tạng rất nặng. Khoảng 20% người bệnh có hoại tử biểu mô phế quản gây suy hô hấp, có thể thể tử vong. Nhiều người bệnh có biến chứng ở mắt như loét giác mạc, dính mi, xơ cứng cùng đồ, dính kết mạc, lộn mi, lông quặm vàmù loà.
**Tiến triển dị ứng thuốc:**
Dị ứng thuốc lần sau nặng hơn lần trước. Khoảng 90% kháng thể IgE còn hiện diện trong huyết thanh người bệnh sau một năm bị dị ứng thuốc, sau 10 năm kháng thể IgE còn lại 20 - 30%. Đối với SPV, kháng thể được giữ lại lâu hơn.
**MỘT SỐ BIỆN PHÁP PHÒNG, HẠN CHẾ SPV VÀ DỊ ỨNG THUỐC**
**Dự phòng SPV:** các biện pháp dự phòng SPV được trình bày trong bảng 4.
**Bảng 4: Các biện pháp dự phòng SPV**
1. Hộp thuốc chống SPV phải đảm bảo có sẵn tại các phòng khám, buồng điều trị, xe tiêm và mọi nơi có dùng thuốc.  
---  
2. Thầy thuốc, y tá (điều dưỡng), nữ hộ sinh cần nắm vững kiến thức và thực hành cấp cứu SPV theo phác đồ.  
3. Phải khai thác kỹ tiền sử dị ứng thuốc và tiền sử dị ứng của người bệnh trước khi kê đơn hoặc dùng thuốc (ghi vào bệnh án hoặc sổ khám).  
4. Chỉ định đường dùng thuốc phù hợp nhất, chỉ dùng đường tiêm khi không có thuốc hoặc người bệnh không thể dùng thuốc đường khác.  
5. Trường hợp đặc biệt cần dùng lại các thuốc đã gây dị ứng mà không  
có thuốc thay thế thì cần hội chẩn chuyên khoa Dị ứng để tiến hành giảm mẫn cảm nhanh.  
6. Thầy thuốc phải cấp cho người bệnh thẻ theo dõi khi đã xác định được thuốc hay dị nguyên gây dị ứng, nhắc nhở người bệnh mang theo thẻ này mỗi khi đi khám, chữa bệnh.  
7. Cần tiến hành test da trước khi tiêm thuốc, vắc xin nếu người bệnh có tiền sử dị ứng thuốc, cơ địa dị ứng, nguy cơ mẫn cảm chéo... việc thử test da phải theo đúng quy định kỹ thuật, phải có sẵn các phương tiện cấp cứu SPV. Nếu kết quả test da (lẩy da hoặc trong da) dương tính thì lựa chọn thuốc thay thế.  
8. Người bệnh có tiền sử SPV cần được trang bị kiến thức dự phòng SPV và cách sử dụng bơm tiêm adrenalin tự động định liều nếu có.  
9. Đối với thuốc cản quang có thể dự phòng bằng glucocorticoid và kháng histamin.  
**Dự phòng chung dị ứng thuốc.**
**_Với người bệnh:_**
Không tự điều trị, chỉ dùng thuốc theo đơn của thầy thuốc.
Không dùng thuốc theo mách bảo của người khác, không dùng đơn thuốc của người khác hoặc đưa đơn thuốc của mình cho người khác sử dụng.
Không dùng thuốc mất nhãn, chuyển màu, có vật lạ, kết tủa trong ống thuốc, quá thời hạn sử dụng...
Tránh mua thuốc ở những nơi không đáng tin cậy.
Phải đọc kỹ tờ hướng dẫn sử dụng trước khi dùng thuốc, phải giữ hướng dẫn sử dụng vì có khi phải đọc lại nhiều lần.
Để thuốc xa tầm tay, tầm nhìn của trẻ em và người quá cao tuổi.
Thận trọng dùng thuốc khi đang có thai, cho con bú và trạng thái bệnh lý khác, thông báo những vấn đề này cho thầy thuốc trước khi kê đơn.
Khi có những dấu hiệu bất thường sau khi dùng thuốc: sốt, mệt mỏi khác thường, choáng váng, chóng mặt, buồn nôn, mẩn ngứa trên da...cần đến ngay thầy thuốc, bệnh viện hoặc các cơ sở y tế gần nhất để được khám, điều trị.
Cần mang theo thẻ theo dõi dị ứng thuốc hoặc nếu có thể đeo vòng cảnh báo dị ứng thuốc.
**_Với thầy thuốc và dược sỹ_**
Chỉ dùng thuốc cho người bệnh khi cần thiết.
Dùng thuốc đúng người, đúng bệnh.
Cân nhắc trước khi cho một loại thuốc có nguy cơ cao gây ra những tác dụng không mong muốn.
Không điều trị bao vây.
Có kiến thức về an toàn thuốc và có hiểu biết về những tai biến do thuốc

## ️ Các phản ứng quá mẫn với vắc xin (Vaccine Hypersensitivity)

**ĐẠI CƯƠNG**
Tỷ lệ các phản ứng không mong muốn do vắc xin dao động trong khoảng 4,8 - 83 ca/ 100.000 liều vắc xin, trong đó, tỷ lệ các phản ứng dị ứng là khoảng 1 / 50.000 - 1 / 100.000 liều tiêm vắc xin. Vắc xin và các thành phần tá dược đều có thể gây ra các tác dụng không mong muốn. Những vắc xin có thành phần bao gồm trứng hoặc gelatine thì phản ứng dị ứng thường nặng và tần suất xuất hiện các phản ứng dị ứng cũng cao hơn. Tuy vậy, SPV rất hiếm khi xảy ra, chỉ khoảng 1 / 1.000.000 liều dùng. Các biểu hiện phản ứng phụ do vắc xin rất đa dạng nhưng hầu hết khu trú tại chỗ tiêm và là hậu quả của quá trình viêm không đặc hiệu do các thành phần trong vắc xin như muối nhôm. Hiện chưa có bằng chứng cho thấy có tăng nguy có dị ứng vắc xin ở những người có cơ địa dị ứng (atopy).
Các phản ứng nhẹ tại chỗ hoặc tình trạng sốt sau tiêm vắc xin thường xảy ra và không có chống chỉ định tiêm những liều vắc xin sau. Tuy nhiên, những trường hợp phản ứng dị ứng toàn thân hoặc SPV cần được thăm khám, khai thác tiền sử dị ứng, làm test da với vắc xin và thành phần trong vắc xin để có thể đưa ra chẩn đoán và quyết định điều trị đúng ở người bệnh có phản ứng tức thì với vắc xin.
**_Bảng 1: Tần suất xuất hiện các tác dụng phụ của một số vắc xin thông thường_**
**Vắc xin** |  **Phản ứng phụ/100000 liều**  
---|---  
Influenza  
Hepatitis B |  11,8  
Sởi - quai bị - rubella |  16,3  
Bạch hầu - ho gà - uốn ván |  12,5  
**BIỂU HIỆN LÂM SÀNG CỦA DỊ ỨNG VẮC XIN**
**Phản ứng tức thì/qua trung gian IgE**
Các dấu hiệu của phản ứng dị ứng tức thì sau tiêm/uống vắc xin thường nổi trội là các triệu chứng toàn thân kết hợp với các biểu hiện trên da như ban đỏ, phù Quincke, mày đay, các triệu chứng đường hô hấp như viêm mũi - kết mạc hoặc cơn co thắt phế quản và các biến chứng tim mạch với biểu hiện mệt mỏi, chóng mặt, tụt huyết áp và thậm chí người bệnh có thể rơi vào tình trạng sốc trong vòng vài phút tiêm/uống vắc xin.
**Các triệu chứng của SPV:**
Các phản ứng phản vệ thường xảy ra trong vòng 4 giờ sau tiêm vắc xin bao gồm các triệu chứng sau:
Biểu hiện trên da: mày đay, phù mạch (phù Quincke), ngứa và ban giãn mạch
Đường hô hấp: ngạt mũi, chảy mũi, sung huyết niêm mạc mũi, tiếng thở rít do phù nề hầu họng và thanh quản hoặc các triệu chứng ở đường hô hấp dưới như khò khè, thở rít, tức nặng ngực, thở nông, nặng có thể suy hô hấp.
Tim mạch: hạ huyết áp, nhịp tim nhanh, da tái nhợt, nặng có thể ngừng tim
Biểu hiện dạ dày ruột: nôn, buồn nôn, đau quặn bụng, nặng có thể đại tiểu tiện không tự chủ.
**Chú ý** : Nghi ngờ SPV khi có ít nhất một triệu chứng hoặc dấu hiệu trong số 4 biểu hiện tại các cơ quan trên.
Dị ứng với các thành phần của vắc xin có vai trò hết sức quan trọng, đặc biệt là các vắc xin được nuôi cấy trong môi trường protein từ trứng, men bia rượu và gelatine. Các thành phần khác trong vắc xin như kháng sinh, các chất bảo quản, cố định, các thành phần nhiễm bẩn như latex cũng có thể là yếu tố kích phát hoặc là nguyên nhân của phản ứng dị ứng. Tuy nhiên, các protein trứng, gelatine và latex vẫn là nguyên nhân thường gặp nhất của các phản ứng dị ứng tức thì.
**Bảng 2: Phân loại các phản ứng qua trung gian miễn dịch liên quan vắc xin**
**Phân loại theo cơ chế miễn dịch** |  **Biểu hiện lâm sàng**  
---|---  
Phản ứng qua trung gian IgE |  SPV, mày đay, phù Quincke…  
Phức hợp miễn dịch (IgG) |  Viêm mạch, viêm cơ tim  
Phản ứng giả dị ứng |  Mày đay, phù Quincke, phản ứng giả phản vệ (anphylactoid), rối loạn dạ dày ruột…  
Phản ứng qua lympho T |  Ngoại ban, ban mụn mủ cấp toàn thân (AGEP), hồng ban đa dạng….  
Tự miễn/viêm |  Giảm tiểu cầu, Viêm mạch, viêm khớp dạng thấp, Sacoidosis, Hội chứng Reiter, Hội chứng Guillain - Barré, bọng nước…  
**Các phản ứng tại chỗ và quá mẫn chậm**
_**Các phản ứng tại chỗ:**_ Các phản ứng chậm với vắc xin thường biểu hiện tại chỗ tiêm. Các phản ứng này không được xếp vào nhóm các phản ứng dị ứng mà thường là hậu quả của phản ứng viêm không đặc hiệu do các thành phần như muối nhôm hoặc các thành phần vi sinh vật gây ra hay còn gọi là các yếu tố hoạt hóa.
_**Hiện tượng Arthus:** _Phức hợp kháng nguyên kháng thể được hình thành do tình trạng dư thừa kháng nguyên lắng đọng trên thành mạch và phức hợp này gây hoạt hóa bổ thể và tăng sự thâm nhiễm của các bạch cầu hạt đa nhân và với tình trạng phá hủy mô. Các phản ứng này thường tiến triển sau 6 - 12 giờ với sự có mặt của các kháng thể ở nồng độ cao hoặc thậm chí sau vài ngày như bệnh huyết thanh. Hậu quả của quá trình viêm cấp tính có thể dẫn đến sự phá hủy tổ chức. Một số triệu chứng có cơ chế giống bệnh huyết thanh là viêm khớp và sốt.
_**Các phản ứng quá mẫn chậm:**_ Các phản ứng qua trung gian tế bào lympho T thường biểu hiện dạng ezema tại chỗ, khởi phát sau từ 2 - 8 giờ cho đến 2 ngày sau chủng vắc xin. Đôi khi phản ứng cũng có thể lan rộng hơn và biểu hiện toàn thân như hồng ban đa dạng, hội chứng AGEP với biểu hiện sốt cao, ban mụn mủ cấp tình toàn thân sau tiêm vắc xin.
Các biểu hiện sưng đau tại chỗ cũng có thể xuất hiện và lan rộng tuy nhiên thường tự thoái lui từ 2 - 4 ngày mà không để lại biến chứng gì. Trong những trường hợp này thì không có chống chỉ định tiêm vắc xin sau đó. Các vắc xin sau đây thường gây ra các phản ứng tại chỗ nặng như: vắc xin phế cầu đa giá, cúm, ho gà và đặc biệt là vắc xin phối hợp bạch hầu và độc tố uốn ván cũng như viêm gan siêu vi B. Đáp ứng miễn dịch đối với uốn ván dẫn đến các tác dụng phụ tại chỗ gặp khoảng 80% ở người lớn. Khoảng 2% số trẻ em chủng vắc xin phối hợp ho gà và uốn ván (DTaP) có phản ứng tại chỗ.
**TIẾP CẬN CHẨN ĐOÁN**
Một số câu hỏi quan trọng cần được đánh giá trong quá trình khai thác và thăm khám người bệnh có tác dụng phân loại phản ứng. Các câu hỏi này được khai thác nhằm xác định thời gian khởi phát triệu chứng sau dùng vắc xin, loại hình tổn thương như: mày đay, phù Quincke hay SPV, ban mụn mủ...Tổn thương tại chỗ hay toàn thân? Phân biệt phản ứng quá mẫn nhanh và chậm ở người bệnh dị ứng vắc xin là cần thiết vì chúng ta phải lựa chọn xét nghiệm phù hợp để chẩn đoán, lựa chọn điều trị.
**Đối với phản ứng quá mẫn nhanh:**
Test lẩy da với vắc xin và các thành phần của vắc xin hoặc phát hiện
IgE đặc hiệu trong máu có thể có vai trò quan trong để xác định nguyên nhân gây dị ứng.
Đối với người bệnh có biểu hiện phản ứng nhanh qua trung gian IgE, xét nghiệm dị ứng được chỉ định nếu người bệnh cần tiếp tục tiêm vắc xin nghi ngờ gây phản ứng. Tuy nhiên chúng ta cũng cần biết một điều quan trọng là các test dị ứng trong chẩn đoán tình trạng quá mẫn với vắc xin không được chuẩn hóa và không nhiều giá trị. Khi thực hiện test, vắc xin phải còn nguyên vẹn và phải cùng nhà sản xuất để đảm bảo tính toàn vẹn và đảm bảo các thành phần tương tự trong vắc xin.
Test da được thực hiện theo khuyến cáo theo hướng dẫn giống cho các bệnh dị ứng khác. Do tình trạng kích ứng cao của test với vắc xin gây ra phản ứng dương tính giả, test nội bì với nồng độ không pha loãng nên được bỏ qua do đặc tính này. Hơn nữa, các phản ứng tại chỗ thường xảy ra với hầu hết các vắc xin với nồng độ 1/10 do đó trường hợp này cũng không phải là phản ứng dị ứng.
Trong trường hợp nhạy cảm với hợp chất của vắc xin được loại trừ, người bệnh có phản ứng quá mẫn nhanh có thể được dùng lại vắc xin, tuy nhiên phải được theo dõi một cách cẩn thận của bác sỹ chuyên khoa và tại trung tâm có thể cấp cứu SPV.
**Sơ đồ 1: Test da chẩn đoán dị ứng vắc xin**
**Test lẩy da với vacxin và các thành phần của vacxin pha loãng 1/10**  
---  
Âm tính 
**Test lẩy da với vacxin không pha loãng**  
---  
Âm tính 
**Test nội bì với nồng độ 1/100**  
---  
Âm tính 
**Test nội bì với nồng độ 1/10**  
---  
**Chú ý:**_Xét nghiệm nội bì với vắc xin nồng độ pha loãng 1/10 có thể gây dương tính giả do tình trạng kích ứng._
**Đối với dị ứng chậm:**
Test áp là chỉ định chủ yếu khi người bệnh có biểu hiện dị ứng chậm biểu hiện toàn thân. Tuy nhiên không có giá trị tiên lượng và độ nhạy khá thấp.
**ĐIỀU TRỊ**
**Điều trị phản ứng tại chỗ**
Chườm đá tại chỗ tiêm.
Nếu người bệnh đau nhiều có thể chỉ định paracetamol hoặc ibuprofen.
Paracetamol: 15 mg/kg/liều uống mỗi 4 - 6 giờ khi cần ở trẻ em, 650 mg/ liều uống mỗi 4 - 6 giờ khi cần ở người lớn.
Ibuprofen: 5 - 10 mg/kg/liều uống mỗi 6 - 8 giờ khi cần.
Nếu có biểu hiện dị ứng, ngứa tại chỗ có thể sử dụng kháng histamine đường uống.
Nếu các triệu chứng thuyên giảm, theo dõi người bệnh ít nhất 30 phút tiếp theo.
**Điều trị các phản ứng phản vệ**
Điều trị các phản ứng phản vệ nhẹ:
Các biểu hiện thường gặp là mày đay và phù mạch (Quincke). Thuốc được lựa chọn là kháng histamine. Nếu triệu chứng nặng, toàn thân cân nhắc dùng thêm corticosteroid. (Liều dùng xin tham khảo bài thuốc kháng histamine và corticosteroid trong bệnh dị ứng và tự miễn).
Điều trị SPV do vắc xin:
Tham khảo phần bài SPV.
**HƯỚNG DẪN TIÊM VẮC XIN Ở NGƯỜI BỆNH CÓ TIỀN SỬ DỊ ỨNG.**
**Quá mẫn tức thì/phản ứng qua trung gian IgE**
Một nguyên tắc chung nhất là phải đánh giá nguy cơ và lợi ích của từng trường hợp, mức độ nặng của phản ứng dị ứng và nhu cầu cần thiết phải dùng vắc xin cho người bệnh. Những qui tắc dưới đây cần được cân nhắc để có thể đưa ra quyết định sử dụng vắc xin an toàn:
Lựa chọn các chế phẩm vắc xin không có kháng nguyên nghi ngờ gây dị ứng nếu có sẵn: ví dụ như vắc xin không có gelatine.
Nếu các xét nghiệm không thể kết luận được nguyên nhân và các vắc xin phối hợp có nguy có cao gây dị ứng thì nên tiêm từng loại và vào các ngày khác nhau.
Nếu test lẩy da âm tính, và người bệnh không có tiền sử dị ứng nặng với biểu hiện SPV, vắc xin có thể được tiêm dưới sự giám sát chặt chẽ của bác sỹ chuyên khoa và theo dõi người bệnh trong vòng 1 giờ sau tiêm.
Nếu test lẩy da âm tính mà tiền sử nghi ngờ SPV hoặc các phản ứng nặng khác, phác đồ sẽ được tiêm là 2 liều: liều đầu 10% vắc xin không pha loãng và sau 30 phút nếu không có phản ứng, liều 2 tiêm 90% còn lại và theo dõi trong vòng 1 giờ sau tiêm.
Nếu test lẩy da dương tính với vắc xin hoặc thành phần của vắc xin và người bệnh có chỉ định tuyệt đối phải tiêm vắc xin, tiêm theo liệu pháp tăng liều dần theo khuyến cáo của Học viện Nhi Khoa Hoa Kỳ có thể được cân nhắc.
Liều tiêm tăng dần sau mỗi 15 đến 30 phút cho đến khi đạt liều tiêm hoặc cho đến khi xảy ra phản ứng phụ đầu tiên được phát hiện. Đối với một số trường hợp, phụ thuộc vào tiền sử, khoảng thời gian giữa các liều có thể được kéo dài hơn (bảng 3).
**Bảng 3: Phác đồ tiêm vắc xin nhiều mũi**
|  **Lượng vắc xin tiêm (mL)** |  **Nồng độ** |  **Khoảng thời gian (Phút)**  
---|---|---|---  
0,05 |  1/10 |  15 - 30  
0,05 |  15 - 30  
15 - 30  
0,15 |  15 - 30  
15 - 30  
Tổng |  Tổng lượng vắc xin cần tiêm ~0,5 mL |  Nồng độ không pha loãng |  Theo dõi sau tiêm 60 phút  
**Chú ý:** Nếu lượng vắc xin cần tiêm là 1 mL thì liều tiêm tiếp theo là 0,5 mLđể đạt tổng liều là xấp xỉ 1 mL.
Trong trường hợp xảy ra phản ứng phụ trong quá trình tiêm với phác đồ tăng dần, có hai lựa chọn cho bác sỹ lâm sàng:
Dừng tiêm vắc xin
Có thể vẫn tiếp tục tiêm với liều tăng lên sau khi điều trị bằng kháng histamine hoặc corticosteroid liều thấp.
**Dị ứng chậm**
Đối với những người bệnh có phản ứng quá mẫn chậm, việc quyết định có tiếp tục tiêm vắc xin nữa hay không phụ thuộc vào biểu hiện của phản ứng trước đây bởi vì test áp không có giá trị tiên lượng nguy cơ. Quyết định tiêm lại vắc xin nên được thực hiện dựa trên từng người bệnh, phụ thuộc vào mức độ nghiêm trọng của việc tiêm vắc xin. Những người bệnh có biểu hiện quá mẫn chậm hoặc tại chỗ thường được tiêm với nồng độ không pha loãng và với tổng liều cần tiêm trong một lần.
Tiêm vắc xin ở người bệnh có tiền sử dị ứng trứng (Ovalbumin)
Những trẻ em bị dị ứng trứng nhưng có test lẩy da âm tính với vắc xin vẫn có thể dung nạp hoàn toàn với vắc xin ở liều tiêm dù có chứa Ovalbumin.
Nếu test lẩy da dương tính, cần đánh giá yếu tố nguy cơ và lợi ích cũng như sự cần thiết phải tiêm vắc xin, nếu bắt buộc, người bệnh nên được tiêm với phác đồ 2 liều nếu vắc xin đó có chứa protein trứng cao hơn 1,2 μg/mL. Người bệnh được điều trị trước với kháng histamin và steroid sau đó được tiêm 1/10 tổng liều và sau đó 30 phút nếu không có phản ứng, 9/10 liều còn lại sẽ được tiêm nốt
**_Hình:_**_Test lẩy da dương tính với vacxin Quinvaxem (DTPw, hepatitis_ _B & Hib) và lòng trắng trứng_
**TÀI LIỆU THAM KHẢO**
Nguyễn Văn Đĩnh (2012). Dị ứng vắc xin: cập nhật chẩn đoán và điều trị.  _Tạp chí Y học lâm sàng_ , Bệnh viện Bạch Mai, 65, 8 - 15.
Fritsche P.J, Helbling A, Ballmer - Weber B.K (2010). Vaccine hypersensitivity - - update and overview _.Swiss Med Wkly,_ 1,140 (17 - 18), 238 - 46
Kels J.M, Greenhawt M.J, Li J.T et al (2012). Advers e reactions to vaccines practice parameter 2012 update _. J Allergy Clin Immunol_ , 130, 25.
Madaan, A. and D.E. Maddox,  _Vaccine allergy: diagnosis and management._ Immunol Allergy
Wood R.A, Berger M, Dreskin S.C et al (2008). An Algorithm for Treatment of Patients With Hypersensitivity Reactions After Vaccines _._
_Pediatrics_ , 122(3), e771–7.
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh

## ️ Viêm gan tự miễn (Autoimmune Hepatitis)

**ĐẠI CƯƠNG**
Viêm gan tự miễn (VGTM) được mô tả lần đầu tiên bởi Waldenstrom và Henry George Kunkel cách đây hơn 50 năm, là nguyên nhân của 20% các trường hợp viêm gan mạn tính.
VGTM có thể gặp ở mọi lứa tuổi, nhiều nhất là nhóm tuổi 10 - 30. Độ lưu hành của bệnh ở người da trắng là 50 - 200 trường hợp/ 1.000.000 dân,hay gặp ở nữ giới (tỉ lệ nữ / nam là 4/1). Nếu không điều trị, VGTM có tỉ lệ tử vong lên tới 50% trong vòng 5 năm.
Bệnh đặc trưng bởi tình trạng tăng men gan aminotransferase và viêm quanh khoảng cửa trên mô học, tiến triển với tổn thương hoại tử bắc cầu nhiều thùy và chuyển thành xơ gan.
**Triệu chứng lâm sàng**
Tỷ lệ các triệu chứng lâm sàng hay gặp của VGTM được trong bảng 1.
**Bảng 1: Các biểu hiện lâm sàng thường gặp của VGTM**
**Biểu hiện** |  **Tỷ lệ (%)**  
---|---  
Triệu chứng |  Mệt mỏi  
Nước tiểu sẫm màu/phân bạc màu  
Đau vùng gan  
Đau cơ  
Gầy sút  
Ỉa chảy  
Khám lâm sàng |  Gan to  
Lách to |  32 - 56  
Vàng mắt/da  
Cổ chướng  
Bệnh não do gan  
Xét nghiệm |  Tăng gammaglobuline  
Bilirubine > 3mg/dL  
Phosphatase alkaline > 2lần  
AST > 1000U/L  
Mô bệnh học |  Hoại tử lan tỏa (nặng)  
Viêm phân thùy (trung bình - nặng)  
Thâm nhiễm tương bào  
Xơ hóa  
**CHẨN ĐOÁN VÀ PHÂN LOẠI VGTM**
**Chẩn đoán**
Do không có tiêu chuẩn “vàng” trong chẩn đoán VGTM, nên việc chẩn đoán vẫn chủ yếu bằng phương pháp loại trừ các nguyên nhân gây viêm gan mạn khác. Sau đây là tiêu chuẩn chẩn đoán của nhóm nghiên cứu VGTM Thế giới được đưa ra năm 1999.
**Bảng 2: Thang điểm chẩn đoán VGTM**
**Chỉ số/ Đặc điểm** |  |  **Lượng rượu trung bình** < 25 g/ngày  
---|---|---  
**Nữ giới**  
**Tỷ lệ phosphatase kiềm/AST (hoặc ALT)** < 1.5 |  >60 g/ngày  
**Mô học gan**  
1.5 - 3.0 |  Viêm gan bề mặt  
< 3.0 |  Thâm nhiễm chủ yếu tế bào lympho dạng tương bào Cụm tế bào gan hình hoa hồng |   
**Kháng thể kháng nhân, SMA hoặc**  
>1/80 |  Không có tất cả các tổn thương trên  
1:80 |  Thay đổi đường mật  
1:40 |  Thay đổi khác  
<1/40 AMA dương tính |  |  Các bệnh tự miễn dịch khác  
**Các thông số bổ sung tùy chọn** Các tự kháng thể được xác định khác  
**Marker virus viêm gan**  
Dương tính Âm tính |  - 3 +3 |  Kháng nguyên bạch cầu người +1 (HLA) DR3 hoặc DR4  
**Đáp ứng điều trị** Hoàn toàn +2  
**Tiền sử dùng thuốc**  
Dương tính Âm tính |  - 4 +1 |  Tái phát +3  
Tổng điểm A>15 hoặc >17 tương ứng để chẩn đoán xác định AIH trước hoặc sau điều trị. Tổng số điểm nằm trong khoảng 10 - 15 và 12 - 17 sẽ tương ứng đưa ra chẩn đoán nghi ngờ trước hoặc sau điều trị.  
**PHÂN LOẠI**
VGTM được chia thành 3 thể theo kết quả xét nghiệm các tự kháng thể (bảng 3)
**Bảng 3: Phân loại VGTM**
**Lâm sàng - xét nghiệm** |  **Type I** |  **Type II** |  **Type III**  
---|---|---|---  
Tự kháng thể |  LKM 1 |  SLA/LP  
Tuổi |  10 - 20 và 45 - 70 |  2 - 14 |  30 - 50  
Nữ (%)  
Bệnh tự miễn kèm theo (%)  
Gamma globulin  
Immunoglobulin A |  Không |  Có thể |  Không  
B8, DR3, DR4 |  B14, DR3, C4AQ0 |  Không rõ  
Đáp ứng corticoid |  Trung bình |  Trung bình  
Tiến triển xơ gan (%)   
**CHẨN ĐOÁN PHÂN BIỆT:**
**Xơ đường mật tiên phát:**
Lâm sàng, sinh hóa, mô học như viêm gan tự miễn cùng với viêm loét đại tràng mạn tính và được chẩn đoán qua chụp đường mật.
Mô bệnh học có thâm nhiễm lympho và xơ đường mật.
**Xơ đường mật trong gan tiên phát:**
Chủ yếu ở trẻ em, có AMA hiệu giá thấp và kháng thể kháng LKM hiệu giá cao.
Chẩn đoán khó do bệnh cảnh lâm sàng và huyết thanh học nghèo nàn. Kháng thể kháng 70 - kd pyruvate dehydrogenase - E2 có giá trị chẩn đoán cao (80 - 95%).
**Viêm đường mật tự miễn:**
Tăng phosphatase kiềm, γ GT. Có ANA và SMA dương tính.
Mô học: tổn thương khoảng cửa, thâm nhiễm lympho, tương bào và viêm đường mật.Đáp ứng với điều trị corticoid.
**Viêm gan virus:**
Xét nghiệm tìm virus viêm gan A, B, C dương tính. Các chỉ số transaminase, bilirubin, gamma globulin, IgG và phosphatase kiềm tăng cao hơn so với VGTM.
Trên mô học thường có hoại tử trên nhiều phân thùy gan.
**Viêm gan mạn tính không rõ căn nguyên:**
Không có kháng thể kháng cơ trơn, kháng nhân, microsome gan/thận type I cùng với hình ảnh mô học điển hình của VGTM, HLA - B8, HLA - DR3, HLA - AI - B8 - DR3. Đáp ứng khi điều trị với corticoid.
**TIÊN LƯỢNG:**
Các chỉ số tiên lượng dựa vào:
XN sinh hóa khi đến khám:
AST > 10 lần bình thường: 50% tử vong sau 3 năm
AST > 5 lần và GGT > 2 lần bình thường: 90% tử vong sau 10 năm.
AST < 10 lần và GGT < 2 lần bình thường: 49% xơ gan sau 15 năm; 10% tử vong sau 10 năm.
Mô bệnh học khi đến khám:
Hoại tử khoảng của: 17% xơ gan sau 5 năm.
Hoại tử bắt cầu: 82% xơ gan sau 5 năm; 45% tử vong sau 5 năm
Xơ gan: 58% tử vong sau 5 năm.
**ĐIỀU TRỊ**
**Chỉ định điều trị:**
Phụ thuộc mức độ hoạt động của bệnh (bảng 4).
**Bảng 4: Chỉ định điều trị VGTM**
**Chỉ định tuyệt đối** |  **Chỉ định tương đối**  
---|---  
AST > 10 lần chỉ số bình thường hoặc AST > 5lần chỉ số bình thường vàgamma globulin > 2 lần chỉ số bình thường với tổn thương mô bệnh học dạng hoại tử lan tỏa |  Triệu chứng (mệt mỏi, vàng da) AST và/hoặc gamma globulin < 2 lần Tổn thương chủ yếu quanh khoảng cửa  
**Phác đồ điều trị**
Phác đồ điều trị VGTM cụ thể được trình bày trong bảng 5.
**Bảng 5: Phác đồ điều trị VGTM**
**Giai đoạn điều trị** |  **Đơn trị liệu** |  **Điều trị phối hợp**  
---|---|---  
**Điều trị tấn công**  
Tuần 1 Tuần 2 Tuần 3 Tuần 4 |  40 - 60 mg prednisone/ngày 40 mg prednisone/ngày 30 mg prednisone/ngày Giảm liều 5mg mỗi tuần tới liều điều trị duy trì |  40 - 60 mg prednisone/ngày+ 1 - 2 mg azathioprin/kg 15 mg prednisone/ngày+ 1 - 2 mg azathioprin/kg 15 mg prednisone/ngày+ 1 - 2 mg azathioprin/kg  
**Điều trị duy trì** |  5 - 15 mg prednisone/ngày |  10 mg prednisone/ngày+ 1 - 2 mg azathioprin/kg Điều trị thay thế:azathioprin 2 mg /kg  
**Tái phát** |  Giống điều trị tấn công |  Giống điều trị tấn công  
**Các thuốc điều trị khác:**
Chỉ định khi người bệnh kháng hoặc có chống chỉ định với các thuốc trên:
Mycophenolate mofetil: có hiệu quả trong các trường hợp kháng thuốc.
Interferon - α : đối với viêm gan C thuộc type IIb khi hiệu giá tự kháng thể thấp.
Cyclosporin: khi kháng hoặc không dung nạp với liệu pháp corticoid.
Tacrolimus: khi kháng hoặc không dung nạp với liệu pháp corticoid.
**Theo dõi điều trị**
**Bảng 6: Theo dõi điều trị VGTM**
**Trước****điều trị** |  **Trong điều trị (mỗi 4 tuần)** |  **Thuyên giảm** |  **Sau điều tri**  
---|---|---|---  
**Mỗi 3 tuần** |  **Mỗi 3 tháng**  
Khám lâm sàng  
Sinh thiết gan  
Công thức máu  
Aminotransferase  
Bilirubin  
Ðông máu  
Tự kháng thể  
Chức năng tuyến giáp  
**Tiêu chuẩn đánh giá đáp ứng điều trị**
Tiêu chuẩn đánh giá đáp ứng với điều trị của VGTM được trình bày trong bảng 7.
**Bảng 7: tiêu chuẩn đánh giá đáp ứng điều trị VGTM**
**Định nghĩa** |  **Tiêu chuẩn**  
---|---  
Đáp ứng hoàn toàn |  Không có triệu chứng Bilirubin và gamma globulin bình thường Transaminase < 2 lần bình thường Mô bệnh học bình thường hoặc viêm tối thiểu  
Đáp ứng một phần |  Cải thiện một phần lâm sàng, sinh hóa và mô học Không đạt được thuyên giảm sau 3 năm điều trị  
Không đáp ứng |  Tăng triệu chứng lâm sàng, sinh hóa và mô bệnh học, mặc dù tuân thủ điều trị Tăng transaminase ≥ 67 % Xuất hiện vàng da, cổ chướng hoặc bệnh não do gan  
**Tiêu chuẩn ngừng điều trị**
Khi đang điều trị duy trì azathioprin (2mg/kg/ngày) và Prednisone (515 mg/ngày)
Xét nghiệm: transaminase, gamma globulin, billirubin bình thường ít nhất 2 năm
Không có dấu hiệu hoạt động trên hình ảnh sinh thiết gan - Theo dõi ALAT và gamma globulin mỗi tháng
Khi ALAT tăng điều trị trở lại với corticoid.
**TÀI LIỆU THAM KHẢO**
Friedman, Sleisenger. Chapter 75. Autoimmune Hepatitis.  _Sleisenger_ _& Fordtran’s Gastrointestinal and Liver Disease, Pathophysiology, Diagnosis, Management_. 7th Edition.
Castro D.O, Gourley M (2010).Diagnostic Testing and Interpretation of Tests for Autoimmunity.  _J Allergy Clin Immunol_ , 125(2 Suppl 2), S238– S247.
Czaja, Albert J (2005). Current Concepts in Autoimmune Hepatitis.  _Annals of Hepatology_ , 4(1), 6 - 24.
Czaja, Albert J (2005). Treatment Challenges and Investigational Opportunities in Autoimmune Hepatitis.  _Hepatology,_ 41, 207 - 215.
Chu Chi Hieu, Nguyen Van Dinh, Nguyen Van Doan (2011). Mycophenolate mofetil for refractory Autoimmune hepatitis.  _Vietnam Journal of Internal medicine ISSN: 0868 - 3109_ , 248 - 249.
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh

## ️ Viêm mũi dị ứng (Allergic Rhinitis)

**ĐẠI CƯƠNG**
VMDƯ là bệnh lý viêm niêm mạc mũi qua trung gian của kháng thể IgE (Type 1 - theo phân loại của Gell - Coombs) do tiếp xúc với dị nguyên đường hô hấp với tam chứng kinh điển trên lâm sàng: hắt hơi, ngứa mũi, chảy nước mũi.
**Dịch tễ học:**
Gặp ở tất cả mọi lứa tuổi, nhiều nhất là lứa tuổi thanh thiếu niên
Nam bị bệnh nhiều hơn nữ, bằng nhau sau dậy thì
Bệnh không gây tử vong, chủ yếu ảnh hưởng đến chất lượng cuộc sống và có nguy cơ biểu hiện của bệnh hen.
Nguyên nhân: bụi nhà, phấn hoa, nấm mốc, lông vũ, bụi công nghiệp...
**ĐẶC ĐIỂM LÂM SÀNG VÀ CẬN LÂM SÀNG**
**Lâm sàng**
Các triệu chứng cơ năng thường gặp: hắt hơi, ngứa mũi, chảy nước mũi, ho, khò khè, tắc ngạt mũi, chảy nước mắt, ngứa mắt, mệt mỏi
Soi mũi: niêm mạc phù nề, nhợt nhạt, cuốn mũi phù nề, xung huyết, có nhiều dịch tiết trong nhày, có thể có lệch vẹo vách ngăn, polyp, phì đại cuốn mũi… Triệu chứng khác: VKM, chàm, nghe phổi có tiếng khò khè, thở rít…
Các bệnh kết hợp: HPQ, VDDƯ, viêm xoang, VKM dị ứng, viêm tai giữa, tắc vòi Eustache
Khai thác tiền sử dị ứng:
Khởi phát, mức độ nặng, triệu chứng phối hợp, dị nguyên nghi ngờ…
Tiền sử gia đình, bản thân: HPQ, mày đay, VKM, dị ứng thuốc, thức ăn…
Môi trường sống và làm việc: bụi, ẩm, lạnh…
Tiền sử chấn thương
**Cận lâm sàng**
Soi dịch mũi: bạch cầu ái toan - Test chẩn đoán nguyên nhân _:_
Test bì với dị nguyên nghi ngờ
Test kích thích: nếu dương tính giúp xác định được nguyên nhân
Các xét nghiệm in vitro nhằm phát hiện kháng thể dị ứng: IgE đặc hiệu (chủ yếu với dị nguyên hô hấp).
**CHẨN ĐOÁN**
**Chẩn đoán xác định cần dựa vào:**
Khai thác tiền sử và khám lâm sàng
Dịch rửa mũi
Test lẩy da với các dị nguyên
Định lượng IgE đặc hiệu
Test kích thích
Phân loại: Chia 2 loại:
VMDƯ: chia 2 nhóm dựa vào thời gian xuất hiện trong năm:
Theo mùa: dị nguyên là phấn hoa, nấm mốc…
Quanh năm: dị nguyên là bụi nhà, gián, lông súc vật… - Viêm mũi không dị ứng:
_Bảng 1: Phân loại viêm mũi theo ARIA 2010_
**Từng đợt** Triệu chứng: ≤ 4 ngày/ tuần |  **Dai dẳng** _Triệu chứng:_ 4 ngày /tuần và  
---|---  
≤ 4 tuần liên tiếp |  > 4 tuần liên tiếp  
_Gồm tất cả các yếu tố:_ Ngủ bình thường Không ảnh hưởng đến hoạt độ sinh hoạt hàng ngày Làm việc, học tập bình thường Không triệu chứng khó chịu |  **Trung bình - nặng** _Một hoặc nhiều yếu tố:_ Ngủ không bình thường Ảnh hưởng đến hoạt động, sinh hoạt hàng ngày Cản trở làm việc, học tập Triệu chứng khó chịu  
**Chẩn đoán phân biệt**
_**Viêm mũi vận mạch:** _quanh năm, không rõ nguyên nhân, biểu hiện chủ yếu là ngạt mũi, cuốn mũi phù nề nhiều, xét nghiệm dị ứng âm tính, dịch mũi nhiều bạch cầu trung tính.
_**Viêm mũi có hội chứng tăng bạch cầu ái toan:**_ xét nghiệm dị ứng âm tính, nhiều bạch cầu ái toan trong dịch mũi, nhạy cảm với corticoid
_**Viêm mũi do nhiễm khuẩn:**_ nước mũi đặc, có thể có màu vàng, xanh, hạch ngoại biên và có thể có sốt. Xét nghiệm dịch mũi có nhiều bạch cầu đa nhân trung tính.
_**Viêm mũi khác:**_ do thuốc ngừa thai, aspirin, thuốc co mạch, cường giáp trạng; do hormone thai nghén; do gắng sức…
_**Các bệnh tại mũi:** _Lệch vách ngăn, phì đại cuốn mũi, dị vật, khối u …
_**Viêm/miễn dịch:**_ Wegener’s, sarcoidosis, LBĐHT, Sjogren’s
_**Dò dịch não tủy**_
**ĐIỀU TRỊ**
**Mục tiêu và nguyên tắc điều trị**
_**Mục tiêu:**_
Cải thiện chất lượng cuộc sống
Giảm nhanh triệu chứng, ngăn ngừa tái phát
Thuốc điều trị phải an toàn
_**Nguyên tắc điều trị:**_
Phân loại đúng mức độ bệnh
**Điều trị theo bậc**
Tránh tiếp xúc với dị nguyên
Kiểm tra có hen kèm theo hay không, đặc biệt khi người bệnh bị nặng và/hoặc dai dẳng
Thuốc kháng histamine không gây buồn ngủ được ưu tiên hàng đầu
Thuốc co mạch, corticoid uống chỉ dùng trong đợt cấp và dùng ngắn ngày
Corticoid xịt chỉ dùng ở bậc hai, dùng hàng ngày và chỉ ngừng sau khi hết triệu chứng ít nhất 1 tháng
Kết hợp điều trị các bệnh đường hô hấp trên và dưới.
Giáo dục người bệnh
**Điều trị cụ thể**
Tránh tiếp xúc dị nguyên
Dùng thuốc: Xịt mũi ± đường uống
Kháng histamine H1: đường uống (fexofenadine, desloratadine, centirizin), đường xịt tại chỗ (azelastin).
Thuốc thông mũi, co mạch: phenylephrine, pseudoephrin uống hoặc oxymetazolin, phenylephrine… xịt mũi.
Corticoid xịt mũi (fluticasone, mometasone, budesonide), đường uống (prednison, methylprednisolone - chỉ dùng ngắn ngày, trong đợt cấp).
Kháng leukotriene: montekulast 10mg/viên/ngày (người lớn), 45mg/viên/ngày (trẻ em).
Thuốc bảo vệ dưỡng bào: cromolyn (5.2 mg/nhát) x 1 nhát/bên mũi, 4 - 6 lần/ ngày, thường kéo dài vài tuần, có thể dùng dự phòng trước khi tiếp xúc với dị nguyên
Kháng cholinergic: Ipratropium (21 mcg/nhát) x 2 nhát/bên mũi, 2 - 3 lần/ngày, hít cải thiện được triệu chứng xổ mũi, ít tác dụng toàn thân.
Giảm mẫn cảm đặc hiệu: Hiệu quả tốt với dị ứng phấn hoa theo mùa, thời gian ít nhất 3 năm. Tiêm dưới da hoặc nhỏ dưới lưỡi
_Bảng 2: Mô hình điều trị VMDƯ theo bậc của ARIA - WHO_
**Nhẹ từng đợt** |  **Nhẹ dai dẳng** |  **TB - nặng từng đợt** |  **TB - nặng dai dẳng**  
---|---|---|---  
**Liệu pháp miễn dịch**  
Cromon es xịt |  Glucocorticosteroid xịt mũi  
Thuốc co mạch/ kháng leukotriene/bảo vệ dưỡng bào/ kháng cholinergic  
Thuốc kháng histamine  
Phòng tránh dị nguyên  
VMDƯ ở trẻ em:
Trên 4 tuổi: điều trị giống người lớn. 
Trên 2 tuổi: Kháng histamin uống, xịt nước muối, corticoid xịt nếu triệu chứng nặng
Phụ nữ có thai: có thể dùng phối hợp các phương pháp sau:
Rửa mũi hàng ngày bằng nước muối sinh lý
Kháng histamin: loratadin, certirizine (B)
Corticoid xịt tại chỗ: budesonide (B)
Corticoid uống (C)
Các thuốc co mạch (C)
**THEO DÕI ĐIỀU TRỊ**
Thường đánh giá lại điều trị sau 2 - 4 tuần
Nếu không đáp ứng: điều chỉnh lại phác đồ, tăng bậc
Nếu đáp ứng: duy trì thuốc đang dùng
**DỰ PHÒNG**
Tránh các yếu tố kích ứng
Dùng thuốc theo đơn và khám theo hẹn
**TÀI LIỆU THAM KHẢO:**
Bousquet J, Schünemann H.J, Samolinski B et al (2012). Allergic Rhinitis and its Impact on Asthma (ARIA): achievements in 10 years and future needs.  _J Allergy Clin Immunol_ ,130(5), 1049 - 62.
Orban N.T, Saleh H, Durham S.R (2008). Allergic and NonAllergic Rhinitis._Middleton’s Allergy: Principle and practice_ , 7th edition, Mosby, 973 - 98.
Ledford D.K (2007). Allergic Rhinitis._Allergic Diseases_ , 3th edition, Humana Press, Totowa, New Jersey, 143 - 166.
Dykewicz M.S (2003). Rhinitis and sinusitis.  _J. Allergy Clin Immunol,_ 111, S520 - S529
Suonpaa J (1996). Treatment of allergic rhinitis.  _Ann Med_ , 28, 17 - 22.
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh

## ️ Xơ cứng bì hệ thống (Systemic Sclerosis)

**Định nghĩa****:**
Xơ cứng bì hệ thống (XCB) là một bệnh tự miễn dịch mạn tính, không rõ căn nguyên , đặc trưng về lâm sàng bởi tình trạng dầy và cứng da do sự tích luỹ collagen, liên quan đến nhiều hệ cơ quan bao gồm ống tiêu hoá , tim, phổi, thận và mạch máu.
**BIỂU HIỆN LÂM SÀNG VÀ CẬN LÂM SÀNG**
**Biểu hiện lâm sàng.**
**Bảng 1: Các triệu chứng lâm sàng thường gặp trong XCB**
**Triệu chứng lâm sàng** |  **Tỷ lệ** |  **Triệu chứng lâm sàng** |  **Tỷ lệ**  
---|---|---|---  
Dấu hiệu Raynaud |  90 - 95 |  Rối loạn nhu động TQ  
Dầy da, cứng da |  Xơ phổi  
Giãn mao mạch dưới da |  Tăng áp ĐMP đơn thuần  
Viêm khớp/ đau khớp |  Suy tim  
Bệnh lý cơ vân |  Suy thận  
Hội chứng Raynaud
Gặp ở 95% người bệnh XCB, thường xuất hiện trước khi có cứng da từ vài tháng đến vài năm, xảy ra đột ngột sau khi bị lạnh hoặc sang chấn tâm lý và tiến triển qua 3 giai đoạn:
**Giai đoạn 1:** đầu ngón trắng, lạnh và giảm cảm giác do co ĐM.
**Giai đoạn 2:** Vùng chi tím và đau do ứ trệ máu ở hệ tiểu tĩnh mạch.
**Giai đoạn 3:** màu sắc da trở lại bình thường nhưng vẫn còn cảm giác tê bì hoặc kiến bò
Hơn 90% các trường hợp hội chứng Raynaud có xơ hoá đầu chi, mất móng, loét, hoại tử đầu chi và đôi khi phải cắt cụt.
**_Triệu chứng ở da và niêm mạc:_**
Biểu hiện ngoài da của XCB tiến triển qua 5 giai đoạn: phù nề, dầy da, chai cứng, teo da và da trở về bình thường.
Da mặt bị dày cứng gây mất nếp nhăn, môi mỏng căng, khuôn mặt vô cảm, khó há miệng. Cứng da ở các chi gây hạn chế vận động, giảm tiết mồ hôi, rụng lông, móng bị khô cứng, gẫy và có khía. 30% người bệnh có rối loạn sắc tố da với các đám tăng sắc tố xen kẽ với những điểm mất sắc tố da. Một số biểu hiện khác có thể gặp là loét miệng, áp xe răng lợi do loạn dưỡng, calci hoá dưới da ở đầu ngón hoặc vùng da cẳng tay, cổ , đầ u gối.
**_Triệu chứng cơ xương khớp:_**
Gặp ở 45% - 90% số người bệnh.
**Khớ****p:** Đau, viêm nhiều khớp đối xứng , có thể cứng khớp vào buổi sáng. Vị trí thường gặp là ở các khớp đốt, bàn ngón, cổ tay, gối, khuỷu, háng, có thể có sưng, nóng, đỏ . Thường có tràn dịch khớp do viêm bao hoạt d ịch và xơ hoá gân, dây chằng.
**Cơ:** biểu hiện đau cơ tăng dần , giai đoạn muộn thường có teo cơ , yếu cơ do hạn chế vận động, loạn dưỡng và xơ hoá cơ.
**_Triệu chứng ở phổi_**
Viêm phổi kẽ : Biểu hiện khó thở khi gắng sức, tức ngực, ho khan, giảm rì rào phế nang và ran nổ ở đáy phổi . Trong giai đoạn muộn, khi đã có xơ phổi, bệnh nhân khó thở cả khi nghỉ ngơi.
Tăng áp lực động mạch phổi (ĐMP): gây ho, khó thở , suy tim phải.
Một số bệnh nhân có thể có viêm phổi do hít, xuất huyết phổi.
**_Triệu chứng ở đường tiêu hóa:_**
Có thể biểu hiện triệu chứng trên toàn bộ ống tiêu hóa, bao gồm loét miệng, viêm teo gai lưỡi, rối loạn nuốt, áp xe lợi, trào ngược thực quản, giảm nhu động, loét, hẹp thực quản gây nuốt nghẹn, sặc, giảm nhu động dạ dày, giãn dạ dày, ứ đọng thức ăn, viêm loét, xuất huyết dạ dày, viêm ruột, rối loạn nhu động ruột, loét hoặc hoại tử ruột.
**_Triệu chứng tim mạch :_**
Viêm màng ngoài tim và TDMT xuất hiện ở khoảng 30 - 40% số BN, có thể tiến triển cấp hoặc mạn tính. Ngoại tâm thu thất và các rối loạn dẫn truyền khác gặp ở khoảng 80% số bệnh nhân. Suy tim phải thường gặp trong giai đoạn cuối. Tổn thương cơ tim rất hay gặp do rối loạn tuần hoàn vi mạch gây giảm tưới máu cho cơ tim.
**_Triệu chứng ở thận :_**
Các biểu hiện thường gặp là có protein niệu , tăng huyết áp do hẹp ĐM thận và suy thận tiến triển nhanh . Khoảng 80% các tổn thương thận xuất hiện trong vòng 4 - 5 năm đầu, trong đó, 15 - 20% dẫn đến suy thận cấp.
**_Các triệu chứng khác_**
Tổn thương hệ nội tiết sinh dục: có thể gặp suy giáp hoặc cường giáp , suy cận giáp do xơ hoá tuyến. Teo tuyến thượng thận trong XCB có thể do điều trị corticoid kéo dài hoặc là biểu hiện của bệnh . Suy giảm chức năng sinh dục cũng thường gặp.
Tổn thương tâm thần kinh: có thể gặp cả tổn thương ở hệ thần kinh trung ương, ngoại biên (đặc biệt là dây tam thoa) và thần kinh thực vật. Khoảng 50% bệnh nhân có trầm cảm.
Khô mắt, khô miệng cũng rất thường gặp
**Biểu hiện cận lâm sàng**
**_Xét nghiệm miễn dịch:_**
Hai loại tự kháng thể thường gặp nhất là kháng thể kháng nhân (> 90%) và kháng thể kháng Scl - 70 (25 - 40%).
**_Xét nghiệm huyết học:_**
Tốc độ máu lắng tăng cao trong đa số BN. Thiếu máu rất thường gặp do tình trạng viêm mạn tính , thiếu sắt do xuất huyết tiêu hoá kéo dài hoặc thiếu vitamin B12 và acid folic do giảm hấp thu.
**_Thăm dò chức năng phổi:_**
Thường có rối loạn thông khí hạn chế, giảm DLco do tăng áp ĐMP, viêm phổ i kẽ hoặc hạn chế thông khí.
**_Xquang phổi hoặc CT scan lồng ngực:_**
Có thể thấy tình trạng viêm phổi kẽ, xơ phổi, thường tập trung ở 2 đá y.
**_Thăm dò chức năng tim:_**
Ttrên siêu âm tim có thể phát hiện tăng áp ĐMP và giãn thất phải. Điện tâm đồ thường phát hiện ngoại tâm thu thất hoặc các rối loạn dẫn truyền khác.
Xét nghiệm sinh hoá má u và nước tiểu:
Có thể có tăng nồ ng độ urê, creatinin máu do suy thận, có protein niệu hoặc hồng cầu niệu do tổn thương cầu thận.
**CHẨN ĐOÁN**
Tiêu chuẩn chẩn đoán của Hội Khớp học Hoa kỳ năm 1980.
**Bảng 2: Tiêu chuẩn chẩn đoán xơ cứng bì của Hội Khớp học Hoa kỳ 1980**
**_Tiêu chuẩn chính_** _Xơ cứng da :_ dầy da, cứng da đối xứng ở ngón tay, gốc các khớp liên đốt hoặc khớp đốt bàn tay. Tổn thương da có thể liên quan đến toàn bộ bàn tay , cổ , ngực, bụng, mặt.  
---  
**_Tiêu chuẩn phụ_** _Xơ cứng đầu chi:_ các tổn thương da mô tả trên giới hạn ở ngón tay _Sẹo lõm hoặc mất lớp mô đệm đầu ngón tay, ngón chân:_ hậu quả của tắc mạch hoặc nhồi máu _Xơ hoá 2 đáy phổi_ : Hình ảnh mờ dạng lưới hoặc nốt, hình tổ ong hoặc hình kính mờ ở 2 đáy phổi trên phim thẳng hoặc phim CT scan lồng ngực  
**_Chẩ_ _n đoán xác định khi có 1 tiêu chuẩn chính hoặc ≥ 2 tiêu chuẩn phụ ._**
**Chẩn đoán phân biệt**
Bệnh mô liên kết hỗn hợp:
Thường có kèm theo các biểu hiện của luput ban đỏ hệ thống hoặc viêm da cơ, có kháng thể kháng RNP.
Dày cứng da do thuốc / hóa chất:
Không có các biểu hiện ở khớp, đường tiêu hóa,phổi và sự xuất hiện của các tự kháng thể.
**ĐIỀU TRỊ**
**Nguyên tắc điều trị:**
Điều trị kiểm soát bệnh + điều trị triệu chứng _._
**Điều trị cụ thể**
Các thuốc kiểm soát bệnh
_**Glucocorticoid (methylprednisolone, prednisolone hoặc prednisone):**_
Khởi đầu với liều 1,5 - 2 mg/kg/24h, giảm dần và duy trì ở liều 5 - 10mg/ ngày.
Các thuốc này tương đối ít tác dụng trong kiểm soát bệnh và nhiều tác dụng phụ nên tránh sử dụng kéo dài.
_**Cyclophosphamide (viên 50mg, lọ 200mg, 500mg):**_
Chỉ định: tổn thương phổi kẽ không đáp ứng với các thuốc khác.
Liều lượng: uống 1 - 2 mg/ kg/ 24h hoặc truyền tĩnh mạch 3 - 4 tuần 1 lần, mỗi lần 500 - 1000mg, giảm liều khi có suy thận . Thời gian điều trị 3 - 6 tháng.
Theo dõi điều trị: CTM 1 tuần /lần, XN chức năng gan thận trước điều trị và 1 tháng /lần trong thời gian điều trị. Ngưng điều trị nế u số lượng BC<1,5 G/ l, TC <100 G/ l, HC niệu (+). Bù dịch tối đa trong thời gian điều trị.
_**Cyclosporin A (viên 25mg, 100mg):**_
Chỉ định: tổn thương phổi kẽ không đáp ứng với các điều trị khác.
Liều lượng: 2 - 5mg/ kg/ 24h, uống chia 2 lần trong 3 - 6 tháng.
Theo dõi điều trị: Đo HA hàng tuần. Xét nghiệm chức năng thận trước điều trị và 1tháng/lần, MLCT 3 tháng/ lần trong thời gian điều trị.
_**D - Penicillamine (viên 300mg):**_
Chỉ định: trong tất cả các trường hợp có cứng da.
Liều lượng : 500 - 1000mg/ 24h (liều chuẩn ) hoặc 120 - 150mg cách ngày (liều thấp), dùng đường uống.
Theo dõi điều trị : XN hemoglobin, số lượng BC, TC, tổng phân tích nước tiểu trước điều trị, 2 tuần/ lần trong 2 tháng đầu, sau đó 4 tuần/ lần. Tạm ngưng thuốc nếu số lượng BC<1,5 G/ l, TC <100 G/ l, HC niệu (+).
**Điều trị triệu chứng**
_**Hộ****i chứng Raynaud**_
Tránh tiếp xúc với khói thuốc lá , tránh lạnh, giứ ấm toàn bộ cơ thể, đặc biệt bàn tay và tránh các sang chấn tâm lý .
Thuốc: thuốc chẹn kênh canxi đường uống (đặc biệ là nifedipine ) có hiệu quả tốt nhất. Dạng phóng thích chậm được dung nạp tốt và ít gây tụt huyết áp. Nếu không hiệu quả có thể dùng thêm iloprost truyền tĩnh mạch, prazosin uống hoặc nitroglycerin dán tại chỗ .
Khi có loét đầu chi: đảm bảo vô trùng , tránh bội nhiễm vùng tổn thương. Phẫu thuật loại bỏ tổ chức hoại tử và cắt cụt là những giải pháp cuối cùng.
_**Tổ****n thương da**_
Hạn chế tắm vì có thể làm khô da, nên sử dụng các kem làm ẩm da.
Colchicine có thể có hiệ u quả vớ i triệ u chƣ́ ng canxi hoá dưới da.
_**Triệ****u chứng cơ xương khớp**_
Thuốc chống viêm giảm đau không steroid (NSAID) có hiệu quả trong phần lớn trường hợp. Nếu có viêm cơ hoặc viêm gân - bao hoạt dịch không đáp ứng với NSAID, có thể dùng glucocorticoid liều thấp (tương đương prednisolone 10 - 20mg/ngày). Cần phối hợp với phục hồi chức năng.
Phối hợp thêm methotrexate nếu không đáp ứng với glucocorticoid.
_**Triệ****u chứng tiêu hoá**_
Những bệnh nhân có rối loạn nhu động thực quản nên ăn nhiều bữa nhỏ trong ngày và nằm cao đầu sau ăn , tránh ăn về đêm. Có thể dùng thêm các thuốc kháng axit như cimetidine, omeprazole.
Nếu có chướng bụng , ỉa chảy, sút cân, giảm hấp thu do rối loạn nhu động ruột non , điều trị bằng các kháng sinh phổ rộng như co- trim hoặc ciprofloxacin mỗi đợt 2 tuần. Bổ xung vitamin và muối khoá ng.
_**Triệ****u chứng tim phổi**_
Viêm phổi kẽ : giai đoạn sớm cần được điều trị bằng glucocorticoid và các thuốc ức chế miễn dịch. Khi tổ chức xơ phát triển nhiều, cân nhắc việc ghép phô i.
Tăng áp động mạch phổi đơn thuần: thở ôxy liên tục , dùng thuốc chống đông và điều trị suy tim phải có thể cải thiện tốt các triệu chứng. Cân nhắc sử dụng iloprost truyền tĩnh mạch.
Các biểu hiện tràn dịch màng tim , suy tim, rối loạn nhịp tim điều trị tương tự như trong các bệnh lý khác
_**Tổ****n thương thận**_
Dùng thuốc lợi tiểu nếu có suy thận , cân nhắc lọc máu sớm hoặc liên hệ ghép thận nếu có suy thận nặng không đáp ứng lợi tiểu.
Nếu có cao huyết áp : điều trị hạ áp bằng các thuốc chẹn kênh canxi, ức chế angiotensin II hoặc ức chế men chuyển (nếu không có hẹp động mạch thận hoặc suy thận nặng)
**THEO DÕI ĐIỀU TRỊ**
Tình trạng lâm sàng: cứng da, nuốt nghẹn, Raynaud, khó thở, ho, rối loạn nhịp tim...
Các xét nghiệm chức năng gan, thận, điện giải, CRP, tốc độ lắng máu
Các thông số nước tiểu: hồng cầu niệu, protein niệu
Kháng thể kháng nhân
Chức năng thông khí phổi, điện tâm đồ , Xquang tim phổi
**TÀI LIỆU THAM KHẢO**
Denton C.P (2006). Systemic sclerosis: clinical features and management.  _Medicine_ , 34, 11, 480 - 488.
Furst D. E., Pope J., Clements P., Ottawa Methods Group (2004). Systemic sclerosis.  _Evidence - based Rheumatology_. BMJ Publishing Group, 443 - 494.
Lin A.T.H, Clements P.G, Furst D.E (2003). Update on diseasemodifying antirheumatic drugs in the treatment of systemic sclerosis.  _Rheum Dis Clin N Am_ , 29, 409–426.
Sapadin A. N., Fleischmajer R (2002)**.** Treatment of Scleroderma._Arch Dermatol_ , 138: 99 - 105.
Valentini G., Black C (2002). Systemic sclerosis.  _Best Practice & Research Clinical Rheumatology_, 16, 5, 807 - 816.
Subcommittee for Scleroderma Criteria of the American Rheumatism Association Diagnostic and Therapeutic Criteria Committee (1980). Preliminary criteria for the classification of systemic sclerosis (scleroderma).  _Arthritis Rheum_ , 23, 581 - 90.
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh

## ️ Viêm kết mạc dị ứng (Allergic Conjunctivitis)

**ĐỊNH NGHĨA**
Viêm kết mạc (VKM) dị ứng là một tình trạng VKM mắt do cơ chế dị ứng, chủ yếu là type I, với các biểu hiện lâm sàng tại mắt. VKM thường không gây ảnh hưởng đến thị lực, nhưng một số ít trường hợp nặng có thể gây tổn thương giác mạc và đe dọa thị lực.
**PHÂN LOẠI:**
Bệnh lý VKM dị ứng chia làm 5 loại:
VKM dị ứng theo mùa (seasonal allergic conjunctivitis - SAC)
VKM dị ứng quanh năm (perennial allergic conjunctivitis - PAC)
Viêm kết - giác mạc atopy(Atopic keratoconjunctivitis - AKC)
Viêm kết - giác mạc mùa xuân (Vernal keratoconjunctivitis - VKC)
VKM có nhú khổng lồ (Giant papillary conjunctivitis - GPC)
**TRIỆU CHỨNG**
**Triệu chứng cơ năng**
Ngứa mắt: là triệu chứng điển hình trong VKM dị ứng
Cảm giác có dị vật trong mắt
Chảy nước mắt
Xuất tiết nhày và huyết thanh ở mắt.
**Triệu chứng thực thể**
Xung huyết kết mạc: do giãn mạch, là biểu hiện hay gặp nhất.
Phù nề kết mạc: do sự ứ trệ tuần hoàn của các mạch máu và bạch huyết trong kết mạc mi, gây ra thấm huyết tương từ mạch máu ra ngoài.
Nang kết mạc: nang lympho được thấy ở dưới biểu mô kết mạc mi dưới.
Nhú kết mạc: do sự tăng sinh biểu mô do viêm, trong đó các tế bào biểu mô bị phì đại. Các nhú có đường kính≥ 1mm được gọi là các nhú khổng lồ.
Các hạt Horner - Trantas: ở vùng rìa giác mạc, là các nhú nhỏ được tạo thành do sự thoái hóa của biểu mô kết mạc tăng sinh.
Tổn thương giác mạc trong các trường hợp nặng gồm có: viêm giác mạc có đốm trên bề mặt, do sự mất một phần biểu mô giác mạc; viêm giác mạc có đốm nang hóa; và loét hình khiên do sự mất biểu mô giác mạc lan rộng.
Xét nghiệm:
Có thể thấy các BC ái toan trong kết mạc. - Test kích thích nhỏ giọt xác định dị nguyên - Kháng thể IgE toàn phần trong nước mắt.
Kháng thể IgE đặc hiệu: test lẩy da và xét nghiệm máu.
**CHẨN ĐOÁN**
**VKM dị ứng theo mùa (SAC):** hay gặp nhất, chiếm > 50% trường hợp.
Triệu chứng chẩn đoán: ngứa mắt, chảy nước mắt, xung huyết mắt, cảm giác có dị vật trong mắt, xung huyết kết mạc, phù kết mạc, và nang kết mạc.
Các triệu chứng này xuất hiện hàng năm cùng trong một mùa. Triệu chứng quan trọng và phổ biến nhất của SAC là ngứa mắt.
Dị nguyên hay gặp nhất là phấn hoa, nên triệu chứng VMDƯ kèm theo được thấy trong 65 - 70% các trường hợp.
Xét nghiệm: có kháng thể IgE đặc hiệu; IgE toàn phần trong nước mắt; có BC ái toan ở kết mạc.
**VKM dị ứng quanh năm (PAC)**
Triệu chứng chẩn đoán: ngứa mắt, chảy nước mắt, xuất tiết mắt xuất hiện quanh năm,xung huyết kết mạc và nhú kết mạc, không có biến đổi tăng sinh ở kết mạc. Hầu hết các trường hợp diễn biến kéo dài mạn tính. Các triệu chứng lâm sàng thường nhẹ và không có triệu chứng thực thể đặc trưng, nên chẩn đoán lâm sàng có thể khó trong một số trường hợp, đặc biệt ở người già.
Dị nguyên chính là bọ nhà, ít gặp hơn là nấm mốc, lông hay vẩy da động vật.
Tỷ lệ dương tính với BC ái toan trong kết mạc thấp. c. Viêm kết - giác mạc atopy (AKC)
Triệu chứng chẩn đoán: các triệu chứng VKM thường là mạn tính gồm có: ngứa mắt, xuất tiết mắt, chói mắt, tăng sinh nhú, và tổn thương giác mạc; phối hợp với viêm da atopy với tổn thương vùng mặt. Viêm mạn tính kéo dài có thể dẫn đến thu hẹp túi cùng kết mạc và dính mi - cầu.
Xét nghiệm: Tăng IgE toàn phần trong huyết thanh và nước mắt, thấy IgE đặc hiệu trong huyết thanh với tỷ lệ cao.
**Viêm kết - giác mạc mùa xuân (VKC)** : thường khởi phát ở trẻ em.
Triệu chứng chẩn đoán: là một bệnh kết mạc dị ứng nặng với tổn thương tăng sinh ở kết mạc. Tổn thương tăng sinh gồm có: các nhú khổng lồ ở kết mạc mi trên, tăng sinh rìa giác mạc (tăng sinh dạng keo rìa giác mạc và các chấm Horner - Trantas),hay gặp tổn thương giác mạc và dễ dẫn đến tổn thương nặng. Các tổn thương giác mạc đặc trưng bao gồm: viêm giác mạc dạng chấm nang hóa, loét hình khiên, và mảng giác mạc. Có thể kèm theo VDCĐ. Chẩn đoán lâm sàng thường dễ vì các triệu chứng điển hình.
Dị nguyên chính là bọ nhà, có thể phản ứng với nhiều loại dị nguyên như phấn hoa, vẩy da động vật …
Xét nghiệm: Tăng IgE toàn phần trong huyết thanh và nước mắt, có kháng thể IgE đặc hiệu; có BC ái toan trong kết mạc.
**Viêm kết mạc có nhú khổng lồ (GPC)**
GPC là một dạng VKM kèm theo sự thay đổi tăng sinh kết mạc mi trên do các kích thích cơ học như:đeo kính áp tròng, mắt giả, chỉ phẫu thuật…
Chẩn đoán lâm sàng:ngứa mắt, cảm giác dị vật trong mắt, xuất tiết mắt, và xung huyếtmắt, phù kết mạc, và tăng sinh nhú khổng lồ. Trên lâm sàng,
GPC khác với VCK bởi không có tổn thương giác mạc và đặc điểm nhú khác nhau.
Xét nghiệm: Không thấy IgE đặc hiệu; ít thấy có BC ái toan trong kết mạc.
**CHẨN ĐOÁN PHÂN BIỆT:**
VKM do nhiễm khuẩn: virus, nấm, Chlamydia.
Nang kết mạc không do viêm.
Khô mắt trong bệnh tự miễn.
**ĐIỀU TRỊ**
**Nguyên tắc điều trị**
Kiểm soát để ngăn ngừa dị nguyên tiếp xúc với kết mạc.
Kiểm soát triệu chứng bằng thuốc.
**Điều trị cụ thể**
Ngăn ngừa dị nguyên tiếp xúc với kết mạc
Điều chỉnh môi trường sống trong nhà trong trường hợp dị ứng bọ nhà.
Đối với trường hợp dị ứng phấn hoa thì cần phải tránh tiếp xúc trong mùa phấn hoa, kính lồi được khuyến cáo đeo trong mùa phấn hoa có thể giảm đáng kể lượng phấn hoa tiếp xúc kết mạc mắt.
Ngừng sử dụng kính áp tròng trong trường hợp VKM do kính áp tròng.
Rửa mắt bằng nước mắt nhân tạo hàng ngày để loại bỏ các dị nguyên bám vào bề mặt mắt, loại nước mắt nhân tạo không có chất bảo quản có thể sử dụng an toàn kéo dài.
**Điều trị bằng thuốc**
**Thuốc nhỏ mắt chống dị ứng: là lựa chọn đầu tiên trong điều trị VKM dị ứng.**
Thuốc kháng histamin H1: rất hiệu quả trong giảm nhanh chóng triệu chứng ngứa và xung huyết kết mạc.
Thuốc làm ổn định dưỡng bào: tác dụng giảm ngứa, giảm xung huyết và kích ứng kết mạc mắt. Thuốc thường có tác dụng chậm và kéo dài, có thể mất vài tuần để đạt hiệu quả đầy đủ.
Thuốc nhỏ mắt vừa kháng H1 vừa ổn định dưỡng bào: có lợi ích vừa giảm nhanh triệu chứng do ức chế thụ thể histamine H1 và tác dụng lâu dài do ổn định dưỡng bào.
**Corticoids:**
Corticoid nhỏ mắt: được sử dụng kết hợp khi thuốc chống dị ứng đơn độc không đạt được hiệu quả đầy đủ. Các tác dụng phụ tại chỗ thường gặp tăng nhãn áp, tăng nhiễm khuẩn, và đục thủy tinh thể. Cần đo nhãn áp định kỳ ở trẻ em bởi vì tỷ lệ gây tăng nhãn áp cao.
Corticoid đường uống: được sử dụng cho trẻ em, các người bệnh khó tiêm dưới kết mạc và các người bệnh có tổn thương giác mạc. Thời gian dùng từ 1 - 2 tuần. Cần lưu ý các tác dụng phụ của thuốc.
Corticoid tiêm dưới kết mạc mi: Triamcinolone acetonide, betamethasone dạng dịch treo được tiêm dưới kết mạc mi trên ở các ca nặng hoặc khó chữa. Thận trọng với những người có tăng nhãn áp, không nên sử dụng nhắc lại hoặc dùng cho trẻ em dưới 10 tuổi - Thuốc nhỏ mắt ức chế miễn dịch: được dùng cho VKM mùa xuân. Được chỉ định trong các ca nặng kháng corticoid hoặc dùng phối hợp để giảm liều hoặc ngừng corticoid.
**Thuốc kháng histamine H1 đường uống:**
Tác dụng giảm triệu chứng mắt nhanh chóng nhưng có thể gây khô mắt. Thuốc thường được chỉ định trong trường hợp VKM dị ứng có kèm theo VMDƯ và các triệu chứng dị ứng toàn thân khác. Tránh dùng các kháng histamine H1 thế hệ 1.
**_Bảng 1: Liều lượng các thuốc dùng trong điều trị VKM dị ứng_**
**Loại thuốc** |  **Tên hoạt chất** |  **Liều dùng**  
---|---|---  
Thuốc kháng histamine H1 nhỏ mắt |  Antazolin 0,5% |  1 - 2 giọt x 4 lần/ngày  
Emedastin 0,05% |  1 giọt x 2 - 4 lần/ngày  
Pheniramine |  1gi ọt x 2 - 5 lần/ngày  
Levocabastine 0,05% |  1 giọt x4 lần/ ngày  
Thuốc làm ổn định dưỡng bào |  Sodium cromoglycate 2%/4% |  1 giọt x 2 - 4 lần/ngày  
Lodoxamine 0,1% |  1 giọt x 4 lần/ngày  
Nedocromil 2% |  1 giọt x 2 lần/ngày  
Pemirolast 0,1% |  1 giọt x 2 lần/ngày  
Thuốc vừa kháng H1 vừa ổn định dưỡng |  Olopatadine 0,1% |  1 giọt x 2 lần/ngày  
Ketotifen 0,025%. |  1 giọt x 2 lần/ngày  
Azelastine 0,05% |  1 giọt x 2 lần/ ngày  
Epinastin 0,05% |  1 giọt x 2 lần/ngày  
Corticoid nhỏ mắt |  Betamethason 0,1% |  1 giọt x 3 - 5 lần/ngày  
Dexamethasone 0,1%; |  1 giọt x 3 - 5 lần/ ngày  
Fluormetholone0,02%/0,1% |  1 giọt x 3 - 5 lần/ ngày  
Prednisolone 0,12%/1% |  1 giọt x 3 - 5 lần/ngày  
Rimexolone 1%; |  1 giọt x 4 lần/ ngày  
Loteprednol 0,5% |  1 giọt x 4 lần/ ngày.  
Thuốc nhỏ mắt ức chế miễn dịch |  Cyclosporin 0,05%; |  1 giọt x 2 lần/ ngày  
Tarcrolimus 0,03% |  1 giọt x 2 lần/ ngày.  
Thuốc kháng histamine H1 đường uống |  Loratadin 10mg |  1 viên/ ngày  
Cetirizin 10mg |  1 viên/ ngày  
Fexofenadin 180mg |  1 viên/ ngày  
Levocetirizin 5mg |  1 viên/ ngày  
Desloratadin 5mg |  1 viên/ ngày  
**_Lựa chọn thuốc điều trị_**
VKM dị ứng (SAC và PAC): Lựa chọn đầu tiên là các thuốc chống dị ứng nhỏ mắt. Có thể lựa chọn kết hợp thuốc ổn định dưỡng bào và thuốc kháng histamine. Trong giai đoạn triệu chứng nặng, có thể kết hợp thêm corticoid nhỏ mắt. Với VKM dị ứng theo mùa, thuốc kháng dị ứng nhỏ mắt có thể bắt đầu dùng 2 tuần trước ngày dự đoán là có phấn hoa hoặc khi bắt đầu có triệu chứng nhẹ xuất hiện.
VKM atopy: Khi thuốc chống dị ứng đơn thuần không đạt hiệu quả, có thể kết hợp thêm corticoid nhỏ mắt. Tại cùng thời điểm, cần điều trị tích cực cả viêm da mi, có thể kết hợp cả kháng histamine H1 đường uống và corticoid đường uống.
Viêm kết - giác mạc mùa xuân: Với các trường hợp vừa và nặng mà thuốc chống dị ứng nhỏ mắt không có hiệu quả, có thể thêm thuốc ức chế miễn dịch nhỏ mắt. Nếu không đạt được sự cải thiện với 2 thuốc, có thể thêm corticoid nhỏ mắt, corticoid đường uống, corticoid tiêm dưới kết mạc mi hoặc phẫu thuật tùy thuộc vào triệu chứng. Khi triệu chứng giảm bớt, corticoid nhỏ mắt nên được giảm liều rồi ngừng hẳn. Sau đó, điều trị được tiếp tục với một thuốc chống dị ứng nhỏ mắt và thuốc ức chế miễn dịch nhỏ mắt, và tiếp tục duy trì bằng thuốc chống dị ứng nhỏ mắt nếu thời gian bệnh tiếp tục kéo dài.
VKM có nhú khổng lồ: Lựa chọn đầu tiên là thuốc nhỏ mắt chống dị ứng, trong các ca nặng có thể thêm corticoid nhỏ mắt. Kèm theo là việc loại bỏ tác nhân kích thích.
**Điều trị phẫu thuật**
Phẫu thuật cắt bỏ các nhú kết mạc: trong các trường hợp triệu chứng không đỡ khi điều trị bằng thuốc và sự tăng sinh các nhú tiếp tục tiến triển gây tổn thương biểu mô giác mạc nặng nề. Hiệu quả điều trị nhanh, nhưng có thể tái phát trong một số trường hợp.
Phẫu thuật nạo bỏ các mảng giác mạc: khi triệu chứng không được cải thiện bằng thuốc.
**TÀI LIỆU THAM KHẢO**
Bielory B.P, O’Brien T.P, Bielory L (2012 _)_. Management of seasonal allergic conjunctivitis: guide to therapy.  _Acta Ophthalmol,_ 90(5), 399 - 407.
Williams D.C, Edney G, et al (2013 _)_. Recognition of allergic conjunctivitis in patients with allergic rhinitis.  _World Allergy Organization Journal,_ 6(1),4.
Takamura E, Uchio E, Ebihara N et al (2011). Japanese Guideline for Allergic Conjunctival Diseases.  _Allergology International_ , 60, 191 - 203.
Bielory L, Friedlaender M.H (2008). Allergic Conjunctivitis.  _Immunol Allergy Clin N Am,_ 28, 43–57.
Bielory L (2007). Diagnosis and Treatment of Ocular Allergy.  _Allergic Diseases: Diagnosis and Treatment, 3 rd edition,_ Humana Press, Totowa, New Jersey 181 - 199.
Sánchez M.C, Parra B.F, Matheu V et al (2011). Allergic Conjunctivitis.  _J Investig Allergol Clin Immunol_ ; 21 (Suppl. 2), 1 - 19.
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh

## ️ Mày đay - phù Quincke (Urticaria - Angioedema)

**ĐỊNH NGHĨA:**
Mày đay là một dạng tổn thương cơ bản ngoài da, đặc trưng bởi sự xuất hiện nhanh của các sẩn phù , sưng nề lan toả từ trung tâm với hình dạng và kích thước khác nhau, thường bao xung quanh bởi một quầng đỏ , ngứa hoặc đôi khi có cảm giác rát bỏng và thường tự biến mấ t trong vòng 24 giờ . (Định nghĩa của Hội Dị ứng - Miễn dịch lâm sàng Châu Âu 2009). [1]
Phù Quincke (hay còn gọi là phù mạch) là tình trạng sưng nề đột ngột và rõ rệt ở vùng hạ bì và dưới da, có cảm giác ngứa hoặc đôi khi đau nhức, thường liên quan đến các vùng niêm mạc , bán niêm mạc và tồn tại trong vòng 72 giờ. (Định nghĩa của Tổ chức Dị ứng Thế giới năm 2008). [2]
**ĐẶC ĐIỂM LÂM SÀNG VÀ CẬN LÂM SÀNG:**
**Đặc điểm lâm sàng:**
**_Mày đay:_**
Biểu hiện là các đám sẩn phù có mật độ mềm, hơi nổi gồ trên mặt da và thường gây ngứa nhiều. Xung quanh tổn thương có viền đỏ, ở giữa có màu hồng nhạt, tổn thương mày đay mạn tính diễn biến kéo dài có thể không nổi gồ trên mặt da và thường có màu đỏ sẫm.
Hình thái và kích thước của mày đay cũng rất đa dạng, đường kính có thể từ một vài mm đến hàng chục cm, có thể hình vòng cung, hình tròn hoặc dạng mảng như bản đồ.
Mày đay có thể xuất hiện ở mọi vị trí trên cơ thể, như mặt, thân mình và tứ chi. Tổn thương mày đay thường có xu hướng thay đổi kích thước và hình thái rất nhanh, mỗi tổn thương đơn lẻ thường xuất hiện và biến mất trong vòng 1 vài giờ, ít khi tồn tại quá 8 giờ và có thể di chuyển từ vị trí này sang vị trí khác. Mày đay thường xuất hiện về chiều tối và sáng sớm, giảm dần vào buổi sáng và buổi trưa.
Khoảng 50% các trường hợp mày đay có kết hợp với phù Quincke. Một số yếu tố như thay đổi thời tiết, hải sản, đồ uống có cồn, thay đổi nhiệt độ môi trường đột ngột, ánh nắng mặt trời, gãi hoặc cọ sát, tì đè... có thể kích phát không đặc hiệu triệu chứng của cả mày đay và phù Quincke.
_Phù Quincke_
Phù Quincke dị ứng thường có biểu hiện sưng nề ở cả vùng dưới và trên bề mặt của da niêm mạc, xuất hiện nhanh và đột ngột, vị trí gặp chủ yếu ở lưỡi, môi, mắt, quanh miệng, bàn tay, bàn chân, hầu họng và bộ phận sinh dục.
Tình trạng sưng nề thường phát triển trong vài phút đến vài giờ, có thể khu trú hoặc lan tỏa, gây cảm giác căng đau, ngứa nhẹ hoặc tê bì do dây thần kinh cảm giác bị chèn ép. Vùng tổn thương thường có màu hồng nhạt, ranh giới không rõ, khi bị cọ xát, kích thích, tình trạng sưng nề có thể tăng lên và màu sắc trở nên tái nhợt.
Mỗi tổn thương đơn lẻ của phù Quincke do dị ứng thường tồn tại trong vòng 72 giờ, biến mất không để lại di chứng.
Ngoài ra, tùy thuộc vào vị trí tổn thương, phù Quincke có thể gây ra một số triệu chứng khác như: đau quặn bụng, nôn, ỉa chảy do phù nề ở ruột; khó thở, thở rít, nghe phổi có ran rít ran ngáy do phù nề đường thở; khó nuốt, khàn giọng do phù nề hầu họng và thanh quản; truỵ tim mạch khi có kèm theo SPV.
**Đặc điểm cận lâm sàng**
Test lẩy da với các dị nguyên có thể cho kết quả dương tính với những dị nguyên mà người bệnh mẫn cảm
Test huyết thanh tự thân có kết quả dương tính trong phần lớn các trường hợp mày đay mạn tính do nguyên nhân miễn dịch.
Xét nghiệm định lượng IgE đặc hiệu với các dị nguyên nghi ngờ có thể xác định được chính xác loại dị nguyên mà người bệnh mẫn cảm.
Các xét nghiệm tự kháng thể tuyến giáp và chức năng tuyến giáp có thể có biến loạn trong các trường hợp mày đay mạn tính kết hợp với viêm tuyến giáp tự miễn.
Các xét nghiệm máu và nước tiểu thông thường ít có biến đổi ở các người bệnh mày đay phù Quincke do dị ứng.
**CHẨN ĐOÁN**
**Chẩn đoán xác định:** Chủ yếu dựa vào:
Các biểu hiện lâm sàng của mày đay và phù mạch
Hỏi tiền sử bệnh tìm thấy mối liên quan giữa sự xuất hiện của mày đay - phù Quincke với việc tiếp xúc các yếu tố lạ như thuốc, thức ăn, lông súc vật...
Khai thác tiền sử dị ứng phát hiện được các bệnh dị ứng khác đi kèm như dị ứng thuốc, chàm, VMDƯ, HPQ… [2],[3]
Phân loại:Theo thời gian diễn biến bệnh, mày đay và phù Quincke dị ứng được chia làm 2 thể cấp tính và mạn tính:
Mày đay phù Quincke cấp tính (diễn biến dưới 6 tuần): thường xuất hiện sau khi tiếp xúc với dị nguyên gây bệnh từ vài phút đến vài giờ, kéo dài một vài ngày đến một vài tuần. Nguyên nhân gây bệnh thường là do các loại thức ăn (như tôm, cua, cá…), thuốc (kháng sinh nhóm bêta lactam, sulfamide, NSAID và thuốc cản quang...), phấn hoa, và nọc côn trùng (kiến, ong).
Mày đay phù Quincke mạn tính (diễn biến ≥ 6 tuần): thường kéo dài trong nhiều tháng, nhiều năm và không rõ căn nguyên.
Dấu hiệu thực thể của 2 nhóm bệnh này không có gì khác biệt. 
**Chẩn đoán phân biệt:**
**_Mày đay:_**
Cần phân biệt với một số tổn thương:
Hồng ban đa dạng: có các ban đỏ dạng bia bắn, có thể kèm theo viêm loét các hốc tự nhiên.
Tổn thương da do viêm mạch: ban xuất huyết, thường kèm theo các triệu chứng khác của viêm mạch như đau khớp, đau bụng, viêm cầu thận.
Hội chứng tăng dưỡng bào: có tổn thương mày đay, ban đỏ, thường kèm theo đau bụng, đi ngoài phân lỏng, khó thở, thở rít và có cơn bốc hỏa.
Nấm da: ban đỏ có ranh giới rõ, bong vảy da và tồn tại cố định.
**_Phù Quincke:_**
Cần phân biệt với một số tổn thương sau:
Viêm mô tế bào : thường biểu hiện sưng, nóng, đỏ, đau tại vùng tổn thương, kèm theo có sốt cao, thể trạng nhiễm khuẩn.
Phù do bệnh tim, thận: phù trắng, mềm, ấn lõm, xuất hiện từ từ, kèm theo các biểu hiện khác của bệnh lý tim mạch và thận.
Phù bạch huyết: phù cứng, không ngứa, cảm giác đau tức, tập trung ở 2 chi dưới, xuất hiện từ từ, gặp ở những người có tiền sử lội ruộng thường xuyên.
Viêm tắc tĩnh mạ h: vùng tổn thương có cảm giác đau tức, da tím đỏ, có thể có hoại tử, siêu âm doppler mạch có thể phát hiện chỗ viêm tắc tĩnh mạch.
**ĐIỀU TRỊ**
**Điều trị đặc hiệu:**
Tránh tiếp xúc hoặc loại bỏ các yếu tố đã được biết gây bệnh hoặc làm nặng bệnh: ngừng dùng thuốc , thức ăn, chuyển chỗ ở, đổi nghề, tránh nóng, lạnh, ánh nắng mặt trời ...
Cân nhắc điều trị giảm mẫn cảm đặc hiệu nếu không thể loại bỏ được dị nguyên gây bệnh.
**Điều trị triệu chứng:**
Các nhóm thuốc chủ yếu để kiểm soát triệu chứng gồm: adrenaline, các thuốc kháng histamin H1, H2 và glucocorticoid.
**_Thuốc kháng histamin H1:_**
Chỉ định: dùng trong tất cả các thể mày đay và phù Quincke do dị ứng. Hiệu quả của các thuốc là tương đương nhau, chỉ khác nhau về tác dụng phụ.
Có thể lựa chọn một trong các thuốc như chlorpheniramine, diphenhydramine, hydroxyzine, cetirizine, fexofenadine, loratadine…
**_Thuốc kháng histamine H 2:_**
Chỉ định: phối hợp với thuốc kháng H 1 trong trường hợ p mày đay, phù Quincke dị ứng không đáp ứng vớ i thuốc kháng H1 đơn thuần.
Liều lượng, cách dùng: xem bảng 2
**Bảng 2 : các thuốc kháng histamin H2 trong điều trị các bệnh dị ứng [4],[5]**
**Thuốc** |  **Liều lượng cách dùng**  
---|---  
_Famotidine_ |  Người lớn: 40mg/ngày uống hoặc tiêm tĩnh mạch Trẻ em: 0,5 - 1mg/kg/ngày. Tổng liều ≤40mg/ngày.  
_Ranitidine_ |  Người lớn: viên 150mg uố ng 2 - 3v/ngày. Trẻ em: > 12 tuổí: 1,25 - 2.5 mg/kg uố ng 2 lần/ngày, tổng liều ≤ 300 mg/ngày  
_Cimetidine_ |  Người lớn: 300 - 800 mg uống 6 - 8 giờ / 1lần Trẻ em: 20 - 40 mg/kg/ngày uống chia 6 giờ /1lần.  
**_Adrenaline (epinephrine):_**
Chỉ định: cho các trường hợp phù Quincke do cơ chế dị ứng có phù nề đường hô hấp hoặc tụt huyết áp.
Liều dùng: 0,3 - 0,5mg tiêm bắp, nhắc lại sau 15 - 20 phút nếu cần, trường hợp nặng nhắc lại sau 1 - 2 phút. Nếu không đáp ứng, tiêm tĩnh mạch 3 - 5 ml dd adrenalin 1/10.000 hoặc bơm qua màng nhẫn giáp hoặc nội khí quản .
Có thể pha loãng 1 ống adrenaline 1mg với 3ml dung dịch muố i sinh lý để khí dung trong các trường hợ có phù nề đường hô hấ p trên.
**_Glucocorticoid:_**
Các chế phẩm thường sử dụng: prednisolon (viên 5mg), methylprednisolon (viên 4mg, 16mg, lọ tiêm 40mg, 125mg và 500mg), prednison (viên 5mg).
Chỉ định: phối hợp với thuốc kháng H 1 và H2 để giảm triệu chứng trong các trườ ng hợp mày đay, phù Quincke nặng không đáp ứng với các thuốc kể trên hoặc để dự phòng triệu chứng tái phát.
Liều lượng, cách dùng: nên dùng liều trung bình , một đợt ngắn ngày để hạn chế tác dụng phụ. Có thể dùng prednisone hoặc prednisolone hoặc methylprednisolone uống hoặc tiêm truyền tĩnh mạch 40 - 60 mg/ngày (ở người lớn) hoặc 1mg/kg/ngày (ở trẻ em) trong 5 - 7 ngày. [4][5]
Các biện pháp điều trị hỗ trợ khác:Đặt nội khí quản hoặc mở khí quản nếu tình trạng phù nề đường hô hấp gây đe doạ tính mạng người bệnh và không đáp ứng với thuốc đơn thuần.
**THEO DÕI ĐIỀU TRỊ:**
Cần theo dõi các yếu tố sau:
Tình trạng lâm sàng
Các tác dụng phụ của thuốc
Số lượng bạch cầu ái toan
Nồng độ IgE đặc hiệu (nếu có thể)
**PHÒNG BỆNH**
Không có biện pháp phòng bệnh tiên phát.
Những người có cơ địa dị ứng và đã có tiền sử bị mày đay phù Quincke, cần cố gắng xác định nguyên nhân gây bệnh và tránh tối đa tiếp xúc với các yếu tố này.
Với những người đang trong đợt cấp của mày đay phù Quincke, cần tránh tối đa tiếp xúc với các yếu tố kích phát không đặc hiệu triệu chứng mày đay như bia rượu, gió lạnh, thay đổi nhiệt độ đột ngột, xúc động mạnh, gắng sức...
**TÀI LIỆU THAM KHẢO**
Zuberbier, R. Asero, C. Bindslev Jensen, et al (2009).
EAACI/GA2LEN/EDF/WAO guideline: definition, classification and diagnosis of urticaria.  _Allergy_ , 64, 1417–1426.
Kaplan A. P (2008). Angioedema.  _World Allergy Organization Journal_ , June,103 - 113.
Zuberbier (2012). Summary of the New International EAACI/GA2LEN/EDF/WAO Guidelines in Urticaria.  _WAO Journal_ , 5, S1–S5.
Powell R. J., Du Toit G. L., Siddiqu N., et al (2007). BSACI guidelines for the management of chronic urticaria and angiooedema.  _Clin Exp Allergy_ , 37, 631–650.
Ferdman R.M (2007). Urticaria and Angioedema.  _Clin Ped Emerg Med_ , 8, 72 - 80.
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh

## ️ Chẩn đoán và xử trí cơn hen phế quản cấp (Diagnosis And Management Of Acute Asthma)

**ĐẠI CƯƠNG**
Cơn hen cấp là tình trạng nặng lên của các triệu chứng hen như khó thở , nặng ngực , thở rít hoặc phối hợp các triệu chứng này. Trong cơn hen thường có giảm các chỉ số thông khí phổi như FEV1 hoặc PEF  _(GINA 2012)._
Sự biến đổi nặng lên của các triệu chứng lâm sàng trong cơn hen thường đi trước sự sụt giảm của các thông số chức năng hô hấp.
**CHẨN ĐOÁN**
**Chẩn đoán xác định :**
Cơn HPQ cấp đặc trưng bởi những cơn khó thở kiểu hen xảy ra ở một người có tiền sử mắc HPQ hoặc các bệnh dị ứng. Cơn khó thở kiểu hen thường có các đặc điểm sau:
**Tiền triệu:** hắt hơi, ngứa mũi, ngứa mắt, buồn ngủ, ho thành cơn...
**Cơn khó thở:** khó thở ra, khò khè, thở rít, mức độ khó thở tăng dần, người bệnh thường phải ngồi dậy để thở, có thể kèm theo vã mồ hôi, nói khó.
Khám thực thể thường nghe thấy tiếng ran rít ran ngáy lan toả khắp 2 phổi, co kéo cơ hô hấp. Lưu lượng đỉnh thường giảm < 60% GTLT.
**Thoái lui:** mỗi cơn hen thường diễn ra trong vòng 5 - 15 phút, nhưng có thể kéo dài hàng giờ hoặc lâu hơn. Cơn hen có thể tự hồi phục hoặc sau khi dùng thuốc giãn phế quản , cuối cơn tình trạng khó thở giảm dần, khạc ra đờm trong, dính.
**Hoàn cảnh xuất hiện:** cơn hen thường xuất hiện về đêm hoặc sau khi tiếp xúc với các yếu tố kích phát như gắng sức, hít phải khói, bụi, mùi thơm, nấm mốc, tiếp xúc với dị nguyên gây bệnh, bị cảm cúm hoặc thay đổi thời tiết… Ngoài cơn hen người bệnh thường không có triệu chứng.
**Chẩn đoán phân biệt :**
**_Đợt cấp của bệnh phổi tắc nghẽn mạn tính (COPD):_**
Tiền sử viêm phế quản (VPQ) mạn tính v ới biểu hiện ho, khạc đờm kéo dài, nghiện thuốc lào thuốc lá.
Đặc điểm LS và CLS: khó thở dai dẳng, ít đáp ứng với thuốc giãn phế quản, ho khạc nhiều đờm đục; có thể có sốt nhẹ. Nghe phổi thường có giảm rì rào phế nang , ran ẩm (ran nổ ). Trên phim XQ phổi thường có hình ảnh VPQ mạn tính hoặc giãn phế nang.
**_Tràn khí màng phổi:_**
Khó thở, đau ngực thường xuất hiện rất đột ngột.
Bên phổi bị tràn khí có mất rì rào phế nang , lồng ngực giãn căng , gõ trong. Thường kèm theo tràn khí dưới da.
**_Phù phổi, cơn hen tim:_**
Khó thở xuất hiện đột ngột , thường đi kèm với các triệu chứng của bệnh tim mạch như suy tim, cao huyết áp…
Có tiền sử mắc bệnh tim mạch hoặc cao huyết áp
**_Nhồi máu phổi_**
Khó thở, đau ngực, ho khạc ra máu, tràn dịch màng phổi xuất hiện đột ngột. Nghe phổi có ran ẩm, ran nổ , trên phim XQ phổi có đám mờ khu trú.
Có các yếu tố nguy cơ gây nhồi máu phổi như bất động kéo dài , bệnh lí đa hồng cầu…
_**Viêm phổi**_
Sốt, khạc đờm vàng, xanh, nghe phổi có ran ẩm, ran nổ .
XQ phổi có hình ảnh viêm phổi
**_Dị vật đường thở_**
Không có tiền sử hen phế quản
Có hội chứng xâm nhập xuất hiện đột ngột sau khi sặc, hít phải dị vật:
Cơn ho dữ dội, tím tái, ngạt thở cấp.
**Đánh giá mức độ của cơn hen**
Mức độ của cơn hen cấp được phân loại trong bảng 1 theo GINA 2012.
Những lưu ý đặc biệt khi đánh giá cơn hen cấp
**Diễ****n biến dự báo cơn hen nặng:**
Cơn hen diễn biến nhanh, nặng lên trong vài giờ
Cơn hen đáp ứng kém với thuốc giãn phế quản
Các dấu hiệu của cơn hen nguy kịch: cơn hen được chẩn đoán là nguy kịch khi có kèm theo ít nhất một trong các dấu hiệu sau đây (lưu ý loại trừ tràn khí màng phổi):
**Bảng 1: Phân độ cơn HPQ cấp theo GINA 2012**
**Dấu hiệu** |  **Cơn hen nhẹ** |  **Cơn hen vừa** |  **Cơn hen nặng** |  **Cơn nguy kịch**  
---|---|---|---|---  
Mức độ khó thở |  Lúc đi lại Có thể nằm được |  Khi nói Ở trẻ nhỏ: khóc ngắn hơi, khó bú |  Lúc nghỉ ngơi Phải ngồi ngả ra trước  
Từng câu |  Cụm từ |  Từng từ |  Không nói được  
Ý thức |  Có thể kích thích |  Thường kích thích |  Thường kích thích |  Ngủ gà hoặc lú lẫn  
Nhịp thở |  Tăng |  Tăng |  Thường > 30 lần/phút |  Thở chậm < 10lần/ phút hoặc ngừng thở  
Co kéo cơ hô hấp phụ |  Thường không có |  Thường xuyên |  Thường xuyên |  Hô hấp nghịch thường  
Ran rít ran ngáy |  Vừa phải, cuối thì thở ra |  Nhiều ran |  Thường nhiều ran |  Phổi im lặng  
Nhịp tim |  < 100 lần/phút |  100 - 120 lần/phút |  >120 lần/phút |  Nhịp chậm  
Mạch đảo |  Không có |  Có thể có 1025 mmHg |  Thường có > 25 mmHg |  Không có, do mỏi cơ hô hấp  
%PEF sau liều giãn phế quản đầu tiên |  >80% |  60 - 80% |  < 60% GTLT (< 100 L/ phút ở người lớn) hoặc đáp ứng kéo dài < |  Không đo được  
PaO2 |  Bình thường |  >60 mmHg |  < 60 mmHg Có thể có tím tái  
PaCO2 |  <45 mmHg |  <45 mmHg |  > 45 mmHg Có thể suy hô hấp  
SaO2 |  >95% |  91 - 95% |  < 90%  
_Tăng CO 2 máu ở trẻ em xảy ra nhanh hơn ở thiếu niên và người trưởng thành_  
_Để phân loại mức độ Cơn hen, không nhất thiết phải có tất cả các thông số trên, cần có sự nhận định tổng quát để có quyết định thích hợp._  
Cơn ngừng thở hoặc thở chậm dưới 10 lần/phút.
Phổi im lặng: lồng ngực dãn căng, di động kém, nghe phổi mất rì rào phế nang, không còn thấy tiếng ran.
Nhịp tim chậm
Huyết áp tụt.
Rối loạn ý thức
Thở nghịch thường ngực bụ ng.
Bệnh nhân không nói được.
**Các yếu tố nguy cơ làm nặng cơn hen**
Có tiền sử bị các cơn hen nặng phải đặt nội khí quản hoặc thở máy.
Có ít nhất 1 lần phải đi cấp cứu vì hen trong 1 năm gần đây.
Dùng kéo dài hoặc ngưng dùng đột ngột glucocorticoid đường uống.
Không điều trị kiểm soát hen bằng glucocorticoid xịt.
Lệ thuộc thuốc cường β2 tác dụng nhanh, đặc biệt những người dùng nhiều hơn 1 bình xịt salbutamol/ tháng.
Hen nhạy cảm với aspirin và các thuốc NSAID.
Có tràn khí màng phổi trong cơn khó thở
Có tiền sử dị ứng thức ăn, đặc biệt là lạc.
Phải dùng phối hợp ít nhất 3 nhóm thuốc chữa hen.
Có các vấn đề về tâm thần hoặc đang phải dùng thuốc an thần.
Tiền sử có bệnh lý tim phổi khác phối hợp hoặc dùng thuốc chẹn bêta giao cảm.
Tiền sử không tuân thủ điều trị, từ chối chẩn đoán và điều trị hen.
Loạn thần, nghiện rượu hoặc đang phải dùng thuốc an thần.
Sang chấn tâm lí hoặc các bất ổn về gia đình.
Tiền sử nghiện thuốc lá.
**XỬ TRÍ CẤP CỨU**
Các thuốc điều trị cắt cơn hen
**_Bảng 2: các nhóm thuốc cắt cơn hen_**
**Tên thuốc** |  **Dạng bào chế** |  **Liều lượng** |  **TD phụ**  
---|---|---|---  
**_Kích thích β 2TDnha nh (SABA)_**  
Salbutamol |  Viên 2mg, 4mg Bình xịt định liều MDI 100μg/ liều. Nang KD2,5mg; 5 mg. Ống 0,5mg tiêm truyền TM. |  2 - 4 viên/ngày. Xịt 2 - 4 liều /lần x 3 lần cách nhau 20 phút, duy trì 2 - 4 liều /lần mỗi 4 - 6h KD 1 nang /lần x3 lần cách nhau 20 phút, duy trì 1 nang/lần mỗi 4 - 6h. TDD 1 ống /lần mỗi 4 - 6h Truyền TM liều khởi đầu 0,5mg/h, liều tối đa 3mg/h. |  Nhịp nhanh, Run cơ Đau đầu Liều cao có thể gây tăng đườ ng máu, hạ kali máu.  
Terbutalin (Bricanyl) |  Viên 5mg. Nang KD 5mg Ống 0,5mg tiêm truyền TM. |  Liều như Salbutamol  
**_Kháng cholinergic_**  
Ipratropium bromide Oxitropium bromide |  Bình xịt định liều MDI 25μg/ liều. Nang KD 0,5mg. |  4 - 6 liều/lần mỗi 4 - 6h hoặc 3 lần cách nhau 20 phút. KD 1 nang/20 phút x 3 lần, duy trì 2 - 4 giờ một lần. |  Gây khô miệng Vị khó chịu trong miệng  
**_Nhóm xanthyl_**  
- Aminophyllin |  - Ống tiêm 4,8% 5ml |  7mg/kg cân nặng tiêm TM chậm trong 20 phút, duy trì 0,4 - 0,6mg/kg/h truyền TM. Giảm liều nếu BN đã uống theophyllin ở nhà |  Buồn nôn, nôn, đau đầu; Liều cao có thể gây co giật, nhịp nhanh, loạn nhịp  
Theophyllin |  Viên 100mg |  Uống 2 - 4v/ngày  
**_Glucocorticoid đườngtoàn thân_**  
Prednisolon Methylprednisolon |  Viên 5mg Viên 4mg, 16mg Lọ tiêm 40mg, 125mg, 500mg |  1 - 2mg/kg/ ngày. Với các cơn hen nặng dai dẳng: tiêm TM 40mg/ lần mỗi 4 - 6 giờ Dùng một đợt 3 - 5 ngày |  Viêm loét dạ dày, tăng đường máu Rối loạn nước điện giải…  
**Điều trị cơn hen cấp tại nhà hoặc y tế cơ sở:**
Khi xuất hiện cơn hen cấp cần dùng ngay thuốc cường 2 dạng hít tác dụng ngắn (SABA), có thể lặp lại 3 lần/giờ và đánh giá đáp ứng theo bảng dưới đây:
_Bảng 3. Đánh giá đáp ứng với điều trị ban đầu_
**Trung bình**  
---  
Hết các triệu chứng sau khi dùng thuốc cường β2 và hiệu quả kéo dài trong 4 giờ; PEF > 80% GTLT hoặc GT tốt nhất của người bệnh |  Triệu chứng giảm nhưng xuất hiện trở lại < 3 giờ sau khi dùng thuốc cường β2 ban đầu; PEF = 60 - 80% GTLT hoặc GT tốt nhất của người bệnh |  Triệu chứng tồn tại dai dẳng hoặc nặng lên mặc dù đã dùng thuốc cường β2; PEF <60% GTLT hoặc GT tốt nhất của người bệnh  
**_Xử trí tiếp_** |  **_Xử trí tiếp_** |  **_Xử trí tiếp_**  
Có thể dùng thuốc cường β2 cứ 3 - 4 giờ 1 lần trong 1 - 2 ngày. Liên lạc với thầy thuốc để nhận được hướng dẫn theo dõi |  Thêm corticoid viên. Tiếp tục dùng thuốc cường β2. Đi khám thầy thuốc |  Thêm corticoid viên hoặc tiêm, truyền. Khí dung thuốc cường β2 và gọi xe cấp cứu. Chuyển ngay vào khoa cấp cứu  
**Điều trị cơn hen cấp tại bệnh viện (xem sơ đồ 1)**
Thuốc cường β2 dạng hít tác dụng ngắn với liều phù hợp là thuốc quan trọng nhất. Có thể lặp lại khi cần thiết.
Dùng sớm corticoid đường uống trong điều trị cơn trung bình hoặc nặng để giảm viêm nhanh hơn, điều trị ngắn hạn (7 ngày).
Chỉ dùng theophylin hoặc aminophylin hay thuốc hủy phó giao cảm nếu không có sẵn thuốc cường β2, khi dùng phải chú ý liều lượng vì có thể có nhiều tác dụng phụ nhất là ở những người bệnh đã dùng theophyllin thường xuyên.
Vấn đề sử dụng kháng sinh: Chỉ dùng trong các trường hợp có các bằng chứng của nhiễm khuẩn phối hợp như sốt, ho có đờm vàng, công thức máu có tăng bạch cầu trung tính…
**Tài liệu tham khảo:**
Vũ Văn Đính (1994). Cơn hen phế quả n á c tính NXB y họ c, Hà Nội.  _Hồi sức cấp cứu_.
Đặng Quốc Tuấn (2001). chẩ n đoá n và xƣ̉ trí cơn hen phế quản cấp.  _Bài giảng sau đại học_.
GINA Executive and Science Committees (2012). Global Strategy for Asthma Management and Prevention.
Levy M.L, Thomas M, Small L.R et al (2009).Summary of the 2008 BTS/SIGN British Guideline on the Management of Asthma.  _Primary Care Respiratory Journal,_ 18(Suppl 1), S1 - S16.
Aldington S, Beasley R (2007). Assessment and management of severe asthma in adults in hospital.  _Thorax_ 62, 447–458.
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh

## ️ Sử dụng thuốc kháng Histamine H1 trong một số bệnh dị ứng (Antihistamines H1 For Allergic Diseases)

Kháng histamin H1 là một trong những nhóm thuốc quan trọng, tương đối an toàn trong điều trị các bệnh lý dị ứng.
**THUỐC KHÁNG HISTAMIN H1 THẾ HỆ 1**
**Đại cương**
Tất cả các thế hệ đầu tiên kháng thụ thể H1 được hấp thu nhanh sau khi uống và đều có chuyển hóa trong gan. Rối loạn chức năng gan nặng có thể kéo dài thời gian bán thải nên liều lượng cần phải được thay đổi cho phù hợp. Trẻ em thời gian bán thải thường ngắn hơn và người cao tuổi thường dài hơn.
**Tác dụng phụ cần chú ý trên lâm sàng**
Gây buồn ngủ nên thường bị cấm dùng cho người vận hành máy móc.
Ít gặp hơn trên hệ thần kinh là chóng mặt, ù tai, mờ mắt và run.
Khô miệng, bí tiểu, mờ mắt và táo bón.
Khác: chán ăn, buồn nôn, đau bụng và tiêu chảy ít gặp.
Gây quái thai: mới chỉ được ghi nhận ở động vật.
Phân loại thai kỳ: phân loại thai kỳ của các thuốc kháng H1 thế 1 được trình bày trong bảng 1.
**Bảng 1: phân loại thai kỳ của các thuốc kháng H1 thế 1**
**Tên thuốc** |  **Phân loại thai kỳ theo FDA**  
---|---  
Diphenhydramine  
Chlorpheniramine  
Hydroxyzine  
Promethazine  
Ketotifen  
**Liều lượng và cách sử dụng:**
Liều thông thường của một số thuốc kháng histamin H1 thế hệ 1 trong điều trị các bệnh dị ứng được trình bày trong bảng 2.
**Bảng 2: liều thông thường của một số thuốc kháng H1 thế 1**
**KHÁNG HISTAMIN H1 THẾ HỆ 2**
**Đại cương**
Ít gây an thần.
Fexofenadine và desloratadine không gây tác dụng an thần
Loratadine không có tác dụng an thần ở liều thông thường nhưng có thể có tác dụng an thần khi dùng liều cao.
Cetirizine, azelastine có thể có tính an thần nhưng ít hơn thế hệ 1 b. Các tác dụng phụ cần chú ý
Terfenadine và astemizole có thể dẫn tới QT kéo dài trên điện tâm đồ. Hiện tại terfenadine bị cấm lưu hành do có nguy cơ trên hệ tim mạch, gây xoắn đỉnh.
Chưa có bằng chứng bất thường thai nhi ở người và chưa có bằng chứng về tác dụng phụ nào đáng kể trên lâm sàng ở trẻ bú mẹ.
**Cách sử dụng trên lâm sàng trong điều trị các bệnh dị ứng:**
Liều lượng và cách sử dụng các thuốc kháng H1 thế hệ 2 thường dùng trên lâm sàng được trình bày trong bảng 3. Các lưu ý về dược động học của thuốc khi sử dụng trên lâm sàng được trình bày trong bảng 4.
_Bảng 3: Liều thông thường của một số thuốc kháng Histamin H1 thế hệ 2_
**Thuốc** |  **Hàm lượng** |  **Liều cho người lớn** |  **Liều cho trẻ em**  
---|---|---|---  
Fexofenadine |  60mg/ viên 180 mg/viên |  2 viên/ ngày chia 2 lần 1 viên/ ngày |  6 - 11 tuổi: 60mg/ngày >12 tuổi: như người lớn  
Desloratadine |  5 mg/viên |  1 viên/ ngày |  >12 tuổi: liều như NL  
2,5mg/5ml |  10ml/1 lần/ ngày |  6 - 11 tuổi: 2,5 mg/ngày 1 - 5 tuổi: 1,25 mg/ngày 6 - 11 tháng: 1mg/ ngày  
Loratadin |  10mg/viên |  1 lần/ ngày |  >12 tuổi: liều như NL  
5mg/5ml |  10ml/1 lần/ ngày |  6 - 11tuổi: 5 - 10ml/ngày 2 - 5 tuổi: 5ml/ngày  
Cetirizine |  10mg/viên |  1viên/ ngày |  >12 tuổi: liều như NL  
5mg/5ml |  5 - 10ml/ngày |  6 - 11tuổi: 5 - 10ml/ngày 2 - 5 tuổi: 2,5 - 5ml/ngày  
Levocetirizine |  5mg/ viên |  1 viên/ngày |  6 - 12 tuổi: 1 viên/ngày  
Azelastin |  137 mcg/nhát |  2 nhát/bên mũi x 2 lần/ ngày |  >12 tuổi: liều như NL 5 - 11 tuổi: 1 nhát/bên mũi x 2 lần/ ngày  
**Bảng 4: Dược động học của kháng histamin thế hệ 2**
**Cần giảm liều ở người cao tuổi** |  **Cần giảm** **liều trên tổn thương gan** |  **Cần giảm liều khi có tổn thương thận** |  **Phân loại thai kỳ (theo FDA)**  
---|---|---|---  
Loratadine  
Desloratadine  
Cetirizine  
Levocetirizine  
Fexofenadine  
Azelastine  
**MỘT SỐ KHÁNG HISTAMIN ĐƯỢC DÙNG TRONG NHÃN KHOA**
Các kháng histamin H1 dùng tại mắt có tác dụng ức chế được sự xung huyết và ngứa mắt, thường được lựa chọn trong điều trị VKM dị ứng.
Antazolin 0,5%: 1 - 2 giọt x 4 lần/ ngày
Emedastin 0,05%: 1 giọt x 2 - 4 lần/ ngày
Pheniramine 1 giọt x 2 - 5 lần/ ngày
Levocabastine 0,05%: 1 giọt x 4 lần/ ngày
**CHỈ ĐỊNH VÀ CHỐNG CHỈ ĐỊNH**
**Chỉ định điều trị trong một số bệnh dị ứng**
_**VMDƯ****:**_ Các thuốc kháng H1 là lựa chọn đầu tay, nó tác dụng lên các triệu chứng như: ngứa mũi, hắt hơi, chảy nước mũi. Ngoài ra, nó có thể có tác dụng lên các triệu chứng tại mắt. Không có sự khác biệt giữa thế hệ thứ nhất và thứ 2 trong tác dụng điều trị VMDƯ, tuy nhiên trên lâm sàng hay lựa chọn thế hệ 2 do tác dụng ít gây buồn ngủ. Một số thuốc kháng H1 có thể được dùng để nhỏ mũi trong điều trị VMDƯ, tác dụng nhanh hơn nhưng cũng ngắn hơn so với đường uống.
_**Mày đay cấp và mạn tính, phù Quincke****:**_
Mày đay - phù Quicke cấp tính: kháng H1 là nhóm thuốc quan trọng hàng đầu, có hiệu quả với các triệu chứng ngứa và ban đỏ. Nhóm kháng H1 thế hệ 2 hay được ưu tiên lựa chọn do không hoặc ít gây buồn ngủ.
Mày đay mạn: kháng H1 cũng là lựa chọn hàng đầu, thường được sử dụng hàng ngày để cải thiện và kiểm soát triệu chứng. Khi không đáp ứng có thể tăng liều gấp 2 - 4 lần so với liều khuyến cáo. Cân nhắc sử dụng các thuốc kháng H1 thế hệ 1 vào buổi tối để kiểm soát triệu chứng ngứa về đêm.
_**Viêm da cơ địa và viêm da tiếp xúc**_
Các nghiên cứu gần đây cho thấy hiệu quả rất tốt của các thuốc kháng H1 thế hệ 2 trong việc kiểm soát các triệu chứng như giảm ngứa, giảm lichen hoá, giảm số lượng và kích thước ban đỏ.
Ở trẻ em bị chàm cơ địa dị ứng và có dị ứng với các dị nguyên (như bụi nhà, phấn hoa) việc điều trị kéo dài với các thuốc kháng H1 thế hệ 2 có thể giúp giảm nguy cơ mắc HPQ.
_**VKM****dị ứng:**_ Các kháng H1 thế hệ 2 có hiệu quả tốt với các triệu chứng ngứa mắt, đỏ mắt và chảy nước mắt, cải thiện được chất lượng cuộc sống. Các chế phẩm nhỏ mắt thường khởi phát tác dụng nhanh hơn so với đường uống nhưng thời gian tác dụng cũng ngắn hơn.
_**SPV****và phù thanh quản:** _các thuốc kháng H1 ít có tác dụng, thường được sử dụng sau khi bệnh ổn định và qua cơn nguy kịch.-
_**Các bệnh dị ứng khác:** _dị ứng do côn trùng đốt, chàm
**Chống chỉ định**
Phì đại tuyến tiền liệt
Glaucome góc hẹp
Tắc nghẽn ống tiêu hóa và đường niệu
Nhược cơ
Dị ứng thuốc
**TƯƠNG TÁC THUỐC VÀ QUÁ LIỀU**
**Tương tác thuốc:**
Không nên dùng các thuốc kháng histamin H1 cùng với rượu, benzodiazepam,IMAO, chống trầm cảm 3 vòng.
Erythromycin hoặc ketoconazole làm tăng nồng độ fexofenadine trong huyết tương.
**Quá liều**
**Ngộ độc cấp tính do quá liều bao gồm:** ảo giác, kích động, hôn mê sâu, mất điều hòa, co giật và suy hô hấp. Có thể có triệu chứng chứng ngoại tháp, nhất là ở trẻ em.
**Xử trí:** Rửa dạ dày, gây nôn, dùng than hoạt, thuốc tảy, dùng thuốc an thần nếu có co giật, truyền máu nếu có thiếu máu do tan máu, đảm bảo các chức năng sống: kiểm soát huyết áp, chống loạn nhịp tim, rối loạn nước, điện giải. Theo dõi chức năng gan, thận. Nếu hôn mê, suy hô hấp đặt nội khí quản...
**TÀI LIỆU THAM KHẢO:**
Ledford D.K (2007). Antihistamines.  _Allergic Diseases_ , 3rd edition, 319334
Golightly L.K, Greis L.S (2005). Second - generation antihistamines: actions and efficacy in the management of allergic disorders.  _Drugs_ , 65, 341–384.
Rich R.R, Fleisher T.A, Shearer W.T, et al (2008). Clinical immunologyprinciple and practive 3rd edition, 89, 1317–1329.
Simons F.E.R. (2003). Antihistamines. Allergy Principles and Practice, 6th edition, vol. 1. Philadelphia, Mosby, 834–869.
Taylor - Clark T., Sodha R., Warner B., et al (2005). Histamine receptors that influence blockage of the normal human nasal airway.  _Br J Pharmacol_ , 144, 867–874
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh

## ️ Hội chứng kháng Phospholipid (Antiphospholipid Syndrome)

**ĐỊNH NGHĨA**
Hội chứng kháng phospholipid (APS - Antiphospholipid Syndrome) đặc trưng bởi sự xuất hiện đồng thời của các biểu hiện lâm sàng như huyết khối hoặc thai chết lưu và sự dương tính trong huyết thanh của ít nhất một trong các kháng thể kháng phospholipid (aPL), kháng cardiolipin (aCL), kháng L - glycoprotein - ß2 (ß2 GPL) hoặc chất kháng đông luput (LA). APS có thể xảy ra riêng rẽ hoặc thứ phát sau các bệnh hệ thống khác như LBĐHT...
**ĐẶC ĐIỂM LÂM SÀNG VÀ CẬN LÂM SÀNG**
**Lâm sàng:**
Biểu hiện lâm sàng của APS có thể từ mức không triệu chứng đến rất nặng. Các biểu hiện chính là huyết khối tĩnh mạch hoặc động mạch và thai chết lưu. Huyết khối trong APS không khác về mặt lâm sàng so với huyết khối do các nguyên nhân khác trừ trường hợp APS mức độ nặng và một số trường hợp huyết khối ở các vị trí bất thường (như hội chứng Budd - Chiari,huyết khối xoang và chi trên đối xứng).
Đột quỵ và cơn thiếu máu cục bộ thoáng qua là biểu hiện phổ biến nhất của huyết khối động mạch, trái lại, huyết khối tĩnh mạch sâu, thường đi kèm với nhồi máu phổi, là biểu hiện tĩnh mạch phổ biến nhất của APS. Tổn thương tế bào nội mô mao mạch cầu thận hoặc huyết khối mạch thận (bệnh vi mạch huyết khối) gây ra protein niệu mà không có tế bào niệu hoặc giảm bổ thể trong máu, có thể dẫn đến tăng huyết áp nặng và suy thận.
Nhiều người bệnh có mạng lưới xanh tím ở da giống như lưới các tĩnh mạch nông trên bề mặt da, bệnh van tim (van sùi, dầy và mất chức năng ) hoặc một số biểu hiện không đặc hiệu hoặc hiếm gặp không do huyết khối gây ra.
Một số người bệnh phát sinh các hội chứng thần kinh không đặc hiệu như mất tập trung, hay quên và các đợt hoa mắt chóng mặt. Trên phim chụp cộng hưởng từ (MRI) có thể thấy các tổn thương tăng nhạy cảm, đa ổ nhỏ, chủ yếu trong chất trắng, quanh não thất và không liên quan nhiều đến các triệu chứng lâm sàng.
Thai chết lưu ở các người bệnh có aPL điển hình xảy ra sau 10 tuần của thời kỳ mang thai, nhưng có thể xảy ra sớm hơn (chết tiền phôi thai hoặc chết phôi thai). Người bệnh APS có thể có các biến chứng nặng như tiền sản giật giai đoạn sớm và hội chứng HELLP (tan máu, tăng men gan, giảm tiểu cầu). - APS nguy kịch (CAPS ) là biến chứng hiếm gặp, xuất hiện đột ngột và có thể đe doạ tính mạng. Người bệnh có đa huyết khối ở các động mạch nhỏ không đáp ứng với điều trị chống đông hợp lý có thể gây ra đột quỵ, nhồi máu tim, gan, thượng thận, thận, ruột non và hoại tử đầu chi. Suy thượng thận cấp có thể là dấu hiệu ban đầu, thường được báo trước bởi đau lưng không rõ nguyên nhân và truỵ mạch. Người bệnh CAPS thường có giảm tiểu cầu mức độ trung bình; vỡ hồng cầu nhưng các sản phẩm thoái giáng fibrin thường không tăng rõ rệt, suy thận và xuất huyết phổi có thể xảy ra. Sinh thiết mô cho thấy tắc mạch không do viêm ở cả các mạch nhỏ và vừa. Các kháng thể kháng prothrombin (yếu tố II) đôi khi đi kèm aPL và có thể gây ra xuất huyết do tiêu prothrombin.
**Cận lâm sàng:**
Với các biểu hiện lâm sàng đặc trưng, APS được chẩn đoán khi người bệnh có ít nhất 1 trong các kháng thể IgG aPL hoặc IgM hoặc IgG aCL hoặc
IgM aß2GPI dương tính với hiệu giá trung bình đến cao hoặc có chất chống đông luput (LA) dương tính. Khoảng 80% các người bệnh với xét nghiệm LA dương tính có aCL và 20% người bệnh dương tính với aCL có LA dương tính. Trong một số ít trường hợp APS có thể gặp kháng thể aCL IgA, một số người bệnh lại có aCL âm tính nhưng ß2GPI dương tính.
Xét nghiệm giang mai dương tính giả hiện không còn được dùng để chẩn đoán APS.
Kháng thể kháng nhân và kháng ds - DNA xuất hiện trong khoảng 45% người bệnh APS tiên phát. Giảm tiểu cầu trong APS thường ở mức độ trung bình (> 50.000/ mm3); protein niệu và suy thận xảy ra ở các người bệnh với bệnh huyết khối vi mạch. Tốc độ lắng máu (ESR), hemoglobin và số lượng BC thường không thay đổi trong những trường hợp không có biến chứng, trừ trong giai đoạn huyết khối cấp. Nồng độ bổ thể thường bình thường hoặc giảm nhẹ.
Thăm dò chẩn đoán hình ảnh: hình ảnh cộng hưởng từ (MRI) cho thấy tắc nghẽn và nhồi máu. Các tổn thương chất trắng đa ổ nhỏ ít gặp và không liên quan rõ rệt tới nhồi máu não. Chụp MRI tim hoặc siêu âm tim có thể cho thấy viêm màng trong tim Libman - Sacks nặng và huyết khối trong tim.
Các thăm dò về mô bệnh học: thăm dò mô bệnh học ở da, thận và các tổ chức khác cho thấy tình trạng tắc nghẽn không do viêm ở các động mạch và tĩnh mạch, tổn thương nội mạc cấp và mạn tính cùng với các di chứng, thông mạch lại ở các tổn thương muộn. Nếu có biểu hiện viêm mạch hoại tử thường gợi ý chẩn đoán LBĐHT hoặc các bệnh mô liên kết khác đi kèm.
**CHẨN ĐOÁN:**
Dựa theo tiêu chuẩn chẩn đoán của Sapporo đã sửa đổi (bảng 1)
**_Bảng 1: tiêu chuẩn chẩn đoán APS của Sapporo sửa đổi_**
**Tiêu chuẩn lâm sàng** **_Huyết khối mạch:_** Một hoặc nhiều đợt cấp trên lâm sàng của huyết khối động mạch, tĩnh mạch hoặc các mạch máu nhỏ, ở bất kỳ cơ quan hoặc mô nào. **_Các bất thường trong thời kỳ mang thai:_** Ít nhất một lần thai chết lưu nhưng bình thường về hình thái học vào tuần thứ 10 trở đi của thai kỳ  _hoặc_ Ít nhất một lần đẻ non sơ sinh bình thường về hình thái học trước tuần thứ 34 của thai kỳ thai do sản giật, tiền sản giật nặng hoặc suy chức năng rau thai  _hoặc_ Ít nhất 3 lần sảy thai ngoài ý muốn liên tiếp trước tuần thứ 10 của th ai kỳ, với việc loại trừ các bất thường về giải phẫu, hóc môn của mẹ và các b ất thường về nhiễm sắc thể của bố và mẹ. **Tiêu chuẩn cận lâm sàng** Chất chống đông Luput xuất hiện trong huyết tương ở ít nhất 2 lần xét nghiệm cách nhau tối thiểu 12 tuần, được phát hiện theo các hướng dẫn của Hội Huyết khối và Đông cầm máu Quốc tế. Kháng thể kháng cardiolipin IgG và/ hoặc IgM dương tính trong huy ết thanh hoặc huyết tương với hiệu giá trung bình hoặc cao ( > 40 GPL ho ặc MPL, hoặc > số phần trăm thứ 99) trong ít nhất 2 lần xét nghiệm với khoảng cách tối thiểu 12 tuần, được định lượng bởi phương pháp ELISA chuẩn. Kháng thể kháng ß2 glycoprotein IgG và/ hoặc IgM dương tính trong huyết thanh hoặc huyết tương với hiệu giá trung bình hoặc cao (> số phần trăm thứ 99) trong ít nhất 2 lần xét nghiệm với khoảng cách tối thiểu 12 tuần, được định lượng bởi phương pháp ELISA chuẩn. _APS được chẩn đoán xác định khi có ít nhất một tiêu chuẩn về lâm sàng và một tiêu chuẩn về xét nghiệm. Không chẩn đoán là APS nếu sự xuất hiện của xét nghiệm aPL dương tính và biểu hiện lâm sàng cách nhau dưới 12tuần hoặc trên 5 năm._  
---  
**ĐIỀU TRỊ:**
**Nguyên tắc điều trị:**
Dự phòng huyết khối thứ phát ở những người có aPL dương tính dai dẳng bằng cách dùng warfarin kéo dài, tuy nhiên, liều lượng và thời gian điều trị warfarin thì vẫn còn tranh cãi. Hiệu quả của việc điều trị chống đông liều cao ởngười bệnh APS với các tổn thương mạch máu chưa được khẳng định rõ ràng.
Không có bằng chứng ủng hộ việc điều trị dự phòng huyết khối tiên phát ở những người có aPL dương tính dai dẳng. Loại bỏ các yếu tố nguy cơ gây huyết khối và điều trị dự phòng trong giai đoạn nguy cơ cao là cần thiết.
Các người bệnh APS nguy kịch cần được điều trị phối hợp thuốc chống đông, corticosteroid, globulin miễn dịch truyền tĩnh mạch (IVIg) và lọc huyết tương.
Dự phòng mất thai ở những bà mẹ có aPL dương tính và tiền sử mất thai trước đó bằng liều thấp aspirin và heparin, nếu thất bại, dùng IVIg.
Điều trị chống đông không có hiệu quả đối với các biểu hiện không do huyết khối của aPL như là mạng xanh tím, giảm tiểu cầu, thiếu máu huyết tán hoặc bệnh van tim.
**Điều trị cụ thể:**
Liệu pháp điều trị hội chứng kháng phospholipid tiên phát và thứ phát trong LBĐHT không có sự khác biệt. Các liệu pháp điều trị hiện nay bao gồm:
_**Heparin:**_
Đối với huyết khối cấp ở các người bệnh có aPL dương tính, heparin là liệu pháp điều trị đầu tiên. Có thể sử dụng heparin trọng lượng phân tử thấp thay thế heparin không phân đoạn. Heparin được dùng đồng thời với warfarin trong tối thiểu 4 - 5 ngày cho đến khi INRđạt được trong khoảng điều trị (2.0 - 3.0) trong hai ngày liên tiếp. Heparin cũng đóng vai trò hết sức quan trọng trong điều trị các người bệnh APS mang thai, vì warfarin chống chỉ định trong thời kỳ đầu của thai kỳ.
__Heparin trọng lượng phân tử thấp:__
Có nhiều loại và liều thì riêng rẽ cho từng sản phẩm. Ví dụ, với enoxaparin, liều dự phòng là 30–40 TDD 1 lần mỗi ngày, liều điều trị là 1 mg/kg TDD 2 lần hàng ngày hoặc 1,55 mg/kg TDD 1 lần hàng ngày. Những trường hợp huyết khối tĩnh mạch sâu (DVT) sau đây bắt buộc phải được điều trị tại bệnh viện:
Huyết khối tĩnh mạch sâu ồ ạt
Tắc mạch phổi có triệu chứng
Nguy cơ chảy máu cao với liệu pháp điều trị chống đông
Xuất hiện tình trạng nặng hoặc các nhân tố khác đòi hỏi chăm sóc tại bệnh viện
__Heparin không phân đoạn:__
Ưu điểm chính của heparin không phân đoạn so với heparin trọng lượng phân tử thấp là trong các trường hợp APS có xuất huyết, khi đó, heparin không phân đoạn có thể phục hồi nhanh chóng protamine, trong khi heparin trọng lượng phân tử thấp thì không có khả năng phục hồi hoàn toàn chất này.
_**Warfarin****:**_
Warfarin là thuốc điều trị chuẩn với các người bệnh APS mạn tính không mang thai. Liều dùng được điều chỉnh để đạt được đích điều trị là duy trì INR giữa 2.0 và 3.0.
Các thuốc kháng tiểu cầu: gồm aspirin và clopidogrel.
_**Aspirin****:**_
Có hiệu quả trong việc phòng ngừa huyết khối ở những người bệnh APS chưa từng bị huyết khối trước đó, nhưng ít có giá trị dự phòng huyết khối ở những người đã từng bị huyết khối. Liều được khuyến cáo của aspirin là 81 mg/ngày.
_**Clopidogrel:**_
Có vai trò trong dự phòng huyết khối ở những người bệnh APS bị dị ứng với aspirin. Tuy nhiên, không nên sử dụng clopidogrel khi không có chống chỉ định với aspirin.
_**Hydroxychloroquine****:**_
Có tác dụng làm giảm kích cỡ và thời gian tồn tại của huyết khối, giúp phục hồi hoạt hóa tiểu cầu được tạo ra bởi aPL IgG và giảm sự hình thành huyết khối. Liều dùng: 200 - 400 mg/ngày
**TÀI LIỆU THAM KHẢO:**
Kaplan A.A, Bermas B.L, Erkan D et al (2011). Treatment of the antiphospholipid syndrome.  _UpToDate_.
Kaplan A.A, Bermas B.L, Erkan D et al (2011). Clinical manifestations of the antiphospholipid syndrome.  _UpToDate._
Kaplan A.A, Bermas B.L, Erkan D et al (2011). Diagnosis of the antiphospholipid syndrome.  _UpToDate_.
Koopman M.M, Prandoni P, Piovella F et al (1996). Treatment of venous thrombosis with intravenous unfractionated heparin administered in the hospital as compared wit subcutaneous low - molecular - weight heparin administered at home.  _N Engl J Med,_ 334, 682 - 5.
Segal J.B, Streiff M.B, Hofmann L.V et al (2007). Management of venous thromboembolism: a systematic review for a practice guideline.  _Ann Intern Med_ , 146, 211 - 20.
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh

## ️ Thuốc ức chế miễn dịch trong bệnh dị ứng và tự miễn (Immunosuppressive Drugs For Allergic And Autoimmune Diseases)

**ĐẠI CƯƠNG:**
**Đáp ứng miễn dịch :**
Đáp ứng miễn dịch bình thường: bảo vệ vật chủ khỏi các tác nhân gây bệnh và loại bỏ bệnh tật dựa trên cơ sở đáp ứng của hệ thống miễn dịch bẩm sinh và hệ thống miễn dịch mắc phải.
Đáp ứng miễn dịch bất thường: đáp ứng miễn dịch không hợp lý có thể dẫn tới tổn thương tổ chức (quá mẫn) hay phản ứng chống lại kháng nguyên tự thân (tự miễn).Đáp ứng kém với tác nhân xâm nhập (suy giảm miễn dịch) có thể gặp và có thể dẫn tới loại bỏ các cơ chế bảo vệ.
**Các thuốc ức chế miễn dịch:**
Ức chế miễn dịch liên quan tới giảm sự hoạt hóa hay ảnh hưởng của hệ thống miễn dịch.
Các thuốc ức chế miễn dịch được sử dụng để kiểm soát các biểu hiện nặng của bệnh dị ứng, tự miễn và chống thải mảnh ghép.
Các thuốc ức chế miễn dịch có ích trong giảm thiểu những tác động bất lợi do đáp ứng miễn dịch quá mức hay không thỏa đáng. Tuy nhiên, các thuốc này có thể gây bệnh và làm tăng nguy cơ nhiễm khuẩn và ác tính.
**PHÂN LOẠI CÁC NHÓM THUỐC ỨC CHẾ MIỄN DỊCH:**
Ức chế bộc lộ gene của cytokine: corticosteroids như prednisone, prednisolone, dexamethasone.
Nhóm gây độc tế bào: bao gồm nhóm alkylating hóa (cyclophosphamide) và nhóm chống chuyển hóa (azathioprine, methotrexate, mycophenolate mofetil).
Các thuốc ức chế sản xuất hay hoạt động của cytokin interleukin - 2: cyclosporine, tacrolimus (FK506)
Các kháng thể ức chế miễn dịch: Kháng thể đa dòng (globulin kháng tế bào lympho, globulin kháng tế bào tuyến ức, muromonoab - CD3); Kháng thể đơn dòng (anti - CD20, anti - CD 52, anti - TNF - α).
**MỘT SỐ THUỐC ỨC CHẾ MIỄN DỊCH THƯỜNG DÙNG TRONG ĐIỀU TRỊ CÁC BỆNH TỰ MIỄN:**
**Corticosteroids**
Chỉ định:
LBĐHT
VKDT
Bệnh mô liên kết hỗn hợp
Viêm da cơ và viêm đa cơ
Thiếu máu tan máu tự miễn
Xuất huyết giảm tiểu cầu
Liều dùng:
Liều trung bình prednisolon 0,5 - 1 mg/kg/ngày, giảm liều khi đạt hiệu quả điều trị; một số trường hợp bệnh nặng, có thể dùng liều bolus methyprednisolon từ 250 mg đến 1000 mg/ngày trong 3 ngày liên tiếp.
Tác dụng phụ:
Liên quan với sử dụng liều cao kéo dài
Giữ muối và nước
Yếu cơ
Bệnh lý cơ do steroid
Teo cơ và loãng xương
Loét cơ quan tiêu hóa có thể gây thủng và xuất huyết
Viêm tụy, chậm liền vết thương, mỏng da
Đái tháo đường
Mất ngủ
**Cyclophosphamide:**
Chỉ định:
Thiếu máu tan máu
Luput ban đỏ hệ thống
U hạt Wegener
Liều dùng:
2 mg/kg/ngày uống một liều duy nhất vào bữa ăn sáng (khoảng 3 - 12 tháng), uống nhiều nước, chú ý đi tiểu hết vào buổi tối trước khi đi ngủ.
Cyclophosphamide truyền tĩnh mạch cách quãng: đặc biệt được áp dụng cho viêm cầu thận luput. Liều 0,5 g - 1g/m2 hàng tháng trong 6 tháng liên tục (7 lần), sau đó tiếp tục truyền tĩnh mạch 3 tháng/lần trong ít nhất 1 năm (National Institute ofHealth) ;hoặc liều cố định 500 mg/lần x 2 tuần/lần trong 3 tháng (Euro - lupus nephritis Trial).
Tác dụng phụ:
Thường liên quan với liều cao cyclophosphamide
Giảm bạch cầu
Viêm bàng quang chảy máu
Rụng tóc
Buồn nôn và nôn
Độc tính trên tim
Rối loạn điện giải
**Azathioprine:**
Chỉ định:
Viêm cầu thận tăng sinh cấp tính
Luput ban đỏ hệ thống
Viêm khớp dạng thấp
Liều dùng: Liều bắt đầu 1mg/kg/ngày, tăng liều 2mg - 3 mg/kg/ngày, chia 1 - 3 lần uống trong bữa ăn.
Tác dụng phụ:
Ức chế tủy xương (giảm bạch cầu, giảm tiểu cầu,thiếu máu)
Buồn nôn và nôn, ỉa chảy
Rối loạn chức năng gan
Tăng nguy cơ nhiễm khuẩn
**Methotrexate:**
Chỉ định:
Viêm khớp dạng thấp hoạt động
Các bệnh lý khớp có viêm khác
Chống chỉ định:
Có thai và cho con bú
Bệnh lý gan, bệnh lý phổi, bệnh thận
Uống nhiều rượu
Liều lượng: Bắt đầu uống hay tiêm 5 - 10 mg/tuần vào một ngày nhất định trong tuần, bổ sung thêm acid folic 5 mg/ngày x 3 ngày trong tuần sau uống methotrexate để hạn chế tác dụng phụ. Tăng liều methotrexate lên 20 mg/tuần nếu chưa đạt hiệu quả điều trị, uống trong bữa ăn hay uống với sữa.
Theo dõi:
Trước điều trị : hemoglobin, công thức máu, chức năng gan, xét nghiệm sinh hóa, marker viêm gan B và viêm gan C nếu có bất thường chức năng gan.
Theo dõi hàng tháng: hemoglobin, công thức máu, chức năng gan
Tác dụng phụ: Loét miệng, viêm dạ dày, ho, khó thở, nôn, buồn nôn.
**Mycophenolate Mofetil:**
Chỉ định:
Một số thể nặng của LBĐHT
Điều trị thay thế corticosteroid trong giai đoạn điều trị duy trì một số bệnh tự miễn đặc biệt là viêm mạch.
Viêm cầu thận luput
Liều dùng:
1 - 3 g/ngày chia 2 lần, uống trong bữa ăn.
Tác dụng phụ: Chủ yếu với đường tiêu hóa: ỉa chảy, đau bụng, giảm bạch cầu, thiếu máu nhẹ, nhiễm khuẩn, nhiễm cytomegalovirus, u hạch, ung thư da
**Cyclosporine:**
Chỉ định:
Chống thải ghép cấp
Viêm khớp dạng thấp, được dùng kết hợp với methotrexate ở những người bệnh không đáp ứng đầy đủ với methotrexate.
Vảy nến
Hội chứng thận hư
Hen nặng phụ thuộc corticoid
Đái đường typ I phát hiện sớm
Liều dùng: 100 - 400 mg/ngày chia 2 liều uống vào một thời điểm nhất định, trong bữa ăn hay giữa các bữa ăn.
Tác dụng phụ:
Phụ thuộc liều dùng.
Độc tính với thận, hội chứng tăng ure máu do tan máu, tăng huyết áp, rối loạn chức năng gan, tăng kali máu, độc tính với thần kinh, tăng sản lợi, thay đổi trên da, rối loạn chuyển hóa lipid máu, rậm lông, tăng nguy cơ đái tháo đường.
**Tacrolimus (FK506):**
Chỉ định:
Viêm da cơ địa
Vảy nến tại chỗ
Tác dụng phụ: Độc tính với thận, độc tính với thần kinh, tăng đường máu, tăng kali máu, tăng huyết áp
**Anti - CD20 (rituximab):**
Được cấp phép chỉ định dùng trong điều trị u lympho tế bào B.Cho tới nay, đã có nhiều công bố về hiệu quả của rituximab trong điều trị 29 bệnh tự miễn. Các nghiên cứu đối chứng ngẫu nhiên đã được tiến hành với LBĐHT, VKDT, viêm da cơ, viêm mạch ANCA dương tính.
Cơ chế tác dụng:
Rituximab là kháng thể đơn dòng của người có tác dụng làm mất tế bào lympho B dẫn tới giảm tế bào lympho B trong máu ngoại vi, tác dụng này kéo dài 4 - 12 tháng sau điều trị .
Liều dùng:
Giai đoạn tấn công: 375 mg/m2/tuần x 4 tuần liên tiếp hay 500 mg - 1000 mg x2 tuần/lần x2 lần.
Giai đoạn duy trì: tùy thuộc vào từng loại bệnh tự miễn để có phác đồ thích hợp.
Tác dụng phụ:
Khi truyền: mày đay, ngứa, ban đỏ, phù môi, lưỡi, họng, mặt, ho, khó thở, mệt, chóng mặt, đau ngực, run.
Phản ứng với da và môi: đau hay loét da, môi, trong miệng; bọng nước, bong da, ban đỏ, đường rò trên da.
Hoạt động trở lại của virus viêm gan B ở người viêm gan B và người mang virus.
Bệnh lý não chất trắng đa ổ tiến triển.
**THEO DÕI ĐIỀU TRỊ CÁC THUỐC ỨC CHẾ MIỄN DỊCH:**
**Nhiễm khuẩn:**
Nhiễm khuẩn vết thương, nhiễm khuẩn phổi, viêm đường tiết niệu
Nhiễm khuẩn cơ hội sau 1 - 2 tháng điều trị : nhiễm herpes, viêm phổi do pneumocystis carini, nhiễm nấm, nhiễm vi khuẩn không điển hình.
Khuyên BN tiêm phòng vắc xin cúm, vắc xin phế cầu hàng năm trong thời điểm điều trị bệnh duy trì, tránh dùng vắc xin sống giảm độc lực như varicella, sởi…
**Nguy cơ gây ung thư :**
Các rối loạn do tăng sinh tế bào lympho, ung thư cổ tử cung, ung thư da.
Các bệnh tự miễn có liên quan với tăng nguy cơ gây ung thư: viêm da cơ, viêm đa cơ liên quan với adenocarcinoma; viêm khớp dạng thấp, luput ban đỏ hệ thống, hội chứng Sjogrene liên quan với ác tính tế bào lympho.
**Ức chế tủy xương và giảm bạch cầu:**
Tạm dừng thuốc ức chế miễn dịch
khi BC giảm dưới 1,5 x 109/l.
**Nguy cơ bệnh tim mạch:**
Là nguyên nhân hay gặp nhất gây biến chứng và tử vong ở những người bệnh bị bệnh tự miễn.
Chế độ sinh hoạt theo dõi : ngừng hút thuốc lá, theo dõi cân nặng, huyết áp, đường máu, mỡ máu.
**TÀI LIỆU THAM KHẢO:**
Denise C Hsu. Long - term management of patients taking immunosuppressive drugs. Clinical Immunology and Allergy, University of Western Sydney|Aust Prescr 2009; 32: 68–71
Katzung B.G. Immunosuppressive Drugs, 11th Edition. Chap 55: 963 - 986.
Kelly’s textbook of rheumatology. Clinical feature and treatment of systemic lupus erythematous, Vol 1, chap 75.
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh

## ️ Bệnh mô liên kết hỗn hợp (Mixed Connective Tissue Disease)

**ĐẠI CƯƠNG**
Bệnh mô liên kết hỗn hợp (Mixed Connective Tissue Disease -MCTD) là một bệnh tự miễn dịch, được mô tả lần đầu tiên bởi Sharp vào năm 1972. Bệnh đặc trưng bởi các triệu chứng tổn thương tại nhiều cơ quan, giao thoa giữa đặc điểm lâm sàng của các bệnh tự miễn dịch khác nhau như Luput ban đỏ hệ thống, xơ cứng bì hệ thống, viêm da cơ/ viêm đa cơ, viêm khớp dạng thấp... Bệnh liên quan chặt chẽ với kháng thể kháng RNP70.
Dịch tễ học: Bệnh gặp chủ yếu ở phụ nữ với tỷ lệ nam/nữ khoảng 1/9, phần lớn xuất hiện bệnh ở tuổi trưởng thành. Độ lưu hành được khảo sát ở Nhật Bản khoảng 2,7 ca/100.000 dân.
**ĐẶC ĐIỂM LÂM SÀNG VÀ CẬN LÂM SÀNG**
MCTD có thể biểu hiện đồng thời các triệu chứng toàn thể của LBĐHT, XCB hệ thống, VKDT và viêm da cơ/ viêm đa cơ, hoặc có thể biểu hiện lần lượt theo thời gian. Các triệu chứng thường gặp trong giai đoạn sớm của bệnh thường ít đặc hiệu như mệt mỏi, đau cơ/đau khớp và sốt nhẹ, các triệu chứng đặc hiệu hơn là hội chứng Raynaud, sưng nề tay, ngón tay hình “dồi lợn” và viêm màng hoạt dịch. MCTD giai đoạn chưa có tổn thương toàn thể được gọi là Hội chứng Sharp.
Tổn thương của các cơ quan cũng có thể xuất hiện đồng thời hoặc tiến triển theo thời gian bị bệnh. Nhiều cơ quan có thể bị ảnh hưởng, trong đó, tổn thương phổi kẽ gặp ở 75% số người bệnh MCTD và tăng áp lực động mạch phổi là nguyên nhân hàng đầu gây tử vong do bệnh. Tổn thương các cơ quan trong MCTD được tóm tắt trong bảng 1.
Đặc điểm miễn dịch học: Bệnh liên quan với sự hiện diện của kháng thể anti - U1RNP hiệu giá cao. Đặc điểm miễn dịch đầu tiên để chẩn đoán MCTD là xét nghiệm ANA dương tính với hiệu giá cao, thường > 1:1000, đôi khi > 1/10.000. Ở những người bệnh có kết quả xét nghiệm ANA dương tính với hiệu giá cao, cần lưu ý làm các xét nghiệm kháng thể kháng U1 - RNP, Sm, Ro và La.
Kháng thể kháng ds - DNA, Scl - 70, Sm và Ro có thể dương tính thoáng qua ở người bệnh MCTD. Kháng thể kháng kháng nguyên 70 - kD liên quan chặt chẽ nhất với biểu hiện lâm sàng của MCTD.
**Bảng 1: Tổn thương cơ quan bệnh mô liên kết hỗn hợp**
**Toàn thể** Bệnh lý hạch lympho **Hệ cơ xương khớp** Viêm đa khớp Đau khớp Sẩn cục dưới da Thoái hóa khớp Jaccoud Tổn thương hủy xương Viêm cơ Đau cơ **Biểu hiện da - cơ** Sưng nề ngón tay (ngón tay “dồi lợn”) Trợt da Cứng da Calci hóa da Loét niêm mạc miệng –sinh dục Dấu hiệu Gottron Rụng tóc Ban đỏ do ánh sáng Loét da Giãn mạch da **Biểu hiện tim mạch** Hiện tượng Raynaud Tổn thương mao mạch Tắc động mạch Huyết khối Viêm màng ngoài tim |  **Viêm cơ tim** Sa van hai lá Hẹp van hai lá Đánh trống ngực **Biểu hiện hô hấp** Giảm DLCO Tăng áp lực động mạch phổi Viêm màng phổi, dày màng phổi Viêm phổi kẽ/xơ phổi Xơ dày mao mạch phổi **Biểu hiện tại thận** Viêm cầu thận Cơn tăng huyết áp do thận Hội chứng thận hư **Biểu hiện tiêu hóa** Kém hấp thu Mất vận động thực quản Viêm tụy Viêm gan tự miễn **Biểu hiện thần kinh** Đau đầu Viêm màng não vô khuẩn Co giật Viêm tủy cắt ngang Viêm đa dây thần kinh ngoại vi Viêm mạch võng mạc Hội chứng đuôi ngựa  
---|---  
**CHẨN ĐOÁN**
**Chẩn đoán xác định**
Hội thấp khớp Hoa Kỳ (ACR) hiện chưa đưa ra tiêu chuẩn chẩn đoán MCTD, chỉ có các bộ tiêu chuẩn chẩn đoán được đề xuất bởi một số tác giả. Bộ tiêu chuẩn được đưa ra đầu tiên bởi Sharp có độ nhạy cao, nhưng độ đặc hiệu thấp. Bộ tiêu chuẩn phân loại của Alarcon - Segovia có độ nhạy và độ đặc hiệu tương ứng là 62,5% và 86,2%, độ nhạy tăng lên 81.3% nếu thay đau cơ cho viêm cơ. Đây là bộ tiêu chuẩn có giá trị phân loại tốt nhất cho MCTD trong số các bộ tiêu chuẩn đã được công nhận.
**Bảng 2: Tiêu chuẩn chẩn đoán MCTD của Alarcon - Segovia (1987)**
**_Huyết thanh học_** Hiệu giá kháng thể kháng RNP cao (>1:1600) **_Lâm sàng_** Phù các ngón tay Viêm màng hoạt dịch Viêm cơ (mô bệnh học hoặc sinh học) Hiện tượng Raynaud Xơ cứng da vùng đầu chi, có hoặc không kèm theo xơ cứng toàn thể |  Chẩn đoán MCTD khi có tiêu chuẩn về huyết thanh học và ít nhất 3 tiêu chuẩn lâm sàng, trong đó ưu tiên tiêu chuẩn viêm cơ hoặc viêm màng hoạt dịch. Trường hợp 3 tiêu chuẩn lâm sàng là sưng ngón tay, xơ cứng đầu chi và hiện tượng Raunaud cần phải có thêm tiêu chuẩn khác để phân biệt với với bệnh xơ cứng bì  
---|---  
Triệu chứng lâm sàng của bệnh diễn biến theo thời gian, nên thường phải mất vài năm mới biểu hiện đầy đủ các triệu chứng để chẩn đoán bệnh. Cần lưu ý chẩn đoán sàng lọc MCTD ở người bệnh có kháng thể kháng nhân và kháng thể kháng RNP70 với hiệu giá cao.
**Chẩn đoán phân biệt**
Tùy thuộc vào các triệu chứng biểu hiện trên lâm sàng, MCTD cần được chẩn đoán phân biệt với các bệnh tự miễn dịch hệ thống khác như LBĐHT, XCB hệ thống, viêm đa cơ, VKDT. Việc chẩn đoán phân biệt chủ yếu dựa vào sự xuất hiện của các tự kháng thể đặc trưng cho từng bệnh như kháng thể kháng RNP - 70 trong MCTD, kháng thể kháng ds - DNA trong LBĐHT, kháng thể kháng Scl - 70 trong XCB hệ thống và kháng thể kháng Jo - 1 trong viêm da cơ.
**ĐIỀU TRỊ**
**Nguyên tắc điều trị**
Điều trị triệu chứng theo tổn thương cơ quan
Hạn chế các đợt diễn biến cấp
Phát hiện và điều trị sớm tổn thương nội tạng
Hạn chế tác dụng phụ của thuốc
**Điều trị cụ thể**
Biện pháp cơ bản là điều trị triệu chứng theo tổn thương cơ quan kết hợp với sử dụng các thuốc chống viêm và ức chế miễn dịch bao gồm:
Thuốc chống viêm không steroid (NSAIDs): diclofenac 50 - 70mg/lần  2 lần/ngày, meloxicam 7,5 - 15mg/ngày, celecoxib 100 - 200mg/lần  2 lần/ngày.
Corticosteroid (prednisolon, methylprednisolon): liều thấp prednisolone 5 - 7,5mg/ ngày với điều trị đau khớp trong MCTD, liều cao methylprednisolon 1mg/kg/ngày hoặc 60mg/ngày, liều pulse 500 - 1000mg/ngày x 3 ngày trong các trường hợp có tổn thương nội tạng hoặc đợt diễn biến cấp của bệnh.
Thuốc chống sốt rét tổng hợp (hydroxychloroquin): 200 - 400 mg/ngày
Thuốc ức chế miễn dịch(azathioprin, cyclophosphamid, infliximab): liều lượng và cách sử dụng tham khảo trong bài  _Thuốc ức chế miễn dịch trong điều trị các bệnh dị ứng và tự miễn._
**Điều trị phối hợp:**
Biện pháp không dùng thuốc: giữ ấm tay chân, oxy liệu pháp, phục hồi chức năng, chế độ dinh dưỡng.
Thuốc ức chế men chuyển (captopril, enalapril) có thể được sử dụng trong điều trị tăng áp động mạch phổi, bệnh phổi kẽ, tổn thương thận ở người bệnh MCTD.
Hội chứng Raynaud có thể được điều trị bằng nifedipin, losartan và nitroglycerin.
**TÀI LIỆU THAM KHẢO**
Firestein G.S., Budd R.C (2008). Mixed Connective Tissue Disease, Kelley's Textbook of Rheumatology, 7th Edition,
Sharp1 G. "MCTD: a concept which stood the test of time".  _Lupus_ 2002: 333 - 339
Oscar - Danilo, Ortega - Hernandez Y. S. (2012). Mixed connective tissue disease: An overview of clinical manifestations, diagnosis and treatment.
_Best Practice_ _& Research Clinical Rheumatology_,26, 61 - 72.
Hoffman, C. J. L. R. W (2008). Management of mixed connective tissue disease.  _Future Rheumatol,_ 3, 357 - 367.
Venables P (2006). Mixed connective tissue disease.  _Lupus,_ 15, 132137.
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh

## ️ Sử dụng thuốc kháng Histamin H1 trong một số bệnh dị ứng

  * [THUỐC KHÁNG HISTAMIN H1 THẾ HỆ 1](https://bvnguyentriphuong.com.vn/mien-dich-lam-sang/su-dung-thuoc-khang-histamin-h1-trong-mot-so-benh-di-ung#thuc-khng-histamin-h1-th-h-1)
  * [Tác dụng phụ cần chú ý trên lâm sàng](https://bvnguyentriphuong.com.vn/mien-dich-lam-sang/su-dung-thuoc-khang-histamin-h1-trong-mot-so-benh-di-ung#tc-dng-ph-cn-ch-trn-lm-sng)
  * [Liều lượng và cách sử dụng:](https://bvnguyentriphuong.com.vn/mien-dich-lam-sang/su-dung-thuoc-khang-histamin-h1-trong-mot-so-benh-di-ung#liu-lng-v-cch-s-dng)
  * [KHÁNG HISTAMIN H1 THẾ HỆ 2](https://bvnguyentriphuong.com.vn/mien-dich-lam-sang/su-dung-thuoc-khang-histamin-h1-trong-mot-so-benh-di-ung#khng-histamin-h1-th-h-2)
  * [Cách sử dụng trên lâm sàng trong điều trị các bệnh dị ứng:](https://bvnguyentriphuong.com.vn/mien-dich-lam-sang/su-dung-thuoc-khang-histamin-h1-trong-mot-so-benh-di-ung#cch-s-dng-trn-lm-sng-trong-iu-tr-cc-bnh-d-ng)
  * [MỘT SỐ KHÁNG HISTAMIN ĐƯỢC DÙNG TRONG NHÃN KHOA](https://bvnguyentriphuong.com.vn/mien-dich-lam-sang/su-dung-thuoc-khang-histamin-h1-trong-mot-so-benh-di-ung#mt-s-khng-histamin-c-dng-trong-nhn-khoa)
  * [CHỈ ĐỊNH VÀ CHỐNG CHỈ ĐỊNH](https://bvnguyentriphuong.com.vn/mien-dich-lam-sang/su-dung-thuoc-khang-histamin-h1-trong-mot-so-benh-di-ung#ch-nh-v-chng-ch-nh)
  * [Chỉ định điều trị trong một số bệnh dị ứng](https://bvnguyentriphuong.com.vn/mien-dich-lam-sang/su-dung-thuoc-khang-histamin-h1-trong-mot-so-benh-di-ung#ch-nh-iu-tr-trong-mt-s-bnh-d-ng)
  * [TƯƠNG TÁC THUỐC VÀ QUÁ LIỀU](https://bvnguyentriphuong.com.vn/mien-dich-lam-sang/su-dung-thuoc-khang-histamin-h1-trong-mot-so-benh-di-ung#tng-tc-thuc-v-qu-liu)
  * [Tương tác thuốc:](https://bvnguyentriphuong.com.vn/mien-dich-lam-sang/su-dung-thuoc-khang-histamin-h1-trong-mot-so-benh-di-ung#tng-tc-thuc)


Kháng histamin H1 là một trong những nhóm thuốc quan trọng, tương đối an toàn trong điều trị các bệnh lý dị ứng.
### **THUỐC KHÁNG HISTAMIN H1 THẾ HỆ 1**
#### **Đại cương**
Tất cả các thế hệ đầu tiên kháng thụ thể H1 được hấp thu nhanh sau khi uống và đều có chuyển hóa trong gan. Rối loạn chức năng gan nặng có thể kéo dài thời gian bán thải nên liều lượng cần phải được thay đổi cho phù hợp. Trẻ em thời gian bán thải thường ngắn hơn và người cao tuổi thường dài hơn.
#### **Tác dụng phụ cần chú ý trên lâm sàng**
Gây buồn ngủ nên thường bị cấm dùng cho người vận hành máy móc.
Ít gặp hơn trên hệ thần kinh là chóng mặt, ù tai, mờ mắt và run.
Khô miệng, bí tiểu, mờ mắt và táo bón.
Khác: chán ăn, buồn nôn, đau bụng và tiêu chảy ít gặp.
Gây quái thai: mới chỉ được ghi nhận ở động vật.
Phân loại thai kỳ: phân loại thai kỳ của các thuốc kháng H1 thế 1 được trình bày trong bảng 1.
**Bảng 1: phân loại thai kỳ của các thuốc kháng H1 thế 1**
**Tên thuốc** |  **Phân loại thai kỳ theo FDA**  
---|---  
Diphenhydramine  
Chlorpheniramine  
Hydroxyzine  
Promethazine  
Ketotifen  
#### **Liều lượng và cách sử dụng:**
Liều thông thường của một số thuốc kháng histamin H1 thế hệ 1 trong điều trị các bệnh dị ứng được trình bày trong bảng 2.
**Bảng 2: liều thông thường của một số thuốc kháng H1 thế 1**
**Tên thuốc** |  **Hàm lượng** |  **Liều cho người lớn** |  **Liều cho trẻ em** |  **Yêu cầu giảm liều**  
---|---|---|---|---  
Diphenhydramine |  10mg/1ml (ống tiêm) |  10 - 50mg/6 giờ, tối đa 300mg/24h |  >12 tuổi: như người lớn 6 - 12 tuổi: ½ liều người lớn |  Suy gan  
Chlorpheniramine |  4 mg/ viên |  1 viên/4 - 6 giờ. Tổng liều <24 mg/ngày. |  2 - 12 tuổi: 0.35 mg/kg/24h |  Không  
Hydroxyzine |  25, 50mg/ viên |  1 viên x 3 lần/ 24h |  2 - 12 tuổi:1 mg/kg/24h |  Suy gan  
Promethazine |  15 mg/ viên 5mg/5ml |  1 viên/lần x 2 lần/24h |  >2 tuổi: 0,1 - 0,5 mg/kg x 2 lần/ ngày |  Không  
### **KHÁNG HISTAMIN H1 THẾ HỆ 2**
#### **Đại cương**
Ít gây an thần.
Fexofenadine và desloratadine không gây tác dụng an thần
Loratadine không có tác dụng an thần ở liều thông thường nhưng có thể có tác dụng an thần khi dùng liều cao.
Cetirizine, azelastine có thể có tính an thần nhưng ít hơn thế hệ 1 b. Các tác dụng phụ cần chú ý
Terfenadine và astemizole có thể dẫn tới QT kéo dài trên điện tâm đồ. Hiện tại terfenadine bị cấm lưu hành do có nguy cơ trên hệ tim mạch, gây xoắn đỉnh.
Chưa có bằng chứng bất thường thai nhi ở người và chưa có bằng chứng về tác dụng phụ nào đáng kể trên lâm sàng ở trẻ bú mẹ.
#### **Cách sử dụng trên lâm sàng trong điều trị các bệnh dị ứng:**
Liều lượng và cách sử dụng các thuốc kháng H1 thế hệ 2 thường dùng trên lâm sàng được trình bày trong bảng 3. Các lưu ý về dược động học của thuốc khi sử dụng trên lâm sàng được trình bày trong bảng 4.
_Bảng 3: Liều thông thường của một số thuốc kháng Histamin H1 thế hệ 2_
**Thuốc** |  **Hàm lượng** |  **Liều cho người lớn** |  **Liều cho trẻ em**  
---|---|---|---  
Fexofenadine |  60mg/ viên 180 mg/viên |  2 viên/ ngày chia 2 lần 1 viên/ ngày |  6 - 11 tuổi: 60mg/ngày >12 tuổi: như người lớn  
Desloratadine |  5 mg/viên |  1 viên/ ngày |  >12 tuổi: liều như NL  
2,5mg/5ml |  10ml/1 lần/ ngày |  6 - 11 tuổi: 2,5 mg/ngày 1 - 5 tuổi: 1,25 mg/ngày 6 - 11 tháng: 1mg/ ngày  
Loratadin |  10mg/viên |  1 lần/ ngày |  >12 tuổi: liều như NL  
5mg/5ml |  10ml/1 lần/ ngày |  6 - 11tuổi: 5 - 10ml/ngày 2 - 5 tuổi: 5ml/ngày  
Cetirizine |  10mg/viên |  1viên/ ngày |  >12 tuổi: liều như NL  
5mg/5ml |  5 - 10ml/ngày |  6 - 11tuổi: 5 - 10ml/ngày 2 - 5 tuổi: 2,5 - 5ml/ngày  
Levocetirizine |  5mg/ viên |  1 viên/ngày |  6 - 12 tuổi: 1 viên/ngày  
Azelastin |  137 mcg/nhát  |  2 nhát/bên mũi x 2 lần/ ngày |  >12 tuổi: liều như NL 5 - 11 tuổi: 1 nhát/bên mũi x 2 lần/ ngày  
**Bảng 4: Dược động học của kháng histamin thế hệ 2**
**Cần giảm liều ở người cao tuổi** |  **Cần giảm** **liều trên tổn thương gan** |  **Cần giảm liều khi có tổn thương thận** |  **Phân loại thai kỳ (theo FDA)**  
---|---|---|---  
Loratadine  
Desloratadine  
Cetirizine  
Levocetirizine  
Fexofenadine  
Azelastine  
### **MỘT SỐ KHÁNG HISTAMIN ĐƯỢC DÙNG TRONG NHÃN KHOA**
Các kháng histamin H1 dùng tại mắt có tác dụng ức chế được sự xung huyết và ngứa mắt, thường được lựa chọn trong điều trị VKM dị ứng.
Antazolin 0,5%: 1 - 2 giọt x 4 lần/ ngày
Emedastin 0,05%: 1 giọt x 2 - 4 lần/ ngày
Pheniramine 1 giọt x 2 - 5 lần/ ngày
Levocabastine 0,05%: 1 giọt x 4 lần/ ngày
#### **CHỈ ĐỊNH VÀ CHỐNG CHỈ ĐỊNH**
##### Chỉ định điều trị trong một số bệnh dị ứng
**VMDƯ** Các thuốc kháng H1 là lựa chọn đầu tay, nó tác dụng lên các triệu chứng như: ngứa mũi, hắt hơi, chảy nước mũi. Ngoài ra, nó có thể có tác dụng lên các triệu chứng tại mắt. Không có sự khác biệt giữa thế hệ thứ nhất và thứ 2 trong tác dụng điều trị VMDƯ, tuy nhiên trên lâm sàng hay lựa chọn thế hệ 2 do tác dụng ít gây buồn ngủ. Một số thuốc kháng H1 có thể được dùng để nhỏ mũi trong điều trị VMDƯ, tác dụng nhanh hơn nhưng cũng ngắn hơn so với đường uống.
**Mày đay cấp và mạn tính, phù Quincke****:**
Mày đay - phù Quicke cấp tính: kháng H1 là nhóm thuốc quan trọng hàng đầu, có hiệu quả với các triệu chứng ngứa và ban đỏ. Nhóm kháng H1 thế hệ 2 hay được ưu tiên lựa chọn do không hoặc ít gây buồn ngủ.
Mày đay mạn: kháng H1 cũng là lựa chọn hàng đầu, thường được sử dụng hàng ngày để cải thiện và kiểm soát triệu chứng. Khi không đáp ứng có thể tăng liều gấp 2 - 4 lần so với liều khuyến cáo. Cân nhắc sử dụng các thuốc kháng H1 thế hệ 1 vào buổi tối để kiểm soát triệu chứng ngứa về đêm.
**Viêm da cơ địa và viêm da tiếp xúc**
Các nghiên cứu gần đây cho thấy hiệu quả rất tốt của các thuốc kháng H1 thế hệ 2 trong việc kiểm soát các triệu chứng như giảm ngứa, giảm lichen hoá, giảm số lượng và kích thước ban đỏ.
Ở trẻ em bị chàm cơ địa dị ứng và có dị ứng với các dị nguyên (như bụi nhà, phấn hoa) việc điều trị kéo dài với các thuốc kháng H1 thế hệ 2 có thể giúp giảm nguy cơ mắc HPQ.
**VKM****dị ứng _:_** Các kháng H1 thế hệ 2 có hiệu quả tốt với các triệu chứng ngứa mắt, đỏ mắt và chảy nước mắt, cải thiện được chất lượng cuộc sống. Các chế phẩm nhỏ mắt thường khởi phát tác dụng nhanh hơn so với đường uống nhưng thời gian tác dụng cũng ngắn hơn.
**SPV****và phù thanh quản _:_** các thuốc kháng H1 ít có tác dụng, thường được sử dụng sau khi bệnh ổn định và qua cơn nguy kịch.-
**Các bệnh dị ứng khác:** dị ứng do côn trùng đốt, chàm
##### Chống chỉ định
Phì đại tuyến tiền liệt
Glaucome góc hẹp
Tắc nghẽn ống tiêu hóa và đường niệu
Nhược cơ
Dị ứng thuốc
#### **TƯƠNG TÁC THUỐC VÀ QUÁ LIỀU**
##### Tương tác thuốc:
Không nên dùng các thuốc kháng histamin H1 cùng với rượu, benzodiazepam,IMAO, chống trầm cảm 3 vòng.
Erythromycin hoặc ketoconazole làm tăng nồng độ fexofenadine trong huyết tương.
##### Quá liều
**Ngộ độc cấp tính do quá liều bao gồm:** ảo giác, kích động, hôn mê sâu, mất điều hòa, co giật và suy hô hấp. Có thể có triệu chứng chứng ngoại tháp, nhất là ở trẻ em.
**Xử trí:** Rửa dạ dày, gây nôn, dùng than hoạt, thuốc tảy, dùng thuốc an thần nếu có co giật, truyền máu nếu có thiếu máu do tan máu, đảm bảo các chức năng sống: kiểm soát huyết áp, chống loạn nhịp tim, rối loạn nước, điện giải. Theo dõi chức năng gan, thận. Nếu hôn mê, suy hô hấp đặt nội khí quản...
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [THUỐC KHÁNG HISTAMIN H1 THẾ HỆ 1](https://bvnguyentriphuong.com.vn/mien-dich-lam-sang/su-dung-thuoc-khang-histamin-h1-trong-mot-so-benh-di-ung#thuc-khng-histamin-h1-th-h-1)
  * [Tác dụng phụ cần chú ý trên lâm sàng](https://bvnguyentriphuong.com.vn/mien-dich-lam-sang/su-dung-thuoc-khang-histamin-h1-trong-mot-so-benh-di-ung#tc-dng-ph-cn-ch-trn-lm-sng)
  * [Liều lượng và cách sử dụng:](https://bvnguyentriphuong.com.vn/mien-dich-lam-sang/su-dung-thuoc-khang-histamin-h1-trong-mot-so-benh-di-ung#liu-lng-v-cch-s-dng)
  * [KHÁNG HISTAMIN H1 THẾ HỆ 2](https://bvnguyentriphuong.com.vn/mien-dich-lam-sang/su-dung-thuoc-khang-histamin-h1-trong-mot-so-benh-di-ung#khng-histamin-h1-th-h-2)
  * [Cách sử dụng trên lâm sàng trong điều trị các bệnh dị ứng:](https://bvnguyentriphuong.com.vn/mien-dich-lam-sang/su-dung-thuoc-khang-histamin-h1-trong-mot-so-benh-di-ung#cch-s-dng-trn-lm-sng-trong-iu-tr-cc-bnh-d-ng)
  * [MỘT SỐ KHÁNG HISTAMIN ĐƯỢC DÙNG TRONG NHÃN KHOA](https://bvnguyentriphuong.com.vn/mien-dich-lam-sang/su-dung-thuoc-khang-histamin-h1-trong-mot-so-benh-di-ung#mt-s-khng-histamin-c-dng-trong-nhn-khoa)
  * [CHỈ ĐỊNH VÀ CHỐNG CHỈ ĐỊNH](https://bvnguyentriphuong.com.vn/mien-dich-lam-sang/su-dung-thuoc-khang-histamin-h1-trong-mot-so-benh-di-ung#ch-nh-v-chng-ch-nh)
  * [Chỉ định điều trị trong một số bệnh dị ứng](https://bvnguyentriphuong.com.vn/mien-dich-lam-sang/su-dung-thuoc-khang-histamin-h1-trong-mot-so-benh-di-ung#ch-nh-iu-tr-trong-mt-s-bnh-d-ng)
  * [TƯƠNG TÁC THUỐC VÀ QUÁ LIỀU](https://bvnguyentriphuong.com.vn/mien-dich-lam-sang/su-dung-thuoc-khang-histamin-h1-trong-mot-so-benh-di-ung#tng-tc-thuc-v-qu-liu)
  * [Tương tác thuốc:](https://bvnguyentriphuong.com.vn/mien-dich-lam-sang/su-dung-thuoc-khang-histamin-h1-trong-mot-so-benh-di-ung#tng-tc-thuc)



## ️ Thuốc ức chế miễn dịch trong bệnh dị ứng và tự miễn

  * [Đáp ứng miễn dịch :](https://bvnguyentriphuong.com.vn/mien-dich-lam-sang/thuoc-uc-che-mien-dich-trong-benh-di-ung-va-tu-mien#p-ng-min-dch-)
  * [Các thuốc ức chế miễn dịch:](https://bvnguyentriphuong.com.vn/mien-dich-lam-sang/thuoc-uc-che-mien-dich-trong-benh-di-ung-va-tu-mien#cc-thuc-c-ch-min-dch)
  * [PHÂN LOẠI CÁC NHÓM THUỐC ỨC CHẾ MIỄN DỊCH:](https://bvnguyentriphuong.com.vn/mien-dich-lam-sang/thuoc-uc-che-mien-dich-trong-benh-di-ung-va-tu-mien#phn-loi-cc-nhm-thuc-c-ch-min-dch)
  * [MỘT SỐ THUỐC ỨC CHẾ MIỄN DỊCH THƯỜNG DÙNG TRONG ĐIỀU TRỊ CÁC BỆNH TỰ MIỄN:](https://bvnguyentriphuong.com.vn/mien-dich-lam-sang/thuoc-uc-che-mien-dich-trong-benh-di-ung-va-tu-mien#mt-s-thuc-c-ch-min-dch-thng-dng-trong-iu-tr-cc-bnh-t-min)
  * [Cyclophosphamide:](https://bvnguyentriphuong.com.vn/mien-dich-lam-sang/thuoc-uc-che-mien-dich-trong-benh-di-ung-va-tu-mien#cyclophosphamide)
  * [Chống chỉ định:](https://bvnguyentriphuong.com.vn/mien-dich-lam-sang/thuoc-uc-che-mien-dich-trong-benh-di-ung-va-tu-mien#chng-ch-nh)
  * [Mycophenolate Mofetil:](https://bvnguyentriphuong.com.vn/mien-dich-lam-sang/thuoc-uc-che-mien-dich-trong-benh-di-ung-va-tu-mien#mycophenolate-mofetil)
  * [Tacrolimus (FK506):](https://bvnguyentriphuong.com.vn/mien-dich-lam-sang/thuoc-uc-che-mien-dich-trong-benh-di-ung-va-tu-mien#tacrolimus-fk506)
  * [Anti - CD20 (rituximab):](https://bvnguyentriphuong.com.vn/mien-dich-lam-sang/thuoc-uc-che-mien-dich-trong-benh-di-ung-va-tu-mien#anti-cd20-rituximab)
  * [Cơ chế tác dụng:](https://bvnguyentriphuong.com.vn/mien-dich-lam-sang/thuoc-uc-che-mien-dich-trong-benh-di-ung-va-tu-mien#c-ch-tc-dng)
  * [THEO DÕI ĐIỀU TRỊ CÁC THUỐC ỨC CHẾ MIỄN DỊCH:](https://bvnguyentriphuong.com.vn/mien-dich-lam-sang/thuoc-uc-che-mien-dich-trong-benh-di-ung-va-tu-mien#theo-di-iu-tr-cc-thuc-c-ch-min-dch)
  * [Nguy cơ gây ung thư :](https://bvnguyentriphuong.com.vn/mien-dich-lam-sang/thuoc-uc-che-mien-dich-trong-benh-di-ung-va-tu-mien#nguy-c-gy-ung-th-)
  * [Ức chế tủy xương và giảm bạch cầu:](https://bvnguyentriphuong.com.vn/mien-dich-lam-sang/thuoc-uc-che-mien-dich-trong-benh-di-ung-va-tu-mien#c-ch-ty-xng-v-gim-bch-cu)
  * [Nguy cơ bệnh tim mạch:](https://bvnguyentriphuong.com.vn/mien-dich-lam-sang/thuoc-uc-che-mien-dich-trong-benh-di-ung-va-tu-mien#nguy-c-bnh-tim-mch)
  * [TÀI LIỆU THAM KHẢO:](https://bvnguyentriphuong.com.vn/mien-dich-lam-sang/thuoc-uc-che-mien-dich-trong-benh-di-ung-va-tu-mien#ti-liu-tham-kho)


### **ĐẠI CƯƠNG:**
#### **Đáp ứng miễn dịch :**
Đáp ứng miễn dịch bình thường: bảo vệ vật chủ khỏi các tác nhân gây bệnh và loại bỏ bệnh tật dựa trên cơ sở đáp ứng của hệ thống miễn dịch bẩm sinh và hệ thống miễn dịch mắc phải.
Đáp ứng miễn dịch bất thường: đáp ứng miễn dịch không hợp lý có thể dẫn tới tổn thương tổ chức (quá mẫn) hay phản ứng chống lại kháng nguyên tự thân (tự miễn).Đáp ứng kém với tác nhân xâm nhập (suy giảm miễn dịch) có thể gặp và có thể dẫn tới loại bỏ các cơ chế bảo vệ.
#### **Các thuốc ức chế miễn dịch:**
Ức chế miễn dịch liên quan tới giảm sự hoạt hóa hay ảnh hưởng của hệ thống miễn dịch.
Các thuốc ức chế miễn dịch được sử dụng để kiểm soát các biểu hiện nặng của bệnh dị ứng, tự miễn và chống thải mảnh ghép.
Các thuốc ức chế miễn dịch có ích trong giảm thiểu những tác động bất lợi do đáp ứng miễn dịch quá mức hay không thỏa đáng. Tuy nhiên, các thuốc này có thể gây bệnh và làm tăng nguy cơ nhiễm khuẩn và ác tính.
### **PHÂN LOẠI CÁC NHÓM THUỐC ỨC CHẾ MIỄN DỊCH:**
Ức chế bộc lộ gene của cytokine: corticosteroids như prednisone, prednisolone, dexamethasone.
Nhóm gây độc tế bào: bao gồm nhóm alkylating hóa (cyclophosphamide) và nhóm chống chuyển hóa (azathioprine, methotrexate, mycophenolate mofetil).
Các thuốc ức chế sản xuất hay hoạt động của cytokin interleukin - 2: cyclosporine, tacrolimus (FK506)
Các kháng thể ức chế miễn dịch: Kháng thể đa dòng (globulin kháng tế bào lympho, globulin kháng tế bào tuyến ức, muromonoab - CD3); Kháng thể đơn dòng (anti - CD20, anti - CD 52, anti - TNF - α).
### **MỘT SỐ THUỐC ỨC CHẾ MIỄN DỊCH THƯỜNG DÙNG TRONG ĐIỀU TRỊ CÁC BỆNH TỰ MIỄN:**
#### **Corticosteroids**
##### Chỉ định:
LBĐHT
VKDT
Bệnh mô liên kết hỗn hợp
Viêm da cơ và viêm đa cơ
Thiếu máu tan máu tự miễn
Xuất huyết giảm tiểu cầu
##### Liều dùng:
Liều trung bình prednisolon 0,5 - 1 mg/kg/ngày, giảm liều khi đạt hiệu quả điều trị; một số trường hợp bệnh nặng, có thể dùng liều bolus methyprednisolon từ 250 mg đến 1000 mg/ngày trong 3 ngày liên tiếp.
##### Tác dụng phụ:
Liên quan với sử dụng liều cao kéo dài
Giữ muối và nước
Yếu cơ
Bệnh lý cơ do steroid
Teo cơ và loãng xương
Loét cơ quan tiêu hóa có thể gây thủng và xuất huyết
Viêm tụy, chậm liền vết thương, mỏng da
Đái tháo đường
Mất ngủ
#### **Cyclophosphamide:**
##### Chỉ định:
Thiếu máu tan máu
Luput ban đỏ hệ thống
U hạt Wegener
##### Liều dùng:
2 mg/kg/ngày uống một liều duy nhất vào bữa ăn sáng (khoảng 3 - 12 tháng), uống nhiều nước, chú ý đi tiểu hết vào buổi tối trước khi đi ngủ.
Cyclophosphamide truyền tĩnh mạch cách quãng: đặc biệt được áp dụng cho viêm cầu thận luput. Liều 0,5 g - 1g/m2 hàng tháng trong 6 tháng liên tục (7 lần), sau đó tiếp tục truyền tĩnh mạch 3 tháng/lần trong ít nhất 1 năm (National Institute ofHealth) ;hoặc liều cố định 500 mg/lần x 2 tuần/lần trong 3 tháng (Euro - lupus nephritis Trial).
##### Tác dụng phụ:
Thường liên quan với liều cao cyclophosphamide
Giảm bạch cầu
Viêm bàng quang chảy máu
Rụng tóc
Buồn nôn và nôn
Độc tính trên tim
Rối loạn điện giải
#### **Azathioprine:**
##### Chỉ định:
Viêm cầu thận tăng sinh cấp tính
Luput ban đỏ hệ thống
Viêm khớp dạng thấp
##### Liều dùng:
Liều bắt đầu 1mg/kg/ngày, tăng liều 2mg - 3 mg/kg/ngày, chia 1 - 3 lần uống trong bữa ăn.
##### Tác dụng phụ:
Ức chế tủy xương (giảm bạch cầu, giảm tiểu cầu,thiếu máu)
Buồn nôn và nôn, ỉa chảy
Rối loạn chức năng gan
Tăng nguy cơ nhiễm khuẩn
#### **Methotrexate:**
##### Chỉ định:
Viêm khớp dạng thấp hoạt động
Các bệnh lý khớp có viêm khác
##### Chống chỉ định:
Có thai và cho con bú
Bệnh lý gan, bệnh lý phổi, bệnh thận
Uống nhiều rượu
##### Liều lượng:
Bắt đầu uống hay tiêm 5 - 10 mg/tuần vào một ngày nhất định trong tuần, bổ sung thêm acid folic 5 mg/ngày x 3 ngày trong tuần sau uống methotrexate để hạn chế tác dụng phụ. Tăng liều methotrexate lên 20 mg/tuần nếu chưa đạt hiệu quả điều trị.uống trong bữa ăn hay uống với sữa.
##### Theo dõi:
Trước điều trị : hemoglobin, công thức máu, chức năng gan, xét nghiệm sinh hóa, marker viêm gan B và viêm gan C nếu có bất thường chức năng gan.
Theo dõi hàng tháng: hemoglobin, công thức máu, chức năng gan
##### Tác dụng phụ:
Loét miệng, viêm dạ dày, ho, khó thở, nôn, buồn nôn.
#### **Mycophenolate Mofetil:**
##### Chỉ định:
Một số thể nặng của LBĐHT
Điều trị thay thế corticosteroid trong giai đoạn điều trị duy trì một số bệnh tự miễn đặc biệt là viêm mạch.
Viêm cầu thận luput
##### Liều dùng:
1 - 3 g/ngày chia 2 lần, uống trong bữa ăn.
##### Tác dụng phụ:
Chủ yếu với đường tiêu hóa: ỉa chảy, đau bụng, giảm bạch cầu, thiếu máu nhẹ, nhiễm khuẩn, nhiễm cytomegalovirus, u hạch, ung thư da
#### **Cyclosporine:**
##### Chỉ định:
Chống thải ghép cấp
Viêm khớp dạng thấp, được dùng kết hợp với methotrexate ở những người bệnh không đáp ứng đầy đủ với methotrexate.
Vảy nến
Hội chứng thận hư
Hen nặng phụ thuộc corticoid
Đái đường typ I phát hiện sớm
##### Liều dùng:
100 - 400 mg/ngày chia 2 liều uống vào một thời điểm nhất định, trong bữa ăn hay giữa các bữa ăn.
##### Tác dụng phụ:
Phụ thuộc liều dùng.
Độc tính với thận, hội chứng tăng ure máu do tan máu, tăng huyết áp, rối loạn chức năng gan, tăng kali máu, độc tính với thần kinh, tăng sản lợi, thay đổi trên da, rối loạn chuyển hóa lipid máu, rậm lông, tăng nguy cơ đái tháo đường.
#### **Tacrolimus (FK506):**
##### Chỉ định:
Viêm da cơ địa
Vảy nến tại chỗ
##### Tác dụng phụ:
Độc tính với thận, độc tính với thần kinh, tăng đường máu, tăng kali máu, tăng huyết áp
#### **Anti - CD20 (rituximab):**
Được cấp phép chỉ định dùng trong điều trị u lympho tế bào B.Cho tới nay, đã có nhiều công bố về hiệu quả của rituximab trong điều trị 29 bệnh tự miễn. Các nghiên cứu đối chứng ngẫu nhiên đã được tiến hành với LBĐHT, VKDT, viêm da cơ, viêm mạch ANCA dương tính.
##### Cơ chế tác dụng:
Rituximab là kháng thể đơn dòng của người có tác dụng làm mất tế bào lympho B dẫn tới giảm tế bào lympho B trong máu ngoại vi, tác dụng này kéo dài 4 - 12 tháng sau điều trị .
##### Liều dùng:
Giai đoạn tấn công: 375 mg/m2/tuần x 4 tuần liên tiếp hay 500 mg - 1000 mg x2 tuần/lần x2 lần.
Giai đoạn duy trì: tùy thuộc vào từng loại bệnh tự miễn để có phác đồ thích hợp.
##### Tác dụng phụ:
Khi truyền: mày đay, ngứa, ban đỏ, phù môi, lưỡi, họng, mặt, ho, khó thở, mệt, chóng mặt, đau ngực, run.
Phản ứng với da và môi: đau hay loét da, môi, trong miệng; bọng nước, bong da, ban đỏ, đường rò trên da.
Hoạt động trở lại của virus viêm gan B ở người viêm gan B và người mang virus.
Bệnh lý não chất trắng đa ổ tiến triển.
### **THEO DÕI ĐIỀU TRỊ CÁC THUỐC ỨC CHẾ MIỄN DỊCH:**
#### **Nhiễm khuẩn:**
Nhiễm khuẩn vết thương, nhiễm khuẩn phổi, viêm đường tiết niệu
Nhiễm khuẩn cơ hội sau 1 - 2 tháng điều trị : nhiễm herpes, viêm phổi do pneumocystis carini, nhiễm nấm, nhiễm vi khuẩn không điển hình.
Khuyên BN tiêm phòng vắc xin cúm, vắc xin phế cầu hàng năm trong thời điểm điều trị bệnh duy trì, tránh dùng vắc xin sống giảm độc lực như varicella, sởi…
#### **Nguy cơ gây ung thư :**
Các rối loạn do tăng sinh tế bào lympho, ung thư cổ tử cung, ung thư da.
Các bệnh tự miễn có liên quan với tăng nguy cơ gây ung thư: viêm da cơ, viêm đa cơ liên quan với adenocarcinoma; viêm khớp dạng thấp, luput ban đỏ hệ thống, hội chứng Sjogrene liên quan với ác tính tế bào lympho.
#### **Ức chế tủy xương và giảm bạch cầu:**
Tạm dừng thuốc ức chế miễn dịch
khi BC giảm dưới 1,5 x 109/l.
#### **Nguy cơ bệnh tim mạch:**
Là nguyên nhân hay gặp nhất gây biến chứng và tử vong ở những người bệnh bị bệnh tự miễn.
Chế độ sinh hoạt theo dõi : ngừng hút thuốc lá, theo dõi cân nặng, huyết áp, đường máu, mỡ máu.
### **TÀI LIỆU THAM KHẢO:**
Denise C Hsu. Long - term management of patients taking immunosuppressive drugs. Clinical Immunology and Allergy, University of Western Sydney|Aust Prescr 2009; 32: 68–71
Katzung B.G. Immunosuppressive Drugs, 11th Edition. Chap 55: 963 - 986.
Kelly’s textbook of rheumatology. Clinical feature and treatment of systemic lupus erythematous, Vol 1, chap 75.
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [Đáp ứng miễn dịch :](https://bvnguyentriphuong.com.vn/mien-dich-lam-sang/thuoc-uc-che-mien-dich-trong-benh-di-ung-va-tu-mien#p-ng-min-dch-)
  * [Các thuốc ức chế miễn dịch:](https://bvnguyentriphuong.com.vn/mien-dich-lam-sang/thuoc-uc-che-mien-dich-trong-benh-di-ung-va-tu-mien#cc-thuc-c-ch-min-dch)
  * [PHÂN LOẠI CÁC NHÓM THUỐC ỨC CHẾ MIỄN DỊCH:](https://bvnguyentriphuong.com.vn/mien-dich-lam-sang/thuoc-uc-che-mien-dich-trong-benh-di-ung-va-tu-mien#phn-loi-cc-nhm-thuc-c-ch-min-dch)
  * [MỘT SỐ THUỐC ỨC CHẾ MIỄN DỊCH THƯỜNG DÙNG TRONG ĐIỀU TRỊ CÁC BỆNH TỰ MIỄN:](https://bvnguyentriphuong.com.vn/mien-dich-lam-sang/thuoc-uc-che-mien-dich-trong-benh-di-ung-va-tu-mien#mt-s-thuc-c-ch-min-dch-thng-dng-trong-iu-tr-cc-bnh-t-min)
  * [Cyclophosphamide:](https://bvnguyentriphuong.com.vn/mien-dich-lam-sang/thuoc-uc-che-mien-dich-trong-benh-di-ung-va-tu-mien#cyclophosphamide)
  * [Chống chỉ định:](https://bvnguyentriphuong.com.vn/mien-dich-lam-sang/thuoc-uc-che-mien-dich-trong-benh-di-ung-va-tu-mien#chng-ch-nh)
  * [Mycophenolate Mofetil:](https://bvnguyentriphuong.com.vn/mien-dich-lam-sang/thuoc-uc-che-mien-dich-trong-benh-di-ung-va-tu-mien#mycophenolate-mofetil)
  * [Tacrolimus (FK506):](https://bvnguyentriphuong.com.vn/mien-dich-lam-sang/thuoc-uc-che-mien-dich-trong-benh-di-ung-va-tu-mien#tacrolimus-fk506)
  * [Anti - CD20 (rituximab):](https://bvnguyentriphuong.com.vn/mien-dich-lam-sang/thuoc-uc-che-mien-dich-trong-benh-di-ung-va-tu-mien#anti-cd20-rituximab)
  * [Cơ chế tác dụng:](https://bvnguyentriphuong.com.vn/mien-dich-lam-sang/thuoc-uc-che-mien-dich-trong-benh-di-ung-va-tu-mien#c-ch-tc-dng)
  * [THEO DÕI ĐIỀU TRỊ CÁC THUỐC ỨC CHẾ MIỄN DỊCH:](https://bvnguyentriphuong.com.vn/mien-dich-lam-sang/thuoc-uc-che-mien-dich-trong-benh-di-ung-va-tu-mien#theo-di-iu-tr-cc-thuc-c-ch-min-dch)
  * [Nguy cơ gây ung thư :](https://bvnguyentriphuong.com.vn/mien-dich-lam-sang/thuoc-uc-che-mien-dich-trong-benh-di-ung-va-tu-mien#nguy-c-gy-ung-th-)
  * [Ức chế tủy xương và giảm bạch cầu:](https://bvnguyentriphuong.com.vn/mien-dich-lam-sang/thuoc-uc-che-mien-dich-trong-benh-di-ung-va-tu-mien#c-ch-ty-xng-v-gim-bch-cu)
  * [Nguy cơ bệnh tim mạch:](https://bvnguyentriphuong.com.vn/mien-dich-lam-sang/thuoc-uc-che-mien-dich-trong-benh-di-ung-va-tu-mien#nguy-c-bnh-tim-mch)
  * [TÀI LIỆU THAM KHẢO:](https://bvnguyentriphuong.com.vn/mien-dich-lam-sang/thuoc-uc-che-mien-dich-trong-benh-di-ung-va-tu-mien#ti-liu-tham-kho)



## ️ Viêm mạch Schönlein - Henoch (Henoch - Schönlein Purpura)

**ĐỊNH NGHĨA**
Viêm mạch Schönlein - Henoch là một bệnh lý viêm mạch hệ thống không rõ căn nguyên, có tổn thương các mạch nhỏ do lắng đọng phức hợp miễn dịch IgA, liên quan chủ yếu đến da, thận, ruột và khớp [5].
**BIỂU HIỆN LÂM SÀNG VÀ CẬN LÂM SÀNG**
**Biểu hiện lâm sàng:**
Viêm mạch Schönlein - Henoch thường biểu hiện với 4 triệu chứng kinh điển là nổi ban xuất huyết, đau khớp, đau bụng và tổn thương thận.
Ban xuất huyết:
Gặp ở hầu hết các người bệnh, hơi nổi gờ trên mặt da, ấn kính không mất màu, không ngứa, không đau, có thể có hoại tử và bọng nước trong một số ít trường hợp (thường gặp ở người trưởng thành).
Ở người lớn và trẻ lớn tuổi, ban thường tập trung ở vùng thấp của tay và chân (dấu hiệu đi ủng), nhưng ở trẻ nhỏ, ban thường tập trung ở lưng, mông và đùi.
Các ban xuất huyết thường đa hình thái, có thể dạng chấm nốt hoặc liên kết với nhau thành mảng, đám, tồn tại 5 - 10 ngày, nhạt dần màu và mất đi không để lại di chứng. Các ban xuất huyết mới có thể liên tục xuất hiện trong 4 - 8 tuần.
Đau khớp/ viêm khớp:
Gặp ở 50 - 80% người bệnh, chủ yếu ở khớp gối và cổ chân, kéo dài 3 - 7 ngày, không đối xứng và không gây biến dạng khớp.
Đau bụng:
Xảy ra ở hơn 50% số người bệnh, thường đau quặn từng cơn, chủ yếu ở vùng quanh rốn và thượng vị, gây ra do xuất huyết ở phúc mạc và mạc treo. Biểu hiện đau bụng thường xuất hiện trong vòng 1 tuần sau khi nổi ban xuất huyết, có thể kèm theo buồn nôn, nôn, ỉa chảy và ỉa ra máu hoặc ỉa phân đen..
Tổn thương thận:
Xảy ra ở 40 - 50% số người bệnh, thường biểu hiện viêm cầu thận mức độ nhẹ và hầu hết các trường hợp này đều hồi phục hoàn toàn. Một số ít trường hợp có thể biểu hiện viêm cầu thận tiến triển nhanh, hội chứng thận hư hoặc viêm cầu thận mạn dẫn đến suy thận mạn.
Tổn thương thận trong viêm mạch Schönlein - Henoch thường xuất hiện sau khi khởi phát bệnh 2 - 8 tuần, hay gặp ở những người bệnh có xuất huyết tiêu hóa và ban xuất huyết dai dẳng kéo dài quá 1 tháng, rất ít gặp ở trẻ dưới 2 tuổi. Viêm cầu thận mạn và suy thận giai đoạn cuối trong viêm mạch Schönlein - Henoch thường gặp ở người trưởng thành, ít gặp hơn ở trẻ em.
**Các biểu hiện thường gặp khác trong viêm mạch Schönlein - Henoch**
Sốt nhẹ, mệt mỏi, đau nhức bắp chân và sưng nề 2 cẳng chân.
Ngoài ra, chảy máu cam, lồng ruột, xuất huyết phổi, tinh hoàn, não, nhồi máu não, co giật cũng là những biểu hiện hiếm có thể gặp trong viêm mạch Schönlein - Henoch.
**Biểu hiện cận lâm sàng**
Tăng số lượng BC đa nhân trung tính
Số lượng TC và các xét nghiệm đông cầm máu bình thường.
Tăng nồng độ CRP
Xét nghiệm nước tiểu có protein niệu, HC niệu và trụ HC ở những người bệnh có tổn thương cầu thận.
Tăng nồng độ IgA trong máu
Mô bệnh học: mẫu sinh thiết da hoặc thận có hình ảnh hoại tử dạng fibrin của thành mạch máu, phù nề tế bào nội mô thành mạch và xâm nhập bạch cầu đa nhân trung tính. Nhuộm miễn dịch huỳnh quang mô sinh thiết có tình trạng lắng đọng IgA và bổ thể.
**CHẨN ĐOÁN**
**Chẩn đoán xác định:**
Theo Tiêu chuẩn của Hội Khớp học châu Âu (2010) [5]: chẩn đoán xác định viêm mạch Schönlein - Henoch khi có ban xuất huyết dạng chấm nốt nổi gờ trên mặt da và ít nhất 1 trong các tiêu chuẩn dưới đây:
Đau bụng lan toả
Sinh thiết tổn thương da và mạch máu có lắng đọng IgA - Viêm khớp (cấp, bất kỳ khớp nào) hoặc đau khớp.
Tổn thương thận (hồng cầu niệu hoặc protein niệu).
**Chẩn đoán phân biệt**
Khi không có đủ các tiêu chuẩn chẩn đoán xác định bệnh, tùy theo biểu hiện lâm sàng, cần phân biệt với một số bệnh lý sau:
_**Các nguyên nhân đau bụng ngoại khoa:**_ có thể có phản ứng thành bụng, cảm ứng phúc mạc, không có các biểu hiện trên da và khớp.
_**Nhiễ****m trùng não mô cầu:**_ sốt, thể trạng nhiễm khuẩn, ban xuất huyết đa hình thái, không có tính chất phân bố ở vùng thấp như trong viêm mạch Schönlein - Henoch.
_**Thấ****p tim:**_ sốt, không có tổn thương da đặc trưng của viêm mạch dị ứng, khám lâm sàng và siêu âm tim có biểu hiện tổn thương van tim và cơ tim, tăng nồng độ CRP máu.
_**Xuấ****t huyết giảm tiểu cầu vô căn:**_ ban xuất huyết đa hình thái, thường dạng mảng, có thể phân bố toàn thân, thường kèm theo xuất huyết niêm mạc và nội tạng như chảy máu chân răng, tiêu hóa, rong huyết…
_**Luput****ban đỏ hệ thống:** _sốt kéo dài, ban cánh bướm, đau khớp, rụng tóc, viêm loét miệng…
_**Phản ứng thuốc:**_ ban xuất huyết xuất hiện sau khi dùng thuốc, thường có ngứa, có thể kèm theo tổn thương niêm mạc các hốc tự nhiên như miệng, mắt…
_**Viêm khớp dạng thấp:**_ sốt kéo dài, sưng đau khớp đối xứng, có biến dạng khớp, thường không có đau bụng và không có ban xuất huyết ngoài da.
**_Viêm nội tâm mạc nhiễm khuẩn:_** sốt cao, biểu hiện nhiễm khuẩn, tổn thương van tim trên lâm sàng và siêu âm tim.
**ĐIỀU TRỊ**
**Nguyên tắc điều trị**
Không có điều trị đặc hiệu.
Phương pháp điều trị chủ yếu: chống viêm + điều trị triệu chứng
**Điều trị cụ thể**
Các biện pháp điều trị bảo tồn: được chỉ định cho tất cả các bệnh nhân.Những trường hợp chỉ có ban xuất huyế t đơn thuần có thể chỉ cần điều trị bằng các biện pháp này:
Nghỉ ngơi tại giường trong đợt cấp
Vitamin C liề u cao (1 - 2 gam/ ngày uống hoặc tiêm tĩnh mạch)
Bù dịch.
Điều trị chống viêm:
**Thuố****c chống viêm không steroid (NSAIDs)**
**_Chỉ định:_** các trường hợp chỉ có ban xuất huyết và đau khớp đơn thuần. Dùng một đợt 5 -10 ngày hoặc đến khi triệu chứng ổn định. Hạn chế sử dụng khi bệnh nhân có xuất huyết tiêu hoá hoặc suy thận hoặc suy gan nặng.
**_Liều lượng:_** có thể dùng một trong các dẫn xuất như diclofenac (viên 25mg, 50mg, 75mg) 50–75 mg uống 2 lần/ ngày; ibuprofen (viên 200, 400mg, hỗn dịch uống 2g/100ml) 200–800 mg uống 2 - 4 lần mỗi ngày ở người lớn hoặc30–40 mg/kg/ngày chia 3 - 4 lần ở trẻ em.
**Glucocorticoid****(GC):**
**_Chỉ định:_** trong các trường hợp có đau bụ ng , tổn thương thận , đau khớp và ban xuất huyết không đáp ứng với các thuốc chống viêm không steroid đơn thuần hoặc với các biểu hiện nặng và hiếm gă p của bệnh như tổn thương thần kinh, tổn thương phổi... Nên dùng sớm GC ở những bệnh nhân chưa có tổn thương thận.
**_Liề_**** _u dùng, cách dùng:_** khởi đầu với liều tương đương prednisolon 1 mg/ kg/ ngày, dùng đường uống hoặc tiêm truyền 1 lần vào buổi sáng, giảm dần liều, thời gian sử dụng tuỳ thuộc vào đáp ứng của người bệnh , đặc biệt tổn thương thậ n. Thời gian điều trị mỗi đợt không nên kéo dài quá 1 tháng. (Tham khảo thêm bài  _Cách sử dụng glucocorticoid trong điều trị một số bệnh dị ứng - tự miễn_).
**Các thuốc ức chế miễn dịch**
**_Chỉ định :_** dùng phối hợp với glucocorticoid khi bệnh nhân có tổn thương thận không đáp ứng vớ i glucocorticoid đơn thuần , đặc biệt là hội chứng thận hư và viêm cầu thận tiến triển nhanh [3,4].
**_Liề_**** _u lượng, cách dùng:_** azathioprine (viên 50mg) 2mg/kg/24h, uống trong 3 - 6 tháng, cyclophosphamide (viên 50mg) 1 - 2mg/kg/24h, uống trong 3 - 8 tuần hoặc cyclosporine (viên 25mg, 100mg) 2 - 5mg/ kg/ 24h, uống chia 2 lần trong 3 - 6 tháng. (tham khảo thêm bài  _Thuốc ức chế miễn dịch trong điều trị các bệnh dị ứng và tự miễn_)
**Các phương pháp điều trị khác:** một số phương pháp điều trị sau đây có thể được sử dụng ở những người bệnh có tổn thương nội tạng nặng không đáp ứng với các thuốc điều trị trên:
Corticoid liều cao: methylprednisolone truyền tĩnh mạch 500mg/ngày trong 3 ngày, sử dụng ở những người bệnh có hội chứng thận hư không đáp ứng với corticoid liều thông thường.
IVIg liều cao
Lọc huyết tương
Ghép thận
Điều trị triệu chứng: [2,3]
Suy thận: dùng thuốc lợi tiểu, ăn nhạt, hạn chế dịch.
Đau bụng: dùng thuốc giảm đau, an thần
Xuất huyết tiêu hoá : thuốc ức chế tiết dịch vị (omeprazole, cimetidine, ranitidine...), thuốc cầm máu (transamin...) và bọc niêm mạc dạ dày. Hạn chế tối đa việc sử dụng glucocorticoid và các thuốc chống viêm không steroid.
Đau khớp: dùng các thuốc chống viêm giảm đau toàn thân hoặc tại chỗ .
**THEO DÕI ĐIỀU TRỊ**
Các chỉ số cần theo dõi
Huyết áp (nếu có sử dụng GC hoặc cyclosporine).
Sự xuấ t hiện các triệu chứng lâm sàng : ban xuất huyết ngoài da , đau khớp, đau bụng, nôn ra máu, đi ngoài phân đen.
Tốc độ lắng máu
Tổng phân tích nước tiểu: HC niệu, protein niệu
Xét nghiệm chức năng gan thận: urê, creatinin, AST, ALT trong máu.
Nồng độ IgA trong máu (nếu có thể ).
Thời gian tái khám
Nếu không có tổn thương thận: theo dõi 3 tháng/ lần trong 6 tháng
Nếu có tổn thương thận: theo dõi 1 tháng/ lần cho đến khi ổn định xét nghiệm nước tiểu và chức năng thận.
**TÀI LIỆU THAM KHẢO**
Weiss P.F, Feinstein J.A, Luan X et al**(** 2007). Effects of Corticosteroid on Henoch - Schönlein Purpura: A Systematic Review.  _Pediatrics_ , 120, 10791087.
Roberts P.F., Waller T.A., Brinker T.M., et al (2007). Henoch - Schönlein Purpura: A Review Article.  _Southern Medical Journal_ , 100, 8, 82124.
Reamy B.V, Williams P.M (2009). Henoch - Schönlein Purpura.  _Am Fam Physician_ , 80(7), 697 - 704.
González L.M, Janniger C.K, Schwartz R.A (2009). Pediatric Henoch– Schönlein purpura _. International Journal of Dermatology_ , 48, 1157–1165.
Ozen S, Pistorio A, Iusan S.M, et al (2010). EULAR/PRINTO/PRES criteria for Henoch–Schönlein purpura, childhood polyarteritis nodosa, childhood Wegener granulomatosis and childhood Takayasu arteritis: Ankara 2008. Part II: Final classification criteria.  _Ann Rheum Dis_ , 69, 798 - 806.
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh

## ️ Viêm da cơ, viêm đa cơ (Dermatomyositis And Polymyositis)

**ĐỊNH NGHĨA, DỊCH TỄ HỌC:**
Viêm da cơ, viêm đa cơ (Dermatomyositis and polymyositis) là một nhóm bệnh lý viêm cơ biểu hiện bởi tình trạng yếu cơ. Khi chỉ có biểu hiện ở cơ gọi là viêm đa cơ, khi kèm theo tổn thương ở da gọi là viêm da cơ.
Bệnh có thể gặp ở mọi lứa tuổi, hay gặp ở lứa tuổi thiếu niên (10 - 15 tuổi) và tuổi trung niên (45 - 60 tuổi), nữ giới mắc bệnh nhiều hơn nam giới tỷ lệ nữ/nam là 3/1. Tỷ lệ mắc bệnh chung ước tính 5 - 10 trường hợp/1 triệu dân.
**ĐẶC ĐIỂM LÂM SÀNG VÀ CẬN LÂM SÀNG:**
**Lâm sàng:**
Triệu chứng toàn thân và cơ năng:
Sốt nhẹ trên 37oC (một số ít trường hợp có sốt cao)
Mệt mỏi, giảm cân.
Yếu cơ, hạn chế vận động, đau cơ, đau tự nhiên hoặc khi bị sờ nắn.
Thực thể:
Khám cơ: phát hiện vị trí cơ bị tổn thương thường ở gốc chi, biểu hiện giảm cơ lực, đau căng cơ nhất là khi bị sờ nắn, giảm khả năng vận động, có thể có dấu hiệu “ghế đẩu” do yếu cơ gốc chi người bệnh rất khó đứng lên khi đang ngồi, trường hợp nặng người bệnh không thể tự đứng dậy và đi lại được.
Ở các thể bệnh kết hợp với các bệnh tự miễn hoặc khối u ác tính có thể kèm theo các triệu chứng đợt cấp bệnh tự miễn, hội chứng Raynaud hoặc các triệu chứng của khối u.
Triệu chứng da (chỉ có ở bệnh viêm da cơ): điển hình của bệnh là tử ban (ban màu đỏ tím) ở quanh mắt và sẩn Gottron ở các vùng sát xương. Một số biểu hiện khác có thể gặp là rụng tóc, biến đổi hình thái móng hoặc vôi hoá dưới da.
**Cận lâm sàng:**
Tốc độ máu lắng tăng, CRP tăng.
Tăng men cơ CK (creatine kinase) hoặc aldolase huyết thanh.
Có thể có tăng men gan AST, ALT
Xét nghiệm kháng thể kháng Jo - 1 (anti - histidil transfer RNA synthetese)
Sinh thiết cơ có các bằng chứng viêm cơ: xâm nhập các tế bào viêm (bạch cầu đơn nhân, đại thực bào, tế bào lympho T CD8...) trong tổ chức cơ. Trong đó tế bào T CD8 có và trò quan trọng. Các tế bào viêm bao xung quanh, xâm nhập và phá hủy các sợi cơ lành.
Điện cơ đồ có thể thấy các rối loạn nguồn gốc cơ.
Chụp cộng hưởng (MRI) vùng cơ nghi ngờ bị tổn thương có thể thấy hình ảnh viêm, hoại tử cơ khu trú. Đối với thể kèm theo khối u ác tính có thể có hình ảnh khối u trên các phim cộng hưởng từ các vùng nghi ngờ.
Đối với thể kết hợp bệnh tự miễn có thể phát hiện được các kháng thể tự miễn trong huyết thanh như: ANA, ds - DNA, RF...
**CHẨN ĐOÁN**
**Chẩn đoán xác định:**
Viêm da cơ và viêm đa cơ được chẩn đoán xác định theo tiêu chuẩn của Tanimoto 1995 (bảng 1,2)
**Bảng 1: tiêu chuẩn chẩn đoán viêm da cơ Tanimoto 1995**
**Tổn thương da** Tử ban ở mi mắt trên Dấu hiệu Gottron: ban hoặc sẩn có teo da và vảy sừng màu đỏ tím ởmặt duỗi của các khớp ngón tay. Ban màu đỏ tím gồ nhẹ trên mặt da ở mặt duỗi của các khớp ở chi (khớp gối hoặc khuỷu). **Yếu cơ ở gốc chi hoặc chi trên.** **Tăng nồng độ men creatine kinase hoặc aldolase trong máu.** **Đau cơ khi gắng sức hoặc đau tự phát.** **Thay đổi trên điện cơ.** **Kháng thể kháng Jo - 1 dương tính.** **Viêm hoặc đau khớp không có biến dạng hoặc phá huỷ khớp.** **Biểu hiện viêm hệ thống** (sốt, tăng nồngºCRP trong máu hoặc tăng tốc độ lắng máu). **Biểu hiện viêm cơ trên mô bệnh học.** _Chẩn đoán xác định viêm da cơ khi có ít nhất 1 dấu hiệu trong mục 1 và ít nhất 4 dấu hiệu trong các mục từ 2đến 9._  
---  
**Bảng 2: Tiêu chuẩn chẩn đoán viêm đa cơ của Tanimoto 1995**
Yếu cơ vùng gốc chi: chi dưới hoặc chi trên. Đau cơ tự nhiên hoặc khi bị sờ nắn. Viêm khớp không phá hủy khớp hoặc đau khớp. Các triệu chứng bệnh viêm không đặc hiệu CRP tăng, máu lắng tăng. Tăng CK hoặc aldolase huyết thanh. Điện cơ đồ có thể thấy hình ảnh rối loạn nguồn gốc cơ. Kháng thể kháng Jo - 1 dương tính. Sinh thiết cơ có các bằng chứng viêm cơ. _Chẩn đoán xác định viêm đa cơ khi có ít nhất 4 trong 8 tiêu chuẩn._  
---  
Phân loại:
Viêm da cơ, viêm đa cơ có thể có 3 thể:
_**Thể đơn thuần:**_ chỉ có các biểu hiện ở da và cơ.
_**Thể phối hợp với các bệnh tự miễn** :_ ngoài các biểu hiện ở da và cơ còn có thêm các biểu hiện của bệnh tự miễn.
_**Thể kết hợp với các khối u ác tính** :_ có các triệu chứng của khối u ác tính (đôi khi rất kín phải thăm khám kỹ mới phát hiện được) kèm theo các biểu hiện ở da và cơ.
**Chẩn đoán phân biệt**
Viêm da cơ, viêm đa cơ đôi khi phải chẩn đoán phân biệt với các tình trạng bệnh lý có gây biểu hiện yếu cơ:
Yếu cơ mạn tính hoặc bán cấp do các bệnh lý thần kính:
Tổn thương tủy, xơ hóa cột bên, loạn dưỡng cơ, nhược cơ...Các dấu hiệu thần kinh vận động, điện cơ và sinh thiết cơ có thể giúp chẩn đoán phân biệt các tình trạng bệnh lý này.
Yếu cơ cấp tính trong các bệnh:
Hội chứng Guillain - Barré, viêm tủy cắt ngang, nhiễm độc thần kinh, viêm cơ do virut... Ở các bệnh lý này thường có dấu hiệu co rút cơ, khai thác tiền sử, khám cảm giác, các xét nghiệm độc tố và vi sinh có thể giúp chẩn đoán phân biệt.
Yếu cơ do thuốc:
Khai thác kỹ biểu hiện lâm sàng đặc biệt tiền sử dùng thuốc có thể giúp chẩn đoán phân biệt.
Yếu cơ do đau cơ, đau khớp:
Trong một số bệnh lý đau cơ do thấp, viêm khớp có thể gây yếu cơ. Thăm khám lâm sàng, các xét nghiệm về viêm, miễn dịch đặc biệt kết quả sinh thiết cơ bình thường giúp chẩn đoán phân biệt.
Yếu cơ trong các bệnh lý nội tiết và chuyển hóa như cường hoặc suy giáp, cường vỏ thượng thận...
Chẩn đoán phân biệt dựa và các xét nghiệm hoc môn nội tiết.
**ĐIỀU TRỊ**
**Nguyên tắc điều trị:**
Không có điều trị đặc hiệu
Cần điều trị sớm ngay khi bệnh được chẩn đoán
Nguyên tắc: chống viêm + điều trị triệu chứng
**Các thuốc điều trị**
**Glucocorticoid****:** prednisolone, prednisone, methylprednisolone
Liều thông thường: prednisolone, prednisone hoặc methylprednisolone khởi đầu 1 - 1,5 mg/kg/ngày đường uống hoặc tiêm truyền, chia 2 - 3 lần trong ngày, sau 2 - 4 tuần chuyển về dùng 1 lần trong ngày, duy trì trong 4 - 12 tuần và bắt đầu giảm dần liều, thường giảm 10 - 15% liều sau mỗi 2 - 4 tuần và duy trì ở liều 5 - 10mg/ ngày hoặc cách ngày.
Liều cao đường tĩnh mạch (liều pulse):methylprednisolone 500 - 1000 mg/ ngày, truyền tĩnh mạch trong 30 phút, truyền 3 ngày liên tiếp, sau đó chuyển về liều thông thường. Liều cao thường được chỉ định để điều trị tấn công trong các trường hợp bệnh nặng không đáp ứng với liều thông thường.
Theo dõi điều trị: huyết áp, mật độ xương, đường máu, nồngºCanxi máu, cortisol máu, test ACTH, các triệu chứng của viêm loét dạ dày tá tràng...
Thuốc ức chế miễn dịch: 25% người bệnh cần phối hợp glucocorticoid với các thuốc ức chế miễn dịch để kiểm soát bệnh.
**Methotrexate****:** là thuốc được lựa chọn hàng đầu
Liều lượng: 10 - 20 mg (tối đa có thểtăng đến 30 - 50 mg) đường uống, tiêm bắp hoặc tĩnh mạch, 1 tuần 1 lần. Để hạn chế tác dụng phụ, nên dùng cùng với axit folic 5 mg đường uống 1 - 2 lần/ tuần hoặc 1mg/ ngày.
Theo dõi điều trị: XQ phổi, CTM, creatinin, CN gan trước điều trị, 1tháng / lần trong 6 tháng, sau đó cách 2 tháng trong thời gian dùng thuốc. Nếu có bất thường AST, ALT, kiểm tra sau mỗi 2 tuần. Giảm liều hoặc ngừng thuốc nếu men gan tăng > 3 lần.
**Cyclosporin****A**
Liều lượng: 2 - 5mg/ kg/ 24h, uống chia 2 lần
Theo dõi điều trị: Đo HA hàng tuần, xét nghiệm chức năng thận trước điều trị và 1tháng/ lần, mức lọc cầu thận 3 tháng/ lần.
**Azathioprine****.** Là thuốc ức chế miễn dịch ít tác dụng phụ nhất, là thuốc được lựa chọn cho những trường hợp chống chỉ định với các thuốc ức chế miễn dịch khác như cyclophosphamide và cyclosporin A…, có thể cân nhắc sử dụng cho cả phụ nữ có thai.
Liều lượng: 1 - 2 mg/kg/ ngày. Cần theo dõi công thức bạch cầu nhất, ngừng thuốc khi BC< 4000, thận trọng với các trường có suy gan suy thận.
**Cyclophosphamide**
Liều lượng: Truyền tĩnh mạch 0,5 - 1g mỗi tháng một lần trong 6 tháng (tham khảo qui trình điều trị cyclophosphamide). Thận trọng với các trường hợp suy thận, cần phải giảm liều <0,5 g/lần trong trường hợp creatinin >265µmol/l. Thuốc có thể gây nhiều tác dụng phụ như: giảm bạch cầu, chảy máu bàng quang, suy buồn trứng, vô tinh trùng...
Theo dõi điều tri: Công thức máu, tiểu cầu, hematocrit ít nhất 1 tháng 1 lần trong quá trình điều trị.
**Mycophenolate mofetil**
Liều lượng: 2g/ngàytrong 6 tháng đầu, 1g/ngày trong 6 tháng tiếp theo, liều duy trì 0,5 /ngày trong 1 - 3 năm. Tác dụng phụ: buồn nôn, nôn, tiêu chảy, đau bụng.
Theo dõi: Men gan một tháng sau điều trị và 3 tháng một lần trong cả quá trình điều trị.
**Cloroquin****:** các trường hợp có tổn thương da có thể cân nhắc điều trị cloroquin
Liều lượng: 0,25 g/ ngày trong 6 tháng đến 1 năm.
Theo dõi: Công thức máu, khám mắt 6 tháng 1 lần trong quá trình điều trị.
Phục hồi chức năng và vật lý trị liệu _:_
Làm sớm giúp cải thiện chức năng hoạt động và giảm nguy cơ co cứng cơ.
**THEO DÕI VÀ TÁI KHÁM**
**Các chỉ số cần theo dõi**
Sự xuất hiện các triệu chứng lâm sàng: ban đỏ, sẩn, đau cơ, yếu cơ, ho, khó thở, sốt...
Nồng độ Creatinin kinase, LDH trong máu
Tốc độ lắng máu, nồng độ CRP máu
Tổn thương phổi kẽ trên XQ phổi thẳng hoặc chụp cắt lớp lồng ngực
Điện tâm đồ
Điện cơ
Sinh thiết cơ (nếu có thể)
**Thời gian tái khám**
3 tháng/ lần nếu không có tổn thương tim, phổi
1 tháng/ lần nếu có tổn thương tim, phổi
**TÀI LIỆU THAM KHẢO**
Miller F.W (2012). Dermatomyositis and polymyositis.  _Goldman’s Cecil Medicine_ , 24th edition, Saunders, Philadelphia, 1716 - 19.
Hector M, Christopher P, Vladimir D (2010).Polymyositis and dermatomyositis.  _Washington Manual of Medical Therapeutics_ , 33rd edition, Lippincott Williams & Wilkins, Philadelphia, 884 - 85.
L.J. Iorizzo, J.L. Jorizzo (2008). The treatment and prognosis of dermatomyositis: An updated review.  _J Am Acad Dermatol_ 59, 99 - 112.
Dalakas M.C (2008). Polymyositis, dermatomyositis and inclusion body myositis.  _Harrison’s Principles of internal medicine_ , 17th edition, McGraw - Hill Companies, 2696 - 2704.
Dimachkie D.M, Barohn R.J (2012). Idiopathic Inflammatory Myopathies.  _Semin Neurol_ , 7, 32(3), 227 - 236.
Tanimoto K, Nakano K, Kano S, et al (1995). Classification criteria for polymyositis and dermatomyositis.  _J Rheumatol_ , 22, 668 - 74.
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh

## ️ Dị ứng do côn trùng đốt (Venom Hypersensitivity)

**ĐẠI CƯƠNG:**
Vết đốt của côn trùng thuộc bộ cánh màng (Hymenoptera) như: ong, ong bắp cày, kiến có thể gây phản ứng dị ứng cấp tính toàn thân, làm chết hàng trăm người bệnh ở châu Âu và Mỹ mỗi năm. Hymenoptera thuộc phân bộ Aculeatae với các họ Apideae, Vespidae, Formicidae và Myrmicidae.
Dịch tễ học: ở người trưởng thành, tỷ lệ phản ứng tại chỗ lan tỏa do côn trùng đốt là 2% - 26%, phản ứng dị ứng toàn thân là 0,3% - 7%, ở người nuôi ong là 14% - 43% [5]. Tỷ lệ tử vong do Hymenoptera đốt là 0,09 - 0,48 ca/ 1 triệu người/năm, đa số xảy ra ở người trên 45 tuổi và có bệnh tim mạch từ trước [1][3].
**ĐẶC ĐIỂM LÂM SÀNG**
Các triệu chứng dị ứng với nọc côn trùng thường gây ra qua trung gian IgE, nhưng đôi khi do các cơ chế miễn dịch không qua trung gian IgE.
**Phản ứng thông thường tại chỗ:**
Đau, đôi khi ngứa, sưng nề tại chỗ, đường kính sẩn có thể lên đến 5 - 10 cm. Các triệu chứng tại chỗ thường tự hết trong vòng vài giờ, hết hẳn sau 24 giờ. Một số loài kiến lửa đốt có thể gây ra các bọng nước nhỏ, sauthành mụn mủ và mất đi sau 1 - 2 tuần.
**Phản ứng tại chỗ lan tỏa:**
Biểu hiện là mảng sưng tấy quanh vết đốt, đường kính > 10 cm, tiến triển vài phút đến vài giờ sau khi bị đốt và kéo dài trên 24 giờ [4]. LLR có thểkéo dài vài ngày hoặc vài tuần và lan ra khắp chân tay, mí mắt hoặc môi. Đôi khi đi kèm sưng hạch lympho hoặc viêm mạch bạch huyết. LLR có thể đi kèm với các triệu chứng viêm toàn thân: mệt mỏi, sốt, run, đau đầu [1][4].
**Phản ứng dị ứng toàn thân (Systemic Reactions - SR)**
Phản ứng dị ứng toàn thân thường qua trung gian IgE. Các cơ quan có thể bị ảnh hưởng: da (ngứa, nổi mày đay, ban đỏ, phù mạch), đường tiêu hóa (đau bụng, nôn mửa hoặc tiêu chảy, khó nuốt), đường hô hấp (phù thanh quản, tắc nghẽn phế quản, phù phổi) và hệ thống tim mạch (hạ huyết áp động mạch, sốc, loạn nhịp tim, mất ý thức kèm theo đại tiểu tiện mất tự chủ) (bảng 2).
Các triệu chứng xuất hiện thường xuyên nhất trong vòng vài phút đến 1 giờ sau khi bị đốt. Người bệnh thường hồi phục trong vòng một vài giờ. Hiếm khi gặp kéo dài hơn một ngày hoặc một đợt hai pha. Có thể gặp các biểu hiện nặng như nhồi máu cơ tim hay nhồi máu não, hoặc thậm chí gây tử vong.
**Bảng 2: Phân loại phản ứng dị ứng toàn thân do vết đốt của Hymenoptera (theo phân loại của Mueller có sửa đổi [4]**
Độ I: thường mày đay, ngứa, khó chịu, lo âu  
---  
Độ II: bất kỳ triệu chứng nào như trên, cộng thêm từ 2 triệu chứng sau trở lên: phù mạch, co thắt ngực, buồn nôn, nôn, tiêu chảy, đau bụng,chóng mặt  
Độ III: bất kỳ triệu chứng nào như trên, cộng thêm từ 2 triệu chứng sau trở lên: khó thở, khò khè,tức ngực, nói khó, giọng khàn, yếu mệt, lú lẫn, cảm thấy như tai họa sắp xảy đến  
Độ IV: bất kỳ triệu chứng nào như trên, cộng thêm từ 2 triệu chứng sau trở lên: tụt huyết áp, suy sụp, bất tỉnh, tiểu không tự chủ, xanh tím  
**Phản ứng độc toàn thân:**
Thường gặp trong trường hợp bị nhiều vết đốt (từ 50 đến vài trăm vết) [1][4]. Biểu hiện độc tiến triển trong vài giờ đến vài ngày, bao gồm myoglobin niệu kịch phát, tan máu nội mạch dẫn đến suy thận cấp với hoại tử ống thận. Tổn thương cơ tim, rối loạn chức năng gan, rối loạn đông máu cũng như phù và/hoặc hoại tử não có thể xảy ra. Số lượng vết đốt có thể gây phản ứng chết người là từ 200 đến 1000 vết ở người lớn. Trẻ nhỏ, dưới 50 vết đốt có thể gây chết người. Hầu hết trường hợp, tử vong xảy ra chỉ sau vài ngày.
**Các phản ứng bất thường:**
Rất hiếm gặp và xuất hiện sau vài giờ đến vài ngày, hơn một nửa số đó xảy ra sau phản ứng tại chỗ hoặc toàn thân [4]. Biểu hiện bao gồm hội chứng giống bệnh huyết thanh với sốt, đau khớp, ban ngoài da và nổi hạch lympho; các bệnh lý thần kinh (bệnh thần kinh ngoại biên, viêm đa rễ thần kinh, hội chứng ngoại tháp, viêm não tủy cấp tính lan tỏa); bệnh thận (viêm cầu thận, viêm thận kẽ); bệnh máu và mạch máu (thiếu máu huyết tán, thiếu máu giảm tiểu cầu, hội chứng Henoch - Schönlein và các dạng viêm mạch khác).
**CHẨN ĐOÁN**
**Tiền sử**
Tiền sử lâm sàng là cơ sở cho chẩn đoán. Tiền sử này bao gồm ngày tháng, số lượng và hoàn cảnh (môi trường, hoạt động); loại và mức độ nghiêm trọng của triệu chứng; vị trí vết đốt; ngòi vẫn còn hay đã loại bỏ; thời gian khởi phát triệu chứng; điều trị cấp cứu; các yếu tố nguy cơ (bệnh đang mắc, thuốc); và các bệnh dị ứng khác [1][4].
Ở người chỉ bị phản ứng tại chỗ thì không cần làm xétnghiệm chẩn đoán.
**Test da:**
Nên được thực hiện ít nhất ba tuần sau SR để tránh kết quả âm tính giả trong giai đoạn chưa khỏi. Test được thực hiện bằng cách tiêm trong da hoặc lẩy da với kim định chuẩn [1]. 0,02 ml dung dịch nọc được tiêm trong da với nồng độ tăng dần, từ 0,001 đến 1 μg/ml vào vị trí trước trong cẳng tay. Đối với test lẩy da, thường dùng nồng độ 0,01 - 300 μg/ml. Độ nhạy test lẩy da thấp hơn rõ rệt so với test trong da.
**Các kháng thể IgE đặc hiệu với nọc độc (sIgE):**
Có nhiều xét nghiệm gắn miễn dịch in vitro khác nhau để phát hiện sIgE, bắt nguồn từ kỹ thuật RAST nguyên bản (radio allergosorbent test - RAST). Ngay sau khi bị đốt, sIgE có thể thấp hoặc không phát hiện được, nhưng thường tăng trong vòng vài ngày hoặc vài tuần sau SR. Nếu không phát hiện được sIgE, thì nên làm lại xét nghiệm sau 2 - 4 tuần [1].
**Xét nghiệm tế bào:**
Có giá trị với những người bệnh có tiền sử bị SR nhưng các xét nghiệm thường quy âm tính, có thể thực hiện các test sau:giải phóng histamine của bạch cầu ái kiềm, kích thích kháng nguyên tế bào (CAST), hoạt hóa bạch cầu ái kiềm. Xét nghiệm tế bào tốn kém, chưa được chuẩn hóa; có ít dữ liệu về độ nhạy, độ đặc hiệu và giá trị dự đoán.
**IgG đặc hiệu (sIgG):**
Sự hiện diện của IgG đặc hiệu và IgG4 chủ yếu phản ánh sự tiếp xúc với loại nọc độc tương ứng. Lượng sIgG tăng sau khi đốt, bất kể có hay không có phản ứng dị ứng với vết đốt.
**Tryptase huyết thanh:**
Khuyến cáo đo enzyme này ở tất cả những người bệnh có tiền sử bị SR. α - Tryptase được phóng thích trong thời gian hoạt hóa dưỡng bào và là một chất chỉ điểm của SPV.
**Test kích thích với vết đốt:**
Kích thích với vết đốt côn trùng và được được giám sát kỹ là test hữu ích cho việc đánh giá hiệu quả của liệu pháp miễn dịch với nọc độc.
**ĐIỀU TRỊ**
**Điều trị phản ứng tại chỗ lan tỏa**
Uống kháng histamine và chườm lạnh chỗ bị đốt giúp giảm sưng, đau và ngứa tại chỗ. Kem chống viêm hoặc corticosteroids có thể làm hạn chế quá trình viêm tại chỗ.
Trong trường hợp sưng nhiều, nên uống corticosteroid phối hợp với thuốc kháng histamine trong vài ngày [2].
**Phản ứng dị ứng toàn thân (SR)**
Tất cả các người bệnh bị SR nên được theo dõi lâm sàng cho đến khi giải quyết được các triệu chứng và huyết áp ổn định (bảng 3) [2].
**Bảng 3: Điều trị cấp cứu SR với vết đốt của Hymenoptera**
**Triệu chứng** |  **Thuốc** |  **Các đánh giá khác**  
---|---|---  
Mày đay, phù mạch nhẹ |  Kháng histamine uống |  Kiểm tra huyết áp, lưu lượng đỉnh hoặc FEV1, theo dõi 12h/lần  
Mày đay, phù mạch nặng |  Kháng histamine uốngCorticoid: 0,5–1,0 mg/kgEpinephrine: người lớn: 0,3 - 0,5 mg tiêm bắp trẻ em: 0,01 mg/kg tiêm bắp |  Kiểm tra huyết áp, lưu lượng đỉnh hoặc FEV1 Theo dõi đến khi hết hoàn toàn các triệu chứng  
Phù thanh quản |  Epinephrine: Tiêm bắp |  Thở ôxy Trường hợp nặng hơn có thể đặt nội khí quản hoặc mở khí quản nếu cần.  
Co thắt phế quản |  Đồng vận β2 hoặc epinephrine |  Thở ôxy  
Epinephrine (nếu cần, dùng nhắc lại cứ 10 phút/lần) Người lớn: 0,3 - 0,5 mg TB  Trẻ em: 0,01mg/kg TB Bù dịch Kháng histamine và corticoid tiêm TM |  Đặt BN ở tư thế nằm, thở oxy. Nhập viện trong 24h (nguy cơ phản ứng 2 pha)  
Truyền liên tục dopamine hoặcnorepinephrine Glucagon: 0,1 mg/kg tiêm tĩnh mạch |  Trường hợp tụt huyết áp kéo dài hoặc sốc ở BN dùng thuốc chẹn beta  
**Hộp thuốc cấp cứu**
Tất cả các người bệnh có tiền sử SR nên mang theo một hộp thuốc cấp cứu để có thể tự dùng (bảng 4). Ở trẻ em trọng lượng dưới 30 kg, dùng loại epipen cho trẻ em (0,15 mg epinephrine) và dùng 1/2 liều lượng thuốc kháng histamin và corticosteroid. Nếu SR xảy ra, phải đến ngay cơ sở y tế.
**Bảng 4: Thuốc cấp cứu để tự dùng**
Thuốc cấp cứu theo đơn |  Epinephrine tiêm tự động (ví dụ epipen) Thuốc kháng histamine viên tác dụng nhanh (ví dụ cetirizine 2 × 10 mg, fexofenadine 2 x 180 mg) Corticosteroid viên (ví dụ prednisolone 2 × 50 mg)  
---|---  
Xử trí khi bị đốt |  Dùng ngay 4 viên thuốc cấp cứu nói trên Chuẩn bị epipen để tiêm Nếu xuất hiện các triệu chứng dị ứng toàn thân, tiêm ngayepipen vào bắp đùi, đến cơ sở y tế ngay.  
**Liệu pháp miễn dịch với nọc côn trùng (VIT)** [2]
Chỉ định:
Người có tiền sử bị SR nặng (độ III/IV), sự mẫn cảm đã được xác định bằng test da và/hoặc xét nghiệm máu. Người có phản ứng tái lại nhẹ, không đe dọa tính mạng và có nguy cơ bị tái phơi nhiễm cao. Người có phản ứng không đe dọa tính mạng nhưng có bệnh tim mạch, tăng dưỡng bào, hoặc chất lượng sống bị giảm sút do dị ứng nọc côn trùng.
Chống chỉ định:
Giống như dùng liệu pháp miễn dịch với các dị nguyên khác. Chống chỉ định tương đối với điều trị bằng thuốc chẹn beta hoặc ức chế ACE: nên dùng các thuốc khác thay thế. Không dùng VIT cho trường hợp LLR hoặc các phản ứng bất thường.
Liệu pháp và liều dùng
Liều duy trì khuyến nghị là 100μg nọc độc, dùng cho cả trẻ em và người lớn. Ở các đối tượng phơi nhiễm cao: người nuôi ong, làm vườn, nên dùng liều duy trì 200μg. Có thể bắt đầu bằng VIT theo phương thức thông thường hoặc phương thức cực gấp (bảng 5). Khoảng thời gian giữa các mũi tiêm VIT duy trì là 4 tuần trong năm đầu tiên. Khoảng thời gian sau đó có thể kéo dài đến 6 tuần nếu VIT được dung nạp tốt.
Điều trị suốt đời có thể là khuyến nghị an toàn nhất. Tại hầu hết các trung tâm dị ứng, VIT được khuyên dùng ít nhất 5 năm.
**Bảng 5: Phương thức dùng liệu pháp miễn dịch với nọc độc**
**Thông thường** |  **Cực gấp**  
---|---  
**Tuần** |  **Liều lượng nọc _(μg)_** |  **Ngày** |  **Phút** |  **Liều lượng nọc _(μg)_**  
0,01  
**DỰ PHÒNG**
Tất cả người bệnh có tiền sử bị SR nên được hướng dẫn chi tiết về cách tránh bị côn trùng đốt và các biện pháp cần thực hiện nếu bị đốt lại. Trong khi làm vườn, nên mặc quần áo sơ mi dài, đeo găng tay, tránh dùng nước hoa có mùi thơm mạnh, kem chống nắng hoặc dầu gội đầu và mặc quần áo sáng màu.
**TÀI LIỆU THAM KHẢO**
Bilò, M.B., Ruff, F., Mosbech, H., et al (2005). Diagnosis of Hymenoptera venom allergy.  _Allergy, 60, 1339 - 1349._
Bonifazi, F., Jutel, M., Bilò, M.B. et al (2005). Prevention and treatment of Hymenoptera venom allergy.  _Allergy, 60, 1459 - 1470._
Graif, Y., Confino - Cohen, R., Goldberg, A (2006). Allergic reactions to insect stings: Results from a national survey of 10000 junior high school children in Israel.  _JAllergy Clin Immunol, 117,1435 - 1439._
Müller, U (1990 _)_. “Insect sting allergy Stuttgart”.  _Gustav Fischer Verlag_.
Müller, U (2005). “Bee venom allergy in beekeepers and their family members”.  _Curr Opin Allergy Clin Immunol, 5, 343 - 347._
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh

