## 4 phần mềm thống kê xử lý số liệu phổ biến trong nghiên cứu y sinh

  * [Phần mềm thống kê SPSS](https://bvnguyentriphuong.com.vn/nghien-cuu-khoa-hoc-va-thu-nghiem-lam-sang/4-phan-mem-thong-ke-xu-ly-so-lieu-pho-bien-trong-nghien-cuu-y-sinh#phn-mm-thng-k-spss)
  * [Phần mềm thống kê STATA](https://bvnguyentriphuong.com.vn/nghien-cuu-khoa-hoc-va-thu-nghiem-lam-sang/4-phan-mem-thong-ke-xu-ly-so-lieu-pho-bien-trong-nghien-cuu-y-sinh#phn-mm-thng-k-stata)
  * [Phần mềm thống kê NVIVO](https://bvnguyentriphuong.com.vn/nghien-cuu-khoa-hoc-va-thu-nghiem-lam-sang/4-phan-mem-thong-ke-xu-ly-so-lieu-pho-bien-trong-nghien-cuu-y-sinh#phn-mm-thng-k-nvivo)
  * [Phần mềm thống kê R](https://bvnguyentriphuong.com.vn/nghien-cuu-khoa-hoc-va-thu-nghiem-lam-sang/4-phan-mem-thong-ke-xu-ly-so-lieu-pho-bien-trong-nghien-cuu-y-sinh#phn-mm-thng-k-r)


## Phần mềm thống kê SPSS
SPSS là viết tắt của chữ Statistical Package for the Social Sciences, SPSS Statistics là một phần mềm thống kê mạnh mẽ được phân phối bởi SPSS Inc và được mua lại bởi IBM vào 2009, phần mềm đã thành lập được sắp 40 năm.
Tuổi đời và khả năng cao của phần mềm này khiến cho nó phát triển thành một trong các chương trình phân tách thống kê rộng rãi và thông dụng nhất trong các lĩnh vực kỹ thuật xã hội khác nhau, giúp các nhà quản lý và nhà nghiên cứu dự đoán chính xác mai sau và từ đấy đưa ra quyết định xác thực để giải quyết vấn đề và tăng năng suất.
SPSS sở hữu giao diện nhập liệu khá giống Excel cần vô cùng dể sử dụng. Từ các số liệu đưa vào người dùng mang thể chuyển thành những dạng đồ thị khác nhau rất đẹp mắt. Các đồ thị này với thể dể dàng xuất ra để nhúng vào những phần mềm rộng rãi khác như Word hay Excel.
Điểm mạnh của phần mềm này là khả năng phân tích phương sai, SPSS cho phép phân tách rộng rãi chiều (phân tích phương sai đa dạng chiều, phân tích nhân tố, phân tách nhóm), SPSS cũng cho phép thực hành đa dạng cái kiểm định tác động riêng biệt.
Điểm yếu của SPSS là khả năng xử lý đối có những vấn đề ước lượng phức tạp và do đấy khó đưa ra các ước lượng sai số đối với những ước tính này.
## Phần mềm thống kê STATA
Stata là phần mềm thống kê, phân tách dữ liệu tích hợp và đa mục đích, sản xuất toàn bộ các nhu cầu của người sử dụng để phân tích, quản lý và hiển thị dữ liệu thống kê bằng đồ thị. Cụm từ “Stata” có khởi thủy từ các từ “Statistics” và “Data”.
Trong tất cả trường hợp, Stata là một trong những phần mềm thống kê siêu phải chăng sở hữu thể được tiêu dùng cho nhiều lĩnh vực khác nhau như kinh tế, xã hội học, công nghệ chính trị và một số ngành của kỹ thuật y tế.
Điểm mạnh của phần mềm này là phân tách hồi qui, hồi qui logistic thứ tự và hồi qui logistic phạm trù là rất dễ thực hiện. STATA cũng trội hơn về lĩnh vực phân tích dữ liệu theo lược đồ mẫu, cho khả năng vận dụng chúng trong phân tích số liệu điều tra bởi những công cụ hồi qui, hồi qui logistic, hồi qui poisson, hồi qui probit.
Nhược điểm của STATA sở hữu lẽ là khả năng phân tách phương sai và phân tích đa dạng chiều truyền thống như phân tích phương sai phổ biến chiều, phân tách nhóm
## Phần mềm thống kê NVIVO
NVivo là một chương trình hỗ trợ nghiên cứu cách phân tách định tính. Nó được bề ngoài để giúp người dùng sắp xếp, phân tách và chọn hiểu sâu về dữ liệu ko sở hữu cấu trúc hoặc định tính, chả hạn như: phỏng vấn, giải đáp khảo sát chấm dứt mở, bài viết, công cụ truyền thông xã hội và nội dung web.
Khi khiến cho việc sở hữu dữ liệu định tính ko sở hữu NVivo, công việc sẽ tốn phổ biến thời gian hơn, khó quản lý và khó điều hướng. Điều quan yếu là hoàn tất việc nghiên cứu không mang phần mềm này sở hữu thể làm cho việc khám phá những kết nối trong dữ liệu của người sử dụng trở nên khó khăn và việc sắm ra các hiểu biết mới sẽ sở hữu lại lợi thế cho họ.
NVivo cung ứng cho người tiêu dùng một nơi để đơn vị và quản lý chương trình nghiên cứu này.
Ưu Điểm của phần mềm NVivo là nhập và phân tích hình ảnh, video, email, bảng tính, khảo sát trực tuyến, dữ liệu webMã hóa mối quan hệBiểu đồ, đám mây từ ngữ, cây từ ngữ, lược đồ khám phá và so sánh
## Phần mềm thống kê R
R là một ngôn ngữ lập trình cũng là 1 phương tiện dùng cho phân tách thống kê học cũng như phân tích dữ liệu đề cập chung. R được rộng rãi trường đại học trên thế giới tiêu dùng rộng rãi. Đây là phần mềm mã nguồn mở miễn phí tổn nhưng nó sở hữu toàn bộ những tính năng của những phần mềm thương mại khác hiện có như SPSS, STATA hay EViews.
Thế mạnh của R là phân tách biểu đồ tuyệt vời. Không một phần mềm nào có thể sánh sở hữu R về phần biểu đồ.
Nhược điểm là có tính học thuật của R, R chạy cốt yếu bằng lệnh, không với giao diện thân thiện như các phần mềm thống kê khác.
  * [Phần mềm thống kê SPSS](https://bvnguyentriphuong.com.vn/nghien-cuu-khoa-hoc-va-thu-nghiem-lam-sang/4-phan-mem-thong-ke-xu-ly-so-lieu-pho-bien-trong-nghien-cuu-y-sinh#phn-mm-thng-k-spss)
  * [Phần mềm thống kê STATA](https://bvnguyentriphuong.com.vn/nghien-cuu-khoa-hoc-va-thu-nghiem-lam-sang/4-phan-mem-thong-ke-xu-ly-so-lieu-pho-bien-trong-nghien-cuu-y-sinh#phn-mm-thng-k-stata)
  * [Phần mềm thống kê NVIVO](https://bvnguyentriphuong.com.vn/nghien-cuu-khoa-hoc-va-thu-nghiem-lam-sang/4-phan-mem-thong-ke-xu-ly-so-lieu-pho-bien-trong-nghien-cuu-y-sinh#phn-mm-thng-k-nvivo)
  * [Phần mềm thống kê R](https://bvnguyentriphuong.com.vn/nghien-cuu-khoa-hoc-va-thu-nghiem-lam-sang/4-phan-mem-thong-ke-xu-ly-so-lieu-pho-bien-trong-nghien-cuu-y-sinh#phn-mm-thng-k-r)



## Phương pháp phòng vấn sâu và thảo luận nhóm trong nghiên cứu định tính

  * [1. Phỏng vấn sâu](https://bvnguyentriphuong.com.vn/nghien-cuu-khoa-hoc-va-thu-nghiem-lam-sang/phuong-phap-phong-van-sau-va-thao-luan-nhom-trong-nghien-cuu-dinh-tinh#1-phng-vn-su)
  * [Phỏng vấn sâu là gì? Khi nào bạn có một cuộc phỏng vấn sâu?](https://bvnguyentriphuong.com.vn/nghien-cuu-khoa-hoc-va-thu-nghiem-lam-sang/phuong-phap-phong-van-sau-va-thao-luan-nhom-trong-nghien-cuu-dinh-tinh#phng-vn-su-l-g-khi-no-bn-c-mt-cuc-phng-vn-su)
  * [4 phương pháp phỏng vấn sâu hữu dụng trong nghiên cứu định tính](https://bvnguyentriphuong.com.vn/nghien-cuu-khoa-hoc-va-thu-nghiem-lam-sang/phuong-phap-phong-van-sau-va-thao-luan-nhom-trong-nghien-cuu-dinh-tinh#4-phng-php-phng-vn-su-hu-dng-trong-nghin-cu-nh-tnh)
  * [ 2. Thảo luận nhóm](https://bvnguyentriphuong.com.vn/nghien-cuu-khoa-hoc-va-thu-nghiem-lam-sang/phuong-phap-phong-van-sau-va-thao-luan-nhom-trong-nghien-cuu-dinh-tinh#2-tho-lun-nhm)


## 1. Phỏng vấn sâu
## Phỏng vấn sâu là gì? Khi nào bạn có một cuộc phỏng vấn sâu?
Phỏng vấn trong nghiên cứu định tính nhằm mô tả ý nghĩa của các chủ đề trung tâm của một số đối tượng cụ thể. Theo nghiên cứu của Kvale (1996), nhiệm vụ chính của việc phỏng vấn là tìm hiểu nguyên nhân sâu xa, ý nghĩa và khám phá các yếu tố mới thông qua đối tượng trả lời.
Những người phỏng vấn chuyên nghiệp có thể tận dụng buổi trò chuyện với các đáp viên để đào sâu và mở rộng thông tin xung quanh chủ đề được định sẵn. Khi thực hiện phỏng vấn, nhà nghiên cứu cần phải theo dõi thái độ, hành vi của đáp viên để ghi nhận và điều tra thêm thông tin dựa trên biểu hiện của họ (McNamara, 1999).
## **4 phương pháp phỏng vấn sâu hữu dụng trong nghiên cứu định tính**
  * _**Phỏng vấn mang tính chất trò chuyện, thân mật**_


Phỏng vấn mang tính chất trò chuyện thân mật: Không có câu hỏi định trước nào được đặt ra, hoàn toàn ngẫu hứng theo tiến trình của câu chuyện. Phương pháp này giúp người phỏng vấn và người tham gia có được bầu không khí trao đổi cởi mở, thoải mái và dễ chia sẻ nhất. Đây cũng là phương pháp dễ thích nghi nhất đối với cả người phỏng vấn và đáp viên.
  * _**Phương pháp tiếp cận hướng dẫn chung/tiếp cận bán cấu trúc**_


Phương pháp phỏng vấn có hướng dẫn chung/ tiếp cận bán cấu trúc nhằm mục đích đảm bảo thu thập được cùng khoảng thông tin chung giống nhau từ những người tham gia phỏng vấn. Điều này giúp cuộc phỏng vấn có tính tập trung cao hơn so với phương pháp phỏng vấn theo hướng trò chuyện, thân mật; đồng thời, giúp rút ngắn thời gian phỏng vấn cho cả hai bên. Bên cạnh đó, vì người phỏng vấn chỉ hướng dẫn sơ qua cho đáp viên, nên phương pháp này vẫn đảm bảo mức độ tự do chia sẻ thông tin và khả năng thích ứng trong việc thu thập thông tin từ người tham gia phỏng vấn.
  * _**Phương pháp phỏng vấn tiêu chuẩn hóa, kết thúc mở**_


Phương pháp phỏng vấn tiêu chuẩn hóa, kết thúc mở là đặt ra các câu hỏi mở giống nhau cho tất cả những người tham gia phỏng vấn. Cách tiếp cận này tạo điều kiện cho cuộc phỏng vấn diễn ra nhanh hơn.
Đồng thời, người phỏng vấn đảm bảo được việc thu thập thông tin trong một phạm vi lĩnh vực cụ thể, nhưng vẫn đảm bảo được việc khám phá ra các yếu tố mới nhờ vào việc đặt câu hỏi mở cho các đáp viên.
  * _**Phương pháp phỏng vấn cấu trúc cố định**_


Trong phương pháp phỏng vấn có cấu trúc cố định, câu trả lời cố định, tất cả những người tham gia phỏng vấn được hỏi những câu hỏi giống nhau và được yêu cầu chọn câu trả lời trong số các lựa chọn đã được định sẵn, kể cả những lựa chọn thay thế.
Cách tiếp cận này giúp tối ưu hóa thời gian phỏng vấn, thông tin thu thập được cố định, dễ phân tích. Tuy nhiên, nhược điểm của phương pháp này là hạn chế sự đào sâu, khám phá các yếu tố mới thông qua câu trả lời của đáp viên.
##  2. Thảo luận nhóm
Một nhóm tập trung thường bao gồm từ 6 đến 8 người có chung một số đặc điểm nhất định phù hợp với chủ đề cuộc thảo luận, ví dụ cùng một trình độ học vấn, cùng một độ tuổi, cùng một giới tính ...
Thảo luận nhóm tập trung (TLNTT) thường được sử dụng để đánh giá các nhu cầu, các biện pháp can thiệp, thử nghiệm các ý tưởng hoặc chương trình mới, cải thiện chương trình hiện tại và thu thập các thông tin về một chủ đề nào đó phục vụ cho việc xây dựng bộ câu hỏi có cấu trúc ... ...
Ưu điểm của phương pháp
- Cung cấp một khối lượng thông tin đáng kể một cách nhanh chóng và rẻ hơn so với phỏng vấn cá nhân.
- Rất có giá trị trong việc tìm hiểu quan niệm, thái độ và hành vi của cộng đồng
- Hỗ trợ việc xác định những câu hỏi phù hợp cho phỏng vấn cá nhân
Nhược điểm
- Nghiên cứu viên khó kiểm soát động thái của quá trình thảo luận so với phỏng vấn cá nhân.
- Thảo luận nhóm tập trung không thể đưa ra tần suất phân bố của các quan niệm và hành vi trong cộng đồng.
- Kết quả TLNTT thường khó phân tích hơn so với phỏng vấn cá nhân.
- Số lượng vấn đề đặt ra trong TLNTT có thể ít hơn so với PV cá nhân
- Việc chi chép lại thông tin và chi tiết của cuộc thảo luận nhóm tập trung rất khó, nhất là việc gỡ băng ghi âm.
  * [1. Phỏng vấn sâu](https://bvnguyentriphuong.com.vn/nghien-cuu-khoa-hoc-va-thu-nghiem-lam-sang/phuong-phap-phong-van-sau-va-thao-luan-nhom-trong-nghien-cuu-dinh-tinh#1-phng-vn-su)
  * [Phỏng vấn sâu là gì? Khi nào bạn có một cuộc phỏng vấn sâu?](https://bvnguyentriphuong.com.vn/nghien-cuu-khoa-hoc-va-thu-nghiem-lam-sang/phuong-phap-phong-van-sau-va-thao-luan-nhom-trong-nghien-cuu-dinh-tinh#phng-vn-su-l-g-khi-no-bn-c-mt-cuc-phng-vn-su)
  * [4 phương pháp phỏng vấn sâu hữu dụng trong nghiên cứu định tính](https://bvnguyentriphuong.com.vn/nghien-cuu-khoa-hoc-va-thu-nghiem-lam-sang/phuong-phap-phong-van-sau-va-thao-luan-nhom-trong-nghien-cuu-dinh-tinh#4-phng-php-phng-vn-su-hu-dng-trong-nghin-cu-nh-tnh)
  * [ 2. Thảo luận nhóm](https://bvnguyentriphuong.com.vn/nghien-cuu-khoa-hoc-va-thu-nghiem-lam-sang/phuong-phap-phong-van-sau-va-thao-luan-nhom-trong-nghien-cuu-dinh-tinh#2-tho-lun-nhm)



## Thử nghiệm lâm sàng (Clinical trials) là gì?

  * [Thử nghiệm lâm sàng](https://bvnguyentriphuong.com.vn/nghien-cuu-khoa-hoc-va-thu-nghiem-lam-sang/thu-nghiem-lam-sang-clinical-trials-la-gi#th-nghim-lm-sng)
  * [Đặc điểm của Thử nghiệm lâm sàng](https://bvnguyentriphuong.com.vn/nghien-cuu-khoa-hoc-va-thu-nghiem-lam-sang/thu-nghiem-lam-sang-clinical-trials-la-gi#c-im-ca-th-nghim-lm-sng)


## **Thử nghiệm lâm sàng**
**Khái niệm**
**Thử nghiệm lâm sàng** tiếng Anh là **Clinical trials.**
**Thử nghiệm lâm sàng** là các nghiên cứu trên cơ thể tình nguyện viên nhằm mục đích đánh giá sự an toàn và hiệu quả của việc điều trị y tế.
### **Đặc điểm của Thử nghiệm lâm sàng**
Các thử nghiệm lâm sàng đánh giá thuốc, thiết bị, qui trình y tế để xem liệu chúng có lợi hay có hại và liệu chúng có hiệu quả hơn, kém hiệu quả hơn hoặc hiệu quả tương đương với các phương pháp điều trị hiện tại hoặc khi so sánh với giả dược hay không.
Thuốc thường trải qua 3 giai đoạn thử nghiệm lâm sàng. Giai đoạn đầu thử nghiệm phân phối thuốc, liều lượng và độ an toàn trên một nhóm nhỏ người. Giai đoạn thứ hai sử dụng nhóm thử nghiệm lớn hơn. Hầu hết các loại thuốc đều thất bại ở một trong các giai đoạn này, nhưng nếu chúng đạt đến giai đoạn ba, chúng sẽ được thử nghiệm trên một nhóm thậm chí còn lớn hơn và so với giả dược hoặc với phương pháp điều trị hiện được chấp nhận. Chỉ có khoảng 5% thuốc vượt qua cả 3 giai đoạn thử nghiệm lâm sàng và được chấp nhận bán ra trên thị trường. 
Có một số loại thử nghiệm lâm sàng. Đầu tiên là thử nghiệm đơn nhóm không có nhóm so sánh. Thử nghiệm ngẫu nhiên và có kiểm soát có hai nhóm bệnh nhân được chỉ định ngẫu nhiên để được điều trị thử nghiệm hoặc sử dụng giả dược. 
Ngoài ra còn có thử nghiệm mù đôi, trong đó cả bệnh nhân và bác sĩ đều không biết hai nhóm thử nghiệm là nhóm nào cho đến khi nghiên cứu kết thúc. Loại nghiên cứu này giúp loại bỏ sự thiên vị trong thử nghiệm. Kết quả thu được từ một nghiên cứu lâm sàng có thể giúp điều trị, chẩn đoán hoặc ngăn ngừa các vấn đề y tế.
Phân tích thống kê là một giai đoạn quan trọng để đánh giá kết quả của một thử nghiệm lâm sàng để xác định liệu phương pháp điều trị có hiệu quả không, hay liệu kết quả dự đoán có khả năng xảy ra hay không. Mặc dù thử nghiệm được thực hiện trên diện rộng, nhưng vẫn khó có thể xác định hiệu quả của thuốc. 
Mặc dù các thử nghiệm lâm sàng có thể chứng minh rằng một loại thuốc có hoặc không có tác dụng, nhưng chúng chưa chắc đã đưa ra một lí do cho tác dụng đó. Một thiếu sót khác của các thử nghiệm lâm sàng là các đối tượng thử nghiệm có thể khỏe hơn so với những bệnh nhân thực sự sử dụng phương pháp điều trị đang được thử nghiệm.
  * [Thử nghiệm lâm sàng](https://bvnguyentriphuong.com.vn/nghien-cuu-khoa-hoc-va-thu-nghiem-lam-sang/thu-nghiem-lam-sang-clinical-trials-la-gi#th-nghim-lm-sng)
  * [Đặc điểm của Thử nghiệm lâm sàng](https://bvnguyentriphuong.com.vn/nghien-cuu-khoa-hoc-va-thu-nghiem-lam-sang/thu-nghiem-lam-sang-clinical-trials-la-gi#c-im-ca-th-nghim-lm-sng)



## Một số nguồn tìm kiếm tài liệu tham khảo cho bài báo khoa học

<http://www.ncbi.nlm.nih.gov/pmc/>
**Open access library**
<http://www.oalib.com/>
**Directory of Open Access Journals**
<https://doaj.org/>
**ResearchGate**
<http://www.researchgate.net/>
**Wikipedia**
<https://www.wikipedia.org/>
<https://pubmed.ncbi.nlm.nih.gov/>
<https://scholar.google.com/>
<http://www.tapchiyhocduphong.vn/>
[**https://db0.vista.gov.vn/**](https://db0.vista.gov.vn/) (cập nhật tháng 02/2023)

## Hướng dẫn cơ bản các cách trích dẫn tài liệu tham khảo phổ biến

  * [Chicago và Turabian](https://bvnguyentriphuong.com.vn/nghien-cuu-khoa-hoc-va-thu-nghiem-lam-sang/huong-dan-co-ban-cac-cach-trich-dan-tai-lieu-tham-khao-pho-bien#chicago-v-turabian)


## 
APA (American Psychological Association) là kiểu trích dẫn ra đời năm 1929 bởi một nhóm các nhà tâm lý học, nhân chủng học và quản lý kinh doanh, kiểu trích dẫn này nhấn mạnh vào tên tác giả và thời gian công bố tác phẩm.
**Cấu trúc cơ bản của kiểu trích dẫn APA**
Họ tác giả, chữ cái đầu tên tác giả. (Năm phát hành). _Tên tác phẩm_. Địa điểm phát hành: Đơn vị phát hành. Nguồn URL 
Ví dụ: Baxter, C. (1997). _Race equality in health care and education_. Philadelphia: Ballière Tindall.
**Danh mục tham khảo theo kiểu APA phải đáp ứng các yêu cầu:**
  * Nằm chính giữa, cuối cùng của bài báo.
  * Sắp xếp theo thứ tự ABC tên của tác giả (hoặc tên tác phẩm nếu không rõ tác giả, trong trường này các mạo từ “a, an, the” được bỏ qua. Nếu trích dẫn nhiều tác phẩm của cùng tác giả, sắp xếp theo năm phát hành. Nếu phát hành cùng năm, sắp xếp theo thứ tự ABC của tên tác phẩm. 
  * Chứa danh sách đầy đủ tất cả các tham chiếu đã được dùng trong bài nghiên cứu (in-text). 


**Cách trích dẫn ngay trong bài viết**
Trích dẫn ngay trong bài viết (in-text) thường được dùng với các câu trích dẫn trực tiếp hoặc tóm tắt ý của tác giả trong tác phẩm gốc. Các trích dẫn này phải khớp với trích dẫn đầy đủ trong phần danh mục tham khảo, gồm họ tác giả cùng năm phát hành tác phẩm. Ví dụ: Mitchell (2017) nói rằng...
Cấu trúc kiểu trích dẫn này còn phụ thuộc vào việc câu trích dẫn là trực tiếp hay được tóm tắt ý. 
Trích dẫn trực tiếp phải gồm câu trích dẫn và số trang của câu đó trong tác phẩm gốc. Ví dụ: (Mitchell, 2017, p.105)
Trích dẫn tóm tắt ý không cần đưa số trang. Ví dụ (Mitchell, 2017)
  * Các trường hợp nhiều tác giả
  * Hai tác giả: Dùng “và” hoặc “hoặc” giữa tên tác giả. Ví dụ: Mitchell và Smith (2017) hoặc (Mitchell & Smith, 2017)
  * Ba, bốn hoặc năm tác giả: Lần đầu trích dẫn ghi tên đầy đủ các tác giả theo cách trên, từ các lần sau chỉ cần ghi tên tác giả đầu tiên là thêm “et al”. Ví dụ: Michell et all (2017) 
  * Từ sáu tác giả trở lên: Chỉ ghi tên tác giả đầu tiên, theo sau bằng “et al” như ví dụ trên. 
  * Không rõ tác giả: Thêm tên tác phẩm. Ví dụ: (A guide to citation, 2017). Nếu là tên bài báo trên mạng, trang web… có thể ghi tên bài, ví dụ “APA Citation”, 2017). 


## 
MLA (Modern Language Association) hiện được cho là kiểu trích dẫn được sử dụng nhiều nhất trong nghiên cứu, đặc biệt là lĩnh vực nhân văn và nghệ thuật. Dưới đây là hướng dẫn cơ bản hình thức trích dẫn này trong phiên bản mới nhất của MLA Handbook (xuất bản lần thứ 8).
**Cấu trúc cơ bản của kiểu trích dẫn MLA**
Họ tác giả, tên tác giả. _Tên tác phẩm_. Tên tác phẩm bao hàm, các đồng tác giả, lần tái bản/phiên bản, số thứ tự trong chuỗi tác phẩm, nhà phát hành, năm phát hành, địa điểm. 
Ví dụ: Mitchell, James A. _A Guide to Citation_. 2nd ed, My London Publisher, 2017.
**Danh mục tham khảo theo kiểu MLA phải đáp ứng các yêu cầu:**
  * Bắt đầu trên trang mới, nằm ở cuối bài nghiên cứu. 
  * Sắp xếp theo thứ tự tác giả, nếu không rõ tác giả thì lấy theo tên tác phẩm. Nếu tác giả có nhiều tác phẩm thì xếp theo năm phát hành, nếu cùng năm phát hành thì xếp theo thứ tự ABC của tên tác phẩm. 
  * Các mục phải cách nhau một dòng trắng. 
  * Các dòng thứ hai trở về sau của cùng một mục phải được lùi đầu dòng 0.5 inch so với lề.
  * Nếu một tác giả có nhiều tác phẩm, tham chiếu đầu tiên phải ghi tên đầy đủ, các tham chiếu sau thay tên bằng “---”. 
  * Chứa danh sách đầy đủ tất cả các tham chiếu đã được dùng trong bài nghiên cứu (in-text). 


**Cách trích dẫn ngay trong bài viết**
Trích dẫn ngay trong bài viết (in-text) thường được dùng với các câu trích dẫn trực tiếp hoặc tóm tắt ý của tác giả trong tác phẩm gốc. Các trích dẫn này phải:
  * khớp với trích dẫn đầy đủ trong phần danh mục tham khảo.
  * chứa từ đầu tiên trong phần danh mục tham khảo, thường là học tác giả, số trang hoặc khoảng trang. 
  * nằm ngay câu trích dẫn hoặc đoạn tóm tắt ý. 


Ví dụ: Mitchell nói rằng “...” (189) hoặc (Mitchell 189)
**Một số trường hợp khác**
  * Tác phẩm có 2-3 tác giả: liệt kê tất cả tên cùng số trang. 
  * Từ 3 tác giả trở lên: chỉ ghi tên tác giả đầu tiên, theo sau bằng “et al”. 
  * Không rõ tác giả: ghi đầy đủ tên tác phẩm in nghiêng, tên viết gọn nằm trong ngoặc kép hoặc tên bài/trang web trong ngoặc kép thay thế tên tác giả. Ví dụ:
    * A Guide to Citation nói rằng “...” (189) hoặc (A Guide to Citation 189). 
    * “MLA Citation Guide” nói rằng “...” (189) hoặc (“MLA Citation Guide” 189).
  * Tác giả có nhiều tác phẩm: ghi thêm tên tác phẩm, ví dụ (Mitchell, A Guide to Citation 189).
  * Tác giả có cùng họ, ghi thêm chữ cái đầu của tên, ví dụ: (J. Mitchell 74) và (M. Mitchell 35-37).


## 
Havard là hình thức trích dẫn khá giống với APA, thường được dùng trong các ngành nhân vân. Ví dụ:
Brick, J 2006, Academic culture: a student’s guide to studying at university, National Centre for English Language Teaching and Research, Sydney.
## Chicago và Turabian
Chicago và Turabian là kiểu trích dẫn được Chicago University Press phát hành từ năm 1906. Hình thức trích dẫn này có 2 loại cơ bản là (1) kiểu dùng cho danh mục tham khảo (thường dùng trong các ngành nhân văn) và (2) kiểu dùng cho trích dẫn trong văn bản, sau đó trích dẫn trong danh mục (thường dùng trong các ngành khoa học xã hội, vật lý, tự nhiên).
Ví dụ kiểu trích dẫn (1): Michael Pollan, The Omnivore's Dilemma: A Natural History of Four Meals (New York: Penguin, 2006), 99–100.
Ví dụ kiểu trích dẫn (2): trích dẫn trong văn bản (Pollan 2006, 99-100) và trích dẫn trong danh mục Pollan, Michael. 2006. The Omnivore’s Dilemma: A Natural History of Four Meals. New York: Penguin.
## IEEE
IEEE (Institute for Electrical and Electronics Engineers) là kiểu trích dẫn của tổ chức cùng tên, gồm các nhánh về kỹ thuật, khoa học máy tính và công nghệ thông tin. Kiểu trích dẫn này gồm trích dẫn trong văn bản với các con số nằm trong ngoặc vuông và xếp thứ tự trong danh mục cũng theo số chữ không phải bảng chữ cái.
Ví dụ: trích dẫn trong văn bản: “This thoery was first put forward in 1987” [1], trích dẫn trong danh mục [1] B. Klaus and P. Horn, Robot Vision. Cambridge, MA: MIT Press, 1986.
## Vancouver
Vancouver là kiểu trích dẫn cũng sử dụng số như IEEE và thường được dùng trong các nghiên cứu khoa học và y tế. Một số nguyên tắc quan trọng khi sử dụng kiểu trích dẫn này:
  * Số thứ tự trong danh mục tham khảo lần lượt theo thứ tự xuất hiện trong bài, nếu bài viết lặp lại trích dẫn thì dùng lại số trước đó.
  * Dùng số Ả rập (1 - 9) và có thể dùng với ngoặc vuông, ngoặc tròn hoặc chỉ số trên, miễn là phải đồng nhất.


Ví dụ:
1. O'Campo P, Dunn JR, editors. Rethinking social epidemiology: towards a science of change. Dordrecht: Springer; 2012. 348 p.
Việc sử dụng hình thức trích dẫn nào còn phụ thuộc vào nhiều yếu tố khác nhau, như tạp chí mà bạn định gửi bài báo hay giáo sư/trường sẽ nhận luận văn của bạn… Tuy vậy, dưới đây là gợi ý về các cách trích dẫn thường dùng theo ngành.
Nhân chủng học/Anthropology - Chicago
Luật và pháp lý/Law & Legal Studies - Bluebook, Maroonbook hoặc ALWD
Lịch sử nghệ thuật/Art History - Chicago hoặc Turabian
Ngôn ngữ học/Linguistics - APA, MLA hoặc LSA
Quản lý nghệ thuật/Arts Management - Chicago
Văn học/Literature - MLA
Sinh học/Biology - CSE
Toán học/Mathematics - AMS
Kinh doanh/Business - APA, Chicago hoặc Harvard
Y dược/Medicine - AMA hoặc NLM
Hóa học/Chemistry - ACS
Âm nhạc/Music - Turabian hoặc Chicago
Truyền thông/Communications - MLA
Triết học/Philosophy - MLA hoặc Chicago
Khoa học máy tính/Computing Science - Chicago
Vật lý/Physics - AIP
Tội phạm học/Criminology - APA hoặc Chicago
Khoa học chính trị/Political Science - APSA
Giáo dục/Education - APA
Tâm lý học/Psychology - APA
Lịch sử/History - Chicago hoặc Turabian
Tôn giáo/Religion - MLA hoặc Chicago
Nghiên cứu quốc tế/International Studies - APA, APSA, hoặc Chicago
Xã hội học/Sociology - ASA
Báo chí/Journalism - AP hoặc APA
Nhà hát/Theater - MLA hoặc Chicago
  * [Chicago và Turabian](https://bvnguyentriphuong.com.vn/nghien-cuu-khoa-hoc-va-thu-nghiem-lam-sang/huong-dan-co-ban-cac-cach-trich-dan-tai-lieu-tham-khao-pho-bien#chicago-v-turabian)



## Viết bài báo khoa học

Việc viết bài báo khoa học là một quá trình phức tạp, tuy nhiên, có một số bước cơ bản sau đây có thể giúp bạn bắt đầu:
  1. Lên kế hoạch và nghiên cứu: Trước khi bắt đầu viết bài báo khoa học, bạn cần lên kế hoạch và tiến hành nghiên cứu kỹ lưỡng về chủ đề của mình. Hãy đảm bảo rằng bạn đã đọc và nghiên cứu các tài liệu liên quan đến chủ đề của bạn để đảm bảo rằng bài báo của bạn sẽ là hợp lý và đầy đủ.
  2. Đặt câu hỏi và giả thuyết: Trong bài báo khoa học, bạn cần đưa ra các câu hỏi và giả thuyết để giải quyết vấn đề của bạn. Điều này giúp bạn tập trung vào vấn đề cần giải quyết và đảm bảo rằng bài báo của bạn là có tính cấp thiết.
  3. Viết phần mở đầu (Introduction): Phần mở đầu của bài báo khoa học cần giới thiệu vấn đề bạn đang nghiên cứu và giải thích tại sao vấn đề này quan trọng. Ngoài ra, bạn cần đưa ra giả thuyết và các câu hỏi cần giải quyết.
  4. Viết phần phương pháp (Methods): Phần phương pháp cần mô tả chi tiết các phương pháp bạn sử dụng để thu thập và xử lý dữ liệu. Phần này cần rõ ràng và chi tiết để đảm bảo tính khả thi của nghiên cứu của bạn.
  5. Viết phần kết quả (Results): Phần kết quả cần trình bày các kết quả của nghiên cứu của bạn. Điều này bao gồm biểu đồ, bảng số liệu, các phân tích thống kê và nhận xét về kết quả của bạn.
  6. Viết phần thảo luận (Discussion): Phần thảo luận cần trình bày các nhận xét và kết luận dựa trên kết quả nghiên cứu của bạn. Phần này cần giải thích tại sao kết quả của bạn quan trọng và có ý nghĩa như thế nào đối với lĩnh vực của bạn.
  7. Viết phần kết (Conclusion): Phần kết là nơi để bạn tóm tắt lại các kết quả của bạn và giải thích ý nghĩa của chúng. Ngoài ra, bạn cũng có thể đưa ra những kiến nghị, đề nghị dựa trên quan điểm và kinh nghiệm cá nhân.


_**Tham khảo về giá trị của các nghiên cứu**_

## Giấy chứng nhận Thực hành tốt thử thuốc trên lâm sàng (GCP)

  * [Giấy chứng nhận Thực hành tốt thử thuốc trên lâm sàng (GCP)](https://bvnguyentriphuong.com.vn/nghien-cuu-khoa-hoc-va-thu-nghiem-lam-sang/giay-chung-nhan-thuc-hanh-tot-thu-thuoc-tren-lam-sang-gcp#giy-chng-nhn-thc-hnh-tt-th-thuc-trn-lm-sng-gcp)


**Bệnh viện Nguyễn Tri Phương** a) Tên và địa chỉ cơ sở thử thuốc trên lâm sàng đáp ứng GCP; Tên cơ sở: BỆNH VIỆN NGUYỄN TRI PHƯƠNG Trụ sở chính: Số 468 Nguyễn Trãi, phường 8, quận 5, thành phố Hồ Chí Minh b) Số giấy chứng nhận đủ điều kiện kinh doanh và số giấy chứng nhận đạt GCP (nếu có); Giấy chứng nhận đạt GCP số 14/GCN-K2ĐT ngày 22/02/2023 d) Thời gian hết hiệu lực của việc đánh giá đáp ứng GCP: Thời gian hết hiệu lực không quá 03 năm kể từ ngày đánh giá gần nhất đ) Phạm vi hoạt động của cơ sở thử thuốc trên lâm sàng: Thuốc hóa dược, Sinh phẩm (thuốc sinh học), Thuốc dược liệu giai đoạn 2,3,4.
### **[Giấy chứng nhận Thực hành tốt thử thuốc trên lâm sàng (GCP)](https://bvnguyentriphuong.com.vn/uploads/072022/files/chung-nhan-GCP.pdf)
#### Nội dung trong file:

Trang ( Page )   1 / 3 BỘ Y TẾ  
MINISTRY OF HEALTH  
CỤC KHOA HỌC CÔNG NGHỆ 
VÀ ĐÀO TẠO  
ADMINISTRATION OF SC IENCE 
TECHNOLOGY AND TRAIN ING CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM  
SOCIALIST REPUBLIC OF VIETNAM  
 Độc lập – Tự do – Hạnh phúc  
 Independence - Freedom - Happiness  
Số / No.:              /GCN -K2ĐT                  Ngày ( day)    tháng ( month )    năm ( year) 2023 
 
GIẤY CH ỨNG NH ẬN ĐÁP ỨNG DUY TRÌ  THỰC HÀNH TỐT TH Ử 
THU ỐC TRÊN LÂM SÀNG  (GCP) 
CERTIFICATE OF GOOD CLINICAL PRACTICE  
Phần 1/ Part 1 : 
Căn cứ  quy định tại Thông tư số 29/2018/TT -BYT ngày 29/10/2018 của Bộ  
trưởng Bộ  Y tế quy định về Thử thuốc trên lâm sàng , 
Pursuant to  the Circular  nº 29/2018/TT -BYT dated 29/10/2018 by Minist er of 
Health  on Good  Clinical Practice (GC P), 
CỤC KHOA H ỌC CÔNG NGH Ệ VÀ ĐÀO T ẠO chứng nh ận: 
Administration of Science Technology and Training  certifie s the following:  
Tên cơ s ở:  BỆNH VI ỆN NGUY ỄN TRI PHƯƠNG  
The Establishment :  Nguyen Tri Phuong Hospital  
Trụ sở chính :  Số 468 Nguy ễn Trãi, phư ờng 8, qu ận 5, T P. Hồ Chí Minh  
Legal address:   Nº 468 Nguyen Trai, Ward 8, District 5, Ho Chi Minh city  
Địa điểm thử thuốc: Số 468 Nguy ễn Trãi, phư ờng 8, qu ận 5, T P. Hồ Chí Minh  
Site address:   Nº 468 Nguyen Trai, Ward 8, District 5, Ho Chi Minh city  
Đã đư ợc đánh giá theo quy đ ịnh liên quan đến việc cấp Giấy chứng nh ận thực 
hành t ốt thử thuốc trên lâm sàng  phù h ợp với các quy đ ịnh tại Điều 33 Lu ật dược số 
105/2016/QH13 ngày 06/04/2016, Đi ều 32 Nghị định s ố 54/2017/NĐ -CP ngày 
08/05/2017 c ủa Chính ph ủ quy đ ịnh chi ti ết một số điều và bi ện pháp thi hành Lu ật 
dược, Đi ều 5 Ngh ị định số 155/2018/NĐ -CP ngày 12/11/2018 c ủa Chính ph ủ về việc 
sửa đổi, bổ sung m ột số quy đ ịnh liên quan đ ến điều kiện đầu tư kinh doanh thu ộc 
phạm vi qu ản lý Nhà nư ớc của Bộ Y tế và Thông tư s ố 29/2018/TT -BYT ngày 
29/10/2018  của Bộ trưởng Bộ Y tế quy đ ịnh về Thử thuốc trên lâm sàng (GC P). 
Has been inspected in connection with  the issuance of Pharmaceutical business 
license and in accordance with  the national regulations at Article 33 of  havtn.k2dt_Vo Thi Nhi Ha_23/02/2023 11:12:33Trang ( Page )   2 / 3 Pharmaceutical Law nº 105/2016/QH13 dated 0 6/04/2016, Article 3 2 of Decree nº 
54/2017/NĐ -CP dated 08 /05/2017 of the Government, detailing some Articles and 
measures t o implement Pharmaceutical Law , Article 5 of Decree nº 155/2018/NĐ -CP 
dated 12/11/2018 by Gorvernment concerning revision and addition of some 
stipulations on trading and investment conditions under the state mandate of Ministry 
of Health  and the Circular  nº 29/2018/TT -BYT dated 29/10 /2018  by Minist er of Health  
on Good Clinical Practice (GC P). 
Căn c ứ kết quả đánh giá cơ sở đáp ứng duy trì GCP  được thực hiện ngày 
25/8/2022, Bệnh viện nêu trên đư ợc chứng nhận đáp ứng các yêu c ầu về Thực hành tốt 
thử thuốc trên lâm sàng  theo quy đ ịnh tại Thông tư s ố 29/2018/TT -BYT ngày 29/10/2018  
của Bộ trưởng B ộ Y tế, phù h ợp với các yêu cầu về Thực hành t ốt thử thuốc trên lâm 
sàng theo khuy ến cáo  của Tổ chức Y t ế thế giới (WH O) & Hội ngh ị quốc tế về hài hòa 
hóa các th ủ tục đăng ký dư ợc phẩm sử dụng cho ngư ời (ICH). 
From  the knowledge gained during  routine  inspection  of GCP of this institution , 
which  was conducted  on 25/8/2022, it is considered that  it complies  with the 
requirements of Good  Clinical Practice  as laid down in  the Circular  nº 29/2018/TT -BYT 
dated 29/10/2018  by Minist er of Health , which is comply  with requirements of Good 
Manufacturing Practice as recommended by  World Health Organization  (WHO)  & 
The International Council for Harmonisation of Technical Requirements for 
Pharmaceuticals for Human Use  (ICH) . 
Giấy chứng nh ận này th ể hiện tình tr ạng đáp ứng th ực hành t ốt thử thuốc trên lâm 
sàng của Đơn v ị tại thời điểm đánh giá nêu trên và có hi ệu lực không quá 03 năm k ể từ 
ngày đánh giá g ần nhất. Tuy nhiên, căn c ứ theo nguyên t ắc quản lý r ủi ro, th ời gian hi ệu 
lực của Giấy chứng nh ận có th ể được rút ngắn hoặc kéo dài và sẽ được ghi t ại mục 
Những nội dung h ạn chế hoặc làm rõ.  
This certificate  reflects  the status  of the manufacturing  site at the time of the 
inspection  noted above and should not  be relied  upon  to reflect  the compliance status  if 
more  than 03 years  have elapsed since the date of that inspection.  However,  this period  
of validity  may be reduced or extended using regulatory  risk management  principles  by 
an entry  in the Restrictions  or Clarifying remarks  field.  
Giấy chứng nh ận chỉ có hi ệu lực khi th ể hiện đầy đủ các trang và bao g ồm cả Phần 
1 và Ph ần 2. 
This certificate is valid only when presented with all pages and both Part 1 and 
Part 2.  havtn.k2dt_Vo Thi Nhi Ha_23/02/2023 11:12:33Trang ( Page )   3 / 3 Tính xác th ực của Giấy chứng nh ận này có th ể được xác nh ận thông qua n ội dung 
đăng t ải trên trang thông tin đi ện tử của Cục Khoa h ọc công ngh ệ và Đào t ạo. Nếu không 
có, hãy liên h ệ với Cục Khoa h ọc công ngh ệ và Đào t ạo để được làm rõ.  
The authenticity  of this certificate may be verified  in website of the Administration 
of Science Technology and Training . If it does  not appear,  please contact the ASTT .  
Phần 2 / Part 2 : 
PHẠM VI ĐĂNG KÝ HOẠT  ĐỘNG THỬ THUỐC TRÊN  LÂM SÀNG /  
CLINICAL REGISTRATION SCOPE  
1. Phạm vi hoạt động thử thuốc trên lâm sàng   1.   Registration Scope  
1.1. Thuốc hóa dược   1.1. Chemical medicines  
1.2. Sinh phẩm (thuốc sinh học)   1.2. Biological medicines  
1.3. Thuốc dược liệu   1.3. Medicinal Herbs  
2.    Giai đoạn thử thuốc trên lâm sàng: Giai 
đoạn 2,3,4 .   2.    Phases of Clinical trial: Phase 2,3,4.  
 
  
KT. C ỤC TRƯ ỞNG 
PHÓ C ỤC TRƯ ỞNG  
Deputy Director  of 
Administration of Science Technology  
 and Training  
 
 
 
Nguy ễn Ngô Quang  
 havtn.k2dt_Vo Thi Nhi Ha_23/02/2023 11:12:33**
  * [Giấy chứng nhận Thực hành tốt thử thuốc trên lâm sàng (GCP)](https://bvnguyentriphuong.com.vn/nghien-cuu-khoa-hoc-va-thu-nghiem-lam-sang/giay-chung-nhan-thuc-hanh-tot-thu-thuoc-tren-lam-sang-gcp#giy-chng-nhn-thc-hnh-tt-th-thuc-trn-lm-sng-gcp)



## Y học chứng cứ (Evidence-Based Medicine)

**Khái niệm Y học chứng cứ (Evidence-Based Medicine)** là phương pháp tiếp cận trong thực hành y tế. Trong đó các quyết định lâm sàng được đưa ra dựa trên các bằng chứng khoa học tốt nhất hiện có, kết hợp với kinh nghiệm lâm sàng của bác sĩ và mong muốn của bệnh nhân.
Thuật ngữ này được định nghĩa rõ ràng vào những năm 1990 bởi nhóm nghiên cứu tại Đại học McMaster, Canada, với mục tiêu nâng cao chất lượng chăm sóc y tế thông qua việc sử dụng dữ liệu nghiên cứu đáng tin cậy
**Theo David Sackett,** một trong những người tiên phong của EBM, y học thực chứng là:
“Sự tích hợp có ý thức, rõ ràng và hợp lý của các bằng chứng khoa học tốt nhất hiện có với kinh nghiệm lâm sàng và mong muốn của bệnh nhân để đưa ra quyết định chăm sóc sức khỏe.”
**Y học thực chứng dựa trên ba trụ cột chính:**
• Bằng chứng khoa học tốt nhất (Best Available Evidence): Các nghiên cứu khoa học có chất lượng cao, như thử nghiệm lâm sàng ngẫu nhiên có đối chứng (RCTs), tổng quan hệ thống (systematic reviews), hoặc meta-analysis (đặc biệt là phân tích gộp dữ liệu từ các RCTs), được ưu tiên sử dụng. Các bằng chứng này phải được đánh giá dựa trên tính hợp lệ, độ tin cậy, và khả năng áp dụng.
• Kinh nghiệm lâm sàng (Clinical Expertise): Kiến thức và kỹ năng của bác sĩ giúp đánh giá tình trạng bệnh nhân, diễn giải bằng chứng khoa học, và áp dụng vào thực tế. Kinh nghiệm này bao gồm khả năng chẩn đoán, điều trị, và dự đoán kết quả.
• Giá trị và mong muốn của bệnh nhân (Patient Values and Preferences): Quyết định y khoa cần tôn trọng nguyện vọng, văn hóa, và hoàn cảnh cá nhân của bệnh nhân. Điều này đảm bảo rằng phương pháp điều trị phù hợp với mục tiêu và ưu tiên của họ.
**Quy trình thực hiện y học thực chứng thường được bắt đầu bằng việc đặt ra câu hỏi lâm sàng (Formulate a Clinical Question)** , nhằm xác định vấn đề cụ thể cần giải quyết. Thường được sử dụng cấu trúc PICO:
• P (Patient/Population): Bệnh nhân hoặc nhóm dân số bệnh nhân.
• I (Intervention): Chỉ định can thiệp hoặc phương pháp điều trị.
• C (Comparison): So sánh với phương pháp khác hoặc giả dược.
• O (Outcome): Kết quả mong muốn.
Một ví dụ minh hoạ khi đặt ra câu hỏi: **“Ở bệnh nhân đột quỵ do thiếu máu não do tắc động mạch lớn trong vòng 4,5 giờ, việc “bridging therapy” với alteplase kết hợp lấy huyết khối bằng dụng cụ cơ học có cải thiện tỷ lệ phục hồi chức năng và an toàn so với điều trị lấy huyết khối bằng dụng cụ cơ học đơn thuần hay không?”**
Để trả lời câu hỏi này, chúng ta sẽ đi theo các bước sau:
1. Đầu tiên chúng ta sẽ tìm kiếm bằng chứng (Search for Evidence) bằng cách sử dụng các cơ sở dữ liệu y khoa như PubMed, Cochrane Library… để tìm các nghiên cứu liên quan. Lưu ý nên ưu tiên các nguồn có chất lượng cao. Chúng ta dễ dàng tìm thấy 6 RCTs và một phân tích gộp từ 6 RCTs trên. Tất cả các bài báo này đều được công bố trên NEJM và Lancet, được xem là 2 tạp chí kinh thánh (Cấm cãi !!!) trong lĩnh vực y khoa.
2. Kế đến, đánh giá bằng chứng (Appraise the Evidence) bằng cách phân tích tính hợp lệ, độ tin cậy, và mức độ phù hợp của các nghiên cứu. Điều này bao gồm kiểm tra thiết kế nghiên cứu, kích thước mẫu, và nguy cơ sai lệch (bias). Nếu đã công bố trên NEJM, hoặc Lancet, chắc chắn các bài báo đã được trải qua quy trình kiểm tra rất chặt chẽ.
3. Áp dụng bằng chứng (Apply the Evidence), cần kết hợp bằng chứng với tình trạng cụ thể của bệnh nhân và kinh nghiệm lâm sàng để đưa ra quyết định điều trị phù hợp. Nếu các chứng cứ đã chứng minh đây là phương pháp mang lại hiệu quả và an toàn, chúng ta cần giải thích cho bệnh nhân để được sử dụng. Các trường hợp bác sĩ điều trị quyết định KHÔNG CHỈ ĐỊNH (đi ngược với chứng cứ hiện tại), cần nêu rõ lý do cụ thể trên từng bệnh nhân (khi bệnh nhân là đối tượng đặc biệt có rủi ro cao, hoặc có chống chỉ định…). Nên tránh mang cảm nhận cá nhân (chỉ dựa trên một vài trường hợp trước đó) để ra quyết định. Cuối cùng, quan trọng là nguyện vọng và mong muốn của bệnh nhân và gia đình có muốn sử dụng phương pháp đó hay không.
Sau điều trị, cần đánh giá kết quả (Evaluate the Outcome) bằng việc theo dõi hiệu quả của quyết định, điều chỉnh nếu cần, và rút kinh nghiệm cho các trường hợp tương lai. Tất cả điều này nên được phản ảnh qua những con số ghi nhận lại một cách khoa học và minh bạch trong một nghiên cứu ứng dụng. Nếu chỉ dựa vào cảm nhận qua 1 hay 2 trường hợp, chúng ta sẽ rất dễ bị sai lệch trong cách đánh giá.
**Tầm quan trọng của y học thực chứng**
• Nâng cao chất lượng chăm sóc: EBM giúp bác sĩ đưa ra quyết định dựa trên dữ liệu đáng tin cậy, giảm thiểu các phương pháp điều trị không hiệu quả hoặc có hại.
• Tăng tính nhất quán: tham khảo các hướng dẫn điều trị đột quỵ dựa trên EBM (như của AHA, ESO) đảm bảo sự thống nhất trong thực hành y tế trên toàn cầu.
• Tối ưu hóa nguồn lực: Giúp sử dụng các phương pháp hiệu quả về chi phí, đặc biệt quan trọng ở các nước đang phát triển như Việt Nam.
• Trao quyền cho bệnh nhân: Kết hợp mong muốn của bệnh nhân giúp tăng sự hài lòng và tuân thủ điều trị.
• Thúc đẩy nghiên cứu: EBM khuyến khích các nghiên cứu chất lượng cao để cung cấp bằng chứng mới, đồng thời chỉ ra các khoảng trống kiến thức cần được nghiên cứu thêm.
Do vậy, các bác sĩ không chỉ là người chăm sóc và điều trị bệnh nhân mà còn có thể đóng vai trò là nhà khoa học. Tham gia vào quá trình nghiên cứu trong lĩnh vực y học, khám phá các phương pháp mới, để hiểu rõ các cơ chế bệnh lý, và phát triển các liệu pháp điều trị dựa trên bằng chứng khoa học.

## Hội nghị khoa học kinh tế y tế X


## Thiết kế nghiên cứu can thiệp


## Phân tích độ tin cậy Cronbach's Alpha của bộ câu hỏi

  * [1. Khái niệm kiểm định độ tin cậy thang đo Cronbach's Alpha?](https://bvnguyentriphuong.com.vn/nghien-cuu-khoa-hoc-va-thu-nghiem-lam-sang/phan-tich-do-tin-cay-cronbachs-alpha-cua-bo-cau-hoi#1-khi-nim-kim-nh-tin-cy-thang-o-cronbachs-alpha)
  * [2. Đo lường độ tin cậy bằng hệ số Cronbach’s Alpha](https://bvnguyentriphuong.com.vn/nghien-cuu-khoa-hoc-va-thu-nghiem-lam-sang/phan-tich-do-tin-cay-cronbachs-alpha-cua-bo-cau-hoi#2-o-lng-tin-cy-bng-h-s-cronbachs-alpha)


## 1. Khái niệm kiểm định độ tin cậy thang đo Cronbach's Alpha?
**Kiểm định độ tin cậy thang đo Cronbach's Alpha là gì** và tại sao phải sử dụng đến nó? Trong nghiên cứu định lượng, việc đo lường các nhân tố lớn sẽ rất khó khăn và phức tạp, không thể chỉ sử dụng những thang đo đơn giản (chỉ dùng 1 câu hỏi qua sát đo lường) mà phải sử dụng các thang đo chi tiết hơn (dùng nhiều câu hỏi quan sát để đo lường nhân tố) để hiểu rõ được tính chất của nhân tố lớn.
Do vậy, khi lập bảng câu hỏi nghiên cứu, chúng ta thường tạo các biến quan sát x1, x2, x3, x4, x5... là biến con của nhân tố A nhằm mục đích thay vì đi đo lường cả một nhân tố A tương đối trừu tượng và khó đưa ra kết quả chính xác thì chúng ta đi đo lường các biến quan sát nhỏ bên trong rồi suy ra tính chất của nhân tố.
Như vậy, khái niệm **"thang đo"** trong cụm kiểm định độ tin cậy thang đo ý muốn nói đến **một tập hợp các biến quan sát con có khả năng** **đo được, thể hiện được tính chất của nhân tố mẹ**. Các bạn không được **hiểu lầm** kiểm định thang đo ở đây là thang đo Likert.
**Kiểm định độ tin cậy thang đo Cronbach's Alpha** là công cụ chúng ta cần. Công cụ này sẽ giúp kiểm tra xem các biến quan sát của nhân tố mẹ (nhân tố A) có đáng tin cậy hay không, có tốt không. Phép kiểm định này phản ánh mức độ tương quan chặt chẽ giữa các biến quan sát trong cùng 1 nhân tố. Nó cho biết trong các biến quan sát của một nhân tố, biến nào đã đóng góp vào việc đo lường khái niệm nhân tố, biến nào không. Kết quả **Cronbach Alpha** của nhân tố tốt thể hiện rằng các biến quan sát chúng ta liệt kê là rất tốt, thể hiện được đặc điểm của nhân tố mẹ, chúng ta đã có được một thang đo tốt cho nhân tố mẹ này.
## 2. Đo lường độ tin cậy bằng hệ số Cronbach’s Alpha
Trước tiên, chúng ta cần hiểu được khái niệm tính nhất quán nội bộ của một yếu tố. Tính nhất quán nội bộ nghĩa là các biến quan sát trong một thang đo phải có sự tương quan thuận chặt chẽ nhau, cùng giải thích cho một khái niệm. Cronbach' Alpha là một chỉ số đo lường tính nhất quán nội bộ này. Như vậy, nếu một thang đo mà các biến quan sát có sự tương quan thuận càng chặt chẽ, thang đo đó càng có tính nhất quán cao, hệ số Cronbach’s Alpha sẽ càng cao. 
Hệ số Cronbach’s Alpha có giá trị biến thiên trong đoạn [0,1]. Mức 0 nghĩa là các biến quan sát trong nhóm gần như không có một sự tương quan nào, mức 1 nghĩa là các biến quan sát tương quan hoàn hảo với nhau, hai mức 0 và 1 hiếm khi xảy ra trong phân tích dữ liệu. Một số trường hợp xuất hiện hệ số Cronbach’s Alpha âm vượt ngoài đoạn giới hạn [0,1], lúc này thang đo hoàn toàn không có độ tin cậy, không có tính đơn hướng, các biến quan sát trong thang đo đối lập, ngược chiều nhau. 
  * [1. Khái niệm kiểm định độ tin cậy thang đo Cronbach's Alpha?](https://bvnguyentriphuong.com.vn/nghien-cuu-khoa-hoc-va-thu-nghiem-lam-sang/phan-tich-do-tin-cay-cronbachs-alpha-cua-bo-cau-hoi#1-khi-nim-kim-nh-tin-cy-thang-o-cronbachs-alpha)
  * [2. Đo lường độ tin cậy bằng hệ số Cronbach’s Alpha](https://bvnguyentriphuong.com.vn/nghien-cuu-khoa-hoc-va-thu-nghiem-lam-sang/phan-tich-do-tin-cay-cronbachs-alpha-cua-bo-cau-hoi#2-o-lng-tin-cy-bng-h-s-cronbachs-alpha)



