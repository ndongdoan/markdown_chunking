## Ðảng và những vấn đề cơ bản về xây dựng Ðảng

**Đảng Cộng sản Việt Nam** do đồng chí Hồ Chí Minh sáng lập và rèn luyện, đã lãnh đạo nhân dân tiến hành Cách mạng Tháng Tám thành công, lập nên nước Việt Nam Dân chủ cộng hoà (nay là nước Cộng hoà xã hội chủ nghĩa Việt Nam), đánh thắng các cuộc chiến tranh xâm lược, xoá bỏ chế độ thực dân, phong kiến, hoàn thành sự nghiệp giải phóng dân tộc, thống nhất đất nước, tiến hành công cuộc đổi mới, xây dựng chủ nghĩa xã hội và bảo vệ vững chắc nền độc lập của Tổ quốc.
Đảng Cộng sản Việt Nam là đội tiên phong của giai cấp công nhân, đồng thời là đội tiên phong của nhân dân lao động và của dân tộc Việt Nam; đại biểu trung thành lợi ích của giai cấp công nhân, của nhân dân lao động và của dân tộc.
Mục đích của Đảng là xây dựng nước Việt Nam độc lập, dân chủ, giàu mạnh, xã hội công bằng, văn minh, không còn người bóc lột người, thực hiện thành công chủ nghĩa xã hội và cuối cùng là chủ nghĩa cộng sản.
Đảng lấy chủ nghĩa Mác - Lênin và tư tưởng Hồ Chí Minh làm nền tảng tư tưởng, kim chỉ nam cho hành động, phát huy truyền thống tốt đẹp của dân tộc, tiếp thu tinh hoa trí tuệ của nhân loại, nắm vững quy luật khách quan, xu thế thời đại và thực tiễn của đất nước để đề ra Cương lĩnh chính trị, đường lối cách mạng đúng đắn, phù hợp với nguyện vọng của nhân dân.
Đảng là một tổ chức chặt chẽ, thống nhất ý chí và hành động, lấy tập trung dân chủ làm nguyên tắc tổ chức cơ bản, thực hiện tập thể lãnh đạo, cá nhân phụ trách, thương yêu đồng chí, kỷ luật nghiêm minh, đồng thời thực hiện các nguyên tắc : tự phê bình và phê bình, đoàn kết trên cơ sở Cương lĩnh chính trị và Điều lệ Đảng, gắn bó mật thiết với nhân dân, Đảng hoạt động trong khuôn khổ Hiến pháp và pháp luật.
Đảng Cộng sản Việt Nam là đảng cầm quyền, tôn trọng và phát huy quyền làm chủ của nhân dân, chịu sự giám sát của nhân dân; dựa vào nhân dân để xây dựng Đảng; đoàn kết và lãnh đạo nhân dân tiến hành sự nghiệp cách mạng. Đảng lãnh đạo hệ thống chính trị, đồng thời là một bộ phận của hệ thống ấy. Đảng lãnh đạo, tôn trọng và phát huy vai trò của Nhà nước, Mặt trận Tổ quốc Việt Nam và các đoàn thể chính trị - xã hội.
Đảng kết hợp chủ nghĩa yêu nước chân chính với chủ nghĩa quốc tế trong sáng của giai cấp công nhân, góp phần tích cực vào sự nghiệp hoà bình, độc lập dân tộc, dân chủ và tiến bộ xã hội của nhân dân thế giới.
Đảng Cộng sản Việt Nam được xây dựng vững mạnh về chính trị, tư tưởng và tổ chức, thường xuyên tự đổi mới, tự chỉnh đốn, không ngừng nâng cao chất lượng đội ngũ cán bộ, đảng viên, sức chiến đấu và năng lực lãnh đạo cách mạng của Đảng.
Được trích từ **Điều lệ Đảng (do Đại hội đại biểu toàn quốc lần thứ XI của Đảng thông qua)**
Xem toàn văn [**tại đây**](https://tulieuvankien.dangcongsan.vn/van-kien-tu-lieu-ve-dang/dieu-le-dang/dieu-le-dang-do-dai-hoi-dai-bieu-toan-quoc-lan-thu-xi-cua-dang-thong-qua-3431)

## Bệnh viện Nguyễn Tri Phương tổ chức khám, phát thuốc miễn phí cho người dân Phường An Đông

Hướng tới kỷ niệm 80 năm Cách Mạng Tháng Tám thành công và Quốc khánh nước Cộng Hòa Xã Hội Chủ Nghĩa Việt Nam (02/9/1945 - 02/9/2025), đồng thời hướng tới Đại hội Đại biểu phường An Đông lần thứ I, nhiệm kỳ 2025 – 2030, sáng thứ Bảy ngày 16/8/2025 tại Bệnh viện Nguyễn Tri Phương, chương trình khám sức khỏe, phát thuốc miễn phí và tặng quà cho người diện chính sách, người dân có hoàn cảnh khó khăn trên địa bàn phường An Đông đã được tổ chức chu đáo và ý nghĩa.
Chương trình do Ủy Ban Nhân Dân phường An Đông phối hợp cùng Bệnh viện Nguyễn Tri Phương thực hiện, với sự tham gia của 100 người dân. Các phần khám bao gồm: đo huyết áp, khám tổng quát, xét nghiệm máu và chụp X-quang. Sau khi khám, mỗi người dân được cấp phát thuốc điều trị theo chỉ định và nhận phần quà động viên từ chương trình.
Phát biểu tại buổi khai mạc, bà Hồ Thiện Mỹ Phương đại diện Ủy Ban Nhân D phường An Đông nhấn mạnh: _“Hoạt động này không chỉ mang ý nghĩa chăm lo thiết thực đến đời sống sức khỏe người dân có hoàn cảnh khó khăn, mà còn góp phần lan tỏa tinh thần đoàn kết, sẻ chia trong cộng đồng, hướng đến mục tiêu chăm sóc sức khỏe toàn dân.”_
Về phía Bệnh viện Nguyễn Tri Phương, BS.CKII Lương Công Minh, Phó Giám đốc khẳng định luôn đồng hành cùng chính quyền địa phương trong công tác an sinh xã hội, xem đây là trách nhiệm và sứ mệnh phục vụ cộng đồng của một bệnh viện công lập hạng I.
Chương trình đã diễn ra trong không khí ấm áp, tạo niềm tin và sự phấn khởi cho người dân được quan tâm chăm sóc sức khỏe, đặc biệt là các gia đình khó khăn, chính sách.
Ban Tổ chức chương trình trân trọng gửi lời cảm ơn đến Công ty Cổ phần Ba Huân cùng các nhà hảo tâm đã đồng hành, hỗ trợ quà tặng và cùng chung tay mang lại niềm vui, sức khỏe cho người dân phường An Đông. Sự đồng hành của các đơn vị, doanh nghiệp chính là nguồn động viên to lớn để chương trình thành công, góp phần xây dựng một cộng đồng nhân ái, văn minh và khỏe mạnh
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh
__________
__________

## Đảng bộ BV Nguyễn Tri Phương trực thuộc Đảng bộ Phường An Đông

Hôm nay, ngày 08.7.2025, đã diễn ra buổi hội nghị "Trao Quyết định tiếp nhận, tổ chức lại các chi bộ, đảng bộ cơ sở thuộc Đảng bộ Phường An Đông"
Theo đó, Đảng bộ BV Nguyễn Tri Phương sẽ trực thuộc Đảng bộ Phường An Đông quản lý trực tiếp
Đồng chí Vính An, phó bí thư thường trực Đảng ủy Phương An Đông, đã nhắc nhở một số nội dung quan trọng trong công tác xây dựng Đảng. Qua đó, Đảng bộ Bệnh viện Nguyễn Tri Phương cần đặc biệt lưu ý trong việc chấp hành nghiêm các chủ trương, đường lối của Đảng bộ cấp trên, đồng thời bảo đảm sự lãnh đạo toàn diện đối với các hoạt động chính trị, tư tưởng, chuyên môn trong nội bộ bệnh viện. Là một tổ chức cơ sở Đảng trong lĩnh vực y tế, Đảng bộ bệnh viện không chỉ có vai trò lãnh đạo về chuyên môn mà còn phải làm tốt công tác giáo dục tư tưởng, đạo đức nghề nghiệp cho đội ngũ cán bộ, đảng viên và nhân viên y tế. 
Sự gắn kết chặt chẽ với Đảng bộ Phường An Đông cũng đòi hỏi Đảng bộ bệnh viện cần chủ động phối hợp trong các chương trình hành động, phong trào thi đua, cũng như thực hiện các nghị quyết liên tịch nhằm phát huy sức mạnh tổng hợp của cả hệ thống chính trị địa phương. Bên cạnh đó, công tác phát triển Đảng, đánh giá chất lượng tổ chức cơ sở Đảng và đảng viên hằng năm phải được thực hiện nghiêm túc, đúng quy trình, bảo đảm tính khách quan, minh bạch. Việc thực hiện tốt vai trò hạt nhân chính trị tại cơ sở sẽ góp phần nâng cao chất lượng chăm sóc sức khỏe nhân dân và xây dựng Đảng bộ trong sạch, vững mạnh.

## Bệnh viện Nguyễn tri phương tổ chức họp mặt kỷ niệm 78 năm Ngày Thương binh – liệt sĩ (27/7/1947 – 27/7/2025)

Vào lúc 14 giờ, thứ Năm, ngày 24/7/2025, Bệnh viện Nguyễn Tri Phương đã tổ chức buổi họp mặt kỷ niệm 78 năm Ngày Thương binh – Liệt sĩ (27/7/1947 – 27/7/2025) trong không khí trang nghiêm và xúc động. Đây là dịp để tập thể cán bộ, nhân viên y tế cùng nhau ôn lại truyền thống, tri ân sâu sắc những người đã anh dũng hy sinh vì độc lập, tự do của dân tộc, vì sự bình yên và hạnh phúc của nhân dân.
Ngày Thương binh – Liệt sĩ được Chủ tịch Hồ Chí Minh ký sắc lệnh công nhận vào ngày 27/7/1947. Trải qua 78 năm, ngày này đã trở thành dấu mốc lịch sử thiêng liêng để toàn dân tưởng nhớ và tôn vinh những người con ưu tú đã cống hiến cả tuổi xuân, cả máu xương cho sự nghiệp bảo vệ Tổ quốc. Họ là các thương binh, bệnh binh, liệt sĩ – những người đã ngã xuống hoặc mang trên mình vết thương chiến tranh, mãi là biểu tượng sống động của lòng yêu nước và tinh thần cách mạng.
Phát huy đạo lý “Uống nước nhớ nguồn”, “Ăn quả nhớ người trồng cây”, buổi họp mặt cũng là dịp để toàn thể cán bộ công nhân viên Bệnh viện Nguyễn Tri Phương tiếp tục thể hiện sự quan tâm, chăm lo thiết thực cho các đối tượng chính sách. Qua đó, góp phần bồi đắp tinh thần nhân ái, nghĩa tình trong cộng đồng và lan tỏa giá trị truyền thống tốt đẹp của dân tộc Việt Nam.
Buổi lễ diễn ra với sự tham dự của đại diện Đảng ủy, Ban Giám đốc, Công đoàn, Đoàn Thanh niên, Hội Cực Chiến binh cùng đông đảo cán bộ, viên chức, người lao động đang công tác tại bệnh viện. Đây là hoạt động có ý nghĩa nhân văn sâu sắc, thể hiện trách nhiệm và lòng biết ơn đối với thế hệ cha anh đã hy sinh vì sự nghiệp giải phóng dân tộc và thống nhất đất nước.

## Đại hội Đoàn TNCS Hồ Chí Minh Bệnh viện Nguyễn Tri Phương lần thứ XXI

  * [Kỳ vọng mới – Thành tích mới trên hành trình 2025–2030](https://bvnguyentriphuong.com.vn/hoat-dong-doan-the/dai-hoi-doan-tncs-ho-chi-minh-benh-vien-nguyen-tri-phuong-lan-thu-xxi#k-vng-mi-thnh-tch-mi-trn-hnh-trnh-20252030)
  * [Tri ân nhiệm kỳ XX – Nền tảng của những bước tiến mới](https://bvnguyentriphuong.com.vn/hoat-dong-doan-the/dai-hoi-doan-tncs-ho-chi-minh-benh-vien-nguyen-tri-phuong-lan-thu-xxi#tri-n-nhim-k-xx-nn-tng-ca-nhng-bc-tin-mi)
  * [Hướng tới tương lai – Kỳ vọng mới, thành tích mới](https://bvnguyentriphuong.com.vn/hoat-dong-doan-the/dai-hoi-doan-tncs-ho-chi-minh-benh-vien-nguyen-tri-phuong-lan-thu-xxi#hng-ti-tng-lai-k-vng-mi-thnh-tch-mi)


## **Kỳ vọng mới – Thành tích mới trên hành trình 2025–2030**
Chiều ngày 17/9/2025, Đại hội đại biểu Đoàn TNCS Hồ Chí Minh Bệnh viện Nguyễn Tri Phương lần thứ XXI, nhiệm kỳ 2025–2030 đã diễn ra trong không khí trang trọng, đoàn kết và tràn đầy nhiệt huyết tuổi trẻ. Đây là sự kiện chính trị quan trọng, đánh dấu chặng đường mới của tổ chức Đoàn bệnh viện – lực lượng xung kích trẻ trung, sáng tạo, luôn đồng hành cùng sự phát triển của bệnh viện và sự nghiệp chăm sóc sức khỏe nhân dân.
## **Tri ân nhiệm kỳ XX – Nền tảng của những bước tiến mới**
Đại hội đã dành nhiều thời gian đánh giá, nhìn lại nhiệm kỳ 2020–2025 với niềm tự hào về những dấu ấn nổi bật:
Các hoạt động chuyên môn gắn với cộng đồng: hàng chục lượt đoàn khám sức khỏe, hiến máu tình nguyện, nhiều công trình thanh niên áp dụng thực tiễn vào công tác khám chữa bệnh.
Đồng hành cùng bệnh viện trong chuyển đổi số, đóng góp thiết thực vào nâng cao chất lượng phục vụ người bệnh.
Chăm lo đoàn viên: hỗ trợ đoàn viên khó khăn, tạo môi trường rèn luyện, trưởng thành cho lớp trẻ y tế.
Đại hội trân trọng gửi lời cảm ơn sâu sắc đến Ban Chấp hành Đoàn nhiệm kỳ XX đã dẫn dắt phong trào bằng tâm huyết, trách nhiệm và sáng tạo, tạo nền móng vững chắc để thế hệ kế thừa tự tin bước tiếp.
## **Hướng tới tương lai – Kỳ vọng mới, thành tích mới**
Đại hội XXI đã thảo luận, thống nhất phương hướng, mục tiêu và giải pháp cho nhiệm kỳ 2025–2030 với tinh thần Đổi mới – Sáng tạo – Hội nhập – Phát triển.
Nhiệm vụ trọng tâm trong giai đoạn mới:
1. Đẩy mạnh công tác giáo dục chính trị tư tưởng, bồi dưỡng lý tưởng cách mạng, nâng cao bản lĩnh chính trị, đạo đức, lối sống, khát vọng cống hiến cho đoàn viên, thanh niên.
2. Phát huy vai trò xung kích, sáng tạo của đoàn viên, thanh niên trong thực hiện nhiệm vụ chuyên môn; tích cực tham gia chuyển đổi số, cải tiến chất lượng bệnh viện và các hoạt động nghiên cứu khoa học.
3. Tăng cường các hoạt động tình nguyện vì cộng đồng gắn với chuyên môn y tế, xây dựng hình ảnh người thầy thuốc trẻ giàu nhiệt huyết, trách nhiệm với xã hội.
4. Chăm lo lợi ích chính đáng, hợp pháp của đoàn viên, thanh niên; đồng hành trong học tập, nghề nghiệp, nâng cao kỹ năng thực hành và đời sống tinh thần.
5. Xây dựng Đoàn vững mạnh toàn diện, nâng cao chất lượng cán bộ Đoàn, đổi mới nội dung và phương thức hoạt động, phát huy vai trò hạt nhân chính trị trong thanh niên.
Đại hội đã tín nhiệm bầu Ban Chấp hành khóa XXI – tập thể cán bộ trẻ trung, bản lĩnh, nhiệt huyết – sẵn sàng dẫn dắt đoàn viên Nguyễn Tri Phương chinh phục những mục tiêu lớn, tiếp tục khẳng định truyền thống Đoàn bệnh viện.
Với khát vọng và niềm tin, tuổi trẻ Nguyễn Tri Phương sẵn sàng viết tiếp những trang mới rực rỡ, đóng góp xứng đáng cho sự phát triển của bệnh viện và sự nghiệp chăm sóc sức khỏe nhân dân.
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [Kỳ vọng mới – Thành tích mới trên hành trình 2025–2030](https://bvnguyentriphuong.com.vn/hoat-dong-doan-the/dai-hoi-doan-tncs-ho-chi-minh-benh-vien-nguyen-tri-phuong-lan-thu-xxi#k-vng-mi-thnh-tch-mi-trn-hnh-trnh-20252030)
  * [Tri ân nhiệm kỳ XX – Nền tảng của những bước tiến mới](https://bvnguyentriphuong.com.vn/hoat-dong-doan-the/dai-hoi-doan-tncs-ho-chi-minh-benh-vien-nguyen-tri-phuong-lan-thu-xxi#tri-n-nhim-k-xx-nn-tng-ca-nhng-bc-tin-mi)
  * [Hướng tới tương lai – Kỳ vọng mới, thành tích mới](https://bvnguyentriphuong.com.vn/hoat-dong-doan-the/dai-hoi-doan-tncs-ho-chi-minh-benh-vien-nguyen-tri-phuong-lan-thu-xxi#hng-ti-tng-lai-k-vng-mi-thnh-tch-mi)



## Hưởng ứng Ngày An toàn Người bệnh Thế giới 17/9/2025

Ngày An toàn người bệnh Thế giới 2025 với chủ đề **“Chăm sóc an toàn cho trẻ sơ sinh và trẻ nhỏ”** là dịp nhằm nâng cao nhận thức của công chúng, tăng cường hiểu biết toàn cầu và huy động hành động để loại bỏ tác hại có thể tránh được trong chăm sóc sức khỏe, cải thiện an toàn người bệnh.
Ngày 17/9/2025, Bệnh viện Nguyễn Tri Phương hưởng ứng **Ngày An toàn người bệnh Thế giới** với chủ đề**_“Chăm sóc an toàn cho trẻ sơ sinh và trẻ nhỏ”_** và khẩu hiệu _**“Patient safety from the start - An toàn từ lúc chào đời!”**._
Trẻ em, đặc biệt là trẻ sơ sinh và dưới 9 tuổi, là nhóm đối tượng dễ bị tổn thương trong chăm sóc y tế do đặc thù phát triển, nhu cầu sức khỏe riêng biệt và phụ thuộc hoàn toàn vào người lớn. Việc đảm bảo an toàn cho trẻ đòi hỏi sự phối hợp chặt chẽ giữa nhân viên y tế, cha mẹ, gia đình và hệ thống y tế, nhằm cung cấp dịch vụ phù hợp, an toàn và toàn diện.
Chiến dịch năm nay tập trung vào 5 mục tiêu chính:
  1. Thu hút trẻ nhỏ và gia đình.
  2. Nâng cao sự an toàn trong dùng thuốc.
  3. Cải thiện an toàn chẩn đoán.
  4. Ngăn ngừa nhiễm khuẩn liên quan đến chăm sóc sức khỏe.
  5. Giảm thiểu rủi ro cho trẻ sơ sinh nhẹ cân và bệnh lý.


Mỗi mục tiêu được giới thiệu bằng một lý do ngắn gọn và được hỗ trợ bởi một số hành động được đề xuất, được tổ chức thành sáu loại:
  1. Con người – hành động hỗ trợ những người cung cấp dịch vụ chăm sóc
  2. Nhiệm vụ – các hoạt động chính mà các nhà cung cấp dịch vụ chăm sóc sức khỏe yêu cầu;
  3. Công cụ và công nghệ – công cụ hỗ trợ công việc, thiết bị, hàng hóa và hỗ trợ công nghệ cần thiết để đảm bảo chăm sóc an toàn 
  4. Môi trường làm việc – điều kiện cơ sở hạ tầng, bố trí và tổ chức của cơ sở chăm sóc;
  5. Tổ chức – các chính sách và hệ thống cho phép thực hiện hiệu quả việc chăm sóc an toàn;
  6. Biện pháp – các dấu vết, cột mốc hoặc chỉ số được sử dụng để theo dõi tiến độ.


Mỗi mục tiêu kết thúc bằng thông tin chi tiết về các nguồn lực liên quan của WHO cung cấp cơ sở cho các hành động được khuyến nghị.
Ngày An toàn Người bệnh Thế giới 2025 hướng tới các hành động, thúc đẩy cải thiện các biện pháp an toàn của nhân viên y tế, lãnh đạo y tế, cũng như của cha mẹ, gia đình, người chăm sóc. Hướng tới thúc đẩy, cải thiện việc cung cấp dịch vụ, an toàn cho bệnh nhân và sức khỏe của trẻ sơ sinh và trẻ em.
**Xem chi tiết nội dung Mục tiêu:**
Video truyền thông:
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh

## HỆ SINH THÁI HỖ TRỢ NGƯỜI BỆNH KHÓ KHĂN

Các mô hình hỗ trợ bao phủ toàn bộ các hình thức hỗ trợ người bệnh khó khăn và tận dụng các phương tiện hỗ trợ điều hành với công nghệ 4.0: 
  * Hỗ trợ khẩn cấp nhập viện: Người bệnh có hoàn cảnh khó khăn (NBHCKK) khi nhập viện cấp cứu sẽ được Quỹ Tâm Nguyện Việt ứng 5.000.000đ viện phí. NBHCKK có thể yên tâm nhập viện điều trị, bệnh viện cũng có thể đẩy nhanh các thủ tục và thực hiện một số xét nghiệm bên ngoài Bệnh viện (ví dụ: xét nghiệm tìm độc chất…)
  * Bữa cơm dinh dưỡng: Bệnh viện kết nối với chương trình Dĩa cơm trên tường (lan tỏa trên mạng xã hội facebook) và bếp ăn tình thương (Công ty P.Dussmann, 100% vốn của Đức) để trao suất ăn hàng ngày cho bệnh nhân tại căntin bệnh viện. Bữa ăn tại bệnh viện đảm bảo cả về vệ sinh an toàn thực phẩm và chức năng hỗ trợ điều trị từng loại bệnh lý riêng biệt.
  * Hỗ trợ viện phí: Kinh phí hỗ trợ được kết nối từ các nguồn quỹ sẵn có và nhiều nguồn xã hội hóa của các tổ chức từ thiện (Từ Tâm, Tâm nguyện Việt, Chia sẻ - Sharing…), thực hiện kết nối qua các group viber, zalo để các tổ chức hoặc các mạnh thường quân nhanh chóng nắm bắt tình hình thực tế của người bệnh. 
  * Hỗ trợ chi phí chi tiêu khác cho NBHCKK khi nằm viện được hỗ trợ từ Nhóm CLB Tình người Sài Gòn hỗ trợ hàng tháng.
  * Chuyến xe nghĩa tình: Nghĩa tử là nghĩa tận, những ca tử vong hoặc bệnh nặng xin về được xe công xa đưa về tận nhà dù khó khăn hay không khó khăn, dù vị trí địa lý có xa xôi trắc trở đến đâu.
  * Gian hàng chia sẻ yêu thương: Những sản phẩm quần áo, vật dụng… được vận động quyên góp và bán lại với những giá rất rẻ năm ngàn, mười ngàn…và cả giá không đồng (0đ). Tất cả số tiền hoạt động từ gian hàng yêu thương sẽ nhập quỹ hỗ trợ người bệnh khó khăn để chia sẻ về viện phí. Sự kêu gọi và ý nghĩa hoạt động được lan tỏa trên các kênh truyền thông của bệnh viện (trang tin điện tử, facebook, zalo offical, youtube, lotus). Mỗi nhân viên y tế hoặc bất cứ ai trong xã hội đều có thể là người cho đi, là người giúp đỡ bệnh nhân có hoàn cảnh khó khăn trong quá trình khám và điều trị tại BV Nguyễn Tri Phương.
  * Gian hàng chia sẻ yêu thương đã giúp nâng dậy tâm hồn của mỗi nhân viên hay mỗi người trong cộng đồng quan tâm cũng như tạo điều kiện cho tất cả mọi người đều có cơ hội để giúp đỡ người khác dù từ vật dụng nhỏ nhất mà mình chưa có nhu cầu sử dụng sự sẻ chia dù ít hay nhiều tùy khả năng của mình trong mỗi ngày.
  * Bằng những phương tiện truyền thông của thời đại 4.0, việc hỗ trợ bệnh nhân được nhanh hơn (các group viber, zalo…) và thông tin chính thống được lan tỏa hơn (facebook, youtube, lotus…) để cả cộng đồng cùng tham gia.



## Công đoàn Bệnh viện Nguyễn Tri Phươngtriển khai “Bữa cơm Công đoàn” đến Tổ công đoàn từ ngày 19/8 - 2/9/2025

Công đoàn Bệnh viện Nguyễn Tri Phương tổ chức chương trình “Bữa cơm Công đoàn – Lan tỏa yêu thương” năm 2025 nhằm thể hiện sự quan tâm, chăm lo đến đoàn viên, người lao động, đồng thời chào mừng Kỷ niệm 96 năm Ngày thành lập Công đoàn Việt Nam (28/7/1929 – 28/7/2025).
Ngày 05/8/2025, Công đoàn Bệnh viện Nguyễn Tri Phương đã ban hành Kế hoạch số 28/KH-CĐCS về việc tổ chức chương trình “Bữa cơm Công đoàn” thiết thực chào mừng kỷ niệm 80 năm ngày Cách mạng Tháng Tám (19/8), Quốc khánh nước Cộng hòa xã hội Chủ nghĩa Việt Nam (02/9) và Nhân dịp chào mừng kỷ niệm 96 năm Ngày thành lập Công đoàn Việt Nam (28/7/1929 - 28/7/2025) để thu hút, tập hợp gắn kết chặt chẽ đoàn viên, người lao động với tổ chức công đoàn và lãnh đạo các đơn vị, chia sẻ, tâm tình tạo nên bầu không khí đoàn kết, thấu hiểu, qua đó tạo dựng niềm tin, sự gắn bó của đoàn viên, người lao động đối với tổ chức công đoàn và Bệnh viện.
Đây là hoạt động thiết thực nhằm chào mừng 96 năm Ngày thành lập Công đoàn Việt Nam (28/7/1929 - 28/7/2025) và tiếp nối thành công của chương trình “Bữa cơm Công đoàn” do Liên đoàn Lao động Thành phố và Tổng Liên đoàn Lao động Việt Nam phát động từ năm 2024.

## Lớp học: 'Thấu hiểu con người - kiến tạo môi trường'

_Điều gì đang khiến nội tâm bạn chưa đơn giản để an vui?_
_Đó là vấn nạn về nội tâm, mối quan hệ, sức khỏe hay tài chính?_
_Dựa vào những tri thức quý báu, những quan niệm chuẩn và khái niệm nguồn có lợi được đúc kết từ cả 3 góc nhìn chi phối con người là đạo lý – tôn giáo – khoa học: hành trình kiến tạo giá trị "giàu toàn diện"_
_– Giàu trí tuệ – Giàu tâm thái – Giàu nhân cách – Giàu phẩm chất – Giàu năng lực – Giàu thể chất – Giàu vật chất_
_7 sự giàu toàn diện được ví như 7 ngọn đèn sẽ xóa tan đi mọi vấn nạn của con người, dù đó là vấn nạn nội tâm, mối quan hệ, sức khỏe hay tài chính._
Với mục đích không ngừng kiến tạo môi trường ngày càng tích cực, Bệnh viện Nguyễn Tri Phương phối hợp cùng Viện Nghiên cứu Phát triển Nguồn lực Việt (IRDM), với sự đồng hành của Công ty BOEHRINGER, đã tổ chức thành công chương trình tập huấn **“Thấu hiểu con người – Kiến tạo môi trường”**.
Suốt 3 ngày tập huấn, hơn 30 cán bộ quản lý và nhân viên y tế của Bệnh viện đã cùng nhau trải nghiệm, học hỏi và ứng dụng những giá trị cốt lõi nhằm nâng cao trí tuệ cảm xúc, tăng cường tinh thần hợp tác, đồng thời kiến tạo một môi trường làm việc tích cực, bền vững.
Chương trình cũng vinh dự có sự chia sẻ đầy cảm hứng của ThS. DS. Trần Lê Diễm Anh – Viện trưởng IRDM, cùng sự đồng hành chuyên môn của ThS. Nguyễn Thị Bích Hà và các giảng viên, trợ giảng tâm huyết.
Bên cạnh đó, sự hỗ trợ quý báu từ Công ty BOEHRINGER không chỉ góp phần vào thành công của chương trình mà còn thể hiện cam kết đồng hành cùng ngành y tế Việt Nam trong hành trình phát triển bền vững.
Ban Tổ chức trân trọng gửi lời cảm ơn đến toàn thể quý đại biểu, các thầy cô giảng viên, học viên đã nhiệt tình tham gia, đóng góp và lan tỏa tinh thần tích cực trong suốt khóa học.
Chương trình **“Thấu hiểu con người – Kiến tạo môi trường”** đã khép lại với nhiều dư âm tốt đẹp, để lại những giá trị bền vững, tiếp thêm động lực cho tập thể cán bộ nhân viên Bệnh viện Nguyễn Tri Phương trong công tác chăm sóc và bảo vệ sức khỏe cộng đồng.

## Chương trình “Bữa cơm Công đoàn - Lan tỏa yêu thương” năm 2025

Trưa ngày 27/8/2025,Công đoàn Bệnh viện Nguyễn Tri Phương tổ chức chương trình “Bữa cơm Công đoàn - Lan tỏa yêu thương” năm 2025 nhằm thể hiện sự quan tâm, chăm lo đến đoàn viên, người lao động, đồng thời chào mừng Kỷ niệm 96 năm Ngày thành lập Công đoàn Việt Nam (28/7/1929 – 28/7/2025)
_Đồng chí_ _Lương Công Minh_ _, Chủ tịch Công đoàn_ _cùng Ban chấp_ _Công đoàn_ _Bệnh viện Nguyễn Tri Phương_ _tham dự_ _chương trình “Bữa cơm Công đoàn – Lan tỏa yêu thương” năm 2025_
_Ban chấp_ _Công đoàn_ _Bệnh viện Nguyễn Tri Phương_ _thăm hỏi, động viên đoàn viên, người lao động tại chương_ _t_ __rình_ “Bữa cơm Công đoàn - Lan tỏa yêu thương” __Bệnh viện Nguyễn Tri Phương_
Đây là một hoạt động thiết thực, hiệu quả, nhằm tiếp tục khẳng định vai trò, trách nhiệm của tổ chức công đoàn trong công tác chăm lo và chăm lo tốt hơn cho đoàn viên, người lao động. “ Bữa cơm công đoàn - Lan tỏa yêu thương” được tổ chức ngon hơn thường ngày, bảo đảm đầy đủ chất lượng dinh dưỡng, an toàn vệ sinh thực phẩm được đoàn viên, người lao động tin dùng trong không khí vui tươi đoàn kết và ấm áp nghĩa tình, từ đó tăng cường sự đoàn kết, thấu hiểu, tạo không khí thân tình giữa người lao động, tổ chức công đoàn và lãnh đạo Bệnh viện. Thể hiện vai trò chăm lo thiết thực của tổ chức công đoàn, xây dựng hình ảnh đẹp về sự đồng hành, sẻ chia và trách nhiệm xã hội.

## Bệnh viện Nguyễn Tri Phương: Kỷ niệm 70 năm Ngày Thầy thuốc Việt Nam

Ngày 27/2, Bệnh viện Nguyễn Tri Phương đã tổ chức lễ kỷ niệm 70 năm Ngày Thầy thuốc Việt Nam (27/2/1955 - 27/2/2025), bày tỏ sự trân trọng, tri ân và tôn vinh những người Thầy thuốc đã có những đóng góp to lớn đối với sự nghiệp bảo vệ, chăm sóc, nâng cao sức khỏe của nhân dân.
BS.CKII Võ Đức Chiến, Giám đốc Bệnh viện Nguyễn Tri Phương, nhấn mạnh: “ _70 năm qua, thấm nhuần lời dạy sâu sắc của Chủ tịch Hồ Chí Minh, các thế hệ cán bộ, bác sĩ, nhân viên y tế đã luôn nỗ lực, phấn đấu không ngừng, vượt qua nhiều gian khó, hết lòng, hết sức cho sứ mệnh cao quý "chữa bệnh, cứu người"; là lực lượng nòng cốt, chủ lực trong thực hiện nhiệm vụ chăm sóc, bảo vệ, nâng cao sức khỏe nhân dân. Trong đó, nhiều tên tuổi y, bác sĩ đã trở thành biểu tượng sáng ngời về y đức, sự dấn thân, dám nghĩ, dám làm, vì dân, vì nước, hết lòng vì người bệnh và là tấm gương nghiên cứu, đổi mới và sáng tạo_. _Nhiều thành tựu y khoa chuyên ngành đã trở thành niềm tự hào của y khoa Việt Nam được ghi nhận trên bản đồ y khoa thế giới, mở ra triển vọng tốt đẹp trên con đường chinh phục các thách thức, giới hạn trong điều trị những bệnh hiểm nghèo, hiếm gặp”._
Bệnh viện Nguyễn Tri Phương, với hơn 120 năm xây dựng, hình thành và phát triển, đã đạt được nhiều thành tựu quan trọng được Đảng, Nhà nước ghi nhận, biểu dương bằng nhiều danh hiệu thi đua, hình thức khen thưởng. Thành công này có được là nhờ sự đóng góp của nhiều thế hệ Thầy thuốc, nhân viên y tế, bao gồm cả những cá nhân không trực tiếp tham gia công tác khám, chữa bệnh nhưng đã đóng góp trí tuệ, công sức trong nhiều công việc, hoạt động khác nhau với mục tiêu chung là đảm bảo hoàn thành xuất sắc nhiệm vụ mà Đảng, Nhà nước giao phó là bảo vệ, chăm sóc và nâng cao sức khỏe nhân dân. 
Đặc biệt, trong bối cảnh đại dịch COVID-19 tấn công vào mọi quốc gia, mọi thành trì y tế, đội ngũ y tế Việt Nam nói chung, Bệnh viện Nguyễn Tri Phương nói riêng đã nỗ lực vượt qua nhiều khó khăn, gian khổ, chịu đựng nhiều mất mát, hy sinh để cùng toàn dân làm tốt nhiệm vụ phòng, chống dịch bệnh.
Thay mặt Đảng ủy, Ban Giám đốc Bệnh viện, BS.CKII Võ Đức Chiến đã biểu dương những nỗ lực, cống hiến to lớn của đội ngũ y, bác sĩ, nhân viên y tế Bệnh viện Nguyễn Tri Phương suốt thời gian qua.
Nhân dịp Kỷ niệm 70 năm ngày Thầy thuốc Việt Nam, ông đã gửi lời chúc đến các Thầy thuốc, viên chức và người lao động Bệnh viện Nguyễn Tri Phương cùng gia đình dồi dào sức khỏe, hạnh phúc và thành công trong sự nghiệp cao quý của mình, xứng đáng với kỳ vọng "Thầy thuốc như mẹ hiền" mà xã hội mong chờ, tin tưởng.
Cũng trong dịp này, Bệnh viện Nguyễn Tri Phương long trọng tiệp nhận Kỷ niệm chương của Bộ Y tế và Bằng khen của Ủy ban nhân dân TP.HCM đối với các cá nhân thuộc Bệnh viện về những đóng góp, cống hiến cũng như những thành tích xuất sắc trong thực hiện nhiệm vụ.
Thay mặt lãnh đạo bệnh viện, BS.CKII Võ Đức Chiến nhấn mạnh: _“Chúng ta không quên những thách thức, gian khó ở phía trước để cùng dặn nhau rằng: Hành trình trị bệnh cứu người, chăm sóc sức khỏe nhân dân là một hành trình không có điểm dừng, những gian khổ và vất vả của nghề Y chưa bao giờ hết, đòi hỏi mỗi y, bác sĩ, nhân viên y tế phải luôn khắc ghi lời thề Hyppocrates, kiên tâm, nỗ lực cố gắng nhiều hơn nữa về mọi mặt, kiến thức phải đầy đủ, đức hạnh phải trọn vẹn, tâm hồn phải rộng lớn, hành vi phải thận trọng như danh y Hải Thượng Lãn Ông Lê Hữu Trác từng chỉ dạy và như lời căn dặn của Bác Hồ - Lương y phải như từ mẫu”._
Theo đó, thực hiện lời dạy Chủ tịch Hồ Chí Minh dành cho Ngành Y tế cũng như tiếp tục phấn đấu thực hiện xuất sắc các nhiệm vụ mà lãnh đạo Đảng, Nhà nước và Nhân dân tin tưởng giao phó, tôi tin tưởng rằng đội ngũ nhân viên y tế Bệnh viện Nguyễn Tri Phương sẽ luôn đoàn kết và sáng tạo, chung tay vì sự nghiệp chăm sóc, bảo vệ và nâng cao sức khỏe nhân dân, tiếp tục viết nên những câu chuyện nhân văn và cảm động, tiếp tục là nguồn cảm hứng lớn lao, mang đến niềm tin và hy vọng cho mỗi người, mỗi gia đình vào một cuộc sống khỏe mạnh và tốt đẹp hơn.
Nhân Kỷ niệm 70 năm Ngày Thầy thuốc Việt Nam, Đồng chí Tổng Bí thư Tô Lâm đã đến thăm và làm việc với Bộ Y tế cũng như chúc mừng Ngành Y tế. Tổng Bí thư Tô Lâm nhấn mạnh:_“Tự hào về truyền thống hào hùng của Ngành Y tế Việt Nam. Việc chăm sóc sức khỏe nhân dân của chúng ta đã được kế thừa từ lịch sử của dân tộc, của đất nước. Ngành Y tế tự hào có Lời dạy của Bác Hồ và phải thi đua thực hiện thật tốt những Lời dạy của Bác mà sâu sắc nhất là Lương y như Từ mẫu… Đất nước Việt Nam trường tồn và phát triển được là có sự đóng góp rất quan trọng của công tác chăm sóc sức khỏe nhân dân. Đảng, Nhà nước, Nhân dân tin tưởng giao nhiệm vụ và trách nhiệm này cho ngành Y tế, mong muốn các thế hệ giáo sư, thầy thuốc, bác sĩ, nhân viên y tế hoàn thành tốt sứ mạng cao cả vinh quang này_
**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/)** - Đa khoa Hạng I Thành phố Hồ Chí Minh

## Bệnh viện Nguyễn Tri Phương: Ứng dụng trí tuệ nhân tạo mang lại lợi ích thiết thực cho người bệnh

**An Quý**
Ứng dụng trí tuệ nhân tạo (AI) không chỉ nâng cao chất lượng chẩn đoán, điều trị mà còn đặt nền móng cho sự phát triển y tế thông minh. Với hướng đi này, Bệnh viện Nguyễn Tri Phương tiếp tục khẳng định ứng dụng công nghệ mang lại nhiều lợi ích thiết thực cho người bệnh.
_Ứng dụng AI không chỉ nâng cao chất lượng chẩn đoán mà còn đặt nền móng cho sự phát triển y tế thông minh tại bệnh viện_
**Kiểm soát gây mê bằng trí tuệ nhân tạo**
Bệnh viện Nguyễn Tri Phương đã nghiên cứu ứng dụng trí tuệ nhân tạo kiểm soát gây mê, để xác định chuyển tiếp của các trạng thái gây mê khác nhau của người bệnh liên quan đến phẫu thuật. Theo đó, các bác sĩ gây mê sẽ tối ưu hóa liều lượng thuốc gây mê, nhằm đem lại sự an toàn cho người bệnh trong gây mê và phẫu thuật. 
_“Các giá trị cá nhân hóa có thể thay đổi đối với từng cá thể người bệnh trong nhóm có cùng thông số như tuổi, giới tính, cân nặng, chỉ số BMI và dấu hiệu lâm sàng. Do đó, áp dụng điều này để điều chỉnh lượng thuốc mê sử dụng chính xác, an toàn và hiệu quả hơn cho người bệnh”_ , BS.CKII Võ Đức Chiến, Giám đốc Bệnh viện Nguyễn Tri Phương, cho biết. 
Bên cạnh đó, theo BS.CKII Võ Đức Chiến, Bệnh viện Nguyễn Tri Phương đã chủ động nghiên cứu và phát triển các ứng dụng trí tuệ nhân tạo (AI) nhằm nâng cao độ chính xác trong chẩn đoán và hỗ trợ bác sĩ trong lâm sàng. Một trong những thành tựu nổi bật là FSpineNet - mô hình AI do chính bệnh viện phát triển và huấn luyện, thay vì sử dụng các giải pháp thương mại có sẵn. 
“Mô hình này được xây dựng dựa trên dữ liệu X-quang thực tế của bệnh nhân tại bệnh viện, đảm bảo khả năng nhận diện tổn thương phù hợp với đặc điểm bệnh lý trong nước. Đặc biệt, hệ thống này hỗ trợ bác sĩ tiết kiệm thời gian đọc phim, giảm tải công việc và cung cấp một công cụ tham khảo tin cậy trong quyết định lâm sàng”, Lãnh đạo Bệnh viện cho biết. 
_Bệnh viện Nguyễn Tri Phương tiếp tục khẳng định vai trò trong việc ứng dụng công nghệ để mang lại lợi ích thiết thực cho người bệnh_
**Tích hợp công cụ AI hỗ trợ chẩn đoán X-quang phổi**
Ngoài ra, Bệnh viện Nguyễn Tri Phương bước đầu đã nghiên cứu sử dụng tích hợp công cụ AI hỗ trợ chẩn đoán X-quang phổi vào hệ thống PACS. PACS là hệ thống lưu trữ và truyền hình ảnh y khoa kỹ thuật số. Các phim Xquang, CTscan, MRI sẽ được lưu trên hệ thống PACS thay vì in phim ra. Các bác sĩ thay vì đọc phim thông thường, BS sẽ có thể đọc trên máy tính hoặc các thiết bị điện tử thông minh. AI được tích hợp vào PACS nên khi bác sĩ đọc 1 phim X-quang phổi, AI sẽ hỗ trợ đọc và gợi ý. 
Thay vì tốn nhiều thời gian cho các thao tác với các phần mềm xử lý ảnh để phát hiện các dấu hiệu bệnh lý và đưa ra các chẩn đoán kèm báo cáo mô tả nhập liệu thủ công, các bác sĩ chỉ cần nhấn nút chức năng AI. Các công cụ trên ứng dụng sẽ tự động thực hiện phân đoạn tim và phổi, xác định nổi bật các vùng bệnh lý trực quan ngay trên hình ảnh X-quang phổi và phân loại nhiều bệnh lý thường gặp (như các bệnh viêm phổi, nốt phổi, mờ phổi, xơ phổi, tràn dịch màng phổi, sự thâm nhiễm phổi, đông đặc phổi, tim to...) kèm hiển thị thông tin chi tiết các kết quả dự đoán. 
Do được nghiên cứu tích hợp trực tiếp trên hệ thống PACS đang vận hành tại bệnh viện nên giải pháp AI không làm thay đổi đáng kể quy trình hoạt động của các bác sĩ bao gồm các bước thăm khám và ra chỉ định cận lâm sàng cần thiết. 
_Bệnh viện Nguyễn Tri Phương bước đầu đã nghiên cứu sử dụng tích hợp công cụ trí tuệ nhân tạo (AI) hỗ trợ chẩn đoán X-quang phổi vào hệ thống PACS - hệ thống lưu trữ và truyền hình ảnh y khoa kỹ thuật số._
Ngoài ra, công cụ AI còn hỗ trợ liệt kê các biểu mẫu và thông tin lâm sàng hữu ích liên quan đến bệnh lý chẩn đoán. Điều này giúp các bác sĩ tổng hợp và đưa ra kết luận chẩn đoán điều trị một cách nhanh chóng, chính xác và chuẩn hóa. Mặt khác, công cụ AI có thể sử dụng cho các trường hợp dán nhãn dữ liệu, sàng lọc và hậu kiểm kết quả chẩn đoán cũng như đưa ra các cảnh báo cần lưu ý. Đặc biệt, công cụ AI này có khả năng nghiên cứu phát triển mở rộng cho các thể loại hình ảnh X-quang khác hoặc các phương thức chụp ảnh khác như CT hoặc MRI.
Bệnh viện Nguyễn Tri Phương cũng đang đề xuất nghiên cứu thử nghiệm ứng dụng trí tuệ nhân tạo để xây dựng công cụ hỗ trợ tra cứu ánh xạ từ mô tả, y lệnh của bác sĩ về hệ thống danh pháp thuật ngữ lâm sàng SNOMED CT nhằm mang lại hiệu quả một cách toàn diện cho việc triển khai bệnh án điện tử. 
Thông tin toàn diện và chi tiết về tất cả các chuyên khoa lâm sàng được chuẩn hóa giúp cung cấp dữ liệu có chất lượng tốt cho các hệ thống hỗ trợ ra quyết định lâm sàng và tạo điều kiện cho việc phân tích, kiểm tra và liên thông dữ liệu. Các thông tin thống kê rõ ràng và đầy đủ cũng giúp ích rất nhiều cho việc nghiên cứu về chuyên môn, dự báo dịch bệnh và phân tích kết quả điều trị.
_“Việc ứng dụng AI không chỉ nâng cao chất lượng chẩn đoán mà còn đặt nền móng cho sự phát triển y tế thông minh tại bệnh viện. Với hướng đi này, Bệnh viện Nguyễn Tri Phương tiếp tục khẳng định vai trò trong việc ứng dụng công nghệ để mang lại lợi ích thiết thực cho người bệnh,”_ BS Chiến chia sẻ. 
**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/)** - Đa khoa Hạng I Thành phố Hồ Chí Minh

## Bệnh viện Nguyễn Tri Phương tổ chức Cuộc thi “Nét đẹp Điều dưỡng” kỷ niệm Ngày Quốc tế Điều dưỡng 12/5

Nhằm chào mừng Ngày Quốc tế Điều dưỡng (12/5/1965 – 12/5/2025), đồng thời hưởng ứng thông điệp của Hội đồng Điều dưỡng Quốc tế (ICN): _“Điều dưỡng chúng ta. Tương lai chúng ta. Quan tâm đến điều dưỡng giúp củng cố nền kinh tế”_ , Bệnh viện Nguyễn Tri Phương tổ chức Cuộc thi ảnh “Nét đẹp Điều dưỡng”
**Chủ đề:** Gắn liền với Slogan của bệnh viện _“Năng động – Thân thiện – Phát triển”_
**Đối tượng:** Toàn thể Điều dưỡng, Hộ sinh, Kỹ thuật y đang công tác tại các khoa, phòng thuộc bệnh viện.
**Nội dung ảnh dự thi:** Những khoảnh khắc chân thực, ý nghĩa thể hiện hoạt động chăm sóc người bệnh của cá nhân hoặc tập thể trong bệnh viện.
# **Yêu cầu ảnh:**
  * Mỗi khoa gửi từ 1 – 2 ảnh cá nhân hoặc tập thể.
  * Ảnh chất lượng cao, rõ nét, không chỉnh sửa sai thực tế (chỉ cân chỉnh màu sắc).
  * Kèm lời bình ngắn gọn (không quá 100 ký tự) và thông tin tác giả.
  * Ảnh rửa khổ A4, không ép plastic; đồng thời gửi file ảnh qua email phòng Điều dưỡng.
  * Hình ảnh có sự đồng thuận của nhân vật xuất hiện trong ảnh.


# **Thời gian:**
  * # Nhận ảnh từ: 14/4/2025 đến hết ngày 05/5/2025.
  * Công bố kết quả: Ngày 12/5/2025.


# **Cơ cấu giải thưởng:**
  * 01 giải Nhất: 1.000.000 đồng
  * 01 giải Nhì: 800.000 đồng
  * 01 giải Ba: 600.000 đồng
  * 03 giải Khuyến khích: 400.000 đồng/giải
  * Giải phong trào: 200.000 đồng/khoa tham gia


**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/)** - Đa khoa Hạng I Thành phố Hồ Chí Minh

## HƯỚNG VỀ ĐẠI HỘI ĐẢNG BỘ CÁC CẤP NHIỆM KỲ 2025–2030: NIỀM TIN – TRÁCH NHIỆM – TỰ HÀO DÂN TỘC

Đại hội Đảng bộ các cấp nhiệm kỳ 2025–2030 là sự kiện chính trị trọng đại, mở ra giai đoạn phát triển mới cho đất nước trên con đường hội nhập và phát triển bền vững. Việc tổ chức thành công đại hội là nhiệm vụ quan trọng hàng đầu, thể hiện bản lĩnh, trí tuệ và khát vọng vươn lên của toàn Đảng, toàn dân và toàn quân ta.
**Đây là thời điểm lịch sử mới, kỷ nguyên mới - kỷ nguyên vươn mình của dân tộc Việt Nam!**
Hướng đến Đại hội, tập thể cán bộ, y bác sĩ và nhân viên Bệnh viện Nguyễn Tri Phương đã và đang thể hiện tinh thần trách nhiệm, ý thức chính trị cao, tích cực hưởng ứng các phong trào thi đua, nâng cao chất lượng chuyên môn, đạo đức nghề nghiệp, gắn bó phục vụ nhân dân với tất cả trái tim và nhiệt huyết. Những hoạt động thiết thực này không chỉ thể hiện sự hưởng ứng sôi nổi, mà còn là minh chứng sống động cho lòng tin vững chắc vào sự lãnh đạo của Đảng và kỳ vọng về một nhiệm kỳ đổi mới, phát triển mạnh mẽ.
Chúng ta đặt niềm tin vào tương lai tươi sáng, vào những thay đổi tích cực trong thời gian tới – nơi đất nước sẽ phát triển phồn vinh, đời sống nhân dân ngày càng ấm no, hạnh phúc. Trên tinh thần **“tự chủ, tự tin, tự lực, tự cường, tự hào dân tộc”** , toàn thể cán bộ ngành y nói riêng và nhân dân cả nước nói chung đang cùng nhau vun đắp cho một Việt Nam cường thịnh, trường tồn.
Hãy cùng nhau phát huy truyền thống vẻ vang của dân tộc, hun đúc khát vọng vươn lên, chung sức xây dựng một đất nước hùng cường, nơi mỗi người dân được sống trong hòa bình, hạnh phúc và tự hào là người con đất Việt! 
**Dân tộc cường thịnh, trường tồn – Đất nước phồn vinh, hạnh phúc!**

## Hướng tới Đại hội Đại biểu Đảng bộ Bệnh viện Nguyễn Tri Phương lần thứ X, nhiệm kỳ 2025-2030: Đoàn kết – Đổi mới – Phát triển

Trong không khí thi đua sôi nổi của toàn Đảng, toàn dân hướng tới những sự kiện trọng đại của đất nước, Đảng bộ Bệnh viện Nguyễn Tri Phương đang tích cực chuẩn bị cho Đại hội Đại biểu lần thứ X, nhiệm kỳ 2025-2030. Đại hội dự kiến diễn ra trong hai ngày, phiên trù bị vào ngày 05 tháng 6 năm 2025 và phiên chính thức vào ngày 06 tháng 6 năm 2025, tại Hội trường Lầu 5, Bệnh viện Nguyễn Tri Phương. Đây là sự kiện chính trị có ý nghĩa quan trọng, đánh dấu một bước phát triển mới của Bệnh viện, với sự tham gia của 124 đảng viên chính thức và 06 đảng viên dự bị.
Nhìn lại nhiệm kỳ 2020-2025, một giai đoạn với nhiều khó khăn và thách thức, đặc biệt là ảnh hưởng của đại dịch COVID-19, Đảng bộ và toàn thể cán bộ, đảng viên, viên chức, người lao động Bệnh viện Nguyễn Tri Phương đã phát huy tinh thần đoàn kết, chủ động, sáng tạo, nỗ lực vượt qua mọi khó khăn, thực hiện thắng lợi Nghị quyết Đại hội Đảng bộ lần thứ IX. Chất lượng khám chữa bệnh không ngừng được cải tiến và nâng cao, hướng đến sự hài lòng của người dân, nhiều lĩnh vực đã đạt thành tích cao, hoàn thành tốt nhiệm vụ của một bệnh viện đa khoa hạng 1 chuyên sâu. Công tác phòng chống dịch bệnh, nhất là đại dịch COVID-19, được thực hiện chủ động và quyết liệt, góp phần vào thành công chung của Thành phố. Cơ sở vật chất, trang thiết bị y tế từng bước được đầu tư, nâng cấp, cùng với đó là những bước tiến trong ứng dụng công nghệ thông tin, triển khai bệnh án điện tử. Công tác xây dựng Đảng được chú trọng, năng lực lãnh đạo và sức chiến đấu của tổ chức Đảng và đảng viên được nâng lên.
Đại hội Đảng bộ Bệnh viện Nguyễn Tri Phương lần thứ X, nhiệm kỳ 2025-2030 có nhiệm vụ quan trọng là tổng kết, đánh giá toàn diện kết quả thực hiện Nghị quyết Đại hội lần thứ IX; đề ra phương hướng, mục tiêu, nhiệm vụ và các giải pháp chủ yếu cho nhiệm kỳ mới; đồng thời, bầu Ban Chấp hành Đảng bộ khóa X và Đoàn đại biểu đi dự Đại hội cấp trên. Đây là dịp để mỗi cán bộ, đảng viên phát huy trí tuệ, dân chủ, đóng góp ý kiến tâm huyết vào các văn kiện Đại hội, đặc biệt là các giải pháp nhằm tiếp tục nâng cao chất lượng chăm sóc sức khỏe nhân dân, phát triển các kỹ thuật y tế chuyên sâu, đẩy mạnh chuyển đổi số, xây dựng Đảng bộ Bệnh viện ngày càng trong sạch, vững mạnh. Các chỉ tiêu chủ yếu cho nhiệm kỳ tới bao gồm việc đảm bảo 100% chỉ tiêu kế hoạch nội trú và ngoại trú, duy trì kết quả đánh giá chất lượng bệnh viện ở mức cao, và không ngừng nâng cao đời sống vật chất, tinh thần cho cán bộ viên chức.
Với tinh thần chung sức – đồng lòng, Đại hội lần này là cơ hội để Đảng bộ Bệnh viện Nguyễn Tri Phương tiếp tục khẳng định vai trò hạt nhân lãnh đạo, khơi dậy niềm tự hào, ý chí tự lực, tự cường và khát vọng cống hiến của mỗi cán bộ, đảng viên và người lao động. Thành công của Đại hội sẽ tạo tiền đề vững chắc để Bệnh viện Nguyễn Tri Phương thực hiện thắng lợi các mục tiêu đề ra, xứng đáng là địa chỉ tin cậy trong sự nghiệp bảo vệ, chăm sóc và nâng cao sức khỏe nhân dân, góp phần xây dựng Thành phố Hồ Chí Minh có chất lượng sống tốt, văn minh, hiện đại, nghĩa tình và cùng ngành Y tế Thành phố hướng đến mục tiêu xây dựng Bệnh viện "Năng động – Thân thiện – Phát triển".
Toàn thể cán bộ, đảng viên, viên chức và người lao động Bệnh viện Nguyễn Tri Phương quyết tâm tổ chức thành công Đại hội Đại biểu Đảng bộ Bệnh viện lần thứ X, nhiệm kỳ 2025-2030, mở ra một giai đoạn phát triển mới, với những thành tựu mới, đóng góp vào sự nghiệp chăm sóc sức khỏe nhân dân và sự phát triển chung của Ngành Y tế Thành phố.
**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/)** - Đa khoa Hạng I Thành phố Hồ Chí Minh

## HỘI THI VĂN NGHỆ MỪNG ĐẢNG MỪNG XUÂN ẤT TỴ 2025

Sáng ngày 09/01/2025, Hội thi văn nghệ Mừng Đảng Mừng Xuân Ất Tỵ năm 2025 do Công đoàn Bệnh viện Nguyễn Tri Phương tổ chức đã diễn ra trong không khí tràn đầy hứng khởi và tự hào. Đây là hoạt động thường niên ý nghĩa, nhằm chào mừng 95 năm ngày thành lập Đảng Cộng sản Việt Nam (03/02/1930-03/02/2025) và đón chào mùa xuân mới, đồng thời gắn kết các cán bộ, nhân viên y tế trong toàn bệnh viện.
Hội thi năm nay có sự tham gia của 38 tiết mục đặc sắc, đến từ các khoa, phòng trong bệnh viện. Các tiết mục đã thể hiện được sự sáng tạo, nhiệt huyết và tài năng của đội ngũ y bác sĩ, nhân viên y tế – những con người không chỉ giỏi chuyên môn mà còn giàu tình yêu nghệ thuật.
Mỗi tiết mục trong hội thi đều mang một thông điệp riêng, góp phần làm nổi bật chủ đề **"Mừng Đảng – Mừng Xuân"**. Nhiều tiết mục ca ngợi Đảng, Bác Hồ kính yêu, thể hiện lòng biết ơn sâu sắc đối với sự lãnh đạo của Đảng trong công cuộc xây dựng và phát triển đất nước. Bên cạnh đó, các tiết mục mừng xuân lại tràn đầy sức sống, đem đến không khí vui tươi, phấn khởi của những ngày đầu năm mới.
_Ảnh 1.Các tiết mục văn nghệ đặc sắc từ các Tổ công đoàn cống hiến tại hội diễn_
Hội thi năm nay đã ghi nhận sự phong phú về thể loại biểu diễn, từ đơn ca, song ca, tốp ca đến múa và cả những tiết mục thời trang sáng tạo. Đặc biệt, các tiết mục múa dân gian và hòa tấu nhạc cụ truyền thống đã để lại ấn tượng sâu sắc, mang đậm màu sắc văn hóa dân tộc. Một số tiết mục kết hợp giữa hiện đại và truyền thống cũng đã tạo nên sự mới mẻ, độc đáo, thu hút sự cổ vũ nhiệt tình từ khán giả.
_Ảnh 2.Các cổ động viên cổ động rất tích cực cho các đội dự thi_
Mỗi khoa, phòng tham gia không chỉ mang đến những tiết mục đặc sắc mà còn thể hiện sự đoàn kết, nỗ lực tập luyện trong thời gian dài. Nhiều tiết mục được đầu tư kỹ lưỡng về trang phục, đạo cụ và cách dàn dựng, thể hiện tinh thần quyết tâm cống hiến những màn trình diễn ấn tượng nhất.
Các tiết mục đạt giải thưởng cao trong hội thi:
**1. Thể loại tốp ca**
  * Giải nhất: Khoa Nội tiêu hóa
  * Giải nhì: Khoa Phụ sản
  * Giải ba: Phối hợp P.CNTT-KHTH-HCQT-CĐT và Phối hợp P.VTTBYT-TCCB-ĐD-GPB


**2. Thể loại đơn ca**
_**a. Đơn ca nam**_
  * Giải nhất: Khoa Nội tổng hợp
  * Giải nhì: Khoa Phụ sản
  * Giải ba: Khoa Tim mạch can thiệp


_**b. Đơn ca nữ**_
  * Giải nhất: Khoa Mắt
  * Giải nhì: Phòng Kế hoạch tổng hợp
  * Giải ba: Khoa Kiểm soát nhiễm khuẩn


**3. Thể loại song ca, tam ca**
  * Giải nhất: Khoa Chẩn đoán hình ảnh
  * Giải nhì: Khoa Phụ sản
  * Giải ba: Khoa Nhi


**4. Thể loại múa**
  * Giải nhất: Khoa Phụ sản
  * Giải nhì: Khoa Thận Lọc máu
  * Giải ba: Khoa Ngoại Thần kinh


**5. Thể loại diễn thời trang**
  * Giải nhất: Phối hợp P.TCCB-VTTBYT-GPB-QLCL
  * Giải nhì: Khoa Ngoại tiêu hóa
  * Giải ba: Khoa HSTC&CĐ


_Ảnh 3: Hình ảnh các Khoa Phòng nhận giải thưởng_
Hội thi không chỉ là sân chơi nghệ thuật mà còn là dịp để các cán bộ, nhân viên bệnh viện giao lưu, thắt chặt tình cảm và cùng nhìn lại một năm với nhiều cố gắng trong công tác. Đồng thời, chương trình cũng là lời tri ân sâu sắc gửi đến toàn thể đội ngũ y tế, những người đã không ngừng nỗ lực vì sức khỏe cộng đồng.
**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/)** - Đa khoa Hạng I Thành phố Hồ Chí Minh

## Chỉ tiêu nhiệm kỳ 2025-2030 do Đại hội Đảng bộ Bệnh viện Nguyễn Tri Phương lần X đề ra

**Thực hiện nhiệm vụ chính trị**
**Công tác xây dựng Đảng**

## BỆNH VIỆN NGUYỄN TRI PHƯƠNG TỔ CHỨC THÀNH CÔNG ĐẠI HỘI ĐẢNG BỘ LẦN THỨ X, NHIỆM KỲ 2025 – 2030

**Ngày 06/6/2025, tại Hội trường A** – Bệnh viện Nguyễn Tri Phương, Đại hội Đảng bộ Bệnh viện lần thứ X, nhiệm kỳ 2025 – 2030 đã được tổ chức trang trọng, nghiêm túc và thành công tốt đẹp.
Đại hội vinh dự đón tiếp đồng chí Nguyễn Hoài Nam – Phó Bí thư Đảng ủy cơ quan Sở Y tế, Phó Giám đốc Sở Y tế TP.HCM; đồng chí Phạm Nam Vĩnh An – Ủy viên Ban Thường vụ Quận ủy, Trưởng Ban Tổ chức Quận ủy Quận 5 cùng nhiều đại biểu đại diện các cơ quan, đơn vị,và toàn thể đảng viên trong Đảng bộ.
Tại Đại hội, các đại biểu đã được nghe và thảo luận các văn kiện quan trọng như: Báo cáo tổng kết công tác nhiệm kỳ 2020 – 2025, phương hướng – nhiệm vụ nhiệm kỳ 2025 – 2030, báo cáo kiểm điểm của Ban Chấp hành, báo cáo thẩm tra tư cách đại biểu, các ý kiến đóng góp cho dự thảo văn kiện Đại hội Đảng các cấp, và biểu quyết các chỉ tiêu trọng tâm nhiệm kỳ tới. Với phương châm "Dân chủ - Đoàn kết - Trí tuệ - Đổi mới", Đại hội đã tập trung thảo luận và đánh giá khách quan, toàn diện những kết quả đạt được trong việc thực hiện Nghị quyết Đại hội Đảng bộ nhiệm kỳ 2020 - 2025. Đồng thời, Đại hội đã nghiêm túc chỉ ra những hạn chế, tồn tại, rút ra các bài học kinh nghiệm sâu sắc; trên cơ sở đó, đề ra phương hướng, mục tiêu và các giải pháp đột phá cho nhiệm kỳ 2025 - 2030. Các báo cáo trình tại Đại hội, đặc biệt là ý kiến chỉ đạo của các đồng chí lãnh đạo cấp trên, đã được toàn thể đại biểu tiếp thu nghiêm túc và coi đây là kim chỉ nam cho các hoạt động trong thời gian tới.
Đại hội đã tiến hành bầu cử dân chủ, đúng quy định để lựa chọn ra Ban Chấp hành Đảng bộ Bệnh viện nhiệm kỳ 2025 – 2030 gồm 07 đồng chí có đủ phẩm chất, năng lực và uy tín. Ban Chấp hành mới đã họp phiên đầu tiên, bầu đồng chí Võ Đức Chiến giữ chức vụ Bí thư Đảng ủy; các vị trí Phó Bí thư, Ủy ban Kiểm tra và các chức danh chủ chốt khác cũng được kiện toàn đầy đủ.
Phát biểu bế mạc Đại hội, đồng chí Võ Đức Chiến nhấn mạnh: "Đại hội lần thứ X là dấu mốc quan trọng, thể hiện tinh thần đoàn kết, trí tuệ và trách nhiệm của toàn thể đảng viên trong Đảng bộ Bệnh viện. Nghị quyết Đại hội sẽ là kim chỉ nam cho sự phát triển vững mạnh, toàn diện, hướng tới nâng cao chất lượng khám chữa bệnh và chăm lo tốt đời sống tinh thần, vật chất cho viên chức, người lao động trong nhiệm kỳ mới."
Thành công của Đại hội là kết quả của quá trình chuẩn bị công phu, nghiêm túc và sự tham gia tích cực, đầy trách nhiệm của toàn thể cán bộ, đảng viên. Đây là nền tảng quan trọng để Đảng bộ Bệnh viện Nguyễn Tri Phương tiếp tục phát huy truyền thống đoàn kết, đổi mới, sáng tạo và hoàn thành xuất sắc các nhiệm vụ chính trị trong giai đoạn mới.

## Tổ chức tốt Đại hội Đảng bộ các cấp nhiệm kỳ 2025-2030 (Bài viết của Tổng Bí thư Tô Lâm)

**Đại hội đảng bộ các cấp nhiệm kỳ 2025 - 2030** có ý nghĩa đặc biệt quan trọng. Đây không chỉ là đợt sinh hoạt chính trị to lớn, sâu rộng trong toàn Đảng, toàn dân mà còn là tiền đề để tổ chức thành công Đại hội đại biểu toàn quốc lần thứ XIV của Đảng. Cao hơn, chuỗi sự kiện này là một trong những yếu tố then chốt tạo nền tảng chính trị vững chắc đưa đất nước vững bước tiến vào kỷ nguyên mới, kỷ nguyên phát triển, giàu mạnh, phồn vinh, thịnh vượng, sánh vai với các cường quốc năm châu như tâm nguyện của Chủ tịch Hồ Chí Minh muôn vàn kính yêu và ước vọng của toàn dân tộc.
Thực tiễn cách mạng Việt Nam cho thấy, Đại hội đảng bộ các cấp có vai trò dẫn dắt, định hướng, trụ cột, có tầm ảnh hưởng sâu rộng trong toàn Đảng và toàn xã hội. Đại hội Đảng bộ các cấp nhiệm kỳ này có 03 nhiệm vụ trọng tâm, đó là: thảo luận, thông qua Văn kiện đại hội cấp mình và góp ý với dự thảo Văn kiện Đại hội cấp trên, Văn kiện Đại hội XIV của Đảng; lựa chọn nhân sự tham gia cấp ủy các cấp; hoàn thiện nhân sự trong hệ thống cơ quan lãnh đạo của Đảng từ cấp cơ sở đến cấp Trung ương. Những nội dung trên đều là vấn đề “cốt tử”, hệ trọng, liên quan đến vai trò lãnh đạo, cầm quyền, sức chiến đấu của Đảng; đến việc hoạch định chủ trương, đường lối, chính sách, biện pháp lãnh đạo; quyết định sức mạnh nội bộ Đảng và hệ thống chính trị; đến toàn bộ hoạt động lãnh đạo của tổ chức đảng các cấp trong nhiệm kỳ tới cũng như sức mạnh của toàn dân tộc trong tương lai.
Đảng ta là đảng cầm quyền, Đảng lãnh đạo bằng đường lối. Văn kiện Đại hội các cấp là sự cụ thể hóa quan điểm, định hướng chỉ đạo của Đảng thành hệ thống những giải pháp có sức sống từ thực tiễn ngành, địa phương, cơ quan đơn vị, địa bàn, lĩnh vực được phân công nhiệm vụ; có giá trị định hướng sự lãnh đạo, dẫn đường, khắc phục triệt để tồn tại, bất cập, tranh thủ tối đa thời cơ, thuận lợi, tháo gỡ triệt để điểm nghẽn, rào cản, huy động tối đa sự tham gia của cán bộ, đảng viên và nhân dân, tạo sức mạnh to lớn để đạt và vượt mục tiêu đã định, góp phần hoàn thành thắng lợi những mục tiêu, chỉ tiêu, kế hoạch mà Trung ương hoặc đảng bộ cấp trên đã đề ra. Bảo đảm chất lượng tham gia ý kiến với Văn kiện Đại hội của cấp mình, dự thảo Văn kiện Đại hội cấp trên trực tiếp và Văn kiện Đại hội của cấp trên cũng như dự thảo Văn kiện Đại hội XIV của Đảng, nhất là đề xuất những giải pháp bắt nguồn từ nhịp sống cơ sở, từ hơi thở của đời sống xã hội của từng địa phương, thậm chí từng làng xã, cộng đồng và cá nhân tạo động lực, khí thế, sức lan tỏa mạnh mẽ trong cả nước là mục tiêu mà các cấp ủy cần đạt được.
Nhân sự cấp ủy cũng chính là đội ngũ cán bộ lãnh đạo, quản lý, chủ trì, chủ chốt ở từng bộ, ngành, địa phương, cơ quan, đơn vị; là “cầu nối” giữa Đảng, Nhà nước với Nhân dân, là lực lượng lãnh đạo, hướng dẫn, tổ chức thực hiện, quyết định việc đưa chủ trương, đường lối của Đảng, chính sách, pháp luật Nhà nước đi vào cuộc sống; đồng thời, nắm bắt tình hình đề xuất với Đảng, Nhà nước đề ra chủ trương, chính sách phù hợp nguyện vọng, lợi ích chính đáng của nhân dân. Bí thư, Phó bí thư, cấp ủy viên luôn là nhân tố quan trọng, quyết định kết quả thực hiện nhiệm vụ chính trị, sự ổn định, phát triển, vững mạnh của địa phương, cơ quan, đơn vị cả trước mắt và lâu dài.
Để tổ chức thành công Đại hội đảng bộ các cấp nhiệm kỳ 2025-2030, cấp ủy các cấp cần bám sát nội dung Chỉ thị số 35-CT/TW ngày 14/06/2024 của Bộ Chính trị “về tổ chức Đại hội đảng bộ các cấp tiến tới Đại hội đại biểu toàn quốc lần thứ XIV của Đảng” và kết luận số 118 KL/TW ngày 18/01/2025 của Bộ Chính trị về sửa đổi, bổ sung Chỉ thị 35 nêu trên. Ngoài ra, Ban Tổ chức Trung ương, Ủy Ban Kiểm tra Trung ương, Ban Tuyên giáo và Dân vận Trung ương, Văn phòng Trung ương đến nay đã có 21 văn bản hướng dẫn liên quan đến Tổ chức Đại hội đảng bộ các cấp, các đồng chí coi đó là “sách giáo khoa” để tổ chức triển khai thực hiện.
Trong bối cảnh chúng ta tích cực triển khai Nghị quyết số 18 của Bộ Chính trị về sắp xếp, tinh gọn tổ chức bộ máy các cơ quan, đơn vị trong hệ thống chính trị, các cấp ủy cần nhanh chóng kiện toàn tổ chức, đưa guồng máy vào hoạt động và tiếp tục tinh gọn bộ máy bên trong của từng cơ quan, đơn vị, địa phương. Bốn Đảng bộ mới được thành lập là Đảng bộ các cơ quan Đảng Trung ương, Đảng bộ Chính phủ, Đảng bộ Quốc hội, Đảng bộ Mặt trận Tổ quốc, các đoàn thể Trung ương; một số Ban Đảng Trung ương mới được cơ cấu lại; các đảng bộ, chi bộ mới của một số Bộ, các tỉnh, thành phố... căn cứ chức năng, nhiệm vụ, tổ chức bộ máy được qui định sớm ổn định tổ chức và duy trì hoạt động theo đúng Điều lệ Đảng và những qui định mới của Ban Chấp hành Trung ương trong điều hành hoạt động cũng như trong quá trình tổ chức Đại hội đảng bộ, chi bộ.
Để tiến hành tốt Đại hội Đảng bộ các cấp, các cấp ủy cần tập trung vào 03 vấn đề chính sau đây:
**Thứ nhất,** cần thống nhất nhận thức, những thành tựu của đất nước đạt được sau 95 năm dưới sự lãnh đạo của Đảng, đặc biệt sau 40 năm đổi mới là rất vĩ đại, rất đáng trân trọng, tự hào. Nhưng đất nước ta vẫn đang phải đối mặt với nhiều khó khăn, thách thức mà toàn Đảng, toàn Dân, toàn quân ta phải nỗ lực đoàn kết, quyết tâm hơn nữa để vượt qua, trong đó Đại hội đảng bộ các cấp nhiệm kỳ 2025-2030 có trách nhiệm phải tham gia và là lực lượng nòng cốt giải quyết hiệu quả những khó khăn, thách thức này. Nhiều điểm nghẽn, rào cản, nút thắt về thể chế tồn tại lâu năm vẫn chưa được tháo gỡ, loại bỏ. Nguy cơ “giậm chân tại chỗ”, nguy cơ tụt hậu, nhất là tụt hậu về kinh tế, về khoa học, công nghệ và rơi vào “bẫy thu nhập trung bình” còn tiềm tàng. Gần đây, thiên tai, bão lũ và nhiều hậu quả của biến đổi khí hậu, môi trường liên tiếp xảy ra đã để lại những hậu quả nặng nề đối với nhiều địa phương. Tình trạng tham nhũng, lãng phí, tiêu cực chưa được khắc phục triệt để; tình trạng “nói không đi đôi với làm; nói một đằng, làm một nẻo”, “đánh trống bỏ dùi”, “lạc quan tếu”, báo cáo không trung thực, cán bộ thiếu năng lực, thiếu gương mẫu, cục bộ, bè phái... đều là những “miếng mồi” để các thế lực thù địch, phản động lợi dụng tuyên truyền chống phá, để thực hiện âm mưu “diễn biến hòa bình”, thúc đẩy “tự diễn biến”, “tự chuyển hóa” trong nội bộ nhằm làm suy giảm lòng tin của nhân dân với Đảng, Nhà nước, Chế độ ta. Những nguy cơ, thách thức này đe dọa trực tiếp đến quá trình thực hiện các mục tiêu chiến lược 100 năm dưới sự lãnh đạo của Đảng, 100 năm thành lập nước, đến giữa thế kỷ XXI, nước ta trở thành nước phát triển, có thu nhập cao. Định vị chính xác “nguy và cơ”, đặt rõ mục tiêu vươn tới để thống nhất cao về quyết tâm chính trị, với những bước đi, hành động đúng, trúng, quyết liệt để giải quyết hiệu quả những khó khăn, vướng mắc, khắc phục triệt để điểm nghẽn, rào cản, khơi thông mọi nguồn lực, phát huy tối đa tiềm năng, lợi thế từng ngành, lĩnh vực, địa phương.
**Thứ hai,** về xây dựng Văn kiện và tham gia ý kiến vào Văn kiện đại hội cấp trên, Văn kiện Đại hội XIV của Đảng. Báo cáo chính trị trình Đại hội Đảng bộ các cấp cần bám sát tinh thần dự thảo các Văn kiện trình Đại hội XIV; tập trung phân tích, đánh giá khách quan việc thực hiện nghị quyết đại hội vừa qua; phản ánh đầy đủ, sát thực tình hình và thực tiễn phát triển của các địa phương, ngành, lĩnh vực, cơ quan, đơn vị. Làm rõ những thành tựu đổi mới, nổi bật trong sự lãnh đạo, chỉ đạo của tổ chức đảng; trên tinh thần nhìn thẳng sự thật, đánh giá đúng sự thật, nói rõ sự thật, cần thẳng thắn chỉ ra những hạn chế, yếu kém, khuyết điểm còn tồn tại, nhất là những điểm nghẽn, nút thắt đối với sự phát triển chưa được tháo gỡ, khắc phục. Phân tích sâu sắc nguyên nhân của thành tựu và hạn chế, nhất là về đường lối, chủ trương, biện pháp, giải pháp tại đơn vị, địa phương; về khâu tổ chức thực hiện; về tính chất quyết định của nhân tố con người và công tác cán bộ; về sự tham gia, đồng thuận, ủng hộ của nhân dân. Chú trọng tổng kết những mô hình mới, cách làm hay, rút ra những bài học kinh nghiệm có giá trị phục vụ phát triển. Chủ động nghiên cứu, nắm bắt, dự báo sát tình hình; phân tích thấu đáo những vấn đề nổi lên đang tác động trực tiếp đến các ngành, các cấp, các địa phương, các cơ quan, đơn vị; xác định rõ tiềm năng, lợi thế phát triển, với phương châm “Tầm nhìn quốc gia, hành động địa phương, đồng hành của doanh nghiệp, trách nhiệm của người dân”, đề ra các định hướng, các nhiệm vụ trọng tâm, các khâu đột phá, đối sách phù hợp; tất cả vì sự phát triển kinh tế, văn hóa xã hội của đất nước với mục tiêu cuối cùng là nâng cao đời sống vật chất, tinh thần và hạnh phúc của nhân dân.
Báo cáo kiểm điểm sự lãnh đạo, chỉ đạo của cấp ủy cần được xây dựng thống nhất với Báo cáo chính trị. Không để xảy ra tình trạng sao chép, rập khuôn báo cáo một cách máy móc hoặc kiểm điểm qua loa, đại khái, hình thức cho có. Việc kiểm điểm cấp ủy cần bám sát quy chế làm việc, chương trình hành động, kết quả lãnh đạo tổ chức thực hiện nghị quyết của đảng bộ, chi bộ, sự chỉ đạo của cấp ủy cấp trên và tình hình cụ thể của địa phương, cơ quan, đơn vị; kết quả thực hiện các nghị quyết, kết luận Hội nghị Trung ương 4 khóa XI, XII, XIII gắn với việc học tập và làm theo tư tưởng, đạo đức, phong cách Hồ Chí Minh; Quy định những điều đảng viên không được làm; Quy định nêu gương của cán bộ, đảng viên, nhất là người đứng đầu. Lấy kết quả đầu ra cụ thể của công tác lãnh đạo, chỉ đạo và việc thực hiện nhiệm vụ chính trị cùng với sự hài lòng của quần chúng, nhân dân làm tiêu chí đánh giá. Cần thẳng thắn, khách quan chỉ ra những hạn chế, thiếu sót, mức độ khắc phục, sửa chữa những khuyết điểm, yếu kém đã được phát hiện, trên tinh thần tự phê bình và phê bình, không nể nang, né tránh. Nhận diện, làm rõ những nguyên nhân, nhất là nguyên nhân chủ quan, để từ đó rút kinh nghiệm, đề ra kế hoạch, lộ trình, biện pháp hiệu quả nhằm sửa chữa, khắc phục trong nhiệm kỳ 2025 - 2030. Báo cáo kiểm điểm cần gắn trách nhiệm của tập thể với trách nhiệm cá nhân, nhất là người đứng đầu, người được phân công phụ trách các lĩnh vực, địa bàn; coi đây là cơ sở quan trọng để đánh giá cấp ủy viên trong nhiệm kỳ và giới thiệu nhân sự cho khóa mới. Cần nhận thức rõ, việc thực hiện kiểm điểm là cơ hội để tăng cường hiểu biết lẫn nhau, đoàn kết, thống nhất, giúp xây dựng môi trường làm việc tốt hơn. Tuyệt đối không được lợi dụng việc kiểm điểm để đấu đá nội bộ, tìm cách triệt hạ, làm mất uy tín của cán bộ, đảng viên.
Thảo luận, đóng góp ý kiến vào dự thảo các văn kiện Đại hội XIV của Đảng và văn kiện đại hội đảng bộ cấp trên trực tiếp theo hướng thực chất, hiệu quả, có trọng tâm, trọng điểm, tránh góp ý theo kiểu hình thức. Căn cứ điều kiện cụ thể của tổ chức đảng và đại hội để định hướng, gợi mở những nội dung cốt lõi, những vấn đề mới, những vấn đề có nhiều phương án cho thảo luận; lựa chọn hình thức trao đổi, góp ý cho phù hợp, từ đó tiếp nhận, tiếp thu được nhiều ý kiến tâm huyết, có chất lượng. Trong quá trình thảo luận, bàn bạc, cần hết sức cầu thị, lắng nghe, tôn trọng ý kiến lẫn nhau, nhất là đối với những vấn đề mới, vấn đề khó, đồng thời kiên định những vấn đề có tính nguyên tắc, không được phép ngả nghiêng, dao động; luôn tỉnh táo, cảnh giác với mọi âm mưu lợi dụng việc góp ý để xuyên tạc, chống phá.
**Thứ Ba,** đặc biệt chú trọng chuẩn bị nhân sự Đại hội. Cần ý thức sâu sắc, chuẩn bị nhân sự không chỉ cho một kỳ đại hội; xa hơn, đó là sự chuẩn bị nhân sự cho tương lai phát triển của tổ chức đảng, sự phát triển của ngành, lĩnh vực, địa phương, cơ quan, đơn vị; rộng hơn, đó là vận mệnh của Đảng, sự tồn vong của chế độ và sự phát triển của đất nước, của dân tộc. Đây là công việc mà cán bộ, đảng viên và nhân dân quan tâm theo dõi; đây cũng là việc mà các phần tử xấu, cơ hội chính trị tìm mọi cách tác động, tung tin thất thiệt, xuyên tạc hòng chia rẽ nội bộ. Về cơ cấu cấp ủy, phải bảo đảm sự lãnh đạo trực tiếp, toàn diện của cấp ủy đối với những địa bàn, lĩnh vực quan trọng; coi trọng chất lượng, không vì cơ cấu mà hạ thấp tiêu chuẩn; không nhất thiết địa phương, ban, ngành nào cũng phải có người tham gia cấp ủy; cấp ủy viên được lựa chọn phải thật sự là hạt nhân lãnh đạo chính trị, là đại diện cho đội ngũ đảng viên và được quần chúng tin yêu, tín nhiệm; các cấp ủy viên phải xứng tầm là thành viên “bộ tham mưu” chiến đấu và phải đoàn kết, thống nhất cao về ý chí và hành động, thật sự trong sạch, vững vàng, trung kiên. Cần đề cao trách nhiệm của người đứng đầu trong việc đề xuất, giới thiệu nhân sự, nhất là người kế nhiệm theo các quy định mới của Trung ương. Chuẩn bị nhân sự phải kết hợp hài hòa giữa nguồn nhân sự tại chỗ với việc điều động, luân chuyển cán bộ từ nơi khác đến. Đối với các địa phương, đơn vị có cơ cấu cấp ủy nhưng chưa chuẩn bị được nhân sự tại chỗ, thì cấp ủy cấp trên trực tiếp xem xét, điều động nhân sự từ nơi khác có đủ tiêu chuẩn, điều kiện, đáp ứng yêu cầu nhiệm vụ chính trị của địa phương, đơn vị để giới thiệu, chỉ định tham gia cấp ủy hoặc bổ sung sau đại hội. Phấn đấu đạt tỉ lệ cấp ủy viên nữ từ 15% trở lên và có cán bộ nữ trong ban thường vụ; phấn đấu tỉ lệ cán bộ trẻ từ 10% trở lên, tỉ lệ cấp ủy viên là người dân tộc thiểu số bảo đảm phù hợp với đặc điểm, cơ cấu dân tộc và điều kiện cụ thể từng địa phương, cơ quan, đơn vị.
Bên cạnh thực hiện đúng Điều lệ Đảng và các qui định hiện hành, công tác nhân sự của các cấp ủy Đảng phải được tiến hành bài bản, khoa học, nhân văn. Phải chuẩn bị kỹ càng cả nhân sự cấp ủy và đại biểu đi dự đại hội đảng bộ cấp trên. Việc giới thiệu, lựa chọn nhân sự phải bảo đảm tiêu chuẩn, điều kiện; dựa trên cơ sở quy hoạch, quy chế, quy định, bảo đảm dân chủ, công khai, minh bạch; dựa trên phẩm chất chính trị, đạo đức, lối sống, trình độ chuyên môn, uy tín, sản phẩm và hiệu quả công tác cụ thể; tuyệt đối không lựa chọn cán bộ không được quần chúng nhân dân tín nhiệm, cũng không giới thiệu những cán bộ lãnh đạo “dĩ hòa vi quý”, “tròn vo” để lấy phiếu bầu. Nhân sự tham gia cấp ủy, các nhân sự được lựa chọn đi dự đại hội cấp trên phải là tinh hoa của Đảng, thật sự tiêu biểu về phẩm chất chính trị, bản lĩnh, trí tuệ; có tầm nhìn và tư duy chiến lược; có trách nhiệm cao, có tư duy đổi mới, biết nắm bắt cơ hội, dám nghĩ, dám làm, dám chịu trách nhiệm vì lợi ích chung, không né tránh, trì trệ, thụ động trước những vấn đề mới phát sinh; có năng lực thực tiễn, khả năng lãnh đạo, quản lý; mạnh dạn, sáng tạo trong đóng góp ý kiến, để giúp đại hội đề ra được các quyết sách đúng đắn đáp ứng những yêu cầu mới nặng nề, phức tạp hơn đối với sự nghiệp xây dựng, phát triển đất nước và bảo vệ Tổ quốc. Công tác nhân sự đại hội phải được tiến hành theo một quy trình chặt chẽ, khoa học và nhất quán theo hướng dẫn của Trung ương; tránh cách làm giản đơn, tùy tiện, vô nguyên tắc, cài cắm “quân xanh, quân đỏ” hoặc máy móc, cứng nhắc, xa rời thực tiễn; phải bảo đảm lựa chọn được những người tốt nhất, người xứng đáng nhất, không bỏ sót những người thật sự có đức, có tài, đủ điều kiện, tiêu chuẩn, đồng thời kiên quyết chống các biểu hiện cơ hội, tham vọng quyền lực, vận động cá nhân, phe cánh, lợi ích nhóm, tư tưởng cục bộ, địa phương, thân quen. Cán bộ là cái gốc của mọi vấn đề cho nên trong quá trình lựa chọn nhân sự bên cạnh việc phát hiện đúng- trúng thì cố gắng không bỏ sót nhân tài bởi không tìm chọn, sử dụng nhân tài là sự lãng phí về tài nguyên và tiềm năng con người.
Quá trình chuẩn bị, tổ chức Đại hội, đặc biệt ở các Đảng bộ mới thành lập, kiện toàn, cần giữ vững các nguyên tắc tổ chức và hoạt động của Đảng, nhất là nguyên tắc “tập trung dân chủ”, “đoàn kết thống nhất”, “tự phê bình và phê bình”; quán triệt các nguyên tắc kiên định và đổi mới, kế thừa và phát triển để chuẩn bị thật nghiêm túc, chu đáo, toàn diện các nội dung đại hội, vừa tập trung chuẩn bị cho đại hội, vừa lãnh đạo thực hiện tốt nhiệm vụ chính trị. Tổ chức đại hội theo hướng thiết thực, tiết kiệm, tránh phô trương, lãng phí, bảo đảm trang trọng, ý nghĩa; gắn với đổi mới cách thức xây dựng, ban hành, quán triệt nghị quyết; tăng cường trao quyền và ủy quyền, giảm thiểu các ban bệ và đầu mối trung gian; phát huy sự chủ động, gương mẫu của cán bộ, đảng viên và sự tham gia đóng góp, ủng hộ tích cực của quần chúng nhân dân. Chủ động, tích cực làm tốt công tác tư tưởng, thông tin tuyên truyền để tạo sự thống nhất trong toàn đảng bộ và sự đồng thuận trong tập thể quần chúng, nhân dân; củng cố, nâng cao niềm tin của cán bộ, đảng viên và nhân dân đối với tổ chức cơ sở đảng. Tạo điều kiện và môi trường thật tốt để phát huy trí tuệ và sự tham gia của các tầng lớp nhân dân trong xây dựng các văn kiện và công tác cán bộ, góp phần tích cực, có hiệu quả vào thành công của đại hội, sớm đưa nghị quyết đại hội Đảng đi vào thực tiễn cuộc sống, mang lại cuộc sống ấm no, tự do, hạnh phúc cho mọi người dân.

## Bệnh viện Nguyễn Tri Phương Tỏa Sáng với Giải Ba Cuộc Thi 'Cùng HTV Hành Động Xanh' Năm 2024

Cuộc thi **"Cùng HTV Hành động Xanh"** , do Đài Truyền hình Thành phố Hồ Chí Minh (HTV) tổ chức, là một sân chơi sáng tạo và đầy cảm hứng, mở ra không gian trải nghiệm cho mọi lứa tuổi. Với mục tiêu khơi dậy và kết nối cộng đồng, cuộc thi đã thành công trong việc thúc đẩy và lan tỏa những hành động thiết thực vì một môi trường bền vững. Thông qua các sản phẩm truyền thông đa dạng như phim ngắn, viral clip, MV, phóng sự..., ban tổ chức mong muốn khuyến khích những việc làm đẹp để gìn giữ văn hóa xanh, cổ vũ lối sống yêu thương, chia sẻ, thân thiện với môi trường, đồng thời hướng đến mục tiêu Net Zero và phát triển kinh tế xanh.
Tác phẩm "Bệnh viện Xanh - Hành động Xanh vì sức khỏe cộng đồng" là một sản phẩm video tâm huyết của tập thể Bệnh viện Nguyễn Tri Phương. Với thời lượng cô đọng và hình ảnh chân thực, video đã truyền tải thông điệp về những nỗ lực không ngừng của bệnh viện trong việc xây dựng một môi trường y tế không chỉ hiện đại, chất lượng cao mà còn xanh - sạch - đẹp, an toàn cho người bệnh, thân nhân và cả đội ngũ y bác sĩ. Đó là những hành động cụ thể như tiết kiệm năng lượng, quản lý chất thải y tế hiệu quả, tăng cường không gian xanh, cho đến việc nâng cao ý thức bảo vệ môi trường trong toàn thể cán bộ, nhân viên. Tất cả vì mục tiêu cao cả: chăm sóc và bảo vệ sức khỏe cộng đồng một cách toàn diện và bền vững.
Giải Ba - Bảng B tại một cuộc thi quy mô và ý nghĩa như **"Cùng HTV Hành động Xanh"** là sự ghi nhận quý báu cho những cố gắng của Bệnh viện Nguyễn Tri Phương. Đây không chỉ là niềm vinh dự mà còn là nguồn động lực to lớn để bệnh viện tiếp tục đẩy mạnh hơn nữa các hoạt động "xanh", khẳng định cam kết mạnh mẽ trong việc tiên phong thực hiện các giải pháp thân thiện với môi trường, song hành cùng sứ mệnh chăm sóc sức khỏe nhân dân.
Bệnh viện Nguyễn Tri Phương trân trọng cảm ơn Đài Truyền hình Thành phố Hồ Chí Minh đã tạo ra một sân chơi bổ ích, ý nghĩa. Xin gửi lời tri ân đến tập thể cán bộ, y bác sĩ, nhân viên bệnh viện đã chung tay, góp sức tạo nên tác phẩm dự thi ấn tượng này. Chúng tôi tin rằng, mỗi hành động nhỏ hôm nay sẽ góp phần tạo nên một tương lai xanh hơn, sạch hơn và khỏe mạnh hơn cho tất cả mọi người. Bệnh viện Nguyễn Tri Phương sẽ tiếp tục là một "Bệnh viện Xanh", không ngừng "Hành động Xanh" vì sức khỏe cộng đồng và một tương lai bền vững.
**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/)** - Đa khoa Hạng I Thành phố Hồ Chí Minh

## Đoàn thanh niên BV tổ chức ngày hội thiếu nhi


## Kế hoạch phát động chương trình “Lễ hội áo dài” và “Áo dài - Trao gửi yêu thương” năm 2024

Ngày 01/3/2024, Công đoàn Bệnh viện Nguyễn Tri Phương đã ban hành Kế hoạch phát động chương trình “Lễ hội áo dài” và “Áo dài - Trao gửi yêu thương” năm 2024. 
Đề nghị các Tổ Công đoàn tích cực triển khai thực hiện.
Tải Kế hoạch [tại đây](https://bvnguyentriphuong.com.vn/uploads/112023/files/2024-03-04%2014-57%20%C3%81o%20D%C3%A0i.pdf)
#### Nội dung trong file:



## Đoàn thể, người lao động BV NTP tham gia đóng góp, ủng hộ đồng bào bị thiệt hại do cơn bão số 3- YAGI


## Hoạt động ý nghĩa hướng đến 50 năm chiến thắng Điện Biên Phủ (07/5/1954-07/5/2024)

Được lời mời từ Hội Chữ Thập Đỏ Thành phố Hồ Chí Minh theo lời kêu gọi từ Trung ương Hội Chữ Thập Đỏ Việt Nam, vừa qua Hội Chữ Thập Đỏ Bệnh viện Nguyễn Tri Phương đã thực hiện chuỗi hoạt động tại Điện Biên từ ngày 19/4-22/4/2024, trong đó có thể kể đến:
- Khám bệnh, tặng quà (700 người/điểm khám) tại Xã Tỏa Tình, Huyện Tuần Giáo: Hoạt động này đã diễn ra vào ngày 20/4/2024. Tại đây ngoài hoạt động khám chữa bệnh miễn phí, với sự tham gia của Nhạc viện Thành phồ Hồ Chí Minh, đoàn công tác đã đem theo lời ca tiếng hát tặng cho các đồng bào miền cao. Bên cạnh đó, đoàn công tác còn tặng quà cho bà con tại đây thông qua sự hỗ trợ hết sức ý nghĩa đến từ các mạnh thường quân (VietjetAir, Sinveco, Doctor Aibolit...)
- Dâng hương Đền thờ các anh hùng liệt sĩ tại Chiến trường Điện Biên Phủ ngày 21/4/2024 và tham gia chặng cuối Chiến dịch Triệu bước chân nhân ái 
- Tham gia Lễ phát động Tháng Nhân đạo vào ngày 22/4/2024: Trong khuôn khổ hoạt động này, BV Nguyễn Tri Phương cũng rất tự hào khi nhận được bằng khen từ Trung ương Hội Chữ Thập Đỏ Việt Nam ghi nhận về việc tham gia đóng góp tích cực trong các hoạt động nhân đạo nói chung và Tháng Nhân đạo 2024 nói riêng.
Hành trình đến với Điện Biên đã hun đúc trong lòng các nhân viên y tế thêm lòng yêu nước, thương nòi. Trên chặng đường đi, có những đoạn đường khúc khuỷu quanh co, có những lúc đoàn đã phải cùng nhau xuống xe dọn cây ngã đổ để mở đường, nhưng sự hăng hái và nụ cười luôn là thứ đọng lại để ươm những hạt mầm tích cực trong lòng mỗi thành viên của đoàn sau chuyến công tác.

## Ngày An Toàn Người bệnh Thế Giới 2024: “Chẩn đoán chính xác, điều trị an toàn - Get it right, make it safe”

Ngày An Toàn người bệnh Thế giới là một trong những Ngày sức khỏe cộng đồng quan trọng do Tổ chức Y tế Thế giới (WHO) đề xuất, được tiếp tục phát động sự hưởng ứng trên toàn cầu trong năm 2024. Đại Hội đồng Y tế Thế giới lần thứ 72 năm 2019 đã thông qua Nghị quyết WHA72.6 "Hành động toàn cầu về an toàn người bệnh" và thống nhất chọn Ngày An Toàn Người bệnh Thế Giới là ngày 17 tháng 9 hàng năm. An toàn người bệnh là một vấn đề được quan tâm hàng đầu trong ngành y tế và Ngày An toàn người bệnh là chiến dịch trọng tâm nhằm thúc đẩy các hoạt động cải tiến chất lượng, quản lý rủi ro nguy cơ tại các bệnh viện, tăng cường nhận thức, sự tham gia và sự hiểu biết của cộng đồng trên toàn cầu, với mục tiêu bền vững: **“Trước tiên là không gây nguy hại cho người bệnh - first do no harm for patient”**
Mỗi năm, một chủ đề mới được lựa chọn cho Ngày An Toàn Người bệnh Thế Giới để nhấn mạnh một lĩnh vực an toàn người bệnh cần được ưu tiên hành động tại tất cả các quốc gia thành viên của WHO. Chủ đề của năm 2014 được lựa chọn là**"Nâng cao năng lực chẩn đoán vì sự an toàn của người bệnh" – Improving diagnosis for patient safety** nhấn mạnh sự cần thiết, tầm quan trọng của việc chẩn đoán chính xác, kịp thời trong bảo đảm an toàn người bệnh. 
Chiến dịch toàn cầu năm nay khuyến khích các quốc gia thành viên áp dụng các chiến lược, kế hoạch hành động để giảm thiểu sự cố trong chẩn đoán, thường do nguyên nhân kết hợp giữa nhận thức cá nhân của nhân viên y tế và sự vận hành chung của hệ thống y tế dẫn đến các sự việc như không nhận ra triệu chứng quan trọng trên người bệnh, giải thích và truyền đạt nhầm kết quả chẩn đoán cho người bệnh. Sự cố trong chẩn đoán có thể là việc không giải thích chính xác hoặc giải thích không kịp thời về vấn đề sức khỏe của người bệnh, bao gồm chẩn đoán chậm trễ, chẩn đoán sai, bỏ sót triệu chứng, hoặc người bệnh không được giải thích về chẩn đoán. 
Theo thống kê của WHO, sự cố trong chẩn đoán chiếm gần 16% tổng các các sự cố y khoa có thể ngăn ngừa và hầu hết người trưởng thành đều có khả năng gặp phải ít nhất một sự cố chẩn đoán trong đời, vì vậy cần cấp thiết **Nâng cao năng lực chẩn đoán.**
Thông qua thông điệp **"Chẩn đoán chính xác, điều trị an toàn!" – Get it right, make it safe****,** WHO kêu gọi nỗ lực phối hợp để giảm thiểu sự cố trong chẩn đoán thông qua nhiều biện pháp can thiệp đa dạng từ tư duy hệ thống đến yếu tố con người với sự tham gia tích cực của mọi đối tượng: người bệnh, người nhà, nhân viên y tế và lãnh đạo quản lý ngành y tế. Các can thiệp từ bước khai thác tiền sử người bệnh, khám lâm sàng, quyền truy cập kết quả xét nghiệm chẩn đoán, đến triển khai các đề án đo lường, áp dụng công nghệ thông tin và học hỏi từ các sai sót chẩn đoán đã xảy ra...
**_Mục Tiêu của Ngày An Toàn Người bệnh Thế Giới 2024_**
  1. Nâng cao nhận thức toàn cầu về hậu quả của sự cố trong chẩn đoán đến người bệnh, nhấn mạnh tầm quan trọng của việc chẩn đoán chính xác, kịp thời trong bảo đảm an toàn người bệnh.
  2. Tăng cường vai trò của nâng cao năng lực chẩn đoán trong ban hành chính sách về an toàn người bệnh và thực hành lâm sàng ở mọi cấp độ của hệ thống y tế.
  3. Thúc đẩy sự hợp tác từ cấp quản lý nhà nước, lãnh đạo ngành y tế đến hiệp hội người hành nghề, hội đồng người bệnh, và các tổ chức chính trị xã hội liên quan... để đồng bộ về chính sách, chiến lược cho mục tiêu chẩn đoán chính xác, điều trị an toàn.
  4. Khuyến khích sự tham gia của người bệnh người nhà cùng với nhân viên y tế, các lãnh đạo, quản lý bệnh viện để nâng cao năng lực chẩn đoán.


**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/) **- Đa khoa Hạng I Thành phố Hồ Chí Minh

## Nội dung cơ bản, cốt lõi của Chỉ thị số 35-CT/TW về đại hội đảng bộ các cấp tiến tới Đại hội đại biểu toàn quốc lần thứ XIV của Đảng

  * [Về ý nghĩa, tầm quan trọng của Chỉ thị số 35-CT/TW ngày 14/6/2024 của Bộ Chính trị về đại hội đảng bộ các cấp nhiệm kỳ 2025 – 2030, tiến tới Đại hội lần thứ XIV của Đảng](https://bvnguyentriphuong.com.vn/hoat-dong-doan-the/noi-dung-co-ban-cot-loi-cua-chi-thi-so-35-cttw-ve-dai-hoi-dang-bo-cac-cap-tien-toi-dai-hoi-dai-bieu-toan-quoc-lan-thu-xiv-cua-dang#v-ngha-tm-quan-trng-ca-ch-th-s-35cttw-ngy-1462024-ca-b-chnh-tr-v-i-hi-ng-b-cc-cp-nhim-k-2025-2030-tin-ti-i-hi-ln-th-xiv-ca-ng)
  * [ Những điểm mới, điểm nhấn của Chỉ thị số 35-CT/TW ngày 14/6/2024 của Bộ Chính trị](https://bvnguyentriphuong.com.vn/hoat-dong-doan-the/noi-dung-co-ban-cot-loi-cua-chi-thi-so-35-cttw-ve-dai-hoi-dang-bo-cac-cap-tien-toi-dai-hoi-dai-bieu-toan-quoc-lan-thu-xiv-cua-dang#nhng-im-mi-im-nhn-ca-ch-th-s-35cttw-ngy-1462024-ca-b-chnh-tr)


**Nội dung cơ bản, cốt lõi của Chỉ thị số 35-CT/TW về đại hội đảng bộ các cấp tiến tới Đại hội đại biểu toàn quốc lần thứ XIV của Đảng**
  1. ## **Về ý nghĩa, tầm quan trọng của Chỉ thị số 35-CT/TW ngày 14/6/2024 của Bộ Chính trị về đại hội đảng bộ các cấp nhiệm kỳ 2025 – 2030, tiến tới Đại hội lần thứ XIV của Đảng**


Điều lệ Đảng quy định đại hội đảng bộ các cấp và Đại hội đại biểu toàn quốc được tổ chức thường lệ 5 năm một lần (đối với chi bộ trực thuộc 5 năm hai lần). Đại hội đảng bộ các cấp tiến tới Đại hội đại biểu toàn quốc của Đảng là đợt sinh hoạt chính trị sâu rộng, sự kiện chính trị đặc biệt quan trọng của Đảng, của Đất nước. Đại hội có nhiệm vụ chủ yếu:
Đại hội có nhiệm vụ đánh giá kết quả thực hiện nghị quyết đại hội trong nhiệm kỳ và quyết định phương hướng, nhiệm vụ nhiệm kỳ tới; thảo luận, tham gia ý kiến vào các dự thảo văn kiện của cấp ủy cấp trên; chuẩn bị nhân sự và bầu ban chấp hành, ban thường vụ, ủy ban kiểm tra, các chức danh lãnh đạo cấp ủy các cấp; bầu đại biểu đi dự đại hội đảng bộ cấp trên.
Để bảo đảm sự lãnh đạo, chỉ đạo của Trung ương Đảng, trong mỗi nhiệm kỳ đại hội, Bộ Chính trị đều ban hành Chỉ thị về đại hội đảng bộ các cấp tiến tới đại hội đại biểu toàn quốc của Đảng; các cơ quan tham mưu của Trung ương Đảng theo chức năng, nhiệm vụ, có trách nhiệm nghiên cứu, xây dựng và ban hành văn bản hướng dẫn liên quan. Đây là các văn bản đặc biệt quan trọng chỉ đạo các cấp ủy, tổ chức đảng cụ thể hóa và lãnh đạo tổ chức thực hiện ở cấp mình, góp phần tổ chức thành công đại hội đảng bộ các cấp và Đại hội lần thứ XIV của Đảng.
Để chủ động chuẩn bị đại hội đảng bộ các cấp nhiệm kỳ 2025 – 2030 tiến tới Đại hội XIV của Đảng, ngay từ đầu nhiệm kỳ khóa XIII, Ban Chấp hành Trung ương, Bộ Chính trị, Ban Bí thư đã đưa vào Chương trình công tác toàn khóa; Bộ Chính trị đã chỉ đạo Ban Tổ chức Trung ương phối hợp với các tỉnh ủy, thành ủy, đảng ủy trực thuộc Trung ương, các cơ quan, đơn vị liên quan, tiến hành tổng kết việc thực hiện Chỉ thị số 35-CT/TW ngày 30/5/2019 của Bộ Chính trị khóa XII và xây dựng Chỉ thị mới của Bộ Chính trị về đại hội đảng bộ các cấp tiến tới Đại hội XIV của Đảng nhằm đáp ứng yêu cầu nhiệm vụ trong giai đoạn hiện nay và nhiệm kỳ tới.
Quá trình tổng kết Chỉ thị số 35 và xây dựng Chỉ thị mới của Bộ Chính trị được tiến hành khẩn trương, nghiêm túc, công phu, kỹ lưỡng, khoa học, bài bản, dân chủ, cầu thị, sát với yêu cầu thực tiễn; tổ chức nhiều hội nghị lấy ý kiến góp ý của các cấp ủy, tổ chức đảng, cơ quan, đơn vị trực thuộc Trung ương; xin ý kiến các đồng chí Ủy viên Bộ Chính trị, Ban Bí thư và trình xin ý kiến Ban Chấp hành Trung ương tại Hội nghị lần thứ 9 (với 108 lượt ý kiến góp ý) để tiếp thu, hoàn thiện. Qua lấy ý kiến, Ban Chấp hành Trung ương, Bộ Chính trị, các cấp ủy, tổ chức đảng đều cơ bản đồng tình, thống nhất cao.
Trên cơ sở đó, Bộ Chính trị đã thống nhất ban hành Chỉ thị số 35-CT/TW ngày 14/6/2024 của Bộ Chính trị về đại hội đảng bộ các cấp tiến tới Đại hội XIV của Đảng. Đây là văn bản hết sức quan trọng, định hướng rõ những quan điểm, nguyên tắc, mục tiêu, yêu cầu và những nội dung cơ bản chuẩn bị đại hội đảng bộ các cấp để các cấp ủy, tổ chức đảng quán triệt, lãnh đạo, chỉ đạo, cụ thể hóa và tổ chức thực hiện ở cấp mình; bảo đảm đồng bộ, thống nhất trong toàn hệ thống chính trị.
  1. ## **Những điểm mới, điểm nhấn của Chỉ thị số 35-CT/TW ngày 14/6/2024 của Bộ Chính trị**


Chỉ thị số 35-CT/TW ngày 14/6/2024 kế thừa các nội dung còn phù hợp của Chỉ thị số 35-CT/TW ngày 30/5/2019 của Bộ Chính trị khóa XII và điều chỉnh, bổ sung thêm những nội dung, trong đó có một số điểm mới sau:
  * **_Thứ nhất,_****_về yêu cầu:_** Chỉ thị lần này đã cơ bản kế thừa các yêu cầu trong Chỉ thị đại hội đảng bộ các cấp một số nhiệm kỳ gần đây; các quan điểm, mục tiêu, yêu cầu của Nghị quyết Đại hội XIII của Đảng, Nghị quyết số 26-NQ/TW ngày 19/5/2018 của Ban Chấp hành Trung ương Đảng khoá XII về tập trung xây dựng đội ngũ cán bộ các cấp, nhất là cấp chiến lược, đủ phẩm chất, năng lực và uy tín, ngang tầm nhiệm vụ, các quy định của Đảng có liên quan; đồng thời, tiếp thu đầy đủ chỉ đạo của đồng chí Tổng Bí thư, Trưởng Tiểu ban Nhân sự Đại hội XIV của Đảng. Chỉ thị đặt ra 7 yêu cầu đối với công tác chuẩn bị và tiến hành đại hội đảng bộ các cấp nhiệm kỳ 2025 – 2030, trong đó bổ sung mới 1 yêu cầu nêu rõ chỉ đạo của Bộ Chính trị cần tiếp tục chấn chỉnh, đổi mới mạnh mẽ công tác cán bộ, công tác chuẩn bị nhân sự.
  * **_Thứ hai,_****_về chuẩn bị văn kiện:_** Chỉ thị nhấn mạnh việc nâng cao chất lượng chuẩn bị văn kiện; quá trình xây dựng dự thảo văn kiện đại hội phải phát huy dân chủ, trí tuệ tập thể, tiếp thu tối đa ý kiến đóng góp của các cấp ủy, tổ chức đảng trực thuộc và của cán bộ, đảng viên, đồng thời nhấn mạnh việc ý kiến tham gia, góp ý của cán bộ, đảng viên, nhân dân; trong thảo luận cần hết sức cầu thị, lắng nghe, tôn trọng ý kiến lẫn nhau, tạo sự đoàn kết, thống nhất cao, nhất là đối với những vấn đề mới, vấn đề khó.
  * **_Thứ ba,_****_về tiêu chuẩn cấp ủy viên nhiệm kỳ 2025 – 2030:_** Chỉ thị lần này cơ bản kế thừa tiêu chuẩn nêu tại Chỉ thị 35 của Bộ Chính trị khóa XII, Nghị quyết số 26-NQ/TW ngày 19/5/2018 của Ban Chấp hành Trung ương Đảng khóa XII; tiêu chuẩn cán bộ nêu tại Quy định số 89-QĐ/TW ngày 4/8/2017 và Quy định số 214-QĐ/TW ngày 2/1/2020 của Bộ Chính trị và các quy định của Đảng, pháp luật của Nhà nước, cụ thể gồm:


Có bản lĩnh chính trị vững vàng, tuyệt đối trung thành với lợi ích của Đảng, Nhà nước và của Nhân dân; kiên định chủ nghĩa Mác-Lênin, tư tưởng Hồ Chí Minh, đường lối đổi mới của Đảng, mục tiêu độc lập dân tộc và CNXH. Kiên quyết đấu tranh bảo vệ nền tảng tư tưởng của Đảng, Hiến pháp và pháp luật của Nhà nước.
Có phẩm chất đạo đức, lối sống gương mẫu, trong sáng; thực hiện nghiêm quy định của Đảng, nguyên tắc tập trung dân chủ, tự phê bình và phê bình; có ý thức tổ chức kỷ luật và tinh thần trách nhiệm cao trong công việc, giữ gìn sự đoàn kết nội bộ; cần, kiệm, liêm, chính, chí công vô tư;  _kê khai tài sản, thu nhập trung thực, minh bạch; không cơ hội, tham vọng quyền lực, cục bộ, bè phái, tham nhũng, tiêu cực, “lợi ích nhóm”,… Không để vợ hoặc chồng, con, người thân lợi dụng chức vụ, quyền hạn để trục lợi._
Có năng lực cụ thể hóa và tổ chức thực hiện có hiệu quả đường lối, chủ trương của Đảng, chính sách, pháp luật của Nhà nước; có tư duy đổi mới, tầm nhìn, phương pháp làm việc khoa học, hiệu quả; nói đi đôi với làm, năng động, sáng tạo, dám nghĩ, dám nói, dám làm, dám chịu trách nhiệm; có thành tích, kết quả công tác và “sản phẩm” cụ thể trong địa bàn, lĩnh vực công tác được giao…); đồng thời, bổ sung, cụ thể hóa quy định về thời gian giữ chức vụ đối với cán bộ được giới thiệu ứng cử chức vụ cao hơn theo Quy định số 80-QĐ/TW ngày 18/8/2022 của Bộ Chính trị về phân cấp quản lý cán bộ và bổ nhiệm, giới thiệu cán bộ ứng cử cụ thể: Cán bộ được giới thiệu để bầu tham gia cấp ủy, các chức danh lãnh đạo cấp ủy, chính quyền, Mặt trận Tổ quốc, tổ chức chính trị – xã hội (chức vụ cao hơn),  _nhìn chung phải có thời gian giữ chức vụ đang đảm nhiệm hoặc chức vụ tương đương ít nhất là 2 năm (24 tháng); trường hợp đặc biệt có thời gian giữ chức vụ ít nhất là 1 năm (12 tháng), do cấp ủy có thẩm quyền bổ nhiệm cán bộ xem xét, quyết định_. Đồng thời, Bộ Chính trị giao cấp ủy các cấp cụ thể hóa tiêu chuẩn cấp ủy cho phù hợp với tình hình, đặc điểm của địa phương, cơ quan, đơn vị, đáp ứng yêu cầu nhiệm vụ chính trị của đảng bộ nhiệm kỳ 2025 – 2030 và những năm tiếp theo.
  * **_Thứ tư,_** ** _về độ tuổi tái cử và lần đầu tham gia cấp ủy, chính quyền, Mặt trận Tổ quốc và các tổ chức chính trị – xã hội gắn với tuổi công tác được kéo dài theo Nghị định số 135-NĐ/CP của Chính phủ quy định về tuổi nghỉ hưu theo Bộ luật Lao động:_** Chỉ thị số 35-CT/TW tiếp tục kế thừa các quy định tại Chỉ thị số 35-CT/TW của Bộ Chính trị khóa XII, xác định:  _Những đồng chí lần đầu tham gia cấp ủy, chính quyền, Mặt trận Tổ quốc và các tổ chức chính trị – xã hội phải còn thời gian công tác ít nhất trọn 1 nhiệm kỳ trở lên; giới thiệu tái cử cấp ủy phải còn thời gian công tác ít nhất từ 1/2 nhiệm kỳ (30 tháng) trở lên_. Đồng thời, bổ sung, điều chỉnh quy định về tái cử chức danh lãnh đạo chính quyền, Mặt trận Tổ quốc, các tổ chức chính trị – xã hội là: Cán bộ tái cử cấp ủy thì được tái cử các chức danh lãnh đạo chính quyền, Mặt trận Tổ quốc, các tổ chức chính trị – xã hội nhưng phải còn thời gian công tác ít nhất 18 tháng trở lên tại thời điểm bầu cử hoặc đại hội của mỗi tổ chức.
  * **_Thứ năm,_** ** _về cơ cấu, tỷ lệ cán bộ tham gia cấp ủy và chủ trương cán bộ không là người địa phương:_** Chỉ thị của Bộ Chính trị quy định rõ phải bảo đảm sự lãnh đạo trực tiếp, toàn diện của cấp ủy đối với những địa bàn, lĩnh vực quan trọng, nhưng coi trọng chất lượng, không vì cơ cấu mà hạ thấp tiêu chuẩn; không nhất thiết địa phương, ban, ngành nào cũng phải có người tham gia cấp ủy; quy định thống nhất những chức danh có cơ cấu “cứng” tham gia ban thường vụ, số chức danh còn lại do cấp ủy quyết định cho phù hợp với yêu cầu nhiệm vụ chính trị và tình hình đội ngũ cán bộ. Phấn đấu đổi mới không dưới 1/3 tổng số cấp ủy viên trong mỗi nhiệm kỳ; phấn đấu đạt tỉ lệ cấp ủy viên nữ từ 15% trở lên và có cán bộ nữ trong ban thường vụ; phấn đấu tỉ lệ cán bộ trẻ từ 10% trở lên, trong đó, độ tuổi cán bộ trẻ được điều chỉnh, bổ sung dưới 42 tuổi đối với cấp tỉnh, cấp huyện; dưới 40 tuổi đối với cấp xã theo Nghị định số 135/2020/NĐ-CP ngày 18/11/2020 của Chính phủ; tỉ lệ cấp ủy viên là người dân tộc thiểu số bảo đảm phù hợp với đặc điểm, cơ cấu dân tộc và điều kiện cụ thể của từng địa phương, cơ quan, đơn vị. Cơ bản thực hiện chủ trương bố trí bí thư cấp ủy cấp tỉnh không là người địa phương gắn với việc sử dụng, bố trí hài hòa nguồn cán bộ tại chỗ trong quy hoạch; hoàn thành 100% ở cấp huyện; khuyến khích thực hiện ở cấp xã và các chức danh khác.
  * **_Thứ sáu_** ** _về số lượng cấp ủy viên, ủy viên ban thường vụ cấp ủy các cấp:_** Chỉ thị lần này xác định số lượng cấp ủy viên cấp tỉnh, cấp huyện thực hiện như nhiệm kỳ 2015 – 2020 và quy định cán bộ Trung ương điều động, luân chuyển giữ chức vụ bí thư, phó bí thư cấp ủy hoặc phó bí thư, chủ tịch ủy ban nhân dân cấp tỉnh nằm trong số lượng ủy viên ban chấp hành, ủy viên thường vụ cấp ủy cấp tỉnh nêu trên. Đồng thời, bổ sung, quy định cụ thể hơn: Số lượng ban thường vụ cấp ủy cấp huyện từ 11 đến 13 đồng chí; số lượng cấp ủy viên đảng bộ cấp xã không quá 15; ban thường vụ không quá 5, định hướng bố trí cơ cấu ban thường vụ đối với một số chức danh cụ thể và giao ban thường vụ cấp uỷ cấp tỉnh cụ thể hoá, chỉ đạo ban thường vụ cấp ủy cấp huyện xem xét, quyết định cơ cấu cụ thể cho thống nhất và phù hợp với tình hình, yêu cầu nhiệm vụ. Đối với những đảng bộ cấp xã, cấp huyện hợp nhất, sáp nhập thì số lượng cấp ủy viên có thể nhiều hơn nhưng tối đa không quá tổng số lượng hiện có trước khi hợp nhất và chậm nhất sau 5 năm, thì phải thực hiện theo quy định.
  * **_Thứ bảy,_** ** _về quy trình nhân sự:_** Cơ bản thực hiện theo Chỉ thị 35 của Bộ Chính trị khóa XII và Quy định số 80-QĐ/TW ngày 18/8/2022 của Bộ Chính trị về phân cấp quản lý cán bộ và bổ nhiệm, giới thiệu cán bộ ứng cử, đồng thời bổ sung để bảo đảm dân chủ, chặt chẽ trên cơ sở xác định rõ thẩm quyền của tập thể lãnh đạo trong công tác nhân sự, đáp ứng yêu cầu thực tiễn; quy trình nhân sự tái cử (2 bước, rút đi 3 bước so với nhiệm kỳ trước) và quy trình nhân sự lần đầu tham gia cấp ủy (5 bước, trong đó bổ sung mới nội dung quy định cụ thể về nguyên tắc lựa chọn và tỉ lệ số dư ở mỗi bước); trình tự thực hiện đối với các đồng chí tái cử trước, sau đó là các đồng chí tham gia lần đầu.
  * **_Thứ tám_**** _về tổ chức thực hiện:_** Chỉ thị của Bộ Chính trị yêu cầu các cấp ủy trực thuộc Trung ương tổ chức quán triệt Chỉ thị; các ban đảng Trung ương theo chức năng, nhiệm vụ, quyền hạn của mình hướng dẫn, theo dõi, tuyên truyền, kiểm tra, đôn đốc việc chuẩn bị và tổ chức đại hội đảng bộ các cấp. Đồng thời, giao Đảng đoàn Quốc hội, Ban cán sự đảng Chính phủ, các ban, cơ quan đảng ở Trung ương, Đảng đoàn Mặt trận Tổ quốc Việt Nam, các tổ chức chính trị – xã hội; các cấp ủy, tổ chức đảng, cơ quan, đơn vị liên quan chỉ đạo, rà soát, sửa đổi, bổ sung các quy định, hướng dẫn liên quan, bảo đảm đồng bộ, thống nhất với Chỉ thị này và các quy định của Đảng; sớm ban hành quy định về chế độ, chính sách đối với cán bộ không đủ tuổi tái cử, có chính sách cụ thể để xây dựng đội ngũ cán bộ lãnh đạo cấp ủy, quản lý các cấp có đủ phẩm chất, năng lực, uy tín, ngang tầm nhiệm vụ, dám nghĩ, dám làm, dám chịu trách nhiệm, đổi mới, sáng tạo vì lợi ích chung.


Chỉ thị số 35- CT/TW, ngày 14/6/2024 của Bộ Chính trị yêu cầu: Các cấp ủy trực thuộc Trung ương tổ chức quán triệt Chỉ thị và xây dựng kế hoạch thực hiện ở cấp mình; lãnh đạo, chỉ đạo công tác chuẩn bị đại hội đảng bộ các cấp; làm tốt công tác chính trị, tư tưởng, đẩy mạnh công tác thông tin, tuyên truyền gắn với các phong trào thi đua yêu nước. Thành lập các tiểu ban giúp việc chuẩn bị và tổ chức đại hội; phân công ủy viên thường vụ, cấp ủy viên chỉ đạo, hướng dẫn, kiểm tra đảng bộ cấp dưới (nếu có); tổ chức đại hội điểm để rút kinh nghiệm; chủ động nắm tình hình, kịp thời có biện pháp xử lý đối với những nơi có khó khăn hoặc có vấn đề phức tạp nảy sinh. Ban thường vụ cấp ủy cấp dưới báo cáo việc chuẩn bị văn kiện và đề án nhân sự cấp ủy khoá mới, khi được ban thường vụ cấp ủy cấp trên trực tiếp đồng ý mới tiến hành đại hội.
  * [Về ý nghĩa, tầm quan trọng của Chỉ thị số 35-CT/TW ngày 14/6/2024 của Bộ Chính trị về đại hội đảng bộ các cấp nhiệm kỳ 2025 – 2030, tiến tới Đại hội lần thứ XIV của Đảng](https://bvnguyentriphuong.com.vn/hoat-dong-doan-the/noi-dung-co-ban-cot-loi-cua-chi-thi-so-35-cttw-ve-dai-hoi-dang-bo-cac-cap-tien-toi-dai-hoi-dai-bieu-toan-quoc-lan-thu-xiv-cua-dang#v-ngha-tm-quan-trng-ca-ch-th-s-35cttw-ngy-1462024-ca-b-chnh-tr-v-i-hi-ng-b-cc-cp-nhim-k-2025-2030-tin-ti-i-hi-ln-th-xiv-ca-ng)
  * [ Những điểm mới, điểm nhấn của Chỉ thị số 35-CT/TW ngày 14/6/2024 của Bộ Chính trị](https://bvnguyentriphuong.com.vn/hoat-dong-doan-the/noi-dung-co-ban-cot-loi-cua-chi-thi-so-35-cttw-ve-dai-hoi-dang-bo-cac-cap-tien-toi-dai-hoi-dai-bieu-toan-quoc-lan-thu-xiv-cua-dang#nhng-im-mi-im-nhn-ca-ch-th-s-35cttw-ngy-1462024-ca-b-chnh-tr)



## Tập huấn An toàn Người bệnh năm 2024

Hưởng ứng **“Ngày An toàn người bệnh Thế giới”** năm 2024, ngày 10/10/2024 vừa qua, Phòng Quản lý chất lượng bệnh viện đã tổ chức buổi tập huấn An toàn người bệnh với các chủ đề thiết thực với mục đích tăng cường nhận diện sai sót, các sự cố y khoa, nhận thức được tầm quan trọng của phòng ngừa sự cố y khoa để nâng cao chất lượng dịch vụ khám bệnh, chữa bệnh hướng tới sự an toàn và hài lòng của người bệnh và nhân viên y tế. 
Đồng thời, thông qua chương trình, bệnh viện cũng đã triển khai một số hoạt động an toàn người bệnh và phòng ngừa sự cố y khoa trong hoạt động khám chữa bệnh.
Một số hình ảnh trong buổi tập huấn:
Đến với buổi tập huấn bao gồm các lãnh đạo, nhân viên các khoa/phòng và đặc biệt là sự quan tâm sâu sắc từ Ban Giám đốc Bệnh viện Nguyễn Tri Phương.
Tiến sĩ Bác sĩ Lê Cao Phương Duy - Phó Giám đốc Bệnh viện Nguyễn Tri Phương
Nội dung trong chương trình tập huấn với các chủ đề:
**TỔNG QUẢN VỀ SỰ CỐ Y KHOA** **Báo cáo viên:**
  * _Bác sĩ Chuyên khoa I Bùi Anh Triết_
  * _Phó Trưởng phòng Quản lý chất lượng, Bệnh viện Nguyễn Tri Phương_

  
---  
**NHẬN DIỆN VÀ BÁO CÁO SỰ CỐ Y KHOA** **Báo cáo viên:**
  * _Thạc sĩ Nguyễn Bá Trọng_
  * _Phó Trưởng phòng Quản lý chất lượng.Bệnh viện Nguyễn Tri Phương_

  
**KIỂM SOÁT NHIỄM KHUẨN TRONG CHĂM SÓC BỆNH NHÂN TRƯỚC PHẪU THUẬT** **Báo cáo viên:**
  * _Bác sĩ Chuyên khoa I Phan Thị Xuân Hoa_
  * _Phó Trưởng khoa Kiểm soát nhiễm khuẩn, Bệnh viện Nguyễn Tri Phương_

  
**PHÒNG NGỪA SỰ CỐ Y KHOA TRONG XÁC ĐỊNH NGƯỜI BỆNH VÀ TRUYỀN ĐẠT THÔNG TIN TRONG NHÓM CHĂM SÓC** **Báo cáo viên:**
  * _Cử nhân Điều dưỡng Lê Thị Thân Ái_
  * _Phó Trưởng phòng Điều dưỡng, Bệnh viện Nguyễn Tri Phương_

  
**SAI SÓT THUỐC: CÂU CHUYỆN GIAO TIẾP** **Báo cáo viên:**
  * _Tiến sĩ Dược sĩ Võ Thị Hà_
  * _Phó Khoa Dược, Bệnh viện Nguyễn Tri Phương_

  
**SAI SÓT TRONG SỬ DỤNG THUỐC KHÁNG SINH VANCOMYCIN VÀ LINEZOLID** **Báo cáo viên:**
  * _Dược sĩ Vũ Thu Thảo_
  * _Khoa Dược, Bệnh viện Nguyễn Tri Phương_

  
Các thành viên tham gia chương trình tập huấn đã được cập nhật và nắm rõ hơn về một số kiến thức an toàn người bệnh. Các kiến thức này được thể hiện qua bài test cuối chương trình.
**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/)** - Đa khoa Hạng I Thành phố Hồ Chí Minh

## Ngày hội Vệ sinh tay năm 2024

Sáng ngày 15/10/2024,Công đoàn Bệnh viện Nguyễn Tri Phương phối hợp với Khoa Kiểm soát Nhiễm khuẩn đã tổ chức thành công Ngày hội Vệ sinh tay năm 2024. Đây là hoạt động thường niên nhằm nâng cao ý thức vệ sinh tay trong bệnh viện, góp phần giảm thiểu nguy cơ lây nhiễm và đảm bảo an toàn cho người bệnh, nhân viên y tế cũng như cộng đồng.
> _Ảnh 1.Đại diện Ban lãnh đạo các khoa phòng tham dự._
Ngày hội bắt đầu với một không khí vui tươi và sôi động từ tiết mục nhảy flashmob cổ động vệ sinh tay. Những điệu nhảy mạnh mẽ, sinh động của các thành viên tham gia đã nhanh chóng thu hút sự chú ý và hưởng ứng nhiệt tình của toàn thể cán bộ, nhân viên bệnh viện. Tiết mục không chỉ thể hiện sự sáng tạo trong công tác truyền thông mà còn là một cách để truyền tải thông điệp về tầm quan trọng của vệ sinh tay trong các cơ sở y tế một cách trực quan và dễ hiểu.
> _Ảnh 2.Tiết mục nhảy Flashmob của Tổ Công đoàn_
> _Khoa Kiểm soát nhiễm khuẩn._
Sau tiết mục nhảy cổ động, phần phát biểu của các đại diện lãnh đạo diễn ra trang trọng và nghiêm túc. Đại diện lãnh đạo Bệnh viện Nguyễn Tri Phương, Ts. BS. Lê Cao Phương Duy- Phó giám đốc phụ trách điều hành Bệnh viện đã có bài phát biểu nhấn mạnh vai trò của vệ sinh tay trong công tác chăm sóc sức khỏe, đặc biệt là trong bối cảnh các dịch bệnh có khả năng lây nhiễm qua đường tiếp xúc ngày càng gia tăng. Bên cạnh đó, ông cũng biểu dương những nỗ lực không ngừng của của các Khoa phòng trong việc duy trì và nâng cao các biện pháp kiểm soát nhiễm khuẩn. Những hoạt động như Ngày hội Vệ sinh tay không chỉ góp phần nâng cao nhận thức của đội ngũ y tế mà còn lan tỏa thông điệp tích cực đến cộng đồng.
> _Ảnh 3. Ts. BS. Lê Cao Phương Duy_
> _Phó giám đốc phụ trách điều hành Bệnh viện phát biểu khai mạc._
Tiếp nối phần phát biểu của lãnh đạo Bệnh viện là phát biểu của Chủ tịch Hội Kiểm soát Nhiễm khuẩn Việt Nam- TTND.PGS.TS. Lê Thị Anh Thư chia sẻ về tầm quan trọng của vệ sinh tay, một trong những biện pháp đơn giản nhưng hiệu quả nhất để ngăn ngừa nhiễm khuẩn. Trong bài phát biểu, bà cũng nêu bật những thành tựu mà Hội đã đạt được trong việc thúc đẩy các biện pháp kiểm soát nhiễm khuẩn, đồng thời kêu gọi sự chung tay của tất cả các đơn vị, cá nhân trong hệ thống y tế để cải thiện hơn nữa chất lượng vệ sinh tay tại các cơ sở y tế.
> _Ảnh 4. TTND.PGS.TS. Lê Thị Anh Thư phát biểu._
Cuối chương trình là phần ký cam kết của các Khoa Phòng trong bệnh viện. Đại diện từng Khoa, Phòng ký kết cam kết và dán bàn tay cam kết thực hiện đúng các quy trình và hướng dẫn về vệ sinh tay. Đây là một hoạt động ý nghĩa, thể hiện quyết tâm và trách nhiệm của mỗi Khoa, Phòng trong việc nâng cao chất lượng chăm sóc sức khỏe và kiểm soát nhiễm khuẩn. Bằng việc ký cam kết, các Khoa, Phòng trong bệnh viện cam đoan sẽ tiếp tục đẩy mạnh các biện pháp vệ sinh tay, đảm bảo mọi nhân viên tuân thủ nghiêm ngặt quy định, từ đó xây dựng một môi trường y tế an toàn và lành mạnh.
> _Ảnh 5. Đại diện Khoa, Phòng ký tên và dán bàn tay cam kết._
Ngày hội Vệ sinh tay 2024 khép lại trong không khí phấn khởi và lạc quan. Những thông điệp và cam kết từ sự kiện này chắc chắn sẽ góp phần tạo ra những thay đổi tích cực trong việc kiểm soát nhiễm khuẩn tại bệnh viện, vì sức khỏe của người bệnh và cả cộng đồng.
**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/)** - Đa khoa Hạng I Thành phố Hồ Chí Minh

## Thông báo mời tham gia: Hiến máu nhân đạo (09/5/2024)

**1. Địa điểm:** Tại sảnh thang máy phía sau khoa Cấp cứu Bệnh viện Nguyễn Tri Phương và sảnh thang máy lầu 1 Khoa Ngoại Tổng Hợp.
**2. Thời gian:** Sáng thứ năm ngày 09 tháng 5 năm 2024 - Từ 07g30 đến 11g00.
**Xin lưu ý:**
o Số lượng máu hiến: 350ml – 450 ml
o Khi đi hiến máu đề nghị đem theo CCCD giúp nhân viên nhập dữ liệu kiểm tra thông tin chính xác.
o Người hiến máu : 
• Nhận 01 suất ăn nhẹ trị giá 30.000 đồng.
• Nhận quà tặng giá trị tương đương với số lượng máu hiến.
• Nhận hỗ trợ phí đi lại: 50.000 đồng
**Trân trọng thông báo**

## Tập huấn văn hóa ứng xử-bình đẳng giới và vị thế của Phụ nữ Việt Nam

Ngày 17 tháng 10 năm 2024, Công đoàn Bệnh viện Nguyễn Tri Phương tổ chức buổi tập huấn quan trọng với nội dung về văn hóa ứng xử, bình đẳng giới và vị thế của phụ nữ Việt Nam nhân kỷ niệm ngày Phụ nữ Việt Nam 20/10 và 94 năm ngày thành lập Hội Liên hiệp phụ nữ Việt Nam (20/10/1930-20/10/2024). 
Buổi tập huấn được tổ chức dành riêng cho đoàn viên công đoàn, với sự tham gia của 30% số lượng đoàn viên học trực tiếp tại hội trường Bệnh viện, trong khi số còn lại học qua hình thức trực tuyến.
> Ảnh 1.Đại diện Ban lãnh đạo và 30% đoàn viên Công đoàn tham gia trực tiếp.
Trong phần đầu của buổi tập huấn, báo cáo viên **TS Huỳnh Đức Thiện – Giảng viên Trường Đại học Khoa học Xã hội và Nhân văn TP. Hồ Chí Minh** đã nhấn mạnh về tầm quan trọng của văn hóa ứng xử trong môi trường làm việc, đặc biệt là trong lĩnh vực y tế. Nhân viên y tế không chỉ đối mặt với các ca bệnh phức tạp mà còn phải duy trì tinh thần hợp tác, tôn trọng và chuyên nghiệp trong giao tiếp với bệnh nhân và đồng nghiệp. Qua buổi tập huấn, các đoàn viên công đoàn đã có cơ hội nắm bắt được những kỹ năng cần thiết để xây dựng và duy trì văn hóa giao tiếp tích cực tại nơi làm việc, từ cách thể hiện sự quan tâm, đồng cảm đến việc giải quyết mâu thuẫn một cách khéo léo.
Phần thứ hai của buổi tập huấn xoay quanh vấn đề bình đẳng giới, một chủ đề đang được quan tâm trong xã hội hiện đại. Báo cáo viên đã chia sẻ những thông tin và số liệu liên quan đến thực trạng về sự phân biệt đối xử giới tính trong các ngành nghề, bao gồm lĩnh vực y tế. Mặc dù phụ nữ chiếm một phần lớn trong ngành y, họ vẫn phải đối mặt với những rào cản trong việc thăng tiến và nhận được cơ hội công bằng như nam giới.
Phần cuối của buổi tập huấn là một điểm nhấn quan trọng, nói về vị thế của phụ nữ Việt Nam trong thời đại hiện nay. Phụ nữ Việt Nam đã và đang có những bước tiến mạnh mẽ trong mọi lĩnh vực của đời sống xã hội, từ kinh tế, chính trị đến giáo dục và khoa học. Tuy nhiên, để duy trì và phát triển vị thế này, phụ nữ cần không ngừng trau dồi kiến thức, kỹ năng và nhận thức về quyền của mình. Các đoàn viên công đoàn đã được khuyến khích học hỏi và phấn đấu để trở thành những người tiên phong trong việc thay đổi nhận thức về vai trò và vị thế của phụ nữ trong xã hội.
> Ảnh 2.Báo cáo viên TS Huỳnh Đức Thiện – Giảng viên Trường Đại học Khoa học Xã hội và Nhân văn TP. Hồ Chí Minh
Điểm đặc biệt của buổi tập huấn này là sự kết hợp giữa hình thức học trực tiếp và trực tuyến, đáp ứng được nhu cầu và điều kiện của các đoàn viên công đoàn. Với 30% đoàn viên tham gia trực tiếp tại hội trường bệnh viện, các nội dung được trình bày rõ ràng, sinh động qua các ví dụ thực tiễn và tương tác trực tiếp. Trong khi đó, những đoàn viên không thể tham gia trực tiếp vẫn có thể theo dõi và tham gia buổi tập huấn thông qua hình thức trực tuyến, đảm bảo không ai bị bỏ lỡ thông tin quan trọng.
Buổi tập huấn về văn hóa ứng xử, bình đẳng giới và vị thế của phụ nữ Việt Nam do Công đoàn Bệnh viện Nguyễn Tri Phương tổ chức đã thành công tốt đẹp. Đây là cơ hội để các đoàn viên công đoàn nâng cao nhận thức, trang bị kiến thức và kỹ năng cần thiết, góp phần tạo dựng môi trường làm việc văn minh, công bằng và tiến bộ.
**Người thực hiện: Ths.Nguyễn Mỹ Linh**
**Uỷ viên BCH CĐ Bệnh viện Nguyễn Tri Phương**
**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/)** - Đa khoa Hạng I Thành phố Hồ Chí Minh

## Công bố kết quả giải thưởng các đội thi chung kết hội thi văn nghệ mừng xuân 2024

Ngày 18/01/2024, Bệnh viện Nguyễn Tri Phương đã tổ chức Chung kết hội thi Văn nghệ mừng xuân 2024.
Các đội thi của các khoa/phòng đã thể hiện hết mình và đạt các giải thưởng từng thể loại nội dung sau:
**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/)** - Đa khoa Hạng I Thành phố Hồ Chí Minh

## Diễn tập Phòng cháy chữa cháy tại Bệnh viện Nguyễn Tri Phương năm 2023

Phòng cháy chữa cháy (PCCC) là một trong những công tác quan trọng nhằm bảo vệ tính mạng, tài sản, giữ vững an ninh trật tự và an toàn xã hội. Nhằm thực hiện tốt công tác phòng cháy và chữa cháy (PCCC) theo quy định của Luật Phòng cháy và chữa cháy; trang bị cho cán bộ, giảng viên các kiến thức về phòng cháy, chữa cháy, cứu nạn, cứu hộ và nâng cao sự phối hợp chỉ huy về chiến thuật, kỹ thuật chữa cháy và cứu nạn, cứu hộ giữa lực lượng chữa cháy chuyên nghiệp với lực lượng chữa cháy ở cơ sở. Công tác tập huấn cho các cán bộ, công chức viên chức hạt nhân phòng cháy chữa cháy là vô cùng cần thiết. Khi có sự cố cháy xảy ra thì lực lượng này sẽ tiên phong dùng các phương tiện tại chỗ để chữa cháy trước khi có lực lượng chữa cháy chuyên nghiệp đến.
Thực hiện chương trình diễn tập, lực lượng cảnh sát PCCC- CNCH Công an Phường 8, Công an Quận 5, ,Đội cảnh sát Giao thông trật tự, lực lượng PCCC - CNCH của Bệnh viện Nguyễn Tri Phương đã được diễn tập tình huống tại khuôn viên bệnh viện, thực hành chữa cháy như: dùng bình bột chữa cháy khay xăng, triển khai chữa cháy bằng bọng nước cứu hoả, sơ cứu người bị nạn, cứu hộ cứu nạn cho các nạn nhân. Thực hiện tốt phương châm 4 tại chổ: Chỉ huy tại chổ, lực lượng tại chổ, phương tiện tại chỗ và vật tư hậu cầu tại chỗ.
Thông qua buổi diễn tập giúp lực lượng PCCC của đơn vị nâng cao trình độ, kiến thức cơ bản về các biện pháp phòng ngừa cháy nổ, kỹ năng xử lý tại chỗ và thoát nạn khi có cháy nổ xảy ra. Cháy nổ có thể xảy đến bất cứ lúc nào, bất cứ đâu trong khuôn viên bệnh viện do đó đội cảnh sát PCCC - CNCH đã trang bị một số kỹ năng và thực tập công tác phòng cháy chữa cháy.
Công tác PCCC đóng vai trò vô cùng quan trọng trong đời sống xã hội. Thực hiện tốt công tác PCCC nhằm bảo vệ tính mạng, tài sản, giữ được bình yên, hạnh phúc cho mọi gia đình và xã hội. Qua buổi diễn tập các đại biểu tham gia đã thu lại cho mình những kiến thức và kỹ năng bổ ích. Giúp nâng cao ý thức về công tác phòng cháy chữa cháy và tìm kiếm cứu nạn, cứu hộ của lực lượng PCCC tại chỗ. Nâng cao khả năng sẳn sàng chiến đấu và phối hợp trong công tác chữa chay, cứu nạn, cứu hộ khi công tác cấp cứu chuyển thương, công tác bảo về hiện trường, điều tiết giao thông. trong việc xử lý các tình huống cháy, nổ lớn.
**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/) **- Đa khoa Hạng I Thành phố Hồ Chí Minh

## Lễ nhận tài trợ bếp ăn tình thương

Hôm ngay ngày 21/08/2023, Bệnh viện Nguyễn Tri Phương tổ chức lễ trao tặng Bếp ăn tình thương cho người bệnh và người có hoàn cảnh khó khăn. Với sự tham dự của khách mời Đồng chí Trương Hòa Bình- Nguyên Phó Bí thư Ban Cán sự Đảng Chính phủ, Nguyên Phó Thủ tướng Thường trực Chính phủ; Đồng chí Bùi Minh Tuyên - Phó Tổng Cục trưởng Tổng cục I - Bộ Công an và nhà tài trợ đến từ công ty, Ông Nguyễn Văn Huynh – Giám đốc Công ty TNHH H.T.H.
Tiếp đón đoàn Đại biểu và tham dự Lễ trao tặng đến từ Bệnh viện Nguyễn Tri Phương có Bác sĩ CKII Võ Đức Chiến – Giám đốc BV – Trưởng ban tổ chức - Chủ tịch Hội Chữ thập đỏ bệnh viện, Tiến sĩ Bác sĩ Lê Cao Phương Duy – Phó Giám đốc BV, Bác sĩ CKII Đỗ Tuấn Linh – Phó Giám đốc BV, Thạc sĩ Bác sĩ CKII Lương Công Minh – Phó Giám độc BV – Chủ tịch Công Đoàn.
Từ một Y quán nhỏ của cộng đồng người Hoa, trải qua 120 năm hình thành và phát triển, đến nay Bệnh viên Nguyễn Tri Phương đã đạt được nhiều thành tựu chuyên môn đáng tự hào. Bên cạnh đó, xuất phát từ đạo lý “lá lành đùm lá rách” thể hiện tinh thần yêu thương, đùm bọc giúp đỡ lẫn nhau. Nhiều năm qua Bệnh viện Nguyễn Tri Phương đã đưa vào nhiều hoạt động hỗ trợ người bệnh và thân nhân như:
  1. Hỗ trợ khẩn cấp tại Khoa cấp cứu,
  2. Hỗ trợ viện phí,
  3. Bữa cơm tình thương, 
  4. Gian hàng chia sẻ yêu thương,
  5. Hỗ trợ chi phí sinh hoạt thiết yếu,
  6. Hoạt động nâng đỡ tinh thần và chuyến xe nghĩa tình.


Những hoạt động trên từng bước củng cố tính bền vững của Hệ sinh thái hỗ trợ người bệnh và thân nhân có hoàn cảnh khó khăn tại bệnh viện Nguyễn Tri Phương./.
**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/) **- Đa khoa Hạng I Thành phố Hồ Chí Minh

## Ngày hội vệ sinh tay năm 2023

Năm 2008, Liên Hợp quốc đã chọn ngày 15 tháng 10 hàng năm là ngày “Thế giới rửa tay - Global handwashing day” nhằm nâng cao nhận thức về tầm quan trọng của việc rửa tay bằng xà phòng như là một phương pháp dễ dàng và hiệu quả để phòng ngừa bệnh. 
Để có được những thành tựu về vệ sinh tay như ngày hôm nay, ngành y tế đã trải qua cả một quá trình dài, đánh đổi nhiều thời gian và công sức. 
Tiếp lời kêu gọi của WHO, Chủ đề cho Ngày Thế giới rửa tay năm 2023 tại Bệnh viện Nguyễn Tri Phương là **"DUY TRÌ VÀ TĂNG TỐC “HÃY VỆ SINH TAY ĐỂ BẢO VỆ CUỘC SỐNG"**
Đến với Ngày hội vệ sinh tay tại Bệnh viện Nguyễn Tri Phương hôm nay có sự tham dự phía khách mời là Phó Giáo sư Tiến sĩ Bác sĩ Lê Thị Anh Thư - Chủ tịch Hội Kiểm soát nhiễm khuẩn Việt Nam
và phía bệnh viện có sự tham dự của Ban Giám đốc Bệnh viện và lãnh đạo Khoa Kiểm soát nhiễm khuẩn bệnh viện cùng các lãnh đạo khoa/phòng, các điều dưỡng và đồng nghiệp của Bệnh viện Nguyễn Tri Phương.
Đồng hành với bệnh viện không thể không nhắc đến sự hỗ trợ không ngừng của các nhà tài trợ, đã luôn ủng hộ và giúp đỡ cho bệnh viện trong công tác kiểm soát nhiễm khuẩn và đặc biệt là trong ngày phát động phong trào vệ sinh tay năm nay. Đó là các công ty VietMedical, Lavitec và 3M.
Nhằm tạo không khí thêm sôi động cho ngày hội vệ sinh tay đó là vũ điệu "Please Hand Washing".
Qua báo cáo vệ sinh tay năm 2023 của Bác sĩ chuyên khoa II Hồ Đắc Phương - Phó trưởng khoa Kiểm soát nhiễm khuẩn cho thấy việc tuân thủ thực hành vệ sinh tay ngày càng tốt hơn. Trong đó cũng chỉ ra được các khoa có tỷ lệ vệ sinh tay cao nhất trong năm và khuyến khích các khoa tiếp tục nâng cao, tăng tỷ lệ thực hành vệ sinh tay tốt hơn nữa. Đồng thời tuyên dương các khoa có thành tích tốt nhất trong năm.
Đại diện Đoàn thanh niên Bệnh viện Nguyễn Tri Phương, Bác sĩ Bùi Anh Triết - Phó Bí thư Đoàn nêu cao khẫu hiệu, phát động phong trào vệ sinh tay.
Thay đổi so với các năm về trước, Nghi thức cam kết thực hiện vệ sinh tay của bệnh viện được thực hiện qua hình thức dán biểu tượng lên bức tranh về cây xanh như một hành động cam kết.
**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/)** - Đa khoa Hạng I Thành phố Hồ Chí Minh

## Kết quả tổ chức cuộc thi “Clip Chào mừng 120 năm thành lập Bệnh viện”

_Căn cứ Kế hoạch 2145/KH-NTP ngày 13 tháng 10 năm 2023 về Tổ chức cuộc thi “Clip Chào mừng 120 năm thành lập Bệnh viện”;_
_Căn cứ kết quả chấm điểm của Ban Giám khảo và khảo sát trên kênh youtube Bệnh viện Nguyễn Tri Phương;_
**Kết quả cuộc thi quay Clip Chào mừng 120 năm thành lập Bệnh viện như sau:**
**Giải nhất:** khoa Ngoại Thần kinh
  * Xem clip [**tại đây**](https://www.youtube.com/watch?v=MKOpP0hXN64&list=PLiU0n83wV1FAlkB39ab6f1EC2sC7_vNMT&index=5)


**Giải nhì:** khoa Nội Tiêu hóa
  * Xem clip [**tại đây**](https://www.youtube.com/watch?v=-CaP1od5Tvs&list=PLiU0n83wV1FAlkB39ab6f1EC2sC7_vNMT&index=7&t=44s)


**Giải ba** : khoa Ngoại Tiêu hóa
  * Xem clip [**tại đây**](https://www.youtube.com/watch?v=1V9UbcK9_r8&list=PLiU0n83wV1FAlkB39ab6f1EC2sC7_vNMT&index=12&t=84s)


**Giải khuyến khích** : khoa Chẩn đoán hình ảnh
  * Xem clip [**tại đây**](https://www.youtube.com/watch?v=ezzokwLu9r4&list=PLiU0n83wV1FAlkB39ab6f1EC2sC7_vNMT&index=4)


**Giải do người bình chọn nhiều nhất** trên kênh truyền thông Bệnh viện: khoa Thận-Lọc máu
  * Xem clip [**tại đây**](https://www.youtube.com/watch?v=GoxH7STywFg&list=PLiU0n83wV1FAlkB39ab6f1EC2sC7_vNMT&index=1&t=3s)


**Xin trân trọng cảm ơn sự cố gắng của các tập thể hướng đến 120 năm thành lập BV!**
**​​​​​​​**

## Kế hoạch Tổ chức Kỷ niệm 114 năm ngày Quốc tế Phụ nữ (08/3/1910-08/3/2024) 1984 năm cuộc khởi nghĩa Hai Bà Trưng và Ngày Quốc tế Hạnh phúc 20/3

Ngày 01/3/2024, Công đoàn Bệnh viện đã ban hành Kế hoạch Tổ chức Kỷ niệm 114 năm ngày Quốc tế Phụ nữ (08/3/1910-08/3/2024); 1984 năm cuộc khởi nghĩa Hai Bà Trưng và Ngày Quốc tế Hạnh phúc 20/3
Đề nghị các Tổ Công đoàn tích cực triển khai thực hiện.
Tải Kế hoạch [tại đây](https://bvnguyentriphuong.com.vn/uploads/112023/files/K%E1%BA%BF%20ho%E1%BA%A1ch%20C%C3%B4ng%20%C4%91o%C3%A0n.pdf)
#### Nội dung trong file:



## Hệ sinh thái vì người bệnh khó khăn - chỗ dựa của nhiều hoàn cảnh


## Huân chương Lao động hạng Ba trao cho Hội Chữ thập đỏ Bệnh viện Nguyễn Tri Phương

hực hiện ý chí chỉ đạo của Đảng và hà nước cũng như ngành y tế về công tác chăm sóc người bệnh có hoàn cảnh khó khăn, trong những năm gần đây, bên cạnh nỗ lực phát triển cơ sở vật chất, tăng cường chất lượng khám chữa bệnh, Bệnh viện Nguyễn Tri Phương còn chú trọng xây dựng “Hệ sinh thái hỗ trợ bệnh nhân có hoàn cảnh khó khăn”
ây là một mô hình vòng tròn khép kín, áp dụng cho những trường hợp bệnh nhân có hoàn cảnh khó khăn với mục tiêu phát huy truyền thống “Lá lành đùm lá rách” và tinh thần thương yêu, tương trợ và giúp đỡ lẫn nhau của người Việt Nam. Hệ sinh thái đã thu hút sự quan tâm của các tầng lớp nhân dân tích cực tham gia trợ giúp các cá nhân, gia đình và cộng đồng gặp khó khăn.
Từ các mô hình**“** _Hỗ trợ khẩn cấp tại cấp cứu nhập viện”, “ Quỹ hỗ trợ viện phí của Bệnh viện và các Quỹ Từ Thiện khác” “Suất ăn tình thương”, “Phí sinh hoạt thiết yếu”, “Chuyến xe nghĩa tình”, “Gian hàng chia sẻ yêu thương” “ Hoạt động nâng đỡ tinh thần”_ hợp nhất tạo thành Mô hình “Hệ sinh thái hỗ trợ hoàn cảnh khó khăn” và được báo cáo tham luận tại Đại hội Đại biểu toàn quốc Hội Chữ thập đỏ Việt Nam lần thứ XI nhiệm kỳ 2022 - 2027. 
ại chương trình “Ngày hội Tình nguyện Quốc gia và Lễ trao Giải thưởng Tình nguyện Quốc gia năm 2022” do Trung ương Đoàn Thanh niên Cộng sản Hồ Chí Minh tổ chức vào ngày 03/12/2022, Hội Chữ thập đỏ Bệnh viện Nguyễn Tri Phương vinh dự là tập thể nhận Giải thưởng Tình nguyện Quốc gia năm 2022.
Trên thực tế, "Hệ sinh thái" của Bệnh viện Nguyễn Tri Phương đã góp phần không nhỏ trong việc cứu được tính mạng của hàng trăm bệnh nhân, giúp họ có cơ hội được sống và làm lại cuộc đời.
Chính vì thế, ngày 10/11/2023, Chủ tịch Nước Cộng hòa Xã hội Chủ nghĩa Việt Nam đã ký Quyết định số 1370/QĐ-CTN về việc tặng thưởng Huân chương Lao động hạng Ba cho Hội Chữ thập đỏ Bệnh viện Nguyễn Tri Phương đã có thành tích xuất sắc trong công tác xã hội, nhân đạo góp phần vào sự nghiệp xây dựng chủ nghĩa xã hội và bảo vệ Tổ quốc. 

## Hội thi trang điểm nét đẹp nhân viên y tế Bệnh viện Nguyễn Tri Phương năm 2023

Thực hiện Kế hoạch số 51/KH-BNC ngày 05/10/2023 của Công đoàn Bệnh viện Nguyễn Tri Phương về việc Kỷ niệm 93 năm Ngày thành lập Hội Liên hiệp Phụ nữ Việt Nam (20/10/1930 - 20/10/2023), 13 năm Ngày Phụ nữ Việt Nam; (20/10/2010 - 20/10/2023). 
Ban Thường vụ Công đoàn và Ban nữ công ban hành kế hoạch tổ chức Hội thi trang điểm năm 2023 chủ đề **"Nét đẹp nhân viên y tế Bệnh viện Nguyễn Tri Phương"** ngày 17/10/2023 tại Hội trường Bệnh viện Nguyễn Tri Phương.
Mục đích tổ chức hội thi nhằm nâng cao nhận thức trong nữ CNVC-LĐ về ý nghĩa lịch sử ra đời và phát triển của Hội liên hiệp Phụ nữ Việt Nam và Ngày phụ nữ Việt Nam 20/10, đồng thời dậy lòng tự hào giới; khẳng định vai trò, vị trí và những đóng góp quan trọng của nữ CNVC-LĐ trong việc thực hiện nhiệm vụ chính trị của Bệnh viện Nguyễn Tri Phương.
Tham gia hội thi là những nhân viên thuộc các khoa/phòng của Bệnh viện Nguyễn Tri Phương, các đội thi đã thể hiện năng khiếu làm đẹp, khả năng khéo léo của nhân viên y tế Bệnh viện Nguyễn Tri Phương.
Qua hội thi trang điểm đã tạo không khí vui vẻ, hào hứng với tinh thần thiết thực, tiết kiệm, an toàn và hiệu quả. Đây cũng là phong trào thi đua trong thành tích chào mừng 120 năm thành lập Bệnh viện Nguyễn Tri Phương.
**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/)** - Đa khoa Hạng I Thành phố Hồ Chí Minh

## Kiểm tra hoạt động Công đoàn cơ sở trực thuộc Công đoàn ngành y tế năm 2023

Ngày 20/9/2023, Công đoàn Bệnh viện Nguyễn Tri Phương tiếp Đoàn kiểm tra công tác công đoàn của Công đoàn ngành y tế.
Qua đợt kiểm tra cho thấy Công đoàn cơ sở đã chấp hành tốt các quy định của Điều lệ Công đoàn Việt Nam, tiếp nhận và triển khai kịp thời các văn bản chỉ đạo của công đoàn ngành y tế và thực hiện đầy đủ các quy định như: thực hiện việc lưu trữ các văn bản, nghị quyết của tổ chức công đoàn; ban hành các Quy chế làm việc của Ban Chấp hành, Ban Thường vụ; Chương trình phối hợp công đoàn cơ sở và Đoàn cơ sở tại đơn vị và các quy chế khác; chế độ sinh hoạt định kỳ của Ban Chấp hành được các Công đoàn cơ sở, duy trì thực hiện tốt, có sổ ghi biên bản đầy đủ nội dung các cuộc họp đúng quy định; hàng năm thực hiện đánh giá, xếp loại theo quy định. Công đoàn đã phối hợp với chính quyền cùng cấp tổ chức Hội nghị cán bộ, công chức theo quy định, thực hiện tốt quy chế dân chủ cơ sở; Công tác tuyên truyền, vận động đoàn viên công đoàn tham gia đầy đủ các cuộc thi do công đoàn cấp trên phát động.
Đoàn kiểm tra đã đề nghị Ban chấp hành Công đoàn cơ sở tiếp tục phát huy tốt hơn nữa những điểm mạnh mà công đoàn đã đạt được.
**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/) **- Đa khoa Hạng I Thành phố Hồ Chí Minh

## Giới thiệu về tổ chức Công đoàn cơ sở BV Nguyễn Tri Phương (NK 2023-2028)

Công đoàn cơ sở Bệnh viện Nguyễn Tri Phương ra đời cùng với việc thành lập Bệnh viện và trực thuộc trực thuộc Công đoàn Ngành Y tế. Sự phát triển của Công đoàn cơ sở Bệnh viện Nguyễn Tri Phương gắn liền quá trình xây dựng, trưởng thành và lớn mạnh của Bệnh viện.
**Ban Chấp hành Công đoàn cơ sở Bệnh viện Nguyễn Tri Phương nhiệm kỳ 2023-2028 gồm có**
  * Đ/c Lương Công Minh – Chủ tịch
  * Đ/c Đặng Thị Ngọc Giàu – Phó Chủ tịch- Trưởng Ban nữ công
  * Đ/c Hoàng Hải – UVBTV
  * Đ/c Nguyễn Thị Thanh Thúy - UVBTV
  * Đ/c Phạm Hồng Phong– UVBTV - Chủ nhiệm Ủy ban kiểm tra
  * Và 10 đồng chí ủy viên Ban Chấp hành Công đoàn cơ sở Bệnh viện


Công đoàn cơ sở Bệnh viện Nguyễn Tri Phương hiện có 46 Tổ công đoàn, với 1236 đoàn viên công đoàn (chiếm 1236/1244, trong tổng số CBVCLĐ toàn Bệnh viện), trong đó nữ:820 đoàn viên (chiếm 820/1236 tổng số đoàn viên).
Xác định rõ vai trò và nhiệm vụ của mình, Công đoàn cơ sở Bệnh viện Nguyễn Tri Phương đã có những bước phát triển lớn mạnh, đóng góp quan trọng cho sự nghiệp xây dựng và phát triển đi lên của Bệnh viện, hoàn thành tốt nhiệm vụ chính trị được giao.
**Các thành tích nổi bật của Công đoàn Bệnh viện:**
Qua hơn 45 năm xây dựng và phát triển của Công đoàn cơ sở Bệnh viện Nguyễn Tri Phương, được sự chỉ đạo sâu sát của Công đoàn Ngành Y tế và sự lãnh đạo trực tiếp của Đảng ủy Bệnh viện, tập thể đoàn viên công đoàn đã vượt lên trên những khó khăn thử thách, nỗ lực lao động sáng tạo, đoàn kết thống nhất, xứng đáng là ngọn cờ tập hợp toàn thể cán bộ, viên chức và người lao động để hoàn thành tốt nhiệm vụ chính trị cao cả mà Sở Y tế đã giao. Với những nỗ lực đó, Công đoàn cơ sở Bệnh viện Nguyễn Tri Phương xứng đáng nhận được các phần thưởng cao quý sau:
+ Cờ Thi đua của của Công đoàn ngành Y tế thành phố Hồ Chí Minh (2018; 2019)
+ Bằng khen của của LĐLĐ Thành phố ( năm 2017, 2019, 2021)

## Ứng dụng phòng chống thiên tai trên địa bàn Thành phố trên các thiết bị điện thoại, máy tính bảng thông minh

Việt Nam là một trong số ít quốc gia chịu tác động của biến đổi khí hậu; thiên tai ngày càng biến động, bất thường, nhiều thách thức đã và đang đặt ra cho công tác phòng chống thiên tai. Để công tác phòng chống thiên tai ngày càng hoàn thiện, hiệu quả hơn, Ban Chỉ huy Phòng thủ dân sự - Phòng chống thiên tại và Tìm kiếm cứu nạn Thành phố đã hoàn thiện ứng dụng phòng chống thiên tai trên địa bàn Thành phố.
Bệnh viện Nguyễn Tri Phương khuyến cáo toàn thể nhân viên y tế và bệnh nhân, thân nhân bệnh nhân cài đặt ứng dụng **“PCTT HCM”** trên thiết bị điện thoại, máy tính bảng thông minh của mình để có thể cập nhật kịp thời các thông tin về thời tiết, thiên tai và các hướng dẫn về phương án phòng tránh ứng phó với thiên tai.
**Tính năng của ứng dụng:**
  * Cập nhật tin tức, các văn bản pháp luật liên quan lĩnh vực phòng chống thiên tai và tìm kiếm cứu nạn;
  * Thông tin về thời tiết, thiên tai và các hướng dẫn về phương án phòng, tránh, ứng phó với các loại hình thiên tai có khả năng ảnh hưởng đến Thành phố như: áp thấp nhiệt đới, bão, ngập úng, sạt lở bờ song, lốc xoáy, sét, mưa đá, nắng nóng, hạn hán, động đất, sóng thần…
  * Bản đồ về vị trí an toàn di dời phòng tránh thiên tai, bản đò vị trí xung yếu và vị trí sạt lở trên toàn địa bàn Thành phố;
  * Tính năng phản ánh thôngt in về thiên tai, cứu nạn, cứu hộ của tổ chức, cá nhân gửi đến các cơ quan chức năng bằng nhiều hình thức: gọi điện, tin nhắn, email. hình ảnh, bản ghi âm;
  * Liên kết với các trang thông tin điện tử của các cơ quan, tổ chức trong nước và quốc tế liên quan lĩnh vực phòng chống thiên tai và tìm kiếm cứu nạn.


**HƯỚNG DẪN TẢI VÀ CÀI ĐẶT ỨNG DỤNG TRÊN HỆ ĐIỀU HÀNH ANDROID VÀ IOS**
**ANDROID**  
---  
Bước 1: truy cập ứng dụng kho ứng dụng  
APP STORE | CH PLAY / PLAY STORE  
Bước 2: gõ từ khóa **"pctt hcm"** tại ô tìm kiếm và chọn ứng dụng PCTT HCM tải về  
Bước 3: Chọn đồng ý cho phép luôn truy cập vị trí khi sử dụng ứng dụng  
Giao diện ứng dụng sau khi hoàn tất các bước tải và cài đặt ứng dụng  
**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/) **- Đa khoa Hạng I Thành phố Hồ Chí Minh

## Công đoàn BV Nguyễn Tri Phương ký kết ghi nhớ hợp tác cùng Công đoàn cơ sở trường ĐH Ngoại Thương cơ sở II

Với mong muốn đa dạng hóa hoạt động và hướng đến những hoạt động phong phú dành cho công đoàn viên của hai bên, Công đoàn cơ sở của BV Nguyễn Tri Phương và Đại học Ngoại Thương cơ sở II đã cùng ký kết ghi nhớ hợp tác, trong đó nhấn mạnh đến một số hoạt động như:
- Tùy thuộc vào thế mạnh của mỗi bên để cùng tạo ra những sân chơi bổ ích, hứng thú cho người lao động, vừa làm mạnh thêm năng lực hoạt động của Công đoàn cơ sở hai bên.
- Cùng tham gia các hoạt động cộng đồng trên cơ sở cộng hưởng thế mạnh của đôi bên nhằm đem lại nhiều giá trị tích cực cho xã hội.
Buổi lễ ký kết đã diễn ra rất trang trọng, chuyên nghiệp và tạo ra những mở đầu tốt đẹp cho sự hợp tác của Công đoàn cơ sở của hai bên./.

## Hội Chữ thập đỏ BV Nguyễn Tri Phương nhận Giải thưởng tình nguyện Quốc gia năm 2022

Với chủ đề “Đoàn kết thông qua hoạt động tình nguyện” (Solidarity through volunteering), nhằm tôn vinh tinh thần đoàn kết thông qua hoạt động tình nguyện; Vì một đất nước Việt Nam phát triển thịnh vượng và hạnh phúc trong tương lai, chúng ta hãy cùng nhau hành động ngay bây giờ vì tương lai tốt đẹp của cộng đồng, quê hương, đất nước và của chính chúng ta.
Giải thưởng Tình nguyện Quốc gia được khởi xướng từ năm 2011, qua 11 năm liên tiếp, giải thưởng đã có hơn 240 tập thể và cá nhân có thành tích xuất sắc tiêu biểu trong hoạt động tình nguyện vì sự phát triển của đất nước và cộng đồng. Năm 2022, giải thưởng đã tiếp nhận 258 hồ sơ được xét chọn và đề cử từ các tỉnh, thành phố, các tổ chức, đơn vị, cá nhân trên khắp cả nước và được tiến hành bình chọn, chia sẻ lan tỏa trên mạng xã hội, thu hút sự quan tâm, bình chọn của cộng đồng. Hội đồng bình chọn toàn quốc Giải thưởng Tình nguyện Quốc gia đã bỏ phiếu, bình chọn 9 tập thể và 10 cá nhân có thành tích xuất sắc tiêu biểu trong hoạt động tình nguyện vì sự phát triển của đất nước và cộng đồng trong năm 2022. 

## Hãy tuân thủ tốc độ quy định

Hiện nay an toàn giao thông đang là vấn đề lớn, được cả xã hội quan tâm. Ở nước ta, mỗi năm tai nạn giao thông đã cướp đi sinh mạng của hàng chục nghìn người, bình quân mỗi ngày trên cả nước xảy ra gần 40 vụ tai nạn giao thông làm chết khoảng 30 người, gây thiệt hại về vật chất hàng nghìn tỷ đồng, chưa kể đến các chi phí cho những người tàn tật và mất khả năng lao động. Trong đó việc tai nạn do không làm chủ tốc độ chiếm tỷ lệ cao. 
Bạn có biết rằng **Tốc độ càng cao, tài xế cần càng nhiều khoảng cách để phản xạ đạp thắng và dừng hẳn xe**
  * Với tốc độ 80km/h, từ lúc bạn phản xạ đến lúc dừng hẳn xe cần đến 68m, tương đương chiều rộng của một sân bóng đá lớn (trong điều kiện thời tiết và thắng xe ở điều kiện tốt) Trong khi đó, 80% khả năng người đi bộ tử vong nếu bị xe va chạm ở tốc độ từ 50km/h 
  * Vận tốc càng cao - hậu quả càng nghiêm trọng.


Chính vì thế hãy tuân thủ tốc độ quy định và hãy nâng cao trách nhiệm của mình khi tham gia giao thông.
**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/) **- Đa khoa Hạng I Thành phố Hồ Chí Minh

## Công đoàn cơ sở BV Nguyễn Tri Phương tham gia Đại hội Công đoàn ngành y tế Thành phố Hồ Chí Minh

Trong 2 ngày 13 và 14/7, Công đoàn ngành Y tế TPHCM đã tổ chức Đại hội Công đoàn ngành Y tế TPHCM lần thứ XIII, nhiệm kỳ 2023 - 2028. Đến dự có các đồng chí: Phùng Thái Quang, Phó Chủ tịch Liên đoàn Lao động TPHCM; PGS.TS.BS. Tăng Chí Thượng, Thành ủy viên, Bí thư Đảng ủy, Giám đốc Sở Y tế TP; Trần Văn Xồi, Phó Bí thư Thường trực Đảng ủy Sở Y tế TPHCM.
Sau 5 năm tổ chức triển khai thực hiện Nghị quyết Đại hội Công đoàn ngành lần thứ XII nhiệm kỳ 2018 - 2023 với nhiều biện pháp, giải pháp cụ thể, thiết thực, Công đoàn ngành Y tế TP đã hoàn thành vượt mức các nhiệm vụ và chỉ tiêu đã đề ra góp phần hoàn thành nhiệm vụ chính trị của ngành và của tổ chức Công đoàn, nâng cao uy tín, vị thế của tổ chức Công đoàn trong tình hình mới…
Phát biểu chỉ đạo Đại hội, PGS.TS.BS. Tăng Chí Thượng đánh giá cao nỗ lực của Công đoàn ngành Y tế TP trong công tác chăm lo cho CNVC-LĐ, nhất là trong giai đoạn bùng phát dịch Covid-19. Đồng chí nêu rõ nhiệm vụ của Công đoàn ngành trong thời gian tới là cần nhanh chóng triển khai học tập và ban hành chương trình, kế hoạch hành động thực hiện Nghị quyết số 31-NQ/TW ngày 30/12/2022 của Bộ Chính trị về phương hướng, nhiệm vụ phát triển TPHCM đến năm 2030, tầm nhìn đến năm 2045; cùng phối hợp với lãnh đạo Sở Y tế xây dựng chương trình hành động, kế hoạch cụ thể thực hiện Nghị quyết số 98/2023/QH15 về thí điểm một số cơ chế, chính sách đặc thù phát triển TPHCM.
Đại hội đã thông qua Nghị quyết khóa XIII gồm 8 nhiệm vụ và 16 chỉ tiêu chủ yếu với khẩu hiệu hành động: “Đổi mới, sáng tạo, nâng cao hiệu quả hoạt động, xây dựng tổ chức Công đoàn vững mạnh; tập trung nhiệm vụ đại diện, chăm lo, bảo vệ quyền, lợi ích hợp pháp, chính đáng của công nhân, viên chức, lao động; xây dựng quan hệ lao động hài hòa, ổn định, tiến bộ, phát triển; tích cực tham gia xây dựng Đảng, chính quyền trong sạch vững mạnh; tăng cường khả năng tham gia quản lý của cán bộ Công đoàn”.
Công đoàn BV Nguyễn Tri Phương kính chúc mừng thành công của Đại hội./.

## Hội thao chữa cháy, cứu nạn, cứu hộ phường 8, Quận 5 năm 2023

Sáng ngày 10/06/2023, UBND Phường 8, Quận 5 đã tổ chức hội thao Chữa cháy, cứu nạn, cứu hộ cho lực lượng PCCC cơ sở thuộc địa bàn phường 8 năm 2023 (lần 2) trên địa bàn. Với sự tham gia của các cơ sở trong khu vực, nhất là các đơn vị Bệnh viện trực thuộc khu vực.
Đây là hoạt động cần thiết để lực lượng cơ sở có thể chủ động xử lý tình huống phát sinh tại địa bàn trước khi lực lượng PCCC chuyên nghiệp có mặt. Ủy ban Nhân dân phường 8, Quận 5 luôn chú trọng đến phương châm 4 tại chỗ trong công tác PCCC để giảm thiểu thiệt hại về người và tài sản.
Qua quá trình tập huấn, diễn tập PCCC hằng năm cũng như nghiệp vụ chuyên nghiệp của các thành viên trong đội PCCC của Bệnh viện Nguyễn Tri Phương, Đội thi của bệnh viện đã tham gia tích cực và đạt giải nhất cuộc thi hội thao Chữa cháy, cứu nạn, cứu hộ cho lực lượng PCCC cơ sở thuộc địa bàn phường 8 năm 2023.
**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/) **- Đa khoa Hạng I Thành phố Hồ Chí Minh

## Hội nghị tổng kết công tác Đoàn và phong trào Đoàn thanh niên năm 2022

Chiều thứ 6, ngày 30/6/2023 vừa qua, Đoàn thanh niên bệnh viện Nguyễn Tri Phương long trọng tổ chức Hội nghị tổng kết hoạt động Đoàn và phong trào thanh niên năm 2022 và triển khai các hoạt động 6 tháng sau năm 2023. 
Tham dự Hội nghi có Đồng chí Võ Đức Chiến - Bí Thư Đảng ủy Bệnh viện Nguyễn Tri Phương và Đồng chí Trần Đức Khánh - Phó Bí Thư Đoàn Sở Y tế đến tham dự cùng toàn thể Ban chấp hành Đoàn Thanh niên Bệnh viện Nguyễn Tri Phương.
Tại Hội nghị, các đại biểu đã nghe Báo cáo Tổng kết công tác Đoàn và phong trào thanh niên năm 2022 với một số thành tích nổi bật trong các lĩnh vực như: Đẩy mạnh công tác xây dựng Đoàn và công tác Đoàn tham gia xây dựng Đảng; Các hoạt động xung kích, tình nguyện của tuổi trẻ được tổ chức đa dạng, mang màu sắc, dấu ấn thanh niên, phù hợp với đặc thù của đoàn viên thanh niên.
Qua báo cáo tổng kết hoạt động Đoàn năm 2022, Đồng chí Võ Đức Chiến và đồng chí Trần Đức Khánh đã ghi nhận và biểu dương những nỗ lực phấn đấu của đoàn viên thanh niên và thành tích đạt được của Đoàn thanh niên Bệnh viện, đóng góp ý kiến cho Đoàn thanh niên bệnh viện để ngày càng phát triển hơn. 
_Đồng chí Võ Đức Chiến - Bí thư Đảng Ủy Bệnh viện Nguyễn Tri Phương và Đồng chí Trần Đức Khánh - Phó Bí thư Đoàn Sở Y tế Tp. Hồ Chí Minh cùng tập thể Ban Chấp Hành Đoàn Bệnh viện Nguyễn Tri Phương_
Bên cạnh đó, hội nghị cũng tổ chức lễ Trưởng thành Đoàn và trao tặng thẻ Đoàn viên ưu tú năm 2022.
_Đồng chí Võ Đức Chiến - Bí thư Đảng Ủy Bệnh viện Nguyễn Tri Phương trao bằng khen cho Đồng chí Hoàng Văn Triều - Bí thư Đoàn thanh niên Bệnh viện Nguyễn Tri Phương_
**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/) **- Đa khoa Hạng I Thành phố Hồ Chí Minh

## Trao trả tài sản đánh rơi của thân nhân bệnh nhân ngày 10,12/06/2023

Vào ngày 10/6/2023, Trong quá trình đi tuần tra an ninh bệnh viện, nhân viên an ninh phát hiện điện thoại tại khu vực hành lang Khoa Thận Lọc Máu. Qua nghiệp vụ của mình, Bộ phận an ninh đã trình báo lên Ban Giám đốc và tiến hành xác minh chủ sở hữu của tài sản là của chị N.T.N.Giàu.
Sau khi liên hệ được chị Giàu, Bộ phận an ninh đã trao trả lại cho chị.
Rạng sáng ngày 12/06/2023, Khi đang tuần tra an ninh bệnh viện tại khu vực khoa Chấn thương chỉnh hình, Bộ phận an ninh bệnh viện phát hiện một điện thoại để ở khu vực hành lang và không người trông coi. Sau khi lập biên bản và trình báo lên Ban Giám đốc, Bộ phận an ninh đã tiến hành xác minh chủ sở hữu đó là anh N.Q.Tiến và đã trao trả lại cho anh.
**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/) **- Đa khoa Hạng I Thành phố Hồ Chí Minh
[facebook.com/BVNTP](http://facebook.com/BVNTP)
[youtube.com/bvntp](http://youtube.com/bvntp)

## Nguồn gốc và ý nghĩa Ngày Gia đình Việt Nam 28/6

**Nguồn gốc Ngày Gia đình Việt Nam**
Chủ tịch Hồ Chí Minh lúc sinh thời luôn đề cao vai trò của gia đình đối với sự phát triển chung của xã hội. Người khẳng định: “Quan tâm đến gia đình là đúng vì nhiều gia đình cộng lại mới thành xã hội, gia đình tốt thì xã hội mới tốt, xã hội tốt thì gia đình càng tốt hơn, hạt nhân của xã hội là gia đình”.
Hưởng ứng lời dạy đó, ngày 28/6/2000, Bộ Chính trị ban hành Chỉ thị số 55-CT/TW về tăng cường sự lãnh đạo của các cấp ủy đảng ở cơ sở đối với công tác bảo vệ, chăm sóc và giáo dục trẻ em. Chỉ thị coi việc xây dựng gia đình bền vững, hạnh phúc là một mục tiêu quan trọng.
Chỉ thị này cũng yêu cầu đề cao vai trò và trách nhiệm của gia đình, giúp đỡ và tạo điều kiện cần thiết để các gia đình thực hiện trách nhiệm đối với thế hệ trẻ, tạo môi trường lành mạnh cho sự phát triển của trẻ em.
Ngày 4/5/2001, Thủ tướng Chính phủ đã ký ban hành Quyết định số 72/2001/QĐ-TTg lấy ngày 28/6 hàng năm làm Ngày Gia đình Việt Nam. Quyết định nhấn mạnh đến vai trò của gia đình cũng như những trách nhiệm của các cán bộ ngành, các cấp và toàn thể xã hội xây dựng gia đình văn minh, bình đẳng, tiến bộ, hạnh phúc, đẩy mạnh công tác bảo vệ, chăm sóc và giáo dục trẻ em góp phần xây dựng và bảo vệ Tổ quốc.
**Ý nghĩa Ngày Gia đình Việt Nam**
Ngày Gia đình Việt Nam là ngày cả nước tôn vinh những giá trị tốt đẹp, cốt lõi của gia đình, nhắc nhở những giá trị truyền thống quý báu của cha ông ta từ ngàn xưa, yêu quê hương, yêu đất nước, yêu thương con người, đùm bọc, chở che cho nhau.
Văn hóa Việt Nam luôn tôn vinh những giá trị truyền thống, giá trị của gia đình. Ngày Gia đình Việt Nam còn là ngày để người Việt Nam hướng về nguồn cội, hướng về gia đình, đề cao những tình cảm cao đẹp. Dù đi đâu, làm gì thì gia đình vẫn là nơi để ta nhớ về, yêu thương và trở về.
Bên cạnh đó, ngày này cũng nhắc nhở về sự thủy chung, lòng son sắt của vợ chồng, sự sẻ chia và cùng nhau vượt qua những khó khăn trong cuộc sống.
Vào Ngày Gia đình Việt Nam, các gia đình có nhiều cách để bày tỏ tình cảm và tăng cường sự gắn kết như tặng quà, cùng nấu một bữa cơm đoàn viên, trao nhau lời chúc ý nghĩa. Đây cũng là cách người lớn dạy con trẻ về ý nghĩa của gia đình và trách nhiệm đối với các thành viên.
Đây cũng là ngày mọi người trong gia đình quan tâm đến nhau, xã hội quan tâm đến trẻ nhỏ và những người không có bố mẹ, cặp vợ chồng phải hiểu được giá trị mái ấm và cùng nhau vượt qua sóng gió để có một gia đình hạnh phúc.
Vào Ngày Gia đình Việt Nam, các gia đình có nhiều cách để bày tỏ tình cảm và tăng cường sự gắn kết như tặng quà, cùng nấu một bữa cơm đoàn viên, trao nhau lời chúc ý nghĩa. Đây cũng là cách người lớn dạy con trẻ về ý nghĩa của gia đình và trách nhiệm đối với các thành viên.

## Cảm ơn hoat động chăm lo của mạnh thường quân nhân dịp Tết Thiếu nhi năm 2023.

Xin chân thành cảm ơn Công ty TNHH Đại Bắc - Miền Nam đã cùng với các tổ chức đoàn thể của BV trao tặng 20 phần quà (gồm 4 bịch bánh các loại, 1 lốc sữa chua uống Susu) cho các bệnh nhi đang điều trị tại Khoa Nhi của bệnh viện nhân dịp Tết Thiếu nhi năm 2023.
Bệnh viện rất mong tiếp tục nhận được sự ủng hộ và đồng hành của các nhà Hảo tâm trong các hoạt động hỗ trợ người bệnh của Bệnh viện.
Xin chân thành cảm ơn !

## Tết trồng cây “Đời đời nhớ ơn Bác Hồ” năm 2023

Theo Thủ tướng, thực hiện di nguyện của Bác, 64 năm qua, Đảng, Nhà nước ta đã có nhiều chương trình trồng, bảo vệ và phát triển rừng, bảo vệ môi trường sinh thái. Hàng triệu héc ta rừng, hàng trăm triệu cây xanh đã được trồng trên khắp mọi miền Tổ quốc, góp phần phủ xanh đất trống, đồi trọc, cải thiện môi trường sinh thái, phát triển kinh tế - xã hội của đất nước, đóng góp tích cực vào việc giảm nhẹ thiên tai, giảm phát thải khí nhà kính và ứng phó có hiệu quả với biến đổi khí hậu. Độ che phủ rừng của nước ta đã tăng từ 28% vào năm 1990 lên trên 42% vào năm 2022; hấp thụ được trên 70 triệu tấn CO2.
Cũng theo Thủ tướng, việc trồng cây không chỉ bảo vệ cảnh quan môi trường và đa dạng sinh học mà còn là một ngành kinh tế quan trọng, mang lại nguồn lợi to lớn cho nước ta ở hiện tại và tương lai. Thực hiện chủ trương của Đảng, Nhà nước về phát triển bền vững, Việt Nam đã tham gia Công ước khung của Liên hợp quốc về Biến đổi khí hậu từ năm 1992. Đặc biệt, tại Hội nghị lần thứ 26 (COP26), Việt Nam cam kết thực hiện lộ trình đạt mức phát thải ròng bằng “0” vào năm 2050. Điều này thể hiện quyết tâm và cam kết chính trị của Việt Nam trong việc giải quyết những thách thức nghiêm trọng của toàn cầu về chống biến đổi khí hậu và suy giảm các hệ sinh thái, hướng đến mục tiêu một hành tinh khỏe mạnh.
Thủ tướng ghi nhận và biểu dương các địa phương, cơ quan, đơn vị có nhiều sáng kiến, cách làm hay, thiết thực, hiệu quả với những thông điệp hết sức cụ thể như: “Góp 1 cây để có rừng”, “Một triệu cây xanh cho Việt Nam”, “Hành động vì một Việt Nam xanh”, “Chung tay xanh hóa học đường”, “Lì xì hạt giống”, “Thêm cây, thêm sự sống”…
Để tiếp tục tổ chức thực hiện hiệu quả phong trào “Tết trồng cây đời đời nhớ ơn Bác Hồ”, Thủ tướng kêu gọi toàn thể đồng bào, đồng chí, chiến sỹ cả nước, các cháu học sinh, sinh viên, thanh thiếu niên, người Việt Nam và các tổ chức nước ngoài tại Việt Nam hãy hăng hái tham gia trồng cây ngay từ những ngày đầu xuân và cả năm; vì một Việt Nam xanh, an toàn, phát triển bền vững.

## Tiêu chuẩn cán bộ công đoàn

Căn cứ theo khoản 1 Điều 2 Quy định Tiêu chuẩn chức danh cán bộ lãnh đạo, quản lý công đoàn các cấp Ban hành kèm theo Quyết định 3169/QĐ-TLĐ năm 2021 quy định như sau:
“Điều 2. Tiêu chuẩn chung
1. Cán bộ công đoàn cấp cơ sở phải đáp ứng các tiêu chuẩn chung sau đây:
a) Có phẩm chất tiêu biểu của giai cấp công nhân, nhiệt tình, tâm huyết, trách nhiệm; có bản lĩnh và tinh thần đấu tranh bảo vệ quyền và lợi ích hợp pháp, chính đáng của đoàn viên, công nhân, viên chức, lao động.
b) Có đạo đức trong sáng, lối sống lành mạnh, trung thực, giản dị; thực hiện tốt nghĩa vụ công dân, sống và làm việc theo Hiến pháp và pháp luật.
c) Có năng lực thực tiễn, phương pháp hoạt động linh hoạt, đổi mới, dám nghĩ, dám làm, dám chịu trách nhiệm; có uy tín, và khả năng đoàn kết, tập hợp được đông đảo đoàn viên, công nhân, viên chức, lao động; có sức khỏe để hoàn thành nhiệm vụ.”
Như vậy để được trở thành cán bộ công đoàn cấp cơ sở thì cần phải đáp ứng những tiêu chuẩn được quy định như trên.
## **Nhiệm vụ và quyền hạn của cán bộ công đoàn trong Điều lệ công đoàn Việt Nam?**
Căn cứ Điều 5 Quyết định 174/QĐ-TLĐ năm 2020 quy định nhiệm vụ và quyền hạn của cán bộ công đoàn trông Điều lệ công đoàn Viêt Nam như sau:
– Nhiệm vụ
+ Liên hệ mật thiết với đoàn viên và người lao động; lắng nghe ý kiến, kiến nghị của đoàn viên và người lao động để giải quyết hoặc báo cáo, phản ánh kịp thời với người có thẩm quyền xem xét giải quyết.
+ Tuyên truyền, vận động đoàn viên, người lao động thực hiện tốt nghĩa vụ công dân; chấp hành chủ trương, nghị quyết của Đảng, chính sách, pháp luật của Nhà nước, các nội quy, quy chế của đơn vị; tích cực học tập nâng cao trình độ chính trị, văn hóa, pháp [luật](http://luatsu247.net/), chuyên môn, nghiệp vụ.
+ Nêu gương về mọi mặt đối với đoàn viên và người lao động; tích cực bảo vệ chế độ, bảo vệ Đảng và tổ chức Công đoàn Việt Nam.
+ Đại diện người lao động đối thoại, thương lượng tập thể theo quy định của pháp luật.
+ Phát triển đoàn viên và xây dựng tổ chức công đoàn vững mạnh.
+ Đấu tranh chống các biểu hiện vi phạm đường lối, chủ trương, nghị quyết của Đảng, chính sách, pháp luật của Nhà nước và nghị quyết của công đoàn các cấp.
+ Thực hiện các nhiệm vụ khác do tổ chức công đoàn phân công.
– Quyền hạn
+ Là người đại diện theo pháp luật hoặc theo ủy quyền, bảo vệ quyền và lợi ích hợp pháp, chính đáng của đoàn viên và người lao động.
+ Được thực hiện các quyền của cán bộ công đoàn theo quy định của Đảng, pháp luật Nhà nước và các quy định của Tổng Liên đoàn Lao động Việt Nam.
+ Được bảo đảm điều kiện hoạt động công đoàn tại nơi làm việc theo quy định của pháp luật. Được tổ chức công đoàn bảo vệ, giúp đỡ, hỗ trợ khi gặp khó khăn trong quá trình thực hiện nhiệm vụ.
+ Được đào tạo, bồi dưỡng nâng cao nghiệp vụ công tác công đoàn.
+ Được hưởng các chế độ, chính sách theo quy định của Đảng, Nhà nước và tổ chức Công đoàn.
+ Cán bộ công đoàn không chuyên trách khi có đủ điều kiện theo quy định và có nguyện vọng, được xem xét ưu tiên tuyển dụng làm cán bộ công đoàn chuyên trách.

## Trao trả tài sản đánh rơi của thân nhân bệnh nhân ngày 25/05/2023

Vào ngày 25/5/2023, Trong quá trình đi tuần tra an ninh bệnh viện, nhân viên an ninh phát hiện điện thoại đánh rơi cùng số tiền 500.000 đồng kẹp trong điện thoại tại khu vực thu viện phí. Qua nghiệp vụ của mình, Bộ phận an ninh đã trình báo lên Ban Giám đốc và tiến hành xác minh chủ sở hữu của tài sản là của chị H.T.T.Ngân.
Sau khi liên hệ được chị Ngân, Bộ phận an ninh đã trao trả lại cho chị.
**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/) **- Đa khoa Hạng I Thành phố Hồ Chí Minh
[facebook.com/BVNTP](http://facebook.com/BVNTP)
[youtube.com/bvntp](http://youtube.com/bvntp)

## Trao trả tài sản đánh rơi của thân nhân bệnh nhân ngày 09/06/2023

Vào ngày 09/6/2023, Trong quá trình đi tuần tra an ninh bệnh viện, nhân viên an ninh phát hiện điện thoại sạc không người trông coi tại khu vực khoa Khám bệnh. Qua nghiệp vụ của mình, Bộ phận an ninh đã trình báo lên Ban Giám đốc và tiến hành xác minh chủ sở hữu của tài sản là của chị T.T.Nga.
Sau khi liên hệ được chị Nga, Bộ phận an ninh đã trao trả lại cho chị.
**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/) **- Đa khoa Hạng I Thành phố Hồ Chí Minh
[facebook.com/BVNTP](http://facebook.com/BVNTP)
[youtube.com/bvntp](http://youtube.com/bvntp)

## Trao trả tài sản đánh rơi của thân nhân bệnh nhân ngày 23/05/2023

Vào ngày 23/5/2023, Trong quá trình đi tuần tra an ninh bệnh viện, nhân viên an ninh phát hiện điện thoại đánh rơi tại hành lang giữa tòa nhà B và C. Qua nghiệp vụ của mình, Bộ phận an ninh đã trình báo lên Ban Giám đốc và tiến hành xác minh chủ sở hữu của tài sản là của anh N.N.Tân
Sau khi liên hệ được anh Tân, Bộ phận an ninh đã trao trả lại cho bệnh nhân.
**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/) **- Đa khoa Hạng I Thành phố Hồ Chí Minh

## Nhiệm vụ của tổ trưởng công đoàn

I. NỘI DUNG HOẠT ĐỘNG CỦA TỔ TRƯỞNG CÔNG ĐOÀN.
Tổ trưởng công đoàn là người sống và làm việc hàng ngày với đoàn viên và CNLĐ, do đoàn viên trong tổ bầu ra, đại diện trực tiếp cho đoàn viên, công nhân viên chức, lao động trong tổ. Tổ trưởng công đoàn có trách nhiệm đại diện bảo vệ quyền, lợi ích hợp pháp, chính đáng của đoàn viên, công nhân lao động trong tổ; trực tiếp giải quyết các vướng mắc của đoàn viên, xây dựng cũng cố tập thể tổ đoàn kết, vận động các thành viên trong tổ tích cực sản xuất, kinh doanh, thực hiện nghiêm các chế độ chính sách của Nhà nước, nội quy, quy chế của cơ quan, đơn vị, góp phần thúc đẩy sản xuất kinh doanh phát triển. Tổ trưởng công đoàn hoạt động tích cực, có hiệu quả thì tổ công đoàn sẽ mạnh và ngược lại. Nội dung hoạt động chủ yếu của tổ trưởng công đoàn cần tập trung vào những vấn đề sau:
1. Tìm hiểu để nắm vững chủ trương đường lối của Đảng, các chính sách, pháp luật của Nhà nước và nhiệm vụ sản xuất, kinh doanh, công tác ở tổ:
- Để hoạt động của tổ công đoàn có hiệu quả, thiết thực, là người đứng đầu tổ công đoàn, tổ trưởng công đoàn cần tranh thủ thời gian nghiên cứu, nắm vững các chủ trương, đường lối của Đảng, chính sách, pháp luật của Nhà nước có liên quan đến công nhân, viên chức, lao động ở tổ, đặc biệt cần nắm vững những quy định của Bộ luật lao động về quyền lợi, nghĩa vụ của người lao động, về thời giờ làm việc, nghỉ ngơi về chính sách bảo hiểm xã hội. Nắm chắc những nội dung của thỏa ước lao động tập thể ở cơ sở, đây là căn cứ để tổ trưởng công đoàn vận động, tổ chức cho công nhân lao động và đoàn viên công đoàn trong tổ thực hiện. Đồng thời là cơ sở để tổ trưởng công đoàn hướng dẫn, giúp đỡ các thành viên trong tổ ký giao kết hợp đồng lao động với người sử dụng lao động và đại diện bảo vệ quyền, lợi ích hợp pháp, chính đáng của công nhân, lao động trong tổ.
Nắm các quyền công đoàn được quy định trong luật Công đoàn. Bộ luật lao động và trong các Nghị định của Chính phủ để thực hiện quyền đại diện bảo vệ quyền, lợi ích của công nhân, viên chức, lao động trong tổ, quyền tham gia quản lý, kiểm tra, giám sát thực hiện chế độ, chính sách, pháp luật liên quan đến quyền lợi, nghĩa vụ của công nhân, lao động.
- Nắm vững tình hình sản xuất, kinh doanh, công tác của đơn vị, chương trình kế hoạch hoạt động của CĐCS, Công đoàn bộ phận để đề ra chương trình, kế hoạch hoạt động và tổ chức thực hiện chương trình, kế hoạch hoạt động tổ công đoàn cho phù hợp.
2. Tổ chức thực hiện các nội dung hoạt động của tổ công đoàn.
Trong điều kiện phát triển kinh tế thị trường định hướng XHCN và hội nhập kinh tế quốc tế, tổ công đoàn cần phải không ngừng đổi mới nội dung, phương pháp hoạt động cho phù hợp với điều kiện cụ thể của tổ công đoàn và tình hình mới. Hoạt động của tổ công đoàn, tổ trưởng công đoàn cần tập trung chỉ đạo hoạt động vào một số nội dung cơ bản sau:
_2.1. Chỉ đạo hoạt động bảo vệ quyền, lợi ích hợp pháp, chính đáng của đoàn viên, công nhân lao động trong tổ:_
Lợi ích hợp pháp, chính đáng cơ bản của CNVC-LĐ nói chung, của công nhân, lao động trong tổ nói riêng gồm lợi ích vật chất, lợi ích tinh thần. Trong điều kiện hiện nay lợi ích vật chât của công nhân, lao động là đảm bảo việc làm ổn định và thu nhập tương xứng với sức lao động của họ bỏ ra, là được đảm bảo về điều kiện làm việc, an toàn vệ sinh, được quan tâm thực hiện đầy đủ các chế độ, chính sách, như bảo hiểm xã hội, bảo hiểm y tế… Lợi ích tinh thần của công nhân, lao động là được tôn trọng và đối xử bình đẳng, được tạo cơ hội, điều kiện để học tập, làm việc, được quan tấm đến các hoạt động văn hóa, xã hội… Để đảm bảo lợi ích vật chất, tinh thần của người lao động trong tổ, một mặt tổ công đoàn cần vận động, tổ chức để cùng nhau lao động làm việc với năng xuất, chất lượng và hiệu quả cao, phấn đấu hoàn thành xuất sắc nhiệm vụ được giao. Đối với tổ công đoàn, công chức, viên chức phấn đấu hoàn thành và hoàn thành đúng chức trách, nhiệm vụ được giao, để cơ quan, doanh nghiệp không ngừng phát triển, người lao động có việc làm ổn định, và thu nhập đảm bảo cuộc sống.
Mặt khác để bảo vệ được quyền, lợi ích hợp pháp, chính đáng của công nhân, lao động. Tổ trưởng công đoàn cần quan tâm đến các nội dung hoạt động sau:
- Giúp đỡ, hướng dẫn công nhân, lao động trong tổ kí giao kết HĐLĐ với người sử dụng lao động theo đúng quy định của pháp luật.
- Vận động, giúp đỡ người lao động thực hiện nghiêm những quy định trong hợp đồng lao động và thoả ước lao động tập thể.
- Giám sát thực hiện đúng các điều khoản đã giao kết trong HĐLĐ và thực hiện các chế độ, chính sách của Nhà nước. Nắm bắt tâm tư, nguyện vọng và những bức xúc của công nhân, lao động để có biện pháp cụ thể trong tổ chức hoạt động tổ công đoàn, nhằm đáp ứng yêu cầu, tâm tư, nguyện vọng của công nhân, lao động, ngăn chặng kịp thời đình công không theo đúng trình tự của pháp luật.
- Tổ chức cho công nhân lao động trong tổ tham gia quản lý sản xuất, kinh doanh, tham gia thoả ước lao động tập thể (khi công đoàn cơ sở xây dựng xong dự thảo TƯLĐTT và lấy ý kiến người lao động).
- Đại diện người lao động trong tổ đề xuất, kiến nghị với người sử dụng lao động, cải thiện điều kiện lao động, thực hiện nghiêm các chế độ chính sách đối với người lao động.
_2.2. Chỉ đạo công tác tham gia quản lý của tổ công đoàn:_
Tổ công đoàn tham gia quản lý, thực chất là để chăm lo bảo vệ quyền, lợi ích trước mắt và lâu dài của công nhân lao động trong tổ tốt hơn, là hình thức tổ chức để công nhân lao động trong tổ phát huy dân chủ, đóng góp chí tuệ của mình vào tìm biện pháp tổ chức sản xuất kinh doanh, quản lý các nguồn lực của tổ, của cơ quan, doanh nghiệp để hiệu quả sản xuất, kinh doanh của cơ quan, doanh nghiệp ngày một tăng. Do vậy tổ trưởng công đoàn cần quan tâm tổ chức cho công nhân, lao động và đại diện cho công nhân, lao động trong tổ tham gia với tổ trưởng sản xuất, với người sử dụng lao động tổ chức sản xuất, quản lý tổ và cơ quan doanh nghiệp ngày một tốt hơn. Nội dung tham gia quản lý của tổ trong điều kiện hiện nay nên tập trung vào tìm các biện pháp tổ chức sản xuất kinh doanh có hiệu quả, như tham gia phân công, bố trí, sử dụng lao động phù hợp với năng lực, sở trường của người lao động nhằm đảm bảo việc làm, tăng thu nhập cho các thành viên trong tổ, tham gia tìm biện pháp mở rộng thị trường tạo việc làm và điều kiện làm việc cho người lao động, tham gia trong công tác tổ chức tiền lương, định mức lao động, tham gia xây dựng, hoàn thiện nội quy, quy chế cơ quan, doanh nghiệp và tổ chức thực hiện nghiêm nội quy, quy chế doanh nghiệp hoặc cơ quan, đơn vị…
_a. Các hình thức công đoàn tham gia quản lý._
Để phát huy dân chủ, tập hợp trí tuệ của công nhân, lao động trong tổ, tham gia quản lý có hiệu quả, tổ trưởng công đoàn cần nắm vững và vận dụng linh hoạt, sáng tạo các hình thức tham gia cơ bản sau, cho phù hợp với điều kiện cụ thể của tổ:
- Tổ chức hội nghị công nhân, lao động trong tổ, để dân chủ bàn bạc, thảo luận những vấn đề liên quan đến việc thực hiện nhiệm vụ sản xuất, kinh doanh, đến thu nhập, các biện pháp đảm bảo đời sống của công nhân, lao động.
- Tổ chức cho đoàn viên, công nhân, viên chức, lao động tham gia xây dựng Thoả ước lao động tập thể, tìm biện pháp thực hiện những nội dung của Thoả ước lao động tập thể, đảm bảo hài hoà lợi ích của người lao động, người sử dụng lao động và lợi ích Nhà nước.
- Giám sát việc thực hiện nội quy, quy chế cơ quan, doanh nghiệp, hợp đồng lao động, Thoả ước lao động tập thể, các chính sách, pháp luật của Nhà nước có liên quan đến quyền lợi và nghĩa vụ của công nhân, viên chức, lao động trong tổ.
- Đề xuất, kiến nghị với CĐCS, với tổ sản xuất hoặc tổ công tác, đặc biệt là với người sử dụng lao động để họ quan tâm cải thiện điều kiện làm việc, đảm bảo an toàn vệ sinh lao động, quan tâm đào tạo bồi dưỡng nâng cao trình độ chuyên môn nghiệp vụ của công nhân, lao động trong tổ, để người lao động có đủ điều kiện, năng lực thực hiện tốt nhiệm vụ được giao. Đặc biệt cần chú trọng đề xuất với người sử dụng lao động quan tâm đến đời sống vật chất, tinh thần của người lao động, nhằm tạo động lực gắn bó với người lao động với tập thể góp phần thúc đẩy sản xuất kinh doanh phát triển.
_b. Vận động, tổ chức công nhân lao động trong tổ hưởng ứng các phong trào thi đua do công đoàn cơ sở tổ chức, phát động._
Thi đua là giải pháp quan trọng để khơi dạy mọi tiềm năng trong CNVC-LĐ, góp phần thúc đẩy sản xuất kinh doanh phát triển. Do vậy khi công đoàn cơ sở tổ chức phát động các phong trào thi đua, một mặt tổ công đoàn cần tuyên truyền vận động để mọi công nhân, lao động nhận thức rõ tầm quan trọng của công tác thi đua, lợi ích cá nhân, lợi ích tập thể và lợi ích xã hội của thi đua để cổ vũ nâng cao tinh thần trách nhiệm của tất cả các thành viên trong tổ nỗ lực tham gia thi đua. Mặt khác tổ trưởng công đoàn cần cùng các thành viên trong tổ bàn bạc tìm các giải pháp tổ chức thực hiện tốt các mục tiêu, nội dung của phong trào thi đua. Đồng thời thông qua việc tổ chức hưởng ứng các phong trào thi đua, tổ công đoàn lựa chọn những cá nhân điển hình tiên tiến để đề nghị động viên, khen thưởng kịp thời và để tuyên truyền nhân rộng các điển hình tiên tiến.
_2.3. Chỉ đạo đẩy mạnh công tác tuyên truyền, giáo dục nâng cao năng lực làm chủ cho CNVC-LĐ._
Tuyên truyền giáo dục công nhân lao động là chức năng của tổ chức Công đoàn, các cấp công đoàn cần quan tâm tổ chức thực hiện tốt chức năng này. Đối với tổ công đoàn, tổ trưởng công đoàn cần quan tâm chỉ đạo công tác tuyên truyền, giáo dục tập trung vào một số nội dung chủ yếu sau:
_a). Tuyên truyền, phổ biến chủ trương, đường lối của Đảng, nghị quyết của cấp ủy Đảng của công đoàn cấp trên, chính sách, pháp luật của Nhà nước có liên quan đến quyền lợi, nghĩa vụ của công nhân, lao động._
Tổ trưởng công đoàn cần tập trung tuyên truyền, phổ biến những quy định của Bộ luật Lao động, Luật Bảo hiểm xã hội liên quan đến quyền lợi, nghĩa vụ của người lao động, tuyên truyền, phổ biến nội dung của Thỏa ước lao động, các nội quy, quy chế ở cơ quan, đơn vị, để mọi thành viên trong tổ nắm vững và tự giác phấn đấu thực hiện nhiệm vụ được quy định trong nội quy, quy chế và trong Thỏa ước lao động tập thể. Đồng thời để công nhân, lao động trong tổ tự bảo vệ quyền và lợi ích của mình khi bị vi phạm.
- Cần tuyên truyền, phổ biến về vị trí, vai trò, chức năng của công đoàn, quyền lợi nghĩa vụ của đoàn viên công đoàn, sự cần thiết phải gia nhập công đoàn và tham gia hoạt động công đoàn, nhằm nâng cao tinh thần tự giác của công nhân, lao động đối với việc gia nhập công đoàn và tự giác tham gia hoạt động công đoàn.
Tuyên truyền vận động công nhân lao động trong tổ chấp hành nghiêm chế độ chính sách của Nhà nước, nội quy, quy chế của cơ quan, doanh nghiệp, phấn đấu lao động với năng xuất, chất lượng, hiệu quả ngày càng cao, tích cực tham gia đời sống văn hóa, đấu tranh phòng chống các tệ nạn xã hội, xây dựng tập thể đoàn kết, thương yêu, đùm bọc lẫn nhau.
_b. Vận động, giúp đỡ công nhân, viên chức học tập nâng cao trình độ học vấn, chuyên môn, nghiệp vụ._
Học tập nâng cao trình độ học vấn chuyên môn nghề nghiệp đáp ứng được yêu cầu sự nghiệp công nghiệp hóa, hiện đại hóa và hội nhập kinh tế quốc tế là yêu cầu khách quan và nhiệm vụ cấp bách của mỗi người, mỗi tập thể trong giai đoạn hiện nay. Đối với người lao động thực chất của việc học tập nâng cao trình độ học vấn, chuyên môn nghề nghiệp là để có điều kiện thực hiện tốt hơn nhiệm vụ được giao, để giữ được việc làm ổn định và nâng cao thu nhập. Tổ trưởng công đoàn, cần quan tâm tuyên truyền, vận động để công nhân lao động nhận thức được lợi ích của việc học tập, cổ vũ mọi công nhân lao động tự giác khắc phục khó khăn, phấn đấu học tập nâng cao trình độ. Mặt khác tổ trưởng công đoàn cần quan tâm vận động, tổ chức công nhân lao động trong tổ giúp đỡ, tạo điều kiện cho nhau học tập nâng cao trình độ học vấn, chuyên môn nghề nghiệp. Tổ trưởng công đoàn cần đề xuất, kiến nghị người sử dụng lao động quan tâm, tạo điều kiện về thời gian, về vật chất để mọi công nhân lao động được học tập đồng thời đề xuất những biện pháp khích lệ kịp thời về tinh thần nhằm khuyến khích, động viên công nhân, lao động trong tổ học tập nâng cao trình độ.
_c) Vận động, tổ chức đoàn viên, công nhân, viên chức, lao động tham gia các hoạt động như:_ Văn nghệ, thể thao, tham quan, du lịch, các hoạt động vui chơi giải trí, các hoạt động nhằm đấu tranh ngăn chặn các tệ nạn xã hội, nhằm cải thiện đời sống tinh thần cho công nhân, viên chức, lao động góp phần nâng cao dân trí, xây dựng môi trường sống, làm việc lành mạnh.
_2.4. Phân công đoàn viên hoạt động:_
Sức mạnh của tổ công đoàn là chỗ thu hút được đông đảo công nhân lao động trong tổ tự giác gia nhập công đoàn và tham gia hoạt động công đoàn. Nên căn cứ để đánh giá kết quả hoạt động của tổ công đoàn là chỗ tổ công đoàn có thu hút được đông đảo công nhân, lao động gia nhập công đoàn và gắn bó với tổ chức công đoàn không.
Do vậy trong tổ chức hoạt động tổ công đoàn, tổ trưởng công đoàn cần chú trọng công tác phân công đoàn viên hoạt động. Khi phân công đoàn viên hoạt động, tổ công đoàn cần căn cứ vào năng lực, sở trường của từng đoàn viên để phân công công việc cho phù hợp.
Nội dung công tác phân công đoàn viên đảm nhận một, hay một vài nội dung hoạt động công đoàn:
_Một là:_
_Hai là:_ Thường xuyên kiểm tra, đôn đốc, giúp đỡ đoàn viên hoạt động để thực hiện tốt những nội dung hoạt động đã được phân công.
_Ba là:_
_Bốn là:_ Đề xuất với công đoàn cơ sở, khen thưởng những cá nhân, tập thể đạt kết quả hoạt động xuất sắc ở tổ công đoàn.
* Trong các định hướng nội dung cơ bản về tổ chức hoạt động của tổ trưởng công đoàn nêu trên tổ trưởng công đoàn trong các thành phần kinh tế, các loại hình cơ sở cần nghiên cứu vận dụng linh hoạt, sáng tạo cho phù hợp với đặc điểm cụ thể của đơn vị mình, tổ mình, nhằm vận động, tập hợp đông đảo đoàn viên nổ lực lao động, sản xuất và tham gia công tác công đoàn, góp phần tạo nên sức mạnh đồng thuận vượt qua mọi khó khăn gian khổ góp phần thực hiện tốt chức năng, nhiệm vụ của công đoàn và hoàn thành xuất sắc nhiệm vụ sản xuất, kinh doanh.
II. PHƯƠNG PHÁP HOẠT ĐỘNG CỦA TỔ TRƯỞNG CÔNG ĐOÀN.
Để tổ trưởng công đoàn hoạt động tốt chức năng nhiệm vụ của mình, góp phần xây dựng tổ công đoàn không ngừng lớn mạnh. Trong tổ chức hoạt động, tổ trưởng công đoàn cần nắm vững và vận dụng linh hoạt, sáng tạo các phương pháp hoạt động cơ bản sau:
1. Liên hệ chặt chẽ với đoàn viên, CNVC-LĐ:
Công đoàn là tổ chức quần chúng rộng lớn của CNVC-LĐ, do vậy liên hệ chặt chẽ với đoàn viên, CNVC-LĐ là yêu cầu không thể thiếu được đối với bất kỳ cán bộ công đoàn nào. Đặc biệt đối với tổ trưởng công đoàn người trực tiếp đại diện cho đoàn viên, công nhân, lao động trong tổ, người trực tiếp vận động, tổ chức đoàn viên tham gia hoạt động công đoàn, thì liên hệ chặt chẽ với đoàn viên trong tổ để hiểu người, rõ việc, nắm được tâm tư, nguyện vọng và những bức xúc của đoàn viên, CNVC-LĐ là phương pháp hoạt động quan trọng, quyết định đến chất lượng, hiệu quả hoạt động của tổ công đoàn. Do vây trong tổ chức hoạt động cũng như trong sinh hoạt, tổ trưởng công đoàn cần đặc biệt quan tâm đến phương pháp hoạt động này, để nắm được tình hình thực tế trong tổ, cùng nhau dân chủ bàn bạc giải quyết những công việc trong tổ, hoặc phản ánh với công đoàn cơ sở giải quyết những tâm tư nguyện vọng và bức xúc của đoàn viên, công nhân, lao động, nhằm tạo nên sức mạnh tổng hợp của tổ để thực hiện tốt nhiệm vụ được giao.
Trong tổ chức hoạt động, tổ trưởng công đoàn cần có sổ công tác công đoàn, để theo dõi những nội dung, chương trình kế hoạch hoạt động của tổ trong từng thời gian cụ thể, theo dõi việc đoàn viên thực hiện những nội dung công việc đã được phân công, để nắm được những nội dung nào đã tổ chức thực hiện, những nội dung nào chưa tổ chức thực hiện, những mặt còn tồn tại, hạn chế trong quá trình tổ chức hoạt động, cần tiếp tục tháo gỡ. Thực tế trong tổ chức hoạt động công đoàn cho thấy, nếu tổ trưởng công đoàn nào có sổ công tác công đoàn và tiến hành ghi chép một cách chi tiết, khoa học những nội dung chương trình, kế hoạch công tác của tổ công đoàn thì hoạt động của tổ trưởng đó có chất lượng, hiệu quả vì vậy tổ công đoàn ở đó càng mạnh.
2. Xây dựng chương trinh, kế hoạch hoạt động của tổ công đoàn theo tháng, quý.
Tổ chức hoạt động theo chương trình, kế hoạch hoạt động là phương pháp tổ chức hoạt động khoa học, nó giúp cho hoạt động không bị chồng chéo, bỏ sót những nội dung cần tập trung tổ chức hoạt động, đồng thời giúp cho công đoàn có thể tập trung được những nội dung hoạt động trọng tâm trong từng thời gian cụ thể.
- Để tổ chức hoạt động của tổ công đoàn được tiến hành thường xuyên có kế hoạch, đạt hiệu quả cao, đáp ứng được yêu cầu nhiệm vụ đặt ra trong từng thời gian cụ thể, tổ trưởng công đoàn cần quan tâm xây dựng chương trình, kế hoạch hoạt động cụ thể.
Khi xây dựng chương trình, kế hoạch hoạt động của tổ công đoàn, tổ trưởng cần căn cứ vào chỉ đạo hướng dẫn của công đoàn bộ phận, công đoàn cơ sở căn cứ vào yêu cầu, nhiệm vụ đặt ra cho tổ trong từng thời gian cụ thể, trên cơ sở đó xác định rõ những nội dung và thời điểm tổ công đoàn cần tổ chức hoạt động. Khi đề ra nội dung hoạt động công đoàn ở từng thời điểm, tổ trưởng công đoàn cần xác định rõ mục tiêu cụ thể của việc thực hiện nội dung đó, các phương pháp tổ chức hoạt động để thực hiện các nội dung hoạt động và phân công người chịu trách nhiệm chính đối với từng nội dung hoạt động tổ công đoàn, cụ thể như: nội dung tổ chức sinh nhật cho đoàn viên, thì trong tháng có mấy đoàn viên sinh nhật, hình thức tổ chức sinh nhật như thế nào, ai chịu trách nhiệm tổ chức?... Đối với nội dung vận động đoàn viên thi đua lao động, sản xuất, cần cụ thể nội dung thi đua, mục tiêu của thi đua, thời gian diễn ra thi đua, ai chịu trách nhiệm chủ yếu trong tổ chức theo dõi thi đua…
- Tổ trưởng công đoàn phải thường xuyên kiểm tra, đôn đốc và có biện pháp hướng dẫn, giúp đỡ đoàn viên thực hiện chương trình, kế hoạch công tác theo đúng tiến độ. Cần gần gũi đoàn viên, nắm được những khó khăn, thuận lợi của đoàn viên khi thực hiện nhiệm vụ được giao, đánh giá đúng kết quả công tác của đoàn viên, CNVC-LĐ của nhóm đoàn viên, để động viên khích lệ kịp thời những đoàn viên tích cực hoạt động có hiệu quả, có biện pháp giúp đỡ, uốn nắn những hoạt động lệch lạc, chưa có hiệu quả của đoàn viên…
3. Duy trì sinh hoạt tổ công đoàn đều đặn.
Sinh hoạt tổ công đoàn có nề nếp sẽ tạo được bầu không khí dân chủ, tập hợp được trí tuệ của các thành viên trong tổ để tổ chức hoạt động. Đồng thời tạo cho mọi đoàn viên gắn bó với tổ, nâng cao tinh thần trách nhiệm trong tham gia hoạt động công đoàn.
Do vậy tổ trưởng công đoàn là người đứng đầu tổ công đoàn, cần có biện pháp cụ thể để duy trì nề nếp sinh hoạt tổ công đoàn và cần chú trọng đổi mới nội dung, phương pháp sinh hoạt để sinh hoạt tổ công đoàn thực sự hấp dẫn, thiết thực đối với đoàn viên. Muốn vậy tổ trưởng công đoàn cần nắm và vận dụng linh hoạt tổ công đoàn chủ yếu sau:
- Sinh hoạt định kỳ: Là hình thức sinh hoạt được tiến hành theo đúng định kỳ quy định, như sinh hoạt theo tháng, quý. Khi tiến hành sinh hoạt tổ công đoàn theo định kỳ, tổ trưởng công đoàn có trách nhiệm chuẩn bị kỹ chương trình, nội dung sinh hoạt, chuẩn bị báo cáo kết quả hoạt động của tổ công đoàn thời gian qua, phương hướng, nhiệm vụ hoạt động của tổ trong thời gian tới. Tổ trưởng công đoàn có trách nhiệm chủ trì để đoàn viên thảo luận, đánh giá kết quả hoạt động của tổ công đoàn theo nội dung chương trình đã đề ra, bàn quyết định chương trình, kế hoạch hoạt động tổ công đoàn thời giam tới. Khi điều hành sinh hoạt tổ công đoàn, tổ trưởng công đoàn cần khéo léo đặt vấn đề, gợi mở vấn đề để khuyến khích đoàn viên phát biểu, cần chú ý hướng các ý kiến phát biểu của đoàn viên vào những vấn đề trọng tâm. Đặc biệt khi chủ trì sinh hoạt tổ công đoàn, phải chú ý tạo được bầu không khí dân chủ cởi mở.
- Sinh hoạt triển khai thực hiện chương trình công tác của công đoàn cấp trên, là hình thức sinh hoạt để nghe phổ biến và bàn biện pháp triển khai chương trình, kế hoạch công tác của công đoàn cấp trên.
Để tổ chức tốt hình thức sinh hoạt này, tổ trưởng cần nghiên cứu kỹ chương trình, kế hoạch công tác (nghị quyết) của công đoàn cơ sở, công đoàn bộ phận, xác định rõ nhiệm vụ cụ thể nào tổ công đoàn phải có trách nhiệm triển khai thực hiện, yêu cầu cần đạt được khi tổ chức triển khai thực hiện nhiệm vụ, tiến độ (thời gian) thực hiện. Trên cơ sở đó tổ trưởng công đoàn đề xuất nội dung, phương pháp, biện pháp tổ chức hoạt động tổ công đoàn và dự kiến phân công đoàn viên thực hiện, để đưa ra tổ dân chủ thảo luận…
- Trao đổi trực tiếp giữa tổ trưởng, tổ phó với đoàn viên, CNVC-LĐ trong tổ.
Hình thức sinh hoạt này nếu được áp dụng thường xuyên sẽ có tác dụng quan trọng đến việc đôn đốc, giúp đỡ và nâng cao tinh thần trách nhiệm của đoàn viên, CNVC-LĐ trong thực hiện tốt nhiệm vụ được giao. Để việc trao đổi giữa tổ trưởng, tổ phó công đoàn với đoàn viên có kết quả, trước khi tiến hành trao đổi tổ trưởng công đoàn cần lựa chọn trước những vấn đề cần đưa ra cho phù hợp và có hiệu quả, thường có các cuộc trao đổi sau trong tổ công đoàn:
+ Hội ý trao đổi với đoàn viên, CNVC-LĐ (hoặc nhóm đoàn viên, CNVC-LĐ) nhằm bàn biện pháp tháo gỡ khó khăn trong quá trình tổ công đoàn triển khai thực hiện nhiệm vụ được giao.
+ Hội ý, trao đổi với đoàn viên để giải quyết các khó khăn, vướng mắc trong việc thực hiện các nhiệm vụ của đoàn viên, CNVC-LĐ đã được phân công, hoặc bàn giao tháo gỡ những vướng mắc trong nội bộ tổ công đoàn.
+ Hội ý, trao đổi với đoàn viên, để thống nhất đánh giá kết quả hoạt động của tổ công đoàn, thống nhất đề xuất, kiến nghị với công đoàn cơ sở, công đoàn bộ phận để thống nhất đề xuất giải quyết những vướng mắc, đề xuất biểu dương khen thưởng những đoàn viên. CNVC-LĐ hoạt động xuất sắc.
Trên đây là các định hướng nội dung, phương pháp hoạt động cơ bản của tổ trưởng công đoàn trong tổ chức hoạt động thực tiễn. Tổ trưởng công đoàn cần nghiên cứu, vận dụng linh hoạt, sáng tạo cho thích hợp với điều kiện công tác của đơn vị mình nhằm đem lại hiệu quả cao.
4. Hội nghị tổ công đoàn.
Theo Điều lệ công đoàn Việt Nam khóa X tổ công đoàn, tổ nghiệp đoàn mỗi năm tổ chức hội nghị toàn thể một lần, để tổng kết đánh giá hoạt động của tổ công đoàn, đề ra chương trình, kế hoạch hoạt động trong năm tiếp theo và bầu tổ trưởng, tổ phó công đoàn.

## Trao trả tài sản đánh rơi của thân nhân bệnh nhân ngày 04/06/2023

Vào ngày 04/6/2023, Trong quá trình đi tuần tra an ninh bệnh viện, nhân viên an ninh phát hiện điện thoại đánh rơi tại khu vực hành lang khoa Thận - Lọc máu và khoa Ngoại Thận. Qua nghiệp vụ của mình, Bộ phận an ninh đã trình báo lên Ban Giám đốc và tiến hành xác minh chủ sở hữu của tài sản là của anh T.T.Hòa và chị V.T.Thúy
Sau khi liên hệ được anh Hòa và chị Thúy, Bộ phận an ninh đã trao trả lại cho anh chị.
**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/) **- Đa khoa Hạng I Thành phố Hồ Chí Minh
[facebook.com/BVNTP](http://facebook.com/BVNTP)
[youtube.com/bvntp](http://youtube.com/bvntp)

## Trao trả tài sản đánh rơi của thân nhân bệnh nhân ngày 02/06/2023

Vào ngày 02/6/2023, Trong quá trình đi tuần tra an ninh bệnh viện, nhân viên an ninh phát hiện điện thoại đánh rơi tại khu vực hành lang lối đi khu D và C. Qua nghiệp vụ của mình, Bộ phận an ninh đã trình báo lên Ban Giám đốc và tiến hành xác minh chủ sở hữu của tài sản là của anh P.N.H.Thịnh
Sau khi liên hệ được anh Thịnh, Bộ phận an ninh đã trao trả lại cho anh
**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/) **- Đa khoa Hạng I Thành phố Hồ Chí Minh
[facebook.com/BVNTP](http://facebook.com/BVNTP)
[youtube.com/bvntp](http://youtube.com/bvntp)

## Trao trả tài sản đánh rơi của thân nhân bệnh nhân ngày 17/5/2023

Vào ngày 17/5/2023, Trong quá trình đi tuần tra an ninh bệnh viện, nhân viên an ninh phát hiện điện thoại đánh rơi tại khoa Tại Mũi Họng. Qua nghiệp vụ của mình, Bộ phận an ninh đã trình báo lên Ban Giám đốc và tiến hành xác minh chủ sở hữu của tài sản là của anh M.N.Thanh
Sau khi liên hệ được anh Vũ, Bộ phận an ninh đã trao trả lại cho bệnh nhân.
**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/) **- Đa khoa Hạng I Thành phố Hồ Chí Minh

## Ban Giám đốc - Đảng ủy Sở Y tế - Công đoàn ngành xuống thăm hỏi và động viên các Đoàn viên Công đoàn Bệnh viện Nguyễn Tri Phương

Nhân kỷ niệm 68 năm ngày Thầy thuốc Việt Nam (27.2.1955 - 27.2.2023), Sáng ngày 16/02/2023, Ban Giám đốc - Đảng ủy Sở Y tế - Công đoàn ngành Y tế đến thăm hỏi, động viên các Đoàn viên Công đoàn Bệnh viện Nguyễn Tri Phương mắc bệnh nan y.
Đồng thời, Đoàn đại biểu cũng gửi lời chúc mừng và động viên đến toàn bộ đội ngũ cán bộ, nhân viên Bệnh viện Nguyễn Tri Phương; tin tưởng cán bộ, đoàn viên trong ngành tiếp tục cố gắng vượt mọi khó khăn, nỗ lực lao động giỏi, lao động sáng tạo để hoàn thành tốt nhiệm vụ được giao.
**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/) **- Đa khoa Hạng I Thành phố Hồ Chí Minh

## Bệnh viện cảm ơn các Ban ngành, Đơn vị đến thăm bệnh viện nhân dịp kỷ niệm ngày Thầy thuốc Việt Nam 27/02/2023

Nhân dịp kỷ niệm ngày Thấy thuốc Việt Nam 27/02, Ban lãnh đạo các Ban ngành, Đơn vị đã đến thăm và chúc mừng ngày truyền thống, tôn vinh những người làm trong ngành Y tế. 
Bệnh viện chân thành cảm ơn những lời quan tâm, thăm hỏi, động viên đối với đội ngũ nhân viên y tế, và cả những sẻ chia chân thành với những khó khăn nhọc nhằn mang tính đặc thù của nghề nghiệp. 
Có lẽ chưa một lãnh tụ nào trên thế giới đưa ra lời dạy quan hệ giữa thầy thuốc với người bệnh là quan hệ 'lương y như từ mẫu' như Chủ tịch Hồ Chí Minh. Hải Thượng Lãn Ông cũng nói về nghề thầy thuốc nhưng là kê bảy tội của thầy thuốc trong đó tội thứ bảy là tội dốt. Gam-bi-ơ người Pháp cũng nói 'bất hạnh nhất cho người bệnh là gặp phải người thầy thuốc dốt chữa bệnh cho mình'. Chính vì vậy, lời khuyên bảo của Bác vừa nhân ái, vừa sâu sắc lại dễ hiểu, vì muốn làm mẹ hiền thì một trong những tiêu chí quan trọng phải là thầy thuốc giỏi. Khi Bác nói thương yêu người bệnh như 'mẹ hiền thương con' thì đó là chữ Nhân của người thầy thuốc phải đứng lên hàng đầu. Ðó chính là sự đúc kết sau khi Người đã đi chiêm nghiệm ở khắp năm châu, chứng kiến được nhiều cuộc đời đau khổ của những người vướng phải căn bệnh hiểm nghèo, Người đã đúc kết lại và nêu được hình tượng cho ngành y tế Việt Nam là 'lương y như từ mẫu'. Nghề y là nghề 'đặc biệt', có thể nói nó là 'dây chuyền công nghệ cao' vì tính mạng con người khâu nào cũng quan trọng, nên tất cả phải đoàn kết một lòng. Bác dạy: 'Từ các Bộ trưởng, Thứ trưởng, bác sĩ, dược sĩ cho đến các anh chị em giúp việc. Bởi vì công việc và địa vị tuy có khác nhau, nhưng người nào cũng là một bộ phận cần thiết trong ngành y tế, trong việc phục vụ nhân dân...'. Lời Bác nhắc nhở để mỗi người thầy thuốc chúng ta không thể quên tính quan trọng hàng đầu của bài học đoàn kết, trong công việc và thủ trưởng phải quý trọng nhân viên đồng nghiệp mới làm nên chuyện lớn được...
Người thầy thuốc thường mất ăn mất ngủ trước một ca bệnh lý, thường bứt rứt ăn năn dài lâu trước một lỡ lầm đôi khi không sao tránh khỏi trong lúc hành nghề. Tập thể thầy thuốc luôn mong nhận được sự tôn trọng và đánh giá đúng sự đóng góp của mình để giúp họ sống xứng đáng với vai trò, chức năng mà xã hội đã giao phó.
_Đảng Ủy Bộ Tư Lệnh Thành phố Hồ Chí Minh_
_Quận ủy - UBND Quận 8, Tp. Hồ Chí Minh_
_Đảng Uỷ - UBND Quận 5 Tp. Hồ Chí Minh_
_Đoàn Lãnh đạo Sở Công Thương Tp. Hồ Chí Minh_
_và còn nhiều các tổ chức, đoàn thể khác..._
**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/) **- Đa khoa Hạng I Thành phố Hồ Chí Minh

## Đảng ủy Bộ tư lệnh Thành phố ghé thăm và chúc mừng Ngày thầy thuốc Việt Nam

Ngày này cách đây 68 năm, Bác Hồ kính yêu của chúng ta đã viết thư gửi Hội nghị cán bộ y tế toàn quốc, Bác đã ân cần thăm hỏi, dành sự quan tâm đặc biệt đối với cán bộ y tế, đồng thời Bác cũng đã căn dặn: “phải thương yêu người bệnh; người bệnh phó thác tính mạng của họ với các cô, các chú; chính phủ phó thác cho các cô các chú việc chữa bệnh tật và giữ gìn sức khoẻ của đồng bào. Đó là một nhiệm vụ rất vẻ vang. Vì vậy, cán bộ y tế cần phải thương yêu chăm sóc người bệnh như anh em ruột thịt của mình; coi họ đau đớn cũng như mình đau đớn; lương y phải như từ mẫu” vẫn vang vọng, thấm sâu trong tâm trí của những người thầy thuốc Việt Nam.
Đây là dịp để chúng ta tiếp tục bày tỏ sự trân trọng, tôn vinh và cảm ơn những người thầy thuốc Việt Nam. Càng tự hào về truyền thống vẻ vang và những thành tựu to lớn mà ngành Y tế nước ta đã đạt được, chúng ta càng nỗ lực phấn đấu nhiều hơn nữa, vượt qua mọi khó khăn mọi thách thức, ra sức khắc phục những hạn chế yếu kém, tiếp tục xây dựng ngành Y tế Việt Nam ngày càng vững mạnh, đáp ứng cao hơn, tốt hơn nữa nhu cầu bảo vệ, chăm sóc và nâng cao sức khỏe của nhân dân, để xứng đáng với sự hy sinh, phấn đấu của các thế hệ thầy thuốc Việt Nam, xứng đáng niềm tin yêu của Đảng, Nhà nước và nhân dân.
Ngày Thầy thuốc Việt Nam không chỉ là ngày tôn vinh nghề thầy thuốc, mà còn là ngày nhắc nhở mọi người hãy sẻ chia với những khó khăn của ngành Y tế. Chúng ta vẫn có thể tôn vinh các thầy thuốc bằng cái nhìn thiện cảm hơn, biểu dương những việc làm tốt của họ, khuyến khích họ sáng tạo và có các giải pháp hữu hiệu bảo vệ các thầy thuốc chân chính. Sự đồng cảm, chia sẻ của người bệnh, của Nhân dân là liều thuốc tiếp thêm sức mạnh cho các lực lượng y tế vững lòng thực hiện sứ mệnh cao cả bảo vệ, chăm sóc và nâng cao sức khỏe nhân dân.

## Công đoàn Bệnh viện Nguyễn Tri Phương tổ chức chương trình ngày 8/3/2023

Nằm trong chuỗi sự kiện chào mừng ngày Quốc tế Phụ nữ 8.3 và phát động phong trào thi đua " Giỏi việc nước, đảm việc nhà", sáng nay Công đoàn Bệnh viện Nguyễn Tri Phương đã tổ chức chương trình Gian hàng ẩm thực.
Trong không khí tươi vui, rất nhiều món hàng thơm ngon và đẹp mắt đã được bày bán với giá cả phải chăng. Một phần kinh phí thu được sẽ trích ra để trao tặng cho Công đoàn viên khó khăn nhằm tiếp thêm động lực và sự sẻ chia từ mọi người.

## BV Nguyễn Tri Phương thành công tổ chức đại hội Công đoàn cơ sở nhiệm kỳ 2023-2028

Thực hiện Kế hoạch số 150/KH-CĐNYT của Công đoàn Ngành Y tế Thành phố về tổ chức Đại hội Công đoàn cơ sở tiến tới Đại hội XIII Công đoàn Ngành Y tế Thành phố Hồ Chí Minh nhiệm kỳ 2023 - 2028;
Nhằm tổng kết đánh giá phong trào và hoạt động công đoàn trong nhiệm kỳ qua, nêu bật những thành tích đã đạt được, chỉ rõ những nguyên nhân tồn tại, yếu kém, từ đó rút ra những bài học kinh nghiệm và trên cơ sở đó đề ra phương hướng, nhiệm vụ trọng tâm, giải pháp cụ thể để thực hiện trong thời gian tới, đồng thời phát huy trí tuệ, dân chủ, thảo luận, bàn bạc, bầu ra BCH nhiệm kỳ mới đầy đủ phẩm chất, năng lực, đưa hoạt động công đoàn lên một bước mới.
Được sự cho phép của Ban Thường vụ Công đoàn ngành y tế Thành phố và Đảng ủy bệnh viện Nguyễn Tri Phương, ngày 29/3/2023, Công đoàn cơ sở bệnh viện Nguyễn Tri Phương long trọng tổ chức Đại hội lần thứ XVIII, nhiệm kỳ 2023-2028 
Ban chấp hành Công đoàn bệnh viện Nguyễn Tri Phương, lần thứ XVIII, nhiệm kỳ 2023 -2028 đã bầu ra BCH Công đoàn bệnh viện Nguyễn Tri Phương, lần thứ XVIII, nhiệm kỳ 2023 -2028 là 15 đ/c, với cơ cấu như sau:
- Chủ Tịch: 01 đ/c
- Phó chủ tịch: 01 đ/c
- Ban thường vụ : 05 đ/c
Đại hội cũng đã tiến hành bầu Đoàn đại biểu đi dự Đại hội Công đoàn Ngành Y tế nhiệm kỳ 2023-2028 gồm 07 đồng chí
Một số thành viên BCH nhiệm kỳ cũ đã thôi không còn tham gia cùng BCH Công đoàn nhiệm kỳ mới, đã nhận phần quà tri ân từ Đại hội và rất nhiều tình cảm từ đại biểu

## Đoàn Lãnh đạo Trung ương Hội Chữ Thập Đỏ và Thành phố đến thăm đơn vị điển hình trong hoạt động xã hội nhân đạo năm 2022

Chiếu ngày 13/01/2023, Đoàn Lãnh đạo Trung ương Hội Chữ Thập Đỏ và Thành Phố đến thăm hỏi và trao quà tết cho BV Nguyễn Tri Phương là một trong các đơn vị điển hình trong hoạt động xã hội nhân đạo năm 2022.
Tham dự Đoàn gồm có:
  * Đồng chí Bùi Thị Hòa - Bí thư Đảng Đoàn - Chủ tích Trung ương Hội Chữ thập đỏ Việt Nam;
  * Đồng chí Lương Thị Hồng Thúy - Trưởng Ban Đối ngoại và Phát triển Trung ương Hội;
  * Đồng Chí Trần Trường Sơn - Chủ tịch Hội Chữ thập đỏ Thành phố
  * Đại diện các ban, Văn phòng Thành Hội.


Tiếp đón đoàn có Ban Giám đốc Bệnh viện cùng lãnh đạo các khoa/phòng tham dự.
Mở đầu chương trình, Bác sĩ CK2 Võ Đức Chiến trình bày tóm tắt kết quả hoạt động trong năm 2022. Qua đó Bác sĩ CK2 Võ Đức Chiến cũng gửi lời cảm ơn đến Lãnh đạo Trung ương và Thành phố và các mạnh thường quân đã hỗ trợ, đồng hành cũng Bệnh viện trong công tác nhân đạo, đặc biệt trong giai đoạn dịch Covid-19 hoành hành. Chính vì điều đó đã giúp cho bệnh viện cũng như các y bác sĩ có thêm động lực chung tay phòng chống dịch bệnh.
Qua báo cáo công tác hoạt động chữ thập đỏ năm 2022 của Bác sĩ Chuyên khoa II Võ Đức Chiến, Đoàn Lãnh đạo Trung ương và Thành phố chúc mừng bệnh viện đã hoàn thành xuất sắc trong công tác chữ thập đỏ.
Đoàn công tác cũng đã chúc tết và tặng quà đến Ban Giám đốc, Ban lãnh đạo cùng toàn thể nhân viên bệnh viện một năm mới mạnh khoẻ, bình an, hạnh phúc đến tập thể y bác sĩ; hy vọng năm mới Bệnh viện sẽ tiếp tục gắn kết để phát triển, có nhiều bước tiến mới, thành công mới, góp phần trong công tác chăm sóc, bảo vệ sức khoẻ người dân thành phố.
**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/) **- Đa khoa Hạng I Thành phố Hồ Chí Minh

## Tấm lòng cộng đồng - Nẻo về của tình người

Xuân Quý Mão 2023 đang đến gần và chúng ta đang chứng kiến những giây phút thiêng liêng cuối cùng của năm cũ - một năm mọi thứ dần chuyển mình hồi phục sau đại dịch COVID-19. 365 ngày vừa qua, dù còn nhiều thách thức chất chồng, nhưng các bệnh nhân có hoàn cảnh khó khăn và nhân viên y tế không hề đơn độc. Chúng tôi còn có sự đồng hành, tin tưởng và ủng hộ quý báu của những mạnh thường quân, những tấm lòng thiện nguyện, từ tâm vì cộng đồng. Đó là một điểm sáng, một may mắn mà chúng tôi có được trong giai đoạn đầy chông gai.
Chủ tịch Hồ Chí Minh - Chủ tịch Danh dự Đầu tiên của Hội Chữ thập đỏ Việt Nam – từng chia sẻ với cán bộ, hội viên, tình nguyện viên, thanh thiếu niên Chữ thập đỏ:**"Phải xuất phát từ tình yêu thương nhân dân tha thiết mà góp phần bảo vệ sức khỏe của nhân dân và làm mọi việc có thể làm được để giảm bớt đau thương cho họ...Không được có thái độ hách dịch, ban ơn, cần làm việc cho tốt, luôn chí công vô tư thì ít mắc sai lầm. Không nên thiên về hình thức, việc gì có lợi cho dân thì làm".** Và trong bối cảnh rối ren, tàn khốc của đại dịch, mỗi nhân viên y tế của bệnh viện Nguyễn Tri Phương nói riêng và cả nước nói chung đã là một địa chỉ đỏ của lòng nhân ái. 
Với đặc thù của ngành nghề và tinh thần trách nhiệm được hun đúc từ bên trong, mỗi nhân viên y tế chúng tôi đối với bệnh nhân luôn nỗ lực chăm sóc ân cần, nhẹ nhàng; đồng thời hướng đến việc điều trị hiệu quả cũng như sự hài lòng của người bệnh và thân nhân. Chúng tôi tin rằng sự thân thiện của đội ngũ y, bác sĩ và nhân viên toàn bệnh viện chính là cách để thực hành câu nói “Lương y như từ mẫu” mà Bác đã dặn dò, gửi gắm đến tập thể y bác sĩ. Bên cạnh đó, chúng tôi cũng mong mỏi mỗi nhân viên y tế sẽ luôn giữ được hình ảnh đẹp nhất trong lòng bệnh nhân và thân nhân của họ.
Ngoài thân thiện, nhẹ nhàng với bệnh nhân nói chung, chúng tôi cũng tích cực quan tâm và hỗ trợ những bệnh nhân có hoàn cảnh khó khăn. Năm vừa qua, bệnh viện đã kêu gọi được các quỹ từ thiện như: Quỹ Từ Tâm, Quỹ Tâm Nguyện Việt, Quỹ Bông Sen, Nhóm Chia sẻ - Sharing, Ông Yung Cam Meng, Nhóm Tâm từ …
Không dừng lại ở đó, mỗi nhân viên y tế, cũng thể hiện sự quan tâm, lòng nhân ái của mình bằng những hàng động rất nhỏ. Họ sẵn lòng giúp đỡ cho bệnh nhân khó khăn qua chính những hoạt động công việc thường ngày: chăm sóc bệnh nhân miễn phí, đóng góp cho gian hàng yêu thương để chia sẻ với bệnh nhân khó khăn,… Trong khả năng của mình, mỗi nhân viên y tế đã đóng góp những giá trị tốt đẹp cho cộng đồng, cho người bệnh để ai nấy đều được thăm khám và chữa trị một cách tốt nhất có thể. Chúng tôi tin đôi khi việc cho đi dù là bất kì điều gì, dù bằng bất kì cách nào, chỉ cần xuất phát từ tấm lòng thì đều luôn rất đẹp.
Một trong những cảm xúc tốt nhất trên thế giới là “sống để cho đi”. Winston Churchill từng nói: “Chúng ta kiếm sống bằng thứ mà ta có nhưng chúng ta sống bằng những gì mà ta cho đi”. Quả thật, khi sự chia sẻ bắt nguồn từ tình cảm chân thành, người cho đi sẽ hạnh phúc hơn rất nhiều và năng lượng tích cực được lan tỏa rộng hơn đến cộng đồng. Chỉ với một hành động tử tế, bạn cũng có thể truyền cảm hứng cho những người khác và gieo những hạt giống hạnh phúc từ những món quà bạn đã cho đi, dù nhỏ nhặt nhất.
Xuân Quý Mão 2023 đang đến gần và chúng ta đang chứng kiến những giây phút thiêng liêng cuối cùng của năm cũ - một năm mọi thứ dần chuyển mình hồi phục sau đại dịch COVID-19. 365 ngày vừa qua, dù còn nhiều thách thức chất chồng, nhưng các bệnh nhân có hoàn cảnh khó khăn và nhân viên y tế không hề đơn độc. Chúng tôi còn có sự đồng hành, tin tưởng và ủng hộ quý báu của những mạnh thường quân, những tấm lòng thiện nguyện, từ tâm vì cộng đồng. Đó là một điểm sáng, một may mắn mà chúng tôi có được trong giai đoạn đầy chông gai.
Chủ tịch Hồ Chí Minh - Chủ tịch Danh dự Đầu tiên của Hội Chữ thập đỏ Việt Nam – từng chia sẻ với cán bộ, hội viên, tình nguyện viên, thanh thiếu niên Chữ thập đỏ: "Phải xuất phát từ tình yêu thương nhân dân tha thiết mà góp phần bảo vệ sức khỏe của nhân dân và làm mọi việc có thể làm được để giảm bớt đau thương cho họ...Không được có thái độ hách dịch, ban ơn, cần làm việc cho tốt, luôn chí công vô tư thì ít mắc sai lầm. Không nên thiên về hình thức, việc gì có lợi cho dân thì làm". Và trong bối cảnh rối ren, tàn khốc của đại dịch, mỗi nhân viên y tế của bệnh viện Nguyễn Tri Phương nói riêng và cả nước nói chung đã là một địa chỉ đỏ của lòng nhân ái. 
Với đặc thù của ngành nghề và tinh thần trách nhiệm được hun đúc từ bên trong, mỗi nhân viên y tế chúng tôi đối với bệnh nhân luôn nỗ lực chăm sóc ân cần, nhẹ nhàng; đồng thời hướng đến việc điều trị hiệu quả cũng như sự hài lòng của người bệnh và thân nhân. Chúng tôi tin rằng sự thân thiện của đội ngũ y, bác sĩ và nhân viên toàn bệnh viện chính là cách để thực hành câu nói “Lương y như từ mẫu” mà Bác đã dặn dò, gửi gắm đến tập thể y bác sĩ. Bên cạnh đó, chúng tôi cũng mong mỏi mỗi nhân viên y tế sẽ luôn giữ được hình ảnh đẹp nhất trong lòng bệnh nhân và thân nhân của họ.
Ngoài thân thiện, nhẹ nhàng với bệnh nhân nói chung, chúng tôi cũng tích cực quan tâm và hỗ trợ những bệnh nhân có hoàn cảnh khó khăn. Năm vừa qua, bệnh viện đã kêu gọi được các quỹ từ thiện như: Quỹ Từ Tâm, Quỹ Tâm Nguyện Việt, Quỹ Bông Sen, Nhóm Chia sẻ - Sharing (do Bà Mai Thị Hạnh - Phu nhân Nguyên Chủ Tịch Nước Trương Tấn Sang vận động), Ông Yung Cam Meng, Nhóm Tâm từ …
Không dừng lại ở đó, mỗi nhân viên y tế, cũng thể hiện sự quan tâm, lòng nhân ái của mình bằng những hàng động rất nhỏ. Họ sẵn lòng giúp đỡ cho bệnh nhân khó khăn qua chính những hoạt động công việc thường ngày: chăm sóc bệnh nhân miễn phí, đóng góp cho gian hàng yêu thương để chia sẻ với bệnh nhân khó khăn,… Trong khả năng của mình, mỗi nhân viên y tế đã đóng góp những giá trị tốt đẹp cho cộng đồng, cho người bệnh để ai nấy đều được thăm khám và chữa trị một cách tốt nhất có thể. Chúng tôi tin đôi khi việc cho đi dù là bất kì điều gì, dù bằng bất kì cách nào, chỉ cần xuất phát từ tấm lòng thì đều luôn rất đẹp.
Một trong những cảm xúc tốt nhất trên thế giới là “sống để cho đi”. Winston Churchill từng nói: “Chúng ta kiếm sống bằng thứ mà ta có nhưng chúng ta sống bằng những gì mà ta cho đi”. Quả thật, khi sự chia sẻ bắt nguồn từ tình cảm chân thành, người cho đi sẽ hạnh phúc hơn rất nhiều và năng lượng tích cực được lan tỏa rộng hơn đến cộng đồng. Chỉ với một hành động tử tế, bạn cũng có thể truyền cảm hứng cho những người khác và gieo những hạt giống hạnh phúc từ những món quà bạn đã cho đi, dù nhỏ nhặt nhất.
SỐNG LÀ ĐỂ CHO (tác giả Võ Đức Chiến)
SỐNG có tình thì sống ở mọi nơi
SỐNG không giận không buồn không nuối tiếc
SỐNG chân thật, sống hết mình, tha thiết
SỐNG làm sao để chẳng thẹn với lòng
LÀ vị tha, là chan chứa mênh mông
LÀ cõi ta bà mình đang gánh vác
LÀ chính mình, chứ chẳng là ai khác
LÀ NGƯỜI trần, dần phủ định chữ CON
ĐỂ dự phần với cay đắng ngọt ngon
ĐỂ góp phần xua nỗi đau nhân thế
ĐỂ chung sức để chung niềm san sẻ
ĐỀ lúc xa, không phải nói giá mà...
CHO chút TỪ TÂM giúp đỡ mọi nhà
CHO thấy cuộc đời dẫu là dâu bể
CHO tất cả những gì ta có thể
CHO bao nhiêu sầu khổ thoát đi dần...
Bằng những nỗ lực không ngơi nghỉ, tập thể y bác sĩ của toàn ngành y tế nói chung, TP.HCM và bản thân Bệnh viện Nguyễn Tri Phương nói riêng đã giúp nhiều bệnh nhân có hoàn cảnh khó khăn đã được chữa trị hồi phục và an toàn. Đó chính là động lực to lớn để chúng tôi luôn nỗ lực hướng tới một môi trường bệnh viện “năng động – thân thiện – phát triển.”, từ đó nâng cao chất lượng chất lượng khám, chữa bệnh để có được sự hài lòng của bệnh nhân và thân nhân của họ. Bởi người bệnh được chăm sóc an toàn, thoải mái khi tới khám và điều trị tại bệnh viện là tiền đề không thể thiếu của việc nâng cao chất lượng bệnh viện hiện nay.
Trong năm Quý Mão 2023, bản thân tôi cũng như tập thể nhân viên y tế ở mọi cơ sở y tế mong muốn tiếp tục nhận được sự đồng hành tốt đẹp của những tấm lòng vàng để vững tâm thực hiện sứ mệnh **_“Không để bệnh nhân có hoàn cảnh khó khăn đi một mình trong hành trị điều trị và hồi phục”_**.
Không chỉ bệnh viện Nguyễn Tri Phương, chúng tôi tin rằng khi lan tỏa sự tử tế và chăm lo cho người bệnh, bất cứ bệnh viện nào hay bất kỳ nhân viên y tế nào cũng có thể trở thành một bệnh viện năng động, thân thiện để phát triển. 
Một mùa Xuân lại về. Trong không khí tràn ngập sắc màu và sức sống mới, thay mặt Ban Giám đốc Bệnh viện Nguyễn Tri Phương, tôi xin gửi tới các tấm lòng hảo tâm, cũng như toàn thể đội ngũ nhân viên y tế, người lao động của bệnh viện và gia đình lời chúc năm mới. Chúc mọi người “Xuân sum vầy - Tết đủ đầy” và chân thành cảm ơn mọi người vì những gì mà mọi người đã cùng nhau “cho đi” trong suốt thời gian qua.

## Bệnh viện 30/4 tham quan và chia sẻ về sử dụng phần mềm quản lý tại Bệnh viện Nguyễn Tri Phương


## Trao trả tài sản đánh rơi của thân nhân bệnh nhân

Vào ngày 16/01/2023, Trong quá trình đi tuần tra an ninh bệnh viện, nhân viên an ninh phát hiện một chiếc điện thoại đánh rơi tại Khoa Hồi Sức Tích Cực. Qua nghiệp vụ của minh, Bộ phận an ninh đã trình báo lên Ban Giám đốc và tiến hành xác minh chủ sở hữu của tài sản là của anh H.V.Phương.
Sau khi liên hệ được anh Phương, Bộ phận an ninh đã trao trả lại cho anh. 
**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/) **- Đa khoa Hạng I Thành phố Hồ Chí Minh

## Hội nghị Kỷ niệm 93 năm thành lập Đảng Cộng Sản Việt Nam ngày 03/02/2023

Sáng ngày 03/02/2023, tại Hội trường bệnh viện, Đảng Ủy Bệnh viện Nguyễn Tri Phương tổ chức hội nghị kỷ niệm 93 năm thành lập Đảng Cộng Sản Việt Nam (03/02/1930 - 03/02/2023).
Đồng chí Bí thư Võ Đức Chiến - Giám đốc Bệnh viện phát biểu khai mạc hội nghị kỷ niệm 93 năm Ngày thành lập Đảng Cộng sản Việt Nam (03/02/1930 - 03/02/2023) là sự kiện có ý nghĩa hết sức quan trọng. Đây là dịp để đẩy mạnh công tác giáo dục truyền thống yêu nước, truyền thống cách mạng, giáo dục ý chí tự lực, tự cường của dân tộc; khẳng định quyết tâm đi theo con đường xã hội chủ nghĩa dưới sự lãnh đạo của Đảng Cộng sản Việt Nam; củng cố niềm tin của Nhân dân vào sự lãnh đạo của Đảng; tăng cường sức mạnh khối đại đoàn kết toàn dân tộc, sự đồng thuận trong xã hội đối với những chủ trương của Đảng, chính sách, pháp luật của Nhà nước.
> _Đồng chí Võ Đức Chiến - Bí thư Đảng ủy Bệnh viện - Giám đốc bệnh viện phát biểu khai mạc hội nghị._
Đến tham dự có đầy đủ các chị bộ cũng như các tổ chức đoàn thể trong Bệnh viện
Không chỉ đẩy mạnh công tác giáo dục truyền thống yêu nước, truyền thống cách mạng. Đảng ủy Bệnh viện Nguyễn Tri Phương còn khen thưởng đến các cá nhân, tập thể khoa, phòng đã có thành tích xuất sắc trong quá trình thực hiện nhiệm vụ tại đơn vị cũng như trong công tác phòng chống dịch nói chung và công tác trong đảng nói riêng.
Qua đó khích lệ tinh thần phấn đấu của các đồng chí đảng viên và tuyên truyền đến toàn thể nhân viên bệnh viện một tinh thần năng động, phấn đấu phát triển mạnh mẽ hơn.
_Bàn giao danh sách Đoàn viên công đoàn và Đoàn viên xuất sắc cho tổ chức Đảng_
_Khen thưởng 02 tập thể có thành tích xuất sắc_
_Khen thưởng 11 cá nhân có thành tích xuất sắc_
**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/) **- Đa khoa Hạng I Thành phố Hồ Chí Minh

## Bệnh viện Nguyễn Tri Phương chăm lo cho bệnh nhân có hoàn cảnh khó khăn

Bên cạnh phát triển và tăng cường công tác khám chữa bệnh, Ban Giám đốc Bệnh viện Nguyễn Tri Phương và tập thể nhân viên bệnh viện đều hướng tới một phương châm **“Sống có tình, đối xử tử tế và thật thân thiết với bệnh nhân, thân nhân, khách và giữa nhân viên với nhau”.**
Lời dạy của Chủ tịch Hồ Chí Minh - Chủ tịch danh dự đầu tiên của Hội Chữ thập đỏ Việt Nam đối với cán bộ, Hội viên, tình nguyện viên, thanh thiếu niên Chữ thập đỏ: "Phải xuất phát từ tình yêu thương nhân dân tha thiết mà góp phần bảo vệ sức khỏe của nhân dân và làm mọi việc có thể làm được để giảm bớt đau thương cho họ...Không được có thái độ hách dịch, ban ơn, cần làm việc cho tốt, luôn chí công vô tư thì ít mắc sai lầm. Không nên thiên về hình thức, việc gì có lợi cho dân thì làm".
Hội Chữ thập đỏ Bệnh viện Nguyễn Tri Phương cũng không nằm ngoài tôn chỉ của Chủ Tịch Hồ Chí Minh, Hội hoạt động vì mục tiêu nhân đạo - hòa bình - hữu nghị, góp phần thực hiện mục tiêu dân giàu, nước mạnh, xã hội công bằng, dân chủ, văn minh, vì hạnh phúc của nhân dân.
Hệ sinh thái chăm lo cho bệnh nhân có hoàn cảnh khó khăn của Bệnh viện Nguyễn Tri Phương bắt đầu từ khi bệnh nhân nhập viện cấp cứu cho đến suốt quá trình nằm viện điều trị, và thậm chí cả khi đưa tiễn một đoạn đường với “bệnh nhân nặng” xin về. 
Đối với bệnh nhân phải chăm sóc ân cần, nhẹ nhàng với kinh nghiệm trong khám và điều trị nhằm tạo niềm tin cũng như sự hài lòng của người bệnh, thân nhân. Sự thân thiện của đội ngũ y, bác sĩ và nhân viên toàn bệnh viện cũng là cách để luôn nhắc đến hình ảnh “Lương y như từ mẫu” mà Bác đã dặn dò, gửi gắm đến tập thể y bác sĩ. 
Thân thiện với bệnh nhân có hoàn cảnh khó khăn, bệnh viện đã kêu gọi được các quỹ từ thiện như: Quỹ Từ Tâm, Quỹ Tâm Nguyện Việt, Quỹ Bông Sen, Nhóm Chia sẻ - Sharing do Bà Mai Thị Hạnh - Phu nhân Nguyên Chủ Tịch Nước Trương Tấn Sang vận động, Ông Yung Cam Meng… 
Các tập thể và cá nhân có tấm lòng vàng đã cùng tham gia vào các hoạt động của Hội Chữ thập Đỏ Bệnh viện Nguyễn Tri Phương để giúp đỡ người bệnh có hoàn cảnh khó khăn được hỗ trợ viện phí trong quá trình nằm viện. Điều đặc biệt nữa là mỗi nhân viên của bệnh viện đều là hội viên của Hội chữ thập đỏ nên bất cứ cá nhân nào cũng ý thức, đóng góp và phát động từ thiện trong và ngoài bệnh viện.
**“Thương người như thể thương thân”, “Lá lành đùm lá rách”** là đạo lý truyền thống, giúp người lúc ngặt nghèo là việc làm nhân nghĩa. “Bát cơm, chén cháo từ thiện” ở các bệnh viện càng ngày càng phổ biến. Hầu hết tại những khu vực xung quanh các bệnh viện, chúng ta không hiếm gặp các nhóm lớn, nhóm nhỏ, cá nhân hay tập thể đến phát cơm từ thiện, nhiều phần cơm được phát nào là thùng cháo, bát mì, cơm… rất khó kiểm soát chất lượng nhất là an toàn vệ sinh thực phẩm. 
Chính vì vậy, để giảm bớt sự lo lắng của người nghèo song song với gánh nặng chi phí khám chữa bệnh, bữa ăn đối với bệnh nhân nghèo “chạy ăn từng bữa toát mồ hôi” càng thêm khốn khó cũng như để họ yên tâm điều trị, bệnh viện ngoài việc hỗ trợ chi phí điều trị cho người bệnh, bên cạnh đó còn chủ động cung cấp suất ăn dinh dưỡng và các bữa ăn bệnh lý với chất lượng được đảm bảo từ công ty cung cấp suất ăn với 100% vốn của Đức cho họ với mong muốn sức khỏe mau hồi phục để họ trở về với cộng đồng.
“Nghĩa tử là nghĩa tận”, tính thân thiện còn được thể hiện qua việc hỗ trợ xe miễn phí cho mỗi bệnh nhân hấp hối và tử vong về nhà (“Chuyến xe tiễn 1 đoạn đường”). Đó là trách nhiệm chia sẻ và động viên từ mỗi nhân viên của Bệnh viện Nguyễn Tri Phương đối với người thân có bệnh nhân hấp hối, tử vong.
Trong bất kỳ trường hợp nào cần thiết - quanh phạm vi Tp. Hồ Chí Minh, người nhà cần hỗ trợ xe đưa bệnh nhân tử vong xin về đều có thể liên hệ phòng Hành chính Quản trị và Hội Chữ thập đỏ - Bệnh viện Nguyễn Tri Phương. Từ năm 2016 đến nay, Bệnh viện Nguyễn Tri Phương đã hỗ trợ hàng ngàn “Chuyến xe đưa tiễn bệnh nhân một chặng đường”. 
Thông qua tinh thần nhân văn của “chuyến xe cuối”, tập thể Bệnh viện Nguyễn Tri Phương đã góp phần an ủi, động viên và chia sẻ niềm đau buồn với gần 3.495 gia đình bệnh nhân ở các địa phương như An Thới Đông, Bình Khánh huyện Cần Giờ, Củ Chi, Bình Chánh; Bến Lức tỉnh Long An, tỉnh Tiền Giang; quận 3, 4, 5, 6, 7, 8, 10, 11, Bình Thạnh, Bình Tân, Tân Bình ….. 
Trong những giây phút bối rối của mất mát và đau buồn của thân nhân, bệnh viện tin rằng mỗi sự chia sẻ dẫu là nhỏ bé ấy cũng sẽ là sự thấu cảm ấm áp và sâu sắc cùng với gia đình người bệnh tử vong.
**“Năng động - Phát triển - Thân thiện”** đã giúp Bệnh viện Nguyễn Tri Phương ngày càng cải thiện chất lượng bệnh viện, thông qua nhiều hoạt động nhằm nâng cao chất lượng khám, chữa bệnh và đạt được sự hài lòng của người bệnh. Người bệnh được chăm sóc an toàn, thoải mái khi tới khám và điều trị tại bệnh viện là mục tiêu lớn nhất của việc quản lý chất lượng bệnh viện hiện nay.
**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/) **- Đa khoa Hạng I Thành phố Hồ Chí Minh

## Chuyến xe tiễn bệnh nhân một đoạn đường

Bệnh viện (BV) Nguyễn Tri Phương là một bệnh viện đa khoa hạng I, trực thuộc quản lý của Sở Y tế Thành phố Hồ Chí Minh. Hiện nay, mỗi năm bệnh viện khám trung bình hơn 560.000 lượt bệnh nhân ngoại trú, tiếp nhận và điều trị khoảng 45.000 lượt bệnh nhân nội trú. 
Trải qua bao thăng trầm lịch sử, BV Nguyễn Tri Phương vừa làm chứng nhân của thời cuộc vừa tham gia vào đời sống xã hội một cách tích cực, đóng góp phần khiêm tốn của mình vào việc chăm sóc sức khỏe cho mọi người dân thuộc mọi thành phần trong xã hội. Đây chính là niềm tự hào của lớp kế tục để từ đó vươn lên làm tròn thiên chức của người cán bộ y tế. Năm 2003, bệnh viện được tặng Huân chương Lao động hạng Nhì.
Đi lên từ một BV truyền thống lâu đời, hạn chế lớn nhất của bệnh viện là cơ sở vật chất chưa kịp đáp ứng nhu cầu khám chữa bệnh ngày càng lớn của người dân Tp. Hồ Chí Minh. Những hạn chế đó được khắc phục bằng một đội ngũ cán bộ công nhân viên năng động, và tận tụy. Cho đến hiện tại, BV Nguyễn Tri Phương đã trải qua 115 năm hình thành và phát triển. BV Nguyễn Tri Phương đã và đang chuyển mình, trở thành một bệnh viện hiện đại, đáp ứng nhu cầu phát triển của xã hội. 
Hằng năm, Bệnh viện Nguyễn Tri Phương, đã hỗ trợ hàng chục triệu đồng cứu bệnh nhân neo đơn bị suy tim, góp phần điều trị cho bệnh nhân có nhiều bệnh lý nội khoa phức tạp và nhiều chiến dịch thiện nguyên lớn nhỏ khác.
Đặc biệt, với quan niệm **“nghĩa tử là nghĩa tận”** , Hội Chữ thập đỏ Bệnh viện Nguyễn Tri Phương còn hỗ trợ xe miễn phí cho mỗi bệnh nhân hấp hối và tử vong về nhà (“chuyến xe đưa tiễn 1 đoạn đường”). 
Các trường hợp bệnh nhân hấp hối hoặc tử vong hoặc có hoàn cảnh khó khăn, địa chỉ gần hay xa đều được bệnh viện đưa về nhà hoàn toàn miễn phí. Nhẹ nhàng chu đáo cho từng chuyến xe đến tận chốn cuối!
Trong bất kỳ trường hợp cần giúp đỡ hỗ trợ xe đưa bệnh nhân tử vong xin về đều có thể liên hệ phòng Hành chính Quản trị và Hội Chữ Thập đỏ - Bệnh viện Nguyễn Tri Phương. 
Bắt đầu từ năm 2016, thông qua tinh thần nhân văn của **“chuyến xe cuối”** , tập thể bệnh viện đã góp phần an ủi, động viên và chia sẻ niềm đau buồn với gần hàng ngàn gia đình bệnh nhân ở các địa phương như xã An Thới Đông, Bình Khánh; huyện Cần Giờ, Củ Chi, Bình Chánh; Bến Lức tỉnh Long An, tỉnh Tiền Giang; quận 3, 4, 5, 6, 7, 8, 10, 11, Bình Thạnh, Bình Tân, Tân Bình ….. 
Trong những giây phút bối rối của mất mát và đau buồn của thân nhân, bệnh viện tin rằng mỗi sự chia sẻ dẫu là nhỏ bé ấy cũng sẽ là sự thấu cảm ấm áp và sâu sắc cùng với gia đình người bệnh tử vong.
**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/) - Đa khoa Hạng I Thành phố Hồ Chí Minh**

## Hội nghị viên chức - người lao động năm 2023

Hội nghị viên chức, người lao động là hoạt động thường niên nhằm đánh giá những kết quả đạt được trong năm, đồng thời nghiêm túc rút ra những hạn chế, tồn tại để từ đó đề ra kế hoạch phương hướng hoạt động cho năm 2023.
Mở đầu hội nghị, BS.CKII Võ Đức Chiến - Giám Đốc Bệnh viện đã trình bày báo cáo kết quả về hoạt động chung, nhân sự, những tiến bộ đạt được của bệnh viện cũng như những khó khăn còn tồn đọng. Đồng thời trình bày Phương hướng hoạt động và biện pháp thực hiện nhiệm vụ năm 2023. Trưởng phòng Tài chính kế toán, Ông Phan Thanh Vân báo cáo công tác tài chính năm 2022 dự toán năm 2023, một số thay đổi trong quy chế chi tiêu nội bộ năm 2023.
Tại hội nghị, các đại biểu cũng thẳng thắn đưa ra các ý kiến tham luận nhằm góp ý cũng như chia sẻ về hoạt động của bệnh viện như: Trách nhiệm của cá nhân trong công tác phòng chống dịch; Một số giải pháp về sử dụng nguồn nhân lực trong công tác chăm sóc người bệnh… 
Bên cạnh đó, hội nghị cũng đưa ra thảo luận các ý kiến về một số chỉ tiêu, các vấn đề liên quan đến việc chi trả phụ cấp, thu nhập tăng thêm… Mọi vấn đề thắc mắc, ý kiến tham luận của các đại biểu được Chủ tọa đoàn tiếp thu, giải đáp chi tiết, thỏa mãn nguyện vọng từ đó thống nhất được các nội dung, phương pháp thực hiện trong năm 2023 để bệnh viện ngày càng một phát triển hơn.
**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/) **- Đa khoa Hạng I Thành phố Hồ Chí Minh

## Bệnh viện Nguyễn Tri Phương: Hỗ trợ khẩn cấp tại khoa Cấp cứu

Khi vào khoa Cấp cứu, Bệnh viện Nguyễn Tri Phương, bệnh nhân không có người thân, bệnh nhân có hoàn cảnh khó khăn, không có khả năng tạm ứng khi nhập viện… sẽ không còn băn khoăn khoản chi phí khi nhập viện điều trị. Quỹ Tâm Nguyện Việt sẽ hỗ trợ mỗi bệnh nhân 5 triệu đồng trong quá trình điều trị tại khoa Cấp cứu.
BS. CKII Võ Đức Chiến, Giám đốc Bệnh viện Nguyễn Tri Phương cho biết, chi phí hỗ trợ này được "Quỹ ứng trợ khẩn cấp 100 triệu đồng" của Quỹ Tâm nguyện Việt dành cho bệnh nhân nghèo cấp cứu khẩn cấp ở Bệnh viện Nguyễn Tri Phương. 
Theo chương trình tài trợ “Nối nhịp yêu thương” cho bệnh nhân nghèo, bệnh nhân có hoàn cảnh khó khăn, bệnh nhân không người thân khi nhập viện…, Quỹ Xã hội Từ thiện Tâm nguyện Việt đã đồng ý tài trợ cho bệnh nhân vào khoa Cấp cứu của Bệnh viện Nguyễn Tri Phương, với chi phí là 5 triệu đồng/bệnh nhân. 
Quỹ Hỗ trợ Khẩn cấp được quỹ “Tâm nguyện Việt” hỗ trợ là nguồn quỹ ban đầu giúp những bệnh nhân có hoàn cảnh khó khăn hoặc những trường hợp tai nạn bất ngờ không có thân nhân có được một khoản tạm ứng nhập viện ban đầu, yên tâm điều trị. 
Mặc dù không nhiều, nhưng khoản tạm ứng này rất hữu ích, giúp cho những thủ tục hành chính để cấp cứu bệnh nhân được thông suốt, nhất là khi phải gửi mẫu xét nghiệm đi các đơn vị khác (thử độc chất, xét nghiệm đặc hiệu...). 
Bệnh viện Nguyễn Tri Phương hiện có khoảng 20% bệnh nhân là những người có hoàn cảnh khó khăn đến khám và điều trị. 
BS. CKII Võ Đức Chiến - Giám đốc Bệnh viện Nguyễn Tri Phương - chia sẻ, với chủ trương “không để ai bị bỏ lại phía sau, không từ chối điều trị bất cứ bệnh nhân nào, nhất là bệnh nhân có hoàn cảnh khó khăn”, trong suốt nhiều năm qua, bên cạnh việc phát triển và tăng cường, nâng cao hiệu quả công tác khám chữa bệnh, các hoạt động nhân đạo cũng được bệnh viện đặc biệt chú trọng. 
Mỗi nhân viên y tế của Bệnh viện đều là một thành viên của Hội Chữ thập đỏ, đều nỗ lực hết mình với phương châm “Sống có tình, đối xử tử tế và thật thân thiết với bệnh nhân, thân nhân, khách và giữa nhân viên với nhau”.
Trung bình mỗi tháng, Bệnh viện Nguyễn Tri Phương hỗ trợ cho 20 - 30 trường hợp bệnh nhân có hoàn cảnh khó khăn ở nhiều mức độ khác nhau, rải đều ở các khoa: cấp cứu, ngoại thần kinh, chấn thương chỉnh hình, sản, nhi, cơ xương khớp…
**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/) - Đa khoa Hạng I Thành phố Hồ Chí Minh**

## Diễn tập Phòng cháy chữa cháy tại Bệnh viện Nguyễn Tri Phương

Từ thực tế công tác tổ chức chữa cháy, cứu nạn cứu hộ cho thấy các vụ cháy tại các công trình nhà cao tầng, khu chung cư, nhà máy xí nghiệp, bệnh viện … đặc biệt nguy hiểm vì đây là nơi tập trung đông người, khi xảy ra cháy, đám cháy sẽ phát triển và lan truyền nhanh. Khi đó khói, khí độc sẽ lan truyền và bao trùm các lối thoát nạn như hành lang bên trong nhà, buồng thang bộ, ... Dẫn đến khó khăn cho quá trình di chuyển của người bị nạn, công tác tổ chức cứu nạn, cứu hộ và triển khai chữa cháy.
Nhận thức được tầm quan trọng của công tác phòng cháy chữa cháy, sáng ngày 29/10/2022, Bệnh viện Nguyễn Tri Phương đã phối hợp với Phòng Cảnh sát PCCC Quận 5, Công an Quận 5 tổ chức diễn tập phương án chữa cháy năm 2022 tại đơn vị với sự tham gia của khoảng 40 cán bộ, nhân viên, lực lượng chữa cháy chuyên nghiệp. Tại buổi diễn tập, các cán bộ của bệnh viện đã được thực hành các thao tác nghiệp vụ PCCC với các bước xử lý tại chỗ, đồng thời với sự trợ giúp của Cảnh sát PCCC đã hướng dẫn bệnh nhân thoát hiểm, dìu và vận chuyển các bệnh nhân nặng, di chuyển tài sản quan trọng ra khỏi đám cháy, khống chế và dập tắt đám cháy.
Qua phần diễn tập với nhiều tình huống thực tế cùng những chia sẻ chi tiết từ các chiến sĩ cứu hỏa, các cán bộ, nhân viên của Bệnh viện Nguyễn Tri Phương đã được tiếp thu những những kiến thức bổ ích và kỹ năng cần thiết trong trường hợp có hỏa hoạn xảy ra, đồng thời nâng cao ý thức trong việc thực hiện phòng ngừa cháy nổ tại cơ quan và nhà ở.
**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/) **- Đa khoa Hạng I Thành phố Hồ Chí Minh

## Cuộc thi “Tìm hiểu các quy định của pháp luật liên quan đến quyền và nghĩa vụ của người Việt Nam ở nước ngoài”

**Hưởng ứng Ngày Pháp luật nước Cộng hòa xã hội chủ nghĩa Việt Nam năm 2022. Bệnh viện Nguyễn Tri Phương phổ biến đến toàn thể viên chức và người lao động khuyến khích tham gia Cuộc thi trực tuyến “Tìm hiểu các quy định của pháp luật liên quan đến quyền và nghĩa vụ của người Việt Nam ở nước ngoài”.**
Cuộc thi sẽ diễn ra trong vòng 30 ngày (từ 0h00 ngày 25/10/2022 đến 24h00 ngày 25/11/2022, theo múi giờ Việt Nam (GMT +7)), được tổ chức theo hình thức trực tuyến.
Cuộc thi được tổ chức theo hình thức trực tuyến tại địa chỉ**<https://moj.gov.vn/cuocthitructuyen> **và được đặt banner Trên Cổng thông tin điện tử của Bộ Tư pháp và Cổng/Trang thông tin điện tử của một số đơn vị liên quan.
Nội dung thi về các quy định về quyền và nghĩa vụ của người Việt Nam ở nước ngoài, người gốc Việt Nam; pháp luật về cư trú, hộ tịch, quốc tịch, chứng thực; bầu cử; xuất cảnh, nhập cảnh; đất đai, nhà ở; các quy định về chính sách bảo hộ của Nhà nước Việt Nam đối với công dân Việt Nam tại nước ngoài cũng như chính sách của Nhà nước Việt Nam trong việc ưu đãi, thu hút đầu tư nước ngoài vào Việt Nam trong mọi lĩnh vực.
Giải thưởng Cuộc thi bao gồm 11 giải, trong đó có 01 giải Nhất, 02 giải Nhì, 03 giải Ba và 05 giải Khuyến khích.
Theo đó, người đạt giải được Ban Tổ chức Cuộc thi cấp Giấy chứng nhận kèm theo hiện vật (nếu có) và mức giải thưởng như sau:
- 01 Giải Nhất: 6.000.000 đồng/giải (Sáu triệu đồng/giải); - 02 Giải Nhì: 3.000.000 đồng/giải (Ba triệu đồng/giải); - 03 Giải Ba: 2.000.000 đồng/giải (Hai triệu đồng/giải); - 05 Giải Khuyến khích: 1.000.000 đồng/giải (Một triệu đồng/giải).
**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/) **- Đa khoa Hạng I Thành phố Hồ Chí Minh

## Tổ chức thành công Hội thi văn nghệ mừng xuân Quý Mão 2023

**Xin chúc mừng các tiết mục đạt giải cao:**
**1. Thể loại tốp ca**
- Giải nhất: Khoa Nội tiêu hóa
- Giải nhì: Khoa Cấp cứu
- Giải ba: Khoa Gây mê hồi sức
- Giải khuyến khích: Khoa Nội thần kinh, Khoa Khám bệnh, Phòng Tổ chức cán bộ, Khoa Ngoại tổng hợp, Khoa Hồi sức tích cực chống độc
**2. Thể loại đơn ca**
**a. Đơn ca nam**
- Giải nhất: Khoa Khám bệnh
- Giải nhì: Khoa Lão
- Giải ba: Khoa Chẩn đoán hình ảnh
**b. Đơn ca nữ**
- Giải nhất: Khoa Nội tiêu hóa
- Giải nhì: Phòng Tài chính kế toán
- Giải ba: Khoa Gây mê hồi sức
- Giải khuyến khích: Khoa Mắt
**3. Thể loại song ca, tam ca**
- Giải nhất: Khoa Cơ xương khớp
- Giải nhì: Khoa Phụ sản
- Giải ba: Khoa Gây mê hồi sức
- Giải khuyến khích: Khoa Chấn thương chỉnh hình, Khoa Nội tổng hợp
**4. Thể loại múa**
- Giải nhất: Khoa Nội tiêu hóa
- Giải nhì: Phòng Tổ chức cán bộ - Điều dưỡng
- Giải ba: Khoa Ngoại Thần kinh
- Giải khuyến khích: Khoa Ngoại thận - tiết niệu
**5. Thể loại diễn thời trang**
- Giải nhất: Khoa Phụ sản
- Giải nhì: Khoa Ngoại tiêu hóa
- Giải ba: Khoa Khám bệnh
**6. Giải chương trình hay nhất**
Khoa Nội tiêu hóa
**Ban Giám đốc và Công đoàn BV** đã có những chia sẻ về sự thành công khi tổ chức hội thi như sau: 
"Thay mặt BGĐ, BCH Công đoàn BV, chúng tôi Cám ơn Ban tổ chức, Cám ơn Lãnh đạo, Tổ trưởng Công đoàn các Khoa Phòng đã quan tâm, nhiệt tình đóng góp các tiết mục văn nghệ mừng Xuân mới, mang lại niềm vui tinh thần quý giá, lan toả đến tập thể Nhân viên Bệnh viện. 
Đặc biệt ghi nhận sự cố gắng của Khối Ngoại đã 100% tham dự, nhất là tiết mục tập thể Khoa Ngoại tiêu hoá, Sản, GMHS, Ngoại Tổng hợp.... Các Phòng, khoa khối Nội dù đông bệnh, làm ca kíp nhưng vẫn cố gắng huy động anh chị em tham gia rất đông như TCCB, Phòng Điều dưỡng, CC, Nội Tiêu hoá, Thận Lọc máu, CXK, Nội TK, HSTC, KKB, Nội tổng hợp... 
Nhiều tay vỗ nên kêu, biết phía trước còn nhiều khó khăn thách thức, nhưng hy vọng với tiềm lực chuyên môn, tài năng phong trào cũng như sức trẻ và một tâm nguyện Vì BV, Cho BV sẽ không ngừng nâng tầm thương hiệu NTP. Trân quý tất cả những khoảnh khắc, nỗ lực này.
Xuân Quý Mão 2023"
**Xem những hình ảnh được ghi lại của Hội thi[tại đây](https://drive.google.com/drive/folders/1jcLWJl-DZoB39tIzEeaFitqUr4hOSRrf?usp=sharing)**

## Công ty PVTrans trao tặng thiết bị 08 phòng VIP, 01 phòng President, 01 phòng áp lực âm


## Đại diện lãnh đạo Thành phố ghé thăm và chúc tết Bv Nguyễn Tri Phương

Sáng ngày 11/01/2023, Đoàn đại diện Lãnh đạo Thành phố Hồ Chí Minh do đồng chí Võ Văn Hoan, Thành ủy viên, Phó Chủ tịch Ủy ban nhân dân Thành phố Hồ Chí Minh làm Trưởng đoàn đã đến thăm, chúc Tết [Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/) nhân dịp Tết nguyên đán Quý Mão năm 2023.
_Đồng chí Võ Văn Hoan - Thành ủy viên - Phó Chủ tịch UBND Tp. Hồ Chí Minh phát biểu_
_Đại diện Đoàn lãnh đạo Tp. Hồ Chí Minh và Toàn thể lãnh đạo Bệnh viện Nguyễn Tri Phương_
Đến thăm, chúc Tết [Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/) - Thành ủy viên, Phó Chủ tịch tịch Ủy ban nhân dân Thành phố Võ Văn Hoan trân trọng bày tỏ lòng trân quý, sự cảm kích và gửi lời cảm ơn đến đội ngũ nhân viên y tế, đã không ngại nguy hiểm kề vai sát cánh cùng Thành phố trong thời gian chống dịch và gửi lời cảm ơn sâu sắc đến đấng sinh thành của các nhân viên y tế đã động viên, chia sẻ, gánh vác trách nhiệm gia đình để họ yên tâm lên đường chống dịch. Đồng thời, ghi nhận và đánh giá cao những nỗ lực của đội ngũ y tế Bệnh viện đã thực hiện tốt các nhiệm vụ được giao, góp phần giúp cùng ngành y tế Thành phố, giúp Thành phố Hồ Chí Minh hoàn thành tốt nhiệm vụ và phát triển.
Nhân dịp này, Thành ủy viên - Phó Chủ tịch tịch Ủy ban nhân dân Thành phố - Ông Võ Văn Hoan chúc đội ngũ nhân viên y tế Bệnh viện cùng gia đình năm mới bình an, hạnh phúc, an khang thịnh vượng.
**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/) **- Đa khoa Hạng I Thành phố Hồ Chí Minh

## Quận ủy - UBND - MTTQVN Quận 5 ghé thăm và chúc tết bệnh viện

Sàng ngày 10/01/2023, Đoàn Đại diện của Quận Ủy - Ủy Ban Nhân Dân - Mặt Trận Tổ Quốc Việt Nam Quận 5 đến thăm và chúc Tết Quý Mão 2023 tại bệnh viện.
Đến thăm, chúc tết cán bộ, y, bác sĩ Bệnh viện Nguyễn Tri Phương, Đại diện đoàn Quận Ủy - Ủy Ban Nhân Dân - Mặt Trận Tổ Quốc Việt Nam Quận 5 ghi nhận và đánh giá cao những nỗ lực vượt khó của đội ngũ y, bác sĩ chung tay chống dịch Covid-19. Nhân dịp Tết Quý Mão 2023, Đoàn chúc cán bộ, y, bác sĩ cùng gia đình năm mới mạnh khỏe, bình an, vạn sự như ý và tiếp tục cùng TPHCM thực hiện tốt công tác phòng chống dịch, nhất là trước việc biến thể XBB xuất hiện trong cộng đồng tại TPHCM trong những ngày cận tết.
**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/) **- Đa khoa Hạng I Thành phố Hồ Chí Minh

## Ban Tuyên giáo Thành ủy TPHCM đến thăm BV và cán bộ, nhân viên y tế

Nhân dịp gần đến ngày Thầy thuốc Việt Nam (27/2/2022), để cảm ơn sự đóng góp của đội ngũ nhân viên y tế, Thành ủy TPHCM đã đến thăm hỏi và động viên tại các Bệnh viện.
Đồng chí Lê Hồng Sơn, Thành ủy viên, Phó trưởng ban thường trực Ban Tuyên giáo Thành ủy đã dẫn đoàn làm việc đến ghé thăm bệnh viện Nguyễn Tri Phương. Đại diện đón tiếp đoàn là BS CK2 Đỗ Tuấn Linh - Phó Giám đốc, Chủ tịch Công đoàn Bệnh viện.
Qua chuyến đi này, Đồng chí Lê Hồng Sơn cũng đại diện lãnh đạo Thành phố thăm hỏi động viên ông Sử Khắc Trí - là nhân viên của Bệnh viện, hiện đang điều trị vì bệnh thận mạn tính tại khoa Lọc máu theo tiêu chuẩn Nhật Bản (TUC).
Bệnh viện xin trân trọng cảm ơn sự quan tâm và những lời thăm hỏi - động viên quý báu này.
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh

## ️ Hội cựu chiến binh BV thành công tổ chức đại hội nhiệm kỳ 2022-2027

**DS CKI Nguyễn Hoàng Phi** đã được tin tưởng bầu vào Chủ tịch Hội cựu chiến binh 2022-2027 của bệnh viện. 
Cựu chiến binh là những người đã cống hiến cho hòa bình của đất nước vì thế theo truyền thống “uống nước nhớ nguồn” Đảng và Nhà nước ta luôn có những chính sách quan tâm đến những người có công với Tổ quốc, trong đó có đối tượng là Cựu chiến binh.
Cựu chiến binh là công dân nước Cộng hòa xã hội chủ nghĩa Việt Nam, đã tham gia đơn vị vũ trang chiến đấu chống ngoại xâm giải phóng dân tộc, làm nhiệm vụ quốc tế, xây dựng và bảo vệ Tổ quốc, đã nghỉ hưu, chuyển ngành, phục viên hoặc xuất ngũ.
Hội cựu chiến binh có các nhiệm vụ chính sau: 
  * Tham gia xây dựng, bảo vệ Đảng, chính quyền, chế độ xã hội chủ nghĩa; đấu tranh chống mọi âm mưu, hoạt động phá hoại của các thế lực thù địch; chống các quan điểm sai trái với đường lối, chính sách của Đảng, pháp luật của Nhà nước. Hội cũng có nhiệm vụ thực hiện các quy định của pháp luật về dân chủ ở cơ sở, đấu tranh chống quan liêu, tham nhũng, lãng phí, tệ nạn xã hội; giám sát hoạt động của cơ quan Nhà nước, của cán bộ, công chức theo quy định của pháp luật.
  * Tham gia phát triển kinh tế – xã hội, củng cố quốc phòng, an ninh; kiến nghị với cơ quan Nhà nước, chính quyền địa phương về xây dựng và tổ chức thực hiện chính sách, pháp luật có liên quan đến Cựu chiến binh, Hội Cựu chiến binh.


**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/)** - Đa khoa Hạng I Thành phố Hồ Chí Minh

## ️ Tổ chức thành công chương trình hiến máu cứu người ngày 11/8/2022

Sáng 11-8, Bệnh viện Nguyễn Tri Phương tổ chức Ngày hội hiến máu "Giọt máu hồng hè 2022". Hoạt động này nhằm tăng cường công tác tuyên truyền, vận động công nhân, viên chức, đoàn viên, thanh niên tham gia hiến máu cứu người, thể hiện nghĩa cử cao đẹp, nét đẹp văn hóa, sống vì xã hội và cộng đồng.
BS CKII Võ Đức Chiến, Giám đốc bệnh viện Nguyễn Tri Phương, cho biết: "Vừa rồi, có thông tin nhiều nhân viên ngành y tế nghỉ việc vì áp lực công việc và nhiều lý do khác; nhưng là một người công tác lâu năm trong ngành y, tôi nhìn thấy về mặt tổng thể, rất nhiều người vẫn tiếp tục gắn bó với nghề, tận tụy với công việc. Đối với bệnh viện chúng tôi, cán bộ, nhân viên y tế không những không bỏ nghề mà còn tích cực tham gia các hoạt động ngoài chuyên môn, đặc biệt là tình nguyện hiến những giọt máu hồng để góp vào ngân hàng máu, giúp đỡ cho người bệnh và cống hiến cho xã hội".
Trong buổi sáng 11/8, có tổng cộng có 140 người là hội viên Hội Chữ thập đỏ, cán bộ y tế, nhân viên, đoàn viên thanh niên của bệnh viện Nguyễn Tri Phương, Trường ĐH Y dược TP HCM, Trường ĐH Y khoa Phạm Ngọc Thạch đang công tác tại bệnh viện tham gia hiến 200 đơn vị máu.
Hoạt động "Giọt máu hồng hè 2022" góp phần tạo nguồn máu sống, giúp cho ngành y tế nói chung và các bệnh viện nói riêng kịp thời cấp cứu và điều trị bệnh nhân, mang lại niềm vui và hạnh phúc cho người bệnh và gia đình của người bệnh.
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh

## Bệnh viện Nguyễn Tri Phương hưởng ứng 'Ngày an toàn người bệnh Thế giới năm 2022' với chủ đề 'Sử dụng thuốc an toàn, không gây hại'

Theo thông báo của Bộ Y tế Việt Nam, Tổ chức Y tế Thế giới (WHO) về việc hưởng ứng “Ngày An toàn người bệnh Thế giới năm 2022”, mỗi người trên thế giới vào một thời điểm nào đó trong đời sẽ phải dùng thuốc để ngăn ngừa hoặc điều trị bệnh tật. Tuy nhiên, thuốc đôi khi gây ra tổn hại nghiêm trọng nếu việc bảo quản, kê đơn, cấp phát, sử dụng không đúng cách hoặc không được theo dõi đầy đủ.
Các hành vi sử dụng thuốc không an toàn và sự cố về sử dụng thuốc là những nguyên nhân hàng đầu gây ra tổn hại (có thể phòng tránh được) trong việc chăm sóc sức khỏe trên toàn cầu. Sự cố về sử dụng thuốc xảy ra khi hệ thống quản lý chất lượng yếu kém; các yếu tố chủ quan như nhân viên y tế mệt mỏi, điều kiện môi trường làm việc kém hay thiếu nhân lực đều ảnh hưởng tới an toàn sử dụng thuốc. Việc này có thể dẫn tới tổn hại nghiêm trọng cho người bệnh, gây tàn phế và thậm chí tử vong. Đại dịch Covid-19 kéo dài đã và đang làm trầm trọng thêm nguy cơ xảy ra sự cố về sử dụng thuốc và các tổn hại có liên quan đến thuốc. Trong bối cảnh đó, ‘Sử dụng thuốc an toàn, không gây hại” được chọn làm chủ đề, khẩu hiệu cho Ngày An toàn người bệnh thế giới năm 2022.
**Mục tiêu của Ngày An toàn người bệnh thế giới năm 2022 là:**
  * Nâng cao nhận thức toàn cầu về gánh nặng của các tổn hại liên quan đến sự cố trong sử dụng thuốc hoặc các hành vi sử dụng thuốc không an toàn, đồng thời ủng hộ hành động khẩn cấp để cải thiện an toàn sử dụng thuốc. 
  * Tăng cường phối hợp giữa các bên liên quan nhằm ngăn ngừa sự cố trong sử dụng thuốc và giảm tổn hại liên quan đến thuốc. 
  * Hướng dẫn người bệnh và gia đình tham gia trong việc sử dụng thuốc an toàn. 
  * Tích cực triển khai Chiến dịch An toàn người bệnh toàn cầu của WHO: Sử dụng thuốc an toàn, không gây hại.


Thực hiện công văn số 4772/BYT-KCB ngày 05 tháng 9 năm 2022 của Thứ trưởng Bộ Y tế về việc Hưởng ứng Ngày An toàn người bệnh Thế giới 17/9/2022. Bệnh viện Nguyễn Tri Phương đã triển khai thực hiện một số nội dung sau:
  * Chạy bảng điện tử, treo pano, áp phích tại Bệnh viện với khẩu hiệu “SỬ DỤNG THUỐC AN TOÀN, KHÔNG GÂY HẠI”.
  * Đăng tải hình ảnh chủ đề Ngày An toàn người bệnh Thế giới 17/9 2022 trên trang Web và các màn hình quảng bá của Bệnh viện.
  * Nhân viên Bệnh viện tham gia thực hiện Khảo sát của Bộ Y tế về chủ đề “SỬ DỤNG THUỐC AN TOÀN, KHÔNG GÂY HẠI” theo hình thức khảo sát trực tuyến bằng cách truy cập đường dẫn sau: **<http://bit.ly/antoanthuocbyt>** hoặc truy cập bằng cách quét mã QR;


**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/) **- Đa khoa Hạng I Thành phố Hồ Chí Minh

## ️ Công ty Nipro tài trợ cho Hội chữ thập đỏ BV để hỗ trợ bệnh nhân chạy thận nhân tạo

Đến tham dự buổi lễ trao tặng, BV Nguyễn Tri Phương hân hạnh tiếp đón:
  * **Đại diện Hội Chữ Thập Đỏ Thành phố Hồ Chí Minh:** Ông Trần Trường Sơn – chủ tịch Hội


  * **Đại diện từ phía Nipro:**
  * Ông Daniel – đại diện Nipro Châu Á
  * Bà Phạm Nguyễn Như Ý – tổng Giám đốc Công ty Nipro Việt Nam


  * **Hội Thận học – lọc máu Thành phố Hồ Chí Minh:** PGS.TS Phạm Văn Bùi - Chủ tịch Hội


Đại diện Hội Chữ Thập Đỏ Thành phố Hồ Chí Minh - Ông Trần Trường Sơn thể hiện sự vui mừng và trân trọng khi Nipro đã quan tâm đến một lực lượng yếu thế của xã hội trong bệnh dịch Covid-19, đó là những bệnh nhân suy thận cần chạy thận nhân tạo. Ông cũng thể hiện niềm tin ở năng lực của BV Nguyễn Tri Phương sẽ sử dụng hợp lý và phát huy tốt nhất những quà tặng quý giá này.
Là một đơn vị đồng hành từ lâu cùng BV Nguyễn Tri Phương, Ông Phạm Văn Bùi thay mặt cho Hội Thận học - Lọc máu TP.HCM cũng bày tỏ sự cảm kích đến chương trình thiện nguyện của Nipro đã mở ra nhiều cơ hội tiếp cận hơn nữa với tiêu chuẩn Nhật Bản cho bệnh nhân cần chạy thận tại BV NTP nói riêng và TP.HCM nói chung.
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh

## Đại Từ Liên Xã: Hoạt động nâng đỡ tinh thần.

Với những người có tín ngưỡng, Đại Từ Liên Xã là nơi để bệnh nhân và thân nhân nhận thêm nguồn niểm tin tích cực giúp cho kết quả điều trị được tốt hơn. Bên cạnh những bữa cơm chay định kỳ (mồng 1 và rằm mỗi tháng), tại đây nhân viên y tế, bệnh nhân, thân nhân có nhu cầu được chia sẻ thông điệp về sự an yên. Mọi người đến đây như được tiếp thêm một nguồn năng lượng để vượt qua những bộn bề, đau đớn đang diễn ra trong cuộc sống.
BS. CKII Võ Đức Chiến, Giám đốc Bệnh viện Nguyễn Tri Phương, còn chia sẻ thêm về ý nghĩa của những hoạt động trong Đại Từ Liên Xã. Ông cho biết, bệnh đái tháo đường, tim mạch - chuyển hoá (như nhồi máu cơ tim, đột quỵ), hô hấp mạn tính (như bệnh phổi tắc nghẽn mạn tính và hen phế quản), ung thư là 4 loại bệnh không lây nhiễm chính nổi bật hiện nay và cũng là nguyên nhân gây tử vong hàng đầu trên thế giới. 
Theo thống kê của Tổ chức Y tế thế giới (World Health Organization - WHO), mỗi năm, khoảng 15 triệu người chết vì các bệnh không lây nhiễm nằm trong độ tuổi từ 30 - 69. 
“Chính vì vậy, nhiều nơi trên thế giới đã phát động phong trào “ngày thứ bảy không thịt”. Các nghiên cứu khẳng định những người ăn nhiều rau quả, ít thịt hay ăn chay sẽ giảm 12% nguy cơ tử vong so với những người không ăn chay. Các nghiên cứu còn lưu ý rằng lợi ích của chế độ ăn chay đặc biệt tốt cho nam giới, giảm đáng kể nguy cơ mắc các bệnh lý tim mạch và rối loạn chuyển hóa,” BS. CKII Võ Đức Chiến nói. 
Bệnh viện Nguyễn Tri Phương đã tổ chức hai ngày ăn chay vào mỗi ngày rằm và cuối tháng âm lịch tại bệnh viện cho 1400 nhân viên y tế của bệnh viện và thậm chí cả bệnh nhân hay người bên ngoài tại Đại Từ Liên Xã. 
Ông cũng nhấn mạnh, bên cạnh các lợi ích sức khỏe rõ ràng từ những bữa ăn chay, không thịt, ăn chay còn phù hợp với các hoạt động tinh thần của người dân Á Đông nói chung, người Việt Nam nói riêng, nơi hơn 90% theo đạo Phật. Việc ăn chay sẽ giúp con người tâm tịnh, hướng thiện, càng củng cố lòng từ bi, nhẫn nại và yêu thương người bệnh từ mỗi nhân viên y tế. 
Những đóng góp từ các tấm lòng hảo tâm để duy trì hoạt động này của Đại từ Liên xã vừa góp phần bảo vệ sức khỏe của nhân viên y tế vừa xây dựng một tập thể Bệnh viện Nguyễn Tri Phương mạnh mẽ lòng thấu cảm, nâng cao chất lượng khám chữa bệnh và chăm sóc người bệnh. 
**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/) **- **Đa khoa Hạng I Thành phố Hồ Chí Minh**

## Bệnh viện Nguyễn Tri Phương đóng góp tích cực trong hoạt động Đoàn của Sở Y Tế TPHCM

TỔNG QUAN KẾT QUẢ ĐẠI HỘI ĐẠI BIỂU ĐOÀN TNCS HỒ CHÍ MINH SỞ Y TẾ THÀNH PHỐ KHÓA IX (2022 - 2027)
**Kính chúc nhiệm kỳ thành công phía trước!**

## Bệnh viện Nguyễn Tri Phương: Những đóng góp trên mặt trận chăm sóc và bảo vệ sức khỏe nhân dân của Thành phố Hồ Chí Minh

Hơn một trăm năm trong chiều dài lịch sử đất nước chẳng là bao nhưng với một đơn vị y tế địa phương thì khoảng thời gian ấy là rất đáng kể. Sự trưởng thành của Bệnh viện Nguyễn Tri Phương hiện nay có phần đóng góp công sức, kinh nghiệm của nhiều thế hệ ngành y, cùng với sự tin yêu của nhân dân cũng như sự đóng góp của lãnh đạo bệnh viên qua các thời kỳ. 
Với đội ngũ cán bộ, công nhân viên năng động, tận tâm, Bệnh viện đã thực hiện tốt sứ mệnh chăm sóc sức khỏe của nhân dân thành phố Hồ Chí Minh và khu vực lân cận, xứng đáng với vai trò bệnh viện hạng I của Thành phố Hồ Chí Minh. Hoạt động hiệu quả theo cơ chế viện – trường không chỉ giúp nâng cao hiệu quả trong công tác khám chữa bệnh mà còn giúp bệnh viện trở thành cơ sở đào tạo quan trọng của nhiều trường Đại học lớn tại Tp.HCM và khu vực lân cận như: ĐH Y Dược Tp.HCM, ĐH Y Nguyễn Tất Thành, ĐH Trà Vinh, ĐH Nguyễn Tất Thành… Bệnh viện có có 05 mã ngành đào tạo CME do Bộ Y tế cấp cho các chuyên khoa: Lọc máu - Thần kinh - [Chấn thương Chỉnh hình](https://bvnguyentriphuong.com.vn/chan-thuong-chinh-hinh) - [Hô hấp](https://bvnguyentriphuong.com.vn/noi-ho-hap). [Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/) cũng là nơi đầu tiên tại miền Nam triển khai kỹ thuật đặt điện cực vào não sâu (DBS_ Deep Brain Stimulation) để điều trị [Parkinson](https://bvnguyentriphuong.com.vn/noi-tam-than-kinh/benh-parkinson-va-cac-hoi-chung-parkinson), là nơi đầu tiên tại Đông Nam Á nhận được chứng nhận Trung tâm Xuất sắc (ICE) của kỹ thuật mổ [thay khớp háng](https://www.youtube.com/watch?v=UyfPRFXhDlM&list=PLiU0n83wV1FDH-NqJwbiEKybC0PS2uRN6&index=10) superpath và [thay khớp gối](https://www.youtube.com/watch?v=Li4U18Lplf4&list=PLiU0n83wV1FDH-NqJwbiEKybC0PS2uRN6&index=8) với kỹ thuật medical pivot theo chuẩn Mỹ. Bên cạnh đó bệnh viện cũng là nơi tiên phong xây dựng trung tâm Lọc máu theo tiêu chuẩn Nhật Bản nhờ vào hợp tác hiệu quả với Nippro và TUC.
Bệnh viện duy trì đầy đủ các chuyên khoa Nội - Ngoại - [Sản](https://bvnguyentriphuong.com.vn/san-phu-khoa) - [Nhi](https://bvnguyentriphuong.com.vn/khoa-nhi) và hệ thống các chuyên khoa lẻ, các chuyên khoa cận lâm sàng đảm bảo đầy đủ cho nhu cầu khám và điều trị đa khoa cũng như phát triển kỹ thuật chuyên sâu. Một số chuyên khoa đã và đang dần trở thành mũi nhọn trong chuyên môn như: [Nội tim mạch](https://bvnguyentriphuong.com.vn/noi-tim-mach), [Nội thận](https://bvnguyentriphuong.com.vn/noi-than-tiet-nieu) - [Lọc máu](https://bvnguyentriphuong.com.vn/than-loc-mau), [Nội tiết](https://bvnguyentriphuong.com.vn/noi-tiet), [Nội thần kinh](https://bvnguyentriphuong.com.vn/noi-tam-than-kinh) có cả phòng khám chuyên khoa tâm thần, [Cơ xương khớp](https://bvnguyentriphuong.com.vn/co-xuong-khop), Ngoại thần kinh, Chấn thương chỉnh hình, [Tai mũi họng](https://bvnguyentriphuong.com.vn/tai-mui-hong)... Bên cạnh đó, Bệnh viện cũng có những đơn vị khám - điều trị chuyên khoa như Đơn vị ung bướu, Đơn vị quản lý Hen và COPD, Đơn vị vi sinh, Đơn vị [Da liễu - Thẩm mỹ da](https://bvnguyentriphuong.com.vn/kham-da-lieu-chuyen-sau)…
Bệnh viện cũng không ngừng đưa vào ứng dụng những kỹ thuật tiên tiến trong chuyên môn và không ngừng cải tạo hệ thống cơ sở vật chất đáp ứng điều trị tại các khoa nhiều bệnh nặng như [Hồi sức tích cực - Chống độc](https://bvnguyentriphuong.com.vn/hoi-suc-tich-cuc-chong-doc), Gây mê hồi sức… Bệnh viện đã thành công triển khai kỹ thuật lọc máu CRRT (Continuous renal replacement therapy - CRRT) cứu sống nhiều ca bệnh nặng..., đang hoàn thiện triển khai kỹ thuật ECMO (hoạt động hô hấp tuần hoàn ngoài cơ thể).
Phương châm Đông - Tây y kết hợp thể hiện rõ qua nhiều hoạt động khám và điều trị đa dạng tại khoa [Y học cổ truyền](https://bvnguyentriphuong.com.vn/y-hoc-co-truyen) - Phục hồi chức năng - [Vật lý trị liệu](https://bvnguyentriphuong.com.vn/y-hoc-co-truyen/vat-ly-tri-lieu-la-gi), cũng sự phương châm điều trị toàn diện được thực hiện bởi sự phối hợp nhịp nhàng giữa nội khoa và ngoại khoa trong điều trị nhiều bệnh lý: [Parkinson](https://bvnguyentriphuong.com.vn/noi-tam-than-kinh/benh-parkinson-va-cac-hoi-chung-parkinson), thoái hóa khớp, thoái hóa cột sống...
Trong thời điểm dịch bệnh Covid-19 bùng phát mạnh tại thành phố Hồ Chí Minh, UBND thành phố đã quyết định thành lập Bệnh viện dã chiến điều trị bệnh nhân Covid-19 Nguyễn Tri Phương trực thuộc Sở Y tế (là đơn vị y tế do Bệnh viện Nguyễn Tri Phương đảm nhận và chịu sự chỉ đạo, quản lý, điều hành trực tiếp của Ban Chỉ đạo Thành phố về phòng, chống dịch Covid-19, đồng thời chịu sự chỉ đạo về chuyên môn nghiệp vụ của Sở Y tế) trên cơ sở chuyển một phần công năng của Bệnh viện Nguyễn Tri Phương. 
Theo đó, Bệnh viện đã chỉ đạo, điều hành việc tiếp nhận, điều trị 4.652 lượt bệnh nhân và lọc máu cho 998 lượt bệnh nhân nhiễm Covid-19. Với những máy móc thiết bị y tế được trang bị và tài trợ, cùng với sự tân tâm, trách nhiệm của đội ngũ nhân viên y tế, Bệnh viện đã cấp cứu, điều trị thành công nhiều bệnh nhân Covid-19 nặng, nguy kịch giúp mang lại niềm vui cho cá nhân, gia đình bệnh nhân và đây cũng chính là niềm hạnh phúc của tập thể lãnh đạo và đội ngũ y bác sĩ của Bệnh viện. Bên cạnh đó, Bệnh viện cũng bố trí trang thiết bị và phân công đội ngũ y bác sĩ chạy thận nhân tạo, lọc máu cho bệnh nhân bệnh thận mãn tính nhiễm Covid-19.
Công tác chích ngừa cho các cơ quan đoàn thể, bệnh nhân, thân nhân nhân viên y tế, đóng góp phần công tác đẩy lùi dịch bệnh. Từ tháng 3/2021 đến tháng 12/2021, Bệnh viện đã tiêm 18.837 mũi 1, 20.978 mũi 2 (với 3 loại vắc xin là Pfizer, AstraZeneca, Moderna).
Với phương châm năng động trong việc kêu gọi nhiều nguồn lực, cùng với quan điểm “mỗi cá nhân, tổ chức đều là một địa chỉ nhân đạo”, Bệnh viện đã góp phần trong việc đảm bảo “không ai bị bỏ lại phía sau” thông qua việc xây dựng và vận hành hệ sinh thái chăm sóc bệnh nhân có hoàn cảnh khó khăn (tổng số tiền kêu gọi được cho hệ sinh thái là hơn 9 tỉ đồng từ 2019-2022). Khi đối mặt với đại dịch, Bệnh viện cũng đã chủ động trong nhiều hoạt động kêu gọi với tổng số tiền huy động được cho công tác phòng chống dịch Covid-19 và cứu chữa bệnh nhân lên đến trên 100 tỉ đồng. 
Với những đóng góp trong công tác phòng, chống dịch, Bệnh viện Nguyễn Tri Phương đã được UBND Thành phố tặng Bằng khen; Sở Y tế tặng Giấy khen đã có thành tích xuất sắc trong công tác thu dung, điều trị bệnh nhân Covid-19 tại các Bệnh viện dã chiến thu dung, Bệnh viện điều trị, Bệnh viện hồi sức Covid-19. Bên cạnh đó nhờ vào sự thành công trong chiến dịch tiêm ngừa nâng cao sức bảo vệ cộng đồng mà Công an Thành phố Hồ Chí Minh tặng Giấy khen đã có thành tích xuất sắc trong công tác hỗ trợ lực lượng Công an Thành phố thực hiện nhiệm vụ phòng, chống dịch bệnh Covid-19./.

## ️ Thành công tổ chức hiến máu Xuân 2022

Hiến máu cứu người, một nghĩa cử cao đẹp thể hiện truyền thống tương thân thương ái, thương người như thể thương thân của dân tộc ta, là hành động giúp đỡ những người bệnh đang cần những giọt máu quý giá để duy trì sự sống. Phong trào “Hiến máu nhân đạo” đang dần trở thành lối sống hết sức cao đẹp của người Việt Nam, được cả xã hội tôn vinh và ghi nhận, thể hiện sự yêu thương san sẻ giữa con người với con người. Với thông điệp “Hiến máu an toàn, chung tay đẩy lùi Covid-19”, “Một giọt máu cho đi, một cuộc đời ở lại” - hoạt động hiến máu sẽ không ngừng lại dẫu nhiều khó khăn vì dịch bệnh.
Qua chương trình hiến máu tình nguyện góp phần tuyên truyền ý nghĩa cao đẹp của hiến máu, giới thiệu, nhân rộng, lan tỏa hình ảnh đẹp của đoàn viên, công đoàn đến người dân trong các hoạt động xã hội, tình nguyện vì cộng đồng”
Rất nhiều người hiến máu còn là những người thầy thuốc luôn dành tặng người bệnh món quà sức khỏe và sự sống, để kịp thời cứu chữa bệnh nhân trong tình trạng nguy cấp, nguy hiểm tính mạng, nhiều y bác sỹ Bệnh viện đã không ngần ngại hiến máu và tiểu cầu của chính mình. Hành động này đã giúp nhiều bệnh nhân vượt qua cơn 'thập tử nhất sinh', góp phần xây dựng hình ảnh người y bác sỹ đúng theo phương châm “lương y như từ mẫu” và hướng tới điều cao cả nhất là sự hài lòng của bệnh nhân. 
Chương trình đã thành công kêu gọi được 171 đơn vị máu - tạo sự lan tỏa tốt đẹp về nghĩa cử cứu người trong cuộc sống hôm nay!
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh

## Tổ chức thành công Hội nghị CBCCVC năm 2022

**Về phát triển chuyên môn**
Tiếp tục phát triển 04 kỹ thuật:
  1. Phẫu thuật cấy điện ốc tai, phẫu thuật chỉnh hình xương, phục hồi thính lực cho người khiếm thính… – khoa Tai Mũi Họng.
  2. Phẫu thuật kích thích não sâu trong điều trị bệnh rối loạn vận động (Parkinson, Run vô căn, Loạn trương lực cơ); Phẫu thuật động kinh kháng trị… - khoa Ngoại Thần Kinh.
  3. Kỹ thuật TACE trong điều trị ung thư gan, tiến tới DEB-TACE bằng nút vi mạch; Cắt đốt u gan kích thước nhỏ bằng sóng cao tần RFA, MWA (nút mạch u gan bằng hạt vi cầu)…- khoa Ngoại Tổng Hợp.
  4. Tiếp tục thực hiện trung tâm Thận học – Lọc máu chất lượng cao theo tiêu chuẩn Nhật Bản – TUC.


Dự kiến phát triển 06 kỹ thuật: 
  1. Ứng dung đo áp lực nội sọ trong điều trị xuất huyết não tự phát; Phẫu thuật u não, phẫu thuật cột sống theo xu hướng ít xâm lấn; Phẫu thuật kích thích tủy sống điều trị đau kháng trị; Các kỹ thuật nâng cao trong can thiệp điều trị đau dùng máy đốt sóng cao tầng (Radio Frequency).
  2. Cầm máu chảy máu tiêu hóa qua nội soi bằng Hemospray, Endooloop; Bóc tách dưới niêm mạc qua nội soi (ESD) điều trị ung thư sớm dạ dày phì.
  3. Phương pháp hạ đường huyết bằng Insulin; Nghiệm pháp Glucagon để phát hiện chậm tăng trưởng do thiếu Hormon; Nghiệm pháp dung nạp Glucose 75g để phát hiện đái tháo đường thai kỳ.
  4. Cắt đốt u giáp, u vú bằng sóng cao tần; Áp dụng sinh học phân tử trong chẩn đoán và điều trị bệnh lý ung thư; Phẫu thuật , triệt mạch, lấy huyết khối bệnh lý tĩnh mạch ngoại vi; Tán sỏi đường mật, lấy sỏi qua ERCP.
  5. Kỹ thuật vi sinh tự động như: vi khuẩn nuôi cấy và định danh hệ thống tự động; Vi khuẩn nuôi cấy kỵ khí và định danh; Vi nấm nuôi cấy, định danh và kháng thuốc hệ thống tự động.
  6. Tiêm thuốc ức chế tăng sinh mạch máu vào nội nhãn để điều trị xuất huyết dịch kính, bệnh lý hoàng điểm, bệnh lý có tăng sinh tân mạch; Chụp cắt lớp quang học võng mạc để nâng cao chẩn đoán và điều trị các bệnh lý đáy mắt.


**Bên cạnh đó:**
  * Phát triển Khoa học kỹ thuật của bệnh viện theo chiều sâu.
  * Hoàn chỉnh phần mềm quản lý bệnh viện đồng bộ, phần mềm quản lý….
  * Trang bị cơ sở vật chất, trang thiết bị hiện đại để nâng cao chất lượng điều trị.
  * Tăng cường mở rộng hoạt động xã hội hóa, mở rộng các dịch vụ phục vụ bệnh nhân ngày càng chuyên nghiệp.
  * Tiếp tục quan tâm tới công tác phục vụ bệnh nhân diện chính sách, bệnh nhân nghèo, bệnh nhân BHYT, bệnh nhân vùng sâu, vùng xa, bệnh nhân là cán bộ hưu trí.
  * Tiếp tục thực hiện công tác hỗ trợ và chuyển giao kỹ thuật cho các bệnh viện tuyến dưới. 
  * Phát triển và quản lý tốt các nguồn thu.
  * Thực hiện Quy chế dân chủ, cải thiện môi trường làm việc và nâng cao đời sống Cán bộ viên chức trên cơ sở nguồn thu của bệnh viện, có chính sách thu hút, đãi ngộ, bố trí sử dụng, luân chuyển cán bộ hợp lý, đáp ứng với yêu cầu phát triển của bệnh viện.
  * Đảm bảo cung cấp thuốc đáp ứng với yêu cầu khám chữa bệnh, Quản lý sử dụng thuốc an toàn, hợp lý và hiệu quả.
  * Nâng cao chất lượng nguồn nhân lực qua tăng cường liên kết Viện Trường trong và ngoài nước.


**Để thành công hoàn thành các chỉ tiêu năm 2022**
**_1. Trách nhiệm của Thủ trưởng_**
  * Giao nhiệm vụ, chỉ tiêu, kế hoạch cụ thể cho từng Khoa/Phòng/ đơn vị; kiểm tra các bộ phận thực hiện theo chương trình, kế hoạch đã đặt ra và giải quyết những phát sinh mới sau Hội nghị; 
  * Tạo điều kiện thuận lợi cho CB, CC, VC hoàn thành tốt nhiệm vụ được giao;
  * Thực hiện đầy đủ, kịp thời các chính sách như tiền lương, tiền thưởng, phúc lợi cho CB, CC, VC; Thực hiện công khai tài chính, phúc lợi của bệnh viện theo quy định của Bộ Tài chính;
  * Tạo điều kiện để Ban TTND của bệnh viện hoạt động theo Luật Thanh tra 2010, thực hiện đầy đủ chế độ cho các thành viên Ban TTND và bảo đảm cho Công đoàn thực hiện tốt Luật Công đoàn 2012. 
  * Cùng Ban Chấp hành công đoàn, định kỳ 6 tháng một lần tổ chức kiểm tra, đánh giá kết quả thực hiện Quy chế dân chủ cơ sở và Nghị quyết Hội nghị của bệnh viện, tổ chức “Đối thoại” với viên chức, người lao động để rút kinh nghiệm, bổ sung giải pháp mới và định ra những việc tiếp tục thực hiện.


**_2. Trách nhiệm của Ban Chấp hành công đoàn_**
  * Phối hợp với chính quyền tổ chức các đợt thi đua, theo dõi phong trào, sơ kết, tổng kết kịp thời; vận động toàn thể viên chức, người lao động hoàn thành tốt công tác được giao;
  * Cùng chính quyền tham gia quản lý, giám sát các hoạt động của bệnh viện theo luật Công đoàn, thực hiện đầy đủ các chỉ tiêu đề ra;
  * Hướng dẫn, đôn đốc, kiểm tra việc thực hiện Nghị quyết hội nghị; phát hiện và kiến nghị với Thủ trưởng các biện pháp giải quyết để thực hiện tốt Nghị quyết;
  * Chỉ đạo Ban TTND của đơn vị thực hiện quyền giám sát, kiểm tra theo quy định của pháp luật 
  * Phối hợp cùng chính quyền chăm lo cải thiện đời sống cho đội ngũ viên chức, người lao động;
  * Cùng với Thủ trưởng đơn vị, định kỳ 6 tháng một lần tổ chức kiểm tra, đánh giá tình hình thực hiện Quy chế dân chủ cơ sở, nội dung thực hiện công khai, Quy chế chi tiêu nội bộ, Nghị quyết Hội nghị và phong trào thi đua, thông báo cho toàn thể viên chức, người lao động của đơn vị được biết; phối hợp tổ chức đối thoại giữa Thủ trưởng đơn vị và viên chức, người lao động trong đơn vị.


_**3. Trách nhiệm của viên chức, người lao động**_
  * Đoàn kết, phấn đấu hoàn thành tốt các chỉ tiêu, nhiệm vụ được phân công trên cương vị công tác của mình, góp phần xây dựng đơn vị phát triển;
  * Nghiêm chỉnh chấp hành đầy đủ mọi chính sách, pháp luật, quy định của Nhà nước và nội quy, quy chế làm việc của bệnh viện; thực hành tiết kiệm, chống lãng phí và bảo đảm thông tin chính xác, kịp thời; 
  * Thực hiện các quy định về nghĩa vụ, y đức, văn hóa giao tiếp, quy tắc ứng xử, nguyên tắc trong hoạt động nghề nghiệp và những việc không được làm theo quy định của pháp luật;
  * Có tinh thần trách nhiệm trong công tác, giữ vững kỷ cương nề nếp, đảm bảo ngày giờ công. Nâng cao tính chủ động, tinh thần tự học, tự rèn, giữ gìn và bảo vệ tài sản chung;
  * Tích cực phản ánh kịp thời tình hình thực hiện của đơn vị và đóng góp ý kiến trên tinh thần xây dựng đúng nơi, đúng lúc, đúng quy định.



## Cảm ơn Merck Family Foundation và EuroCham với chiến dịch ‘Breathe Again Vietnam’


## ️ Trước làn sóng Covid: vì chúng tôi là nhân viên y tế!

_**Tôi đã từng hỏi nhiều nhân viên y tế đã đang và sẽ tham gia hoạt động chống dịch Covid rằng họ có sợ không?**_
_**Ai cũng trả lời là sợ, nhưng đi vẫn đi, bởi vì lúc này xã hội đang cần chúng ta nhất. Vốn dĩ khoác lên mình chiếc áo blouse trắng là mang sứ mệnh chữa bệnh cho nhân nhân, đặc biệt là tình hình dịch bệnh như lúc này.**_
_**(BS Hoàng Văn Triều - Bí thư đoàn Bệnh viện)**_
## **Sau khi nghỉ ngơi, họ lại tiếp tục đăng ký ra trận**
Có nữ bác sĩ B.C.U.N là bác sĩ khoa cấp cứu sau khi hậu sản 6 tháng thì đã vào nhận công tác tại bệnh viện và từ đó không gặp con nữa vì chị biết rằng… phải tham gia điều trị tại khu vực nguy hiểm, nguy cơ có thể lây bệnh cho con rất cao. Cô bác sĩ trẻ đành giao con lại cho ông bà còn mình ra trận chống dịch.
Mỗi lần nhắc đến con, đôi mắt người mẹ lại ánh lên vẻ đượm buồn vì hơn 3 tháng nay chưa thể về nhà để bế đứa con của mình, không thể tiếp tục duy trì cho con bú sữa mẹ như mong muốn của các bà mẹ khác. Nghề của cô không ai có thể thay thể được nên phải hi sinh lợi ích riêng tham gia chống dịch bệnh, bảo vệ cộng đồng. 
**Tạm xa gia đình để đảm bảo an toàn cho người thân yêu**
Vì trong nhà có con nhỏ và người thân chưa chích ngừa Covid-19, nhưng bản thân lại công tác tại môi trường đầy nguy cơ phơi nhiễm Covid-19, BS Q.B.Đ xin chuyển hẳn “hộ khẩu” vô bệnh viện ở nội trú để tiện cho công tác trực gác cũng như nhanh chóng có mặt khi có sự điều động khẩn cấp của bệnh viện. 
BS Đ. kể “Có lần thèm ăn cơm nhà, vợ nhà đã nấu cơm sẵn, tan ca tôi chạy về nhà, ăn cơm một mình dưới mái hiên rồi nhìn vào nhà nơi con đang chơi đùa. Nhưng tôi không thể ôm con, không thể chơi đùa với con.” Sau khi ăn xong, anh lại tất tả vẫy tay chào vợ và con qua cánh cửa rồi trở vào bệnh viện. Tôi biết rằng lý do thèm ăn cơm nhà là phụ, về nhìn thoáng qua gia đình yêu thương của mình mới là chính.
**Khoa Cấp cứu, "thành trì" bảo vệ sức khỏe người dân kiên cố**
Những ngày qua, dịch Covid-19 diễn tiến phức tạp trên địa bàn TPHCM đã khiến cho đội ngũ y tế tham gia chống dịch vất vả hơn bao giờ hết. Cũng như nhiều bệnh viện khác trên địa bàn thành phố, Bệnh viện Nguyễn Tri Phương đã liên tục gửi hàng trăm chiến sĩ lần lượt ra tiền tuyến. Họ làm việc liên tục trong nhiều giờ đồng hồ nhằm truy vết thần tốc, khoanh vùng dịch, tiêm ngừa văcxin cho cộng đồng, hỗ trợ bệnh viện dã chiến…
Ở hậu phương, chúng tôi cũng có 1 tòa thành trì cần được bảo vệ cẩn mật. Đó chính là bệnh viện. Và bức tường kiên cố để giữ vững tòa thành trì là các chiến sĩ tại khoa Cấp cứu. 
Đặc biệt, vào mùa dịch, người bệnh thường có tâm lý ngại vô bệnh viện, ngại đi khám bệnh. Vì lý do này, những bệnh nhân vào với khoa Cấp cứu thời điểm này thường là những ca rất nặng hoặc nhập viện trễ. Các bác sĩ phải chạy hết công suất để chẩn đoán và điều trị mới kịp thời cứu lấy tính mạng bệnh nhân. Khoa Cấp cứu của một bệnh viện còn phải đảm bảo công tác sàng lọc, rà soát nguy cơ Covid-19 trước khi cho bệnh nhân nhập viện, tránh để nguồn bệnh đi sâu vào nội viện. Chỉ cần 1 lỗ thủng thôi, hậu quả sẽ rất nghiêm trọng.
Bệnh nhân N.T.B (sinh năm 1939) nhập khoa Cấp cứu trong tình trạng ho, khó thở. Bệnh nhân được xử trí và làm các xét nghiệm được chuẩn đoán nhiễm virus SARS-CoV-2 biến chứng suy hô hấp. Tình trạng bệnh nhân xấu dần, suy hô hấp không cải thiện với oxy phải can thiệp bằng đặt nội khí quản, thở máy. Con gái đi cùng bệnh nhân vào viện cũng được xét nghiệm Covid-19 ngay sau khi bệnh nhân có kết quả test nhanh dương tính. Kết quả người con đi cùng cũng bị nhiễm virus SARS-CoV-2 và bắt đầu có triệu chứng ho, đau họng 1 ngày sau đó.
Hàng ngày khi tôi đi thăm buồng, cô con gái vẫn cứ luôn hỏi thăm xem tình hình mẹ như thế nào, dù cách nhau chỉ một tấm kính thôi nhưng người con cũng chỉ có thể ngồi từ bên đây nhìn mẹ mình ở bên kia và cầu mong cho mẹ mau khỏi bệnh. 
Thật vui khi tình trạng của bà dần cải thiện sau 4 ngày thở máy, các thông số về khí máu đã dần ổn định, phổi đã có cải thiện nhiều trên phim Xquang, tuy nhiên vẫn trong giai đoạn nguy hiểm không thể chủ quan bất kỳ giây phút nào. Hi vọng với những tín hiệu tốt như vậy trong thời gian tới bệnh nhân có thể cai máy thở và rút nội khí quản. 
_**Ghi chú: Hình phổi tổn thương tiến triển nhanh vì Covid**_
01 ekip trực Cấp cứu có 4 bác sĩ, 5 điều dưỡng và 4 hộ lý chia cho cả 3 khu vực/ca trực 12 tiếng. Nếu có trường hợp người bệnh có dấu hiệu nghi ngờ, toàn bộ ekip trực sẽ phải nán lại, lấy mẫu xét nghiệm, chỉ khi nào kết quả âm tính mới được về nhà. Chính vì thế sau 12h liên tục làm việc, họ chưa chắc đã được... về nhà. 
Y bác sĩ của khoa Cấp cứu và của toàn bệnh viện gần như phải làm việc liên tục trong ca trực bởi lẽ bệnh nặng hơn, giải thích cho người bệnh hiểu, hỏi dịch tễ và khai thác thông tin lâu hơn đã khiến cho hiệu suất điều trị cho một ca chậm đi rất nhiều so với “thời bình”. Nhiều người ngã vội ra bàn ghế chỉ để nghỉ ngơi vài phút rồi lại đi làm tiếp. 
Bữa ăn của họ chỉ là những bữa ăn vội vàng với thức ăn thường đã nguội lạnh - bởi lẽ ở ngoài kia, người bệnh...vô nữa rồi, thức ăn có thể chờ chúng ta nhưng người bệnh không thể. Nhiều khi sau khi xử lý xong cho bệnh nhân nhìn lên đồng hồ, đã là 15h00, khi bụng không còn biết đói nữa, các đồng nghiệp của tôi cũng chẳng nhớ ra là đã ăn trưa chưa.
**Nỗi buồn tan biến đi khi người bệnh khỏe lên mỗi ngày**
Họ buồn chứ, buồn vì vừa làm vừa nghĩ xem đứa con của họ giờ này ở nhà không biết có được cho ăn đúng giờ, có quấy khóc đòi mẹ hay không. Buồn bởi họ giờ này không thể ở bên cạnh làm chỗ dựa cho những chông chênh, bất an của người thân. Nhưng bệnh nhân mỗi ngày một khỏe lên, bệnh nhân cải thiện, xuất viện và cảm ơn y bác sĩ, bao nhiêu nỗi buồn và vất vả đều tan đâu hết.
Đó là một đêm trực tại Khoa Cấp cứu, chúng tôi tiếp nhận 1 sản phụ vào viện với triệu chứng đau bụng chuyển dạ lúc 23h30, thai 37 tuần. Sản phụ ngay lập tức được làm các xét nghiệm cần thiết và test nhanh Covid-19 song song với đó là chuẩn bị công tác hỗ trợ sinh. 
Bé sinh thường lúc 0h05, tuy nhiên sau sinh có dấu hiệu giảm oxy máu, chẩn đoán suy hô hấp sơ sinh, bé được chuyển lên khoa Nhi của bệnh viện hỗ trợ điều trị và theo dõi lúc 0h20. 
Đến sáng kết quả xét nghiệm khẳng định RT PCR của người mẹ là dương tính. Mẹ bé được chuyển đến khu điều trị Covid-19 của Bệnh viện Nguyễn Tri Phương. Cô của bé đi cùng cũng được cách ly do thuộc diện F1 tiếp xúc gần. Em bé phải thở oxy, thật thương biết bao. 
Các cô điều dưỡng đã đi xin sữa và tập bú cho bé, lại quyên góp ủng hộ mua tả, áo quần và sữa thêm cho bé do ba mẹ bé chưa kịp chuẩn bị. Lúc đầu mới tập bú, bé bị ọc sữa 2-3 lần. Nhưng với sự kiên trì của các cô và nghị lực của bé, sau vài ngày điều trị, bé đã được cai thở oxy và bú rất giỏi; mỗi cử được 30ml sữa. Hôm nay bé sẽ được chích viêm gan siêu vi B và chích ngừa lao như bình thường. Đợi vài hôm nữa, khi kết quả xét nghiệm lần 2 của cô ruột âm tính, con sẽ được về nhà. 
Thật vui vì giữa đại dịch dù gặp nhiều khó khăn nhưng công tác khám chữa bệnh vẫn hoạt động trơn tru, đặc biệt là sự tin tưởng và hợp tác của người nhà đối các y bác sĩ trong những lúc rối ren như thế để đem lại hiệu quả điều trị tốt nhất. Hãy cùng nhau cố gắng để vượt qua đại dịch, bởi vì "không có ai bị bỏ lại phía sau". 
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh

## ️ Hiệp hội doanh nghiệp Châu Âu đồng hành cùng phòng chống Covid tại BV

EuroCham được thành lập năm 1998, là tiếng nói đại diện cho hơn 1.000 doanh nghiệp châu Âu, trong đó có nhiều doanh nghiệp hàng đầu thế giới. Hiện nay, EuroCham có 18 Tiểu ban Ngành nghề và 9 Hiệp hội Doanh nghiệp trực thuộc đang hoạt động tích cực tại Việt Nam

## Nhận tài trợ máy xét nghiệm nhanh Covid-19

Xin trân trọng cảm ơn:
- Những Người Yêu Sài Gòn, 
- Công Ty UniqueM và 
- Công Ty Việt Tiến

## CHUNG TAY VÌ MIỀN TRUNG

Kính thưa quý mạnh thường quân
Trước những thiên tai xảy ra liên tiếp tại miền Trung, mỗi chúng ta đều đầy khắc khoải với những mất mát, khổ đau của đồng bào.
BV Nguyễn Tri Phương đã nhiều lần được quý mạnh thường quân tin cậy, với chiến dịch hỗ trợ Đà Nẵng - Quảng Nam huy động được hơn 1 tỷ 200 triệu. Đây là những điều vô cùng quý giá.
Nay, xin được tiếp nối tinh thần chia sẻ lúc gian nan - hoạn nạn; BV xin được là đầu mối nhận sự đóng góp của các tấm lòng trong xã hội để chúng tôi có thể thực hiện những hành động thiết thực nhất hỗ trợ cho miền Trung.
Trong trường hợp muốn đóng góp ở các hình thức khác như qua hệ thống ví điện tử (Momo, Zalopay, Viettelpay...): xin liên hệ qua các kênh truyền thông của BV để đội ngũ quản trị hướng dẫn ạ!
  * Lotus: <https://lotus.vn/p/follow.html?profile_token=9a2d6b33-8c9e-4091-ad82-ba550ea3cbcf>
  * Fanpage: [fb.com/bvntp](http://fb.com/bvntp)
  * Zalo official: [zalo.me/1744466261097093886](http://zalo.me/1744466261097093886)



## Tổng Công ty Cổ phần Vận Tải dầu khí - PVTrans tặng xe cứu thương hỗ trợ phòng chống Covid-19

BV Nguyễn Tri Phương đón tiếp từ Tổng Công ty Cổ phần Vận Tải dầu khí - PVTrans: 
  * Ông Phạm Việt Anh – Bí thư Đảng ủy, Chủ Tịch Hội đồng quản trị 
  * Ông Nguyễn Viết Long – Phó Tổng Giám đốc 
  * Ông Lưu Trung Duy - Chủ tịch Công đoàn
  * Ông Nguyễn Văn Bằng – Trưởng Ban An toàn Pháp Chế
  * Ông Đào Quang Trung – Phó Ban An toàn Pháp chế 
  * Ông Đào Hà Thanh – Phó Chánh Văn Phòng


Xin trân trọng cảm ơn./.

## Hoa hậu Đền Hùng Giáng My đến thăm và tặng quà động viên lực lượng chống dịch


## GIAN HÀNG YÊU THƯƠNG THƯỜNG XUYÊN HOẠT ĐỘNG


## Lời cảm ơn nhân ngày Thầy thuốc Việt Nam


## ️ Đại hội Đại biểu Hội Chữ thập đỏ BV Nguyễn Tri Phương lần thứ VII, nhiệm kỳ 2021 - 2026

_**Hiệp thương Nhân sự BCH cho Đại hội Hội Chữ Thập Đỏ nhiệm kỳ 2021-2026 như sau:**_ 1. Ông Võ Đức Chiến - Giám đốc bệnh viện. 2. Ông Phan văn Ngọc - TK. Khoa Khám bệnh 3. Ông Lê Huy Hùng - TK. Khoa Nhi 4. Ông Trần Anh Triết - Nguyên TK. Giải phẫu bệnh. 5. Ông Phan Thanh Vân - TP.TCKT 6. Ông Đặng Trung Hiếu - TK. Khoa Mắt 7. Bà Trần Thị Như Mai - TT.Hội chữ thập đỏ 8. Bà Trần Thanh Nhàn - PTP.CTXH 9. Bà Trương Thùy Trang - PTP. Tổ chức cán bộ 10. Bà Ngô Kim Tiền - Khoa Dược 11. Ông Hoàng văn Triều - PTP. Quản lý chất lượng 

## Ủng hộ phòng chống COVID-19

**Thầy Toàn Hạnh, Trụ Trì Thiền Viện Trúc Lâm Nhật Quang, Phường Long Bình, Tp Biên Hoà , Tỉnh Đồng Nai**
**Đã tham gia trao tặng 5000 khẩu trang ủng hộ hoạt động phòng chống dịch COVID-19 tại Bệnh viện Nguyễn Tri Phương**

## Ủng hộ nước sát khuẩn chống dịch

Xin trân trọng cảm ơn quà tặng tri ân ngành y tế của công ty Aruwa dành tặng cho đội ngũ nhân viên y tế bệnh viện Nguyễn Tri Phương: 10 Thùng dung dịch diệt khuẩn sinh học ARUWA (tương đương 200 lít) để ủng hộ hoạt động phòng, chống dịch COVID-19.
Nhưng quà tặng của quý mạnh thường quân sẽ giúp đội ngũ y bác sĩ thêm vũ khí chống lại bệnh dịch

## Những đôi giày thay lời tỏ lòng tri ân

Bệnh viện xin tri ân sự chăm sóc này của đơn vị: <https://motdoigiay.vn/>

## CÔNG TY LỐP KUMHO TRI ÂN SỰ ĐÓNG GÓP CỦA NGÀNH Y TẾ TRONG PHÒNG CHỐNG DỊCH BỆNH COVID-19

Phần quà tặng bao gồm:
  * 350 voucher giảm giá khi thay lốp xe;
  * 350 bịch khăn giấy tiệt trùng;
  * 350 chai nước rửa tay Lifebouy.


Bệnh viện Nguyễn Tri Phương trân trọng cảm ơn những món quà nghĩa tình này./.

## CÔNG TY CP THỰC PHẨM DINH DƯỠNG NUTIFOOD

Công ty CP thực phẩm Nutifood đã trao tặng cho đội ngũ nhân viên y tế bệnh viện Nguyễn Tri Phương: 300 thùng nước uống dinh dưỡng ủng hộ cho hoạt động phòng, chống dịch COVID-19.

## Cửa hàng dụng cụ Minh Long hỗ trợ bệnh viện

Cửa hàng dụng cụ y khoa Minh Long đã trao tặng cho đội ngũ nhân viên y tế bệnh viện Nguyễn Tri Phương: 2000 khẩu trang vải y tế để ủng hộ hoạt động phòng, chống dịch COVID-19.
**Xin trân trọng cảm ơn**

## TIẾP TỤC ĐỒNG HÀNH TRONG TÌNH HÌNH 'BÌNH THƯỜNG MỚI'

Xin trân trọng cảm ơn sự đồng hành của quý mạnh thường quân cùng bệnh viện phòng chống bệnh dịch./.

## Cắt tóc miễn phí trong mùa dịch

Đây là chương trình thiện nguyện vô cùng ý nghĩa mà nhóm Hành trình thắp lửa” đã dành tặng cho tập thể nhân viên y tế và các bệnh nhân cùng thân nhân trong thời gian phòng chống COVID-19

## Tập Đoàn Hành Trình Thành Công Mới ( NSJ Group) đồng hành cùng BV

Xin trân trọng cảm ơn sự đồng hành quý báu ủng hộ hoạt động phòng chống dịch COVID-19 tại Bệnh viện Nguyễn Tri Phương 

## Món quà từ Hội kiểm soát nhiễm khuẩn Thành phố Hồ Chí Minh

BV Nguyễn Tri Phương chân thành cảm ơn sự quan tâm và đồng hành của Quý tổ chức.

## 180 chai nước rửa tay ion đã gửi đến nhân viên y tế để cùng phòng chống dịch

Bs CK2 Trương Bá Quân (Thanh tra Bộ y tế) đồng hành cùng công ty VIETNAM PROJECT và công ty cổ phần TM-DV-Du lịch Vịnh San Hổ Đỏ đã trao phần quà này cho bệnh viện

## Xin trân trọng ghi nhận những đóng góp phòng chống dịch COVID-19

STT | TÊN | TÊN HÀNG HÓA | SỐ LƯỢNG NHẬP  
---|---|---|---  
1 | QUỸ TÂM NGUYỆN VIỆT | KHẨU TRANG KHÁNG KHUẨN KTVT | 4,000  
2 | CÔNG TY CP CIZZA (BÀ ANNA THINH LE) | KHẨU TRANG VẢI | 1,500  
3 | DIỄN VIÊN DƯƠNG HỒNG LOAN | KHẨU TRANG VẢI KHÁNG KHUẨN  | 3,000  
4 | NGUYỄN ANH THƯ | KHẨU TRANG VẢI KHÁNG KHUẨN  | 300  
5 | CHỊ PHƯƠNG | KHẨU TRANG Y TẾ  | 2,500  
6 | TRẦN THỊ CHI LAN | KHẨU TRANG VẢI | 760  
7 | CÔNG TY TNHH SX TM SONG TRẦN | KHẨU TRANG VẢI | 1,000  
8 | CÔNG TY TNHH SX TM SONG TRẦN | KÍNH CHE | 50  
9 | NGUYỄN LÊ BẢO THUẬN | KHẨU TRANG Y TẾ  | 1,250  
PHẠM VĂN TUÂN  
10 | ERINAKAD (NHẬT NGỮ CỐ ĐÔ) | KHẨU TRANG VẢI KHÁNG KHUẨN  | 100  
11 | LÂM THỊ NGỌC TRINH | KHẨU TRANG VẢI KHÔNG DỆT KHÁNG KHUẨN | 300  
12 | NGÂN HÀNG TMCP SÀI GÒN CÔNG THƯƠNG | KHẨU TRANG VẢI KHÁNG KHUẨN  | 5,000  
CÔNG TY TNHH MAY THÊU THUẬN PHƯƠNG  
13 | ANH THẾ - BẠN BS VINH | KHẨU TRANG N95 (3M) | 50  
14 | HỘI BẠN BÈ CỦA L.A & HẢI VÂN | BỘ BẢO HỘ | 100  
BAO CHÙM TÓC | 200  
15 | CÔNG TY TNHH NSJ | KHẨU TRANG N95  | 300  
16 | NHÓM TỪ TÂM TP.HỒ CHÍ MINH | BỘ TRANG PHỤC PHÒNG HỘ | 100  
KHẨU TRANG GIẤY | 10,000  
17 | NHÓM PHẬT TỬ TP.HỒ CHÍ MINH | KHẨU TRANG CHỐNG THẤM | 200  
KHẨU TRANG GIẤY | 500  
BỘ BẢO HỘ (XANH+TRẮNG) | 200  
18 | CÔNG TY TNHH MAY THÊU THUẬN PHƯƠNG | KHẨU TRANG VẢI 3 LỚP | 5,000  
19 | CÔNG TY HOÀNG BẢO NGUYÊN | NƯỚC RỬA TAY NHANH (100ML) | 40  
NƯỚC RỬA TAY NHANH (300ML) | 40

## CÔNG TY TNHH KIMBERLY-CLARK VIỆT NAM CHUNG TAY PHÒNG CHỐNG DỊCH COVID-19

Để góp phần chung tay cùng phòng chống dịch Covid-19, hôm nay ngày 21/04/2020, Công ty TNHH Kimberly-Clark Việt Nam đã trao tặng cho Bệnh viện Nguyễn Tri Phương bộ thiết bị - vật tư hỗ trợ phòng chống dịch bệnh Covid-19 như sau:
- 02 bộ máy rửa tay tự động gồm Máy rửa tay cảm ứng tự động thương hiệu SmarTech và kệ.
- 36 lít dung dịch rửa tay khô thương hiệu Green Cross
- 60 bộ đồ bảo hộ kháng khuẩn theo tiêu chuẩn quốc tế.
- 96 gói Khăn ướt thương hiệu Huggies
Bệnh viện Nguyễn Tri Phương trân thành cảm ơn đến Quý Công ty đã hỗ trợ phòng chống dịch bệnh Covid-19.

## BỒN RỬA TAY MỚI CHO BỆNH NHÂN TRONG MÙA DỊCH

Trong công tác phòng chống dịch COVID-19, việc nâng cao ý thức rửa tay là điều vô cùng quan trọng
Bệnh viện xin cảm ơn những đóng góp hết sức thiết thực này./.

## BỆNH VIỆN ĐƯỢC NHẬN 10 MÁY LỌC NƯỚC 

Đây là hệ thống máy lọc nước bù khoáng, tốt cho sức khỏe người dùng 
Đồng thời cũng có hệ thống cảnh báo thông minh khi cần thay cột lọc được cài đặt sẵn trong máy 

## GỬI PHẦN QUÀ CỦA MẠNH THƯỜNG QUÂN CHO NGƯỜI THAM GIA CHỐNG DỊCH COVID-19

Công ty sản xuất kính bảo hộ Đại Kim Thành đã gửi Bệnh viện 400 kính bảo hộ
Ngoài ra nhóm Phật tử tại Thành phố Hồ Chí Minh cũng đã tặng nhiều món quà phòng hộ cá nhân cho BV

## Phần quà từ công ty MEDTRONIC


## BV NGUYỄN TRI PHƯƠNG THAM GIA CHỐT PHÒNG DỊCH CỦA THÀNH PHỐ

Công việc tầm soát diễn ra liên tục trong ngày nên cần chia ca sáng - tối, và luôn đảm bảo có lực lượng làm việc để tầm soát thân nhiệt tại các cửa ngõ 

## BỆNH VIỆN NHẬN ĐƯỢC NHỮNG MÓN QUÀ DINH DƯỠNG GỬI CHO NGƯỜI CHỐNG DỊCH

Trứng nướng này có thể sử dụng ngay và bổ dưỡng vì cơ chế xử lý vừa an toàn vừa hiệu quả đã loại đi một số chất có thể làm tăng cholesterol xấu cho cơ thể

## 5000 khẩu trang vải đồng hành cùng BV phòng chống COVID-19

Thay mặt BGĐ, BS CK2 Đỗ Tuấn Linh đã nhận món quà quý này và cảm ơn các mạnh thường quân đã quan tâm đồng hành cùng nhân viên y tế BV Nguyễn Tri Phương
Ngoài 5.000 khẩu trang vừa nhận, số lượng khẩu trang và kính che hiện tại của BV Nguyễn Tri Phương nhận được như sau
TÊN HÀNG HÓA | SỐ LƯỢNG NHẬP | SỐ LƯỢNG TỒN  
---|---|---  
KHẨU TRANG KHÁNG KHUẨN KTVT | 4,000 | 1,496  
KHẨU TRANG XANH 4 LỚP | 2,500 | 0  
KHẨU TRANG VẢI | 1,500 | 1,500  
KHẨU TRANG VẢI KHÁNG KHUẨN  | 3,000 | 2,560  
KHẨU TRANG VẢI KHÁNG KHUẨN  | 300 | 300  
KHẨU TRANG Y TẾ  | 2,500 | 2,441  
KHẨU TRANG VẢI | 760 | 760  
KHẨU TRANG VẢI | 1,000 | 1,000  
KÍNH CHE | 50 | 50  
KHẨU TRANG Y TẾ  | 1,250 | 660  
KHẨU TRANG VẢI KHÁNG KHUẨN  | 100 | 100  
KHẨU TRANG VẢI KHÔNG DỆT KHÁNG KHUẨN | 200 | 200  
Xin trân trọng cảm ơn quý mạnh thường quân

## NHỮNG MÓN QUÀ QUÝ MÙA CHỐNG DỊCH COVID-19

Xin Trân trọng cảm ơn: 
1. Chị Anna Thinh Le - Cty CP Ciza -417 Võ Văn Tần, P.5, Q.3, đã tặng 1500 khẩu trang vải cho nhân viên y tế
2. Công ty TNHH Sản xuất Thương mại Song Trần - 52/2 Huỳnh Thiện Lộc, P. Hoà Thạnh, Q. Tân Phú, TP.HCM - đã tặng 500 khẩu trang kháng khuẩn 3 lớp

## BỆNH VIỆN NGUYỄN TRI PHƯƠNG ĐƯỢC TÀI TRỢ 01 PHÒNG ÁP LỰC ÂM 

Trong cuộc chiến chống dịch COVID-19, bệnh viện được nhận tài trợ 01 phòng áp lực âm để có thể nâng cao năng lực điều trị khi tình hình dịch bệnh chuyển biến xấu. Điều nay đã giúp đội ngũ y bác sĩ thêm yên tâm trong hoạt động chuyên môn hàng ngày.
Phật giáo đã luôn đồng hành cùng dân tộc - trích lời phát biểu của Thầy Thích Thiện Quý, phó ban trị sự Giáo hội Phật giáo Việt Nam tại thành phố Hồ Chí Minh - từ hàng ngàn năm lịch sử và bây giờ sẽ vẫn luôn như thế.
Bệnh viện Nguyễn Tri Phương, một lần nữa, xin trân trọng cảm ơn sự đồng hành quý báu này.

## Hiến máu có làm giảm sức đề kháng của cơ thể, làm virut dễ dàng tấn công cơ thể hơn hay không?

Sau mỗi dịp lễ Tết và đặc biệt là trong giai đoạn phòng chống virus như hiện nay, tình trạng thiếu máu tại các ngân hàng máu thường xuyên xảy ra.
Hiến máu chủ yếu là hiến hồng cầu. Máu gồm có huyết tương chiếm 55% thể tích máu và các tế bào máu chiếm 45% còn lại. Các tế bào máu gồm có hồng cầu chiếm số lượng nhiều nhất, kế tiếp là bạch cầu và tiểu cầu.
  * Đời sống của hồng cầu là khoảng 90 ngày, dài nhất trong các tế bào máu. Đây là khoảng thời gian cần thiết để một hồng cầu sinh ra, thực hiện chức năng và bị tiêu hủy trong gan, lá lách. Nói một cách khác, mọi hồng cầu lưu hành trong máu đều lần lượt được tủy xương sinh ra và được thay thế sau khi hoàn thành nhiệm vụ. Vậy nên, khi cho đi một phần lượng máu rất nhỏ trong cơ thể, đối với bản thân người cho sẽ không bị ảnh hưởng gì, nhưng với người nhận lại là một “nguồn sống” mới.
  * Trong cơ thể chúng ta có từ 4,5 – 5 lít máu, vì thế khi chúng ta cho đi một đơn vị máu thông thường từ 250ml – 350ml (tương đương với 5% tổng thể tích máu toàn cơ thể) sẽ tạo điều kiện kích thích tủy xương tăng sinh hồng cầu tạo ra hồng cầu mới. Sau khi hiến máu, lượng máu sẽ được hồi phục sau 3 -5 ngày. Các thành phần trong máu được tái tạo và trẻ hóa, có sức đề kháng chống lại bệnh tật.
  * Chính nhờ chu kỳ sinh lý của máu, hiến máu hoàn toàn không có ảnh hưởng gì tới sức khỏe nếu thể tích máu hiến phù hợp với thể trạng cũng như tần suất hiến hợp lý.


Lợi ích của việc hiến máu :
  * Giúp kích thích khả năng tạo máu
  * Thể tích máu được ước tính là chiếm 1/10 khối lượng cơ thể. Như vậy, một người trưởng thành nặng trung bình 50kg sẽ có lượng máu khoảng 5000 ml. Tuy nhiên, quy định hiến máu mỗi lần là không quá 9 ml/kg (tức khoảng 450 ml) và cũng không quá 500 ml trong một lần hiến. Vậy nên, lượng máu cho đi là không quá nhiều.
  * Hơn thế nữa, khi một lượng máu trong cơ thể bị mất đi, hệ thống tủy xương sẽ có phản ứng tạo ra nguồn máu mới. Chính điều này giúp máu trong cơ thể có cơ hội được thay đổi, chất lượng hồng cầu được trẻ hóa nên sẽ làm việc hiệu quả hơn.
  * Thực tế, chỉ có phụ nữ trong lứa tuổi sinh sản mới có quá trình mất máu sinh lý mỗi tháng do chu kỳ kinh nguyệt. Còn lại các đối tượng khác như nam giới, phụ nữ sau mãn kinh, các tế bào hồng cầu được thay mới một cách chậm chạp, khả năng ứng phó với sự mất máu sẽ kém đi nếu thiếu máu đột ngột xảy ra. Chính vì thế, đi hiến máu định kỳ là một dịp để nguồn máu trong huyết quản trở nên tươi mới hơn cũng như hệ tạo máu thường xuyên được trau dồi.


**Các nghiên cứu hiện có chưa cho thấy bất kỳ bằng chứng nào về việc hiến máu có thể làm giảm hiệu quả của tiêm bất cứ loại vắc xin nào bao gồm vắc xin phòng chống COVID-19 đối với cơ thể người được tiêm phòng, cũng như việc được truyền máu từ người đã được tiêm vắc xin COVID không nhận thấy có ảnh hưởng bất lợi nào ở người bệnh nhận máu.**
Khi cơ thể bị nhiễm vi rút SARS-CoV-2 hoặc được tiêm vắc xin chống vi rút này, hệ thống miễn dịch của cơ thể sẽ sản sinh ra các tế bào bạch cầu lympho T và các kháng thể đặc biệt, có khả năng ghi nhớ để chiến đấu với tác nhân gây bệnh COVID-19 nếu bị chúng tấn công trong tương lai. Các tế bào có khả năng đáp ứng miễn dịch này được lưu giữ trong máu và một số cơ quan khác như gan, lách, hạch.
Chỉ một lượng rất nhỏ các tế bào bạch cầu được lấy đi trong quá trình hiến máu, không làm ảnh hưởng đến hệ miễn dịch, không làm mất đi các kháng thể được hình thành trong quá trình đáp ứng với vắc xin. Việc hiến máu không hề loại bỏ vắc xin khỏi cơ thể.
Nói cách khác, cơ thể người trưởng thành có trung bình khoảng 4 – 6 lít máu (tùy thuộc vào cân nặng) và mỗi lần hiến máu chỉ cho đi 350 – 450 ml máu. Số lượng kháng thể chống lại vi rút SARS-CoV-2 trong lượng máu hiến là không đáng kể, trong khi cơ thể lại thường xuyên sản sinh ra lượng máu mới, bao gồm cả các tế bào bạch cầu cần cho đáp ứng miễn dịch.
Hi vọng những giọt máu hồng của chúng ta sẽ đem đến những sự sống cho những bệnh nhân đang cần. Đặc biệt trong giai đoạn khan hiếm máu như hiện nay

## Thành lập câu lạc bộ Thiền bệnh viện Nguyễn Tri Phương

Căn cứ nhu cầu về rèn luyện thể chất và tâm lý của nhân viên y tế;
Tham khảo từ Nghiên cứu “Giảm Những Vấn Đề Sức Khỏe Tâm Trí Trong Chăm Sóc Sức Khỏe Cho Nhân Viên Y Tế (NVYT) tại Bệnh Viện Bệnh Nhiệt Đới” phối hợp giữa Đơn vị Nghiên cứu lâm sàng Đại học Oxford và Bệnh viện Bệnh Nhiệt đới;
Căn cứ thành công của hoạt động tập Yoga của bệnh viện;
Học tập từ mô hình Phòng thư giãn tại BV Bệnh Nhiệt đới,
Ban Chấp Hành Đoàn Bệnh viện xây dựng câu lạc bộ Thiền cho nhân viên bệnh viện như sau:
**Mục đích, vai trò của Thành lập Câu Lạc Bộ Thiền**
  * Nâng cao sức khỏe của cán bộ - công nhân viên bệnh viện
  * Tạo sân chơi giao lưu của các cá nhân yêu thích bộ môn Thiền
  * Giảm áp lực của công việc cho cán bộ - công nhân viên bệnh viện, nâng cao hiệu quả trong công tác khám chữa bệnh và chăm sóc bênh nhân.


**Nội dung**
  * Thành lập câu lạc bộ Thiền Bệnh viện Nguyễn Tri Phương với số lượng nòng cốt 20 người (có danh sách đính kèm)
  * Đề xuất trưởng Ban – phụ trách câu lạc bộ : Bác sĩ Cao Văn Hội – Phó khoa Hô Hấp, với vai trò hỗ trợ, dẫn dắt cho những thành viên mới tham gia khi câu lạc bộ đã đi vào hoạt động ổn định.


**Cơ sở vật chất**
  * Nhóm tập Yoga và Câu lạc bộ Thiền sẽ dùng chung 01 phòng chức năng
  * Phòng chức năng sử dụng là phòng cạnh hội trường A được công ty SSI trao tặng 



## XÃ HỘI ĐỒNG HÀNH CÙNG NHÂN VIÊN Y TẾ TRONG CUỘC CHIẾN CHỐNG DỊCH

Cuộc chiến chống COVID-19 còn cần rất nhiều nhân lực - tài lực và vật lực. BV Nguyễn Tri Phương xin trân trọng cảm ơn mỗi sự đóng góp của các mạnh thường quân trong xã hội.
Chúng tôi tin rằng với sự đồng lòng của tất cả xã hội, dịch bệnh sẽ bị đẩy lùi!!

## THÊM KÍNH CHẮN - KHẨU TRANG CHO NHÂN VIÊN Y TẾ

Bệnh viện xin cảm ơn nhóm tình nguyện Xuân yêu thương đã tặng 100 kính chắn cho nhân viên y tế
Đồng thời cũng xin cảm ơn nhiều nhà hảo tâm đã tặng khẩu trang N95 hoặc khẩu trang vải y tế
Cùng chung tay - chúng ta sẽ đẩy lùi dịch bệnh!!!

## Chương trình tư vấn trực tuyến


## ĐỘI BÓNG ĐÁ NỮ BỆNH VIỆN NGUYỄN TRI PHƯƠNG ĐẠT GIẢI CAO NĂM 2019

Đội bóng giành chiến thắng giòn giã 3-0 trước đội nữ BV Nhi Đồng TP ngày 10/12
Đội tuyển nữ xuất sắc vượt qua đương kim vô địch năm 2018 và giành tấm vé duy nhất của bảng đấu để đi tiếp.
Đội tuyển đã tiến đến trận chung kết lịch sử sau chiến thắng 3-0 trong trận bán kết với đội BV Phạm Ngọc Thạch
Tại vòng Chung kết, với tất cả sự cố gắng, đội tuyển bóng đã nữ đã đạt hạng Nhì chung cuộc ở tỷ số 1-3 
Xin chúc mừng những thành tích đáng tự hào này!!!

## GIỌT MÀU HỒNG CỨU NGƯỜI MÙA DỊCH

Rất nhiều nhân viên y tế đã tham gia hiến máu - cứu người
Dẫu đang rất bận rộn chăm sóc bệnh nhân, nhưng cứu người luôn là thiên chức cao cả của người thầy thuốc
Không những thế, để giúp bệnh nhân đang nằm viện, nhân viên của khoa Xét nghiệm cũng đã chủ động qua Bệnh viện Truyền máu Huyết học hiến máu 

## Lớp tập huấn sơ cấp cứu ban đầu miễn phí lần 2

Lớp học tiếp tục nhắc đến các kiến thức cần thiết ban đầu về:
- Chăm sóc và cố định vết thương
- Cấp cứu ngừng tuần hoàn - hô hấp 
- Xử lý ban đầu gãy xương - bong gân
Những hình ảnh và video của buổi tập huấn sẽ được đăng tải tại 
<https://www.facebook.com/dichvuyteBVNTP>
<https://www.youtube.com/channel/UChxKxP26ogaXAnT6dwwdP-w/featured?disable_polymer=1>
Các cơ quan, công ty muốn được tổ chức (có cấp chứng nhận tham gia) lớp sơ cấp cứu ban đầu cho nhân viên; có thể liên hệ (028)73077307 bấm số nội bộ 20661 gặp BS Lương Công Minh./.

## Đoàn BV cùng tham gia hoạt động chăm sóc sức khoẻ cộng đồng người cao tuổi nhóm ngôn ngữ Quảng Đông

Các nội dung hoạt động đã triển khai:
  * Báo cáo về nội dung Thoái hóa khớp gối: Bs Phạm Thế Hiển
  * Báo cáo về phòng chống loãng xương bằng dinh dưỡng: BS Lâm Vạn Phong
  * Phát tờ rơi tư vấn kiến thức: BS Lâm Vạn Phong và BS Lương Công Minh


Hoạt động đã nhận được nhiều phản hồi tích cực từ Hội quán Tuệ thành cũng như cộng đồng người cao tuổi nhóm ngôn ngữ Quảng Đông tại đây

## Phiên chợ chia sẻ yêu thương

Xã hội ngày nay vẫn còn nhiều đồng bào có hoàn cảnh khó khăn, những mảnh đời bất hạnh, khó khăn, và khi bệnh tật ập đến thì những hoàn cảnh đó càng cần được quan tâm
Nắm bắt được những điều đó đồng thời nhân ngày Quốc tế Hạnh phúc 20/03/2019 và Ngày Công tác Xã hội Việt Nam 25/03/2019, Bệnh viện Nguyễn Tri Phương tổ chức chương trình **“Phiên chợ chia sẻ yêu thương”.**
Chương trình mang đến ý nghĩa của việc tôn vinh giá trị cao quý, ý nghĩa nhân văn của nghề công tác xã hội, đồng thời phát huy truyền thống “Lá lành đùm lá rách” với tinh thần thương yêu, tương trợ và giúp đỡ lẫn nhau của người Việt Nam nói chung, của toàn thể nhân viên y tế Bệnh viện Nguyễn Tri Phương đối với bệnh nhân hoàn cảnh khó khăn nói riêng.
Phiên chợ diễn ra với sự ủng hộ, tham gia đông đảo các khách mời, các mạnh thường quân và chính các nhân viên y tế đến từ các khoa, phòng Bệnh viện Nguyễn Tri Phương thực hiện để cung cấp các mặt hàng chất lượng giá rẻ như mặt hàng ăn uống, may mặc, phụ kiện trang trí…
Tất cả số tiền thu được từ các gian hàng sẽ được ủng hộ vào quỹ hỗ trợ bệnh nhân nghèo trong bệnh viện và trao tặng nhiều phần quà cho bệnh nhân có hoàn cảnh khó khăn.
Nhằm khích lệ tinh thần các nhân viên tham gia, chương trình đã trao giải thưởng cho các khoa, phòng đã đạt thành tích tốt nhất trong phiên chợ này như trang trí gian hàng, số tiền quyên góp từ doanh thu đạt được cụ thể như: Khoa Lọc Máu, Khoa Dược, Khoa Khám bệnh, Phòng Công Tác Xã Hội…

## Hoạt động hiến máu tình nguyện cứu người

Trân trọng từng tấm lòng tham gia!!!

## Lớp tập huấn sơ cấp cứu ban đầu miễn phí 

Lớp học đã nhắc đến các kiến thức cần thiết ban đầu về:
- Chăm sóc và cố định vết thương
- Cấp cứu ngừng tuần hoàn - hô hấp 
Nhiều kiến thức bổ ích đã được thực hành và thị phạm ngay tại chỗ, nhờ đó các bạn sinh viên đã tiếp thu nhanh và phản hồi rất tích cực, từ đó lan truyền những kiến thức chuẩn về sơ cấp cứu ban đầu.
Vào ngày 15/9/2019 (Chủ nhật) sẽ là buổi thứ 2 tiếp tục chương trình tập huấn miễn phí này
Xin trân trọng kính mời tham gia bằng cách đăng ký [tại đây](https://www.facebook.com/events/896115840749451/)./.

## SỰ KIỆN SAVE OUR SEA

Chương trình được tổ chức tại Xã Cần Thạnh, Huyện Cần Giờ, Thành phố Hồ Chí Minh với sự tham gia nhiệt tình từ các Đoàn viên Bệnh viện Nguyễn Tri Phương, Tình nguyện viên, Đoàn viên Đoàn thanh niên Thị trấn Cần Thạnh và các anh chiến sĩ Quân nhân Biên phòng.
Không chỉ dừng lại ở việc tham gia vệ sinh dọn rác ở bãi biển, chương trình còn trao tặng quà cho các em thiếu nhi tại trường tiểu học Cần Thạnh 2, đồng thời giúp các em nâng cao ý thức về việc giữ gìn vệ sinh và bảo vệ môi trường bằng các trò chơi như: Gian hàng trồng cây, Kiến thức phân loại rác...
Hoạt động đem lại nhiều tiếng cười, sự thích thú cho các em nhỏ, đồng thời giúp lan tỏa thông điệp về bảo vệ môi trường: hãy cùng nhau bảo vệ biển!
Đoàn thanh niên Bệnh viện Nguyễn Tri Phương luôn mong muốn các đoàn viên tham gia nhiều hơn nữa những hoạt động vì lợi ích của xã hội như thế.
Có thể tìm hiểu thêm hoạt động của Cộng đồng hoạt động vì môi trường biển Việt Nam tại: <https://www.facebook.com/saveourseasvietnam/>
Vũ Minh Tuấn - Phòng QLCL

## Lễ ra mắt lực lượng dân quân tự vệ của Bệnh viện

Dân quân tự vệ có 6 nhiệm vụ:
  * Sẵn sàng chiến đấu, chiến đấu và phục vụ chiến đấu để bảo vệ địa phương, cơ sở; phối hợp với các đơn vị bộ đôi biên phòng, hải quân, cảnh sát biển và lực lượng khác bảo vệ chủ quyền, an ninh biên giới quốc gia và chủ quyền, quyền chủ quyền trên các vùng biển Việt Nam.
  * Phối hợp với các đơn vị quân đội nhân dân, công an nhân dân và lực lượng khác trên địa bàn tham gia xây dựng nền quốc phòng toàn dân, khu vực phòng thủ; giữ gìn an ninh chính trị, trật tự, an toàn xã hội, bảo vệ Đảng, chính quyền, bảo vệ tính mạng, tài sản của nhân dân, tài sản của nhà nước.
  * Thực hiện nhiệm vụ phòng, chống, khắc phục hậu quả thiên tai, dịch bệnh, tìm kiếm, cứu nạn, bảo vệ và phòng, chống cháy rừng, bảo vệ môi trường và nhiệm vụ phòng thủ dân sự khác.
  * Tuyên truyền, vận động nhân dân thực hiện chủ trương, đường lối, chính sách của Đảng, pháp luật của Nhà nước về quốc phòng, an ninh; tham gia xây dựng cơ sở vững mạnh toàn diện, xây dựng và phát triển kinh tế - xã hội tại địa phương, cơ sở.
  * Học tập chính trị, pháp luật, huấn luyện quân sự và diễn tập.
  * Thực hiện các nhiệm vụ khác theo quy định của pháp luật.


BCH Quân sự bệnh viện gồm:
- Đồng chí Đặng Quốc Quân
- Đồng chí Đỗ Tuấn Linh
- Đồng chí Nguyễn Mạnh Hùng
- Đồng chí Lương Công Minh
Quyết định có hiệu lực từ 28/12/2018./. 

## Phiên chợ yêu thương - gây quỹ cho bệnh nhân nghèo

Phiên chợ sẽ diển ra vào lúc 8g00 ngày 20/3/2019. Với sự chung tay của tập thể nhân viên bệnh viện và mạnh thường quân, những gian hàng với nhiều màu sắc chứa đầy tình thương yêu dành cho bệnh nhân.

## Mỗi giọt máu - Mỗi tấm lòng - Ngàn trân quý


## Đoàn thanh niên đồng hành cùng hoạt động ý nghĩa

Ban tổ chức rất vui mừng đón tiếp quý vị phụ huynh cùng các em nhỏ quan tâm tới nội dung chương trình đã đến để được thăm khám và được tư vấn về bệnh thiếu hormone tăng trưởng. Bên cạnh đó có các đơn vị báo chí truyền thông đã đến phỏng vấn và đưa tin. Chương trình có sự tham dự của chị Loan- phụ huynh của 1 bé đã được chẩn đoán và điều trị thành công. Chị cho biết hết sức vui mừng vì bé đã cải thiện được chiều cao rất tốt chỉ với chi phí chỉ bằng 1/6 nếu như điều trị tại Singapore lại được thuận tiện hơn trong việc chăm sóc con. Bệnh viện Nguyễn Tri Phương là một trong những cơ sở đầu tiên thực hiện chương trình này trong suốt 3 năm qua, bệnh viện đã hỗ trợ và điều trị cho các bé đạt nhiều hiệu quả cao. Với đội ngũ bác sĩ chuyên môn cao cùng với sự hỗ trợ nhiệt tình của Ban Giám Đốc bệnh viện mong rằng chương trình sẽ mang lại hiệu quả cao thiết thực hơn nữa cho cộng đồng.
Chương trình sẽ diễn ra trong suốt thời gian từ ngày 8/6–>27/7/2019 vào sáng thứ 7 và chủ nhật hàng tuần nhằm tầm soát bệnh thiếu hormone tăng trưởng ở trẻ. Phụ huynh có con từ 3-14t có chiều cao thấp hơn đáng kể so với bạn cùng lứa hoặc nghi ngờ con mình chậm tăng trưởng đều có thể đăng kí khám tầm soát bằng cách số hotline 0774880289 hoặc liên hệ khoa Nội Tiết vào sáng thứ 7 và chủ nhật trong thời gian diễn ra chương trình. Trẻ và phụ huynh sẽ được các BS khoa Nội Tiết tư vấn về chiều cao và phát triển của trẻ để đưa ra chiến lược điều trị phù hợp
Địa điểm hoạt động diễn ra: khoa Nội Tiết - lầu 3- khu A Bệnh viện Nguyễn Tri Phương

## Tổ chức Ngày hội hiến máu “ Giọt máu hồng hè năm 2019”

**Ai có thể tham gia hiến máu?**
- Tất cả mọi người từ 18 - 60 tuổi, thực sự tình nguyện hiến máu của mình để cứu chữa người bệnh.
- Cân nặng ít nhất là 42kg đối với phụ nữ, 45kg đối với nam giới. Lượng máu hiến mỗi lần không quá 9ml/kg cân nặng và không quá 500ml mỗi lần.
- Không bị nhiễm hoặc không có các hành vi lây nhiễm HIV và các bệnh lây nhiễm qua đường truyền máu khác.
- Thời gian giữa 2 lần hiến máu là 12 tuần đối với cả Nam và Nữ.
- Có giấy tờ tùy thân.
**Ai là người không nên hiến máu?**
- Người đã nhiễm hoặc đã thực hiện hành vi có nguy cơ nhiễm HIV.
- Người đã nhiễm viêm gan B, viêm gan C, và các vius lây qua đường truyền máu.
- Người có các bệnh mãn tính: tim mạch, huyết áp, hô hấp, dạ dày…
**Tại sao lại có nhiều người cần phải được truyền máu?**
Mỗi giờ có hàng trăm người bệnh cần phải được truyền máu vì :
- Bị mất máu do chấn thương, tai nạn, thảm hoạ, xuất huyết tiêu hoá...
- Do bị các bệnh gây thiếu máu, chảy máu: ung thư máu, suy tuỷ xương, máu khó đông...
- Các phương pháp điều trị hiện đại cần truyền nhiều máu: phẫu thuật tim mạch, ghép tạng...
**Nhu cầu máu điều trị ở nước ta hiện nay?**
- Mỗi năm nước ta cần khoảng 1.800.000 đơn vị máu điều trị.
- Máu cần cho điều trị hằng ngày, cho cấp cứu, cho dự phòng các thảm họa, tai nạn cần truyền máu với số lượng lớn.
- Hiện tại chúng ta đã đáp ứng được khoảng 54% nhu cầu máu cho điều trị.
**Tại sao khi tham gia hiến máu lại cần phải có giấy CMND?**
Mỗi đơn vị máu đều phải có hồ sơ, trong đó có các thông tin về người hiến máu. Theo quy định, đây là một thủ tục cần thiết trong quy trình hiến máu để đảm bảo tính xác thực thông tin về người hiến máu.
**Hiến máu nhân đạo có hại đến sức khoẻ không?**
Hiến máu theo hướng dẫn của thầy thuốc không có hại cho sức khỏe. Điều đó đã được chứng minh bằng các cơ sở khoa học và cơ sở thực tế:
_Cơ sở khoa học:_
- Máu có nhiều thành phần, mỗi thành phần chỉ có đời sống nhất định và luôn luôn được đổi mới hằng ngày. Ví dụ: Hồng cầu sống được 120 ngày, huyết tương thường xuyên được thay thế và đổi mới. Cơ sở khoa học cho thấy, nếu mỗi lần hiến dưới 1/10 lượng máu trong cơ thể thì không có hại đến sức khỏe.
- Nhiều công trình nghiên cứu đã chứng minh rằng, sau khi hiến máu, các chỉ số máu có thay đổi chút ít nhưng vẫn nằm trong giới hạn sinh lý bình thường không hề gây ảnh hưởng đến các hoạt động thường ngày của cơ thể.
_Cơ sở thực tế:_
- Thực tế đã có hàng triệu người hiến máu nhiều lần mà sức khỏe vẫn hoàn toàn tốt. Trên thế giới có người hiến máu trên 400 lần. Ở Việt Nam, người hiến máu nhiều lần nhất đã hiến gần 100 lần, sức khỏe hoàn toàn tốt.
- Như vậy, mỗi người nếu thấy sức khoẻ tốt, không có các bệnh lây nhiễm qua đường truyền máu, đạt tiêu chuẩn hiến máu thì có thể hiến máu từ 3-4 lần trong một năm, vừa không ảnh hưởng xấu đến sức khoẻ của bản thân, vừa đảm bảo máu có chất lượng tốt, an toàn cho người bệnh.

## Đoàn BV viếng thăm nhà tổ dòng Nguyễn Tri nhân ngày giỗ của tổng đốc Nguyễn Tri Phương

Đoàn thanh niên BV đã cùng BS Phan Quý Nam - nguyên giám đốc của BV đến thăm viếng nhà tổ dòng họ Nguyễn Tri nhân ngày giỗ của tổng đốc Nguyễn Tri Phương, tọa lạc phường Hiệp Bình Chánh, quận Thủ Đức
**Nguyễn Tri Phương** ([chữ Hán](https://vi.wikipedia.org/wiki/Ch%E1%BB%AF_H%C3%A1n "Chữ Hán"): 阮知方) tên cũ là **Nguyễn Văn Chương** , tự **Hàm Trinh** , hiệu là **Đường Xuyên** , sinh ngày 21 tháng 7 năm Canh Thân ([9 tháng 9](https://vi.wikipedia.org/wiki/9_th%C3%A1ng_9 "9 tháng 9") năm 1800), quê làng Đường Long (Chí Long), xã Điền Lộc, [huyện Phong Điền](https://vi.wikipedia.org/wiki/Phong_%C4%90i%E1%BB%81n,_Th%E1%BB%ABa_Thi%C3%AAn-Hu%E1%BA%BF "Phong Điền, Thừa Thiên-Huế"), tỉnh [Thừa Thiên Huế](https://vi.wikipedia.org/wiki/Th%E1%BB%ABa_Thi%C3%AAn_-_Hu%E1%BA%BF "Thừa Thiên - Huế").
Ông xuất thân trong một gia đình làm ruộng và nghề thợ mộc. Nhà nghèo lại không xuất thân từ [khoa bảng](https://vi.wikipedia.org/wiki/Khoa_b%E1%BA%A3ng_Vi%E1%BB%87t_Nam "Khoa bảng Việt Nam") nhưng nhờ ý chí tự lập ông đã làm nên cơ nghiệp lớn.

## Học tập và làm theo tấm gương đạo đức Hồ Chí Minh

HOẠT ĐỘNG HỌC TẬP VÀ LÀM THEO TẤM GƯƠNG ĐẠO ĐỨC HỒ CHÍ MINH TẠI BỆNH VIỆN NGUYỄN TRI PHƯƠNG (30/09/2015)
Tấm gương đạo đức của Chủ tịch Hồ Chí Minh là những bài học đầy ý nghĩa và rất sinh động về việc không ngừng phấn đấu cho lòng yêu thương con người, tình cảm thiêng liêng với tổ quốc và sự cống hiến không ngừng nghỉ cho cách mạng tiến bộ trên thế giới. Người đã có những căn dặn rất sâu sắc về tình đoàn kết, tính trung thực, thái độ dám nhận khuyết điểm cũng như tinh thần học hỏi không ngừng. Ngày hôm nay, những bài học ấy còn nguyên giá trị đối với mỗi người dân Việt Nam nói chung và càng sâu sắc hơn đối với đội ngũ những người thầy thuốc nói riêng.
Nhận thức sâu sắc về áp lực hiện nay mà mỗi người nhân viên y tế phải đối diện, đồng thời với lòng mong mỏi sẽ khích lệ được động cơ vượt khó và sự phấn đấu đúng đắn trong từng cán bộ công nhân viên, Ban Giám Đốc Bệnh viện Nguyễn Tri Phương đã tổ chức buổi sinh hoạt học tập theo tấm gương đạo đức của Chủ tịch Hồ Chí Minh. Buổi sinh hoạt đã vô cùng sinh động và ý nghĩa với sự tham gia của Giảng viên cao cấp, Tiến sĩ Nguyễn Việt Hùng – Trưởng khoa Xây Dựng Đảng Học Viện Cán Bộ TP.HCM.
Đại diện cho tập thể cán bộ công nhân viên bệnh viện, BSCKII. Võ Đức Chiến đã có những lời cảm ơn sâu sắc đối với sự nhiệt tình trao đổi cũng như những thông điệp đầy ý nghĩa do TS.Nguyễn Việt Hùng đã đem đến thông qua những bài trình bày ngắn gọn nhưng rất bao quát của mình. Đồng thời, một lần nữa, BS Chiến xin gửi thông điệp đến toàn thể nhân viên Nguyễn Tri Phương: chúng ta hãy luôn cố gắng học tập phấn đấu theo tấm gương đạo đức của Chủ tịch Hồ Chí Minh để xứng đáng với danh xưng Người đã ưu ái dành tặng cho nhân viên ngành Y – những người “mẹ hiền”, đồng thời cùng nhau chung sức chung lòng xây dựng mái nhà chung Nguyễn Tri Phương ngày càng khang trang hơn, tốt đẹp hơn. 
Bs.Lương Công Minh

## HỒI KÝ ĐẶC NHIỆM BLOUSE TRẮNG

Chương trình Đặc nhiệm Blouse trắng do Công ty Pharma Hậu Giang tài trợ đưa đến 01 sân chơi bổ ích, truyền đạt và thể hiện tài năng chuyên môn trong ngành y giữa các bệnh viện khu vực phía Nam.
Ngày 29/9/2018, diễn ra cuộc thi đầu tiên của Bệnh viện Nguyễn Tri Phương với Bệnh viện Răng Hàm Mặt Trung Ương.
Mặc dù Bệnh viện Nguyễn Tri Phương lần đầu tham gia chương trình nhưng các thành viên trong đội thi không hề lo ngại, hồi hộp mà luôn giữ được sứ bình tĩnh và quyết đoán trong từng quyết định, điều này đã giúp đội thi khôn ngoan hóa giải những tình huống gây khó của giám khảo đưa ra.
Đến với vòng thi tiếp theo ngày 10/11/2018, Bv Nguyễn Tri Phương thi đấu với Bv Hoàn Mỹ Cửu Long. Tại vòng thi này hai đội chơi đã đưa ra tình huống rất kịch tính, cuộc đối đáp nảy lửa liên tục giữa 02 đội khiến không khí căng thăng hơn bao giờ hết. Các vị giám khảo đã phải liên tục đứng để đưa ra những nhận định đanh thép để cung cố lại cách xử lý của cả 2 đội.
Bv Nguyễn Tri Phương đã xử lý 01 tình huống của đội bạn đưa ra đó là “Sập giàn giáo” khi lao động dẫn đến chết người. Tai nạn là điều thường xuyên xảy ra trong cuộc sống của chúng ta; nhắc đến không xa chính là vụ cháy chung cư CARINA ngày 22/3 mà Bv Nguyễn Tri Phương đã xử lý cấp cứu, đây là một vấn đề đang được xã hội quan tâm. 12 ca ngạt thở và bỏng nặng được đưa về BV Nguyễn Tri Phương cấp cứu ngay trong đêm. Toàn bệnh viện báo động đỏ. Mọi cán bộ y tế không thuộc kíp trực cũng tức tốc đến trợ lực. Họ thức trắng đêm để điều trị miễn phí, trấn an tinh thần, phục vụ đồ ăn, nước uống và sữa cho các nạn nhân. Một tuần sau vụ cháy, BV Nguyễn Tri Phương vẫn tiếp tục nhận thêm và khám miễn phí cho 43 lượt nạn nhân nữa. Cho nên khi tiếp nhận tình huống từ đội bạn, các bác sĩ Bv Nguyễn Tri Phương bằng kinh nghiệm dồi dào của minh đã xử lý tình huống hết sức bình tĩnh, thấu tình đạt lý trong khi đang bị bủa vậy bởi rất nhiều phóng viên, thân nhân người nhà bị tai nạn, các ca cấp cứu khác, được ban giám khảo khen ngợi hết lời. Chính vì thế Bv Nguyễn Tri Phương đã giành được chiến thắng vào chung kết.
Trận chung kết cuối cùng đã diễn ra vào ngày 17/11/2018, đó là cuộc tranh tài tay ba của Bv Nguyễn Tri Phương, Bv Răng Hàm Mặt Thành phố, Bv Nhân Ái. Phần thi xử lý tình huống do ban giám khảo đưa ra, Đội BV Nguyễn Tri Phương đã phải đối mặt với một tình huống hết sức đau lòng đó là họ có một cô em gái đang bệnh nặng sắp không qua khỏi, muốn hiến tạng để cứu sống những người khác. Ngay lúc đó có một bệnh nhân của bác sĩ đang chờ ghép thận nhưng gia đình họ không còn đủ tiền để duy trì viện phí. Bác sĩ đã nung nấu ý định dùng thận của em gái để cứu bệnh nhân của mình. Biết được việc đó, mẹ của bác sĩ đã tức giận và oà khóc khi cho rằng con mình chỉ lo cho người khác. Giữa một bênh là mẹ ruột và một bên là người mẹ có con đang cần hiến tạng. Với sự nhanh trí, sự thuyết phục tài tình, các y bác sĩ của chúng ta đã dung hoà đôi bên và giải quyết xác đáng tình huống được giao.
Với sự đoàn kết cao của mình, cùng cật lực tập luyện, trao dồi kỹ năng, vượt bao nỗi mệt nhọc trong thời gian tập luyện, tất cả những thứ đã tan biến, bù đắp bằng chính chiến thắng vinh quang trong cuộc thi Đặc nhiệm blouse trắng.
Xin chúc mừng đội thi của chúng ta!!!
Vũ Minh Tuấn, phòng QLCL
- - - - - 
Sau đây là 01 số link xem cuộc thi đấu tranh tài của Bv Nguyễn Tri Phương
  * Bv Nguyễn Tri Phương vs Bv Răng Hàm Mặt Trung Ương


<https://youtu.be/vFqUTpXFdyM>
  * Bv Nguyễn Tri Phương vs Bv Hoàn Mỹ Cửu Long


<https://youtu.be/xw8wMwOKowI>
  * Bv Nguyễn Tri Phương vs Bv Răng Hàm Mặt Thành phố vs Bv Nhân Ái


<https://youtu.be/c6aSuttz_Ik>

## Hoạt động kỷ niệm ngày Phụ nữ Việt Nam

Bác từng tặng cho phụ nữ Việt Nam 8 chữ vàng "Anh hùng - Bất khuất - Trung hậu - Đảm đang" để vinh danh những người phụ nữ đã hy sinh vì nghĩa lớn mà vẫn chăm lo cho gia đình chu đáo để trọn tình riêng. 
Ngày hôm nay, với nhiều sự thay đổi, người phụ nữ Việt Nam đang tích cực cống hiến cho xã hội trên nhiều mặt, thể hiện sự năng động và bản lĩnh. Sự tự tin và tự trọng với vị thế của mình đã và đang tạo nét đẹp riêng cho từng người phụ nữ. Đó là lý do mà người Phụ nữ hôm nay đang chọn cho mình "Tự tin - Tự trọng - Trung hậu - Đảm đang" làm hành trang trong công cuộc hội nhập hôm nay.
Với sự tham gia của cô Nguyễn Thị Thu Thào, phó trưởng ban nữ công Liên đoàn lao động thành phố, cán bộ nhân viên BV đã có thêm nhiều sự chia sẻ đầy hóm hỉnh mà thiết thực về vai trò của người phụ nữ trong thế giới đầy sôi động hôm nay.
Nhân ngày Phụ nữ Việt Nam, hoạt động do Công đoàn và Đoàn thanh niên bệnh viện tổ chức đã đem lại nhiều suy nghĩ tích cực và ý nghĩa cho cán bộ, nhân viên./.

## Kêu gọi hiến máu cứu người - tháng 9/2018

HIẾN MÁU KHẨN CẤP VÌ BỆNH NHÂN HIỆN NGÂN HÀNG MÁU TP ĐANG KHAN HIẾM CÁC NHÓM MÁU O+, A+, AB+. NHIỀU BỆNH NHÂN ĐANG CHỜ MÁU ĐỂ ĐƯỢC CỨU SỐNG!
Chúng tôi rất mong nhận được sự hỗ trợ nhiệt tình từ cộng đồng, để người bệnh đang cần máu có thể được kịp thời cứu chữa. MỘT GIỌT MÁU CHO ĐI, MỘT CUỘC ĐỜI Ở LẠI.
***Địa điểm hiến máu: 1. Bệnh viện Truyền máu Huyết học ( Cơ sở 1), số 118 Hồng Bàng, Phường 12, Quận 5 - Thời gian: 7h - 12h sáng, chiều từ 13h30 - 17h30 các ngày từ Thứ 2 đến Thứ 6. - Hoặc tại các điểm lấy máu lưu động gần nhất 2. Trung tâm Hiến máu nhân đạo Hội Chữ thập đỏ tp, 106 Thiên Phước, Phường 9, Quận Tân Bình. - Thứ 2 đến thứ 6: 7h - 11h sáng, chiều từ 13h30 - 16h. - Thứ 7, chủ nhật: 7h - 10h30 sáng.
Mọi thông tin cần thêm xin vui lòng liên hệ: Khoa Tiếp nhận hiến máu - Bệnh viện Truyền máu Huyết học 028.3955.7858 XIN CHÂN THÀNH CẢM ƠN!

