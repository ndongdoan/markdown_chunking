## Khen thưởng các cá nhân đã tham gia tích cực phòng chống Covid

# **QUYẾT ĐỊNH**
Tặng Giấy khen cho các cá nhân có thành tích xuất sắc trong tham gia công tác phòng, chống dịch Covid-19 dịp Tết Nguyên đán Tân Sửu
**GIÁM ĐỐC BỆNH VIỆN NGUYỄN TRI PHƯƠNG**
Căn cứ Quyết định số 227/QĐ-SYT ngày 14 tháng 01 năm 2020 của Sở Y tế về ban hành Quy chế tổ chức và hoạt động của Bệnh viện Nguyễn Tri Phương trực thuộc Sở Y tế;
Căn cứ Quyết định số 447/QĐ-NTP ngày 12 tháng 11 năm 2019 của Bệnh viện Nguyễn Tri Phương về việc ban hành Quy chế Thi đua, khen thưởng của Bệnh viện Nguyễn Tri Phương;
Căn cứ Biên bản họp của Hội đồng Thi đua khen thưởng ngày 22/3/2021;
Xét đề nghị của Thường trực Hội đồng Thi đua khen thưởng Bệnh viện Nguyễn Tri Phương,
#### **QUYẾT ĐỊNH:**
Điều 1. Nay tặng Giấy khen Bệnh viện Nguyễn Tri Phương cho  cá nhân có thành tích xuất sắc trong tham gia công tác phòng, chống dịch Covid-19 dịp Tết Nguyên đán Tân Sửu (danh sách đính kèm)
**Điều 2.** Thường trực Hội đồng Thi đua - Khen thưởng, Trưởng các khoa, phòng Bệnh viện Nguyễn Tri Phương, các đơn vị có liên quan và các cá nhân nêu tại Điều 1 chịu trách nhiệm thi hành Quyết định này./.

## Khen thưởng đột xuất công tác phòng, chống dịch Covid-19

Trong hơn 02 năm qua, nhất là từ tháng 4-2021 đến nay, khi đợt dịch Covid-19 thứ 4 bùng phát, cả nước nói chung, thành phố Hồ Chí Minh nói riêng đã trải qua một cuộc chiến đặc biệt, chưa có tiền lệ với diễn biến rất phức tạp, nguy hiểm, khó lường... Trong muôn vàn khó khăn, thử thách, với tinh thần “chống dịch như chống giặc”, “bảo vệ sức khỏe, tính mạng của Nhân dân là trên hết, trước hết”; dưới sự lãnh đạo của Đảng, sự điều hành của Chính phủ; Thành phố Hồ Chí Minh đã chủ động, sáng tạo, tập trung lãnh đạo, chỉ đạo thực hiện quyết liệt, đồng bộ các giải pháp thích ứng an toàn, linh hoạt, kiểm soát hiệu quả dịch bệnh Covid-19.
Thành quả ấy được làm nên bởi sự đồng lòng, chung sức của cả hệ thống chính trị, đặc biệt là các lực lượng tuyến đầu chống dịch. Trong đó, đặc biệt là đội ngũ y, bác sĩ, nhân viên y tế ngày đêm cứu chữa cho bệnh nhân Covid-19.
Nhằm ghi nhận, tôn vinh những tập thể, cá nhân đã có thành tích xuất sắc trong công tác phòng, chống dịch Covid-19 tại Thành phố Hồ Chí Minh, Thủ tướng Chính phủ, Chủ tịch Ủy ban nhân dân Thành phố Hồ Chí Minh, Giám đốc Sở Y tế Thành phố Hồ Chí Minh đã ban hành quyết định tặng thưởng cho các tập thể, cá nhân thuộc Bệnh viện Nguyễn Tri Phương, cụ thể như sau:
- Tặng Bằng khen Thủ tướng Chính phủ cho ông Võ Đức Chiến, Giám đốc Bệnh viện.
- Tặng Bằng khen Chủ tịch Ủy ban nhân dân Thành phố cho 9 tập thể, 214 cá nhân thuộc Bệnh viện.
- Tặng Giấy khen Giám đốc Sở Y tế Thành phố cho 397 cá nhân thuộc Bệnh viện.
Xin trân trọng chúc mừng và cảm ơn sự đóng góp của từng từng tập thể, từng cá nhân./.

## Khen thưởng tập thể và cá nhân có thành tích xuất sắc trong năm 2021


## Quyết định khen thưởng dành cho các tập thể đã thực hiện xuất sắc nhiệm vụ trong năm 2022

Vì những hoạt động với nỗ lực không ngừng để đạt và vượt mức nhiệm vụ đề ra, Giám Đốc BV Nguyễn Tri Phương đã có quyết định khen thưởng đối với
  1. Khoa Nội tiêu hóa
  2. Khoa Ngoại thần kinh
  3. Khoa Hồi sức tích cực chống độc
  4. Khoa Nội tổng hợp
  5. Khoa Nội thận - Lọc máu
  6. Khoa Ngoại tiêu hóa


Xin trân trọng chúc mừng các tập thể ./.

