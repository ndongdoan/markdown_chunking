## Bạn biết gì về lọc thận?

  * [Lọc thận là gì?](https://bvnguyentriphuong.com.vn/than-loc-mau/ban-biet-gi-ve-loc-than#lc-thn-l-g)
  * [Lọc thận như thế nào? Có bao nhiêu loại lọc thận?](https://bvnguyentriphuong.com.vn/than-loc-mau/ban-biet-gi-ve-loc-than#lc-thn-nh-th-no-c-bao-nhiu-loi-lc-thn)
  * [Cầu mạch máu là gì?](https://bvnguyentriphuong.com.vn/than-loc-mau/ban-biet-gi-ve-loc-than#cu-mch-mu-l-g)
  * [Lọc thận có thực hiện được ở nhà không?](https://bvnguyentriphuong.com.vn/than-loc-mau/ban-biet-gi-ve-loc-than#lc-thn-c-thc-hin-c-nh-khng)
  * [Loại lọc thận nào là tốt nhất?](https://bvnguyentriphuong.com.vn/than-loc-mau/ban-biet-gi-ve-loc-than#loi-lc-thn-no-l-tt-nht)


Khi thận bắt đầu suy yếu, bạn sẽ phải trải qua các giai đoạn tiến triển của mất chức năng thận. Những giai đoạn này được chia từ 1 đến 5 của bệnh thận mạn. Giai đoạn 5 là giai đoạn xấu nhất, khi hầu hết người bệnh cần **lọc thận** hoặc **ghép thận**. Tuy nhiên, không phải ai bị bệnh thận nhẹ (giai đoạn 1-3) đều tiến triển đến giai đoạn 5.
Bệnh thận đi cùng với rất nhiều biến chứng.
Trong giai đoạn đầu của bệnh thận mạn, những biến chứng này có thể điều trị được với thuốc. Những biến chứng có thể được điều trị như tăng huyết áp, rối loạn điện giải, phù (thường xảy ra ở bệnh thận mạn). Tuy nhiên, nếu bệnh thận tiến triển nặng hoặc bệnh thận mạn rơi vào giai đoạn 5, những biến chứng này sẽ trở nên khó điều trị hơn nếu chỉ dùng thuốc. Ở thời điểm này, bạn không cần ghép thận (hoặc nếu bạn không đủ điều kiện), bạn sẽ cần lọc thận.
## **Lọc thận là gì?**
Lọc thận cách thay thế một số chức năng của thận bằng cách nhân tạo. Thận thực hiện rất nhiều chức năng thiết yếu của cơ thể, nhiều hơn việc chỉ tạo ra nước tiểu:
  * Điều hoà và duy trì mức điện giải như natri, kali, ở mức bình thường
  * Điều hòa lượng nước trong máu, và nồng độ các chất trong máu
  * Sản xuất hormone cần thiết để tạo hồng cầu
  * Đảm bảo xương chắc khỏe nhờ sản xuất vitamin D
  * Chuyển hóa bình thường của cơ thể
  * Kiểm soát huyết áp


Lọc thận với mục đích thay thế một số chức năng, không phải tất cả những chức năng này.
## **Lọc thận như thế nào? Có bao nhiêu loại lọc thận?**
Lọc thận được thực hiện như thế nào tùy thuộc vào loại lọc thận. Một kĩ thuật (phổ biến nhất ở Mỹ) đó là lọc máu. Khi lọc máu, máu của bệnh nhân được lấy để lọc và tuần hoàn qua máy lọc bắt chước chức năng lọc của thận. Khi máu đi qua máy lọc, máu sạch sẽ được đưa lại vào cơ thể. Lọc máu thường được thực hiện ở các trung tâm, với tuần suất khoảng 3 lần/tuần, mỗi lần thực hiện trong khoảng 3-4 giờ (phụ thuộc vào từng bệnh nhân). Tuy nhiên, lọc máu cũng có thể được thực hiện ở nhà. Kĩ thuật này có thể được thực hiện đến 5-7 lần/tuần, nhưng mỗi lần thường ngắn hơn khoảng 2-4 giờ.
Một loại lọc thận nữa cũng được thực hiện ở nhà đó là lọc màng bụng. Màng bụng là khoang ổ bụng. Trong phương thức này, một ống catheter được đặt vào màng bụng bệnh nhân qua thành bụng. Dịch lọc sạch được truyền vào màng bụng, và dịch ở trong đó vài tiếng để lọc sạch chất độc. Sau đó dịch bẩn được chảy ra, và dịch sạch được đưa vào. Quá trình này được lặp lại nhiều lần, và sau đó vào buổi sáng, bệnh nhân tháo máy và buộc catheter lại.
## **Cầu mạch máu là gì?**
Cầu mạch máu (Shunt) là vị trí nơi hai ống kim được đưa vào bệnh nhân lọc máu (bệnh nhân lọc màng bụng không cần shunt, nhưng cần một ống thông đường tiểu (catheter) cố định ở bụng). Khi đó, một kim sẽ đưa máu từ cơ thể vào máy lọc, kim còn lại sẽ trả lại máu từ máy lọc vào người bệnh nhân.
Shunt là sự kết nối giữa động mạch và tĩnh mạch. Kỹ thuật này được đặt bởi bác sĩ – người sử dụng chính tĩnh mạch của bạn để tạo nên sự liên kết này (còn được gọi là đường rò) hoặc sử dụng một ống giả.
## **Lọc thận có thực hiện được ở nhà không?**
Đương nhiên là có, cả lọc màng bụng và lọc máu tại nhà có thể được thực hiện tại nhà. Bác sĩ và y tá sẽ hướng dẫn bạn cách thực hiện việc này trong vòng một vài tuần. Khi bạn đã thuần thục, họ sẽ để bạn tự làm tại nhà.
Dù vậy, bạn vẫn cần theo dõi bởi bác sĩ , và bạn hãy gọi cho bác sĩ nếu có vấn đề. Y tá sẽ lên kế hoạch đến nhà bạn thường xuyên trong trường hợp không thể nói chuyện qua điện thoại.
## **Loại lọc thận nào là tốt nhất?**
Từ phương diện y học, vẫn chưa có nghiên cứu nào khẳng định phương thức nào là cần thiết hơn loại khác. Lọc máu tại nhà thường được ưa thích hơn với những bệnh nhân không thể tự chăm sóc bản thân, và không muốn gắn chặt với bệnh viên. Lọc máu tại nhà cũng cải thiện chất lượng cuộc sống cho bệnh nhân hơn do họ không cần thường xuyên đến trung tâm. Tuy nhiên bạn cần có trách nhiệm với chính sức khỏe của mình.
**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/)** - Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [Lọc thận là gì?](https://bvnguyentriphuong.com.vn/than-loc-mau/ban-biet-gi-ve-loc-than#lc-thn-l-g)
  * [Lọc thận như thế nào? Có bao nhiêu loại lọc thận?](https://bvnguyentriphuong.com.vn/than-loc-mau/ban-biet-gi-ve-loc-than#lc-thn-nh-th-no-c-bao-nhiu-loi-lc-thn)
  * [Cầu mạch máu là gì?](https://bvnguyentriphuong.com.vn/than-loc-mau/ban-biet-gi-ve-loc-than#cu-mch-mu-l-g)
  * [Lọc thận có thực hiện được ở nhà không?](https://bvnguyentriphuong.com.vn/than-loc-mau/ban-biet-gi-ve-loc-than#lc-thn-c-thc-hin-c-nh-khng)
  * [Loại lọc thận nào là tốt nhất?](https://bvnguyentriphuong.com.vn/than-loc-mau/ban-biet-gi-ve-loc-than#loi-lc-thn-no-l-tt-nht)



## ️ Lọc màng bụng liên tục ngoại trú

**1. NGUYÊN LÝ:**
- Lọc màng bụng ở Việt Nam hiện nay chủ yếu sử dụng phương pháp lọc màng bụng liên tục ngoại trú.
- Lọc màng bụng liên tục ngoại trú: Continuous Ambulatory Peritoneal Dialysis (CAPD):
+ Lọc màng bụng hay thẩm phân phúc mạc (Peritoneal Dialysis – PD): Sử dụng màng bụng (phúc mạc ổ bụng của bệnh nhân, bao gồm cả phúc mạc thành và phúc mạc tạng) như một màng bán thấm để trao đổi chất giữa khoang dịch và khoang máu. Màng bụng trao đổi chất nhờ 2 cơ chế là (1) Sự khuếch tán xảy ra khi có sự chênh lệch nồng độ các chất giữa máu và dịch lọc trong khoang phúc mạc và (2) Sự siêu lọc (sự hút nước) xảy ra nhờ sự chênh lệch áp lực thẩm thấu được tạo ra nhờ nồng độ glucose cao trong dịch lọc dẫn đến sự rút nước từ trong huyết tương vào trong ổ bụng
+ Liên tục: Ngày thay dịch trung bình 4 lần, mỗi lần trung bình 5h - 6h, lọc tất cả các ngày trong tuần.
+ Ngoại trú: Bệnh nhân tự thay dịch ở nhà, bình thường 1 tháng đến bệnh viện để khám, đánh giá, làm xét nghiệm và lĩnh dịch, thuốc về nhà.
**2. CHỈ ĐỊNH:**
- Bệnh thận giai đoạn cuối (CKD g/đ V).
- Trẻ em: Là đối tượng thường khó tạo đường vào mạch máu để thận nhân tạo.
- Người lớn: Những đối tượng gặp khó khăn khi tạo đường vào mạch máu (không làm được thông động – tĩnh mạch ở bệnh nhân đái tháo đường, thông động – tĩnh mạch bị tắc hoặc hẹp không đủ lưu lượng để lọc máu bằng thận nhân tạo…).
- Ưu tiên cho những bệnh nhân có rối loạn chức năng tim, suy tim nặng.
- Sự lựa chọn phương pháp LMB còn phụ thuộc vào tuổi, nghề nghiệp, điều kiện địa lý (xa hay gần trung tâm thận nhân tạo), điều kiện kinh tế - văn hóa – xã hội, môi trường tại gia đình và nơi làm việc, sự hỗ trợ từ gia đình, tình trạng tim mạch, các bệnh lý kèm theo…
**3. CHỐNG CHỈ ĐỊNH:**
**3.1. Chống chỉ định tuyệt đối:**
+ Màng bụng không còn chức năng lọc hoặc bị kết dính diện rộng gây cản trở dòng chảy của dịch lọc: Xơ hóa phúc mạc, viêm dính phúc mạc do phẫu thuật trong ổ bụng cũ,
+ Một số trường hợp bất thường về màng bụng và thành bụng không thể khắc phục: Thoát vị rốn, thoát vị cạnh rốn bẩm sinh, thoát vị hoành, rò bàng quang...
+ Bệnh phổi tắc nghẽn mạn tính nặng: Do lọc màng bụng có thể gây khó khăn khi kiểm soát bệnh phổi.
**3.2. Chống chỉ định tương đối:**
+ Nhiễm trùng da hay thành bụng.
+ Thể tích khoang màng bụng bị hạn chế: Gan to, lách to, thận đa nang.
+ Mới mổ ghép động mạch chủ bụng.
+ Đã phẫu thuật cắt đại tràng, ruột non, thận…
+ Có shunt não thất - ổ bụng (dẫn lưu não thất trong não úng thủy).
+ Không dung nạp với dịch lọc chứa trong ổ bụng.
+ Thị lực kém, có các bệnh lý thần kinh, bệnh khớp không thể tự làm được LMB hoặc không có người giúp đỡ.
+ Rối loạn tâm thần.
+ Suy dinh dưỡng nặng.
+ Bệnh lý đại tràng mạn tính nặng, viêm ruột.
+ Đau lưng mạn tính do bệnh lý cột sống, béo phì.
**4. ƯU VÀ NHƯỢC ĐIỂM:**
**4.1. Ưu điểm:**
**a. Về y học:**
- Quá trình lọc máu xảy ra liên tục nên:
+ Thích hợp với tim mạch do huyết động ổn định, giảm các rối loạn về nhịp tim, kiểm soát tốt huyết áp, tránh bị suy tim sớm hơn so với thận nhân tạo.
+ Tình trạng sinh hoá máu của bệnh nhân ổn định hơn, tránh hội chứng mất cân bằng.
- Còn tồn tại chức năng thận dự trữ: Tiên lượng bệnh nhân sẽ tốt hơn nếu còn chức năng thận dự trữ (chức năng thận tồn lưu).
- Kiểm soát tốt thiếu máu.
- Không cần dùng chống đông toàn thân.
- Không cần làm thông động tĩnh mạch.
- Không cần tiếp xúc vật liệu lạ.
- Không phải chọc kim như thận nhân tạo  đỡ đau.
- Tránh lây nhiễm chéo (HIV, viêm gan virus B, viêm gan virus C...) giữa các bệnh nhân.
- Được chỉ định ưu tiên đối với bệnh nhân đã có suy tim, rối loạn nhịp, tình trạng mạch máu khó khăn khi làm thông động tĩnh mạch, nhất là bệnh nhân tiểu đường.
**b. Về xã hội**
- So với thận nhân tạo, LMB mang lại cho bệnh nhân nhiều sự tự do hơn, BN tự thực hiện ở nhà, không cần đến các trung tâm thận nhân tạo nên không phụ thuộc nhiều vào bệnh viện.
- Bệnh nhân có thể duy trì những sinh hoạt hàng ngày trong suốt quá trình điều trị.
- Tự quản, dễ di động.
- Kỹ thuật đơn giản, đào tạo nhanh.
- Giá thành không cao lắm so với lọc máu.
**4.2. Nhược điểm:**
**a. Về y học:**
- Tồn tại một ống thông trong ổ bụng, dễ có các biến chứng như màng bụng bị tổn thương (xơ hóa màng bụng), viêm phúc mạc, tăng áp lực trong ổ bụng, thoát vị…
- Nguy cơ thiểu dưỡng cao hơn.
- Dễ bị ứ trệ nước và điện giải.
- Có nguy cơ lọc không đầy đủ sau một vài năm.
- Hiệu suất kém (bằng ¼ so với lọc máu bằng thận nhân tạo)  nồng độ ure và creatinin thường cao hơn so với thận nhân tạo.
- Không thay thế được chức năng thận nội tiết (kiểm soát tạo hồng cầu, loãng xương).
**b. Về xã hội:**
- Bắt buộc phải thực hiện hàng ngày và ngày nhiều lần (thời gian kéo dài hơn).
- Đòi hỏi phải có kỹ năng và trình độ hiểu biết tốt; đòi hỏi về điều kiện sinh hoạt (nguồn nước sạch).
- Gây ảnh hưởng đến môi trường gia đình, lao động và công tác.
- Dễ ứ trệ nước và điện giải, nguy cơ lọc không đầy đủ sau vài năm.
**5. KỸ THUẬT:**
- Bệnh nhân được đặt catheter bằng chất dẻo vào trong ổ bụng, đầu catheter (đầu cong) ở vị trí túi cùng Douglas.
- Kỹ thuật mổ: Mổ mở hoặc mổ nội soi.
- Kiểm tra trong và sau mổ: Thay dịch ngay trong cuộc mổ kiểm tra sự lưu thông catheter. Chụp X quang bụng sau mổ kiểm tra vị trí catheter.
- Sau 2 tuần: Vết mổ và đường hầm ổn định, cắt chỉ và bắt đầu vào dịch với số lần vào và thể tích dịch tăng dần để có sự thích nghi.
- Dịch lọc có 3 loại là 1.5%, 2.5% và 4.25%: Khác nhau về nồng độ đường. Nồng độ đường càng cao thì khả năng hút nước thừa (siêu lọc) càng cao do tạo được áp lực thẩm thấu cao hơn.
- Giờ thay dịch thường là Sáng – Trưa – Cuối buổi chiều và Đêm (ngâm qua đêm).
- Bệnh nhân Lọc màng bụng nếu không duy trì được phương pháp này có thể chuyển sang Thận nhân tạo chu kỳ hoặc làm Lọc màng bụng trước trong lúc chờ đợi được ghép thận. Bệnh nhân đã ghép thận hoặc đã Thận nhân tạo chu kỳ có thể quay trở lại làm Lọc màng bụng.
- Một số nước thực hiện chính sách “PD first” có nghĩa là ưu tiên làm lọc màng bụng trước (so với lựa chọn Thận nhân tạo) nếu như chưa được ghép thận.
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh

## ️ Ứ nước, ứ mủ bể thận

**ĐẠI CƯƠNG**
Hậu quả của tắc nghẽn đường tiết niệu làm cho đài thận rồi bể thận và có thể cả niệu quản giãn dần ra dẫn đến kích thước thận to lên so với bình thường gọi là hiện tượng thận ứ nước. Trong thời gian ứ nước bể thận và niệu quản có thể dẫn đến nhiễm trùng tại thận. Nếu nhiễm trùng nặng có thế dẫn đến tình trạng ứ mủ bể thận. 
Tùy theo nguyên nhân thận có thể ứ nước một bên hoặc cả hai bên, tùy theo thời gian và tiến triển của bệnh mà biểu hiện lâm sàng có thể là cấp tính hoặc mạn tính. Trong những trường hợp mạn tính chức năng thận có thể bị suy giảm và không có khả năng hồi phục, thận chí có thể dẫn đến bệnh thận giai đoạn cuối. 
**NGUYÊN NHÂN**
Nguyên nhân chủ yếu gặp trong ứ nước, ứ mủ bể thận là do những cản trở cơ học từ bên trong hoặc bên ngoài cũng như những tổn thương chức năng đơn thuần không liên quan đến sự tắc nghẽn cố định trong hệ thống dẫn niệu. 
Nghẽn, tắc cơ học có thể gặp ở bất cứ đoạn nào của đường dẫn niệu, bắt đầu từ đài thận đến lỗ ngoài của niệu đạo.
Ở trẻ em các dị tật bẩm sinh chiếm ưu thế bao gồm hẹp khúc nối bể thận niệu quản, niệu quản sau tĩnh mạch chủ, van niệu đạo sau [1].
Ở người lớn, tắc nghẽn đường tiểu chủ yếu do các nguyên nhân mắc phải: 
Sỏi thận và sỏi niệu quản là nguyên nhân hay gặp, ngoài ra là các nguyên nhân như hẹp niệu quản, u niệu quản, cục máu đông [2]. 
Nguyên nhân do do chấn thương niệu quản trong phẫu thuật ở vùng chậu hoặc đại tràng 
Nguyên nhân do các khối u bên ngoài chèn ép vào niệu quản như ung thư cổ tử cung hay đại tràng, u lympho sau phúc mạc, viêm nhiễm quanh niệu quản.
Xơ hóa sau phúc mạc chưa rõ nguyên nhân cũng thường gặp ở nam tuổi trung niên và có thể dẫn đến tắc nghẽn niệu quản 2 bên.
**CHẨN ĐOÁN**
**Triệu chứng lâm sàng:**
Biểu hiện lâm sàng thận ứ nước, ứ mủ tùy thuộc vào sự tắc nghẽn là cấp tính hay mạn tính, tắc một bên hay hai bên, vị trí tắc thấp hay cao, có nhiễm khuẩn kết hợp hay chỉ ứ nước đơn thuần. Nhiều trường hợp bệnh tiến triển âm thầm chỉ tình cờ phát hiện khi siêu âm hay khám sức khỏe định kì, hoặc bệnh nhân đi khám vì nhiễm khuẩn tiết niệu, suy thận [3]. 
Triệu chứng hay gặp nhất là đau mỏi, tức hông lưng do đài bể thận, bao thận bị căng giãn. Đau thường khởi phát khu trú ở vùng mạng sườn hay hông lưng rồi lan xuống, ra sau. Có thể đau 2 bên do tắc nghẽn cả 2 bên và đau tăng lên khi có nhiễm trùng.
Sốt rét run từng đợt chỉ xuất hiện khi có nhiễm khuẩn.
Bệnh nhân có thể bị rối loạn tiểu tiện: tiểu buốt, tiểu rắt, tiểu máu, tiểu đục nếu có nhiễm khuẩn.
Thận to là dấu hiệu thường gặp, do giãn đài bể thận làm thận to lên có thể phát hiện được qua khám lâm sàng.
Thay đổi số lượng nước tiểu: Lượng nước tiểu có thể tăng > 2 lít/ ngày do rối loạn chức năng cô đặc nước tiểu, hoặc có khi bệnh nhân bị thiểu niệu, vô niệu do tắc nghẽn niệu quản hoàn toàn cả hai bên.
Tăng huyết áp: Khoảng 1/3 bệnh nhân có biểu hiện tăng huyết áp khi thận bị ứ nước, huyết áp chỉ tăng nhẹ hoặc trung bình do thận tăng tiết renin hoặc có thể do giữ muối giữ nước.
Trong trường hợp bệnh nhân đã có biểu hiện của suy giảm chức năng thận nặng và không hồi phục thì có thể có phù, da xanh, niêm mạc nhợt biểu hiện một tình trạng thiếu máu.
**Triệu chứng cận lâm sàng:**
*Chụp hệ tiết niệu không chuẩn bị
Nên là chỉ định đầu tiên để xác định nguyên nhân tắc nghẽn, trên phim X quang chuẩn có thể thấy được bóng thận to, sỏi cản quang ở thận, niệu quản, bàng quang. Nếu có thể nên thụt đại tràng cho bệnh nhân trước khi chụp để tránh các hình ảnh nhầm lẫn do bã thức ăn, bóng hơi của đại tràng.
Kỹ thuật đơn giản nhưng có thể phát hiện tới trên 90% sỏi tiết niệu cản quang gây tắc đường tiết niệu trên. 
*Siêu âm hệ thận tiết niệu 
Trong thận ứ nước siêu âm cho phép đánh giá kích thước thận, độ dầy của nhu mô, mức độ ứ nước thận, tình trạng dịch ứ đục hay đồng nhất, phát hiện được một số nguyên nhân tắc nghẽn như sỏi, khối u đường tiết niệu hay bên ngoài chèn ép vào, các dị dạng bẩm sinh ở đường tiết niệu. Tuy nhiên, hạn chế của siêu âm: khó đánh giá được toàn bộ niệu quản. 
*Chụp cắt lớp vi tính (Computerized Tomogaphy Scan – CT Scan)
Chụp CT Scan có độ nhậy cao 95 – 98% và độ đặc hiệu 96 – 100%. Đặc biệt chính xác trong chẩn đoán ứ nước thận – niệu quản về vị trí giãn, độ dầy của thành niệu quản, vị trí, kích thước sỏi, dấu hiệu của tắc nghẽn có thể được đánh giá mà không cần thuốc cản quang. Chụp CT Scan cho phép chẩn đoán các bệnh lý khác như khối u sau phúc mạc, khối u vùng tiểu khung, xơ hóa sau phúc mạc, hạch di căn, ung thư… 
*Phương pháp thăm d chức năng thận (Chụp xạ hình chức năng thận bằng Tc - 99m – _DTPA)_
Xạ hình chức năng thận là kỹ thuật chẩn đoán đơn giản, dễ tiến hành, rất có giá trị trong các bệnh lý của thận, không chỉ cung cấp các thông tin về chức năng riêng rẽ của từng thận qua phân tích định lượng và định tính mà c n cho các thông tin về vị trí, kích thước và giải phẫu thận. 
Xạ hình cũng rất có ích trong trường hợp bệnh nhân mẫn cảm với thuốc cản quang có iod hoặc chức năng thận suy giảm nhiều mà không thể sử dụng thuốc cản quang đường tĩnh mạch khi chụp CT Scan…
*Xét nghiệm máu và nước tiểu:
Xét nghiệm ure, creatinin huyết thanh…
Xét nghiệm công thức máu, máu lắng… cấy máu nếu cần thiết
Xét nghiệm nước tiểu: tổng phân tích, tế bào niệu, cấy nước tiểu…
**Chẩn đoán xác định**
*Lâm sàng: 
Đau vùng hông lưng
Sốt trong trường hợp có nhiễm trùng
Rối loạn tiểu tiện 
Biểu hiện triệu chứng suy giảm chức năng thận của bệnh thận cấp hoặc mạn tùy theo giai đoạn bệnh
*Cận lâm sàng: Đóng vai trò quan trọng do nhiều bệnh nhân có rất ít triệu chứng lâm sàng
Xquang hệ thận- tiết niệu 
Siêu âm thận- tiết niệu
Chụp cắt lớp vi tính 
Xạ hình thận
Xét nghiệm nước tiểu có tế bào niệu, cấy vi khuẩn dương tính
Xét nghiệm máu có thể có biểu hiện triệu chứng suy giảm chức năng thận của bệnh thận cấp hoặc mạn tùy theo giai đoạn bệnh 
**ĐIỀU TRỊ**
Tùy thuộc vào tình trạng lâm sàng toàn thận, mức độ ứ nước, ứ mủ ở thận, nguyên nhân gây ứ nước và chức năng thận suy giảm cấp tính hay mạn tính mà có phương pháp điều trị thích hợp cho từng bệnh nhân cụ thể nhưng nguyên tắc chung là loại bỏ yếu tố gây tắc nghẽn. 
**Chỉ định dùng thuốc**
*Kháng sinh
Nếu bệnh nhân có tình trạng nhiễm khuẩn, tốt nhất sử dụng kháng sinh theo kháng sinh đồ. Trong trường hợp chưa có kết quả kháng sinh đồ có thể dùng thuốc theo kinh nghiệm. Các nhóm thuốc có thể sử dụng là Fluoroquinolon, Cepholosporin và Etarpendem. 
*Thuốc huyết áp
Phối hợp các nhóm thuốc hạ huyết áp nếu cần để khống chế huyết áp <130/80 mmHg. 
*Điều trị các rối loạn do suy giảm chức năng thận 
Điều trị các rối loạn điện giải đặc biệt chú ý tình trạng rối loạn Kali máu và Natri máu. 
Nếu có suy giảm chức năng thận thì kiểm soát toan máu, ph ng tăng phospho máu, điều trị thiếu máu, điều chỉnh mỡ máu nếu có rối loạn, và chế độ ăn theo các mức độ bệnh thận mạn. 
**Dẫn lưu bể thận qua da**
Dẫn lưu bể thận qua da là một thủ thuật cơ bản và cần thiết trong điều trị thận ứ nước, ứ mủ do các nguyên nhân khác nhau. Đây là một thủ thuật đơn giản, ít tốn kém, ít tốn thời gian, ít chấn thương và cho kết quả khả quan giúp giảm nhanh áp lực tại thận, giải quyết nhanh tình trạng ứ đọng và nhiễm khuẩn góp phần hồi phục nhu mô và chức năng thận. 
Những trường hợp nguyên nhân không thể giải quyết được nhiều bệnh nhân đã lựa chọn việc dẫn lưu tạm thời thành biện pháp lâu dài để duy trì chức năng thận, hoặc để tránh việc phải lọc máu ngắt quãng vì việc lọc máu ngắt quãng quá tốn kém và mất nhiều thời gian [4, 5]. 
Phần kỹ thuật dẫn lưu bể thận qua da xin đề nghị tham khảo thêm sách về qui trình các kỹ thuật, thủ thuật trong thận - tiết niệu. 
Phẫu thuật giải quyết nguyên nhân tắc nghẽn
Cắt bỏ thận
Chỉ định khi thất bại trong điều trị bảo tồn và nhu mô thận đã bị phá hủy nhiều dẫn đến mất chức năng hoàn toàn và không có khả năng hồi phục. 
**Điều trị thận thay thế**
Chỉ định cụ thể theo tình trạng rối loạn điện giải, toan hóa máu và sự suy giảm chức năng thận của bệnh thận cấp hoặc mạn ở từng giai đoạn bệnh. 
**TÀI LIỆU THAM KHẢO**
Trần Quán Anh (2007),  _Hẹp khúc nối bể thận – niệu quản_. NXB y học: Tr. 498504.
Etemadian M, Robab Maghsoudi, 1 Pejman Shadpour, Ghasemi H, Shati M (2012), “Outcomes of Tubeless Percutaneous Nephrolithotomy in Patients With Chronic Renal Insufficiency”.  _Iranian Journal of Kidney Diseases_ 6 (3): pp.216 – 8. Garne E, Loane M, Wellesley D, Barisic I. Congenital hydronephrosis: prenatal diagnosis and epidemiology in Europe. J Pediatr Urol 2009;5:47-52. 4.Brian Funaki JA (2006), “Percutaneous nephrostomy”. 23: pp 205 - 8. 
Ecric Van Sonnenberg GC (1992), “Symptomatic Renal Obstruction or Urosepsisuring Pregnancy: Treatment by Sonographically Guide Percutaneous.
Nephrostomy”.  _American Roentgen Ray Society_ 158: pp.91 – 4.
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh

## Xơ hóa thận ở người tăng huyết áp

Ở thận, tổn thương sớm thấy ở các mạch máu trước cầu thận và động mạch đến, bao gồm cả các động mạch trong cầu thận. Tổn thương động mạch trước cầu thận là đặc trưng của tổn thương thận do tăng huyết áp, nhưng không đặc hiệu vì còn thấy trong các bệnh lý mạch máu thận. Trong xơ mạch thận lành tính, tổn thương cơ bản là hyalin hóa lớp áo giữa thành động mạch trong cầu thận, dẫn tới tổn thương đoạn búi mao mạch cầu thận. Trong xơ mạch thận ác tính, đặc trưng cơ bản là tổn thương lớp nội mạc. Tế bào nội mạc có chỗ bị bong khỏi màng nền, tạo ra các khoang được lấp đầy các chất liệu huyết tương và collagen, gây hẹp lòng động mạch. Ngoài ra còn hoại tử lớp áo giữa, xẹp các búi mao mạch cầu thận do thiếu máu. Giai đoạn đầu của tăng huyết áp, thấy tăng lưu lượng dòng huyết tương qua thận, và tăng áp lực thủy tĩnh trong mao mạch cầu thận, làm xuất hiện microalbumin niệu. Khi tổn thương đoạn búi mao mạch cầu thận, làm xuất hiện macroalbumin niệu và dẫn tới xơ hóa cầu thận, mức lọc cầu thận giảm và dần dần dẫn tới suy thận. Trong xơ mạch thận ác tính, do hẹp lòng động mạch trước cầu thận và trong cầu thận, gây xẹp các búi mao mạch cầu thận do thiếu máu, dẫn đến thiểu niệu, vô niệu, và suy thận cấp.
_Hình ảnh cắt ngang một động mạch: thành động mạch dày làm thu hẹp lòng mạch_
Tổn thương mô bệnh học thận ở người tăng huyết áp là không đặc hiệu. Tổn thương bao gồm xơ hóa cầu thận, teo ống thận và xơ hóa kẽ thận. Tổn thương còn thấy ở các động mạch trước cầu thận, đây là tổn thương đặc trưng nhưng không đặc hiệu, vì không thể phân biệt được với các tổn thương thận do các bệnh mạch máu.
_Hình ảnh tái cấu trúc thành mạch máu do tăng huyết áp_
**1. Kính hiển vi quang học**
Kính hiển vi quang học cho thấy hyalin hóa lớp áo giữa các động mạch trong cầu thận và động mạch đến của cầu thận, giống như thực nghiệm trên động vật. Hyalin hóa kiểu đoạn hay gặp nhất trong xơ mạch thận lành tính. Tổn thương chủ yếu thấy ở lớp áo giữa của thành động mạch, lòng mạch ở đoạn hyalin hóa không bị hẹp.
**2. Miễn dịch huỳnh quang**
Kỹ thuật miễn dịch huỳnh quang cho thấy có tích tụ các chất rỉ huyết tương, một ít globulin miễn dịch (IgM), và thành phần bổ thể (C1q, C3) trong vùng hyalin hóa.
**3. Kính hiển vi điện tử**
Kính hiển vi điện tử cho thấy có tích tụ các chất rỉ huyết tương trong vùng hyalin hóa. Tích tụ các chất rỉ huyết tương là do biến đổi cấu trúc thành mạch và tăng tính thấm thành mạch. Nếu thấy hyalin hóa thành mạch ở mẫu sinh thiết thận người trẻ tuổi, không bị đái tháo đường, có thể nghĩ đến tổn thương thận do tăng huyết áp.
**Tiến triển của tổn thương thận**
Mặc dù tăng huyết áp có thể không liên tục, chỉ phát hiện được khi theo dõi Holter huyết áp 24 giờ, tổn thương hyalin hóa thành mạch của xơ cầu thận lành tính là dấu hiệu thường thấy nhất khi quan sát trên kính hiển vi quang học. Hyalin hóa đoạn của động mạch trong cầu thận và động mạch đến, thường quan sát thấy tại thời điểm mà cấu trúc cầu thận và ống kẽ thận vẫn bình thường. Điều này phản ánh tổn thương động mạch trước cầu thận và động mạch đến, thường đi trước tổn thương búi mao mạch cầu thận. Tiếp theo thấy tổn thương cầu thận ổ đoạn. Xơ hóa cầu thận ổ đoạn được quan sát thấy ở các bệnh nhân bị tăng huyết áp nhiều năm. Trong giai đoạn sớm của tổn thương cầu thận, thấy khoang gian mạch nở rộng, sưng phồng tế bào nội mô, đôi khi lòng mao mạch được lấp đầy các chất liệu của huyết tương. Có thể thấy các tế bào ngoài mao mạch tăng sinh, tiền đề tạo thành hình liềm và dính búi mao mạch với nang Bowman, ống thận bị teo và xơ hóa kẽ thận phát triển cùng với xơ hóa cầu thận, làm thận mất dần chức năng.

## Phiếu tóm tắt thông tin điều trị các bệnh lý Thận - Lọc máu

**1. Phiếu tóm tắt thông tin điều trị là gì?**
Phiếu tóm tắt thông tin điều trị giúp cho người bệnh theo dõi và cùng tham gia vào quá trình điều trị với bác sĩ và nhân viên y tế 
Phiếu tóm tắt thông tin điều trị được xây dựng cho một bệnh xác định. Thiết kế theo dạng tờ rơi trên 1 tờ giấy khổ A4 hoặc A5 (1 trang hoặc 2 trang). Các thông tin chính được rút ra từ hướng dẫn chẩn đoán và điều trị của bệnh viện. Nội dung bao gồm:
  * Các triệu chứng lâm sàng;
  * Xét nghiệm CLS;
  * Chẩn đoán;
  * Phương pháp điều trị;
  * Biến chứng;
  * Điều trị biến chứng và Hướng dẫn chăm sóc, cách dùng thuốc, dinh dưỡng, sinh hoạt;
  * Phòng ngừa;
  * Truyền thông giáo dục sức khỏe. 


**2. Sử dụng phiếu tóm tắt thông tin như thế nào?**
Thông qua phiếu tóm tắt thông tin điều trị Người bệnh có thể biết được và tự theo dõi được quá trình điều trị bằng cách đánh dấu vào danh mục (hoặc bảng kiểm). Dựa trên các mục đã được đánh dấu, người bệnh có thể biết được các hoạt động thăm khám, xét nghiệm, chẩn đoán hình ảnh, nội soi, thăm dò chức năng, thủ thuật, phẫu thuật, phương pháp điều trị, loại thuốc điều trị... đã thực hiện hoặc dự kiến thực hiện. Từ việc theo dõi này, người bệnh có thể hỏi nhân viên y tế lý do chưa nhận được dịch vụ y tế trong phiếu tóm tắt và tiến trình điều trị đang đến giai đoạn nào.
Phiếu có thể tích hợp thêm các hướng dẫn, khuyến cáo tóm tắt về chế độ dinh dưỡng, phòng tránh tái phát, biến chứng của bệnh và các vấn đề cần lưu ý khác, giúp việc điều trị, chăm sóc hiệu quả hơn
[**Phiếu tóm tắt thông tin điều trị Bệnh lý Bệnh thận mạn giai đoạn cuối - Chạy thận nhân tạo**](https://bvnguyentriphuong.com.vn/uploads/072022/files/1_%20BTM%20GD5%20CTNT.pdf)
#### Nội dung trong file:

BỆNH VI ỆN NGUY ỄN TRI PHƯƠNG  
KHOA THẬN – LỌC M ÁU PHIẾU TÓM T ẮT 
THÔNG TIN ĐI ỀU TR Ị 
BỆNH TH ẬN M ẠN GIAI ĐO ẠN CU ỐI – CHẠY TH ẬN NHÂN T ẠO 
Hướng đi ều trị 1) Tiếp tục điều trị nguyên nhân và các bi ến chứng (đái tháo 
đường, tăng huy ết áp…): Ki ểm soát huy ết áp, đư ờng huy ết, 
mỡ máu, gi ảm tiểu đạm 
2) Điều trị các tình tr ạng quá t ải dịch, rối loạn toan ki ềm - điện 
giải, loãng xương, thi ếu máu, nhi ễm trùng catheter …  
3) ĂN L ẠT, mu ối dưới 6g/ngày (1 thìa cafe mu ối tính t ất cả các 
loại thức ăn, nư ớc uống/ngày), có th ể dùng t ỏi, hành, tiêu, 
chanh, các lo ại rau nêm và gia v ị để làm ngon mi ệng. Ăn đ ầy 
đủ thịt, cá, lòng tr ắng trứng có th ể, 2-3 lòng tr ắng trứng/ngày. 
Hạn chế nước nhập, gi ữ cân n ặng tăng không quá 1 -2kg so 
với trọng lư ợng khô gi ữa 2 lần mọc máu. Nư ớc nhập/ngày = 
nước tiểu + 500ml.  
4) Bỏ thuốc lá, rư ợu bia; t ập thể dục hàng ngày. Chích ng ừa cúm, 
viêm gan B đ ịnh kỳ. 
5) Giữ vệ sinh, gi ữ khô s ạch vị trí catheter, AVF.  
Tai bi ến, bi ến ch ứng 
có thể có 1) Quá t ải dịch, phù ph ổi, suy hô h ấp thở máy. T ụt huy ết áp.  
2) Rối loạn nhịp, suy tim, nh ồi máu cơ tim, ngưng tim. R ối loạn 
toan ki ềm. Cư ờng cận giáp th ứ phát 
3) Suy dinh dư ỡng. Thi ếu máu đ ề kháng Erythrop oietin.  
4) Nhiễm trùng catheter, nhi ễm trùng huy ết, viêm n ội tâm m ạc 
nhiễm trùng , viêm ph ổi 
5) Nhiễm trùng AVF, phình AVF, v ỡ AVF, t ắc AVF.
**[Phiếu tóm tắt thông tin điều trị Bệnh lý](https://bvnguyentriphuong.com.vn/uploads/072022/files/2_%20BTM%20GD5%20LMB.pdf)
#### Nội dung trong file:

BỆNH VI ỆN NGUY ỄN TRI PHƯƠNG  
KHOA THẬN – LỌC MÁU  PHIẾU TÓM T ẮT 
THÔNG TIN ĐI ỀU TR Ị 
BỆNH TH ẬN M ẠN GIAI ĐO ẠN CU ỐI – LỌC M ÀNG B ỤNG 
Hướng đi ều trị 1) Tiếp tục điều trị nguyên nhân và các bi ến chứng (đái tháo 
đường, tăng huy ết áp… ): Ki ểm soát huy ết áp, đư ờng huy ết, 
mỡ máu, gi ảm tiểu đạm 
2) Điều trị các tình tr ạng quá t ải dịch, rối loạn toan ki ềm - điện 
giải, loãng x ương, thi ếu máu, thay transfer set sau đi ều trị 
viêm phúc m ạc … 
3) ĂN L ẠT, mu ối dưới 6g/ngày (1 thìa cafe mu ối tính t ất cả các 
loại thức ăn, nư ớc uống/ngày), có th ể dùng t ỏi, hành, tiêu, 
chanh, các lo ại rau nêm và gia v ị để làm ngon mi ệng. Ăn đ ầy 
đủ thịt, cá, lòng tr ắng tr ứng có th ể 2-3 lòng tr ắng trứng/ngày, 
ăn đủ rau- trái cây. Nư ớc nhập = nư ớc tiểu + 500ml.  
4) Bỏ thuốc lá, rư ợu bia; t ập thể dục hàng ngày, duy trì thói quen 
đi tiêu, TRÁNH táo bón  
5) Hướng dẫn bệnh nhân t ự làm t ốt cách l ọc màng b ụng (theo 
sách hư ớng dẫn) 
Tai bi ến, bi ến ch ứng 
có th ể có 1) Quá t ải dịch, phù ph ổi, tràn d ịch màng ph ổi 
2) Rối loạn điện giải, thư ờng hạ Kali 
3) Suy dinh dư ỡng 
4) Nhiễm trùng l ỗ thoát, nhi ễm trùng đư ờng hầm, viêm phúc 
mạc, tắc ống thông**[**Bệnh thận mạn giai đoạn cuối - Lọc màng bụng**](https://bvnguyentriphuong.com.vn/uploads/072022/files/2_%20BTM%20GD5%20LMB.pdf)
#### Nội dung trong file:

BỆNH VI ỆN NGUY ỄN TRI PHƯƠNG  
KHOA THẬN – LỌC MÁU  PHIẾU TÓM T ẮT 
THÔNG TIN ĐI ỀU TR Ị 
BỆNH TH ẬN M ẠN GIAI ĐO ẠN CU ỐI – LỌC M ÀNG B ỤNG 
Hướng đi ều trị 1) Tiếp tục điều trị nguyên nhân và các bi ến chứng (đái tháo 
đường, tăng huy ết áp… ): Ki ểm soát huy ết áp, đư ờng huy ết, 
mỡ máu, gi ảm tiểu đạm 
2) Điều trị các tình tr ạng quá t ải dịch, rối loạn toan ki ềm - điện 
giải, loãng x ương, thi ếu máu, thay transfer set sau đi ều trị 
viêm phúc m ạc … 
3) ĂN L ẠT, mu ối dưới 6g/ngày (1 thìa cafe mu ối tính t ất cả các 
loại thức ăn, nư ớc uống/ngày), có th ể dùng t ỏi, hành, tiêu, 
chanh, các lo ại rau nêm và gia v ị để làm ngon mi ệng. Ăn đ ầy 
đủ thịt, cá, lòng tr ắng tr ứng có th ể 2-3 lòng tr ắng trứng/ngày, 
ăn đủ rau- trái cây. Nư ớc nhập = nư ớc tiểu + 500ml.  
4) Bỏ thuốc lá, rư ợu bia; t ập thể dục hàng ngày, duy trì thói quen 
đi tiêu, TRÁNH táo bón  
5) Hướng dẫn bệnh nhân t ự làm t ốt cách l ọc màng b ụng (theo 
sách hư ớng dẫn) 
Tai bi ến, bi ến ch ứng 
có th ể có 1) Quá t ải dịch, phù ph ổi, tràn d ịch màng ph ổi 
2) Rối loạn điện giải, thư ờng hạ Kali 
3) Suy dinh dư ỡng 
4) Nhiễm trùng l ỗ thoát, nhi ễm trùng đư ờng hầm, viêm phúc 
mạc, tắc ống thông
**[Phiếu tóm tắt thông tin điều trị Bệnh lý Bệnh Thận mạn](https://bvnguyentriphuong.com.vn/uploads/072022/files/3_%20B%E1%BB%86NH%20TH%E1%BA%ACN%20M%E1%BA%A0N.pdf)
#### Nội dung trong file:

BỆNH VI ỆN NGUY ỄN TRI PHƯƠNG  
KHOA THẬN – LỌC MÁU  PHIẾU TÓM T ẮT 
THÔNG TIN ĐI ỀU TR Ị 
BỆNH TH ẬN M ẠN  
Hướng đi ều trị 1) Tìm và đi ều trị nguyên nhân (đái tháo đư ờng, tăng huy ết áp, 
bệnh ống th ận mô k ẽ, tắc ngh ẽn ho ặc rối loạn chức năng 
đường tiểu, bệnh lý th ận – hệ niệu bẩm sinh, t ổn thương th ận 
cấp không h ồi phục, bệnh lý c ầu thận, ống th ận – mô k ẽ, bệnh 
lý mạch máu th ận: hẹp động m ạch th ận, huy ết khối tĩnh m ạch 
thận…)  
2) ĂN L ẠT, mu ối dưới 6g/ngày (1 thìa cafe mu ối tính t ất cả các 
loại thức ăn, nư ớc uống/ngày), b ỏ thuốc lá, rư ợu bia; t ập thể 
dục hàng ngày. Ch ế độ rau- trái cây tùy lư ợng nư ớc tiểu 24 
giờ, Kali máu 
3) Điều chỉnh các y ếu tố có th ể gây t ổn thương th ận cấp: quân 
bình đi ện giải, thăng b ằng ki ềm toan, tránh các thu ốc gây t ổn 
thương th ận (NSAIDs, kháng sinh lưu ý ch ỉnh liều, KHÔNG 
dùng các thực phẩm ch ức năng b ổ thận, thu ốc nam/ b ắc/ đông 
y), n ếu cần dùng thu ốc cản quang - ưu tiên ch ụp cản quang 
đồng th ẩm thấu  
4) Kiểm soát huy ết áp, đư ờng huy ết, mỡ máu, gi ảm tiểu đạm 
5) Điều trị các tình tr ạng quá t ải dịch, rối loạn toan ki ềm - điện 
giải, loãng xương, thi ếu máu…  
6) Chuẩn bị điều trị thay th ế thận khi suy th ận nặng 
Tai bi ến, bi ến ch ứng 
có th ể có 1) Rối loạn nhịp, ngưng tim  
2) Phù ph ổi cấp- suy hô h ấp thở máy 
3) Suy dinh dư ỡng, xu ất huy ết tiêu hóa  
4) Rối loạn tri giác**
**[Phiếu tóm tắt thông tin điều trị Bệnh lý Bệnh Thận đái tháo đường](https://bvnguyentriphuong.com.vn/uploads/072022/files/4_%20B%E1%BB%86NH%20TH%E1%BA%ACN%20%C4%90%C3%81I%20TH%C3%81O%20%C4%90%C6%AF%E1%BB%9CNG.pdf)
#### Nội dung trong file:

BỆNH VI ỆN NGUY ỄN TRI PHƯƠNG  
KHOA THẬN – LỌC MÁU  PHIẾU TÓM T ẮT 
THÔNG TIN ĐI ỀU TR Ị 
BỆNH TH ẬN ĐÁI TH ÁO ĐƯỜNG  
Hướng đi ều trị 1) Giảm cân n ếu thừa cân, t ập thể dục 
2) Chế độ ăn: ngày 3 b ữa chính, KHÔNG ăn b ữa phụ/ KHÔNG 
ăn vặt, giảm tinh b ột, hạn chế trái cây ch ỉ số đường cao, không 
sử dụng th ức uống ng ọt… Ăn đ ầy đủ đạm, rau xanh, ch ất xơ 
3) Có th ể sử dụng các nhóm thu ốc hạ đường huy ết uống ho ặc liệu 
pháp insulin tùy  chỉ định. M ục tiêu không gây h ạ đường huy ết, 
đường huy ết và HbA1c m ục tiêu tùy tình tr ạng tu ổi, các b ệnh 
lý kết hợp 
4) Thuốc ức chế men chuy ển, ức chế thụ thể nếu có đ ạm niệu 
5) Theo dõi đư ờng huy ết mao m ạch 
Tai bi ến, biến ch ứng 
có th ể có 1) Biến chứng m ạch máu: não, tim, th ận, mắt, mạch máu ngo ại 
biên  
2) Bệnh võng m ạc đái tháo đư ờng, b ệnh th ận đái tháo đư ờng, 
bệnh th ần kinh ngo ại biên, li ệt hệ tiêu hóa  
3) Biến dạng bàn chân ti ểu đường 
4) Nhiễm trùng  
5) Biến chứng cấp: hạ đường huy ết, nhi ễm toan ceton, tăng áp 
lực thẩm thấu máu**
**[Phiếu tóm tắt thông tin điều trị Bệnh lý Hội chứng Thận hư](https://bvnguyentriphuong.com.vn/uploads/072022/files/5_%20H%E1%BB%98I%20CH%E1%BB%A8NG%20TH%E1%BA%ACN%20H%C6%AF.pdf)
#### Nội dung trong file:

BỆNH VI ỆN NGUY ỄN TRI PHƯƠNG  
KHOA THẬN – LỌC MÁU  PHIẾU TÓM T ẮT 
THÔNG TIN ĐI ỀU TR Ị 
HỘI CH ỨNG TH ẬN HƯ  
Hướng đi ều trị 1) Điều trị đặc hiệu: corticoid, thu ốc ức chế miễn dịch theo 
chỉ định (phân bi ệt tiểu đạm ngư ỡng th ận hư do đái tháo 
đường, thu ốc, côn trùng c ắn, viêm gan B, C, HIV… trư ớc 
khởi trị) 
2) Điều trị giảm đạm niệu, giảm quá t ải, kiểm soát huy ết áp, 
đường huy ết, rối loạn lipid máu, phòng ng ừa và đi ều trị 
biến chứng (n ếu có), b ổ sung calcium, vitamin D  
3) Chế độ ăn: gi ảm mu ối nhập dư ới 6g NaCl/24 gi ờ, đủ 
protein theo hư ớng dẫn, nư ớc nhập tùy tình tr ạng quá t ải 
và nư ớc tiểu/ngày, theo dõi cân n ặng/ngày. Ăn nhi ều lòng 
trắng trứng m ỗi ngày.  
4) Theo dõi tác d ụng ph ụ các thu ốc điều trị corticoid, các 
thuốc ức chế miễn dịch. 
5) Sinh thi ết thận nếu cần 
Tai bi ến, biến ch ứng 
có th ể có 1) Thuyên t ắc phổi, huy ết khối tĩnh m ạch cửa, tĩnh m ạch th ận 
2) Nhiễm trùng: Viêm phúc m ạc, viêm mô t ế bào. 
3) Suy dinh dư ỡng 
4) Liên quan đi ều trị: loãng xương, đ ục thủy tinh th ể, đái tháo 
đường m ới, tăng huy ết áp, xu ất huy ết tiêu hóa, suy thư ợng 
thận 
5) Tổn thương th ận cấp, bệnh th ận mạn**
**[Phiếu tóm tắt thông tin điều trị Bệnh lý Nhiễm trùng tiểu](https://bvnguyentriphuong.com.vn/uploads/072022/files/6_%20NHI%E1%BB%84M%20TR%C3%99NG%20TI%E1%BB%82U.pdf)
#### Nội dung trong file:

BỆNH VI ỆN NGUY ỄN TRI PHƯƠNG  
KHOA THẬN – LỌC MÁU  PHIẾU TÓM T ẮT 
THÔNG TIN ĐI ỀU TR Ị 
NHI ỄM TR ÙNG TI ỂU 
Hướng đi ều trị 1) Thuốc kháng sinh (u ống ho ặc tĩnh m ạch tùy m ức độ bệnh) 
chỉnh li ều theo ch ức năng th ận. NTT trên: kháng sinh 3 -5 
ngày (nh ẹ: điều trị ngoại trú). NNT trên: kháng sinh 10 -14 
ngày  
2) Triệu chứng: Gi ảm sốt, giảm đau  
3) Điều trị tình tr ạng thu ận lợi gây nhi ễm trùng ti ểu (sỏi thận, 
phì đ ại tiền liệt tuy ến, bàng quang th ần kinh, nhi ễm trùng 
vùng ph ụ cận: đư ờng ru ột, âm đ ạo) 
Tai bi ến, biến ch ứng 
có th ể có 1) Áp xe th ận, nhi ễm trùng huy ết 
2) Shock nhi ễm trùng, suy đa cơ quan  
3) Tổn thương th ận thận cấp, bệnh th ận mạn**
**[Phiếu tóm tắt thông tin điều trị Bệnh lý Tăng huyết áp](https://bvnguyentriphuong.com.vn/uploads/072022/files/7_%20%20T%C4%82NG%20HUY%E1%BA%BET%20%C3%81P\(1\).pdf)**
**[Phiếu tóm tắt thông tin điều trị Bệnh lý Tổn thương Thận cấp](https://bvnguyentriphuong.com.vn/uploads/072022/files/8_%20T%E1%BB%94N%20TH%C6%AF%C6%A0NG%20TH%E1%BA%ACN%20C%E1%BA%A4P.pdf)
#### Nội dung trong file:

BỆNH VI ỆN NGUY ỄN TRI PHƯƠNG  
KHOA THẬN – LỌC MÁU  PHIẾU TÓM T ẮT 
THÔNG TIN ĐI ỀU TR Ị 
TỔN TH ƯƠNG TH ẬN CẤP 
Hướng đi ều trị 1) Phân bi ệt tổn thương th ận cấp: trư ớc, tại hay sau th ận (thi ếu 
dịch, nhi ễm trùng n ặng, suy tim c ấp, kháng sinh, NSAIDs, 
thực phẩm ch ức năng, thu ốc cản quang, t ắc ngh ẽn đư ờng 
niệu …)  
2) ĂN L ẠT, mu ối dưới 6g/ngày (1 thìa cafe mu ối tính t ất cả 
các lo ại thức ăn, nư ớc uống/ngày), b ỏ thuốc lá, rư ợu bia; t ập 
thể dục hàng ngày. Ch ế độ rau- trái cây tùy lư ợng nư ớc tiểu 
24 gi ờ, K máu. U ống đủ nước theo hư ớng dẫn tùy trình tr ạng 
bệnh. 
3) Điều trị bệnh đồng m ắc 
4) Điều trị biến chứng: tình tr ạng quá t ải dịch, r ối loạn toan 
kiềm - điện giải (tăng Kali, h ạ Natri, toan chuy ển hóa), thi ếu 
máu, các bi ểu hiện hội chứng ure huy ết cao …  
5) Có th ể điều trị lọc máu c ấp cứu nếu tình tr ạng bệnh không 
cải thiện với điều trị nội tối đa 
Tai bi ến, bi ến ch ứng 
có th ể có 1) Rối loạn nhịp, ngưng tim, suy tim, tràn d ịch màng tim  
2) Phù ph ổi cấp- suy hô h ấp thở máy 
3) Hội chứng ure huy ết cao: xu ất huy ết tiêu hóa, r ối loạn tri giác, 
rung gi ật cơ…**
**[Phiếu tóm tắt thông tin điều trị Bệnh lý Viêm phổi](https://bvnguyentriphuong.com.vn/uploads/072022/files/9_%20VI%C3%8AM%20PH%E1%BB%94I.pdf)
#### Nội dung trong file:

BỆNH VI ỆN NGUY ỄN TRI PHƯƠNG  
KHOA THẬN – LỌC MÁU  PHIẾU TÓM T ẮT 
THÔNG TIN ĐI ỀU TR Ị 
VIÊM PHỔI 
Hướng đi ều trị 1) Thuốc kháng sinh (u ống ho ặc tĩnh m ạch tùy m ức độ bệnh) – 
chỉnh liều theo ch ức năng th ận 
2) Nâng đ ỡ: Loãng đàm, gi ảm sốt, giảm đau, v ận động, dinh 
dưỡng, giãn ph ế quản, bù d ịch tùy tình tr ạng bệnh 
3) Oxy li ệu pháp trong gi ảm oxy máu  
4) Phòng ng ừa: chích ng ừa cúm, ph ế cầu 
5) Bỏ hút thu ốc lá, gi ữ ấm cơ th ể, vệ sinh răng mi ệng. T ập vật 
lý trị liệu hô h ấp, uống nhi ều nước, ăn nhi ều rau tăng 
cường mi ễn dịch 
Tai bi ến, biến ch ứng 
có th ể có 1) Suy hô h ấp cấp 
2) Nhiễm trùng huy ết, nhi ễm trùng lan r ộng nơi khác: viêm n ội 
tâm m ạc nhi ễm trùng, viêm màng não, viêm kh ớp, áp xe sâu  
3) Shock nhi ễm trùng, suy đa t ạng 
4) Áp xe ph ổi, tràn d ịch, tràn m ủ màng ph ổi**
**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/) **- Đa khoa Hạng I Thành phố Hồ Chí Minh

## ️ Quy trình đặt catheter màng bụng lọc máu cấp cứu

**ĐẠI CƯƠNG**
Suy thận cấp là tình trạng giảm chức năng thận đột ngột, dẫn đến giảm mức lọc cầu thận nhanh chóng (trong vài giờ, vài ngày), giảm khả năng đào thải các sản phẩm chuyển hoá của nitơ, gây mất cân bằng duy trì nội môi về nước, dịch và điện giải.
Ngày nay người ta coi suy thận cấp khi creatinin máu tăng thêm 0.5mg/dl (44 mcmol/l) so với creatinin máu trước đó của người với chức năng thận bình thường.
Suy thận cấp chiếm khoảng 5% tổng số bệnh nhân vào viện và khoảng 30 - 40% tại các khoa hồi sức.
Các biện pháp điều trị suy thận cấp trong hồi sức cấp cứu:
+ Thận nhân tạo ngắt quãng (intermitent hemodialysis)
+ Thẩm phân phúc mạc liên tục hay còn gọi lọc màng bụng (Peritoneal dialysis).
+ Điều trị thay thế thận liên tục (CRRT) gồm một số kỹ thuật sau: Lọc máu tĩnh mạch-tĩnh mạch liên tục không thẩm tách (CVVH), lọc máu tĩnh mạch-tĩnh mạch liên tục có thẩm tách (CVVHDF), siêu lọc chậm liên tục (SCUF) - Lọc màng bụng là một kỹ thuật được tiến hành bằng cách đưa vào khoang phúc mạc 1-3 lít dịch thẩm phân thành phần có đường, mui và một số chất khác, các chất độc, sản phẩm của quá trình chuyển hoá trong cơ thể và nước sẽ được loại b từ máu và các tổ chức trong khoang phúc mạc vào khoang dịch lọc dựa trên cơ chế khuyếch tán và siêu lọc.
Nước và các chất hoà tan được loại b bằng cơ chế khuyếch tán và siêu lọc dựa vào sự chênh lệch nồng độ các chất hoà tan, áp lực thẩm thấu giữa khoang dịch thẩm phân và khoang máu trong mao mạch phúc mạc cũng như hệ bạch mạch trong phúc mạc.
**CHỈ ĐỊNH**
Suy thận cấp có chỉ định lọc máu cấp: với các bệnh nhân có biểu hiện tăng urê máu, creatinin máu, kali máu, thừa dịch, toan chuyển hoá:
+ Bệnh nhân không lấy được đường vào mạch máu cho lọc máu ngắt quãng (bệnh lý mạch máu nhiều nơi, viêm tắc TM, tắc cầu nối động - tĩnh mạch, không có vị trí để đặt catheter chạy thận nhân tạo...)
+ Tình trạng bệnh tim mạch mạn tính, cơ thể không chấp nhận được với lọc máu cấp cứu
**CHỐNG CHỈ ĐỊNH**
Bệnh lý nhiễm khuẩn trong khoang bụng hoặc các tạng trong ổ bụng (viêm phúc mạc, viêm ruột, áp xe các tạng).
Rối loạn đông máu nặng.
Mới phẫu thuật ổ bụng, có tăng áp lực ổ bụng do các nguyên nhân khác (viêm tuỵ cấp nặng, dịch cổ chướng, u phần phụ..)
Có thai.
Bệnh nhân đang được thông khí nhân tạo (khi đưa một lượng dịch lớn vào ổ bụng sẽ gây tăng áp lực ổ bụng, nguy cơ gây giảm thông khí phế nang).
Béo bệu.
Gãy xương đùi, chậu hông.
Dính ruột.
**CHUẨN BỊ**
**CÁC BƯỚC TIẾN HÀNH**
**Đặt catheter vào khoang ổ bụng:**
Catheter trong lọc màng bụng cấp cứu nên chọn loại Tenckhoff (catheter thẳng, có 2 mức cuff cố định) và nên thay catheter mỗi 3 ngày.
Catheter đặt vào khoang ổ bụng, nối với ba chục chữ Y, dẫn lưu một chiều, một nhánh của chữ Y nối với túi đựng dịch lọc ( để trên cao), nhánh kia nối với đầu của túi dịch thải vô trùng.
**Dịch lọc màng bụng:**
Dung dịch lọc màng bụng của hãng B.Braun túi 2000ml hoặc dịch pha từ các loại dịch thông thường.
Đề phòng tăng đường máu do nồng độ đường trong dịch lọc quá cao, có thể pha insulin vào dịch lọc màng bụng.
Heparin: heparin thường được pha vào dịch lọc màng bụng với mục đích ề phòng tắc catheter do các cục máu đông và sợi huyết. Heparin cũng không có khả năng hấp phụ qua màng bụng, vì vậy không làm tăng nguy cơ chảy máu.
Liều lượng 200-500 đơn vị/1 lít dịch lọc
Kali: dịch lọc màng bụng bình thường không có kali, vì vậy lọc màng bụng cho bệnh nhân có kali máu bình thường hoặc giảm phải chú ý theo dõi xét nghiệm kali máu, điều chỉnh kali trong dịch lọc, chú ý nguy cơ rối loạn nhịp tim đặc biệt bệnh nhân có dùng thuốc nhóm Digitalis.
Một số lựa chọn cho lọc màng bung cấp cứu: về thời gian, thể tích trao ổi, lựa chọn loại dịch lọc. Thời gian:
Trong lọc màng bụng cấp cứu thời gian tiến hành nên kéo dài 48-72 giờ. Sau mỗi 24 giờ nên đánh giá lại tình trạng lâm sàng và các xét nghiệm để có các thay đổi về chỉ định tiếp theo.
Một chu trình lọc màng bụng có thể được chọn:
+ Chu trình chuẩn: 60 phút/1 chu trình/ 2000ml: 10 phút dịch vào, ngâm 30 phút, cho dịch chảy ra 20 phút.
+ Chu trình lọc ngắn (lọc màng bụng hiệu quả cao): 30 phút/1 chu trình/ 2000 ml, thời gian dịch vào 10 phút, ngâm 10 phút, cho dịch chảy ra 10 phút.
+ Thể tích trao ổi: 1000-3000 ml/chu trình tuỳ theo cơ địa bệnh nhân, bệnh nhân nh bé, có bệnh phổi, thể tích trao đổi < 2000 ml/chu trình, bệnh nhân to lớn, có thoát vị bẹn, thể tích trao đổi có thể tới 2500-3000 ml/1 lần.
+ Lựa chọn loại dịch lọc: tuỳ theo mục đích lấy dịch mà chỉ định dịch lọc màng bụng với glucose 1,5, 2.5, hoặc 3,5.
+ Các điều trị hỗ trợ.
+ insulin: Theo dõi đường máu, điều trị thêm insulin tĩnh mạch hoặc dưới da theo xét nghiệm đường mao mạch, hoặc pha thêm insulin vào dịch lọc.
+ Protein mất qua lọc màng bụng mỗi ngày 10-20 gam, vì vậy chế độ tăng cường dinh dưỡng là rất cần thiết.
**THEO DÕI VÀ XỬ LÝ SỐC**
Thể tích dịch cho một chu trình lọc màng bụng, thời gian ổ vào, thời gian ngâm, thời gian tháo ra, lựa chọn loại dịch lọc hoàn toàn do bác sĩ chỉ định.
Chú ý cân bằng dịch vào và ra, các thao tác phải Tuyệt đối vô trùng.
Lọc màng bụng bằng máy có ưu điểm: máy sẽ ảm bảo cân dịch vào ra, dịch được làm ấm.
Chọn dịch: CAPD glucose l.5; 2.5 hoặc 3.5. Dịch CAPD 1,5 có nồng độ áp lực thẩm thấu 358 mOsm/l.
Thời gian lọc màng bụng: kéo dài 12-24-48-72 giờ tuỳ theo chỉ định và diễn biến lâm sàng.
Một ví dụ về đơn chỉ định cho lọc màng bụng cấp:
+ Thời gian 24 giờ.
+ Thể tích dịch lọc trao ổi: 2000 ml.
+ Thời gian trao ổi/ chu trình: 60 phút (dịch vào 10 phút, dịch ra 20 phút, ngâm 30 phút).
+ Dịch lọc Glucose 1.5
+ Thêm 3.5 mmol KCl/ 1 lít dịch lọc.
+ Heparin 200 đơn vị/ 1 lít dịch lọc.
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh

## ️ Suy thận cấp

**ĐẠI CƯƠNG**
**Định nghĩa**
Suy thận cấp là một hội chứng được biểu hiện bằng sự giảm nhanh của mức lọc cầu thận với thể tích nước tiểu < 0,5 ml/kg/giờ kéo dài trên 6 giờ, và có nồng độ creatinin huyết tương tăng thêm 0,5 mg/dl (44Pg/l) hoặc trên 50% so với giá trị bình thường (trên 130Pg/l) ở người trước đó chức năng thận bình thường.
Hậu quả: ứ đọng các sản phẩm chuyển hoá của nitơ, rối loạn cân bằng nước, điện giải, axit-bazơ.
**Định nghĩa mới: theo phân loại RIFLE**
GFR: mức lọc cầu thận; RRT: điều trị thay thế thận
(Theo ADQI 2003 và theo KDIGO Clinical Practice Guideline for Acute Kidney Injury 2012)
**NGUYÊN NHÂN**
**Suy thận cấp trước thận**
_Giảm thể tích tuần hoàn_
Mất máu: chấn thương, chảy máu tiêu hoá, hoặc chảy máu khác.
Mất dịch trong lòng mạch: bỏng, viêm phúc mạc, viêm tụy cấp, tắc ruột, hạ albumin máu, hội chứng thận hư, xơ gan, ỉa chảy, nôn, hút dịch tiêu hoá. Tiêu cơ vân cấp.
Mất qua thận: đái đường toan xeton, tăng áp lực thẩm thấu máu như (sử dụng manitol, tăng natri máu), hoặc giảm kali máu, giảm canxi máu.
Mất qua da: mất mồ hôi, bỏng nặng, vận động nặng kéo dài (chạy marathon hay làm việc nặng trong môi trường nhiệt độ cao), rối loạn điều hoà thân nhiệt (hội chứng tăng thân nhiệt ác tính ), say nắng say nóng …
Giảm thể tích tuần hoàn liên quan đến giảm cung lượng tim : nhồi máu cơ tim, sốc tim, tràn dịch màng tim có ép tim, nhồi máu phổi, loạn nhịp tim.
_Do mạch thận_
Tắc tĩnh mạch mạch thận.
Co thắt mạch thận (dùng thuốc ức chế men chuyển ở bệnh nhân suy tim ứ huyết) hoặc dùng noradrenalin khi chưa truyền đủ dịch …).
Nhồi máu động mạch thận.
Hẹp động mạch thận.
Xơ vữa mạch thận.
Phình tách động mạch chủ bụng.
_Rối loạn điều hoà mạch thận_
Nhiễm trùng.
Do prostaglandin hoặc ức chế men chuyển.
Hội chứng gan thận: có giãn mạch hệ thống dẫn đến tụt huyết áp, thiểu niệu do co thắt mạch thận cùng với rối loạn chức năng gan nặng. Cơ chế bệnh sinh chưa rõ.
**Suy thận cấp tại thận**
_Ống thận:_
Phổ biến nhất gây suy thận cấp.
Thiếu máu: do tình trạng suy thận trước thận nặng và kéo dài.
Do thuốc: thuốc kháng sinh (aminoglycoside, cephalosporin, amphotericinB), thuốc cản quang có iode, kim loại nặng, hoá chất điều trị (cisplatin).
Suy thận cấp thứ phát sau nhiễm khuẩn nặng, điều trị muộn: giảm dòng máu tới thận gây tổn thương thiếu máu, mất khả năng tự điều hoà mạch thận và co mạch thận.
Tắc ống thận do sản phẩm phân huỷ từ tế bào: hemoglobulin và myoglobulin niệu (tiêu cơ vân, tan máu, tổn thương cơ do nhiệt), myeloma, các tinh thể muối oxalate, urat.
Mang thai: sản giật, chảy máu tử cung...
_Viêm thận kẽ_
Nhiễm trùng: vi khuẩn (_streptococcus, pneumococcus_), virút (_EBV, CMV, HIV_), nấm,  _Mycoplasma_.
Thâm nhiễm: lymphoma, sarcoidosis.
Kháng sinh: penicilin, rifampicin, vancomycin, quinolone, cephalosporin.., acyclovir, ethambutol. 
Lợi tiểu: thiazide, furosemide. 
Các thuốc khác: thuốc chống viêm giảm đau không steroide, ức chế men chuyển, allopurinol.
Nguyên nhân do cầu thận:
Bệnh mạch máu và màng đáy cầu thận.
Bệnh kháng thể kháng màng đáy cầu thận: hội chứng Goodpasture.
Bệnh lý mạch máu: viêm mạchWegener, viêm mạch, tăng huyết áp ác tính.
Do thuốc: cyclosporin, amphotericin B, cisplatin ...
Hội chứng tan máu tăng ure máu (HUS), hội chứng tan máu giảm tiểu cầu (TTP).
**Suy thận cấp sau thận**
Tắc ống thận: axít uric, canci oxalat, acyclovir, methotrexate, protein Bence Jone trong bệnh đa u tủy xương.
Tắc nghẽn tại thận: cục máu đông, sỏi, hoại tử nhú.
Tắc niệu quản: sỏi niệu quản, do chèn ép từ ngoài vào ví dụ u sau phúc mạc, u tử cung, u xơ tiền liệt tuyến, u niệu đạo, bàng quang, buộc nhầm niệu quản trong mổ đẻ...
Tắc niệu đạo: co thắt niệu đạo, bệnh lý tuyến tiền liệt, khối u bàng quang.
**TRIỆU CHỨNG**
**Lâm sàng**
Điển hình tiến triển qua 4 giai đoạn.
**Giai đoạn 1:**
24 giờ đầu, mệt, buồn nôn, nôn, khó thở, đau ngực, nước tiểu ít dần, vô niệu. Triệu chứng của nguyên nhân gây ra suy thận cấp như ngộ độc, nhiễm khuẩn, mất nước. Điều trị kịp thời và đúng có thể tránh tiến triển sang giai đoạn 2.
**Giai đoạn 2:**
Toàn phát với các triệu chứng nặng và các biến chứng có thể tử vong.
Kéo dài 1-6 tuần, trung bình sau 7-14 ngày người bệnh sẽ có nước tiểu trở lại.
Thiểu, vô niệu, phù. Tuỳ theo thể bệnh mà vô thiểu niệu xuất hiện rất nhanh, đồng thời có triệu chứng thừa dịch như phù phổi, suy tim ứ huyết.
Urê, creatinin máu tăng nhanh. Các triệu chứng của tăng ure máu như chảy máu nội tạng, viêm màng ngoài tim, biểu hiện rối loạn não.
Rối loạn điện giải, tăng kali máu gây ra các rối loạn nhịp tim như sóng T cao, QT ngắn, ngoại tâm thu thất, rung thất, xoắn đỉnh. 
Toan chuyển hoá: pH, HCO3máu giảm, có khoảng trống anion. Người bệnh thở sâu, giãn mạch, tụt huyết áp.
**Giai đoạn 3:**
Đái trở lại, trung bình 5-7 ngày
Có lại nước tiểu 200-300ml/24giờ, lượng nước tiểu tăng dần 4-5lít/24giờ. 
Các nguy cơ: mất nước do đái nhiều, vẫn tăngurê, kali máu, rối loạn điện giải
**Giai đoạn 4:**
Hồi phục, tuỳ theo nguyên nhân ( 2-6 tuần), trung bình khoảng 4 tuần.
**Cận lâm sàng**
Nồng độ creatinin huyết tương, ure huyết tương.tăng
Rối loạn điện giải máu. Toan chuyển hóa pH giảm, HCO3, dự trữ kiềm giảm.
Các xét nghiệm khác nhằm chẩn đoán phân biệt, gợi ý nguyên nhân:
Thiếu máu, có mảnh vỡ hồng cầu: hội chứng tan máu tăng ure máu, tan máu vi mạch, viêm nội tâm mạc, đông máu nội quản rải rác.
Canxi máu tăng kèm theo suy thận cấp: thường liên quan bệnh ác tính phá hủy xương.
Men creatine kinase (CPK) tăng > 6000 đơn vị hoặc có myoglobulin trong nước tiểu: tiêu cơ vân.
Bất thường về điện di miễn dịch: gợi ý nguyên nhân myeloma.
Xét nghiệm huyết thanh: kháng thể kháng nhân (+), kháng thể kháng màng đáy cầu thận (+), pANCA (+) nghi ngờ bệnh lý tự miễn dịch. 
Tăng bạch cầu ưa axit gợi ý suy thận do viêm thận kẽ cấp do dị ứng.
Suy chức năng gan: tìm chứng gan thận, suy tim ứ huyết, nhiễm khuẩn.
Xét nghiệm nước tiểu: protein, điện giải, ure, creatinin, áp lực thẩm thấu niệu.
Nước tiểu: nhiều hồng cầu, trụ hồng cầu gợi ý nguyên nhân viêm tiểu cầu thận, viêm mạch thận. Nhiều tế bào mủ, trụ bạch cầu gợi ý viêm thận kẽ cấp nhiễm khuẩn.
**Các xét nghiệm khác:** giúp tìm nguyên nhân
Chụp Xquang bụng: tìm sỏi, xác định bóng thận.
Siêu âm bụng, CT-scan ổ bụng: bệnh lý thận, mạch thận, ứ nước thận, hẹp động mạch thận.
Chụp xạ hình thận: đánh giá tưới máu thận và chức năng bài tiết thận.
MRI mạch máu xác định tắc nghẽn động mạch, tĩnh mạch thận.
Sinh thiết thận: chỉ định khi
Suy thận cấp tại thận: trường hợp chẩn đoán chưa rõ ràng như viêm cầu thận cấp, viêm cầu thận Lupus, bệnh thận kẽ cấp tính tiến triển xấu đi sau khi đã loại trừ các nguyên. 
Chẩn đoán chưa chắc chắn, dựa vào kết quả sinh thiết thận giúp cho điều trị đặc hiệu như viêm cầu thận, bệnh viêm mạch, HUS, TTP, viêm thận kẽ dị ứng.
**CHẨN ĐOÁN**
**Chẩn đoán xác định**
Xét nghiệm creatinin huyết tương tăng thêm 0,5 mg/dl (44Pg/l) so với creatinin huyết tương trước bị bệnh hoặc trên 50% so với giá trị bình thường.
Thể tích nước tiểu: theo phân độ RIFLE với thể thiểu niệu (nước tiểu< 200 ml/12 giờ, hoặc mức lọc cầu thận giảm 50%), vô niệu (nước tiểu < 100 ml/24 giờ).
Các chỉ số khác: tăng urê, toan chuyển hoá, dự trữ kiềm giảm, BE giảm. - Có nguyên nhân hoặc yếu tố nguy cơ cao gây suy thận cấp.
**Chẩn đoán phân biệt**
Suy thận cấp chức năng với suy thận cấp thực thể (hoại tử ống thận cấp).
**FE Na ****= (U Na xPCr/PNa) x UCr) (100)**
Đợt cấp của suy thận mạn: tiền sử có bệnh thận trước đó, thiếu máu nặng, urê,
**Chẩn đoán thể**
Thể vô niệu.
Thể thiểu niệu.
Thể bảo tồn nước tiểu.
Suy thận cấp chức năng (suy thận cơ năng, suy thận cấp trước thận) hay suy thận cấp thực thể.
**Chẩn đoán nguyên nhân: (tham khảo phần 2)**
**ĐIỀU TRỊ**
**Nguyên tắc xử trí**
Sơ bộ chẩn đoán được suy thận cấp chức năng hay thực thể để có thái độ xử trí cấp cứu.
Xử trí cấp cứu vì các dấu hiệu đe doạ tính mạng người bệnh: tăng kali máu, phù phổi cấp, phù não co giật, toan chuyển hóa nặng.
Xử trí nguyên nhân gây ra suy thận cấp: đòi hỏi chuyên khoa, cần kết hợp với các thăm dò cận lâm sàng.
**Xử trí ban đầu và vận chuyển cấp cứu:**
Khi phù to, đái ít, khó thở nhiều ở người bệnh có tiền sử bệnh thận phải đến ngay cơ sở y tế chuyên khoa, không để người bệnh điều trị tại nhà.
Nắm được các biện pháp điều trị cấp cứu tăng kali máu có rối loạn nhịp tim, phù phổi cấp, phù não co giật, toan chuyển hóa nặng gây trụy tim mạch.
Thận trọng trong quá trình vận chuyển người bệnh có thể tử vong vì tăng kali máu, suy hô hấp cấp, trụy tim mạch.
**Xử trí tại bệnh viện**
_Suy thận cấp chức năng_
**Xử trí nguyên nhân:**
Giảm thể tích tuần hoàn trong lòng mạch: cầm máu, truyền bù thể tích tuần hoàn (mất máu, truyền hồng cầu, các chế phẩm máu) mất dịch như nôn, ỉa chay, say nắng (bù dịch đẳng trương truyền và uống). Mục tiêu cần đạt duy trì ALTMTT 8-12 mmHg và huyết áp trung bình t 65 mmHg.
Nếu nguyên nhân giảm huyết áp do thuốc (ức chế men chuyển) , do các thuốc ức chế COX II, hoặc các thuốc kháng viêm không steroid (NSAIDs) và các chất độc với thận thì dừng thuốc.
**Điều trị bệnh chính:**
Xuất huyết tiêu hóa, bỏng rộng nặng, viêm phúc mạc, viêm tụy cấp, tắc ruột.
Loại bỏ các thuốc độc với thận và có kali, các thuốc gây giảm dòng máu tới thận, tránh dùng thuốc cản quang.
**Điều trị các yếu tố gây mất bù và các căn nguyên mãn tính khác.**
_Suy thận cấp thực tổn_
**Kiểm soát cân bằng nước và đảm bảo huyết động:**
Đủ thể tích lòng mạch, theo dõi ALTMTT, dấu hiệu phù niêm mạc, kết mạc, phù tổ chức kẽ, tĩnh mạch cổ nổi, nghe phổi, cân nặng hàng ngày, dịch vào-ra.
Cân bằng dịch: dịch ra= số lượng tiểu/24 giờ + 0,5-0,6 ml/kg/giờ ( mất qua da, mồ hôi khoảng 850-1000ml/ngày/70kg). Sốt thêm 10C, nước mất thêm 13%.
Truyền các loại dịch có khả năng giữ lại trong lòng mạch, đặc biệt khi có giảm albumim máu, có nhiễm khuẩn nặng, có ARDS.Lựa chọn dịch truyền muối tinh thể hay dung dịch albumin hoặc dung dịch keo tùy theo tình trạng lâm sàng và nguyên nhân.
Dịch được lựa chọn dùng là NaCl 0,9% hoặc albumin 5%: giúp tăng tưới máu tổ chức, giảm tính thấm mạch, giảm phù (đặc biệt khi có nhiễm khuẩn).
Khi đã có phù khoảng kẽ, không nên truyền nhiều dịch muối đẳng trương vì sau khi truyền thể tích giữ lại trong lòng mạch được 20%, thời gian bán huỷ ngắn 2030 phút.
Huyết áp không lên khi ALTMTT trên 8-12 mmHg, cần chỉ định thuốc vận mạch, norepinephrine truyền TM liên tục, liều 0,1đến 2 mcg/kg/phút.
**Kiểm soát thăng bằng kiềm toan, điện giải:**
Hạn chế kali đưa vào và điều trị tăng kali máu: điều trị khi kali máu > 5,5 mEq/l hoặc có thay đổi trên điện tâm đồ.
Kayexalate 30 gam/4-6 giờ kết hợp sorbitol 30gam : uống hoặc thụt giữ.
Calciclorua 0,5-1gam tiêm TM chậm , thời gian tác dụng 30-60 phút.
Glucose 20%, 30% có insuline: truyền tĩnh mạch, tác dụng trong vài giờ.
Natribicarbonate 1,4% hoặc 4,2%.
Toan chuyển hoá: khi pH < 7,20 truyền NaHCO34,2% hoặc 1,4% 250500ml. 
Kiểm soát natri máu: hạ natri máu dễ đi kèm thừa thể tích.
Kiểm soát canxi, photpho máu: giảm canxi máu gặp suy thận cấp do tiêu cơ vân cấp, tăng photpho máu trong các hội chứng tiêu huỷ khối u.
**Lợi tiểu**
_Furosemide_ có thể chuyển suy thận cấp thể vô niệu thành thể còn nước tiểu: làm giảm sự tái hấp thu chủ động natri, làm tăng dòng chảy tới ống thận.
Giúp trì hoãn lọc máu, không làm giảm tiên lượng nặng và tỉ lệ tử vong.
Cách sử dụng: 10 ống (200mg) tiêm tĩnh mạch 3 lần cách nhau 1giờ hoặc truyền tĩnh mạch duy trì 40 mg/giờ.
Liều 600mg-1000mg/24giờ không đáp ứng phải xét chỉ định lọc máu.
_Manitol_ _:_ là một lợi niệu thẩm thấu, chỉ dùng khi có tiêu cơ vân cấp.
Suy thận cấp do tiêu cơ vân, hội chứng vùi lấp, có tác dụng đề phòng phù nề, sưng và tắc ống thận cấp.
Thuốc được dùng cùng dung dịch bicarbonate và đảm bảo truyền dịch đủ với ALTMTT 8-12 mmHg.
**Chống nhiễm khuẩn**
Điều chỉnh liều kháng sinh theo độ thanh thải creatinin, tránh thuốc độc tính với thận.
Phát hiện và kiểm soát ổ nhiễm khuẩn sớm, tránh suy thận cấp nặng lên do nhiễm khuẩn không kiểm soát được. Cấy tìm vi khuẩn, làm kháng sinh đồ.
_Xử trí nguyên nhân:_ chẩn đoán nguyên nhân và phối hợp giải quyết chuyên khoa.
**NHIỄM KHUẨN NẶNG VÀ/HOẶC SỐC NHIỄM KHUẨN: XEM BÀI SỐC NHIỄM KHUẨN.**
Hội chứng gan thận cấp (xem bài hội chứng gan thận cấp).
Bệnh lý cầu thận cấp tự miễn dịch và nhiễm trùng: hội chứng thận hư, viêm cầu thận cấp, lupus ban đỏ hệ thống, bệnh lý mạch máu.
Các bệnh lý do tắc nghẽn sau thận: hội chẩn chuyên khoa, can thiệp khi cần.xU xơ tiền liệt tuyến.
Sỏi hệ thống thận tiết niệu.
Các khối u, máu cục …gây tắc nghẽn, gây chèn ép.
**Chỉ định của các biện pháp lọc máu**
_Lọc máu sớm khi có 1 dấu hiệu, chỉ định bắt buộc khi có 2 dấu hiệu_
Không đáp ứng với lợi tiểu furosemide (liều như trên).
Urê máu > 30mmol/l.
Kali máu > 6 mmol/l, tăng nhanh, có rối loạn nhịp trên điện tâm đồ.
Tăng gánh thể tích, phù to, ALTMTT tăng, phù phổi cấp huyết động.
Toan chuyển hoá pH máu < 7,20.
Na+ máu >160 mmol/l hoặc < 115 mmol/l.
_Thẩm phân phúc mạc._
Chỉ định lọc máu nhưng cơ sở y tế không có máy lọc máu cấp, hoặc không lấy được đường vào mạch máu để lọc máu.
Kỹ thuật: 1h/1 lần/1-3 lít dịch thẩm phân qua ống thônglọc màng bụng, lọc liên tục 18-24h/ngày tùy theo xét nghiệm. Sử dụng dịch lọc màng bụng sẵn có.
Lọc máu ngắt quãngxCấp cứu cho các người bệnh nặng có thể kéo dài 4-5-6 giờ/1 lần lọc, tốc độ máu chậm, tốc độ siêu lọc chậm, có thể không sử dụng thuốc chống đông.
Tần xuất lọc hàng ngày hoặc cách ngày, thận trọng khi có huyết áp tụt.
Nên sửdụng dung dịch lọc có dịch đệm bicarbonate, màng lọc có độ tương hợp sinh học cao.
_Lọc máu liên tục CVVH_
Ưu điểm: Loại bỏ các chất hoà tan có phân tử lượng nhỏ, trung bình (dưới 40.000 dalton) cùng với nước theo nguyên lý đối lưu, không phụ thuộc nồng độ. Hiệu quả, dung nạp tốt khi có kèm sốc, suy tim, suy đa tạng.
Kỹ thuật: lọc máu liên tục trong 18- 24 giờ mỗi ngày, máu từ cơ thể ra, được lọc qua 1 màng lọc có hệ số siêu lọc cao, kích thước lỗ màng lớn.
**Dinh dưỡng**
_Cung cấp năng lượng 30-35kcal/kg/ngày với suy thận cấp không có biến chứng._
Người bệnh có nhiễm khuẩn, suy đa tạng, tổng năng lượng tăng tới 130%.
Suy thận cấp không biến chứng: axít amin 0,65-1gam/kg/ngày, có lọc máu ngắt quãng, tăng dị hóa cung cấp axít amin 1,2-1,5gam/kg/ngày, lọc máu liên tục nhu cầu axít amin tới 2,5gam/kg/ngày.
Tổng lượng nước qua mọi đường cần tính theo cân bằng dịch vào-ra.
Giai đoạn vô niệu, thiểu niệu, hạn chế nước, các chế phẩm, thức ăn giàu kali.
_Các quan điểm mới về chế độ dinh dưỡng:_
Tỷ lệ carbonhydrat trong khẩu phần ăn chiếm 50-80%. Cung cấp thêm lipít, đặc biệt các axít béo thiết yếu, axít béo không no.
Bệnh nặng: ăn qua ống thông dạ dày, đề phòng nhiễm khuẩn tiêu hoá.
**Bảo tồn chức năng các cơ quan khác**
Điều trị dự phòng xuất huyết tiêu hoá thuốc kháng a xít hoặc ức chế bơm proton.
Các biến chứng tim và phổi có liên quan tới suy thận cấp: rối loạn nhịp, phù phổi, nhiễm trùng phổi, tăng huyết áp, chảy máu phổi (viêm cầu thận cấp tiến triển).
Rối loạn đông máu: giảm tiểu cầu, DIC, giảm fibrinogen.
Thiếu máu, tan máu, giảm erythropoietin có thể xuất hiện trong giai đoạn đầu.
Biến chứng thần kinh-cơ: giai đoạn sớm có thể có thất điều, ngủ gà, đờ đẫn, kích thích hoặc hôn mê, chú ý các nguyên nhân như rối loạn điện giải, tăng ure máu.
**TIÊN LƯỢNG VÀ BIẾN CHỨNG**
Các yếu tố góp phần tiên lượng không tốt của suy thận cấp:
Tuổi cao, bệnh mạn tính đi kèm: đái đường, suy gan mãn, cao huyết áp…
Suy thận cấp trong bệnh cảnh nhiễm khuẩn, suy đa tạng, chấn thương, hội chứng vùi lấp, sau mổ, creatinin máu > 3mg/dl.
Người bệnh có nhiều yếu tố nguy cơ: hoá chất, tiêu cơ vân, thuốc cản quang, hạ huyết áp do mọi nguyên nhân, điều trị thuốc độc với thận.
Suy thận cấp tại thận hay suy thận cấp chức năng điều trị muộn đều có thể dẫn đến tử vong do các biến chứng cấp tính, chú ý đặc biệt ở giai đoạn vô niệu (tăng K+máu, toan hóa nặng, phù phổi huyết động).
**PHÒNG BỆNH**
Chẩn đoán sớm, phát hiện các yếu tố nguy cơ và dự phòng cũng như điều trị sớm và đúng nguyên nhân gây ra suy thận cấp.
Người bệnh cần được giáo dục và có kiến thức về các bệnh lý mạn tính có nguy cơ cao ảnh hưởng tới chức năng thận như bệnh đái tháo đường, cao huyết áp, suy tim mạn, u xơ tiền liệt tuyến, từ đó giúp phòng ngừa suy thận cho bản thân.
Biết các thuốc độc với thận cũng như cơ chế gây suy thận của nó.
Dự phòng suy thận cấp ở người bệnh phẫu thuật:
Yếu tố nguy cơ: lớn tuổi, có bệnh thận từ trước, có bệnh gan mãn, suy tim + Phòng suy thận cấp: phải bù đủ dịch, đảm bảo huyết áp trong phẫu thuật.
Phòng tránh nguy cơ suy thận cấp do các thuốc cản quang: xét nghiệm creatinin máu trước chụp, hội chẩn với bác sĩ chuyên khoa chẩn đoán hình ảnh.
Truyền NaCl 0,9% 1ml/kg/h bắt đầu 8 tiếng trước chụp cản quang, Nacetylcystein 600mg x 2 lần/ngày, vào ngày trước và sau dùng thuốc cản quang.
Chọn thuốc cản quang nhóm ít nguy cơ gây suy thận: iodixanol (Visipaque)
Phòng STC do tiêu huỷ khối u (lympho cấp, ưng thư bạch cầu cấp sau điều trị hoá chất).
Allopurinol 300-600mg/trước ngày dùng hoá chất + Truyền NaCl 0,9% 5000 ml/24h. 
Kiềm hoá nước tiểu: truyền NaHCO3100 mEq/m2/ngày, giữ pH nước tiểu >7,00;
Tiêm tĩnh mạch acetazolamide 1gam/m2 cùng với NaHCO3.
Phòng suy thận cấp ở người bệnh có tiêu cơ vân cấp.
**TÀI LIỆU THAM KHẢO**
Nguyễn Đạt Anh, Đặng Quốc Tuấn. (2012); Tổn thương thận cấp;“ Hồi sức cấp cứu: tiếp cận theo phác đồ”. (Bản tiếng Việt của The Washington manual of critical care). Nhà xuất bản khoa học kĩ thuật. Trang 557- 582.
Vũ Văn Đính. (2004); Suy thận cấp; Hồi sức cấp cứu toàn tập; Nhà xuất bản y học; Trang 263-277.
Ronco C., Ricci Z., Bellomo R., D’intini V. (2013), “Renal replacement therapy”,  _Textbook of critical care_. sixth edition. jean- louis Vincent. elsevier sauders. chapter 115, Pp. 894-901.
Elhassan E.A., Schrier R.W. (2013), “Acute kidney injury”,  _textbook of critical care_. sixth edition. jean- louis Vincent, elsevier sauders. chapter 114, Pp. 883-93.
Kellum J.A. and work group membership. (2012), “Kdigo clinical practice guideline for acute kidney injury” vol 2-| supplements 2-| march.
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh

## ️ Bệnh thận đa nang

**ĐẠI CƯƠNG**
Bệnh được đặc trưng bởi xuất hiện nhiều nang ở cả hai thận. Bệnh thận đa nang là bệnh di truyền phần lớn theo gen trội, chỉ có một tỉ lệ nhỏ theo gen lặn. Gen bệnh lý nằm ở đầu xa, nhánh ngắn của nhiễm sắc thể thứ 16. Có khoảng 10-15% bệnh nhân, rối loạn gen nằm ở nhiễm sắc thể thứ 4. Có thể còn một gen thứ 3 chưa được xác định, di truyền tính trội. 
Bệnh thận nang có thể kết hợp với nang gan và các bất thường tim mạch. Bệnh thường dẫn tới suy thận giai đoạn cuối.
Sự phát sinh và phát triển nang thận phụ thuộc vào gen, môi trường. Nhiều chất hóa học hoặc thuốc có thể gây ra nang thận, bao gồm các chất chống oxy hóa (như diphenyl-thiazole và nordihydro guaiaretic acid), alloxan và steptozotoxin, lithium cloride và cis-platinium. 
Có ba cơ chế chính hình thành nang thận:
+ Tắc nghẽn trong l ng ống thận.
+ Tăng sinh tế bào biểu mô ống thận.
+ Biến đổi màng đáy của ống thận.
**TRIỆU CHỨNG**
**Triệu chứng**
Ban đầu thường không có triệu chứng, bệnh nhân phát hiện được bệnh thường do khám sức khỏe thường kỳ, hoặc siêu âm ổ bụng vì các lý do ngoài thận. Bệnh thường được phát hiện ở tuổi trung niên.
Đau bụng hoặc đau hông lưng: khoảng 20-30% số bệnh nhân, thường tăng lên theo tuổi và kích cỡ của nang. Nếu đau cấp tính, có thể là do chảy máu trong nang, nhiễm khuẩn nang, tắc nghẽn đường tiết niệu do cục máu, sỏi. 
Đau dưới hạ sườn phải có thể gặp do nang gan phối hợp.
**Xét nghiệm**
Siêu âm là xét nghiệm đơn giản và dễ thực hiện đê chẩn đoán xác định, theo dõi đánh giá tình trạng nang thận và các biến chứng.
XQ hệ tiết niệu, chup CT đánh giá các tổn thương, biến chứng của bệnh đa nang
Xét nghiệm sinh hóa máu, nước tiểu xác định các biến chứng suy thận, nhiễm trùng, tiểu máu.
**Các biểu hiện ngoài thận**
Biểu hiện bệnh ở gan: Có khoảng 50% bệnh nhân bị bệnh thận đa nang có nang ở gan. 
Phình mạch trong sọ: Chụp động mạch não phát hiện khoảng 10-30% bệnh nhân có phình mạch trong sọ. Tỉ lệ gặp chảy máu trong sọ gặp khoảng 2% số bệnh nhân, do vỡ phình mạch. 
Bất thường van tim: Có thể thấy bất thường ở một hoặc nhiều hơn các van tim ở 18% bệnh nhân. Van tim thấy thoái hóa tổ chức cơ, mạch máu, và collagen. Sa van hai lá, rối loạn nhịp tim, viêm màng trong tim nhiễm khuẩn, huyết khối nhĩ trái.
Biểu hiện bệnh ở các cơ quan khác: Nang có thể thấy ở tụy và lách, tỉ lệ gặp là 10% và 5%. Đôi khi c n phát hiện nang ở thực quản, ở niệu quản, ở buồng trứng, ở não.
**Biến chứng**
Chảy máu trong nang gây tiểu máu đại thể gặp 15-20% số bệnh nhân. Tiểu máu đại thể thường xảy ra sau các chấn thương. Chảy máu quanh thận hiếm khi xảy ra, nếu có thường do chấn thương làm vỡ nang.
Nhiễm khuẩn: đây là lý do chionhs khiến bệnh nhân phải nhập viện. Vi khuẩn tới thận theo đường ngược d ng. Nếu nhiễm khuẩn nang, làm nang to lên và đau. Khám có thận to, ấn đau. 
Sỏi thận: tỉ lệ gặp sỏi thận 11-34% số bệnh nhân thận đa nang. Chú ý những trường hợp sỏi nhỏ trong thận thường khó chẩn đoán được và bị bỏ qua. 
Ung thư thận: Gần 50% số ca ung thư thận xảy ra ở bệnh nhân bị bệnh thận đa nang. Chủ yếu là ung thư tế bào thận, một số ít ung thư nhú thận. Chẩn đoán được ung thư thận dựa vào các triệu chứng: hồng cầu niệu, đau thắt lưng, thận to, chảy máu trong nang. Chụp CTscan, MRI, sinh thiết và xét nghiệm giải phẫu bệnh giúp cho chẩn đoán xác định.
Tăng huyết áp: Tăng huyết áp có thể xảy ra sớm, gặp với tỉ lệ 13-20% số bệnh nhân ngay cả khi chưa có suy thận.
Suy thận: Tiến triển đến suy thận là biến chứng thường gặp nhất ở bệnh nhân bị bênh thận đa nang. 
Giảm khả năng cô đặc nước tiểu: xảy ra sớm, mức độ giảm khả năng cô đặc nước tiểu phụ thuộc vào thể tích nang và số lượng nang. Nồng độ natri máu thường giảm nhẹ.
Thiếu máu hay gặp ở bệnh nhân suy thận giai đoạn nặng. Tuy nhiên mức độ ít trầm trọng hơn so với bệnh nhân suy thận giai đoạn cuối do các nguyên nhân khác. 
Tăng acid uric máu do rối loạn tái hấp thu và bài tiết acid uric của ống thận.
**Chẩn đoán xác định**
Chẩn đoán bệnh thận đa nang dựa vào:
Tiền sử gia đình 
Siêu âm thấy hai thận to, có nhiều nang kích cỡ khác nhau ở cả vùng vỏ và vùng tủy thận. 
Có nang ở gan.
Chụp cắt lớp thận CTscan 
Kỹ thuật gen xác định bất thường ở đầu xa nhánh ngắn của nhiễm sắc thể 16.
**Điều trị**
Nguyên tắc chung là điều trị triệu chứng và biến chứng.
Nhiễm khuẩn thận điều trị bằng kháng sinh phù hợp
Tăng huyết áp điều trị bằng các nhóm thuốc hạ áp
Cắt thận nếu nang thận quá to, biến chứng tiểu máu, nhiễm trùng tái phát
Suy thận, điều trị bảo tồn và thay thế khi suy thận giai đoạn cuối bằng lọc máu và ghép thận. 
Với những trường hợp nang không quá lớn: có thể lọc màng bụng,…
**TÀI LIỆU THAM KHẢO**
Hateboer N, van Dijk MA, Bogdanova N et al, 1999. “Comparison of phenotypes of polycystic kidney disease types 1 and 2” ,  _Lancet,_ 353, pp.103107 
E Higashihara, K Nutahara and M Kojima et al, 1998. “Prevalence and renal prognosis of diagnosed autosomal dominant polycystic kidney disease in Japan”,  _Nephron_ 80, pp. 421–427 
Amaout MA, 2011. “Cystic kidney diseases”,  _Cecil Medicine_. 24th ed. Philadelphia, Saunders Elsevier; chap 128.
Porter CC, Avner Ed, 2011. “Anatomic abnormalities associated with hematuria”,  _Nelson Textbook of Pediatrics._ 19th ed. Philadelphia, Saunders Elsevier, chap 515.
Torres VE, Grantham JJ, 2007. “Cystic diseases of the kidney”,  _Brenner and Rector's the Kidney_. 8th ed. Philadelphia, Saunders Elsevier, chap 41.
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh

## ️ Giới thiệu khoa Thận - Lọc máu Bệnh viện Nguyễn Tri Phương

  * [I. Thông tin lãnh đạo khoa Thận- Lọc máu](https://bvnguyentriphuong.com.vn/than-loc-mau/gioi-thieu-khoa-than-loc-mau-benh-vien-nguyen-tri-phuong#i-thng-tin-lnh-o-khoa-thn-lc-mu)
  * [1. Phó trưởng khoa – Phụ trách điều hành:](https://bvnguyentriphuong.com.vn/than-loc-mau/gioi-thieu-khoa-than-loc-mau-benh-vien-nguyen-tri-phuong#1-ph-trng-khoa-ph-trch-iu-hnh)
  * [2. Phó trưởng khoa:](https://bvnguyentriphuong.com.vn/than-loc-mau/gioi-thieu-khoa-than-loc-mau-benh-vien-nguyen-tri-phuong#2-ph-trng-khoa)
  * [3. Phó trưởng khoa:](https://bvnguyentriphuong.com.vn/than-loc-mau/gioi-thieu-khoa-than-loc-mau-benh-vien-nguyen-tri-phuong#3-ph-trng-khoa)
  * [II. Thông tin giới thiệu về khoa](https://bvnguyentriphuong.com.vn/than-loc-mau/gioi-thieu-khoa-than-loc-mau-benh-vien-nguyen-tri-phuong#ii-thng-tin-gii-thiu-v-khoa)
  * [Quá trình hình thành](https://bvnguyentriphuong.com.vn/than-loc-mau/gioi-thieu-khoa-than-loc-mau-benh-vien-nguyen-tri-phuong#qu-trnh-hnh-thnh)


## **I. Thông tin lãnh đạo khoa Thận- Lọc máu**
### **1. Phó trưởng khoa – Phụ trách điều hành:**
Họ tên:**VŨ THỊ MINH HOA**
Năm tốt nghiệp BS: 2002
Năm cấp bằngThS: 2013. Chuyên ngành: Nội khoa.
Số năm làm việc ở BV : Hơn 10 năm.
Nghiên cứu khoa học tâm đắc hoặc thành tích nổi bật (trong chuyên môn, trong nghiên cứu…) mà bản thân muốn được nhắc đến: “ Khảo sát sự suy giảm chức năng thận tồn lưu qua lượng nước tiểu trên bệnh nhân chạy thận nhân tạo định kì”
### **2. Phó trưởng khoa:**
Họ tên: **LÊ THỊ THU THẢO**
Năm tốt nghiệp BS: 2012
Năm cấp bằng ThS: 2016. Chuyên ngành: Nội khoa.
Số năm làm việc ở BV : Gần 05 năm.
Nghiên cứu khoa học: “Khảo sát bệnh động mạch ngoại biên chi dưới ở bệnh nhân tăng huyết áp có hút thuốc lá”.
### **3. Phó trưởng khoa:**
Họ tên: **NGUYỄN HỮU PHÚC**
Năm tốt nghiệp BS: 2011
Năm cấp bằng ThS/CK1: 2019. Chuyên khoa: Nội Tổng Quát
Số năm làm việc ở BV: gần 10 năm
**4. Điều dưỡng trưởng:**
Họ tên:**TRẦN THỊ HỒNG**
Năm tốt nghiệp trình độ cử nhân: 2013
Năm cấp bằng sau đại học: 2016 Trình độ: Điều Dưỡng chuyên khoa I
Số năm làm việc ở BV : gần 20 năm
## **II. Thông tin giới thiệu về khoa**
Điểm mạnh về nhân lực:Với sự hướng dẫn chuyên sâu về chuyên môn của PGS.TS.BS Phạm Văn Bùi, Hội trưởng hội Lọc máu TP.HCM; khoa luôn có sự hợp tác với nước ngoài có nền y học phát triển như Nhật, Pháp, Mỹ… Đội ngũ Bác sĩ trong khoa luôn được cập nhật kiến thức liên tục, và được giao lưu học hỏi với các nước bạn. Khoa hiện có 5 Thạc sĩ, 2 chuyên khoa cấp I…
Điểm mạnh về chuyên môn: 
  * Khu chạy thận nhân tạo thường, khu chạy thận nhân tọa kỹ thuật cao T.U.C hợp tác với Nhật Bản và đạt tiêu chuẩn Nhật Bản; hiện có 10 máy chạy thận.
  * Khu chạy thận nhân tạo theo tiêu chuẩn Nhật Bản NTP-Nipro hợp tác với công ty Nipro Nhật Bản với hệ thống máy chạy thận hiện đại và hệ thống lọc nước RO thế hệ mới đạt chất lượng theo tiêu chuẩn Nhật Bản; hiện có 20 máy
  * Tham gia các nghiên cứu khoa học đa quốc gia về thận học.
  * Trung tâm đào tạo cấp chứng chỉ và chứng nhận đào tạo liên tục trong lãnh vực Thận học- Lọc máu. 


Điểm mạnh về trang thiết bị: Khoa có 10 máy chạy thận nhân tạo thế hệ mới, có mang lọc nội độc tố sau mỗi máy đạt tiêu chuẩn Nhật Bản; 20 máy chạy thận hợp tác Công ty Nipro Nhật Bản, hệ thống RO thế hệ mới siêu tinh khiết đạt chất lượng nước siêu sạch theo tiêu chuẩn Nhật Bản.
## **_Quá trình hình thành_**
**_Giai đoạn 2010-2016:_** Với sự dẫn dắt và lãnh đạo của PGS.TS.BS Phạm Văn Bùi, đơn vị Lọc máu được hình thành với 17 máy Chạy thận khu thường, và đến tháng 7/2016 có thêm 9 máy mới nâng tổng số máy chạy thận khu thường thành 26 máy.
**_Giai đoạn 2016-2019:_**
**_Giai đoạn 2019 đến nay:_** Với sự phát triển ngày càng lớn mạnh của khoa , tháng 7/2019 với quyết định và cho phép của Sở y tế TP HCM nhập 2 khoa: Khoa Nội Thận và khoa Lọc máu thành Khoa Thận-Lọc máu, làm cho khoa ngày càng phát triển. Nhu cầu chạy thận của bệnh nhân trên địa bàn ngày càng nhiều,khoa làm việc thường xuyên quá tải, máy chạy thận phải vận hành hết công suất cũng không thể đáp ứng hết được nhu cầu và phải thường xuyên chuyển viện cho bệnh nhân đến các trung tâm chạy thận lân cận. Trước tính hình đó. ngày 20/01/2021 khoa Thận Lọc máu đưa vào hoạt động khu Chạy thận nhân tạo theo tiêu chuẩn Nhật Bản NTP-Nipro.
Những định hướng phát triển trong thời gian tới muốn nhấn mạnh:
  * Công tác điều trị của khoa đã tạo được sự yên tâm, tin tưởng của Người bệnh. Khoa đã triển khai và thực hiện tốt 52 quy trình thận nhân tạo do Bộ Y Tế ban hành.
  * Mở lớp đào tạo CME về Thận-Lọc máu cho Điều dưỡng, Bác sĩ trong và ngoài thanh phố.
  * Hợp tác quốc tế trong đào tạo CME ngắn hạn.
  * Khoa nhận bàn giao từ Bệnh viện và phòng VTTTB khu Lọc máu tiêu chuẩn Nhật Bản NTP-NIPRO từ ngày 12/01/2021, đây là khu Chạy thận nhân tạo hợp tác giữa Bệnh viện và Công ty Nipro, đạt tiêu chuẩn chất lượng nước cảu Nhật Bản.


Hướng phát triển: Khoa tiếp tục cải tiến chất lượng một số nội dung: 
  * Hoàn thiện phòng thẩm phân phúc mạc
  * Phòng chuyên về huấn luyện thẩm phân phúc mạc cho Người bệnh
  * Cập nhật mới một số quy trình kỹ thuật về thận nhân tạo
  * Tiếp tục mở lớp đào tạo CME về Thận-Lọc máu cho Điều dưỡng, Bác sĩ trong và ngoài thành phố. 
  * Cử Bác sĩ – Điều Dưỡng học chăm sóc ghép thận tại bệnh viện Trung Ương Huế
  * Tiếp tục hợp tác quốc tế trong đào tạo CME ngắn hạn
  * Nghiên cứu khoa học
  * Đưa vào hoạt động và phát triển khu Chạy thận nhân tạo tiêu chuẩn Nhật Bản NTP-NIPRO.


**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [I. Thông tin lãnh đạo khoa Thận- Lọc máu](https://bvnguyentriphuong.com.vn/than-loc-mau/gioi-thieu-khoa-than-loc-mau-benh-vien-nguyen-tri-phuong#i-thng-tin-lnh-o-khoa-thn-lc-mu)
  * [1. Phó trưởng khoa – Phụ trách điều hành:](https://bvnguyentriphuong.com.vn/than-loc-mau/gioi-thieu-khoa-than-loc-mau-benh-vien-nguyen-tri-phuong#1-ph-trng-khoa-ph-trch-iu-hnh)
  * [2. Phó trưởng khoa:](https://bvnguyentriphuong.com.vn/than-loc-mau/gioi-thieu-khoa-than-loc-mau-benh-vien-nguyen-tri-phuong#2-ph-trng-khoa)
  * [3. Phó trưởng khoa:](https://bvnguyentriphuong.com.vn/than-loc-mau/gioi-thieu-khoa-than-loc-mau-benh-vien-nguyen-tri-phuong#3-ph-trng-khoa)
  * [II. Thông tin giới thiệu về khoa](https://bvnguyentriphuong.com.vn/than-loc-mau/gioi-thieu-khoa-than-loc-mau-benh-vien-nguyen-tri-phuong#ii-thng-tin-gii-thiu-v-khoa)
  * [Quá trình hình thành](https://bvnguyentriphuong.com.vn/than-loc-mau/gioi-thieu-khoa-than-loc-mau-benh-vien-nguyen-tri-phuong#qu-trnh-hnh-thnh)



## Cơ chế hình thành sỏi thận – tiết niệu ?

  * [1, Các thuyết giải thích quá trình tạo sỏi?](https://bvnguyentriphuong.com.vn/than-loc-mau/co-che-hinh-thanh-soi-than-tiet-nieu#1-cc-thuyt-gii-thch-qu-trnh-to-si)
  * [2, Cơ chế hình thành các tinh thể trong nước tiểu ?](https://bvnguyentriphuong.com.vn/than-loc-mau/co-che-hinh-thanh-soi-than-tiet-nieu#2-c-ch-hnh-thnh-cc-tinh-th-trong-nc-tiu-)
  * [3, Lý thuyết tổng hợp các yếu tố tạo sỏi](https://bvnguyentriphuong.com.vn/than-loc-mau/co-che-hinh-thanh-soi-than-tiet-nieu#3-l-thuyt-tng-hp-cc-yu-t-to-si)


Sỏi niệu hay bệnh sỏi thận - đường tiết niệu đã nổi lên như một mối quan tâm nghiêm trọng về sức khỏe trên toàn Thế giới. Với tỷ lệ tái phát cao ở cả nam và nữ cũng như ảnh hưởng đến khoảng 12% dân số trên toàn cầu, sỏi thận hoặc sỏi niệu (sỏi thận) được đánh dấu bằng sự hình thành các cục sỏi trong đường tiết niệu Nguyên nhân chính của bệnh sỏi thận là sự siêu bão hòa của nước tiểu với canxi và oxalat dẫn đến sự khoáng hóa bệnh lý ở thận. Canxi oxalat chiếm tỷ lệ tối đa của sỏi thận (khoảng 75%) trong khi canxi hydroxyl photphat (brushite hoặc canxi hydroxyapatit) magie amoni photphat (struvite hoặc photphat ba), urat và cystine chiếm khoảng 50%, (10-20)%, 5% và (1-2)% sỏi thận tương ứng.
## **1, Các thuyết giải thích quá trình tạo sỏi?**
Có hai thuyết chính được đưa ra để giải thích quá trình hình thành nhân sỏi, đó là thuyết “hạt tự do” (free partical) và thuyết “hạt cố định” (fixed partical). Thuyết “hạt tự do” giải thích quá trình sỏi hình thành ở ngoài tế bào (trong lòng ống thận). Thuyết “hạt cố định” giải thích khởi đầu tạo sỏi từ nhu mô thận (trong tế bào hoặc mô kẽ thận). Cả hai thuyết đều chấp nhận, khởi đầu của quá trình tạo sỏi là hiện tượng sinh hóa liên quan đến việc tạo thành các tinh thể của các muối trong nước tiểu, trong những điều kiện thích hợp. Mỗi thuyết nhấn mạnh đến vị trí và cơ chế khởi đầu của quá trình tạo sỏi.
Thuyết “hạt tự do” cho rằng do hiện tượng tăng bài tiết các chất hòa tan vào nước tiểu tới mức bão hòa, làm chúng kết tinh thành các tinh thể. Các tinh thể hình thành trong đường tiết niệu kết dính với nhau để tạo thành nhân, và to dần lên do sự kết dính tiếp tục các tinh thể để trở thành các hạt lớn hơn. Các sạn sỏi này trôi theo dòng nước tiểu và bị “bẫy” lại ở các vị trí hẹp của đường tiết niệu. Tại các vị trí này, chúng tiếp tục lớn lên để tạo thành sỏi. Lý thuyết này dựa trên cơ sở đi kèm với sỏi có tăng nồng độ các ion, các muối, hoặc các acid trong nước tiểu, các chất này có cùng thành phần với sỏi. Sự tăng quá mức các thành phần trong nước tiểu cho thấy có nguy cơ tạo sỏi.
Thuyết “hạt cố định” cho rằng, khởi đầu là sự lắng đọng các muối ở trong mô kẽ thận hoặc trong tế bào ống thận. Các tế bào và các mô vùng này bị phá hủy làm bộc lộ các tinh thể ra đường tiết niệu và chúng trở thành nhân gắn với một vị trí ở ống thận hoặc mô thận. Các nhân này lớn dần lên do sự kết dính tiếp tục các tinh thể, rồi sau đó bong ra đường tiết niệu. Các sạn sỏi này bị bẫy lại ở các vị trí hẹp của đường tiết niệu và tiếp tục lớn để trở thành sỏi. Lý thuyết này có cơ sở là người ta phát hiện thấy có các “hạt” ở trong tế bào ống thận và thực tế có hiện tượng lắng đọng các muối trong mô kẽ thận hoặc ở nhú thận.
## **2, Cơ chế hình thành các tinh thể trong nước tiểu ?**
Các tinh thể hình thành trong nước tiểu có liên quan với tình trạng bão hòa các chất hòa tan trong nước tiểu, và nồng độ các chất hoạt hóa hoặc ức chế quá trình kết tinh.
+ Tăng nồng độ các chất hoạt hóa quá trình kết tinh để tạo thành các tinh thể: sự có mặt của một số chất, có tác dụng làm tăng hiện tượng ngưng kết các chất khoáng và hình thành các nhân, được gọi là các chất hoạt hóa hay kích hoạt quá trình kết tinh.
+ Giảm bài tiết các chất ức chế tạo tinh thể: trái với thuyết hoạt hóa, lý thuyết này giải thích các tinh thể được hình thành do thiếu các chất ức chế sự kết tinh các tinh thể.
## **3, Lý thuyết tổng hợp các yếu tố tạo sỏi**
Các tác giả theo lý thuyết này đã kết hợp các yếu tố có vai trò hình thành sỏi để giải thích quá trình tạo sỏi như: tình trạng bão hòa các chất hòa tan trong nước tiểu, tăng nồng độ các chất hoạt hóa và/hoặc giảm nồng độ các chất ức chế kết tinh để tạo thành các tinh thể trong nước tiểu, thể tích nước tiểu giảm, pH nước tiểu kiềm hoặc acid. Các yếu tố trên được coi là các yếu tố nguy cơ tạo sỏi.
  * [1, Các thuyết giải thích quá trình tạo sỏi?](https://bvnguyentriphuong.com.vn/than-loc-mau/co-che-hinh-thanh-soi-than-tiet-nieu#1-cc-thuyt-gii-thch-qu-trnh-to-si)
  * [2, Cơ chế hình thành các tinh thể trong nước tiểu ?](https://bvnguyentriphuong.com.vn/than-loc-mau/co-che-hinh-thanh-soi-than-tiet-nieu#2-c-ch-hnh-thnh-cc-tinh-th-trong-nc-tiu-)
  * [3, Lý thuyết tổng hợp các yếu tố tạo sỏi](https://bvnguyentriphuong.com.vn/than-loc-mau/co-che-hinh-thanh-soi-than-tiet-nieu#3-l-thuyt-tng-hp-cc-yu-t-to-si)



## ️ Bệnh thận mạn giai đoạn cuối

**ĐẠI CƯƠNG VÀ ĐỊNH NGHĨA BỆNH THẬN MẠN GIAI ĐỌAN CUỐI**
**Các định nghĩa**
**Bệnh thận mạn giai đoạn cuối (end stage renal disease, ESRD**) là bênh thận mạn giai đoạn 5. Đây là giai đọan nặng nhất của bệnh thận mạn (BTM) với mức lọc cầu thận (GFR) < 15mL/ph/1,73 m2, biểu hiện bằng hội chứng urê máu, và tình trạng này sẽ gây tử vong nếu không được điều trị thay thế thận.
**Hội chứng urê máu (uremic syndrome)** là một hội chứng lâm sàng và cận lâm sàng, gây ra không chỉ do sự gia tăng của urê huyết thanh, mà c n tăng hơn 100 sản phẩm có nguồn gốc nitơ khác trong máu như peptide, aminoacid, creatinin, …khi người bệnh bị suy thận (cấp hoặc mạn). Thuật ngữ chính xác hơn là “hội chứng tăng azote máu”. Do không phải chất nào cũng đo đạt được, nên cho đến nay, urê và créatinine tăng đồng nghĩa với sự tăng các sản phẫm azote khác.
**Tăng azote máu (azotemia)** là sự gia tăng nồng độ các sản phẩm có nguồn gốc nitơ trong máu như protein, peptide, aminoacid, creatinin, urê, uric acid, ammoniac, hippurates, sản phẩm thoái hóa của acid nhân, polyamine, myoinositol, phenols, benzoates, và indoles.
Dịch tể học của bệnh thận mạn giai đọan cuối
Tần suất bệnh thận mạn (BTM) trong cộng đồng theo nghiên cứu NHANES III (Third National Health and Nutrition Examination Survey) tiến hành trên 15.625 người trưởng thành trên 20 tuổi, công bố năm 2007 là 13%. Cứ mỗi người bệnh BTM giai đoạn cuối đến điều trị thay thế thận, tương ứng với ngoài cộng đồng có khoảng 100 người đang bị bệnh thận ở những giai đoạn khác nhau.
**NGUYÊN NHÂN**
Ba nhóm nguyên nhân hằng đầu gây BTM giai đoạn cuối trên thế giới là (1) đái tháo đường, (2) tăng huyết áp, (3) bệnh cầu thận. Nếu tại các nước đã phát triển, đái tháo đường vẫn chiếm ưu thế trong khi tại các nước đang phát triển, nguyên nhân hằng đầu vẫn là bệnh cầu thận (30-48%). 
**TRIỆU CHỨNG LÂM SÀNG VÀ CẬN LÂM SÀNG:**
Rối loạn gây ra do sự tích tụ các chất thải, và độc chất trong cơ thể, quan trọng nhất là sản phẩm biến dưỡng của protein.
Rối loạn là hậu quả của sự mất dần các chức năng khác của thận như điều h a thăng bằng nội môi, nước điện giải, nội tíết tố
Rối lọan là hậu quả của phản ứng viêm tiến triển gây ra ảnh hưởng lên mạch máu và dinh dưỡng.
**+ Rối loạn chuyển hóa natri**
Có thể tăng hoặc giảm natri máu
**+ Rối loạn bài tiết nước**
Tiểu đêm là triệu chứng của tình trạng thải nước tiểu và sodium với mức độ thẩm thấu cố định. Người bệnh  _dễ bị thiếu nước và muối_ , nếu tiết chế quá mức, và dễ giảm natri huyết thanh, nếu uống quá nhiều nước. 
**+Rối loạn chuyển hóa kali**
Người bệnh suy thận mạn, thận tăng tiết aldosteron làm tăng thải kali tại ống thận xa, và tăng thải kali qua đường tiêu hóa. Do vậy, kali máu chỉ tăng ở BTM giai đoạn cuối cần tìm nguyên nhân khác nếu tăng kali xuất hiện trước giai đọan cuối
Giảm kali ít gặp hơn ở người bệnh BTM, chủ yếu do tiết chế nguồn nhập kali, kèm với việc dùng lợi tiểu quá liều, hoặc do tăng mất kali qua đường tiêu hóa.
**+ Toan chuyển hóa**
Suy thận mạn: lượng acid bài tiết bị khống chế trong khoảng hẹp từ 30-40 mmol/ngày, nên dễ bị toan chuyển hóa. 
**+ Rối loạn chuyển hoá calcium và phosphor**
Suy thận mạn: thận giảm bài tiết phospho và calci, gây tăng phospho trong máu. Để duy trì tích số phospho và calci ổn định trong máu, calci máu giảm khi phospho tăng, kích thích tuyến cận giáp tiết PTH, làm tăng huy động calci từ xương vào máu, phức hợp calci - phospho tăng lắng đọng tại mô, gây rối loạn chu chuyển xương, tăng bài tiết phospho tại ống thận. 
**+Rối loạn về tim mạch**
Bệnh lý tim mạch là nguyên nhân hàng đầu gây bệnh và tử vong ở mọi giai đoạn của bệnh thận mạn, nhất là khi người bệnh đến giai đoạn cuối. 
Tăng huyết áp và dày thất trái
Suy tim sung huyết
Viêm màng ngoài tim
Bệnh mạch máu
**Rối loạn về huyết học**
Thiếu máu ở người bệnh BTM.
Rối loạn đông máu ở người bệnh BTM
Rối loạn đông máu bao gồm kéo dài thời gian máu đông, giảm hoạt tính của yếu tố III tiểu cầu, giảm độ tập trung tiểu cầu và giảm prothrombin. c- Rối loạn chức năng bạch cầu
Rối loạn chức năng bạch cầu như giảm sản xuất bạch cầu, giảm chức năng bạch cầu do suy dinh dưỡng, toan chuyển hóa, môi trường tăng urê máu, và do teo hạch lympho. 
**Rối loạn tiêu hóa và dinh dưỡng**
Buồn nôn và nôn 
Ăn giảm đạm sẽ giúp giảm buồn nôn và nôn, tuy nhiên sẽ tăng nguy cơ suy dinh dưỡng. 
**Rối loạn thần kinh cơ**
Triệu chứng thần kinh cơ bắt đầu xuẩt hiện từ BTM giai đọan 3 như giảm trí nhớ, kém tập trung, rối loạn giấc ngủ. Sau đó, tiến triển thành thần kinh kích thích như nấc cục, chuột rút, đau xoắn vặn cơ, nặng hơn trong giai đoạn suy thận nặng là rung vẫy, clonus cơ, co giật và hôn mê. 
Triệu chứng thần kinh ngọai biên xuất hiện từ BTM giai đoạn 4
Triệu chứng rối loạn thần kinh cảm giác người bệnh BTM giai đoạn cuối là chỉ điểm người bệnh cần lọc máu. 
Bệnh thần kinh ngoại biên ở người bệnh BTM là chỉ định của điều trị thay thế thận, ngoại trừ tổn thương thần kinh trên người bệnh đái tháo đường. 
**Rối loạn nội tiết và chuyển hóa**
Hormone sinh dục: Ở người bệnh nữ, giảm estrogen gây rối loạn kinh nguyệt, giảm khả năng thụ thai và dễ sảy thai, nhất là khi mức lọc cầu thận giảm c n 40 ml/ph, chỉ có 20% sản phụ của thể sanh được con c n sống và ngược lại, thai kỳ sẽ đẩy nhanh tiến triển của suy thận. Ở người bệnh nam, giảm nồng độ testosteron, rối loạn tình dục, và thiểu sản tinh trùng.
Các rối loạn nội tiết này sẽ cải thiện sau điều trị lọc máu tích cực hoặc sau ghép thận thành công.
**Tổn thương da**
Tổn thương da trên BTM đang tiến triển đa dạng như: 
.Da vàng xanh do thiếu máu, có thể giảm sau điều trị erythropoietin
.Xuất huyết da niêm, mảng bầm trên da do rối loạn đông cầm máu
.Da tăng sắc tố do tăng lắng đọng các sản phẩm biến dưỡng tăng sắc tố, hoặc urochrome, triệu chứng này có thể vẫn tồn tại và gia tăng sau lọc máu
.Ngứa là triệu chứng thường gặp ở người bệnh suy thận mạn và có thể kéo dài ngay sau khi đã được lọc máu. 
.Bệnh da xơ do thận (nephrogenic fibrosing dermopathy) biểu hiện bằng tổn thương xơ tiến triển vùng mô dưới da vùng cánh tay và chân tương tự tổn thương da do phù niêm xơ hóa, xuất hiện ở người bệnh suy thận mạn, thường ở người bệnh đang lọc máu, có kèm dùng gadolinium trong chụp cộng hưởng từ (MRI) là một trong các nguyên nhân gây bệnh.
**ĐIỀU TRỊ BỆNH THẬN MẠN GIAI ĐỌAN CUỐI**
**Mục tiêu của điều trị người bệnh BTM giai đoạn cuối là**
Chuẩn bị điều trị thay thế thận khi thận suy nặng
Điều chỉnh liều thuốc ở người bệnh suy thận
Điều trị các biến chứng của hội chứng urê huyết cao như thiếu máu, suy dinh dưỡng, tăng huyết áp, rối loạn chuyển hóa canxi - phospho, rối loạn nước điện giải.
Điều trị các biến chứng tim mạch, và các yếu tố nguy cơ.
**Điều trị triệu chứng**
Tuỳ theo bệnh nhân có triệu chứng bất thường nào thì chọn phương pháp điều trị phù hợp
**Chỉ định điều trị thay thế thận**
Trừ phi người bệnh từ chối, mọi người bệnh BTM giai đoạn cuối, với lâm sàng của hội chứng urê huyết cao (thường xảy ra khi độ thanh thải creatinin dưới 15 ml/phút, hoặc sớm hơn ở người bệnh đái tháo đường) đều có chỉ định điều trị thay thế thận. 
Các chỉ đinh điều trị thay thế thận:
Tăng kali máu không đáp ứng với điều trị nội khoa
Toan chuyển hóa nặng (khi việc dùng HCO3 có thể sẽ gây quá tải tuần hoàn).
Quá tải tuần hòan, phù phổi cấp không đáp ứng với điều trị lợi tiểu.
Suy dinh dưỡng tiến triển không đáp ứng với can thiệp khẩu phần
Mức lọc cầu thận từ 5-10ml/ph/1,73 m2 ( hoặc BUN > 100mg/dL, créatinine huyết thanh > 10mg/dL)
**Lựa chọn hình thức điều trị thay thế thận**
Có ba hình thức điều trị thay thế thận bao gồm: 
1.Thận nhân tạo (hoặc thẩm tách máu, hemodialysis, HD)
2.Thẩm phân phúc mạc (peritoneal dialysis, PD)
3.Ghép thận. 
Có thể lựa chọn một trong ba phương pháp, tuỳ vào từng trường hợp cụ thể của người bệnh.
**TÀI LIỆU THAM KHẢO**
Brenner B.M, 2012.  _The Kidney_ , 9th ed, Vol 1.
Braunward, Fauci et al, 2007.  _Harrison's Principles of Internal Medicine_ , 15th ed.
Greenberg A, 2009.  _Primer on Kidney diseases._
K DOQI guideline - Chronic Kidney Disease, 2002. National Kidney Foudation,  _American Journal of Kidney Disease_ , 39 (2), Supp 1, p 1-242.
KDIGO guidelines 2012. The clinical practice guidelines for evaluation and management of Chronic kidney disease.  _Kidney International_ (2012), 3, 1-150.
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh

## ️ Lọc màng bụng liên tục 24 giờ

  * [Người thực hiện ](https://bvnguyentriphuong.com.vn/than-loc-mau/loc-mang-bung-lien-tuc-24-gio#ngi-thc-hin)
  * [CÁC BƯỚC TIẾN HÀNH](https://bvnguyentriphuong.com.vn/than-loc-mau/loc-mang-bung-lien-tuc-24-gio#cc-bc-tin-hnh)
  * [Chuẩn bị người bệnh](https://bvnguyentriphuong.com.vn/than-loc-mau/loc-mang-bung-lien-tuc-24-gio#chun-b-ngi-bnh)
  * [Thực hiện kỹ thuật](https://bvnguyentriphuong.com.vn/than-loc-mau/loc-mang-bung-lien-tuc-24-gio#thc-hin-k-thut)
  * [TAI BIẾN VÀ XỬ TRÍ](https://bvnguyentriphuong.com.vn/than-loc-mau/loc-mang-bung-lien-tuc-24-gio#tai-bin-v-x-tr)
  * [TÀI LIỆU THAM KHẢO](https://bvnguyentriphuong.com.vn/than-loc-mau/loc-mang-bung-lien-tuc-24-gio#ti-liu-tham-kho)


### **ĐẠI CƯƠNG**
Lọc màng bụng liên tục 24 giờ hay thẩm phân phúc mạc liên tục 24 giờ là một trong các biện pháp lọc máu để điều trị cho người bệnh suy thận cấp hoặc điều trị thay thế cho người bệnh mắc bệnh thận mạn giai đoạn cuối sau 2 tuần đặt catheter ổ bụng. 
Mục đích của lọc màng bụng liên tục 24 giờ nhằm đào thải một số sản phẩm chuyển hoá ra ngoài cơ thể, đồng thời huấn luyện người bệnh và người nhà người bệnh làm quen với phương pháp lọc màng bụng liên tục để chuẩn bị cho việc thực hiện phương pháp lọc màng bụng liên tục ngoại trú khi ra viện.
### **CHỈ ĐỊNH**
Suy thận cấp đã được đặt catheter ổ bụng.
Bệnh thận mạn tính giai đoạn cuối đã được đặt catheter ổ bụng (thường là sau 2 tuần).
Người bệnh lọc màng bụng liên tục ngoại trú bị viêm phúc mạc.
### **CHỐNG CHỈ ĐỊNH**
Viêm dính sau phẫu thuật ổ bụng.
Bệnh thận mạn tính do thận đa nang.
Đã có can thiệp ngoại khoa ổ bụng.
Thoát vị thành bụng, dò hệ thống tiêu hoá vào trong ổ bụng, tử cung - phần phụ.
### **CHUẨN BỊ**
#### **Người thực hiện**
01 bác sĩ, 01 điều dưỡng.
#### **Phương tiện**
Dung dịch sát khuẩn tay nhanh, cồn 900
Hộp đựng khăn lau tay: 01 hộp
Kẹp xanh: 02 cái
Minicap 4 -20 cái ( tuỳ theo từng trường hợp người bệnh nêu ở trên)
Khay Inox: 01 cái
Bàn tiêm hoặc xe tiêm: 01 cái
Cọc truyền dịch: 01 cái
Cân (loại cân treo loại nhỏ dùng để cân dịch): 01 cái
Túi dịch pha sẵn theo tiêu chuẩn quốc tế (Dianeal Low Calcium 1.5 hoặc 2.5): 4 - 20 túi (2 lít/1 túi).
Heparine: 1 lọ 25.000 UI
Bơm tiêm 1 ml: 01 cái
Bộ quần áo blue: 02 cái
Khẩu trang: 03 cái
#### **Người bệnh**
Người bệnh suy thận cấp: người bệnh đã được đặt catheter ổ bụng trước và catheter thông tốt.
Người bệnh suy thận mạn giai đoạn cuối chuẩn bị điều trị thay thế đã được đặt catheter ổ bụng trước đó 2 tuần và catheter thông tốt.
Xét nghiệm sinh hóa máu trước khi tiến hành, khám lâm sàng, đo huyết áp, cân nặng. 
**Hồ sơ bệnh án:** kẻ bảng theo dõi dịch vào - ra, cân bằng dịch,..
### **CÁC BƯỚC TIẾN HÀNH**
#### **Kiểm tra hồ sơ**
Đối chiếu người bệnh và chỉ định. 
#### **Chuẩn bị người bệnh**
Người bệnh được giải thích về phương pháp điều trị đồng thời ký cam kết.
Cho người bệnh vào phòng cách ly để đảm bảo vô trùng.
Người bệnh được đeo khẩu trang y tế.
#### **Thực hiện kỹ thuật**
Thay dịch:
Lau bàn ( khay) bằng cồn 900.
2 kẹp xanh và các minicap để vào khay đã vô trùng.
Xé bao ngoài túi dịch, để túi dịch vào khay.
Đeo khẩu trang.
Rửa tay theo quy trình.
Kiểm tra túi dịch 7 bước: hạn dùng, thể tích, nồng độ, ấn túi dịch xem có rò rỉ không, kiểm tra độ trong của dịch, khoen xanh và khoá an toàn đảm bảo.
Kẹp dây túi dịch, bẻ khóa.
Bộc lộ vùng bụng người bệnh và lấy ống thông ra (catheter).
Sát khuẩn tay nhanh lần 1.
Kết nối túi dịch vào ống thông.
Treo túi dịch lên, bỏ túi xả xuống.
Mở khoá xoay (trắng) để xả dịch trong bụng người bệnh ra đến hết.
Đóng khoá xoay (trắng), chuyển kẹp đếm chậm từ 1 đến 5 (đuổi khí).
Mở khoá xoay (trắng) để cho dịch mới vào.
Dịch vào hết, kẹp 2 đường dây túi dịch, đóng khóa xoay (trắng).
Sát khuẩn tay nhanh lần 2.
Mở minicap (nắp đậy) - kiểm tra màu vàng của thuốc bên trong nắp.
Tháo kết nối, đậy minicap lại.
Quan sát màu, tính chất túi dịch xả trong hay đục, có vẩn không.
Cân túi dịch xả, ghi sổ theo dõi dịch.
**Đối với người bệnh suy thận mạn điều trị thay thế bằng lọc màng bụng liên tục 24 giờ:**
Việc thực hiện thay dịch là 4 lần, mỗi lần ngâm dịch trong ổ bụng 6 giờ; khối lượng dịch mỗi lần cho vào ổ bụng tuỳ theo đáp ứng của người bệnh ( thường mỗi lần cho vào ổ bụng < 2 lít dịch).
**Đối với người bệnh suy thận cấp:**
Cho 2 lít dịch lọc 1,5% chảy vào ổ bụng với thời gian 15 phút chảy vào và 15 phút chảy ra, rửa sạch ổ bụng.
Các túi dịch tiếp theo 2 lít /lần, lưu trong ổ bụng từ 30- 60 phút rồi xả dịch ra ngoài để tiếp tục lọc tiếp. Dịch lọc có thể pha 500 UI heparin/lít dịch lọc ở tất cả các túi để phòng ngừa tắc catheter. Tùy từng người bệnh cụ thể sẽ quyết định liều thuốc chống đông hợp lý. 
Số lượng dịch: 30- 40 lít/ngày lọc hàng ngày cho đến khi chức năng thận phục hồi, hết tình trạng đe dọa để có thể tiến hành được các chỉ định khác cần thiết cho chẩn đoán và điều trị.
Theo dõi cân bằng dịch mỗi lần lọc và điều chỉnh loại dịch tùy thuộc vào tình trạng của người bệnh. Lưu ý nguy cơ mất dịch, thừa dịch, rối loạn điện giải có thể xảy ra, cần được điều chỉnh sớm. 
### **THEO DÕI**
Tình trạng lâm sàng nói chung: mạch, HA, nhiệt độ, tình trạng bụng, rò rỉ dịch, tắc dịch, tốc độ dịch chảy vào, chảy ra.
### **TAI BIẾN VÀ XỬ TRÍ**
Hiếm gặp (viêm phúc mạc, đau bụng do co thắt dạ dày,..).
Tuỳ theo loại tai biến mà có phương pháp điều trị thích hợp.
### **TÀI LIỆU THAM KHẢO**
Ash SR. (2004) Peritoneal dialysis in acute renal failure of aldults: the underutilized modality. Contrib Nephrol 44: 239- 254.
Chitalia VC, Almeida AF et al. (2002) Is peritoneal dialysis adequate for hypercatabolic acute renal failure in developing countries ? Kidney Int. 61: 747- 757.
Gabriel DP, Nascimento GV et al. (2007) High volume peritoneal dialysis for acute renal failure . Pert Dial Int 277- 282.
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [Người thực hiện ](https://bvnguyentriphuong.com.vn/than-loc-mau/loc-mang-bung-lien-tuc-24-gio#ngi-thc-hin)
  * [CÁC BƯỚC TIẾN HÀNH](https://bvnguyentriphuong.com.vn/than-loc-mau/loc-mang-bung-lien-tuc-24-gio#cc-bc-tin-hnh)
  * [Chuẩn bị người bệnh](https://bvnguyentriphuong.com.vn/than-loc-mau/loc-mang-bung-lien-tuc-24-gio#chun-b-ngi-bnh)
  * [Thực hiện kỹ thuật](https://bvnguyentriphuong.com.vn/than-loc-mau/loc-mang-bung-lien-tuc-24-gio#thc-hin-k-thut)
  * [TAI BIẾN VÀ XỬ TRÍ](https://bvnguyentriphuong.com.vn/than-loc-mau/loc-mang-bung-lien-tuc-24-gio#tai-bin-v-x-tr)
  * [TÀI LIỆU THAM KHẢO](https://bvnguyentriphuong.com.vn/than-loc-mau/loc-mang-bung-lien-tuc-24-gio#ti-liu-tham-kho)



## ️ Đặt catheter tĩnh mạch cảnh để lọc máu cấp cứu

  * [Người thực hiện](https://bvnguyentriphuong.com.vn/than-loc-mau/dat-catheter-tinh-mach-canh-de-loc-mau-cap-cuu#ngi-thc-hin)
  * [CÁC BƯỚC TIẾN HÀNH](https://bvnguyentriphuong.com.vn/than-loc-mau/dat-catheter-tinh-mach-canh-de-loc-mau-cap-cuu#cc-bc-tin-hnh)
  * [Kiểm tra người bệnh ](https://bvnguyentriphuong.com.vn/than-loc-mau/dat-catheter-tinh-mach-canh-de-loc-mau-cap-cuu#kim-tra-ngi-bnh)
  * [Thực hiện kỹ thuật ](https://bvnguyentriphuong.com.vn/than-loc-mau/dat-catheter-tinh-mach-canh-de-loc-mau-cap-cuu#thc-hin-k-thut)
  * [TAI BIẾN VÀ XỬ TRÍ](https://bvnguyentriphuong.com.vn/than-loc-mau/dat-catheter-tinh-mach-canh-de-loc-mau-cap-cuu#tai-bin-v-x-tr)
  * [TÀI LIỆU THAM KHẢO](https://bvnguyentriphuong.com.vn/than-loc-mau/dat-catheter-tinh-mach-canh-de-loc-mau-cap-cuu#ti-liu-tham-kho)


### **ĐẠI CƯƠNG**
Đặt catheter tĩnh mạch cảnh để lọc máu cấp cứu nhằm thiết lập đường vào mạch máu cho điều trị thay thế thận bằng lọc máu ở những người bệnh có chỉ định cần lọc máu cấp cứu. 
### **CHỈ ĐỊNH**
Người bệnh có chỉ định đặt đường vào mạch máu cho lọc máu cấp cứu.
### **CHỐNG CHỈ ĐỊNH**
Rối loạn đông máu nặng không đáp ứng với điều trị. 
Đang được điều trị với chống đông: aspirin, warfarin, heparin.
Tăng huyết áp không kiểm soát được.
Bướu cổ lan tỏa. 
Dị dạng xương đòn lồng ngực. 
Đã có nhiều phẫu thuật vùng cổ, ngực. 
Khí phế thủng. 
Xuất huyết. 
Bệnh toàn thể nặng tiên lượng tử vong. 
### **CHUẨN BỊ**
#### **Người thực hiện**
02 bác sĩ: 01 bác sĩ thực hiện thủ thuật, 01 bác sĩ chuẩn bị dụng cụ và phụ.
01 điều dưỡng: phụ giúp các bác sĩ tiến hành thủ thuật.
#### **Phương tiện**
Giường thực hiện thủ thuật: 01 chiếc
Catheter hai nòng lọc máu cấp cứu (short-term)
Dung dịch Betadin sát trùng :1 lọ
Săng vô khuẩn loại có lỗ: 01 chiếc
Săng vô khuẩn không có lỗ: 01 chiếc
Thuốc gây tê lidocain 2%: 04 ống
Nước muối sinh lý 0,9%: 500ml
Heparin 3-5ml
Kim tiêm, bơm tiêm 5ml: 01 chiếc
Bơm tiêm 20ml: 02 chiếc
Bông băng, gạc vô trùng: 04 gói
Găng tay vô trùng: 03 đôi
Bộ dụng cụ và thuốc chống choáng, chống sốc phản vệ
#### **Người bệnh**
Người bệnh đã được làm các xét nghiệm về đông máu cơ bản và các xét nghiệm cơ bản khác.
Người bệnh và người nhà được nghe bác sĩ giải thích kỹ về tác dụng và tai biến của thủ thuật và ký vào giấy cam kết đồng ý làm thủ thuật.
#### **Hồ sơ bệnh án**
Bệnh án được hoàn thiện với các thủ tục dành cho người bệnh tiến hành làm thủ thuật: hồ sơ đã duyệt can thiệp thủ thuật, giấy cam đoan có ký xác nhận của người bệnh hoặc người nhà. 
### **CÁC BƯỚC TIẾN HÀNH**
#### **Kiểm tra hồ sơ**
Kiểm tra các xét nghiệm đã được làm. 
#### **Kiểm tra người bệnh**
Đối chiếu tên, tuổi, chẩn đoán bệnh.
#### **Thực hiện kỹ thuật**
Người bệnh dược thử phản ứng với thuốc gây tê lidocain.
Người bệnh được kiểm tra mạch, huyết áp trước khi tiến hành thủ thuật. 
Người bệnh được nằm ngửa, đầu nghiêng tư thế Trendelenburg, đầu quay 45o về phía đối diện.
Bác sĩ rửa tay, đi găng vô trùng, mặc áo thủ thuật.
Sát trùng da vùng định đặt catheter.
Trải săng vô trùng loại có lỗ.
Xác định tam giác được tạo thành bởi hai đầu của cơ ức đòn chũm và xương ức, bắt mạch cảnh.
Gây tê da và tổ chức dưới da vùng đặt catheter.
Bắt mạch cảnh. Chọc bên ngoài động mạch cảnh bằng kim thăm dò, góc chọc kim lên 30- 450 so với người bệnh, hướng về núm vú cùng bên trong khi vừa đi vừa hút chân không trong tay. Khi có máu trào ra, đánh dấu hướng và độ sâu của kim, rút kim thăm dò.
Đưa kim dẫn đường chính xác theo đường đi của kim thăm dò khi có máu tĩnh mạch ra luồn guidewire. Đưa kim mở đường vào theo guidewire sau đó dùng dao để mở đường qua da cho kim mở đường vào để mở đường vào tĩnh mạch. Rút kim mở đường vào tĩnh mạch và luồn catheter vào tĩnh mạch cảnh trong. 
Rút guidewire và dùng bơm tiêm heparin bơm chậm vào hai nhánh catheter, thông thường khoảng 1,5 ml mỗi bên.
Khâu cố định chân catheter
Băng vùng chân catheter
Cho người bệnh về giường bệnh 
Chụp X quang tim phổi thẳng cấp trước khi tiến hành lọc máu.
### **THEO DÕI**
Các thông số sinh tồn: toàn trạng, mạch, huyết áp, nhịp thở.
Kiểm soát đau.
### **TAI BIẾN VÀ XỬ TRÍ**
Tai biến thường gặp nhất khi đặt catheter tĩnh mạch cảnh là chọc vào động mạch. Xử trí bằng tạm dừng thủ thuật, ép khoảng 15 phút. 
Tai biến ít gặp hơn là tràn khí màng phổi, tràn dịch màng phổi, tràn máu màng phổi, tắc mạch khí, chảy máu khoang sau phúc mạc. Theo dõi toàn trạng, chụp phổi thẳng, xử trí theo tình trạng tổn thương. 
Nhiễm trùng (liên quan đến đặt catheter, nhiễm trùng tại vị trí đặt, viêm mô tế bào). Dùng kháng sinh phổ rộng như cephalosporin thế hệ 3 hoặc cân nhắc sử dụng kháng sinh diệt liên cầu, tụ cầu như vancomycine…
Các bệnh lý tắc mạch, huyết khối liên quan đến đặt catheter tĩnh mạch cảnh trong rất hiếm gặp. 
### **TÀI LIỆU THAM KHẢO**
Scott O. Trerotola. 2000. Hemodialysis Catheter Placement and Management. Radiology. 215:651-658. 
Julie AG, Alan DK. 2012. Ultrasound-Guided Central vein Cannulation: Current recommendations and guideline. Anesthesiology News. June: 1-6. 
Gibbs FJ, Murphy MC. 2006. Ultrasound Guidance for Central venous catheter placement. Hospital physician. March: 23-31.
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [Người thực hiện](https://bvnguyentriphuong.com.vn/than-loc-mau/dat-catheter-tinh-mach-canh-de-loc-mau-cap-cuu#ngi-thc-hin)
  * [CÁC BƯỚC TIẾN HÀNH](https://bvnguyentriphuong.com.vn/than-loc-mau/dat-catheter-tinh-mach-canh-de-loc-mau-cap-cuu#cc-bc-tin-hnh)
  * [Kiểm tra người bệnh ](https://bvnguyentriphuong.com.vn/than-loc-mau/dat-catheter-tinh-mach-canh-de-loc-mau-cap-cuu#kim-tra-ngi-bnh)
  * [Thực hiện kỹ thuật ](https://bvnguyentriphuong.com.vn/than-loc-mau/dat-catheter-tinh-mach-canh-de-loc-mau-cap-cuu#thc-hin-k-thut)
  * [TAI BIẾN VÀ XỬ TRÍ](https://bvnguyentriphuong.com.vn/than-loc-mau/dat-catheter-tinh-mach-canh-de-loc-mau-cap-cuu#tai-bin-v-x-tr)
  * [TÀI LIỆU THAM KHẢO](https://bvnguyentriphuong.com.vn/than-loc-mau/dat-catheter-tinh-mach-canh-de-loc-mau-cap-cuu#ti-liu-tham-kho)



## ️ Lọc màng bụng liên tục 24 giờ bằng máy

  * [Người thực hiện ](https://bvnguyentriphuong.com.vn/than-loc-mau/loc-mang-bung-lien-tuc-24-gio-bang-may#ngi-thc-hin)
  * [CÁC BƯỚC TIẾN HÀNH](https://bvnguyentriphuong.com.vn/than-loc-mau/loc-mang-bung-lien-tuc-24-gio-bang-may#cc-bc-tin-hnh)
  * [KẾT THÚC LẦN THAY DỊCH](https://bvnguyentriphuong.com.vn/than-loc-mau/loc-mang-bung-lien-tuc-24-gio-bang-may#kt-thc-ln-thay-dch)
  * [Theo dõi hoạt động của máy lọc.](https://bvnguyentriphuong.com.vn/than-loc-mau/loc-mang-bung-lien-tuc-24-gio-bang-may#theo-di-hot-ng-ca-my-lc)
  * [TÀI LIỆU THAM KHẢO](https://bvnguyentriphuong.com.vn/than-loc-mau/loc-mang-bung-lien-tuc-24-gio-bang-may#ti-liu-tham-kho)


### **ĐẠI CƯƠNG**
Lọc màng bụng là một trong các phương pháp điều trị thay thế thận suy.
Lọc màng bụng bằng máy hay còn gọi là thẩm phân phúc mạc tự động (APD = Automated peritoneal dialysis): là một phương thức lọc màng bụng có dùng máy thay dịch tự động (cycler).
Máy được thiết kế để giảm số lần thay dịch -> giảm nguy cơ nhiễm trùng. Các thông số điều trị như lượng dịch cho vào, thời gian ngâm dịch, số chu kỳ thực hiện đều được lập trình trên máy.
### **CHỈ ĐỊNH**
Tăng cường siêu lọc: trong trường hợp người bệnh đang được lọc màng bụng liên tục ngoại trú nhưng vì nguyên nhân gì đó làm người bệnh bị quá tải dịch, phù toàn thân, đe dọa phù phổi cấp.
Suy thận cấp và có chỉ định lọc màng bụng cấp (người bệnh có chống chỉ định thận nhân tạo cấp).
### **CHỐNG CHỈ ĐỊNH**
Người bệnh bị gan thận đa nang, tiền sử bị mổ can thiệp vào ổ bụng và bị dày dính phúc mạc...
Người bệnh đang bị viêm phúc mạc.
### **CHUẨN BỊ**
#### **Người thực hiện**
01 bác sĩ, 01 điều dưỡng, 01 kỹ thuật viên.
#### **Phương tiện**
Máy thay dịch tự động Cycler. 
Túi dịch thẩm phân (số lượng tuỳ chỉ định, thường dùng túi 5 lít); tổng số lượng dịch tuỳ theo chỉ định (có thể từ 8 đến 20 lít/24giờ); nồng độ dịch tùy theo chỉ định: 1,5%, 2,5%, 4,25%.
Bộ cassette (đầu Luer lock).
Túi xả 15 lít
Minicap: 05 cái
Dung dịch sát khuẩn: betadine 10% 
Găng vô trùng: 02 đôi
#### **Người bệnh**
Giải thích người bệnh về thủ thuật để người bệnh hợp tác.
Thông báo người bệnh ngày, giờ tiến hành lọc màng bụng liên tục 24 giờ bằng máy.
#### **Hồ sơ bệnh án**
Hồ sơ bệnh án được ghi chỉ định và có bảng theo dõi quá trình lọc màng bụng.
### **CÁC BƯỚC TIẾN HÀNH**
Kiểm tra hồ sơ: đối chiếu tên tuổi người bệnh.
Kiểm tra người bệnh: đo huyết áp, nhịp tim trước khi tiến hành thủ thuật lọc màng bụng liên tục 24 giờ bằng máy.
Thực hiện kỹ thuật: tuỳ theo mỗi loại máy thì có các bước tiến hành riêng trên từng máy. Sau đây là các bước thực hiện trên máy HomeChoice của hãng Baxter được sử dụng phổ biến trên Việt Nam và trên thế giới hiện nay.
### **KẾT THÚC LẦN THAY DỊCH**
### **THEO DÕI**
#### Theo dõi hoạt động của máy lọc.
Monitoring theo dõi người bệnh: theo dõi mạch, huyết áp, SpO2, nhiệt độ. 
Theo dõi tình trạng ổ bụng người bệnh: đau, các dấu hiệu bất thường.
Theo dõi hiệu quả lọc màng bụng: ure, creatinine máu, mức độ phù (hiệu quả siêu lọc).
**TAI BIẾN VÀ XỬ TRÍ**
Hiếm khi có tai biến.
Một số biểu hiện có thể xảy ra: rét run do dùng dịch lọc chưa được làm ấm trước khi kết nối với người bệnh: tạm dừng lọc và thay bằng túi dịch đã được làm ấm. 
### **TÀI LIỆU THAM KHẢO**
The HomeChoice and HomeChoice PRO APD Systems Trainer’s Guide
(October 2. 2009). Baxter International Inc 07-19-61-245.
Baxter Renal division Setting up the Homechoice Machine (2004)
Nottingham University Hospitals NHS Trust (2011), Infection Control Policy
V Keill (Nov 2011), ISPD Position Statement on Reducing The Risks of Peritoneal Dialysis Related infections.
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [Người thực hiện ](https://bvnguyentriphuong.com.vn/than-loc-mau/loc-mang-bung-lien-tuc-24-gio-bang-may#ngi-thc-hin)
  * [CÁC BƯỚC TIẾN HÀNH](https://bvnguyentriphuong.com.vn/than-loc-mau/loc-mang-bung-lien-tuc-24-gio-bang-may#cc-bc-tin-hnh)
  * [KẾT THÚC LẦN THAY DỊCH](https://bvnguyentriphuong.com.vn/than-loc-mau/loc-mang-bung-lien-tuc-24-gio-bang-may#kt-thc-ln-thay-dch)
  * [Theo dõi hoạt động của máy lọc.](https://bvnguyentriphuong.com.vn/than-loc-mau/loc-mang-bung-lien-tuc-24-gio-bang-may#theo-di-hot-ng-ca-my-lc)
  * [TÀI LIỆU THAM KHẢO](https://bvnguyentriphuong.com.vn/than-loc-mau/loc-mang-bung-lien-tuc-24-gio-bang-may#ti-liu-tham-kho)



## ️ Đặt catheter màng bụng cấp cứu để lọc màng bụng cấp cứu

  * [Người thực hiện ](https://bvnguyentriphuong.com.vn/than-loc-mau/dat-catheter-mang-bung-cap-cuu-de-loc-mang-bung-cap-cuu#ngi-thc-hin)
  * [CÁC BƯỚC TIẾN HÀNH](https://bvnguyentriphuong.com.vn/than-loc-mau/dat-catheter-mang-bung-cap-cuu-de-loc-mang-bung-cap-cuu#cc-bc-tin-hnh)
  * [Kiểm tra hồ sơ bệnh án](https://bvnguyentriphuong.com.vn/than-loc-mau/dat-catheter-mang-bung-cap-cuu-de-loc-mang-bung-cap-cuu#kim-tra-h-s-bnh-n)
  * [Kiểm tra người bệnh](https://bvnguyentriphuong.com.vn/than-loc-mau/dat-catheter-mang-bung-cap-cuu-de-loc-mang-bung-cap-cuu#kim-tra-ngi-bnh)
  * [Thực hiện kỹ thuật](https://bvnguyentriphuong.com.vn/than-loc-mau/dat-catheter-mang-bung-cap-cuu-de-loc-mang-bung-cap-cuu#thc-hin-k-thut)
  * [TAI BIẾN VÀ XỬ TRÍ](https://bvnguyentriphuong.com.vn/than-loc-mau/dat-catheter-mang-bung-cap-cuu-de-loc-mang-bung-cap-cuu#tai-bin-v-x-tr)
  * [TÀI LIỆU THAM KHẢO](https://bvnguyentriphuong.com.vn/than-loc-mau/dat-catheter-mang-bung-cap-cuu-de-loc-mang-bung-cap-cuu#ti-liu-tham-kho)


### **ĐẠI CƯƠNG**
Lọc màng bụng cấp cứu là một trong những biện pháp điều trị thay thế thận cấp cứu cho những người bệnh bị suy thận cấp do nhiều nguyên nhân khác nhau. Hiệu quả lọc được tạo ra do sự trao đổi một số chất giữa máu và dịch lọc trong ổ bụng thông qua màng bán thấm là màng bụng. 
Kỹ thuật đặt catheter lọc màng bụng cấp cứu là đặt catheter vào ổ bụng để thiết lập đường dẫn dịch lọc màng bụng vào ổ bụng nhờ đó tiến hành lọc màng bụng (thẩm phân phúc mạc).
Có nhiều cách đặt catheter vào ổ bụng với những ưu nhược điểm khác nhau, để lọc màng bụng cấp cứu thường tiến hành đặt catheter lọc màng bụng qua da.
### **CHỈ ĐỊNH**
Khi người bệnh bị suy thận cấp có chỉ định lọc máu cấp cứu. 
### **CHỐNG CHỈ ĐỊNH**
Người bệnh đã có can thiệp ngoại khoa trong ổ bụng. 
Người bệnh có tình trạng viêm phúc mạc. 
Hiện đang bị nhiễm trùng ngoài da.
### **CHUẨN BỊ**
#### **Người thực hiện**
01 bác sĩ, 01 điều dưỡng
#### **Phương tiện**
Bộ catheter Quinton hoặc Tenckhoff thẳng 1 cuff hoặc 2 cuff: 01 bộ 
Bộ dụng cụ đặt catheter bao gồm: 
Trocar kim loại: 01 cái
Kim nong: 01 cái
Dẫn đường kim loại: 01 cái
Dao rạch da mở đường: 01 cái
Bơm kim tiêm 5ml: 02 cái
Gạc vô trùng: 01 gói (5 miếng) 
Bộ dây dẫn dịch nối với túi dịch lọc: 01 cái
Dịch lọc màng bụng loại 1.5%: 01 túi 
Heparin 25000 UI: 01 lọ
Thuốc gây tê lidocain 2%: 02 ống
Dung dịch sát trùng betadine 10%: 01 lọ
Găng vô khuẩn: 04 đôi
Áo mổ: 02 cái
Kỹ thuật đặt catheter lọc màng bụng qua da được tiến hành trong phòng thủ thuật đảm bảo vô trùng.
#### **Người bệnh**
Được giải thích về phương pháp điều trị và cách thức đặt catheter để đưa dịch lọc vào ổ bụng, ký giấy cam kết.
Thụt tháo trước đó.
Đi tiểu hết.
Kháng sinh dự phòng nhiễm trùng nhóm cephalosporin thế hệ I liều duy nhất.
Vệ sinh và sát trùng toàn bộ vùng da bụng. 
#### **Hồ sơ bệnh án**
Kiểm tra đủ thủ tục hành chính.
### **CÁC BƯỚC TIẾN HÀNH**
#### **Kiểm tra hồ sơ bệnh án**
Xem có đầy đủ thủ tục hành chính trước khi tiến hành thủ thuật.
#### **Kiểm tra người bệnh**
Tình trạng lâm sàng, chỉ định và chống chỉ định.
#### **Thực hiện kỹ thuật**
Xác định vị trí trên đường trắng giữa, dưới rốn 2 cm
Gây tê tại chỗ
Rạch da mở đường vào ổ bụng vừa lỗ troca (1 cm)
Nong đường vào
Đưa catheter có nòng kim loại vào ổ bụng đi sát thành bụng, hướng về phía túi cùng Douglas cho đến khi người bệnh có cảm giác tức vùng hạ vị. Rút kim nòng kim loại ra khỏi lòng catheter.
Khâu cố định catheter với thành bụng.
Nối catheter với bộ dây nối với túi dịch lọc màng bụng.
Cho dịch chảy vào ổ bụng với số lượng 1500 ml-2000 ml/túi có pha heparrin 1000 UI/túi. Xả dịch ra ngay cho đến khi dịch trong.
### **THEO DÕI**
Theo dõi tình trạng bụng ngoại khoa, thủng ruột, rò rỉ dịch, màu sắc dịch, sốt, cân bằng dịch, điện giải…
### **TAI BIẾN VÀ XỬ TRÍ**
Đau, chảy máu vào trong ổ bụng, thủng tạng rỗng, nhiễm trùng,… 
Tùy vào từng tai biến để có biện pháp xử trí kịp thời. 
### **TÀI LIỆU THAM KHẢO**
Abdel - Aal AK, Joshi AK et all. (2009) Fluoroscopic and sonographic guidance to place peritoneal catheters: how we do it. Am J Roentgerol 192: 1085 - 1089.
Alvarez AC, Salman L et al. (2009) Peritoneal dialysis catheter insertion by interventional nephrologists. Adv Chronic Kidney Dis 16: 378 -385.
Stegmayr B, (2006) Advantages and disadvantages of surgical placement of PD catheters with regard to other methods. Int J Artif Organs 29: 95-100.
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [Người thực hiện ](https://bvnguyentriphuong.com.vn/than-loc-mau/dat-catheter-mang-bung-cap-cuu-de-loc-mang-bung-cap-cuu#ngi-thc-hin)
  * [CÁC BƯỚC TIẾN HÀNH](https://bvnguyentriphuong.com.vn/than-loc-mau/dat-catheter-mang-bung-cap-cuu-de-loc-mang-bung-cap-cuu#cc-bc-tin-hnh)
  * [Kiểm tra hồ sơ bệnh án](https://bvnguyentriphuong.com.vn/than-loc-mau/dat-catheter-mang-bung-cap-cuu-de-loc-mang-bung-cap-cuu#kim-tra-h-s-bnh-n)
  * [Kiểm tra người bệnh](https://bvnguyentriphuong.com.vn/than-loc-mau/dat-catheter-mang-bung-cap-cuu-de-loc-mang-bung-cap-cuu#kim-tra-ngi-bnh)
  * [Thực hiện kỹ thuật](https://bvnguyentriphuong.com.vn/than-loc-mau/dat-catheter-mang-bung-cap-cuu-de-loc-mang-bung-cap-cuu#thc-hin-k-thut)
  * [TAI BIẾN VÀ XỬ TRÍ](https://bvnguyentriphuong.com.vn/than-loc-mau/dat-catheter-mang-bung-cap-cuu-de-loc-mang-bung-cap-cuu#tai-bin-v-x-tr)
  * [TÀI LIỆU THAM KHẢO](https://bvnguyentriphuong.com.vn/than-loc-mau/dat-catheter-mang-bung-cap-cuu-de-loc-mang-bung-cap-cuu#ti-liu-tham-kho)



## ️ Biến chứng thường gặp ở người bệnh lọc màng bụng liên tục ngoại trú

Người bệnh lọc màng bụng có thể gặp nhiều biến chứng, bao gồm những biến chứng nhiễm trùng và biến chứng không nhiễm trùng.
**BIẾN CHỨNG NHIỄM TRÙNG:**
Đây vẫn là một thách thức lớn và là nguyên nhân của phần lớn các trường hợp phải rút catheter. Trong số biến chứng nhiễm trùng thường gặp trong lọc màng bụng chu kỳ phải kể đến nhiễm trùng chân ống – đường hầm và viêm phúc mạc.
**Viêm phúc mạc:**
Viêm phúc mạc là nguyên nhân chính gây nhập viện. Viêm phúc mạc đôi khi gây tử vong, trực tiếp do nhiễm khuẩn huyết hoặc gián tiếp do những biến chứng của nhiễm khuẩn.
Chẩn đoán viêm phúc mạc: Khi có 2 trong 3 tiêu chuẩn sau đây 
.Sự hiện diện của vi khuẩn trong nuôi cấy hoặc nhuộm Gram
.Dịch đục ( số lượng bạch ≥ 100/mm; ≥ 50% là bc đa nhân trung tính) - Có các triệu chứng của VPM: đau bụng, cảm ứng phúc mạc..
Điều trị viêm phúc mạc: Điều trị ban đầu của VPM dựa vào kinh nghiệm và thường dùng kháng sinh phổ rộng cho cả vi khuẩn gram âm và dương. Kết quả nuôi cấy tìm vi khuẩn trong dịch lọc màng bụng sẽ quyết định điều trị viêm phúc mạc theo phác đồ nào. Thời gian điều trị phụ thuộc vào vi khuẩn và độ nặng của viêm phúc mạc, ví dụ với nhiễm trùng tụ cầu dịch tễ là 14 ngày và hầu hết các nhiễm trùng khác là 3 tuần.
**Nhiễm trùng liên quan đến Catheter**
Nhiễm trùng exit site được định nghĩa khi có mủ, có hoặc không có tấy đỏ ở vị trí exit site.
Nhiễm trùng của catheter dưới da (đường hầm) có biểu hiện đau, sưng tấy, đỏ, cứng lên ở vùng đường hầm. 
Xử trí: cấy dịch mủ, dịch viêm tìm vi khuẩn. Dựa vào kinh nghiệm điều trị viêm tại chỗ và kháng sinh đường uống, chờ kết quả cấy vi khuẩn để lựa chọn kháng sinh phù hợp. Theo dõi và đánh giá tình trạng viêm, có thể siêu âm để đánh giá mức độ ứ dịch và ú mủ ở đường hầm. Nên thay băng 3h/lần hoặc nhiều hơn. 
Tụ cầu vàng là nguyên nhân thường gặp cho nhiễm trùng exit site và khó điều trị, với tiến triển thường gặp là nhiễm trùng đường hầm và viêm phúc mạc, trong đó việc rút Catheter là cần thiết. Nhiễm trùng Catheter do trực khuẩn mủ xanh cũng khó điều trị, nên rút Catheter trong những trường hợp nặng.
**CÁC BIẾN CHỨNG KHÔNG NHIỄM TRÙNG**
**Biến chứng liên quan đến Catheter**
Biến chứng sau mổ: bao gồm chấn thương đến các cơ quan trong ổ bụng( ruột, bàng quang) hoặc mạch máu, chảy máu hoặc nhiễm trùng. 
Dò dịch: Dò dịch xảy ra ở 7% bn trong năm đầu tiên. Nguy cơ do tăng lên nếu thời gian nghỉ ngơi sau mổ ngắn. Do dịch liên quan đến kỹ thuật đặt Catheter, chấn thương, hoặc bất thường giải phẫu của người bệnh. Hầu hết các trường hợp đều tự liền. Ngừng lọc càng lâu, cơ hội liền càng lớn. Nếu dịch tồn tại dai dẳng cần rút Catheter và đặt lại vào vị trí khác.
Dịch ra kém: Dịch ra kém thường được phát hiện khi thể tích dịch ra ít hơn đáng kể thể tích dịch vào và không có bằng chứng của dò quanh Catheter. Thường xảy ra sớm sau phẫu thuật, trong hoặc sớm sau đợt viêm phúc mạc hoặc bất cứ giai đoạn nào. Các yếu tố trong lòng ống (cục máu đông, fibrin) hoặc ngoài lòng ống ( táo bón, bít các lỗ của Catheter bởi các tạng lân cận hoặc mạc nối bao quanh, đầu Catheter lạc chỗ ra khỏi hố chậu, đặt Catheter không chính xác) là những nguyên nhân thường gặp nhất. 
Điều trị: Tùy vào từng nguyên nhân
+ Kiểm tra xem Catheter có bị xoắn vặn không: nếu có, thường cần phẫu thuật đặt lại Catheter hoặc loại bỏ cuff ở bề mặt
+ Điều trị táo bón: một trong các bước nên làm trước tiên ở người bệnh tắc nghẽn d ng dịch ra là dùng thuốc nhuận tràng. Điều trị táo bón giải quyết được gần 50% các trường hợp tắc nghẽn d ng dịch ra do Catheter.
+ Heparin: thêm Heparin vào dịch lọc màng bụng( 250-500 UI/lít) bất cứ khi nào quan sát thấy fibrin ở d ng dịch ra. Tuy nhiên, heparin có tác dụng dự ph ng hơn là điều trị và thường ít thành công trong trường hợp có tắc nghẽn.
+ Các thuốc tiêu sợi huyết: nếu Heparin không có hiệu quả, cần dùng thuốc tiêu sợi huyết( streptokinase, Urokinase, các chất hoạt hóa plasminogen mô)
+ Sửa lại vị trí Catheter: Nếu tắc nghẽn không giảm khi áp dụng các biện pháp trên, nguyên nhân có thể do mạc nối hoặc các mô khác làm bít đầu Catheter. Trong trường hợp này, cần giải phóng Catheter ra khỏi chỗ bao bọc mạc nối và đặt lại ở vị trí khác trong ổ bụng. 
+ Đặt lại Catheter: Nếu các biện pháp trên thất bại, cần đặt lại Catheter khác.
Dịch vào kém: truyền 2 lít vào ổ bụng thường mất 15 phút. Thời gian này có thể dài hơn hoặc dịch hoàn toàn không vào được. Cần làm những biện pháp sau
+ Kiểm tra xem có xoắn vặn: nếu có, cần đặt lại Catheter hoặc bỏ cuff bề mặt
+ Bơm mạnh 20 ml muối pha heparin
+ Nếu catheter vẫn bị tắc, kiểm tra XQ thấy Catheter nằm sai vị trí cần sửa lại vị trí Catheter
+ Nếu Catheter ở đúng vị trí, truyền urokinase (25 000 đơn vị trong 2 ml muối) vào l ng ống và giữ tại chỗ trong 2-4 h
Mon cuff: Cuff bề mặt có thể gặm vào da vì nhiễm trùng exit site hoặc do lúc đầu đặt quá gần da vùng exit site hoặc cuff sâu tách khỏi lớp cơ thành bụng. Cần cắt bỏ cuff bề mặt.
Đau khi truyền dịch vào: liên quan đến dịch lọc có pH thấp, nhiệt độ dịch lọc cao bất thường, mạc nối bao bọc catheter, hoặc áp lực được tạo ra bởi các cấu trúc lân cận( ruột, âm đạo, thừng tinh) trong thời gian cho dịch vào. Mạc nối bao bọc và áp lực tăng trong các tạng lân cận thường gặp nhất và được điều trị bằng cách sửa lại vị trí Catheter. Thêm Natri hydroxide hoặc Natri bicarbonate vào dịch lọc hoặc sử dụng dịch bicarbonate có thể giảm cảm giác đau
Đau khi xả dịch ra: điều này thường xảy ra khi viêm phúc mạc hoặc vài tuần đầu tiên sau khi bắt đầu lọc màng bụng. Chuyển sang chế độ lọc màng bụng bằng máy kiểu thủy triều thường giúp giảm cảm giác này. 
**Các biến chứng cơ học của LMB:**
Hai yếu tố góp phần gây tăng áp lực trong ổ bụng là lượng dịch vào truyền vào trong ổ bụng và tư thế của người bệnh trong thời gian ngâm dịch
Thoát vị: Khoảng 10-20% bn có biểu hiện thoát vị tại thời điểm nào đó . Những yếu tố nguy cơ bao gồm thể tích dịch lọc lớn, các thiếu sót của thành bụng bẩm sinh. Vị trí thường gặp nhất là thoát vị chỗ đặt Catheter, rốn, bẹn. Thoát vị đáng kể nên được điều trị ngoại khoa, sau đó giữ áp lực thấp trong ổ bụng để tạo điều kiện cho liền vị trí thoát vị.
Phù sinh dục: Dịch lọc có thể chảy đến vùng sinh dục bằng 2 đường: một là đi qua đường thông với âm đạo gây ra ổ tụ dịch( hydrocele) và thứ hai là dịch từ vị trí yếu của thành bụng chảy xuống gây phù ở bao quy đầu và bìu. Nếu do con đường thứ nhất có thể sửa chữa bằng phẫu thuật, nếu do con đường thứ hai có thể đặt lại Catheter. Để có thời gian liền, chuyển tạm thời sang TNT hoặc LMB liên tục bằng máy(CCPD) với thể tích dịch ít.
Tràn dịch màng phổi: Do áp lực ổ bụng tăng, dịch lọc có thể từ khoang màng bụng di chuyển lên khoang màng phổi thông qua vị trí yếu của cơ hoành. Hầu hết xảy ra ở màng phổi phải. Điều trị triệu chứng bằng cách ngừng lọc và chọc tháo nếu cần. Điều trị nguyên nhân bằng phẫu thuật sửa cơ hoành hoặc gây dính khoang màng phổi.
Đau lưng: Áp lực ổ bụng tăng và trung tâm trọng lực chuyển ra phía trước, khiến cột sống có xu hướng ưỡn ra. Người bệnh thường bị đau lưng và đau thần kinh tọa. Để khắc phục, có thể thay dịch nhiều lần và mỗi lần ít dịch hoặc tiến hành lọc màng bụng bằng máy với lượng dịch ngâm ban ngày ít.
**Các biến chứng chuyển hóa**
Hấp thu Glucose và đái tháo đường: Một số lớn người bệnh đái tháo đường cần insulin khi lọc màng bụng, thậm chí nếu trước đó họ không cần insulin. Điều này một phần do glucose được hấp thu từ dịch lọc vào máu kết hợp với hiện tượng tăng cân. Khoảng 60-80% glucose trong dịch lọc được hấp thu trong mỗi lần thay dịch, có thể đạt tới 100-150 g/ngày. Nó có thể gây tăng insulin và triglyceride trong máu. Để giảm thiểu tình trạng hấp thu glucose, người bệnh nên hạn chế muối nước để loại bỏ nhu cầu dùng loại dịch ưu trương, đồng thời có thể lựa chọn các loại dịch khác như polyglucose hoặc amino acids
Rối loạn lipid máu: Người bệnh lọc màng bụng thường có cholesterol toàn phần và LDL cholesterol cao, HDL cholesterol thấp, apoB cao, apoA-1 thấp, triglyceride cao, lipoprotein alpha cao. Rối loạn chuyển hóa lipid là nguy cơ đáng kể gây xơ vữa đm. Người bệnh nên được điều trị bằng statin, fibrate, tránh rượu và thuốc gây tăng lipid máu, giảm thiểu nhu cầu sử dụng dịch ưu trương. 
Mất protein: Mỗi lần dẫn lưu dịch, người bệnh mất lượng protein khoảng ≥0,5g/lít, tương đương khoảng 10-20 g/ngày, đặc biệt ở người bệnh có màng vận chuyển cao hoặc trung bình cao, hoặc trong đợt VPM. Khắc phục bằng chế độ ăn để bù vào lượng protein bị mất đi.
Rối loạn điện giải và kiềm toan: tăng/giảm natri máu, tăng/giảm kali máu, tăng/giảm calci máu, tăng lactate máu. Điều trị bằng điều chỉnh chế độ ăn, lọc bằng dịch lọc bicarbonate…
**Các biến chứng khác**
Suy dinh dưỡng: Suy dinh dưỡng nhẹ-trung bình gặp ở khoảng 40% và suy dinh dưỡng trầm trọng gặp ở 8-10% người bệnh. Điều trị bằng dùng dịch lọc amino acid hoặc sử dụng một số thuốc như thuốc thúc đẩy tăng trưởng( Domperidone) hoặc steroid tăng đồng hóa( Nadrolone).
Biến chứng tim mạch: Tử vong do tim mạch ở nhóm người bệnh này vẫn rất cao. Nguyên nhân bao gồm rất nhiều yếu tố. Một vài yếu tố liên quan đến bản thân phương pháp, với sự tiến triển của màng tăng vận chuyển, sự xuất hiện viêm trong môi trường suy dinh dưỡng và xơ vữa động mạch, rối loạn chuyển hóa calci phospho và calci hóa mạch máu. 
Lọc máu không đầy đủ: Mất chức năng thận tồn dư là yếu tố quan trọng nhất gây ra lọc máu không đầy đủ. Có thể cải thiện chất lượng lọc máu bằng việc tăng số lần thay dịch hàng ngày, tăng thể tích ngâm dịch và tăng độ ưu trương của dịch lọc.
Suy siêu lọc: màng bụng phản ứng với những thay đổi để đáp ứng với môi trường mới bằng cách dày lên và tăng sinh màng đáy cả trung biểu mô cũng như mao mạch. Những thay đổi này xảy ra thứ phát do màng bụng tiếp xúc với những chất không sinh lý của dịch lọc, đồng thời cũng là hoạt động trực tiếp của glucose và các chất giáng hóa của glucose bao gồm các sản phẩm glycosyl hóa cuối cùng lên màng bụng. Điều trị tốt nhất là giảm thời gian ngâm dịch, thay dịch ban đêm bằng máy kết hợp với sử dụng dịch icodextrin ban ngày. 
**TÀI LIỆU THAM KHẢO**
Simon J. Daies, Louise Phillips, Anne M.Griffiths et al, 1998. What really happens to people on long-term peritoneal dialysis.  _Kidney Int,_ Vol.54, pp.2207-2217.
S K Mandal, Sanjiv Jasuja et al, 2009. Non infectious complicantions of peritoneal dialysis.  _Apollo medicine_. Vol 6, No.2.
Plum J, Sudkamp S, Grabensee B, 1994. Results of ultrasound-assisted diagnosis of tunnel infections in continuous ambulatory peritoneal dialysis.  _Am J Kidney Dis_. ;23(1):99-104.
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh

## ️ Chăm sóc sonde dẫn lưu tụ dịch-máu quanh thận/lần (thực hiện cho một lần)

  * [Người thực hiện](https://bvnguyentriphuong.com.vn/than-loc-mau/cham-soc-sonde-dan-luu-tu-dich-mau-quanh-thanlan-thuc-hien-cho-mot-lan#ngi-thc-hin)
  * [CÁC BƯỚC TIẾN HÀNH](https://bvnguyentriphuong.com.vn/than-loc-mau/cham-soc-sonde-dan-luu-tu-dich-mau-quanh-thanlan-thuc-hien-cho-mot-lan#cc-bc-tin-hnh)
  * [Kiểm tra người bệnh ](https://bvnguyentriphuong.com.vn/than-loc-mau/cham-soc-sonde-dan-luu-tu-dich-mau-quanh-thanlan-thuc-hien-cho-mot-lan#kim-tra-ngi-bnh)
  * [Thực hiện kỹ thuật](https://bvnguyentriphuong.com.vn/than-loc-mau/cham-soc-sonde-dan-luu-tu-dich-mau-quanh-thanlan-thuc-hien-cho-mot-lan#thc-hin-k-thut)
  * [TAI BIẾN VÀ XỬ TRÍ](https://bvnguyentriphuong.com.vn/than-loc-mau/cham-soc-sonde-dan-luu-tu-dich-mau-quanh-thanlan-thuc-hien-cho-mot-lan#tai-bin-v-x-tr)
  * [TÀI LIỆU THAM KHẢO](https://bvnguyentriphuong.com.vn/than-loc-mau/cham-soc-sonde-dan-luu-tu-dich-mau-quanh-thanlan-thuc-hien-cho-mot-lan#ti-liu-tham-kho)


### **ĐẠI CƯƠNG**
Chăm sóc dẫn lưu tụ dịch-máu quanh thận là cần thiết để dẫn lưu đảm bảo được chức năng dẫn lưu hết dịch và máu, phòng tránh biến chứng và phát hiện sớm nếu có biến chứng theo thời gian mang dẫn lưu. 
### **CHỈ ĐỊNH**
Người bệnh có dẫn lưu.
### **CHỐNG CHỈ ĐỊNH**
Không có chống chỉ định. 
### **CHUẨN BỊ**
#### **Người thực hiện**
Bác sĩ: 01 bác sĩ 
Điều dưỡng: 01 điều dưỡng
#### **Phương tiện**
Giường thực hiện thủ thuật: 01 chiếc
Bộ dây truyền huyết thanh: 01 bộ
Túi đựng nước tiểu: 01 chiếc
Dung dịch betadin sát trùng: 01 lọ
Săng vô khuẩn loại có lỗ: 01 chiếc
Nước muối sinh lý 0,9%: 500ml
Bơm tiêm 20ml: 02 chiếc
Bông băng, gạc vô trùng: 04 gói
Găng tay vô trùng: 02 đôi
#### **Người bệnh**
Người bệnh và người nhà được nghe bác sĩ giải thích kỹ về kỹ thuật và đồng ý phối hợp cùng với bác sĩ.
#### **Hồ sơ bệnh án**
Bệnh án được hoàn thiện với các thủ tục cần thiết.
### **CÁC BƯỚC TIẾN HÀNH**
#### **Kiểm tra hồ sơ**
#### **Kiểm tra người bệnh**
Đối chiếu tên, tuổi, chẩn đoán bệnh.
#### **Thực hiện kỹ thuật**
Người bệnh được theo dõi mạch, huyết áp trước khi tiến hành thủ thuật. 
Người bệnh nằm nghiêng bộc lộ bên thận dẫn lưu.
Bác sĩ rửa tay, đi găng vô trùng.
Sát trùng da vùng dẫn lưu.
Trải săng vô trùng loại có lỗ.
Sát trùng sạch vùng chân sonde.
Kiểm tra tại chỗ xem có chảy máu hoặc nhiễm trùng không; Chỉ cố định chân sonde dẫn lưu có bị đứt tuột không, nếu không còn cố định được sonde thì phải khâu lại chân sonde. 
Nối sonde dẫn lưu với bộ dây truyền và túi đựng nước tiểu.
Băng vùng chân dẫn lưu.
Cho người bệnh về giường bệnh.
### **THEO DÕI**
Các thông số sinh tồn: toàn trạng, mạch, huyết áp, nhịp thở.
Kiểm soát đau.
Theo dõi dịch số lượng, tính chất, màu sắc qua sonde dẫn lưu.
Siêu âm lại thận - tiết niệu.
### **TAI BIẾN VÀ XỬ TRÍ**
Hầu như không có tai biến nếu có chảy máu tại chỗ dẫn lưu: băng ép hoặc khâu lại vị trí dẫn lưu nếu cần thiết.
### **TÀI LIỆU THAM KHẢO**
Mark J, Hogan M, Brian D et al. (2001). “Percutaneous Nephrostomy in Children and Adolescents: Outpatient Management”. Radiology 218: pp.207 - 10.
Mosbah A, Siala A (1990). “Percutaneous nephrostomy in the treatment of Pyonephrosis. A comparative study apropos of 36 cases”. Ann Urol (Paris) 24 (4): pp.279 - 81. 
Ogg CS, Pedersen JS (1969). “Percutaneous Needle Nephrostomy”. Bristish Medical Journal 4: pp.657 - 60.
Karim SS R, Samanta S, Aich RK et al. (2010). “Percutaneous nephrostomy by direct puncture technique: An observational study”. Indial journal of Nephrology 20 (2): pp.84 - 8.
Radecka E MA (2004). “Complications associated with percutaneous nephrostomies. A retrospective study”. Acta Radiol 45 (2): pp.184 - 8.
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [Người thực hiện](https://bvnguyentriphuong.com.vn/than-loc-mau/cham-soc-sonde-dan-luu-tu-dich-mau-quanh-thanlan-thuc-hien-cho-mot-lan#ngi-thc-hin)
  * [CÁC BƯỚC TIẾN HÀNH](https://bvnguyentriphuong.com.vn/than-loc-mau/cham-soc-sonde-dan-luu-tu-dich-mau-quanh-thanlan-thuc-hien-cho-mot-lan#cc-bc-tin-hnh)
  * [Kiểm tra người bệnh ](https://bvnguyentriphuong.com.vn/than-loc-mau/cham-soc-sonde-dan-luu-tu-dich-mau-quanh-thanlan-thuc-hien-cho-mot-lan#kim-tra-ngi-bnh)
  * [Thực hiện kỹ thuật](https://bvnguyentriphuong.com.vn/than-loc-mau/cham-soc-sonde-dan-luu-tu-dich-mau-quanh-thanlan-thuc-hien-cho-mot-lan#thc-hin-k-thut)
  * [TAI BIẾN VÀ XỬ TRÍ](https://bvnguyentriphuong.com.vn/than-loc-mau/cham-soc-sonde-dan-luu-tu-dich-mau-quanh-thanlan-thuc-hien-cho-mot-lan#tai-bin-v-x-tr)
  * [TÀI LIỆU THAM KHẢO](https://bvnguyentriphuong.com.vn/than-loc-mau/cham-soc-sonde-dan-luu-tu-dich-mau-quanh-thanlan-thuc-hien-cho-mot-lan#ti-liu-tham-kho)



## ️ Chẩn đoán nguyên nhân và xử trí một số biến chứng thường gặp trong quá trình lọc máu

Có các biến chứng thường gặp: hạ huyết áp; vọp bẻ (chuột rút); buồn nôn - nôn; nhức đầu; đau ngực; đau thắt lưng; ngứa ; sốt. 
Các biến chứng ít gặp nhưng nghiêm trọng: hội chứng mất quân bình; phản ứng với màng lọc; rối loạn nhịp; chảy máu trong sọ; động kinh ; tán huyết ; thuyên tắc khí.
**BIẾN CHỨNG THƯỜNG GẶP**
HẠ HUYẾT ÁP (xem trong**“** Hướng dẫn chẩn đoán nguyên nhân và xử trí hạ huyết áp trong quá trình lọc máu”)
**VỌP BẺ (CHUỘT RÚT):** Tỷ lệ: 5 – 20%
**Nguyên nhân :**
Hạ huyết áp 
Giảm thể tích máu tuần hoàn (Người bệnh dưới trọng lượng khô)
Siêu lọc cao (tăng cân nhiều )
Nồng độ Na+ trong dịch lọc thấp.
Tình trạng Mg ++, Ca++, K+ trong máu thấp, trước khi lọc máu (chạy thận nhân tạo = CTNT). 
**Xử trí:** tương tự như trong các trường hợp hạ huyết áp
**BUỒN NÔN – NÔN:**
Nguyên nhân:
Hạ huyết áp 
Biểu hiện sớm của hội chứng mất quân bình 
Phản ứng với màng lọc: type A, type B (coi phần “phản ứng màng lọc” )
Liệt ruột ở người bệnh đái tháo đường 
**Xử trí:** như trường hợp hạ huyết áp 
Lưu ý ở người bệnh hạ huyết áp kèm theo mất ý thức có nguy cơ hít phải chất nôn.
Thuốc chống nôn: Metoclopamide 
**Phòng ngừa**
Phòng ngừa hạ huyết áp
Nếu nôn ói không phải do hạ huyết áp, dùng thuốc: Metoclopamide 
**NHỨC ĐẦU**
**Nguyên nhân:** không rõ, có thể là biểu hiện của hội chứng mất quân bình (coi thêm “Hội chứng mất quân bình”) 
Triệu chứng: dữ dội, không điển hình, lưu ý nguyên nhân thần kinh trung ương.
**Xử trí:** acétaminophen 
**ĐAU LƯNG – ĐAU NGỰC:**
Tỷ lệ: 1 - 4%
Nguyên nhân: không rõ 
Không có điều trị, phòng ngừa đặc hiệu 
Một số trường hợp: do thay đổi chủng loại màng lọc 
LƯU Ý: đây là triệu chứng của: tán huyết, thuyên tắc khí, viêm màng ngoài tim …
**NGỨA**
Là triệu chứng của người bệnh CTNT. Tăng mức độ khi CTNT.
Ngứa chỉ xảy ra khi CTNT kèm theo trịêu chứng dị ứng khác.
**+ Nguyên nhân:**
Dị ứng với màng lọc hay dây máu.
Viêm gan do thuốc hay do nhiễm virus
Lắng đọng trên da các tinh thể: Mg++, Ca++, Phospho… 
Hay do cường phó giáp trạng thứ phát 
**+ Xử trí:**
Kháng histamine 
Châm cứu hoặc chiếu tia cực tím (Ultraviolet therapy) 
Làm ẩm, trơn da.
Điều chỉnh: Ca, Phospho, PTH máu về mức bình thường 
CTNT đủ liều, dùng màng lọc High flux
**SỐT LẠNH RUN**
**Nguyên nhân** :
Nhiễm trùng, đặc biệt khi để catheter lâu ngày.
Vệ sinh kém. 
Nguồn nước không đảm bảo.
Dị ứng hóa chất tiệt trùng màng lọc.
**Xử trí** : Sử dụng kháng sinh nếu nghi ngờ có nhiễm khuẩn
**Phòng ngừa** : 
Đảm bảo vô trùng khi thao tác kỹ thuật.
Giữ vệ sinh nơi đặt catheter, không để catheter lâu ngày 
Rửa sạch màng lọc với nhiều nước.
**TẠO CỤC MÁU ĐÔNG**
**Nguyên nhân:**
Vị trí kim tiêm fistule 
Catheter tĩnh mạch trung tâm có vấn đề 
Triệu chứng:
Tăng áp lực tĩnh mạch, máy báo TMP
Máu đỏ sẫm trong dây máu hoặc trong bầu nhỏ giọt.
Fibrin xuất hiện trong bầu nhỏ giọt (dạng “sợi”)
Có thể thấy cục máu đông hoặc máu đen vón cục trong bầu nhỏ giọt hoặc quả lọc.
**Xử trí:**
Kháng đông 
**RÒ RỈ MÁU SANG NGĂN DỊCH LỌC**
**Nguyên nhân:**
Màng lọc vỡ khiến máu rò rỉ sang ngăn dịch lọc.
Triệu chứng:
Máy báo rò rỉ máu 
Test máu trong dịch lọc (+)
**Xử trí:**
Kiểm tra rò rỉ máu trong dịch lọc thải ra 
Nếu dương tính, dừng điều trị,
**Không trả máu.**
Nếu âm tính, có thể cần phải đổi máy khác.
**BIẾN CHỨNG ÍT GẶP NHƯNG NGHIÊM TRỌNG**
**HỘI CHỨNG MẤT QUÂN BÌNH**
**Nguyên nhân:** hay gặp ở người bệnh :
BUN cao nhiều khi bắt đầu CTNT.
Người bệnh lớn tuổi .
Người bệnh có tổn thương não trước đó.
Nhiễm toan chuyển hoá nặng .
Lâm sàng :
Thể trung bình : nhức đầu ,buồn nôn.
Thể nặng: người bệnh bứt rứt, không yên, huyết áp tăng cao, mất định hướng, động kinh, hôn mê, có thể tử vong.
Sinh lý bệnh:
.Phù não 
.Dịch não tủy bị toan hóa 
Xử trí:
Nhẹ: không điều trị đặc hiệu.
Nặng ( động kinh, hôn mê ):
+ Ngưng CTNT 
+ Chống động kinh: diazépam 
+ Săn sóc người bệnh hôn mê, giữ thông đường thở, có thể thở máy 
**TÁN HUYẾT**
**Nguyên nhân** : thường có liên quan đến kỹ thuật
Đường dây máu ngoài cơ thể bị vặn, xoắn, gấp… 
Bơm máu được cân chỉnh không chính xác hoặc hoạt động kém.
Áp lực âm quá mạnh trong hệ thống dây máu 
Tắc nghẽn trong bơm máu 
Vấn đề dịch lọc:
+ Dịch lọc quá nóng > 420 C
+ Dịch lọc nhược trương 
+ Dịch lọc có chứa các chất như: formaldéhyde, chất tẩy, chloramine, chất đồng, fluorite nitrate… 
Triệu chứng: 
Đau lưng, nặng ngực, thở nông, mệt, buồn nôn, nhức đầu, hạ huyết áp, thiếu máu cấp, tăng kali máu.
Máu trở về có màu nâu lợt. Huyết tương ly tâm có màu hồng.
Xử trí:
Ngưng CTNT. Không truyền trả phần máu còn ngoài cơ thể 
Xét nghiệm kiểm tra: ion đồ, toan kiềm, Hct … 
Hoãn CTNT, điều trị triệu chứng
Nếu có tăng kali máu cần CTNT lại, hoặc dùng kayexalate 
Kiểm tra toàn bộ qui trình 
Phòng ngừa :
Theo dõi sát quá trình CTNT
Định kỳ kiểm tra chất lượng nước 
**THUYÊN TẮC KHÍ**
Là biến chứng nghiêm trọng, có thể gây tử vong, nếu không được phát hiện và điều trị nhanh chóng.
**Nguyên nhân** :
Khí vào máu theo đường máu về, hoặc catheter trung tâm.
Các thao tác an toàn kiểm tra không được thực hiện: Hết túi/ chai dịch truyền, các khớp kết nối không chặt, đứt dây máu, rò khí vào dây máu 
Không trang bị cảm biến phát hiện khí 
Người bệnh hít vào khi CVC đang mở ra không khí 
**Triệu chứng** : (tùy theo tư thế)
Tư thế ngồi: Khí → máu → hệ thống TM → TM máu não → nghẽn lượng máu đỗ về tim → mất ý thức, hôn mê, co giật → tử vong .
Tư thế nằm: Khí → tim → thất phải → phổi: gây khó thở, nặng ngực, ho, rối loạn nhịp tim. Hoặc khí di chuyển xa hơn, qua mao quản phổi → thất trái → thuyên tắc khí ở tim, não cấp.
**Triệu chứng :**
+ Đau, nặng ngực, ho, tím tái, thở dốc 
+ Tim nhanh 
+ Tĩnh mạch cổ nổi 
+ Rối loạn tri giác, co giật, hôn mê, co giật nhẹ một bên người (não)
+ Có thể ngưng hô hấp tuần hoàn 
**Xử trí :**
Kẹp dây máu và dừng bơm máu.
Người bệnh nằm tư thế Trendelenburg, nghiêng trái để giữ bọt khí ở thất phải.
Điều trị nâng đỡ hô hấp tuần hoàn.
Có thể thở máy với 0xy 100% hoặc Oxy cao áp.
**PHẢN ỨNG MÀNG LỌC**
**Nguyên nhân** :
Hội chứng “sử dụng màng lọc lần đầu”
Tăng nhạy cảm với màng lọc 
**Triệu chứng:**
Hội chứng “sử dụng màng lọc lần đầu”:
+ Đau lưng 
+ Đau ngực 
+ Hạ huyết áp 
+ Ngứa 
+ Buồn nôn, cảm giác khó chịu không rõ, mơ hồ
Tăng nhạy cảm với màng lọc :
+ Lo lắng 
+ Nổi mẩn ngứa 
+ Nặng ngực, khó thở, khò khè 
+ Có thể ngưng tim 
**Chẩn đoán:**
Phản ứng type A: Hiếm gặp, biểu hiện nhanh và nặng nề, biểu hiện của sốc phản vệ, kèm theo cảm giác nóng nơi tiêm chích fistule, nhanh chóng ngưng tim thở và tử vong
+ Nguyên nhân: sử dụng Ethylene oxide để tiệt trùng quả lọc và sử dụng màng Polyacrylonitrite (PAN) đặc biệt là AN69 ở Người bệnh đang dùng ức chế men chuyển (ƯCMC)
Có 3 tiêu chuẩn chính hoặc 2 tiêu chuẩn chính và 01 tiêu chuẩn phụ:
Tiêu chuẩn chính: 
+ Biểu hiện trong v ng 20 phút khi bắt đầu lọc máu 
+ Khó thở 
+ Cảm giác nóng/ bỏng rát ở vị trí đường mạch máu hoặc khắp cơ thể 
+ Phù mạch 
Tiêu chuẩn phụ:
+ Triệu chứng lặp lại ở những lầm lọc máu sau đó khi sử dụng cùng một loại hay một nhãn hiệu quả lọc nhất định 
+ Nổi hồng ban dạng mề đay 
+ Chảy mũi hoặc chảy nước mắt 
+ Co thắt cơ bụng
Phản ứng type B: 
Xảy ra 20-40 phút sau khi bắt đầu lọc máu 
Triệu chứng chính là đau ngực và lưng, triệu chứng mất hẳn hoặc thuyên giảm ngoạn mục trong những giờ sau đó của buổi lọc máu 
Sinh bệnh học chưa rõ 
Có thể liên quan đến tình trạng hoạt hóa bổ thể 
Các dữ liệu hiện nay không ủng hộ sử dụng màng lọc tương hợp sinh học ở những người bệnh có những phản ứng type B.
**Xử trí:**
Điều trị triệu chứng và nâng đỡ 
Ngưng CTNT và trả máu, thở oxy, kháng histamine, epinephrine, corticosteroid
Có thể lọc máu trở lại sau khi ổn định các triệu chứng và sử dụng các màng lọc có tương hợp sinh học cao hơn và quả lọc tiệt trùng không sử dụng ETO (Ethylene Oxideb**.**
**Phòng ngừa** : rửa màng lọc với nhiều nước
**TÀI LIỆU THAM KHẢO:**
Richard A.Sherman, John T, 2007. Daugirdasand Todd S.Ing. Complication duringhemodialysis. In:  _Handbook of Dialysis_ , Lippicott, William & Wilkins, Philadelphia; 170-191
_Lọc máu liên tục”_ , 2013. tài liệu hướng dẫn về lọc máu ngoài cơ thể, Bệnh viện Nhân dân 115, Nhà xuất bản Y học; 214-224.
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh

## ️ Lọc màng bụng chu kỳ (CAPD) (Lọc màng bụng liên tục ngoại trú )

  * [Người thực hiện ](https://bvnguyentriphuong.com.vn/than-loc-mau/loc-mang-bung-chu-ky-capd-loc-mang-bung-lien-tuc-ngoai-tru#ngi-thc-hin)
  * [CÁC BƯỚC TIẾN HÀNH](https://bvnguyentriphuong.com.vn/than-loc-mau/loc-mang-bung-chu-ky-capd-loc-mang-bung-lien-tuc-ngoai-tru#cc-bc-tin-hnh)
  * [TAI BIẾN VÀ XỬ TRÍ](https://bvnguyentriphuong.com.vn/than-loc-mau/loc-mang-bung-chu-ky-capd-loc-mang-bung-lien-tuc-ngoai-tru#tai-bin-v-x-tr)
  * [TÀI LIỆU THAM KHẢO](https://bvnguyentriphuong.com.vn/than-loc-mau/loc-mang-bung-chu-ky-capd-loc-mang-bung-lien-tuc-ngoai-tru#ti-liu-tham-kho)


### **ĐẠI CƯƠNG**
Lọc màng bụng liên tục ngoại trú (CAPD-Continuous Ambulatory Peritoneal Dialysis) là một trong những biện pháp điều trị thay thế cho người bệnh suy thận mạn giai đoạn cuối (hay bệnh thận mạn giai đoạn cuối) có hiệu quả, đơn giản và tiết kiệm nhân lực y tế đang được thực hiện ở nhiều nước trên thế giới. Đây là phương pháp sử dụng màng bụng của chính người bệnh làm màng lọc như một màng bán thấm để đào thải một số sản phẩm chuyển hóa ra ngoài cơ thể. Một số chất như ure, creatinin và điện giải… 
Trải qua nhiều thời kỳ kỹ thuật của phương pháp đã được nhiều nhà khoa học cải tiến liên tục nhằm ứng dụng rộng rãi trên lâm sàng và giảm biến chứng.
Năm 1963 Henry Tenckhoff cùng với nhóm Boen sử dụng catheter đưa vào ổ bụng nối với túi dịch để lọc liên tục cho người bệnh tại nhà và sống được 3 năm. Năm 1976 Popovich và Moncrief đã phát triển phương pháp lọc máu này thành lọc màng bụng liên tục để lọc máu cho người bệnh tại nhà (gọi là CAPD).
### **CHỈ ĐỊNH**
Người bệnh mắc bệnh thận mạn tính giai đoạn 5 (hay suy thận mạn giai đoạn cuối) khi mức lọc cầu thận < 15ml/phút. Đặc biệt những người bệnh có các tình trạng sau: suy tim nặng, thiếu máu nặng, huyết động không ổn định, tăng huyết áp khó kiểm soát, hội chứng mất cân bằng sau lọc máu thận nhân tạo, đường vào mạch máu kém, vữa xơ mạch máu, những người bệnh ở xa trung tâm lọc máu thận nhân tạo…
### **CHỐNG CHỈ ĐỊNH**
**Chống chỉ định đối với những người bệnh mắc bệnh thận mạn giai đoạn cuối sau đây:**
Tình trạng viêm dính sau phẫu thuật ổ bụng.
Khiếm thính, khiếm thị, thiểu năng trí tuệ, rối loạn tâm thần hoặc hạn chế vận động mà không có người trợ giúp. 
Đã có can thiệp ngoại khoa ổ bụng, nội soi ổ bụng, hiện viêm phúc mạc.
Hiện đang có nhiễm trùng ngoài da, hoặc nguy cơ nhiễm trùng ngoài da cao. 
Thoát vị thành bụng, túi thừa ruột.
Rò hệ thống tiêu hóa, tử cung - phần phụ.
### **CHUẨN BỊ**
#### **Người thực hiện**
Gồm 02 kíp 
**Nhóm ngoại khoa** mổ đặt catheter vào ổ bụng 
01 bác sĩ mổ chính, 01 bác sĩ phụ mổ, 01 điều dưỡng đưa dụng cụ (thuộc phần phẫu thuật đặt catheter ổ bụng để lọc màng bụng).
**Nhóm nội khoa** điều trị và theo dõi hướng dẫn người bệnh điều trị ngoại trú tại nhà 
01 bác sĩ, 01 điều dưỡng chuyên khoa.
#### **Phương tiện**
Tên, số lượng của thiết bị, dụng cụ, vật tư tiêu hao (định hướng, ước lượng…): 
01 bộ catheter Tenckhoff chuyên dùng cho lọc màng bụng loại 2 cuff, đầu thẳng hoặc đầu cong, hoặc cổ ngỗng (có nhiều loại với giá thành khác nhau và ưu - nhược điểm khác nhau) để đặt vào ổ bụng qua phẫu thuật ổ bụng bằng phương pháp mổ mở hoặc mổ nội soi.
01 bộ dây nối transfer set nối giữa catheter và hệ thống dây và dịch lọc.
01 đầu nối giữa catheter và transferset bằng chất liệu Titanium.
Hệ thống túi đôi chứa dịch lọc 2 lít x 4 túi/ngày x 30 ngày/tháng x hàng tháng.
Các loại dịch lọc: loại 1,5%, 2,5%, 4,25% x 1500 ml - 2000 ml/túi.
#### **Người bệnh**
Được tư vấn về biện pháp điều trị, theo dõi lâu dài tự nguyện viết đơn và cam kết trước khi tiến hành phẫu thuật.
Được thông qua mổ để đặt catheter vào ổ bụng.
Được bác sĩ và điều dưỡng huấn luyện trong 2 tuần để thực hiện thành thạo các thao tác thay dịch lọc và bơm thuốc tự điều trị hàng ngày.
Được huấn luyện theo dõi và tự phát hiện, xử trí ban đầu các biến chứng đơn giản có liên quan đến quá trình lọc màng bụng tại nhà.
#### **Hồ sơ bệnh án**
Lập bệnh án theo dõi hàng tháng ngoại trú lâu dài cho người bệnh.
Lập lịch khám và xét nghiệm định kỳ hàng tháng.
Lập lịch đánh giá chất lượng và hiệu quả lọc màng bụng 6 tháng/1 lần bao gồm: PET test, Kt/V.
Kê đơn thuốc bao gồm: dịch lọc màng bụng, thuốc chống đông, kháng sinh nếu cần thiết, thuốc điều trị biến chứng của suy thận mạn (Hạ huyết áp, điều trị thiếu máu (sắt, vitamin, EPO), dự phòng loãng xương do suy thận (tiền vitamin D3). 
Chống suy dinh dưỡng (chế độ ăn uống…).
### **CÁC BƯỚC TIẾN HÀNH**
Khám lâm sàng người bệnh toàn diện: đánh giá tình trạng catheter, đường hầm dưới da, tình trạng ổ bụng, dinh dưỡng, nước tiểu tồn dư, cân bằng dịch vào - ra, huyết áp, thiếu máu…
Yêu cầu xét nghiệm cần thiết và các thăm dò cận lâm sàng cần thiết.
Y lệnh điều trị: số lượng dịch, loại dịch, thời gian lưu dịch trong ổ bụng, các thuốc phối hợp điều trị...
Giám sát người bệnh thực hiện các quy trình thay dịch, lấy dịch xét nghiệm, bơm thuốc vào dịch (nếu có).
Đánh giá tốc độ dịch chảy vào - ra ở bụng, tính chất dịch lọc, cân bằng dịch.
### **THEO DÕI**
Cân bằng dịch vào – ra.
Chất lượng dịch vào – ra.
Kết quả xét nghiệm sinh hóa, huyết học…
Diễn biến lâm sàng: sốt, đau bụng, dịch đục, tắc dịch, viêm tấy chân catheter. 
### **TAI BIẾN VÀ XỬ TRÍ**
Dịch chảy vào - ra chậm.
Rò dịch vào khoang khác (màng phổi, sau phúc mạc..).
Thủng tạng rỗng. 
Tắc catheter hoặc thay đổi vị trí catheter. Dịch đục, máu… Viêm phúc mạc.
Viêm chân catheter.
Viêm đường hầm catheter.
**Xử trí biến chứng sẽ tùy thuộc vào từng biến chứng.**
### **TÀI LIỆU THAM KHẢO**
Stegmayr B, (2006) Advantages and disadvantages of surgical placement of PD catheters with regard to other methods. Int J Artif Organs; 29: 95-100.
NKF - KDOQI (2006) Clinical Practice Guidelines for Peritoneal dialysis Adequacy . Am J Kidney Dis ; 48 (suppl) S91- S158.
Stevent Guest (2010) Handbook of Peritoneal Dialysis. 
Ram Gokal and Karl D. Nolph (1994) The Textbook of Peritoneal Dialysis.
Kluwer Academic Bublishers. 
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [Người thực hiện ](https://bvnguyentriphuong.com.vn/than-loc-mau/loc-mang-bung-chu-ky-capd-loc-mang-bung-lien-tuc-ngoai-tru#ngi-thc-hin)
  * [CÁC BƯỚC TIẾN HÀNH](https://bvnguyentriphuong.com.vn/than-loc-mau/loc-mang-bung-chu-ky-capd-loc-mang-bung-lien-tuc-ngoai-tru#cc-bc-tin-hnh)
  * [TAI BIẾN VÀ XỬ TRÍ](https://bvnguyentriphuong.com.vn/than-loc-mau/loc-mang-bung-chu-ky-capd-loc-mang-bung-lien-tuc-ngoai-tru#tai-bin-v-x-tr)
  * [TÀI LIỆU THAM KHẢO](https://bvnguyentriphuong.com.vn/than-loc-mau/loc-mang-bung-chu-ky-capd-loc-mang-bung-lien-tuc-ngoai-tru#ti-liu-tham-kho)



## ️ Chăm sóc sonde dẫn lưu bể thận qua da/lần (thực hiện chăm sóc cho một lần)

  * [Người thực hiện](https://bvnguyentriphuong.com.vn/than-loc-mau/cham-soc-sonde-dan-luu-be-than-qua-dalan-thuc-hien-cham-soc-cho-mot-lan#ngi-thc-hin)
  * [CÁC BƯỚC TIẾN HÀNH](https://bvnguyentriphuong.com.vn/than-loc-mau/cham-soc-sonde-dan-luu-be-than-qua-dalan-thuc-hien-cham-soc-cho-mot-lan#cc-bc-tin-hnh)
  * [Kiểm tra người bệnh ](https://bvnguyentriphuong.com.vn/than-loc-mau/cham-soc-sonde-dan-luu-be-than-qua-dalan-thuc-hien-cham-soc-cho-mot-lan#kim-tra-ngi-bnh)
  * [Thực hiện kỹ thuật ](https://bvnguyentriphuong.com.vn/than-loc-mau/cham-soc-sonde-dan-luu-be-than-qua-dalan-thuc-hien-cham-soc-cho-mot-lan#thc-hin-k-thut)
  * [TAI BIẾN VÀ XỬ TRÍ](https://bvnguyentriphuong.com.vn/than-loc-mau/cham-soc-sonde-dan-luu-be-than-qua-dalan-thuc-hien-cham-soc-cho-mot-lan#tai-bin-v-x-tr)
  * [TÀI LIỆU THAM KHẢO](https://bvnguyentriphuong.com.vn/than-loc-mau/cham-soc-sonde-dan-luu-be-than-qua-dalan-thuc-hien-cham-soc-cho-mot-lan#ti-liu-tham-kho)


### **ĐẠI CƯƠNG**
Chăm sóc dẫn lưu bể thận qua da nhằm mục đích đảm bảo dẫn lưu duy trì được chức năng, phòng, phát hiện và xử trí sớm các biến chứng trong thời gian mang dẫn lưu. 
### **CHỈ ĐỊNH**
Người bệnh có dẫn lưu bể thận qua da.
### **CHỐNG CHỈ ĐỊNH**
Không có chống chỉ định.
### **CHUẨN BỊ**
#### **Người thực hiện**
Bác sĩ: 01 bác sĩ thực hiện thủ thuật.
Điều dưỡng: 01 phụ giúp các bác sĩ tiến hành thủ thuật.
#### **Phương tiện**
Giường thực hiện thủ thuật: 01 chiếc
Bộ dây truyền huyết thanh: 01 bộ
Túi đựng nước tiểu: 01 chiếc
Dung dịch betadin sát trùng: 01 lọ
Săng vô khuẩn loại có lỗ: 01 chiếc
Săng vô khuẩn không có lỗ: 01 chiếc
Nước muối sinh lý 0,9%: 500 ml
Bơm tiêm 20ml: 02 chiếc
Bông băng, gạc vô trùng: 04 gói
Găng tay vô trùng: 02 đôi
#### **Người bệnh**
Người bệnh và người nhà được nghe bác sĩ giải thích kỹ về thủ thuật và đồng ý phối hợp cùng với bác sĩ. 
#### **Hồ sơ bệnh án**
Bệnh án được hoàn thiện với các thủ tục dành cho người bệnh tiến hành làm thủ thuật. 
### **CÁC BƯỚC TIẾN HÀNH**
#### **Kiểm tra hồ sơ**
Kiểm tra các xét nghiệm đã được làm. 
#### **Kiểm tra người bệnh**
Đối chiếu tên, tuổi, chẩn đoán bệnh.
#### **Thực hiện kỹ thuật**
Người bệnh được kiểm tra mạch, huyết áp trước khi tiến hành thủ thuật. 
Người bệnh được nằm nghiêng bộc lộ bên thận dẫn lưu.
Bác sĩ rửa tay, đi găng vô trùng.
Sát trùng da vùng dẫn lưu.
Trải săng vô trùng loại có lỗ.
Sát trùng sạch vùng chân sonde.
Kiểm tra chỉ cố định chân sonde dẫn lưu có bị đứt, tuột không, nếu không còn cố định được sonde thì phải khâu lại chân sonde. 
Nối sonde dẫn lưu với bộ dây truyền và túi đựng nước tiểu.
Siêu âm kiểm tra lại vị trí sonde dẫn lưu trong bể thận.
Băng vùng chân dẫn lưu.
Cho người bệnh về giường bệnh. 
### **THEO DÕI**
Các thông số sinh tồn: toàn trạng, mạch, huyết áp, nhịp thở.
Kiểm soát đau.
Theo dõi dịch số lượng, tính chất, màu sắc qua sonde dẫn lưu.
Siêu âm lại thận - tiết niệu sau 24 giờ.
Kháng sinh theo tình trạng bệnh.
### **TAI BIẾN VÀ XỬ TRÍ**
Hầu như không có tai biến nếu có chảy máu tại chỗ dẫn lưu: băng ép hoặc khâu lại vị trí dẫn lưu nếu cần thiết. 
### **TÀI LIỆU THAM KHẢO**
Mark J, Hogan M, Brian D et al. (2001). “Percutaneous Nephrostomy in Children and Adolescents: Outpatient Management”. Radiology 218: pp.207- 10.
Mosbah A, Siala A (1990). “Percutaneous nephrostomy in the treatment of Pyonephrosis. A comparative study apropos of 36 cases”. Ann Urol (Paris) 24 (4): pp.279 - 81. 
Ogg CS, Pedersen JS (1969). “Percutaneous Needle Nephrostomy”. Bristish Medical Journal 4: pp.657 - 60.
Karim SS R, Samanta S, Aich RK et al. (2010). “Percutaneous nephrostomy by direct puncture technique: An observational study”. Indial journal of Nephrology 20 (2): pp.84 - 8.
Radecka E MA (2004). “Complications associated with percutaneous nephrostomies.
A retrospective study”. Acta Radiol 45 (2): pp.184 - 8.
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [Người thực hiện](https://bvnguyentriphuong.com.vn/than-loc-mau/cham-soc-sonde-dan-luu-be-than-qua-dalan-thuc-hien-cham-soc-cho-mot-lan#ngi-thc-hin)
  * [CÁC BƯỚC TIẾN HÀNH](https://bvnguyentriphuong.com.vn/than-loc-mau/cham-soc-sonde-dan-luu-be-than-qua-dalan-thuc-hien-cham-soc-cho-mot-lan#cc-bc-tin-hnh)
  * [Kiểm tra người bệnh ](https://bvnguyentriphuong.com.vn/than-loc-mau/cham-soc-sonde-dan-luu-be-than-qua-dalan-thuc-hien-cham-soc-cho-mot-lan#kim-tra-ngi-bnh)
  * [Thực hiện kỹ thuật ](https://bvnguyentriphuong.com.vn/than-loc-mau/cham-soc-sonde-dan-luu-be-than-qua-dalan-thuc-hien-cham-soc-cho-mot-lan#thc-hin-k-thut)
  * [TAI BIẾN VÀ XỬ TRÍ](https://bvnguyentriphuong.com.vn/than-loc-mau/cham-soc-sonde-dan-luu-be-than-qua-dalan-thuc-hien-cham-soc-cho-mot-lan#tai-bin-v-x-tr)
  * [TÀI LIỆU THAM KHẢO](https://bvnguyentriphuong.com.vn/than-loc-mau/cham-soc-sonde-dan-luu-be-than-qua-dalan-thuc-hien-cham-soc-cho-mot-lan#ti-liu-tham-kho)



## ️ Chăm sóc catheter tĩnh mạch trung tâm trong lọc máu

**ĐẠI CƯƠNG**
Chăm sóc catheter tĩnh mạch trung tâm trong lọc máu nhằm đảm bảo catheter thực hiện được chức năng lưu thông dòng máu, dự phòng và phát hiện sớm những biến chứng tắc mạch, nhiễm trùng. Không được sử dụng catherter lọc máu cho mục đích tiêm, truyền thuốc, hỗ trợ dinh dưỡng hoặc lấy máu làm xét nghiệm. 
**CHỈ ĐỊNH**
Người bệnh có catheter tĩnh mạch trung tâm cho lọc máu.
**CHỐNG CHỈ ĐỊNH**
Không có chống chỉ định. 
**CHUẨN BỊ**
Người thực hiện.
Bác sĩ: 01 bác sĩ.
Điều dưỡng: 01 điều dưỡng.
**Phương tiện**
Giường thực hiện thủ thuật: 01 chiếc.
Bàn đựng dụng cụ thủ thuật: 01 chiếc.
Dung dịch betadin sát trùng: 01 lọ.
Săng vô khuẩn loại có lỗ: 01 chiếc.
Bông băng, gạc vô trùng: 04 gói.
Găng tay vô trùng: 02 đôi.
**Người bệnh**
Người bệnh được nghe bác sĩ giải thích quy trình chăm sóc catheter và ký vào giấy cam kết đồng ý làm thủ thuật.
**Hồ sơ bệnh án**
Bệnh án được hoàn thiện với các thủ tục dành cho người bệnh tiến hành làm thủ thuật. 
**CÁC BƯỚC TIẾN HÀNH**
**Kiểm tra hồ sơ**
**Kiểm tra người bệnh**
**Thực hiện kỹ thuật**
Người bệnh được kiểm tra mạch, huyết áp. 
Người bệnh được nằm ngửa, đầu nghiêng tư thế Trendelenburg, đầu quay 45o về phía đối diện.
Bác sĩ rửa tay, đi găng vô trùng.
Trải săng vô trùng loại có lỗ.
Tháo băng catheter.
Sát trùng sạch vùng chân catheter.
Kiểm tra chỉ cố định chân catheter có bị đứt tuột không, nếu không còn cố định được catheter thì phải khâu lại chân catheter.
Băng vùng chân catheter.
Cho người bệnh về giường bệnh. 
**THEO DÕI**
Các thông số sinh tồn: toàn trạng, mạch, huyết áp, nhịp thở.
Kiểm soát đau.
**TAI BIẾN VÀ XỬ TRÍ**
Hầu như không có tai biến nếu có chảy máu tại chỗ: băng ép hoặc khâu lại chân catheter nếu cần thiết.
**TÀI LIỆU THAM KHẢO**
Scott O. Trerotola. 2000. Hemodialysis Catheter Placement and Management. Radiology: 215:651-658. 
Julie AG, Alan DK. 2012. Ultrasound-Guided Central vein Cannulation: Current recommendations and guideline. Anesthesiology News. June: 1-6. 
Gibbs FJ, Murphy MC. 2006. Ultrasound Guidance for Central venous catheter placement. Hospital physician. March: 23-31. 
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh

## ️ Lọc máu cấp cứu bằng kỹ thuật thận nhân tạo (Thận nhân tạo cấp cứu - Acute Hemodialyse)

  * [Người thực hiện ](https://bvnguyentriphuong.com.vn/than-loc-mau/loc-mau-cap-cuu-bang-ky-thuat-than-nhan-tao-than-nhan-tao-cap-cuu-acute-hemodialyse#ngi-thc-hin)
  * [Người bệnh và người nhà người bệnh ](https://bvnguyentriphuong.com.vn/than-loc-mau/loc-mau-cap-cuu-bang-ky-thuat-than-nhan-tao-than-nhan-tao-cap-cuu-acute-hemodialyse#ngi-bnh-v-ngi-nh-ngi-bnh)
  * [CÁC BƯỚC TIẾN HÀNH](https://bvnguyentriphuong.com.vn/than-loc-mau/loc-mau-cap-cuu-bang-ky-thuat-than-nhan-tao-than-nhan-tao-cap-cuu-acute-hemodialyse#cc-bc-tin-hnh)
  * [Đường vào mạch máu](https://bvnguyentriphuong.com.vn/than-loc-mau/loc-mau-cap-cuu-bang-ky-thuat-than-nhan-tao-than-nhan-tao-cap-cuu-acute-hemodialyse#ng-vo-mch-mu)
  * [Đường tĩnh mạch đùi: đặt catheter theo kỹ thuật Seldinger.](https://bvnguyentriphuong.com.vn/than-loc-mau/loc-mau-cap-cuu-bang-ky-thuat-than-nhan-tao-than-nhan-tao-cap-cuu-acute-hemodialyse#ng-tnh-mch-i-t-catheter-theo-k-thut-seldinger)
  * [Đường tĩnh mạch dưới đòn](https://bvnguyentriphuong.com.vn/than-loc-mau/loc-mau-cap-cuu-bang-ky-thuat-than-nhan-tao-than-nhan-tao-cap-cuu-acute-hemodialyse#ng-tnh-mch-di-n)
  * [Đường tĩnh mạch cảnh trong](https://bvnguyentriphuong.com.vn/than-loc-mau/loc-mau-cap-cuu-bang-ky-thuat-than-nhan-tao-than-nhan-tao-cap-cuu-acute-hemodialyse#ng-tnh-mch-cnh-trong)
  * [Thiết lập vòng tuần hoàn ngoài cơ thể](https://bvnguyentriphuong.com.vn/than-loc-mau/loc-mau-cap-cuu-bang-ky-thuat-than-nhan-tao-than-nhan-tao-cap-cuu-acute-hemodialyse#thit-lp-vng-tun-hon-ngoi-c-th)
  * [CÁC PHƯƠNG PHÁP LỌC MÁU CẤP CỨU](https://bvnguyentriphuong.com.vn/than-loc-mau/loc-mau-cap-cuu-bang-ky-thuat-than-nhan-tao-than-nhan-tao-cap-cuu-acute-hemodialyse#cc-phng-php-lc-mu-cp-cu)
  * [Lọc máu cấp cứu ngắt quãng](https://bvnguyentriphuong.com.vn/than-loc-mau/loc-mau-cap-cuu-bang-ky-thuat-than-nhan-tao-than-nhan-tao-cap-cuu-acute-hemodialyse#lc-mu-cp-cu-ngt-qung)
  * [Lọc máu cấp cứu liên tục](https://bvnguyentriphuong.com.vn/than-loc-mau/loc-mau-cap-cuu-bang-ky-thuat-than-nhan-tao-than-nhan-tao-cap-cuu-acute-hemodialyse#lc-mu-cp-cu-lin-tc)
  * [TAI BIẾN VÀ XỬ TRÍ](https://bvnguyentriphuong.com.vn/than-loc-mau/loc-mau-cap-cuu-bang-ky-thuat-than-nhan-tao-than-nhan-tao-cap-cuu-acute-hemodialyse#tai-bin-v-x-tr)
  * [Tai biến xảy ra trong buổi lọc máu](https://bvnguyentriphuong.com.vn/than-loc-mau/loc-mau-cap-cuu-bang-ky-thuat-than-nhan-tao-than-nhan-tao-cap-cuu-acute-hemodialyse#tai-bin-xy-ra-trong-bui-lc-mu)
  * [Cơn tăng huyết áp ](https://bvnguyentriphuong.com.vn/than-loc-mau/loc-mau-cap-cuu-bang-ky-thuat-than-nhan-tao-than-nhan-tao-cap-cuu-acute-hemodialyse#cn-tng-huyt-p)
  * [Rối loạn nhịp tim](https://bvnguyentriphuong.com.vn/than-loc-mau/loc-mau-cap-cuu-bang-ky-thuat-than-nhan-tao-than-nhan-tao-cap-cuu-acute-hemodialyse#ri-lon-nhp-tim)
  * [Nôn và buồn nôn ](https://bvnguyentriphuong.com.vn/than-loc-mau/loc-mau-cap-cuu-bang-ky-thuat-than-nhan-tao-than-nhan-tao-cap-cuu-acute-hemodialyse#nn-v-bun-nn)
  * [Các tai biến khác ](https://bvnguyentriphuong.com.vn/than-loc-mau/loc-mau-cap-cuu-bang-ky-thuat-than-nhan-tao-than-nhan-tao-cap-cuu-acute-hemodialyse#cc-tai-bin-khc)
  * [Ngoài ra cần lưu ý tới các tai biến sau](https://bvnguyentriphuong.com.vn/than-loc-mau/loc-mau-cap-cuu-bang-ky-thuat-than-nhan-tao-than-nhan-tao-cap-cuu-acute-hemodialyse#ngoi-ra-cn-lu-ti-cc-tai-bin-sau)
  * [Lọc máu cấp cứu ngắt quãng](https://bvnguyentriphuong.com.vn/than-loc-mau/loc-mau-cap-cuu-bang-ky-thuat-than-nhan-tao-than-nhan-tao-cap-cuu-acute-hemodialyse#lc-mu-cp-cu-ngt-qung)
  * [Lọc máu cấp cứu liên tục](https://bvnguyentriphuong.com.vn/than-loc-mau/loc-mau-cap-cuu-bang-ky-thuat-than-nhan-tao-than-nhan-tao-cap-cuu-acute-hemodialyse#lc-mu-cp-cu-lin-tc)
  * [TÀI LIỆU THAM KHẢO](https://bvnguyentriphuong.com.vn/than-loc-mau/loc-mau-cap-cuu-bang-ky-thuat-than-nhan-tao-than-nhan-tao-cap-cuu-acute-hemodialyse#ti-liu-tham-kho)


### **ĐẠI CƯƠNG**
Lọc máu là sự trao đổi qua màng bán thấm các chất hòa tan trong máu người bệnh suy thận cấp hoặc ngộ độc với dịch lọc thận có thành phần điện giải gần giống với thành phần huyết tương.
Lọc máu cấp cửu phải được tiến hành khẩn trương, đôi khi được thực hiện ngay lập tức song song với chẩn đoán nguyên nhân nhằm:
Thay thế tạm thời chức năng thận bị suy giảm đột ngột.
Điều chỉnh hay dự phòng các biểu hiện của hội chứng ure máu cao.
Đảm bảo duy trì huyết động cho tới giai đoạn hồi phục chức năng thận.
### **CHỈ ĐỊNH**
Suy thận cấp
Nồng độ ure máu vượt quá 30mmol/l, kèm theo tăng kali máu.
Quá tải muối-nước nặng.
Rối loạn chuyển hóa acid-base nặng. Hội chứng gan thận.
Các trường hợp ngộ độc thuốc Thuốc ngủ (barbiturat)…
Suy thận mạn
Đợt cấp của suy thận mạn.
Suy thận mạn giai đoạn cuối diễn biến đột ngột nên chưa kịp chỉ định nối thông động-tĩnh mạch. Các buổi lọc máu đầu tiên phải sử dụng đường vào mạch máu tạm thời.
### **CHỐNG CHỈ ĐỊNH**
Không có chống chỉ định tuyệt đối. Cần cân nhắc thận trọng trong các trường hợp:
Xuất huyết não.
Rối loạn huyết động, nhất là khi huyết áp quá thấp.
### **CHUẨN BỊ**
#### **Người thực hiện**
Bác sĩ, điều dưỡng chuyên khoa được đào tạo về kỹ thuật.
#### **Phương tiện**
Máy thận nhân tạo.
Dịch lọc thận.
Hệ thống xử lý nước.
Các vật liệu tiêu hao: quả lọc thận, dây máu, kim chọc F.A.V, ống thông tĩnh mạch đùi hay ống thông Canaud.
Các loại thuốc chống đông máu: heparin hay các loại heparin có trọng lượng phân tử thấp.
#### **Người bệnh và người nhà người bệnh**
Được giải thích về bệnh và kỹ thuật lọc máu.
#### **Hồ sơ bệnh án**
Theo quy định.
### **CÁC BƯỚC TIẾN HÀNH**
#### **Đường vào mạch máu**
##### _Đường tĩnh mạch đùi: đặt catheter theo kỹ thuật Seldinger._
**Ưu điểm:**
Dễ thực hiện, rất phù hợp với lọc máu cấp cứu.
Đảm bảo lưu lượng máu tốt.
**Tai biến thường gặp:**
Tụ máu do chọc nhầm vào động mạch đùi.
Gây thông động - tĩnh mạch đùi.
Không lưu catheter được lâu ngày vì dễ bị tắc mạch và nhất là nhiễm khuẩn.
##### _Đường tĩnh mạch dưới đòn_
**Ưu điểm:**
Cố định catheter tốt.
Chăm sóc, theo dõi tại chỗ đặt catheter dễ dàng.
**Tai biến thường gặp:**
Đôi khi gây các tai biến nặng: tràn khí, tràn máu màng phổi.
Tắc mạch và chít hẹp tĩnh mạch dưới đòn gây nên hội chứng cánh tay to làm ảnh hưởng chức năng vận động và thẩm mỹ.
Nhiễm khuẩn.
##### _Đường tĩnh mạch cảnh trong_
**Ưu điểm:**
Ít tai biến khi đặt catheter.
Ít gây tắc mạch và hầu như không gây chít hẹp tĩnh mạch.
**Tai biến:** nhiễm khuẩn.
#### Thiết lập vòng tuần hoàn ngoài cơ thể
**Bước 1:** Lắp bộ lọc thận.
**Bước 2:** Đuổi hơi.
**Bước 3:** Kiểm tra hoạt động và an toàn của vòng tuần hoàn ngoài cơ thể.
**Bước 4:** Lắp người bệnh với vòng tuần hoàn ngoài cơ thể, theo thứ tự:
Bơm heparin liều tấn công.
Đặt heparin duy trì nếu sử dụng phương pháp liên tục.
Đặt bơm máu với tốc độ 100 ml/phút.
Khi máu đến bầu tĩnh mạch, nối dây tĩnh mạch với kim FAV tĩnh mạch.
Kiểm tra và điều chỉnh các thông số: tốc độ máu, hệ số siêu lọc, thời gian lọc máu…
Theo dõi trong buổi lọc máu
Kết thúc lọc máu
Ghi đầy đủ số liệu có trong phiếu theo dõi lọc máu
### **CÁC PHƯƠNG PHÁP LỌC MÁU CẤP CỨU**
#### **Lọc máu cấp cứu ngắt quãng**
Tiến hành các buổi lọc máu kéo dài từ 4-6 giờ.
Các thông số kỹ thuật lọc máu:
Đường vào mạch máu tạm thời.
Lưu lượng máu 200-300ml/phút (tùy tình trạng người bệnh).
Dịch lọc thận bicarbonat và lưu lượng dịch lọc 500 ml/phút.
#### **Lọc máu cấp cứu liên tục**
Lọc phương pháp lọc máu liên tục kéo dài sử dụng cho cấp cứu để tránh các thay đổi chuyển hóa và huyết động đột ngột. Có thể chọn một trong các phương pháp sau:
Siêu lọc máu động-tĩnh mạch liên tục chậm.
Siêu lọc máu động-tĩnh mạch liên tục.
Siêu lọc thẩm tách máu liên tục.
Siêu lọc kết hợp với siêu lọc thẩm tách máu liên tục. Lọc máu liên tục tốc độ thấp.
### **TAI BIẾN VÀ XỬ TRÍ**
#### **Tai biến xảy ra trong buổi lọc máu**
##### _Giảm huyết áp_
Ngừng siêu lọc, giảm tốc độ máu, cho người bệnh nằm tư thế đầu thấp, phục hồi lại thể tích tuần hoàn bằng truyền dung dịch đẳng trương, ưu trương hay albumin.
##### Cơn tăng huyết áp 
Sử dụng các thuốc hạ huyết áp đường uống, trường hợp cấp cứu sử dụng đường tiêm hoặc truyền tĩnh mạch (Loxen, nipride).
##### _Rối loạn nhịp tim_
Ngoại tâm thu thất: xylocain 1% 5-10 ml tiêm tĩnh mạch.
Nhịp chậm: atropin 1-2mg tiêm tĩnh mạch, nếu không đỡ truyền tĩnh mạch Isuprel (1-2 mg trong 500ml).
Lấy máu làm xét nghiệm điện giải và theo dõi người bệnh trên monitor (kiểm tra xem có hạ kali máu).
##### _Cơn chuột rút_
Giảm siêu lọc, dùng NaCl ưu trương 10%, 20% tiêm tĩnh mạch.
##### _Đau đầu_
Xử lí tùy nguyên nhân gây đau đầu.
##### _Mất máu_
Nếu do đông vòng tuần hoàn ngoài cơ thể, chỉ định truyền máu cấp cứu.
##### _Sốt và rét run_
Thuốc hạ sốt, chống dị ứng và tìm nguyên nhân.
##### _Cơn đau ngực_
Nếu do giảm thể tích máu: truyền máu.
Căn nguyên mạch vành: thuốc giãn mạch vành.
##### _Ngừng tim_
Xoa bóp tim ngoài lồng ngực, thở oxy, dùng các thuốc nâng huyết áp.
##### _Nôn và buồn nôn_
Tìm nguyên nhân để điều trị.
##### _Các tai biến khác_
Đông vòng tuần hoàn ngoài cơ thể, dị ứng, co giật, tắc mạch do hơi, phù phổi cấp,…
#### **Ngoài ra cần lưu ý tới các tai biến sau**
##### _Lọc máu cấp cứu ngắt quãng_
Hội chứng mất cân bằng: Điều chỉnh nước điện giải.
Các tai biến của đường vào mạch máu: băng ép.
Mỗi buổi lọc mất khoảng 10-13 gam acid amin và mất khoảng 30g glucose. Chỉ định truyền các dung dịch acid amin (Nephrosteril) và các dung dịch glucose ưu trương 10%, 20%, 30%.
##### _Lọc máu cấp cứu liên tục_
Ngoài các tai biến như lọc máu cấp cứu ngắt quãng, lọc máu liên tục gây ra một số phức tạp về kỹ thuật và phiền hà cho người bệnh như:
Đòi hỏi các phương tiện, máy móc đắt tiền. Cần nhiều dịch truyền.
Phải theo dõi liên tục thuốc chống đông máu, điện giải đồ máu.
Theo dõi liên tục, chặt chẽ đường vào mạch máu.
Người bệnh phải nằm lâu.
### **TÀI LIỆU THAM KHẢO**
Nguyễn Nguyên Khôi, Trần Văn Chất (2004) “Thận nhân tạo” Bệnh học nội khoa, Nhà xuất bản Y học, Tr.250 - 260.
Edward T. Zawada, Jr. (2001) “Initiation of Dialysis” Handbook of Dialysis, Third Edition, P.3 -11.
John T. Daugirdas, Edward A. Ross, and Allen R. Nissenson “Acute Hemodialysis Prescription: A Urea Kinetic Approach” Handbook of Dialysis, Third Edition, P.102 - 120.
Harold Bregman, John T. Daugirdas, and Todd S. Ing “Complications During Hemodialysis” Handbook of Dialysis, Third Edition, P.148 - 168.
Joachim Hertel, Dawn M. Keep, and Ralph J. Caruana “Anticoagulation” Handbook of Dialysis, Third Edition, P.182 - 198.
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [Người thực hiện ](https://bvnguyentriphuong.com.vn/than-loc-mau/loc-mau-cap-cuu-bang-ky-thuat-than-nhan-tao-than-nhan-tao-cap-cuu-acute-hemodialyse#ngi-thc-hin)
  * [Người bệnh và người nhà người bệnh ](https://bvnguyentriphuong.com.vn/than-loc-mau/loc-mau-cap-cuu-bang-ky-thuat-than-nhan-tao-than-nhan-tao-cap-cuu-acute-hemodialyse#ngi-bnh-v-ngi-nh-ngi-bnh)
  * [CÁC BƯỚC TIẾN HÀNH](https://bvnguyentriphuong.com.vn/than-loc-mau/loc-mau-cap-cuu-bang-ky-thuat-than-nhan-tao-than-nhan-tao-cap-cuu-acute-hemodialyse#cc-bc-tin-hnh)
  * [Đường vào mạch máu](https://bvnguyentriphuong.com.vn/than-loc-mau/loc-mau-cap-cuu-bang-ky-thuat-than-nhan-tao-than-nhan-tao-cap-cuu-acute-hemodialyse#ng-vo-mch-mu)
  * [Đường tĩnh mạch đùi: đặt catheter theo kỹ thuật Seldinger.](https://bvnguyentriphuong.com.vn/than-loc-mau/loc-mau-cap-cuu-bang-ky-thuat-than-nhan-tao-than-nhan-tao-cap-cuu-acute-hemodialyse#ng-tnh-mch-i-t-catheter-theo-k-thut-seldinger)
  * [Đường tĩnh mạch dưới đòn](https://bvnguyentriphuong.com.vn/than-loc-mau/loc-mau-cap-cuu-bang-ky-thuat-than-nhan-tao-than-nhan-tao-cap-cuu-acute-hemodialyse#ng-tnh-mch-di-n)
  * [Đường tĩnh mạch cảnh trong](https://bvnguyentriphuong.com.vn/than-loc-mau/loc-mau-cap-cuu-bang-ky-thuat-than-nhan-tao-than-nhan-tao-cap-cuu-acute-hemodialyse#ng-tnh-mch-cnh-trong)
  * [Thiết lập vòng tuần hoàn ngoài cơ thể](https://bvnguyentriphuong.com.vn/than-loc-mau/loc-mau-cap-cuu-bang-ky-thuat-than-nhan-tao-than-nhan-tao-cap-cuu-acute-hemodialyse#thit-lp-vng-tun-hon-ngoi-c-th)
  * [CÁC PHƯƠNG PHÁP LỌC MÁU CẤP CỨU](https://bvnguyentriphuong.com.vn/than-loc-mau/loc-mau-cap-cuu-bang-ky-thuat-than-nhan-tao-than-nhan-tao-cap-cuu-acute-hemodialyse#cc-phng-php-lc-mu-cp-cu)
  * [Lọc máu cấp cứu ngắt quãng](https://bvnguyentriphuong.com.vn/than-loc-mau/loc-mau-cap-cuu-bang-ky-thuat-than-nhan-tao-than-nhan-tao-cap-cuu-acute-hemodialyse#lc-mu-cp-cu-ngt-qung)
  * [Lọc máu cấp cứu liên tục](https://bvnguyentriphuong.com.vn/than-loc-mau/loc-mau-cap-cuu-bang-ky-thuat-than-nhan-tao-than-nhan-tao-cap-cuu-acute-hemodialyse#lc-mu-cp-cu-lin-tc)
  * [TAI BIẾN VÀ XỬ TRÍ](https://bvnguyentriphuong.com.vn/than-loc-mau/loc-mau-cap-cuu-bang-ky-thuat-than-nhan-tao-than-nhan-tao-cap-cuu-acute-hemodialyse#tai-bin-v-x-tr)
  * [Tai biến xảy ra trong buổi lọc máu](https://bvnguyentriphuong.com.vn/than-loc-mau/loc-mau-cap-cuu-bang-ky-thuat-than-nhan-tao-than-nhan-tao-cap-cuu-acute-hemodialyse#tai-bin-xy-ra-trong-bui-lc-mu)
  * [Cơn tăng huyết áp ](https://bvnguyentriphuong.com.vn/than-loc-mau/loc-mau-cap-cuu-bang-ky-thuat-than-nhan-tao-than-nhan-tao-cap-cuu-acute-hemodialyse#cn-tng-huyt-p)
  * [Rối loạn nhịp tim](https://bvnguyentriphuong.com.vn/than-loc-mau/loc-mau-cap-cuu-bang-ky-thuat-than-nhan-tao-than-nhan-tao-cap-cuu-acute-hemodialyse#ri-lon-nhp-tim)
  * [Nôn và buồn nôn ](https://bvnguyentriphuong.com.vn/than-loc-mau/loc-mau-cap-cuu-bang-ky-thuat-than-nhan-tao-than-nhan-tao-cap-cuu-acute-hemodialyse#nn-v-bun-nn)
  * [Các tai biến khác ](https://bvnguyentriphuong.com.vn/than-loc-mau/loc-mau-cap-cuu-bang-ky-thuat-than-nhan-tao-than-nhan-tao-cap-cuu-acute-hemodialyse#cc-tai-bin-khc)
  * [Ngoài ra cần lưu ý tới các tai biến sau](https://bvnguyentriphuong.com.vn/than-loc-mau/loc-mau-cap-cuu-bang-ky-thuat-than-nhan-tao-than-nhan-tao-cap-cuu-acute-hemodialyse#ngoi-ra-cn-lu-ti-cc-tai-bin-sau)
  * [Lọc máu cấp cứu ngắt quãng](https://bvnguyentriphuong.com.vn/than-loc-mau/loc-mau-cap-cuu-bang-ky-thuat-than-nhan-tao-than-nhan-tao-cap-cuu-acute-hemodialyse#lc-mu-cp-cu-ngt-qung)
  * [Lọc máu cấp cứu liên tục](https://bvnguyentriphuong.com.vn/than-loc-mau/loc-mau-cap-cuu-bang-ky-thuat-than-nhan-tao-than-nhan-tao-cap-cuu-acute-hemodialyse#lc-mu-cp-cu-lin-tc)
  * [TÀI LIỆU THAM KHẢO](https://bvnguyentriphuong.com.vn/than-loc-mau/loc-mau-cap-cuu-bang-ky-thuat-than-nhan-tao-than-nhan-tao-cap-cuu-acute-hemodialyse#ti-liu-tham-kho)



## ️ Lọc huyết tương sử dụng 2 quả lọc (quả lọc kép)

**ĐẠI CƯƠNG**
Là một biện pháp lọc máu mà huyết tương sau khi được tách ra qua màng lọc thứ nhất được đi qua màng lọc thứ hai với kích cỡ lỗ nhỏ, các protein có trọng lượng phân tử cao sẽ bị giữ lại, các chất có trọng lượng phân tử thấp bao gồm cả albumin sẽ đi qua và quay trở về người bệnh, trong một vài trường hợp có thể bù lại một phần nhỏ albumin bị mất trong quá trình lọc.
Lọc huyết tương theo phương pháp này có chọn lọc, tùy thuộc vào từng bệnh lý và mục đích điều trị mà lựa chọn quả lọc có kích cỡ lỗ màng tương ứng. 
**CHỈ ĐỊNH**
Được dùng để loại bỏ các chất có hại trong huyết tương như các phức hợp miễn dịch trong hội chứng Guillain-Barré, nhược cơ, các bệnh hệ thống như lupus ban đỏ hệ thống… 
Loại bỏ các chất có trọng lượng phân tử cao như LDL-Cholesterol trong huyết tương ở các bệnh rối loạn lipid máu … 
Suy gan cấp.
Trong các bệnh bất đồng nhóm máu mẹ con, tắc mạch do xơ cứng động mạch, trước và sau ghép thận…
**CHỐNG CHỈ ĐỊNH**
Rối loạn đông máu nặng.
**CHUẨN BỊ**
**Người thực hiện**
Bác sĩ chuyên khoa: 01.
Điều dưỡng chuyên khoa: 01.
Kỹ thuật viên chuyên khoa: 01.
**Phương tiện**
Hệ thống máy lọc - thay huyết tương: 01.
Catheter 2 nòng để lọc máu: 01 cái.
Quả lọc huyết tương (màng lọc) 1: 01.
Quả lọc huyết tương (màng lọc ) 2: 01.
Bộ dây lọc máu tương thích với máy và 2 quả lọc: 01 bộ.
Phin lọc khí: 04 cái.
Bơm kim tiêm 10ml: 02 cái.
Bơm kim tiêm 20ml: 02 cái.
Găng vô trùng: 04 đôi.
Albumin 20%: tùy theo mức độ thiếu hụt của người bệnh.
Nước muối sinh lý (%o) 1000ml: 03 chai.
Thuốc chống đông heparin 25000 UI: 01 lọ.
Gạc vô trùng: 02 gói.
Túi nhựa thải huyết tương: 02 túi.
**Người bệnh**
Người bệnh và người nhà người bệnh được giải thích rõ về phương pháp điều trị.
Ký cam kết trước làm thủ thuật.
**Hồ sơ bệnh án**
Hồ sơ bệnh án đầy đủ thủ tục hành chính.
Đủ xét nghiệm cần thiết trước khi tiến hành: công thức máu, chức năng gan thận, điện giải đồ Na, K, Cl, Ca, đông máu cơ bản, các xét nghiệm miễn dịch tùy theo yêu cầu của bệnh.
**CÁC BƯỚC TIẾN HÀNH**
**Kiểm tra hồ sơ**
Đủ các nội dung theo yêu cầu.
**Kiểm tra người bệnh**
Khám lâm sàng chung, mạch, HA, nhịp thở, nhiệt độ, số lượng nước tiểu. 
**Thực hiện kỹ thuật**
Đặt catheter lọc máu vào TM bẹn hoặc cảnh (có thể đặt trước).
Chuẩn bị máy- test. 
Lắp bộ lọc và rửa hệ thống dây quả bằng dung dịch NaCl 9% có pha Heparin dự phòng tắc quả lọc.
Chuẩn bị albumin 20 % để bổ sung. Số lượng tùy thuộc vào cân nặng từng người bệnh, trung bình 2000ml. 
Tiến hành lọc huyết tương theo lập trình trên máy. Đặt chế độ lọc.
**THEO DÕI**
Theo dõi tình trạng chung của người bệnh, mạch, HA, nhiệt độ, nhịp thở, tình trạng chảy máu…
Theo dõi số lượng, màu sắc huyết tương được lọc ra.
**TAI BIẾN VÀ XỬ TRÍ**
Tai biến có thể gặp: dị ứng màng lọc, tắc màng lọc, rách màng lọc, chảy máu, nhiễm trùng, tắc mạch…
Xử trí tùy vào từng trường hợp cụ thể có biện pháp xử trí phù hợp.
**TÀI LIỆU THAM KHẢO**
Liu et al. (2011) Successful treatment of patients with systemic lupus erythematosus complicated with autoimmune thyroid disease using double- filtration plasmaphersis: a retrospective study. . J clin Aphen. 26: 174 - 80, 
Klingel et al. (2004) Lipidfiltration- safe and effective methodology to perform lipid - apheresis. Transfusion and Apheresis science, 30: 245 - 254, 
Higgins R. et al. (2010) Double filtration plasmapheresis in antibody- incompatible kidney transplantation . Ther Apher Dial Aug 1, 14 (4)392-399
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh

## ️ Lọc máu bằng kỹ thuật thẩm tách siêu lọc dịch bù trực tiếp từ dịch lọc

**ĐẠI CƯƠNG**
Người bệnh được lọc máu kéo dài sẽ xuất hiện nhiều các biến chứng do kỹ thuật lọc máu thông thường (HD) không đào thải được hoặc đào thải rất ít các chất có trọng lượng phân tử trung bình, chất lượng cuộc sống người bệnh giảm. Kỹ thuật HDF-Online khắc phục được phần lớn vấn đề này, mức làm sạch máu tăng lên, giảm các biến chứng do lọc máu lâu năm. Kỹ thuật này ở một số nước tiên tiến đã trở thành thường quy, một số nước khác áp dụng bổ sung.
**CHỈ ĐỊNH**
Ở các nước phát triển: thường quy 3 lần/ tuần như HD thông thường.
_Ở các nước do điều kiện kỹ thuật không thể áp dụng như vậy nên HDF-Online được áp dụng trong một số trường hợp sau:_
Tăng phospho máu.
Suy dinh dưỡng.
Thiếu máu.
Các biến chứng nhiễm trùng.
Đau khớp, ngứa, mất ngủ.
Amyloidosis.
Bệnh lý tim mạch.
Các biến chứng thần kinh.
Lọc máu cấp cứu trong một số trường hợp huyết động không cố định, cần lọc các cytokin…
**CHỐNG CHỈ ĐỊNH**
Không có chống chỉ định tuyệt đối.
Lưu ý trong một số trường hợp người bệnh có nguy cơ chảy máu… như HD thường quy.
**CÁC BƯỚC TIẾN HÀNH**
**Chuẩn bị người bệnh**
**Bác sĩ khám bệnh:**
Khám toàn thân, kiểm tra huyết áp, xác định cân khô… Kiểm tra các xét nghiệm và các thăm dò gần nhất.
Ra các y lệnh điều trị: số cân rút trong buổi lọc máu, tốc độ máu, bù dịch trước hoặc sau màng, số lượng dịch bù, tốc độ dịch lọc, quả lọc, thời gian lọc máu…
Người bệnh sẵn sàng lọc máu, điều dưỡng sát trùng vùng chọc kim.
**Chuẩn bị máy lọc máu**
Máy: thẩm tách siêu lọc (5008S, Fresenius 4008S-Plus,…).
Quả lọc: có hệ số siêu lọc cao (HF 80S, HF 60S,…). 
K0A Urea: 805 ml/phút.
Hệ số siêu lọc UF Coefficient: 55 ml/giờ/mmHg.
Hệ số dây S: Sieving coefficient β2M: 0,65.
Diện tích màng: 1,8 m2.
Chất liệu polysulfone.
Khởi động máy.
Nhúng dịch.
Lắp quả lọc, dây máu.
Đặt các thông số theo y lệnh: UF, vào các dữ kiện (Hematocrit, đặt cân khô, chiều cao, tuổi, giới…).
Đặt online: bù dịch trước màng hoặc sau màng, đặt tốc độ dịch bù.
Sau khi T1 Test hoàn thành → lắp cổng online, lắp 2 cổng dịch vào quả lọc.
Bấm nút Start, máy tự động đuổi khí ở quả lọc, lớp bơm tiêm chống đông.
Tiến hành thủ thuật chọc kim vào cầu nối người bệnh. Kim lấy máu ra hướng về miệng nối. Kim đưa máu vào cơ thể hướng về tim người bệnh.
Kết thúc đuổi khí. Bơm máu sẽ tự về tốc độ 50 ml/phút. Nhấm vào nút Blood Pump, và thực hiện các kết nối online, kết nối các đường máu, bơm chống đông.
Theo dõi các thông số trong buổi lọc.
Sau 4 giờ, kết thúc buổi lọc, trả máu về cho người bệnh.
Sát trùng máy.
Dịch lọc máu (Dịch Bicarbonate): Thành phần gồm dịch 1B và 2A.
**Kydheamo****- 1B:** Mỗi lít dung dịch chứa:
Natribicarbonat 84g.
Nước cất pha tiêm vừa đủ 1000 ml.
**Kydheamo****- 2A:** Mỗi lít dung dịch chứa:
Natriclorid 210,7g Kaliclorid 5,222g
Calciclorid 2H2O 9,000g.
Magnesiclorid 6H2O 3,558g. 
Acid acetic 6,310g.
Dextrosemonohydrat 38,5g.
Nước cất pha tiêm vừa đủ: 1000 ml.
**Khi dùng pha loãng theo tỷ lệ:**
Kydheamo - 2A (acide) 1.000 thể tích.
Kydheamo - 1B (Bicarbonat) 1.225 thể tích.
Nước cất (R.O) 32.775 thể tích.
**Sau khi pha loãng 2 dung dịch trên, thành phần sẽ như sau:**
CH3CO3- 3,00mEg/lít.
Glucose 1,00g/lít.
Dịch pha loãng trên gọi là dịch lọc (Dialysal): Dịch lọc màng sẽ đi vào quả lọc, quá trình thẩm tách giữa máu và dịch lọc qua màng bán thấm diễn ra trong quả lọc thận.
Một phần dịch lọc được tách ra trước khi đi vào quả lọc và được truyền trực tiếp vào máu người bệnh gọi là dịch bù (trong HDF Online).
**TAI BIẾN VÀ XỬ TRÍ**
Giống như lọc máu thường quy.
**TÀI LIỆU THAM KHẢO**
Canaud B (2007). “Online Hemodiafiltration technical options and Best Clinical practices”. Hemodiafiltration, Karger, pp 110- 123.
Locatelli F et al (2007). “Clinical Aspacts of heamodiafiltration”. Hemodiafiltration, Karger, pp 185- 194.
Von Albertini B (2011). “Producing on-line ultrapure dialysis fluid”. On-line Hemodiafiltration, The Journey and the vision, pp 35-46.
Panichi V et al (2011). “On-line Hemodiafiltration in the Large RISCAVID study”. On-line Hemodiafiltration, The Journey and the vision, pp 117 - 129.
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh

## ️ Đặt catheter hai nòng có cuff, tạo đường hầm để lọc máu

**ĐẠI CƯƠNG**
Khi có chỉ định điều trị thay thế chức năng thận, người bệnh cần có đường mạch máu sẵn sàng, thường là thông động tĩnh mạch. Hiện tại, đa số người bệnh khi có chỉ định lọc máu đều không có đường mạch máu sẵn sàng. Sử dụng catheter đôi, có cuff, tạo đường hầm mang lại nhiều lợi ích: có thể sử dụng ngay sau khi đặt, độ ổn định cao, tuổi thọ của đường mạch máu khoảng 3-9 tháng phù hợp cho việc thiết lập đường mạch máu lâu dài.
**CHỈ ĐỊNH**
Người bệnh có chỉ định chạy thận nhân tạo và cần có đường mạch máu:
Đường mạch máu tạm thời: suy thận cấp, chuẩn bị ghép thận, thẩm phân phúc mạc.
Hỗ trợ đường mạch máu, hay tắc catheter của thẩm phân phúc mạc.
Sử dụng trong thời gian chờ thông động tĩnh mạch trưởng thành.
Sử dụng là đường mạch máu lâu dài: chống chỉ định thông động tĩnh mạch, thất bại trong làm thông động tĩnh mạch.
**CHỐNG CHỈ ĐỊNH**
Rối loạn đông-cầm máu: số đếm tiểu cầu <50.000/ml.
Chống chỉ định tương đối: tiền sử hẹp tĩnh mạch trung tâm, người bệnh có nguy cơ nhiễm trùng cao/suy giảm miễn dịch.
**CHUẨN BỊ**
**Người thực hiện**
Bác sĩ thận học.
02 điều dưỡng.
**Phương tiện**
**Thuốc**
Thuốc gây tê tại chỗ: lidocain 1%.
Thuốc an thần: seduxen 10mg.
Heparin 5000UI/ml.
**Dụng cụ**
Bộ dụng cụ phẫu thuật thường.
01 bộ catheter đôi có cuff.
**Người bệnh**
Người bệnh có thể được thực hiện theo điều trị nội trú hay ngoại trú.
Có đầy đủ các xét nghiệm cơ bản.
Được giải thích rõ lý do thực hiện phẫu thuật, các lợi ích cũng như khó khăn của phương pháp.
Người bệnh nhịn ăn trước 6 tiếng.
Rửa tay bằng xà phòng diệt khuẩn.
**Hồ sơ bệnh án**
Bệnh án chi tiết.
Có đủ các xét nghiệm:
Đông máu cơ bản.
Huyết học, sinh hóa, chức năng gan,… 
**CÁC BƯỚC TIẾN HÀNH**
**Chuẩn bị người bệnh**
Người bệnh được giải thích rõ toàn bộ quá trình phẫu thuật.
Tư thế: nằm ngửa.
Vị trí xâm nhập tĩnh mạch trung tâm được bộc lộ.
Đặt máy theo dõi mạch, huyết áp, SPO2 trong quá trình thực hiện phẫu thuật.
Sát trùng rộng (đường kính 40cm).
**Phương pháp vô cảm**
Gây tê dưới da bằng lidocain 1%.
**Kỹ thuật**
(điển hình: đặt catheter đôi, có cuff, được tạo đường hầm vào tĩnh mạch cảnh trong bên phải).
Vị trí: tĩnh mạch cảnh trong bên phải. (**Hình 1 và Hình 2**)
Vị trí ra khỏi da:1/4 trên ngoài thành ngực phải.
Thăm dò định vị vị trí tĩnh mạch trung tâm.
Dùng kim to xâm nhập tĩnh mạch trung tâm. 
Luồn guidewire vào TMTT. (**Hình 3**)
Xác định vị trí qua da của catheter.
Rạch ra, luồn ống nong đi ngầm dưới da.
Luồn catheter đi ngầm dưới da. (**Hình 4**)
Nong rộng đường xâm nhập tĩnh mạch trung tâm
Đưa sheat vào tĩnh mạch trung tâm. (**Hình 5**)
Đưa catheter vào tĩnh mạch trung tâm qua sheat. (**Hình 6**)
Rút bỏ sheat. (Hình 7) Kiểm tra catheter. (**Hình 8**)
Cố định catheter.
Bởm rửa và kiểm tra lưu thông của catheter.
**THEO DÕI**
Trong khi tiến hành thủ thuật: theo dõi mạch, nhiệt độ, huyết áp, tri giác.
Sau khi tiến hành thủ thuật: theo dõi mạch, nhiệt độ, huyết áp, tri giác.
Chụp Xquang kiểm tra vị trí catheter.
**TÀI LIỆU THAM KHẢO**
Ingemar J.A. Davidson, 2008. Access for Dialysis: Surgical and Radiologic Procedures, 2nd edition (ISBN: 1-57059-627-1).
Oxford University Press, 2008. Oxford Textbook of Clinical Nephrology,
p.1909- 1926 (Third Edition 2008) (ISBN-10: 0198508247 ISBN-13: 978-0198508243).
  1. Brenner and Rector, 2008. The Kidney, 2008.(ISBN 978-1-4160-3105-5).


**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh

## ️ Tán sỏi ngoài cơ thể định vị bằng XQuang hoặc siêu âm

  * [Người thực hiện ](https://bvnguyentriphuong.com.vn/than-loc-mau/tan-soi-ngoai-co-the-dinh-vi-bang-x-quang-hoac-sieu-am#ngi-thc-hin)
  * [CÁC BƯỚC TIẾN HÀNH](https://bvnguyentriphuong.com.vn/than-loc-mau/tan-soi-ngoai-co-the-dinh-vi-bang-x-quang-hoac-sieu-am#cc-bc-tin-hnh)
  * [Kiểm tra người bệnh ](https://bvnguyentriphuong.com.vn/than-loc-mau/tan-soi-ngoai-co-the-dinh-vi-bang-x-quang-hoac-sieu-am#kim-tra-ngi-bnh)
  * [Thực hiện kỹ thuật](https://bvnguyentriphuong.com.vn/than-loc-mau/tan-soi-ngoai-co-the-dinh-vi-bang-x-quang-hoac-sieu-am#thc-hin-k-thut)
  * [Kiểm tra máy tán sỏi và hệ thống định vị.](https://bvnguyentriphuong.com.vn/than-loc-mau/tan-soi-ngoai-co-the-dinh-vi-bang-x-quang-hoac-sieu-am#kim-tra-my-tn-si-v-h-thng-nh-v)
  * [Bước 2: Định vị trí tán](https://bvnguyentriphuong.com.vn/than-loc-mau/tan-soi-ngoai-co-the-dinh-vi-bang-x-quang-hoac-sieu-am#bc-2-nh-v-tr-tn)
  * [Bước 3: Tiến hành tán sỏi](https://bvnguyentriphuong.com.vn/than-loc-mau/tan-soi-ngoai-co-the-dinh-vi-bang-x-quang-hoac-sieu-am#bc-3-tin-hnh-tn-si)
  * [TAI BIẾN VÀ XỬ TRÍ](https://bvnguyentriphuong.com.vn/than-loc-mau/tan-soi-ngoai-co-the-dinh-vi-bang-x-quang-hoac-sieu-am#tai-bin-v-x-tr)
  * [TÀI LIỆU THAM KHẢO](https://bvnguyentriphuong.com.vn/than-loc-mau/tan-soi-ngoai-co-the-dinh-vi-bang-x-quang-hoac-sieu-am#ti-liu-tham-kho)


### **ĐẠI CƯƠNG**
Tán sỏi ngoài cơ thể là phương pháp dùng một nguồn phát ra sóng chấn động điều trị sỏi thận và niệu quản ít xâm lấn, an toàn. Chùm sóng chấn động này được tập trung vào một tiêu điểm, điều khiển sao cho tiêu điểm này rơi vào đúng vị trí sỏi dưới hướng dẫn của siêu âm hay tia X. Khi chùm sóng chạm vào mặt trước của viên sỏi, do sự khác biệt về trở kháng, bề mặt của sỏi sẽ sinh ra một lực ép lớn hơn lực căng bề mặt của viên sỏi làm bề mặt của viên sỏi vỡ ra. 
### **CHỈ ĐỊNH**
Sỏi thận
Sỏi thận ≤ 2,5 cm, thận ứ nước < độ 3.
Với sỏi thận > 2,5 cm tùy từng người bệnh cụ thể.
Sỏi niệu quản 1/3 trên: sỏi niệu quản có thận ứ nước ≤ độ 2, kích thước < 1,5cm.
### **CHỐNG CHỈ ĐỊNH**
Chống chỉ định tương đối: Nhiễm trùng đường tiết niệu, rối loạn nhịp tim, cao huyết áp.
Chống chỉ định tuyệt đối: có thai, rối loạn đông máu, tắc nghẽn đường tiết niệu bên dưới vị trí sỏi. 
### **CHUẨN BỊ**
#### **Người thực hiện**
Bác sĩ chuyên khoa.
01 điều đưỡng chuyên khoa (hoặc kỹ thuật viên chuyên khoa).
#### **Phương tiện**
Hệ thống máy tán sỏi ngoài cơ thể.
Áo chì: 02 chiếc
Hộp chống sốc
Seduxen 10mg x 01 ống
Nospa 40mg x 02 ống
Natriclorua 0,9% x 1500ml
Nước cất: 10 lít
Dây truyền huyết thanh x 01 bộ
Bơm kim tiêm 5 ml x 02 cái
Bơm kim tiêm 10 ml x 02 cái 
Găng vô trùng x 02 đôi
#### **Người bệnh**
Xét nghiệm máu (công thức máu, chức năng đông máu, ure, creatinin máu)
Cấy nước tiểu, tổng phân tích nước tiểu và tế bào niệu. 
Siêu âm bụng, chụp phim bụng, chụp phim có thuốc cản quang, đo điện tim.
Người bệnh được thụt tháo phân trước khi tán sỏi, đi tiểu trước khi tán sỏi.
Đặt sonde JJ niệu quản bên có sỏi trong một số trường hợp cụ thể cần thiết (ví dụ như sỏi có đường kính > 1,5cm).
#### **Hồ sơ bệnh án**
Hồ sơ bệnh án đã được ghi chỉ định tán sỏi ngoài cơ thể và hồ sơ được mang theo đến phòng tán sỏi bao gồm cả film X quang và film UIV.
### **CÁC BƯỚC TIẾN HÀNH**
#### **Kiểm tra hồ sơ**
Tên tuổi người bệnh.
#### **Kiểm tra người bệnh**
Đo huyết áp, nhịp tim trước khi làm thủ thuật.
#### **Thực hiện kỹ thuật**
Bước 1: 
##### _Kiểm tra máy tán sỏi và hệ thống định vị._
Kết nối hệ thống điện với hệ thống máy tán sỏi.
Kiểm tra khối lượng nước cung cấp cho hệ thống tán: 10 lít nước (9 lít nước cất + 1 lít natriclorua 0,9%).
Thay điện cực mới.
Khởi động máy tán sỏi và hệ thống định vị. Kiểm tra sự hoạt động của bàn nằm tán sỏi.
Cho người bệnh nằm vào giường (bàn) tán theo tư thế nằm ngửa và hướng hông lưng bên thận có sỏi vào bầu tán; Người bệnh được lắp monitoring theo dõi mạch, huyết áp, SpO2; đeo bảo vệ tai người bệnh.
Truyền dịch: natriclorua 0,9 % x 500 ml, 20 giọt/phút 
Tiêm 02 ống nospa 40mg tĩnh mạch chậm và tiêm ½ ống seduxen 10 mg tĩnh mạch chậm.
##### _Bước 2: Định vị trí tán_
Định vị kiểm tra và điều chỉnh sao cho vị trí sỏi cần tán nằm trùng với tâm điểm tán ở các góc độ.
##### _Bước 3: Tiến hành tán sỏi_
Sau khi người bệnh đã được chuẩn bị xong như ở bước 1 và xác định được vị trí tán.
Bắt đầu tán với tần số phát xung thấp, sau khi phát xung được 2000 xung thì có thể chuyển sang tần số nhanh hơn; bắt đầu tán với cường độ của xung thấp sau đó tăng dần cường độ nếu người bệnh chịu được (không bị đau). Tổng liều phát xung không quá 3000 với 100% công xuất đối với sỏi thận và 4000 đối với sỏi niệu quản đoạn 1/3 trên.
Kiểm tra lại định kỳ (cách 15 phút 1 lần) xem vị trí của sỏi có nằm đúng tâm tán không. Kiểm tra lại ngay khi thấy người bệnh tự ý thay đổi tư thế.
Thời gian cho 1 lần tán sỏi kéo dài khoảng 1 giờ. Sau khi tán sỏi xong người bệnh nằm lưu lại tại phòng chờ 1-2 giờ, sau đó được chuyển về bệnh phòng theo dõi tiếp 1-2 ngày.
Theo dõi mạch, huyết áp, SpO2 và ghi vào hồ sơ.
Kiểm tra lại sau khi kết thúc liều tán xem tình trạng sỏi sau tán.
##### _Bước 4:_
Chụp X quang hệ tiết niệu không chuẩn bị để đánh giá hiệu quả điều trị.
Xét nghiệm nước tiểu: tổng phân tích.
Điều trị phối hợp
Giảm đau: uống nospa 0,04 g x 4 viên/ngày x 7-14 ngày sau tán
Kháng sinh: noroxin 400mg x 02 viên/ngày chia 2 lần x 7 ngày
Thuốc tăng cường tống sỏi ra ngoài: rowatinec 300mg x6 viên/ ngày chia 3 lần x 14 ngày sau tán sỏi.
### **THEO DÕI**
Sau tán sỏi: đái máu, chấn thương thận, nhiễm trùng, tắc nghẽn.
Sau ra viện: kiểm tra lại sau 1 tháng, 3 tháng: siêu âm thận tiết niệu, chụp Xquang, kiểm tra chức năng thận, xét nghiệm nước tiểu.
### **TAI BIẾN VÀ XỬ TRÍ**
Đái máu đại thể, đái máu vi thể, vỡ thận, vỡ lách, vỡ gan, tắc nghẽn đường tiểu.
Phối hợp với ngoại khoa: khi có một trong các biến chứng cần cấp cứu ngoại khoa như: tắc nghẽn đường tiểu gây ứ nước bể thận, vỡ thận gây đái máu đại thể, vỡ gan, lách. 
### **TÀI LIỆU THAM KHẢO**
Martin X, Mestas J.L, et al (1986). Ultrasound Stone Localisation for Extracorporeal Shock Wave Lithotripsy. British Journal of Urology, Vol 58, Issue 2-4, P 349 - 352.
Sauerbruch, Tilman et al (1986). Fragmenttation of Gallstones by Extracorporeal Shock Waves, New England Journal of Medicine, 27, vol 314, No. 13, pp 818 - 822.
Sackmann, MD., Michael (1988). Shock - Wave Lithotripsy of Gallblader stones, New England Journal of Medicine, Feb. 18, 8; vol. 318 No. 7, pp. 393 - 397.
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [Người thực hiện ](https://bvnguyentriphuong.com.vn/than-loc-mau/tan-soi-ngoai-co-the-dinh-vi-bang-x-quang-hoac-sieu-am#ngi-thc-hin)
  * [CÁC BƯỚC TIẾN HÀNH](https://bvnguyentriphuong.com.vn/than-loc-mau/tan-soi-ngoai-co-the-dinh-vi-bang-x-quang-hoac-sieu-am#cc-bc-tin-hnh)
  * [Kiểm tra người bệnh ](https://bvnguyentriphuong.com.vn/than-loc-mau/tan-soi-ngoai-co-the-dinh-vi-bang-x-quang-hoac-sieu-am#kim-tra-ngi-bnh)
  * [Thực hiện kỹ thuật](https://bvnguyentriphuong.com.vn/than-loc-mau/tan-soi-ngoai-co-the-dinh-vi-bang-x-quang-hoac-sieu-am#thc-hin-k-thut)
  * [Kiểm tra máy tán sỏi và hệ thống định vị.](https://bvnguyentriphuong.com.vn/than-loc-mau/tan-soi-ngoai-co-the-dinh-vi-bang-x-quang-hoac-sieu-am#kim-tra-my-tn-si-v-h-thng-nh-v)
  * [Bước 2: Định vị trí tán](https://bvnguyentriphuong.com.vn/than-loc-mau/tan-soi-ngoai-co-the-dinh-vi-bang-x-quang-hoac-sieu-am#bc-2-nh-v-tr-tn)
  * [Bước 3: Tiến hành tán sỏi](https://bvnguyentriphuong.com.vn/than-loc-mau/tan-soi-ngoai-co-the-dinh-vi-bang-x-quang-hoac-sieu-am#bc-3-tin-hnh-tn-si)
  * [TAI BIẾN VÀ XỬ TRÍ](https://bvnguyentriphuong.com.vn/than-loc-mau/tan-soi-ngoai-co-the-dinh-vi-bang-x-quang-hoac-sieu-am#tai-bin-v-x-tr)
  * [TÀI LIỆU THAM KHẢO](https://bvnguyentriphuong.com.vn/than-loc-mau/tan-soi-ngoai-co-the-dinh-vi-bang-x-quang-hoac-sieu-am#ti-liu-tham-kho)



## ️ Thay transfer set ở người bệnh lọc màng bụng liên tục ngoại trú

  * [Người thực hiện ](https://bvnguyentriphuong.com.vn/than-loc-mau/thay-transfer-set-o-nguoi-benh-loc-mang-bung-lien-tuc-ngoai-tru#ngi-thc-hin)
  * [CÁC BƯỚC TIẾN HÀNH](https://bvnguyentriphuong.com.vn/than-loc-mau/thay-transfer-set-o-nguoi-benh-loc-mang-bung-lien-tuc-ngoai-tru#cc-bc-tin-hnh)
  * [Thực hiện kỹ thuật](https://bvnguyentriphuong.com.vn/than-loc-mau/thay-transfer-set-o-nguoi-benh-loc-mang-bung-lien-tuc-ngoai-tru#thc-hin-k-thut)
  * [TAI BIẾN VÀ XỬ TRÍ](https://bvnguyentriphuong.com.vn/than-loc-mau/thay-transfer-set-o-nguoi-benh-loc-mang-bung-lien-tuc-ngoai-tru#tai-bin-v-x-tr)
  * [TÀI LIỆU THAM KHẢO](https://bvnguyentriphuong.com.vn/than-loc-mau/thay-transfer-set-o-nguoi-benh-loc-mang-bung-lien-tuc-ngoai-tru#ti-liu-tham-kho)


### **ĐẠI CƯƠNG**
Transfer set là một đoạn ống kết nối giữa catheter lọc màng bụng và túi dịch lọc, gồm một đầu nối với đầu ngoài của catheter lọc màng bụng và đầu còn lại là hệ thống van nối với túi dịch lọc. Transfer set còn gọi là bộ chuyển tiếp.
Thay transfer set nhằm mục đích phòng tránh viêm phúc mạc ở người bệnh lọc màng bụng liên tục ngoại trú.
### **CHỈ ĐỊNH**
Transfer set được thay định kỳ 6 tháng 1 lần
Transfer set bị rách hoặc bị rò rỉ
Nhiễm trùng hay nghi ngờ nhiễm trùng do sờ chạm vào đầu ống transfer set.
Sau điều trị viêm phúc mạc ổn định. 
### **CHỐNG CHỈ ĐỊNH**
Không có chống chỉ định.
### **CHUẨN BỊ**
#### **Người thực hiện**
01 điều dưỡng chuyên khoa.
#### **Phương tiện**
Transfer set: 01 bộ
Bộ thay băng (khay quả đậu x 01 cái, bát inox x 01 cái, gạc N2 vô trùng x 10 miếng, săng vô khuẩn không lỗ x 2 cái)
Khoá kẹp catheter tiệt trùng x 01 cái
Găng tay tiệt trùng x 02 đôi
Minicap x 01 cái
Dung dịch sát trùng tay nhanh
Povidone Iodine 10% (100ml) x 02 lọ 
Khăn tiệt trùng x 02 cái
#### **Người bệnh**
Thông báo người bệnh ngày, giờ tiến hành thủ thuật
Giải thích người bệnh về thủ thuật để người bệnh hợp tác
#### **Hồ sơ bệnh án**
Mang hồ sơ bệnh án của người bệnh đến phòng thủ thuật.
### **CÁC BƯỚC TIẾN HÀNH**
#### **Kiểm tra hồ sơ**
#### **Thực hiện kỹ thuật**
Đeo khẩu trang cho cả điều dưỡng và người bệnh.
Lau mặt bàn hoặc mâm thay băng bằng cồn 700.
Soạn dụng cụ: mở bộ thay băng theo các nếp góc.
Dùng panh kẹp xếp các dụng cụ trong mâm theo vị trí tiện sử dụng.
Rót povidone vào trong khay hạt đậu và 2 bát Inox.
Tháo bỏ transfer set và thả vào mâm vô trùng.
Chuẩn bị găng tay tiệt trùng, thả vào mâm vô trùng.
Rửa tay 6 bước với xà phòng sát khuẩn, lau khô tay.
Trải săng lên bụng người bệnh phía dưới catheter.
Cẩn thận kẹp khoá catheter lại bằng kẹp nhỏ tiệt trùng chuyên dùng trong lọc màng bụng (chú ý kẹp cách đầu Titanium khoảng 3cm).
Rửa tay nhanh (theo 6 bước).
Mang găng tay vào.
Lấy 2 miếng gạc và nhúng gạc vào dung dịch povidone iodine. Dùng một miếng gạc đã nhúng đè giữ một đầu catheter, miếng gạc còn lại sát trùng xung quanh mối nối catheter/đầu nối adapter trong khoảng 1 phút.
Đặt mối nối catheter/adapter lên một miếng gạc kho tiệt trùng.
Ngâm đầu nối catheter/adapter chìm hoàn toàn vào khay hạt đậu đựng povidone Iodine trong 5 phút.
Nhấc đoạn đầu nối lên và đặt đoạn nối catheter/adapter lên miếng gạc vô trùng. Lấy khay hạt đậu đựng povidone Iodine đã dùng ra khỏi khu vực vô trùng.
Dùng 2 miếng gạc vô trùng, nắm và vặn ống thông cũ ra khỏi đầu nối. Chú ý tránh sờ vào đầu hở của catheter. Bỏ ngay ống thông cũ ra khỏi đầu nối.
Lấy 1 bát Inox đựng povidone Iodine khác ngâm rửa đầu hở catheter trong 5 phút.
Nhấc đầu hở catheter lên khỏi bát povidone Iodine và đặt lên miếng gạc vô trùng.
Rửa tay lại với dung dịch sát trùng tay nhanh và mang găng tay mới vào.
Lấy ống thông mới ra, tháo nắp bảo vệ màu xanh và gắn vào đầu nối trên catheter; vặn vừa đủ chặt.
Đóng khoá xoay trên ống thông mới và thay nắp trong suốt bằng một nắp đậy mới (Minicap).
Tháo khoá kẹp catheter ra và tháo các khăn trải khỏi người bệnh.
Thực hiện quy trình thay băng lỗ thoát.
Người bệnh tự thực hiện quy trình thay dịch.
Ghi sổ ngày thay transfer set.
### **TAI BIẾN VÀ XỬ TRÍ**
Không có tai biến.
### **TÀI LIỆU THAM KHẢO**
Prowant BF, Ryan LP: Peritoneal dialysis transfer set change procedures study. ANNA J. 1989 Feb; 16 (1): 23-6.
Goetz A, Muder R (1989). Pseudomonas aeruginosa infections associated with use of povidone-iodine in patients receiving CAPD. Infect Control Hosp Epidemiol, 10: 447.
Mileto F, Pellegrino E (1983). Infezioni in corso di CAPD causate doll'uso di disinfettanti a base di povidone-iodine o contaminati da pseudomonas aeruginosa.. Minerva Urol Nefrol, 30:235.
Peritoneal dialysis transfer set change: http://www.nursinghelp.com/2012/06/peritoneal-dialysis-transfer-set-change.html.
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [Người thực hiện ](https://bvnguyentriphuong.com.vn/than-loc-mau/thay-transfer-set-o-nguoi-benh-loc-mang-bung-lien-tuc-ngoai-tru#ngi-thc-hin)
  * [CÁC BƯỚC TIẾN HÀNH](https://bvnguyentriphuong.com.vn/than-loc-mau/thay-transfer-set-o-nguoi-benh-loc-mang-bung-lien-tuc-ngoai-tru#cc-bc-tin-hnh)
  * [Thực hiện kỹ thuật](https://bvnguyentriphuong.com.vn/than-loc-mau/thay-transfer-set-o-nguoi-benh-loc-mang-bung-lien-tuc-ngoai-tru#thc-hin-k-thut)
  * [TAI BIẾN VÀ XỬ TRÍ](https://bvnguyentriphuong.com.vn/than-loc-mau/thay-transfer-set-o-nguoi-benh-loc-mang-bung-lien-tuc-ngoai-tru#tai-bin-v-x-tr)
  * [TÀI LIỆU THAM KHẢO](https://bvnguyentriphuong.com.vn/than-loc-mau/thay-transfer-set-o-nguoi-benh-loc-mang-bung-lien-tuc-ngoai-tru#ti-liu-tham-kho)



## ️ Chăm sóc và bảo quản catheter đường hầm có cuff để lọc máu

  * [Người thực hiện](https://bvnguyentriphuong.com.vn/than-loc-mau/cham-soc-va-bao-quan-catheter-duong-ham-co-cuff-de-loc-mau#ngi-thc-hin)
  * [CÁC BƯỚC TIẾN HÀNH](https://bvnguyentriphuong.com.vn/than-loc-mau/cham-soc-va-bao-quan-catheter-duong-ham-co-cuff-de-loc-mau#cc-bc-tin-hnh)
  * [Kiểm tra người bệnh](https://bvnguyentriphuong.com.vn/than-loc-mau/cham-soc-va-bao-quan-catheter-duong-ham-co-cuff-de-loc-mau#kim-tra-ngi-bnh)
  * [Thực hiện kỹ thuật ](https://bvnguyentriphuong.com.vn/than-loc-mau/cham-soc-va-bao-quan-catheter-duong-ham-co-cuff-de-loc-mau#thc-hin-k-thut)
  * [TAI BIẾN VÀ XỬ TRÍ](https://bvnguyentriphuong.com.vn/than-loc-mau/cham-soc-va-bao-quan-catheter-duong-ham-co-cuff-de-loc-mau#tai-bin-v-x-tr)
  * [TÀI LIỆU THAM KHẢO](https://bvnguyentriphuong.com.vn/than-loc-mau/cham-soc-va-bao-quan-catheter-duong-ham-co-cuff-de-loc-mau#ti-liu-tham-kho)


### **ĐẠI CƯƠNG**
Chăm sóc catheter đường hầm duy trì chức năng của catheter nhằm theo dõi chảy máu đường hầm và chân catheter, hạn chế nguy cơ nhiễm trùng đường hầm, tụt catheter khỏi vị trí đặt và hạn chế nhiễm trùng huyết cho người bệnh. 
### **CHỈ ĐỊNH**
Người bệnh có catheter đường hầm. 
### **CHỐNG CHỈ ĐỊNH**
Không có chống chỉ định.
### **CHUẨN BỊ**
#### **Người thực hiện**
Bác sĩ: 01 
Điều dưỡng: 01 
#### **Phương tiện**
Giường thực hiện thủ thuật: 01 chiếc
Dung dịch betadin sát trùng: 01 lọ
Săng vô khuẩn loại có lỗ: 01 chiếc
Bông băng, gạc vô trùng: 04 gói
Găng tay vô trùng: 02 đôi
#### **Người bệnh**
Người bệnh đã được làm các xét nghiệm về đông máu cơ bản và các xét nghiệm cơ bản khác.
Người bệnh được nghe bác sĩ giải thích kỹ về thủ thuật và ký vào giấy cam kết đồng ý làm thủ thuật.
#### **Hồ sơ bệnh án**
Bệnh án được hoàn thiện với các thủ tục dành cho người bệnh tiến hành làm thủ thuật. 
### **CÁC BƯỚC TIẾN HÀNH**
#### **Kiểm tra hồ sơ**
#### **Kiểm tra người bệnh**
#### **Thực hiện kỹ thuật**
Người bệnh được kiểm tra mạch, huyết áp. 
Người bệnh được nằm ngửa, đầu nghiêng tư thế Trendelenburg, đầu quay 45o về phía đối diện.
Bác sĩ rửa tay, mặc áo thủ thuật, đi găng vô trùng.
Tháo băng catheter đường hầm.
Sát trùng sạch vùng chỗ đường hầm ra và catheter.
Kiểm tra chỉ cố định chân catheter có bị đứt gãy không, nếu không còn cố định được catheter thì phải khâu lại chân catheter.
Băng lại catheter đường hầm.
Cho người bệnh về giường bệnh. 
### **THEO DÕI**
Các thông số sinh tồn: toàn trạng, mạch, huyết áp, nhịp thở.
Kiểm soát đau.
### **TAI BIẾN VÀ XỬ TRÍ**
Hầu như không có tai biến. 
Nếu có chảy máu tại chỗ: băng ép hoặc khâu lại chân catheter nếu cần thiết. 
### **TÀI LIỆU THAM KHẢO**
Scott O. Trerotola. 2000. Hemodialysis Catheter Placement and Management. Radiology. 215:651-658. 
Julie AG, Alan DK. 2012. Ultrasound-Guided Central vein Cannulation: Current recommendations and guideline. Anesthesiology News. June: 1-6. 
Gibbs FJ, Murphy MC. 2006. Ultrasound Guidance for Central venous catheter placement. Hospital physician. March: 23-31. 
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [Người thực hiện](https://bvnguyentriphuong.com.vn/than-loc-mau/cham-soc-va-bao-quan-catheter-duong-ham-co-cuff-de-loc-mau#ngi-thc-hin)
  * [CÁC BƯỚC TIẾN HÀNH](https://bvnguyentriphuong.com.vn/than-loc-mau/cham-soc-va-bao-quan-catheter-duong-ham-co-cuff-de-loc-mau#cc-bc-tin-hnh)
  * [Kiểm tra người bệnh](https://bvnguyentriphuong.com.vn/than-loc-mau/cham-soc-va-bao-quan-catheter-duong-ham-co-cuff-de-loc-mau#kim-tra-ngi-bnh)
  * [Thực hiện kỹ thuật ](https://bvnguyentriphuong.com.vn/than-loc-mau/cham-soc-va-bao-quan-catheter-duong-ham-co-cuff-de-loc-mau#thc-hin-k-thut)
  * [TAI BIẾN VÀ XỬ TRÍ](https://bvnguyentriphuong.com.vn/than-loc-mau/cham-soc-va-bao-quan-catheter-duong-ham-co-cuff-de-loc-mau#tai-bin-v-x-tr)
  * [TÀI LIỆU THAM KHẢO](https://bvnguyentriphuong.com.vn/than-loc-mau/cham-soc-va-bao-quan-catheter-duong-ham-co-cuff-de-loc-mau#ti-liu-tham-kho)



## ️ Nối thông động tĩnh mạch (arteriovenous fistula-A.V.F)

**ĐẠI CƯƠNG**
Lỗ thông động tĩnh mạch (Fistula) được Michael Brescia và James E. Cimino đưa vào sử dụng từ năm 1966. Đây là đường vào mạch máu lâu dài, có nhiều ưu điểm nhất khi so sánh với các dạng còn lại (căn cứ trên các yếu tố: khả năng cung cấp dòng máu ổn định, tuổi đời sử dụng và tỷ lệ biến chứng). Trong phẫu thuật nối thông động tĩnh mạch, căn cứ vào vị trí giải phẫu, chúng ta có các kiểu nối sau đây (được đề cập từ xa đến gần).
**Vị trí hõm lào giải phẫu tại bàn tay (vị trí 1).** Đây là vị trí xa nhất ở chi trên có thể thiết lập được đường vào mạch máu.
**Vị trí cổ tay:** Miệng nối được tạo bởi động mạch quay và tĩnh mạch đầu (vị trí 2). Đây là vị trí kinh điển và phổ biến nhất. Vị trí này được giới thiệu đầu tiên năm 1966 bởi Bresscia và Cimino, và cũng là ý tưởng đầu tiên chủ động tạo một miệng nối thông giữa động mạch và tĩnh mạch nhằm thiết lập đường mạch máu cho lọc máu chu kỳ.
**Vị trí cổ tay:** Miệng nối tạo bởi động mạch trụ và tĩnh mạch nền (vị trí 3). Trong một số trường hợp, hệ tĩnh mạch đầu ở cẳng tay không cho phép thiết lập cầu nối, có thể vị trí này cũng là một lựa chọn.
**Vị trí khuỷu tay: (vị trí 4)** Miệng nối được thiết lập giữa động mạch cánh tay và tĩnh mạch đầu tại vị trí khuỷu. Đây là lựa chọn cho những người bệnh mà hệ tĩnh mạch tại cẳng tay không cho phép thiết lập cầu nối hoặc đã được thiết lập cầu nối nhưng đã hỏng sau thời gian sử dụng hoặc thất bại. Vị trí này có tốc độ dòng máu cao và thường ổn định. Đồng thời nó cũng có một số hạn chế, như: nguy cơ gây hội chứng thiếu máu đầu chi.
**CHỈ ĐỊNH**
Suy thận giai đoạn cuối lựa chọn điều trị thay thế chức năng thận bằng thẩm tách máu (HD-Hemodialysis). 
**CHỐNG CHỈ ĐỊNH**
Hội chứng suy tim sung huyết có EF 30%.
Rối loạn đông cầm máu: Số đếm tiểu cầu máu 50.000/ml.
**CHUẨN BỊ**
**Người thực hiện**
**Cần 1 nhóm phẫu thuật viên bao gồm:**
01 hoặc 02 bác sĩ chuyên ngành Thận-Lọc máu được đào tạo phẫu thuật mạch máu.
02 điều dưỡng.
**Phương tiện**
**Thuốc**
Thuốc gây tê tại chỗ: lidocain 1%
Thuốc an thần: seduxen 10mg Heparin 5000UI/ml. 
Cefazolin 1g (dự phòng chống nhiễm khuẩn).
**Dụng cụ**
Bộ dụng cụ phẫu thuật thường.
Bộ dụng cụ vi phẫu phẫu thuật mạch máu.
Kính lúp phóng đại.
Dao điện cao tần.
Bàn mổ.
Đèn mổ.
**Người bệnh**
Người bệnh có thể được thực hiện theo điều trị nội trú hay ngoại trú.
Có đầy đủ các xét nghiệm cơ bản.
Có đầy đủ thăm dò hình ảnh hệ động tĩnh mạch tạo nối thông.
Được giải thích rõ lý do thực hiện phẫu thuật, các lợi ích cũng như khó khăn của phương pháp.
Người bệnh nhịn ăn trước 6 tiếng.
Rửa tay bằng xà phòng diệt khuẩn.
**Hồ sơ bệnh án**
Bệnh án chi tiết.
Có đủ các xét nghiệm:Đông máu cơ bản.
Huyết học, sinh hóa, chức năng gan,… 
**CÁC BƯỚC TIẾN HÀNH**
**Chuẩn bị người bệnh**
Người bệnh được giải thích rõ toàn bộ quá trình phẫu thuật.
Được cắt toàn bộ móng tay, rửa sạch toàn bộ cánh tay bằng xà phòng diệt khuẩn.
Tư thế: nằm ngửa.
Tay phẫu thuật để ngang thân người, đặt trên bàn mổ.
Đặt Máy theo dõi mạch, huyết áp, SPO2 trong quá trình thực hiện phẫu thuật.
**Sát trùng**
Toàn bộ cánh tay được sát trùng bằng iod hữu cơ: betadin10%.
**Phương pháp vô cảm**
Người bệnh được gây tê đám rối cánh tay hoặc gây tê tại chỗ phẫu thuật.
**Kỹ thuật (điển hình cho vị trí cổ tay trái hay Cimino trái)**
Rạch da: vị trí gần cổ tay, dài khoảng 5 cm.
Bộc lộ tĩnh mạch.
Bộc lộ động mạch.
Cắt tĩnh mạch, tạo miệng nối (theo hình bên). Bơm rửa bằng NaCl 0,9%, kiểm tra khả năng thông thoáng của tĩnh mạch.
Rạch mở động mạch (khoảng 4-7mm).
Khâu nối tĩnh mạch (đầu tận) - Động mạch (bên). Kiểm tra tĩnh mạch xem có xoắn vặn, gập (hình mô phỏng bên dưới)
Kiểm tra đặc điểm rung của tĩnh mạch sau nối thông. 
Kiểm tra toàn bộ đường đi của tĩnh mạch.
Cầm máu toàn bộ trường mổ.
Khâu da đóng kín vết mổ.
**THEO DÕI**
Trong khi tiến hành thủ thuật.
Theo dõi mạch, huyết áp, tri giác.
Sau khi tiến hành thủ thuật.
Theo dõi mạch, huyết áp, tri giác.
Khám/đánh giá quá trình phát triển của thông động tĩnh mạch sau 1 tháng.
Xem xét đưa thông động tĩnh mạch vào sử dụng sau 1 tháng.
**TAI BIẾN VÀ XỬ TRÍ**
**Biến chứng sớm**
_Tắc miệng nối do huyết khối:_
Đây là biến chứng thường gặp nhất.
Thường do rất nhiều yếu tố, luôn luôn phải xét đến khả năng do kỹ thuật thao tác: bao gồm, xoắn, vặn, gập miệng nối; do các mũi chỉ khâu quá chặt; do đóng da quá chặt; hoặc do hiện tượng hẹp, tắc tĩnh mạch máu về ở vị trí gần hơn.
Chảy máu sau phẫu thuật:
Thường ít gặp, nếu chảy nhiều và xuất hiện hiện tượng huyết khối trong vết mổ gây chèn ép đòi hỏi phải can thiệp mổ lại cầm máu.
_Biến chứng nhiễm trùng:_
Đây là biến chứng hiếm khi xảy ra, liên quan trực tiếp đến quá trình vô khuẩn trong mổ và chăm sóc vết mổ sau phẫu thuật.
_Thiếu máu đầu chi:_
Rất ít gặp, thông thường trên những người bệnh có sẵn bệnh về mạch máu (xơ vữa, calci, phospho lắng đọng, bất thường giải phẫu...) có dự đoán trước thông qua thăm khám lâm sàng trước phẫu thuật một cách tỉ mỉ (trong đó có thực hiện Allen test).
**Biến chứng muộn**
_Hẹp Fistula:_
Có thể xuất hiện dưới bất kỳ cấp độ nào, vị trí thường gặp nhất là đoạn cách miệng nối 1-2cm.
_Giả phình mạch tại vị trí miệng nối:_
Đây thường là hiện tượng chảy máu giữa các mũi khâu.
_Tắc thông động tĩnh mạch do huyết khối:_
Thông thường đây là bước cuối cùng của quá trình hẹp Fistula.
_Tăng áp lực tĩnh mạch bàn tay:_
Xuất hiện khá thường xuyên nếu miệng nối được thực hiện bởi kỹ thuật bên bên (15-20%).
Khi người bệnh xuất hiện đau, hoặc có những dấu hiệu thiếu máu đầu chi thì có chỉ định can thiệp loại bỏ dòng trào ngược.
**TÀI LIỆU THAM KHẢO**
Ingemar J.A. Davidson, 2008. Access for Dialysis : Surgical and Radiologic Procedures, 2nd edition (ISBN: 1-57059-627-1).
Oxford University Press, 2008. Oxford Textbook of Clinical Nephrology,
p.1909-1926 (Third Edition 2008) (ISBN-10: 0198508247 ISBN-13: 978-0198508243).
Brenner and Rector, 2008. The Kidney, 2008. (ISBN 978-1-4160-3105-5).
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh

## ️ Lọc màng bụng cấp cứu liên tục 24 giờ

**ĐẠI CƯƠNG**
Lọc màng bụng cấp cứu hay thẩm phân phúc mạc cấp cứu là biện pháp lọc máu cấp cứu nhờ sự trao đổi một số chất giữa máu và dịch lọc trong ổ bụng thông qua màng bán thấm là phúc mạc khi chức năng thận bị suy giảm đột ngột.
**CHỈ ĐỊNH**
Chỉ định lọc màng bụng cấp cứu khi có suy thận cấp do các nguyên nhân khác nhau. Chỉ định bắt buộc khi có thiểu niệu - vô niệu, kali máu > 6,5mmol/l, ure > 35 mmol/l. Trong một số trường hợp ngộ độc, có thể chỉ định lọc màng bụng cấp cứu nhằm mục đích loại bỏ chất độc ra khỏi cơ thể càng sớm càng tốt khi không có điều kiện lọc máu thận nhân tạo.
**CHỐNG CHỈ ĐỊNH**
**Không tiến hành lọc màng bụng cấp cứu trong những trường hợp sau:**
Viêm ruột thừa, viêm phúc mạc.
Tưới máu kém các tạng.
Tắc ruột, thủng ruột.
Rò ổ bụng, rò cơ hoành.
Viêm da.
Ghép động mạch chủ.
**CHUẨN BỊ**
**Người thực hiện**
02 bác sĩ, 01 điều dưỡng, kỹ thuật viên.
**Phương tiện**
Tên, số lượng của thiết bị, dụng cụ, vật tư tiêu hao (định hướng, ước lượng…): 
01 bộ catheter thường dùng loại cứng đầu cong (Troca catheters) hoặc catheter Tenckhoff với 1 cuff Dacron.
01 nòng sắt dẫn đường.
01 bộ dây - túi dẫn lưu dịch vào - ra.
Dịch lọc các thành phần: 30 lít - 40 lít.
Lidocain hoặc xylocain 2% 10ml x 01 ống.
Bộ dụng cụ làm thủ thuật vô trùng: săng gạc, panh, kéo, bông băng,..
Betadin 10% 100ml x 01 lọ
Bộ quần áo vô trùng x 02 bộ
**Người bệnh**
Người bệnh và người nhà được giải thích về thủ thuật và ký cam kết đồng ý làm thủ thuật.
Người bệnh có đủ xét nghiệm sinh hóa, huyết học, đông máu cơ bản trước khi tiến hành; được khám lâm sàng, đo huyết áp, số lượng nước tiểu, cân nặng. 
**Hồ sơ bệnh án**
Kẻ bảng theo dõi dịch vào - ra, cân bằng dịch,..
**CÁC BƯỚC TIẾN HÀNH**
**Kiểm tra hồ sơ đối chiếu người bệnh và chỉ định**
**Chuẩn bị người bệnh**
Nhịn ăn.
Vô trùng thành bụng. 
Gây tê tại chỗ vị trí quanh rốn bằng lidocain hoặc xylocain.
**Thực hiện kỹ thuật**
Xác định vị trí chọc catheter tại đường trắng giữa, dưới rốn 2cm.
Rạch da tại đường trắng giữa đủ cho trocat đưa qua.
Dùng trocat dẫn đường đưa catheter qua phúc mạc vào ổ bụng.
Dùng kim nòng kim loại dẫn đường cho catheter đi sát dưới cơ thẳng trước bụng, hướng về phía túi cùng Douglas. Khi đầu catheter đưa vào túi cùng Douglas thì dừng lại (người bệnh có cảm giác tức vùng hạ vị), rút kim nòng kim loại ra khỏi lòng catheter.
_Cố định catheter với thành bụng để tránh di lệch:_
Khâu quanh chân ống catheter để tránh rò rỉ dịch trong quá trình lọc.
Cho 2 lít dịch lọc 1.5% chảy vào ổ bụng với thời gian 15 phút/chảy vào và 15 phút/chảy ra, rửa sạch ổ bụng.
Các túi dịch tiếp theo 2 lít/lần, lưu trong ổ bụng từ 30- 60 phút rồi xả dịch ra ngoài để tiếp tục lọc tiếp. Dịch lọc có thể pha 500 UI heparin/lit dịch lọc ở tất cả các túi để phòng ngừa tắc catheter. Tùy từng người bệnh cụ thể sẽ quyết định liều thuốc chống đông hợp lý. 
Số lượng dịch: 30- 40 lít/ngày lọc hàng ngày cho đến khi chức năng thận phục hồi, hết tình trạng đe dọa để có thể tiến hành được các chỉ định khác cần thiết cho chẩn đoán và điều trị.
Theo dõi cân bằng dịch mỗi lần lọc và điều chỉnh loại dịch tùy thuộc vào tình trạng của người bệnh. Lưu ý nguy cơ mất dịch, thừa dịch, rối loạn điện giải có thể xảy ra, cần được điều chỉnh sớm. 
**THEO DÕI**
Tình trạng lâm sàng nói chung: mạch, HA, nhiệt độ.
Tình trạng bụng, chảy máu thành bụng, thủng tạng rỗng; rò rỉ dịch, tắc dịch, tốc độ dịch chảy vào, chảy ra, biểu hiện viêm phúc mạc…
**TAI BIẾN VÀ XỬ TRÍ**
Những tai biến có thể: thủng tạng rỗng khi đưa catheter vào ổ bụng, tắc catheter do mạc nối quấn xung quanh, chảy máu, đau bụng, sốt nhiễm trùng, tắc catheter do fibrin, catheter quặt lên trên… Xử trí tùy thuộc vào từng biến chứng cụ thể.
**TÀI LIỆU THAM KHẢO**
Abdel- Aal AK, Joshi AK et all (2009). Fluoroscopic and sonographic guidance to place peritoneal catheters: how we do it. Am J Roentgerol 192: 1085 - 1089.
Gabriel DP, Nascimento GV et al. (2007) High volume peritoneal dialysis for acute renal failure . Pert Dial Int 277 - 282.
Stevent Guest (2010) Handbook of Peritoneal Dialysis. 
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh

## ️ Chạy thận nhân tạo: Những điều cần biết

  * [1. Khi nào cần chạy thận nhân tạo?](https://bvnguyentriphuong.com.vn/than-loc-mau/chay-than-nhan-tao-nhung-dieu-can-biet#1khi-no-cn-chy-thn-nhn-to)
  * [2. Quy trình chạy thận nhân tạo](https://bvnguyentriphuong.com.vn/than-loc-mau/chay-than-nhan-tao-nhung-dieu-can-biet#2quy-trnh-chy-thn-nhn-to)
  * [3. BHYT có chi trả cho bệnh nhân chạy thận nhân tạo không?](https://bvnguyentriphuong.com.vn/than-loc-mau/chay-than-nhan-tao-nhung-dieu-can-biet#3bhyt-c-chi-tr-cho-bnh-nhn-chy-thn-nhn-to-khng)
  * [4. Chạy thận nhân tạo sống được bao lâu?](https://bvnguyentriphuong.com.vn/than-loc-mau/chay-than-nhan-tao-nhung-dieu-can-biet#4-chy-thn-nhn-to-sng-c-bao-lu)
  * [5. Làm gì để tăng tuổi thọ cho bệnh nhân chạy thận nhân tạo?](https://bvnguyentriphuong.com.vn/than-loc-mau/chay-than-nhan-tao-nhung-dieu-can-biet#5-lm-g-tng-tui-th-cho-bnh-nhn-chy-thn-nhn-to)


## **1. Khi nào cần chạy thận nhân tạo?**
Thận là cơ quan quan trọng của cơ thể, có chức năng duy trì cân bằng dịch tổng thể; Điều hòa và lọc khoáng chất từ ​​máu; Lọc chất thải từ thực phẩm, thuốc và các chất độc hại; Tạo ra các hormone giúp sản sinh hồng cầu, tăng cường sức khỏe của xương và điều hòa huyết áp.
Đối với các bệnh nhân bị bệnh suy thận giai đoạn cuối thì thận không thể thực hiện các chức năng tự nhiên của nó một cách đầy đủ, gây tổn hại cho sức khỏe, thậm chí là tử vong. Khi đó, chạy thận nhân tạo là giải pháp giúp bệnh nhân duy trì được cuộc sống và kéo dài thời gian sống.
Vậy chạy thận nhân tạo là gì? Đó là quá trình là thiết lập vòng tuần hoàn ngoài cơ thể có lưu lượng máu từ 200 – 400 ml/phút, thời gian kéo dài từ 4 – 8h. Quá trình này sử dụng máy lọc để “làm sạch” máu thay cho chức năng thận của người bệnh. Sau khi được lọc bỏ các chất cặn bã, máu sẽ đưa trở lại vào cơ thể.
**Chạy thận nhân tạo** dựa trên các cơ chế sau:
  * Cơ chế siêu lọc: Do áp lực của bơm máu cao hơn áp lực bơm dịch nên áp lực thủy tĩnh của khoang máu sẽ cao hơn áp lực ở khoang dịch, nước từ khoang máu sẽ di chuyển sang khoang dịch và kéo theo các chất hòa tan.
  * Cơ chế khuếch tán riêng phần: Các chất hòa tan như urê, creatinin và các chất có trọng lượng phân tử nhỏ khác có nồng độ cao trong máu sẽ khuếch tán từ máu sang khoang dịch lọc do sự chênh lệch nồng độ.
  * Cơ chế dòng đối lưu: Sau một thời gian khi chất tan ở khoang máu và khoang dịch lọc cân bằng nhau, quá trình khuếch tán sẽ giảm hiệu lực.


_Chỉ định chạy thận nhân tạo:_
  * Tất cả những người bệnh suy thận giai đoạn cuối phải điều trị thay thế khi khả năng làm việc của thận còn 10-15%, hay mức lọc cầu thận (MLCT) ≤ 15 ml/ phút/ 1.73 m2 .
  * Ở những bệnh nhân có bệnh lý kèm theo là đái tháo đường, có thể chỉ định sớm hơn.
  * Ngoài ra, kỹ thuật thận nhân tạo còn được áp dụng để lọc máu trong các trường hợp khác: Chỉ định lọc máu cấp cứu, ngộ độc,…
  * Lọc máu chu kỳ 1 tuần ≥ 12 giờ (mỗi lần lọc máu ít nhất 4 giờ, tuần 3 lần, cách ngày).


Chạy thận nhân tạo là một quy trình đòi hỏi sự nghiêm ngặt, kéo dài theo suốt cuộc đời, kết hợp với việc dùng thuốc và chế độ ăn uống hợp lý. Do đó, để đảm bảo an toàn và hiệu quả điều trị cao nhất, bệnh nhân cần lựa chọn cơ sở y tế chất lượng, tránh xảy ra các rủi ro biến chứng.
_Đối tượng chống_ _chỉ định tuyệt đối chạy thận nhân tạo:_ Không có đường lấy máu thích hợp.
_Đối tượng chống chỉ định tương đối chạy thận nhân:_ Trụy tim mạch, rối loạn nhịp tim, nhồi máu cơ tim và bệnh mạch vành, suy tim toàn bộ, rối loạn đông máu và chảy máu. Ngoài ra còn có: Người bệnh đang sốt cao, suy kiệt do ung thư.
## **2. Quy trình chạy thận nhân tạo**
Quy trình chạy thận nhân tạo là quá trình máu được lọc bằng máy chạy thận ngoài cơ thể. Khi lọc máu, máu được rút ra từ mạch máu, sau đó di chuyển qua quả lọc máu. Qủa lọc sẽ có tác dụng làm sạch máu, rồi đưa máu quay trở lại cơ thể bệnh nhân qua mạch máu. Qúa trình này diễn ra ít nhất 4h mỗi lần, ở bệnh nhân nhẹ thì 1 tuần lọc 2 lần, sau đó tăng lên 3 lần/ tuần.
– Theo dõi sau quá trình chạy thận nhân tạo:
Sau khi chạy thận nhân tạo cần phải theo dõi: Huyết áp, mạch ở các tư thế đứng, nằm; Các dấu hiệu của cao hoặc tụt huyết áp; Cân nặng của bệnh nhân,…
_Chú ý:_ Sau khi lọc máu, người bệnh không được ngủ gối đầu tay vì tăng nguy cơ tắc nghẽn, nhiễm trùng do sự phát sinh các cục máu đông.
_Các tai biến có thể xảy ra trong và sau khi chạy thận nhân tạo:_ Tụt huyết áp, chuột rút, buồn nôn, nôn, đau đầu, sốt, rét run, tắc mạch do khí, các biến chứng do thủ thuật,…
## **3. BHYT có chi trả cho bệnh nhân chạy thận nhân tạo không?**
Theo quy định của Bộ Y tế, chi phí cho mỗi lần chạy thận nhân tạo của bệnh nhân bao gồm 11 khoản (dây lọc máu, màng lọc, dịch sát khuẩn màng lọc,…). Trong đó BHYT thanh toán 7 khoản nhưng không vượt quá 543.000 đồng (đối với bệnh viện hạng một). Mức chi trả bảo hiểm còn phụ thuộc vào vấn đề người bệnh được thanh toán theo diện đồng chi trả 80%, 95% hay 100%; chạy thận ở bệnh viện nào.
Bệnh nhân chạy thận nhân tạo có 2 dạng là chạy thận cấp cứu (khi có bệnh lý cấp tính) và chạy thận chu kỳ. Bệnh nhân chạy thận cấp cứu lần đầu phải đặt cathete riêng, chi phí phần này khoảng 1 triệu đồng. Chi phí chạy thận chu kỳ tùy thuộc vào vật tư tiêu hao, trung bình khoảng 700.000 đến 1 triệu đồng một lần. Do đó, trong trường hợp bảo hiểm y tế chi trả 100%, người bệnh mỗi lần chạy thận còn phải đóng thêm khoảng 150.000-450.000 đồng nữa. Một số bệnh viện có quy định chi trả thêm vài phụ phí đi kèm như: Điện, nước,.. dao động trong khoảng 20-30 nghìn đồng.
Khoản chi phí chi trả thêm với nhiều bệnh nhân là con số đáng kể, vì số lần chạy thận chiếm khoảng thời gian dài và phải theo gần như suốt cuộc đời để duy trì sự sống. Cụ thể, người bệnh chạy thận nhân tạo chu kỳ thông thường được chỉ định chạy 3 lần mỗi tuần; Trường hợp bệnh nhẹ thì thời gian đầu 2 lần mỗi tuần, sau đó tăng lên 3 lần.
## **4. Chạy thận nhân tạo sống được bao lâu?**
Theo các chuyên gia, nếu bệnh nhân chạy thận nhân tạo đều đặn sẽ tăng khả năng sống lên 5-10 năm, có trường hợp lên đến 20-30 năm. Điều này phụ thuộc vào rất nhiều yếu tố: Mức độ bệnh, giai đoạn bệnh, chế độ ăn uống, chế độ luyện tập, khả năng kinh tế,…
## **5. Làm gì để tăng tuổi thọ cho bệnh nhân chạy thận nhân tạo?**
– Tuân thủ chỉ định điều trị của bác sĩ.
– Xây dựng chế độ sinh hoạt – dinh dưỡng nghiêm ngặt và hợp lý: Chế độ ăn giàu calo, cần ăn nhạt, không được ăn quá nhiều muối. Không sử dụng các đồ uống như: trà, cà phê, rượu, bia,… Chế độ ăn nhiều chất đạm, vitamin, ít nước, hạn chế thực phẩm nhiều kali, natri,…
– Tránh tập luyện và làm việc nặng, thái độ sống lạc quan, giảm căng thẳng, vận động nhẹ nhàng, dành nhiều thời gian hơn cho việc nghỉ ngơi.
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [1. Khi nào cần chạy thận nhân tạo?](https://bvnguyentriphuong.com.vn/than-loc-mau/chay-than-nhan-tao-nhung-dieu-can-biet#1khi-no-cn-chy-thn-nhn-to)
  * [2. Quy trình chạy thận nhân tạo](https://bvnguyentriphuong.com.vn/than-loc-mau/chay-than-nhan-tao-nhung-dieu-can-biet#2quy-trnh-chy-thn-nhn-to)
  * [3. BHYT có chi trả cho bệnh nhân chạy thận nhân tạo không?](https://bvnguyentriphuong.com.vn/than-loc-mau/chay-than-nhan-tao-nhung-dieu-can-biet#3bhyt-c-chi-tr-cho-bnh-nhn-chy-thn-nhn-to-khng)
  * [4. Chạy thận nhân tạo sống được bao lâu?](https://bvnguyentriphuong.com.vn/than-loc-mau/chay-than-nhan-tao-nhung-dieu-can-biet#4-chy-thn-nhn-to-sng-c-bao-lu)
  * [5. Làm gì để tăng tuổi thọ cho bệnh nhân chạy thận nhân tạo?](https://bvnguyentriphuong.com.vn/than-loc-mau/chay-than-nhan-tao-nhung-dieu-can-biet#5-lm-g-tng-tui-th-cho-bnh-nhn-chy-thn-nhn-to)



## ️ Thay huyết tương trong lupus ban đỏ rải rác

**ĐẠI CƯƠNG**
Thay huyết tương (plasma exchange) là phương pháp dùng máy tách huyết tương từ máu của người bệnh bỏ đi và truyền trả lại các thành phần hữu hình của máu cùng với huyết tương của người cho khoẻ mạnh hoặc sản phẩm thay thế. Kỹ thuật này được chỉ định đặc biệt cho những người bệnh có bằng chứng tăng rõ rệt phức hợp miễn dịch lưu hành trong máu, trong đó có đợt cấp của lupus ban đỏ hệ thống. Khi tiến hành biện pháp này người bệnh vẫn cần phải được điều trị bằng corticoid và/hoặc các thuốc ức chế miễn dịch khác.
**CHỈ ĐỊNH**
Đợt cấp của lupus ban đỏ hệ thống.
**CHỐNG CHỈ ĐỊNH**
**Không có chống chỉ định tuyệt đối.**
Thận trọng trong trường hợp người bệnh đang có chảy máu hoặc rối loạn đông máu nặng, người bệnh suy hô hấp, suy tuần hoàn hoặc đang nhiễm trùng nặng, người bệnh dị ứng với dây, quả lọc và các thuốc sử dụng. 
**CHUẨN BỊ**
**Người thực hiện**
02 bác sĩ chuyên khoa.
01 điều dưỡng chuyên khoa.
**Phương tiện**
_Chuẩn bị dụng cụ và vật tư tiêu hao:_
Máy lọc máu có chức năng thay huyết tương.
Màng tách huyết tương: 01 bộ.
Bộ dây lọc huyết tương: 01 bộ.
Catheter 2 nòng lọc máu: 01 bộ hoặc kim luồn to (cỡ 17 - 15 G): 02 cái (nếu không có catheter).
Bộ dụng cụ đặt catheter: 01 bộ.
Natri chlorua 0,9% - 500 ml: 10 chai.
Heparin 25000 UI: 01 lọ.
Lidocain 2%: 02 ống.
Calci clorua 10%: 04 ống.
Methylprednisolon: 02 lọ.
Dimedrol 10 mg: 02 ống.
Bơm 5ml: 05 cái.
Bơm 10ml: 04 cái.
Găng vô trùng: 04 đôi.
Găng khám: 03 đôi.
Săng vô trùng có lỗ: 02 cái.
Kim lấy thuốc: 05 cái.
Mũ, khẩu trang: 03 bộ.
Áo mổ: 02 bộ.
Gạc tiểu phẫu N2: 04 gói.
Băng dính: 01 cuộn.
Betadin 10%: 01 lọ.
Bộ làm kỹ thuật định nhóm máu: 01 bộ.
Dây truyền huyết thanh: 02 bộ.
Túi đựng dịch 2000 ml: 02 chiếc.
Dự trù 2000ml - 2500ml huyết tương đông lạnh cùng nhóm máu với người bệnh, hoặc dung dịch human albumin 20%: 500ml.
Bộ chống sốc..
**Người bệnh**
Người bệnh và người nhà được giải thích kỹ về quy trình kỹ thuật, mục đích, tai biến khi tiến hành kỹ thuật và ký giấy cam kết.
Khám toàn thân và bộ phận: chiều cao, cân nặng, nhiệt độ, mạch, huyết áp, tim mạch, hô hấp… 
**Xét nghiệm**
Công thức máu, nhóm máu.
Đông máu cơ bản.
Anti HIV, HBsAg, anti HCV.
Kháng thể kháng nhân, kháng thể kháng Ds DNA.
Sinh hoá máu: ure, creatinin, glucose, acid uric, protein, albumin, GOT, GPT, bộ mỡ, điện giải đồ, calci, các xét nghiệm miễn dịch (bổ thể, globulin miễn dịch…).
Tổng phân tích nước tiểu.
**Hồ sơ, bệnh án**
**CÁC BƯỚC TIẾN HÀNH**
**Kiểm tra hồ sơ, bệnh án**
Đối chiếu họ tên, tuổi người bệnh.
**Kiểm tra, thăm khám người bệnh**
**Thực hiện kỹ thuật**
Kỹ thuật nên được tiến hành ở phòng vô trùng, có đủ các trang thiết bị cấp cứu.
Người làm thủ thuật cần đội mũ, đeo khẩu trang, rửa tay theo quy trình, mặc áo mổ và đeo găng vô trùng. 
**Đường vào mạch máu**
Đặt catheter 2 nòng vào tĩnh mạch đùi, tĩnh mạch cảnh trong hoặc tĩnh mạch dưới đòn.
Nếu không có catheter 2 nòng có thể sử dụng kim luồn to: 1 kim đặt vào tĩnh mạch đùi để lấy máu ra và 1 kim đặt vào tĩnh mạch ở cẳng tay để trả máu về.
**Chú ý:** Cần thử test lidocain trước khi sử dụng để gây tê tại chỗ.
**Thiết lập vòng tuần hoàn ngoài cơ thể**
Bước 1: Chuẩn bị dịch thay thế bằng 2000 - 2500 ml huyết tương đông lạnh cùng nhóm máu hoặc 2500 ml dung dịch human albumin 5% bằng cách pha 500 ml human albumin 20% với 2000 ml natri clorua 0,9% (Thường sử dụng khoảng 2000 ml dịch thay thế). Nếu sử dụng huyết tương cần thực kiện kỹ thuật định nhóm máu người nhận và huyết tương người cho như trước khi truyền máu.
Bước 2: Chuẩn bị máy.
Khởi động máy lọc máu, lắp màng lọc và hệ thống dây dẫn theo chỉ dẫn.
Đuổi khí bằng 2000ml dung dịch natriclorua 0,9% có pha heparin 1000 đơn vị/lít.
Kiểm tra hệ thống an toàn của máy: các khoá an toàn, đầu tiếp nối.
Cài đặt bước đầu các thông số: Lưu lượng huyết tương thay thế, bilan dịch, tổng thể tích huyết tương thay thế, lưu lượng máu, thời gian tiến hành thủ thuật.
Bước 3: Kết nối hệ thống dây dẫn - quả lọc vào kim hoặc catheter trong lòng mạch tạo thành một hệ thống tuần hoàn khép kín.
Nối đường máu ra (nòng màu đỏ của catheter) với tuần hoàn ngoài cơ thể (đầu màu đỏ), bật bơm máu (tốc độ ban đầu khoảng 50 ml/phút), khi máu bắt đầu tới màng lọc thì bơm heparin liều ban đầu (2000 đơn vị), khi máu qua hết màng lọc thì dừng bơm, nối hệ thống tuần hoàn ngoài cơ thể (đầu màu xanh) với đường máu trở về (màu xanh) của catheter.
Bước 4: Kiểm tra các thông số áp lực, điều chỉnh các thông số cài đặt ban đầu cho phù hợp với mục đích điều trị và tình trạng lâm sàng của người bệnh.
Tốc độ máu: tăng dần cho đến 100 - 150 ml/phút.
Nhiệt độ: 37oC.
Chống đông heparin: duy trì 10 - 20 đơn vị/kg/giờ (500 - 1000 đơn vị/giờ).
Tốc độ dịch thay thế: 15 - 20 ml/phút (khoảng 500 - 1000 ml/giờ).
Tổng lượng huyết tương thay thế: 2000 - 2500ml.
Bilan dịch: Đặt bilan âm nếu muốn lấy nước ra khỏi cơ thể.
Thời gian lọc huyết tương: 2 - 3 giờ (giới hạn cho phép đến 8 giờ).
Calci 0,5g tiêm tĩnh mạch chậm 2 - 4 ống.
Bước 5: Kết thúc thủ thuật, dồn máu về khi hết thời gian lọc và hết lượng huyết tương thay thế. Nếu lưu catheter cần bơm rửa sạch hai nòng catheter bằng natrichlorua 0,9% và bơm vào mỗi bên nòng một lượng heparin đề phòng huyết khối gây tắc catheter, lượng heparin tuỳ thuộc vào từng loại catheter. Nếu sử dụng kim luồn thì rút kim sau khi kết thúc thủ thuật, băng ép chặt cầm máu.
**THEO DÕI**
Theo dõi ý thức, mạch, điện tim, huyết áp, tình trạng hô hấp.
Các thông số máy: áp lực vào - ra, áp lực xuyên màng…
Ghi chép vào hồ sơ bệnh án hoặc phiếu theo dõi: loại máy, đường vào mạch máu, loại quả lọc, thời gian lọc, liều chống đông, tốc độ rút máu, loại dịch và tổng lượng dịch thay thế, tổng lượng dịch rút ra; huyết áp trước, trong và sau lọc; xử trí bất thường (nếu có).
Xét nghiệm sinh hoá máu, công thức máu, đông máu, các xét nghiệm đặc hiệu sau thủ thuật để đánh giá hiệu quả điều trị.
Theo dõi tình trạng catheter nếu còn lưu catheter.
**TAI BIẾN VÀ XỬ TRÍ**
**Liên quan tới thủ thuật tạo đường vào mạch máu:**
Tụ máu tại chỗ, tràn khí màng phổi, tràn máu màng phổi, chảy máu trung thất. 
Cần phải hội chẩn chuyên khoa để xử trí.
**Nhiễm trùng tại chỗ chọc và nhiễm trùng huyết:**
Cần phải đảm bảo vô trùng khi tiến hành thủ thuật, có thể phải rút bỏ catheter, cấy máu, cấy chân catheter và cho kháng sinh (tốt nhất là theo kháng sinh đồ nếu có).
**Tụt huyết áp trong thủ thuật:**
Ít xảy ra, nếu có tụt huyết áp phải truyền bù bằng dung dịch natriclorua 0,9% hoặc dung dịch cao phân tử và tìm nguyên nhân để xử trí.
**Biến chứng xuất huyết:**
Có thể sử dụng chất trung hoà heparin (protamin sulphat). Cần tìm nguyên nhân để xử trí.
**Đông máu trong dây và quả lọc:**
Thường ít xảy ra do thời gian lọc ngắn. Nếu có tăng đông máu cần tính toán lại liều chống đông.
**Tình trạng dị ứng hoặc sốc do do dị ứng với dây hoặc màng lọc, hoặc dị ứng với huyết tương:**
Sử dụng dimedrol, methylprednisolon… theo phác đồ.
**TÀI LIỆU THAM KHẢO**
Bộ Y tế (2011), “Lọc máu cấp cứu”, Hướng dẫn quy trình kỹ thuật bệnh viện, tập II, Nhà xuất bản Y học, tr.609 - 612.
Vũ Văn Đính và cộng sự, “Thay huyết tương bằng máy”, Hồi sức cấp cứu toàn tập, Nhà xuất bản Y học.
Nguyễn Công Tấn, Nguyễn Gia Bình (2011), “Vai trò của thay huyết tương trong điều trị hội chứng Guillain Barre tại Khoa Hồi sức tích cực Bệnh viện Bạch Mai”, Y học Việt Nam, số 1, tập 386, tr.43-48.
Nguyễn Công Tấn, Nguyễn Gia Bình (2010), “ Bước đầu đánh giá hiệu quả của thay huyết tương trong điều trị cơn nhược cơ nặng tại khoa hồi sức tích cực Bệnh viện Bạch Mai”, Y học lâm sàng, số 55, tr.39 - 44.
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh

## ️ Siêu lọc máu chậm liên tục (Scuf)

**ĐẠI CƯƠNG**
Siêu lọc chậm liên tục (Slow Continuous Ultrafiltration - SCUF) là một trong những kỹ thuật điều trị thay thế thận liên tục. Đây là một kỹ thuật đơn giản, an toàn, mang lại nhiều lợi ích cho công tác điều trị tích cực những người bệnh có thừa nước trầm trọng do những nguyên nhân khác nhau. Trong kỹ thuật này lượng nước được lấy ra khỏi cơ thể chỉ đơn thuần bằng cơ chế đối lưu dựa vào áp lực xuyên màng vì vậy lượng nước thừa được lấy ra là chủ yếu, có kéo theo các chất hòa tan trong nước mà trọng lượng phân tử nhỏ đủ để lọt qua lỗ màng lọc. Thông thường lượng nước chỉ lấy ra khoảng 4 - 5 lít/24 giờ và không cần phải truyền bù dịch thay thế. 
**CHỈ ĐỊNH**
Thừa nước nhiều do suy thận hoặc hội chứng thận hư.
Thừa nước nhiều do suy tim nặng.
Thừa nước nhiều nhưng không đáp ứng với các biện pháp điều trị thông thường, có nguy cơ biến chứng phù phổi cấp.
**CHỐNG CHỈ ĐỊNH**
**Không có chống chỉ định tuyệt đối**
_Chống chỉ định tương đối:_
Rối loạn đông máu, đang có chảy máu.
Thiếu khối lượng dịch trong lòng mạch.
Huyết áp thấp do các nguyên nhân khác nhau.
**CHUẨN BỊ**
**Người thực hiện**
02 bác sĩ: 01 bác sĩ chuyên khoa làm chính và 01 bác sĩ phụ.
01 điều dưỡng chuyên khoa.
**Phương tiện và vật tư tiêu hao**
Máy để tiến hành siêu lọc chậm.
Bộ dây quả lọc: 01 bộ.
Catheter 2 nòng để lọc máu: 01 bộ hoặc kim luồn to (cỡ 17 - 15 G): 02 cái (nếu không có catheter).
Bộ dụng cụ đặt catheter: 01 bộ.
Natrichlorua 0,9% - 500 ml: 06 chai.
Heparin 25000 UI: 01 lọ.
Lidocain 2%: 02 ống.
Calci clorua 10%: 04 ống.
Methylprednisolon: 02 lọ.
Bơm 5ml: 05 cái.
Bơm 10ml: 04 cái.
Găng vô trùng: 04 đôi.
Găng khám: 04 đôi.
Săng vô trùng có lỗ: 02 cái.
Kim lấy thuốc: 05 cái.
Mũ khẩu trang: 03 bộ.
Áo mổ: 02 bộ.
Gạc tiểu phẫu N2: 04 gói.
Băng dính: 01 cuộn.
Betadin 10%: 01 lọ.
Dây truyền huyết thanh: 02 bộ.
Túi đựng dịch 2000 ml: 03 cái.
Bộ chống sốc.
**Người bệnh**
Người bệnh được giải thích kỹ về quy trình kỹ thuật, mục đích, tai biến khi tiến hành kỹ thuật và ký giấy cam kết.
_Đánh giá lâm sàng:_
Chiều cao, cân nặng, nhiệt độ, mạch, huyết áp, tim mạch, hô hấp, tình trạng phù... 
_Đánh giá cận lâm sàng:_
Công thức máu, nhóm máu.
Đông máu cơ bản.
Anti HIV, HBsAg, anti HCV.
Sinh hoá máu: ure, creatinin, glucose, protein, albumin, GOT, GPT, điện giải đồ, calci.
Tổng phân tích nước tiểu.
**Hồ sơ, bệnh án**
**CÁC BƯỚC TIẾN HÀNH**
**Kiểm tra hồ sơ, bệnh án**
Kiểm tra họ tên, tuổi người bệnh…
**Kiểm tra, thăm khám người bệnh**
**Thực hiện kỹ thuật**
Kỹ thuật nên được tiến hành ở phòng vô trùng, có đủ các trang thiết bị cấp cứu.
Người làm thủ thuật cần đội mũ, đeo khẩu trang, rửa tay theo quy trình, mặc áo mổ và đeo găng. 
**Đường vào mạch máu**
Đặt catheter 2 nòng vào tĩnh mạch đùi, tĩnh mạch cảnh trong hoặc tĩnh mạch dưới đòn.
Nếu không có catheter 2 nòng có thể sử dụng 2 kim luồn to: 01 kim đặt vào tĩnh mạch đùi để lấy máu ra và 1 kim đặt vào tĩnh mạch ở cẳng tay để trả máu về.
Chú ý: Cần thử test lidocain trước khi sử dụng để gây tê tại chỗ.
**Thiết lập vòng tuần hoàn ngoài cơ thể**
**Bước 1:** Chuẩn bị máy.
Khởi động máy lọc máu, lắp màng lọc và hệ thống dây dẫn theo chỉ dẫn.
Đuổi khí bằng 2000 ml dung dịch natriclorua 0,9% có pha heparin 1000 đơn vị/lít.
Kiểm tra hệ thống an toàn của máy: các khoá an toàn, đầu tiếp nối.
Cài đặt bước đầu các thông số: Bilan dịch, lượng lượng máu, thời gian tiến hành thủ thuật.
**Bước 2:** Kết nối hệ thống dây dẫn - quả lọc vào kim hoặc catheter trong lòng mạch tạo thành một hệ thống tuần hoàn khép kín.
Nối đường máu ra (nòng màu đỏ của catheter) với tuần hoàn ngoài cơ thể (đầu màu đỏ), bật bơm máu (tốc độ ban đầu khoảng 50 ml/phút), khi máu bắt đầu tới màng lọc thì bơm heparin liều ban đầu (2000 đơn vị), khi máu qua hết màng lọc thì dừng bơm, nối hệ thống tuần hoàn ngoài cơ thể (đầu màu xanh) với đường máu trở về (màu xanh) của catheter.
**Bước 3:** Kiểm tra các thông số áp lực, điều chỉnh các thông số cài đặt ban đầu cho phù hợp với mục đích điều trị và tình trạng lâm sàng của người bệnh.
Tốc độ máu: tăng dần cho đến 80 - 100 ml/phút.
Nhiệt độ: 37oC.
Tốc độ siêu lọc trung bình 500 - 800 ml/ giờ.
Liều lượng heparin trung bình 500 đơn vị/giờ
Trung bình lấy ra khoảng 4 - 5 lít trong một kỳ lọc dài khoảng 6 - 8 giờ.
**Bước 4:** Kết thúc thủ thuật, dồn máu về khi hết thời gian siêu lọc. Nếu lưu catheter cần bơm rửa sạch hai nòng catheter bằng natrichlorua 0,9% và bơm vào mỗi bên nòng một lượng heparin đề phòng huyết khối gây tắc catheter, lượng heparin tuỳ thuộc vào từng loại catheter. Nếu sử dụng kim luồn thì rút kim sau khi kết thúc thủ thuật, băng ép chặt cầm máu.
**THEO DÕI**
Theo dõi người bệnh: lập bảng theo dõi ý thức, mạch, điện tim, huyết áp, áp lực tĩnh mạch trung tâm (CVP), tình trạng hô hấp.
Các thông số máy: áp lực vào - ra, áp lực xuyên màng…
Ghi chép hồ sơ bệnh án hoặc phiếu theo dõi: Loại máy, đường vào mạch máu, loại quả lọc, thời gian lọc, liều chống đông, tốc độ rút máu, tổng lượng dịch rút ra; huyết áp trước, trong và sau lọc; xử trí bất thường (nếu có).
Sau buổi lọc: tiếp tục theo dõi mạch, huyết áp, nhiệt độ, nước tiểu, tình trạng chảy máu ít nhất 8 giờ tiếp theo.
Xét nghiệm sau thủ thuật: điện giải đồ, công thức máu, đông máu. Theo dõi tình trạng catheter nếu còn lưu catheter.
**TAI BIẾN VÀ XỬ TRÍ**
**Liên quan tới thủ thuật tạo đường vào mạch máu:**
Tụ máu tại chỗ, tràn khí màng phổi, tràn máu màng phổi, chảy máu trung thất.
Cần phải hội chẩn chuyên khoa để xử trí.
**Nhiễm trùng tại chỗ chọc và nhiễm trùng huyết:**
Cần phải đảm bảo vô trùng khi tiến hành thủ thuật, có thể phải rút bỏ catheter, cấy máu, cấy chân catheter và cho kháng sinh (tốt nhất là theo kháng sinh đồ nếu có).
**Tụt huyết áp do siêu lọc nhanh:**
Giảm bớt tốc độ siêu lọc, có thể bù thêm dung dịch keo hoặc albumin nếu cần.
Biến chứng xuất huyết: có thể sử dụng chất trung hoà heparin (protamin sulphat).
Cần tìm nguyên nhân để xử trí.
**Đông máu trong bộ dây và quả lọc:**
Cần tính toán lại liều chống đông. Nếu cần thiết có thể xả dịch bằng natriclorua 0,9%; nếu đông máu nhiều phải dừng thủ thuật.
Tình trạng dị ứng hoặc sốc do dị ứng với dây hoặc màng lọc, hoặc dị ứng với huyết tương: sử dụng dimedrol, methylprednisolon… theo phác đồ.
**TÀI LIỆU THAM KHẢO**
Bộ Y tế (2011), “Lọc máu cấp cứu”, Hướng dẫn quy trình kỹ thuật bệnh viện, tập II, Nhà xuất bản Y học, tr.609 – 612.
Robert M Winrow, Suhail Ahmad, “Continuous therapies”, Manual of clinical dialysis, Second edition, p.95-122.
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh

## ️ Rút catheter đường hầm

**ĐẠI CƯƠNG**
Rút catheter đường hầm để lọc máu được chỉ định khi người bệnh không cần lọc máu tiếp do chức năng thận đã hồi phục, ví dụ như trong suy thận cấp hoặc khi người bệnh đã hết tình trạng viêm phúc mạc, việc lọc màng bụng liên tục đã được trở về bình thường hoặc người bệnh đã làm được đường vào mạch máu tốt hơn như AVF, Graft. Rút catheter kịp thời khi chỉ định đã hết sẽ hạn chế nguy cơ nhiễm trùng đường hầm và chân catheter. 
**CHỈ ĐỊNH**
Khi người bệnh không còn cần sử dụng đến catheter đường hầm cho việc lọc máu.
Nhiễm trùng. 
**CHỐNG CHỈ ĐỊNH**
Không có chống chỉ định tuyệt đối.
**CHUẨN BỊ**
**Người thực hiện**
Bác sĩ: 01 bác sĩ thực hiện thủ thuật. 
Một điều dưỡng: phụ giúp các bác sĩ tiến hành thủ thuật.
**Phương tiện**
Giường thực hiện thủ thuật: 01 chiếc
Dung dịch Betadin sát trùng: 01 lọ
Săng vô khuẩn loại có lỗ: 04 chiếc
Panh kẹp xăng: 04 chiếc
Nước muối sinh lý 0,9%: 500ml
Kim tiêm, bơm tiêm 5ml: 01 chiếc
Bơm tiêm 20ml: 02 chiếc
Bông băng, gạc vô trùng: 04 gói
Găng tay vô trùng: 03 đôi
Bộ dụng cụ và thuốc chống choáng, chống sốc phản vệ.
**Người bệnh**
Người bệnh đã được làm các xét nghiệm về đông máu cơ bản và các xét nghiệm cơ bản khác.
Người bệnh và người nhà được nghe bác sĩ giải thích kỹ về thủ thuật và ký vào giấy cam kết đồng ý làm thủ thuật.
**Hồ sơ bệnh án**
Bệnh án được hoàn thiện với các thủ tục dành cho người bệnh tiến hành làm thủ thuật. 
**CÁC BƯỚC TIẾN HÀNH**
**Kiểm tra hồ sơ**
Kiểm tra các xét nghiệm đã được làm. 
**Kiểm tra người bệnh**
Đối chiếu tên, tuổi, chẩn đoán bệnh.
**Thực hiện kỹ thuật**
Người bệnh được kiểm tra mạch, huyết áp trước khi tiến hành thủ thuật. 
Người bệnh được nằm ngửa, đầu nghiêng tư thế Trendelenburg, đầu quay 45o về phía đối diện.
Bác sĩ rửa tay, đi găng vô trùng, mặc áo thủ thuật.
Tháo băng catheter và đường hầm.
Sát trùng sạch vùng đường hầm và chân catheter.
Kiểm tra chỉ cố định chân catheter. Cắt chân chỉ cố định và rút catheter. Ép khoảng 15 phút.
Băng vùng đường hầm và chân catheter.
Cho người bệnh về giường bệnh. 
**THEO DÕI**
Các thông số sinh tồn: toàn trạng, mạch, huyết áp, nhịp thở. Kiểm soát đau.
**TAI BIẾN VÀ XỬ TRÍ**
**Chảy máu**
Băng ép hoặc khâu lại nếu cần thiết.
Sử dụng thuốc cầm máu.
**Nhiễm trùng**
Sử dụng kháng sinh theo kháng sinh đồ là tốt nhất nếu không có thể sử dụng kháng sinh phổ rộng. 
**TÀI LIỆU THAM KHẢO**
Scott O. Trerotola. 2000. Hemodialysis Catheter Placement and Management. Radiology. 215:651-658. 
Julie AG, Alan DK. 2012. Ultrasound-Guided Central vein Cannulation: Current recommendations and guideline. Anesthesiology News. June: 1-6. 
Gibbs FJ, Murphy MC. 2006. Ultrasound Guidance for Central venous catheter placement. Hospital physician. March: 23-31. 
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh

## ️ Rút catheter tĩnh mạch đùi chạy thận nhân tạo cấp cứu

**ĐẠI CƯƠNG**
Rút catheter tĩnh mạch đùi để lọc máu cấp cứu được chỉ định khi người bệnh không cần lọc máu tiếp do chức năng thận đã hồi phục, ví dụ như trong suy thận cấp hoặc khi người bệnh đã hết tình trạng viêm phúc mạc, việc lọc màng bụng liên tục đã được trở về bình thường hoặc người bệnh đã làm được đường vào mạch máu tốt hơn như AVF, Graft. Rút catheter kịp thời khi chỉ định đã hết sẽ hạn chế nguy cơ nhiễm trùng do catheter. 
**CHỈ ĐỊNH**
Khi người bệnh không còn cần sử dụng đến catheter đùi cho việc lọc máu.
Nhiễm trùng. 
**CHỐNG CHỈ ĐỊNH**
Không có chống chỉ định tuyệt đối.
**CHUẨN BỊ**
**Người thực hiện**
01 bác sĩ thực hiện thủ thuật. 
01 điều dưỡng: phụ giúp các bác sĩ tiến hành thủ thuật.
**Phương tiện**
GIường thực hiện thủ thuật: 01 chiếc.
Dung dịch betadin sát trùng: 01 lọ.
Săng vô khuẩn loại có lỗ: 04 chiếc.
Panh kẹp xăng: 04 chiếc.
Nước muối sinh lý 0,9%: 500ml.
Kim tiêm, bơm tiêm 5ml: 01 chiếc.
Bơm tiêm 20ml: 02 chiếc.
Bông băng, gạc vô trùng: 04 gói.
Găng tay vô trùng: 03 đôi.
Bộ dụng cụ và thuốc chống choáng, chống sốc phản vệ.
**Người bệnh**
Người bệnh đã được làm các xét nghiệm về đông máu cơ bản và các xét nghiệm cơ bản khác.
Người bệnh và người nhà được nghe bác sĩ giải thích kỹ về thủ thuật và ký vào giấy cam kết đồng ý làm thủ thuật.
**Hồ sơ bệnh án**
Bệnh án được hoàn thiện với các thủ tục dành cho người bệnh tiến hành làm thủ thuật. 
**CÁC BƯỚC TIẾN HÀNH**
**Kiểm tra hồ sơ**
Kiểm tra các xét nghiệm đã được làm. 
**Kiểm tra người bệnh**
Đối chiếu tên, tuổi, chẩn đoán bệnh.
**Thực hiện kỹ thuật**
Người bệnh được theo dõi mạch, huyết áp trước khi tiến hành thủ thuật. 
Người bệnh được nằm ngửa, bộc lộ vùng bẹn có catheter.
Bác sĩ rửa tay, đi găng vô trùng, mặc áo thủ thuật.
Tháo băng catheter. 
Sát trùng sạch vùng bẹn và chân catheter.
Kiểm tra chỉ cố định chân catheter. Cắt chân chỉ cố định và rút catheter. Ép khoảng 15 phút.
Băng vùng chân catheter.
Cho người bệnh về giường bệnh. 
**THEO DÕI**
Các thông số sinh tồn: toàn trạng, mạch, huyết áp, nhịp thở.
Kiểm soát đau.
**TAI BIẾN VÀ XỬ TRÍ**
Chảy máu: băng ép hoặc khâu lại nếu cần thiết. Sử dụng thuốc cầm máu.
Nhiễm trùng: sử dụng kháng sinh theo kháng sinh đồ là tốt nhất nếu không có thể sử dụng kháng sinh phổ rộng. 
**TÀI LIỆU THAM KHẢO**
Scott O. Trerotola. 2000. Hemodialysis Catheter Placement and Management. Radiology. 215:651-658. 
Julie AG, Alan DK. 2012. Ultrasound-Guided Central vein Cannulation: Current recommendations and guideline. Anesthesiology News. June: 1-6. 
Gibbs FJ, Murphy MC. 2006. Ultrasound Guidance for Central venous catheter placement. Hospital physician. March: 23-31.
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh

## ️ Nối thông động tĩnh mạch sử dụng mạch nhân tạo

**ĐẠI CƯƠNG**
Thông động tĩnh mạch tự thân là lựa chọn tốt nhất để làm đường mạch máu cho người bệnh lọc máu chu kỳ. Trong thực tế, một số lượng người bệnh không có hệ mạch ngoại vi đáp ứng được yêu cầu tạo thông động tĩnh mạch: tĩnh mạch hạn chế, nhỏ, không thẳng, hoặc tĩnh mạch đã bị phá hủy do tiêm truyền, các thuốc khi tiêm truyền. Do đó, mạch nhân tạo, có chất liệu từ PTFE, được đưa vào sử dụng.
Có rất nhiều kiểu thiết kế về hình dạng cho mạch nhân tạo dùng tạo nối thông: thẳng, quai, và đầu nối động mạch vuốt nhỏ nhằm tránh hiện tượng lỗ thông có tốc độ dòng máu quá cao. Đi cùng với thiết kế, vị trí nối cũng đa dạng: động mạch quay-tĩnh mạch cánh tay, động mạch cánh tay-tĩnh mạch cánh tay (dạng quai), động mạch cánh tay-tĩnh mạch nách, động mạch cánh tay-tĩnh mạch cảnh trong,...
**CHỈ ĐỊNH**
_Người bệnh có chỉ định lọc máu chu kỳ và:_
Không thể tạo được thông động tĩnh mạch dùng mạch tự thân (hệ tĩnh mạch không cho phép/đã thất bại nhiều lần).
Người bệnh có yêu cầu vị trí nối thông động tĩnh mạch (do công việc và giao tiếp xã hội) và tại vị trí đó không thể thực hiện được với tĩnh mạch tự thân.
**CHỐNG CHỈ ĐỊNH**
Hội chứng suy tim sung huyết có EF<30%.
Rối loạn đông cầm máu: số đếm tiểu cầu <50.000/ml.
Chống chỉ định tương đối: người bệnh nguy cơ nhiễm trùng cao/suy giảm miễn dịch.
**CHUẨN BỊ**
**Người thực hiện**
01 hoặc 02 bác sĩ chuyên ngành Thận - Lọc máu được đào tạo phẫu thuật mạch máu.
02 điều dưỡng.
**Phương tiện**
**Thuốc**
Thuốc gây tê tại chỗ: lidocain 1%. 
Thuốc an thần: seduxen 10mg.
Heparin 5000UI/ml.
Kháng sinh: cefazolin 1g (dự phòng nhiễm khuẩn).
Dụng cụ 
**Hình 1. Đánh dấu vị trí của Graft trên da**
Bộ dụng cụ phẫu thuật thường.
01 dụng cụ vi phẫu phẫu thuật mạch máu.
01 bộ tunneler đưa tĩnh mạch đi ngầm dưới da.
Một đoạn mạch nhân tạo, dài 50cm, đường kính 6mm.
**Người bệnh**
Người bệnh có thể được thực hiện theo điều trị nội trú hay ngoại trú.
Có đầy đủ các xét nghiệm cơ bản.
Có đầy đủ thăm dò hình ảnh động mạch/tĩnh mạch của thông động tĩnh mạch.
Được giải thích rõ lý do thực hiện phẫu thuật, các lợi ích cũng như khó khăn của phương pháp.
Người bệnh nhịn ăn trước 6 tiếng.
Rửa tay bằng xà phòng diệt khuẩn.
**Hình 2. Đưa Graft đi ngầm dưới da**
**Hồ sơ bệnh án**
Bệnh án chi tiết.
Có đủ các xét nghiệm.
Đông máu cơ bản.
Huyết học, sinh hóa, chức năng gan,…
**CÁC BƯỚC TIẾN HÀNH**
**Chuẩn bị người bệnh**
Người bệnh được giải thích rõ toàn bộ quá trình phẫu thuật.
Được cắt toàn bộ móng tay, rửa sạch toàn bộ cánh tay bằng xà phòng diệt khuẩn.
Tư thế: nằm ngửa.
Tay phẫu thuật để ngang thân người, đặt trên bàn mổ.
Đặt máy theo dõi mạch, huyết áp, SpO2 trong quá trình thực hiện phẫu thuật.
Đánh dấu các vị trí đặt Graft dưới da lên da (**Hình 1**).
**Hình 3. Khâu nối Graft với động mạch và tĩnh mạch**
**Phương pháp vô cảm**
Gây tê đám rối hay gây tê dưới da bằng lidocain 1%.
**Kỹ thuật**
Bộc lộ động mạch.
Bộc lộ tĩnh mạch.
Luồn mạch nhân tạo đi dưới da theo vị trí định trước (**Hình 2**).
Khâu nối mạch nhân tạo với tĩnh mạch.
Khâu nối mạch nhân tạo với động mạch (**Hình 3**).
Kiểm tra toàn bộ hệ Graft, lưu thông máu trong Graft.
Cầm màu miệng nối và vết mổ.
Đóng da.
**THEO DÕI**
**Trong khi tiến hành thủ thuật**
Theo dõi mạch, nhiệt độ, huyết áp, tri giác.
**Sau khi tiến hành thủ thuật**
Theo dõi mạch, nhiệt độ, huyết áp, tri giác.
Kiểm tra lưu thông máu qua lỗ thông.
Khám/đánh giá quá trình phát triển của thông động tĩnh mạch sau 1 tháng.
Xem xét đưa thông động tĩnh mạch vào sử dụng sau 1 tháng.
**TAI BIẾN VÀ XỬ TRÍ**
Tắc thông động tĩnh mạch: thường do xoắn vặn mạch nhân tạo trong quá trình tạo đường hầm đi dưới da. Mở lại và định vị lại vị trí tĩnh mạch.
**TÀI LIỆU THAM KHẢO**
Ingemar J.A. Davidson, 2008. Access for Dialysis : Surgical and Radiologic Procedures, 2nd edition (ISBN: 1-57059-627-1).
Oxford University Press, 2008. Oxford Textbook of Clinical Nephrology, p.1909- 1926(Third Edition 2008) (ISBN-10: 0198508247 ISBN-13: 978-0198508243) 3. Brenner and Rector, 2008. The Kidney, 2008. (ISBN 978-1-4160-3105-5).
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh

## ️ Thay huyết tương (plasma exchange)

**ĐẠI CƯƠNG**
Thay huyết tương (Plasma Exchange - PE) là một trong các biện pháp lọc máu nhằm mục đích tách và loại bỏ phần huyết tương của người bệnh đồng thời thay thế bằng một lượng huyết tương tươi đông lạnh (FFP) tương đương phần tách ra hoặc albumin 5% cho người bệnh.
**CHỈ ĐỊNH**
Suy gan cấp.
Trong một số bệnh tự miễn: nhược cơ, hội chứng Guillain - Barre, xuất huyết giảm tiểu cầu, lupus ban đỏ hệ thống, viêm cầu thận lupus tiến triển, viêm cầu thận tiến triển nhanh, hội chứng Goodpasture’s.
Thải ghép cấp. 
**CHỐNG CHỈ ĐỊNH**
Rối loạn đông máu nặng.
**CHUẨN BỊ**
**Người thực hiện**
01 bác sĩ, 01 điều dưỡng, 01 kỹ thuật viên.
**Phương tiện**
Tên, số lượng của thiết bị, dụng cụ, vật tư tiêu hao (định hướng, ước lượng…). 
Hệ thống máy lọc - thay huyết tương.
01 catheter lọc máu hai nòng để tạo đường vào mạch máu.
Quả lọc huyết tương.
Bộ dây lọc máu tương thích với máy và quả lọc.
Phin lọc khí: 04 cái.
Bơm kim tiêm 10ml, 20ml: 2 cái.
Găng vô trùng: 04 đôi.
Huyết tương tươi đông lạnh, tùy thuộc vào chỉ định, thông thường 2000ml/ lần thay huyết tương.
Hoặc albumin 5% với số lượng tương đương huyết tương tươi đông lạnh.
NaCl 0,9% 500ml x 03 chai
Thuốc chống đông heparin x 4000UI
Gạc vô trùng N2 x 10 miếng
Dung dịch betadin 10% 100ml x 1/2 lọ 
Túi nhựa thải huyết tương của người bệnh x 01 cái
**Người bệnh**
Được giải thích rõ về phương pháp điều trị kí cam kết đồng ý làm thủ thuật.
Được đặt catheter lọc máu để có đường vào mạch máu tạm thời ở cổ hoặc bẹn trước đó.
**Hồ sơ bệnh án**
Hồ sơ bệnh án đầy đủ thủ tục hành chính.
Có cam đoan của người bệnh và gia đình. 
Đủ xét nghiệm cần thiết trước khi tiến hành: CTM, Chức năng gan thận, điện giải đồ Na, K, Cl, Ca, đông máu cơ bản, các xét nghiệm miễn dịch tùy theo yêu cầu của bệnh.
**CÁC BƯỚC TIẾN HÀNH**
**Kiểm tra hồ sơ**
Đủ các nội dung theo yêu cầu.
**Kiểm tra người bệnh**
Khám lâm sàng chung, mạch, HA, Nhịp thở, nhiệt độ, số lượng nước tiểu, 
**Thực hiện kỹ thuật**
Chuẩn bị máy: kiểm tra máy theo các thông số kỹ thuật, cài đặt các thông số trên máy bao gồm: tốc độ lọc, tổng số thể tích huyết tương cần tách, heparin…
Lắp bộ lọc và rửa hệ thống dây quả bằng dung dịch NaCl 9% có pha heparin dự phòng tắc quả lọc.
Chuẩn bị plasma tươi đông lạnh hoặc albumin 5% để thay thế. Số lượng tùy thuộc vào cân nặng từng người bệnh, trung bình 2000ml.
Lưu ý: nguy cơ dị ứng nếu dùng plasma tươi đông lạnh, nguy cơ chảy máu nếu dùng albumin.
Kết nối người bệnh và máy lọc như quy trình lọc máu thông thường. 
Tiến hành lọc huyết tương theo lập trình trên máy.
**THEO DÕI**
Theo dõi tình trạng chung của người bệnh, mạch, HA, nhiệt độ, nhịp thở, tình trạng chảy máu… trong suốt quá trình lọc.
Theo dõi phản ứng dị ứng với huyết tương thay thế.
**TAI BIẾN VÀ XỬ TRÍ**
Tai biến có thể gặp: dị ứng với huyết tương thay thế, chảy máu, tắc màng, nhiễm trùng, tắc mạch…. 
Xử trí tùy vào từng trường hợp cụ thể có biện pháp xử trí phù hợp.
**TÀI LIỆU THAM KHẢO**
Pusey CD. (1991) Plasma exchange in focal necrotizing glomerulonephritis without anti - GBM antibodies. Kidney Int 40 (4): 757-763.
Davis R.W. et al. (2007) Randomized trial of plasma Exchange or High - Dose Methylprednisolone as adjunctive therapy for severe renal vasculitis. JASN Apr. 
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh

## ️ Lọc máu chu kỳ bằng kỹ thuật thận nhân tạo

**ĐẠI CƯƠNG**
Người bệnh suy thận giai đoạn cuối phải điều trị thay thế, bao gồm thận nhân tạo, lọc màng bụng, ghép thận. Trong đó thận nhân tạo được áp dụng phổ biến nhất.
Thận nhân tạo là thiết lập vòng tuần hoàn ngoài cơ thể có lưu lượng máu từ 200 - 400 ml/phút thời gian kéo dài từ 4 - 8 giờ. Vì có nhiều khâu kỹ thuật và thời gian theo dõi dài nên có rất nhiều nguy cơ do vậy nhất thiết phải chuẩn hoá các bước, xây dựng thành quy trình chặt chẽ để tránh các biến chứng có thể xảy ra trong buổi lọc.
**CHỈ ĐỊNH**
Người bệnh suy thận giai đoạn cuối phải điều trị thay thế khi mức lọc cầu thận (MLCT) ≤ 15 ml/ phút/ 1.73 m2. Ở người bệnh đái tháo đường có thể chỉ định sớm hơn.
Ngoài ra, kỹ thuật thận nhân tạo áp dụng để lọc máu trong các trường hợp khác: chỉ định lọc máu cấp cứu, ngộ độc,...
Lọc máu chy kỳ 1 tuần ≥ 12 giờ (mỗi lần lọc máu ít nhất 4 giờ, tuần 3 lần, cách ngày).
**CHỐNG CHỈ ĐỊNH**
Tim mạch: trụy tim mạch, rối loạn nhịp tim, nhồi máu cơ tim và bệnh mạch vành, suy tim toàn bộ.
Rối loạn đông máu và chảy máu: chỉ là chống chỉ định tương đối, có thể cùng phối hợp lọc máu và thay máu.
Toàn trạng: người bệnh đang sốt cao, suy kiệt do ung thư. 
**CÁC BƯỚC TIẾN HÀNH**
**Chuẩn bị, khởi động máy**
Mở hệ thống nước, quan sát hoạt động toàn bộ hệ thống nước, tháo bỏ phần nước ứ đọng, kiểm tra lưu lượng và độ dẫn điện của hệ thống nước.
Kiểm tra máy thận, lưu lượng 500 ml/phút, không còn chất sát trùng, kiểm tra độ dẫn điện dịch lọc, kiểm tra các báo động an toàn của máy thận.
Kiểm tra hệ thống oxy, điện và các thiết bị khác.
**Bác sĩ kiểm tra tình trạng người bệnh trước khi lọc máu**
Tình trạng lâm sàng, cận lâm sàng của người bệnh trong 24 giờ trước đó: điện tim, phim Xquang tim phổi, tình trạng tim mạch hiện tại.
Các thuốc và điều trị gần đây nhất: các chỉ định, các thay đổi liều lượng thuốc.
**Các chỉ số sinh hoá thông thường và các xét nghiệm gần nhất:**
Điện giải đồ, calci, phospho.
pH, CO2, acid uric.
Hemoglobin, hematocrit.
Protein máu.
Tình trạng đông máu.
Men tim.
Nhóm máu Rh và sự ngưng kết bất thường.
Tiền sử dị ứng. 
**Các chỉ định cho buổi lọc:**
Các xét nghiệm trước và sau lọc.
Thời gian lọc.
Lưu lượng (vận tốc) máu.
Siêu lọc (rút cân).
Thuốc chống đông, liều lượng và cách dùng.
Quả lọc.
**Các chỉ định theo dõi điều trị:**
Trong buổi lọc.
Kết thúc buổi lọc.
Chuẩn bị người bệnh lọc máu chu kỳ
**Điều dưỡng chuẩn bị:**
Cân người bệnh: Không quên trừ bì (giầy dép, quần áo…).
Nếu nghi ngờ có thể cân lại nhiều lần.
Ghi chính xác cân nặng cho người bệnh.
Đo huyết áp, mạch người bệnh ở tư thế đứng, nằm.
Các thông số được ghi chép cẩn thận vào sổ theo dõi người bệnh.
**Người bệnh trải ga, nằm lên giường chuẩn bị lọc máu.**
**Tay FAV của người bệnh phải được sát trùng cẩn thận, rộng rãi.**
**Nối vòng tuần hoàn ngoài cơ thể**
_Tư thế người bệnh và chuẩn bị chọc tay:_
Người bệnh phải được nằm đúng tư thế, thuận lợi, nằm hoặc nửa nằm, giường cao vừa phải.
Máy lọc thận đã sẵn sàng, không có một báo động nào.
_Các bước chuẩn bị dụng cụ:_
Mở hộp vô trùng đựng các dụng cụ lọc máu, tránh nhiễm trùng.
Lắp quả lọc: Kiểm tra đối chiếu tên tuổi người bệnh tránh nhầm lẫn. Đuổi hơi thật kỹ, để tốc độ bơm từ 90 - 120 ml/phút đồng thời vỗ nhẹ tay vào quả lọc đảm bảo cho khí không còn trong quả lọc, khi còn khoảng 300ml dịch thì quay vòng dịch trong quả lọc với heparin, các râu của đường dây phải được xả rửa sạch.
Điều dưỡng và người bệnh đeo khẩu trang.
Chuẩn bị găng.
Chuẩn bị gạc đã thấm chất sát trùng.
Đặt kim trên khay đựng kim vô trùng. 
Chuẩn bị các ống để lấy máu bên cạnh khay.
Đi găng vô trùng.
Lấy săng vô trùng.
Nâng cao tay người bệnh.
Trải săng dưới tay người bệnh.
Người bệnh đặt tay xuống.
Chuẩn bị băng dính.
Sát trùng lại tay người bệnh bằng miếng gạc đã thấm chất sát trùng.
Ga rô.
_Chọc FAV:_
Xác định bằng đầu ngón tay đường đi mạch máu (FAV)
Chọc FAV: kim “động mạch” hướng về phía miệng nối, kim “tĩnh mạch” hướng lên cao (ngược kim động mạch).
Cố định kim bằng băng dính vô trùng.
Thông kim bằng cách mở nút sau đó siết chặt lại ngay.
Đóng khoá kim lại.
Thực hiện lấy bệnh phẩm.
Chương trình lọc máu và theo dõi người bệnh:
Đặt chương trình lọc máu: 
Phải đặt chương trình trước khi nối vòng tuần hoàn vào người bệnh.
Thời gian lọc máu.
Số cân rút.
Liều heparin tấn công, duy trì.
Kiểm tra hoạt động bơm heparin.
Để theo dõi tốt FAV: bộc lộ tay để quan sát được rõ.
_Nối vòng tuần hoàn:_
Các chức năng của máy đã sẵn sàng.
Kẹp đường dây “động mạch”.
Nối đường dây “động mạch” với kim “động mạch” của người bệnh.
Mở kẹp ở kim “động mạch” sau đó mở kẹp ở dây “động mạch”.
Kiểm tra bơm máu đang ở vị trí 0 ml/phút sau đó cho bơm máu chạy, máu người bệnh sẽ được hút theo bơm, nước muối sinh lý trong dây và quả lọc bị đẩy về túi đựng nước thải, máu dâng dần trong vòng tuần hoàn - tấn công liều heparin - khi máu đến bầu xanh (bầu tĩnh mạch). Dừng bơm máu.
Kẹp đường dây “tĩnh mạch”, kiểm tra xem có khí trong vòng tuần hoàn không.
Nối đường “tĩnh mạch” với kim “tĩnh mạch” của người bệnh.
Khi nối các đầu dây nhớ sát trùng các điểm nối.
Cho bơm tăng dần tốc độ 100ml/phút.
Kiểm tra áp lực động mạch tĩnh mạch trên màn hình.
Tăng tốc độ máu lên từ từ.
Chỉ định liều heparin duy trì.
Bấm nút Dialyse.
Kiểm tra các đèn báo an toàn của máy.
Kiểm tra đường dây trên ga, cố định đường đây vào ga, không để dây quét, quệt trên đất, tránh vướng phải.
**Theo dõi buổi lọc máu**
_Các tiêu chí theo dõi trong buổi lọc máu:_
Huyết áp, mạch của người bệnh từng giờ.
Kiểm tra áp lực động mạch, tĩnh mạch, áp lực xuyên màng.
Theo dõi nồng độ dịch lọc (thành phần Na+ và bicarbonat).
Theo dõi đường huyết ở người bệnh tiểu đường.
Toàn trạng trạng người bệnh.
Tất cả các dấu hiệu phải ghi chép đầy đủ.
Trả máu về cho người bệnh - kết thúc buổi lọc
Trả máu lại máu cho người bệnh là đưa toàn bộ máu ở vòng tuần hoàn vào cơ thể người bệnh và kết thúc buổi lọc.
Trên màn hình thời gian là 0.00 -> kết thúc buổi lọc máu.
**Trả máu cho người bệnh**
Dừng bơm máu, kẹp kim “động mạch” và dây “động mạch”.
Tháo kim “động mạch” với đường dây “động mạch”, nối đường dây “động mạch” với dịch NaCl 0,9 % chai 500ml, mở kẹp đường “động mạch”, cho bơm máu chạy với tốc độ thấp, nước muối sẽ đẩy máu từ từ vào cơ thể người bệnh đến khi quả lọc, đường dây sạch máu. Trong thời gian trả mau vỗ nhẹ vào quả lọc và kẹp nhẹ vào đường dây để trách máu tồn đọng trong vòng tuần hoàn.
Trả lại máu ở kim “động mạch” cho người bệnh bằng bơm tiêm có nước muối sinh lý.
Dừng bơm máu khi vòng tuần hoàn đã sạch máu.
**Kết thúc buổi lọc**
Kẹp kim “tĩnh mạch” và đường dây”tĩnh mạch”
Đấu hai đầu dây lại và cho quả lọc vào túi
Rút kim FAV ra khỏi tay người bệnh, ép vào điểm chọc 15 - 20 phút.
**Theo dõi sau buổi lọc**
Sau khi lọc các tham số cần phải theo dõi:
Huyết áp, mạch ở các tư thế đứng, nằm.
Các dấu hiệu của cao hoặc tụt huyết áp.
Cân người bệnh: cân lúc kết thúc phải bằng cân khô.
Dấu hiệu của người bệnh do rút cân quá hoặc rút không đủ.
Ghi các chỉ số vào sổ theo dõi, ghi rõ các sai sót so với protocol.
Điều dưỡng lau máy và rửa máy theo chương trình, chuẩn bị ca lọc tiếp theo.
**TAI BIẾN - XỬ TRÍ**
Tụt huyết áp: tắt siêu lọc, bù lưu lượng tuần hoàn.
Chuột rút: bù dịch NaCl 0,9% hoặc muối ưu trương.
Buồn nôn, nôn: xử trí theo nguyên nhân. Ví dụ: do tụt huyết áp, hội chứng mất cân bằng, phản ứng màng lọc.
Đau đầu.
Đau ngực, đau lưng.
Sốt, rét run: do quả lọc bẩn, nước không đạt chất lượng.
Hội chứng mất cân bằng.
Phản ứng với màng lọc.
Loạn nhịp tim.
Co giật.
Tan máu.
Tắc mạch do khí.
Các biến chứng khác do thủ thuật,...
**TÀI LIỆU THAM KHẢO**
Nguyễn Nguyên Khôi, Trần Văn Chất (2004) “Thận nhân tạo” Bệnh học nội khoa, Nhà xuất bản Y học, Tr. 250 - 260.
Donald, LL (2002) “Pre - end - stage renal disease and dialysis programs: The view of the manager” Hemodialysis Technology, Karger, P311- 317.
Eric Delmas (1997) “Procedure de mise en ouvre d’une dialyse” L’epuration extra - Renale, ISBN: 2- 84204- 013- 9, ISSN: 1275- 3289, P54 - 60.
Suhail Ahmad (2009) “Complications of Hemodialysis” Manual of Clinical dialysis, Springer, P59 - 76.
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh

## ️ Rút catheter tĩnh mạch trung tâm chạy thận nhân tạo cấp cứu

  * [Người thực hiện](https://bvnguyentriphuong.com.vn/than-loc-mau/rut-catheter-tinh-mach-trung-tam-chay-than-nhan-tao-cap-cuu#ngi-thc-hin)
  * [CÁC BƯỚC TIẾN HÀNH](https://bvnguyentriphuong.com.vn/than-loc-mau/rut-catheter-tinh-mach-trung-tam-chay-than-nhan-tao-cap-cuu#cc-bc-tin-hnh)
  * [Kiểm tra người bệnh ](https://bvnguyentriphuong.com.vn/than-loc-mau/rut-catheter-tinh-mach-trung-tam-chay-than-nhan-tao-cap-cuu#kim-tra-ngi-bnh)
  * [Thực hiện kỹ thuật ](https://bvnguyentriphuong.com.vn/than-loc-mau/rut-catheter-tinh-mach-trung-tam-chay-than-nhan-tao-cap-cuu#thc-hin-k-thut)
  * [TAI BIẾN VÀ XỬ TRÍ](https://bvnguyentriphuong.com.vn/than-loc-mau/rut-catheter-tinh-mach-trung-tam-chay-than-nhan-tao-cap-cuu#tai-bin-v-x-tr)
  * [TÀI LIỆU THAM KHẢO](https://bvnguyentriphuong.com.vn/than-loc-mau/rut-catheter-tinh-mach-trung-tam-chay-than-nhan-tao-cap-cuu#ti-liu-tham-kho)


### **ĐẠI CƯƠNG**
Rút catheter trung tâm để lọc máu cấp cứu được chỉ định khi người bệnh không cần lọc máu tiếp do chức năng thận đã hồi phục, ví dụ như trong suy thận cấp hoặc khi người bệnh đã hết tình trạng viêm phúc mạc, việc lọc màng bụng liên tục đã được trở về bình thường hoặc người bệnh đã làm được đường vào mạch máu tốt hơn như AVF, Graft. Rút catheter kịp thời khi chỉ định đã hết sẽ hạn chế nguy cơ nhiễm trùng catheter. 
### **CHỈ ĐỊNH**
Khi người bệnh không còn cần sử dụng đến catheter tĩnh mạch trung tâm cho việc lọc máu cấp cứu.
Nhiễm trùng 
### **CHỐNG CHỈ ĐỊNH**
Không có chống chỉ định tuyệt đối.
### **CHUẨN BỊ**
#### **Người thực hiện**
01 bác sĩ thực hiện thủ thuật. 
01 điều dưỡng: phụ giúp các bác sĩ tiến hành thủ thuật.
#### **Phương tiện**
Giường thực hiện thủ thuật: 01 chiếc
Dung dịch betadin sát trùng: 01 lọ
Săng vô khuẩn loại có lỗ: 04 chiếc
Panh kẹp xăng: 04 chiếc
Nước muối sinh lý 0,9%: 500ml
Kim tiêm, bơm tiêm 5ml: 01 chiếc
Bơm tiêm 20ml: 02 chiếc
Bông băng, gạc vô trùng: 04 gói
Găng tay vô trùng: 03 đôi
Bộ dụng cụ và thuốc chống choáng, chống sốc phản vệ.
#### **Người bệnh**
Người bệnh đã được làm các xét nghiệm về đông máu cơ bản và các xét nghiệm cơ bản khác.
Người bệnh và người nhà được nghe bác sĩ giải thích kỹ về thủ thuật và ký vào giấy cam kết đồng ý làm thủ thuật.
#### **Hồ sơ bệnh án**
Bệnh án được hoàn thiện với các thủ tục dành cho người bệnh tiến hành làm thủ thuật. 
### **CÁC BƯỚC TIẾN HÀNH**
#### **Kiểm tra hồ sơ**
Kiểm tra các xét nghiệm đã được làm. 
#### **Kiểm tra người bệnh**
Đối chiếu tên, tuổi, chẩn đoán bệnh.
#### **Thực hiện kỹ thuật**
Người bệnh được theo dõi mạch, huyết áp trước khi tiến hành thủ thuật 
Người bệnh được nằm ngửa, đầu nghiêng tư thế Trendelenburg, đầu quay 45o về phía đối diện.
Bác sĩ rửa tay, đi găng vô trùng, mặc áo thủ thuật.
Tháo băng catheter và đường hầm.
Sát trùng sạch vùng chân catheter.
Kiểm tra chỉ cố định chân catheter. Cắt chân chỉ cố định và rút catheter. Ép khoảng 15 phút.
Băng vùng chân catheter.
Cho người bệnh về giường bệnh. 
### **THEO DÕI**
Các thông số sinh tồn: toàn trạng, mạch, huyết áp, nhịp thở.
Kiểm soát đau.
### **TAI BIẾN VÀ XỬ TRÍ**
Chảy máu: băng ép hoặc khâu lại nếu cần thiết. Sử dụng thuốc cầm máu.
Nhiễm trùng: sử dụng kháng sinh theo kháng sinh đồ là tốt nhất nếu không có thể sử dụng kháng sinh phổ rộng. 
### **TÀI LIỆU THAM KHẢO**
Scott O. Trerotola. 2000. Hemodialysis Catheter Placement and Management. Radiology. 215:651-658. 
Julie AG, Alan DK. 2012. Ultrasound-Guided Central vein Cannulation: Current recommendations and guideline. Anesthesiology News. June: 1-6. 
Gibbs FJ, Murphy MC. 2006. Ultrasound Guidance for Central venous catheter placement. Hospital physician. March: 23-31. 
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [Người thực hiện](https://bvnguyentriphuong.com.vn/than-loc-mau/rut-catheter-tinh-mach-trung-tam-chay-than-nhan-tao-cap-cuu#ngi-thc-hin)
  * [CÁC BƯỚC TIẾN HÀNH](https://bvnguyentriphuong.com.vn/than-loc-mau/rut-catheter-tinh-mach-trung-tam-chay-than-nhan-tao-cap-cuu#cc-bc-tin-hnh)
  * [Kiểm tra người bệnh ](https://bvnguyentriphuong.com.vn/than-loc-mau/rut-catheter-tinh-mach-trung-tam-chay-than-nhan-tao-cap-cuu#kim-tra-ngi-bnh)
  * [Thực hiện kỹ thuật ](https://bvnguyentriphuong.com.vn/than-loc-mau/rut-catheter-tinh-mach-trung-tam-chay-than-nhan-tao-cap-cuu#thc-hin-k-thut)
  * [TAI BIẾN VÀ XỬ TRÍ](https://bvnguyentriphuong.com.vn/than-loc-mau/rut-catheter-tinh-mach-trung-tam-chay-than-nhan-tao-cap-cuu#tai-bin-v-x-tr)
  * [TÀI LIỆU THAM KHẢO](https://bvnguyentriphuong.com.vn/than-loc-mau/rut-catheter-tinh-mach-trung-tam-chay-than-nhan-tao-cap-cuu#ti-liu-tham-kho)



## ️ Sinh thiết thận ghép sau ghép thận dưới hướng dẫn của siêu âm

**ĐẠI CƯƠNG**
Ghép thận hiện là một trong các phương pháp điều trị thay thế thận ở các người bệnh bị bệnh thận mạn tính giai đoạn cuối do các nguyên nhân khác nhau. Ghép thận ngày càng được phát triển rộng rãi trên thế giới cũng như trong nước.
Tình trạng suy giảm chức năng thận sau ghép thận do nhiều nguyên nhân gây nên. Sinh thiết thận ghép sau ghép thận là một thủ thuật cần thiết phải được tiến hành ở những người bệnh sau ghép thận khi có giảm sút chức năng thận ghép. Các mẫu sinh thiết thận ghép được làm xét nghiệm giải phẫu bệnh với nhiều phương pháp khác nhau sẽ đánh giá được các tổn thương thận ghép và các nguyên nhân gây nên suy giảm chức năng thận ghép.
**CHỈ ĐỊNH**
Thải ghép.
Tăng cao creatinin máu không rõ nguyên nhân.
Ngộ độc thuốc chống thải ghép.
Có protein niệu sau ghép thận.
Nghi ngờ có bệnh thận mạn tính sau ghép thận.
**CHỐNG CHỈ ĐỊNH**
Rối loạn đông máu.
Người bệnh đang trong tình trạng nhiễm trùng, nhiễm độc.
**CHUẨN BỊ**
**Những người thực hiện**
Bác sĩ: 02 người.
Điều dưỡng hoặc kỹ thuật viên: 01 người.
**Phương tiện**
Dung dịch betadine sát trùng: 01 lọ.
Thuốc gây tê lidocaine 2%: 04 ống 10mg/ml-2 ml.
Nước muối sinh lý 0,9%: 200ml.
Bơm, kim tiêm 5ml: 01 chiếc.
Bông băng gạc vô trùng: 04 gói.
Găng tay vô trùng: 03 đôi.
Săng vô khuẩn: 04 chiếc.
Panh kẹp săng.
Khăn trải bàn thủ thuật: 01 chiếc.
Bàn thủ thuật: 01 bàn.
Bộ đầu dò: 01 bộ.
Súng sinh thiết: 01 chiếc.
Kim chuyên dụng để sinh thiết thận: 01 chiếc.
Túi nilon vô khuẩn bọc đầu dò siêu âm: 01 bộ.
Máy siêu âm có đầu dò 7,5 MHz và 3,5 MHz.
Dung dịch formol: 10ml.
Lọ đựng bệnh phẩm sinh thiết. 
**Người bệnh**
Người bệnh được làm các xét nghiệm cơ bản và đông máu cơ bản.
Người bệnh và người nhà được nghe bác sĩ giải thích kỹ về tác dụng và tai biến của thủ thuật. Gia đình ký vào giấy cam kết đồng ý làm thủ thuật. 
**Hồ sơ bệnh án**
Hoàn thiện bệnh án và chẩn đoán.
**CÁC BƯỚC TIẾN HÀNH**
**Kiểm tra hồ hơ**
Kiểm tra các xét nghiệm đã được làm. 
**Kiểm tra người bệnh**
Đối chiếu tên, tuổi, chẩn đoán bệnh.
**Thực hiện kỹ thuật**
Người bệnh được thử phản ứng với thuốc gây tê lidocaine.
Người bệnh được theo dõi mạch, huyết áp trước khi tiến hành thủ thuật. 
Người bệnh được nằm ngửa trên bàn, hai chân duỗi thẩng.
Định vị bằng siêu âm để tìm điểm sinh thiết thận.
Bác sĩ rửa tay, đi găng vô trùng, mặc áo thủ thuật, đội mũ, đeo khẩu trang.
Sát trùng da vùng định sinh thiết (bên hố chậu phải hoặc trái tùy vào vị trí ghép thận).
Trải ga, săng vô khuẩn. 
Gây tê vùng định chọc kim sinh thiết qua da bằng kim nhỏ. 
Chọc kim sinh thiết vào vị trí cực dưới của thận ghép dưới sự hướng dẫn của siêu âm.
Khi kim sinh thiết đã vào vùng định sinh thiết thì tiến hành cắt 01 mảnh tổ chức thận.
Rút súng sinh thiết, lấy mảnh tổ chức thận để vào miếng gạc có tẩm nước nuối sinh lý để gửi đến Khoa Giải phẫu bệnh làm xét nghiệm miễn dịch huỳnh quang. Sau rút súng sinh thiết phải ấn chặt cầm máu vị trí sinh thiết.
Sinh thiết lần 2, mảnh sinh thiết được cho vào lọ đựng formol, gửi đến Khoa Giải phẫu bệnh làm xét nghiệm dưới kính hiển vi quang học. 
Ấn cầm máu điểm sinh thiết trong vòng 5 phút.
Siêu âm kiểm tra lại thận ghép.
Sát khuẩn lại vùng sinh thiết.
Băng ép nhẹ vùng sinh thiết thận ghép.
Cho người bệnh về giường nằm bất động 24 giờ.
**Theo dõi**
Người bệnh cần được theo dõi mạch, nhiệt độ, huyết áp, màu sắc nước tiểu, vị trí sinh thiết thận ghép và toàn trạng. 
Sau sinh thiết, người bệnh cần được cho làm xét nghiệm tổng phân tích nước tiểu ngay khi đi tiểu được.
**TAI BIẾN VÀ XỬ TRÍ**
**Đau vị trí sinh thiết:**
Nếu đau nhiều có thể dùng thuốc giảm đau như paracetamol, nospa uống hoặc tiêm. 
**Đái máu vi thể:**
Theo dõi, không cần xử trí.
**Đái máu đại thể:**
Đái máu ít: truyền thêm natriclorua 9% hoặc glucose 5%, theo dõi chặt chẽ mạch, huyết áp, toàn trạng. 
Đái máu nhiều cần cho người bệnh siêu âm kiểm tra lại thận ghép xem có dò động - tĩnh mạch thận hay không. Có thể tiêm thuốc tranxenamic acid 250mg x 2- 4ống. 
Nếu có đái máu nhiều thường do rò động mạch - tĩnh mạch thận gây tụt huyết áp cần truyền máu sau đó cho người bệnh làm các thăm dò và xét nghiệm chẩn đoán. Trong trường hợp nặng có thể phải giải quyết triệt để bằng nút mạch thận hoặc phẫu thuật.
**TÀI LIỆU THAM KHẢO**
Iftikhar Ahmad (2004). Biopsy of the Transplanted Kidney. Semin Intervent Radiol. December; 21(4), 275-281.
Lefaucheur C, Nochy D, Bariety J(2009). Renal biopsy: procedures, contraindications, complications. Nephrol Ther. Jul 5(4), 331-339. 
William L. Whittier and Stephen M. Korbet (2004). Timing of Complications in Percutaneous Renal Biopsy. JASN January 1(15), 1 142-147.
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh

## ️ Lọc máu - thẩm phân phúc mạc

  * [Thẩm phân phúc mạc là gì?](https://bvnguyentriphuong.com.vn/noi-than-tiet-nieu/loc-mau-tham-phan-phuc-mac#thm-phn-phc-mc-l-g)
  * [Quá trình thực hiện có đau không?](https://bvnguyentriphuong.com.vn/noi-than-tiet-nieu/loc-mau-tham-phan-phuc-mac#qu-trnh-thc-hin-c-au-khng)
  * [Trong quá trình thực hiện thủ thuật](https://bvnguyentriphuong.com.vn/noi-than-tiet-nieu/loc-mau-tham-phan-phuc-mac#trong-qu-trnh-thc-hin-th-thut)
  * [Thực hiện thay dịch](https://bvnguyentriphuong.com.vn/noi-than-tiet-nieu/loc-mau-tham-phan-phuc-mac#thc-hin-thay-dch)
  * [Thay đổi chế độ ăn](https://bvnguyentriphuong.com.vn/noi-than-tiet-nieu/loc-mau-tham-phan-phuc-mac#thay-i-ch-n)
  * [So sánh với chạy thận nhân tạo](https://bvnguyentriphuong.com.vn/noi-than-tiet-nieu/loc-mau-tham-phan-phuc-mac#so-snh-vi-chy-thn-nhn-to)


## **Thẩm phân phúc mạc là gì?**
Thẩm phân phúc mạc là biện pháp điều trị dành cho bệnh suy thận. Nó hoạt động như là thận nhân tạo và giúp cơ thể thải trừ các chất cặn và hỗ trợ duy trì cân bằng dịch. Phương pháp này sử dụng lớp màng bao phủ của ổ bụng  lọc máu ở bên trong cơ thể.
Bệnh nhân sẽ được đặt một ống catheter mềm vào bên trong bụng. Vài tuần sau đó thì bệnh nhân sẽ cho dung dịch thẩm phân vào bụng thông qua ống catheter đó.
Sau khi đã hoàn tất, bệnh nhân có thể tháo túi ra và đậy nắp ống catheter lại, quay trở lại hoạt động bình thường. Một vài giờ sau, bệnh nhân sẽ mở ống catheter lại và đổ dịch ra ngoài. Động tác này được gọi là thay dịch.
Bệnh nhân có thể sẽ phải thay dịch 4-6 lần mỗi ngày.
## **Quá trình thực hiện có đau không?**
Quá trình thực hiện thường sẽ không đau. Bệnh nhân có thể sẽ cảm thấy bình thường hoặc đầy hơi một chút khi cho dịch vào trong ổ bụng.
Vì nguyên nhân này nên bệnh nhân có thể sẽ cảm thấy thoải mái hơn khi mặc quần áo rộng rãi.
**Phân loại**
Có hai loại thẩm phân phúc mạc.
**Loại thứ nhất được gọi là thẩm phân phúc mạc liên tục (CAPD).** Đây là một phương pháp liên tục không dùng máy.
Bệnh nhân sẽ cho khoảng 2 lít dịch vào trong bụng, một thời gian thì đổ ra hết. Phải thay dịch khoảng 4 đến 5 lần trong 24 giờ. Một lần thay dịch mất khoảng 30-40 phút.
Một số bệnh nhân thường hay thay dịch trước giờ ngủ và giờ ăn.
**Loại thứ hai được gọi là thẩm phân phúc mạc thay dịch tự động (APD).** Phương pháp này kết nối ống catheter vào một máy thay tự động, máy này sẽ tự động thay dịch khi bệnh nhân ngủ.
Máy thường sẽ cho dịch thẩm phân vào bụng bệnh nhân vào đầu ngày, và bệnh nhân sẽ tự thay dịch trong ngày. Một tên gọi khác của phương pháp này là thẩm phân phúc mạc liên tục theo chu kỳ (CCPD).
Bệnh nhân có thể tham khảo ý kiến bác sĩ trước khi quyết định lực chọn phương pháp điều trị.
**Thủ thuật gắn ống catheter**
Bệnh nhân sẽ được gây tê tại chỗ khi gắn ống catheter thẩm phân phúc mạc.
Một vài bệnh nhân nếu có nhu cầu thì có được gắn ống sau khi đã gây mê tổng quát để không cảm nhận được quá trình thực hiện.
## **Chuẩn bị**
Bệnh nhân được khuyến cáo không ăn hay uống sau 12 giờ đêm ngày trước đặt ống, điều này đặc biệt quan trọng đối với bệnh nhân lựa chọn gây mê tổng quát.
Bệnh nhân nên sắp xếp trước người chở về nhà sau khi thực hiện thủ thuật.
Bệnh nhân nên tham khảo ý kiến chuyên gia về các vật liệu cần đến để có thể bảo quản ống catheter bên trong người.
## **Trong quá trình thực hiện thủ thuật**
Thủ thuật có thể khác nhau tùy theo lựa chọn của bác sĩ. Tuy nhiên, những bước cơ bản thường là:
  1. Rửa sạch vùng bụng trước khi thực hiện đường mổ.
  2. Bác sĩ thực hiện đường mổ, thường thì sẽ nằm phía dưới lệch phải hoặc trái một chút so với rốn.
  3. Sau đó ống catheter sẽ được đưa vào trong ổ bụng.


Theo khuyến cáo thì bệnh nhân nên được đặt ống 3 tuần trước khi thực hiện thay dịch lần đầu, v ống catheter sẽ hoạt động tốt hơn nếu có được khoảng 10 - 20 ngày để lành vết thương trước lần sử dụng đầu tiên.
## **Hướng dẫn**
Bệnh nhân sẽ được hướng dẫn để có thể thực hiện thẩm phân phúc mạc tại nhà. Một nhân viên y tế sẽ hướng dẫn bệnh nhân trong vòng 1 - 2 tuần. Bệnh nhân sẽ được hướng dẫn cách chuẩn bị máy thay, cách đặt ống dẫn lưu và cách gắn các túi dịch thẩm phân.
Tốt nhất bệnh nhân có thể đi cùng với người thân đến để cùng nghe bác sĩ hướng dẫn về quy trình thực hiện.
Kể cả khi bệnh nhân sử dụng biện pháp thay dịch tự động APD thì cũng cần phải học cách thay túi dịch mà không sử dụng máy để đề phòng trường hợp máy bị hư hoặc mất điện.
Việc phòng ngừa nhiễm trùng là rất quan trọng khi thực hiện thẩm phân phúc mạc, do đó bệnh nhân hoặc người thân cần được hướng dẫn kỹ càng các biện pháp vô trùng.
## **Thực hiện thay dịch**
Trước khi thay dịch, người thay cần phải rửa tay sạch sẽ và mang khẩu trang.
Sau đó người thay sẽ sử dụng một thiết bị kết nối giữa ống catheter và túi dịch.
Để thay dịch bằng tay, người thay cần làm ấm túi dịch đến nhiệt độ cơ thể bằng cách:
  * Sử dụng chăn điện
  * Ngâm túi dịch vào nước ấm
  * Sử dụng lò vi sóng nếu như bao chứa dịch có thể cho vào lò


Sau đó treo túi lên cao và kết nối túi qua dây dẫn để dịch chảy vào cơ thể.
Nếu như bệnh nhân sử dụng thay dịch tự động APD, máy sẽ tự động làm ấm túi dịch. Bệnh nhân có thể thiết lập chương trình cho máy để thực hiện một vài chu kỳ trong 1 đêm.
Cả hai phương pháp đều cần sử dụng ống catheter để rút dịch ra khỏi ổ bụng. Nếu như sử dụng thay dịch tự động APD thì có thể nên dùng một bộ dụng cụ chuyển đổi dài hơn để có thể xả dịch vào toilet, bồn tắm, hay một vật chứa khác vào ban đêm.
Lượng và loại dịch thẩm phân còn phụ thuộc vào tình trạng sức khỏe của từng cá nhân và chỉ định của bác sĩ.
## **Thay đổi chế độ ăn**
Các bệnh nhân sử dụng thẩm phân phúc mạc được khuyến cáo nên thay đổi chế độ ăn của mình.
Các sự thay đổi có thể bao gồm lượng natri, phospho và kali trong khẩu phần, đây là các chất điện giải lọc qua thận.
Bệnh nhân lọc máu cần dùng thêm thực phẩm chức năng để thay thế cho các chất dinh dưỡng bị thiếu hụt do hạn chế dùng các thực phẩm chứa hàm lượng kali cao.
Thẩm phân phúc mạc loại bỏ protein, do đó, bệnh nhân cần phải tiêu thụ một lượng protein lớn hơn bình thường.
Bệnh nhân cần hạn chế uống nước. Do thận không thể lọc nước nên lượng dịch sẽ tích tụ lại bên trong cơ thể. Bệnh nhân sẽ được khuyến cáo lượng nước dùng mỗi ngày.
## **Biến chứng**
Một biến chứng thường gặp của thẩm phân phúc mạc là viêm phúc mạc. Đây là tình trạng nhiễm trùng ở lớp phúc mạc - lớp mô bao bọc ổ bụng. Thường tình trạng này xảy ra là do vi trùng xâm nhập vào ống catheter.
Các triệu chứng của viêm phúc mạc bao gồm đau bụng, sốt, và dịch từ ổ bụng đi ra có màu đục. Nếu như có các triệu chứng trên thì nên đến bệnh viện ngay để có thể được điều trị kịp thời bằng kháng sinh.
Các biến chứng khác bao gồm:
  * Thoát vị, hoặc cơ ở vùng bụng có catheter bị yếu đi do phẫu thuật đặt ống và áp lực của dịch bên trong ổ bụng đẩy ra ngoài
  * Nhiễm trùng ở vị trí ống catheter
  * Hạ huyết áp, hoặc huyết áp thấp, có thể xảy ra do bệnh nhân mất quá nhiều dịch giữa các lần thay
  * Tăng cân do dịch thẩm phân có dextrose chứa nhiều calories


## **So sánh với chạy thận nhân tạo**
Chạy thận nhân tạo và thẩm phân phúc mạc là hai phương pháp điều trị hiệu quả đối với bệnh suy thận.
Thẩm phân phúc mạc trao đổi dịch và chất thải thông qua phúc mạc. Chạy thận nhân tạo trao đổi dịch và chất thải thông qua máu.
Để thực hiện chạy thận nhân tạo thì bệnh nhân cần phải đến một trung tâm lọc máu. Thay vì đặt catheter vào bụng thì bệnh nhân sẽ được đặt catheter vào cánh tay.
Một vài bác sĩ ưu tiên tư vấn thẩm phấn phúc mạc do tính tiện lợi, bệnh nhân có thể tự thực hiện tại nhà, không cần phải đều đặn đến trung tâm lọc máu.
Hiện vẫn chưa có nghiên cứu nào kết luận được bệnh nhân chạy thận nhân tạo hay bệnh nhân thẩm phân phúc mạc có chất lượng cuộc sống tốt hơn.
Trong một vài trường hợp thì thẩm phân phúc mạc có lẽ không phù hợp, do béo phì, hay có nhiều sẹo từ những lần phẫu thuật trước.
## **Tóm tắt**
Thẩm phân phúc mạc là một phương pháp điều trị dành cho bệnh nhân suy thận. Phương pháp này sử dụng lớp màng bao bọc ổ bụng để lọc máu bên trong cơ thể.
Sau khi đã được hướng dẫn, bệnh nhân có thể tự thực hiện tại nhà, không cần phải đi đến trung tâm lọc máu để chạy thận.
Bệnh nhân cũng cần phải thực hiện một số thay đổi trong chế độ ăn để cải thiện chức năng thận.
Xem thêm: [**Lọc màng bụng liên tục ngoại trú- Continuous ambulatory peritoneal dialysis (CAPD)**](https://bvnguyentriphuong.com.vn/than-loc-mau/loc-mang-bung-lien-tuc-ngoai-tru-continuous-ambulatory-peritoneal-dialysis-capd)
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [Thẩm phân phúc mạc là gì?](https://bvnguyentriphuong.com.vn/noi-than-tiet-nieu/loc-mau-tham-phan-phuc-mac#thm-phn-phc-mc-l-g)
  * [Quá trình thực hiện có đau không?](https://bvnguyentriphuong.com.vn/noi-than-tiet-nieu/loc-mau-tham-phan-phuc-mac#qu-trnh-thc-hin-c-au-khng)
  * [Trong quá trình thực hiện thủ thuật](https://bvnguyentriphuong.com.vn/noi-than-tiet-nieu/loc-mau-tham-phan-phuc-mac#trong-qu-trnh-thc-hin-th-thut)
  * [Thực hiện thay dịch](https://bvnguyentriphuong.com.vn/noi-than-tiet-nieu/loc-mau-tham-phan-phuc-mac#thc-hin-thay-dch)
  * [Thay đổi chế độ ăn](https://bvnguyentriphuong.com.vn/noi-than-tiet-nieu/loc-mau-tham-phan-phuc-mac#thay-i-ch-n)
  * [So sánh với chạy thận nhân tạo](https://bvnguyentriphuong.com.vn/noi-than-tiet-nieu/loc-mau-tham-phan-phuc-mac#so-snh-vi-chy-thn-nhn-to)



## ️ Triệu chứng thường gặp trong hội chứng thận hư

  * [1. Protein niệu](https://bvnguyentriphuong.com.vn/than-loc-mau/trieu-chung-thuong-gap-trong-benh-hoi-chung-than-hu#1-protein-niu)
  * [2. Giảm albumin máu](https://bvnguyentriphuong.com.vn/than-loc-mau/trieu-chung-thuong-gap-trong-benh-hoi-chung-than-hu#2-gim-albumin-mu)
  * [Có 2 cơ chế chính để bù trừ lại sự mất albumin qua nước tiểu:](https://bvnguyentriphuong.com.vn/than-loc-mau/trieu-chung-thuong-gap-trong-benh-hoi-chung-than-hu#c-2-c-ch-chnh-b-tr-li-s-mt-albumin-qua-nc-tiu)
  * [Tổng hợp albumin ở gan gia tăng:](https://bvnguyentriphuong.com.vn/than-loc-mau/trieu-chung-thuong-gap-trong-benh-hoi-chung-than-hu#tng-hp-albumin-gan-gia-tng)
  * [Cơ chế giảm áp lực keo huyết tương](https://bvnguyentriphuong.com.vn/than-loc-mau/trieu-chung-thuong-gap-trong-benh-hoi-chung-than-hu#c-ch-gim-p-lc-keo-huyt-tng)
  * [Những cơ chế tại thận đặc hiệu](https://bvnguyentriphuong.com.vn/than-loc-mau/trieu-chung-thuong-gap-trong-benh-hoi-chung-than-hu#nhng-c-ch-ti-thn-c-hiu)
  * [Cơ chế của tăng Lipid trong hội chứng thận hư được giải thích do các yếu tố sau đây:](https://bvnguyentriphuong.com.vn/than-loc-mau/trieu-chung-thuong-gap-trong-benh-hoi-chung-than-hu#c-ch-ca-tng-lipid-trong-hi-chng-thn-h-c-gii-thch-do-cc-yu-t-sau-y)
  * [Tăng tổng hợp ở gan Lipoprotein tỷ trọng thấp rất thấp (VLDL)](https://bvnguyentriphuong.com.vn/than-loc-mau/trieu-chung-thuong-gap-trong-benh-hoi-chung-than-hu#tng-tng-hp-gan-lipoprotein-t-trng-thp-rt-thp-vldl)
  * [Giảm men Lipoprotein Lipase (LPL)](https://bvnguyentriphuong.com.vn/than-loc-mau/trieu-chung-thuong-gap-trong-benh-hoi-chung-than-hu#gim-men-lipoprotein-lipase-lpl)
  * [Giảm men Lecithin cholesterol acyl transferase (LCAT)](https://bvnguyentriphuong.com.vn/than-loc-mau/trieu-chung-thuong-gap-trong-benh-hoi-chung-than-hu#gim-men-lecithin-cholesterol-acyl-transferase-lcat)
  * [Mất qua nước tiểu HDL và apo A1](https://bvnguyentriphuong.com.vn/than-loc-mau/trieu-chung-thuong-gap-trong-benh-hoi-chung-than-hu#mt-qua-nc-tiu-hdl-v-apo-a1)
  * [Giảm hoạt động tiêu fibrin do giảm plasminogene và tăng antiplasmine (alpha 2 macroglobuline, alpha 2 antiplasmine).](https://bvnguyentriphuong.com.vn/than-loc-mau/trieu-chung-thuong-gap-trong-benh-hoi-chung-than-hu#gim-hot-ng-tiu-fibrin-do-gim-plasminogene-v-tng-antiplasmine-alpha-2-macroglobuline-alpha-2-antiplasmine)
  * [Tăng khả năng bị nhiễm trùng](https://bvnguyentriphuong.com.vn/than-loc-mau/trieu-chung-thuong-gap-trong-benh-hoi-chung-than-hu#tng-kh-nng-b-nhim-trng)


## **1. Protein niệu**
Protein niệu trong hội chứng thận hư rất nhiều, thường trên 3,5g/24 giờ/1,73 m2 diện tích cơ thể, có thể đạt đến 40g/24 giờ. Ở trẻ em, gần đây người ta đã đề xuất protein niệu cần để chẩn đoán là 1,66g/ngày/m2 diện tích cơ thể, nếu albumin máu giảm dưới 25g/l. Protein niệu thay đổi phụ thuộc vào mức lọc cầu thận và albumin máu, vì vậy protein niệu có thể giảm trong trường hợp giảm nhiều mức lọc cầu thận hoặc giảm rất rõ và nhanh của albumin máu.
Protein niệu có thể gồm chủ yếu là albumin hoặc những protein có trọng lượng phân tử nhỏ hơn: gọi là protein niệu chọn lọc. Trong trường hợp khác, protein niệu chứa phần lớn là các protein huyết tương, đặc biệt là IgG: gọi là không chọn lọc.
Protein niệu là do các bất thường của hàng rào cầu thận mà tính thấm chọn lọc với các đại phân tử trở nên bất thường.
Trong một số trường hợp, chính hàng rào chọn lọc theo điện tích của các đại phân tử bị rối loạn: Có những biến đổi về mặt sinh hóa lan tỏa khắp cấu trúc cầu thận, bất thường này không thể xác định bằng kính hiển vi quang học được. Protein niệu chọn lọc là thường gặp trong tình huống này.
Trong các trường hợp khác, chính hàng rào chọn lọc theo kích thước của các đại phân tử bị thương tổn. Có các bất thường của cấu trúc cầu thận, dễ thấy bằng kính hiển vi quang học. Protein niệu trong trường hợp này thường là không chọn lọc.
## **2. Giảm albumin máu**
Giảm albumin máu < 30 g/l, thường gặp hơn là < 20 g/l.
Giảm albumin máu chủ yếu là do mất albumin qua nước tiểu, có sự tương quan giữa mức độ protein niệu và albumin máu.
Ngoài ra còn có yếu tố gia tăng dị hóa của thận đối với albumin: Albumin sau khi đã lọc, được tái hấp thu trở lại ở ống lượn gần bởi sự hấp thu nội bào và sau đó bị thoái biến tại tiêu thể.
### **Có 2 cơ chế chính để bù trừ lại sự mất albumin qua nước tiểu:**
#### **Tổng hợp albumin ở gan gia tăng:**
Bình thường gan tổng hợp 12 - 14g albumin/ngày ở người lớn, ở bệnh hội chứng thận hư có thể gia tăng tổng hợp thêm khoảng 20%. Như vậy có thể thấy rằng sự tổng hợp này là không đủ để bù sự mất protein qua nước tiểu.
Một số yếu tố như tuổi, tình trạng dinh dưỡng kém, các bệnh gan có sẵn từ trước cũng có thể hạn chế sự tăng tổng hợp này. Điều này có thể giúp giải thích trong một số trường hợp giảm albumin máu rất rõ, với protein niệu < 10g/24 giờ, trong khi một số trường hợp khác, có protein niệu lớn hơn nhiều, mà albumin máu còn bình thường hoặc giảm vừa phải.
Có sự chuyển vận albumin từ khu vực khoảng kẽ vào huyết tương. Nhưng sự bù trừ này cũng không đầy đủ để hồi phục lại albumin máu.
## **3. Phù**
Phù là triệu chứng thường gặp với tính chất phù mềm, dễ ấn lõm (dấu godet). Phù xuất hiện ở những vùng áp lực mô kẽ thấp như xung quanh hốc mắt, mắt cá chân.
Hiếm hơn, có thể liên quan đến màng phổi, màng bụng, đôi khi gây khó thở. Phù là do tình trạng giữ muối và nước mà cơ chế do các yếu tố sau:
### **Cơ chế giảm áp lực keo huyết tương**
Cơ chế này làm vận chuyển nước và điện giải vào khu vực kẽ và có thể dẫn đến giảm thể tích máu và từ giảm thể máu này tác động, mang tính chất sinh lí, lên hệ thống thần kinh - nội tiết (giao cảm, RAA, Arginine vasopressine) làm kích thích sự tái hấp thu ở ống thận đối với nước và muối để bù trừ sự giảm thể tích máu.
### **Những cơ chế tại thận đặc hiệu**
Được tạo ra bởi sự giảm albumin máu hoặc albumin niệu. Có thể giải thích sự giữ muối và nước trong hội chứng thận hư như sau: Sự tái hấp thu muối (natri) gia tăng rất sớm trong những tế bào chính của ống góp vì có sự gia tăng hoạt động của bơm Natri (Na+/K+/ATPase) và của kênh Natri biểu mô.
### **Tăng lipid máu**
Bất thường này thường được thấy trong hội chứng thận hư. Lúc khởi đầu, tăng cholesterol máu là chính.
Cholesterol máu là chính, tăng Triglycéride máu xuất hiện thứ phát sau đó. Các bất thường Lipide này thường gặp hơn khi albumin máu giảm < 20 g/l.
Các Lipoprotein tỷ trọng thấp (LDL), rất thấp (VLDL) và loại trung gian (IDL) đều tăng, các lipoprotein tỷ trọng cao (HDL) là bình thường hoặc giảm.
Theo phân loại của Fredrickson và Lees rối loạn thường gặp nhất là type IIa và IIb (60%), sau đó là type V (30%), hiếm hơn là type III hay IV (10%). Các bất thường lipide hồi phục khi hội chứng thận hư biến mất.
### **Cơ chế của tăng Lipid trong hội chứng thận hư được giải thích do các yếu tố sau đây:**
#### **Tăng tổng hợp ở gan Lipoprotein tỷ trọng thấp rất thấp (VLDL)**
Đây là cơ chế chính, thường liên quan với độ nặng của giảm albumine máu. Khi giảm áp lực keo của huyết tương sẽ kích thích tổng hợp apoLipoprotein B. Gia tăng men HGM CoA réductase, acide mévalonique, tiền chất của cholesterol và các acide béo tự do, cũng có thể bị ảnh hưởng.
#### **Giảm men Lipoprotein Lipase (LPL)**
Đóng vai trò quan trọng bằng cách làm giảm thoái biến VLDL. Những acide béo tự do ức chế hoạt động của LPL. Sự thiếu hụt apo C II và những héparan sulfate, do bài tiết trong nước tiểu, cũng ức chế hoạt động của enzyme này.
#### **Giảm men Lecithin cholesterol acyl transferase (LCAT)**
Điều này đóng góp vào những bất thường về Lipide trong hội chứng thận hư bằng cách giảm tổng hợp HDL bắt đầu từ những VLDL.
#### **Mất qua nước tiểu HDL và apo A1**
Mất qua nước tiểu HDL và apo A1 cũng được ghi nhận, nhưng nồng độ của HDL huyết tương phần lớn là bình thường.
Tác động sinh xơ vữa của những bất thường Lipide này chưa được chứng minh một cách rõ ràng, có lẽ vì thời gian ngắn trong tiến triển của hội chứng thận hư.
Tăng Lipde máu cũng có thể tạo thuận lợi ngưng tập tiểu cầu và những biến chứng huyết khối tắc mạch, làm giảm đáp ứng của Lymphô bào đối với những kích thích kháng nguyên. Tăng Lipde máu cũng có thể là một yếu tố của xơ hoá cầu thận.
#### **Tăng đông máu**
Nhiều bất thường cầm máu được quan sát thấy trong hội chứng thận hư, là nguyên nhân gây ra tăng đông máu và những biến chứng huyết khối tắc mạch. Tăng đông máu trong hội chứng thận hư do các cơ chế sau:
  * Gia tăng fibrinogen máu do tăng tổng hợp ở gan.
  * Gia tăng các yếu tố II, V, VII, VIII và X, giảm các yếu tố IX, XI, XII do bài tiết trong trong nước tiểu vì trọng lượng phân tử thấp.


#### **Giảm hoạt động tiêu fibrin do giảm plasminogene và tăng antiplasmine (alpha 2 macroglobuline, alpha 2 antiplasmine).**
Thiếu hụt những chất ức chế quá trình đông (Prôtêin C, antithrombin III).
Tăng ngưng tập tiểu cầu.
Những bất thường này, kết hợp với tăng Lipide máu và giảm thể tích máu, tạo thuận lợi xuất hiện huyết khối tĩnh mạch và tắc mạch phổi.
#### **Tăng khả năng bị nhiễm trùng**
Dường như là do giảm gammaglobulin máu, ngoài ra còn do mất bổ thể qua nước tiểu. Chính những điều này làm sai sót của đáp ứng Lymphô bào đối với kháng nguyên.
Suy dinh dưỡng và chậm phát triển.
Ngoài những tác dụng của stéroide, suy dinh dưỡng và chậm phát triển do mất prôtêin và mất những hocmôn gắn liền với chất mang prôtêin (TBG, T3, T4, Vitamin D).
Xem thêm: [**Tổng quan về bệnh thận mạn**](https://bvnguyentriphuong.com.vn/noi-than-tiet-nieu/benh-than-man-nguyen-nhan-chan-doan-dieu-tri-va-phong-ngua)
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [1. Protein niệu](https://bvnguyentriphuong.com.vn/than-loc-mau/trieu-chung-thuong-gap-trong-benh-hoi-chung-than-hu#1-protein-niu)
  * [2. Giảm albumin máu](https://bvnguyentriphuong.com.vn/than-loc-mau/trieu-chung-thuong-gap-trong-benh-hoi-chung-than-hu#2-gim-albumin-mu)
  * [Có 2 cơ chế chính để bù trừ lại sự mất albumin qua nước tiểu:](https://bvnguyentriphuong.com.vn/than-loc-mau/trieu-chung-thuong-gap-trong-benh-hoi-chung-than-hu#c-2-c-ch-chnh-b-tr-li-s-mt-albumin-qua-nc-tiu)
  * [Tổng hợp albumin ở gan gia tăng:](https://bvnguyentriphuong.com.vn/than-loc-mau/trieu-chung-thuong-gap-trong-benh-hoi-chung-than-hu#tng-hp-albumin-gan-gia-tng)
  * [Cơ chế giảm áp lực keo huyết tương](https://bvnguyentriphuong.com.vn/than-loc-mau/trieu-chung-thuong-gap-trong-benh-hoi-chung-than-hu#c-ch-gim-p-lc-keo-huyt-tng)
  * [Những cơ chế tại thận đặc hiệu](https://bvnguyentriphuong.com.vn/than-loc-mau/trieu-chung-thuong-gap-trong-benh-hoi-chung-than-hu#nhng-c-ch-ti-thn-c-hiu)
  * [Cơ chế của tăng Lipid trong hội chứng thận hư được giải thích do các yếu tố sau đây:](https://bvnguyentriphuong.com.vn/than-loc-mau/trieu-chung-thuong-gap-trong-benh-hoi-chung-than-hu#c-ch-ca-tng-lipid-trong-hi-chng-thn-h-c-gii-thch-do-cc-yu-t-sau-y)
  * [Tăng tổng hợp ở gan Lipoprotein tỷ trọng thấp rất thấp (VLDL)](https://bvnguyentriphuong.com.vn/than-loc-mau/trieu-chung-thuong-gap-trong-benh-hoi-chung-than-hu#tng-tng-hp-gan-lipoprotein-t-trng-thp-rt-thp-vldl)
  * [Giảm men Lipoprotein Lipase (LPL)](https://bvnguyentriphuong.com.vn/than-loc-mau/trieu-chung-thuong-gap-trong-benh-hoi-chung-than-hu#gim-men-lipoprotein-lipase-lpl)
  * [Giảm men Lecithin cholesterol acyl transferase (LCAT)](https://bvnguyentriphuong.com.vn/than-loc-mau/trieu-chung-thuong-gap-trong-benh-hoi-chung-than-hu#gim-men-lecithin-cholesterol-acyl-transferase-lcat)
  * [Mất qua nước tiểu HDL và apo A1](https://bvnguyentriphuong.com.vn/than-loc-mau/trieu-chung-thuong-gap-trong-benh-hoi-chung-than-hu#mt-qua-nc-tiu-hdl-v-apo-a1)
  * [Giảm hoạt động tiêu fibrin do giảm plasminogene và tăng antiplasmine (alpha 2 macroglobuline, alpha 2 antiplasmine).](https://bvnguyentriphuong.com.vn/than-loc-mau/trieu-chung-thuong-gap-trong-benh-hoi-chung-than-hu#gim-hot-ng-tiu-fibrin-do-gim-plasminogene-v-tng-antiplasmine-alpha-2-macroglobuline-alpha-2-antiplasmine)
  * [Tăng khả năng bị nhiễm trùng](https://bvnguyentriphuong.com.vn/than-loc-mau/trieu-chung-thuong-gap-trong-benh-hoi-chung-than-hu#tng-kh-nng-b-nhim-trng)



## ️ Những khuyến cáo về lọc máu trong thời gian dịch COVID-19

https://www.theisn.org/881#recommendations-for-the-novel-coronavirus-2019-epidemic 
Đây là trang thông tin của Hiệp Hội Thận học Quốc Tế, cung cấp cho cộng đồng thận học toàn cầu về các cập nhật của đại dịch do chủng coronavirus mới (COVID-19). Trang này vừa đồng hành xuất bản bài báo "The Novel Coronavirus 2019 Epidemia and Kidneys” trên tờ Kidney International. Chúng tôi sẽ tiếp tục cập nhật thông tin khi tình hình thay đổi. Mục đích của chúng tôi là cung cấp cho cộng đồng sức khỏe thận học toàn cầu (các bác sĩ, nhân viên y tế cũng như công chúng) về kiến thức hiện tại, chia sẻ các tình huống và thực hành tốt nhất từ khắp nơi trên thế giới đến thời điểm hiện tại.
Toàn bộ khuyến cáo xin xem /.
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh
[youtube.com/bvntp](http://youtube.com/bvntp)

## ️ Chạy thận - lọc máu

  * [Chức năng của thận](https://bvnguyentriphuong.com.vn/than-loc-mau/chay-than-loc-mau#chc-nng-ca-thn)
  * [Các dạng lọc máu](https://bvnguyentriphuong.com.vn/than-loc-mau/chay-than-loc-mau#cc-dng-lc-mu)
  * [Các phương pháp thay thế thận liên tục](https://bvnguyentriphuong.com.vn/than-loc-mau/chay-than-loc-mau#cc-phng-php-thay-th-thn-lin-tc)


Thận khỏe mạnh có thể loại bỏ các chất thải, duy trì nồng độ các chất điện giải và điều hòa huyết áp. Tuy nhiên, khi thận không còn khả năng thực hiện các chức năng này thì người bệnh cần phải được lọc máu để giữ được sự cân bằng của cơ thể.
## **Lọc máu là gì?**
Bệnh nhân suy thận cấp hoặc mạn cần được lọc máu, hay còn gọi là chạy thận nhân tạo. Suy thận là khi chức năng thận giảm xuống còn dưới 15% so với bình thường. Nếu bệnh nhân mất từ 85-90% chức năng thận thì khả năng cao là cần được lọc máu.
Lọc máu là thủ thuật mô phỏng lại hoạt động tự nhiên của thận.
## **Chức năng của thận**
Thận là cơ quan trọng yếu của cơ thể và có vai trò quan trọng trong hệ tiết niệu. Chúng có chức năng lọc máu, loại bỏ các chất thải và bài tiết chúng qua nước tiểu.
Thận có thể lọc được khoảng 140 lít máu mỗi ngày. Nếu như có bệnh lý, chấn thương, hoặc các nguyên nhân khác làm cản trở thận thực hiện chức năng của mình thì muối và các chất thải sẽ tích tụ dần trong máu và gây tổn thương đến các cơ quan trong cơ thể, khiến cho tình trạng bệnh nhân trở nên nặng hơn.
Lọc máu sẽ thay thế chức năng của thận, bằng cách sử dụng một thiết bị để lọc và làm sạch máu trước khi đưa máu vào lại cơ thể. Việc này giúp cơ thể duy trì được sự cân bằng và các chất điện giải, giúp cho cơ thể hoạt động được bình thường.
Mặc dù lọc máu có thể bắt chước lại hoạt động của thận, nhưng nó không thể chữa khỏi bệnh thận mạn và những vấn đề khác của thận. Các bệnh nhân sẽ cần được điều trị thêm bằng những phương pháp khác để giải quyết được các nguyên nhân nền.
## **Các dạng lọc máu**
Có ba dạng chạy thận - lọc máu:
**Chạy thận nhân tạo**
Chạy thận nhân tạo là thủ thuật sử dụng máy lọc máu và một màng lọc đặc biệt. Một vài người gọi máy lọc máu này là thận nhân tạo.
Khi thực hiện thủ thuật, hai đầu kim sẽ được đưa vào mạch máu, thường là ở tay, để kết nối cơ thể với máy. Máy sau đó sẽ bơm máu của bệnh nhân đi xuyên qua màng lọc và quay trở lại cơ thể. Máy cũng đo được huyết áp, kiểm soát tốc độ của dòng chảy đi qua màng lọc, và sau đó quyết định thể tích dịch có thể lọc ra khỏi cơ thể.
Bên trong máy này, dòng máu sẽ đi qua những sợi rỗng, và dung dịch lọc máu sẽ đi theo chiều ngược lại ở bên ngoài các sợi này. Chất thải đi từ máu vào dung dịch lọc máu, và máu được lọc sau đó sẽ quay trở lại cơ thể. Một lần lọc máu thường kéo dài khoảng 4 giờ.
Bệnh nhân có thể được lọc máu tại một bệnh viện, trung tâm lọc máu, hoặc tại nhà.
**Thẩm phân phúc mạc**
Thẩm phân phúc mạc sử dụng lớp màng ở thành bụng để lọc máu.
Có hai dạng thẩm phân phúc mạc: thẩm phân phúc mạch liên tục (CAPD) và thẩm phân phúc mạc tự động (APD).
****
Phương pháp này không cần sử dụng máy. Thay vào đó, nó sẽ sử dụng một túi chứa dung dịch thẩm phân (bao gồm nước, muối và một vài phụ chất khác). Bệnh nhân sẽ được gắn túi này vào bụng thông qua một ống catheter. Dung dịch này sau đó sẽ chảy vào bụng, hấp thu những chất thải và dịch dư thừa từ cơ thể.
Sau một vài giờ, bệnh nhân đổ lượng dịch và chất thải trong túi ra hết, và có thể bắt đầu sử dụng một túi dịch thẩm phân khác. Có thể sẽ cần phải thay đổi túi dịch ba đến năm lần một ngày.
Phương pháp này tương tự như CAPD nhưng nó sẽ sử dụng một thiết bị được gọi là máy thay dịch tự động để thay mới dịch thẩm phân. Một số người còn gọi phương pháp này là thẩm phân phúc mạc liên tục có sử dụng máy tự thay (CCPD).
Bệnh nhân có thể thực hiện CAPD hay APD ở bất kỳ không gian riêng tư sạch sẽ nào, ví dụ như nhà và công ty.
## **Các phương pháp thay thế thận liên tục**
Các phương pháp này (CRRT) là một dạng lọc máu đặc biệt được sử dụng để điều trị suy thận cấp. Phương pháp thường được dụng cho bệnh nhân nằm trong phòng chăm sóc đặc biệt. Đây có thể là một lựa chọn tốt cho các bệnh nhân có huyết động không ổn định.
CRRT cũng giống như lọc máu bình thường nhưng thay vì lọc nhiều đợt, mỗi đợt 4 giờ thì phương pháp này kéo dài 24 giờ và sẽ liên tục lọc máu một cách chậm rãi.
Có ba dạng CRRT chính:
  * **Lọc máu tĩnh mạch - tĩnh mạch đối lưu liên tục**
  * **Lọc máu tĩnh mạch - tĩnh mạch khuếch tán liên tục**
  * **Lọc máu tĩnh mạch - tĩnh mạch khuếch tán đối lưu liên tục**


**Chuẩn bị**
Cách thức chuẩn bị thì khác nhau tùy phương pháp lọc máu. Thường thì bác sĩ sẽ đặt một thiết bị vào người bệnh nhân để có thể tiếp cận được đến mạch máu, đây là một thủ thuật nhanh.
Bệnh nhân nên mặc trang phục thoải mái đến lọc máu và nên tuân thủ theo hướng dẫn của nhân viên y tế, ví dụ như nhịn ăn trước khi thực hiện.
**Chạy thận nhân tạo**
Bệnh nhân cần được thực hiện phẫu thuật tiếp cận mạch máu trước khi thực hiện. Đây là một tiểu phẫu cho phép bệnh nhân kết nối được với máy chạy thận một cách dễ dàng. Bác sĩ sẽ sử dụng ống thông động tĩnh mạch, mảnh ghép động tĩnh mạch, hoặc một ống catheter để bệnh nhân có thể chạy thận.
Bệnh nhân nên tuân theo một chế độ ăn đặc biệt để có thể ngăn chặn các chất thải tích tụ lại ở giữa những đợt chạy thận. Chế độ ăn này bao gồm nhiều đạm và hạn chế các chất điện giải và dịch. Kích thước cơ thể bệnh nhân, tình trạng dinh dưỡng và chức năng thận sẽ quyết định lượng đạm chính xác cần.
**Thẩm phân phúc mạc**
Cũng như chạy thận nhân tạo, bệnh nhân cần được thực hiện một tiểu phẫu để đưa ống catheter vào trong bụng. Sau khi đã đặt catheter xong thì bệnh nhân sẽ được hướng dẫn cách thay túi bằng tay và tránh nhiễm trùng. Nếu bệnh nhân lựa chọn phương pháp APD thì sẽ được hướng dẫn thêm cách sử dụng máy thay tự động.
Mặc dù bệnh nhân chạy thận cần phải tuân theo một chế độ ăn chuyên biệt nhưng bệnh nhân sử dụng phương pháp chạy thận nhân tạo có chế độ ăn nghiêm khắc hơn so với thẩm phân phúc mạc. Nguyên nhân là vì thẩm phân phúc mạc diễn ra thường xuyên hơn do đó các chất thải sẽ ít bị tích tụ hơn.
****
Bệnh nhân không cần phải chuẩn bị gì trước khi thực hiện. Bác sĩ sẽ quyết định xem bệnh nhân có cần được thực hiện thủ thuật này hay không và sẽ chuẩn bị những thứ cần thiết.
**Nguy cơ**
Nguy cơ của lọc máu thì có sự khác nhau nhỏ giữa các phương pháp.
**Chạy thận nhân tạo**
Các vấn đề thường gặp của chạy thận nhân tạo bao gồm: nhiễm trùng, dòng chảy máu bị kém, và tắc nghẽn đường thông nối với mạch máu. Trong vài trường hợp, bệnh nhân sẽ gặp vài vấn đề với sự cân bằng hóa chất và nước, có thể gây ra co cơ hoặc tụt huyết áp đột ngột. Kim bị lỏng cũng có thể gây mất máu, dẫn đến các biến chứng nặng nề.
**Thẩm phân phúc mạc**
Bệnh nhân luôn phải vệ sinh tay thường xuyên để tránh nhiễm trùng xung quanh catheter và ngăn ngừa viêm phúc mạc. Viêm phúc mạc là nhiễm trùng của dịch bên trong bụng, và có thể gây đau, sốt, buồn nôn và nôn ói. Nếu gặp phải các triệu chứng trên thì nên đi khám ngay.
Thẩm phân phúc mạc còn có thể làm tăng nguy cơ bị thoát vị, nguyên nhân là do catheter cần phải có một đường thông nối đi vào cơ thể. Ngoài ra, tăng cân cũng có thể gặp do cơ thể hấp thụ đường ở trong dung dịch thẩm phân.
****
Cũng giống như các biện pháp khác, nguy cơ của CRRT bao gồm nhiễm trùng, hạ huyết áp, và mất cân bằng điện giải.
## **Tóm tắt**
Lọc máu là biện pháp điều trị khi thận không thực hiện được chức năng của mình. Nếu như bệnh nhân mắc phải suy thận cấp hoặc mạn thì cần được lọc máu để thay thế cho vai trò của thận.
Các dạng khác nhau của lọc máu bao gồm: chạy thận nhân tạo, thẩm phân phúc mạc, và liệu pháp thay thế thận liên tục. Mặc dù mỗi cách đều có khác biệt nhỏ, lọc máu thường sẽ cần sử dụng một thiết bị và một dung dịch đặc biệt để loại bỏ các chất thải độc hại, lượng muối và dịch dư thừa ra khỏi máu.
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [Chức năng của thận](https://bvnguyentriphuong.com.vn/than-loc-mau/chay-than-loc-mau#chc-nng-ca-thn)
  * [Các dạng lọc máu](https://bvnguyentriphuong.com.vn/than-loc-mau/chay-than-loc-mau#cc-dng-lc-mu)
  * [Các phương pháp thay thế thận liên tục](https://bvnguyentriphuong.com.vn/than-loc-mau/chay-than-loc-mau#cc-phng-php-thay-th-thn-lin-tc)



## ️ Lọc màng bụng liên tục ngoại trú- Continuous ambulatory peritoneal dialysis (CAPD)

  * [Chống chỉ định:](https://bvnguyentriphuong.com.vn/than-loc-mau/loc-mang-bung-lien-tuc-ngoai-tru-continuous-ambulatory-peritoneal-dialysis-capd#chng-ch-nh)
  * [Chống chỉ định tuyệt đối:](https://bvnguyentriphuong.com.vn/than-loc-mau/loc-mang-bung-lien-tuc-ngoai-tru-continuous-ambulatory-peritoneal-dialysis-capd#chng-ch-nh-tuyt-i)
  * [Chống chỉ định tương đối:](https://bvnguyentriphuong.com.vn/than-loc-mau/loc-mang-bung-lien-tuc-ngoai-tru-continuous-ambulatory-peritoneal-dialysis-capd#chng-ch-nh-tng-i)
  * [Ưu và nhược điểm:](https://bvnguyentriphuong.com.vn/than-loc-mau/loc-mang-bung-lien-tuc-ngoai-tru-continuous-ambulatory-peritoneal-dialysis-capd#u-v-nhc-im)


## **Nguyên lý**
Lọc màng bụng ở Việt Nam hiện nay chủ yếu sử dụng phương pháp lọc màng bụng liên tục ngoại trú.
Lọc màng bụng hay thẩm phân phúc mạc (Peritoneal Dialysis – PD): Sử dụng màng bụng (phúc mạc ổ bụng của bệnh nhân, bao gồm cả phúc mạc thành và phúc mạc tạng) như một màng bán thấm để trao đổi chất giữa khoang dịch và khoang máu. Màng bụng trao đổi chất nhờ 2 cơ chế là (1) Sự khuếch tán xảy ra khi có sự chênh lệch nồng độ các chất giữa máu và dịch lọc trong khoang phúc mạc và (2) Sự siêu lọc (sự hút nước) xảy ra nhờ sự chênh lệch áp lực thẩm thấu được tạo ra nhờ nồng độ glucose cao trong dịch lọc dẫn đến sự rút nước từ trong huyết tương vào trong ổ bụng.
Liên tục: Ngày thay dịch trung bình 4 lần, mỗi lần trung bình 5h - 6h, lọc tất cả các ngày trong tuần.
Ngoại trú: Bệnh nhân tự thay dịch ở nhà, bình thường 1 tháng đến bệnh viện để khám, đánh giá, làm xét nghiệm và lĩnh dịch, thuốc về nhà.
## **Chỉ định:**
Bệnh thận giai đoạn cuối.
Trẻ em: Là đối tượng thường khó tạo đường vào mạch máu để thận nhân tạo
Người lớn: Những đối tượng gặp khó khăn khi tạo đường vào mạch máu (không làm được thông động – tĩnh mạch ở bệnh nhân đái tháo đường, thông động – tĩnh mạch bị tắc hoặc hẹp không đủ lưu lượng để lọc máu bằng thận nhân tạo…).
Ưu tiên cho những bệnh nhân có rối loạn chức năng tim, suy tim nặng.
Sự lựa chọn phương pháp lọc màng bụng còn phụ thuộc vào tuổi, nghề nghiệp, điều kiện địa lý (xa hay gần trung tâm thận nhân tạo), điều kiện kinh tế - văn hóa – xã hội, môi trường tại gia đình và nơi làm việc, sự hỗ trợ từ gia đình, tình trạng tim mạch, các bệnh lý kèm theo…
## **Chống chỉ định:**
### **Chống chỉ định tuyệt đối:**
Màng bụng không còn chức năng lọc hoặc bị kết dính diện rộng gây cản trở dòng chảy của dịch lọc: Xơ hóa phúc mạc, viêm dính phúc mạc do phẫu thuật trong ổ bụng cũ.
Một số trường hợp bất thường về màng bụng và thành bụng không thể khắc phục: Thoát vị rốn, thoát vị cạnh rốn bẩm sinh, thoát vị hoành, rò bàng quang...
Bệnh phổi tắc nghẽn mạn tính nặng: Do lọc màng bụng có thể gây khó khăn khi kiểm soát bệnh phổi.
### **Chống chỉ định tương đối:**
  * Nhiễm trùng da hay thành bụng.
  * Thể tích khoang màng bụng bị hạn chế: Gan to, lách to, thận đa nang.
  * Mới mổ ghép động mạch chủ bụng. Đã phẫu thuật cắt đại tràng, ruột non, thận…
  * Có shunt não thất - ổ bụng (dẫn lưu não thất trong não úng thủy).
  * Không dung nạp với dịch lọc chứa trong ổ bụng. Thị lực kém, có các bệnh lý thần kinh, bệnh khớp không thể tự làm được lọc màng bụng hoặc không có người giúp đỡ.
  * Rối loạn tâm thần.
  * Suy dinh dưỡng nặng.
  * Bệnh lý đại tràng mạn tính nặng, viêm ruột.
  * Đau lưng mạn tính do bệnh lý cột sống, béo phì.


## **Ưu và nhược điểm:**
### **Ưu điểm:**
#### **Về y học:**
Quá trình lọc máu xảy ra liên tục nên: Thích hợp với tim mạch do huyết động ổn định, giảm các rối loạn về nhịp tim, kiểm soát tốt huyết áp, tránh bị suy tim sớm hơn so với thận nhân tạo. Tình trạng sinh hoá máu của bệnh nhân ổn định hơn, tránh hội chứng mất cân bằng.
Còn tồn tại chức năng thận dự trữ: Tiên lượng bệnh nhân sẽ tốt hơn nếu còn chức năng thận dự trữ (chức năng thận tồn lưu).
Kiểm soát tốt thiếu máu.
Không cần dùng chống đông toàn thân.
Không cần làm thông động tĩnh mạch.
Không cần tiếp xúc vật liệu lạ.
Không phải chọc kim như thận nhân tạo đỡ đau.
Tránh lây nhiễm chéo (HIV, viêm gan virus B, viêm gan virus C...) giữa các bệnh nhân.
Được chỉ định ưu tiên đối với bệnh nhân đã có suy tim, rối loạn nhịp, tình trạng mạch máu khó khăn khi làm thông động tĩnh mạch, nhất là bệnh nhân tiểu đường.
#### **Về xã hội**
  * So với thận nhân tạo, lọc màng bụng mang lại cho bệnh nhân nhiều sự tự do hơn, bệnh nhân tự thực hiện ở nhà, không cần đến các trung tâm thận nhân tạo nên không phụ thuộc nhiều vào bệnh viện.
  * Bệnh nhân có thể duy trì những sinh hoạt hàng ngày trong suốt quá trình điều trị.
  * Tự quản, dễ di động.
  * Kỹ thuật đơn giản, đào tạo nhanh.
  * Giá thành không cao lắm so với lọc máu.


### **Nhược điểm:**
#### **Về y học:**
  * Tồn tại một ống thông trong ổ bụng, dễ có các biến chứng như màng bụng bị tổn thương (xơ hóa màng bụng), viêm phúc mạc, tăng áp lực trong ổ bụng, thoát vị…
  * Nguy cơ thiểu dưỡng cao hơn.
  * Dễ bị ứ trệ nước và điện giải.
  * Có nguy cơ lọc không đầy đủ sau một vài năm.
  * Hiệu suất kém (bằng ¼ so với lọc máu bằng thận nhân tạo) nồng độ ure và creatinin thường cao hơn so với thận nhân tạo.
  * Không thay thế được chức năng thận nội tiết (kiểm soát tạo hồng cầu, loãng xương).


#### **Về xã hội:**
  * Bắt buộc phải thực hiện hàng ngày và ngày nhiều lần (thời gian kéo dài hơn).
  * Đòi hỏi phải có kỹ năng và trình độ hiểu biết tốt; đòi hỏi về điều kiện sinh hoạt (nguồn nước sạch).
  * Gây ảnh hưởng đến môi trường gia đình, lao động và công tác.
  * Dễ ứ trệ nước và điện giải, nguy cơ lọc không đầy đủ sau vài năm.


## **Kỹ thuật:**
  * Bệnh nhân được đặt catheter bằng chất dẻo vào trong ổ bụng, đầu catheter (đầu cong) ở vị trí túi cùng Douglas.
  * Kỹ thuật mổ: Mổ mở hoặc mổ nội soi.
  * Kiểm tra trong và sau mổ: Thay dịch ngay trong cuộc mổ kiểm tra sự lưu thông catheter. Chụp X quang bụng sau mổ kiểm tra vị trí catheter.
  * Sau 2 tuần: Vết mổ và đường hầm ổn định, cắt chỉ và bắt đầu vào dịch với số lần vào và thể tích dịch tăng dần để có sự thích nghi.
  * Dịch lọc có 3 loại là 1.5%, 2.5% và 4.25%: Khác nhau về nồng độ đường. Nồng độ đường càng cao thì khả năng hút nước thừa (siêu lọc) càng cao do tạo được áp lực thẩm thấu cao hơn.
  * Giờ thay dịch thường là Sáng – trưa – cuối buổi chiều và đêm (ngâm qua đêm).
  * Bệnh nhân lọc màng bụng nếu không duy trì được phương pháp này có thể chuyển sang thận nhân tạo chu kỳ hoặc làm lọc màng bụng trước trong lúc chờ đợi được ghép thận. Bệnh nhân đã ghép thận hoặc đã thận nhân tạo chu kỳ có thể quay trở lại làm lọc màng bụng.
  * Một số nước thực hiện chính sách “PD first” có nghĩa là ưu tiên làm lọc màng bụng trước (so với lựa chọn Thận nhân tạo) nếu như chưa được ghép thận.


Xem thêm: **[Chạy thận nhân tạo là gì- chức năng của chạy thận](https://bvnguyentriphuong.com.vn/than-loc-mau/chay-than-nhan-tao-la-gi-chuc-nang-cua-chay-than)**
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [Chống chỉ định:](https://bvnguyentriphuong.com.vn/than-loc-mau/loc-mang-bung-lien-tuc-ngoai-tru-continuous-ambulatory-peritoneal-dialysis-capd#chng-ch-nh)
  * [Chống chỉ định tuyệt đối:](https://bvnguyentriphuong.com.vn/than-loc-mau/loc-mang-bung-lien-tuc-ngoai-tru-continuous-ambulatory-peritoneal-dialysis-capd#chng-ch-nh-tuyt-i)
  * [Chống chỉ định tương đối:](https://bvnguyentriphuong.com.vn/than-loc-mau/loc-mang-bung-lien-tuc-ngoai-tru-continuous-ambulatory-peritoneal-dialysis-capd#chng-ch-nh-tng-i)
  * [Ưu và nhược điểm:](https://bvnguyentriphuong.com.vn/than-loc-mau/loc-mang-bung-lien-tuc-ngoai-tru-continuous-ambulatory-peritoneal-dialysis-capd#u-v-nhc-im)



## ️ Tóm tắt hướng dẫn của hiệp hội thận học Trung Quốc và hiệp hội thận học Đài Loan

  * [Những khuyến cáo tạm thời cho khu thực chạy thận- lọc máu](https://bvnguyentriphuong.com.vn/than-loc-mau/tom-tat-huong-dan-cua-hiep-hoi-than-hoc-trung-quoc-va-hiep-hoi-than-hoc-dai-loan#nhng-khuyn-co-tm-thi-cho-khu-thc-chy-thn-lc-mu)
  * [Những chiến lược hoạt động cho thân nhân và người chăm sóc](https://bvnguyentriphuong.com.vn/than-loc-mau/tom-tat-huong-dan-cua-hiep-hoi-than-hoc-trung-quoc-va-hiep-hoi-than-hoc-dai-loan#nhng-chin-lc-hot-ng-cho-thn-nhn-v-ngi-chm-sc)


## **Những khuyến cáo tạm thời cho khu thực chạy thận- lọc máu**
1. Nhóm làm việc bao gồm các bác sĩ lọc máu, điều dưỡng và các kỹ thuật viên nên được huấn luyện và cập nhật các kiến thức lâm sàng về dịch bệnh COVID-19. Thông báo về các nguy cơ nhiễm trùng, các công cụ phòng chống dịch bệnh và các hướng dẫn từ chính phủ, hiệp hội các chuyên gia và nhà chức trách của bệnh viện. Danh sách các nhân viên nên được ghi lại và lưu giữ bởi các bệnh viện chạy thận nhân tạo.
2. Thông tin về lịch trình, nghề nghiệp, sự tiếp xúc và tiền sử cụm (TOCC) của từng nhân viên y tế, bệnh nhân chạy thận, các thành viên gia đình của họ, người của cùng tổ chức và đồng nghiệp tại nơi làm việc nên được thu thập và cập nhật thường xuyên.
3. Các khuyến cáo mới nhất và thông tin về dịch bệnh nên được cập nhật và phổ biến cho tất cả nhân viên chăm sóc y tế. Việc đào tạo có thể thực hiện thông qua mạng nội bộ hoặc trực tuyến.
4. Các hoạt động nhóm như nhóm thực hành, nhóm nghiên cứu, các nhóm thảo luận nên được hạn chế đến mức tối thiểu.
5. Khuyến cáo các nhân viên nên có thời gian ăn khác nhau để tránh ăn cùng nhau. Kính bảo hộ, khẩu trang và mũ nên được tháo ra trước bữa ăn và rửa tay dưới vòi nước. Hạn chế nói chuyện trong bữa ăn để giảm lây lan bởi giọt bắn.
6. Nhân viên nên tự theo dõi các triệu chứng của mình và thông báo cho trưởng nhóm trong trường hợp họ hoặc các thành viên gia đình của họ có triệu chứng gợi ý nhiễm COVID-19.
7. Kiểm soát lối vào, nhận dạng và cách li những người có nguy cơ nhiễm bệnh, đo nhiệt độ cơ thể, rửa tay, đeo khẩu trang thích hợp (khẩu trang phẫu thuật hoặc N95) trong suốt quá trình, khử trùng bằng máy, vệ sinh môi trường sạch sẽ, điều hòa không khí và thông gió tốt.
8. Bệnh nhân và thân nhân nên được rửa tay khử trùng tay khi vào phòng Lọc Máu. Bệnh nhân nên đeo khẩu trang y tế và tránh ăn trong quá trình lọc máu. Bệnh nhân có thể mang theo các thực phẩm tiện lợi như kẹo để ngăn ngừa hạ đường huyết.
9. Bệnh nhân nghi ngờ hoặc xác định nhiễm COVID-19 nên được đưa vào khu vực cách ly áp lực âm được chỉ định của bệnh viện. Nếu sức chứa của cơ sở cách ly bị quá tải, "Fixed Dialysis Care Model – Mô hình chăm sóc lọc máu cố định" như dưới đây được khuyến cáo để thẩm tách cho bệnh nhân trong thời gian cách ly 14 ngày khi có nguy cơ nhiễm COVID-19.
10. Nơi điều trị lọc máu: Bệnh nhân nên tiếp tục chạy thận nhân tạo tại trung tâm chạy thận nhân tạo ban đầu và không đổi sang trung tâm khác.
11. Ca lọc máu và nhân viên lọc máu: Không thay đổi ca lọc máu và nhân viên chăm sóc để tránh lây nhiễm chéo và truyền nhiễm. Giảm thiểu tối đa các mối liên hệ có liên quan.
12. Bệnh nhân cần phẫu thuật mạch máu nên được kiểm tra Coronavirus mới trước khi phẫu thuật. Các phẫu thuật trên bệnh nhân nghi ngờ hoặc xác định nhiễm Coronavirus mới phải thực hiện trong một phòng được thiết kế để bảo vệ cho các nhân viên y tế.
13. Chuyển bệnh: Không nên sử dụng giao thông công cộng. Người bệnh nên sắp xếp phương tiện vận chuyển cá nhân và cố định đường di chuyển. Nhân viên vận chuyển và hộ tống nên đeo mặt nạ phẫu thuật hoặc mặt nạ N95 trong suốt quá trình chuyển bệnh.
14. Tất cả bệnh nhân bị sốt nên được kiểm tra nhiễm Coronavirus mới và nên được lọc máu trong ca cuối cùng trong ngày cho đến khi được loại trừ.
15. Đường đi vào bệnh viện và đơn vị lọc máu: Việc đưa và đón bệnh nhân không nên chung với các bệnh nhân chạy thận khác. Tránh lối vào và ra chung đối với bệnh nhân lọc máu khác trong cùng thời gian. Lộ trình, kiểu và thời gian di chuyển của các nhân viên lọc máu cần được cố định.
16. Phòng ngừa ở đơn vị lọc máu: Các bệnh nhân không nên ở gần nhau. Khu vực điều trị và chờ đợi nên được thông khí và thông gió tốt để loại bỏ các giọt bắn trong không khí.
17. Nhân viên chăm sóc được chỉ định: Tất cả các nhân viên tham gia trực tiếp chăm sóc bệnh nhân nên được bảo vệ đầy đủ, bao gồm quần áo cách ly dài tay không thấm nước, mũ, kính bảo hộ, găng tay và mặt nạ y tế (mặt nạ phẫu thuật trở lên). Vệ sinh tay cần được thực hiện nghiêm túc.
18. Máy lọc máu: Những thiết bị có thể tiếp xúc với bệnh nhân hoặc những vật liệu có khả năng bị lây nhiễm nên được khử trùng theo quy trình chuẩn.
19. Nếu ở trung tâm lọc máu có trường hợp mới xác định hoặc nguy cơ cao nhiễm Coronavirus mới, việc khử trùng nên được thực hiện ngay lập tức. Khu vực tiếp xúc gần với những bệnh nhân đó không nên sử dụng cho những bệnh nhân khác cho đến khi được làm sạch.
20. Chất thải y tế từ những bệnh nhân bị nghi ngờ hoặc xác định nhiễm Coronavirus mới nên cân nhắc như là rác thải lây nhiễm và nên được xử lí phù hợp.
## **Những chiến lược hoạt động cho thân nhân và người chăm sóc**
1. Tất cả các thành viên trong gia đình đang sống với bệnh nhân lọc máu phải tuân thủ tất cả các biện pháp phòng ngừa và các quy định cho bệnh nhân để ngăn ngừa lây nhiễm COVID-19 từ người sang người và giữa các thành viên trong gia đình với nhau; bao gồm kiểm tra thân nhiệt cơ thể, vệ sinh cá nhân tốt, rửa tay và báo cáo những trường hợp có khả năng nhiễm bệnh.
2. Bệnh nhân lọc máu có thành viên trong gia đình hoặc người chăm sóc chịu "kiểm dịch cơ bản", có thể lọc máu như bình thường trong khu vực phù hợp trong thời gian 14 ngày.
3. Một khi các thành viên gia đình hoặc người chăm sóc bệnh nhân chạy thận được xác định nhiễm, danh tính của bệnh nhân nên được cập nhật và điều trị trong khu vực phù hợp theo những quy định nêu trên.
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [Những khuyến cáo tạm thời cho khu thực chạy thận- lọc máu](https://bvnguyentriphuong.com.vn/than-loc-mau/tom-tat-huong-dan-cua-hiep-hoi-than-hoc-trung-quoc-va-hiep-hoi-than-hoc-dai-loan#nhng-khuyn-co-tm-thi-cho-khu-thc-chy-thn-lc-mu)
  * [Những chiến lược hoạt động cho thân nhân và người chăm sóc](https://bvnguyentriphuong.com.vn/than-loc-mau/tom-tat-huong-dan-cua-hiep-hoi-than-hoc-trung-quoc-va-hiep-hoi-than-hoc-dai-loan#nhng-chin-lc-hot-ng-cho-thn-nhn-v-ngi-chm-sc)



## ️ Bệnh thận ở người đái tháo đường

  * [1. Vì sao bệnh tiểu đường gây biến chứng trên thận?](https://bvnguyentriphuong.com.vn/noi-tiet/bien-chung-than-o-nguoi-dai-thao-duong#1-v-sao-bnh-tiu-ng-gy-bin-chng-trn-thn)
  * [2. Biến chứng thận của bệnh tiểu đường tiến triển như thế nào?](https://bvnguyentriphuong.com.vn/noi-tiet/bien-chung-than-o-nguoi-dai-thao-duong#2-bin-chng-thn-ca-bnh-tiu-ng-tin-trin-nh-th-no)
  * [3. Cách nhận biết sớm biến chứng thận của bệnh tiểu đường](https://bvnguyentriphuong.com.vn/noi-tiet/bien-chung-than-o-nguoi-dai-thao-duong#3-cch-nhn-bit-sm-bin-chng-thn-ca-bnh-tiu-ng)
  * [4. Biến chứng thận tiểu đường điều trị như thế nào?](https://bvnguyentriphuong.com.vn/noi-tiet/bien-chung-than-o-nguoi-dai-thao-duong#4-bin-chng-thn-tiu-ng-iu-tr-nh-th-no)


## **1. Vì sao bệnh tiểu đường gây biến chứng trên thận?**
Công việc chính của thận là lọc chất thải, nước, muối thừa ra khỏi máu và hỗ trợ điều hòa huyết áp. Để làm được điều này, thận cần một hệ thống mạch máu nhỏ (mao mạch) khỏe mạnh.
Ở người bệnh tiểu đường, đường huyết cao sẽ làm các mạch máu nhỏ tại thận bị tổn thương. Điều này khiến thận của bạn không thể làm sạch máu đúng cách gây giữ muối, nước và tăng thải protein ra nước tiểu.
Bệnh tiểu đường cũng gây tổn thương các dây thần kinh khiến quá trình làm rỗng bàng quang gặp khó khăn. Áp lực do bàng quang đầy cũng là một nguyên nhân làm tổn thương thận. Ngoài ra, nếu nước tiểu đọng lại trong bàng quang lâu, vi khuẩn có thể phát triển nhanh chóng gây nhiễm trùng. Nhiễm trùng đường tiết niệu cũng làm suy yếu chức năng thận.
## **2. Biến chứng thận của bệnh tiểu đường tiến triển như thế nào?**
Bệnh thận tiểu đường thường phát triển qua 5 giai đoạn.
  * Giai đoạn 1: Đường huyết tăng cao, lượng máu đến thận tăng khiến thận phải tăng kích thước. Đồng thời trong giai đoạn này, thận phải làm việc nhiều hơn để tăng đào thải đường ra ngoài cơ thể.
  * Giai đoạn 2: Mao mạch cầu thận bắt đầu bị tổn thương gây ra những thay đổi mô học tại thận, tiêu biểu là tình trạng màng lọc bị xơ hóa, kích thước lỗ lọc to ra. Tuy nhiên, mức độ tổn thương trong giai đoạn 2 chưa đủ để gây ra các triệu chứng rõ rệt trên lâm sàng.
  * Giai đoạn 3: Các dấu hiệu tổn thương thận biểu hiện rõ trên lâm sàng. Người bệnh có thể thấy hiện tượng nước tiểu sủi bọt, có mùi lạ do tiểu ra albumin (lượng albumin trong nước tiểu 24 giờ là 30 – 300 mg). Đây là dấu hiệu chỉ điểm quan trọng cho thấy biến chứng thận của bệnh tiểu đường đang tiến triển nặng hơn.
  * Giai đoạn 4: Sau một thời gian dài phải làm việc nhiều hơn, chức năng lọc của thận bị suy giảm. Người bệnh có các triệu chứng rõ ràng, huyết áp tăng, kiểm tra nước tiểu thấy nồng độ albumin, đạm niệu cao (albumin trong nước tiểu 24 giờ lớn hơn 300mg).
  * Giai đoạn 5: Bệnh thận giai đoạn cuối. Nếu không điều trị tốt, người bệnh sẽ phải lọc thận hoặc thay thận để duy trì cuộc sống.


Điều đáng nói, biến chứng thận ở bệnh nhân tiểu đường không dừng lại ở suy thận mà còn ẩn chứa nhiều nguy cơ tổn thương các cơ quan khác. Ví dụ như: phù phổi cấp, tăng kali máu, bệnh tim mạch, đột quỵ, bệnh võng mạc tiểu đường, loét chân, rối loạn cương dương… Vì vậy, người bệnh tiểu đường, đặc biệt những người có nguy cơ cao (cao tuổi, tăng huyết áp, mỡ máu) cần chủ động phòng ngừa và phát hiện sớm biến chứng thận để giảm rủi ro.
## **3. Cách nhận biết sớm biến chứng thận của bệnh tiểu đường**
Trong giai đoạn đầu của bệnh thận do tiểu đường, người bệnh có thể không nhận thấy bất kỳ dấu hiệu hoặc triệu chứng nào. Một số người bệnh có thể thấy tăng cân, đi tiểu nhiều hơn vào ban đêm hay nước tiểu sủi bọt – dấu hiệu cảnh báo có protein trong nước tiểu. Tuy nhiên đa phần đều bỏ qua các triệu chứng này hoặc nhầm lẫn sang một bệnh lý khác.
Khi chức năng thận suy yếu hơn, nồng độ nitơ urê và creatinin trong máu (BUN) sẽ tăng lên. Và bạn sẽ gặp các dấu hiệu, triệu chứng rõ ràng hơn bao gồm:
  * Buồn nôn, nôn, chán ăn
  * Ngày càng mệt mỏi, khó thở
  * Ngứa, chuột rút (đặc biệt là ở chân)
  * Khó tập trung, nhớ nhớ quên quên
  * Người xanh xao, suy nhược, thiếu máu
  * Huyết áp tăng cao khó hạ
  * Cần ít insulin hoặc thuốc tiểu đường hơn. 


  * Sưng bàn chân, mắt cá chân, bàn tay hoặc mắt


Vì vậy thay vì dựa vào triệu chứng, các chuyên gia khuyến cáo người bệnh nên làm xét nghiệm albumin trong nước tiểu. Đây là cách chính xác và đơn giản nhất giúp phát hiện sớm biến chứng thận của bệnh tiểu đường.
Với bệnh nhân tiểu đường type 2, việc xét nghiệm albumin trong nước tiểu để sàng lọc bệnh thận nên được làm ngay tại thời điểm chẩn đoán và định kỳ hàng năm trong những năm kế tiếp. Trường hợp bị tiểu đường type 1, bệnh nhân nên thực hiện xét nghiệm này khi mắc bệnh 3 – 5 năm, sau đó là sàng lọc hàng năm.
## **4. Biến chứng thận tiểu đường điều trị như thế nào?**
Biến chứng thận tiểu đường có tiên lượng tốt ở những người bệnh phát hiện sớm, điều trị kịp thời và kiểm soát tốt. Tuy nhiên hầu hết các bệnh nhân bị biến chứng thận tiểu đường đều phát hiện vào giai đoạn muộn, khi thận đã bị mất dần chức năng. Điều này khiến việc điều trị biến chứng thận tiểu đường gặp nhiều khó khăn hơn. Hạ huyết áp và duy trì kiểm soát đường huyết là vô cùng cần thiết để làm chậm sự tiến triển của bệnh thận do tiểu đường.
Có những loại thuốc có sẵn để làm chậm sự tiến triển của tổn thương thận. Chúng bao gồm:
  * Thuốc ức chế đồng vận chuyển natri-glucose 2 (SGLT2) như dapagliflozin (Forxiga)
  * Thuốc ức chế men chuyển angiotensin (ACE)
  * Thuốc chẹn thụ thể angiotensin (ARB) nếu gặp tác dụng phụ khi sử dụng thuốc ACE


Những trường hợp bị suy thận nặng, người bệnh sẽ được điều trị bằng chạy thận nhân tạo hoặc ghép thận nếu có người hiến tặng phù hợp.
**5. Bí quyết phòng ngừa biến chứng thận cho người tiểu đường**
Phòng bệnh hơn chữa bệnh, điều này rất đúng với biến chứng thận của bệnh tiểu đường. Để giảm nguy cơ phát triển bệnh thận do tiểu đường, bạn cần.
  * **Kiểm soát tốt đường huyết:** Các thuốc hạ đường huyết là giải pháp không thể thiếu để giữ lượng đường trong máu khi đói, sau ăn và HbA1c trong mức cho phép. Tuy nhiên bạn cũng đừng quên các giải pháp khác như tập thể dục, ăn nhiều rau xanh, hạn chế chất bột đường, thảo dược hỗ trợ… Một số mẹo trong ăn uống có thể giúp bạn không phải kiêng khem quá mức mà vẫn giảm được lượng đường trong máu là: ăn rau trước khi ăn cơm, chia nhỏ bữa ăn, ăn đúng giờ, không bỏ bữa, ăn ngũ cốc nguyên hạt thay vì cơm trắng…
  * **Kiểm soát tốt huyết áp và mỡ máu.** Nếu bạn bị huyết áp cao hoặc cholesterol trong máu cao, hãy điều trị tích cực theo chỉ định của bác sĩ. Việc điều trị huyết áp và mỡ máu thường bao gồm dùng thuốc, tập thể dục, ăn giảm muối và giảm chất béo.
  * **Cẩn thận khi dùng thuốc giảm đau:** Lạm dụng các thuốc giảm đau không kê đơn như aspirin và ibuprofen (Advil, Motrin IB) có thể dẫn đến tổn thương thận. Do đó, hãy hỏi ý kiến dược sĩ và dùng theo đúng hướng dẫn.
  * **Duy trì cân nặng hợp lý:** Nếu bạn đang ở mức cân nặng hợp lý, hãy cố gắng duy trì nó bằng chế độ ăn và cách hoạt động thể chất hầu hết các ngày trong tuần. Nếu bạn thừa cân hay béo phì, hãy nói chuyện với bác sĩ về các chiến lược giảm cân, chẳng hạn như tăng hoạt động thể chất hàng ngày và giảm lượng calo.
  * **Bỏ hút thuốc.** Hút thuốc lá có thể làm hỏng thận của bạn và làm cho tình trạng tổn thương thận hiện tại trở nên trầm trọng hơn. Nếu bạn là người hút thuốc, hãy nói chuyện với bác sĩ của bạn về các chiến lược bỏ thuốc. Các nhóm hỗ trợ, tư vấn và thuốc đều có thể giúp bạn dừng việc hút thuốc một cách dễ dàng hơn.


Biến chứng thận của bệnh tiểu đường có thể trở nên tệ hơn theo thời gian. Tuy nhiên, bạn có thể thực hiện các lời khuyên kể trên để giữ cho thận khỏe mạnh, giúp làm chậm quá trình tổn thương thận hoặc trì hoãn suy thận.
Xem thêm: [**Bệnh thần kinh tiểu đường - tổng quan và theo dõi các biến chứng**](https://bvnguyentriphuong.com.vn/noi-tam-than-kinh/benh-than-kinh-tieu-duong-va-nhung-bien-chung-nguy-hiem)
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [1. Vì sao bệnh tiểu đường gây biến chứng trên thận?](https://bvnguyentriphuong.com.vn/noi-tiet/bien-chung-than-o-nguoi-dai-thao-duong#1-v-sao-bnh-tiu-ng-gy-bin-chng-trn-thn)
  * [2. Biến chứng thận của bệnh tiểu đường tiến triển như thế nào?](https://bvnguyentriphuong.com.vn/noi-tiet/bien-chung-than-o-nguoi-dai-thao-duong#2-bin-chng-thn-ca-bnh-tiu-ng-tin-trin-nh-th-no)
  * [3. Cách nhận biết sớm biến chứng thận của bệnh tiểu đường](https://bvnguyentriphuong.com.vn/noi-tiet/bien-chung-than-o-nguoi-dai-thao-duong#3-cch-nhn-bit-sm-bin-chng-thn-ca-bnh-tiu-ng)
  * [4. Biến chứng thận tiểu đường điều trị như thế nào?](https://bvnguyentriphuong.com.vn/noi-tiet/bien-chung-than-o-nguoi-dai-thao-duong#4-bin-chng-thn-tiu-ng-iu-tr-nh-th-no)



## ️ Ure máu và những điều cần biết

  * [1. Ure máu là gì?](https://bvnguyentriphuong.com.vn/noi-than-tiet-nieu/ure-mau-va-nhung-dieu-can-biet#1-ure-mu-l-g)
  * [2. Những nguyên nhân làm Ure máu thay đổi](https://bvnguyentriphuong.com.vn/noi-than-tiet-nieu/ure-mau-va-nhung-dieu-can-biet#2-nhng-nguyn-nhn-lm-ure-mu-thay-i)
  * [3. Sự biến đổi của Ure máu gây hậu quả như thế nào?](https://bvnguyentriphuong.com.vn/noi-than-tiet-nieu/ure-mau-va-nhung-dieu-can-biet#3-s-bin-i-ca-ure-mu-gy-hu-qu-nh-th-no)
  * [4. Cách xử trí khi tăng ure máu](https://bvnguyentriphuong.com.vn/noi-than-tiet-nieu/ure-mau-va-nhung-dieu-can-biet#4-cch-x-tr-khi-tng-ure-mu)


## **1. Ure máu là gì?**
Ure máu là sản phẩm cuối cùng của chuyển hóa chất đạm (protein) trong cơ thể, được đào thải ra ngoài qua thận. Ure tương đối ít độc kể cả khi lượng Ure trong máu tăng cao. Để đánh giá khả năng lọc của thận, người ta thường xét nghiệm máu để xác định chỉ số Ure máu, nếu chỉ số này càng cao thì chức năng thận càng kém. Bình thường, Ure máu vào khoảng 2,5-7,5 mmol/l.
Ure luôn có trong cơ thể và thường xuyên được bổ sung bằng chất đạm (protein) chúng ta ăn hằng ngày. Đó là các protein ngoại sinh và được các protease của đường tiêu hóa chuyển hóa thành axit amin. Cuối cùng được chuyển hóa thành NH3 và CO2.
Xét nghiệm Ure máu là một trong các xét nghiệm được sử dụng để đánh giá tình trạng thận
+ Nếu mức Ure máu cao hơn bình thường thì có thể thận hoạt động không tốt. Hoặc có thể lượng protein cao, lượng nước uống không đủ dẫn đến lưu thông kém.
+ Còn nếu mức độ Ure máu thấp, thì có thể là dấu hiệu của các bệnh gan, suy dinh dưỡng. Để có kết luận bệnh chính xác hơn, bác sĩ sẽ chỉ định thực hiện thêm một số xét nghiệm khác. Bởi chỉ mình xét nghiệm Ure máu thì không đủ để sàng lọc, chẩn đoán hay theo dõi các bệnh lý của gan, thận.
## **2. Những nguyên nhân làm Ure máu thay đổi**
Ure ở mức bình thường vào khoảng 2,5-7,5mmol/l và sẽ có sự thay đổi ở một số trường hợp:
Mức ure máu có thể thay đổi vì nhiều nguyên nhân
2.1. Nguyên nhân tăng Ure máu
- Suy thận cấp hoặc mạn;
- Chế độ ăn nhiều protein;
- Xuất huyết tiêu hóa, nhiễm trùng nặng,...;
- Tăng dị hóa protein: Sốt, bỏng, suy dinh dưỡng,...;
- Ngộ độc thủy ngân.
- Uống quá nhiều các loại thuốc trầm cảm, một số loại kháng sinh, thuốc lợi tiểu hoặc thuốc cản quang,…
2.2. Nguyên nhân giảm Ure máu
- Hội chứng tiết ADH không thích hợp.
- Có thai.
- Ăn kiêng.
- Hội chứng giảm hấp thu.
- Suy gan, xơ gan, viêm gan nặng cấp hay mạn tính làm giảm tổng hợp Ure.
- Chế độ ăn nghèo protein, hòa loãng máu, hội chứng thận hư.
Để biết rõ nguyên nhân Ure máu tăng hoặc giảm, bệnh nhân nên đi xét nghiệm ure máu để được bác sĩ chẩn đoán chính xác nhất. Đồng thời giúp tầm soát bệnh và không để lại hậu quả nghiêm trọng về sau.
## **3. Sự biến đổi của Ure máu gây hậu quả như thế nào?**
Ure máu tăng hoặc giảm đều ảnh hưởng đến sức khỏe con người. Đặc biệt khi ure máu tăng cao có những dấu hiệu rất rõ ràng mà bạn cần đặc biệt lưu ý là:
Ăn không ngon, bụng luôn cảm thấy chướng
Hoa mắt, chóng mặt và nhức đầu trong thời gian dài
Thường xuyên mất ngủ về đêm dẫn đến kiệt sức
Hiện tượng nôn mửa, tiêu chảy kéo dài
Hơi thở có mùi Amoniac, nhịp thở không đều
Nhiệt độ cơ thể giảm
Cao huyết áp, mạch đập nhanh và nhẹ
Lưỡi có màu đen
Họng và niêm mạc miệng xuất hiện tình trạng viêm loét
Có thể xảy ra hiện tượng trụy mạch ở người suy thận độ nặng
Ure máu tăng quá cao có thể gây hôn mê, co giật
Đồng tử co và phản ứng ánh sáng kém
Võng mạc và vùng dưới da và niêm mạc xuất hiện hiện tượng chảy máu
Không thấy tổn thương thần kinh khu trú
## **4. Cách xử trí khi tăng ure máu**
Thay đổi chế độ ăn uống: Ure là sản phẩm cuối của Protein vì vậy bạn cần hạn chế nạp chất này vào cơ thể khi được chẩn đoán là mắc hội chứng ure tăng cao. Lượng Protein cơ thể được nạp tùy vào từng giai đoạn và nồng độ ure máu xét nghiệm. Chế độ dinh dưỡng này bạn có thể tham khảo ý kiến bác sĩ hoặc chuyên gia dinh dưỡng để có được sự tư vấn cụ thể nhất.
Có chế độ nghỉ ngơi hợp lý: Ure máu cao có thể được điều chỉnh thông qua việc nghỉ ngơi. Bệnh nhân cần tránh thức khuya, ngủ thiếu giấc,…
Lưu ý sử dụng các loại thuốc: các loại thuốc đặc biệt loại dẫn đến khả năng tăng ure máu bạn cần tránh sử dụng. Trong trường hợp sử dụng, bắt buộc phải có chỉ định và quan sát của bác sĩ để không gây ra các tác dụng phụ không mong muốn.
Xem thêm: [**Làm sao để bảo vệ chức năng thận**](https://bvnguyentriphuong.com.vn/than-loc-mau/lam-sao-de-bao-ve-chuc-nang-than)
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [1. Ure máu là gì?](https://bvnguyentriphuong.com.vn/noi-than-tiet-nieu/ure-mau-va-nhung-dieu-can-biet#1-ure-mu-l-g)
  * [2. Những nguyên nhân làm Ure máu thay đổi](https://bvnguyentriphuong.com.vn/noi-than-tiet-nieu/ure-mau-va-nhung-dieu-can-biet#2-nhng-nguyn-nhn-lm-ure-mu-thay-i)
  * [3. Sự biến đổi của Ure máu gây hậu quả như thế nào?](https://bvnguyentriphuong.com.vn/noi-than-tiet-nieu/ure-mau-va-nhung-dieu-can-biet#3-s-bin-i-ca-ure-mu-gy-hu-qu-nh-th-no)
  * [4. Cách xử trí khi tăng ure máu](https://bvnguyentriphuong.com.vn/noi-than-tiet-nieu/ure-mau-va-nhung-dieu-can-biet#4-cch-x-tr-khi-tng-ure-mu)



## Hiệu chỉnh liều của thuốc khi có tình trạng suy thận

Việc tiếp cận điều trị cho những bệnh nhân có chức năng thận suy giảm gồm có:
– làm giảm hoặc ngăn chặn sự tiến triển của suy thận;
– làm giảm tần suất và mức độ nghiêm trọng của các tác động bất lợi ngoài thận;
– tránh hoặc giảm thiểu việc sử dụng các thuốc gây độc trên thận.
Đầu tiên, lưu ý rằng cần bắt đầu hiệu chỉnh liều lượng của thuốc khi độ thanh thải creatinin dưới 50 ml/phút. Thật vậy, việc hiệu chỉnh liều lúc này là cần thiết để tránh sự tích lũy của các thuốc cùng độc tính mà chúng gây ra. Khi bệnh nhân có suy thận, thời gian bán thải của thuốc được tăng lên, điều đó có nghĩa rằng thuốc sẽ được lưu giữ lâu hơn trong cơ thể và rằng việc sử dụng thuốc ở liều quá cao hoặc liều lặp lại đều có thể dẫn đến sự tích lũy của thuốc [2, 3].
**Khi nào cần hiệu chỉnh liều của thuốc?**
Để biết liều dùng của thuốc có cần hiệu chỉnh hay không, chúng ta phải xem xét ba đặc tính dược động học của thuốc [1, 2, 4, 5]. Việc phân tích các đặc tính này cho phép chúng ta hiểu được suy thận có thể ảnh hưởng như thế nào đến quá trình chuyển hóa của thuốc trong cơ thể.
Một thuốc không được hấp thu đáng kể vào cơ thể cũng sẽ không có được đủ nồng độ trong máu tương ứng với mức lọc tại thận, gây ảnh hưởng đến nồng độ thuốc trong huyết tương. Do đó,  _một thuốc hấp thu không đáng kể không phải là đối tượng để điều chỉnh liều._
**_Chuyển hóa_**
Con đường thải trừ chính của một thuốc là thông tin quan trọng cho việc hiệu chỉnh liều. Thật vậy, nồng độ của một thuốc được chuyển hóa gần như hoàn toàn ở gan, hoặc các chất chuyển hóa có hoạt tình của thuốc không được thải trừ ở thận, sẽ ít bị ảnh hưởng bởi suy thận, nói cách khác thuốc không bị tích lũy trong cơ thể. Tuy nhiên, người ta đã chứng minh rằng một số phản ứng enzyme gan nhất định bị chậm đi khi có suy thận, trong khi một số khác lại được đẩy nhanh lên, có thể khiến việc giải thích về chuyển hóa của thuốc ở những bệnh nhân suy thận trở nên khó khăn hơn. Tuy nhiên, nhìn chung,  _không cần thiết hiều chỉnh liều cho các thuốc được chuyển hóa ở gan hoặc không có các chất chuyển hóa có hoạt tính được thải trừ qua thận._
**_Thải trừ và thải loại_**
Liều lượng của thuốc cần được hiệu chỉnh tùy theo chức năng thận khi  _thuốc đó có hơn 40-50% lượng thuốc hoặc các chất chuyển hóa có hoạt tính của thuốc, được đào thải qua thận._
## **Hiệu chỉnh liều như thế nào?**
Có 3 cách thức hiệu chỉnh liều được đưa ra [1, 2, 4, 5]:
– giảm liều,
– tăng khoảng cách giữa các lần đưa thuốc,
– hoặc vừa giảm liều vừa kéo dài khoảng cách giữa các lần đưa thuốc.
**a. Các trường hợp thường gặp cần có sự _giảm liều_ của thuốc**
– Thuốc có khoảng điều trị hẹp, có nghĩa là khi có rất ít sự chênh lệch giữa liều điều trị và liều gây độc. Trong trường hợp này, sử dụng thuốc với mức liều bình thường có thể tạo ra nồng độ thuốc có nguy cơ gây độc tính (ví dụ : digoxin).
– Thuốc có thời gian bán thải ngắn và không tăng lên trên bệnh nhân suy thận, điều này nghĩa là thuốc sẽ được thải trừ nhanh chóng khỏi cơ thể. Việc tăng khoảng cách giữa các lần đưa thuốc có thể khiến thuốc không đạt được nồng độ cần thiết trong điều trị (penicillin).
– Thuốc cần đạt được một nồng độ tối thiểu hoặc không đổi trong huyết tương khi điều trị. Vì vậy, khoảng cách dùng thuốc phải không được thay đổi, thuốc mới có thể duy trì nồng độ này.
**b. Các trường hợp có thể _kéo dài khoảng cách_ giữa các lần đưa thuốc**
– Thuốc có phạm vi điều trị rộng.
– Hoạt động của thuốc có liên quan đến nồng độ đỉnh đạt được. Việc giảm liều sẽ khiến thuốc không đạt được nồng độ này. Hoặc khi cần kéo dài khoảng cách giữa các lần đưa thuốc để tránh độc tính hoặc khi thời gian bán thải của thuốc được tăng lên (ví dụ, gentamicin), việc mở rộng khoảng cách đưa thuốc sẽ cho phép thuốc và các chất chuyển hóa có hoạt tính của thuốc được thải trừ khỏi cơ thể.
**c. Cuối cùng, trong nhiều trường hợp, sẽ cần _vừa tăng khoảng cách giữa các lần đưa thuốc vừa giảm liều của thuốc_(ví dụ như các cephalosporin, metronidazol)**
Việc áp dụng các quy tắc thường rất khó khăn trong thực tế, phương pháp kết hợp vừa giảm liều và vừa kéo dài khoảng thời gian giữa các lần dùng thường được áp dụng nhiều hơn, lý do chính là nhằm đảm bảo nồng độ điều trị. Thật vậy, ví dụ việc dùng một thuốc ở liều bình thường sau mỗi 15 giờ sẽ gây khó khăn cho bệnh nhân để dùng thuốc đúng giờ. Sẽ là hợp lý hơn nếu ta giảm liều và chuyển sang dùng thuốc sau mỗi 12 giờ.
Bệnh nhân suy thận nhìn chung có nguy cơ cao gặp các tác dụng không mong muốn của thuốc do sự tích lũy thuốc trong cơ thể. Những ảnh hưởng của việc sử dụng một số thuốc liều cao trên những đối tượng này đã được biết đến.
Hầu hết các loại thuốc được thải trừ qua thận. Ở bệnh nhân suy thận, con đường thải trừ này bị phá vỡ có thể dẫn đến việc tích lũy của thuốc và/hoặc của các chất chuyển hóa có hoạt tính.
Bệnh nhân có chức năng thận suy giảm vì vậy có nhiều nguy cơ phát triển các phản ứng có hại của thuốc do tích lũy thuốc. Những ảnh hưởng của liều cao trên đối tượng này rất thường gặp và đôi khi có thể gây độc.
TÀI LIỆU THAM KHẢO
1. Matzke GR, Frye RF. Drug administration in patients with renal in-sufficiency: minimizing renal and extrarenal toxicity. Drug Safety 1997; 16 (3): 205-31.
2. Swan SK, Bennett WM. Drug dosing guidelines in patients with re-nal failure. West J Med1992; 156: 633-8.
3. Bennett W, Arnoff G, Golper T, et al. Drug Prescribing in Renal Failure, Dosing Guidelines for Adults. Philadelphie: American College of Physicians, 1999.
4. Launay-Vacher V, Storme T, Izzedine H, Deray G. Modifications phar-macocinétiques au cours de l’insuffisance rénale. Presse Med2001; 30: 597-604.
5. Bakris GL, Talbert R. Drug dosing in patients with renal insufficiency: asimplified approach. Postgrad Med1993; 94 (3): 153-64.
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh

## ️ Hướng dẫn lâm sàng về các liệu pháp dược lý sẵn có cho COVID-19 của JHMI

  * [Mục đích, phát triển và các nguyên lý hướng dẫn](https://bvnguyentriphuong.com.vn/than-loc-mau/huong-dan-lam-sang-ve-cac-lieu-phap-duoc-ly-san-co-cho-covid-19-cua-jhmi#mc-ch-pht-trin-v-cc-nguyn-l-hng-dn)
  * [Quá trình phát triển: ](https://bvnguyentriphuong.com.vn/than-loc-mau/huong-dan-lam-sang-ve-cac-lieu-phap-duoc-ly-san-co-cho-covid-19-cua-jhmi#qu-trnh-pht-trin)


## **Mục đích, phát triển và các nguyên lý hướng dẫn**
### **Mục đích:**
Mục đích của tài liệu này là cung cấp hướng dẫn điều trị dược lý cho các bác sĩ lâm sàng tại Bệnh viện Johns Hopkins (JHH) đang quản lý việc chăm sóc bệnh nhân được chẩn đoán nhiễm bệnh coronavirus 2019 (COVID-19). Hướng dẫn được cung cấp dựa trên kiến thức, kinh nghiệm hiện tại và ý kiến chuyên gia. Mục tiêu là thiết lập và ban hành hướng tiếp cận chuẩn để điều trị dược lý cho những bệnh nhân nội trú của JHH được chẩn đoán nhiễm COVID-19. Hướng dẫn này không nhằm thay thế hoặc loại bỏ việc quản lý và đánh giá lâm sàng cá thể hoá bệnh nhân tùy theo đánh giá tốt nhất của bác sĩ lâm sàng dựa trên những yếu tố bệnh nhân độc nhất.
### **Quá trình phát triển:**
Paul Auwaerter, Bác sĩ, Giám đốc lâm sàng Khoa Truyền nhiễm của Johns Hopkins Medicine, đã triệu tập một nhóm các chuyên gia lâm sàng của Johns Hopkins về bệnh truyền nhiễm, phổi và chăm sóc đặc biệt, dược lâm sàng và dược để xem xét và cân nhắc các bằng chứng sẵn có về điều trị COVID-19.
Từ nhóm làm việc lớn, một nhóm viết nhỏ hơn đã được triệu tập để phát triển hướng dẫn. Nhóm đã họp cuộc gọi hội nghị hai lần để xác dịnh phạm vi hướng dẫn, xem xét bằng chứng, xem xét các tài liệu dự thảo và thiết lập sự đồng thuận.
**NHÓM BIÊN DỊCH KHOA THẬN-LỌC MÁU BV NGUYỄN TRI PHƯƠNG**  
---  
**Chủ tọa** : PGS. TS. BS Phạm Văn Bùi – Cố vấn Bệnh viện Nguyễn Tri Phương  
**Thành viên đóng góp**  
  * ThS. BS Nguyễn Thanh Vân
  * BS Lê Thị Thu Thảo (1992)
  * BS Lâm Thị Mỹ Tiên
  * BS Nguyễn Hồ Duy

  
**​Toàn bộ văn bản xin vui lòng xem[tại đây](https://drive.google.com/open?id=1OwsWb3SOKggxYQLZIIrGuQ5qnrJkKVgr)./.**
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [Mục đích, phát triển và các nguyên lý hướng dẫn](https://bvnguyentriphuong.com.vn/than-loc-mau/huong-dan-lam-sang-ve-cac-lieu-phap-duoc-ly-san-co-cho-covid-19-cua-jhmi#mc-ch-pht-trin-v-cc-nguyn-l-hng-dn)
  * [Quá trình phát triển: ](https://bvnguyentriphuong.com.vn/than-loc-mau/huong-dan-lam-sang-ve-cac-lieu-phap-duoc-ly-san-co-cho-covid-19-cua-jhmi#qu-trnh-pht-trin)



## ️ 10 biểu hiện cảnh báo chức năng thận bị suy giảm

  * [2. Nhức đầu, mệt mỏi và suy nhược cơ thể](https://bvnguyentriphuong.com.vn/than-loc-mau/10-bieu-hien-canh-bao-chuc-nang-than-bi-suy-giam#2-nhc-u-mt-mi-v-suy-nhc-c-th)
  * [3. Da khô kèm theo ngứa ngáy](https://bvnguyentriphuong.com.vn/than-loc-mau/10-bieu-hien-canh-bao-chuc-nang-than-bi-suy-giam#3-da-kh-km-theo-nga-ngy)
  * [4. Mùi hôi miệng và có vị kim loại](https://bvnguyentriphuong.com.vn/than-loc-mau/10-bieu-hien-canh-bao-chuc-nang-than-bi-suy-giam#4-mi-hi-ming-v-c-v-kim-loi)
  * [6. Sưng ở mắt cá chân, bàn chân và bàn tay](https://bvnguyentriphuong.com.vn/than-loc-mau/10-bieu-hien-canh-bao-chuc-nang-than-bi-suy-giam#6-sng-mt-c-chn-bn-chn-v-bn-tay)
  * [9. Huyết áp cao](https://bvnguyentriphuong.com.vn/than-loc-mau/10-bieu-hien-canh-bao-chuc-nang-than-bi-suy-giam#9-huyt-p-cao)
  * [10. Có những thay đổi khi đi tiểu](https://bvnguyentriphuong.com.vn/than-loc-mau/10-bieu-hien-canh-bao-chuc-nang-than-bi-suy-giam#10-c-nhng-thay-i-khi-i-tiu)


Những biểu hiện này không phải chỉ đặc hiệu cho bệnh thận - nhưng có thể thường gặp bệnh bệnh thận, nhất là [suy thận mạn](https://indembassy.com.vn/suy-than-man/) tính
## **1. Khó ngủ**
Khi thận hoạt động không hiệu quả có nghĩa độc tố không thể được thải lọc ra khỏi cơ thể qua nước tiểu và tồn tại ở trong máu. Mức độ độc tố tăng lên khiến cơ thể khó đi vào giấc ngủ. Đó là lý do tại sao thời gian ngủ ít hơn, khó ngủ hơn và tăng nguy cơ suy giảm chức năng thận.
**_Cảnh báo:_** Những người mắc bệnh thận mãn tính thường có hội chứng ngưng thở khi ngủ. Ngưng thở khi ngủ là một rối loạn gây ra một hoặc nhiều lần tạm dừng hơi thở khi ngủ. Những lần ngừng thở có thể kéo dài từ vài giây đến một phút. Sau mỗi lần tạm dừng, hơi thở bình thường trở lại với tiếng khịt mũi lớn. Ngáy lớn và kéo dài liên tục báo hiệu rằng có một số vấn đề về sức khỏe cần đi khám bác sĩ.
## **2. Nhức đầu, mệt mỏi và suy nhược cơ thể**
Thận khỏe mạnh và hoạt động hiệu quả sẽ chuyển đổi Vitamin D trong cơ thể để duy trì xương chắc khỏe và sản xuất hormone Erythropoietin (EPO) có vai trò quan trọng trong việc sản xuất các tế bào hồng cầu. Khi thận hoạt động không hiệu quả, chúng tạo ra ít EPO gây giảm sản xuất các tế bào hồng cầu làm thiếu hụt lượng oxi dẫn đến cơ thể mệt mỏi, thường xuyên mỏi cơ, hoạt động não kém hiệu quả.
**_Cảnh báo:_** Thông thường, những người mắc bệnh thận mãn tính bị thiếu máu. Thiếu máu có thể bắt đầu xảy ra khi hiệu suất làm việc của thận từ 20-50%. Nếu cơ thể mặc dù được nghỉ ngơi và ngủ đủ giấc nhưng tiếp tục trải qua cảm giác mệt mỏi, thiếu năng lượng, nên đến các cơ sở y tế để kiểm tra sức khỏe.
## **3. Da khô kèm theo ngứa ngáy**
Thận khỏe mạnh thực hiện các công việc là loại bỏ chất thải và một số chất dư thừa từ máu, giúp tạo ra các tế bào hồng cầu và duy trì lượng khoáng chất thích hợp trong cơ thể. Da ngứa và khô báo hiệu thận hoạt động chưa thực sự tốt để duy trì sự cân bằng các khoáng chất và chất dinh dưỡng, điều này có thể dẫn đến bệnh xương và thận.
**Cảnh báo:** Nếu da khô và ngứa, hãy cố gắng uống nước nhiều hơn. Hãy nhớ rằng, trước khi dùng bất kỳ loại thuốc nào để điều trị ngứa, hãy tham khảo ý kiến bác sĩ. Một số loại thuốc chứa thành phần có khả năng làm tình trạng suy thận trở nên trầm trọng hơn.
## **4. Mùi hôi miệng và có vị kim loại**
Khi chất thải tích tụ trong máu làm thay đổi mùi vị thức ăn đồng thời để lại mùi vị kim loại trong miệng. Hôi miệng là một dấu hiệu khác của việc có quá nhiều độc tố trong máu. Hơn nữa, cảm giác không muốn ăn thịt và mất cảm giác ngon miệng nói chung, điều này có thể dẫn đến tụt cân do thiếu dinh dưỡng.
**Cảnh báo:** Có nhiều lý do khiến thực phẩm có thể có vị kim loại (từ dị ứng đến sức khỏe răng miệng kém). Thông thường, vị kim loại trong miệng sẽ biến mất nếu nguyên nhân giả định đã được điều trị. Nếu mùi vị tiếp tục xuất hiện, cần tư vấn bác sĩ để có thêm lời khuyên.
## **5. Khó thở**
Mối liên quan giữa bệnh thận và khó thở, đặc biệt sau vận động gắng sức liên quan đến hai cơ chế.
Đầu tiên, cơ thể ứ dịch (vì thận lọc không hiệu quả) và làm kém hoạt động của phổi (ứ dịch phế nang). Thứ hai, thiếu hồng cầu làm giảm sự vận chuyển lượng oxy của cơ thể và điều này dẫn đến khó thở.
**Cảnh báo:** Có nhiều lý do gây khó thở vì nhiều nguyên nhân như [suy thận](https://tamminhduong.com/benh-than/suy-than.html), hen suyễn, ung thư phổi hoặc suy tim. Nếu nhận thấy rằng cơ thể liên tục hết hơi sau khi vận động thể chất, nên liên hệ với bác sĩ ngay lập tức.
## **6. Sưng ở mắt cá chân, bàn chân và bàn tay**
Chức năng thận kém sẽ không loại bỏ được hết lượng chất thải ra khỏi cơ thể. Điều này dẫn đến việc natri bị giữ lại trong cơ thể khiến ứ dịch và gây sưng ở mắt cá chân, bàn chân và bàn tay. Phù nề các chi dưới cũng có thể báo hiệu bệnh tim và gan hoặc các vấn đề về tĩnh mạch chân.
**Cảnh báo:** Đôi khi dùng thuốc, giảm lượng muối và lọc máu có thể giúp thuyên giảm tình trạng trên.
## **7. Đau lưng**
Suy thận có thể dẫn đến đau lưng thường xuyên ngay phía dưới khung xương sườn, có thể được cảm giác đau lan ra phía trước vùng chậu hoặc vùng hông.
**Lưu ý:** Đau lưng do suy thận đi kèm với cảm giác ốm yếu, nôn mửa, sốt và đi tiểu thường xuyên. [Đau lưng](https://indembassy.com.vn/dau-lung/) cơ năng bình thường không có mối tương quan với thận, cơn đau khu trú và xảy ra đột ngột, không kèm theo sốt. Nếu bạn tiếp tục bị đau lưng, sử dụng thuốc giảm đau không hiệu quả, cần đi khám bác sĩ sớm nhất có thể.
## **8. Bọng mắt**
Dấu hiệu sớm cho thấy thận bị tổn thương là sự xuất hiện của protein trong nước tiểu. Bọng mắt xung quanh mắt có thể được giải thích do thận thải một lượng lớn protein vào nước tiểu thay vì giữ lại trong máu và phân phối khắp cơ thể. Mất protein làm giảm áp lực keo của máu và gây ra phù.
**Lưu ý:** Nếu chắc chắn rằng cơ thể đang nhận đủ chất béo và protein, nhưng nếu bọng mắt quanh mắt không thuyên giảm, hãy nhớ sắp xếp cuộc gặp với bác sĩ.
## **9. Huyết áp cao**
Hệ thống tuần hoàn và thận phụ thuộc và có mối liên hệ mật thiết với nhau. Thận có nephron (đơn vị thận) nhỏ lọc chất thải từ máu. Nếu các mạch máu bị tổn thương, các nephron lọc máu sẽ không nhận đủ oxy và chất dinh dưỡng. Đó là lý do tại sao huyết áp cao là nguyên nhân hàng thứ hai của suy thận.
**Lưu ý:** Kiểm soát huyết áp cao để tránh suy thận. Bổ sung thực phẩm giàu axit folic – chất tham gia vào việc sản xuất các tế bào hồng cầu và có thể giúp ngăn ngừa thiếu máu.
## **10. Có những thay đổi khi đi tiểu**
Thận có nhiệm vụ sản xuất nước tiểu và loại bỏ chất thải qua đường tiểu. Vì vậy, không nên bỏ qua những thay đổi về tần suất đi tiểu, mùi, màu sắc và các thay đổi khác của nước tiểu như:
  * Tăng số lần đi tiểu, đặc biệt là vào ban đêm. Số lần giao động từ 4 đến 10 lần một ngày được coi là bình thường.
  * Thấy máu trong nước tiểu. Thận khỏe mạnh lọc chất thải từ máu để tạo ra nước tiểu, nhưng suy thận, các tế bào máu có xuất hiện ở nước tiểu.
  * Nước tiểu có bọt: bọt khó tan cho thấy có sự hiện diện của protein trong nước tiểu.


Xem thêm: [**Làm sao để bảo vệ chức năng thận**](https://bvnguyentriphuong.com.vn/than-loc-mau/lam-sao-de-bao-ve-chuc-nang-than)
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [2. Nhức đầu, mệt mỏi và suy nhược cơ thể](https://bvnguyentriphuong.com.vn/than-loc-mau/10-bieu-hien-canh-bao-chuc-nang-than-bi-suy-giam#2-nhc-u-mt-mi-v-suy-nhc-c-th)
  * [3. Da khô kèm theo ngứa ngáy](https://bvnguyentriphuong.com.vn/than-loc-mau/10-bieu-hien-canh-bao-chuc-nang-than-bi-suy-giam#3-da-kh-km-theo-nga-ngy)
  * [4. Mùi hôi miệng và có vị kim loại](https://bvnguyentriphuong.com.vn/than-loc-mau/10-bieu-hien-canh-bao-chuc-nang-than-bi-suy-giam#4-mi-hi-ming-v-c-v-kim-loi)
  * [6. Sưng ở mắt cá chân, bàn chân và bàn tay](https://bvnguyentriphuong.com.vn/than-loc-mau/10-bieu-hien-canh-bao-chuc-nang-than-bi-suy-giam#6-sng-mt-c-chn-bn-chn-v-bn-tay)
  * [9. Huyết áp cao](https://bvnguyentriphuong.com.vn/than-loc-mau/10-bieu-hien-canh-bao-chuc-nang-than-bi-suy-giam#9-huyt-p-cao)
  * [10. Có những thay đổi khi đi tiểu](https://bvnguyentriphuong.com.vn/than-loc-mau/10-bieu-hien-canh-bao-chuc-nang-than-bi-suy-giam#10-c-nhng-thay-i-khi-i-tiu)



## ️ Tổng quan về ghép thận

  * [Ghép thận là gì?](https://bvnguyentriphuong.com.vn/than-loc-mau/tong-quan-ve-ghep-than#ghp-thn-l-g)
  * [Nguồn thận để ghép lấy từ đâu?](https://bvnguyentriphuong.com.vn/than-loc-mau/tong-quan-ve-ghep-than#ngun-thn-ghp-ly-t-u)
  * [Chỉ định và chống chỉ định ghép thận](https://bvnguyentriphuong.com.vn/than-loc-mau/tong-quan-ve-ghep-than#ch-nh-v-chng-ch-nh-ghp-thn)
  * [Chỉ định ghép thận: ](https://bvnguyentriphuong.com.vn/than-loc-mau/tong-quan-ve-ghep-than#ch-nh-ghp-thn)
  * [Chống chỉ định ghép thận: ](https://bvnguyentriphuong.com.vn/than-loc-mau/tong-quan-ve-ghep-than#chng-ch-nh-ghp-thn)
  * [Ghép thận cần làm các xét nghiệm gì?](https://bvnguyentriphuong.com.vn/than-loc-mau/tong-quan-ve-ghep-than#ghp-thn-cn-lm-cc-xt-nghim-g)
  * [Thận ghép tồn tại được bao lâu?](https://bvnguyentriphuong.com.vn/than-loc-mau/tong-quan-ve-ghep-than#thn-ghp-tn-ti-c-bao-lu)
  * [Theo dõi hậu ghép thận](https://bvnguyentriphuong.com.vn/than-loc-mau/tong-quan-ve-ghep-than#theo-di-hu-ghp-thn)


## **Ghép thận là gì?**
Ghép thận là lấy thận khỏe mạnh từ người hiến ghép vào ổ bụng của người nhận. Vị trí ghép thận thường là vùng hố chậu bên phải (cũng có thể là bên trái). Nguồn thận ghép có thể từ người cho sống hoặc người cho chết não, người cho tim ngừng đập. Ghép thận không phải là cắt bỏ thận bệnh rồi ghép một quả thận mới vào đúng vị trí cũ. Người ta chỉ cắt bỏ thận bệnh lý trong một số trường hợp đặc biệt (thận đa nang quá to, thận bệnh bị viêm mãn tính nặng, hẹp động mạch thận nặng). Một người có thể ghép thận được nhiều lần, nếu thận ghép bị hỏng.
## **Nguồn thận để ghép lấy từ đâu?**
Nguồn thận ghép có thể từ người cho sống hoặc người cho chết não, người cho tim ngừng đập. Người chết não, ngừng tuần hoàn có lấy được thận để ghép hay không do những hội đồng chuyên môn của bệnh viện quyết định. Nguồn thận ghép từ hiến thận khỏe mạnh có thể cùng huyết thống (bố, mẹ đẻ, anh chi em ruột hoặc anh chị em họ hàng xa hơn) và không cùng huyết thống. Những trường hợp không cùng huyết thống phải chứng minh được sự “tự nguyện hiến thận vì mục đích nhân đạo” chữa bệnh chứ không được mua bán (luật pháp cấm mua bán tạng).
Đối với người hiến thận, khi hiến 1 quả thận thì quản thận còn lại vẫn đảm đương chức năng của cả 2 thận. Do đó người hiến thận nếu được tư vấn, khám xét và làm các xét nghiệm đầy đủ, chính xác thì việc ghép thận để ghép cho người khác là đảm bảo an toàn, không ảnh hưởng gì đến chất lượng cuộc sống và tuổi thọ của người hiến. Vì vậy người muốn hiến thận phải được tư vấn, hiến thận tại các bệnh viện có chuyên khoa ghép thận.
## **Chỉ định và chống chỉ định ghép thận**
### **Chỉ định ghép thận:**
Bệnh thận mạn giai đoạn cuối có nguyện vọng ghép thận, có tình trạng tim mạch ổn định, tình trạng toàn thân và tình trạng mạch máu vùng chậu tốt, có sự hỗ trợ hiệu quả từ gia đình, xã hội và sẵn sàng tuân thủ kế hoạch điều trị và theo dõi.
### **Chống chỉ định ghép thận:**
Bệnh ác tính, nhiễm khuẩn chưa kiểm soát, bệnh lý tim mạch không ổn định, bệnh lý mạch máu không tốt, bệnh lý đông máu, bệnh nhân có kì vọng đời sống ngắn, phản ứng đọ chéo với người nhận trước ghép dương tính, chậm phát triển tâm thần, vận động, một số bệnh lý khác ( như xơ gan, bệnh cường giáp chưa điều trị ổn định, cường cận giáp, loét dạ dày nặng, nghiện rượu). 
## **Ghép thận cần làm các xét nghiệm gì?**
Khi đã đủ điều kiện ban đầu để tuyển chọn nhận thận và hiến thận, cả người nhận và hiến thận sẽ được làm các xét nghiệm nhằm xác định sự phù hợp giữa người nhận và hiến (nhóm máu, định danh HLA, crossmatch, kháng thể kháng HLA), tình trạng sức khỏe chung của cả 2 người (các xét nghiệm sinh hóa, huyết học, đông máu, vi khuẩn, virus, ký sinh trùng ...), tình trạng giải phẫu chức năng mạch máu thận của người hiến và mạch máu vùng chậu của người nhận. Nếu tất cả các xét nghiệm đảm bảo yêu cầu nhận và hiến thận, được hội đồng chuyên môn của bệnh viện thông qua, thì phẫu thuật lấy thận để ghép và phẫu thuật ghép thận sẽ được tiến hành đồng thời.
## **Thận ghép tồn tại được bao lâu?**
Có nhiều yếu tố ảnh hưởng đến sự sống còn của thận ghép: như thận ghép từ người cho sống hay chết, tình trạng sức khỏe người nhận thận, sự hòa hợp nhóm máu, tương đồng về mặt miễn dịch… mà tùy vào từng cá thể sẽ có thời gian tồn tại thận ghép khác nhau. Nhìn chung tỉ lệ thận ghép tồn tại trên 1 năm là 95%, trên 5 năm là trên 80% và trên 10 năm là 75%. Khi thận ghép bị hỏng, bệnh nhân có thể tiếp tục ghép thận lần 2, lần 3 và phải chạy thận nhân tạo trong thời gian chờ được ghép.
## **Theo dõi hậu ghép thận**
Thông thường sau ghép thận hàng ngày bệnh nhân phải dùng 2 – 3 loại thuốc chống thải ghép và phải dùng suốt đời. Tuy vậy các chi phí cũng không tốn kém hơn so với điều trị bằng thận nhân tạo hay lọc màng bụng vì có thẻ bảo hiểm y tế chi trả. Sau ghép thận, mặc dù chức năng thận ghép tốt, bệnh nhân trở lại cuộc sống khỏe mạnh như người bình thường nhưng các bệnh nhân luôn luôn cần lưu ý một số điều sau: tái khám đúng hẹn, dùng thuốc đúng giờ, xây dựng một lối sống lành mạnh, tuân thủ và nghe theo chỉ dẫn của nhân viên y tế. 
Tóm lại, ghép thận là một hệ thống các quy trình chặt chẽ từ khâu tuyển chọn, sàng lọc, phẫu thuật, chăm sóc và điều trị sau ghép. Ghép thận là lựa chọn hàng đầu trong các phương pháp điều trị thay thế thận đối với bệnh nhân suy thận mạn giai đoạn cuối, làm tăng chất lượng cuộc sống và cải thiện tỉ lệ sống còn.
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh
[youtube.com/bvntp](http://youtube.com/bvntp)
  * [Ghép thận là gì?](https://bvnguyentriphuong.com.vn/than-loc-mau/tong-quan-ve-ghep-than#ghp-thn-l-g)
  * [Nguồn thận để ghép lấy từ đâu?](https://bvnguyentriphuong.com.vn/than-loc-mau/tong-quan-ve-ghep-than#ngun-thn-ghp-ly-t-u)
  * [Chỉ định và chống chỉ định ghép thận](https://bvnguyentriphuong.com.vn/than-loc-mau/tong-quan-ve-ghep-than#ch-nh-v-chng-ch-nh-ghp-thn)
  * [Chỉ định ghép thận: ](https://bvnguyentriphuong.com.vn/than-loc-mau/tong-quan-ve-ghep-than#ch-nh-ghp-thn)
  * [Chống chỉ định ghép thận: ](https://bvnguyentriphuong.com.vn/than-loc-mau/tong-quan-ve-ghep-than#chng-ch-nh-ghp-thn)
  * [Ghép thận cần làm các xét nghiệm gì?](https://bvnguyentriphuong.com.vn/than-loc-mau/tong-quan-ve-ghep-than#ghp-thn-cn-lm-cc-xt-nghim-g)
  * [Thận ghép tồn tại được bao lâu?](https://bvnguyentriphuong.com.vn/than-loc-mau/tong-quan-ve-ghep-than#thn-ghp-tn-ti-c-bao-lu)
  * [Theo dõi hậu ghép thận](https://bvnguyentriphuong.com.vn/than-loc-mau/tong-quan-ve-ghep-than#theo-di-hu-ghp-thn)



## ️ Lọc máu chất lượng cao được sự an tâm từ du khách

Từ tháng 8/2016, bệnh viện hợp tác với các tổ chức của Nhật Bản, một trong các quốc gia có chất lượng lọc máu tốt nhất thế giới, xây dựng [trung tâm lọc máu](https://vnexpress.net/suc-khoe/trung-tam-loc-mau-hien-dai-nhat-viet-nam-3451303.html) đạt tiêu chuẩn quốc tế. Trung tâm không dùng lại màng lọc, chất lượng nước siêu tinh khiết do được "khử độc" một lần nữa bằng màng lọc nội độc tố, quy trình lọc máu được các chuyên gia Nhật Bản huấn luyện và kiểm tra định kỳ.
Trung tâm hiện có tên trong danh sách khuyến nghị của các trung tâm hỗ trợ y tế như Nhật Bản, Mỹ, châu Âu... Hiện nơi đây nhận được nhiều đơn đăng ký qua mạng của khách nước ngoài có chỉ định lọc máu từ Mỹ, Pháp, Đức, Australia, Hàn Quốc, Đài Loan, Trung Quốc... Nhiều Việt kiều về nước thăm thân nhân cũng đến đây để chạy thận
Toàn bộ nội dung xin tham khảo [tại đây](https://vnexpress.net/suc-khoe/du-khach-ngoai-chon-chay-than-o-viet-nam-3977995.html?fbclid=IwAR3PZsYKYvSdto4Kh9WB5xczxu5Aprsc7nBTDcLOWzFFM6RoEPD1y5hBfAk)./.
**Bệnh viện Nguyễn Tri Phương** - Bệnh viện Đa khoa Hạng I Thành phố Hồ Chí Minh
  * 468 Nguyễn Trãi, Phường 8, Quận 5, Tp. Hồ Chí Minh
  * Hotline: (84-028) 39234332
  * Mạng xã hội **Facebook** : [**Bệnh viện Nguyễn Tri Phương**](https://www.facebook.com/BVNTP/)
  * Đăng ký (Subcribe) kênh **Youtube** : [https://youtube.com/bvntp](https://youtube.com/bvntp?fbclid=IwAR3q_UvPI4OZAebT1uQGPKKwk3RmCzAFLkBJm9lb7EwIz0EHtgiLhKM5bxU)
  * Quan tâm Zalo Official: [zalo.me/1744466261097093886](https://zalo.me/1744466261097093886?fbclid=IwAR3E-fLqdh-x1cYSvuDY6E5Eyxfjo5ZSs4p0hDWAyBG-ROlTkxXkXvdEWAY)



## ️ Những nguyên nhân phổ biến gây tiểu đêm

  * [Tiểu đêm là tình trạng gì?](https://bvnguyentriphuong.com.vn/than-loc-mau/nhung-nguyen-nhan-pho-bien-gay-tieu-dem#tiu-m-l-tnh-trng-g)
  * [Tăng sản lành tính tuyến tiền liệt ở nam giới](https://bvnguyentriphuong.com.vn/than-loc-mau/nhung-nguyen-nhan-pho-bien-gay-tieu-dem#tng-sn-lnh-tnh-tuyn-tin-lit-nam-gii)


## **Tiểu đêm là tình trạng gì?**
Tiểu đêm được định nghĩa là tăng nhu cầu quá mức khiến ai đó phải thức giấc để đi tiểu vào buổi tối. Bạn có thể tự nhận thấy mình phải sử dụng nhà vệ sinh nhiều hơn 1 lần trong đêm và làm gián đoạn giấc ngủ của bản thân. Nó khác với chứng đái dầm, tình trạng thường xảy ra ở trẻ nhỏ. Một số nguyên nhân Có 1 số nguyên nhân gây ra tình trạng tiểu đêm, thường gặp nhất là uống quá nhiều nước hay các loại thức uống khác (đặc biệt là thức uống có cafein và cồn) khi sắp đến giờ ngủ. Giảm lượng nước nhập thời điểm trên giúp giảm thiểu đáng kể tình trạng này. Thông thường, cơ thể chúng ta có khả năng cô đặc nước tiểu, cho phép chúng ta ngủ suốt đêm mà không phải thức giấc, nhưng khi chúng ta già đi, công việc này không được hoàn thành tốt nữa. Ngoài ra, ở những người đàn ông lớn tuổi, tình trạng tiểu đêm này còn do bàng quang phải giữ nhiều nước tiểu hơn vì sự phì đại tuyến tiền liệt. Trong khi đó, phụ nữ có bàng quang yếu hơn hay các vấn đề tiết niệu khác. Viêm nhiễm bàng quang hay đường tiết niệu làm tăng đi tiểu vào ban đêm. Các bệnh lý khác cũng gây ra như:
  * Đái tháo đường
  * Bệnh thận mạn
  * Suy tim sung huyết
  * Tăng calci máu


Có nhiều loại thuốc cũng làm đi tiểu đêm, thường nhất là thuốc lợi tiểu trong điều trị tăng huyết áp hay điều trị phù ngoại biên (như phù bàn chân và mắt cá). Một trong số đó là furosemide (Lasix), những thuốc khác như:
  * Demeclocycline
  * Lithium
  * Methoxyflurane
  * Phenytoin
  * Propoxyphene


Cuối cùng, các rối loạn giấc ngủ cũng có thể gây ra tiểu đêm. Chứng ngưng thở do tắc nghẽn đường thở khi ngủ đã được ghi nhận làm tăng tần suất tiểu đêm, bởi vì khi thức giấc, cơ thể chúng ta nhận thức được tình trạng căng đầy bàng quang. Thêm vào đó, trạng thái tắc nghẽn đường thở khi ngủ làm quả tim phát đi tín hiệu thải nước tiểu từ 2 quả thận, vì trạng thái này làm tăng áp lực âm trong lồng ngực, tương tự xảy khi quá tải thể tích tuần hoàn. Tín hiệu hóc môn từ tim phát đi làm thận tăng thải ra từng lượng nước tiểu nhỏ khiến chúng ta phải đi tiểu nhiều lần. Do đó, điều trị bệnh lý ngưng thở do tắc nghẽn đường thở khi ngủ thường cải thiện đáng kể tình trạng này.
## **Tăng sản lành tính tuyến tiền liệt ở nam giới**
Tăng sản lành tính tuyền tiền liệt là nguyên nhân tiểu đêm rất phổ biến nam giới lớn tuổi, được xem như không phải ung thư mà lành tính; tuyến tiền liệt bao quanh niệu đạo, khi to ra, tuyến này sẽ gây tắc nghẽn dòng chảy. Cùng với đó, thành bàng quang sẽ dày lên và khó làm trống nước tiểu một cách chính xác.
Tăng sản lành tính tuyền tiền liệt là bệnh lý phổ biến nhất ở nam giới trên 50 tuổi. Theo Viện Y tế quốc gia Hoa Kỳ, có khoảng 14 triệu người Mỹ có triệu chứng gợi ý bệnh lý này. Bệnh lý này cũng ảnh hưởng đến một nửa nam giới từ 51 đến 60 tuổi và ảnh hưởng tới 90% nam giới trên 80 tuổi.
Nếu triệu chứng đi tiểu chỉ xảy ra về đêm, nên cân nhắc chứng ngưng thở khi ngủ trước khi nghĩ do phì đại tuyến tiền liệt.
Có nhiều cách điều trị tăng sản lành tính tuyến tiền liệt, bao gồm can thiệp ngoại khoa và điều trị nội khoa. Một số bệnh nhân sống chung với các triệu chứng của bệnh lý tăng sản lành tính tuyến tiền liệt có thể trì hoãn điều trị sau khi khám bác sĩ. Nếu bạn có những triệu chứng nghi ngờ bệnh lý này, bạn nên đến khám và nghe tư vấn từ bác sĩ.
Tìm hiểu thêm: [**Muối và bệnh lý huyết áp**](https://bvnguyentriphuong.com.vn/noi-tim-mach/muoi-va-benh-ly-huyet-ap)
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [Tiểu đêm là tình trạng gì?](https://bvnguyentriphuong.com.vn/than-loc-mau/nhung-nguyen-nhan-pho-bien-gay-tieu-dem#tiu-m-l-tnh-trng-g)
  * [Tăng sản lành tính tuyến tiền liệt ở nam giới](https://bvnguyentriphuong.com.vn/than-loc-mau/nhung-nguyen-nhan-pho-bien-gay-tieu-dem#tng-sn-lnh-tnh-tuyn-tin-lit-nam-gii)



## ️ Chạy thận nhân tạo là gì - chức năng của chạy thận

  * [Chạy thận là gì?](https://bvnguyentriphuong.com.vn/than-loc-mau/chay-than-nhan-tao-la-gi-chuc-nang-cua-chay-than#chy-thn-l-g)
  * [Các dạng lọc máu](https://bvnguyentriphuong.com.vn/than-loc-mau/chay-than-nhan-tao-la-gi-chuc-nang-cua-chay-than#cc-dng-lc-mu)
  * [Chạy thận nhân tạo không liên tục](https://bvnguyentriphuong.com.vn/than-loc-mau/chay-than-nhan-tao-la-gi-chuc-nang-cua-chay-than#chy-thn-nhn-to-khng-lin-tc)
  * [Có hai loại lọc màng bụng chính:](https://bvnguyentriphuong.com.vn/than-loc-mau/chay-than-nhan-tao-la-gi-chuc-nang-cua-chay-than#c-hai-loi-lc-mng-bng-chnh)
  * [Liệu pháp thay thế thận liên tục](https://bvnguyentriphuong.com.vn/than-loc-mau/chay-than-nhan-tao-la-gi-chuc-nang-cua-chay-than#liu-php-thay-th-thn-lin-tc)
  * [Lọc máu tạm thời](https://bvnguyentriphuong.com.vn/than-loc-mau/chay-than-nhan-tao-la-gi-chuc-nang-cua-chay-than#lc-mu-tm-thi)
  * [Nguy cơ và biến chứng bao gồm:](https://bvnguyentriphuong.com.vn/than-loc-mau/chay-than-nhan-tao-la-gi-chuc-nang-cua-chay-than#nguy-c-v-bin-chng-bao-gm)
  * [Liệu lọc máu có thay thế thận?](https://bvnguyentriphuong.com.vn/than-loc-mau/chay-than-nhan-tao-la-gi-chuc-nang-cua-chay-than#liu-lc-mu-c-thay-th-thn)
  * [Triệu chứng suy thận](https://bvnguyentriphuong.com.vn/than-loc-mau/chay-than-nhan-tao-la-gi-chuc-nang-cua-chay-than#triu-chng-suy-thn)


## **Chạy thận là gì?**
Thận của một người khỏe mạnh lọc khoảng **120-150 lít** máu mỗi ngày. Nếu thận không hoạt động hiệu quả, chất thải sẽ tích tụ trong máu. Tình trạng này có thể dẫn đến hôn mê và tử vong.
Nguyên nhân thận hoạt động không hiệu quả có thể do một tình trạng suy giảm chức năng mãn tính hay một vấn đề cấp tính chẳng hạn như chấn thương hoặc bệnh ngắn hạn ảnh hưởng đến chức năng thận.
Lọc máu ngăn việc các chất thải trong máu để ngăn đạt đến mức nguy hiểm. Phương pháp này cũng có thể loại bỏ độc tố hoặc thuốc trong máu trong trường hợp khẩn cấp.
## **Các dạng lọc máu**
Có nhiều dạng lọc máu khác nhau, trong đó 3 phương pháp chính là:
  * Chạy thận nhân tạo không liên tục (IHD);
  * Lọc màng bụng (PD);
  * Liệu pháp thay thế thận liên tục (CRRT).


Lựa chọn sẽ phụ thuộc vào các yếu tố như tình trạng sức khỏe, các phương pháp sẵn có và chi phí của bệnh nhân.
### **Chạy thận nhân tạo không liên tục**
Trong chạy thận nhân tạo, máu lưu thông bên ngoài cơ thể, đi qua một máy với các bộ lọc đặc biệt. Máu từ bệnh nhân được đưa ra ngoài bằng một ống nối phù hợp thông qua đường nối động - tĩnh mạch. Giống như thận, các bộ lọc loại bỏ các chất thải từ máu, máu được lọc sau đó quay trở lại cơ thể thông qua một ống thông khác. Hệ thống hoạt động giống như một quả thận nhân tạo.
Những người sắp chạy thận nhân tạo cần phẫu thuật để mở rộng mạch máu, thường là ở cánh tay. Việc mở rộng tĩnh mạch giúp việc chèn ống thông được dễ dàng hơn.
Chạy thận nhân tạo thường được thực hiện **3** lần một tuần, mỗi lần kéo dài từ **3 đến 4 giờ**. Tùy thuộc vào chức năng thận còn lại và lượng máu, chất thải lọc được qua các lần điều trị.
Chạy thận nhân tạo có thể được thực hiện tại một trung tâm lọc máu đặc biệt trong bệnh viện.
### **Lọc màng bụng**
Trong khi chạy thận nhân tạo loại bỏ tạp chất bằng cách lọc máu, lọc màng bụng hoạt động thông qua khuếch tán. Trong lọc màng bụng, một dung dịch lọc máu vô trùng giàu khoáng chất và glucose được đưa qua một ống vào khoang phúc mạc có màng bán thấm, màng phúc mạc.
Lọc màng bụng sử dụng khả năng lọc tự nhiên của phúc mạc để lọc các chất thải từ máu. Chất lọc được để lại trong khoang màng bụng một thời gian để có thể hấp thụ chất thải. Sau đó được dẫn lưu ra ngoài qua một ống. Quá trình thực hiện này thường được lặp lại nhiều lần trong ngày và có thể được thực hiện qua đêm với một hệ thống tự động.
Việc loại bỏ dịch không mong muốn hoặc siêu lọc, xảy ra thông qua thẩm thấu, dung dịch lọc máu có nồng độ glucose cao gây ra áp suất thẩm thấu. Áp lực làm cho chất lỏng di chuyển từ máu vào chất thẩm tích.
Lọc màng bụng kém hiệu quả hơn thẩm phân máu do phải mất thời gian dài hơn, nhưng vẫn loại bỏ một lượng tổng chất thải, muối và nước tương đương như chạy thận nhân tạo.
Lọc màng bụng giúp bệnh nhân thoải mái hơn do có thể được thực hiện tại nhà thay vì đến các cơ sở y tế nhiều lần mỗi tuần. Trước khi bắt đầu lọc màng bụng, bệnh nhân cần một thủ thuật phẫu thuật nhỏ để đặt ống thông vào bụng.
#### **Có hai loại lọc màng bụng chính:**
  * Lọc màng bụng cấp cứu liên tục (CAPD): không cần máy móc, bệnh nhân hoặc người nhà có thể tự thực hiện. Chất lọc được để trong bụng tối đa 8 giờ và sau đó cần được thay thế bằng một liệu trình mới. Phương pháp này thực hiện mỗi ngày từ 4 đến 5 lần.
  * Lọc màng bụng theo chu kỳ liên tục (CCPD): hoặc lọc màng bụng tự động sử dụng máy để trao đổi chất lỏng thường được thực hiện mỗi đêm trong khi bệnh nhân ngủ. Mỗi phiên kéo dài từ 10 đến 12 giờ. Sau khi thực hiện một liều trình vào ban đêm, hầu hết mọi người đều giữ chất lỏng bên trong bụng vào ban ngày. Một số bệnh nhân có thể cần thực hiện các liệu pháp khác trong ngày.


Lọc màng bụng là một lựa chọn phù hợp cho những bệnh nhân không đủ sức khỏe để chạy thận nhân tạo thường xuyên, chẳng hạn như người già, trẻ sơ sinh và trẻ em. Phương pháp này có thể được thực hiện trong khi đi du lịch, vì vậy thường thuận tiện hơn cho những người hay di chuyển.
### **Liệu pháp thay thế thận liên tục**
Chạy thận có thể gián đoạn hoặc liên tục. Trong khi một phiên lọc máu gián đoạn kéo dài đến 6 giờ, các liệu pháp thay thế thận liên tục (CRRT) được thiết kế để thực hiện 24 giờ tại đơn vị chăm sóc đặc biệt (ICU).
Có nhiều loại CRRT khác nhau có thể liên quan đến lọc hoặc khuếch tán. Phương pháp này được dung nạp tốt hơn so với lọc máu gián đoạn do việc loại bỏ các chất hòa tan hoặc chất lỏng chậm hơn, từ đó ít có biến chứng xảy ra hơn.
## **Lọc máu tạm thời**
Đôi khi lọc máu được thực hiện trong một khoảng thời gian giới hạn. Những đối tượng có thể cần được lọc máu tạm thời bao gồm:
  * Có một tình trạng gây ảnh hưởng chức năng thận đột ngột, hoặc cấp tính;
  * Đã dung nạp các chất độc hại hoặc dùng thuốc quá liều;
  * Bị chấn thương thận;
  * Bị bệnh tim mãn tính.


### **Nguy cơ và biến chứng bao gồm:**
  * Huyết áp thấp;
  * Chuột rút;
  * Buồn nôn và ói mửa;
  * Đau đầu, tức ngực;
  * Đau lưng, ngứa ngáy;
  * Sốt và ớn lạnh.


Trong một số trường hợp, thận phục hồi và không cần điều trị thêm.
### **Liệu lọc máu có thay thế thận?**
Lọc máu có thể giúp bệnh nhân bị suy thận nhưng chắc chắn sẽ không hiệu quả như thận bình thường. Bệnh nhân được lọc máu cần phải chú ý hơn việc ăn uống và cần phải uống thuốc hỗ trợ điều trị. Nhiều người đã lọc máu có thể làm việc, và sinh hoạt bình thường miễn là vẫn thực hiện điều trị lọc máu định kỳ.
Phụ nữ chạy thận thường gặp khó khăn khi mang thai do sẽ có một lượng chất thải trong cơ thể cao hơn so với người có thận bình thường. Điều này gây cản trở khả năng sinh sản. Khi đó phụ nữ có thai có thể sẽ cần lọc máu nhiều lần hơn trong thai kỳ. Nếu được ghép thận thành công, khả năng sinh sản sẽ trở lại bình thường. Lọc máu có một số ảnh hưởng đến khả năng sinh sản của nam giới, nhưng ít hơn so với nữ giới.
## **Triệu chứng suy thận**
Suy thận mãn tính xảy ra dần dần. Ngay cả khi chỉ một bên thận hoạt động, hay cả hai thận chỉ hoạt động một phần, vẫn có thể thực hiện chức năng thận bình thường. Tình trạng này có thể diễn ra trong một thời gian dài trước khi các triệu chứng của tình trạng suy thận xuất hiện.
Các triệu chứng suy thận biểu hiện khác nhau ở mỗi người khiến cho việc chẩn đoán suy thận sớm trở nên khó khăn hơn. Các triệu chứng của suy thận có thể bao gồm:
  * Mệt mỏi, khó thở, buồn nôn;
  * Nhu cầu đi tiểu ngày càng thường xuyên, đặc biệt là vào ban đêm;
  * Da ngứa;
  * Rối loạn cương dương;
  * Cơ thể giữ nước, dẫn đến sưng chân, tay và mắt cá chân;
  * Máu trong nước tiểu;
  * Protein trong nước tiểu.


Chấn thương bất ngờ có thể gây suy thận. Khi đó, các triệu chứng có xu hướng xuất hiện và tiến triển nhanh hơn.
Thiếu máu thường gặp ở những người mắc bệnh thận mãn tính xảy ra khi mức độ **erythropoietin (EPO)** thấp. EPO là một sản phẩm của thận giúp cơ thể sản xuất các tế bào hồng cầu.
## **Phản ứng phụ**
Những bệnh nhân lọc máu có thể gặp các triệu chứng như:
  * Chuột rút cơ bắp;
  * Ngứa da;
  * Huyết áp thấp, đặc biệt ở những người mắc bệnh tiểu đường;
  * Vấn đề về giấc ngủ, đôi khi do ngứa, tê chân hoặc do vấn đề hô hấp (ngưng thở khi ngủ);
  * Quá tải dịch lỏng vì vậy bệnh nhân phải dung nạp một lượng chất lỏng cố định mỗi ngày;
  * Nhiễm trùng hoặc phồng rộp tại vùng can thiệp để lọc máu;
  * Trầm cảm và rối loạn tâm trạng.


Suy thận là một tình trạng bệnh lý nghiêm trọng. Ở những người bị suy thận mãn tính, thận không có khả năng phục hồi, lọc máu có thể cải thiện tình trạng sức khỏe và kéo dài tuổi thọ lên đến 20 năm hoặc hơn.
Tìm hiểu về [**biến chứng có thể gặp trong chạy thận nhân tạo**](https://bvnguyentriphuong.com.vn/than-loc-mau/bien-chung-hay-gap-trong-chay-than-nhan-tao)
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh
[youtube.com/bvntp](http://youtube.com/bvntp)
  * [Chạy thận là gì?](https://bvnguyentriphuong.com.vn/than-loc-mau/chay-than-nhan-tao-la-gi-chuc-nang-cua-chay-than#chy-thn-l-g)
  * [Các dạng lọc máu](https://bvnguyentriphuong.com.vn/than-loc-mau/chay-than-nhan-tao-la-gi-chuc-nang-cua-chay-than#cc-dng-lc-mu)
  * [Chạy thận nhân tạo không liên tục](https://bvnguyentriphuong.com.vn/than-loc-mau/chay-than-nhan-tao-la-gi-chuc-nang-cua-chay-than#chy-thn-nhn-to-khng-lin-tc)
  * [Có hai loại lọc màng bụng chính:](https://bvnguyentriphuong.com.vn/than-loc-mau/chay-than-nhan-tao-la-gi-chuc-nang-cua-chay-than#c-hai-loi-lc-mng-bng-chnh)
  * [Liệu pháp thay thế thận liên tục](https://bvnguyentriphuong.com.vn/than-loc-mau/chay-than-nhan-tao-la-gi-chuc-nang-cua-chay-than#liu-php-thay-th-thn-lin-tc)
  * [Lọc máu tạm thời](https://bvnguyentriphuong.com.vn/than-loc-mau/chay-than-nhan-tao-la-gi-chuc-nang-cua-chay-than#lc-mu-tm-thi)
  * [Nguy cơ và biến chứng bao gồm:](https://bvnguyentriphuong.com.vn/than-loc-mau/chay-than-nhan-tao-la-gi-chuc-nang-cua-chay-than#nguy-c-v-bin-chng-bao-gm)
  * [Liệu lọc máu có thay thế thận?](https://bvnguyentriphuong.com.vn/than-loc-mau/chay-than-nhan-tao-la-gi-chuc-nang-cua-chay-than#liu-lc-mu-c-thay-th-thn)
  * [Triệu chứng suy thận](https://bvnguyentriphuong.com.vn/than-loc-mau/chay-than-nhan-tao-la-gi-chuc-nang-cua-chay-than#triu-chng-suy-thn)



## ️ Làm sao để bảo vệ chức năng thận

  * [Hoạt động thể lực phù hợp](https://bvnguyentriphuong.com.vn/than-loc-mau/lam-sao-de-bao-ve-chuc-nang-than#hot-ng-th-lc-ph-hp)
  * [Kiểm soát tốt đường huyết](https://bvnguyentriphuong.com.vn/than-loc-mau/lam-sao-de-bao-ve-chuc-nang-than#kim-sot-tt-ng-huyt)
  * [Theo dõi huyết áp](https://bvnguyentriphuong.com.vn/than-loc-mau/lam-sao-de-bao-ve-chuc-nang-than#theo-di-huyt-p)
  * [Chế độ ăn phù hợp và kiểm soát cân nặng](https://bvnguyentriphuong.com.vn/than-loc-mau/lam-sao-de-bao-ve-chuc-nang-than#ch-n-ph-hp-v-kim-sot-cn-nng)
  * [Uống lượng nước thích hợp](https://bvnguyentriphuong.com.vn/than-loc-mau/lam-sao-de-bao-ve-chuc-nang-than#ung-lng-nc-thch-hp)
  * [Không hút thuốc lá](https://bvnguyentriphuong.com.vn/than-loc-mau/lam-sao-de-bao-ve-chuc-nang-than#khng-ht-thuc-l)
  * [Dùng thuốc theo đúng chỉ định bác sĩ](https://bvnguyentriphuong.com.vn/than-loc-mau/lam-sao-de-bao-ve-chuc-nang-than#dng-thuc-theo-ng-ch-nh-bc-s)
  * [Kiểm tra chức năng thận nếu có yếu tố nguy cơ](https://bvnguyentriphuong.com.vn/than-loc-mau/lam-sao-de-bao-ve-chuc-nang-than#kim-tra-chc-nng-thn-nu-c-yu-t-nguy-c)


Thận là một cơ quan rất quan trọng của cơ thể. Thận thực hiện các chức năng :
  * Ổn định thể dịch, điện giải và kiềm toan: Đây là chức năng quan trọng nhất. Măc dù lượng nước và điện giải nhập vào cơ thể thay đổi nhưng nhờ sự bài tiết nước tiểu của thận giúp giữ vững nước và chất điện giải như K+, Na+ , H+...
  * Bài tiết các chất dư thừa từ sự chuyển hóa của cơ thể. Các chất nội sinh từ sự chuyển hóa của cơ thể gồm sản phẩm có chứa Nitơ ( Ure, Creatinine) và các Acid hữu cơ, ngoài ra Thận còn giúp loại thải các chất ngoại sinh được đưa vào cơ thể như dược chất.
  * Bài tiết Hormon giúp điều hòa huyết áp( Renin), sản xuất hồng cầu( Erythropoietin) và khoáng chất và xương( Hoạt hóa Vitamin D thành 1,25-diOH cholecalciferol)


Ngày nay, các bệnh về thận ngày càng tăng nhiều, theo bệnh viện Bạch Mai tại buổi lễ kỷ niệm “Ngày Thận Thế giới” (12/3/2015), hiện nay có tới 6.73% dân số Việt Nam mắc bệnh thận, trong đó, những bệnh nhân suy thận giai đoạn cuối cần lọc máu chiếm 0.09% dân số, và chỉ 10% trong số đó được lọc máu, 90% đều tử vong. Cũng theo thống kê của Hội Thận học Thế giới , trên thế giới có hơn 500 triệu người đang có vấn đề bệnh lý mãn tính ở thận. Nguyên nhân chủ yếu là do các bệnh lý tại thận, tăng huyết áp và đái tháo đường.
Những người mắc bệnh thận mạn tính sẽ tiến triển dẫn đến suy thận mạn tính, làm mất chức năng thận và phải dùng các biện pháp điều trị thay thế thận như lọc máu, ghép thận. Trong khi đó, đây là bệnh có thể kiểm soát được nếu như người bệnh phát hiện bệnh sớm và điều trị đúng.
Muốn phòng ngừa, kiểm soát và làm chậm diễn tiến bệnh thận , cần tuân thủ tốt các bước sau :
## **Hoạt động thể lực phù hợp**
Thiếu hoạt động thể chất là nguyên nhân gốc rễ của nhiều loại bệnh liên quan đến lối sống. Điều này khiến bạn dễ bị cao huyết áp, bệnh tim, béo phì và thậm chí cả bệnh tiểu đường.
Những bệnh nhân tiền tiểu đường, người có nguy cơ bị biến chứng vì tiểu đường, có thể kiểm soát lượng đường trong máu của họ bằng cách tập thể dục 30 phút/ngày.
Tập thể dục cũng giúp kiểm soát cholesterol, huyết áp và cân nặng của bạn. Thừa cân làm tăng nguy cơ phát triển bệnh tiểu đường và huyết áp cao, đó cũng là những yếu tố nguy cơ chính đối với bệnh thận.
## **Kiểm soát tốt đường huyết**
Luôn giữ đường huyết ổn định trong giới hạn cho phép (< 7mmol/l lúc đói và< 10mmol/l sau ăn 2h).
Bệnh tiểu đường làm tổn thương, ảnh hưởng đến chức năng hoạt động của thận và là nguyên nhân chính gây suy thận. Bị đái tháo đường có nghĩa là đường trong máu cao. Khi đó, thận phải làm việc vất vả hơn để lọc máu. Theo năm tháng, do tăng cường làm việc quá nhiều, thận sẽ bị tổn thương gây rò rỉ một lượng nhỏ protein vào trong nước tiểu. Tổn thương ngày một nặng dần và rò rỉ nhiều protein hơn vào nước tiểu. Lúc này, huyết áp sẽ có chiều hướng tăng dần, các chất thải cũng tích tụ dần trong máu. Nếu không điều trị, chức năng hoạt động của thận sẽ bị suy yếu. Một khi thận bị suy hoàn toàn thì người bệnh cần phải lọc máu qua máy (chạy thận nhân tạo) hoặc ghép thận. 
Biến chứng thận hoàn toàn có thể phòng ngừa được bằng cách kiểm soát tốt đường huyết và các yếu tố nguy cơ. Kiểm soát tốt đường huyết có thể làm giảm đến 1/3 nguy cơ xuất hiện protein niệu vi thể và giảm 1/2 nguy cơ tiến triển từ protein niệu vi thể thành protein niệu đại thể.
## **Theo dõi huyết áp**
Giữ Huyết áp ≤ 120/80mmHg. Huyết áp cao không chỉ làm tăng nguy cơ bị đột quỵ và bệnh tim mạch, huyết áp cao cũng làm tăng nguy cơ mắc bệnh thận. Nếu gia đình có tiền sử mắc bệnh cao huyết áp và bệnh thận, hãy kiểm tra huyết áp thường xuyên. Bạn nên thực hiện một cuộc sống lành mạnh, duy trì mức độ cholesterol ổn định.
Bốn cách đơn giản để hạ HA phải thực hiện đồng thời là: giảm cân (nếu có thừa cân); ăn nhạt, bỏ rượu, thuốc lá và tập thể dục đều đặn. Nếu các biện pháp này không có hiệu quả thì cần dùng các thuốc hạ HA sớm. Một nghiên cứu trên các bệnh nhân đã có biến chứng thận trong 16 năm cho thấy điều trị kiểm soát tốt HA có thể làm giảm tỉ lệ bệnh nhân bị suy thận giai đoạn cuối từ 73% xuống 31%.
## **Chế độ ăn phù hợp và kiểm soát cân nặng**
Không uống nhiều rượu và nên ăn các thức ăn có lợi như ít muối, ít chất béo, ăn nhiều cá, rau quả. Một số loại thức ăn ít muối như thực phẩm tươi, trái cây, củ hành, tiêu, chanh, gừng...
## **Uống lượng nước thích hợp**
Uống nhiều nước giúp thận làm sạch natri, urê và độc tố khác từ cơ thể một cách lành mạnh. Nước sẽ giúp cho 2 quả thận và toàn bộ cơ thể bạn khỏe mạnh. Nước có nhiệm vụ pha loãng nước tiểu, nhờ đó cũng giảm tải cho thận khi phải bài tiết. Nước tiểu được bài tiết nhanh chóng còn giúp ngăn ngừa hình thành sỏi.
## **Không hút thuốc lá**
Hút thuốc làm tăng huyết áp, thuốc lá cũng làm lắng đọng cholesterol trong các mạch máu lớn, giảm lượng máu cung cấp cho thận. Điều này có nghĩa là nồng độ oxy trong thận giảm, gây ra tình trạng thiếu oxy, làm giảm bớt khả năng hoạt động tối ưu của thận.
## **Dùng thuốc theo đúng chỉ định bác sĩ**
Không nên lạm dụng thuốc bừa bãi, nhất là thuốc nam, thuốc bắc vì trong thuốc nam, thuốc bắc có chứa Kali và các chất độc thận khác sẽ làm bệnh thận càng nặng hơn, khó kiểm soát và nguy hiểm tính mạng.
Nếu bị bệnh, bị đau khớp hay các bệnh gây đau khác cần phải uống thuốc, bạn nên đi khám bác sĩ và uống thuốc theo chỉ định, liều lượng của bác sĩ kê đơn.
## **Kiểm tra chức năng thận nếu có yếu tố nguy cơ**
Người cao tuổi, bị tiểu đường, tăng huyết áp hoặc gia đình có người bị bệnh thận là những yếu tố dễ bị suy thận. Khám bác sĩ chuyên khoa thận học định kỳ 6 tháng hoặc 1 năm. Khi khám thận cần chú ý kiểm tra huyết áp, nước tiểu, xét nghiệm máu. Nếu người thân, có thể là bố hoặc mẹ có tiền sử mắc bệnh về thận, bạn nên đi kiểm tra sức khỏe và thực hiện các xét nghiệm để có cách phòng ngừa.
_Các biểu hiện của bệnh thận thường âm thầm và không rõ rệt_ _thường gặp là mất cảm giác ngon miệng, choáng váng và nôn. Mệt mỏi, khó tập trung, giảm trí nhớ và mất ngủ... có thể do thiếu máu, do chức năng thận suy giảm nên không loại bỏ được các chất độc.Có vị tanh trong miệng hoặc hơi thở hôi, choáng váng, buồn nôn, mất cảm giác ngon miệng, sợ ăn thịt, khó tập trung, bị ngứa.Phù ở mặt, chân hoặc tay, khó thở, hụt hơi.Đi tiểu nhiều hoặc ít hơn bình thường, nước tiểu có bọt hoặc bong bóng, đi tiểu ra máu.Thiếu máu: mệt mỏi, yếu sức, luôn thấy lạnh, khó thở, lú lẫn...Ngoài ra còn nhiều dấu hiệu xuất hiện ở bệnh nhân suy thận như: ngứa ngoài da, có thể là do hàm lượng phospho và canxi trong máu cao. Khi bạn có các biểu hiện nói trên cần đi khám bác sĩ chuyên khoa thận ngay để tầm soát, điều trị và kiểm soát để làm chậm diễn tiến bệnh thận._
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [Hoạt động thể lực phù hợp](https://bvnguyentriphuong.com.vn/than-loc-mau/lam-sao-de-bao-ve-chuc-nang-than#hot-ng-th-lc-ph-hp)
  * [Kiểm soát tốt đường huyết](https://bvnguyentriphuong.com.vn/than-loc-mau/lam-sao-de-bao-ve-chuc-nang-than#kim-sot-tt-ng-huyt)
  * [Theo dõi huyết áp](https://bvnguyentriphuong.com.vn/than-loc-mau/lam-sao-de-bao-ve-chuc-nang-than#theo-di-huyt-p)
  * [Chế độ ăn phù hợp và kiểm soát cân nặng](https://bvnguyentriphuong.com.vn/than-loc-mau/lam-sao-de-bao-ve-chuc-nang-than#ch-n-ph-hp-v-kim-sot-cn-nng)
  * [Uống lượng nước thích hợp](https://bvnguyentriphuong.com.vn/than-loc-mau/lam-sao-de-bao-ve-chuc-nang-than#ung-lng-nc-thch-hp)
  * [Không hút thuốc lá](https://bvnguyentriphuong.com.vn/than-loc-mau/lam-sao-de-bao-ve-chuc-nang-than#khng-ht-thuc-l)
  * [Dùng thuốc theo đúng chỉ định bác sĩ](https://bvnguyentriphuong.com.vn/than-loc-mau/lam-sao-de-bao-ve-chuc-nang-than#dng-thuc-theo-ng-ch-nh-bc-s)
  * [Kiểm tra chức năng thận nếu có yếu tố nguy cơ](https://bvnguyentriphuong.com.vn/than-loc-mau/lam-sao-de-bao-ve-chuc-nang-than#kim-tra-chc-nng-thn-nu-c-yu-t-nguy-c)



## ️ Điều trị thay thế bệnh thận mạn giai đoạn cuối

  * [1. Lọc màng bụng](https://bvnguyentriphuong.com.vn/than-loc-mau/dieu-tri-thay-the-benh-than-man-giai-doan-cuoi#1-lc-mng-bng)
  * [2.Thận nhân tạo](https://bvnguyentriphuong.com.vn/than-loc-mau/dieu-tri-thay-the-benh-than-man-giai-doan-cuoi#2thn-nhn-to)
  * [Biến chứng ghép thận:](https://bvnguyentriphuong.com.vn/than-loc-mau/dieu-tri-thay-the-benh-than-man-giai-doan-cuoi#bin-chng-ghp-thn)


Xem lại: [**Tổng quan về suy thận mạn**](https://bvnguyentriphuong.com.vn/noi-than-tiet-nieu/benh-than-man-nguyen-nhan-chan-doan-dieu-tri-va-phong-ngua)
## **1. Lọc màng bụng**
Chỉ định:
  * Suy thận cấp
  * Suy thận mạn
  * Ngộ độc cấp đặc biệt là do Barbiturat


Chống chỉ định:
  * Viêm phúc mạc có dính
  * Chấn thương chảy máu ổ bụng
  * Sẹo mổ cũ vùng bụng ảnh hưởng nhiều đến phúc mạc
  * Bệnh thận đa nang, thận quá
  * Tình trạng thần kinh không tỉnh táo
  * Suy tim suy hô hấp nặng


## **2.Thận nhân tạo**
Dùng máy thận nhân tạo và màng lọc nhân tạo cùng các dụng cụ tiêu hao đi kèm để lọc bớt nước và các sản phẩm chuyển hoá từ trong máu ra ngoài cơ thể
Vai trò của thận nhân tạo: Điều trị thay thế thận mục đích:
  * Thăng bằng nước
  * Thăng bằng điện giải
  * Thăng bằng acid base
  * Lấy bỏ chất cần thải (ure, creatinine)
  * Lọc, tái hấp thu và bài tiết các chất


Có thể bạn quan tâm: [**BS tư vấn về thận nhân tạo**](https://www.youtube.com/watch?v=d88bIEYH87g&list=PLiU0n83wV1FDH-NqJwbiEKybC0PS2uRN6&index=1)
## **3. Ghép thận**
  * Ghép thận của người sống cùng huyết thống như bố mẹ, anh chị em ruột, họ hàng cho người bệnh một thận
  * Ghép thận của người sống không có cùng huyết thống
  * Ghép thận của người đã chết não
  * Tất cả các kiểu ghép thận trên đều cần điều trị bằng thuốc ức chế miễn dịch lâu dài để chống thải ghép


### **Biến chứng ghép thận:**
  * Miễn dịch: Thải ghép tối cấp- Thải ghép cấp- Thải ghép cấp- Thải ghép mạn
  * Phẫu thuật: Nhiễm trùng vết mổ, rò nước tiểu, bế tắc niệu quản. Nang bạch huyết, trào ngược niệu quản, bế tắc niệu quản, sỏi niệu, xơ hóa hay hẹp động mạch thận, …
  * Nội khoa: Suy thận, hoại tử ống thận cấp, thải ghép cấp, …- Suy thận tiến triển, hội chứng thận hư, thải ghép cấp, viêm bể thận, tăng huyết áp, xơ vữa động mạch, bệnh hồng cầu, …


Xem thêm: [**Xét nghiệm bệnh thận mạn**](https://bvnguyentriphuong.com.vn/noi-than-tiet-nieu/xet-nghiem-benh-than-man)
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [1. Lọc màng bụng](https://bvnguyentriphuong.com.vn/than-loc-mau/dieu-tri-thay-the-benh-than-man-giai-doan-cuoi#1-lc-mng-bng)
  * [2.Thận nhân tạo](https://bvnguyentriphuong.com.vn/than-loc-mau/dieu-tri-thay-the-benh-than-man-giai-doan-cuoi#2thn-nhn-to)
  * [Biến chứng ghép thận:](https://bvnguyentriphuong.com.vn/than-loc-mau/dieu-tri-thay-the-benh-than-man-giai-doan-cuoi#bin-chng-ghp-thn)



## ️ Đái ra máu

  * [a) Chẩn đoán xác định](https://bvnguyentriphuong.com.vn/than-loc-mau/dai-ra-mau#a-chn-on-xc-nh)
  * [b) Chẩn đoán phân biệt](https://bvnguyentriphuong.com.vn/than-loc-mau/dai-ra-mau#b-chn-on-phn-bit)
  * [c) Chẩn đoán nguyên nhân đái máu](https://bvnguyentriphuong.com.vn/than-loc-mau/dai-ra-mau#c-chn-on-nguyn-nhn-i-mu)
  * [Các thăm dò chuyên sâu có thể thực hiện:](https://bvnguyentriphuong.com.vn/than-loc-mau/dai-ra-mau#cc-thm-d-chuyn-su-c-th-thc-hin)
  * [Điều trị triệu chứng:](https://bvnguyentriphuong.com.vn/than-loc-mau/dai-ra-mau#iu-tr-triu-chng)
  * [Điều trị nguyên nhân](https://bvnguyentriphuong.com.vn/than-loc-mau/dai-ra-mau#iu-tr-nguyn-nhn)


## **1. Định nghĩa**
Đái máu là tình trạng nước tiểu có máu. Có đái máu đại thể và đái máu vi thể.
  * Đái máu đại thể: khi nước tiểu đỏ sẫm màu, nhận biết được bằng mắt thường.
  * Đái máu vi thể: mắt thường không nhận thấy, chỉ phát hiện được khi làm xét nghiệm tế bào học nước tiểu với số lượng hồng cầu > 10.000 hồng cầu/ml.


​​​​​​​
## **2. Chẩn đoán**
### **a) Chẩn đoán xác định**
Có hồng cầu trong nước tiểu ở các mức độ khác nhau (vi thể hoặc đại thể). Có thể phát hiện nước tiểu có máu bằng mắt thường hoặc có thể phát hiện hồng cầu niệu vi thể bằng xét nghiệm tổng phân tích nước tiểu hoặc xét nghiệm tế bào niệu.
Triệu chứng lâm sàng: tùy theo nguyên nhân gây đái máu sẽ có triệu chứng lâm sàng tương ứng
  * Đái máu đại thể hoặc vi thể,
  * Có thể kèm theo tiểu buốt, dắt, khó, ngắt quãng, bí tiểu,
  * Có thể có sốt có hoặc không rét run
  * Có thể cơn đau quặn thận, đau hố thắt lưng 1 hoặc 2 bên,
  * Có thể đau tức, nóng rát vùng bàng quang


Cận lâm sàng:
Xét nghiệm nước tiểu để khẳng định đái máu: có hồng cầu niệu ở các mức độ
Để tìm nguyên nhân đái máu cần làm thêm một số thăm dò, tùy thuộc lâm sàng:
  * Tế bào niệu: tìm tế bào ác tính
  * Cấy vi khuẩn
  * Siêu âm hệ thận – tiết niệu
  * Chụp bụng không chuẩn bị
  * Protein niệu 24h
  * Soi bàng quang, có thể tiến hành trong giai đoạn đang đái máu.
  * Chụp bể thận ngược dòng
  * Chụp cắt lớp vi tính
  * Chụp mạch
  * Định lượng các Ig
  * Sinh thiết thận: hiển vi quang học và miễn dịch huỳnh quang


### **b) Chẩn đoán phân biệt**
Nước tiểu đỏ không do đái máu do:
  * Một số thức ăn
  * Một số thuốc (rifampicine, metronidazole…)


Chảy máu niệu đạo: chảy máu từ niệu đạo không phụ thuộc vào các lần đi tiểu tiện.
Nước tiểu lẫn máu: ở phụ nữ đang có kinh nguyệt
Myoglobine niệu khi có tiêu cơ
Hemoglobine niệu khi có tan máu trong lòng mạch, porphyline niệu (nước tiểu đỏ sẫm không có máu cục). Cần xét nghiệm tế bào học để khẳng định có đái máu.
### **c) Chẩn đoán nguyên nhân đái máu**
Các nguyên nhân có thể gây đái máu:
Đái máu do nguyên nhân tiết niệu: trước hết phải cảnh giác với khối u thận tiết niệu gây ra đái máu.
  * Đái máu do sỏi thận, tiết niệu:
  * Đái máu do khối u:
    * Khối u nhu mô thận
    * U biểu mô tiết niệu
    * U bàng quang
    * U tuyến tiền liệt
  * Đái máu do nhiễm trùng tiết niệu
  * Đái máu do chấn thương:
    * Chấn thương vùng thắt lưng
    * Chấn thương vùng hạ vị
    * Chấn thương niệu đạo


Đái máu do nguyên nhân thận:
  * Viêm cầu thận:
    * Viêm cầu thận cấp:
    * Viêm cầu thận mạn:
  * Viêm kẽ thận


Đái máu do các nguyên nhân hiếm gặp:
  * Nghẽn, tắc mạch thận (động mạch và tĩnh mạch)
  * Tắc tĩnh mạch chủ
  * Sán máng


### **Các thăm dò chuyên sâu có thể thực hiện:**
  * Nội soi bàng quang: tiến hành khi đang có đái máu
  * Chụp bể thận ngược dòng, chụp cắt lớp vi tính, chụp mạch: khi có đái máu từ 1 bên niệu quản cần tiến hành để tìm kiếm khối u thận kích thước nhỏ hoặc dị dạng mạch máu.
  * Sinh thiết thận : khi có đái máu từ 2 bên niệu quản ở bệnh nhân trẻ tuổi nghĩ nhiều đến bệnh thận IgA.


## **3. Điều trị**
### **Điều trị triệu chứng:**
Nội khoa:
  * Thuốc cầm máu: Transamin đường uống hoặc truyền tĩnh mạch
  * Truyền máu nếu mất nhiều máu
  * Kháng sinh nếu có dấu hiệu nhiễm trùng: Sulfamid, Quinolone, có thể phối hợp với nhóm khác tùy theo diễn biến lâm sang và kết quả cấy vi khuẩn máu và nước tiểu.
  * Tùy thuộc vào nguyên nhân gây đái máu cần phối hợp thêm thuốc khác


Ngoại khoa:
Trong một số trường hợp nếu có tắc nghẽn nhiều đường tiết niệu do máu cục tạo thành, cần can thiệp ngoại khoa tạm thời dẫn lưu, lấy máu cục tai bang quang, trước khi giải quyết nguyên nhân.
### **Điều trị nguyên nhân**
Can thiệp ngoại khoa tùy vào nguyên nhân đái máu và tình trạng lâm sàng cụ thể của bệnh nhân.
## **4. Phòng bệnh**
Nên khám và kiểm tra định kỳ để phát hiện bệnh sớm và điều trị kịp thời
Xem thêm: [**Sỏi thận - Tiết niệu**](https://bvnguyentriphuong.com.vn/ngoai-than-tiet-nieu/soi-than-tiet-nieu)
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh
[facebook.com/BVNTP](http://facebook.com/BVNTP)
[youtube.com/bvntp](http://youtube.com/bvntp)
  * [a) Chẩn đoán xác định](https://bvnguyentriphuong.com.vn/than-loc-mau/dai-ra-mau#a-chn-on-xc-nh)
  * [b) Chẩn đoán phân biệt](https://bvnguyentriphuong.com.vn/than-loc-mau/dai-ra-mau#b-chn-on-phn-bit)
  * [c) Chẩn đoán nguyên nhân đái máu](https://bvnguyentriphuong.com.vn/than-loc-mau/dai-ra-mau#c-chn-on-nguyn-nhn-i-mu)
  * [Các thăm dò chuyên sâu có thể thực hiện:](https://bvnguyentriphuong.com.vn/than-loc-mau/dai-ra-mau#cc-thm-d-chuyn-su-c-th-thc-hin)
  * [Điều trị triệu chứng:](https://bvnguyentriphuong.com.vn/than-loc-mau/dai-ra-mau#iu-tr-triu-chng)
  * [Điều trị nguyên nhân](https://bvnguyentriphuong.com.vn/than-loc-mau/dai-ra-mau#iu-tr-nguyn-nhn)



## ️ Hướng dẫn bổ sung tạm thời về khuyến cáo phòng ngừa và kiểm soát nhiễm khuẩn đối với bệnh nhân nghi ngờ hoặc xác định nhiễm Covid-19 tại các cơ sở chạy thận nhân tạo ngoại trú

  * [Nhận biết sớm và cách ly những cá nhân nhiễm trùng đường hô hấp:](https://bvnguyentriphuong.com.vn/than-loc-mau/huong-dan-bo-sung-tam-thoi-ve-khuyen-cao-phong-ngua-va-kiem-soat-nhiem-khuan-doi-voi-benh-nhan-nghi-ngo-hoac-xac-dinh-nhiem-covid-19-tai-cac-co-so-chay-than-nhan-tao-ngoai-tru#nhn-bit-sm-v-cch-ly-nhng-c-nhn-nhim-trng-ng-h-hp)
  * [Khi tại cơ sở có bệnh nhân chạy thận nhân tạo nghi ngờ hoặc xác định nhiễm COVID-19, áp dụng các biện pháp bổ sung sau:](https://bvnguyentriphuong.com.vn/than-loc-mau/huong-dan-bo-sung-tam-thoi-ve-khuyen-cao-phong-ngua-va-kiem-soat-nhiem-khuan-doi-voi-benh-nhan-nghi-ngo-hoac-xac-dinh-nhiem-covid-19-tai-cac-co-so-chay-than-nhan-tao-ngoai-tru#khi-ti-c-s-c-bnh-nhn-chy-thn-nhn-to-nghi-ng-hoc-xc-nh-nhim-covid19-p-dng-cc-bin-php-b-sung-sau)


## **Các khuyến cáo**
Một phần của kiểm soát nhiễm khuẩn thường quy, các cơ sở chạy thận nhân tạo ngoại trú nên thiết lập các chính sách và thực hành để giảm sự lây lan của các tác nhân gây bệnh lây truyền qua đường hô hấp. Điêu này bao gôm:
### **Nhận biết sớm và cách ly những cá nhân nhiễm trùng đường hô hấp:**
  * Các cơ sở nên thực hiện các chính sách nghỉ ốm không trừng phạt, linh hoạt và phù hợp với các chính sách y tế công cộng cho phép nhân viên y tế (NVYT) bị bệnh ở nhà. NVYT nên được nhắc nhở không đi làm khi họ bị bệnh.
  * Các cơ sở nên xác định những bệnh nhân có dấu hiệu và triệu chứng nhiễm trùng đường hô hấp (ví dụ, sốt, ho) trước khi họ vào khu vực điều trị.


  * Hướng dẫn bệnh nhân gọi điện trước báo cáo các triệu chứng hô hấp hoặc sốt để cơ sở có thể chuẩn bị cho việc họ đến hoặc đưa họ đến một cơ sở thích hợp hơn (ví dụ: bệnh viện chăm sóc cấp tính).
  * Bệnh nhân nên thông báo cho nhân viên về các triệu chứng hô hấp hoặc sốt ngay khi đến cơ sở (ví dụ: khi họ đăng ký tại bàn đăng ký).
  * Những bệnh nhân có triệu chứng nhiễm trùng đường hô hấp nên đeo khẩu trang khi đến nơi đăng ký và tiếp tục đeo cho đến khi họ rời khỏi bệnh viện.


  * Các cơ sở nên cung cấp cho bệnh nhân và NVYT các hướng dẫn (bằng ngôn ngữ phù hợp) về vệ sinh tay, vệ sinh hô hấp và quy tắc ho/_che miệng khi ho_.


  * Các hướng dẫn bao gồm cách sử dụng khẩu trang, cách sử dụng khăn giấy che mũi và miệng khi ho hoặc hắt hơi, cách bỏ khăn giấy và những vật dụng ô nhiễm vào thùng đựng chất thải, cách thức và thời điểm thực hiện vệ sinh tay.
  * Dán các dấu hiệu bệnh tại lối vào phòng khám kèm các hướng dẫn dành cho bệnh nhân có triệu chứng nhiễm trùng đường hô hấp hoặc sốt nhằm cảnh báo cho nhân viên thực hiện các biện pháp phòng ngừa thích hợp.
  * Các cơ sở nên có vật tư được đặt gần ghế lọc máu và những vị trí chăm sóc bệnh nhân để đảm bảo tuân thủ vệ sinh tay và hô hấp, và quy tắc ho. Chúng bao gồm khăn giấy và các thùng chứa không chạm để đựng giấy đã sử dụng và chất vệ sinh tay (ví dụ: chất khử trùng tay chứa cồn).
  * **Bố trí bệnh nhân** : Các cơ sở nên có không gian ở khu vực chờ để bệnh nhân bị bệnh ngồi riêng biệt với bệnh nhân khác ít nhất 6 feet (khoảng 1,8m). Những bệnh nhân có tình trạng sức khỏe ổn định có thể chọn chờ trong xe cá nhân hoặc bên ngoài cơ sở chăm sóc sức khỏe nơi họ có thể liên lạc bằng điện thoại di động khi đến lượt của họ.
  * Những bệnh nhân có triệu chứng hô hấp nên được đưa trở lại khu vực điều trị thích hợp càng sớm càng tốt để giảm thời gian ở khu vực chờ.
  * Các cơ sở nên duy trì khoảng cách ít nhất 6 feet (khoảng 1,8m) giữa những bệnh nhân có triệu chứng được đeo khẩu trang, và những bệnh nhân khác trong suốt thời gian lọc máu. Lý tưởng nhất, bệnh nhân có triệu chứng sẽ được thẩm tách trong một phòng riêng với cửa đóng (nếu có).


Những phòng cách ly viêm gan B chỉ được sử dụng cho bệnh nhân chạy thận có triệu chứng nhiễm trùng đường hô hấp nếu: 1) bệnh nhân có kháng nguyên bề mặt viêm gan B dương tính hoặc 2) cơ sở đã được kiểm tra không có bệnh nhân nhiễm viêm gan B cần điều trị trong phòng cách ly.
  * Nếu phòng riêng không có sẵn, bệnh nhân nên được đeo khẩu trang và nằm điều trị tại góc hoặc vị trí cuối dãy, cách xa lối đi lại chính (nếu có). Bệnh nhân nên nằm cách xa ít nhất 6 feet (khoảng 1,8m) với bệnh nhân gần nhất (theo mọi hướng).
  * Nếu bệnh nhân không thể chịu được khẩu trang, họ nên được cách nhau ít nhất 6 feet (khoảng 1,8m) với vị trí bệnh nhân gần nhất (theo mọi hướng).
  * **Thiết bị bảo hộ cá nhân:** Nói chung, NVYT chăm sóc bệnh nhân bị nhiễm trùng đường hô hấp chưa được chẩn đoán nên tuân thủ các biện pháp phòng ngừa Chuẩn, Tiếp xúc và Giọt bắn với bảo vệ mắt trừ khi chẩn đoán sơ bộ yêu cầu các biện pháp phòng ngừa bệnh lây qua không khí (ví dụ, bệnh lao). Điều này bao gồm việc sử dụng:
  * Găng tay
  * Khẩu trang
  * Bảo vệ mắt (ví dụ: kính bảo hộ, tấm chắn mặt dùng một lần che phía trước và hai bên mặt). Kính cá nhân và kính áp tròng KHÔNG đủ để bảo vệ mắt.
  * Áo choàng cách ly
    * Áo choàng cách ly nên được mặc trùm lên hoặc thay bằng áo choàng phủ (ví dụ, áo khoác phòng thí nghiệm, áo choàng hoặc tạp dề có tay áo dính liền) thường được nhân viên chạy thận nhân tạo mặc. Nếu thiếu áo choàng, chúng nên được ưu tiên khi bắt đầu và kết thúc phiên lọc máu, khi thao tác đâm kim hoặc catheter, khi giúp bệnh nhân vào và ra khỏi vị trí, và khi làm sạch và khử trùng thiết bị chăm sóc bệnh nhân và khu vực lọc máu.
    * Khi cởi áo choàng ra, đặt vào thùng chứa chuyên dụng để đựng chất thải hoặc vải lanh trước khi rời khu lọc máu. Áo choàng dùng một lần nên được loại bỏ sau khi sử dụng. Áo vải nên được giặt sau mỗi lần sử dụng.


### **Khi tại cơ sở có bệnh nhân chạy thận nhân tạo nghi ngờ hoặc xác định nhiễm COVID-19, áp dụng các biện pháp bổ sung sau:**
  * Phòng chăm sóc sức khỏe nên được thông báo về bệnh nhân.
  * NVYT nên tuân theo Khuyến cáo về Kiểm soát và Phòng ngừa Nhiễm khuẩn tạm thời của CDC đối với bệnh nhân xác định nhiễm bệnh Coronavius 2019 (COVID-19) hoặc những người đang được điều tra về COVID-19 trong môi trường chăm sóc sức khỏe. Điều này bao gồm các khuyến cáo về PPE. Vệ sinh và khử trùng thường quy thích hợp đối với COVID-19 ở môi trường lọc máu. Bất kỳ bề mặt, vật tư hoặc thiết bị nào (ví dụ: máy lọc máu) nằm trong vòng 6 feet (khoảng 1,8m) của bệnh nhân có triệu chứng nên được khử trùng hoặc loại bỏ.


  * Các sản phẩm được EPA phê chuẩn về yêu cầu đối với tác nhân virus mới nổi được khuyến cáo sử dụng chống lại COVID-19. Tham khảo Danh sách biểu tượng Nexternal trên trang web EPA để biết các chất khử trùng đã đăng ký EPA mà có đủ điều kiện cần thiết theo chương trình các tác nhân virus mới nổi của EPA từ việc sử dụng chống lại SARS-CoV-2.


Nếu cơ sở chạy thận nhân tạo đang thẩm tách nhiều hơn một bệnh nhân nghi ngờ hoặc xác định nhiễm COVID-19, nên cân nhắc để gộp những bệnh nhân này và NVYT chăm sóc họ ở cùng một khu vực của đơn vị và/hoặc trên cùng một phiên trực (ví dụ, xem xét phiên cuối cùng trong ngày). Nếu nguyên nhân của các triệu chứng hô hấp được xác định, bệnh nhân có nguyên nhân khác không nên được gộp chung (ví dụ, bệnh nhân đã được xác định bị cúm và COVID-19 không nên gộp chung).
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh
[youtube.com/bvntp](http://youtube.com/bvntp)
  * [Nhận biết sớm và cách ly những cá nhân nhiễm trùng đường hô hấp:](https://bvnguyentriphuong.com.vn/than-loc-mau/huong-dan-bo-sung-tam-thoi-ve-khuyen-cao-phong-ngua-va-kiem-soat-nhiem-khuan-doi-voi-benh-nhan-nghi-ngo-hoac-xac-dinh-nhiem-covid-19-tai-cac-co-so-chay-than-nhan-tao-ngoai-tru#nhn-bit-sm-v-cch-ly-nhng-c-nhn-nhim-trng-ng-h-hp)
  * [Khi tại cơ sở có bệnh nhân chạy thận nhân tạo nghi ngờ hoặc xác định nhiễm COVID-19, áp dụng các biện pháp bổ sung sau:](https://bvnguyentriphuong.com.vn/than-loc-mau/huong-dan-bo-sung-tam-thoi-ve-khuyen-cao-phong-ngua-va-kiem-soat-nhiem-khuan-doi-voi-benh-nhan-nghi-ngo-hoac-xac-dinh-nhiem-covid-19-tai-cac-co-so-chay-than-nhan-tao-ngoai-tru#khi-ti-c-s-c-bnh-nhn-chy-thn-nhn-to-nghi-ng-hoc-xc-nh-nhim-covid19-p-dng-cc-bin-php-b-sung-sau)



## ️ Biến chứng hay gặp trong chạy thận nhân tạo

  * [Những biến chứng thường gặp nhất theo thứ tự tần suất là tụt huyết áp (20-30%), chuột rút (5-20%), buồn nôn và nôn (5-15%), nhức đầu (5%), đau ngực (2-5%), ngứa (5%) và sốt ớn lạnh (<1%). A. TỤT HUYẾT ÁP](https://bvnguyentriphuong.com.vn/than-loc-mau/bien-chung-hay-gap-trong-chay-than-nhan-tao#nhng-bin-chng-thng-gp-nht-theo-th-t-tn-sut-l-tt-huyt-p-2030-chut-rt-520-bun-nn-v-nn-515-nhc-u-5-au-ngc-25-nga-5-v-st-n-lnh-1a-tt-huyt-p)
  * [ 1/ Nguyên nhân thường gặp](https://bvnguyentriphuong.com.vn/than-loc-mau/bien-chung-hay-gap-trong-chay-than-nhan-tao#1-nguyn-nhn-thng-gp)
  * [2/ Tụt huyết áp do co mạch không đầy đủ.](https://bvnguyentriphuong.com.vn/than-loc-mau/bien-chung-hay-gap-trong-chay-than-nhan-tao#2-tt-huyt-p-do-co-mch-khng-y-)
  * [3/ Thuốc hạ áp: ](https://bvnguyentriphuong.com.vn/than-loc-mau/bien-chung-hay-gap-trong-chay-than-nhan-tao#3-thuc-h-p)
  * [4/ Tụt huyết áp liên quan đến yếu tố tim mạch: ](https://bvnguyentriphuong.com.vn/than-loc-mau/bien-chung-hay-gap-trong-chay-than-nhan-tao#4-tt-huyt-p-lin-quan-n-yu-t-tim-mch)
  * [5/ Những nguyên nhân hiếm gặp: ](https://bvnguyentriphuong.com.vn/than-loc-mau/bien-chung-hay-gap-trong-chay-than-nhan-tao#5-nhng-nguyn-nhn-him-gp)
  * [C. BUỒN NÔN VÀ NÔN](https://bvnguyentriphuong.com.vn/than-loc-mau/bien-chung-hay-gap-trong-chay-than-nhan-tao#c-bun-nn-v-nn)


##  Những biến chứng thường gặp nhất theo thứ tự tần suất là tụt huyết áp (20-30%), chuột rút (5-20%), buồn nôn và nôn (5-15%), nhức đầu (5%), đau ngực (2-5%), ngứa (5%) và sốt ớn lạnh (<1%). **A. TỤT HUYẾT ÁP**
Tụt huyết áp liên quan đến giảm quá mức hoặc nhanh chóng thể tích máu như: Tăng cân nhiều giữa hai lần chạy thận, thời gian chạy thận ngắn, trọng lượng khô thấp hơn trọng lượng khô thực tế, tính số ký rút không chính xác hoặc nhầm. Tụt huyết áp trong chạy thận bắt nguồn chủ yếu từ giảm thể tích máu do rút dịch (siêu lọc) mà đáp ứng huyết động bù trừ không đủ.
Để tránh tụt Huyết áp nên:
  * Sự dụng bộ phận kiểm soát siêu lọc. Hiện nay, các máy chạy thận đều có thiết bị kiểm soát siêu lọc một cách thường qui.
  * Tránh tăng cân nhiều giữa hai lần chạy thận hoặc tránh chạy thận thời gian ngắn. Bệnh nhân nên **hạn chế ăn muối và qua đó tránh được tăng cân giữa hai lần chạy thận ( < 1 kg/ngày)**. Hạn chế ăn muối có hiệu quả hơn nhiều trong việc giảm tăng cân giữa hai lần chạy thận so với giảm uống nước (Tomson, 2001). Tăng thời gian chạy thận cũng là một cách hiệu quả làm giảm tốc độ rút dịch và tần suất tụt huyết áp trong chạy thận. Khuyến cáo của KDOQI 2006 thời gian mỗi lần chạy thận không nên giảm dưới 3 giờ (đối với chế độ ba lần/tuần) ở những bệnh nhân không còn hoặc ít đi tiểu.
  * Xác định trọng lượng khô cẩn thận. Việc tính nhầm trọng lượng khô (chọn trọng lượng khô quá thấp) sẽ gây tụt huyết áp trong lúc chạy thận, và thường là tụt huyết áp sau chạy thận, chuột rút, choáng váng, khó chịu và cảm giác mệt lã.


### **2/ Tụt huyết áp do co mạch không đầy đủ.**
  * Nhiệt độ dịch lọc nên duy trì được nhiệt độ máu của bệnh nhân từ lúc bắt đầu cho tới lúc kết thúc chạy thận. Khi nhiệt độ dịch lọc cao hơn mức lý tưởng này, có sự dãn mạch ngoài da nhằm tản bớt nhiệt. Sự dãn mạch này làm giảm kháng lực mạch và làm bệnh nhân dễ tụt huyết áp. _Các máy chạy thận đều có bộ phận điều chỉnh nhiệt độ, cung cấp dịch lọc đẳng nhiệt với bệnh nhân.._
  * **_Tránh ăn trong lúc chạy thận ở bệnh nhân dễ tụt huyết áp_**. Ăn trong lúc chạy thận có thể thúc đẩy hoặc làm tăng nguy cơ tụt huyết áp. Nguyên nhân là do dãn các mạch máu ở hệ tiêu hóa, làm tăng dung lượng máu ở tĩnh mạch hệ tiêu hóa, làm máu đổ về tim kém hơn. Bệnh nhân dễ tụt huyết áp trong lúc chạy thận nên tránh ăn ngay trước hoặc trong khi chạy thận.


  * Hạn chế thiếu máu nặng . Kể từ khi có Erythropoietin được sử dụng, ít bệnh nhân bị thiếu máu nặng đến mức phải tụt huyết áp. Tuy nhiên, CTNT cấp cứu có thể gặp những bệnh nhân thiếu máu nặng và tụt huyết áp trong lúc chạy thận kháng trị; khi đó truyền máu để nâng nồng độ hemoglobin trước chạy thận tới 11-12 g/dL có thể có ích.


### **3/ Thuốc hạ áp:**
Những người hay tụt huyết áp khi chạy thận nhân tạo nên tránh uống thuốc huyết áp trước chạy thận nhằm hạn chế biến chứng tụt huyết áp khi chạy thận.
### **4/ Tụt huyết áp liên quan đến yếu tố tim mạch:**
Bệnh tim thiếu máu cục bộ, suy tim, nhồi máu cơ tim, rối loạn nhịp tim ( rung nhĩ), rối loạn chức năng tâm trương, chèn ép tim.
  * Chức năng tâm trương. Rối loại chức năng tâm trương thường gặp ở bệnh nhân chạy thận do tăng huyết áp, bệnh mạch vành và độc tố của hội chứng urê huyết.
  * Tần số tim và khả năng co bóp của cơ tim. Tụt huyết áp trong lúc chạy thận thường liên quan đến giảm đổ đầy thất, người suy tim cơ chế bù trừ ở tim không làm tăng được cung lượng tim, rối loạn cơ chế bù trừ của tim có thể đóng vai trò trực tiếp trong sự hình thành tụt huyết áp.


### **5/ Những nguyên nhân hiếm gặp** : 
Thuyên tắc khí, dị ứng màng lọc, tán huyết, nhiễm trùng huyết,
**Phát hiện tụt huyết áp** : Hầu hết bệnh nhân than phiền cảm giác chóng mặt, choáng váng, hoặc buồn nôn khi xảy ra tụt huyết áp. Một số bị chuột rút. Số khác có thể có triệu chứng kín đáo, chỉ có thể thấy được bởi nhân viên y tế quen thuộc với bệnh nhân (chẳng hạn mất tỉnh táo, cảm giác tối sầm). Ở một số bệnh nhân, không có triệu chứng nào cho tới khi huyết áp giảm cực thấp (và rất nguy hiểm). Vì lý do này, huyết áp phải được theo dõi đều đặn trong suốt quá trình chạy thận. Đo huyết áp mỗi giờ hoặc nửa giờ tùy thuộc vào từng trường hợp. **Chiến lược giúp phòng ngừa tụt huyết áp trong lúc chạy thận** |  _1. Dùng máy chạy thận có bộ phận kiểm soát siêu lọc. 2. Khuyên bệnh nhân hạn chế ăn muối, qua đó làm giảm tăng cân giữa hai lần chạy thận (lý tưởng <1 kg/ngày). 3. Đánh giá nhiều lần và cẩn thận trọng lượng khô. 4. Dùng dịch lọc có nồng độ natri trung bình theo thời gian khoảng 140-145 mM, theo sự dung nạp của bệnh nhân. 5. Dùng thuốc hạ áp hàng ngày sau khi chạy thận. 6. Dùng dịch lọc bicarbonate. 7. Dùng dịch lọc có nhiệt độ 35.5°C, giảm (hoặc tăng) nếu cần và theo sự dung nạp của bệnh nhân. 8. Bảo đảm hemoglobin trước chạy thận khoảng 11 g/dL (110 g/L). 9. Không ăn hoặc dùng glucose đường uống trong lúc chạy thận ở những bệnh nhân dễ tụt huyết áp. 10. Xem xét việc dùng bộ phận theo dõi thể tích máu. _ _11. Kéo dài thời gian chạy thận thêm 30 phút._  
---  
##  **B. CHUỘT RÚT**
Nguyên nhân của chuột rút trong CTNT hiện chưa rõ. Bốn yếu tố thuận lợi quan trọng nhất là tụt huyết áp, giảm thể tích (bệnh nhân thấp hơn trọng lượng khô), tốc độ siêu lọc cao (tăng cân nhiều giữa hai lần chạy thận), và dùng dịch lọc có nồng độ natri thấp. Tất cả các yếu tố này tạo thuận lợi cho co mạch, gây giảm tưới máu cơ làm rối loạn thư dãn cơ. Chuột rút thường xảy ra nhất liên quan đến tụt huyết áp, mặc dù chuột rút thường kéo dài dai dẳng sau khi huyết áp đã phục hồi đầy đủ. Chuột rút cũng thường gặp ở tháng đầu của chạy thận hơn là giai đoạn về sau. Hạ magiê máu cũng có thể gây chuột rút kháng trị trong lúc chạy thận. Hạ can xi máu cũng nên được xem như là một nguyên nhân tiềm tàng. Hạ kali máu trước chạy thận sẽ nặng thêm bởi nồng độ kali dịch lọc thường dùng (2 mM) và cũng có thể gây chuột rút
Xử trí. Khi tụt huyết áp và chuột rút xảy ra đồng thời, cả hai có thể đáp ứng với truyền NaCl 0.9%; Tuy nhiên, chuột rút thường kéo dài dai dẳng. Kéo căng cơ bị chuột rút (chẳng hạn gấp cổ chân đối với chuột rút bắp chân) có thể làm giảm khó chịu. Xoa bóp có tác dụng tùy bệnh nhân và nên được áp dụng tùy trường hợp.
Phòng ngừa tụt huyết áp sẽ loại bỏ hầu hết chuột rút. Bài tập căng cơ. Một chương trình tập căng cơ dành cho nhóm cơ bị chuột rút có thể có ích.
## **C. BUỒN NÔN VÀ NÔN**
### **Nguyên nhân**
Buồn nôn và nôn xảy ra lên tới 10% trường hợp chạy thận thường qui. Có nhiều nguyên nhân. Ở bệnh nhân ổn định, hầu hết do tụt huyết áp. Buồn nôn và nôn có thể có triệu chứng sớm của hội chứng mất cân bằng. Phản ứng màng lọc có thể gây buồn nôn và nôn. Liệt nhẹ dạ dày, rất thường gặp ở bệnh nhân đái đường, nhưng cũng gặp ở bệnh nhân không đái đường, sẽ nặng lên do chạy thận. Dịch lọc nhiễm bẩn hoặc có nồng độ các chất không đúng (natri, canxi cao) có thể gây buồn nôn và nôn. Bệnh nhân chạy thận dường như bị buồn nôn và nôn dễ hơn những bệnh nhân khác (nhiễm trùng hô hấp, dùng thuốc gây nghiện, tăng canxi máu); chạy thận có thể làm nặng triệu chứng trong các bệnh lý này.
### **Xử trí**
Bước đầu tiên là điều trị tụt huyết áp nếu có. Thuốc chống ói có thể được dùng cho những nguyên nhân ói khác nếu cần.
### **Phòng ngừa**
Tránh tụt huyết áp trong lúc chạy thận có tầm quan trọng hơn hết. Triệu chứng dai dẳng không liên quan đến huyết động có thể giảm khi dùng các thuốc chống ói (metoclopramide).
## **D. NHỨC ĐẦU**
### **Nguyên nhân**
Nhức đầu thường gặp trong lúc chạy thận; nguyên nhân thường chưa rõ, có thể là triệu chứng kín đáo của hội chứng mất cân bằng. Ở bệnh nhân có uống cà phê, nhức đầu có thể là triệu chứng của ngưng cà phê vì nồng độ cà phê giảm cấp tính trong lúc chạy thận. Với nhức đầu không điển hình hoặc quá nặng, nên xem xét nguyên nhân thần kinh (đặc biệt là xuất huyết thúc đẩy bởi thuốc kháng đông).
### **Xử trí**
Có thể dùng acetaminophen trong chạy thận.
### **Phòng ngừa**. 
Một ly cà phê đậm có thể giúp phòng ngừa (hoặc điều trị) triệu chứng ngưng cà phê. Bệnh nhân nhức đầu trong lúc chạy thận có thể thiếu Mg. Bổ sung Mg một cách thận trọng có thể được chỉ định, nhưng không quên những nguy cơ của việc cho dùng Mg ở bệnh nhân suy thận.
## **E. ĐAU NGỰC**
Đau ngực nhẹ hoặc khó chịu ở ngực (thường ít nhiều có đau lưng kèm theo) xảy ra trong 1-4% bệnh nhân chạy thận. Nguyên nhân không rõ, không có xử trí hay phòng ngừa đặc hiệu. Xảy ra đau thắt ngực trong chạy thận là thường gặp, và phải được chẩn đoán phân biệt với nhiều nguyên nhân đau ngực khác (ví dụ tán huyết, thuyên tắc khí, viêm màng ngoài tim, nhồi máu cơ tim).
## **F. NGỨA**
Ngứa, một vấn đề thường gặp ở bệnh nhân chạy thận, đôi khi được thúc đẩy hoặc nặng lên do chạy thận. Ngứa xảy ra chỉ trong chạy thận, đặc biệt nếu có kèm các triệu chứng dị ứng nhẹ khác, có thể là triệu chứng của dị ứng mức độ nhẹ với màng lọc hoặc thành phần của dây chạy thận, tuy nhiên, thường gặp là ngứa mãn tính. Không nên bỏ qua viêm gan siêu vi (hoặc do thuốc) như là nguyên nhân tiềm tàng của ngứa. Điều trị chuẩn bằng antihistamine có ích, châm cứu có thể có ích. Về lâu dài, nên dùng chất làm ẩm toàn thân và kem bôi trơn da. Trị liệu bằng tia cực tím, đặc biệt tia UVB, có thể có ích. Ngứa thường thấy ở bệnh nhân có nồng độ canxi cao, tích số canxi x phospho cao và/hoặc nồng độ PTH tăng đáng kể; cần phải giảm nồng độ phospho, canxi (tới giới hạn dưới của bình thường) và PTH.
Tìm hiểu thêm về [**cách bảo vệ chức năng thận**](https://bvnguyentriphuong.com.vn/than-loc-mau/lam-sao-de-bao-ve-chuc-nang-than)
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [Những biến chứng thường gặp nhất theo thứ tự tần suất là tụt huyết áp (20-30%), chuột rút (5-20%), buồn nôn và nôn (5-15%), nhức đầu (5%), đau ngực (2-5%), ngứa (5%) và sốt ớn lạnh (<1%). A. TỤT HUYẾT ÁP](https://bvnguyentriphuong.com.vn/than-loc-mau/bien-chung-hay-gap-trong-chay-than-nhan-tao#nhng-bin-chng-thng-gp-nht-theo-th-t-tn-sut-l-tt-huyt-p-2030-chut-rt-520-bun-nn-v-nn-515-nhc-u-5-au-ngc-25-nga-5-v-st-n-lnh-1a-tt-huyt-p)
  * [ 1/ Nguyên nhân thường gặp](https://bvnguyentriphuong.com.vn/than-loc-mau/bien-chung-hay-gap-trong-chay-than-nhan-tao#1-nguyn-nhn-thng-gp)
  * [2/ Tụt huyết áp do co mạch không đầy đủ.](https://bvnguyentriphuong.com.vn/than-loc-mau/bien-chung-hay-gap-trong-chay-than-nhan-tao#2-tt-huyt-p-do-co-mch-khng-y-)
  * [3/ Thuốc hạ áp: ](https://bvnguyentriphuong.com.vn/than-loc-mau/bien-chung-hay-gap-trong-chay-than-nhan-tao#3-thuc-h-p)
  * [4/ Tụt huyết áp liên quan đến yếu tố tim mạch: ](https://bvnguyentriphuong.com.vn/than-loc-mau/bien-chung-hay-gap-trong-chay-than-nhan-tao#4-tt-huyt-p-lin-quan-n-yu-t-tim-mch)
  * [5/ Những nguyên nhân hiếm gặp: ](https://bvnguyentriphuong.com.vn/than-loc-mau/bien-chung-hay-gap-trong-chay-than-nhan-tao#5-nhng-nguyn-nhn-him-gp)
  * [C. BUỒN NÔN VÀ NÔN](https://bvnguyentriphuong.com.vn/than-loc-mau/bien-chung-hay-gap-trong-chay-than-nhan-tao#c-bun-nn-v-nn)



