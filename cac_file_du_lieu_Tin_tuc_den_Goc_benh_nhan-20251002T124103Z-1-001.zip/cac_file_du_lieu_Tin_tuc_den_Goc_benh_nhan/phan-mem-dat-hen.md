## Dịch vụ y tế tại BV Nguyễn Tri Phương


## ️ Đơn giản hóa quy trình đặt lịch khám tại bệnh viện Nguyễn Tri Phương với ứng dụng GlobeDr

So với quy trình thanh toán truyền thống phải qua nhiều khâu: Đăng ký, xếp hàng chờ được phân phòng, bác sỹ theo yêu cầu, thanh toán chi phí khám và ngồi chờ khám mất nhiều thời gian, thì việc đăng ký tư vấn, khám chữa bệnh và thanh toán viện phí tại bệnh viện Nguyễn Tri Phương giờ đây càng đơn giản chỉ với một chạm qua ứng dụng GlobeDr (Bác sĩ toàn cầu). Người bệnh chỉ cần ngồi ở nhà, xem danh sách ngày khám, đăng ký bác sỹ và thanh toán nhanh chóng qua GlobeDr. Khi đến bệnh viện, bệnh nhân vào thẳng quầy ưu tiên và tiến hành thăm khám ngay mà không phải xếp hàng chờ đợi lâu. 
Bệnh viện Nguyễn Tri Phương chọn dịch vụ hỗ trợ đặt lịch khám và thanh toán qua GlobeDr và Payoo mà không chọn các phương án nào khác vì các yếu tố: độ phủ rộng khắp, hỗ trợ tốt cho người dùng và đa dạng phương thức thanh toán.
Cụ thể, là nền tảng thanh toán hàng đầu đáp ứng các nhu cầu thanh toán từ trực tuyến đến trực tiếp, ngoài ứng dụng ví điện tử, Payoo còn liên kết với gần 40 ngân hàng và hơn 20.000 cửa hàng tiện lợi, siêu thị, điện máy,…trên toàn quốc, giúp người dùng tiện lợi trong việc thanh toán mọi lúc mọi nơi, nhanh chóng và an toàn.
Với việc kết hợp cùng ứng dụng GlobeDr, bệnh nhân và người nhà có thể thanh toán với đa dạng phương thức khác nhau, bao gồm các nguồn thanh toán quen thuộc như thẻ nội địa, quốc tế (Visa/Mastercard/JCB), quét mã QR qua ứng dụng của các ngân hàng, ví điện tử Payoo. Thậm chí, bệnh nhân chưa chắc chắn về thời gian khám có thể lựa chọn hình thức đặt lịch trước, thanh toán sau tại cửa hàng liên kết.
Theo đó, bệnh nhân và người nhà có thể tải, cài đặt ứng dụng GlobeDr, nhập thông tin đặt khám và chọn phương thức thanh toán phù hợp. Việc đặt khám và thanh toán chỉ diễn ra trong vài phút và có thể thực hiện trước khi đến bệnh viện. Đây là bước chuẩn bị sẵn sàng để bệnh nhân an tâm khám bệnh.
**MỘT CHẠM APP GLOBEDR, THANH TOÁN VIỆN PHÍ TỨC THÌ**
GlobeDr - mạng xã hội y tế đầu tiên ở Việt Nam, ứng dụng chăm sóc sức khỏe trực tuyến vừa hợp tác cùng Payoo triển khai giải pháp thanh toán viện phí không dùng tiền mặt ngay trên ứng dụng, chấp nhận mọi hình thức thanh toán linh hoạt cho khách hàng.
Chỉ với 1 bước tải ứng dụng GlobeDr, người nhà bệnh nhân có thể:
✔️ Chủ động rút ngắn quy trình đăng ký tư vấn sức khỏe, thăm khám tại bệnh viện.
✔️ Thanh toán viện phí tức thì mọi lúc, mọi nơi.
✔️ Linh hoạt lựa chọn hình thức thanh toán phù hợp: thẻ nội địa, thẻ quốc tế (Visa/Master/JCB), QR code, ví điện tử Payoo.
✔️ Đặc biệt, book lịch trước, thanh toán sau tại cửa hàng tiện lợi trong trường hợp chưa chắc chắn lịch trình.
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh

## ️ Mở thêm dịch vụ dành cho khách hàng: gói khám định kỳ được quản lý, tư vấn

**- Đối tượng áp dụng:**
**- Quyền lợi tham gia:**
  * Tạo tài khoản thành viên trên trang web của BV Nguyễn Tri Phương
  * Được nhắc hẹn lấy máu định kỳ
  * Lấy máu tại nhà
  * BS khám tổng quát và tư vấn kết quả xét nghiệm
  * Được ưu tiên chọn lựa bác sĩ khi khám ngoại trú tại BV
  * Được ưu tiên thực hiện các xét nghiệm tăng thêm do BS chuyên khoa chỉ định hoặc theo nhu cầu (chi phí sẽ đóng theo quy định phí dịch vụ của bệnh viện)
  * Được xem xét giải quyết, sắp xếp phòng dịch vụ khi có nhu cầu nhập viện
  * Có thẻ khách hàng hội viên của BV
  * Mỗi năm được 01 lần thực hiện miễn phí (tại bệnh viện) các danh mục sau
    * X Quang phổi
    * Siêu âm bụng
    * Siêu âm tim
    * Đo ECG


**a. Gói tầm soát định kỳ toàn diện (bao gồm các xét nghiệm dấu ấn ung thư)**
- Chi phí trọn gói toàn diện là 8.000.0000đ/năm cho 02 lần lấy máu tại nhà (và các xét nghiệm tại BV). 
- Các xét nghiệm cơ bản được thực hiện bao gồm
Nhóm xét nghiệm huyết học - đông máu - nhóm máu
  * Tổng phân tích tế bào máu
  * Nhóm máu ABO, Rh (D)


Nhóm xét nghiệm sinh hóa - miễn dịch - khí máu
  * Glycemie
  * HbA1C
  * Bộ mỡ (Cholesterol toàn phần, Triglycerid, HDL-C, LDL-C)
  * AST (GOT)
  * AST (GPT)
  * Protid
  * Albumin
  * Globulin
  * Creatinin
  * eGFR (MDRD)
  * Acid Uric
  * Ion đồ (NA,K,Cl,Ca)
  * Ferritin
  * HBsAg miễn dịch tự động
  * Anti HBs miễn dịch tự động
  * Anti HCV


Nhóm xét nghiệm nước tiểu
  * Tổng phân tích nước tiểu


- Các xét nghiệm tầm soát ung thư cho nam
  * AFP (gan, tiêu hóa)
  * CEA (gan, tiêu hóa, phổi)
  * CA 19.9 (tiêu hóa)
  * CA 72.4 (tiêu hóa)
  * CYFRA 21.1 (phổi)


- Các xét nghiệm tầm soát ung thư cho nữ
  * β-HCG
  * CA 15.3 (vú, buồng trứng)
  * CA 125 (vú, buồng trứng)
  * AFP (gan, tiêu hóa)
  * CEA (gan, tiêu hóa, phổi)
  * CA 19.9 (tiêu hóa)
  * CA 72.4 (tiêu hóa)
  * CYFRA 21.1 (phổi)


**b. Gói tầm soát định kỳ cơ bản (không bao gồm các xét nghiệm dấu ấn ung thư)**
- Chi phí trọn gói toàn diện là 5.000.0000đ/năm cho 02 lần lấy máu tại nhà (và các xét nghiệm tại BV). 
- Các xét nghiệm được thực hiện bao gồm
Nhóm xét nghiệm huyết học - đông máu - nhóm máu
  * Tổng phân tích tế bào máu
  * Nhóm máu ABO, Rh (D)


Nhóm xét nghiệm sinh hóa - miễn dịch - khí máu
  * Glycemie
  * HbA1C
  * Bộ mỡ (Cholesterol toàn phần, Triglycerid, HDL-C, LDL-C)
  * AST (GOT)
  * AST (GPT)
  * Protid
  * Albumin
  * Globulin
  * Creatinin
  * eGFR (MDRD)
  * Acid Uric
  * Ion đồ (NA,K,Cl,Ca)
  * Ferritin
  * HBsAg miễn dịch tự động
  * Anti HBs miễn dịch tự động
  * Anti HCV


Nhóm xét nghiệm nước tiểu
  * Tổng phân tích nước tiểu


**Hình thức đăng ký**
  * Điền thông tin theo mẫu 
    * _**Họ tên**_
    * _**Giới**_
    * _**Ngày tháng năm sinh**_
    * _**Số CMND/CCCD**_
    * _**Địa chỉ tạm trú / thường trú**_
    * _**Gói khám theo năm muốn đăng ký**_
    * _**Tình trạng bệnh đang điều trị hiện tại (ví dụ: tăng huyết áp, viêm gan mạn…)**_
  * Gửi email về: truyenthong@bvnguyentriphuong.com.vn với tiêu đề "đăng ký gói khám định kỳ"


**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/) **- Đa khoa Hạng I Thành phố Hồ Chí Minh

## ️ GlobeDr và Payoo đồng hành cùng BV Nguyễn Tri Phương để chăm sóc khách hàng tốt hơn

Payoo là sản phẩm của Công ty Cổ phần Dịch vụ Trực tuyến Cộng Đồng Việt (VietUnion), được đầu tư bởi Công ty Cổ phần Xây dựng Sài Gòn và NTT Data – Tập đoàn Công nghệ Thông tin hàng đầu Nhật Bản. Dịch vụ Thanh toán Payoo được Thống đốc Ngân hàng Nhà nước cấp phép hoạt động trong lĩnh vực trung gian thanh toán vào ngày 18/02/2009, nhằm giúp cho người dùng có thể thanh toán một cách dễ dàng, nhanh chóng và tiện lợi hơn.
**PAYOO – MỘT ĐIỂM ĐẾN CHO MỌI THANH TOÁN**
Website: <https://www.payoo.vn/>
Tải ứng dụng:
  * Android: <http://bit.ly/payooandroid>
  * IOS: <http://bit.ly/payooapp>


Ứng dụng GlobeDr (Bác sĩ toàn cầu) là ứng dụng cung cấp dịch vụ thương mại điện tử để hỗ trợ kết nối giữa khách hàng/người dùng với các nhà cung cấp dịch vụ chăm sóc sức khỏe đã được cấp phép tư vấn khám chữa bệnh theo quy định của pháp luật Việt Nam.
**Hiện tại, GlobeDr đã có hơn 500 đối tác là các đơn vị Bệnh viện, Nhà thuốc, Phòng khám, Nha khoa, Trung tâm xét nghiệm... trải dài trên khắp cả nước.**
**Giờ đây, khi có nhu cầu đi khám/chữa bệnh tại Bệnh viện Nguyễn Tri Phương, người dùng có thể dễ dàng****Đặt Hẹn****qua ứng dụng GlobeDr với:**
  * Đầy đủ dịch vụ, đáp ứng đa đạng nhu cầu thăm khám
  * Được phép chọn Chuyên khoa khám – Ngày khám – Buổi khám – Giờ khám 
  * Chi phí minh bạch, rõ ràng, hiển thị đầy đủ ở mỗi dịch vụ 
  * Thao tác thanh toán đơn giản, nhanh gọn qua ví điện tử 


Thanh toán qua ứng dụng GlobeDr đa dạng các hình thức, bao gồm các nguồn thanh toán quen thuộc như thẻ nội địa, quốc tế (Visa/Mastercard/JCB), quét mã QR qua ứng dụng của các ngân hàng, ví điện tử Payoo. Thậm chí, bệnh nhân chưa chắc chắn về thời gian khám có thể lựa chọn hình thức đặt lịch trước, thanh toán sau thông qua mạng lưới các đối tác siêu thị, cửa hàng tiện lợi liên kết với Payoo trên cả nước.

## ️ Tính năng mới: Quản lý hồ sơ sức khỏe và đăng ký BS tư vấn

Nhằm tăng thêm hiệu quả phục vụ và tăng cường dịch vụ trực tuyến cho khách hàng, BV Nguyễn Tri Phương xây dựng tính năng đăng ký thành viên với các tiện ích:
**- Tải lên hồ sơ sức khỏe cá nhân (hỗ trợ file ảnh và file pdf)**
**- Đăng ký BS tư vấn trực tuyến hoặc qua điện thoại trên cơ sở thông tin hồ sơ sức khỏe**
* Các tính năng này thực hiện được cả trên **giao diện máy tính (desktop) và điện thoại - máy tính bảng (mobile, tablet)**
**Về tính năng đăng ký:**
**1. Trên giao diện mobile, tablet: gọi chức năng từ thanh menu**
- Thanh menu được đặt góc trên cùng bên phải
- Phần đăng ký ở cuối cùng của menu
**2. Trên giao diện desktop: bấm ô "Đăng ký" góc trên cùng bên trái cạnh thanh tìm kiếm**
Sau khi thực hiện đăng ký - sẽ có email xác nhận gửi về mail đã đăng ký. Vui lòng thực hiện xác thực qua mail. Xin vui lòng tìm kiếm ở thư rác (spam) trong trường hợp không thấy mail trong hộp thư đến sau 15ph.
**_*Sau khi kích hoạt email - quản trị viên sẽ kiểm tra hồ sơ và kích hoạt tài khoản - khi đó chức năng đăng nhập mới có thể thực hiện._**
**Về tính năng tạo hồ sơ sức khỏe**
**1. Trên giao diện mobile, tablet:**
- Tạo hồ sơ sức khỏe theo ngày khám
- Thực hiện chức năng chụp hình hoặc chọn từ kho ảnh đúng theo ngày khám
**2. Trên giao diện desktop:**
- Tạo hồ sơ sức khỏe theo ngày khám
- Dùng chức năng đính kèm để tải hồ sơ sức khỏe - lưu ý file đúng định dạng
**Về tính năng đặt lịch khám**
- Tạo lịch tư vấn theo thời gian mong muốn (ngày và giờ)
- Có thể chọn BS mong muốn được tư vấn (có tính tham khảo) hoặc để trống và đội ngũ quản trị sẽ sắp xếp BS phù hợp.
_*** Vui lòng chú ý điện thoại trong thời gian đặt hẹn tư vấn và nhận cuộc gọi từ số điện thoại lạ!**_
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh

## Hướng dẫn đặt xét nghiệm thực hiện tại nhà

Bước 1: truy cập trang web [khamtainha-bvntp.com](http://khamtainha-bvntp.com/?fbclid=IwAR1acGT9VhRW-a6NILOJpHe3kRNpxJCwoQQafAi5rzrfM9iYGYp2fgT3dj4)
Bước 2: chọn thẻ "Đăng ký xét nghiệm"
Bước 3: thực hiện khai báo các trường bắt buộc và chọn lựa các xét nghiệm cần thực hiện
Bước 4: bấm nút gửi (submit) khi đã hoàn thành để gửi toàn bộ các thông tin cho chúng tôi 
Bước 5: vui lòng chờ nhận cuộc gọi xác nhận từ nhân viên y tế bệnh viện Nguyễn Tri Phương
(Bạn cũng có thể nhắn tin trên fanpage của BV thông báo đã đặt lịch để chúng tôi có thể hỗ trợ nhanh hơn!)
Theo dõi các thông tin của BV trên facebook [tại đây](https://www.facebook.com/BVNTP)
Theo dõi các video về y tế của BV tại [kênh truyền thông](https://www.youtube.com/channel/UCRlRfMJl5emGJvWjuoJK7sg)./.

## Những tiến bộ và phát triển của BV trong năm 2020


