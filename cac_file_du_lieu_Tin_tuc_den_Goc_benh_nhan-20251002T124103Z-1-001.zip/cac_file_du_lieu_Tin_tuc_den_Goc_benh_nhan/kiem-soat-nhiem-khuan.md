## Truyền thông: Bệnh tay chân miệng - 2023

Bệnh tay chân miệng do siêu vi gây ra. Trong đó, nhóm EV71 nguy hiểm nhất vì có nhiều biến chứng nặng, gây tử vong cao. Tuy nhiên, siêu vi bệnh tay chân miệng dễ bị tiêu diệt.
Bệnh tay chân miệng có khả năng lây nhiễm cao.
  * Thường gặp ở trẻ dưới 5 tuồi.
  * Biểu hiện chính của bệnh là bóng nước ở tay chân và miệng


Hịện nay chưa có thuốc tiêm chủng phòng ngừa.
**I. Đường lây truyền**
Do tiếp xúc trực tiếp với dịch tiết ở mũi, họng, nước bọt, bóng nước vỡ, phân của bệnh nhân trên các dụng cụ sinh hoạt, đồ chơi, bàn ghế, nền nhà.
Lây qua đường hô hấp: Khi hắt hơi, ho, nói chuyện sẽ làm vi-rut lây lan từ người sang người. Thời gian ủ bệnh từ 3 - 7 ngày.
Thời kỳ lây truyền: vài ngày trước khi phát bệnh, mạnh nhất trong tuần đầu của bệnh và có thể kéo dài vài tuần sau đó, thậm chí sau khi bệnh nhân hết triệu chứng.
**II. Triệu chứng**
Nỗi bóng nước tại lòng bàn tay, chân, mông, gối và quanh miệng
Nỗi bóng nước trong miệng
**Dấu hiệu nặng cần đưa trẻ đến bệnh viện ngay**
  * Số liên tục trên 39oC
  * Bỏ ăn lì bì
  * Quấy khóc, bức rứt
  * Giật mình
  * Đi loạng choạng


**III. Phòng bệnh**
Rửa tay với xà phòng làm giảm yếu tố gây bệnh từ các mầm bệnh hiện diện trên bàn tay
**1. Rửa tay cho trẻ và người chăm sóc trẻ**
**Trước**  
---  
  * Khi chuẩn bị thức ăn
  * Khi ăn

| 
  * Đi vệ sinh
  * Thay tả, quần áo
  * Tiếp xúc phân, nước bọt, nước mũi, họng, bóng nước
  * Khi về nhà

  
**2. Rửa đồ chơi, lau sàn nhà**
Rửa đồ chơi bằng nước và xà phòng
Lau sàn, bàn ghế, thành, tay nắm vịnh cầu thang, lang cang bằng xà phòng hoặc hóa chất lau sàn _(pha theo hướng dẫn nhà sản xuất)_
**3. Cách ly khi trẻ mắc bệnh tay chân miệng**
Cách ly trẻ bệnh tại nhà để theo dõi chăm sóc và hạn chế lây lan. 
Không đến nhà trẻ, trường học, khu vui chơi trong ít nhất là 10 ngày kể từ khi khởi bệnh và chỉ đến lớp khi hết loét miệng và các phỏng nước.
**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/) **- Đa khoa Hạng I Thành phố Hồ Chí Minh

## Tụ cầu vàng kháng methicillin: tổng quan và điều trị

**1. Giới thiệu**
Tụ cầu vàng (_Staphylococcus aureus_) là một cầu khuẩn Gram dương bất động, gây đông máu trong họ vi khuẩn có màng tế bào (Firmicutes phylum).  _S.aureus_ tìm thấy trong hệ vi sinh vật cư trú tại màng nhầy mũi ở 20 – 40% dân số nói chung. Khi hàng rào nhầy và da bị tổn thương, ví dụ như các bệnh da mạn tính, vết thương, phẫu thuật,  _S.aureus_ có thể xâm nhập vào các lớp mô dưới da hoặc máu và gây nhiễm trùng. Người bệnh có các dụng cụ y tế xâm lấn như catheter tĩnh mạch trung tâm và ngoại vi hoặc suy giảm hệ miễn dịch có nguy cơ nhiễm  _S.aureus_ [5].
Methicillin là một penicillin bán tổng hợp bảo vệ vòng betalactam không bị thuỷ phân bởi penicillinase được giới thiệu vào năm 1959, ngay sau khi được đưa vào sử dụng trên lâm sàng, tụ cầu vàng kháng methicillin (Methicillin Resistant  _Staphylococcus aureus_ _–_ MRSA _)_ đã được báo cáo. Sự bùng phát của MRSA xảy ra ở châu Âu vào đầu những năm 1960 [2]. Do độc tính, hiện nay methicillin không còn được sử dụng cho người và thay vào đó là các penicillin ổn định hơn như oxacillin, flucloxacillin và dicloxacillin. Dù vậy, thuật ngữ tụ cầu vàng kháng methicillin vẫn tiếp tục được sử dụng. Bên cạnh đó, MRSA còn có khả năng kháng nhiều nhóm kháng sinh khác đã trở thành vấn đề lớn [1].
MRSA khá phổ biến ở hầu hết các bệnh viện ở châu Á, tỷ lệ MRSA chiếm tới 50% các nhiễm trùng huyết do tụ cầu vàng. Tỷ lệ kháng methicillin cao liên quan đến tình trạng sử dụng kháng sinh rộng rãi cũng như tình trạng dân số đông là điều kiện thuận lợi để lan truyền nhanh các chủng đề kháng [5].
**2. Cơ chế bệnh sinh**
**_Staphylococcus aureus cư trú_**
_S.aureus_ cư trú là nguyên nhân dẫn đến tình trạng nhiễm trùng ở hầu hết các trường hợp. Nhiễm trùng có thể xảy ra khi không có  _S.aureus_ cư trú trước đó như bệnh nhân có đặt Catheter hoặc vết thương không được kiểm soát tốt tình trạng nhiễm trùng. Vị trí cư trú chủ yếu của tụ cầu vàng là mũi, ngoài ra có thể gặp ở các vị trí khác như họng, đáy chậu [5].
**_Giai đoạn đầu của nhiễm trùng_**
Nhiễm trùng da và mô mềm (skin and soft tissue infections – SSTIs) do tụ cầu vàng thường bắt đầu từ sự chuyển dịch của vi khuẩn từ khoang chứa trong mũi đến các vết thương và vết xước nhỏ trên da. Tụ cầu vàng có khả năng bám dính và hình thành biofilm (là sự tích tụ dày đặc vi khuẩn trong khối cấu trúc ở ngoại bào; giúp vi khuẩn chống lại những tác động cơ học, hàng rào bảo vệ của cơ thể và liệu pháp kháng sinh) trên bề mặt nhựa hoặc bề mặt kim loại, gây nên các nhiễm trùng liên quan đến catheter, khớp nhân tạo hoặc viêm phổi thở máy. Tiếp theo đó, tụ cầu vàng lôi kéo sự xâm nhập của bạch cầu đa nhân dẫn đến hình thành tổn thương viêm tại chỗ [5].
**_Hình thành apxe_**
Protein bị kết đông bởi tụ cầu vàng có thể hình thành túi giả fibrin bao quanh vi khuẩn và các bạch cầu đa nhân, ngăn cản các bạch cầu đa nhân khác tràn vào.  _S.aureus_ có thể cản trở quá trình opsonin hóa, sản xuất ra các vi nang polysaccharide và ức chế dòng thác bổ thể [5].
**_Nhiễm trùng hệ thống_**
Áp xe có thể bị phá vỡ ở giai đoạn muộn, giải phóng dịch mủ và vi khuẩn sống theo đường da thúc đẩy quá trình lây bệnh hoặc theo đường máu gây nhiễm trùng huyết. Tụ cầu trong nội bào có thể bám dính vào bề mặt tế bào nội mô và tiểu cầu, sự kết dính này có thể gây viêm nội tâm mạc, khởi phát sự hình thành các áp xe thứ phát hoặc kích ứng sự thâm nhập của vi khuẩn vào tế bào nội mô, nơi vi khuẩn có thể tránh khỏi sự tác động của kháng sinh và các phân tử miễn dịch của cơ thể. Khả năng gây ngưng kết của các enzyme coagulase tiết ra bởi  _S.aureus_ được cho là góp phần gây nên quá trình đông máu hệ thống và sự giải phóng ồ ạt của các chất có liên quan từ vi khuẩn có dạng độc tố siêu kháng nguyên, gây ra cơn bão cytokine, dẫn đến tổn thương viêm toàn thân bùng phát, sốc nhiễm trùng và suy đa tạng nếu sự xâm nhập của vi khuẩn vào nội mạch không được kiểm soát [5].
**3. Chẩn đoán****vi sinh**
MRSA có thể gây ra nhiều loại nhiễm trùng, như SSTIs, viêm phổi, nhiễm trùng xương khớp, hội chứng sốc nhiễm độc (là một biến chứng hiếm gặp, đe dọa tính mạng) và nhiễm trùng huyết, có thể dẫn đến viêm nội tâm mạc hoặc sốc nhiễm khuẩn.
Mẫu bệnh phẩm vi sinh liên quan đến MRSA có thể phân làm hai loại: mẫu lâm sàng và mẫu sàng lọc. Mẫu lâm sàng (ví dụ như dịch mủ, mô sâu, đờm và máu) được lấy từ người bệnh có triệu chứng hoặc dấu hiệu chẩn đoán nhiễm trùng. Mẫu sàng lọc (như phết mũi, đáy chậu và họng) được thu thập để xác định các trường hợp vi khuẩn cư trú không gây bệnh [5].
**4. Điều trị nhiễm trùng**
**_Điều trị theo kinh nghiệm_**
Lựa chọn kháng sinh theo kinh nghiệm điều trị nhiễm khuẩn do MRSA nên được xem xét khi bệnh nhân có một số yếu tố nguy cơ nhiễm khuẩn bệnh viện do MRSA hoặc những bệnh nhân nhiễm trùng nghi ngờ do tụ cầu nặng ở khu vực có tỷ lệ MRSA > 20%. Lựa chọn kháng sinh, đường dùng và thời gian dùng phụ thuộc vào độ nặng và vị trí nhiễm trùng. Điều trị sau đó nên điều chỉnh dựa vào kết quả nuôi cấy và kháng sinh đồ [5].
**_Điều trị nhiễm trùng da và mô mềm_**
Có thể sử dụng vancomycin, daptomycin hoặc linezolid đường tĩnh mạch cho nhiễm trùng da và mô mềm nặng. Cần tránh liệu pháp đường uống trong điều trị khởi đầu cho nhiễm trùng nặng. Clindamycin, trimethoprim–sulfamethoxazole và doxycyclin là liệu pháp thay thế cho điều trị nhiễm trùng da và mô mềm nhẹ và trung bình dựa trên kháng sinh đồ. Với áp xe da không biến chứng, sử dụng clindamycin hoặc trimethoprim–sulfamethoxazol kết hợp với rạch da và dẫn lưu giúp cải thiện tỷ lệ khỏi lâm sàng ở khoa cấp cứu và các phòng khám ngoại trú [5].
**_Nhiễm trùng toàn thân nặng_**
Các kháng sinh khuyến cáo điều trị nhiễm trùng nặng do MRSA bao gồm vancomycin hoặc daptomycin trong nhiễm khuẩn huyết, vancomycin hoặc linezolid đường tĩnh mạch cho viêm phổi mắc phải tại cộng đồng. Với nhiễm trùng nặng, không nên sử dụng linezolid đường uống cho điều trị khởi đầu. Tuy nhiên, khi bệnh nhân ổn định và có thể dung nạp thuốc đường uống, khuyến cáo chuyển sang dùng linezolid đường uống. Trong trường hợp nhiễm trùng liên quan đến dụng cụ y tế (như catheter tĩnh mạch trung tâm), để điều trị thành công thường cần thay dụng cụ nếu có thể [5].
Các glycopeptid (như vancomycin, teicoplanin) là các thuốc chính trong điều trị nhiễm trùng do MRSA. Vancomycin vẫn là kháng sinh nền tảng trong điều trị nhiễm trùng nghi do MRSA theo kinh nghiệm vì đặc tính an toàn và độ hiệu quả của thuốc. Teicoplanin thường được sử dụng ở châu Âu và không thua kém vancomycin về tỉ lệ tử vong do mọi nguyên nhân, cải thiện được mức độ an toàn, tuy nhiên có ít bệnh nhân nhiễm trùng nặng được đưa vào nghiên cứu với kháng sinh này. Các glycopeptid có tốc độ diệt khuẩn chậm hơn các beta-lactam và khả năng thấm vào các mô kém [5].
Các khuyến cáo cho rằng tăng liều vancomycin để đạt nồng độ “đáy” thích hợp (nồng độ thuốc thấp nhất tại thời điểm trước khi dùng liều tiếp theo) có khả năng tối ưu tác dụng diệt khuẩn và hiệu quả trên lâm sàng. Hiệu quả diệt khuẩn thể hiện bằng kết quả nuôi cấy âm tính và cải thiện các dấu hiệu, triệu chứng của nhiễm trùng. Tối ưu hóa liệu pháp vancomycin dựa trên khả năng đạt được chỉ số AUC/MIC mục tiêu, đặc biệt với các chủng MRSA có MIC > 1 mcg/ml đang ngày càng gia tăng ở nhiều nơi được khuyến cáo. Tuy nhiên, nồng độ đáy cao có liên quan đến tăng nguy cơ độc thận và không cải thiện rõ ràng hiệu quả điều trị. Do đó, truyền tĩnh mạch liên tục vancomycin được thực hiện ở một số nước châu Âu. Với những nhiễm trùng do MRSA có MIC > 2 mcg/ml, vancomycin không còn hiệu quả, cần thay thế bằng thuốc khác. Khi MIC với vancomycin tăng cao nên cân nhắc chuyển đổi sang daptomycin sớm [5].
Các kháng sinh diệt MRSA khác ngày càng được sử dụng nhiều nhưng cần lưu ý về tác dụng phụ của thuốc, đặc biệt là linezolid (Phụ lục 1).
**_Liệu pháp kết hợp_**
Một thử nghiệm lâm sàng ở Hàn Quốc ở bệnh nhân viêm phổi MRSA đã chứng minh tính vượt trội của vancomycin phối hợp với rifampicin so với vancomycin dùng một mình [4]. Tuy nhiên, áp dụng phối hợp rộng rãi có thể dẫn đến gia tăng nhanh chóng đề kháng rifampicin. Hơn nữa, rifampicin có tương tác với nhiều loại thuốc thường được sử dụng ở những bệnh nhân nặng. Bằng chứng trên in vitro cho thấy tác dụng hiệp đồng kết hợp giữa beta-lactam, fluoroquinolon (như levofloxacin) và glycopeptid làm giảm tần suất vi khuẩn đột biến. Vai trò của các kết hợp kháng sinh hiệp đồng điều trị theo kinh nghiệm MRSA cần phải tiếp tục nghiên cứu trong các thử nghiệm lâm sàng [3].
**_Các vấn đề khác_**
Trái với nhiều loại nhiễm trùng khác, nhiễm tụ cầu (bao gồm cả MRSA) thường cần thời gian điều trị kéo dài do nguy cơ xảy ra các biến chứng muộn như áp xe, nhiễm trùng xương khớp. Với các nhiễm trùng huyết, thời gian điều trị tối thiểu là 14 ngày, liệu pháp ngắn hơn không được chứng minh là hiệu quả và an toàn. Các lựa chọn thay thế khác, dựa trên dữ liệu hiện có, gồm linezolid, trimethoprim–sulfamethoxazol, ceftaroline, quinupristin–dalfopristin và telavancin. Nên tránh dùng tigecyclin, do thuốc chỉ có tác dụng kìm khuẩn với MRSA và thể tích phân bố rộng với nồng độ trong mô cao nhưng nồng độ trong huyết tương thấp. Không có các dữ liệu về điều trị nhiễm trùng huyết do MRSA với các thuốc mới được công bố gần đây (như ceftobiprole, dalbavancin, oritavancin hoặc tedizolid) [5].
**Tài liệu tham khảo**
1. Dien Bard, J., et al., Rationale for eliminating Staphylococcus breakpoint for beta – lactam agents other than penicillin, oxacillin or cefoxitin and ceftaroline, Clin Infect Dis, 2014, 58(9): p. 1287-96.
2. Enright, M.C., et al., The evolutionary history of methicillin-resistant Staphylococcus aureus (MRSA), Proc Natl Acad Sci USA, 2002, 99 (11): p.7687-92.
3. Cao, B., et al., Consensus statement on the management of methicillin-resistant Staphylococcus aureus nosocomial pneumonia in Asia, Clin Respir J, 2015, 9(2): p.129-42.
4. Jung, Y.J., et al., Effect of vancomycin plus rifampicin in the treatment of nosocomial methicillin-resistant Staphylococcus aureus pneumonia, Crit Care Med, 2010, 38(1): p.175-80.
5. Andie S. Lee., et al., Methicillin-resistant Staphylococcus aureus, Nat Rev Dis Primers, 2018, 4:18033.

## Nấm chiếm cư: Candida auris

**CDC Hoa Kỳ lo ngại về C. auris vì ba lý do chính:**
- Thường kháng đa thuốc, có nghĩa là nó kháng nhiều loại thuốc kháng nấm thường được sử dụng để điều trị nhiễm trùng Candida. Một số chủng có khả năng chống lại cả ba loại thuốc kháng nấm hiện có.
- Rất khó để xác định bằng các phương pháp phòng thí nghiệm thông thường và nó có thể bị xác định sai trong phòng thí nghiệm nếu không có công nghệ đặc hiệu. Xác định sai có thể dẫn đến điều trị không đúng cách.
- Gây ra sự bùng phát trong các cơ sở y tế. Vì lý do này, điều quan trọng là phải nhanh chóng xác định C. auris ở bệnh nhân nhập viện để có thể thực hiện các biện pháp phòng ngừa đặc biệt nhằm ngăn chặn sự lây lan của nó cho môi trường xung quanh.
**Ai có nguy cơ nhiễm nấm Candida auris?**
C. auris thường ảnh hưởng đến những bệnh nhân đã mắc bệnh nghiêm trọng hoặc bị suy giảm miễn dịch và nó có thể ảnh hưởng đến bệnh nhân ở mọi lứa tuổi.
**Những bệnh nhân có nguy cơ nhiễm trùng cao nhất, gồm:**
- Đã nằm viện trong trong một thời gian dài
- Có đặt ống xâm lấn vào cơ thể
- Đã có sử dụng thuốc kháng sinh hoặc thuốc chống nấm
**Các triệu chứng của nấm Candida auris và các lựa chọn điều trị là gì?**
Bệnh nhân có các triệu chứng khác nhau, tùy thuộc vào vị trí hoặc loại nhiễm trùng nhưng thường bao gồm sốt và ớn lạnh không đáp ứng với thuốc kháng sinh.
Thuốc thường dùng điều trị là echinocandin. Nhưng một số chủng kháng lại cả ba loại thuốc chính, và có thể phải dùng với liều lượng cao hơn.
**Bạn có nên lo lắng về nấm Candida auris không?**
Nếu bạn khỏe mạnh, bạn không cần phải quá lo lắng. C. auris không gây nhiễm trùng ở những người khỏe mạnh. Để tránh nhiễm trùng Candida auris, cũng giống như khi ngăn ngừa sự lây lan của bất kỳ bệnh nhiễm trùng nào, hãy rửa tay bằng xà phòng và khử khuẩn bề mặt tiếp xúc với vi nấm Candida theo khuyến cáo của nhân viên y tế.
**Nguồn: Medicalxpress**
<https://medicalxpress.com/news/2023-03-deadly-fungal-infection-candida-auris.html>

## Truyền thông hưởng ứng Ngày Quốc tế phòng chống dịch bệnh (27/12) năm 2024


## ️ Xử lý rác thải y tế như thế nào?

  * [Một bệnh viện trung bình tạo ra bao nhiêu chất thải y tế?](https://bvnguyentriphuong.com.vn/kiem-soat-nhiem-khuan/xu-ly-rac-thai-y-te-nhu-the-nao#mt-bnh-vin-trung-bnhto-ra-bao-nhiu-cht-thi-y-t)
  * [Chất thải y tế nên được quản lý như thế nào?](https://bvnguyentriphuong.com.vn/kiem-soat-nhiem-khuan/xu-ly-rac-thai-y-te-nhu-the-nao#cht-thi-y-t-nn-c-qun-l-nh-th-no)
  * [Phân loại rác thải y tế](https://bvnguyentriphuong.com.vn/kiem-soat-nhiem-khuan/xu-ly-rac-thai-y-te-nhu-the-nao#phn-loi-rc-thi-y-t)
  * [Sử dụng thùng rác y tế như thế nào để phân loại rác thải](https://bvnguyentriphuong.com.vn/kiem-soat-nhiem-khuan/xu-ly-rac-thai-y-te-nhu-the-nao#s-dng-thng-rc-y-t-nh-th-no-phn-loi-rc-thi)


Chất thải y tế Căn cứ theo Điều 3 Thông tư Số: 20/2021/TT-BYT Quy định về quản lý chất thải y tế trong phạm vi khuôn viên cơ sở y tế là chất thải phát sinh từ hoạt động của cơ sở y tế, bao gồm chất thải y tế nguy hại, chất thải rắn thông thường, khí thải, chất thải lỏng không nguy hại và nước thải y tế. Chất thải lây nhiễm là chất thải thấm, dính, chứa máu của cơ thể hoặc chứa vi sinh vật gây bệnh. Thu gom chất thải y tế là quá trình tập hợp chất thải y tế từ nơi phát sinh về khu vực lưu giữ chất thải y tế tạm thời hoặc về nơi xử lý chất thải y tế trong phạm vi khuôn viên cơ sở y tế.
Xử lý và tiêu hủy chất thải y tế không đúng cách có nguy cơ lây truyền bệnh thứ cấp nghiêm trọng, vì những người thu gom rác, công nhân vệ sinh, nhân viên y tế, bệnh nhân và toàn bộ cộng đồng có thể tiếp xúc với các tác nhân lây nhiễm thông qua việc xử lý chất thải không đúng cách. Việc đốt và đốt lộ thiên mà không có biện pháp kiểm soát ô nhiễm thích hợp có thể khiến công nhân xử lý chất thải và cộng đồng xung quanh tiếp xúc với khí thải, tro có chứa các chất ô nhiễm độc hại.
## Một bệnh viện trung bình tạo ra bao nhiêu chất thải y tế?
Dựa theo dữ liệu điều tra về tỷ lệ phát sinh chất thải cho thấy các bệnh viện trên thế giới tạo ra khoảng 0,5 kg chất thải mỗi giường mỗi ngày. Tuy nhiên, số lượng và thành phần cơ bản của chất thải rất khác nhau tùy thuộc vào hoàn cảnh kinh tế, địa lý của từng địa phương. Ví dụ, các quốc gia có thu nhập cao tạo ra lượng chất thải nhựa cao hơn nhiều, chiếm hơn một nửa tổng số chất thải y tế. Do sự đa dạng của chất thải, không có giải pháp tốt nhất nào cho vấn đề về chất thải y tế.
Chất thải y tế có thể được phân loại theo cách phân loại chung sau: chất thải sắc nhọn, chất thải bệnh lý, chất thải lây nhiễm khác, chất thải dược phẩm, bao gồm chất thải gây độc tế bào, chất thải hóa học nguy hại, chất thải phóng xạ và chất thải thông thường (không nguy hiểm).
Thông thường 75 đến 90% chất thải do các cơ sở y tế tạo ra là chất thải thông thường không nguy hại, có thể so sánh với chất thải sinh hoạt. Chất thải lây nhiễm là chất thải nghi ngờ có chứa mầm bệnh (vi khuẩn gây bệnh, vi rút, ký sinh trùng hoặc nấm) với nồng độ hoặc số lượng đủ để gây bệnh cho vật chủ mẫn cảm.
## Chất thải y tế nên được quản lý như thế nào?
Xử lý chất thải y tế bao gồm 4 quy trình cơ bản: nhiệt, hóa học, bức xạ và sinh học. Tuy nhiên, một thực tế đáng tiếc trên toàn cầu là khối lượng lớn chất thải chăm sóc sức khỏe, bao gồm cả chất thải được tạo ra do đại dịch của chúng ta, hoặc được xử lý sai bằng cách sử dụng các công nghệ xử lý được bảo trì kém, hoặc không được xử lý hoàn toàn.
## Phân loại rác thải y tế
Phân loại là một yếu tố quan trọng trong việc quản lý chất thải y tế hiệu quả. Bằng cách tách chất thải nguy hại khỏi chất thải không nguy hại, lượng chất thải cần xử lý chuyên biệt có thể giảm đáng kể.
Các yếu tố khác của quản lý chất thải y tế bao gồm phân loại chất thải, giảm thiểu chất thải, chứa đựng, mã hóa màu sắc, dán nhãn, bảng chỉ dẫn, vận chuyển, lưu trữ, xử lý và thải bỏ lần cuối.
Tất nhiên, việc duy trì một hệ thống như vậy đòi hỏi phải được đào tạo liên tục, lập kế hoạch, lập ngân sách, giám sát, đánh giá, tài liệu và lưu trữ hồ sơ.
## Sử dụng thùng rác y tế như thế nào để phân loại rác thải
Màu sắc của bao bì, dụng cụ, thiết bị lưu chứa chất thải y tế theo quy định tại các khoản 3, khoản 4, khoản 5, khoản 6 Điều 6 Thông tư số 20 của Bộ Y Tế ban hành năm 2021.
- Rác thải y tế lây nhiễm sử dụng thùng rác màu vàng riêng rác thải dạng lỏng cần phải chứa trong túi kín hoặc dụng cụ lưu trữ chất lỏng và có nắp đậy kín đính kèm tên và kí hiệu.
- Chất thải nguy hại không lây nhiễm đựng trong thùng rác y tế màu đen.
- Chất thải rắn thông thường không thể tái chế đựng trong thùng rác màu xanh.
- Chất thải rắn thông thường có thể tái chế đựng trong túi hoặc thùng rác y tế màu trắng.
- Chất thải lỏng không nguy hại chứa trong thùng rác hoặc dụng cụ chứa chất lỏng, có nắp đậy kín kèm tên và kí hiệu.
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [Một bệnh viện trung bình tạo ra bao nhiêu chất thải y tế?](https://bvnguyentriphuong.com.vn/kiem-soat-nhiem-khuan/xu-ly-rac-thai-y-te-nhu-the-nao#mt-bnh-vin-trung-bnhto-ra-bao-nhiu-cht-thi-y-t)
  * [Chất thải y tế nên được quản lý như thế nào?](https://bvnguyentriphuong.com.vn/kiem-soat-nhiem-khuan/xu-ly-rac-thai-y-te-nhu-the-nao#cht-thi-y-t-nn-c-qun-l-nh-th-no)
  * [Phân loại rác thải y tế](https://bvnguyentriphuong.com.vn/kiem-soat-nhiem-khuan/xu-ly-rac-thai-y-te-nhu-the-nao#phn-loi-rc-thi-y-t)
  * [Sử dụng thùng rác y tế như thế nào để phân loại rác thải](https://bvnguyentriphuong.com.vn/kiem-soat-nhiem-khuan/xu-ly-rac-thai-y-te-nhu-the-nao#s-dng-thng-rc-y-t-nh-th-no-phn-loi-rc-thi)



## An toàn và Kiểm soát Nhiễm khuẩn trong Gây mê

**Nhiễm khuẩn mắc phải trong chăm sóc y tế (HAI)** là một trong những nguyên nhân hàng đầu gây bệnh tật, tử vong và tăng chi phí điều trị trong các cơ sở y tế. Theo CDC, cứ 31 bệnh nhân nằm viện ở Hoa Kỳ thì có ít nhất một người mắc một loại HAI. Các dạng thường gặp bao gồm: nhiễm khuẩn huyết liên quan catheter trung tâm, nhiễm khuẩn tiết niệu liên quan catheter, nhiễm khuẩn liên quan máy thở và nhiễm khuẩn vết mổ (SSI).
Nhân viên gây mê giữ vai trò then chốt trong kiểm soát nhiễm khuẩn vì tiếp xúc thường xuyên với thuốc, thiết bị xâm lấn, và đường thở. Việc thực hành vô khuẩn đúng cách giúp giảm tỷ lệ tử vong, rút ngắn thời gian nằm viện và nâng cao chất lượng chăm sóc.
**1. Các biện pháp phòng ngừa chuẩn**
• Vệ sinh tay đúng cách bằng xà phòng và nước hoặc dung dịch cồn
• Sử dụng găng tay khi tiếp xúc với dịch tiết, máu, thiết bị
• Mặc đầy đủ áo choàng, mũ, khẩu trang, kính bảo hộ
• Khử khuẩn bề mặt thiết bị gây mê, bàn thao tác, bơm tiêm
• Xử lý vật sắc nhọn đúng quy định
**2. Phòng ngừa theo đường lây truyền**
a. Tiếp xúc: đeo găng tay và áo choàng khi chăm sóc bệnh nhân nhiễm trùng da, tiêu chảy, vi khuẩn đa kháng
b. Giọt bắn: đeo khẩu trang y tế khi tiếp xúc gần với bệnh nhân cúm, ho gà, bạch hầu
c. Không khí: sử dụng N95 hoặc PAPR và cách ly tại phòng áp lực âm trong bệnh lao, COVID-19, sởi, thủy đậu
**3. Vệ sinh tay**
5 thời điểm theo WHO:
1. Trước khi tiếp xúc bệnh nhân
2. Trước thủ thuật vô khuẩn
3. Sau khi tiếp xúc dịch cơ thể
4. Sau khi tiếp xúc bệnh nhân
5. Sau khi tiếp xúc môi trường xung quanh
Phương pháp:
• Xà phòng và nước: khi tay bẩn
• Dung dịch cồn: khi tay không bẩn rõ ràng
• Sát khuẩn tay phẫu thuật: đến khuỷu tay trước thủ thuật vô khuẩn
**4. Khử khuẩn môi trường gây mê**
• Lau sạch và khử khuẩn bề mặt thiết bị tiếp xúc nhiều như bàn máy, công tắc, màn hình
• Sử dụng bọc nhựa một lần cho thiết bị khó làm sạch
• Dụng cụ tái sử dụng phải khử khuẩn mức độ cao hoặc tiệt trùng
**5. Quản lý đường thở an toàn**
• Đeo găng tay kép khi đặt nội khí quản, bỏ lớp ngoài sau khi thao tác xong
• Ưu tiên thiết bị dùng một lần
• Thiết bị tái sử dụng phải được khử khuẩn/tiệt trùng đúng quy trình
• Mang kính chắn giọt, khẩu trang N95 khi có nguy cơ tạo khí dung
**6. Xử lý thuốc gây mê và thuốc tiêm**
• Lau sạch nắp lọ thuốc bằng cồn 70% trước khi rút
• Ưu tiên dùng lọ đơn liều
• Không bao giờ tái sử dụng kim hoặc ống tiêm
• Đậy nắp kim tiêm sau mỗi lần sử dụng
• Loại bỏ vật sắc nhọn vào hộp chống đâm xuyên
**7. Thủ thuật xâm lấn vô khuẩn**
• Sát khuẩn da bằng chlorhexidine trong cồn, để khô trước thao tác
• Mặc trang phục vô khuẩn đầy đủ: áo choàng, găng tay, mũ, khẩu trang, kính
• Dùng màn phủ vô khuẩn toàn thân
• Dán băng vô khuẩn, thay khi bẩn, bong, hoặc định kỳ
• Theo dõi dấu hiệu viêm tại vị trí thủ thuật
**8. Các biện pháp bổ sung nâng cao**
• Ngưng hút thuốc trước mổ ≥4 tuần
• Duy trì thân nhiệt, đường huyết ổn định trong phẫu thuật
• Tiêm kháng sinh dự phòng đúng lúc, đúng loại
• Áp dụng ERAS: phục hồi sớm sau mổ (ăn sớm, vận động sớm, giảm opioid)
• Ứng dụng công nghệ: cảm biến vô khuẩn, máy pha thuốc kín, hệ thống giám sát tiệt trùng
**Kết luận**
Kiểm soát nhiễm khuẩn là một mắt xích thiết yếu trong quy trình gây mê an toàn. Nhân viên gây mê với vai trò chủ đạo trong tiếp cận đường thở, thuốc và thiết bị y tế – cần tuân thủ nghiêm ngặt các biện pháp phòng ngừa chuẩn và chuyên biệt. Lồng ghép giáo dục kiểm soát nhiễm khuẩn vào đào tạo gây mê là bước đi chiến lược nhằm nâng cao chất lượng chăm sóc và bảo vệ sức khỏe cộng đồng y tế.
**Phụ lục các từ viết tắt**
• HAI – Healthcare-Associated Infection: Nhiễm khuẩn mắc phải trong chăm sóc y tế
• SSI – Surgical Site Infection: Nhiễm khuẩn tại vị trí phẫu thuật
• ICU – Intensive Care Unit: Khoa hồi sức tích cực
• OR – Operating Room: Phòng mổ
• PAPR – Powered Air-Purifying Respirator: Thiết bị lọc khí áp lực dương
• N95 – N95 Respirator Mask: Khẩu trang lọc 95% hạt nhỏ
• CHG – Chlorhexidine Gluconate: Dung dịch sát khuẩn
• IPA – Isopropyl Alcohol: Cồn isopropyl
• ABHR – Alcohol-Based Hand Rub: Dung dịch rửa tay chứa cồn
• DSA – Digital Subtraction Angiography: Chụp mạch xóa nền kỹ thuật số
• C-arm – C-shaped Imaging Device: Máy chụp hình di động hình chữ C
• ERAS – Enhanced Recovery After Surgery: Chương trình phục hồi sớm sau phẫu thuật
• CDC – Centers for Disease Control and Prevention: Trung tâm Kiểm soát và Phòng ngừa Dịch bệnh Hoa Kỳ
• WHO – World Health Organization: Tổ chức Y tế Thế giới
**Tài liệu tham khảo**
1. Provenzano, D. A., et al. (2025). ASRA Infection Control Guidelines. Reg Anesth Pain Med. <https://doi.org/10.1136/rapm-2024-105651>
2. American Society of Anesthesiologists (ASA). (2025). Infection Prevention Resources. <https://www.asahq.org>
3. American Association of Nurse Anesthetists (AANA). (2024). Infection Control Guidelines. <https://www.aana.com>
4. Loftus, R. W., et al. (2024). Hand hygiene in anesthesia practice. Am J Infect Control.
5. Sharma, A., et al. (2020). Infection Control and Anesthesia. Curr Anesthesiol Rep.

## Ngày hội vệ sinh tay năm 2023

Năm 2008, Liên Hợp quốc đã chọn ngày 15 tháng 10 hàng năm là ngày “Thế giới rửa tay - Global handwashing day” nhằm nâng cao nhận thức về tầm quan trọng của việc rửa tay bằng xà phòng như là một phương pháp dễ dàng và hiệu quả để phòng ngừa bệnh. 
Để có được những thành tựu về vệ sinh tay như ngày hôm nay, ngành y tế đã trải qua cả một quá trình dài, đánh đổi nhiều thời gian và công sức. 
Tiếp lời kêu gọi của WHO, Chủ đề cho Ngày Thế giới rửa tay năm 2023 tại Bệnh viện Nguyễn Tri Phương là **"DUY TRÌ VÀ TĂNG TỐC “HÃY VỆ SINH TAY ĐỂ BẢO VỆ CUỘC SỐNG"**
Đến với Ngày hội vệ sinh tay tại Bệnh viện Nguyễn Tri Phương hôm nay có sự tham dự phía khách mời là Phó Giáo sư Tiến sĩ Bác sĩ Lê Thị Anh Thư - Chủ tịch Hội Kiểm soát nhiễm khuẩn Việt Nam
và phía bệnh viện có sự tham dự của Ban Giám đốc Bệnh viện và lãnh đạo Khoa Kiểm soát nhiễm khuẩn bệnh viện cùng các lãnh đạo khoa/phòng, các điều dưỡng và đồng nghiệp của Bệnh viện Nguyễn Tri Phương.
Đồng hành với bệnh viện không thể không nhắc đến sự hỗ trợ không ngừng của các nhà tài trợ, đã luôn ủng hộ và giúp đỡ cho bệnh viện trong công tác kiểm soát nhiễm khuẩn và đặc biệt là trong ngày phát động phong trào vệ sinh tay năm nay. Đó là các công ty VietMedical, Lavitec và 3M.
Nhằm tạo không khí thêm sôi động cho ngày hội vệ sinh tay đó là vũ điệu "Please Hand Washing".
Qua báo cáo vệ sinh tay năm 2023 của Bác sĩ chuyên khoa II Hồ Đắc Phương - Phó trưởng khoa Kiểm soát nhiễm khuẩn cho thấy việc tuân thủ thực hành vệ sinh tay ngày càng tốt hơn. Trong đó cũng chỉ ra được các khoa có tỷ lệ vệ sinh tay cao nhất trong năm và khuyến khích các khoa tiếp tục nâng cao, tăng tỷ lệ thực hành vệ sinh tay tốt hơn nữa. Đồng thời tuyên dương các khoa có thành tích tốt nhất trong năm.
Đại diện Đoàn thanh niên Bệnh viện Nguyễn Tri Phương, Bác sĩ Bùi Anh Triết - Phó Bí thư Đoàn nêu cao khẫu hiệu, phát động phong trào vệ sinh tay.
Thay đổi so với các năm về trước, Nghi thức cam kết thực hiện vệ sinh tay của bệnh viện được thực hiện qua hình thức dán biểu tượng lên bức tranh về cây xanh như một hành động cam kết.
**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/)** - Đa khoa Hạng I Thành phố Hồ Chí Minh

## Quản lý chất thải rắn y tế trong khuôn viên cơ sở y tế

**_Chất thải rắn y tế là gì?_**
Chất thải y tế là chất thải phát sinh từ hoạt động của cơ sở y tế, bao gồm chất thải y tế nguy hại (bao gồm chất thải lây nhiễm và không lây nhiễm) và chất thải rắn thông thường.
**_Chất thải nguy hại lây nhiễm_**
Chất thải lây nhiễm sắc nhọn bao gồm kim tiêm, bơm liền kim tiêm, đầu sắc nhọn của dây truyền, kim chọc dò, kim châm cứu, lưỡi dao mổ, đinh, cưa dùng trong phẫu thuật, các ống tiêm, mảnh thủy tinh vỡ...
Chất thải lây nhiễm không sắc nhọn bao gồm bông, băng, gạc, găng tay, các chất thải không sắc nhọn khác thấm, dính, chứa máu của cơ thể, chứa vi sinh vật gây bệnh; vỏ lọ vắc xin thuộc loại vắc xin...
**_Chất thải có nguy cơ lây nhiễm_** cao bao gồm mẫu bệnh phẩm, dụng cụ đựng, dính mẫu bệnh phẩm, chất thải dính mẫu bệnh phẩm thải bỏ từ các phòng xét nghiệm tương đương an toàn sinh học cấp II trở lên; các chất thải phát sinh từ buồng bệnh cách ly, khu vực điều trị cách ly...
Chất thải giải phẫu bao gồm mô, bộ phận cơ thể người thải bỏ, xác động vật thí nghiệm.
Chất thải nguy hại không lây nhiễm bao gồm hóa chất thải bỏ có thành phần, tính chất nguy hại vượt ngưỡng chất thải nguy hại; dược phẩm thải bỏ thuộc nhóm gây độc tế bào; vỏ chai, lọ đựng thuốc, hoá chất; thiết bị y tế bị vỡ, hỏng, đã qua sử dụng thải bỏ có chứa thủy ngân, cadimi (Cd); pin, ắc quy thải bỏ; vật liệu tráng chì sử dụng trong ngăn tia xạ thải bỏ.....
**_Chất thải rắn thông thường_** là phát sinh từ hoạt động sinh hoạt thường ngày của nhân viên y tế, người bệnh, người nhà người bệnh, các chất thải ngoại cảnh trong cơ sở y tế (trừ chất thải sinh hoạt phát sinh từ khu vực cách ly, điều trị người mắc bệnh truyền nhiễm nguy hiểm)...
**_Phân loại chất thải rắn y tế_**
**_Chất thải rắn y tế nguy hại lây nhiễm_**
Chất thải lây nhiễm sắc nhọn: bỏ vào trong thùng hoặc hộp kháng thủng và có màu vàng.
Chất thải lây nhiễm không sắc nhọn: bỏ vào trong thùng có lót túi và có màu vàng.
Chất thải có nguy cơ lây nhiễm cao: bỏ vào trong thùng có lót túi và có màu vàng.
Chất thải giải phẫu: bỏ vào trong 2 lần túi hoặc trong thùng có lót túi và có màu vàng.
**_Chất thải rắn nguy hại không lây nhiễm_**
Chất thải nguy hại phải được phân loại theo mã chất thải nguy hại để lưu giữ trong các bao bì, dụng cụ, thiết bị lưu chứa phù hợp. Được sử dụng chung bao bì, dụng cụ, thiết bị lưu chứa đối với các chất thải nguy hại có cùng tính chất, không có khả năng gây phản ứng, tương tác lẫn nhau và có khả năng xử lý bằng cùng một phương pháp.
Chất thải rắn nguy hại không lây nhiễm đựng trong túi hoặc thùng hoặc thùng có lót túi và có màu đen.
**_Chất thải rắn thông thường_**
Chất thải rắn thông thường không sử dụng để tái chế: đựng trong túi hoặc thùng hoặc thùng có lót túi và có màu xanh. Chất thải sắc nhọn đựng trong dụng cụ kháng thủng.
Chất thải rắn thông thường sử dụng để tái chế: đựng trong túi hoặc thùng hoặc thùng có lót túi và có màu trắng.
**_Thu gom chất thải rắn y tế_**
Cơ sở y tế quy định luồng đi và thời điểm thu gom chất thải lây nhiễm phù hợp để hạn chế ảnh hưởng đến khu vực chăm sóc người bệnh và khu vực khác trong cơ sở y tế.
Chất thải lây nhiễm phải thu gom riêng từ nơi phát sinh về khu vực lưu giữ chất thải tạm thời trong cơ sở y tế. Trước khi thu gom, túi đựng chất thải phải buộc kín miệng, thùng đựng chất thải phải có nắp đậy kín.
Chất thải rắn thông thường sử dụng để tái chế và chất thải rắn thông thường không sử dụng để tái chế được thu gom riêng.
**_Lưu giữ chất thải rắn y tế_**
Từng loại chất thải phải được lưu giữ riêng tại khu vực lưu giữ chất thải tạm thời trong khuôn viên cơ sở y tế, trừ trường hợp các loại chất thải này có cùng tính chất, không có khả năng gây phản ứng, tương tác lẫn nhau và có khả năng xử lý bằng cùng một phương pháp.

## Dấu hiệu nhận biết và cách phòng ngừa Bệnh đau mắt đỏ


## Ngày hội vệ sinh tay năm 2022 tại BV Nguyễn Tri Phương

Khi các cơ sở y tế coi trọng việc vệ sinh tay và phòng chống nhiễm khuẩn (ICP) sẽ giúp bệnh nhân và cả nhân viên y tế đều cảm thấy được bảo vệ và chăm sóc. Để ưu tiên bàn tay sạch trong các cơ sở y tế, tất cả mọi người cần tin tưởng vào tầm quan trọng của vệ sinh tay và IPC để cứu mạng sống. Nói cách khác, cán bộ y tế các cấp và người dân khi tiếp cận với cơ sở y tế cần đoàn kết trong việc đảm bảo bàn tay sạch.
Chủ đề của Ngày vệ sinh tay tập trung vào việc công nhận rằng chúng ta có thể đảm bảo môi trường hoặc văn hóa cơ sở trở nên an toàn và có chất lượng thông qua việc làm sạch bàn tay vào đúng thời điểm phù hợp. Đoàn kết, kêu gọi và hành động cùng nhau về vệ sinh tay để việc chăm sóc sức khỏe trở nên an toàn hơn và có chất lượng cao ở mọi nơi. Chủ đề năm 2022 cùa WHO cho ngày VST toàn cầu 15/10 "ĐOÀN KẾT VÌ SỰ AN TOÀN: HÃY VỆ SINH TAY"
Với sự tham mưu và chuẩn bị chu đáo từ khoa Kiểm soát nhiễm khuẩn, Ban Giám đốc BV cùng lãnh đạo các khoa, phòng trong Bệnh viện đã cùng nhau tổ chức thành công Ngày Vệ sinh tay của Bệnh viện năm 2022 với sự tham gia của các vị khách quý:
  * BS CK2 Nguyễn Hữu Hưng, Phó Giám đốc SYT Tp.HCM
  * PGS.TS Lê Thị Anh Thư, Chủ tịch Hội Kiểm soát nhiễm khuẩn Việt Nam


**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh

## ️ Các loại khẩu trang bảo vệ chúng ta trong dịch Covid như thế nào

  * [1. Các loại khẩu trang bảo vệ chống lại COVID-19 như thế nào?](https://bvnguyentriphuong.com.vn/kiem-soat-nhiem-khuan/cac-loai-khau-trang-bao-ve-chung-ta-trong-dich-covid-nhu-the-nao#1-cc-loi-khu-trang-bo-v-chng-li-covid19-nh-th-no)
  * [Khẩu trang vải:](https://bvnguyentriphuong.com.vn/kiem-soat-nhiem-khuan/cac-loai-khau-trang-bao-ve-chung-ta-trong-dich-covid-nhu-the-nao#khu-trang-vi)
  * [Khẩu trang y tế:](https://bvnguyentriphuong.com.vn/kiem-soat-nhiem-khuan/cac-loai-khau-trang-bao-ve-chung-ta-trong-dich-covid-nhu-the-nao#khu-trang-y-t)
  * [Khẩu trang N95:](https://bvnguyentriphuong.com.vn/kiem-soat-nhiem-khuan/cac-loai-khau-trang-bao-ve-chung-ta-trong-dich-covid-nhu-the-nao#khu-trang-n95)
  * [* Còn tấm che mặt thì sao?](https://bvnguyentriphuong.com.vn/kiem-soat-nhiem-khuan/cac-loai-khau-trang-bao-ve-chung-ta-trong-dich-covid-nhu-the-nao#-cn-tm-che-mt-th-sao)
  * [2. Cách đeo và tháo gỡ khẩu trang đúng cách](https://bvnguyentriphuong.com.vn/kiem-soat-nhiem-khuan/cac-loai-khau-trang-bao-ve-chung-ta-trong-dich-covid-nhu-the-nao#2-cch-eo-v-tho-g-khu-trang-ng-cch)
  * [Đeo khẩu trang:](https://bvnguyentriphuong.com.vn/kiem-soat-nhiem-khuan/cac-loai-khau-trang-bao-ve-chung-ta-trong-dich-covid-nhu-the-nao#eo-khu-trang)
  * [Tháo gỡ khẩu trang:](https://bvnguyentriphuong.com.vn/kiem-soat-nhiem-khuan/cac-loai-khau-trang-bao-ve-chung-ta-trong-dich-covid-nhu-the-nao#tho-g-khu-trang)


## 1. Các loại khẩu trang bảo vệ chống lại COVID-19 như thế nào?
Đứng trước tình hình dịch bệnh phức tạp, khẩu trang bảo vệ chống lại COVID-19 như thế nào là vấn đề luôn được mọi người quan tâm. Trên thị trường có nhiều loại khẩu trang tương ứng với các công dụng khác nhau. Dưới đây là một số loại khẩu trang thường được sử dụng trong cuộc sống sinh hoạt và lĩnh vực y tế:
### **Khẩu trang vải:**
Khẩu trang vải là loại khẩu trang được sản xuất từ vải bông hoặc pha bông. Chúng gồm 2 - 3 lớp vải dệt chặt lại với nhau. 
Tổ chức Y tế Thế giới khuyến nghị ba lớp bao gồm:
  * một lớp vật liệu thấm hút bên trong như vải cotton
  * một lớp ở giữa làm từ vật liệu vải không dệt như vải lọc từ chất liệu polypropylene
  * một lớp bên ngoài bằng vật liệu không thấm hút, chẳng hạn như polyester hoặc hỗn hợp polyester


Một chiếc khẩu trang vải đạt chuẩn cần đạt các tiêu chí sau:
  * Khi đưa ra nguồn sáng, khẩu trang phải chắn được ánh sáng.
  * Khẩu trang gồm nhiều lớp có khả năng ngăn chặn các giọt bắn, dịch tiết từ đường hô hấp khi người đối diện nói chuyện, ho, hắt hơi,…
  * Khẩu trang ôm sát khuôn mặt và đảm bảo độ thông thoáng.


### **Khẩu trang y tế:**
Khẩu trang y tế không được làm từ vải và không thể giặt nên chỉ được sử dụng một lần duy nhất. Loại khẩu trang này gồm 3 lớp ứng với những công dụng khác nhau. Vậy, khẩu trang bảo vệ chống lại COVID-19 như thế nào? 
Lớp màu xanh hoặc vàng ở ngoài cùng có thể chống thấm nước, giúp ngăn chặn các giọt bắn khi người đối diện ho, hắt xì,… Không chỉ vậy, lớp màu này còn giúp bạn dễ dàng phân biệt với lớp trong.
Lớp phía trong, có đặc tính mịn màng và không xù lông để tránh gây khó chịu khi áp sát vào khuôn mặt. Đồng thời, lớp này còn có khả năng thấm hút mồ hôi nhanh, giúp người dùng cảm thấy thoải mái dễ chịu.
Với tác dụng lọc bụi và các vi khuẩn có kích thước nhỏ, lớp giữa của khẩu trang có vai trò quan trọng trong bảo vệ, chống dịch COVID-19. Để đảm bảo an toàn, bạn nên chọn loại khẩu trang vừa vặn với khuôn mặt, không hở hai bên, đặc biệt là phải che kín mũi và miệng. Nếu khẩu trang bị ướt hoặc bẩn thì bạn không nên sử dụng lại. Bởi vì, chúng có thể bị nhiễm vi khuẩn từ môi trường bên ngoài.
### **Khẩu trang N95:**
Khẩu trang N95 có thể lọc được bụi và vi khuẩn có kích thước 0.3 micro. Do đó, khẩu trang này có khả năng bảo vệ, ngăn chặn virus SARS-CoV-2. Để mang lại hiệu quả, các nhân viên y tế sẽ được đào tạo và kiểm tra về cách sử dụng. Ngoài ra, đối với một số loại khẩu trang N95 trong cấu tạo còn có van khí giúp người dùng có thể thở qua dễ dàng.
Để tránh tình trạng thiếu hụt khẩu trang nghiêm trọng, bạn nên sử dụng khẩu trang vải và các loại khẩu trang y tế thông thường. Đối với những người làm trong lĩnh vực y tế hoặc tiếp xúc với người bệnh thì mới cần thiết dùng khẩu trang N95.
- Ở Việt Nam thường gọi là khẩu trang N95, nhưng với tiếng Anh là N95 respirator (chứ không phải mask) thì từ chính xác hơn nên gọi là "mặt nạ N95".
- Chữ cái đầu tiên để phân loại mặt nạ. Chữ “N” có nghĩa mặt nạ “Không kháng dầu” (“Not oil resistant”).
- N95 nghĩa là có hiệu quả 95% về hiệu quả lọc đối với các hạt có kích thước 0,3 micron. Ngoài 95%, mặt nạ còn được đánh giá hiệu quả ở mức 99% hoặc 100%. Kích thước 0,3 micron được chọn là vì đó là kích thước mà vật liệu trở nên kém hiệu quả.
- Các hạt được lọc bằng hai phương pháp chính.
+ Các hạt lớn hơn 0,3 micron được giữ lại bởi các sợi vải. Tuy nhiên, khi kích thước hạt càng nhỏ, hiệu quả của phương pháp này càng kém đi.
+ Vì vậy, chúng được lọc bằng phương pháp thứ hai, sử dụng điện tích tĩnh điện trên các sợi vải, thông qua quá trình chuyển động Brown (các hạt nhỏ hoạt động giống như các chất khí hơn là chất rắn). Kích thước càng lớn, chuyển động Brown càng kém hiệu quả.
+ Do đó, hiệu quả lọc các hạt lớn hoặc nhỏ hơn 0,3 micron cao hơn nhiều so với các hạt 0,3 micron.
### *** Còn tấm che mặt thì sao?**
Tấm chắn giúp bảo vệ mắt, nhưng không giống như khẩu trang khi bảo vệ khỏi các giọt bắn. Tuy nhiên, đối với những người gặp khó khăn trong việc đeo khẩu trang thông thường (ví dụ như những người bị khiếm khuyết về nhận thức, hô hấp hoặc thính giác), tấm che mặt có thể được coi là một giải pháp thay thế. Nếu bạn chọn sử dụng, hãy đảm bảo rằng nó che được hai bên mặt và dưới cằm của bạn.
## 2. Cách đeo và tháo gỡ khẩu trang đúng cách
Để phát huy hiệu quả bảo vệ và giảm thiểu nguy cơ lây nhiễm dịch bệnh, bạn nên sử dụng khẩu trang đúng cách. Dưới đây là các bước đeo và tháo gỡ khẩu trang do Bộ Y tế khuyến cáo: 
### **Đeo khẩu trang:**
Để hạn chế vi khuẩn từ tay nhiễm vào khẩu trang, trước khi đeo bạn nên rửa tay sạch sẽ với xà phòng hoặc dung dịch sát trùng. Đối với khẩu trang y tế dùng một lần, bạn nên đeo mặt có màu ra ngoài và điều chỉnh kẹp nhôm ôm sát vào mũi, không để hở phần phía trên.
Sau khi đeo mũi, miệng phải được che kín hoàn toàn, đồng thời không để hở hai bên má. Bởi vì, nếu có khoảng hở thì dịch tiết có thể rơi vào trong hoặc phát tán ra ngoài, làm lây lan dịch bệnh. 
Trong quá trình sử dụng, bạn không nên dùng tay sờ vào bề mặt khẩu trang, nhất là mặt trong. Đồng thời, khi đang ở nơi công cộng, bạn cũng không nên cởi bỏ khẩu trang để nói chuyện, ho, hắt hơi,… 
### **Tháo gỡ khẩu trang:**
Khi tháo khẩu trang, bạn nên cầm vào dây đeo qua tai hoặc sau đầu rồi tháo bỏ cẩn thận. Tiếp theo, gấp hai bên mép khẩu trang lại với nhau sau đó vứt vào thùng rác có nắp đậy đối với khẩu trang y tế. Ngược lại đối với khẩu trang vải, bạn có thể giặt sạch bằng xà phòng sau mỗi lần sử dụng.
Trong suốt quá trình tháo khẩu trang: bạn không nên chạm tay vào mắt, mũi, miệng,… Sau khi tháo xong, bạn nên rửa tay sạch sẽ để loại bỏ mầm bệnh.
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [1. Các loại khẩu trang bảo vệ chống lại COVID-19 như thế nào?](https://bvnguyentriphuong.com.vn/kiem-soat-nhiem-khuan/cac-loai-khau-trang-bao-ve-chung-ta-trong-dich-covid-nhu-the-nao#1-cc-loi-khu-trang-bo-v-chng-li-covid19-nh-th-no)
  * [Khẩu trang vải:](https://bvnguyentriphuong.com.vn/kiem-soat-nhiem-khuan/cac-loai-khau-trang-bao-ve-chung-ta-trong-dich-covid-nhu-the-nao#khu-trang-vi)
  * [Khẩu trang y tế:](https://bvnguyentriphuong.com.vn/kiem-soat-nhiem-khuan/cac-loai-khau-trang-bao-ve-chung-ta-trong-dich-covid-nhu-the-nao#khu-trang-y-t)
  * [Khẩu trang N95:](https://bvnguyentriphuong.com.vn/kiem-soat-nhiem-khuan/cac-loai-khau-trang-bao-ve-chung-ta-trong-dich-covid-nhu-the-nao#khu-trang-n95)
  * [* Còn tấm che mặt thì sao?](https://bvnguyentriphuong.com.vn/kiem-soat-nhiem-khuan/cac-loai-khau-trang-bao-ve-chung-ta-trong-dich-covid-nhu-the-nao#-cn-tm-che-mt-th-sao)
  * [2. Cách đeo và tháo gỡ khẩu trang đúng cách](https://bvnguyentriphuong.com.vn/kiem-soat-nhiem-khuan/cac-loai-khau-trang-bao-ve-chung-ta-trong-dich-covid-nhu-the-nao#2-cch-eo-v-tho-g-khu-trang-ng-cch)
  * [Đeo khẩu trang:](https://bvnguyentriphuong.com.vn/kiem-soat-nhiem-khuan/cac-loai-khau-trang-bao-ve-chung-ta-trong-dich-covid-nhu-the-nao#eo-khu-trang)
  * [Tháo gỡ khẩu trang:](https://bvnguyentriphuong.com.vn/kiem-soat-nhiem-khuan/cac-loai-khau-trang-bao-ve-chung-ta-trong-dich-covid-nhu-the-nao#tho-g-khu-trang)



## ️ Nhiễm trùng hậu phẫu: Tổng quan và xử trí

  * [Trước phẫu thuật](https://bvnguyentriphuong.com.vn/kiem-soat-nhiem-khuan/nhiem-trung-hau-phau-tong-quan-va-xu-tri#trc-phu-thut)


Một trong những tiến bộ lớn nhất của ngoại khoa ở thế kỷ 20 là tìm ra giải pháp làm giảm nguy cơ nhiễm trùng trong và sau phẫu thuật. Bất kỳ thủ thuật ngoại khoa nào, dù nhỏ, đều có nguy cơ nhiễm trùng. Vì vậy giảm thiểu nguy cơ nhiễm trùng đòi hỏi những áp dụng triệt để về kiểm soát nhiễm khuẩn
Thuật ngữ nhiễm trùng vết mổ đề cập đến vấn đề nhiễm khuẩn ở vết thương phẫu thuật, tính từ lúc tiến hành cho đến:
  * 1 tháng sau đó đối với phẫu thuật thông thường
  * 1 năm sau đó đối với phẫu thuật cấy ghép nội tạng hoặc bất kỳ bộ phận nhân tạo nào khác


Hiện nay, thường phân loại tình trạng này thành ba nhóm khác nhau gồm:
  * Nhiễm trùng vết mổ nông: liên quan đến da và các bộ phận ngay bên dưới da
  * Nhiễm trùng vết mổ sâu: vi khuẩn từ vết mổ tấn công sâu vào lớp mô mềm (cân cơ)
  * Nhiễm trùng tại cơ quan hoặc khoang phẫu thuật


Các thủ thuật đơn giản, như đưa kim vào khớp để tháo dịch hay bơm thuốc, có rất ít nguy cơ. Các cuộc mổ phức tạp hơn với đường mổ lớn hơn và mở da trong thời gian dài có nguy cơ cao hơn. Các phẫu thuật đưa vật vào cơ thể, như khung kim loại hoặc khớp nhân tạo, phải được thực hiện cẩn thận để đảm bảo các vật ngoại lai đặt vào trong cơ thể không mang theo vi khuẩn. Phòng ngừa nhiễm trùng là một trong những **khâu quan trọng nhất của mọi cuộc phẫu thuật.** Tất cả các nhân viên y tế đều theo dõi phòng ngừa nhiễm trùng rất sát sao.
Phòng ngừa nhiễm trùng **bắt đầu từ trước cuộc mổ**. Bác sĩ sẽ đảm bảo là không có nhiễm trùng nào hiện diện có thể làm ảnh hưởng đến cuộc phẫu thuật. Nếu bạn có nhiễm trùng da, viêm bàng quang, hay bất kì nhiễm trùng nào khác, cuộc mổ sẽ hoãn cho đến khi nhiễm trùng được điều trị và kiểm soát tốt.
## **Trước phẫu thuật**
Buổi sáng trước phẫu thuật, người bệnh sẽ được yêu cầu tắm với xà phòng kháng khuẩn để giảm số lượng vi khuẩn trên da. Trước khi cuộc phẫu thuật bắt đầu, vùng da xung quanh vết mổ sẽ được làm sạch và vô trùng với thuốc khử trùng, như là iodine. Trước phẫu thuật, bác sĩ có thể sẽ kê đơn uống kháng sinh nếu cần thiết (điều này không áp dụng cho tất cả các loại phẫu thuật). Các cuộc mổ có nguy cơ nhiễm trùng thấp thường không cần uống kháng sinh dự phòng và nhiều ca phẫu thuật lớn cần dùng kháng sinh - đặc biệt là những ca đặt vật liệu nhân tạo vào trong cơ thể.
Trong quá trình phẫu thuật, đội ngũ nhân viên y tế luôn đảm bảo toàn bộ cuộc phẫu thuật được thực hiện trong điều kiện vô trùng. Phẫu thuật được thực hiện trong phòng vô trùng được thiết kể để tránh lây nhiễm. Tất cả dụng cụ cần cho phẫu thuật đều vô trùng.
Vết mổ được băng lại trong điều kiện vô trùng trước khi người bệnh rời khỏi phòng mổ. Băng gạc là hàng rào quan trọng ngăn chặn nhiễm trùng cho đến khi đường mổ tự liền hẳn, thường trong vài ngày đầu tiên. Nếu vết mổ vẫn còn rỉ dịch, đó có thể là con đường để vi trùng thâm nhập vào vết thương. Băng gạc sẽ được giữ cho đến khi vết thương ngừng rỉ dịch và lành hoàn toàn.
**Những vấn đề trước phẫu thuật cần lưu ý bao gồm những nguyên tắc chung:**
  * **Tắm khử khuẩn cho người bệnh trước phẫu thuật;**
  * **Loại bỏ lông và chuẩn bị vùng rạch da đúng quy định;**
  * **Khử khuẩn tay ngoại khoa và thường quy bằng dung dịch rửa tay chứa cồn;**
  * **Áp dụng đúng liệu pháp kháng sinh dự phòng**
  * **Tuân thủ chặt chẽ quy trình vô khuẩn trong buồng phẫu thuật**
  * **Duy trì tốt các điều kiện vô khuẩn khu phẫu thuật như dụng cụ, đồ vải phẫu thuật, nước vô khuẩn để rửa tay ngoại khoa và đảm bảo thông khí sạch trong buồng phẫu thuật.**


## **Sau phẫu thuật**
Sau phẫu thuật, có thể tiếp tục **dùng kháng sinh trong 24 đến 72 giờ**. Điều này giúp giảm khả năng nhiễm trùng vết mổ.
Khi còn ở trong bệnh viện, nhân viên y tế sẽ đảm bảo băng gạc vết mổ luôn khô và sạch. Băng gạc thấm đầy dịch có thể tạo đường cho vi khuẩn xâm nhập vào vết thương. Báo ngay với điều dưỡng nếu nhận thấy băng vết thương thấm nhiều dịch. Trước khi rời bệnh viện, người bệnh sẽ được chỉ dẫn cách chăm sóc vết mổ. 
Lưu ý là các nhân viên y tế luôn luôn rửa tay trước khi thay băng. Người bệnh hoặc thân nhân luôn nên làm như vậy. Nếu có nhiễm trùng ở bất kì nơi nào trên cơ thể sau phẫu thuật, hãy cho bác sĩ biết. Một số nhiễm trùng có thể lan rộng và gây ra vấn đề tại vết mổ.
**Hãy làm theo những hướng dẫn sau:**
  * Rửa tay trước khi thay băng.
  * Thay băng theo sự hướng dẫn của nhân viên y tế.
  * Không để vết mổ ướt trừ khi bác sĩ yêu cầu như vậy.
  * Không thoa bất kì thuốc gì lên vết mổ nếu bác sĩ không yêu cầu.
  * Không cào hay châm vào vết mổ.


​​​​​​​
**Nếu bạn có bất kì dấu hiệu cảnh báo nhiễm trùng nào sau đây, hãy báo cho bác sĩ:**
  *   * Vùng xung quanh vết mổ đỏ hơn
  * Vùng xung quanh vết mổ sưng hơn
  * Vẫn chảy dịch từ vết mổ hơn 5 ngày sau phẫu thuật
  * Dịch chảy từ vết mổ đục, vàng hay có mùi hôi
  * Đau ngày càng tăng và thường xuyên


​​​​​​​
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [Trước phẫu thuật](https://bvnguyentriphuong.com.vn/kiem-soat-nhiem-khuan/nhiem-trung-hau-phau-tong-quan-va-xu-tri#trc-phu-thut)



## ️ Vệ sinh tay thường quy

  * [KHÁI NIỆM VỀ VỆ SINH TAY](https://bvnguyentriphuong.com.vn/kiem-soat-nhiem-khuan/ve-sinh-tay-thuong-quy#khi-nim-v-v-sinh-tay)
  * [MỤC ĐÍCH VỆ SINH TAY](https://bvnguyentriphuong.com.vn/kiem-soat-nhiem-khuan/ve-sinh-tay-thuong-quy#mc-ch-v-sinh-tay)
  * [TẦM QUAN TRỌNG CỦA VỆ SINH TAY](https://bvnguyentriphuong.com.vn/kiem-soat-nhiem-khuan/ve-sinh-tay-thuong-quy#tm-quan-trng-ca-v-sinh-tay)
  * [CHỈ ĐỊNH VỆ SINH TAY](https://bvnguyentriphuong.com.vn/kiem-soat-nhiem-khuan/ve-sinh-tay-thuong-quy#ch-nh-v-sinh-tay)
  * [Chỉ định 1: Trước khi động chạm bệnh nhân](https://bvnguyentriphuong.com.vn/kiem-soat-nhiem-khuan/ve-sinh-tay-thuong-quy#ch-nh-1-trc-khi-ng-cham-bnh-nhn)
  * [QUI TRÌNH VỆ SINH TAY THƯỜNG QUY](https://bvnguyentriphuong.com.vn/kiem-soat-nhiem-khuan/ve-sinh-tay-thuong-quy#qui-trnh-v-sinh-tay-thng-quy)
  * [Phương tiện rửa tay](https://bvnguyentriphuong.com.vn/kiem-soat-nhiem-khuan/ve-sinh-tay-thuong-quy#phng-tin-ra-tay)
  * [Qui trình rửa tay bằng nước và xà phòng](https://bvnguyentriphuong.com.vn/kiem-soat-nhiem-khuan/ve-sinh-tay-thuong-quy#qui-trnh-ra-tay-bng-nc-v-x-phng)
  * [TÀI LIỆU THAM KHẢO](https://bvnguyentriphuong.com.vn/kiem-soat-nhiem-khuan/ve-sinh-tay-thuong-quy#ti-liu-tham-kho)


### **KHÁI NIỆM VỀ VỆ SINH TAY**
Vệ sinh tay được dùng để chỉ ra các phương pháp làm sạch tay, bao gồm rửa tay bằng nước với xà phòng, chà tay với dung dịch chứa cồn và rửa tay/sát khuẩn tay phẫu thuật.
Rửa tay: Rửa tay với xà phòng thường (trung tính) và nước
Rửa tay sát khuẩn: Rửa tay với xà phòng chứa chất sát khuẩn
Chà tay bằng dung dịch chứa cồn (Hand rub)
Rửa tay/sát khuẩn tay phẫu thuật: phương pháp mà phẫu thuật viên rửa tay sát khuẩn hay chà tay bằng dung dịch chứa cồn trước khi phẫu thuật
### **MỤC ĐÍCH VỆ SINH TAY**
Loại bỏ vết bẩn nhìn thấy bằng mắt thường trên bàn tay.
Phòng ngừa sự lan truyền mầm bệnh từ cộng đồng vào Bệnh viện.
Ngăn ngừa sự lan truyền mầm bệnh từ Bệnh viện ra cộng đồng.
Ngăn ngừa các nhiễm khuẩn người bệnh có thể mắc phải trong Bệnh viện.
### **TẦM QUAN TRỌNG CỦA VỆ SINH TAY**
Bàn tay là phương tiện trung gian làm lan truyền tác nhân gây nhiễm khuẩn bệnh viện và các tác nhân gây bệnh đề kháng kháng sinh. Bàn tay dễ dàng bị ô nhiễm khi chăm sóc và điều trị người bệnh vì các vi khuẩn cư trú ở lớp sâu của da và xung quanh móng tay. Vi khuẩn định cư thường gặp ở nhóm này là các cầu khuẩn gram (+): S. epidermidis, S. hominis và một số VK gram (-) như Acinetobacter, Enterobacter, v.v. vi khuẩn trên da người bệnh như tụ cầu vàng, Klebsiella spp...
Phần lớn các vi khuẩn định cư có độc lực thấp, ít có khả năng gây nhiễm khuẩn trừ khi chúng xâm nhập vào cơ thể qua vết trầy xước da, các vết thương bao gồm cả vết mổ hoặc các thủ thuật xâm lấn khác.
Rửa tay bằng nước và xà phòng thường khó loại bỏ hết những vi khuẩn trên. Muốn loại bỏ chúng, trước khi thực hiện thủ thuật xâm lấn và phẫu thuật, nhân viên y tế cần vệ sinh tay bằng xà phòng chứa chất khử khuẩn hoặc dung dịch vệ sinh tay chứa cồn.
Vi khuẩn vãng lai là các vi khuẩn có ở trên da người bệnh hoặc trên các bề mặt môi trường bệnh nhân (chăn, ga giường, dụng cụ, phương tiện phục vụ người bệnh) và là thủ phạm chính gây nhiễm khuẩn bệnh viện do gây nhiễm bẩn tay trong quá trình chăm sóc và điều trị. Các vi khuẩn vãng lai ít có khả năng nhân lên trên tay và có thể loại bỏ dễ dàng bằng vệ sinh tay thường quy. Do vậy, vệ sinh tay là biện pháp đơn giản và quan trọng nhất trong phòng chống nhiễm khuẩn bệnh viện.
### **CHỈ ĐỊNH VỆ SINH TAY**
#### Chỉ định 1: Trước khi động chạm bệnh nhân
Bắt tay, cầm tay, xoa trán trẻ, thăm khám.
Giúp nâng đỡ, xoay trở, dìu, tắm, gội, xoa bóp cho người bệnh.
Bắt mạch, đo huyết áp, nghe phổi, khám bụng, ghi điện tâm đồ…
Trước khi thực hiện thủ thuật hoặc quy trình sạch/vô khuẩn.
Đánh răng, nhỏ mắt cho bệnh nhân.
Tiêm, truyền, cho người bệnh uống thuốc.
Chuẩn bị dụng cụ, phương tiện chăm sóc, khám bệnh, điều trị.
Chăm sóc vùng da tổn thương, thay băng.
Đặt thông dạ dày, thông tiểu, mở hệ thống dẫn lưu, hút đờm rãi.
Chuẩn bị thức ăn, pha thuốc, dược phẩm …..
Sau khi có nguy cơ tiếp xúc dịch cơ thể.
Vệ sinh răng miệng, nhỏ mắt, hút đờm cho người bệnh.
Chăm sóc vùng da tổn thương, thay băng, tiêm dưới da.
Lấy bệnh phẩm hoặc thao tác liên quan tới dịch cơ thể, mở hệ thống dẫn lưu, đặt và loại bỏ ống nội khí quản.
Loại bỏ phân, nước tiểu, chất nôn, xử lý chất thải (băng, tã, đệm, quần áo, ga giường ở người bệnh đại tiểu tiện không tự chủ), làm sạch các vật liệu hoặc khu vực dây chất bẩn nhìn thấy bằng mắt thường (đổ vải bẩn, nhà vệ sinh, ống đựng nước tiểu làm xét nghiệm, bô, dụng cụ y tế)
Sau khi động chạm BN.
Đánh răng, nhỏ mắt cho bệnh nhân.
Tiêm, truyền, cho người bệnh uống thuốc.
Chuẩn bị dụng cụ, phương tiện chăm sóc, khám bệnh, điều trị.
Chăm sóc vùng da tổn thương, thay băng.
Đặt thông dạ dày, thông tiểu, mở hệ thống dẫn lưu, hút đờm rãi.
Chuẩn bị thức ăn, pha thuốc, dược phẩm …..
Sau khi động chạm bề mặt xung quanh BN
Động chạm vào giường, bàn, ghế xung quanh người bệnh.
Đụng chạm vào các máy móc xung quanh giường người bệnh.
Thay ga giường, thay chiếu.
Điều chỉnh tốc độ dịch truyền.
Đụng chạm vào bất cứ vật gì trong bán kính 1m xung quanh người bệnh.
### **QUI TRÌNH VỆ SINH TAY THƯỜNG QUY**
Có hai phương pháp VST:
+ Rửa tay bằng nước và xà phòng;
+ Chà tay bằng dung dịch cồn
Rửa tay khi bàn tay nhìn thấy bẩn hoặc có dính dịch cơ thể bằng xà bông và nước.
Nếu bàn tay không nhìn thấy bẩn hoặc nhiễm khuẩn, có thể dùng cồn sát khuẩn bàn tay.
Phải đảm bảo bàn tay khô hoàn toàn trước khi bắt đầu bất kỳ hoạt động chăm sóc nào cho người bệnh.
#### **Phương tiện rửa tay**
Bồn rửa tay: Đủ sâu (50cm) để tránh nước bắn ra bên ngoài và bắn vào người rửa, không có góc, nhẵn, nghiêng về phía trũng bồn rửa tay. Chiều cao từ mặt đất lên mặt bồn rửa từ 65-80cm (phù hợp với chiều cao trung bình của người rửa tay).
Vòi nước: Gắn cố định vào trong tường, chiều cao so với bề mặt của bồn khoảng 25 cm. Nên sử dụng khoá vòi tự động hoặc có cần gạt.
Hệ thống nước: tốt nhất là nước máy.
Giá để xà phòng rửa tay: lắp đặt phù hợp với kích cỡ xà phòng hoặc lọ chứa dung dịch rửa tay.
Khăn lau tay sử dụng 1 lần. Nếu có điều kiện có thể sử dụng khăn lau tay giấy.
Thùng đựng khăn đã sử dụng: Thiết kế sao cho thao tác bỏ khăn vào thùng được dễ dàng, không phải đụng chạm tay vào nắp.
#### **Qui trình rửa tay bằng nước và xà phòng**
Quy trình này được thực hiện khi bắt đầu hoặc kết thúc một ngày làm việc, khi tay dây bẩn mà mắt nhìn thấy được hoặc cảm giác có dính bẩn, dính máu, dịch cơ thể.
Phải tháo trang sức ở tay trước khi tiến hành các bước sau:
Bước 1: Lấy 3 - 5ml dung dịch rửa tay hoặc chà bánh xà phòng lên lòng và mu hai bàn tay. Xoa hai lòng bàn tay vào nhau cho dung dịch và xà phòng dàn đều.
Bước 2: Chà lòng bàn tay này lên mu và kẽ các ngón của bàn tay kia và ngược lại.
Bước 3: Chà hai lòng bàn tay vào nhau, miết mạnh các kẽ ngón tay.
Bước 4: Chà mặt ngoài các ngón tay của bàn tay này vào lòng bàn tay kia.
Bước 5: Dùng lòng bàn tay này xoay ngón cái của bàn tay kia và ngược lại.
Bước 6: Xoay đầu ngón tay này vào lòng bàn tay kia và ngược lại.
**Ghi chú** : Mỗi bước chà tối thiểu 5 lần, thời gian rửa tay tối thiểu là 30 giây.
Sát khuẩn tay bằng dung dịch chứa cồn
Sát khuẩn tay bằng dung dịch chứa cồn là một trong những giải pháp quan trọng nhất để tăng số lần rửa tay của nhân viên y tế. Vì vậy, các khoa cần trang bị các lọ đựng dung dịch chứa cồn có sẵn ở những nơi cần thiết để nhân viên y tế sử dụng. Tối thiểu ở các vị trí sau đây:
Đầu giường bệnh các khoa cấp cứu, khoa điều trị tích cực, chống độc, khoa Truyền nhiễm, khoa gây mê-hồi sức.
Trên các xe tiêm, xe thay băng, xe dụng cụ làm thủ thuật.
Trên các bàn khám bệnh.
Tường cạnh cửa ra vào cửa chính của mỗi khoa.
#### **Quy trình**
Bước 1: Lấy 3ml dung dịch chứa cồn. Chà hai lòng bàn tay vào nhau cho dung dịch dàn đều.
Bước 2: Chà lòng bàn tay này lên mu và kẽ các ngón của bàn tay kia và ngược lại.
Bước 3: Chà hai lòng bàn tay vào nhau, miết mạnh các kẽ ngón tay.
Bước 4: Chà mặt ngoài các ngón tay của bàn tay này vào lòng bàn tay kia.
Bước 5: Dùng lòng bàn tay này xoay ngón cái của bàn tay kia và ngược lại.
Bước 6: Xoay đầu ngón tay này vào lòng bàn tay kia và ngược lại. Chà sát tay đến khi tay khô.
**Ghi chú:** Mỗi bước chà tối thiểu 5 lần, thời gian chà sát tay từ 20-30 giây, hoặc chà sát cho đến khi tay khô.
### **TÀI LIỆU THAM KHẢO**
WHO guideline in Hand hygiene, 2009.
Tài liệu đào tạo phòng ngừa chuẩn của Bộ Y tế, 2010.
Công văn số 7517/BYT-ĐTr ngày 12/10/2007 về việc Hướng dẫn thực hiện quy trình rửa tay thường quy và sát khuẩn tay nhanh bằng dung dịch chứa cồn.
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [KHÁI NIỆM VỀ VỆ SINH TAY](https://bvnguyentriphuong.com.vn/kiem-soat-nhiem-khuan/ve-sinh-tay-thuong-quy#khi-nim-v-v-sinh-tay)
  * [MỤC ĐÍCH VỆ SINH TAY](https://bvnguyentriphuong.com.vn/kiem-soat-nhiem-khuan/ve-sinh-tay-thuong-quy#mc-ch-v-sinh-tay)
  * [TẦM QUAN TRỌNG CỦA VỆ SINH TAY](https://bvnguyentriphuong.com.vn/kiem-soat-nhiem-khuan/ve-sinh-tay-thuong-quy#tm-quan-trng-ca-v-sinh-tay)
  * [CHỈ ĐỊNH VỆ SINH TAY](https://bvnguyentriphuong.com.vn/kiem-soat-nhiem-khuan/ve-sinh-tay-thuong-quy#ch-nh-v-sinh-tay)
  * [Chỉ định 1: Trước khi động chạm bệnh nhân](https://bvnguyentriphuong.com.vn/kiem-soat-nhiem-khuan/ve-sinh-tay-thuong-quy#ch-nh-1-trc-khi-ng-cham-bnh-nhn)
  * [QUI TRÌNH VỆ SINH TAY THƯỜNG QUY](https://bvnguyentriphuong.com.vn/kiem-soat-nhiem-khuan/ve-sinh-tay-thuong-quy#qui-trnh-v-sinh-tay-thng-quy)
  * [Phương tiện rửa tay](https://bvnguyentriphuong.com.vn/kiem-soat-nhiem-khuan/ve-sinh-tay-thuong-quy#phng-tin-ra-tay)
  * [Qui trình rửa tay bằng nước và xà phòng](https://bvnguyentriphuong.com.vn/kiem-soat-nhiem-khuan/ve-sinh-tay-thuong-quy#qui-trnh-ra-tay-bng-nc-v-x-phng)
  * [TÀI LIỆU THAM KHẢO](https://bvnguyentriphuong.com.vn/kiem-soat-nhiem-khuan/ve-sinh-tay-thuong-quy#ti-liu-tham-kho)



## ️ Gợi ý về tái sử dụng khẩu trang N95 khi thật cần thiết

Khi bạn mua hoặc chọn khẩu trang N95, để đảm bảo rằng khẩu trang bạn chọn đạt tiêu chuẩn để sử dụng trong chăm sóc y tế bệnh nhân COVID-19, hãy kiểm tra xem:
  1. N95 này dùng để lọc vi khuẩn/vi rút hay lọc bụi mịn (đọc ở bao bì)?
  2. Đạt tiêu chuẩn tương đương tiêu chuẩn sau:


  * Mỹ: N95 Respirator (tiêu chuẩn NIOSH-42C FR84)
  * Châu Âu: FFP2 Respirator (tiêu chuẩn EN 149-2001)
  * Úc, Newzealand: P2 Respirator (tiêu chẩn AS/NZ 1716:2012)
  * Trung Quốc: KN95 Respirator (tiêu chuẩn GB2626-20 06)
  * Nhật bản: DS Respirator (tiêu chuẩn JMHLW- Notification 214, 2018)
  * Hàn Quốc: Korea 1st Class Respirator (tiêu chuẩn KMOEL-2017-64).


Bạn có thể tra nhanh bằng cách tìm mã khẩu trang của bạn trong [**danh sách này**](https://www.cdc.gov/niosh/npptl/topics/respirators/disp_part/N95list1.html). Nếu có tức là khẩu trang của bạn đạt tiêu chuẩn.
Trong tình huống khan hiếm khẩu trang do dịch bùng phát, Hoa Kỳ và một số nước Châu Âu đã có những biện pháp tái sử dụng khẩu trang N95, và đây là những cách được gợi ý (không phải là khuyến cáo) và chỉ áp dụng trong những hoàn cảnh thật cần thiết. 
Có những trường hợp khẩu trang N95 không được phép tái sử dụng - vì vậy cần tham khảo thêm những quy định về kiểm soát nhiễm khuẩn tại cơ sở y tế tại địa phương! 
Điều quan trọng cần nhớ: **KHÔNG tiệt khuẩn khẩu trang N95 bằng lò vi sóng, lò nướng tại nhà!**
**Sấy ở 70 Độ C trong 30 phút theo khuyến cáo của trường Đại học Standford (lò sấy chuyên dụng)**
Tất cả các quy trình ở bảng dưới đây TIÊU DIỆT ĐƯỢC Coronavirus (tham khảo toàn bộ nội dung tại [ĐÂY)](https://m.box.com/shared_item/https%3A%2F%2Fstanfordmedicine.box.com%2Fv%2Fcovid19-PPE-1-1?fbclid=IwAR0zh7Pz9GeyiwjiBZFnSigY_YLDITodDcymkJR5i22JDvPFcZGv4Z7o6wU)
_**Những dòng đỏ cảnh báo rằng: KHÔNG sử dụng cồn và các phương pháp khử trùng bằng chất sát trùng có gốc clo để tái sử dụng khẩu trang N95 do hiệu suất thấp của chúng!**_
**2.**Dùng luân phiên:****
_**Lấy 01 ví dụ áp dụng quy trình mỗi nhân viên 07 khẩu trang cho 07 ngày**_
_(Không áp dụng nếu vừa thực hiện các thủ thuật có khí dung, tiếp xúc bệnh nhân rất gần <1m, khẩu trang dính chất trang điểm)_
**3. Dùng tia UV ( 300 mJ/cm2) theo khuyến cáo của trường Đại học Standford**
_**(Cần tuân theo những quy trình cụ thể nếu muốn áp dụng phương pháp này)**_
Tham khảo quy trình khử khuẩn khẩu trang N95 bằng tia UV ở [ĐÂY](https://www.nebraskamed.com/sites/default/files/documents/covid-19/n-95-decon-process.pdf?fbclid=IwAR18gz0Kad28-jG79Ld3e35l1AhebnkMv3OrzcCe77zkWpOwbCFXPPng8UU).
**Lưu ý**
  1. Vì tia UV có thể gây ung thư da nên cẩn thận khi sử dụng.
  2. Tia UV cần chiếu 2 mặt của khẩu trang.
  3. Tại Việt Nam - với khí hậu nhiệt đới, UV tự nhiên rất dồi dào: đó chính là nắng tự nhiên. Phơi khi trời nắng to tầm 15-20ph cũng đã phát huy được vai trò diệt virus corona của UV tự nhiên!


**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh

## ️ Thuốc sát khuẩn (antisepticum)

  * [Khái niệm cơ bản](https://bvnguyentriphuong.com.vn/kiem-soat-nhiem-khuan/thuoc-sat-khuan-antisepticum#khi-nim-c-bn)
  * [Nguyên tắc sử dụng.](https://bvnguyentriphuong.com.vn/kiem-soat-nhiem-khuan/thuoc-sat-khuan-antisepticum#nguyn-tc-s-dng)
  * [Dẫn xuất của Phenol, tác dụng ở vùng pH từ 3 - 6.](https://bvnguyentriphuong.com.vn/kiem-soat-nhiem-khuan/thuoc-sat-khuan-antisepticum#dn-xut-ca-phenol-tc-dng-vng-ph-t-3-6)
  * [Dẫn xuất Biguanid (chlorhexidin), tác dụng ở vùng pH 6 - 8,5.](https://bvnguyentriphuong.com.vn/kiem-soat-nhiem-khuan/thuoc-sat-khuan-antisepticum#dn-xut-biguanid-chlorhexidin-tc-dng-vng-ph-6-85)
  * [SALICYLANID, tác dụng ở vùng pH 4 - 7.](https://bvnguyentriphuong.com.vn/kiem-soat-nhiem-khuan/thuoc-sat-khuan-antisepticum#salicylanid-tc-dng-vng-ph-4-7)
  * [Dẫn xuất Halogen:](https://bvnguyentriphuong.com.vn/kiem-soat-nhiem-khuan/thuoc-sat-khuan-antisepticum#dn-xut-halogen)
  * [Kim loại nặng: (hay dùng Hg, Ag, Cu, Zn ).](https://bvnguyentriphuong.com.vn/kiem-soat-nhiem-khuan/thuoc-sat-khuan-antisepticum#kim-loi-nng-hay-dng-hg-ag-cu-zn-)


#### Định nghĩa
Là thuốc dùng rửa, bôi lên da, niêm mạc đ­ược bào chế từ hoá chất d­ược dụng để diệt vi khuẩn, làm sạch vùng da trước khi tiêm, mổ, hoặc điều trị tại chỗ vùng da bị nhiễm vi khuẩn, nấm ...
#### Khái niệm cơ bản
Chất sát khuẩn, tiệt khuẩn (antisepticum): là thuốc dùng ngoài, tuyệt đối không uống được (ghi rõ trên nhãn thuốc).
Chất tẩy uế (desinficiens): là những chất không dùng đ­ược trên bề mặt cơ thể sống, chỉ dùng đ­ợc tẩy uế dụng cụ đồ vật (đất rác - môi tr­ờng) không phải là chất d­ược dụng.
Sự tiệt khuẩn, khử trùng (sterilisation): đã là quá trình không những chỉ dùng các chất sát khuẩn và chất tẩy uế (tác nhân hoá học) và còn dùng các tác nhân khác như cơ học, nhiệt, điện từ, quang học … nữa (ví dụ: lọc vi khuẩn ở nước).
#### Nguyên tắc sử dụng.
  * Với da lành: rửa sạch da (bằng n­ước sạch, nư­ớc muối, ethe), bôi thuốc sát khuẩn.
  * Với da có vết loét, vết th­ương:


Đo pH ở vùng vết thư­ơng (có thể dùng giấy chỉ thị pH).
Xác định vi khuẩn (nếu cần).
Làm sạch (cắt lọc), rửa sạch n­ước muối, oxy già.
Bôi thuốc (căn cứ vào pH).
#### Dẫn xuất của Phenol, tác dụng ở vùng pH từ 3 - 6.
Acid para hydroxybenzoic: tác dụng ức chế vi khuẩn Gr (+), nấm. Không dùng bản thân acid mà dùng dẫn chất ester của acid này, gọi là Phraben, làm chất bảo quản trong công nghiệp dư­ợc (crem) thực phẩm - chú ý: có thể gây viêm da (ví dụ mỹ phẩm).
**Hexachlorphen.**
Thuốc hấp thu qua da, niêm mạc (chú ý trẻ sơ sinh) qua máu, rau thai, TKTW. Có thể gây độc: cấp - mạn; sốt - co giật - hôn mê.
Dùng rửa tay tr­ước mổ, rửa vết bỏng ...
#### Dẫn xuất Biguanid (chlorhexidin), tác dụng ở vùng pH 6 - 8,5.
Phổ tác dụng: kìm và diệt khuẩn rộng, ít độc.
Hấp thu qua da lành < da tổn th­ương. 98% gắn vào da không hấp thu qua ống tiêu hoá, thải hoàn toàn theo phân.
Ứng dụng: rửa tay, n­ước rửa trong phụ khoa, tiết niệu (ví dụ rửa bàng quang), rửa vết bỏng, giác mạc.
Chế phẩm, có dạng thuốc tan trong nư­ớc, r­ượu, crem, n­ước súc miệng, kem răng.
#### SALICYLANID, tác dụng ở vùng pH 4 - 7.
Không phân ly, tan trong dung môi hữu cơ.
Phổ tác dụng: kìm khuẩn, nấm, dùng bôi da.
Carbanilid: phổ tác dụng: kìm khuẩn Gr (+).
Huyết thanh làm mất tác dụng của thuốc.
Khi giáng hoá cho ra sản phẩm độc, gây met Hb/ máu (sơ sinh). 
Dùng mì, bột bôi da, xà phòng cạo râu.
#### Dẫn xuất Halogen:
Các dẫn xuất của chlor, brom, flor, dùng làm chất tẩy uế.
Dẫn xuất của iod: do dung nạp tốt hơn (với da, niêm mạc) nên đư­ợc dùng làm thuốc sát khuẩn da - niêm mạc.
Phổ tác dụng rộng: tác dụng nhanh (cả với vi khuẩn, virus; trừ dạng bào tử và Mycobacteri).
Chế phẩm của chlor, tác dụng ở pH 5- 8
Chlor: dùng tẩy uế n­ước uống, bể bơi, dụng cụ chứa thực phẩm.
Hypochlorid : tẩy uế bệnh phẩm (đờm, máu, mủ, phân...).
Do kích ứng da - niêm mạc nên không dùng rửa vết th­ương.
Dung dịch Dakin (có Natri hypochlorid + NaHCO3 + KMnO4).
Còn có : Chloramin T, DichloraminT.
Dakin tác dụng t­ương tự Chloramin B.
Chế phẩm chứa iod (tác dụng ở pH 2-6).
Phổ tác dụng rộng: rộng, kể cả trực khuẩn lao, vi khuẩn, bào tử, virus, nấm, trùng roi (trichomonas).
Hấp thu: qua da, vào đ­ược máu, thải trừ chậm qua thận.
Độc tính: uống nhầm 30ml cồn iod ® có thể tử vong.
Cấp: dùng một l­ượng lớn để bôi, đắp lên da (tổn thương bỏng) : thuốc sẽ hấp thu vào huyết thanh gây nhiễm acid chuyển hoá; suy thận. kích ứng da - niêm mạc.
Độc tính mạn: suy giáp trạng (qua hormon tuyến này).
Ứng dụng lâm sàng: sát khuẩn tay kỹ thuật viên, da vùng mổ, vùng mổ, vùng tiêm.
Chữa viêm da: nay dùng polyvinyl - pyrolidon. iod ( PVPI ): dung nạp tốt hơn I.
#### Rư­ợu (ALCOOL)
Loại này dùng làm thuốc sát khuẩn: r­ượu đơn Ethanol.
Dẫn chất của propanol như­ iso butanol .
Dẫn chất Glycol (rượu nhiều lần r­ượu).
Ethylic: 70 % vol diệt khuẩn tốt hơn loại 90 %.vol (diệt nấm, virus yếu).
Loại propionic: tác dụng mạnh hơn ethanol.
Không dùng : Ethanol + iod + Ethanol + Chlorhexidin.
Tuyệt đối không dùng: Methylic (methanol); Benzylic; độc TK, mù.
#### Kim loại nặng: (hay dùng Hg, Ag, Cu, Zn ).
Dẫn xuất thuỷ ngân, tác dụng ở pH 5 - 7.
Nay dùng hợp chất hữu cơ của thuỷ ngân, ít độc hơn vô cơ (cũ: điều trị giang mai).
Phổ tác dụng: rộng, kìm khuẩn rộng, tác dụng với virus yếu.
Do: gắn vào nhóm - SH, thiol của protein (enzym).
Ứng dụng lâm sàng: sát khuẩn da, viêm mạc.
Chế phẩm : Mercurochrom (thuốc đỏ) : nay ít dùng.
Mercuro - butyl
Dẫn xuất của bạc (arginin).
Tác dụng kìm khuẩn - diệt khuẩn, dễ dung nạp.
Chế phẩm: Vitellinat - bạc (argyrol) dung dịch dùng nhỏ mắt; (chú ý dễ bị huỷ bởi ánh sáng).
Albuminat - bạc (protargol).
Bạc - sulfadiazin.
Bạc Niclosamid - Citrat bạc: nhỏ mắt trẻ mới đẻ, chống giang mai lây theo đ­ường tiếp xúc mẹ - con.
Dẫn xuất của Cu- Zn. Chế phẩm: Sulfat Zn dung dịch nhỏ mắt.
Dung dịch (Cu- Sulfat + Zn- Sulfat).
Kẽm oxyd; dạng mì, bột dùng trong mỹ phẩm và Herpes simplex.
#### Chất màu
Tím gentian.
Dung dịch Millan.
Xanh methylen.
Fuschin
#### Thuốc khác
**Aldehyd:** (Formaldehyd, Formalin, Formol). Tác dụng diệt khuẩn : làm chất tẩy uế, ư­ớp xác, khử dụng cụ, đất đai, rác, môi trư­ờng.
**Chất oxy hoá :**
Dung dịch Hydroperoxyd (H2O2, n­ước oxy già): rửa vết th­ương, súc miệng.
Dung dịch Kali permanganat (KMnO4) 1/10.000, giải phóng oxy nguyên tử diệt khuẩn do tạo gốc tự do.
Acid benzoic: tác dụng diệt khuẩn, làm chất bảo quản (thuốc nư­ớc).
Hexatidin: dung dịch diệt khuẩn, giảm đau, làm chất sát khuẩn tai, mũi, họng.
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [Khái niệm cơ bản](https://bvnguyentriphuong.com.vn/kiem-soat-nhiem-khuan/thuoc-sat-khuan-antisepticum#khi-nim-c-bn)
  * [Nguyên tắc sử dụng.](https://bvnguyentriphuong.com.vn/kiem-soat-nhiem-khuan/thuoc-sat-khuan-antisepticum#nguyn-tc-s-dng)
  * [Dẫn xuất của Phenol, tác dụng ở vùng pH từ 3 - 6.](https://bvnguyentriphuong.com.vn/kiem-soat-nhiem-khuan/thuoc-sat-khuan-antisepticum#dn-xut-ca-phenol-tc-dng-vng-ph-t-3-6)
  * [Dẫn xuất Biguanid (chlorhexidin), tác dụng ở vùng pH 6 - 8,5.](https://bvnguyentriphuong.com.vn/kiem-soat-nhiem-khuan/thuoc-sat-khuan-antisepticum#dn-xut-biguanid-chlorhexidin-tc-dng-vng-ph-6-85)
  * [SALICYLANID, tác dụng ở vùng pH 4 - 7.](https://bvnguyentriphuong.com.vn/kiem-soat-nhiem-khuan/thuoc-sat-khuan-antisepticum#salicylanid-tc-dng-vng-ph-4-7)
  * [Dẫn xuất Halogen:](https://bvnguyentriphuong.com.vn/kiem-soat-nhiem-khuan/thuoc-sat-khuan-antisepticum#dn-xut-halogen)
  * [Kim loại nặng: (hay dùng Hg, Ag, Cu, Zn ).](https://bvnguyentriphuong.com.vn/kiem-soat-nhiem-khuan/thuoc-sat-khuan-antisepticum#kim-loi-nng-hay-dng-hg-ag-cu-zn-)



## ️ Xử lý chất thải trong bệnh viện

**ĐẠI CƯƠNG**
Các chất thải trong bệnh viện ở các dạng rắn, lỏng, khí, đều có khả năng gây ô nhiễm cho môi trường và người tiếp xúc. Nên trước khi thải ra ngoài đều phải được xử lý.
Khoa chống nhiễm khuẩn của bệnh viện chịu trách nhiệm tổ chức công tác này.
Nơi tập trung các chất thải phải được riêng biệt, có mái che (tốt nhất là để ở phía Tây Bắc của bệnh viện). 
**Chất thải y tế nguy hại là:**
Máu dịch cơ thể chất bài tiết.
Cơ quan bộ phận con người động vật.
Bơm tiêm kim vật sắc nhọn.
Dược phẩm hoá chất phóng xạ.
**PHÂN LOẠI CHẤT THẢI: 5 LOẠI**
Chất thải lâm sàng.
Chất thải phóng xạ.
Chất thải hoá học.
Chất thải dạng khí.
Chất thải sinh hoạt.
**Chất thải lâm sàng: 5 nhóm**
**Nhóm A** : các loại chất thải có dính máu hoặc dịch tiết người bệnh: bông băng, găng tay, bột, nẹp, dây tiêm truyền, ống thông chất thải nhiễm khuẩn.
**Nhóm B** : các vật sắc nhọn: bơm tiêm kim, dao mổ, đinh, lưỡi cưa, mảnh thủy tinh vỡ.
**Nhóm C** : chất thải có nguy cơ lây nhiễm cao phát sinh từ phòng xét nghiệm: găng tay, lam kính, ống nghiệm, bệnh phẩm xét nghiệm, môi trường nuôi cấy máu.
**Nhóm D** : chất thải dược phẩm: dược phẩm quá hạn, nhiễm khuẩn, hoặc đổ ra ngoài, không còn sử dụng.
**Nhóm E** : mô cơ quan người cắt bỏ, động vật thí nghiệm.
**Chất thải phóng xạ: ở các dạng rắn, lỏng, khí**
Chất thải phóng xạ rắn: các vật liệu xử dụng trong các xét nghiệm chẩn đoán, điều trị: bơm tiêm, kim, kính bảo hộ, giấy thấm, gạc, ống nghiệm, chai đựng phóng xạ.
Chất thải phóng xạ lỏng: dung dịch có chứa nhân phóng xạ trong chẩn đoán, điều trị: nước tiểu người bệnh, chất bài tiết, nước súc rửa các dụng cụ có chất phóng xạ.
Chất thải phóng xạ khí: chất khí dùng trong lâm sàng thoát ra rừ kho chứa chất phóng xạ 133.
**Chất thải hoá học**
ở các dạng rắn, lỏng, khí, 2 loại.
Chất thải hóa học không gây hại: đường, acid béo, 1 số vô cơ, hữu cơ
**Chất thải hóa học nguy hại**
Formaldehyd: dùng trong giải phẫu bệnh, lọc máu, ướp xác.
Các chất quang hóa học: nước tráng phim X quang.
Các dung môi: các hợp chất Halogen, không có Clorofrom, thuốc mê ư Oxyd ethylen: tiệt khuẩn dụng cụ.
Dung dịch hóa học hỗn hợp: dung dịch làm sạch và khử khuẩn.
**Các bình chứa khí có áp suất**
O2, CO2, gaz, các khí thải trong điều trị chăm sóc.
**Chất thải sinh hoạt**
Chất thải không bị nhiễm các yếu tố nguy hại, phát sinh từ các buồng bệnh, phòng làm việc, hành lang, các bộ phận cung ứng, nhà kho, nhà giặt, nhà ăn là các loại rác thải trong sinh hoạt hằng ngày như giấy báo, tài liệu, vật liệu đóng gói, túi đựng phim, giấy gói thức ăn, túi nilông, rác quét dọn từ sàn nhà. Ngoài ra còn có rác thải từ môi trường như: lá cây và rác từ các khu vực ngoại cảnh.
**QUY ĐỊNH VỀ TÚI CHỨA, THÙNG ĐỰNG CHẤT THẢI**
**Quy định về màu sắc của túi chứa chất thải**
_Màu xanh_ : chất thải sinh hoạt.
_Màu vàng_ : chất thải lâm sàng, bên ngoài có biểu tượng nguy hại sinh học.
_Hộp cứng màu vàng_ , có biểu tượng nguy hại sinh học, đựng vật sắc nhọn.
_Màu đen_ : chứa các chất hoá học, chất phóng xạ, thuốc gây độc tế bào.
**Tiêu chuẩn túi chứa chất thải**
Nếu xử lý bằng phương pháp đốt nên dùng túi nhựa PE hoặc PP không dùng túi nhựa PVC vì khi đốt sẽ tạo ra nhiều chất gây ô nhiễm môi trường.
Kích thước túi chứa lớn, nhỏ tùy rác: tối đa < 0,1 m3.
Có đường kẻ ngang ở mức 2/3 và có chữ: không được đựng quá vạch này.
**Tiêu chuẩn hộp đựng vật sắc nhọn**
Vật liệu cứng không đâm xuyên không rò rỉ có thể đốt được.
Dung tích lớn, nhỏ khác nhau từ 2,5 - 20 lít.
Có nắp đậy kín, an toàn không để đổ ra ngoài.
Màu vàng: có nhãn đề chỉ đựng vật sắt nhọn; có vạch báo hiệu ở mức 2/3 hộp và có dòng chữ không để quá vạch này.
**Tiêu chuẩn thùng đựng chất thải**
Thùng làm bằng nhựa PE (Poly Etylen) có tỷ trọng cao, dày, cứng và có nắp đậy.
Thùng màu vàng dùng để gom rác trong túi màu vàng: chất thải lâm sàng.
Thùng màu xanh dùng để gom rác trong túi màu xanh: chất thải sinh hoạt.
Thùng màu đen dùng để gom rác trong túi màu đen: chất thải hóa học, phóng xạ.
Dung tích của thùng chứa từ 10 - 250 lít.
Bên ngoài thùng có vạch chỉ rõ mức 2/3 của thùng và có dòng chữ không để quá vạch này.
**Thời gian lưu trữ chất thải**
Đối với các bệnh viện nên xử lý rác thải hàng ngày, đặc biệt là chất thải y tế nguy hại như máu, dịch tiết người bệnh, vật sắc nhọn, chất thải có nguy cơ lây nhiễm cao phát sinh từ phòng xét nghiệm, chất thải dược phẩm thì thời gian lưu trữ tối đa là 48 giờ.
Đối với các cơ sở y tế nhỏ (trạm y tế, phòng khám) không nên để quá 1 tuần. Chất thải y tế như máu, dịch tiết người bệnh, vật sắc nhọn, chất thải có nguy cơ lây nhiễm cao phát sinh từ phòng xét nghiệm, chất thải dược phẩm được lưu trữ không nên để quá 1 tuần.
Đối với chất thải là mô cơ quan người, động vật thí nghiệm phát sinh ở bệnh viện hay cơ sở y tế thì phải được xử lý ngay bằng cách đốt hoặc chôn. 
**QUY ĐỊNH CỤ THỂ VỀ XỬ LÝ CHẤT THẢI**
****
Phải được thu gom phân loại đúng quy định.
Rác phải được tập trung đúng nơi quy định.
Túi rác chứa không quá 2/3 túi, ghi rõ tên khoa phòng bệnh.
Vận chuyển chất thải không để rơi vãi trên đường, tránh đi qua khu vực có người bệnh nằm, khu vực sạch khác.
Thu gom chất thải trung bình khoảng 2 lần/ngày vào nơi tập trung chất thải của bệnh viện.
Các mô cơ quan, phần cơ thể cắt bỏ hoặc con vật dùng để thí nghiệm phải có nơi tập trung riêng để chôn hoặc đốt.
Bệnh viện có lò đốt chất thải phải đúng tiêu chuẩn công nghệ, bảo đảm các điều kiện xử lý chất thải.
**Xử lý chất thải:**
Xử lý ban đầu đối với các chất thải có nguy cơ lây nhiễm cao trước khi đốt hoặc chôn.
Chôn cách mặt đất cao 50 cm, hoặc đốt chất thải nơi quy định.
Tẩy uế xử lý cơ học, đốt hoặc chôn sâu 50 cm đối với chất thải sắc nhọn.
Đối với chất thải phóng xạ dạng rắn cần thực hiện theo các qui định của pháp lệnh an toàn và kiểm soạt bức xạ của nhà nước.
Đối với các chất hoá học không nguy hại: có thể áp dụng một trong 2 cách sau: tái sử dụng, hoặc tiêu huỷ như chất thải sinh hoạt.
**Đối với các chất thải hoá học nguy hại:**
Các chất thải hoá học nguy hiểm có tính chất khác nhau không được trộn lẫn với nhau để tiêu hủy.
Không được đốt các chất thải có chứa Halogen vì sẽ gây ô nhiễm không khí.
Không được đổ vào hệ thống nước thải chung của thành phố.
Không được chôn một lượng lớn chất thải hoá học vì có thể gây ô nhiễm mạch nước ngầm.
Phương pháp tiêu hủy: trả về nơi phân phối cung cấp ban đầu, thiêu đốt hoặc có thể làm trơ hoá chất thải trước khi chôn lấp.
Đối với các bình chứa khí có áp suất: không dùng phương pháp đốt được vì có thể gây nổ do vậy có thể xử lý bằng cách trả về nơi sản xuất, tái sử dụng hoặc tiêu hủy như rác sinh hoạt đối với các bình nhỏ.
Đối với rác thải sinh hoạt: không cần phải thiêu đốt và tiêu hủy như rác thải trong các hộ gia đình.
**Chất thải lỏng**
**Quy định chung:** mỗi bệnh viện phải có hệ thống thu gom và xử lý nước thải đồng bộ, nước thải bệnh viện khi thải ra ngoài khu vực quản lý của bệnh viện phải đạt tiêu chuẩn hiện hành của Việt Nam. Do đó các bệnh viện:
Phải có hệ thống cống rãnh và bể ngầm để chứa và xử lý nước thải. 
Nạo vét cống rãnh định kỳ, không để tắc nghẽn.
Xử lý bằng phương pháp lý hóa hoặc sinh học hoặc kết hợp các phương pháp đó trước khi cho thải vào hệ thống cống rãnh của thành phố. Việc áp dụng các thiết bị và công nghệ mới phải đồng bộ và được cơ quan nhà nước có thẩm quyền về công nghệ môi trường xét duyệt.
****
Quy định chung: các phòng xét nghiệm, kho hoá chất dược phẩm phải bảo đảm tiêu chuẩn hiện hành của Việt Nam, do vậy phải có hệ thống thông khí và xử lý khí độc.
Khí từ lò đốt rác.
Từ phòng xét nghiệm.
Lò đốt rác đạt chuẩn công nghệ, che chắn khí thải ra môi trường.
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh

## ️ Sử dụng dung dịch sát khuẩn tay chứa cồn (ABHR – Alcohol Based Hand Rubs)

**Sử dụng dung dịch sát khuẩn tay chứa cồn (ABHR – Alcohol Based Hand Rubs)**
Ngoài việc rửa tay truyền thống bằng nước và xà bông, CDC (Trung tâm kiểm soát và phòng bệnh) khuyến cáo các nhân viên y tế sử dụng dung dịch sát khuẩn tay có chứa cồn trong khi chăm sóc bệnh nhân khi tay không vẩy bẩn một cách rõ rệt vì dung dịch vệ sinh tay có chứa cồn có những ưu việt như sau:
- ABHR tốn ít thời gian hơn so với rửa tay truyền thống. Trong một ca làm việc 8 tiếng Điều dưỡng của khoa ICU có thể tiết kiệm được một 1giờ nếu sử dung ABHR
- Cách này làm giảm một cách rõ rệt các vi sinh vật trên bề mặt da, có tác dụng nhanh, ít gây kích ứng đối với da như xà bông và nước
- ABHR rất ít gây dị ứng cho da, tuy nhiên việc sử dụng thường xuyên dung dịch này cũng có thể gây dị ứng
**Cách sử dụng ABHR:**
- Đổ dung dịch vào lòng một bàn tay rồi chà hai bàn tay vào nhau
- Trải đều dung dịch lên bề mặt da bàn tay và ngón tay cho đến khi thấy bàn tay đã khô. (Lưu ý lượng dung dịch cần thiết để đủ diệt khuẩn trên bàn tay thay đổi theo từng sản phẩm)
**Rửa tay, găng tay và móng tay giả:**
- Khi tay của nhân viên y tế có vết bẩn rõ rệt thì phải rửa tay bằng xà bông và nước
- Việc sử dụng găng tay không có nghĩa là không cần rửa tay nữa. Tương tự như vậy, việc vệ sinh tay sạch sẽ không có nghĩa là không cần phải đeo găng tay.
- Găng tay làm giảm việc nhiễm khuẩn bàn tay xuống 70-80%, ngăn ngừa được nhiễm trùng chéo, bảo vệ cả bệnh nhân và nhân viên y tế khỏi bị nhiễm trùng.
- Dung dịch sát khuẩn được sử dụng trước và sau khi chăm sóc mỗi bệnh nhân, găng tay phải được thay trước và sau khi chăm sóc mỗi bệnh nhân
**Gợi ý để thuyết phục nhân viên nhớ luôn giữ vệ sinh tay sạch sẽ:**
- Hướng dẫn bệnh nhân để họ hỏi nhân viên y tế xem họ có rửa tay hay chưa (ví dụ một vài cơ sở y tế cho nhân viên đeo nút báo trên đồng phục trên đó có ghi: “ Hãy hỏi xem tôi đã rửa tay chưa”
- Khuyến khích nhân viên nhắc nhở nhau rửa tay trước và sau khi chăm sóc từng bệnh nhân
- Yêu cầu trưởng nhóm nổ lực nêu gương việc thực hiện tốt việc vệ sinh tay cho nhân viên noi theo
- Lắp đặt bình chưa dung dịch sát khuẩn tay (ABHR) ngay trong phòng bệnh nhân hoặc ngay cửa phòng bệnh
- Lắp đặt loa ở bên ngoài cửa các phòng bệnh nguy cơ cao để tự động nhắc nhở các nhân viên mỗi khi họ ra khỏi phòng “ Hãy nhớ rửa tay trước khi bạn rời khỏi phòng lây nhiễm” chẳng hạn.
- Cho các nhân viên biết là sẽ có hệ thống theo dõi việc tuân thủ các nguyên tắc vệ sinh tay
- Đo lường khối lượng ABHR được sử dụng trên 1000 ngày bệnh nhân và cho các nhân viên biết kết quả đo lường
- Nhân viên y tế cần tránh mang móng tay giả và giữ cho móng tay tự nhiên ngắn hơn 1/4 in (0,65cm) nếu họ có tham gia vào việc chăm sóc các bệnh nhân có nguy cơ nhiễm trùng cao (ví dụ bệnh nhân tại phòng ICU)
**Lựa chọn sản phẩm**
Khi cân nhắc lựa chọn sản phẩm vệ sinh tay trong bệnh viện của mình, nhân viên hoặc tiểu ban chịu trách nhiệm cần cân nhắc tính hiệu quả của các chất sát khuẩn đối với các đặc điểm bệnh học, cũng như việc đồng tình của nhân viên trong việc sử dụng các sản phẩm đó. Nhiều tính chất sản phẩm ảnh hưởng đến việc đồng tình sử dụng của nhân viên. Ví dụ như: mùi, màu, tính gây khô da…của sản phẩm
**Theo dõi sự tuân thủ của nhân viên**
Theo tiêu chuẩn của JCI, các cơ sở y tế được khuyến khích thiết lập và triển khai một hệ thống đánh giá việc nhân viên thực hiện vệ sinh tay. Sau đây là một vài chỉ số đánh giá để tham khảo:
- Định kỳ theo dõi việc tuân thủ của nhân viên bằng cách kiểm tra trực tiếp và thông tin kết quả cho từng nhân viên về sự tuân thủ của họ
-Theo dõi khối lượng dung dịch trên 1000 ngày bệnh nhân
-Theo dõi việc nhân viên tuân thủ chính sách về việc mang móng tay giả
- Tập trung điều tra việc nhân viên có tuân thủ đầy đủ quy định vệ sinh tay khi có nhiễm trùng phát sinh
**Tham khảo từ SỔ TAY AN TOÀN NGƯỜI BỆNH của JCI**
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh

## ️ Làm sạch, khử trùng nơi ở và văn phòng trong mùa dịch Covid

  * [Thời điểm nên vệ sinh và thời điểm khử trùng](https://bvnguyentriphuong.com.vn/kiem-soat-nhiem-khuan/lam-sach-khu-trung-noi-o-va-van-phong-trong-mua-dich-covid#thi-im-nn-v-sinh-v-thi-im-kh-trng)
  * [Vệ sinh và khử trùng các loại bề mặt cụ thể](https://bvnguyentriphuong.com.vn/kiem-soat-nhiem-khuan/lam-sach-khu-trung-noi-o-va-van-phong-trong-mua-dich-covid#v-sinh-v-kh-trng-cc-loi-b-mt-c-th)
  * [Các biện pháp phòng ngừa khi đóng gói và xử lý thực phẩm ](https://bvnguyentriphuong.com.vn/kiem-soat-nhiem-khuan/lam-sach-khu-trung-noi-o-va-van-phong-trong-mua-dich-covid#cc-bin-php-phng-nga-khi-ng-gi-v-x-l-thc-phm)
  * [Không gian bên ngoài](https://bvnguyentriphuong.com.vn/kiem-soat-nhiem-khuan/lam-sach-khu-trung-noi-o-va-van-phong-trong-mua-dich-covid#khng-gian-bn-ngoi)


## **Thời điểm nên vệ sinh và thời điểm khử trùng**
Vệ sinh bằng các sản phẩm có chứa xà phòng hoặc chất tẩy rửa giúp giảm mầm bệnh trên bề mặt bằng cách loại bỏ chất gây ô nhiễm và làm giảm nguy cơ lây nhiễm từ các bề mặt.
Khi không có người đã được xác nhận hoặc nghi nhiễm COVID-19 được xác định là đã có mặt tại đó, thì việc vệ sinh mỗi ngày một lần thường là đủ để loại bỏ vi-rút có thể có trên các bề mặt và giúp duy trì cơ sở lành mạnh.
**Nếu có người bị bệnh hoặc ai đó xét nghiệm dương tính với COVID-19 tại cơ sở của quý vị trong vòng 24 giờ qua, quý vị nên vệ sinh VÀ khử trùng không gian đó.**
**Bộ Y tế khuyến cáo, những vị trí có tiếp xúc thường xuyên như: tay nắm cửa, tay vịn cầu thang, tay vịn lan can, nút bấm thang máy, công tắc điện, bàn phím máy tính, điều khiển từ xa, điện thoại dùng chung cần được khử khuẩn ít nhất 02 lần/ngày.**
**Vệ sinh các bề mặt thường xuyên chạm vào**
Vệ sinh các bề mặt thường xuyên chạm vào ít nhất mỗi ngày một lần hoặc thường xuyên tới mức được xác định là cần thiết. Các ví dụ minh họa về các bề mặt thường xuyên chạm vào bao gồm: bút, quầy, xe đẩy mua hàng, bàn, tay nắm cửa, công tắc đèn, tay nắm, tay vịn cầu thang, nút bấm thang máy, bàn làm việc, bàn phím, điện thoại, toa-lét, vòi nước và bồn rửa.
## **Vệ sinh và khử trùng các loại bề mặt cụ thể**
**Các bề mặt mềm như thảm, thảm nhỏ và rèm**
  * Vệ sinh bề mặt đó bằng sản phẩm có chứa xà phòng, chất tẩy rửa hoặc các loại sản phẩm vệ sinh khác phù hợp để sử dụng trên các bề mặt đó.
  * Giặt những món đồ này (nếu có thể) theo hướng dẫn của nhà sản xuất. Giặt bằng nhiệt độ thích hợp cao nhất và sấy khô hoàn toàn.
  * **Hút bụi như thường lệ.**


**Đồ giặt như quần áo, khăn tắm và ga trải giường**
  * Giặt bằng nhiệt độ thích hợp cao nhất và sấy khô hoàn toàn.
  * Có thể giặt chung đồ của một người bị bệnh với đồ của người khác.
  * Nếu xử lý đồ giặt bẩn từ người bị bệnh, hãy mang bao tay và đeo khẩu trang.
  * Làm sạch khay đựng quần áo hoặc giỏ đựng quần áo theo hướng dẫn đối với các bề mặt.
  * Rửa tay sau khi xử lý quần áo bẩn.
  * Có thể giặt chung đồ của một người bị bệnh COVID-19 với đồ của người khác, nếu cần.


**Các thiết bị điện tử như máy tính bảng, màn hình cảm ứng, bàn phím, điều khiển từ xa và máy ATM.**
  * Cân nhắc việc bọc thiết bị điện tử bằng tấm phủ có thể lau chùi để vệ sinh và khử trùng dễ dàng hơn.
  * Làm theo các hướng dẫn và khuyến nghị của nhà sản xuất để làm sạch đồ điện tử.


#### **Các biện pháp phòng ngừa khi đóng gói và xử lý thực phẩm**
  * Loại bỏ mọi bao bì không cần thiết và bỏ vào thùng rác có nắp đậy.
  * Lấy thực phẩm ra khỏi hộp đựng mang đi, đặt lên đĩa sạch và vứt bỏ hộp đựng.
  * Bao bì như lon có thể được lau sạch bằng chất khử trùng trước khi mở hoặc cất giữ.
  * Rửa kỹ các sản phẩm không đóng gói, chẳng hạn như trái cây và rau quả dưới vòi nước.
  * Rửa tay bằng xà phòng và nước, hoặc sử dụng chất tẩy rửa tay có cồn ngay sau đó.


## **Không gian bên ngoài**
  * Việc phun sản phẩm vệ sinh và khử trùng ở khu vực ngoài trời - như vỉa hè, đường xá, hoặc tấm phủ bề mặt đều **không** cần thiết và có hiệu quả hoặc được khuyên dùng.
  * Các bề mặt tiếp xúc thường xuyên làm bằng nhựa hoặc kim loại, như thanh vịn và kết cấu sân chơi và lan can nên được làm sạch thường xuyên.
  * Vệ sinh và khử trùng các bề mặt bằng gỗ (kết cấu sân chơi bằng gỗ, ghế băng, bàn) hoặc lớp phủ bề mặt (như lớp phủ bổi và cát) không được khuyên dùng.


## **Cách khử trùng**
Điều quan trọng là không lau dung dịch tẩy rửa ngay sau khi bạn vừa thoa lên bề mặt. Nhiều sản phẩm khử trùng, chẳng hạn như khăn lau và thuốc xịt, cần phải để ướt trên bề mặt trong vài phút để có hiệu quả. Luôn đọc hướng dẫn để đảm bảo rằng bạn đang sử dụng các sản phẩm được khuyến nghị và tránh làm hỏng các vật dụng nhạy cảm như điện thoại di động và các thiết bị điện tử khác. Cân nhắc sử dụng khăn lau bề mặt an toàn dành riêng cho các thiết bị điện tử.
Đối với các bề mặt bẩn phải được làm sạch bằng xà phòng và nước trước khi khử khuẩn. Ưu tiên khử khuẩn bằng cách lau rửa. Khử khuẩn bằng các chất tẩy rửa thông thường như chai xịt tẩy rửa đa năng dùng sẵn hoặc pha dung dịch tẩy rửa bồn cầu gia dụng (chứa khoảng 5% sodium hypochlorite) theo tỷ lệ 10ml dung dịch tẩy rửa với 1 lít nước để thành dung dịch có khả năng diệt vi rút, hoặc dung dịch chứa 0,05% Clo hoạt tính sau khi pha để lau các bề mặt. _Lưu ý chỉ pha lượng đủ dùng trong ngày, không để dung dịch đã pha sang ngày hôm sau vì hàm lượng Clo hoạt tính trong dung dịch không còn đủ để khử khuẩn._ Đối với các bề mặt, vật dụng không chịu nước như điều khiển điều hòa, ti vi, công tắc đèn, máy tính, điện thoại và các thiết bị điện tử dùng chung khác..., nên sử dụng dung dịch chứa ít nhất 60% cồn để khử khuẩn bằng cách dùng khăn sạch nhúng vào cồn và lau bề mặt, để khô tự nhiên không rửa lại với nước. Lưu ý tắt các thiết bị điện tử, công tắc đèn trước khi khử khuẩn. Người làm vệ sinh cần sử dụng găng tay cao su, đeo khẩu trang khi thực hiện vệ sinh, khử khuẩn môi trường nơi làm việc.
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [Thời điểm nên vệ sinh và thời điểm khử trùng](https://bvnguyentriphuong.com.vn/kiem-soat-nhiem-khuan/lam-sach-khu-trung-noi-o-va-van-phong-trong-mua-dich-covid#thi-im-nn-v-sinh-v-thi-im-kh-trng)
  * [Vệ sinh và khử trùng các loại bề mặt cụ thể](https://bvnguyentriphuong.com.vn/kiem-soat-nhiem-khuan/lam-sach-khu-trung-noi-o-va-van-phong-trong-mua-dich-covid#v-sinh-v-kh-trng-cc-loi-b-mt-c-th)
  * [Các biện pháp phòng ngừa khi đóng gói và xử lý thực phẩm ](https://bvnguyentriphuong.com.vn/kiem-soat-nhiem-khuan/lam-sach-khu-trung-noi-o-va-van-phong-trong-mua-dich-covid#cc-bin-php-phng-nga-khi-ng-gi-v-x-l-thc-phm)
  * [Không gian bên ngoài](https://bvnguyentriphuong.com.vn/kiem-soat-nhiem-khuan/lam-sach-khu-trung-noi-o-va-van-phong-trong-mua-dich-covid#khng-gian-bn-ngoi)



## ️ PPE là gì? Đồ phòng hộ trong y tế quy định ra sao

Trang thiết bị bảo hộ lao động cá nhân là các trang thiết bị bảo đảm sự an toàn cho người lao động, được sử dụng khi đang làm việc tại một số nơi như: giao thông, công trường… các trang thiết bị bảo hộ lao động phổ biến như mũ bảo hộ, quần áo chống hóa chất, giày bảo hộ, găng tay bảo hộ…
PPE sẽ giúp bảo vệ con người bởi ô nhiễm khói bụi, khí độc, phản ứng sinh hóa học từ môi trường xung quanh cũng như khu vực làm việc phát ra. Mục đích của việc sử dụng thiết bị bảo hộ cá nhân là làm giảm tiếp xúc của người lao động với các mối nguy hiểm xung quanh. PPE sẽ giúp giảm thiểu những rủi ro có thể gặp trong quá trình lao động, bảo vệ con người khỏi các mối nguy hiểm.
PPE sẽ chia ra nhiều cấp độ khác nhau tùy theo mức nguy hiểm của công việc. Mỗi cấp độ sẽ được sản xuất với các chất liệu khác nhau và sử dụng các thiết bị khác nhau nhằm đảm bảo an toàn cho người lao động. Hiện nay, PPE được chia ra thành 4 cấp độ chính: cấp độ 1, cấp độ 2, cấp độ 3, cấp độ 4. Từ cấp độ 4 trở lên sẽ là mức độ nguy hiểm cao nhất.
**Một số quy định về sử dụng PPE trong y tế**
**1. Mang và tháo khẩu trang:**
- Khẩu trang y tế:
+ Kỹ thuật mang khẩu trang: Vệ sinh tay; lấy khẩu trang, một tay cầm vào một cạnh bên; đặt khẩu trang lên mặt, mặt chống thấm quay ra ngoài, mặt thấm hút quay vào trong. Một tay giữ mặt trước khẩu trang cố định trên mặt, một tay luồn một bên dây đeo qua tai sau đó làm ngược lại với bên kia; dùng ngón trỏ và ngón giữa của hai tay ấn chỉnh thanh kim loại trên mũi sao cho ôm sát sống mũi và mặt; dùng hai ngón tay cầm mép dưới của khẩu trang kéo nhẹ xuống dưới, đưa vào trong để khẩu trang bám sát vào mặt dưới cằm.
+ Kỹ thuật tháo khẩu trang: Vệ sinh tay; dùng hai tay cầm phần dây đeo từ sau hai tai, tháo khỏi tai, giữ tay cầm dây đeo đưa khẩu trang ra phía trước và bỏ vào thùng chất thải đúng quy định. Tháo khẩu trang bằng cách chỉ chạm vào dây đeo. Không chạm vào phần trước của khẩu trang; vệ sinh tay.
- Khẩu trang N95
+ Kỹ thuật mang khẩu trang: vệ sinh tay; lấy khẩu trang, đặt khẩu trang vào lòng bàn tay, úp khẩu trang vào sống mũi, miệng, phần có miếng kim loại ở phía trên mũi, để dây đeo thả tự do dưới bàn tay; kéo dây đeo trên vòng qua đầu, để giữ ở phía trên tai. Kéo dây đeo dưới vòng qua đầu, để giữ ở phía dưới tai. Lưu ý không để hai dây bắt chéo nhau ở sau đầu; kiểm tra và chỉnh lại dây đeo nếu bị xoắn, vặn; Dùng ngón trỏ và ngón giữa của hai tay đặt tại đỉnh sống mũi, ấn thanh kim loại sao cho vừa khít vùng mũi; Kiểm tra độ kín của khẩu trang: Úp nhẹ hai tay vào bề mặt ngoài của khẩu trang; thử nghiệm hít vào: hít vào từ từ, nếu khẩu trang ôm kín mặt, áp lực âm làm cho khẩu trang bám sát vào khuôn mặt, khẩu trang kín sẽ hơi xẹp và không có luồng khí lọt qua. Nếu khẩu trang không ôm kín mặt, không khí sẽ qua khe hở giữa khẩu trang và mặt, cần điều chỉnh lại độ căng của dây đeo và làm lại thử nghiệm hít vào; thử nghiệm thở ra: thở ra mạnh, nếu khẩu trang ôm kín mặt, áp lực dương làm cho khẩu trang hơi phồng ra và không có luồng khí lọt vào. Nếu khẩu trang không ôm kín mặt, không khí sẽ qua khe hở giữa khẩu trang và mặt, cần điều chỉnh lại độ căng của dây đeo và làm lại thử nghiệm thở ra.
+ Kỹ thuật tháo khẩu trang: Vệ sinh tay; tháo dây dưới bằng cách cầm vào phần dây sau đầu và nhấc qua khỏi đầu, sau đó tháo dây trên qua khỏi đỉnh đầu, nhẹ nhàng đưa khẩu trang khỏi mặt; tránh để khẩu trang úp vào mặt và tránh tay chạm vào mặt trước khẩu trang khi tháo; vệ sinh tay.
Lưu ý khi mang và tháo khẩu trang thì cần mang khẩu trang đúng chiều trên, dưới; mang khẩu trang đúng mặt trong, ngoài; không chạm tay vào mặt trong khẩu trang khi mang; dặt khẩu trang cẩn thận để che kín miệng và mũi; chỉnh gọng mũi và dây đeo để bảo đảm khẩu trang ôm sát sống mũi và khuôn mặt, không để không khí đi vào/ra qua khe hở giữa khẩu trang và mặt; tay không chạm vào mặt trước khẩu trang khi loại bỏ khẩu trang; sau khi loại bỏ hoặc bất cứ khi nào vô tình chạm vào khẩu trang đã sử dụng, cần làm sạch tay bằng dung dịch VST có chứa cồn hoặc rửa tay bằng xà phòng và nước; thay khẩu trang ngay khi thấy khẩu trang bị nhiễm bẩn hoặc bị ẩm/ướt, sau mỗi khi thực hiện thủ thuật sạch/vô khuẩn hoặc sau mỗi ca làm việc; không sử dụng lại khẩu trang đã qua sử dụng; khi lấy khẩu trang mới: Kiểm tra để không có lỗi, lỗ hổng hoặc vết bẩn.
**2. Sử dụng phương tiện phòng hộ cá nhân (PHCN):**
- Mang phương tiện phòng hộ cá nhân: trước khi mang phương tiện PHCN cần kiểm tra số lượng, loại, kích cỡ phù hợp với người mang; kiểm tra chất lượng đúng tiêu chuẩn quy định, không rách, thủng, hết hạn,..., sau đó lần lượt tiến hành các bước:
  * Bước 1: Vệ sinh tay.
  * Bước 2: Mặc áo choàng chống dịch.
  * Bước 3 : Vệ sinh tay.
  * Bước 4: Mang khẩu trang theo tình huống (khẩu trang y tế hoặc N95).
  * Bước 5: Mang kính bảo hộ hoặc tấm che mặt.
  * Bước 6 : Mang găng theo chỉ định.


Trình tự tháo bỏ phương tiện phòng hộ cá nhân
  * Bước 1: Tháo găng. Khi tháo cuộn mặt trong găng ra ngoài, bỏ vào thùng đựng chất thải.
  * Bước 2: Vệ sinh tay.
  * Bước 3: Tháo dây buộc/khuy cài và tháo bỏ áo choàng, cuộn lại sao cho mặt trong của áo choàng lộn ra ngoài và bỏ vào thùng chất thải.
  * Bước 4: Vệ sinh tay.
  * Bước 5: Tháo tấm che mặt hoặc kính bảo hộ.
  * Bước 6: Vệ sinh tay.
  * Bước 7: Tháo khẩu trang (cầm vào phần dây đeo phía sau đầu hoặc sau tai).
  * Bước 8: Vệ sinh tay.


Lưu ý khi tháo bỏ phương tiện phòng hộ cá nhân: Các phương tiện PHCN được tháo bỏ tại phòng đệm và cho ngay vào thùng chất thải lây nhiễm sau khi tháo bỏ. Luôn vệ sinh tay khi tháo bỏ từng phương tiện PHCN; khu vực mặc và tháo bỏ phương tiện PHCN phải là hai khu vực riêng biệt; Bộ quần áo mặc trong trang phục PHCN được thay và giặt tập trung sau mỗi ca làm việc.
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh

## ️ Tiêu chuẩn khẩu trang thường dùng

  * [Chỉ dùng cho kỹ thuật viên xét nghiệm, nhân viên y tế, người tiếp xúc trực tiếp để khám, điều trị, chăm sóc người bệnh Covid-19. ](https://bvnguyentriphuong.com.vn/kiem-soat-nhiem-khuan/tieu-chuan-khau-trang-thuong-dung#ch-dng-cho-k-thut-vin-xt-nghim-nhn-vin-y-t-ngi-tip-xc-trc-tip-khm-iu-tr-chm-sc-ngi-bnh-covid19)
  * [Bộ TCVN 8389:2010 Khẩu trang y tế, gồm các tiêu chuẩn sau:](https://bvnguyentriphuong.com.vn/kiem-soat-nhiem-khuan/tieu-chuan-khau-trang-thuong-dung#b-tcvn-83892010-khu-trang-y-t-gm-cc-tiu-chun-sau)


**1. Khẩu trang là gì?**
Khẩu trang là loại mặt nạ bảo hộ giúp che chắn vùng mũi, miệng, hạn chế nguy cơ hít phải chất độc hại, ngăn mùi, giảm nguy cơ tiếp xúc với virus và hóa chất. Khẩu trang có nhiều loại khác nhau, mỗi dòng khẩu trang có công dụng riêng biệt nhưng đều có chức năng chính là bảo vệ hệ hô hấp. 
**2. Một số hệ thống tiêu chuẩn**
**2.1 NIOSH là gì?**
NIOSH là viết tắt của từ tiếng Anh National Institute for Occupational Safety and Health - Viện Quốc gia về An toàn và Sức khỏe Nghề nghiệp Hoa Kỳ. NIOSH được thành lập như một cơ quan nghiên cứu tập trung vào việc nghiên cứu an toàn và sức khỏe của người lao động, đồng thời trao quyền cho người sử dụng lao động và người lao động để tạo ra nơi làm việc an toàn và lành mạnh. NIOSH là một phần của Trung tâm Kiểm soát và Phòng ngừa Dịch bệnh Hoa Kỳ, thuộc Bộ Y tế và Dịch vụ Nhân sinh Hoa Kỳ. Tiêu chuẩn NIOSH về mặt nạ, khẩu trang - Dùng để đánh giá khả năng ngăn chất độc hại, khả năng chống ô nhiễm của những dòng sản phẩm bảo hộ như khẩu trang và mặt nạ. NIOSH được đánh giá là một tiêu chuẩn chất lượng, có độ chính xác cao. Hiện nay, các dòng khẩu trang và mặt nạ đều sử dụng tiêu chuẩn NIOSH là quy chuẩn để đánh giá. NIOSH gồm nhiều tiêu chuẩn, chúng thường được in tại bao bì hoặc bề mặt sản phẩm. Một số tiêu chuẩn khẩu trang thường gặp nhất phải kể đến là: N95, N99, N100, R95, P95, P99, P100
**Tiêu chuẩn NIOSH về mặt nạ, khẩu trang**
Dùng để đánh giá khả năng ngăn chất độc hại, khả năng chống ô nhiễm của những dòng sản phẩm bảo hộ như khẩu trang và mặt nạ. NIOSH được đánh giá là một tiêu chuẩn chất lượng, có độ chính xác cao. Hiện nay, các dòng khẩu trang và mặt nạ đều sử dụng tiêu chuẩn NIOSH là quy chuẩn để đánh giá. NIOSH gồm nhiều tiêu chuẩn, chúng thường được in tại bao bì hoặc bề mặt sản phẩm. Một số tiêu chuẩn khẩu trang thường gặp nhất phải kể đến là: N95, N99, N100, R95, P95, P99, P100 Các ký hiệu thường gặp là các chữ cái như N, R, P cùng một chữ số biểu thị. Trong đó, các chữ cái sẽ đại diện cho khả năng lọc khi tiếp xúc với dầu. Thứ tự từ hoàn toàn chống được dấu, chống một phần và không chống được lần lượt sẽ là P, R, N. Các chữ số sẽ thể hiện khả năng, tỷ lệ phần trăm lọc bụi.
- Tiêu chuẩn NIOSH N95: hiệu suất lọc ít nhất 95% bụi, không có khả năng chống dầu. N95 là loại mặt nạ/khẩu trang chống độc có khả năng lọc và ngăn chặn sự tiếp xúc của bụi PM 2.5 tới sức khỏe con người. 
- Tiêu chuẩn NIOSH N99: hiệu suất lọc ít nhất 99% các loại bụi siêu vi, không có khả năng chống dầu. 
- Tiêu chuẩn NIOSH N100: loại bỏ 99.97% các hạt, bụi trong không khí. Không có khả năng chống dầu. 
- Tiêu chuẩn NIOSH R95: khả năng lọc 95% các hạt trong không khí. Kháng dầu nhẹ. 
- Tiêu chuẩn NIOSH P95: khả năng lọc 95% các hạt trong không khí. Có khả năng chống dầu mạnh mẽ. 
- Tiêu chuẩn NIOSH P99: khả năng lọc 99% các hạt trong không khí. Có khả năng chống dầu mạnh mẽ. Tiêu chuẩn NIOSH P100: khả năng lọc 99,97% các hạt trong không khí. Có khả năng chống dầu mạnh mẽ. 
- Tiêu chuẩn KN95: tiêu chuẩn Trung Quốc về khẩu trang, mặt nạ: Hiệu suất lọc ít nhất 95%. Tiêu chuẩn FFP2: tiêu chuẩn châu Âu về khẩu trang, mặt nạ. Hiệu xuất lọc ít nhất 94%. Các tiêu chuẩn NIOSH N95 (Mỹ) , FFP2 (Châu Âu), KN95 (Trung Quốc) được đánh giá tương đương nhau về hiệu suất lọc
Trong số những loại khẩu trang đạt tiêu chuẩn NIOSH thì N95 là loại khẩu trang được sử dụng phổ biến hơn cả. Loại khẩu trang/mặt nạ chống độc này có thể loại bỏ những loại bụi PM 2.5 siêu nhỏ có kích cỡ 0.3 micromet. Đây là loại bụi thường gặp và có mức độ nguy hiểm nhất hiện nay. 
**2.2 Tiêu chuẩn EN 149 là gì?**
EN 149 quy định về: Thiết bị bảo vệ đường hô hấp - Mặt nạ lọc một nửa để bảo vệ khỏi các hạt, bụi. 
Tiêu chuẩn Châu Âu này quy định các yêu cầu tối thiểu để lọc một nửa mặt nạ được sử dụng làm thiết bị bảo vệ đường hô hấp, đặc biệt chống lại các hạt và các thử nghiệm hiệu suất thực tế và phòng thí nghiệm bắt buộc để đánh giá sự tuân thủ của mặt nạ. Tiêu chuẩn EN149:1991 trước đây, phân loại mặt nạ nửa mặt thành FFP1S, FFP2S, FFP2SL, FFP3S và FFP3SL.
Mặt nạ FFP phải đủ điều kiện đáp ứng tiêu chuẩn EN 149. Tiêu chuẩn Châu Âu EN 149: 2001 thiết lập các đặc tính của thiết bị hô hấp. Tiêu chuẩn này bao gồm các xét nghiệm trong phòng thí nghiệm, test hiện trường cùng các yêu cầu nhất định để đảm bảo tính tương thích phù hợp của mặt nạ. 
Các đặc điểm được phân tích bao gồm 
  * Bao bì sản phẩm 
  * Vật liệu: Khả năng chống thao tác 
  * Kiểm tra hiệu suất thực tế 
  * Rò rỉ: Rò rỉ toàn bộ vào bên trong và sự xâm nhập của vật liệu lọc 


Có một số tổ chức châu Âu cấp giấy chứng nhận kiểm tra xác nhận sự phù hợp và chỉ định các đặc điểm của sản phẩm: INRS APAVE ở Pháp; INSPECT ở Anh; FACE AUSSCHUSS ở Đức
  * Khẩu trang FFP1 chống lại các hạt rắn lớn. Chỉ thích hợp để bảo vệ chống lại các chất gây kích ứng, không có hại. Hiệu suất lọc tối thiểu 80%. 
  * Khẩu trang FFP2 bảo vệ chống lại các bình xịt kích ứng dạng rắn, lỏng và có hại. Hiệu suất lọc tối thiểu 94%. 
  * Khẩu trang FFP3 chống lại các bình xịt độc chất rắn lỏng độc hại. Hiệu suất lọc tối thiểu 99%. 


Hiện nay, tỉ lệ người mắc các bệnh về đường hô hấp ngày một tăng một phần do môi trường ngày càng ô nhiễm. Việc sử dụng các biện pháp bảo vệ sức khỏe là rất cần thiết. Khẩu trang chống bụi là một trong những giải pháp hiệu quả giúp loại bỏ phần nào các tác nhân và mầm mống gây bệnh. 
Khẩu trang đang là “cứu tinh” trong việc phòng lây nhiễm các bệnh liên quan đến đường hô hấp, nhất là trong thời điểm dịch Covid 19 đang có diễn biến phức tạp. Để phát huy được hiệu quả tại mỗi chiếc khẩu trang cần có lớp bảo vệ như FFP1, FFP2, FFP3 của EN 149:2001.
**3. Khẩu trang y tế N95 hoặc tương đương**
## Chỉ dùng cho kỹ thuật viên xét nghiệm, nhân viên y tế, người tiếp xúc trực tiếp để khám, điều trị, chăm sóc người bệnh Covid-19. 
Gồm các loại tiêu chuẩn tương đương phổ biến: 
+ Mỹ: N95 Respirator (tiêu chuẩn NIOSH-42C FR84) 
+ Châu Âu: FFP2 Respirator (tiêu chuẩn EN 149-2001) 
+ Úc, Newzealand: P2 Respirator (tiêu chẩn AS/NZ 1716:2012) 
+ Trung Quốc: KN95 Respirator (tiêu chuẩn GB2626-20 06) 
+ Nhật bản: DS Respirator (tiêu chuẩn JMHLW- Notification 214, 2018) 
+ Hàn Quốc: Korea 1st Class Respirator (tiêu chuẩn KMOEL-2017-64).
**4. Khẩu trang y tế**
Dành cho cán bộ y tế khi làm việc trong môi trường y tế ở khu vực có khả năng lây nhiễm và tiếp xúc nhiều với người bệnh (khoa khám bệnh, khoa điều trị, khoa hồi sức tích cực,…).
Được quản lý là trang thiết bị y tế (đáp ứng tiêu chuẩn tối thiểu đạt TCVN 8389-1 : 2010; TCVN 8389-2 : 2010; TCVN 8389-3 : 2010 và đã có số lưu hành do cơ quan y tế có thẩm quyền cấp theo quy định của Nghị định 36/2016/NĐCP).
### **Bộ TCVN 8389:2010 Khẩu trang y tế, gồm các tiêu chuẩn sau:**
– TCVN 8389-1:2010 Phần 1: Khẩu trang y tế thông thường.
– TCVN 8389-2:2010 Phần 2: Khẩu trang y tế phòng nhiễm khuẩn.
– TCVN 8389-3:2010 Phần 3: Khẩu trang y tế phòng độc hóa chất.
Khẩu trang y tế thông thường: là khẩu trang y tế (đã tiệt khuẩn và không tiệt khuẩn) sử dụng trong các cơ sở y tế, gồm các bộ phận: các lớp vải: có thể có từ 2 đến 4 lớp vải không dệt, dạng phẳng, có gấp nếp; lớp vi lọc; thanh nẹp mũi; dây đeo.
Khẩu trang y tế phòng nhiễm khuẩn có tác dụng ngăn cản và diệt 99,9% vi khuẩn ngay trên bề mặt khẩu trang, gồm các bộ phận: các lớp vải có thể có từ 2 đến 4 lớp dạng phẳng có gấp nếp hoặc có từ 5 đến 7 lớp dạng mõm; lớp vi lọc; lóp vải tẩm chất nano – bạc; thanh nẹp mũi; đệm mũi, dây đeo; khóa điều chỉnh dây đeo (nếu cần).
Khẩu trang y tế phòng độc hóa chất có tác dụng lọc khí độc và hơi độc, tạo luồng khí sạch sau khi đi qua lớp vi Iọc than hoạt tính, gồm các bộ phận: các lớp vải (có thể có từ 2 đến 4 lớp vải dạng phẳng có gấp nếp hoặc có từ 5 đến 7 lớp dạng mõm); lớp vi lọc; lớp than hoạt tính; thanh nẹp mũi; đệm mũi, dây đeo.
Trong đó, khẩu trang y tế phòng nhiễm khuẩn đang được khuyến cáo sử dụng trong tình hình đại dịch Covid 19 hiện nay. Giữa xu thế các doanh nghiệp đẩy mạnh nghiên cứu, tiến hành sản xuất và tìm kiếm tiêu chuẩn chứng nhận, thì TCVN 8389-2:2010 là tiêu chuẩn mà nhiều doanh nghiệp quan tâm nhất.
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [Chỉ dùng cho kỹ thuật viên xét nghiệm, nhân viên y tế, người tiếp xúc trực tiếp để khám, điều trị, chăm sóc người bệnh Covid-19. ](https://bvnguyentriphuong.com.vn/kiem-soat-nhiem-khuan/tieu-chuan-khau-trang-thuong-dung#ch-dng-cho-k-thut-vin-xt-nghim-nhn-vin-y-t-ngi-tip-xc-trc-tip-khm-iu-tr-chm-sc-ngi-bnh-covid19)
  * [Bộ TCVN 8389:2010 Khẩu trang y tế, gồm các tiêu chuẩn sau:](https://bvnguyentriphuong.com.vn/kiem-soat-nhiem-khuan/tieu-chuan-khau-trang-thuong-dung#b-tcvn-83892010-khu-trang-y-t-gm-cc-tiu-chun-sau)



## Hướng dẫn về Các loại khẩu trang

  * [1. Khẩu trang vải](https://bvnguyentriphuong.com.vn/kiem-soat-nhiem-khuan/cac-loai-khau-trang#1-khu-trang-vi)
  * [2. Khẩu trang dùng một lần](https://bvnguyentriphuong.com.vn/kiem-soat-nhiem-khuan/cac-loai-khau-trang#2khu-trang-dng-mt-ln)
  * [3. Khẩu trang đáp ứng tiêu chuẩn](https://bvnguyentriphuong.com.vn/kiem-soat-nhiem-khuan/cac-loai-khau-trang#3-khu-trang-p-ng-tiu-chun)
  * [Cách tháo khẩu trang](https://bvnguyentriphuong.com.vn/kiem-soat-nhiem-khuan/cac-loai-khau-trang#cch-tho-khu-trang)


_**Có nhiều loại khẩu trang quý vị có thể dùng để bảo vệ bản thân và người khác khỏi bị nhiễm và lây lan COVID-19. Khi chọn khẩu trang, chọn cái vừa khớp với khuôn mặt. Tìm hiểu thêm về cách chọn khẩu trang vừa khớp và bảo vệ tốt nhất.**_
## 1. Khẩu trang vải
**Khẩu trang vải** có thể làm từ nhiều loại vải khác nhau và hiện có sẵn nhiều loại khẩu trang vải.
**Tìm kiếm**
  * Nhiều lớp vải dệt chặt và thoáng khí
  * Gọng mũi
  * Khẩu trang phải chặn được ánh sáng khi giơ ra dưới nguồn ánh sáng


**KHÔNG đeo**
  * Khẩu trang có van thở hoặc lỗ thông hơi
  * Khẩu trang một lớp hoặc làm bằng vải mỏng không chặn được ánh sáng


## 2. Khẩu trang dùng một lần
Khẩu trang dùng **một lần** hiện có bán rộng rãi trên thị trường.
**Tìm kiếm:**
  * Mô tả cho thấy nhiều lớp vật liệu không dệt
  * Gọng mũi 


**KHÔNG đeo**
  * Khẩu trang có khoảng trống quanh hai bên mặt hoặc mũi
  * Nếu ẩm hoặc bị bẩn 


**Cách để có lớp bảo vệ phụ và vừa khớp tốt hơn**
  * Đeo hai khẩu trang (khẩu trang dùng một lần bên dưới **VÀ** khẩu trang vải bên ngoài)
  * Khẩu trang vải có thể kết hợp với phần lắp khớp hoặc nẹp
  * Thắt nút và nhét vòng đeo tai của khẩu trang 3 lớp ở nơi chúng tiếp xúc với mép khẩu trang
    * Gấp lại và nhét vào bên trong phần vật liệu không cần thiết bên dưới các mép.
    * (Để biết hướng dẫn, hãy xem phần sau [https://youtu.be/GzTAZDsNBe0external icon](https://youtu.be/GzTAZDsNBe0))


## 3. Khẩu trang đáp ứng tiêu chuẩn
**Tìm các khẩu trang có ghi nhãn**
  * ĐÁP ỨNG ASTM F3502
  * ĐÁP ỨNG TIÊU CHUẨN TẠI NƠI LÀM VIỆC
  * ĐÁP ỨNG TIÊU CHUẨN TẠI NƠI LÀM VIỆC VÀ NHIỀU HƠN NỮA
  * KN95


**KHÔNG đeo**
  * Nếu quý vị có một số loại râu nhất định
  * Khẩu trang KN95 giả mạo (hàng giả)
  * Nếu thấy khó thở
  * Nếu ẩm hoặc bị bẩn
  * Với khẩu trang khác theo cách không phù hợp


**Thời điểm nên đeo**
  * Bất cứ khi nào phù hợp để đeo khẩu trang
  * Ở nơi làm việc, khi không đòi hỏi phải dùng mặt nạ hoặc khẩu trang y tế, sử dụng loại khẩu trang vải phù hợp.


**Cách đeo**
Làm theo hướng dẫn của nhà sản xuất để đeo, cất giữ và vệ sinh hoặc thải bỏ khẩu trang theo cách phù hợp.
## Cách Lựa Chọn
Quý vị có nhiều lựa chọn khi chọn khẩu trang. Dưới đây là một số điều nên làm và không nên làm.
## Cách tháo khẩu trang
**(Theo hướng dẫn của CDC)**
  * [1. Khẩu trang vải](https://bvnguyentriphuong.com.vn/kiem-soat-nhiem-khuan/cac-loai-khau-trang#1-khu-trang-vi)
  * [2. Khẩu trang dùng một lần](https://bvnguyentriphuong.com.vn/kiem-soat-nhiem-khuan/cac-loai-khau-trang#2khu-trang-dng-mt-ln)
  * [3. Khẩu trang đáp ứng tiêu chuẩn](https://bvnguyentriphuong.com.vn/kiem-soat-nhiem-khuan/cac-loai-khau-trang#3-khu-trang-p-ng-tiu-chun)
  * [Cách tháo khẩu trang](https://bvnguyentriphuong.com.vn/kiem-soat-nhiem-khuan/cac-loai-khau-trang#cch-tho-khu-trang)



## ️ Tránh nhiễm trùng tại Bệnh viện

  * [Mầm bệnh lây truyền qua máu và cách phòng tránh](https://bvnguyentriphuong.com.vn/kiem-soat-nhiem-khuan/tranh-nhiem-trung-tai-benh-vien#mm-bnh-ly-truyn-qua-mu-v-cch-phng-trnh)
  * [​ Mọi chất dịch cơ thể đều mang mầm bệnh?](https://bvnguyentriphuong.com.vn/kiem-soat-nhiem-khuan/tranh-nhiem-trung-tai-benh-vien#mi-cht-dch-c-th-u-mang-mm-bnh)
  * [Làm gì khi bị dính máu vì một vết cắt, bị kim đâm hay bị máu bắn tóe?](https://bvnguyentriphuong.com.vn/kiem-soat-nhiem-khuan/tranh-nhiem-trung-tai-benh-vien#lm-g-khi-b-dnh-mu-v-mt-vt-ct-b-kim-m-hay-b-mu-bn-te)
  * [Bị máu dây hoặc bắn vào người thì nên làm thế nào?](https://bvnguyentriphuong.com.vn/kiem-soat-nhiem-khuan/tranh-nhiem-trung-tai-benh-vien#b-mu-dy-hoc-bn-vo-ngi-th-nn-lm-th-no)
  * [Làm thế nào để bảo vệ bản thân khỏi nhiễm trùng lao?](https://bvnguyentriphuong.com.vn/kiem-soat-nhiem-khuan/tranh-nhiem-trung-tai-benh-vien#lm-th-no-bo-v-bn-thn-khi-nhim-trng-lao)
  * [Có nên chủng ngừa thủy đậu khi đã bị rồi?](https://bvnguyentriphuong.com.vn/kiem-soat-nhiem-khuan/tranh-nhiem-trung-tai-benh-vien#c-nn-chng-nga-thy-u-khi-b-ri)
  * [Có thể tái nhiễm bệnh thủy đậu hay không?](https://bvnguyentriphuong.com.vn/kiem-soat-nhiem-khuan/tranh-nhiem-trung-tai-benh-vien#c-th-ti-nhim-bnh-thy-u-hay-khng)
  * [Bệnh ho gà có thể ngăn ngừa bằng tiêm chủng?](https://bvnguyentriphuong.com.vn/kiem-soat-nhiem-khuan/tranh-nhiem-trung-tai-benh-vien#bnh-ho-g-c-th-ngn-nga-bng-tim-chng)


## **Mầm bệnh lây truyền qua máu và cách phòng tránh**
Nhiều trường hợp nhiễm trùng xảy ra vì lây truyền qua máu hoặc dịch cơ thể. Virus (vi-rút) gây suy giảm miễn dịch ở người (HIV) và virus gây viêm gan siêu vi B là những ví dụ phổ biến. Tuy nhiên, nhiễm trùng do virus và vi khuẩn khác (như giang mai và viêm gan siêu vi C) cũng có thể lây truyền qua máu hoặc dịch cơ thể. Các hướng dẫn sau đây có thể giúp bạn tự bảo vệ mình:
  * Xem mọi bệnh nhân đều có khả năng nhiễm bệnh và tránh tiếp xúc với máu hoặc dịch cơ thể của bệnh nhân.
  * Tránh những hành vi nguy hiểm khi sử dụng kim tiêm và các dụng cụ sắc nhọn (kéo, dao mổ, và các loại dao khác). Ví dụ, không cố gắng để đóng nắp kim tiêm lại. Hãy cẩn thận vứt bỏ dụng cụ sắc nhọn trong các thùng chứa thích hợp.
  * **Trang bị đồ bảo hộ** (kể cả găng tay và mặt nạ) để tránh máu văng lên da hoặc vào trong mắt khi bạn đang thực hiện các thủ thuật có thể gây ra sự bắn tóe hoặc tràn máu.
  * Hãy chắc chắn rằng **bạn đã chủng ngừa viêm gan siêu vi B**. Việc tiêm chủng thường được tiến hành tại nơi bạn làm việc.


## **​ Mọi chất dịch cơ thể đều mang mầm bệnh?**
Chất dịch cơ thể như nước mắt, mồ hôi, nước tiểu, nước bọt và những thứ nôn mửa ra không được xem là có mang mầm bệnh lây qua máu, trừ khi chúng có máu lẫn vào. Thật ra, những thứ như nước tiểu hoặc phân có thể chứa vi khuẩn hay các tác nhân lây nhiễm nhưng không được coi là mầm bệnh lây qua máu. Hầu hết các loại dịch cơ thể khác có thể truyền mầm bệnh lây qua máu. Những thứ đó bao gồm tinh dịch, dịch tiết âm đạo, dịch màng ngoài tim (dịch quanh tim), dịch phúc mạc (dịch trong ổ bụng và vùng chậu), dịch khớp, nước ối (dịch quanh thai nhi), dịch màng phổi (dịch trong lồng ngực) và dịch não tủy (dịch trong não và tủy sống).
## **Làm gì khi bị dính máu vì một vết cắt, bị kim đâm hay bị máu bắn tóe?**
Nếu sự cố xảy ra, hãy nói cho người cấp trên hoặc phòng trung tâm y tế ở cơ quan ngay lập tức. Nếu da bị rách bởi một cây kim, hoặc nếu máu đã văng vào mắt, vào miệng hoặc lên da bị trầy xước, bạn và bệnh nhân nguồn (người có nguồn máu gây lây nhiễm) phải được kiểm tra. Bệnh nhân cũng sẽ được tìm hiểu xem hiện tại và trong quá khứ đã bị nhiễm bệnh gì. Nếu bệnh nhân nguồn bị nhiễm viêm gan siêu vi B thì dù có tiêm chủng rồi bạn cũng không được miễn dịch với loại virus này và cần được tiêm thêm globulin miễn dịch chống viêm gan B. Nếu bệnh nhân nguồn bị bệnh giang mai, bạn cần được điều trị bằng kháng sinh. Nếu bệnh nhân nguồn bị nhiễm HIV, bạn cần phải dùng thuốc dự phòng trong 4 tuần. Những điều trị này nên được bắt đầu trong vòng vài giờ sau khi xảy ra tai nạn. Tùy thuộc vào mức độ rủi ro gây ra bởi bệnh nhân nguồn, bạn cần được xét nghiệm máu lặp lại từ 6 đến 9 tháng để chắc rằng sự lây nhiễm được phát hiện càng sớm càng tốt (nếu có).
## **Bị máu dây hoặc bắn vào người thì nên làm thế nào?**
Nếu da không bị nứt, xước hoặc nổi mụn, bạn hầu như **không có** nguy cơ bị lây nhiễm khi máu dây hoặc bắn vào người. Nếu bạn bị dính máu, hãy rửa sạch sẽ khu vực đó.
## **Làm thế nào để bảo vệ bản thân khỏi nhiễm trùng lao?**
Điều quan trọng là nắm rõ bệnh nhân nào có thể mắc bệnh lao. Khi bệnh nhân ho, những giọt nhỏ chứa vi khuẩn lao văng ra không khí và bạn có thể mắc bệnh nếu hít phải. Bệnh nhân bị bệnh lao có thể có các triệu chứng như ho mạn tính (kéo dài trong nhiều tuần, ho ra đàm hoặc máu), giảm cân, sốt hoặc đổ mồ hôi vào ban đêm. Nếu bạn làm việc gần bệnh nhân lao, hãy đeo mặt nạ chuyên dụng để bảo vệ. Bệnh nhân cũng cần đeo mặt nạ và được tách biệt với những bệnh nhân khác. Ví dụ, di dời họ khỏi phòng chờ chung, hoặc đưa họ vào khu điều trị riêng trong bệnh viện.
## **Có nên chủng ngừa thủy đậu khi đã bị rồi?**
Ngay cả khi bạn chưa hề bị thủy đậu, bạn cũng **nên làm xét nghiệm máu để kiểm tra miễn dịch** (khả năng đề kháng của cơ thể). Hầu hết người lớn có miễn dịch với bệnh thủy đậu ngay cả khi chưa hề mắc bệnh. Nếu xét nghiệm cho thấy bạn chưa có miễn dịch với thủy đậu, hãy tiêm chủng ngừa thủy đậu. Nếu không tiêm phòng, bạn có nguy cơ mắc bệnh thủy đậu và lây nhiễm cho bệnh nhân.
## **Có thể tái nhiễm bệnh thủy đậu hay không?**
Việc đã mắc bệnh thủy đậu thường có nghĩa rằng bạn có miễn dịch với mầm bệnh này. Tuy nhiên, vẫn có người bị thủy đậu lần thứ hai mặc dù điều này khá hiếm. Chuyện này vẫn có thể xảy ra ngay cả khi xét nghiệm máu cho thấy bạn đang có miễn dịch với thủy đậu. Không có cách nào 100% chắc chắn tránh được việc nhiễm lại. Tuy nhiên, bệnh thủy đậu thường nhẹ hơn khi nhiễm lần thứ hai. Nếu bạn bị nhiễm lại, hãy nói ngay với cấp trên để giảm thiểu việc tiếp xúc với bệnh nhân.
## **Bệnh ho gà có thể ngăn ngừa bằng tiêm chủng?**
Sau khi trẻ em được chủng ngừa bệnh ho gà, khả năng miễn dịch chỉ kéo dài cho đến khi chúng trưởng thành. Điều này có nghĩa là thanh thiếu niên và người lớn có thể mắc bệnh ho gà. Vắc-xin ho gà tăng cường hiện có sẵn cho cả thanh thiếu niên và người lớn. Người lớn làm việc trong lĩnh vực chăm sóc sức khỏe nên nhận liều tăng cường 10 năm một lần để giảm nguy cơ mắc bệnh ho gà. Ho gà là nguyên nhân của chứng ho hoặc viêm phế quản kéo dài dai dẳng hơn cảm lạnh thông thường. Nếu cảm lạnh kéo dài hơn 2 tuần, bạn nên gặp bác sĩ. Bệnh ho gà có thể đe dọa tính mạng của trẻ sơ sinh chưa được miễn dịch.
Xem thêm: [**Huớng dẫn mặc đồ bảo hộ cho nhân viên y tế**](https://www.youtube.com/watch?v=T8muqwbvM9M)
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [Mầm bệnh lây truyền qua máu và cách phòng tránh](https://bvnguyentriphuong.com.vn/kiem-soat-nhiem-khuan/tranh-nhiem-trung-tai-benh-vien#mm-bnh-ly-truyn-qua-mu-v-cch-phng-trnh)
  * [​ Mọi chất dịch cơ thể đều mang mầm bệnh?](https://bvnguyentriphuong.com.vn/kiem-soat-nhiem-khuan/tranh-nhiem-trung-tai-benh-vien#mi-cht-dch-c-th-u-mang-mm-bnh)
  * [Làm gì khi bị dính máu vì một vết cắt, bị kim đâm hay bị máu bắn tóe?](https://bvnguyentriphuong.com.vn/kiem-soat-nhiem-khuan/tranh-nhiem-trung-tai-benh-vien#lm-g-khi-b-dnh-mu-v-mt-vt-ct-b-kim-m-hay-b-mu-bn-te)
  * [Bị máu dây hoặc bắn vào người thì nên làm thế nào?](https://bvnguyentriphuong.com.vn/kiem-soat-nhiem-khuan/tranh-nhiem-trung-tai-benh-vien#b-mu-dy-hoc-bn-vo-ngi-th-nn-lm-th-no)
  * [Làm thế nào để bảo vệ bản thân khỏi nhiễm trùng lao?](https://bvnguyentriphuong.com.vn/kiem-soat-nhiem-khuan/tranh-nhiem-trung-tai-benh-vien#lm-th-no-bo-v-bn-thn-khi-nhim-trng-lao)
  * [Có nên chủng ngừa thủy đậu khi đã bị rồi?](https://bvnguyentriphuong.com.vn/kiem-soat-nhiem-khuan/tranh-nhiem-trung-tai-benh-vien#c-nn-chng-nga-thy-u-khi-b-ri)
  * [Có thể tái nhiễm bệnh thủy đậu hay không?](https://bvnguyentriphuong.com.vn/kiem-soat-nhiem-khuan/tranh-nhiem-trung-tai-benh-vien#c-th-ti-nhim-bnh-thy-u-hay-khng)
  * [Bệnh ho gà có thể ngăn ngừa bằng tiêm chủng?](https://bvnguyentriphuong.com.vn/kiem-soat-nhiem-khuan/tranh-nhiem-trung-tai-benh-vien#bnh-ho-g-c-th-ngn-nga-bng-tim-chng)



## ️ Nghiên cứu cho thấy khẩu trang có thể được khử trùng hiệu quả tại nhà

  * [COVID-19 và khẩu trang](https://bvnguyentriphuong.com.vn/nghien-cuu-duoc-dang-tai-tren-tap-chi-quoc-te/nghien-cuu-cho-thay-khau-trang-co-the-duoc-khu-trung-hieu-qua-tai-nha#covid19-v-khu-trang)
  * [Kiểm tra trên mô hình](https://bvnguyentriphuong.com.vn/nghien-cuu-duoc-dang-tai-tren-tap-chi-quoc-te/nghien-cuu-cho-thay-khau-trang-co-the-duoc-khu-trung-hieu-qua-tai-nha#kim-tra-trn-m-hnh)
  * [Xử lý nhiệt không làm giảm hiệu quả](https://bvnguyentriphuong.com.vn/nghien-cuu-duoc-dang-tai-tren-tap-chi-quoc-te/nghien-cuu-cho-thay-khau-trang-co-the-duoc-khu-trung-hieu-qua-tai-nha#x-l-nhitkhng-lm-gim-hiu-qu)


Các nhà nghiên cứu kết luận rằng khẩu trang vải và một số khẩu trang y tế có thể được khử trùng đơn giản mà không làm giảm đáng kể hiệu quả của chúng.
Một nghiên cứu mới đã phát hiện ra rằng việc khử trùng khẩu trang vải bằng cách xử lý nhiệt chúng có thể không làm giảm đáng kể hiệu quả và một số khẩu trang y tế cũng có thể thực hiện phương pháp này mà vẫn giữ được tính bảo vệ hiệu quả.
Nghiên cứu được công bố trên Tạp chí của Hiệp hội bảo vệ hô hấp quốc tế có thể có giá trị trong việc giảm tải đối với trữ lượng khẩu trang y tế trong đại dịch Coronavirus 19 (COVID-19).
## **COVID-19 và khẩu trang**
Theo Tổ chức Y tế Thế giới (WHO), virus gây ra COVID-19, hội chứng hô hấp cấp tính nặng Coronavirus 2 (SARS-CoV-2), chủ yếu lây truyền qua giọt bắn (ho và hắt hơi).
Những giọt nước bọt và nước mũi chảy ra có thể mang virus. Nó có thể lây truyền trực tiếp nếu một người hít phải các giọt hắt hơi từ người bị nhiễm virus.
Virus cũng có thể tồn tại trên các bề mặt mà các giọt hắt hơi rơi xuống. Sự lây truyền có thể xảy ra nếu một người đưa tay lên mắt mũi hay miệng sau khi tiếp xúc với các giọt hắt hơi trên bề mặt đồ vật.
Có bằng chứng cho thấy một số người mắc phải chỉ có triệu chứng nhẹ hoặc chỉ một vài triệu chứng cũng có thể lây nhiễm virus cho người khác.
Do đó, Trung tâm kiểm soát và phòng ngừa dịch bệnh Hoa Kỳ (CDC) đã khuyến nghị nên đeo khẩu trang trong các tình huống khi khó hoặc không thể duy trì khoảng cách 6 feet (khoảng 1,8m) giữa mọi người.
Các chuyên gia kêu gọi mọi người tự làm khẩu trang và nhường khẩu trang phẫu thuật và khẩu trang N-95 cho nhân viên y tế. CDC đã đưa ra một hướng dẫn về cách làm khẩu trang tại nhà.
Trước lời khuyên này, các nhà nghiên cứu đã bắt đầu nghiên cứu các cách khử trùng khẩu trang an toàn - tiêu diệt bất kỳ SARS-CoV-2 nào mà không làm giảm hiệu quả của khẩu trang theo thời gian.
Họ đã nghiên cứu các phương tiện khử trùng khẩu trang vải và khẩu trang chuyên dụng cho nhân viên y tế, vì việc tái sử dụng khẩu trang có thể giúp giảm bớt áp lực đối với tình trạng khan hiếm khẩu trang.
Các tác giả nghiên cứu trích dẫn nghiên cứu trước đây chứng minh rằng khẩu trang làm nóng đến 70oC có hiệu quả trong việc tiêu diệt virus SARS-CoV-2.
Trong khi các kỹ thuật khử trùng khác cũng đã được chứng minh là hiệu quả, tuy nhiên việc khử trùng bằng nhiệt có thể được thực hiện một cách dễ dàng.
## **Kiểm tra trên mô hình**
Để kiểm tra mức độ hiệu quả của khẩu trang sau khi khử trùng bằng nhiệt, các tác giả đã sử dụng các loại khẩu trang khác nhau vào mô hình.
Các nhà nghiên cứu đã sử dụng bồ hóng từ đèn dầu hỏa, các hạt có kích thước gần bằng kích thước của virus SARS-CoV-2 để mô phỏng.
Sau đó, các tác giả đã thử nghiệm 2 khẩu trang chống độc N-95, 1 khẩu trang phẫu thuật dùng một lần và 3 khẩu trang vải từ các chất liệu khác nhau như cotton, cotton pha len và vải polyester. Sau đó, đo mức độ của bồ hóng bên ngoài của mô hình và trong không khí đã lọt qua khẩu trang.
Họ lặp đi lặp lại các thử nghiệm, thay đổi độ kín của khẩu trang và sử dụng mô hình được làm bằng vật liệu khác nhau như nhựa hay silicone để mô phỏng sự mềm mại của khuôn mặt người.
## **Xử lý nhiệt không làm giảm hiệu quả**
Các nhà nghiên cứu kết luận rằng nếu được đeo vào mô hình bằng nhựa, chỉ một khẩu trang N-95 và khẩu trang phẫu thuật có thể được khử trùng bằng cách xử lý nhiệt 10 lần mà không làm mất hiệu quả.
Khẩu trang N-95 đạt hiệu suất lọc 95%, trong khi khẩu trang phẫu thuật đạt 70%.
Các khẩu trang phòng độc N-95 khác không thể giữ được tính bảo vệ hiệu quả khi liên tục được sử dụng cho mô hình. Tuy nhiên, khi các tác giả sử dụng khẩu trang trên chất làm mềm, silicon của mô hình với mức độ phù hợp mà một người thường sử dụng, họ thấy rằng mức lọc thấp hơn đáng kể - khoảng 40% cho cả khẩu trang phẫu thuật và khẩu trang N-95.
Khi nhóm nghiên cứu sử dụng khẩu trang vải trên mồ hình mềm hơn, họ phát hiện ra rằng hiệu quả lọc là 55% - tốt hơn cả khẩu trang phẫu thuật hoặc khẩu trang N-95 khi được sử dụng với thiết bị thông thường.
Việc xử lý nhiệt khẩu trang vải cũng không ảnh hưởng đến khả năng lọc của chúng.
Cuối cùng, các tác giả đã nghiên cứu tính hiệu quả của các nẹp mũi tự làm được áp dụng cho khẩu trang. Họ phát hiện ra rằng, khi sử dụng cho khẩu trang dùng một lần với độ vừa vặn, nẹp mũi làm tăng đáng kể hiệu quả lọc: đến 98% cho khẩu trang N-95 và lên đến 88% cho khẩu trang phẫu thuật.
Các nhà nghiên cứu thừa nhận rằng nghiên cứu của họ tương đối nhỏ và không loại trừ cách thức mà một người thở và chuyển động hay cách một người đeo khẩu trang.
Tuy nhiên, các tác giả - người đến từ Đài quan sát Trái đất Lamont-Doherty của Đại học Columbia, ở Palisades, NY - lưu ý, tất cả mọi thứ chúng ta biết cho đến nay cho thấy rằng đeo khẩu trang cho dù là bất kì loại nào đi nữa ở nơi công cộng vẫn tốt hơn là không có gì.
Việc xử lý nhiệt khẩu trang là điều phù hợp ở thời điểm hiện tại, và với số nhất định, khẩu trang có thể được tái sử dụng bên ngoài các cơ sở y tế.
**Bệnh viện Nguyễn Tri Phương** - Bệnh viện Đa khoa Hạng I Thành phố Hồ Chí Minh
  * 468 Nguyễn Trãi, Phường 8, Quận 5, Tp. Hồ Chí Minh
  * Hotline: (84-028) 39234332
  * Mạng xã hội **Facebook** : [**Bệnh viện Nguyễn Tri Phương**](https://www.facebook.com/BVNTP/)
  * Đăng ký (Subcribe) kênh **Youtube** : [https://youtube.com/bvntp](https://youtube.com/bvntp?fbclid=IwAR3q_UvPI4OZAebT1uQGPKKwk3RmCzAFLkBJm9lb7EwIz0EHtgiLhKM5bxU)
  * Quan tâm Zalo Official: [zalo.me/1744466261097093886](https://zalo.me/1744466261097093886?fbclid=IwAR3E-fLqdh-x1cYSvuDY6E5Eyxfjo5ZSs4p0hDWAyBG-ROlTkxXkXvdEWAY)


  * [COVID-19 và khẩu trang](https://bvnguyentriphuong.com.vn/nghien-cuu-duoc-dang-tai-tren-tap-chi-quoc-te/nghien-cuu-cho-thay-khau-trang-co-the-duoc-khu-trung-hieu-qua-tai-nha#covid19-v-khu-trang)
  * [Kiểm tra trên mô hình](https://bvnguyentriphuong.com.vn/nghien-cuu-duoc-dang-tai-tren-tap-chi-quoc-te/nghien-cuu-cho-thay-khau-trang-co-the-duoc-khu-trung-hieu-qua-tai-nha#kim-tra-trn-m-hnh)
  * [Xử lý nhiệt không làm giảm hiệu quả](https://bvnguyentriphuong.com.vn/nghien-cuu-duoc-dang-tai-tren-tap-chi-quoc-te/nghien-cuu-cho-thay-khau-trang-co-the-duoc-khu-trung-hieu-qua-tai-nha#x-l-nhitkhng-lm-gim-hiu-qu)



## Hướng dẫn phòng và kiểm soát lây nhiễm dịch Corona

Vui lòng xem toàn văn bản [tại đây](https://drive.google.com/open?id=1WLncEj_tE1yDp4ChlwcStOYpdfPNwmmR)./.

## ️ Phương thức lây truyền của 2019-nCoV và kiếm soát trong nha khoa lâm sàng

_Phòng thí nghiệm trọng điểm về bệnh răng miệng & Trung tâm nghiên cứu lâm sàng quốc gia về bệnh răng miệng & Khoa Nội soi và Nội nha, Trung tâm Răng hàm mặt Bệnh viện Hoa Tây, Đại học Tứ Xuyên, Thành Đô, Trung Quốc Xian Peng, Xin Xu, Yuqing Li, Lei Cheng, Xuedong Zhou & Biao Ren_
**2019-nCoV** có thể được truyền trực tiếp từ người này sang người khác bằng các giọt hô hấp, qua tiếp xúc các bề mặt truyền bệnh. Ngoài ra, thời gian ủ bệnh không triệu chứng cho những người bị nhiễm 2019-nCov đã được báo cáo là khoảng **14 ngày.** Người ta đã xác nhận rằng 2019-nCov xâm nhập vào tế bào theo cùng một đường với SARS coronavirus, nghĩa là thông qua thụ thể tế bào ACE2. 2019-nCoV có thể sử dụng hiệu quả ACE2 như một thụ thể để xâm chiếm các tế bào, điều này có thể thúc đẩy sự lây truyền từ người sang người. Các tế bàoACE2 đã được thấy có mặt nhiều trong đường hô hấp, cũng như các tế bào tương thích về mặt hình thái với biểu mô tuyến nước bọt trong miệng của con người. Các tế bào biểu mô ACE2 của ống tuyến nước bọt đã được chứng minh là mục tiêu ban đầu của nhiễm **SARS-CoV** , và 2019-nCoV có thể là tình trạng tương tự, mặc dù cho đến nay chưa có nghiên cứu nào được báo cáo.
**Bệnh nhân nha khoa và bác sĩ** , nhân viên có thể tiếp xúc với các vi sinh vật gây bệnh, bao gồm virus và vi khuẩn lây nhiễm vào khoang miệng và đường hô hấp. Các cơ sở chăm sóc nha khoa luôn có nguy cơ bị nhiễm 2019-nCoV do tính đặc thù của quy trình, bao gồm giao tiếp mặt đối mặt với bệnh nhân và thường xuyên tiếp xúc với nước bọt, máu và các chất dịch cơ thể khác kèm theo dụng cụ sắc nhọn. Mầm bệnh từ các giọt và khí dung có chứa vi sinh vật của một người bị nhiễm bệnh, phát tán bằng ho, nói chuyện không đeo khẩu trang, có thể đến trực tiếp với kết mạc, mũi hoặc niêm mạc miệng của người bình thường, hoặc tiếp xúc gián tiếp với các dụng cụ bị ô nhiễm và/hoặc bề mặt môi trường.
Toàn văn xin vui lòng xem [tại đây](https://drive.google.com/open?id=1ivN-sahpZshAr6L5d97gf44hubKx0k4W)./.
**Bệnh viện Nguyễn Tri Phương** - Bệnh viện Đa khoa Hạng I Thành phố Hồ Chí Minh
  * 468 Nguyễn Trãi, Phường 8, Quận 5, Tp. Hồ Chí Minh
  * Hotline: (84-028) 39234332
  * Mạng xã hội **Facebook** : [**Bệnh viện Nguyễn Tri Phương**](https://www.facebook.com/BVNTP/)
  * Đăng ký (Subcribe) kênh **Youtube** : [https://youtube.com/bvntp](https://youtube.com/bvntp?fbclid=IwAR3q_UvPI4OZAebT1uQGPKKwk3RmCzAFLkBJm9lb7EwIz0EHtgiLhKM5bxU)
  * Quan tâm Zalo Official: [zalo.me/1744466261097093886](https://zalo.me/1744466261097093886?fbclid=IwAR3E-fLqdh-x1cYSvuDY6E5Eyxfjo5ZSs4p0hDWAyBG-ROlTkxXkXvdEWAY)



## ️ Khử trùng trong đại dịch Covid ở những nơi không phải đơn vị y tế

  * [Những khu vực nào cần được ưu tiên khử trùng](https://bvnguyentriphuong.com.vn/kiem-soat-nhiem-khuan/khu-trung-trong-dai-dich-covid-o-nhung-noi-khong-phai-don-vi-y-te#nhng-khu-vc-no-cn-c-u-tin-kh-trng)
  * [Chất khử trùng bề mặt nào có hiệu quả đối với COVID-19](https://bvnguyentriphuong.com.vn/kiem-soat-nhiem-khuan/khu-trung-trong-dai-dich-covid-o-nhung-noi-khong-phai-don-vi-y-te#cht-kh-trng-b-mt-no-c-hiu-qu-i-vi-covid19)
  * [Cần thực hiện những biện pháp bảo vệ nào khi sử dụng chất khử trùng?](https://bvnguyentriphuong.com.vn/kiem-soat-nhiem-khuan/khu-trung-trong-dai-dich-covid-o-nhung-noi-khong-phai-don-vi-y-te#cn-thc-hin-nhng-bin-php-bo-v-no-khi-s-dng-cht-kh-trng)
  * [Đường hầm khử khuẩn/buồng khử khuẩn có an toàn để sử dụng không?](https://bvnguyentriphuong.com.vn/kiem-soat-nhiem-khuan/khu-trung-trong-dai-dich-covid-o-nhung-noi-khong-phai-don-vi-y-te#ng-hm-kh-khunbung-kh-khun-c-an-ton-s-dng-khng)
  * [Các thực hành được khuyến nghị khi trở về nhà sau các hoạt động ngoài trời là gì?](https://bvnguyentriphuong.com.vn/kiem-soat-nhiem-khuan/khu-trung-trong-dai-dich-covid-o-nhung-noi-khong-phai-don-vi-y-te#cc-thc-hnh-c-khuyn-ngh-khi-tr-v-nh-sau-cc-hot-ng-ngoi-tri-l-g)
  * [Găng tay có được khuyến nghị cho cộng đồng ở các không gian công cộng để bảo vệ chống lại COVID-19, ví dụ như khi đi siêu thị cửa hàng tạp hóa không?](https://bvnguyentriphuong.com.vn/kiem-soat-nhiem-khuan/khu-trung-trong-dai-dich-covid-o-nhung-noi-khong-phai-don-vi-y-te#gng-tay-c-c-khuyn-ngh-cho-cng-ng-cc-khng-gian-cng-cng-bo-v-chng-li-covid19-v-d-nh-khi-i-siu-th-ca-hng-tp-ha-khng)
  * [Nên làm thế nào để làm sạch các mặt hàng thực phẩm từ cửa hàng tạp hóa, chẳng hạn như trái cây, rau quả hoặc các mặt hàng đóng gói sẵn?](https://bvnguyentriphuong.com.vn/kiem-soat-nhiem-khuan/khu-trung-trong-dai-dich-covid-o-nhung-noi-khong-phai-don-vi-y-te#nn-lm-th-no-lm-sch-cc-mt-hng-thc-phm-t-ca-hng-tp-ha-chng-hn-nh-tri-cy-rau-qu-hoc-cc-mt-hng-ng-gi-sn)


## **Những khu vực nào cần được ưu tiên khử trùng**
  * Khử trùng là một hành động rất quan trọng để làm giảm khả năng con người tiếp xúc với vi-rút COVID-19 ở trong các môi trường không phải cơ sở chăm sóc sức khỏe, chẳng hạn như nhà ở, văn phòng, trường học, phòng tập thể dục, các tòa nhà công cộng dễ tiếp cận, các trung tâm cộng đồng, chợ, các phương tiện giao thông hoặc các nhà hàng.
  * Các bề mặt nơi có nguy cơ tiếp xúc cao nhất cần được ưu tiên khử trùng, như tay nắm cửa và cửa sổ, nhà bếp, khu vực chuẩn bị và chế biến thực phẩm, mặt bàn của bếp, bề mặt phòng tắm, nhà vệ sinh và vòi nước, thiết bị cảm ứng cá nhân, bàn phím máy tính cá nhân và bề mặt môi trường làm việc.


## **Chất khử trùng bề mặt nào có hiệu quả đối với COVID-19**
  * Natri hypoclorit (hay còn gọi là thuốc tẩy hoặc chlorine) có thể được sử dụng khuyến nghị là 0,1% hoặc 1,000 ppm (một phần thuốc tẩy gia dụng 5% pha với 49 phần nước). Cồn 70 đến 90 độ cũng có thể được sử dụng để khử trùng bề mặt.
  * Các bề mặt phải được làm sạch bằng nước và xà phòng hoặc chất tẩy rửa trước để loại bỏ chất bẩn, sau đó mới khử trùng. Việc vệ sinh phải luôn bắt đầu từ khu vực ít bẩn nhất đến khu vực nhiều chất bẩn hơn để không làm lây lan chất bẩn.
  * Tất cả các dung dịch khử trùng nên bảo quản trong các hộp tối màu, để ở nơi thông thoáng, có mái che và hạn chế tiếp xúc trực tiếp với ánh nắng mặt trời. Tốt nhất là sử dụng chất khử trùng được pha mới mỗi ngày để đem lại hiệu quả cao nhất.
  * Trong không gian nhà ở, không nên sử dụng thường xuyên chất khử trùng bằng cách phun lên các bề mặt mà chỉ nên lau với miếng vải hoặc khăn đã được ngâm trong dung dịch khử trùng.


## **Cần thực hiện những biện pháp bảo vệ nào khi sử dụng chất khử trùng?**
  * Khi sử dụng chất khử trùng, cần chú ý một vài điều sau để giảm các nguy cơ liên quan:
    * Loại chất khử trùng và nồng độ cần được lựa chọn cẩn thận để tránh làm hỏng bề mặt và giảm tác độc tính đối với con người.
    * Tránh kết hợp nhiều loại chất khử trùng, ví dụ như thuốc tẩy và amoniac,vì các hỗn hợp có thể gây kích ứng đường hô hấp và giải phóng một số loại khí gây chết người.
    * Giữ trẻ em, vật nuôi và những người khác tránh xa khỏi những khu vực vừa mới khử trùng cho đến khi khô ráo hoàn toàn và sạch mùi.
    * Nên mở cửa sổ, bật quạt sau khi khử trùng để đảm bảo thông thoáng. Tránh xa khu vực đã khử trùng nếu mùi quá nồng.
    * Rửa tay sau khi sử dụng bất kì chất khử trùng nào, kể cả khăn lau bề mặt.
    * Đậy nắp chặt khi không sử dụng để tránh đổ tràn lan và tai nạn do vô ý.
    * Không cho trẻ em sử dụng khăn lau đã có chất khử trùng. Giữ chất lỏng tẩy rửa và chất khử trùng ngoài tầm với của trẻ em và vật nuôi.
    * Nên vứt bỏ những đồ dùng một lần như găng tay và khẩu trang nếu chúng đã được sử dụng trong quá trình vệ sinh. Không làm sạch và sử dụng lại.
    * Không sử dụng khăn lau có chất khử trùng để lau tay hoặc lau cho em bé.
    * Thiết bị bảo hộ cá nhân được khuyến nghị tối thiểu khi khử trùng trong các cơ sở không thuộc trong lĩnh vực chăm sóc sức khỏe là găng tay cao su, tạp dề chống thấm nước và giày kín. Cũng có thể cần đến kính bảo vệ mắt và khẩu trang y tế để chống lại các hóa chất đang sử dụng hoặc nếu có nguy cơ bị bắn tung tóe.
    * Luôn đọc và làm theo chỉ dẫn trên nhãn của các sản phẩm vệ sinh và khử trùng để đảm bảo sử dụng an toàn và hiệu quả. 
    * Chỉ dùng đúng lượng khuyến nghị trên nhãn thông tin.
    * Nếu trong chỉ định, cần pha loãng với nước để sử dụng, hãy sử dụng nước ở nhiệt độ phòng (trừ khi có chỉ định khác trên nhãn).
    * Không sử dụng bất kỳ sản phẩm vệ sinh và khử trùng bề mặt nào để lau hoặc tắm cho người hoặc thú cưng.


  * **_Lưu ý:_** Trong trường hợp không thể làm sạch và khử trùng thường xuyên do hạn chế về nguồn lực, thì biện pháp rửa tay thường xuyên và tránh đưa tay lên mặt sẽ là phương pháp phòng ngừa chính để làm giảm bất kỳ khả năng lây truyền có nguy cơ.


## **Đường hầm khử khuẩn/buồng khử khuẩn có an toàn để sử dụng không?**
  * Xịt thuốc khử trùng vào người (chẳng hạn như trong đường hầm, tủ hoặc buồng) đều không được khuyến cáo trong bất kỳ trường hợp nào**.** Hành động này có thể có hại về thể chất và tâm lý và sẽ không làm giảm khả năng lây lan vi-rút của người nhiễm bệnh thông qua các giọt bắn hoặc tiếp xúc. Ngay cả khi người bị nhiễm COVID-19 đi qua đường hầm hoặc buồng khử trùng, ngay khi họ bắt đầu nói, ho hoặc hắt hơi, họ vẫn có thể lây lan vi-rút.
  * Tác dụng độc hại của việc phun các hóa chất như chlorine lên người có thể dẫn đến kích ứng mắt và da, co thắt phế quản do hít phải và có nguy cơ ảnh hưởng đến đường tiêu hóa như buồn nôn và nôn. Ngoài các mối quan tâm về an toàn sức khỏe, việc sử dụng chlorine trong các hoạt động phun quy mô lớn có thể làm thiếu hụt nguồn cung hoá chất này cho các can thiệp cần thiết khác như xử lý nước uống và khử trùng môi trường cho các cơ sở chăm sóc sức khỏe.


## **Các thực hành được khuyến nghị khi trở về nhà sau các hoạt động ngoài trời là gì?**
  * Vệ sinh tay kỹ lưỡng: rửa tay bằng xà phòng và nước hoặc sử dụng gel rửa tay chứa cồn, nên được thực hiện trước khi chạm vào bề mặt, vật dụng, vật nuôi và người trong môi trường gia đình.
  * Trong khi ở bên ngoài, mọi người phải luôn tuân theo các biện pháp giữ khoảng cách vật lý, duy trì khoảng cách tối thiểu một mét với người khác; thực hiện vệ sinh tay bằng cách rửa tay thường xuyên bằng xà phòng và nước hoặc sử dụng nước sát khuẩn chứa cồn; vệ sinh hô hấp tốt bằng cách che miệng và mũi bằng khuỷu tay hoặc khăn giấy trong khi ho hoặc hắt hơi; tránh chạm vào mắt, mũi và miệng; và tránh đến những nơi đông người.


## **Găng tay có được khuyến nghị cho cộng đồng ở các không gian công cộng để bảo vệ chống lại COVID-19, ví dụ như khi đi siêu thị cửa hàng tạp hóa không?**
  * Việc sử dụng găng tay ở không gian công cộng không phải là một biện pháp phòng ngừa được khuyến nghị hay đã được chứng minh. Đeo găng tay ở nơi công cộng không thay thế nhu cầu vệ sinh tay, cũng như không cung cấp bất kỳ biện pháp bảo vệ bổ sung nào chống lại vi-rút COVID-19 so với vệ sinh tay.
  * Găng tay không cung cấp sự bảo vệ hoàn toàn chống lại ô nhiễm tay, vì mầm bệnh có thể xâm nhập vào tay thông qua các khiếm khuyết nhỏ trong găng tay hoặc do nhiễm bẩn bàn tay trong quá trình tháo găng tay. Mọi người cũng có thể lan truyền mầm bệnh từ bề mặt này sang bề mặt khác thông qua vô tình chạm vào găng, hoặc thậm chí truyền mầm bệnh đến miệng, mũi hoặc mắt nếu họ chạm vào mặt mình bằng tay đang mang găng.


## **Nên làm thế nào để làm sạch các mặt hàng thực phẩm từ cửa hàng tạp hóa, chẳng hạn như trái cây, rau quả hoặc các mặt hàng đóng gói sẵn?**
  * Chưa có bằng chứng cho đến nay về vi-rút gây ra các bệnh về đường hô hấp được truyền qua bao bì thực phẩm hoặc thực phẩm. Vi-rút corona không thể nhân lên trong thực phẩm; chúng chỉ nhân lên khi trong cơ thể động vật hoặc vật chủ của con người.
  * Vi-rút COVID-19 thường được cho là lây lan từ người sang người thông qua giọt bắn từ đường hô hấp. Hiện tại, không có bằng chứng nào chứng minh sự lây truyền vi-rút COVID-19 liên quan đến thực phẩm.


  * Trước khi chuẩn bị hoặc ăn thức ăn, điều quan trọng là phải luôn rửa tay bằng xà phòng và nước trong ít nhất 40-60 giây. Cần tuân thủ hướng dẫn xử lý và an toàn thực phẩm thường xuyên


**Tài liệu tham khảo**
<https://www.who.int/news-room/q-a-detail/coronavirus-disease-covid-19-cleaning-and-disinfecting-surfaces-in-non-health-care-settings>
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [Những khu vực nào cần được ưu tiên khử trùng](https://bvnguyentriphuong.com.vn/kiem-soat-nhiem-khuan/khu-trung-trong-dai-dich-covid-o-nhung-noi-khong-phai-don-vi-y-te#nhng-khu-vc-no-cn-c-u-tin-kh-trng)
  * [Chất khử trùng bề mặt nào có hiệu quả đối với COVID-19](https://bvnguyentriphuong.com.vn/kiem-soat-nhiem-khuan/khu-trung-trong-dai-dich-covid-o-nhung-noi-khong-phai-don-vi-y-te#cht-kh-trng-b-mt-no-c-hiu-qu-i-vi-covid19)
  * [Cần thực hiện những biện pháp bảo vệ nào khi sử dụng chất khử trùng?](https://bvnguyentriphuong.com.vn/kiem-soat-nhiem-khuan/khu-trung-trong-dai-dich-covid-o-nhung-noi-khong-phai-don-vi-y-te#cn-thc-hin-nhng-bin-php-bo-v-no-khi-s-dng-cht-kh-trng)
  * [Đường hầm khử khuẩn/buồng khử khuẩn có an toàn để sử dụng không?](https://bvnguyentriphuong.com.vn/kiem-soat-nhiem-khuan/khu-trung-trong-dai-dich-covid-o-nhung-noi-khong-phai-don-vi-y-te#ng-hm-kh-khunbung-kh-khun-c-an-ton-s-dng-khng)
  * [Các thực hành được khuyến nghị khi trở về nhà sau các hoạt động ngoài trời là gì?](https://bvnguyentriphuong.com.vn/kiem-soat-nhiem-khuan/khu-trung-trong-dai-dich-covid-o-nhung-noi-khong-phai-don-vi-y-te#cc-thc-hnh-c-khuyn-ngh-khi-tr-v-nh-sau-cc-hot-ng-ngoi-tri-l-g)
  * [Găng tay có được khuyến nghị cho cộng đồng ở các không gian công cộng để bảo vệ chống lại COVID-19, ví dụ như khi đi siêu thị cửa hàng tạp hóa không?](https://bvnguyentriphuong.com.vn/kiem-soat-nhiem-khuan/khu-trung-trong-dai-dich-covid-o-nhung-noi-khong-phai-don-vi-y-te#gng-tay-c-c-khuyn-ngh-cho-cng-ng-cc-khng-gian-cng-cng-bo-v-chng-li-covid19-v-d-nh-khi-i-siu-th-ca-hng-tp-ha-khng)
  * [Nên làm thế nào để làm sạch các mặt hàng thực phẩm từ cửa hàng tạp hóa, chẳng hạn như trái cây, rau quả hoặc các mặt hàng đóng gói sẵn?](https://bvnguyentriphuong.com.vn/kiem-soat-nhiem-khuan/khu-trung-trong-dai-dich-covid-o-nhung-noi-khong-phai-don-vi-y-te#nn-lm-th-no-lm-sch-cc-mt-hng-thc-phm-t-ca-hng-tp-ha-chng-hn-nh-tri-cy-rau-qu-hoc-cc-mt-hng-ng-gi-sn)



## ️ Hướng dẫn mang đồ phòng hộ cá nhân

**Bệnh viện Nguyễn Tri Phương** - Bệnh viện Đa khoa Hạng I Thành phố Hồ Chí Minh
  * 468 Nguyễn Trãi, Phường 8, Quận 5, Tp. Hồ Chí Minh
  * Hotline: (84-028) 39234332
  * Mạng xã hội **Facebook** : [**Bệnh viện Nguyễn Tri Phương**](https://www.facebook.com/BVNTP/)
  * Đăng ký (Subcribe) kênh **Youtube** : [https://youtube.com/bvntp](https://youtube.com/bvntp?fbclid=IwAR3q_UvPI4OZAebT1uQGPKKwk3RmCzAFLkBJm9lb7EwIz0EHtgiLhKM5bxU)
  * Quan tâm Zalo Official: [zalo.me/1744466261097093886](https://zalo.me/1744466261097093886?fbclid=IwAR3E-fLqdh-x1cYSvuDY6E5Eyxfjo5ZSs4p0hDWAyBG-ROlTkxXkXvdEWAY)



## ️ Điều trị dự phòng phơi nhiễm với HIV

## **A. Điều trị dự phòng cho người bị phơi nhiễm với HIV trong nghề nghiệp**
**I. Nguyên tắc chung**
Tư vấn cho người bị phơi nhiễm với máu, dịch cơ thể có nguy cơ lây nhiễm của người HIV(+).
Cần lấy máu thử ngay HIV và điều trị ngay không cần chờ kết quả xét nghiệm.
Thử lại HIV sau khi dùng thuốc 1 tháng; 3 tháng và 6 tháng.
Không điều trị tổn thương không làm xây xát da mà chỉ cần rửa sạch da.
**II. Đánh giá mức độ phơi nhiễm và xử trí vết thương tại chỗ**
**_1. Đánh giá tính chất phơi nhiễm_**
Cần xác định vị trí tổn thương.
Xem kích thước kim đâm (nếu kim to và rỗng thì nguy cơ lây nhiễm cao).
Xem độ sâu của vết kim đâm
Nhìn thấy chảy máu khi bị kim đâm.
_Vết thương do dao mổ, do ống nghiệm đựng máu_ ,  _chất_  _dịch_ của bệnh nhân nhiễm HIV bị vỡ đâm vào da, cần xác định độ sâu và kích thước của vết thương.
_Da bị tổn thương từ trước và niêm mạc._
Da có các tổn thương do: Chàm, bỏng hoặc bị viêm loét từ trước.
Niêm mạc mắt hoặc mũi họng.
**_2. Xử trí ngay tại chỗ_**
Da: Rửa kỹ bằng xà phòng và nước sạch, sau đó sát trùng bằng dung dịch Dakin hoặc nước Javel pha loãng 1/10 hoặc cồn 70o, để tiếp xúc nơi bị tổn thương ít nhất 5 phút.
Mắt: Rửa mắt với nước cất hoặc dung dịch natri clorid đẳng trương (0,9%), sau đó nhỏ mắt bằng nước cất liên tục trong 5 phút.
Miệng, mũi: Rửa mũi bằng nước cất, súc miệng bằng dung dịch natri clorid đẳng trương (0,9%).
**III. Điều trị dự phòng**
Thời gian điều trị tốt nhất là ngay từ những giờ đầu tiên (2- 3 giờ sau khi xảy ra tai nạn), muộn nhất không quá 7 ngày.
Nếu tổn thương chỉ xây xước da không chảy máu hoặc máu, dịch của bệnh nhân bắn vào mũi họng thì phối hợp 2 loại thuốc trong thời gian 1 tháng (có phác đồ riêng).
Nếu tổn thương sâu, chảy máu nhiều thì phối hợp 3 loại thuốc trong thời gian 1 tháng (có phác đồ riêng).
**B. Điều trị dự phòng lây nhiễm HIV từ mẹ sang con**
Điều trị người mang thai nhiễm HIV với mục đích làm giảm lây nhiễm từ mẹ sang con, nếu người mẹ và gia đình sau khi được tư vấn vẫn muốn giữ thai.
**_1. Điều trị trước khi và trong khi đẻ_**
Tùy điều kiện có thể chọn một trong hai phác đồ sau:
_Phác đồ sử dụng nevirapin_
Chỉ định: Khi bắt đầu chuyển dạ thực sự hoặc trước khi mổ lấy thai.
Điều trị: Uống một lần duy nhất 1 viên nevirapin 200 mg.
Theo dõi cuộc chuyển dạ và tiếp tục đỡ đẻ như bình thường.
_Phác đồ sử dụng zidovudin_
Zidovudin 600 mg/ngày, chia 2 lần, uống bắt đầu từ tuần thai thứ 36 đến khi chuyển dạ. Trong trường hợp thai phụ đến muộn (sau tuần thứ 36), cũng cho uống với liều trên cho đến khi chuyển dạ.
Trong khi chuyển dạ đẻ, tiếp tục dùng zidovudin 300 mg/lần, cứ 3 giờ cho uống 1 lần đến lúc cặp và cắt dây rốn thì ngừng uống thuốc.
Cần cho thêm thuốc chống thiếu máu bằng cách bổ sung viên sắt hoặc acid folic.
Nếu người mẹ có nhiễm khuẩn cơ hội kèm theo thì điều trị như những người bệnh nhiễm khuẩn cơ hội khác hoặc gửi đi khám chuyên khoa để có chỉ định dùng thuốc đúng và hợp lý.
**_2. Các điểm cần thực hiện đúng khi đỡ đẻ_**
_Đối với sản phụ_
Đảm bảo vô khuẩn tuyệt đối khi đỡ đẻ.
Lau âm đạo nhiều lần bằng bông tẩm dung dịch benzalkonium clorid hay clorhexidin 0,2%.
Không cạo lông vùng vệ.
Chỉ mổ lấy thai khi có chỉ định sản khoa.
Tư vấn cho người mẹ về lợi ích của việc nuôi trẻ bằng sữa thay thế nếu có điều kiện, để giảm bớt nguy cơ lây truyền bệnh.
_Đối với trẻ mới sinh_
Không đặt điện cực vào đầu thai nhi.
Không lấy máu da đầu thai nhi làm pH.
Tắm cho trẻ ngay sau khi sinh.
Ngay sau khi trẻ được sinh ra, cán bộ y tế buồng đẻ phải thông báo cho cho khoa Nhi để trẻ được chăm sóc đặc biệt tại khoa Sản và khoa Nhi của bệnh viện.
**_3. Điều trị sau khi sinh_**
Nếu người mẹ uống nevirapin thì cho con uống duy nhất một lần siro nevirapin 2 mg/kg cân nặng, trong vòng 72 giờ sau khi sinh.
Nếu người mẹ uống zidovudin thì cho con uống siro zidovudin 2 mg/kg/6 giờ, bắt đầu khoảng 8 - 10 giờ sau khi sinh, kéo dài trong 6 tuần. Trường hợp không có siro zidovudin thì sử dụng siro nevirapin như trên.
* Với những thai còn nhỏ (dưới 3 tháng), sau khi được tư vấn, nếu thai phụ và gia đình đồng ý phá thai thì giải quyết hút hay nạo thai tùy theo tuổi thai. Những trường hợp này sẽ được thực hiện ở nơi có cơ sở phẫu thuật (có bác sĩ chuyên khoa sản, phòng mổ).
Sau khi phá thai, tiếp tục điều trị như các trường hợp bệnh nhân nhiễm HIV khác.
Nếu thai phụ muốn giữ thai thì y tế cơ sở nên gửi đến khoa sản bệnh viện tỉnh hoặc tuyến kỹ thuật cao hơn để được quản lý.
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh

## ️ F1 cách ly tại nhà vì Covid cần chú ý gì

  * [1. Chuẩn bị phòng cách ly: điều quan trọng nhất là tất cả hoạt động và đồ dùng cần phải RIÊNG](https://bvnguyentriphuong.com.vn/kiem-soat-nhiem-khuan/f1-cach-ly-tai-nha-vi-covid-can-chu-y-gi#1-chun-b-phng-cch-ly-iu-quan-trng-nht-l-tt-c-hot-ng-v-dng-cn-phi-ring)
  * [2. Chuẩn bị đồ sát khuẩn cho người chăm sóc: càng ít người chăm sóc càng tốt](https://bvnguyentriphuong.com.vn/kiem-soat-nhiem-khuan/f1-cach-ly-tai-nha-vi-covid-can-chu-y-gi#2-chun-b-st-khun-cho-ngi-chm-sc-cng-t-ngi-chm-sc-cng-tt)
  * [3. Thực hiện cách ly](https://bvnguyentriphuong.com.vn/kiem-soat-nhiem-khuan/f1-cach-ly-tai-nha-vi-covid-can-chu-y-gi#3-thc-hin-cch-ly)
  * [3.1. Đối với F1](https://bvnguyentriphuong.com.vn/kiem-soat-nhiem-khuan/f1-cach-ly-tai-nha-vi-covid-can-chu-y-gi#31-i-vi-f1)
  * [Tuyệt đối không đi ra ngoài và](https://bvnguyentriphuong.com.vn/kiem-soat-nhiem-khuan/f1-cach-ly-tai-nha-vi-covid-can-chu-y-gi#tuyt-i-khng-i-ra-ngoi-v)
  * [3.2. Các thành viên sống cùng nhà với người được cách ly](https://bvnguyentriphuong.com.vn/kiem-soat-nhiem-khuan/f1-cach-ly-tai-nha-vi-covid-can-chu-y-gi#32-cc-thnh-vin-sng-cng-nh-vi-ngi-c-cch-ly)
  * [3.3. Đối với người chăm sóc cần tiếp xúc trực tiếp với người nghi nhiễm](https://bvnguyentriphuong.com.vn/kiem-soat-nhiem-khuan/f1-cach-ly-tai-nha-vi-covid-can-chu-y-gi#33-i-vi-ngi-chm-sc-cn-tip-xc-trc-tip-vi-ngi-nghi-nhim)
  * [3.4. Nếu người nhà xuất hiện triệu chứng nghi mắc COVID](https://bvnguyentriphuong.com.vn/kiem-soat-nhiem-khuan/f1-cach-ly-tai-nha-vi-covid-can-chu-y-gi#34-nu-ngi-nh-xut-hin-triu-chng-nghi-mc-covid)


### **1. Chuẩn bị phòng cách ly: điều quan trọng nhất là tất cả hoạt động và đồ dùng cần phải RIÊNG**
  * Cần chuẩn bị ** _phòng riêng_** có nhà vệ sinh riêng để cách ly.
  * Phòng/vị trí mở cửa sổ thoáng, nhiều ánh sáng.
  * Hạn chế đồ đạc trong phòng/vị trí cách ly, đảm bảo:
    * Trong nhà vệ sinh riêng cần có xà phòng, khăn tắm, giấy vệ sinh, giấy lau tay, túi nilon đựng rác.
    * Có bàn, ghế, TV để giải trí, đồ chơi (nếu là trẻ em). Điều khiển TV, điện thoại di động để trong túi nilon để dễ tiệt khuẩn
    * Bát, cốc, đũa, thìa riêng (hoặc đồ dùng 1 lần) để ăn uống
    * Khẩu trang y tế, thùng rác, túi nilon đựng rác
  * Ngoài phòng cách ly nên có ** _1 diện tích trống_** để khử khuẩn trước khi ra khu sinh hoạt chung.


### **2. Chuẩn bị đồ sát khuẩn cho người chăm sóc: càng ít người chăm sóc càng tốt**
  * Xà phòng, nước sạch và giấy để lau khô tay
  * Dung dịch rửa tay khô có cồn 60-70% (60-70 độ cồn)
  * Kính bảo hộ (hoặc bất kỳ loại kính nào)
  * Găng tay y tế (hoặc thay bằng găng tay nấu ăn)
  * Khẩu trang N95 (hoặc thay bằng khẩu trang y tế và tấm che mặt)
  * Túi nilon đựng rác thải, khăn lau, giấy vệ sinh để thấm hút lau chùi


### **3. Thực hiện cách ly**
### **3.1. Đối với F1**
**Theo dõi sức khỏe khi cách ly**
  * Theo dõi các vấn đề sức khỏe như mệt mỏi, sốt, ho, khó thở, mất vị giác, mất khứu giác…. Ghi lại ngày đầu tiên xuất hiện triệu chứng.
  * Tự đo nhiệt độ cơ thể ít nhất 2 lần/ngày (sáng, chiều), ghi chép kết quả đo nhiệt độ và tình trạng sức khỏe chung và phiếu theo dõi sức khỏe hàng ngày và thông báo cho CBYT phụ trách theo dõi.
  * Nếu được xác định là nhiễm SARS-CoV 2 và chưa được nhập viện:
    * Uống nhiều nước, uống oresol để bù nước.
    * Tập thể dục nhẹ nhàng. Xem các chương trình giải trí, thư giãn.
    * Nằm nghiêng hoặc nằm sấp nếu tư thế này làm cho bạn thấy dễ chịu.
    * Đo nhịp thở bằng cách đặt bàn tay lên ngực, thư giãn, thở đều và đếm số lần lồng ngực nhô lên trong 1 phút.
    * Kiểm tra độ bão hòa oxy ít nhất 3-4 lần/ngày (bằng máy đo kẹp ngón tay, đo khi nghỉ ngơi, theo dõi sự thay đổi của kết quả).
    * Uống Paracetamol nếu sốt ≥ 38.5oC.
      * Người lớn ≤ 70 kg: 1-1,5 viên 500 mg/lần; > 70 kg: 2 viên 500 mg/lần. 3-4 lần/ngày, cách tối thiểu 4-6h/lần, không quá 4 lần/ngày.
      * Trẻ em: 10-15 mg/kg/lần, cách 4-6 h/lần, không quá 4 lần/ngày. Liều tối đa tính theo cân nặng không được vượt quá 500 mg.
      * Không dùng cùng các thuốc cảm cúm khác có chứa paracetamol hoặc acetaminophen.
      * Người có tiền sử dị ứng với Paracetamol hoặc đang bị viêm gan không nên dùng.
    * Hạn chế tối đa ra khỏi phòng/góc cách ly trong nhà.
    * Sắp xếp các sinh hoạt trong gia đình sao cho khoảng cách giữa người được cách ly và những người khác trong gia đình tối thiểu 2m.


**9 DẤU HIỆU CẦN TỚI bệnh viện cấp cứu COVID hoặc bệnh viện gần nhất ngay**
  * Độ bão hòa oxy trong máu **< 94%**
  * Nhịp thở > 24 lần/phút
  * Đau ngực, cảm giác thắt ngực
  * Khó thở khi vận động
  * Không thể nói đầy đủ câu
  * Bị lẫn lộn về thời gian và địa điểm
  * Da xanh, môi nhợt
  * Không tự đi, không tự cầm nắm, ăn uống được
  * Lạnh đầu ngón tay, ngón chân


**Sinh hoạt hằng ngày khi cách ly**
  * Luôn đeo khẩu trang
  * Ho khạc vào giấy và bỏ vào túi nilon đựng rác.
  * Khi sốt: uống nhiều nước, uống Oresol theo chỉ dẫn, uống thuốc hạ sốt nếu sốt từ 38.5oC trở lên. Uống thuốc theo chỉ dẫn của bác sĩ.
  * Rửa tay, đánh răng, súc miệng nước muối, tắm/lau bằng nước ấm nhằm làm sạch cơ thể để tránh nhiễm trùng các loại vi khuẩn khác.
  * Sau khi đi vệ sinh, đậy nắp bồn cầu trước khi xả nước.
  * Tập thể dục nhẹ nhàng, nghe nhạc xem phim thư giãn, viết nhật ký cách ly…
  * Sử dụng riêng bát đĩa cốc khi ăn uống, sau khi dùng xong rửa sạch bằng xà phòng rửa bát.
  * Người cách ly là người nhiễm được yêu cầu tiếp tục cách ly tại nhà: **Tuyệt đối** ở trong phòng/góc cách ly trong suốt thời gian yêu cầu cách ly.


### **Tuyệt đối không đi ra ngoài và**
  * Không tổ chức hoặc tham gia liên hoan
  * Không đi chợ, đi thăm bạn bè, đi chơi
  * Không tiếp khách đến thăm
  * Không ra hiệu thuốc tự mua thuốc
  * Hãy gọi người trợ giúp khi cần


### **3.2. Các thành viên sống cùng nhà với người được cách ly**
  * Thường xuyên rửa tay bằng xà phòng ít nhất 20 giây mỗi lần.
  * Đeo khẩu trang vải hoặc khẩu trang y tế. Khẩu trang vải phải được giặt hàng ngày bằng xà phòng.
  * Giữ khoảng cách tối thiểu 2 mét với người được cách ly.
  * Sử dụng riêng nhà vệ sinh với người cách ly là tốt nhất.
  * Tắm nước ấm ít nhất 1 lần ngày.
  * Tráng nước nóng cốc, chén, bát, đũa trước khi sử dụng.
  * Lau nhà, đồ dùng trong nhà với nước Javen 0.5%.
  * Không ra khỏi nhà trong thời gian cách ly.


### **3.3. Đối với người chăm sóc cần tiếp xúc trực tiếp với người nghi nhiễm**
  * **_Trước khi vào phòng cách ly:_** + Mặc quần áo bảo hộ có mũ (hoặc thay bằng áo mưa giấy) + Đi ủng bảo hộ (hoặc thay bằng túi nilon buộc chun cổ chân) + Đeo khẩu trang N95 khít mặt (hoặc thay bằng khẩu trang y tế và tấm che mặt). Đem theo 1 khẩu trang dự phòng, cất trong túi dễ lấy khi cần + Đeo kính bảo hộ và/hoặc tấm nhựa che mặt (hoặc bất kỳ loại kính nào) + Đeo găng tay y tế


  * **_Khi vào phòng cách ly:_**


+ Động viên người được cách ly để họ ổn định tinh thần, không lo lắng, không cảm thấy bị bỏ rơi hoặc có lỗi. + Hỏi tình trạng sức khỏe, thu thập thông tin nhiệt độ và tình trạng chung (hỗ trợ đo nhiệt độ nếu cần), các vấn đề sinh hoạt (ăn uống, cảm giác ngon miệng, số lần đi tiểu, số lần đi đại tiện) (sau khi ra ngoài cần ghi lại vào sổ theo dõi – theo mẫu). + Động viên (kiểm tra) uống thuốc theo chỉ dẫn của bác sĩ. Đảm bảo người cách ly uống đủ nước, giữ ấm cơ thể. + Nếu người cách ly có nhiều đờm mà không khạc được thì khum tay vỗ mạnh vào lưng để kích thích long đờm. + Luôn ý thức và tự nhắc nhở không chạm lên mặt, lên người mình kể cả khi ngứa. Nếu khẩu trang bị ướt hay bẩn do chất nôn/ho của người cách ly thì phải thay ngay. + Lau sàn nhà, vật dụng hàng ngày… bằng xà phòng. Lau các khu nguy cơ cao bằng nước Javen. Với các vật dụng bằng da, kim loại thì lau bằng cồn 60-70% 2 lần/ngày.
+ Bỏ rác thải của người cách ly (khẩu trang, giấy lau chùi…) ít nhất 1-2 lần/ngày. Rác thải cần bỏ vào túi nilon, rót dung dịch Chlorin hoặc Chloramin B pha theo hướng dẫn ở bao bì vào để tiệt khuẩn trước khi bỏ.
  * **_Khi ra khỏi phòng cách ly_**


+ Để nguyên găng tay, rửa tay bằng nước rửa tay khô.
+ Cởi bỏ quần áo bảo hộ, ủng bảo hộ. + Cởi bỏ kính bảo hộ và khẩu trang.
+ Bỏ chất thải, đồ bảo hộ vào túi đựng chất thải, buộc lại và bỏ vào 1 túi khác, buộc lại rồi mới vứt đi. Tuyệt đối tránh tiếp xúc trực tiếp với chất thải. + Tiệt khuẩn các đồ dùng mang ra khỏi phòng cách ly.
+ Rửa tay bằng xà phòng và nước sạch ít nhất 20 giây và lau tay bằng giấy.
  * **_Hoạt động chung_**


+ Giặt quần áo người cách ly riêng với xà phòng và nước nóng (60-90oC). Tránh tiếp xúc trực tiếp với quần áo người bệnh (đeo găng tay khi giặt).
+ Dụng cụ ăn uống: khử khuẩn bằng nước Javen 0.5% rồi rửa lại bằng nước sạch và xà phòng
+ Thường xuyên liên hệ với bác sĩ để báo cáo tình hình và xin tư vấn.
+ Giám sát tình hình sức khỏe của tất cả mọi người trong nhà xem có triệu chứng nghi bệnh không. Nếu không có triệu chứng hoàn thành cách ly theo quy định y tế địa phương. 
​​​​​​​+ Mạnh mẽ và kiên định khi bị người xung quanh xa lánh vì sợ lây. Đó là cảm xúc bình thường của con người.
+ Nấu đồ ăn dinh dưỡng, dễ nuốt, dễ tiêu hóa cho người cách ly và cả gia đình.
+ Không ra khỏi nhà trong thời gian cách ly.
### **3.4. Nếu người nhà xuất hiện triệu chứng nghi mắc COVID**
  * Thông báo cơ quan y tế và làm theo hướng dẫn.
  * Nếu phải đến cơ sở y tế khám, không đi bằng các phương tiện giao thông công cộng. Nếu đi bằng ô tô, mở cửa sổ cho thoáng.
  * Luôn đeo khẩu trang, ho/hắt hơi vào giấy, rửa tay thường xuyên hoặc sau ho/hắt hơi.
  * Giữ khoảng cách tối thiểu 2m với người xung quanh.


​​​​​​​
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [1. Chuẩn bị phòng cách ly: điều quan trọng nhất là tất cả hoạt động và đồ dùng cần phải RIÊNG](https://bvnguyentriphuong.com.vn/kiem-soat-nhiem-khuan/f1-cach-ly-tai-nha-vi-covid-can-chu-y-gi#1-chun-b-phng-cch-ly-iu-quan-trng-nht-l-tt-c-hot-ng-v-dng-cn-phi-ring)
  * [2. Chuẩn bị đồ sát khuẩn cho người chăm sóc: càng ít người chăm sóc càng tốt](https://bvnguyentriphuong.com.vn/kiem-soat-nhiem-khuan/f1-cach-ly-tai-nha-vi-covid-can-chu-y-gi#2-chun-b-st-khun-cho-ngi-chm-sc-cng-t-ngi-chm-sc-cng-tt)
  * [3. Thực hiện cách ly](https://bvnguyentriphuong.com.vn/kiem-soat-nhiem-khuan/f1-cach-ly-tai-nha-vi-covid-can-chu-y-gi#3-thc-hin-cch-ly)
  * [3.1. Đối với F1](https://bvnguyentriphuong.com.vn/kiem-soat-nhiem-khuan/f1-cach-ly-tai-nha-vi-covid-can-chu-y-gi#31-i-vi-f1)
  * [Tuyệt đối không đi ra ngoài và](https://bvnguyentriphuong.com.vn/kiem-soat-nhiem-khuan/f1-cach-ly-tai-nha-vi-covid-can-chu-y-gi#tuyt-i-khng-i-ra-ngoi-v)
  * [3.2. Các thành viên sống cùng nhà với người được cách ly](https://bvnguyentriphuong.com.vn/kiem-soat-nhiem-khuan/f1-cach-ly-tai-nha-vi-covid-can-chu-y-gi#32-cc-thnh-vin-sng-cng-nh-vi-ngi-c-cch-ly)
  * [3.3. Đối với người chăm sóc cần tiếp xúc trực tiếp với người nghi nhiễm](https://bvnguyentriphuong.com.vn/kiem-soat-nhiem-khuan/f1-cach-ly-tai-nha-vi-covid-can-chu-y-gi#33-i-vi-ngi-chm-sc-cn-tip-xc-trc-tip-vi-ngi-nghi-nhim)
  * [3.4. Nếu người nhà xuất hiện triệu chứng nghi mắc COVID](https://bvnguyentriphuong.com.vn/kiem-soat-nhiem-khuan/f1-cach-ly-tai-nha-vi-covid-can-chu-y-gi#34-nu-ngi-nh-xut-hin-triu-chng-nghi-mc-covid)



## ️ Hướng dẫn mang đồ bảo hộ cá nhân dành cho nhân viên y tế

**Bệnh viện Nguyễn Tri Phương** - Bệnh viện Đa khoa Hạng I Thành phố Hồ Chí Minh
  * 468 Nguyễn Trãi, Phường 8, Quận 5, Tp. Hồ Chí Minh
  * Hotline: (84-028) 39234332
  * Mạng xã hội **Facebook** : [**Bệnh viện Nguyễn Tri Phương**](https://www.facebook.com/BVNTP/)
  * Đăng ký (Subcribe) kênh **Youtube** : [https://youtube.com/bvntp](https://youtube.com/bvntp?fbclid=IwAR3q_UvPI4OZAebT1uQGPKKwk3RmCzAFLkBJm9lb7EwIz0EHtgiLhKM5bxU)
  * Quan tâm Zalo Official: [zalo.me/1744466261097093886](https://zalo.me/1744466261097093886?fbclid=IwAR3E-fLqdh-x1cYSvuDY6E5Eyxfjo5ZSs4p0hDWAyBG-ROlTkxXkXvdEWAY)



## ️ Các vật dụng cần làm sạch trong mùa cảm cúm

  * [Tay cầm vòi nước](https://bvnguyentriphuong.com.vn/dieu-duong/cac-vat-dung-can-lam-sach-trong-mua-cam-cum#tay-cm-vi-nc)
  * [Bàn chải đánh răng bị nhiễm khuẩn](https://bvnguyentriphuong.com.vn/dieu-duong/cac-vat-dung-can-lam-sach-trong-mua-cam-cum#bn-chi-nh-rng-b-nhim-khun)
  * [Đồ chơi bằng nhựa nhiễm bẩn](https://bvnguyentriphuong.com.vn/dieu-duong/cac-vat-dung-can-lam-sach-trong-mua-cam-cum#-chi-bng-nha-nhim-bn)
  * [Màn hình cảm ứng ](https://bvnguyentriphuong.com.vn/dieu-duong/cac-vat-dung-can-lam-sach-trong-mua-cam-cum#mn-hnh-cm-ng)
  * [Điều khiển TV bẩn](https://bvnguyentriphuong.com.vn/dieu-duong/cac-vat-dung-can-lam-sach-trong-mua-cam-cum#iu-khin-tv-bn)
  * [Rửa tay thật kỹ](https://bvnguyentriphuong.com.vn/dieu-duong/cac-vat-dung-can-lam-sach-trong-mua-cam-cum#ra-tay-tht-k)


## **Tay cầm vòi nước**
Tay bẩn có nhiễm vi rút cúm và cảm lạnh thường xuyên chạm vào tay cầm vòi nước ở nhà bếp và phòng tắm. Khi người khác sử dụng vòi nước, vi rút cúm có thể lây lan và gây bệnh cho người lành. Không những thế, những khu vực này là nơi lý tưởng cho nấm men, nấm mốc và vi khuẩn như salmonella và E.coli trú ngụ và phát triển. Vì vậy việc vệ sinh khu vực này là vô cùng cần thiết. Nên vệ sinh tay cầm vòi hàng ngày bằng nước xịt khử trùng hoặc khăn lau sạch.
## **Bàn chải đánh răng bị nhiễm khuẩn**
Một nghiên cứu cho thấy bàn chải đánh răng có thể là một trong những vật dụng nhiễm khuẩn nhiều nhất trong nhà. Theo nguyên tắc chung, hãy vệ sinh cho chúng bằng nước xà phòng nóng từ 1-2 lần/tuần. Và nếu như có ai đó trong gia đình bị bệnh, hãy để riêng bàn chải đánh răng của người đó.
## **Đồ chơi bằng nhựa nhiễm bẩn**
Trẻ có thể bị cảm lạnh tới 8 lần một năm do đó những vi trùng có thể dễ dàng lây lan sang đồ đạc của chúng.
Làm sạch đồ chơi vào cuối mỗi tháng và khi chúng có thể bẩn hơn bình thường (ví dụ như sau khi con bạn bị ốm). Có thể tiêu diệt nhiều loại vi khuẩn và vi rút trên đồ chơi bằng nhựa cứng bằng cách rửa với xà phòng và nước ấm. Nếu được, hãy lau sạch chúng bằng hỗn hợp 1 muỗng thuốc tẩy pha với 1 lít nước, sau đó để khô.
## **Màn hình cảm ứng**
Từ những chiếc điện thoại thông minh hoặc máy tính bảng mà bạn luôn luôn sử dụng để làm việc, giải trí hằng ngày, virus có thể dễ dàng lây lan từ kính màn hình sang đầu ngón tay khi bạn sử dụng. Vì vậy, cần làm sạch các thiết bị điện tử thường tiếp xúc, đặc biệt là trong mùa lạnh và cúm.
Có thể sử dụng khăn lau đặc biệt hoặc thực hiện theo các hướng dẫn để làm sạch màn hình từ nhà sản xuất. Ngoài ra có thể sử dụng các thiết bị chiếu tia cực tím để khử trùng.
## **Điều khiển TV bẩn**
Liệu làm sạch các nút trên điều khiển TV có được liệt kê vào danh sách công việc nhà của bạn? Rất có thể đây là một trong các vật dụng thường dùng bẩn nhất trong nhà. Hơn nữa, virus cúm thường sống lâu trên bề mặt nhựa cứng.
Để làm sạch điều khiển TV, đầu tiên sử dụng với một bàn chải đánh răng khô. Sau đó sử dụng tăm bông hoặc miếng bông tẩm dung dịch sát khuẩn và vắt gần khô để khử trùng. Có thể sử dụng phương pháp trên đối với bàn phím máy tính.
## **Bàn làm việc**
Văn phòng có thể chứa nhiều loại vi trùng. Mọi người mang theo vi khuẩn từ nhà, trên xe buýt sau đó mang đến văn phòng làm việc. Những virus này có thể sống trên bề mặt bàn tới 8 giờ. Vì vậy cần thường xuyên dọn dẹp và làm sạch không gian làm việc của bạn, đặc biệt là khi cảm lạnh và cúm đang diễn ra.
## **Rửa tay thật kỹ**
Ngay cả khi làm sạch mọi thứ xung quanh, rửa tay vẫn là việc cần phải thực hiện kỹ càng. Thực hiện thường xuyên có thể làm giảm khả năng bị cảm lạnh hoặc cúm.
Cách rửa tay đúng:
  * Chà hai bàn tay với xà phòng trong ít nhất 20 giây trước khi rửa sạch
  * Không quên rửa sạch mu bàn tay, giữa các ngón tay và khu vực bên dưới móng tay của bạn. Nếu không có bồn rửa tay, hãy sử dụng chất khử trùng tay với ít nhất 60% cồn.


**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [Tay cầm vòi nước](https://bvnguyentriphuong.com.vn/dieu-duong/cac-vat-dung-can-lam-sach-trong-mua-cam-cum#tay-cm-vi-nc)
  * [Bàn chải đánh răng bị nhiễm khuẩn](https://bvnguyentriphuong.com.vn/dieu-duong/cac-vat-dung-can-lam-sach-trong-mua-cam-cum#bn-chi-nh-rng-b-nhim-khun)
  * [Đồ chơi bằng nhựa nhiễm bẩn](https://bvnguyentriphuong.com.vn/dieu-duong/cac-vat-dung-can-lam-sach-trong-mua-cam-cum#-chi-bng-nha-nhim-bn)
  * [Màn hình cảm ứng ](https://bvnguyentriphuong.com.vn/dieu-duong/cac-vat-dung-can-lam-sach-trong-mua-cam-cum#mn-hnh-cm-ng)
  * [Điều khiển TV bẩn](https://bvnguyentriphuong.com.vn/dieu-duong/cac-vat-dung-can-lam-sach-trong-mua-cam-cum#iu-khin-tv-bn)
  * [Rửa tay thật kỹ](https://bvnguyentriphuong.com.vn/dieu-duong/cac-vat-dung-can-lam-sach-trong-mua-cam-cum#ra-tay-tht-k)



## ️ Ngày hội rửa tay

BS CKII Võ Đức Chiến, Giám đốc BV Nguyễn Tri Phương (TP.HCM), nhấn mạnh tầm quan trọng và lợi ích của hành động [vệ sinh tay](https://plo.vn/tags/duG7hyBzaW5oIHRheQ==/ve-sinh-tay.html) vừa đơn giản và rẻ tiền tại buổi lễ phát động vệ sinh tay năm 2019 với chủ đề “Tất cả chăm sóc sạch - nằm trong bàn tay bạn” diễn ra chiều 15-10 nhằm hưởng ứng Ngày thế giới rửa tay 15-10.
Theo Tổ chức Y tế thế giới (WHO), vệ sinh tay là biện pháp đơn giản, rẻ tiền nhưng giúp giảm 30% vi khuẩn gây bệnh, có hiệu quả góp phần đáng kể làm giảm nhiễm khuẩn BV, hạn chế các mầm bệnh lây lan.
Tại BV Nguyễn Tri Phương những năm gần đây, công tác vệ sinh tay tại BV đã có chuyển biến tích cực, tỉ lệ tuân thủ vệ sinh tay tại BV ngày càng tăng (đạt hơn 90%). Bên cạnh đó, BV cũng chú trọng tuyên truyền, khuyến khích thân nhân bệnh nhân việc vệ sinh tay trong chăm sóc người thân.
Một số trang tin chi tiết: 
**Bệnh viện Nguyễn Tri Phương** - Bệnh viện Đa khoa Hạng I Thành phố Hồ Chí Minh
  * 468 Nguyễn Trãi, Phường 8, Quận 5, Tp. Hồ Chí Minh
  * Hotline: (84-028) 39234332
  * Mạng xã hội **Facebook** : [**Bệnh viện Nguyễn Tri Phương**](https://www.facebook.com/BVNTP/)
  * Đăng ký (Subcribe) kênh **Youtube** : [https://youtube.com/bvntp](https://youtube.com/bvntp?fbclid=IwAR3q_UvPI4OZAebT1uQGPKKwk3RmCzAFLkBJm9lb7EwIz0EHtgiLhKM5bxU)
  * Quan tâm Zalo Official: [zalo.me/1744466261097093886](https://zalo.me/1744466261097093886?fbclid=IwAR3E-fLqdh-x1cYSvuDY6E5Eyxfjo5ZSs4p0hDWAyBG-ROlTkxXkXvdEWAY)



## ️ Chiến lược, nguyên tắc và biện pháp kiểm soát lây nhiễm nCoV

  * [Người không có triệu chứng hô hấp nên:](https://bvnguyentriphuong.com.vn/khoa-kham-benh/chien-luoc-nguyen-tac-va-bien-phap-kiem-soat-lay-nhiem-ncov#ngi-khng-c-triu-chng-h-hp-nn)
  * [Người có triệu chứng hô hấp nên:](https://bvnguyentriphuong.com.vn/khoa-kham-benh/chien-luoc-nguyen-tac-va-bien-phap-kiem-soat-lay-nhiem-ncov#ngi-co-triu-chng-h-hp-nn)
  * [Quản lý khẩu trang](https://bvnguyentriphuong.com.vn/khoa-kham-benh/chien-luoc-nguyen-tac-va-bien-phap-kiem-soat-lay-nhiem-ncov#quan-ly-khu-trang)


Người dân hạn chế đến những khu vực đang có dịch. Người đã đến những khu vực đó hoặc người có tiếp xúc gần với người nghi nhiễm hoặc đã được khẳng định nCoV cần tự cách ly, theo dõi sát thân nhiệt trong vòng 14 ngày. Phải đến bệnh viện ngay khi có sốt hoặc có các triệu chứng về hô hấp.
### **Người không có triệu chứng hô hấp nên:**
  * Tránh tụ tập và thường xuyên đến nơi đông đúc;
  * Duy trì khoảng cách ít nhất 1 m với bất kỳ người nào có triệu chứng hô hấp nCoV (ví dụ: ho, hắt hơi);
  * Thực hiện vệ sinh tay thường xuyên, sử dụng chà tay bằng dung dịch chứa cồn nếu tay không dính bẩn hoặc bằng xà phòng và nước khi tay bị dính bẩn;
  * Nếu ho hoặc hắt hơi che mũi và miệng bằng khuỷu tay gấp hoặc khăn giấy bị, vứt bỏ khăn giấy ngay sau khi sử dụng và thực hiện vệ sinh tay;
  * Hạn chế không chạm vào miệng và mũi;


Không cần thiết phải đeo khẩu trang y tế, vì không có bằng chứng nào về tính hữu ích của nó để bảo vệ người không mắc bệnh. Tuy nhiên, khẩu trang có thể được đeo ở một số quốc gia theo thói quen văn hóa địa phương. Nếu sử dụng khẩu trang, cần tuân thủ các cách thực hành tốt nhất về cách đeo, tháo, vứt bỏ sau khi sử dụng và vệ sinh tay sau khi tháo ra (xem lời khuyên dưới đây về cách quản lý khẩu trang phù hợp).
### **Người có triệu chứng hô hấp nên:**
Đeo khẩu trang y tế và tìm kiếm sự chăm sóc y tế nếu bị sốt, ho và khó thở… càng sớm càng tốt hoặc theo các hướng dẫn của y tế địa phương;
Sử dụng và quản lý khẩu trang đúng.
### **Quản lý khẩu trang**
Nếu đeo khẩu trang y tế, việc sử dụng và thải bỏ phù hợp là điều cần thiết để đảm bảo có hiệu quả và tránh mọi nguy cơ lây truyền liên quan đến việc sử dụng và thải bỏ khẩu trang không đúng cách:
  * Đặt khẩu trang cẩn thận để che kín miệng và mũi và buộc chắc chắn để giảm thiểu bất kỳ khoảng trống giữa mặt và khẩu trang;
  * Trong khi thao tác đeo, tránh chạm vào khẩu trang;
  * Loại bỏ khẩu trang bằng cách sử dụng kỹ thuật thích hợp (nghĩa là không chạm vào mặt trước mà tháo dây từ phía sau);
  * Sau khi loại bỏ hoặc bất cứ khi nào vô tình chạm vào khẩu trang đã sử dụng, hãy làm sạch tay bằng cách chà tay bằng cồn hoặc xà phòng và nước nếu thấy bẩn;
  * Thay khẩu trang bằng khẩu trang mới khô, sạch ngay khi chúng bị ẩm/ướt;
  * Không sử dụng lại khẩu trang sử dụng một lần;
  * Loại bỏ khẩu trang sử dụng một lần sau mỗi lần sử dụng và loại bỏ chúng ngay lập tức sau khi tháo.


**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh
[youtube.com/bvntp](http://youtube.com/bvntp)
  * [Người không có triệu chứng hô hấp nên:](https://bvnguyentriphuong.com.vn/khoa-kham-benh/chien-luoc-nguyen-tac-va-bien-phap-kiem-soat-lay-nhiem-ncov#ngi-khng-c-triu-chng-h-hp-nn)
  * [Người có triệu chứng hô hấp nên:](https://bvnguyentriphuong.com.vn/khoa-kham-benh/chien-luoc-nguyen-tac-va-bien-phap-kiem-soat-lay-nhiem-ncov#ngi-co-triu-chng-h-hp-nn)
  * [Quản lý khẩu trang](https://bvnguyentriphuong.com.vn/khoa-kham-benh/chien-luoc-nguyen-tac-va-bien-phap-kiem-soat-lay-nhiem-ncov#quan-ly-khu-trang)



## ️ Làm thế nào để giảm nguy cơ mắc các bệnh truyền nhiễm?

  * [Thường xuyên rửa sạch tay](https://bvnguyentriphuong.com.vn/kiem-soat-nhiem-khuan/lam-the-nao-de-giam-nguy-co-mac-cac-benh-truyen-nhiem#thng-xuyn-ra-sch-tay)
  * [Không dùng chung dụng cụ cá nhân](https://bvnguyentriphuong.com.vn/kiem-soat-nhiem-khuan/lam-the-nao-de-giam-nguy-co-mac-cac-benh-truyen-nhiem#khng-dng-chung-dng-c-c-nhn)
  * [Che miệng khi bạn ho hoặc hắt hơi](https://bvnguyentriphuong.com.vn/kiem-soat-nhiem-khuan/lam-the-nao-de-giam-nguy-co-mac-cac-benh-truyen-nhiem#che-ming-khi-bn-ho-hoc-ht-hi)
  * [Chích ngừa Vắc- xin](https://bvnguyentriphuong.com.vn/kiem-soat-nhiem-khuan/lam-the-nao-de-giam-nguy-co-mac-cac-benh-truyen-nhiem#chch-nga-vc-xin)
  * [Áp dụng thực hành nấu ăn an toàn](https://bvnguyentriphuong.com.vn/kiem-soat-nhiem-khuan/lam-the-nao-de-giam-nguy-co-mac-cac-benh-truyen-nhiem#p-dng-thc-hnh-nu-n-an-ton)
  * [Hãy là 1 du khách khôn ngoan](https://bvnguyentriphuong.com.vn/kiem-soat-nhiem-khuan/lam-the-nao-de-giam-nguy-co-mac-cac-benh-truyen-nhiem#hy-l-1-du-khch-khn-ngoan)
  * [An toàn trong tình dục](https://bvnguyentriphuong.com.vn/kiem-soat-nhiem-khuan/lam-the-nao-de-giam-nguy-co-mac-cac-benh-truyen-nhiem#an-ton-trong-tnh-dc)
  * [Đừng ngoáy mũi (hoặc miệng và mắt của bạn)](https://bvnguyentriphuong.com.vn/kiem-soat-nhiem-khuan/lam-the-nao-de-giam-nguy-co-mac-cac-benh-truyen-nhiem#ng-ngoy-mi-hoc-ming-v-mt-ca-bn)
  * [Thận trọng với động vật](https://bvnguyentriphuong.com.vn/kiem-soat-nhiem-khuan/lam-the-nao-de-giam-nguy-co-mac-cac-benh-truyen-nhiem#thn-trng-vi-ng-vt)
  * [Cập nhật thông tin](https://bvnguyentriphuong.com.vn/kiem-soat-nhiem-khuan/lam-the-nao-de-giam-nguy-co-mac-cac-benh-truyen-nhiem#cp-nht-thng-tin)


Hãy xem 10 lời khuyên thiết thực dưới đây để giảm nguy cơ của bạn, sau đó là một vài lưu ý đặc biệt cho những người đang mang thai hoặc bị suy giảm miễn dịch do bệnh hoặc hóa trị. Một số lời khuyên này có vẻ rõ ràng, nhưng những lời khuyên khác có thể làm bạn ngạc nhiên.
## **Thường xuyên rửa sạch tay**
Bạn có biết rằng vi khuẩn có thể sống trên bề mặt ở bất cứ đâu từ vài phút đến vài tháng? Nó phụ thuộc vào loại vi khuẩn và môi trường. Một số chỉ có thể sống trong thời gian ngắn; những người khác có thể sống trong thời gian dài. Hãy tưởng tượng những vi khuẩn gây bệnh này sống trên bàn phím máy tính, công tắc đèn hoặc thậm chí trên vị trí băng qua đường dành cho người đi bộ bên cạnh lối đi.Nhiều bệnh có thể lây truyền qua vật trung gian (fomites), thuật ngữ được sử dụng để mô tả trung gian giữa người nhiễm bệnh khác và chính bạn.
Đáng ngạc nhiên, đại đa số chúng ta không biết cách tốt nhất để rửa tay hiệu quả. CDC khuyên bạn nên rửa kỹ và mạnh bằng xà phòng và nước trong ít nhất 20 giây, sau đó lau khô bằng khăn giấy. Trong trường hợp không có nước chảy, một loại gel rửa tay hoặc giấy có chứa cồn có thể chấp nhận được, mặc dù không có gì tốt hơn xà phòng và nước. Điều này mất khoảng thời gian để hát "Chúc mừng sinh nhật", vì vậy một số bệnh viện ở nước ngoài khuyên bạn nên rửa tay trong lúc hát giai điệu đơn giản này!
## **Không dùng chung dụng cụ cá nhân**
Bàn chải đánh răng, khăn tắm, dao cạo râu, khăn tay và đồ cắt móng tay đều có thể là nguồn của các tác nhân truyền nhiễm (vi khuẩn, vi rút và nấm). Bây giờ hãy cố gắng nhớ để giữ các vật dụng cá nhân cho chính mình!
Một ví dụ về lây truyền "đáng ngạc nhiên" là lây truyền viêm gan B. Chúng ta biết rằng vi-rút cần truyền từ máu của người này sang máu của người khác. Tuy nhiên, một tỷ lệ lớn những người nhiễm bệnh không nhớ lại bất kỳ yếu tố nguy cơ "rõ ràng" nào sẽ giải thích cách họ nhiễm virus.
## **Che miệng khi bạn ho hoặc hắt hơi**
Trong 1 cách tương tự, vệ sinh cá nhân tốt bao gồm không chỉ vệ sinh cá nhân bạn mà còn cả thói quen che miệng khi bạn ho hoặc hắt hơi. Tại sao điều này lại quan trọng nếu bạn bị ốm? Đối với hầu hết các bệnh nhiễm trùng, vi khuẩn gây bệnh đã bắt đầu phát triển và phân chia từ lâu trước khi bất kỳ triệu chứng nào bắt đầu xuất hiện.
Ho hoặc hắt hơi có thể lây lan những mầm bệnh này qua những giọt nước siêu nhỏ trong không khí. Khuyến cáo hiện tại là che miệng bằng cánh tay, tay áo hoặc khuỷu tay của bạn, thay vì dùng tay.
## **Chích ngừa Vắc- xin**
Hệ thống miễn dịch của bạn được thiết kế để có bộ nhớ về các bệnh nhiễm trùng trước đó. Khi cơ thể bạn gặp một vi khuẩn trước đây đã gây ra nhiễm trùng, nó sẽ tăng cường sản xuất các tế bào bạch cầu và kháng thể để ngăn ngừa nhiễm trùng lần thứ hai. Tuy nhiên, bằng cách tiêm vắc-xin, bạn đã lừa cơ thể của mình nghĩ rằng nó đã bị nhiễm một loại vi khuẩn cụ thể, do đó tăng cường khả năng phòng vệ của chính nó chống lại nhiễm trùng tiếp theo.
## **Áp dụng thực hành nấu ăn an toàn**
Bệnh do thực phẩm thường phát sinh từ thói quen chuẩn bị thức ăn và thói quen ăn uống kém. Điều mà nhiều người không nhận ra là hầu hết các trường hợp "cúm dạ dày" ở người lớn thực sự là ngộ độc thực phẩm. Vi khuẩn phát triển mạnh trên hầu hết tất cả các mặt hàng thực phẩm và hơn thế nữa là thực phẩm ở nhiệt độ phòng
Tủ lạnh làm chậm hoặc ngăn chặn sự phát triển của hầu hết các vi khuẩn. Nhanh chóng làm lạnh thực phẩm trong vòng hai giờ sau khi chuẩn bị. Hãy xem những lời khuyên này để đảm bảo an toàn thực phẩm tại các bữa tiệc nướng và dã ngoại. Sử dụng thớt riêng cho thịt và rau sống, giữ cho mặt bàn của bạn sạch sẽ, và rửa tất cả các loại trái cây và rau quả trước khi ăn.
## **Hãy là 1 du khách khôn ngoan**
Các bệnh truyền nhiễm có thể dễ dàng bị mắc phải khi đi du lịch, đặc biệt là khi đi du lịch đến các quốc gia hạn chế về nguồn tài nguyên. Nếu điểm đến du lịch của bạn là một nơi mà nguồn nước đang có vấn đề, hãy đảm bảo sử dụng một nguồn nước an toàn như nước đóng chai để uống và đánh răng. Hãy nhớ rằng đá viên đôi khi có thể là một nguồn nước bị ô nhiễm "ngầm".
Ăn thực phẩm đã được nấu chín, và tránh rau và trái cây sống. Khi bạn ăn trái cây, hãy chọn những quả có thể gọt vỏ và đảm bảo vỏ không tiếp xúc với phần còn lại của quả trong quá trình gọt vỏ. Cuối cùng, hãy chắc chắn cập nhật tất cả các loại chủng ngừa được tư vấn hoặc cần thiết cho điểm đến du lịch của bạn.
## **An toàn trong tình dục**
Các bệnh lây truyền qua đường tình dục có lẽ là bệnh truyền nhiễm dễ phòng ngừa nhất. Bằng cách thông minh về tình dục an toàn (sử dụng bao cao su), việc truyền vi khuẩn hoặc vi rút truyền nhiễm từ người này sang người khác có thể được ngăn chặn.
Đó không chỉ là một bệnh truyền nhiễm, hoặc thậm chí khi mang thai, đó có thể là một vấn đề. Ở Hoa Kỳ, người ta cho rằng 10% bệnh ung thư có liên quan đến nhiễm trùng và trên toàn thế giới, con số này chiếm 25%.
## **Đừng ngoáy mũi (hoặc miệng và mắt của bạn)**
Không chỉ là một điều phản cảm trong xã hội, mà việc ngoáy mũi dẫn đến sự lây lan của một số bệnh nhiễm trùng. Nhìn xung quanh và bạn sẽ nhận thấy có bao nhiêu người có bàn tay bên cạnh khuôn mặt của họ. Nhiều vi khuẩn thích môi trường ấm áp, ẩm ướt bên trong mũi của bạn, cũng như các bề mặt phủ chất nhầy khác như mắt và miệng của bạn. Nhiễm trùng có thể dễ dàng ngăn ngừa bằng cách tránh chạm vào các khu vực này.
## **Thận trọng với động vật**
Các loại động vật hoang dã khác nhau có thể mang các bệnh như bệnh dại hoặc cúm gà và bọ chét và ve có thể truyền bệnh dịch hạch và bệnh Lyme. Đảm bảo cho khu vực xung quanh nhà bạn không có sự lui tới của loài gặm nhấm và các động vật có vú khác bằng cách loại bỏ những khu vực chúng có thể ẩn nấp hoặc xây tổ, sử dụng thùng rác chống gặm nhấm có chứa chất thải thực phẩm và bịt kín các lỗ dễ dàng tiếp cận với động vật. Dạy trẻ nhỏ trong gia đình của bạn phải thận trọng khi gặp động vật hoang dã.
## **Cập nhật thông tin**
Hiểu rõ về các tin tức sự kiện hiện tại có thể giúp bạn đưa ra quyết định sáng suốt về du lịch hoặc các hoạt động giải trí khác. Ví dụ, dịch cúm gia cầm ở châu Á có thể khiến bạn phải suy nghĩ kỹ về chuyến đi mà bạn đang lên kế hoạch. Báo cáo gần đây về siêu vi trùng West Nile do muỗi truyền? Bạn có thể muốn mang theo một số thuốc chống côn trùng trong chuyến đi cắm trại của bạn! Salmonella trong cà chua? Đừng ăn cà chua. Các trang mạng trực tuyến cung cấp thông tin về các vụ dịch mới nhất cũng như các khu vực trên thế giới đang có bệnh dịch.
**Bệnh viện Nguyễn Tri Phương** - Bệnh viện Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [Thường xuyên rửa sạch tay](https://bvnguyentriphuong.com.vn/kiem-soat-nhiem-khuan/lam-the-nao-de-giam-nguy-co-mac-cac-benh-truyen-nhiem#thng-xuyn-ra-sch-tay)
  * [Không dùng chung dụng cụ cá nhân](https://bvnguyentriphuong.com.vn/kiem-soat-nhiem-khuan/lam-the-nao-de-giam-nguy-co-mac-cac-benh-truyen-nhiem#khng-dng-chung-dng-c-c-nhn)
  * [Che miệng khi bạn ho hoặc hắt hơi](https://bvnguyentriphuong.com.vn/kiem-soat-nhiem-khuan/lam-the-nao-de-giam-nguy-co-mac-cac-benh-truyen-nhiem#che-ming-khi-bn-ho-hoc-ht-hi)
  * [Chích ngừa Vắc- xin](https://bvnguyentriphuong.com.vn/kiem-soat-nhiem-khuan/lam-the-nao-de-giam-nguy-co-mac-cac-benh-truyen-nhiem#chch-nga-vc-xin)
  * [Áp dụng thực hành nấu ăn an toàn](https://bvnguyentriphuong.com.vn/kiem-soat-nhiem-khuan/lam-the-nao-de-giam-nguy-co-mac-cac-benh-truyen-nhiem#p-dng-thc-hnh-nu-n-an-ton)
  * [Hãy là 1 du khách khôn ngoan](https://bvnguyentriphuong.com.vn/kiem-soat-nhiem-khuan/lam-the-nao-de-giam-nguy-co-mac-cac-benh-truyen-nhiem#hy-l-1-du-khch-khn-ngoan)
  * [An toàn trong tình dục](https://bvnguyentriphuong.com.vn/kiem-soat-nhiem-khuan/lam-the-nao-de-giam-nguy-co-mac-cac-benh-truyen-nhiem#an-ton-trong-tnh-dc)
  * [Đừng ngoáy mũi (hoặc miệng và mắt của bạn)](https://bvnguyentriphuong.com.vn/kiem-soat-nhiem-khuan/lam-the-nao-de-giam-nguy-co-mac-cac-benh-truyen-nhiem#ng-ngoy-mi-hoc-ming-v-mt-ca-bn)
  * [Thận trọng với động vật](https://bvnguyentriphuong.com.vn/kiem-soat-nhiem-khuan/lam-the-nao-de-giam-nguy-co-mac-cac-benh-truyen-nhiem#thn-trng-vi-ng-vt)
  * [Cập nhật thông tin](https://bvnguyentriphuong.com.vn/kiem-soat-nhiem-khuan/lam-the-nao-de-giam-nguy-co-mac-cac-benh-truyen-nhiem#cp-nht-thng-tin)



