## Bệnh hẹp van tim là gì?

  * [BỆNH HẸP VAN TIM LÀ GÌ?](https://bvnguyentriphuong.com.vn/noi-tim-mach/benh-hep-van-tim-la-gi#bnh-hp-van-tim-l-g)
  * [VỀ BỆNH HẸP VAN TIM 2 LÁ](https://bvnguyentriphuong.com.vn/noi-tim-mach/benh-hep-van-tim-la-gi#v-bnh-hp-van-tim-2-l)
  * [TRIỆU CHỨNG BỆNH HẸP VAN TIM](https://bvnguyentriphuong.com.vn/noi-tim-mach/benh-hep-van-tim-la-gi#triu-chng-bnh-hp-van-tim)
  * [CHẨN ĐOÁN BỆNH HẸP VAN TIM](https://bvnguyentriphuong.com.vn/noi-tim-mach/benh-hep-van-tim-la-gi#chn-on-bnh-hp-van-tim)
  * [ĐIỀU TRỊ BỆNH HẸP VAN TIM](https://bvnguyentriphuong.com.vn/noi-tim-mach/benh-hep-van-tim-la-gi#iu-tr-bnh-hp-van-tim)


Hẹp van tim là là bệnh van tim phổ biến với tỷ lệ người mắc bệnh đang có xu hướng ngày càng gia tăng. Nếu không phát hiện và điều trị kịp thời, bệnh có thể dẫn tới nhiều biến chứng nguy hiểm như suy tim, đột quỵ, loạn nhịp tim     Hẹp van tim là tình trạng các lá van không thể mở ra hoàn toàn làm cản trở quá trình lưu thông máu qua van.
## **BỆNH HẸP VAN TIM LÀ GÌ?**
Hẹp van tim là tình trạng các lá van không thể mở ra hoàn toàn làm cản trở quá trình lưu thông máu qua van. Bệnh xảy ra khi cấu trúc của các lá van bị thay đổi, thay vì thanh mảnh, mềm mại như bình thường, chúng bị dày lên, xơ cứng hoặc dính lại với nhau. Bệnh hẹp van tim được phân loại thành:
  * Hẹp van tim 2 lá: làm giảm lưu lượng máu từ tâm nhĩ trái (buồng tim phía trên, bên trái) xuống tâm thất trái (buồng tim phía dưới, bên trái).
  * Hẹp van tim 3 lá: làm giảm lượng máu từ tâm nhĩ phải (buồng tim phía trên, bên phải) xuống tâm thất phải (buồng tim phía dưới, bên phải).
  * Hẹp van động mạch chủ: phổ biến và nghiêm trọng nhất, làm giảm lưu lượng máu từ tâm thất trái vào động mạch chủ đi nuôi cơ thể.
  * Hẹp van động mạch phổi: hạn chế lưu lượng máu từ tâm thất phải tới động mạch phổi.


## **VỀ BỆNH HẸP VAN TIM 2 LÁ**
Hẹp van tim 2 lá là dạng hẹp van tim thường gặp và có tỷ lệ tử vong cao trong các bệnh tim hiện nay tại Việt Nam. Bệnh có thể xảy ra ở những người đã từng mắc bệnh sốt thấp khớp (nguyên nhân do liên cầu khuẩn beta tan huyết nhóm A gây ra). Hẹp van tim 2 lá phổ biến ở những nước đang phát triển hoặc kém phát triển, đặc biệt là các vùng ẩm thấp và nghèo khó do không điều trị dứt điểm tình trạng sốt thấp khớp, viêm họng.
## **TRIỆU CHỨNG BỆNH HẸP VAN TIM**
Người bị hẹp van tim thường gặp phải các triệu chứng sau:
  * Đau ngực
  * Khó thở, đặc biệt là khi gắng sức.
  * Mệt mỏi, tăng lên khi làm việc nặng.
  * Tim đập nhanh.
  * Choáng váng, ngất xỉu.
  * Sưng phù ở mắt cá chân, bàn chân (giai đoạn nặng)


## **CHẨN ĐOÁN BỆNH HẸP VAN TIM**
Chẩn đoán bệnh hẹp van tim bao gồm:
  * Khám lâm sàng: bác sĩ dùng ống nghe để nghe tim, ở những người có hẹp van tim, trái tim sẽ có những âm thanh bất thường.
  * Các xét nghiệm hình ảnh: siêu âm tim, chụp X quang tim phổi, siêu âm tim qua thực quản (đây là một phương pháp thăm dò không xâm lấn, giúp khảo sát tim rõ hơn, khắc phục các nhược điểm của siêu âm tim qua thành ngực).


## **ĐIỀU TRỊ BỆNH HẸP VAN TIM**
Có nhiều phương pháp điều trị hẹp van tim khác nhau, tùy thuộc vào tình trạng cụ thể của người bệnh.
  * Thuốc: giúp làm giảm các triệu chứng của bệnh, cải thiện chất lượng cuộc sống cho người bệnh. Thuốc lợi tiểu, thuốc chống đông máu, thuốc kháng sinh, thuốc hạ áp, thuốc chống loạn nhịp… là những loại thuốc được sử dụng trong điều trị hẹp van tim.
  * Phẫu thuật: được chỉ định trong trường hợp bệnh hẹp van tim đã tiến triển nặng, điều trị nội khoa không hiệu quả. Các phương pháp phẫu thuật bao gồm: nong van đường tĩnh mạch, sửa van và thay van.


Ngoài những phương pháp điều trị nêu trên, người bệnh cũng nên điều chỉnh chế độ ăn uống, sinh hoạt để phòng ngừa và ngăn chặn hẹp van tim trở nặng thêm. Cụ thể:
  * Vệ sinh răng miệng tốt để ránh nguy cơ nhiễm trùng răng miệng do liên cầu nhóm A.
  * Tiêm vắc xin cúm hằng năm
  * Kiểm soát tốt các bệnh lý khác như huyết áp cao, tiểu đường, mỡ máu cao, viêm họng…
  * Không hút thuốc
  * Duy trì chế độ ăn lành mạnh: ăn nhạt, ít chất béo bão hòa
  * Tập thể dục đều đặn
  * Khám sức khỏe định kỳ, thông báo ngay cho bác sỹ khi có dấu hiệu bất thường cảnh báo hẹp van tim.


**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/) **- Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [BỆNH HẸP VAN TIM LÀ GÌ?](https://bvnguyentriphuong.com.vn/noi-tim-mach/benh-hep-van-tim-la-gi#bnh-hp-van-tim-l-g)
  * [VỀ BỆNH HẸP VAN TIM 2 LÁ](https://bvnguyentriphuong.com.vn/noi-tim-mach/benh-hep-van-tim-la-gi#v-bnh-hp-van-tim-2-l)
  * [TRIỆU CHỨNG BỆNH HẸP VAN TIM](https://bvnguyentriphuong.com.vn/noi-tim-mach/benh-hep-van-tim-la-gi#triu-chng-bnh-hp-van-tim)
  * [CHẨN ĐOÁN BỆNH HẸP VAN TIM](https://bvnguyentriphuong.com.vn/noi-tim-mach/benh-hep-van-tim-la-gi#chn-on-bnh-hp-van-tim)
  * [ĐIỀU TRỊ BỆNH HẸP VAN TIM](https://bvnguyentriphuong.com.vn/noi-tim-mach/benh-hep-van-tim-la-gi#iu-tr-bnh-hp-van-tim)



## Dấu hiệu của đột quỵ

**Đột quỵ** là nguyên nhân gây tử vong xếp thứ năm trên toàn cầu. những **tổn thương não** do **đột quỵ** có thể được hạn chế hoặc phòng ngừa nếu như được điều trị sớm. Tuy nhiên, những **dấu hiệu** của đột quỵ lại rất dễ bị nhầm lẫn với những vấn đề sức khỏe khác, điều này có thể ngăn ngừa bạn đến sớm được với quá trình điều trị.
Cứ mỗi phút chưa được điều trị của cơn đột quỵ, não của bạn lại mất khoảng 1,9 triệu tế bào não. Cứ mỗi giờ chưa được điều trị cơn đột quỵ tương đương với 3,5 năm tuổi thọ của não mất đi. Những cơn đột quỵ có thời gian không được điều trị kéo dài hơn hoặc hoàn toàn không được điều trị sẽ gây nên những khó khăn về mặt ngôn ngữ, mất trí nhớ hoặc thay đổi hành vi. Do đó, điều trị đột quỵ càng sớm sẽ có thể giảm thiệu thiệt hại và nâng cao khả năng phục hồi toàn diện.
Bạn cũng cần lưu ý rằng có hai dạng đột quỵ khác nhau. Đột quỵ thiếu máu cục bộ xảy ra khi mạch máu bị tắc làm giảm lưu lượng máu lên não. Đột quỵ xuất huyết xảy ra khi mạch máu bị vỡ hoặc máu bị rò rỉ khỏi mạch trong não. Bởi vì các triệu chứng của cả hai dạng đột quỵ này tương đương với nhau nên điều quan trọng là bạn cần nhận biết các dấu hiệu tiềm ẩn mà mình có thể bỏ qua liên quan đến đột quỵ.
**Bạn nghĩ rằng kiệt sức khiến bạn nhìn đôi**
Các vấn đề về thị lực như nhìn đôi, mờ mắt hoặc mất thị lực một mắt có thể là dấu hiệu của đột quỵ, tuy nhiên nhiều người lại cho rằng đây là dấu hiệu của tuổi già hoặc mệt mỏi. Mạch máu bị tắc có thể làm giảm lượng oxy đến mắt, gây ra các vấn đề về thị giác.
**Bạn nghĩ rằng cánh tay của bạn bị tê chỉ vì bạn ngủ quên hoặc sai tư thế**
Nếu bạn thức dậy sau một giấc ngủ ngắn và cánh tay của bạn bị tê, đó là điều hoàn toàn bình thường. Tuy nhiên nếu cánh tay của bạn đột nhiên bị tê hoặc yếu và không biến mất trong vài phút, hãy đi khám bác sĩ ngay. Giảm lưu lượng máu đi qua các động mạch chạy lên cốt sống phía sau đầu gây ra tê hoặc yếu ở một bên cơ thể, là nguyên nhân gây tê tay.
**Bạn cho rằng bạn đang gặp tác dụng phụ của thuốc**
Một số loại thuốc như thuốc giảm đau có thể gây rối loạn ngôn ngữ và người ta thường cho rằng những rối loạn ngôn ngữ của họ là do thuốc chứ không hề nghĩ đến đột quỵ. Nếu như bạn đột nhiên gặp phải rối loạn ngôn ngữ khi dùng những loại thuốc này trong khi trước đó chưa từng bị, hãy nghĩ đến đột quỵ và đến gặp bác sĩ ngay lập tức.
**Bạn đổ lỗi cho rượu làm bạn cảm thấy choáng váng, mất thăng bằng**
Mọi người thường nghĩ rằng họ có vấn đề vể cảm thấy mất thăng bằng do uống rượu. Tuy nhiên bạn không thể đổ lỗi cho rượu nếu như bạn uống rượu từ ngày hôm trước và đến tối hôm sau mới choáng váng hoặc mất thăng bằng. Lúc này, mất thăng bằng và choáng váng có thể đến từ việc giảm lượng máu lên não.
Bạn đột nhiên bị đau nửa đầu: Nếu bạn đột nhiên đau nửa đầu, đó có thể là dấu hiệu của một cơn đột quỵ. Hãy tìm đến bác sĩ ngay khi có thể nếu bạn đột nhiên đau nửa đầu hoặc tìm đến sự trợ giúp y tế.
**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/)** - Đa khoa Hạng I Thành phố Hồ Chí Minh

## Tổng quan về hội chứng mạch vành cấp

  * [1. Hội chứng mạch vành cấp là gì?](https://bvnguyentriphuong.com.vn/noi-tim-mach/tong-quan-ve-hoi-chung-mach-vanh-cap#1-hi-chng-mch-vnh-cp-l-g)
  * [1.2 Nhồi máu cơ tim](https://bvnguyentriphuong.com.vn/noi-tim-mach/tong-quan-ve-hoi-chung-mach-vanh-cap#12-nhi-mu-c-tim)
  * [2. Các yếu tố nguy cơ của hội chứng mạch vành](https://bvnguyentriphuong.com.vn/noi-tim-mach/tong-quan-ve-hoi-chung-mach-vanh-cap#2-cc-yu-t-nguy-c-ca-hi-chng-mch-vnh)
  * [3. Chẩn đoán và điều trị hội chứng tắc nghẽn mạch vành cấp tính](https://bvnguyentriphuong.com.vn/noi-tim-mach/tong-quan-ve-hoi-chung-mach-vanh-cap#3-chn-on-v-iu-tr-hi-chng-tc-nghn-mch-vnh-cp-tnh)
  * [3.1 Chẩn đoán hội chứng mạch vành cấp](https://bvnguyentriphuong.com.vn/noi-tim-mach/tong-quan-ve-hoi-chung-mach-vanh-cap#31-chn-on-hi-chng-mch-vnh-cp)


**Hội chứng mạch vành cấp** là tình trạng lưu lượng máu nuôi tim bị giảm đột ngột do tắc nghẽn mạch vành, khiến bệnh nhân đối mặt với nguy cơ tử vong rất cao. Cùng tìm hiểu những đặc điểm bệnh mạch vành cấp qua bài viết sau đây để nhận biết và chủ động phòng tránh.
## **1. Hội chứng mạch vành cấp là gì?**
Hội chứng mạch vành cấp (ACS) là thuật ngữ dùng để chỉ hiện tượng giảm cung cấp máu đột ngột, chỉ xảy ra trong một thời gian ngắn rồi chấm dứt. Hội chứng cấp tính này thường biểu hiện dưới hai dạng là: cơn đau thắt ngực không ổn định và nhồi máu cơ tim.
_**1.1 Cơn đau thắt ngực không ổn định**_
Là tình trạng người bệnh xuất hiện những cơn đau thắt ngực do sự nứt vỡ đột ngột của các mảng xơ vữa, gây tắc nghẽn lòng động mạch vành và giảm sút lưu lượng máu tới nuôi cơ tim. Tình trạng này có thể xảy ra mà không cần bất kỳ sự gắng sức nào, tức là cả khi người bệnh đang nghỉ ngơi hay đang ngủ. Điều này khác với những cơn đau chỉ xảy ra khi gắng sức và thuyên giảm khi nghỉ ngơi hợp lý, được gọi là cơn đau thắt ngực ổn định.
Trong cơn đau thắt ngực không ổn định, các tế bào cơ tim không bị chết đi, nhưng bị tổn hại trong thời gian dài do thiếu oxy và dưỡng chất, khiến cho cơ tim không thể làm việc một cách chính xác và hiệu quả.
_Hội chứng mạch tắc nghẽn mạch vành cấp gồm 2 dạng là cơn đau thắt ngực ổn định và nhồi máu cơ tim._
### _**1.2 Nhồi máu cơ tim**_
Khi lòng động mạch vành bị tắc nghẽn hoàn toàn, thường do sự hình thành của các cục máu đông, sẽ gây ra một cơn nhồi máu cơ tim cấp tính. Lúc này các tế bào cơ tim hoàn toàn bị thiếu oxy và năng lượng sẽ bị chết đi nhanh chóng. Một vùng cơ tim bị hoại tử và hình thành mô sẹo trên tim. Nếu không được xử lý kịp thời, người bệnh sẽ tử vong.
Nhồi máu cơ tim gồm 2 dạng: nhồi máu cơ tim không ST chênh lên và nhồi máu cơ tim cấp ST chênh lên.
## **2. Triệu chứng**
Các dạng của hội chứng tim mạch cấp tính này có đặc điểm chung là các triệu chứng thường xảy ra rất đột ngột, nhiều trường hợp còn không có dấu hiệu báo trước.
Những triệu chứng thường gặp của hội chứng này nếu có bao gồm:
  * Đau thắt ngực có cảm giác bị bóp nghẹt, đè nén ở vùng ngực. Cơn đau có thể lan lên cổ, hàm, vai và cánh tay.
  * Khó thở và đổ mồ hôi lạnh
  * Buồn nôn
  * Đầy bụng, khó tiêu
  * Chóng mặt, đầu óc quay cuồng


Khi phát hiện bản thân hoặc những người xung quanh có triệu chứng này, cần nhanh chóng gọi cấp cứu. Vì hội chứng này dù xuất hiện trong thời gian ngắn nhưng lại có thể tiến triển nhanh chóng và khiến người bệnh tử vong bất cứ lúc nào.
_Đau thắt ngực là một trong những biểu hiện của hội chứng tắc nghẽn mạch vành cấp._
## **2. Các yếu tố nguy cơ của hội chứng mạch vành**
Sau đây là các yếu tố nguy cơ của hội chứng ACS:
  * Nam giới trên 45 tuổi, nữ giới trên 55 tuổi
  * Những người bị tăng huyết áp, tăng cholestol máu hay mắc bệnh đái tháo đường
  * Hút thuốc lá thường xuyên
  * Lười vận động, lối sống tĩnh tại
  * Thừa cân hoặc béo phì
  * Tiền sử gia đình có người từng mắc bệnh hội chứng mạch vàng cấp tính


## **3. Chẩn đoán và điều trị hội chứng tắc nghẽn mạch vành cấp tính**
### _**3.1 Chẩn đoán hội chứng mạch vành cấp**_
Vì là tình trạng cấp cứu, nên người bệnh gặp phải hội chứng ACS cần được đưa đến bệnh viện có chuyên khoa tim mạch để điều trị càng sớm càng tốt. Tại đây, bệnh nhân sẽ được khám lâm sàng và thực hiện các xét nghiệm, chụp chiếu như:
  * Điện tâm đồ để kiểm tra nhịp tim để xác định có sự chênh lên của đoạn ST hay không, tìm kiếm những bất thường có thể xảy ra trong hội chứng cấp tính này
  * Xét nghiệm men tim nhằm tìm kiếm tổn thương cơ tim
  * Chụp mạch vành nếu bệnh nhân đau ngực dai dẳng, hạ huyết áp, men tim tăng rõ rệt, loạn nhịp,…


Việc thực hiện chụp mạch ngay lập tức hay trì hoãn còn tùy thuộc vào mức độ biểu hiện các triệu chứng.
**_3.2 Điều trị hội chứng mạch vành cấp_**
Sau khi chẩn đoán, các bác sĩ sẽ quyết định phương pháp điều trị phù hợp. Các biện pháp điều trị bao gồm:
  * Điều trị bằng thuốc: Các loại thuốc thường sử dụng thường là thuốc chống ngưng tiểu cầu, thuốc giãn mạch nhằm giảm đau thắt ngực, thuốc chống đông và một số loại thuốc khác. Tùy trong từng trường hợp (nguyên nhân, mức độ bệnh, thể trạng của bệnh nhân,…) mà các bác sĩ sẽ chỉ định loại thuốc và cách sử dụng phù hợp.
  * Điều trị tái tưới máu mạch vành: Các phương pháp gồm sử dụng thuốc tiêu sợi huyết, các can thiệp vào mạch vành trong trường hợp cần thiết theo chỉ định.
  * Chăm sóc và phục hồi chức năng sau xuất viện: Sau khi xuất viện, bệnh nhân có thể cần duy trì uống một số loại thuốc nhằm kiểm soát tình trạng huyết áp, cholesterol máu. Một số bệnh nhân có di chứng sau biến cố cần thực hiện các bài tập phục hồi để khôi phục lại chức năng của tim và cơ thể.


**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/) **- Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [1. Hội chứng mạch vành cấp là gì?](https://bvnguyentriphuong.com.vn/noi-tim-mach/tong-quan-ve-hoi-chung-mach-vanh-cap#1-hi-chng-mch-vnh-cp-l-g)
  * [1.2 Nhồi máu cơ tim](https://bvnguyentriphuong.com.vn/noi-tim-mach/tong-quan-ve-hoi-chung-mach-vanh-cap#12-nhi-mu-c-tim)
  * [2. Các yếu tố nguy cơ của hội chứng mạch vành](https://bvnguyentriphuong.com.vn/noi-tim-mach/tong-quan-ve-hoi-chung-mach-vanh-cap#2-cc-yu-t-nguy-c-ca-hi-chng-mch-vnh)
  * [3. Chẩn đoán và điều trị hội chứng tắc nghẽn mạch vành cấp tính](https://bvnguyentriphuong.com.vn/noi-tim-mach/tong-quan-ve-hoi-chung-mach-vanh-cap#3-chn-on-v-iu-tr-hi-chng-tc-nghn-mch-vnh-cp-tnh)
  * [3.1 Chẩn đoán hội chứng mạch vành cấp](https://bvnguyentriphuong.com.vn/noi-tim-mach/tong-quan-ve-hoi-chung-mach-vanh-cap#31-chn-on-hi-chng-mch-vnh-cp)



## Tắc động mạch vành nguy hiểm như thế nào?

  * [1. Tắc động mạch vành có phải bệnh nguy hiểm không?](https://bvnguyentriphuong.com.vn/noi-tim-mach/tac-dong-mach-vanh-nguy-hiem-nhu-the-nao#1-tc-ng-mch-vnh-c-phi-bnh-nguy-him-khng)
  * [2. Nguyên nhân chính gây tắc nghẽn động mạch vành](https://bvnguyentriphuong.com.vn/noi-tim-mach/tac-dong-mach-vanh-nguy-hiem-nhu-the-nao#2-nguyn-nhn-chnh-gy-tc-nghn-ng-mch-vnh)
  * [2.1. Nhóm nguyên nhân không thể thay đổi được](https://bvnguyentriphuong.com.vn/noi-tim-mach/tac-dong-mach-vanh-nguy-hiem-nhu-the-nao#21-nhm-nguyn-nhn-khng-th-thay-i-c)
  * [2.2. Nhóm nguyên nhân có thể thay đổi được](https://bvnguyentriphuong.com.vn/noi-tim-mach/tac-dong-mach-vanh-nguy-hiem-nhu-the-nao#22-nhm-nguyn-nhn-c-th-thay-i-c)
  * [3. Dấu hiệu cảnh báo nguy cơ tắc mạch vành tim](https://bvnguyentriphuong.com.vn/noi-tim-mach/tac-dong-mach-vanh-nguy-hiem-nhu-the-nao#3-du-hiu-cnh-bo-nguy-c-tc-mch-vnh-tim)
  * [3.1. Đau thắt ngực do tắc động mạch vành](https://bvnguyentriphuong.com.vn/noi-tim-mach/tac-dong-mach-vanh-nguy-hiem-nhu-the-nao#31-au-tht-ngc-dotc-ng-mch-vnh)
  * [3.2. Đau vùng tim do tắc động mạch vành](https://bvnguyentriphuong.com.vn/noi-tim-mach/tac-dong-mach-vanh-nguy-hiem-nhu-the-nao#32-au-vng-tim-dotc-ng-mch-vnh)
  * [3.3. Các triệu chứng khác](https://bvnguyentriphuong.com.vn/noi-tim-mach/tac-dong-mach-vanh-nguy-hiem-nhu-the-nao#33-cc-triu-chng-khc)
  * [4. Tắc động mạch vành có điều trị được không?](https://bvnguyentriphuong.com.vn/noi-tim-mach/tac-dong-mach-vanh-nguy-hiem-nhu-the-nao#4-tc-ng-mch-vnh-c-iu-tr-c-khng)
  * [5. Cách phòng tránh tắc nghẽn động mạch vành hiệu quả](https://bvnguyentriphuong.com.vn/noi-tim-mach/tac-dong-mach-vanh-nguy-hiem-nhu-the-nao#5-cch-phng-trnh-tc-nghn-ng-mch-vnh-hiu-qu)


Để trái tim hoạt động bình thường, các động mạch vành cần phải cung cấp lượng máu đầy đủ đến cơ tim. Nhưng khi tắc động mạch vành xảy ra, quá trình này gặp khó khăn, ngưng trệ thì sẽ gây ra những bất thường cho hệ tim mạch và hệ lụy đối với toàn cơ thể. Cùng tìm hiểu về tình trạng tắc nghẽn mạch vành gây nguy hiểm như thế nào nhé.
## **1. Tắc động mạch vành có phải bệnh nguy hiểm không?**
Đông mạch vành gồm động mạch mũ, động mạch liên thất trước và động mạch vành phải. Đây là hệ thống động mạch duy nhất cho cơ tim. Muốn trái tim hoạt động bình thường, động mạch vành cần mang đủ số lượng máu giàu oxy đến cơ tim.
Khi mạch vành bị tắc nghẽn một phần hoặc cục bộ sẽ làm giảm lượng máu đến cơ tim. Nếu lúc đó bạn đang hoạt động thể lực, cơ thể cần nhiều oxy, cơ tim tăng co bóp, tăng huyết áp…mà không đáp ứng được, lượng máu cung cấp giảm sẽ gây đau thắt ngực. Tình trạng này có thể tái phát nhiều lần, gây ảnh hưởng tới cuộc sống người bệnh.
Không chỉ vậy, **tắc động mạch vành** có thể dẫn đến đột tử hoặc những biến chứng dễ gây tử vong như: sốc tim, loạn nhịp thất, suy tim trái cấp.
Trong trường hợp mạch vành bị tắc hẹp do mảng xơ vữa, sau đó những mảng này vỡ ra có thể gây co thắt ngực, nhồi máu cơ tim, đột quỵ.
Vì vậy, những người có nguy cơ cao mắc các bệnh tim mạch cần đề phòng, kiểm tra sức khỏe định kỳ để phát hiện sớm và điều trị kịp thời, tránh biến chứng nguy hiểm.
_Quá trình sinh sống tạo ra rất nhiều yếu tố nguy cơ gây tắc nghẽn động mạch vành._
## **2. Nguyên nhân chính gây tắc nghẽn động mạch vành**
Quá trình sống tạo ra rất nhiều yếu tố nguy cơ gây tắc mạch vành. Các bác sĩ chia nguyên nhân gây bệnh làm hai nhóm chủ yếu: nhóm nguy cơ không thể thay đổi và có thể thay đổi được như sau.
### _**2.1. Nhóm nguyên nhân không thể thay đổi được**_
Bệnh mạch vành thường có nguy cơ xảy ra cao hơn ở một số đối tượng như:
  * Tuổi cao: Đặc biệt ở độ tuổi nữ trên 55 và nam giới trên 50. Tuổi cao khiến hoạt động của mạch vành tim kém linh hoạt, xuất hiện nhiều mảng xơ vữa tại đây gây cản trở dòng máu vào tim.
  * Giới tính: Tắc mạch vành tim hay xảy ra ở nam giới hơn nữ giới. Nguyên nhân là do nam giới hay có thói quen lạm dụng rượu bia, thuốc lá, sinh hoạt kém điều độ hơn. Tuy nhiên, nữ giới sau mãn kinh lại có nguy cơ mắc bệnh cao hơn ở nam giới.
  * Tiền sử gia đình: Nếu gia đình có người thân mắc bệnh tim mạch sẽ gia tăng nguy cơ mắc bệnh.
  * Mắc bệnh lý nền như huyết áp cao, béo phì, rối loạn mỡ máu, đái tháo đường…Ở nhóm đối tượng này bệnh hẹp mạch vành rất dễ xảy ra.


### 2.2. Nhóm nguyên nhân có thể thay đổi được
Lối sống, ăn uống, làm việc, nghỉ ngơi của chúng ta cũng đem đến nhiều yếu tố nguy cơ gây bệnh.
  * Ít vận động: Những người thường xuyên ngồi một chỗ, ít hoạt động thể chất, ít di chuyển sẽ có nguy cơ mắc bệnh tim mạch cao hơn.
  * Lạm dụng rượu bia: Rượu bia là một nguyên nhân gây thiếu máu cục bộ cơ tim và đau thắt ngực.
  * Hút thuốc lá: Thói quen này không chỉ tăng nguy cơ bệnh tim mạch mà còn ảnh hưởng đến nhiều bộ phận khác trong cơ thể như phổi, vòm họng…


_Những cơn đau vùng tim và đau thắt vùng ngực là dấu hiệu sớm cảnh báo nguy cơ tắc động mạch vành._
Trong đó, điều chỉnh nhóm nguy cơ có thể thay đổi góp phần quan trọng vào việc làm giảm sự phát triển và tính nguy hiểm của hiện tượng tắc nghẽn động mạch vành.
## **3. Dấu hiệu cảnh báo nguy cơ tắc mạch vành tim**
Hai dấu hiệu sớm cảnh báo nguy cơ tắc nghẽn động mạch vành là những cơn đau vùng tim và đau thắt vùng ngực.
### **_3.1. Đau thắt ngực do tắc động mạch vành_**
Đau ngực được chia thành hai loại:
  * Đau thắt ngực ổn định xảy ra do xơ vữa động mạch vành, khiến lòng động mạch hẹp lại, máu lưu thông qua đây bị cản trở. Khi người bệnh gắng sức sẽ xuất hiện cơn đau thắt ngực, tình trạng có thể tái phát nhiều lần. Nếu được phát hiện sớm và thực hiện các biện pháp thay đổi lối sống thì người bệnh sẽ gặp nguy hiểm lớn. Tuy nhiên nếu phát hiện muộn, bệnh có thể phát triển thành dạng đau thắt ngực không ổn định.
  * Đau thắt ngực không ổn định xảy ra cả khi bệnh nhân nghỉ ngơi hoặc khi ngừng gắng sức. Những cơn đau như vậy nếu không được phát hiện và xử trí kịp thời sẽ dễ chuyển thành nhồi máu cơ tim. Đây là tình trạng cấp tính nguy hiểm có thể cướp đi tính mạng của bệnh nhân trong thời gian rất ngắn.


### **_3.2. Đau vùng tim do tắc động mạch vành_**
Những cơn đau tim do hẹp động mạch vành thường có biểu hiện như:
  * Cảm giác tim bị chèn ép
  * Đau ran và nóng rát vùng ngực
  * Tê vùng ngực tim
  * Cảm giác như tim bị bóp nghẹt
  * Đau vùng ngực âm ỉ


### **_3.3. Các triệu chứng khác_**
Trong cơn đau bệnh nhân có thể kèm vã mồ hôi, mệt mỏi, buồn nôn, khó thở. Ngoài ra, người bị bệnh mạch vành có thể gặp các hiện tượng khác như:
  * Đánh trống ngực
  * Rối loạn nhịp tim
  * Chóng mặt đau đầu
  * Choáng váng, loạng choạng


Ngoài các triệu chứng nói trên, bệnh nhân có thể gặp cả những dấu hiệu khác hoặc không gặp triệu chứng điển hình nào. Vì vậy rất nhiều người chủ quan, cho rằng đó chỉ là vấn đề sức khỏe không đáng lo ngại.
_Bệnh có thể dẫn đến đột tử hoặc những biến chứng dễ gây tử vong như: sốc tim, loạn nhịp thất, suy tim trái cấp._
## **4. Tắc động mạch vành có điều trị được không?**
Hiện nay bệnh mạch vành được điều trị chủ yếu bằng phương pháp nội khoa. Tùy thuộc tình trạng bệnh mà bác sĩ sẽ chỉ định một hoặc nhiều loại thuốc phối hợp: thuốc chẹn kênh calci, thuốc chống kết vón tiểu cầu, thuốc ức chế thụ thể beta, thuốc hạ cholesterol máu, nhóm Fibrat… Việc sử dụng thuốc nào, liều lượng ra sao phải được các bác sĩ chỉ định sau khi thăm khám lâm sàng và cận lâm sàng. Như vậy mới cho hiệu quả tối ưu và tránh những tác dụng phụ không mong muốn hoặc ảnh hưởng đến các bệnh lý đi kèm.
Nếu bệnh tình nặng hơn, bệnh đã gây ra biến chứng hoặc điều trị nội khoa không đáp ứng thì các phương pháp khác sẽ được đề nghị nhằm tái tưới máu mạch vành, cải thiện lượng máu nuôi dưỡng cơ tim.
Một điều rất quan trọng nhất trong điều trị hẹp động mạch vành là bệnh nhân có ý thức tự loại bỏ các yếu tố nguy cơ như hút thuốc, uống rượu bia, béo phì, huyết áp cao, tiểu đường… để tránh khiến bệnh tăng nặng, hạn chế việc phải dùng đến các biến pháp can thiệp khác.
## **5. Cách phòng tránh tắc nghẽn động mạch vành hiệu quả**
Vì đây là một căn bệnh nguy hiểm nên mỗi chúng ta cần chủ động phòng bệnh tiên phát nghĩa là dự phòng không để bệnh xảy ra và dự phòng thứ phát để bệnh không tiến triển. Dù áp dụng cách phòng tránh nào chúng ta đều cân:
Thay đổi thói quen sống lành mạnh: Bỏ hút thuốc, ngủ đủ giấc, hạn chế căng thẳng.
  * Tập thể dục thường xuyên cho máu lưu thông, tránh tăng cân, béo phì.
  * Hạn chế ăn muối, đồ ăn nhanh, đồ dầu mỡ, ngũ tạng động vật, đồ ngọt, nước có gas…
  * Ăn nhiều rau xanh, trái cây, thịt cá giàu omega-3 tốt cho tim, ít cholesterol.
  * Kiểm tra sức khỏe định kỳ.
  * Điều trị tích cực bệnh lý nguy cơ cho mạch vành tim như huyết áp cao, rối loạn lipid máu, tiểu đường, béo phì…
  * Tuyệt đối tuân thủ hướng dẫn điều trị của bác sĩ để tránh bệnh mạch vành tái phát.


**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/) **- Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [1. Tắc động mạch vành có phải bệnh nguy hiểm không?](https://bvnguyentriphuong.com.vn/noi-tim-mach/tac-dong-mach-vanh-nguy-hiem-nhu-the-nao#1-tc-ng-mch-vnh-c-phi-bnh-nguy-him-khng)
  * [2. Nguyên nhân chính gây tắc nghẽn động mạch vành](https://bvnguyentriphuong.com.vn/noi-tim-mach/tac-dong-mach-vanh-nguy-hiem-nhu-the-nao#2-nguyn-nhn-chnh-gy-tc-nghn-ng-mch-vnh)
  * [2.1. Nhóm nguyên nhân không thể thay đổi được](https://bvnguyentriphuong.com.vn/noi-tim-mach/tac-dong-mach-vanh-nguy-hiem-nhu-the-nao#21-nhm-nguyn-nhn-khng-th-thay-i-c)
  * [2.2. Nhóm nguyên nhân có thể thay đổi được](https://bvnguyentriphuong.com.vn/noi-tim-mach/tac-dong-mach-vanh-nguy-hiem-nhu-the-nao#22-nhm-nguyn-nhn-c-th-thay-i-c)
  * [3. Dấu hiệu cảnh báo nguy cơ tắc mạch vành tim](https://bvnguyentriphuong.com.vn/noi-tim-mach/tac-dong-mach-vanh-nguy-hiem-nhu-the-nao#3-du-hiu-cnh-bo-nguy-c-tc-mch-vnh-tim)
  * [3.1. Đau thắt ngực do tắc động mạch vành](https://bvnguyentriphuong.com.vn/noi-tim-mach/tac-dong-mach-vanh-nguy-hiem-nhu-the-nao#31-au-tht-ngc-dotc-ng-mch-vnh)
  * [3.2. Đau vùng tim do tắc động mạch vành](https://bvnguyentriphuong.com.vn/noi-tim-mach/tac-dong-mach-vanh-nguy-hiem-nhu-the-nao#32-au-vng-tim-dotc-ng-mch-vnh)
  * [3.3. Các triệu chứng khác](https://bvnguyentriphuong.com.vn/noi-tim-mach/tac-dong-mach-vanh-nguy-hiem-nhu-the-nao#33-cc-triu-chng-khc)
  * [4. Tắc động mạch vành có điều trị được không?](https://bvnguyentriphuong.com.vn/noi-tim-mach/tac-dong-mach-vanh-nguy-hiem-nhu-the-nao#4-tc-ng-mch-vnh-c-iu-tr-c-khng)
  * [5. Cách phòng tránh tắc nghẽn động mạch vành hiệu quả](https://bvnguyentriphuong.com.vn/noi-tim-mach/tac-dong-mach-vanh-nguy-hiem-nhu-the-nao#5-cch-phng-trnh-tc-nghn-ng-mch-vnh-hiu-qu)



## Triệu chứng xơ vữa động mạch là gì?

  * [Triệu chứng xơ vữa động mạch là gì?](https://bvnguyentriphuong.com.vn/noi-tim-mach/trieu-chung-xo-vua-dong-mach-la-gi#triu-chng-x-va-ng-mch-l-g)
  * [Nguyên nhân hình thành mảng xơ vữa là gì?](https://bvnguyentriphuong.com.vn/noi-tim-mach/trieu-chung-xo-vua-dong-mach-la-gi#nguyn-nhn-hnh-thnh-mng-x-va-l-g)
  * [Phòng ngừa hình thành mảng xơ vữa động mạch bằng cách nào?](https://bvnguyentriphuong.com.vn/noi-tim-mach/trieu-chung-xo-vua-dong-mach-la-gi#phng-nga-hnh-thnh-mng-x-va-ng-mch-bng-cch-no)


**Xơ vữa động mạch là nguyên nhân gây nên nhiều biến chứng nguy hiểm đe dọa tính mạng người bệnh. Vì vậy người bệnh cần phát hiện sớm triệu chứng xơ vữa động mạch là gì để chẩn đoán và điều trị hiệu quả.**
### **Triệu chứng xơ vữa động mạch là gì?**
Bệnh xơ vữa động mạch không xuất hiện ngay lập tức khi ở giai đoạn nhẹ thông thường khi bệnh tiến triển gây ách tắc mạch máu, người bệnh mới xuất hiện triệu chứng. Các triệu chứng xơ vữa động mạch từ trung bình cho đến nghiêm trọng tùy thuộc vào động mạch bị ảnh hưởng, bao gồm:
Nếu mảng xơ vữa ở động mạch tim, bạn có thể có các triệu chứng như đau ngực hoặc thắt ngực;
_Xơ vữa động mạch có thể gây nên các triệu chứng đau thắt ngực thiếu máu cơ tim,…_
Nếu mảng xơ vữa ở động mạch cung cấp máu cho não, bạn có thể có các dấu hiệu và triệu chứng như tê đột ngột hoặc yếu ở tay hoặc chân, khó nói hoặc nói lắp, mất thị lực tạm thời ở một mắt hoặc cơ mặt bị rủ xuống. Những dấu hiệu của cơn thiếu máu thoáng qua, nếu không được điều trị, có thể diễn tiến thành một cơn đột quỵ;
Nếu mảng xơ vữa động mạch ở động mạch cánh tay và chân, bạn có thể có các triệu chứng của bệnh động mạch ngoại vi như đau chân khi đi bộ;
Nếu mảng xơ vữa ở động mạch thận, bạn sẽ bị cao huyết áp hoặc suy thận.
### **Nguyên nhân hình thành mảng xơ vữa là gì?**
Các nguyên nhân dẫn đến sự hình thành mảng xơ vữa bao gồm:
  * _Cholesterol cao_. Cholesterol là một chất sáp, màu vàng được tìm thấy trong cơ thể và trong các loại thực phẩm. Chất này có thể tăng trong máu và làm tắc nghẽn các động mạch, trở thành một mảng xơ cứng làm hạn chế hoặc làm tắc nghẽn khiến cho máu không thể lưu thông đến tim và các cơ quan khác;
  * _Chất béo_. Ăn nhiều thực phẩm có chất béo cũng có thể dẫn đến hình thành mảng xơ vữa;
  * _Lớn tuổi_. Khi bạn có tuổi, tim và mạch máu làm việc nhiều hơn để bơm và nhận máu. Động mạch có thể bị suy yếu và trở nên kém đàn hồi, từ đó dễ hình thành mảng xơ vữa.


### **Phòng ngừa hình thành mảng xơ vữa động mạch bằng cách nào?**
Các phương pháp phòng ngừa chính bao gồm:
– Bỏ hút thuốc lá
– Duy trì nồng độ cholesterol trong máu ở mức thích hợp bằng cách áp dụng chế độ ăn uống lành mạnh, tập thể dục.
– Duy trì huyết áp ở mức an toàn
– Sử dụng các loại thuốc theo chỉ định của bác sĩ.
– Kiểm soát và giảm thiểu các yếu tố nguy cơ như đường huyết, lipid máu, huyết áp ở mức mục tiêu bằng thuốc điều trị, chế độ ăn uống và thực hiện các hoạt động thể dục thể thao nhằm làm chậm hoặc ngăn chặn sự tích tụ của các mảng xơ vữa.
**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/) **- Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [Triệu chứng xơ vữa động mạch là gì?](https://bvnguyentriphuong.com.vn/noi-tim-mach/trieu-chung-xo-vua-dong-mach-la-gi#triu-chng-x-va-ng-mch-l-g)
  * [Nguyên nhân hình thành mảng xơ vữa là gì?](https://bvnguyentriphuong.com.vn/noi-tim-mach/trieu-chung-xo-vua-dong-mach-la-gi#nguyn-nhn-hnh-thnh-mng-x-va-l-g)
  * [Phòng ngừa hình thành mảng xơ vữa động mạch bằng cách nào?](https://bvnguyentriphuong.com.vn/noi-tim-mach/trieu-chung-xo-vua-dong-mach-la-gi#phng-nga-hnh-thnh-mng-x-va-ng-mch-bng-cch-no)



## Phiếu tóm tắt thông tin điều trị các bệnh lý Tim mạch can thiệp

**1. Phiếu tóm tắt thông tin điều trị là gì?**
Phiếu tóm tắt thông tin điều trị giúp cho người bệnh theo dõi và cùng tham gia vào quá trình điều trị với bác sĩ và nhân viên y tế 
Phiếu tóm tắt thông tin điều trị được xây dựng cho một bệnh xác định. Thiết kế theo dạng tờ rơi trên 1 tờ giấy khổ A4 hoặc A5 (1 trang hoặc 2 trang). Các thông tin chính được rút ra từ hướng dẫn chẩn đoán và điều trị của bệnh viện. Nội dung bao gồm:
  * Các triệu chứng lâm sàng;
  * Xét nghiệm CLS;
  * Chẩn đoán;
  * Phương pháp điều trị;
  * Biến chứng;
  * Điều trị biến chứng và Hướng dẫn chăm sóc, cách dùng thuốc, dinh dưỡng, sinh hoạt;
  * Phòng ngừa;
  * Truyền thông giáo dục sức khỏe. 


**2. Sử dụng phiếu tóm tắt thông tin như thế nào?**
Thông qua phiếu tóm tắt thông tin điều trị Người bệnh có thể biết được và tự theo dõi được quá trình điều trị bằng cách đánh dấu vào danh mục (hoặc bảng kiểm). Dựa trên các mục đã được đánh dấu, người bệnh có thể biết được các hoạt động thăm khám, xét nghiệm, chẩn đoán hình ảnh, nội soi, thăm dò chức năng, thủ thuật, phẫu thuật, phương pháp điều trị, loại thuốc điều trị... đã thực hiện hoặc dự kiến thực hiện. Từ việc theo dõi này, người bệnh có thể hỏi nhân viên y tế lý do chưa nhận được dịch vụ y tế trong phiếu tóm tắt và tiến trình điều trị đang đến giai đoạn nào.
Phiếu có thể tích hợp thêm các hướng dẫn, khuyến cáo tóm tắt về chế độ dinh dưỡng, phòng tránh tái phát, biến chứng của bệnh và các vấn đề cần lưu ý khác, giúp việc điều trị, chăm sóc hiệu quả hơn.
**[Phiếu tóm tắt thông tin điều trị Bệnh lý Nhồi máu cơ tim cấp có đoan Stent chênh lên - Stemi](https://bvnguyentriphuong.com.vn/uploads/072022/files/6_%20NH%E1%BB%92I%20M%C3%81U%20C%C6%A0%20TIM%20C%E1%BA%A4P%20C%C3%93%20%C4%90O%E1%BA%A0N%20ST%20CH%C3%8ANH%20L%C3%8AN-%20STEMI.pdf)
#### Nội dung trong file:

BỆNH VIỆN NGUYỄN TRI PHƯƠNG 
KHOA TIM MẠCH CAN THIỆP PHIẾU TÓM TẮT 
THÔNG TIN ĐIỀU TRỊ  
NHỒI MÁU CƠ TIM CẤP CÓ ĐOẠN ST CHÊNH LÊN 
STEMI là gì? Nhồi máu cơ tim cấp có đoạn ST chênh lên là do tắc đột ngột 
hoàn toàn một trong các động mạch vành (mạch máu nuôi tim) 
lớn kéo dài (thường > 30 phút) dẫn đến chết (hoại tử) vùng cơ tim 
mà nó nuôi dưỡng. 
Nguyên nhân gây 
STEMI Nguyên nhân chính gây tắc động mạch vành thường do các 
mảng xơ vữa hình thành sẵn từ trước đó trong thành mạch bị 
nứt, vỡ dẫn đến hình thành huyết khối (cục máu đông) tại chỗ 
gây tắc nghẽn lòng động mạch. 
Những yếu tố nguy 
cơ của STEMI Lớn tuổi (Nam > 45 tuổi, Nữ > 55 tuổi); Hút thuốc lá, thuốc lào; 
Cao huyết áp; Bệnh tiểu đường; Bệnh thận mãn tính; Tăng 
cholesterol trong máu; Thừa cân, béo phì; Lối sống tĩnh tại ít 
hoạt động thể lực; Chế độ ăn nhiều chất béo, mỡ bão hòa... 
Biểu hiện thường 
gặp của STEMI Biểu hiện thường gặp là cơn đau thắt ngực cấp tính: đau ngực sau 
xương ức hay ngực trái; có thể lan lên cổ, vai, tay trái hoặc lưng 
trên; thường xuất hiện khi nghỉ ngơi hoặc gắng sức rất nhẹ; cảm 
giác nghẹn, thắt chặt hay đè ép; cơn đau thường kéo dài hơn 30 
phút; không giảm khi nghỉ ngơi hay ngậm dưới lưỡi bằng thuốc 
dãn mạch Nitroglycerin. Thường có các triệu chứng đi kèm như 
vã mồ hôi, khó thở, buồn nôn. Một số trường hợp nặng, người 
bệnh có thể bị tụt huyết áp, đột tử. 
Khoảng 1/4 bệnh nhân nhồi máu cơ tim lại hoàn toàn không đau 
ngực mà chỉ biểu hiện mệt, khó thở, đau bụng vùng trên rốn, đột 
ngột lú lẫn, ngất xỉu hoặt tụt huyết áp. Những bệnh nhân này 
thường gặp ở nữ giới, người bệnh tiểu đường, bệnh nhân suy 
thận, người cao tuổi...  
Biến chứng của 
STEMI Suy tim nặng hoặc sốc tim 
Rối loạn nhịp, có thể dẫn đến đột tử. 
Hở van 2 lá nặng do đứt dây chằng lá van. 
Thủng cơ tim ở vách liên thất gây thông nối thất trái và thất phải. 
Thủng vách tim ở thành tự do gây tràn máu màng tim hoặc vỡ 
tim. 
Các xét nghiệm 
cần làm - Điện tâm đồ, Troponin  
- Sinh hóa máu: Huyết đồ, glucose, creatinin, AST/ALT, Bilan 
lipid máu, NT-proBNP, Điện giải đố, Tổng phân tích nước 
tiểu. 
- XQ ngực, Siêu âm tim…  
Hướng điều trị 
STEMI Điều trị cấp cứu: 
- Ổn định sinh hiệu: tuần hoàn, hô hấp, huyết áp, đường máu 
- Chống huyết khối: kháng đông, kháng kết tập tiểu cầu 
- Tái thông động mạch vành: thuốc TSH, can thiệp đặt stent 
mạch vành (PCI), phẩu thuật bắc cầu nối mạch vành (CABG). 
- Điều trị nâng đỡ: giảm đau, dinh dưỡng… 
Điều trị ngay sau can thiệp:  
- Rút sheath/băng ép, theo dõi biến chứng (huyết khối, chảy 
máu, nhiễm trùng, suy thận, dị ứng thuốc, rối loạn nhịp, suy 
tim…), tối ưu hóa điều trị nội khoa, dinh dưỡng, phục hồi chức 
năng tim mạch…  
Chế độ theo dõi và 
phòng ngừa Bệnh nhân sau nhồi máu cơ tim cần được điều trị và chăm sóc lâu 
dài để tránh tái phát và biến chứng về sau: 
- Thay đổi lối sống là điều cần làm xuyên suốt quá trình điều 
trị: 
Tập thể dục đều đặn, giảm cân nếu dư cân hoặc béo phì. 
Không hút thuốc lá, hạn chế rượu bia, nước ngọt. 
Không nên ăn mặn, giảm ăn thịt mỡ, thức ăn đóng hộp, thức 
ăn nhanh, đồ ăn chiên xào… 
Nên ăn nhiều trái cây, rau, củ, quả, hạt; ăn cá hoặc thịt gà thay 
cho thịt heo, thịt bò… 
Tránh stress, luyện tập thư giãn. 
- Người bệnh cần uống thuốc và tái khám thường xuyên: 
Các thuốc điều trị thiết yếu: Thuốc ức chế men chuyển hoặc 
chẹn thụ thể angiotensin 2, chẹn bêta, chống kết tập tiểu cầu 
(aspirin, clopidogrel, ticagrelor, prasugrel), statin, 
spironolactone. 
Bệnh nhân sau nhồi máu cơ tim cần uống 2 loại thuốc chống 
kết tập tiểu cầu trong vòng 1 năm nếu không có nguy cơ chảy 
máu cao. 
Bệnh nhân sau phẫu thuật bắc cầu hoặc đặt stent mạch vành 
cần uống thuốc chống kết tập tiểu cầu lâu dài để phòng ngừa 
huyết khối trong stent hoặc tái hẹp mạch vành. 
Điều trị tích cực các bệnh đi kèm như: Tăng huyết áp, đái tháo 
đường, rối loạn mỡ máu…**
**[Phiếu tóm tắt thông tin điều trị Bệnh lý Nhồi máu cơ tim cấp Stent không chênh lên - NStemi](https://bvnguyentriphuong.com.vn/uploads/072022/files/7_%20NH%E1%BB%92I%20M%C3%81U%20C%C6%A0%20TIM%20C%E1%BA%A4P%20ST%20KH%C3%94NG%20CH%C3%8ANH%20L%C3%8AN-%20NSTEMI.pdf)
#### Nội dung trong file:

BỆNH VIỆN NGUYỄN TRI PHƯƠNG 
KHOA TIM MẠCH CAN THIỆP PHIẾU TÓM TẮT 
THÔNG TIN ĐIỀU TRỊ  
NHỒI MÁU CƠ TIM CẤP ĐOẠN ST KHÔNG CHÊNH LÊN- NSTEMI 
NSTEMI là gì? Nhồi máu cơ tim cấp đoạn ST không chênh lên là do tắc đột ngột 
không hoàn toàn một trong các động mạch vành (mạch máu nuôi 
tim) kéo dài dẫn đến chết (hoại tử) một phần vùng cơ tim mà nó 
nuôi dưỡng. 
Nguyên nhân gây 
bệnh Nguyên nhân chính gây tắc động mạch vành thường do các 
mảng xơ vữa hình thành sẵn từ trước đó trong thành mạch bị 
nứt, vỡ dẫn đến hình thành huyết khối (cục máu đông) tại chỗ 
gây tắc nghẽn lòng động mạch. 
Những yếu tố nguy 
cơ của bệnh Lớn tuổi (Nam > 45 tuổi, Nữ > 55 tuổi); Hút thuốc lá, thuốc lào; 
Cao huyết áp; Bệnh tiểu đường; Bệnh thận mãn tính; Tăng 
cholesterol trong máu; Thừa cân, béo phì; Lối sống tĩnh tại ít 
hoạt động thể lực; Chế độ ăn nhiều chất béo, mỡ bão hòa... 
Biểu hiện thường 
gặp của bệnh Biểu hiện thường gặp của NSTEMI là cơn đau thắt ngực cấp tính: 
đau ngực sau xương ức hay ngực trái; có thể lan lên cổ, vai, tay 
trái hoặc lưng trên; thường xuất hiện khi nghỉ ngơi hoặc gắng sức 
rất nhẹ; cảm giác nghẹn, thắt chặt hay đè ép; cơn đau thường kéo 
dài hơn 20 phút; không giảm khi nghỉ ngơi hay ngậm dưới lưỡi 
bằng thuốc dãn mạch Nitroglycerin. Thường có các triệu chứng 
đi kèm như vã mồ hôi, khó thở, buồn nôn. Một số trường hợp 
nặng, người bệnh có thể bị tụt huyết áp, đột tử. 
Khoảng 1/4 bệnh nhân nhồi máu cơ tim lại hoàn toàn không đau 
ngực mà chỉ biểu hiện mệt, khó thở, đau bụng vùng trên rốn, đột 
ngột lú lẫn, ngất xỉu hoặt tụt huyết áp. Những bệnh nhân này 
thường gặp ở nữ giới, người bệnh tiểu đường, bệnh nhân suy 
thận, người cao tuổi...  
Biến chứng của bệnh Suy tim nặng hoặc sốc tim: Người bệnh khó thở, huyết áp thấp 
cần được hỗ trợ máy thở, thuốc vận mạch, dụng cụ hỗ trợ tim 
(bóng đối xung động mạch chủ),… 
Rối loạn nhịp, có thể dẫn đến đột tử 
Hở van 2 lá nặng do đứt dây chằng lá van 
Thủng cơ tim ở vách liên thất gây thông nối thất trái và thất phải 
Thủng vách tim ở thành tự do gây tràn máu màng tim hoặc vỡ 
tim. 
Các xét nghiệm 
cần làm - Điện tâm đồ, Troponin  
- Sinh hóa máu: Huyết đồ, glucose, creatinin, AST/ALT, Bilan 
lipid máu, NT-proBNP, Điện giải đố, Tổng phân tích nước 
tiểu. 
- XQ ngực, Siêu âm tim…  
Hướng điều trị bệnh Điều trị cấp cứu: 
- Ổn định sinh hiệu: tuần hoàn, hô hấp, huyết áp, đường máu 
- Chống huyết khối: kháng đông, kháng kết tập tiểu cầu 
- Tái thông động mạch vành: can thiệp đặt stent mạch vành 
(PCI), phẩu thuật bắc cầu nối mạch vành ( CABG). 
- Điều trị nâng đỡ: giảm đau, dinh dưỡng… 
Điều trị ngay sau can thiệp:  
- Rút sheath/băng ép, theo dõi biến chứng (huyết khối, chảy 
máu, nhiễm trùng, suy thận, dị ứng thuốc, rối loạn nhịp, suy 
tim…), tối ưu hóa điều trị nội khoa, dinh dưỡng, phục hồi chức 
năng tim mạch…  
Chế độ theo dõi và 
phòng ngừa Bệnh nhân sau nhồi máu cơ tim cần được điều trị và chăm sóc lâu 
dài để tránh tái phát và biến chứng về sau: 
- Thay đổi lối sống là điều cần làm xuyên suốt quá trình điều 
trị: 
Tập thể dục đều đặn, giảm cân nếu dư cân hoặc béo phì. 
Không hút thuốc lá, hạn chế rượu bia, nước ngọt. 
Không nên ăn mặn, giảm ăn thịt mỡ, thức ăn đóng hộp, thức 
ăn nhanh, đồ ăn chiên xào… 
Nên ăn nhiều trái cây, rau, củ, quả, hạt; ăn cá hoặc thịt gà thay 
cho thịt heo, thịt bò… 
Tránh stress, luyện tập thư giãn. 
- Người bệnh cần uống thuốc và tái khám thường xuyên: 
Các thuốc điều trị thiết yếu: Thuốc ức chế men chuyển hoặc 
chẹn thụ thể angiotensin 2, chẹn bêta, chống kết tập tiểu cầu 
(aspirin, clopidogrel, ticagrelor, prasugrel), statin, 
spironolactone. 
Bệnh nhân sau nhồi máu cơ tim cần uống 2 loại thuốc chống 
kết tập tiểu cầu trong vòng 1 năm nếu không có nguy cơ chảy 
máu cao. 
Bệnh nhân sau phẫu thuật bắc cầu hoặc đặt stent mạch vành 
cần uống thuốc chống kết tập tiểu cầu lâu dài để phòng ngừa 
huyết khối trong stent hoặc tái hẹp mạch vành. 
Điều trị tích cực các bệnh đi kèm như: Tăng huyết áp, đái tháo 
đường, rối loạn mỡ máu…**
**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/) **- Đa khoa Hạng I Thành phố Hồ Chí Minh

## Kiểm soát bệnh động mạch vành cần lưu ý những điều gì?

  * [1. Hiểu bệnh động mạch vành là gì?](https://bvnguyentriphuong.com.vn/noi-tim-mach/kiem-soat-benh-dong-mach-vanh-can-luu-y-nhung-dieu-gi#1-hiu-bnh-ng-mch-vnh-l-g)
  * [2. Nhận biết bệnh mạch vành sớm qua các triệu chứng](https://bvnguyentriphuong.com.vn/noi-tim-mach/kiem-soat-benh-dong-mach-vanh-can-luu-y-nhung-dieu-gi#2-nhn-bit-bnh-mch-vnh-sm-qua-cc-triu-chng)
  * [3. Phòng tránh các nguyên nhân gây bệnh](https://bvnguyentriphuong.com.vn/noi-tim-mach/kiem-soat-benh-dong-mach-vanh-can-luu-y-nhung-dieu-gi#3-phng-trnh-cc-nguyn-nhn-gy-bnh)
  * [3.1. Nguyên nhân khách quan](https://bvnguyentriphuong.com.vn/noi-tim-mach/kiem-soat-benh-dong-mach-vanh-can-luu-y-nhung-dieu-gi#31-nguyn-nhn-khch-quan)
  * [3.2. Nguyên nhân chủ quan gây bệnh động mạch vành](https://bvnguyentriphuong.com.vn/noi-tim-mach/kiem-soat-benh-dong-mach-vanh-can-luu-y-nhung-dieu-gi#32-nguyn-nhn-ch-quan-gy-bnh-ng-mch-vnh)
  * [4. Những nguy hiểm đến từ bệnh mạch vành](https://bvnguyentriphuong.com.vn/noi-tim-mach/kiem-soat-benh-dong-mach-vanh-can-luu-y-nhung-dieu-gi#4-nhng-nguy-him-n-t-bnh-mch-vnh)
  * [4.1. Nhồi máu cơ tim](https://bvnguyentriphuong.com.vn/noi-tim-mach/kiem-soat-benh-dong-mach-vanh-can-luu-y-nhung-dieu-gi#41-nhi-mu-c-tim)
  * [4.3. Suy tim do bệnh động mạch vành](https://bvnguyentriphuong.com.vn/noi-tim-mach/kiem-soat-benh-dong-mach-vanh-can-luu-y-nhung-dieu-gi#43-suy-tim-do-bnh-ng-mch-vnh)
  * [5. Điều trị bệnh mạch vành](https://bvnguyentriphuong.com.vn/noi-tim-mach/kiem-soat-benh-dong-mach-vanh-can-luu-y-nhung-dieu-gi#5-iu-tr-bnh-mch-vnh)
  * [Hiện nay điều trị nội khoa vẫn là phương pháp điều trị bệnh mạch vành chủ yếu. Điều trị bằng thuốc được thực hiện với các mục tiêu:](https://bvnguyentriphuong.com.vn/noi-tim-mach/kiem-soat-benh-dong-mach-vanh-can-luu-y-nhung-dieu-gi#hin-nay-iu-tr-ni-khoa-vn-l-phng-php-iu-tr-bnh-mch-vnh-ch-yu-iu-tr-bng-thuc-c-thc-hin-vi-cc-mc-tiu)
  * [6. Cách phòng ngừa bệnh mạch vành hiệu quả](https://bvnguyentriphuong.com.vn/noi-tim-mach/kiem-soat-benh-dong-mach-vanh-can-luu-y-nhung-dieu-gi#6-cch-phng-nga-bnh-mch-vnh-hiu-qu)


**Bệnh động mạch vành** là bệnh lý nguy hiểm, nguyên nhân hàng đầu gây nhồi máu cơ tim, đột quỵ. Nếu không được phát hiện sớm tỉ lệ tử vong ở người bệnh là rất cao. Do vậy, việc tầm soát và điều trị về bệnh mạch vành có ý nghĩa vô cùng quan trọng. Dưới đây là những lưu ý quan trọng.
## **1. Hiểu bệnh động mạch vành là gì?**
Bệnh động mạch vành là tình trạng động mạch bị thu hẹp, tắc nghẽn do các mảng xơ vỡ bên trong lòng mạch. Sự tích tụ các mảng bám này khiến cho các động mạch vốn mềm mại trở nên xơ cứng, dẫn đến cản trở dòng máu đi qua động mạch. Lượng máu cung cấp cho cơ tim không đủ gây thiếu tình trạng thiếu máu cơ tim hoặc hoại tử cơ tim. 
Đây là bệnh lý tim mạch nguy hiểm, có xu hướng gia tăng mạnh ở Việt Nam, gây tử vong cao nếu không phát hiện sớm.
_Bệnh mạch vành là hiện tượng lòng mạch bị thu hẹp gây tắc nghẽn, giảm lưu thông máu_
## **2. Nhận biết bệnh mạch vành sớm qua các triệu chứng**
Các triệu chứng thường gặp của bệnh mạch vành bao gồm:
  * Đau thắt ngực
  * Hồi hộp, hụt hơi
  * Chóng mặt, hoảng hốt
  * Mệt mỏi, đau ngực kèm theo buồn nôn


Trong đó, cơn đau thắt ngực là dấu hiệu điển hình của bệnh mạch vành. Đây là hậu quả của việc cơ tim không nhận được lượng máu và oxy cần thiết cho hoạt động co bóp của tim. Cơn đau có thể thoáng qua, gây khó thở nhẹ. Nhưng cũng có khi đau bó chặt, thắt nghẹt, đè ép trong lồng ngực khiến ngực trở nên nặng nề, đau rát, nóng ran. Người bệnh có thể xuất hiện cơn đau sau xương ức, tim, giữa ngực. Đôi khi đau có thể lan lên vai, cổ, cánh tay bên trái. 
Thông thường, cơn đau ngực thường chỉ xuất hiện trong vài chục giây hoặc vài phút. Nếu cơn đau kéo dài trên 15 phút, nhiều khả năng người bệnh bị nhồi máu cơ tim, cần đi cấp cứu ngay để được chẩn đoán kịp thời.
Những việc cần làm ngay khi các cơn đau thắt ngực xuất hiện:
  * Nghỉ ngơi ngay lập tức, dừng toàn bộ mọi hoạt động gắng sức, vận động mạnh
  * Dùng thuốc Nitroglycerin dạng ngậm hoặc xịt dưới lưỡi
  * Tới cơ sở y tế uy tín càng sớm càng tốt để chẩn đoán, điều trị.


## **3. Phòng tránh các nguyên nhân gây bệnh**
Có 2 nhóm nguyên nhân chính gây bệnh mạch vành:
### **_3.1. Nguyên nhân khách quan_**
Đó là những yếu tố gây bệnh mà người bệnh không thể thay đổi được, bao gồm:
  * Tuổi tác: Bệnh thường xảy ra ở bệnh nhân nam trên 50 và nữ trên 55 tuổi. Càng lớn tuổi, động mạch càng dễ bị tổn thương và thu hẹp hơn. 
  * Giới tính: Thông thường nam giới thường có nguy cơ mắc bệnh mạch vành cao hơn nữ giới. Tuy nhiên, sau tuổi mãn kinh, tỉ lệ nữ mắc bệnh này lại cao hơn.
  * Di truyền: Những người có người thân từng mắc bệnh tim mạch, đột quỵ sẽ có nguy cơ cao mắc các bệnh này, thậm chí từ khi còn trẻ.


### **3.2. Nguyên nhân chủ quan gây bệnh động mạch vành**
  * Các bệnh lý: các bệnh cao huyết áp, rối loạn mỡ máu, béo phì, đái tháo đường…là những yếu tố nguy cơ gây bệnh mạch vành.
  * Các thói quen thiếu lành mạnh: Hút thuốc lá, nghiện rượu bia, ít vận động…là những thói quen khiến bạn dễ mắc bệnh mạch vành. Thường xuyên ngồi một chỗ, không luyện tập thể dục đều đặn làm tăng nguy cơ béo phì, dư thừa cholesterol, gây các bệnh về tim và mạch máu. Hút thuốc làm tăng nguy cơ các bệnh tim mạch, ung thư phổi, ung thư vòm họng,… Uống quá nhiều rượu bia cũng gây thiếu máu cục bộ cơ tim.


## **4. Những nguy hiểm đến từ bệnh mạch vành**
Bệnh mạch vành không chỉ gây đau tức, mệt mỏi mà còn mang tới nhiều hệ lụy cho sức khỏe. Các biến chứng thường gặp:
### _**4.1. Nhồi máu cơ tim**_
Nhồi máu cơ tim là hiện tượng động mạch vành xuất hiện cục máu đông (huyết khối), khiến động mạch vành bị tắc nghẽn. Khoảng 1/3 bệnh nhân bị nhồi máu cơ tim có nguy cơ tử vong trước khi được điều trị. Mặt khác, quá trình này thúc đẩy sự hình thành các mô sẹo, nguyên nhân chủ yếu gây rối loạn nhịp tim, ngừng tim. 90% người bệnh bị nhồi máu cơ tim sẽ bị rối loạn nhịp tim nhanh.
Các bệnh nhân đã bị nhồi máu cơ tim có tỉ lệ tái phát bệnh sau 1 năm ở mức cao.
### _**4.2. Đột quỵ**_
Sư xuất hiện các cục máu đông làm tắc nghẽn mạch máu dẫn lên não là một trong những nguyên nhân gây đột quỵ. Trong trường hợp bị nhẹ thì bị liệt nửa người, nếu bị nặng có thể dẫn tới tử vong.
_Bệnh mạch vành là nguyên nhân hàng đầu gây đột quỵ_
### **_4.3. Suy tim do bệnh động mạch vành_**
Không được cung cấp đủ máu khiến cho hoạt động của cơ tim ngày càng yếu dần đi và mệt mỏi. Đó là cơ chế gây suy tim
_**4.4. Phình mạch**_
Phình mạch là một trong những biến chứng nguy hiểm nhất của xơ vữa động mạch vành. Khi động mạch bị vỡ, bệnh tử vong ngay lập tức.
_**4.5. Rối loạn nhịp tim**_
Các cơn rung nhĩ khiến tim loạn nhịp, có thể đe dọa đến tính mạng người bệnh.
## **5. Điều trị bệnh mạch vành**
### Hiện nay điều trị nội khoa vẫn là phương pháp điều trị bệnh mạch vành chủ yếu. Điều trị bằng thuốc được thực hiện với các mục tiêu:
  * Giảm triệu chứng của bệnh
  * Ngăn bệnh tiến triển phòng ngừa biến chứng
  * Điều trị duy trị sau nhồi máu cơ tim, dự phòng tái phát


Sử dụng một hoặc kết hợp một vài loại thuốc điều trị đặc hiệu có thể cải thiện các yếu tố nguy cơ tim mạch, tiểu đường, tăng huyết áp.
  * Thuốc chống kết vón tiểu cầu
  * Thuốc ức chế thụ thể beta 
  * Thuốc chẹn kênh calci
  * Thuốc hạ Cholesterol máu 
  * Thuốc nhóm Fibrat


Các loại thuốc trên cần được dùng theo đơn và tuân thủ chỉ định của bác sĩ dựa trên các thăm khám lâm sàng và cận lâm sàng. Người bệnh không tự dùng thuốc khi không có chỉ định, không tăng liều, bỏ liều, ngưng thuốc hay thay đổi loại thuốc khi chưa tham khảo ý kiến bác sĩ.
Trong những trường hợp nặng hơn, các phương pháp khác sẽ được sử dụng nhằm khai mở mạch vành.
## **6. Cách phòng ngừa bệnh mạch vành hiệu quả**
Xây dựng lối sống lành mạnh giúp ngăn ngừa hoặc cải thiện xơ vữa động mạch:
  * Bệnh nhân nên bỏ thuốc lá, hạn chế đến mức tối đa sử dụng rượu bia
  * Ăn các loại thực phẩm tốt cho sức khỏe và hệ tim mạch như rau xanh, ngũ cốc nguyên hạt…
  * Cố gắng ăn nhạt, hạn chế các thực phẩm nhiều dầu mỡ
  * Tập thể dục nhẹ nhàng mỗi ngày như đi bộ, yoga, ngồi thiền… 
  * Giảm cân


Thư giãn, giải tỏa căng thẳng bằng nhiều biện pháp
  * Theo dõi và điều trị triệt để các bệnh lý nguy cơ. Đặc biệt là tăng huyết áp, đái tháo đường, mỡ máu
  * Tuân thủ các hướng dẫn điều trị, dự phòng tái phát bệnh.
  * Khám sức khỏe định kỳ nhằm phát hiện kịp thời những dấu hiệu bất thường ở tim, những nguy cơ tiềm ẩn gây bệnh động mạch vành. Chẩn đoán sớm bệnh và chữa trị ngay từ đầu không chỉ tăng khả năng hồi phục, tránh bệnh tiến triển nặng, phòng ngừa biến chứng mà còn tiết kiệm nhiều chi phí và thời gian điều trị. Vì vậy, người bệnh hoặc có nguy cơ mắc bệnh mạch vành nên đi khám tim mạch 6 tháng/lần để kiểm soát tiến triển bệnh tốt hơn. 


Có thể thấy, **bệnh động mạch vành** có khả năng gây ra nhiều hệ lụy cho sức khỏe. Chủ động theo dõi sức khỏe, phát hiện sớm bệnh bằng thăm khám hay qua các triệu chứng là những biện pháp giúp kiểm soát bệnh hiệu quả.
**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/) **- Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [1. Hiểu bệnh động mạch vành là gì?](https://bvnguyentriphuong.com.vn/noi-tim-mach/kiem-soat-benh-dong-mach-vanh-can-luu-y-nhung-dieu-gi#1-hiu-bnh-ng-mch-vnh-l-g)
  * [2. Nhận biết bệnh mạch vành sớm qua các triệu chứng](https://bvnguyentriphuong.com.vn/noi-tim-mach/kiem-soat-benh-dong-mach-vanh-can-luu-y-nhung-dieu-gi#2-nhn-bit-bnh-mch-vnh-sm-qua-cc-triu-chng)
  * [3. Phòng tránh các nguyên nhân gây bệnh](https://bvnguyentriphuong.com.vn/noi-tim-mach/kiem-soat-benh-dong-mach-vanh-can-luu-y-nhung-dieu-gi#3-phng-trnh-cc-nguyn-nhn-gy-bnh)
  * [3.1. Nguyên nhân khách quan](https://bvnguyentriphuong.com.vn/noi-tim-mach/kiem-soat-benh-dong-mach-vanh-can-luu-y-nhung-dieu-gi#31-nguyn-nhn-khch-quan)
  * [3.2. Nguyên nhân chủ quan gây bệnh động mạch vành](https://bvnguyentriphuong.com.vn/noi-tim-mach/kiem-soat-benh-dong-mach-vanh-can-luu-y-nhung-dieu-gi#32-nguyn-nhn-ch-quan-gy-bnh-ng-mch-vnh)
  * [4. Những nguy hiểm đến từ bệnh mạch vành](https://bvnguyentriphuong.com.vn/noi-tim-mach/kiem-soat-benh-dong-mach-vanh-can-luu-y-nhung-dieu-gi#4-nhng-nguy-him-n-t-bnh-mch-vnh)
  * [4.1. Nhồi máu cơ tim](https://bvnguyentriphuong.com.vn/noi-tim-mach/kiem-soat-benh-dong-mach-vanh-can-luu-y-nhung-dieu-gi#41-nhi-mu-c-tim)
  * [4.3. Suy tim do bệnh động mạch vành](https://bvnguyentriphuong.com.vn/noi-tim-mach/kiem-soat-benh-dong-mach-vanh-can-luu-y-nhung-dieu-gi#43-suy-tim-do-bnh-ng-mch-vnh)
  * [5. Điều trị bệnh mạch vành](https://bvnguyentriphuong.com.vn/noi-tim-mach/kiem-soat-benh-dong-mach-vanh-can-luu-y-nhung-dieu-gi#5-iu-tr-bnh-mch-vnh)
  * [Hiện nay điều trị nội khoa vẫn là phương pháp điều trị bệnh mạch vành chủ yếu. Điều trị bằng thuốc được thực hiện với các mục tiêu:](https://bvnguyentriphuong.com.vn/noi-tim-mach/kiem-soat-benh-dong-mach-vanh-can-luu-y-nhung-dieu-gi#hin-nay-iu-tr-ni-khoa-vn-l-phng-php-iu-tr-bnh-mch-vnh-ch-yu-iu-tr-bng-thuc-c-thc-hin-vi-cc-mc-tiu)
  * [6. Cách phòng ngừa bệnh mạch vành hiệu quả](https://bvnguyentriphuong.com.vn/noi-tim-mach/kiem-soat-benh-dong-mach-vanh-can-luu-y-nhung-dieu-gi#6-cch-phng-nga-bnh-mch-vnh-hiu-qu)



## Các mức độ hẹp van động mạch phổi và cách điều trị

  * [1.1 Hẹp van động mạch phổi và các mức độ của bệnh](https://bvnguyentriphuong.com.vn/noi-tim-mach/cac-muc-do-hep-van-dong-mach-phoi-va-cach-dieu-tri#11-hp-van-ng-mch-phi-v-cc-mc-ca-bnh)
  * [2. Các triệu chứng thường gặp khi van động mạch phổi hẹp](https://bvnguyentriphuong.com.vn/noi-tim-mach/cac-muc-do-hep-van-dong-mach-phoi-va-cach-dieu-tri#2-cc-triu-chng-thng-gp-khi-van-ng-mch-phi-hp)
  * [3. Nguyên nhân dẫn đến hẹp van động mạch phổi là gì?](https://bvnguyentriphuong.com.vn/noi-tim-mach/cac-muc-do-hep-van-dong-mach-phoi-va-cach-dieu-tri#3-nguyn-nhn-dn-n-hp-van-ng-mch-phi-l-g)
  * [4. Phát hiện bệnh như thế nào?](https://bvnguyentriphuong.com.vn/noi-tim-mach/cac-muc-do-hep-van-dong-mach-phoi-va-cach-dieu-tri#4-pht-hin-bnh-nh-th-no)
  * [4.1 Chẩn đoán lâm sàng](https://bvnguyentriphuong.com.vn/noi-tim-mach/cac-muc-do-hep-van-dong-mach-phoi-va-cach-dieu-tri#41-chn-on-lm-sng)
  * [4.2 Chẩn đoán cận lâm sàng](https://bvnguyentriphuong.com.vn/noi-tim-mach/cac-muc-do-hep-van-dong-mach-phoi-va-cach-dieu-tri#42-chn-on-cn-lm-sng)
  * [5. Bệnh có nguy hiểm không? ](https://bvnguyentriphuong.com.vn/noi-tim-mach/cac-muc-do-hep-van-dong-mach-phoi-va-cach-dieu-tri#5-bnh-c-nguy-him-khng)
  * [5.1 Nhiễm trùng ](https://bvnguyentriphuong.com.vn/noi-tim-mach/cac-muc-do-hep-van-dong-mach-phoi-va-cach-dieu-tri#51-nhim-trng)
  * [5.2 Phì đại tâm thất phải, suy tim ](https://bvnguyentriphuong.com.vn/noi-tim-mach/cac-muc-do-hep-van-dong-mach-phoi-va-cach-dieu-tri#52-ph-i-tm-tht-phi-suy-tim)
  * [5.3 Loạn nhịp tim ](https://bvnguyentriphuong.com.vn/noi-tim-mach/cac-muc-do-hep-van-dong-mach-phoi-va-cach-dieu-tri#53-lon-nhp-tim)
  * [6. Điều trị van động mạch phổi bị hẹp ](https://bvnguyentriphuong.com.vn/noi-tim-mach/cac-muc-do-hep-van-dong-mach-phoi-va-cach-dieu-tri#6-iu-tr-van-ng-mch-phi-b-hp)
  * [6.1 Điều trị hẹp van động mạch phổi nhẹ](https://bvnguyentriphuong.com.vn/noi-tim-mach/cac-muc-do-hep-van-dong-mach-phoi-va-cach-dieu-tri#61-iu-tr-hp-van-ng-mch-phi-nh)
  * [6.2 Điều trị hẹp van động mạch phổi có triệu chứng](https://bvnguyentriphuong.com.vn/noi-tim-mach/cac-muc-do-hep-van-dong-mach-phoi-va-cach-dieu-tri#62-iu-tr-hp-van-ng-mch-phi-c-triu-chng)


**Hẹp van động mạch phổi** là bệnh lý thường phát hiện ở trẻ em, chiếm 9-10% các trường hợp tim bẩm sinh. Bệnh này có nguy hiểm không, nguyên nhân gây bệnh là gì, cách chẩn đoán và điều trị ra sao? Cùng tìm hiểu ngay ở bài viết dưới đây.
## **1.1 Hẹp van động mạch phổi và các mức độ của bệnh**
Van động mạch phổi là van tim có nhiệm vụ từ kiểm soát việc bơm máu từ buồng thất phải sang động mạch phổi theo 1 chiếu Nhưng khi van này bị biến dạng hoặc chít hẹp sẽ gây ra tình trạng dòng máu chảy từ tim đến phổi gặp khó khăn, lượng máu có thể lên phổi để trao đổi oxy giảm. Tình trạng này gọi là hẹp van động mạch phổi.
Phân loại mức độ của bệnh dựa trên các mức độ hẹp của van này gồm:
**– Hẹp nhẹ**
Khi chênh lệch áp lực thất phải/động mạch phổi ≤ 40 mmHg, áp lực thất phải ≤ 1/2 áp lực thất trái. Độ chênh lệch áp tối đa qua van < 30 mmHg. 
**– Hẹp vừa**
Là khi sự chênh lệch áp lực 40 mmHg < thất phải/động mạch phổi ≤ 80 mmHg, áp lực thất phải > ½ áp lực thất trái. Độ chênh lệch áp tối đa qua van từ 30 – 50 mmHg. 
**– Hẹp nặng**
Trường hợp hẹp nặng khi chênh lệch áp thất phải/động mạch phổi > 80mmHg, áp lực thất phải ≥ áp lực thất trái. Độ chênh lệch áp tối đa qua van > 50 mmHg. 
_Van động mạch phổi không mở hết được khiến lượng máu từ tim lên phổi giảm._
## **2. Các triệu chứng thường gặp khi van động mạch phổi hẹp**
Triệu chứng van động mạch phổi hẹp ở một số người là khác nhau, tùy thuộc vào mức độ hẹp của van từ nhẹ đến nặng. Những trường hợp van động mạch phổi hẹp nhẹ thường chỉ có triệu chứng khi gắng sức. 
Một số triệu chứng điển hình của bệnh nhân van động mạch phổi hẹp: 
  * – Khó thở, đặc biệt là trường hợp gắng sức
  * – Đau ngực 
  * – Mất ý thức, ngất xỉu 
  * – Mệt mỏi thường xuyên 


Khi có các triệu chứng khó thở, đau ngực hoặc bất tỉnh, bạn cần phải đến bác sĩ chuyên khoa khám ngay, để đánh giá kịp thời tình trạng hạn chế biến chứng có thể xảy ra. 
## **3. Nguyên nhân dẫn đến hẹp van động mạch phổi là gì?**
Nguyên nhân dẫn đến hiện tượng này thường là do sự phát triển bất thường trong quá trình phát triển thai nhi. Bất thường về tim bẩm sinh cũng gặp đồng thời ở trẻ hẹp động mạch phổi chiếm đến 9 – 10 %. Trường hợp này có thể chẩn đoán trước sinh ở thể nặng. 
Ngoài ra, các nguyên nhân khác gây hẹp van tim này gồm:
  * – Di chứng thấp tim, dính mép van tim gây hẹp van. 
  * – Trường hợp hẹp thứ phát do hội chứng U Carcinoid gây thâm nhiễm lá van động mạch phổi. 
  * – Giả hẹp van trong trường hợp tắc nghẽn đường tống máu thất phải, nguyên nhân do u trong tim hoặc túi phình xoang Valsalva. 
  * – Mắc hội chứng Noonan – Leopard – Williams Beurens-Rubella bẩm sinh, hội chứng sốt thấp khớp (gây nhiễm trùng do vi khuẩn liên cầu như viêm họng, ban đỏ gây tổn thương van tim) … 
  * – Nguyên nhân từ bên ngoài gây ép vòng van động mạch phổi do VMT-U Carcinoide


Một số trường hợp hẹp động mạch phổi ở người già do có van nhân tạo khác, gây hẹp van. 
_Van động mạch phổi thường bị hẹp ở trẻ em._
## **_4. Phát hiện bệnh như thế nào?_**
Trường hợp hẹp động mạch phổi thường được phát hiện ở giai đoạn nhỏ tuổi. Tuy nhiên, một số trường hợp bỏ sót, phát hiện muộn ở giai đoạn trẻ lớn. Bác sĩ sẽ thăm khám lâm sàng và dựa vào một số cận lâm sàng để phát hiện ra tình trạng hẹp van. 
### _**4.1 Chẩn đoán lâm sàng**_
_– Nghe tim phổi_
Nghi ngờ hẹp động mạch phổi khi đi khám định kỳ ở chuyên khoa, bác sĩ nghe thấy tiếng thổi tim ở phía trên bên trái lồng ngực. 
### _**4.2 Chẩn đoán cận lâm sàng**_
### _Điện tim_
Trên hình ảnh sóng điện tim, có thể xác định được dày thành cơ thất phải trong trường hợp phì đại tâm thất. 
### _Siêu âm tim_
Siêu âm tim giúp kiểm tra cấu trúc van động mạch phổi, vị trí, mức độ bệnh, chức năng tâm thất phải của tim. 
### _CT, MRI_
Nhằm xác định và mức độ khi hẹp van ĐMP. 
## **5. Bệnh có nguy hiểm không?**
Trong trường hợp hẹp động mạch phổi nhẹ, trung bình thì thường ít khi xảy ra biến chứng. Tuy nhiên trường hợp hẹp nặng thì có thể xảy ra một số biến chứng nguy hiểm. 
### _**5.1 Nhiễm trùng**_
Những người bị hẹp van này có nguy cơ nhiễm trùng do vi khuẩn ở trong lớp lót bên trong tim, gây viêm nội tâm mạc nhiễm trùng. 
### _**5.2 Phì đại tâm thất phải, suy tim**_
Trường hợp hẹp nặng, tâm thất phải phải bơm máu mạnh hơn, nhằm đẩy máu vào động mạch phổi. Lúc này, tâm thất phải chống lại áp lực gia tăng, làm cho cơ thành thất dày lên. Khoang chứa trong tâm thất to ra, gây phì đại tâm thất phải. Cuối cùng, làm cho tim trở nên cứng hơn, dễ suy tim. 
### _**5.3 Loạn nhịp tim**_
Nhịp tim không đều, gây loạn nhịp, tuy nhiên không đe dọa tính mạng. 
Việc chẩn đoán và điều trị bất thường ở van động mạch phổi phải được thực hiện ở các cơ sở y tế uy tín với đội ngũ bác sĩ có chuyên môn cao và các thiết bị hiện đại.
## **6. Điều trị van động mạch phổi bị hẹp**
### _**6.1 Điều trị hẹp van động mạch phổi nhẹ**_
Một số trường hợp hẹp van nhẹ không cần điều trị, người bệnh chỉ cần kiểm tra, theo dõi định kỳ thường xuyên theo lịch của bác sĩ và thực hiện các biện pháp thay đổi lối sống như:
  * – Bỏ thuốc lá
  * – Hạn chế hoặc từ bỏ rượu và các chất kích thích khác
  * – Ăn uống khoa học, ăn đủ các nhóm dưỡng chất, tăng cường rau xanh, trái cây, hạn chế chất béo gây hại
  * – Thường xuyên luyện tập, rèn luyện thân thể với những bài tập phù hợp như đi bộ, yoga
  * – Giữ tâm trạng thoải mái, tránh thức khuya, căng thẳng,…


### _**6.2 Điều trị hẹp van động mạch phổi có triệu chứng**_
Khi bệnh nhân có các triệu chứng đau ngực, khó thở, mệt mỏi, bác sĩ có thể kê đơn thuốc nhằm cải thiện lưu lượng máu; giảm nguy cơ đông máu; tăng sức co bóp của tim; giảm lượng chất lỏng dư thừa; phòng ngừa nhịp tim không đều. Đơn thuốc sẽ được chỉ định tùy vào tình trạng của bệnh nhân sau các chẩn đoán, xét nghiệm kỹ càng.
Trong các trường hợp van hẹp nặng, các triệu chứng gây khó chịu trầm trọng hoặc điều trị nội khoa không đáp ứng, các bác sĩ có thể tiến hành các can thiệp sâu hơn nhằm giải quyết các tình trạng khó chịu và xử lý các biến chứng.
Tóm lại, **hẹp van động mạch phổi** là bệnh lý van tim có nguyên nhân và biểu hiện đa dạng. Tùy từng tình trạng của bệnh nhân mà các biện pháp điều trị được đưa ra và thực hiện. Hãy kiểm tra sức khỏe định kỳ thường xuyên, để phát hiện bệnh lý ở giai đoạn sớm để được điều trị hiệu quả nhất nhé.
**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/) **- Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [1.1 Hẹp van động mạch phổi và các mức độ của bệnh](https://bvnguyentriphuong.com.vn/noi-tim-mach/cac-muc-do-hep-van-dong-mach-phoi-va-cach-dieu-tri#11-hp-van-ng-mch-phi-v-cc-mc-ca-bnh)
  * [2. Các triệu chứng thường gặp khi van động mạch phổi hẹp](https://bvnguyentriphuong.com.vn/noi-tim-mach/cac-muc-do-hep-van-dong-mach-phoi-va-cach-dieu-tri#2-cc-triu-chng-thng-gp-khi-van-ng-mch-phi-hp)
  * [3. Nguyên nhân dẫn đến hẹp van động mạch phổi là gì?](https://bvnguyentriphuong.com.vn/noi-tim-mach/cac-muc-do-hep-van-dong-mach-phoi-va-cach-dieu-tri#3-nguyn-nhn-dn-n-hp-van-ng-mch-phi-l-g)
  * [4. Phát hiện bệnh như thế nào?](https://bvnguyentriphuong.com.vn/noi-tim-mach/cac-muc-do-hep-van-dong-mach-phoi-va-cach-dieu-tri#4-pht-hin-bnh-nh-th-no)
  * [4.1 Chẩn đoán lâm sàng](https://bvnguyentriphuong.com.vn/noi-tim-mach/cac-muc-do-hep-van-dong-mach-phoi-va-cach-dieu-tri#41-chn-on-lm-sng)
  * [4.2 Chẩn đoán cận lâm sàng](https://bvnguyentriphuong.com.vn/noi-tim-mach/cac-muc-do-hep-van-dong-mach-phoi-va-cach-dieu-tri#42-chn-on-cn-lm-sng)
  * [5. Bệnh có nguy hiểm không? ](https://bvnguyentriphuong.com.vn/noi-tim-mach/cac-muc-do-hep-van-dong-mach-phoi-va-cach-dieu-tri#5-bnh-c-nguy-him-khng)
  * [5.1 Nhiễm trùng ](https://bvnguyentriphuong.com.vn/noi-tim-mach/cac-muc-do-hep-van-dong-mach-phoi-va-cach-dieu-tri#51-nhim-trng)
  * [5.2 Phì đại tâm thất phải, suy tim ](https://bvnguyentriphuong.com.vn/noi-tim-mach/cac-muc-do-hep-van-dong-mach-phoi-va-cach-dieu-tri#52-ph-i-tm-tht-phi-suy-tim)
  * [5.3 Loạn nhịp tim ](https://bvnguyentriphuong.com.vn/noi-tim-mach/cac-muc-do-hep-van-dong-mach-phoi-va-cach-dieu-tri#53-lon-nhp-tim)
  * [6. Điều trị van động mạch phổi bị hẹp ](https://bvnguyentriphuong.com.vn/noi-tim-mach/cac-muc-do-hep-van-dong-mach-phoi-va-cach-dieu-tri#6-iu-tr-van-ng-mch-phi-b-hp)
  * [6.1 Điều trị hẹp van động mạch phổi nhẹ](https://bvnguyentriphuong.com.vn/noi-tim-mach/cac-muc-do-hep-van-dong-mach-phoi-va-cach-dieu-tri#61-iu-tr-hp-van-ng-mch-phi-nh)
  * [6.2 Điều trị hẹp van động mạch phổi có triệu chứng](https://bvnguyentriphuong.com.vn/noi-tim-mach/cac-muc-do-hep-van-dong-mach-phoi-va-cach-dieu-tri#62-iu-tr-hp-van-ng-mch-phi-c-triu-chng)



## Bệnh lý mạch vành: Nguyên nhân, triệu chứng và cách điều trị

  * [1. Bệnh lý mạch vành là gì?](https://bvnguyentriphuong.com.vn/noi-tim-mach/benh-ly-mach-vanh-nguyen-nhan-trieu-chung-va-cach-dieu-tri#1-bnh-l-mch-vnh-l-g)
  * [2. Người mắc bệnh lý mạch vành có triệu chứng gì?](https://bvnguyentriphuong.com.vn/noi-tim-mach/benh-ly-mach-vanh-nguyen-nhan-trieu-chung-va-cach-dieu-tri#2-ngi-mc-bnh-l-mch-vnh-c-triu-chng-g)
  * [3. Nguyên nhân gây bệnh mạch vành](https://bvnguyentriphuong.com.vn/noi-tim-mach/benh-ly-mach-vanh-nguyen-nhan-trieu-chung-va-cach-dieu-tri#3-nguyn-nhn-gy-bnh-mch-vnh)
  * [3.1. Yếu tố khách quan](https://bvnguyentriphuong.com.vn/noi-tim-mach/benh-ly-mach-vanh-nguyen-nhan-trieu-chung-va-cach-dieu-tri#31-yu-t-khch-quan)
  * [3.2. Yếu tố chủ quan](https://bvnguyentriphuong.com.vn/noi-tim-mach/benh-ly-mach-vanh-nguyen-nhan-trieu-chung-va-cach-dieu-tri#32-yu-t-ch-quan)
  * [4. Bệnh lý mạch vành có nguy hiểm không?](https://bvnguyentriphuong.com.vn/noi-tim-mach/benh-ly-mach-vanh-nguyen-nhan-trieu-chung-va-cach-dieu-tri#4-bnh-l-mch-vnh-c-nguy-him-khng)
  * [5. Điều trị bệnh mạch vành và giảm biến chứng nguy hiểm](https://bvnguyentriphuong.com.vn/noi-tim-mach/benh-ly-mach-vanh-nguyen-nhan-trieu-chung-va-cach-dieu-tri#5-iu-tr-bnh-mch-vnh-v-gim-bin-chng-nguy-him)
  * [5.1. Điều trị nội khoa bệnh lý mạch vành](https://bvnguyentriphuong.com.vn/noi-tim-mach/benh-ly-mach-vanh-nguyen-nhan-trieu-chung-va-cach-dieu-tri#51-iu-tr-ni-khoa-bnh-l-mch-vnh)
  * [7. Người mắc bệnh động mạch vành nên ăn gì?](https://bvnguyentriphuong.com.vn/noi-tim-mach/benh-ly-mach-vanh-nguyen-nhan-trieu-chung-va-cach-dieu-tri#7-ngi-mc-bnh-ng-mch-vnh-nn-n-g)
  * [7.1. Thực phẩm chống oxy hóa, tăng cường hệ miễn dịch](https://bvnguyentriphuong.com.vn/noi-tim-mach/benh-ly-mach-vanh-nguyen-nhan-trieu-chung-va-cach-dieu-tri#71-thc-phm-chng-oxy-ha-tng-cng-h-min-dch)
  * [7.2. Thực phẩm tăng cường lưu thông máu](https://bvnguyentriphuong.com.vn/noi-tim-mach/benh-ly-mach-vanh-nguyen-nhan-trieu-chung-va-cach-dieu-tri#72-thc-phm-tng-cng-lu-thng-mu)
  * [7.3. Thực phẩm giảm lượng cholesterol xấu](https://bvnguyentriphuong.com.vn/noi-tim-mach/benh-ly-mach-vanh-nguyen-nhan-trieu-chung-va-cach-dieu-tri#73-thc-phm-gim-lng-cholesterol-xu)


Bệnh mạch vành là một trong những bệnh lý tim mạch nguy hiểm, là nguyên gây tử vong hàng đầu hiện nay. Bệnh mạch vành hiện đang có xu hướng gia tăng nhanh chóng ở cả người lớn tuổi và người trẻ. Bài viết dưới đây sẽ giúp bạn tìm hiểu **bệnh lý mạch vành** , những biểu hiện, phương pháp phòng ngừa và điều trị hiệu quả.
## **1. Bệnh lý mạch vành là gì?**
Xơ vữa động mạch là tình trạng xuất hiện một hoặc nhiều nhánh của động mạch vành bị thu hẹp và cản trở bởi các mảng bám tích tụ theo thời gian bên trong mạch máu bởi cholesterol và một số chất khác. Đây là một dạng của bệnh mạch vành.
Ở trạng thái bình thường, động mạch trong cơ thể rất mềm mại và có tính đàn hồi, nhưng sự xuất hiện của các mảng bám sẽ khiến động mạch trở nên cứng hơn, máu lưu thông kém và khó khăn. Hậu quả là tim sẽ không nhận được lượng oxy cần thiết để hoạt động và gây ra tình trạng đau thắt ngực hoặc nhồi máu cơ tim khi về lâu dài.
Tình trạng nhồi máu cơ tim là do các cục máu đông di chuyển đến những phần động mạch đang bị hẹp, gây tắc mạch máu và gây tổn thương cho tim do không được cung cấp máu.
Bệnh mạch vành còn làm cho tim phải hoạt động nặng hơn để bổ sung đủ lượng máu cho hoạt động duy trì sự sống, tạo ra những biến chứng nặng như suy tim hay rối loạn nhịp tim.
_Khi một hoặc nhiều nhánh của động mạch vành bị tắc hẹp gây cản trở dòng máu đến nuôi dưỡng cơ tim._
## **2. Người mắc bệnh lý mạch vành có triệu chứng gì?**
Triệu chứng thường gặp nhất của người mắc bệnh mạch vành là đau thắt ngực và đây cũng là biểu hiện sớm thấy nhất. Cơn đau thường ở giữa ngực, ngay sau xương ức, có thể lan ra các vùng xung quanh như cổ, hàm hoặc cánh tay.
Các cơn đau thường có thời gian xuất hiện ngắn, chỉ khoảng từ 10 30 giây hoặc vài phút. Tuy nhiên, vẫn có người bị lâu hơn lên tới 15 phút, nếu cơn đau kéo dài và không có dấu hiệu suy giảm có thể gây nhồi máu cơ tim cấp.
Ngoài triệu chứng đau thắt ngực, bệnh mạch vành cũng có các biểu hiện khác như:
  * Người bệnh có cảm giác hồi hộp, đánh trống ngực, hụt hơi
  * Cảm giác hoa mắt, chóng mặt bất thường
  * Cảm thấy mệt mỏi, xuất hiện các cơn đau tức ngực kèm buồn nôn


Biểu hiện điển hình nhất của bệnh mạch vành chính là đau thắt ngực ổn định. Gọi là đau thắt ngực ổn định bởi nó xảy ra thường xuyên, lặp đi lặp lại khi bạn gắng sức đến một mức độ nhất định, đôi khi có thể do cảm xúc hoặc thời tiết lạnh.
## **3. Nguyên nhân gây bệnh mạch vành**
### **_3.1. Yếu tố khách quan_**
  * Độ tuổi: Với độ tuổi càng cao thì tỉ lệ mắc bệnh mạch vành càng cao, thường từ 50 tuổi đối với nam và 55 tuổi đối với nữ.-Giới tính: Nam giới được coi là đối tượng có nguy cơ cao hơn so với nữ trong các bệnh về tim mạch. Tuy nhiên, nữ giới sau mãn kinh lại có nguy cơ mắc bệnh mạch vành cao hơn.
  * Do di truyền: Những người có bố mẹ, ông bà hoặc anh chị em trong gia đình mắc các chứng tai biến về tim mạch sẽ có nguy cơ bệnh mạch vành cao hơn, nhất là ở độ tuổi 55 đối với nam và 65 đối với nữ.
  * Người mắc các bệnh lý liên quan: Những người mắc các bệnh lý như cao huyết áp, đái tháo đường, béo phì hoặc rối loạn mỡ máu cũng sẽ có nguy cơ cao mắc bệnh mạch vành.


### _**3.2. Yếu tố chủ quan**_
Các yếu tố có thể thay đổi được thường do chủ quan của con người, bắt nguồn từ lối sống sinh hoạt, do vậy có thể thay đổi để cải thiện sức khỏe tốt hơn.
  * Lối sống ít vận động: Những người có thói quen ít đi lại, không tập thể dục thể thao thường xuyên, hay ngồi một chỗ sẽ có nguy cơ cao mắc bệnh mạch vành và các bệnh liên quan khác.
  * Hút thuốc lá: Hút thuốc là không chỉ làm tăng các nguy cơ về bệnh tim mạch mà còn bao gồm các bệnh như ung thư vòm họng, ung thư phổi. Ngoài ra, nó còn gián tiếp gây bệnh cho những người bên cạnh người hút thuốc.
  * Uống rượu bia: Uống quá nhiều rượu bia sẽ tăng khả năng thiếu máu cục bộ cơ tim và xuất hiện những cơn đau thắt ngực bất thường.


## **4. Bệnh lý mạch vành có nguy hiểm không?**
Bệnh động mạch vành có tỷ lệ tử vong rất cao, thậm chí người bệnh có thể bị tử vong ngay tức khắc hoặc sau vài giờ khi động mạch vành bị tắc nghẽn gây nhồi máu cơ tim. Bệnh mạch vành ảnh hưởng sức khỏe khi kéo dài dễ tạo ra các biến chứng nguy hiểm:
  * Hội chứng mạch vành cấp: là khi cơn đau thắt ngực trở nên bất ổn định, kéo dài kể cả sau thời gian nghỉ ngơi hoặc đau thắt cả khi bạn nghỉ ngơi, đau thắt ngực bất ổn định vẫn có thể tự khỏi. Tuy nhiên nó có nguy cơ cao chuyển thành nhồi máu cơ tim.
  * Nhồi máu cơ tim: Nhồi máu cơ tim là sự tắc nghẽn hoàn toàn của một động mạch vành và gây tổn thương một phần cơ tim. Nhồi máu cơ tim nguy hiểm hơn so với đau thắt ngực bất ổn định, bởi nếu không được cứu chữa kịp thời, bạn sẽ bị mất một phần cơ tim của bạn.
  * Suy tim: Suy tim là triệu chứng trễ của bệnh mạch vành, thường xuất hiện sau cơn nhồi máu cơ tim nặng hoặc do sự yếu dần của tim theo thời gian.


_Nếu không được điều trị, bệnh lý mạch vành có thể gây ra những biến chứng nguy hiểm._
## **5. Điều trị bệnh mạch vành và giảm biến chứng nguy hiểm**
Có 2 cách để điều trị bệnh mạch vành bao gồm:
### **_5.1. Điều trị nội khoa bệnh lý mạch vành_**
Điều trị nội khoa bằng cách sử dụng một hoặc kết hợp các loại thuốc điều trị như:
  * Thuốc chống kết vón tiểu cầu
  * Thuốc hạ cholesterol máu (nhóm statin như zocor, lipitor, crestor…)
  * Thuốc ức chế thụ thể beta
  * Thuốc chẹn kênh calci…


Các loại thuốc này chỉ mang tính chất tham khảo. Trong quá trình điều trị, tùy theo tình trạng của bệnh nhân mà bác sĩ sẽ kê đơn phù hợp. Người bệnh cần tuân thủ chặt chẽ yêu cầu của bác sĩ và sử dụng thuốc theo đơn để cải thiện yếu tố tim mạch và giảm các bệnh liên quan.
**5.2. Điều trị bệnh lý mạch vành bằng các phương pháp khác**
Trong trường hợp nặng, các bác sĩ sẽ tiến hành các phương pháp điều trị khác có tính đặc hiệu hơn nhằm tái thông mạch vành, mở đường cho dòng máu lưu thông. Khi sử dụng các phương pháp này, người bệnh vẫn phải dùng thuốc duy trì nhằm kiểm soát bệnh và phòng tránh tái phát.
**6. Một số cách phòng ngừa bệnh lý mạch vành**
Cách tốt nhất để có thể phòng ngừa bệnh mạch vành hiệu quả chính là thay đổi lối sống khoa học, thăm khám sức khỏe định kỳ đặc biệt là các bệnh lý tim mạch khi có dấu hiệu hoặc ngay cả khi không có biểu hiện sẽ giúp bạn ngăn ngừa xơ vữa động mạch, cải thiện bệnh lý liên quan khác.
Một số cách phòng ngừa bệnh lý tim mạch như sau:
  * Không hút thuốc lá, hạn chế tối đa rượu bia
  * Ăn nhiều rau xanh, các loại ngũ cốc nguyên hạt, hạn chế ăn dầu mỡ, đồ ăn nhiều muối.
  * Luyện tập thể dục thể thao như chạy bộ, bơi lội, yago,… Ít nhất 30 phút mỗi ngày
  * Tham khảo ý kiến bác sĩ để tiến hành giảm cân trong trường hợp thừa cân, béo phì
  * Tránh stress, căng thẳng thần kinh, thư giãn đầu óc nhiều hơn.


Đối với bệnh nhân đang điều trị bệnh mạch vành cần chú ý:
  * Tuân thủ theo hướng dẫn của bác sĩ, cần chú ý dự phòng tái phát bệnh.
  * Điều trị dứt điểm các bệnh lý liên quan như mỡ máu, cao huyết áp, đái tháo đường…
  * Khám sức khỏe định kỳ nhằm phát hiện kịp thời các dấu hiệu bất thường, tránh bệnh tiến triển nặng hơn và tiết kiệm chi phí, thời gian điều trị.


### **7. Người mắc bệnh động mạch vành nên ăn gì?**
Dinh dưỡng đóng vai trò quan trọng trong đời sống, nhất là đối với những người đang trong quá trình điều trị bệnh lý mạch vành. Hãy tham khảo một số loại thực phẩm sau đây ,để biết được người bị bệnh động mạch vành nên ăn tốt cho sức khỏe:
### _**7.1. Thực phẩm chống oxy hóa, tăng cường hệ miễn dịch**_
  * Các loại trái cây nhiều màu sắc
  * Ngũ cốc nguyên hạt như yến mạch, gạo lứt, đại mạch,…
  * Các loại chất béo tốt như dầu mè, dầu ô liu, đậu nành
  * Bổ sung Acid béo Omega 3 từ các loại cá tăng khả năng chống viêm
  * Rau xanh như bắp cải, súp lơ, cải xoăn, cải bó xôi rất giàu vitamin và chất chống oxy hóa.


### _**7.2. Thực phẩm tăng cường lưu thông máu**_
Bao gồm các loại gia vị như tỏi, gừng, hành tây và các loại quả mọng như nho, việt quất, dâu tây có chứa rất nhiều salicylate một loại chất thúc đẩy lưu thông máu và ngăn ngừa hình thành các cục máu đông.
### _**7.3. Thực phẩm giảm lượng cholesterol xấu**_
Là những loại thực phẩm có chứa nhiều chất xơ hòa tan, giúp giảm khả năng hấp thu cholesterol và thúc đẩy đào thải cholesterol ra khỏi cơ thể.
  * Ngũ cốc nguyên hạt như yến mạch, bánh mì đen
  * Các loại rau xanh nhớt như mồng tơi, đậu bắp, rau đay
  * Các loại trái cây như ổi, lê, cam, đu đủ


Ngoài ra, những người đang trong quá trình điều trị bệnh mạch vành thì nên hạn chế ăn các đồ ăn chiên xào, rán, thay vào đó là món luộc, hấp hoặc trộn. Người mắc bệnh lý mạch vành cũng nên hạn chế sử dụng các gia vị như bột canh, muối, các loại sốt trong bữa ăn hàng ngày.
Để xây dựng được chế độ ăn phù hợp nhất, bạn cần đi khám và nghe theo tư vấn của các bác sĩ để đem lại hiệu quả tốt nhất.
Hi vọng những thông tin trên đây đã giúp bạn hiểu hơn về **bệnh lý mạch vành** để phòng tránh và phát hiện, điều trị bệnh sớm nhằm tránh những hậu quả đáng tiếc có thể xảy ra.
**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/) **- Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [1. Bệnh lý mạch vành là gì?](https://bvnguyentriphuong.com.vn/noi-tim-mach/benh-ly-mach-vanh-nguyen-nhan-trieu-chung-va-cach-dieu-tri#1-bnh-l-mch-vnh-l-g)
  * [2. Người mắc bệnh lý mạch vành có triệu chứng gì?](https://bvnguyentriphuong.com.vn/noi-tim-mach/benh-ly-mach-vanh-nguyen-nhan-trieu-chung-va-cach-dieu-tri#2-ngi-mc-bnh-l-mch-vnh-c-triu-chng-g)
  * [3. Nguyên nhân gây bệnh mạch vành](https://bvnguyentriphuong.com.vn/noi-tim-mach/benh-ly-mach-vanh-nguyen-nhan-trieu-chung-va-cach-dieu-tri#3-nguyn-nhn-gy-bnh-mch-vnh)
  * [3.1. Yếu tố khách quan](https://bvnguyentriphuong.com.vn/noi-tim-mach/benh-ly-mach-vanh-nguyen-nhan-trieu-chung-va-cach-dieu-tri#31-yu-t-khch-quan)
  * [3.2. Yếu tố chủ quan](https://bvnguyentriphuong.com.vn/noi-tim-mach/benh-ly-mach-vanh-nguyen-nhan-trieu-chung-va-cach-dieu-tri#32-yu-t-ch-quan)
  * [4. Bệnh lý mạch vành có nguy hiểm không?](https://bvnguyentriphuong.com.vn/noi-tim-mach/benh-ly-mach-vanh-nguyen-nhan-trieu-chung-va-cach-dieu-tri#4-bnh-l-mch-vnh-c-nguy-him-khng)
  * [5. Điều trị bệnh mạch vành và giảm biến chứng nguy hiểm](https://bvnguyentriphuong.com.vn/noi-tim-mach/benh-ly-mach-vanh-nguyen-nhan-trieu-chung-va-cach-dieu-tri#5-iu-tr-bnh-mch-vnh-v-gim-bin-chng-nguy-him)
  * [5.1. Điều trị nội khoa bệnh lý mạch vành](https://bvnguyentriphuong.com.vn/noi-tim-mach/benh-ly-mach-vanh-nguyen-nhan-trieu-chung-va-cach-dieu-tri#51-iu-tr-ni-khoa-bnh-l-mch-vnh)
  * [7. Người mắc bệnh động mạch vành nên ăn gì?](https://bvnguyentriphuong.com.vn/noi-tim-mach/benh-ly-mach-vanh-nguyen-nhan-trieu-chung-va-cach-dieu-tri#7-ngi-mc-bnh-ng-mch-vnh-nn-n-g)
  * [7.1. Thực phẩm chống oxy hóa, tăng cường hệ miễn dịch](https://bvnguyentriphuong.com.vn/noi-tim-mach/benh-ly-mach-vanh-nguyen-nhan-trieu-chung-va-cach-dieu-tri#71-thc-phm-chng-oxy-ha-tng-cng-h-min-dch)
  * [7.2. Thực phẩm tăng cường lưu thông máu](https://bvnguyentriphuong.com.vn/noi-tim-mach/benh-ly-mach-vanh-nguyen-nhan-trieu-chung-va-cach-dieu-tri#72-thc-phm-tng-cng-lu-thng-mu)
  * [7.3. Thực phẩm giảm lượng cholesterol xấu](https://bvnguyentriphuong.com.vn/noi-tim-mach/benh-ly-mach-vanh-nguyen-nhan-trieu-chung-va-cach-dieu-tri#73-thc-phm-gim-lng-cholesterol-xu)



## Bóc tách động mạch vành

  * [1. Bóc tách động mạch vành là gì?](https://bvnguyentriphuong.com.vn/noi-tim-mach/boc-tach-dong-mach-vanh#1-bc-tch-ng-mch-vnh-l-g)
  * [2. Những ai có nguy cơ mắc bệnh?](https://bvnguyentriphuong.com.vn/noi-tim-mach/boc-tach-dong-mach-vanh#2-nhng-ai-c-nguy-c-mc-bnh)
  * [2.3 Mang thai và sinh nở](https://bvnguyentriphuong.com.vn/noi-tim-mach/boc-tach-dong-mach-vanh#23-mang-thai-v-sinh-n)
  * [2.4 Bệnh mạch máu tiềm ẩn](https://bvnguyentriphuong.com.vn/noi-tim-mach/boc-tach-dong-mach-vanh#24-bnh-mch-mu-tim-n)
  * [2.5 Huyết áp rất cao gây bóc tách động mạch vành](https://bvnguyentriphuong.com.vn/noi-tim-mach/boc-tach-dong-mach-vanh#25-huyt-p-rt-cao-gy-bc-tch-ng-mch-vnh)
  * [2.6 Tập thể dục quá sức](https://bvnguyentriphuong.com.vn/noi-tim-mach/boc-tach-dong-mach-vanh#26-tp-th-dc-qu-sc)
  * [2.7 Căng thẳng, thay đổi cảm xúc đột ngột](https://bvnguyentriphuong.com.vn/noi-tim-mach/boc-tach-dong-mach-vanh#27-cng-thng-thay-i-cm-xc-t-ngt)
  * [2.8 Bệnh tự miễn](https://bvnguyentriphuong.com.vn/noi-tim-mach/boc-tach-dong-mach-vanh#28-bnh-t-min)
  * [2.9 Bệnh mô liên kết di truyền](https://bvnguyentriphuong.com.vn/noi-tim-mach/boc-tach-dong-mach-vanh#29-bnh-m-lin-kt-di-truyn)
  * [2.10 Sử dụng các chất gây nghiện](https://bvnguyentriphuong.com.vn/noi-tim-mach/boc-tach-dong-mach-vanh#210-s-dng-cc-cht-gy-nghin)
  * [3. Bị bóc tách động mạch vành sống được bao lâu?](https://bvnguyentriphuong.com.vn/noi-tim-mach/boc-tach-dong-mach-vanh#3-b-bc-tch-ng-mch-vnh-sng-c-bao-lu)
  * [4. Các dấu hiệu cảnh báo tình trạng bóc tách mạch vành](https://bvnguyentriphuong.com.vn/noi-tim-mach/boc-tach-dong-mach-vanh#4-cc-du-hiu-cnh-bo-tnh-trng-bc-tch-mch-vnh)
  * [5. Chẩn đoán bệnh bóc tách động mạch vành](https://bvnguyentriphuong.com.vn/noi-tim-mach/boc-tach-dong-mach-vanh#5-chn-on-bnh-bc-tch-ng-mch-vnh)
  * [6. Điều trị và phòng ngừa mạch vành bóc tách](https://bvnguyentriphuong.com.vn/noi-tim-mach/boc-tach-dong-mach-vanh#6-iu-tr-v-phng-nga-mch-vnh-bc-tch)
  * [6.1 Điều trị bệnh bóc tách động mạch vành ](https://bvnguyentriphuong.com.vn/noi-tim-mach/boc-tach-dong-mach-vanh#61-iu-tr-bnh-bc-tch-ng-mch-vnh)


**Bóc tách động mạch vành** là một bệnh lý tim mạch nguy hiểm ở phụ nữ và trẻ em, là nguyên nhân gây ra các cơn đau tim, bất thường nhịp tim hoặc tử vong đột ngột. Vậy bóc tách mạch vành là gì, nguyên nhân và triệu chứng của bệnh ra sao?
## **1. Bóc tách động mạch vành là gì?**
Bóc tách động mạch vành (SCAD) là tình trạng động mạch vành đột ngột bị rách vì nguyên nhân nào đó khiến lưu lượng máu đến tim giảm. Tình trạng này làm tăng nguy cơ xảy ra các biến cố tim mạch như nhồi máu cơ tim, ngừng tim, đột quỵ.
Bóc tách mạch vành là một bệnh hiếm gặp, chỉ chiếm một tỷ lệ nhỏ trong các bệnh tim mạch nói chung. Tuy nhiên đây lại là nguyên nhân gây ra 40% các cơn đột quỵ tim ở phụ nữ dưới 50 tuổi.
_Bóc tách mạch vành là tình trạng động mạch đưa máu đến nuôi cơ tim đột ngột bị rách._
## **2. Những ai có nguy cơ mắc bệnh?**
Những người mắc bệnh này thường là người khỏe mạnh, không bị mắc bất cứ bệnh tim nào trước đó và hầu như không có các yếu tố nguy cơ của bệnh tim mạch như hút thuốc lá, thừa cân, tiểu đường….
Có một số yếu tố nguy cơ khiến một số người mắc căn bệnh này hơn, bao gồm:
_**2.1 Giới tính**_
Bệnh có thể xảy ra ở cả 2 giới, nhưng thường ảnh hưởng đến phụ nữ nhiều hơn nam giới.
### _**2.2 Tuổi tác**_
Bệnh có thể xảy ra trong độ tuổi từ 15 đến 80 nhưng thường gặp nhất ở các phụ nữ trẻ dưới 50 tuổi, độ tuổi trung bình là 42. Bên cạnh đó, trẻ sơ sinh cũng có thể mắc căn bệnh này, với tỷ lệ khoảng 10-15%.
### _**2.3 Mang thai và sinh nở**_
SCAD tự phát có thể xảy ra ở những phụ nữ mới sinh con, thường trong vài tuần đầu tiên sau khi sinh.
### _**2.4 Bệnh mạch máu tiềm ẩn**_
Một số bất thường của mạch máu, đặc biệt là tình trạng sợi cơ loạn sản (FMD) có thể gây ra sự phát triển bất thường của các tế bào trong thành động mạch. Điều này dẫn tới suy yếu thành mạch, gây tắc nghẽn, rách hoặc phình mạch. Bên cạnh đó, hiện tượng loạn sản cơ cũng có thể gây huyết áp cao, đột quỵ, dẫn tới vết rách trong các mạch máu.
### _**2.5 Huyết áp rất cao gây bóc tách động mạch vành**_
Huyết áp nghiêm trọng không được điều trị có thể khiến thành mạch suy yếu. Do đó tăng nguy cơ vỡ, rách mạch máu.
### _**2.6 Tập thể dục quá sức**_
Thường xuyên tập thể dục với cường độ cao làm huyết áp tăng cao, gây bệnh mạch vành bóc tách.
### _**2.7 Căng thẳng, thay đổi cảm xúc đột ngột**_
Một người phải trải qua những trạng thái căng thẳng cảm xúc nghiêm trọng (như cái chết đột ngột của người thân, cú sốc trong chuyện tình cảm, công việc…) sẽ rất dễ bị bóc tách mạch vành.
### _**2.8 Bệnh tự miễn**_
Các bệnh tự miễn hệ thống như lupus có thể gây viêm các mạch máu, viêm nút quanh động mạch. Đây có thể là nguyên nhân gây bóc tách mạch vành tự phát.
### _**2.9 Bệnh mô liên kết di truyền**_
Hội chứng mạch máu Ehlers-Danlos, Marfan có thể làm tăng nguy cơ rách động mạch vành đột ngột.
### _**2.10 Sử dụng các chất gây nghiện**_
Những người thường xuyên sử dụng cocaine hoặc các loại thuốc bất hợp pháp có nguy cơ cao bị bóc tách mạch vành.
## **3. Bị bóc tách động mạch vành sống được bao lâu?**
Bệnh thường tiến triển âm thầm, có thể không gây ra bất cứ vấn đề sức khỏe nào nên việc nhận biết, phát hiện và điều trị bệnh khá khó khăn. Bệnh thường chỉ được tìm ra khi sau khi bệnh nhân gặp phải một cơn đau tim. 
Tỷ lệ tử vong của bệnh mạch vành bóc tách rất thấp, chỉ khoảng 1- 5%. Tuy nhiên với những người bị bóc tách mạch vành tái phát thì cơ hội sống chỉ còn 20%.
_Bệnh thường không biểu hiện ở giai đoạn đầu nhưng có thể gây đau hoặc khó chịu ở ngực khi bệnh trở nặng hơn._
## **4. Các dấu hiệu cảnh báo tình trạng bóc tách mạch vành**
Bệnh bóc tách mạch vành thường ít biểu hiện ở giai đoạn đầu. Các triệu chứng của bệnh ở giai đoạn sau thường gồm:
  * Đau hoặc khó chịu ở ngực
  * Đau lưng, mặt trong cánh tay, vai hoặc hàm
  * Khó thở, hơi thở ngắn, gấp
  * Nhịp tim bất thường, cảm giác rung trong lồng ngực
  * Mệt mỏi bất thường và cực độ
  * Buồn nôn, chóng mặt, đau đầu


## **5. Chẩn đoán bệnh bóc tách động mạch vành**
Như đã nói ở trên, SCAD thường xảy ra ở nhóm phụ nữ trẻ khỏe mạnh bình thường, lại không có các yếu tố nguy cơ vì thế bệnh rất dễ bị chẩn đoán nhầm và phát hiện muộn.
Các chuyên gia tim mạch khuyên bạn nên duy trì thăm khám định kỳ để có thể phát hiện sớm các dấu hiệu bất thường và dự phòng các yếu tố làm tăng nguy cơ bóc tách mạch vành. Đặc biệt, với những bệnh nhân từng mắc SCAD, việc kiểm tra sức khỏe thường xuyên, nhất là các vấn đề về động mạch (phình mạch não, tắc nghẽn, bóc tách hoặc rách động mạch…) tại các chuyên khoa tim mạch là rất cần thiết.
Để chẩn đoán chính xác bệnh bóc tách động mạch vành, bác sĩ sẽ xem xét các dấu hiệu và triệu chứng mà bệnh nhân gặp phải, sau đó yêu cầu bệnh nhân làm một số xét nghiệm, chụp chiếu. Trong đó, điện tâm đồ và xét nghiệm máu là những chẩn đoán cận lâm sàng thường dùng giúp phát hiện tổn thương này. Nếu nghi ngờ một cơn đau tim, bệnh nhân có thể được chỉ định chụp động mạch, siêu âm nội mạch, chụp CT tim… để tìm kiếm các dấu hiệu bất thường.
## **6. Điều trị và phòng ngừa mạch vành bóc tách**
### _**6.1 Điều trị bệnh bóc tách động mạch vành**_
Việc điều trị SCAD phụ thuộc vào các triệu chứng và mức độ nghiêm trọng của bệnh. Đối với các trường hợp vết rách nhỏ, có thể để bóc tách tự lành theo cơ chế riêng của cơ thể. 
Để giảm nguy cơ cục máu đông, các bác sĩ có thể chỉ định dùng chất làm loãng máu. Trong một số trường hợp, đặc biệt các bệnh nhân có loạn sản cơ, có thể sử dụng các thuốc chẹn beta. Nếu các vết rách nghiêm trọng, dẫn tới tắc nghẽn hoặc thiếu máu nghiêm trọng, các phương pháp can thiệp, phẫu thuật có thể được cân nhắc sử dụng. 
_**6.2 Phòng ngừa bóc tác mạch vành như thế nào?**_
Để phòng ngừa và giảm nguy cơ mắc hoặc tái phát bệnh bóc tách mạch vành, bạn cần chăm sóc tốt cho bản thân bằng các biện pháp:
  * Ngủ đủ giấc để bạn có cảm giác thoải mái khi thức dậy
  * Chọn một chế độ ăn uống khỏe mạnh đầy đủ dinh dưỡng, bổ sung các loại trái cây và rau quả
  * Tập luyện các môn thể thao nhẹ nhàng, tránh quá sức
  * Bỏ hút thuốc lá, không sử dụng các chất gây nghiện 


**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/) **- Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [1. Bóc tách động mạch vành là gì?](https://bvnguyentriphuong.com.vn/noi-tim-mach/boc-tach-dong-mach-vanh#1-bc-tch-ng-mch-vnh-l-g)
  * [2. Những ai có nguy cơ mắc bệnh?](https://bvnguyentriphuong.com.vn/noi-tim-mach/boc-tach-dong-mach-vanh#2-nhng-ai-c-nguy-c-mc-bnh)
  * [2.3 Mang thai và sinh nở](https://bvnguyentriphuong.com.vn/noi-tim-mach/boc-tach-dong-mach-vanh#23-mang-thai-v-sinh-n)
  * [2.4 Bệnh mạch máu tiềm ẩn](https://bvnguyentriphuong.com.vn/noi-tim-mach/boc-tach-dong-mach-vanh#24-bnh-mch-mu-tim-n)
  * [2.5 Huyết áp rất cao gây bóc tách động mạch vành](https://bvnguyentriphuong.com.vn/noi-tim-mach/boc-tach-dong-mach-vanh#25-huyt-p-rt-cao-gy-bc-tch-ng-mch-vnh)
  * [2.6 Tập thể dục quá sức](https://bvnguyentriphuong.com.vn/noi-tim-mach/boc-tach-dong-mach-vanh#26-tp-th-dc-qu-sc)
  * [2.7 Căng thẳng, thay đổi cảm xúc đột ngột](https://bvnguyentriphuong.com.vn/noi-tim-mach/boc-tach-dong-mach-vanh#27-cng-thng-thay-i-cm-xc-t-ngt)
  * [2.8 Bệnh tự miễn](https://bvnguyentriphuong.com.vn/noi-tim-mach/boc-tach-dong-mach-vanh#28-bnh-t-min)
  * [2.9 Bệnh mô liên kết di truyền](https://bvnguyentriphuong.com.vn/noi-tim-mach/boc-tach-dong-mach-vanh#29-bnh-m-lin-kt-di-truyn)
  * [2.10 Sử dụng các chất gây nghiện](https://bvnguyentriphuong.com.vn/noi-tim-mach/boc-tach-dong-mach-vanh#210-s-dng-cc-cht-gy-nghin)
  * [3. Bị bóc tách động mạch vành sống được bao lâu?](https://bvnguyentriphuong.com.vn/noi-tim-mach/boc-tach-dong-mach-vanh#3-b-bc-tch-ng-mch-vnh-sng-c-bao-lu)
  * [4. Các dấu hiệu cảnh báo tình trạng bóc tách mạch vành](https://bvnguyentriphuong.com.vn/noi-tim-mach/boc-tach-dong-mach-vanh#4-cc-du-hiu-cnh-bo-tnh-trng-bc-tch-mch-vnh)
  * [5. Chẩn đoán bệnh bóc tách động mạch vành](https://bvnguyentriphuong.com.vn/noi-tim-mach/boc-tach-dong-mach-vanh#5-chn-on-bnh-bc-tch-ng-mch-vnh)
  * [6. Điều trị và phòng ngừa mạch vành bóc tách](https://bvnguyentriphuong.com.vn/noi-tim-mach/boc-tach-dong-mach-vanh#6-iu-tr-v-phng-nga-mch-vnh-bc-tch)
  * [6.1 Điều trị bệnh bóc tách động mạch vành ](https://bvnguyentriphuong.com.vn/noi-tim-mach/boc-tach-dong-mach-vanh#61-iu-tr-bnh-bc-tch-ng-mch-vnh)



## Bệnh tim mạch ở người trẻ tuổi

**Nhiều thống kê của ngành y tế cho thấy, bệnh nhân tim mạch đang có xu hướng trẻ hóa khi độ tuổi mắc bệnh chỉ gần 40 tuổi. Điều này cho thấy, bệnh tim mạch ở người trẻ tuổi ngày càng có xu hướng gia tăng. Vậy, đâu là nguyên nhân làm nên xu hướng này?**
Bệnh tim mạch được ví như “kẻ giết người số 1” bởi đây là một trong những bệnh làm nên tỷ lệ tử vong cao nhất thế giới, là nỗi ám ảnh của toàn nhân loại. Bệnh tim mạch ở người trẻ tuổi đang ngày càng có xu hướng gia tăng mạnh trong cộng đồng những năm gần đây.
_Bệnh tim mạch ở người trẻ tuổi đang ngày càng có xu hướng gia tăng mạnh trong cộng đồng những năm gần đây._
Theo các chuyên gia tim mạch, nguyên nhân chính làm nênhiện tượng trẻ hóa này phần lớn là do lối sống kém lành mạnh của những người trẻ, như: Lười vận động, thức khuya, ăn uống không hợp lý, stress vì công việc…
**Cụ thể:** Đa phần người trẻ có tâm lý coi thường việc xây dựng thời gian biểu học tập, làm việc, nghỉ ngơi khoa học. Thói quen thức khuya, sử dụng nhiều chất kích thích (cà phê, thuốc lá, rượu…); ăn nhiều đồ ăn nhanh, đồ ăn đóng hộp có chứa chất bảo quản, dùng nhiều đồ ăn chiên, xào; lười vận động; để cơ thể thừa cân, béo phì… Đây là những nguyên nhân chính yếu có thể làm tăng nguy cơ mắc các bệnh về tim mạch ở người trẻ tuổi.
_Nguyên nhân chính làm nên hiện tượng trẻ hóa này phần lớn là do lối sống kém lành mạnh của những người trẻ, như: Lười vận động, thức khuya, ăn uống không hợp lý, stress vì công việc…_
Theo đó, khám sức khỏe định kỳ, xây dựng khẩu phần ăn cân bằng các dưỡng chất, ngủ sớm, hạn chế các chất kích thích có hại cho tim, vận động thường xuyên, duy trì cân nặng cơ thể ở mức phù hợp… là các biện pháp giúp phòng ngừa hữu hiệu bệnh tim mạch. Kiểm soát bệnh tim mạch ở người trẻ tuổi như thế nào? Hiểu biết để nhận biết sớm các bệnh về tim mạch có ý nghĩa quan trọng, giúp người bệnh chủ động phòng ngừa và điều trị bệnh sớm, tránh được những hậu quả đáng tiếc. Khám tim mạch thường xuyên tại các chuyên khoa tim mạch uy tín.
**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/) **- Đa khoa Hạng I Thành phố Hồ Chí Minh

## ️ Phương pháp chụp hình mạch máu

  * [Kỹ thuật chụp hình mạch máu là gì?](https://bvnguyentriphuong.com.vn/tim-mach-can-thiep/phuong-phap-chup-hinh-mach-mau#k-thut-chp-hnh-mch-mu-l-g)
  * [Vậy kỹ thuật chụp hình mạch máu được sử dụng trong các việc gì?](https://bvnguyentriphuong.com.vn/tim-mach-can-thiep/phuong-phap-chup-hinh-mach-mau#vy-k-thut-chp-hnh-mch-mu-c-s-dng-trong-cc-vic-g)
  * [Kỹ thuật này được thực hiện để chẩn đoán:](https://bvnguyentriphuong.com.vn/tim-mach-can-thiep/phuong-phap-chup-hinh-mach-mau#k-thut-ny-c-thc-hin-chn-on)
  * [Kỹ thuật chụp hình mạch máu còn được dùng để:](https://bvnguyentriphuong.com.vn/tim-mach-can-thiep/phuong-phap-chup-hinh-mach-mau#k-thut-chp-hnh-mch-mu-cn-c-dng-)


Kỹ thuật chụp hình mạch máu có thể giúp phát hiện các bất thường và dị dạng mạch máu bao gồm suy yếu thành mạch, các mảng bám trên thành mạch và huyết khối.
Bài viết sẽ cung cấp cái nhìn tổng quan về lợi công dụng, cách thực hiện, nguy cơ và tác dụng phụ của kỹ thuật hình ảnh học này.
Bài viết cũng sẽ cung cấp vài mẹo dành cho các bệnh nhân vừa mới thực hiện xong kỹ thuật để hồi phục nhanh hơn.
## **Kỹ thuật chụp hình mạch máu là gì?**
Thuật ngữ này được dùng để nói về rất nhiều kỹ thuật hình ảnh học khác nhau có thể được thực hiện để xác định xem các mạch máu bị hẹp hoặc tắc nghẽn hay không.
Hình ảnh học mạch máu còn giúp ích trong việc chẩn đoán các bệnh tim mạch, như xơ vữa động mạch vành, hẹp mạch máu, và phình mạch.
Để thực hiện kỹ thuật chụp hình mạch máu truyến thống thì một ống nhỏ và hẹp được gọi là catheter sẽ được đưa vào động mạch ở tay, trên đùi hay bẹn.
Thuốc tương phản sẽ được đưa vào thông qua catheter và tia X được dùng để chụp lại hình ảnh của các mạch máu. Thuốc tương phản sẽ giúp các mạch máu hiện rõ trên hình ảnh X quang.
Không phải kỹ thuật hình ảnh mạch máu nào cũng sử dụng máy X quang, các máy như CT, MRI cũng có thể được sử dụng.
Bệnh nhân có thể sẽ được chỉ định thực hiện kỹ thuật này nếu như:
  * Có triệu chứng của hẹp hay tắc động mạch, ví dụ như sau khi có kết quả thử nghiệm áp lực bất thường
  * Có cơn đau ngực mới hoặc bất thường
  * Đã từng bị đột quỵ, đau tim hoặc suy tim.


Suy tim là một trong những nguyên nhân tử vong thường gặp nhất. Chẩn đoán và điều trị sớm có thể làm giảm nguy cơ tử vong do bệnh tim mạch. Nhiều thủ thuật và kỹ thuật, bao gồm cả chụp hình mạch máu, được sử dụng trong việc chẩn đoán và điều trị các loại suy tim khác nhau.
## **Vậy kỹ thuật chụp hình mạch máu được sử dụng trong các việc gì?**
Kỹ thuật này được sử dụng để khảo sát các mạch máu trong cơ thể, bao gồm ở:
  * Tay và bàn tay
  * Chân và bàn chân


Trong khi thực hiện kỹ thuật, các bác sĩ sẽ để ý để phát hiện các dấu hiệu của bệnh tim mạch và các vấn đề của mạch máu.
### **Kỹ thuật này được thực hiện để chẩn đoán:**
  * Phình mạch máu xuất hiện ở nơi thành mạch bị yếu
  * Xơ vữa mạch máu, thường xảy ra ở vị trí các mảng bám và chất béo kết tụ lên trên thành trong của mạch máu
  * Huyết khối động mạch phổi
  * Hẹp mạch máu, ảnh hưởng đến các mạch máu ở não, tim và chân
  * Bất thường dị dạng mạch máu hoặc ở tim


### **Kỹ thuật chụp hình mạch máu còn được dùng để:**
  * Đánh giá sức khỏe mạch máu trước khi phẫu thuật
  * Để xác định các mạch máu cấp máu cho khối u
  * Để lên kế hoạch thực hiện các phương pháp điều trị như bắc cầu nối mạch vành, đặt stent hoặc hóa trị


Để đánh giá stent sau khi đặt
Xem tiếp: [**Kỹ thuật chụp hình mạch máu được tiến hành như thế nào?**](https://bvnguyentriphuong.com.vn/tim-mach-can-thiep/ky-thuat-chup-hinh-mach-mau-duoc-tien-hanh-nhu-the-nao)
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [Kỹ thuật chụp hình mạch máu là gì?](https://bvnguyentriphuong.com.vn/tim-mach-can-thiep/phuong-phap-chup-hinh-mach-mau#k-thut-chp-hnh-mch-mu-l-g)
  * [Vậy kỹ thuật chụp hình mạch máu được sử dụng trong các việc gì?](https://bvnguyentriphuong.com.vn/tim-mach-can-thiep/phuong-phap-chup-hinh-mach-mau#vy-k-thut-chp-hnh-mch-mu-c-s-dng-trong-cc-vic-g)
  * [Kỹ thuật này được thực hiện để chẩn đoán:](https://bvnguyentriphuong.com.vn/tim-mach-can-thiep/phuong-phap-chup-hinh-mach-mau#k-thut-ny-c-thc-hin-chn-on)
  * [Kỹ thuật chụp hình mạch máu còn được dùng để:](https://bvnguyentriphuong.com.vn/tim-mach-can-thiep/phuong-phap-chup-hinh-mach-mau#k-thut-chp-hnh-mch-mu-cn-c-dng-)



## ️ Nhồi máu cơ tim có ST chênh (STEMI) và Nhồi máu cơ tim không ST chênh (NSTEMI)

  * [1. Giải phẫu động mạch vành tim](https://bvnguyentriphuong.com.vn/tim-mach-can-thiep/nhoi-mau-co-tim-co-st-chenh-stemi-va-nhoi-mau-co-tim-khong-st-chenh-nstemi#1-gii-phu-ng-mch-vnh-tim)
  * [2. STEMI và NSTEMI](https://bvnguyentriphuong.com.vn/tim-mach-can-thiep/nhoi-mau-co-tim-co-st-chenh-stemi-va-nhoi-mau-co-tim-khong-st-chenh-nstemi#2-stemi-v-nstemi)
  * [3. Triệu chứng của nhồi máu cơ tim không ST chênh lên](https://bvnguyentriphuong.com.vn/tim-mach-can-thiep/nhoi-mau-co-tim-co-st-chenh-stemi-va-nhoi-mau-co-tim-khong-st-chenh-nstemi#3-triu-chng-ca-nhi-mu-c-tim-khng-st-chnh-ln)
  * [4. Triệu chứng nhồi máu cơ tim ST chênh lên](https://bvnguyentriphuong.com.vn/tim-mach-can-thiep/nhoi-mau-co-tim-co-st-chenh-stemi-va-nhoi-mau-co-tim-khong-st-chenh-nstemi#4-triu-chng-nhi-mu-c-tim-st-chnh-ln)


Thuật ngữ “nhồi máu cơ tim có ST chênh” (ST-segment elevation myocardial infarction, STEMI) được hiểu đầy đủ là nhồi máu cơ tim có ST chênh lên. Còn “nhồi máu cơ tim không ST chênh” (Non ST-segment elevation myocardial infarction, NSTEMI) nghĩa là đoạn ST không chênh hoặc chênh xuống. Đây là các dấu hiệu cơ bản trên ECG giúp gợi ý bệnh lý mạch vành tim. Vậy vấn đề đặt ra là tại sao trong nhồi máu cơ tim, đều có sự hủy hoại tế bào cơ tim và giải phóng men tim nhưng 1 bên có ST chênh, 1 bên thì không?
## **1. Giải phẫu động mạch vành tim**
Tim được cấp máu từ 2 nguồn: động mạch vành trái và động mạch vành phải xuất phát ở gốc động mạch chủ qua trung gian là những xoang Valsalva, chạy trên bề mặt của tim (giữa cơ tim và ngoại tâm mạc). Những xoang Valsalva có vai trò như một bình chứa để duy trì một cung lượng vành khá ổn định.
  * Động mạch vành trái (LCA): Sau khi chạy một đoạn ngắn (thân chung ĐMV trái) giữa động mạch phổi và nhĩ trái, LMCA chia ra thành 2 nhánh: động mạch liên thất trước (LAD) và động mạch mũ (LCx).


+ LAD chạy dọc theo rãnh liên thất trước về phía mỏm tim, phân thành những nhánh vách và nhánh chéo.
+ Động mạch mũ: chạy trong rãnh nhĩ thất, có vai trò rất thay đổi tùy theo sự ưu năng hay không của ĐMV phải, cấp máu cho thành bên của thất trái.
  * Động mạch vành phải (RCA): Có nguyên ủy từ xoang Valsalva trước phải, chạy trong rãnh nhĩ thất phải. Ở đoạn gần cho nhánh vào nhĩ (động mạch nút xoang) và thất phải (động mạch phễu) rồi vòng ra bờ phải chia thành nhánh động mạch liên thất sau và quặt ngược thất trái.


## **2. STEMI và NSTEMI**
Tại sao trong nhồi máu cơ tim, đều có sự hủy hoại tế bào cơ tim, giải phóng men tim nhưng có trường hợp ST chênh, có trường hợp lại không? Khi cục máu đông đủ lớn, duy trì vài phút, đủ để gây tắc nghẽn mạch vành khiến tế bào cơ tim bị hoại tử do thiếu máu nuôi. Khi tế bào cơ tim chết có nghĩa là có nhồi máu cơ tim.
(1) Nhồi máu cơ tim có ST chênh lên (STEMI): xảy ra khi động mạch vành bị block hoàn toàn, một lượng lớn tế bào cơ tim được cung cấp máu bởi động mạch vành đó bị chết.
(2) Nhồi máu cơ tim không có ST chênh lên (NSTEMI): xảy ra khi sự block động mạch vành chỉ một phần, đủ để làm tổn thương tế bào cơ tim nhưng không rộng rãi như trong STEMI, chỉ nhồi máu vùng cơ tim sát nội tâm mạc – vùng nằm sâu nhất và chịu áp lực thì tâm thu lớn nhất -> ST chênh xuống hoặc không chênh.
Như vậy, sự khác nhau giữa ST chênh và không chênh lên là do sự tắc nghẽn hoàn toàn hay không hoàn toàn mạch vành. Tắc nghẽn hoàn toàn sẽ gây nhồi máu toàn bộ thành cơ tim, ST chênh vòm lên, nếu để lâu không can thiệp sẽ dẫn tới hoại tử thành cơ tim, xuất hiện Q hoại tử trên ECG. Còn tắc nghẽn không hoàn toàn thì chỉ nhồi máu dưới nội tâm mạc, ST chênh xuống hoặc không chênh, T đảo ngược và không có Q hoại tử.
## **3. Triệu chứng của nhồi máu cơ tim không ST chênh lên**
Lâm sàng: Khoảng 20% các trường hợp **nhồi máu cơ tim** là thầm lặng, thoáng qua, người bệnh thường không có triệu chứng gì hoặc các triệu chứng không rõ ràng dẫn đến không nhận ra bệnh, đặc biệt thường thấy ở bệnh nhân tiểu đường. **Đau thắt ngực không ổn định** là một trong các biểu hiện của**nhồi máu cơ tim không ST chênh lên.** Các triệu chứng có thể xảy ra ở **nhồi máu cơ tim không ST chênh lên** như:
  * Triệu chứng cơ năng: Thường xuất hiện vài ngày đến vài tuần trước khi xảy ra**nhồi máu cơ tim**.
    * Đau tức, nặng sau xương ức, lan ra ở lưng, cánh tay, hàm, vai,... đau nghiêm trọng với thời gian kéo dài.
    * Khó thở, đặc biệt là ở người lớn tuổi.
    * Vã mồ hôi, da nhợt nhạt.
    * Sợ hãi, bồn chồn.
    * Nôn, buồn nôn thường gặp ở **nhồi máu cơ tim** thành dưới.
    * Cơn đau có thể giảm nhẹ khi nghỉ ngơi hoặc dùng **nitroglycerin**.
    * Suy nhược, phù phổi, sốc, loạn nhịp tim.
    * Tím trung ương hoặc ngoại biên.
    * Mạch yếu, huyết áp thay đổi.
    * Có thể ngất.
  * Triệu chứng thực thể: Khoảng 15% bệnh nhân có đau thành ngực, nghe tim có tiếng thổi tâm thu ở mỏm tim.
  * Cận lâm sàng:
    * Có tăng men tim trong máu: Nồng độ Troponin I hoặc Troponin T và CK tăng.
    * Trên điện tâm đồ, không có sự chênh lên của đoạn ST, có sự thay đổi đoạn ST như chênh xuống, đảo ngược sóng T.


## **4. Triệu chứng nhồi máu cơ tim ST chênh lên**
  * Đau ngực tương tự đau thắt ngực nhưng nặng và kéo dài hơn; không giảm hoàn toàn khi nghỉ hoặc dùng nitroglycerin, thường kèm theo nôn, vã mồ hôi, và cảm giác lo lắng. Tuy nhiên, khoảng 25% trường hợp nhồi máu không có biểu hiện lâm sàng.
  * Thăm khám thực thể nhồi máu cơ tim ST chênh lên
  * Xanh xao, vã mồ hôi, nhịp tim nhanh, T4, rối loạn hoạt động cơ tim có thể gặp.
  * Nếu có suy tim sung huyết, có thể nghe tiếng ran và T3. Tĩnh mạch cổ nổi thường thấy trong trường hợp nhồi máu thất phải.
  *     * ST chênh lên, theo sau bởi (nếu không được tái tưới máu ngay) sóng T đảo ngược, sau đó xuất hiện sóng Q sau khoảng vài giờ


**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [1. Giải phẫu động mạch vành tim](https://bvnguyentriphuong.com.vn/tim-mach-can-thiep/nhoi-mau-co-tim-co-st-chenh-stemi-va-nhoi-mau-co-tim-khong-st-chenh-nstemi#1-gii-phu-ng-mch-vnh-tim)
  * [2. STEMI và NSTEMI](https://bvnguyentriphuong.com.vn/tim-mach-can-thiep/nhoi-mau-co-tim-co-st-chenh-stemi-va-nhoi-mau-co-tim-khong-st-chenh-nstemi#2-stemi-v-nstemi)
  * [3. Triệu chứng của nhồi máu cơ tim không ST chênh lên](https://bvnguyentriphuong.com.vn/tim-mach-can-thiep/nhoi-mau-co-tim-co-st-chenh-stemi-va-nhoi-mau-co-tim-khong-st-chenh-nstemi#3-triu-chng-ca-nhi-mu-c-tim-khng-st-chnh-ln)
  * [4. Triệu chứng nhồi máu cơ tim ST chênh lên](https://bvnguyentriphuong.com.vn/tim-mach-can-thiep/nhoi-mau-co-tim-co-st-chenh-stemi-va-nhoi-mau-co-tim-khong-st-chenh-nstemi#4-triu-chng-nhi-mu-c-tim-st-chnh-ln)



## Dấu hiệu xơ vữa động mạch điều trị cũng như ngừa bệnh

_**Xơ vữa động mạch là một trong những nguyên nhân gây nhồi máu cơ tim, đột quỵ não nguy hiểm. Việc nhận biết sớm dấu hiệu xơ vữa động mạch có vai trò quan trọng trong điều trị cũng như ngừa bệnh**_
Xơ vữa động mạch là một bệnh lý nguy hiểm có diễn biến âm thầm và không có dấu hiệu nhận biết ban đầu. Phần lớn người bị xơ vữa động mạch đều không biết mình có bệnh và chỉ bắt đầu điều trị khi động mạch bị hẹp một cách trầm trọng hoặc bị tắc hoàn toàn một động mạch có thể gây nhồi máu cơ tim, hay đột quỵ não.
_Xơ vữa động mạch ở não gây đau nhức đầu dữ dội_
**Những dấu hiệu xơ vữa động mạch**
Dấu hiệu xơ vữa động mạch có sự khác nhau tùy thuộc vào từng vị trí:
  * Xơ vữa động mạch cảnh – động mạch cung cấp máu lên não, có thể gây suy yếu đột ngột, người bệnh có dấu hiệu khó thở, nhức đầu, nói khó, tê liệt, nhìn khó một mắt hoặc cả hai mắt.
  * Xơ vữa động mạch vành – động mạch cung cấp máu nuôi tim gây đau thắt ngực, nôn mửa, hốt hoảng, đau ngực, ho…


_Đau thắt ngực là triệu chứng thường gặp khi bị động mạch vành_
Xơ vữa động mạch thận – động mạch cung cấp máu đến thận, người bệnh có triệu chứng mất cảm giác ngon miệng, phù bàn tay và bàn chân và khó tập trung…
Xơ vữa động mạch ngoại biên – các động mạch chân tay, hay gặp ở động mạch chân bị xơ vữa. Người bệnh có cảm giác đau chân ở một hoặc cả hai chân, chuột rút, ở nam có rối loạn cương dương, tê ở chân, màu sắc của da chân thay đổi, chân yếu…
**Điều trị và phòng ngừa xơ vữa động mạch**
Nhận biết sớm dấu hiệu xơ vữa động mạch có giá trị cao trong điều trị, bởi nếu xơ vữa động mạch không phát hiện và điều trị phù hợp có thể gây những biến chứng nguy hiểm như cơn nhồi máu cơ tim cấp, đột quỵ não,…Việc điều trị xơ vữa đông mạch giúp giảm triệu chứng đồng thời giảm các yếu tố nguy cơ gây xơ vữa động mạch; giảm nguy cơ hình thành cục máu đông,…
_Khó thở, khó nói, tê liệt chân tay,…là triệu chứng cơn đột quỵ não -biến chứng của xơ vữa động mạch_
Để phòng ngừa xơ vữa động mạch, ngoài chế độ điều trị theo hưỡng dẫn của bác sĩ, người bệnh cần ăn uống lành mạnh, năng hoạt động thể chất, phòng tránh thừa cân. Nên bổ sung nhóm thực phẩm giàu chất xơ, giảm ăn mặn, giảm các loại thức ăn có nhiều cholesterol; hạn chế uống rượu bia; tập thể dục đều đặn hàng ngày; bỏ hút thuốc lá thuốc lào; tránh căng thẳng về thể chất và tinh thần…
**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/) **- Đa khoa Hạng I Thành phố Hồ Chí Minh

## ️ Bạn cần làm gì khi huyết áp thấp?

**1. Biện pháp dự phòng cho bệnh nhân huyết áp thấp?**
_Người bị huyết áp thấp có trị số huyết áp tâm thu dưới 90mmHg và huyết áp tâm trương dưới 60mmHg, hoặc giảm hơn 20mmHg so với trị số huyết áp bình thường trước đó_
– Thay đổi tư thế đúng: Khi ngủ máu sẽ tập trung vào gan, phổi, lách, nên gây ra tình trạng thiếu máu não tạm thời. Vì vậy, khi thức dậy bạn cần nằm thêm một lúc, có thể làm vài động tác khởi động đơn giản trước khi ngồi dậy. Trong sinh hoạt hàng ngày nên tránh thay đổi tư thế đột ngột, hít thở sâu vài phút trước khi đứng lên nhằm làm tăng cường lưu thông máu đến các bộ phận của cơ thể.
– Tránh trèo cao, đi ra nắng gắt hoặc để bị lạnh đột ngột, đắc biệt lúc đêm khuya.
– Nếu có dấu hiệu hoa mắt, chóng mặt, mệt mỏi, nên nằm nghỉ ngơi ở tư thế đầu thấp để tăng lượng máu lên não.
– Luyện tập thể dục thể thao đều đặn, phù hợp với sức khoẻ và độ tuổi, giúp duy trì lưu thông máu trong cơ thể nên giảm chứng huyết áp thấp.
– Cần thận trọng khi xông hơi hay tắm nước nóng nhằm tránh nguy cơ tụt huyết áp do mất nước, hay giãn mạch.
– Người bị huyết áp thấp vẫn có thể mắc bệnh tăng huyết áp, đặc biệt ở tuổi trên 50, vì vậy bạn cần thường xuyên theo dõi huyết áp để có thể điều chỉnh cho hợp lý.
_Người tụt huyết áp thường có triệu chứng hoa mắt, chóng mặt,…_
**2. Người bệnh huyết áp thấp nên ăn uống như thế nào?**
– Ăn đủ các bữa, không nên bỏ bữa sáng: Các chuyên gia khuyến cáo nên ăn sáng với những thực phẩm tốt cho tim mạch và các loại nước hoa quả ép (có thể thêm một ít muối) sẽ giúp máu được lưu thông dễ dàng hơn.
– Nên tăng muối vào khẩu phần ăn so với người bình thường (10-15g/ngày). Nếu không may mắc bệnh tim cần tham khảo ý kiến bác sĩ trước khi điều chỉnh sang chế độ ăn này.
– Nên giảm các loại thực phẩm giàu carbon hydrate trong khẩu phần ăn như khoai tây, cơm gạo và bánh mỳ; không nên ăn quá nhiều chất bổ dưỡng chẳng hạn như trứng, thịt mỡ, sữa béo, tránh béo phì. Tăng lượng rau quả, thịt lườn gà và cá trong chế độ ăn.
– Bên cạnh đó, sữa, mật ong, nước chanh pha đường và muối cũng mang lại tác dụng đáng kể, dùng nước khoáng mặn hàng ngày càng tốt.
– Uống đủ lượng nước: Nếu cơ thể bị thiếu nước sẽ dễ xảy ra tình trạng bị khử nước. Điều này đặc biệt quan trọng khi đang luyện tập hoặc hoạt động, làm việc dưới điều kiện thời tiết nắng nóng.
_Khi mắc huyết áp thấp người bệnh cần thường xuyên theo dõi sức khỏe, xây dựng lối sống khoa học để huyết áp được cải thiện_
– Ăn thành nhiều bữa nhỏ. Thay vì việc chỉ ăn 3 bữa chính như thông thường, người huyết áp thấp nê chia thành nhiều bữa nhỏ. Cần bổ sung thêm các loại thực phẩm có chứa các thành phần như protein, vitamin C và tất cả các loại vitamin thuộc nhóm B rất có lợi.
– Nếu huyết áp thấp do thiếu máu (hay gặp ở phụ nữ), nên tăng cường thức ăn chứa nhiều sắt chẳng hạn thịt nạc, gan động vật, mộc nhĩ, nấm hương khô, cần tây, rau đay, rau rền, quả lựu, táo.
– Tránh xa các loại đồ uống có cồn, vì sử dụng đồ uống có cồn gây mất nước trong cơ thể.
**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/) **- Đa khoa Hạng I Thành phố Hồ Chí Minh

## ️ Kỹ thuật chụp hình mạch máu được tiến hành như thế nào?

  * [Quá trình thực hiện](https://bvnguyentriphuong.com.vn/tim-mach-can-thiep/ky-thuat-chup-hinh-mach-mau-duoc-tien-hanh-nhu-the-nao#qu-trnh-thc-hin)
  * [Sau khi thực hiện xong](https://bvnguyentriphuong.com.vn/tim-mach-can-thiep/ky-thuat-chup-hinh-mach-mau-duoc-tien-hanh-nhu-the-nao#sau-khi-thc-hin-xong)
  * [QUÁ TRÌNH PHỤC HỒI](https://bvnguyentriphuong.com.vn/tim-mach-can-thiep/ky-thuat-chup-hinh-mach-mau-duoc-tien-hanh-nhu-the-nao#qu-trnh-phc-hi)
  * [CHỤP HÌNH MẠCH MÁU VÀ NONG MẠCH](https://bvnguyentriphuong.com.vn/tim-mach-can-thiep/ky-thuat-chup-hinh-mach-mau-duoc-tien-hanh-nhu-the-nao#chp-hnh-mch-mu-v-nong-mch)


Kỹ thuật chụp hình mạch máu có thể giúp phát hiện các bất thường và dị dạng mạch máu bao gồm suy yếu thành mạch, các mảng bám trên thành mạch và huyết khối.
## **Chuẩn bị**
Bệnh nhân sẽ được giải thích quá trình chuẩn bị trước khi thực hiện kỹ thuật. Trong hầu hết các trường hợp thì bệnh nhân nên nhịn ăn và uống vào đêm trước khi thực hiện kỹ thuật.
Bệnh nhân cũng nên sắp xếp sẵn người để đón mình về từ bệnh viện.
Nên nhớ mang theo các vật dụng sau:
  * Danh sách các thuốc uống và thực phẩm chức năng đang dùng
  * Danh sách các dị ứng mắc phải đã biết trước
  * Các giấy tờ lý lịch
  * Các thông tin bảo hiểm y tế


Sau khi đã xong thủ tục nhập viên, nhân viên y tế sẽ hướng dẫn bệnh nhân thay trang phục để thực hiện kỹ thuật.
Bệnh nhân sẽ được đặt đường truyền tĩnh mạch và sau đó kiểm tra các dấu hiệu sinh tồn bao gồm cân nặng, nhiệt độ, nhịp tim và huyết áp.
## **Quá trình thực hiện**
Bệnh nhân sẽ được gây tê để giúp thư giãn nhưng sẽ không mất ý thức.
Vị trí đặt catheter sẽ được sát trùng và sau đó cắt một lỗ nhỏ để luồng catheter vào bên trong động mạch.
Khi catheter đã được đặt vào bên trong động mạch, nó sẽ được luồng nhẹ nhàng đến vị trí cần được khảo sát. Thuốc tương phản sau đó sẽ được đưa vào mạch máu và tia X sẽ được dùng để ghi lại hình ảnh các mạch máu. Bệnh nhân có thể sẽ cảm thấy hơi bỏng rát nhẹ khi được tiêm thuốc.
## **Sau khi thực hiện xong**
Sau khi đã chụp xong hình X quang, ống catheter sẽ được rút ra và vị trí đó sẽ được đè ấn nhẹ lên trong vòng 15 phút để đảm bảo không có xuất huyết nội nào xảy ra.
Bệnh nhân sẽ được nhân viên y tế đưa về phòng bệnh hoặc khoa tim mạch. Kết quả sẽ được bác sĩ thông báo sau.
## **KẾT QUẢ**
Kỹ thuật này được thực hiện nhằm đánh giá dòng chảy ở các mạch máu đến tim, não và các cơ quan khác. Kết quả bất thường có thể gợi ý rằng bệnh nhân có một hoặc nhiều mạch máu bị tắc nghẽn.
Trong các trường hợp đó, các mạch máu bị tắc nghẽn có thể được điều trị luôn ngay trong quá trình thực hiện kỹ thuật.
## **CÁC NGUY CƠ**
Nguy cơ xảy ra biến chứng nặng sau khi thực hiện hầu như rất thấp. Tuy nhiên, kỹ thuật xâm lấn này cũng có các nguy cơ riêng, chủ yếu liên quan đến quá trình đưa catheter đến tim.
Các bệnh nhân lớn tuổi và các bệnh nhân có một số bệnh khác như suy thận mạn hay tiểu đường có nguy cơ xảy ra biến chứng cao hơn.
Các nguy cơ liên quan đến đặt catheter tim và kỹ thuật chụp hình mạch máu bao gồm:
  * Phản ứng dị ứng với thuốc tê tại chỗ, thuốc tương phản.
  * Chảy máu, bầm hoặc đau tại vị trí đặt catheter
  * Huyết khối
  * Tổn thương mạch máu
  * Tổn thương thành tim
  * Suy thận cấp
  * Nhiễm trùng
  * Rối loạn nhịp tim
  * Cơn đau tim, đột quỵ, mặc dù tỉ lệ xảy ra rất thấp


Những bệnh nhân đã có tiền căn bị dị ứng với chất tương phản thì cần dùng thuốc để làm giảm nguy cơ xảy ra thêm một phản ứng dị ứng nữa. Bệnh nhân nên dùng thuốc này 24 giờ trước khi thực hiện kỹ thuật.
Để loại bỏ hoàn toàn nguy cơ xảy ra phản ứng dị ứng thì một kỹ thuật khảo sát khác nên được sử dụng thay vì kỹ thuật chụp hình mạch máu truyền thống.
## **QUÁ TRÌNH PHỤC HỒI**
Sau khi thực hiện xong, bệnh nhân nên nghỉ ngơi tại nhà càng nhiều càng tốt. Các mẹo nên nhớ trong quá trình thực hiện thủ thuật:
  * Hạn chế lái xe hay sử dụng các loại máy móc cho đến khi thuốc tê hoàn toàn hết tác dụng
  * Uống nhiều nước
  * Hạn chế thực hiện các hoạt động nặng trong vòng vài ngày
  * Sử dụng băng y tế theo hướng dẫn
  * Giữ vết thương khô và sạch
  * Hạn chế tắm rửa, tắm bồn hoặc bơi lội trong quá trình lành vết thương


Bệnh nhân nên đi khám ngay nếu như nghi ngờ vết thương bị nhiễm trùng. Các triệu chứng của nhiễm trùng bao gồm:
  * Sưng, đỏ, đau gần vết thương
  * Dịch tiết ra từ vết thương


## **CHỤP HÌNH MẠCH MÁU VÀ NONG MẠCH**
Trong thủ thuật nong mạch máu, một dụng cụ có bong bóng hoặc lưới sẽ được đặt vào trong mạch máu bị tắc nghẽn hay hẹp. Khi chúng được đặt vào đúng vị trí thì lưới hoặc bong bóng sẽ được bung ra hoặc bơm lên để cải thiện được dòng chảy tại mạch máu đó.
Thủ thuật nong mạch thường được kết hợp khi thực hiện kỹ thuật chụp hình mạch máu.
## **TÓM TẮT**
Kỹ thuật chụp hình mạch máu được sử dụng để khảo sát các mạch máu. Kết quả của kỹ thuật có thể giúp các bác sĩ chẩn đoán và điều trị các bệnh mạch máu và tim mạch.
Trong quá trình thực hiện, một ống catheter sẽ được đưa nhẹ nhàng vào động mạch cho đến khi nó đi đến được vị trí cần được khảo sát. Sau khi đã đến nơi, thuốc tương phản sẽ được bơm vào và hình ảnh của mạch máu đó sẽ được ghi lại.
Mặc dù hiếm khi gặp nhưng kỹ thuật này cũng có một số tác dụng phụ bao gồm:
  * Chảy máu
  * Nhiễm trùng
  * Huyết khối
  * Tổn thương mạch máu
  * Tổn thương thành tim
  * Rối loạn nhịp tim


Bệnh nhân nên đi khám ngay nếu như gặp các triệu chứng trên sau khi thực hiện kỹ thuật.
Xem thêm: [**Can thiệp động mạch đùi nông**](https://bvnguyentriphuong.com.vn/ngoai-tong-hop/can-thiep-dong-mach-dui-nong)
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [Quá trình thực hiện](https://bvnguyentriphuong.com.vn/tim-mach-can-thiep/ky-thuat-chup-hinh-mach-mau-duoc-tien-hanh-nhu-the-nao#qu-trnh-thc-hin)
  * [Sau khi thực hiện xong](https://bvnguyentriphuong.com.vn/tim-mach-can-thiep/ky-thuat-chup-hinh-mach-mau-duoc-tien-hanh-nhu-the-nao#sau-khi-thc-hin-xong)
  * [QUÁ TRÌNH PHỤC HỒI](https://bvnguyentriphuong.com.vn/tim-mach-can-thiep/ky-thuat-chup-hinh-mach-mau-duoc-tien-hanh-nhu-the-nao#qu-trnh-phc-hi)
  * [CHỤP HÌNH MẠCH MÁU VÀ NONG MẠCH](https://bvnguyentriphuong.com.vn/tim-mach-can-thiep/ky-thuat-chup-hinh-mach-mau-duoc-tien-hanh-nhu-the-nao#chp-hnh-mch-mu-v-nong-mch)



## Bệnh động mạch vành là gì? Điều trị ra sao?

  * [Nguyên nhân gây bệnh động mạch vành](https://bvnguyentriphuong.com.vn/tim-mach-can-thiep/benh-dong-mach-vanh-la-gi-dieu-tri-ra-sao#nguyn-nhn-gy-bnh-ng-mch-vnh)
  * [Chẩn đoán và điều trị bệnh động mạch vành như thế nào?](https://bvnguyentriphuong.com.vn/tim-mach-can-thiep/benh-dong-mach-vanh-la-gi-dieu-tri-ra-sao#chn-on-v-iu-tr-bnh-ng-mch-vnh-nh-th-no)
  * [Điều trị nội khoa](https://bvnguyentriphuong.com.vn/tim-mach-can-thiep/benh-dong-mach-vanh-la-gi-dieu-tri-ra-sao#iu-tr-ni-khoa)
  * [Điều trị can thiệp động mạch vành](https://bvnguyentriphuong.com.vn/tim-mach-can-thiep/benh-dong-mach-vanh-la-gi-dieu-tri-ra-sao#iu-tr-can-thip-ng-mch-vnh)
  * [Điều trị phẫu thuật bắc cầu động mạch vành](https://bvnguyentriphuong.com.vn/tim-mach-can-thiep/benh-dong-mach-vanh-la-gi-dieu-tri-ra-sao#iu-tr-phu-thut-bc-cu-ng-mch-vnh)


Bệnh động mạch vành là thuật ngữ dùng để chỉ tình trạng bệnh lý làm cho lòng động mạch vành bị hẹp lại (hoặc gây tắc nghẽn), tình trạng này còn được gọi xơ vữa động mạch.
Bệnh động mạch vành xảy ta khi lòng động mạch vành bị hẹp khiến dòng máu đến nuôi tim sẽ không đủ và dẫn đến tình trạng thiếu máu cơ tim. Bệnh còn có một số tên gọi khác như: suy động mạch vành, thiếu máu cơ tim, thiểu năng vành, bệnh tim thiếu máu cục bộ.
## **Nguyên nhân gây bệnh động mạch vành**
_Bệnh còn có một số tên gọi khác như: suy động mạch vành, thiếu máu cơ tim, thiểu năng vành_
Việc tìm hiểu và nắm rõ nguyên nhân gây bệnh động mạch vành không chỉ có tác dụng trong điều trị, mà còn giúp loại bỏ những nguy cơ gây bệnh, có vai trò trong phòng ngừa bệnh.
Hầu hết bệnh nhân bị động mạch vành là do xơ vữa động mạch gây nên. Nguyên nhân của xơ vữa động mạch vẫn chưa được xác định rỏ ràng. Tuy nhiên, có một số yếu tố nguy cơ là tăng khả năng mắc bệnh như: tăng huyết áp, rối loạn lipid máu (LDL cao, HDI thấp, Triglyceride cao). Người hút thuốc lá, người có bệnh đáo=I tháo đường, béo phì, yếu tố bệnh sử gia đình, người cao tuổi,…
Hẹp lòng động mạch vành sẽ gây ra tình trạng thiếu máu cơ tim, với triệu chứng đau ngực, suy tim, rối loạn nhịp tim và nguy cơ bị nhồi máu cơ tim cấp.
Khi những mảng xơ vữa trong lòng động mạch vành vỡ ra sẽ làm bít tắc hoàn toàn động mạch vành và gây ra thiếu máu cơ tim cấp tính, hoại tử cơ tim – còn được gọi là nhồi máu cơ tim cấp. Tỷ lệ tử vong do nhồi máu cơ tim cấp rất cao hoặc nếu qua khỏi thì những di chứng để lại cũng rất nguy hiểm, bệnh nhân có thể sẽ bị suy tim sau nhồi máu cơ tim, bị rối loạn nhịp tim sau nhồi máu cơ tim.
_Hút thuốc lá là một trong những nguy cơ làm tăng khả năng mắc bệnh_
## **Chẩn đoán và điều trị bệnh động mạch vành như thế nào?**
Chẩn đoán dựa vào điện tâm đồ. Tình trạng thiếu máu cơ tim làm thay đổi về tính chất diện học của tim. Do đó, điện tâm đồ có thể phát hiện được những thay đổi về điện học đó.
Siêu âm tim: Thiếu máu cơ tim làm ảnh hưởng đến sự co bóp của tim. Thiếu máu cơ tim ở vùng nào thì cơ tim ở vùng đó sẽ bị rối loạn. Siêu âm tim cũng là một phương tiện giúp bác sĩ thấy được sự co bóp của cơ tim. Theo đó, những vùng giảm động do thiếu máu cơ tim gây ra sẽ được phát hiện bởi siêu âm tim.
Điện tâm đồ và siêu âm tim lúc gắng sức: khi lòng động mạch vànhchỉ hẹp ở một mức độ vừa phải thì triệu chứng thiếu máu cơ tim chỉ xảy ra khi gắng sức. Tức là bệnh nhân chỉ đau ngực khi gắng sức, theo đó những thay đổi về điện tâm đồ và về siêu âm tim chỉ xuất hiện khi bệnh nhân gắng sức mà thôi. Vì vậy, có rất nhiều trường hợp bị thiếu máu cơ tim nhưng điện tâm đồ và siêu âm tim hoàn toàn bình thường. Trong những trường họp này, điện tâm đồ họăc siêu âm tim cần thực hiện lúc gắng sức. Chụp động mạch vành chọn lọc, cản quang. Phương pháp nàu được xem là tiêu chuẩn vàng giúp chẩn đoán bệnh động mạch vành. Các bác sĩ sẽ nắm được tình trạng của hệ thống động mạch vành của bệnh nhân: hẹp, tắc, bao nhiêu mạch máu bị tổn thương…
**Điều trị bệnh động mạch vành hiện tại có 3 phương pháp**
### _**Điều trị nội khoa**_
Điều trị dựa theo các yếu tố nguy cơ của bệnh động mạch vành để bệnh không tiến triển nặng thêm như: điều trị rối loạn lipide máu, điều trị tăng huyết áp, điều trị đái tháo đường, bỏ hút thuốc lá, giảm cân nặng đạt cân nặng lý tưởng, thay đổi thói quen sinh hoạt,.. Điều trị chống cơn đau thắt ngực bằng các loại thuốc dãn mạch.
### _**Điều trị can thiệp động mạch vành**_
Dùng cho các trường hợp đau ngực do thiếu máu cơ tim mà ít hoặc không đáp ứng với thuốc điều trị nội khoa; hoặc trường hợp bị đau thắt ngực không ổn định hay cơn nhồi máu cơ tim cấp.
### _**Điều trị phẫu thuật bắc cầu động mạch vành**_
Dùng cho các trường hợp động mạch vành bị tổn thương nhiều, kéo dài… Đây là một phẫu thuật lớn, dùng các mạch máu khác của ngay chính bản thân bệnh nhân để làm cầu nối qua chỗ động mạch vành bị hẹp.
**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/) **- Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [Nguyên nhân gây bệnh động mạch vành](https://bvnguyentriphuong.com.vn/tim-mach-can-thiep/benh-dong-mach-vanh-la-gi-dieu-tri-ra-sao#nguyn-nhn-gy-bnh-ng-mch-vnh)
  * [Chẩn đoán và điều trị bệnh động mạch vành như thế nào?](https://bvnguyentriphuong.com.vn/tim-mach-can-thiep/benh-dong-mach-vanh-la-gi-dieu-tri-ra-sao#chn-on-v-iu-tr-bnh-ng-mch-vnh-nh-th-no)
  * [Điều trị nội khoa](https://bvnguyentriphuong.com.vn/tim-mach-can-thiep/benh-dong-mach-vanh-la-gi-dieu-tri-ra-sao#iu-tr-ni-khoa)
  * [Điều trị can thiệp động mạch vành](https://bvnguyentriphuong.com.vn/tim-mach-can-thiep/benh-dong-mach-vanh-la-gi-dieu-tri-ra-sao#iu-tr-can-thip-ng-mch-vnh)
  * [Điều trị phẫu thuật bắc cầu động mạch vành](https://bvnguyentriphuong.com.vn/tim-mach-can-thiep/benh-dong-mach-vanh-la-gi-dieu-tri-ra-sao#iu-tr-phu-thut-bc-cu-ng-mch-vnh)



## ️ Nhiều bệnh nhân trẻ đột ngột ngưng tim, ngưng thở ngoài bệnh viện

**Đột ngột ngưng tim, ngưng thở khi tham gia các sinh hoạt thường nhật**
Cách nhập viện 15 phút, anh Trần H. T (1978, Quận 7) đang làm việc tại công trường đột ngột tím tái, khó thở, sau đó ngất đi. Anh được đồng nghiệp phát hiện nên đưa vào bệnh viện Quận 7 trong tình trạng ngưng tim ngưng thở. Mạch và huyết áp không đo được. 
Bệnh nhân được các bác sĩ và điều dưỡng của bệnh viện này tiến hành hồi sức tim phổi nâng cao với ấn tim ngoài lồng ngực, bóp bóng giúp thở, đặt nội khí quản. Monitor của bệnh nhân báo rung thất và được xử lý sốc điện 3 lần. đo lại điện tim lúc này là một tình trạng nhồi máu cơ tim cấp. 
Sau hồi sức tích cực khoảng 15 phút, tim bệnh nhân đập lại, mạch và huyết áp đo được nên được hội chẩn qua điện thoại và chuyển ngay qua Bệnh viện Nguyễn Tri Phương. Thời gian vận chuyển khoảng 15 phút. Sau khi tiếp nhận bệnh nhân, các bác sĩ cấp cứu đã hội chẩn ngay với bác sĩ chuyên khoa tim mạch can thiệp, chẩn đoán lúc này là một trường hợp nhồi máu cơ tim cấp giờ thứ nhất có biến chứng ngưng tim ngoại viện đã được hồi sức thành công. 
Bệnh nhân có chỉ định phải tái thông mạch vành cấp cứu, tuy nhiên do nguy cơ tử vong rất cao nên bác sĩ đã giải thích cho người nhà về tình trạng bệnh, và người nhà đã đồng ý can thiệp động mạch vành. 
Bệnh nhân được chụp mạch vành với kết quả tắc nhánh động mạch liên thất trước (động mạch lớn nhất nuôi tim), được xử lý tái thông bằng cách đặt 01 giá đỡ trong lòng động mạch vành, thủ thuật kéo dài khoảng 15 phút. Thời gian từ lúc bệnh nhân nhập viện tới lúc bệnh nhân được tái thông mạch vành khoảng 30 phút.
Sau can thiệp, bệnh nhân được chuyển về khoa tim mạch can thiệp theo dõi và điều trị tiếp. Khoảng 1 ngày sau, các bác sĩ đánh giá tình trạng bệnh nhân ổn định hơn nên đã tiến hành rút nội khí quản. Hiện bệnh nhân hết đau ngực, tự thở khí trời, đi lại bình thường, mạch và huyết áp ổn định; điện tim, siêu âm tim và các xét nghiệm cận lâm sàng của các cơ quan trong giới hạn bình thường.
Trước đó, khi đang bơi, ông Nguyễn Ng. Đ (sinh năm 1964, ngụ tại Quận 11, TPHCM) đột nhiên đau ngực, khó thở. Sau đó khoảng 30 phút, ông được người dân phát hiện bị tím tái nên gọi cấp cứu. Đội cấp cứu tiếp xúc bệnh nhân với tình trạng mê, ngưng tim ngưng thở, mạch và huyết áp không đo được. 
Bệnh nhân đã được các bác sĩ và điều dưỡng cấp cứu của đội cấp cứu 115 tiến hành hồi sức tim phổi nâng cao với ấn tim ngoài lồng ngực, bóp bóng giúp thở, đặt nội khí quản ngay trên xe cứu thương. Sau đó bệnh nhân có biểu hiện rung thất nên được xử lý sốc điện 5 lần. Sau hồi sức tích cực khoảng 50 phút, bệnh nhân có tim đập lại, mạch và huyết áp đo được nên được hội chẩn qua điện thoại và chuyển ngay qua Bệnh viện Nguyễn Tri Phương.
Tại Bệnh viện Nguyễn Tri Phương, đo khẩn điện tâm đồ gợi ý nhồi máu cơ tim cấp và hội chẩn ngay với bác sĩ chuyên khoa tim mạch can thiệp, chẩn đoán lúc này là một trường hợp nhồi máu cơ tim cấp thành trước rộng giờ thứ 3 biến chứng ngưng tim ngoại viện được hồi sức thành công. 
Bệnh nhân được chỉ định tái thông mạch vành cấp cứu. TS.BS Lê Cao Phương Duy, Phó Giám đốc Bệnh viện, cùng êkip chuyên khoa can thiệp đã cho bệnh nhân chụp mạch vành. Kết quả cho thấy bệnh nhân bị tắc nhánh động mạch liên thất trước (động mạch lớn nhất nuôi tim) nên các bác sĩ xử lý tái thông bằng cách đặt 01 giá đỡ trong lòng động mạch vành, thủ thuật hoàn thành trong 30 phút. 
Sau can thiệp, bệnh nhân bị suy đa cơ quan sau ngưng tim ngưng thở kéo dài và được chuyển xuống Khoa Hồi sức Tích cực tiếp tục điều trị và theo dõi. Tại đây, bệnh nhân được điều trị tích cực với: thở máy, điều chỉnh thuốc vận mạch, lọc máu liên tục, kháng sinh và nuôi ăn qua đường tĩnh mạch. Sau 13 ngày điều trị, bệnh nhân ngừng được thuốc vận mạch, và sau đó bệnh nhân được cai máy thở và rút nội khí quản sau 18 ngày điều trị. 
Theo TS.BS Lê Cao Phương Duy, đây là những trường hợp điển hình ngưng tim ngưng thở do rối loạn nhịp ở bệnh nhân nhồi máu cơ tim cấp. Nhờ sự tiếp cận kịp thời với một quy trình điều trị hợp lý và chính xác nên bệnh nhân được cứu sống và hồi phục ngoạn mục. Kết quả này có được là nhờ sự phối hợp nhịp nhàng từ nơi tiếp nhận ban đầu (các bệnh viện tuyến dưới, trung tâm cấp cứu ngoại viện 115), quy trình chuyển viện, bác sĩ cấp cứu nội viện, êkip can thiệp động mạch vành và đội ngũ hồi sức tích cực. 
**Nhiều bệnh nhân nhồi máu cơ tim cấp tử vong ở những giờ đầu tiên trước khi vào đến bệnh viện vì các biến chứng liên quan đến rối loạn nhịp**
Nhồi máu cơ tim cấp (NMCT) là một trong những nguyên nhân hàng đầu gây nhập viện và tử vong hiện nay trên thế giới cũng như tại Việt Nam. Khi bệnh nhân đã có ngưng tim ngoài bệnh viện, thì tỷ lệ tử vong trên 90%. Nếu được nhập viện và điều trị kịp thời, tỷ lệ tử vong giảm xuống còn 6 - 10%. Khi đã có biến chứng choáng tim, tỷ lệ tử vong vẫn còn rất cao tuy nhiên nếu được can thiệp động mạch vành kịp thời sẽ cứu sống rất nhiều người bệnh. Khi cơ tim bị hoại tử do thiếu máu cục bộ, dẫn đến các biến chứng như phù phổi cấp, sốc tim, rối loạn nhịp, và ảnh hưởng đến nhiều cơ quan khác như thận (suy thận), não (thiếu máu não)... Do đó, NMCT cấp là một bệnh cảnh cấp cứu cần được chẩn đoán sớm và điều trị tích cực, kịp thời.
Những bệnh nhân có nguy cơ cao bị NMCT bao gồm bệnh nhân đã từng được chẩn đoán bệnh mạch vành, có những yếu tố nguy cơ của bệnh mạch vành như: lớn tuổi (Nam > 45 tuổi, nữ > 55 tuổi); thừa cân, béo phì; ít vận động thể lực; hút thuốc lá; tăng huyết áp; đái tháo đường; rối loạn lipid máu; stress về thể chất và tinh thần. 
“Nhiều nghiên cứu cho thấy trong hơn 50% các trường hợp, bệnh nhân sẽ có một yếu tố khởi kích xảy ra trước khi NMCT như: vận động gắng sức, stress tâm lý, phẫu thuật, có bệnh lý nội khoa nặng. Nhồi máu cơ tim có tần suất xảy ra cao vào buổi sáng (từ 6 giờ đến 11 giờ), đặc biệt là trong vòng 3 giờ đầu tiên sau khi ngủ dậy,” TS.BS Phương Duy cho biết. 
**Triệu chứng cảnh báo nhồi máu cơ tim:**
  * Đau ngực là triệu chứng thường gặp nhất với các tính chất sau: 
    * Đau sau xương ức hoặc đau ngực trái; kiểu đè nặng, siết chặt, bóp nghẹt
    * Cơn đau có khi lan lên cổ, hàm dưới, vai trái hoặc bờ trụ tay trái. Một số trường hợp lan xuống thượng vị nhưng không bao giờ vượt quá rốn
    * Những cơn đau ngực thường kéo dài >30 phút
  * Triệu chứng kèm theo thường gặp: khó thở, vã mồ hôi (đau ngực sau xương ức, kéo dài >30 phút, kèm vã mồ hôi gợi ý rất nhiều đến nhồi máu cơ tim)


Một số bệnh nhân không biểu hiện đau ngực mà có những triệu chứng không đặc hiệu: cảm giác mệt mỏi, cảm giác hồi hộp, khó thở, đau thượng vị, buồn nôn, nôn, rối loạn tri giác… 
Bệnh nhân hậu phẫu, lớn tuổi, đái tháo đường có thể không biểu hiện đau ngực mà xuất hiện triệu chứng rối loạn tri giác hoặc dấu hiệu sinh tồn xấu đi khi bị NMCT cấp.
**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/) **- Đa khoa Hạng I Thành phố Hồ Chí Minh

## Những dấu hiệu mắc bệnh tim mạch

**Nhận biết sớm những dấu hiệu mắc bệnh tim mạch sẽ giúp chúng ta phòng ngừa và điều trị bệnh kịp thời, tránh được những hậu quả đáng tiếc. Bài viết dưới đây sẽ đề cập đến những dấu hiệu mắc bệnh tim mạch…**
Những dấu hiệu dưới đây có thể báo hiệu bạn đang mắc các bệnh về tim mạch hoặc có nguy cơ rất cao với căn bệnh này.
_Đau ngực là một trong những triệu chứng điển hình của bệnh tim mạch._
**1.Cơn đau thắt ngực**
Đau ngực là một trong những triệu chứng điển hình của bệnh tim mạch. Theo đó, những cơn đau ngực liên quan đến tim thường xuất hiện ở vị trí ngay dưới xương ức, ở phần trước của ngực hoặc cánh tay. Các bác sĩ cho biết, những cơn đau này có thể khởi phát sau khi bạn vận động thể lực, xúc động mạnh hay bị stress. Người bệnh có cảm giác đau thắt ngực như có người bóp từ phía sau. Các cơn đau ngực liên quan đến tim thường kéo dài từ 10-15 phút và tái lại nhiều lần. Cơn đau thắt ngực là một trong những dấu hiệu điển hình cảnh báo nhồi máu cơ tim. Do đó, chúng ta tuyệt đối không được chủ quan với những cơn đau ngực kéo dài và không rõ nguyên nhân. Ngay sau khi xuất hiện dấu hiệu này, bạn cần nghỉ ngơi, dừng mọi công việc đang làm và báo cho người thân, bạn bè biết để có hướng xử lý kịp thời.
**2.Khó thở**
Khó thở dù không gắng sức hay phải vận động thể lực nhiều là dấu hiệu của bệnh tim mạch. Cụ thể, hiện tượng khó thở này xuất hiện không rõ nguyên nhân và và luôn khiến bạn có cảm giác bị hụt hơi.
_Khó thở dù không gắng sức hay phải vận động thể lực nhiều là dấu hiệu của bệnh tim mạch._
**3.Mệt mỏi kéo dài**
Những cơn mệt mỏi kéo dài, tinh thần uể oải, chán ăn, người tím tái hay bị phù…đều là những dấu hiệu mắc bệnh tim mạch.
**4.Thường xuyên chóng mặt, choáng váng**
Bạn thường xuyên bị chóng mặt hoặc choáng váng?Rất có thể bạn đang gặp các vấn đề về tim như tắc nghẽn động mạch, giảm huyết áp hay van tim bị lỗi…
**5.Đau nửa đầu**
40% bệnh nhân tim mạch bị đau nửa đầu. Do đó, khi bị đau nửa đầu thường xuyên, liên tục, bạn nên đi khám và nói với bác sĩ để được chẩn đoán bệnh sớm.
**6.Lo lắng, trầm cảm, buồn nôn và nôn**
Đây là những dấu hiệu cảnh báo bệnh tim mạch rất rõ nét.
**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/) **- Đa khoa Hạng I Thành phố Hồ Chí Minh

## ️ Tắc mạch u xơ tử cung - Những hỗ trợ hiệu quả từ can thiệp mạch

  * [Phương pháp tắc mạch u xơ tử cung](https://bvnguyentriphuong.com.vn/san-phu-khoa/tac-mach-u-xo-tu-cung-phuong-phap-dieu-tri-moi#phng-php-tc-mch-u-x-t-cung)
  * [Những lưu ý trước khi điều trị tắc mạch u xơ tử cung](https://bvnguyentriphuong.com.vn/san-phu-khoa/tac-mach-u-xo-tu-cung-phuong-phap-dieu-tri-moi#nhng-lu-trc-khi-iu-trtc-mch-u-x-t-cung)
  * [Diễn biến sau điều trị tắc mạch u xơ tử cung](https://bvnguyentriphuong.com.vn/san-phu-khoa/tac-mach-u-xo-tu-cung-phuong-phap-dieu-tri-moi#din-bin-sau-iu-tr-tc-mch-u-x-t-cung)
  * [Những lưu ý sau khi ra viện](https://bvnguyentriphuong.com.vn/san-phu-khoa/tac-mach-u-xo-tu-cung-phuong-phap-dieu-tri-moi#nhng-lu-sau-khi-ra-vin)
  * [Các triệu chứng sức khỏe sau điều trị](https://bvnguyentriphuong.com.vn/san-phu-khoa/tac-mach-u-xo-tu-cung-phuong-phap-dieu-tri-moi#cc-triu-chng-sc-khe-sau-iu-tr)


## **Phương pháp tắc mạch u xơ tử cung**
Đây là phương pháp điều trị bệnh UXTC không phẫu thuật, sử dụng ống thông đi trong lòng mạch, được thực hiện trên máy chụp mạch DSA.
Một ống thông nhỏ và mềm được đưa qua động mạch đùi để đi đến động mạch tử cung 2 bên. Qua đó, chất gây tắc là các hạt PVA (PolyVinyl Alcohol) được bơm vào và làm tắc 2 động mạch tử cung.
Khối UXTC sẽ bị hoại tử vô trùng và teo nhỏ dần vì thiếu máu, trở thành sẹo nhỏ trên thành tử cung. Phương pháp điều trị này có hiệu quả cao, không gây mê, không mất máu, không để lại sẹo trên bụng, không can thiệp vào ổ bụng, còn khả năng có thai và sinh con, ra viện sau 2-3 ngày, hồi phục sức khỏe nhanh.
Tỷ lệ thành công đạt 95%. Bệnh nhân hết hoàn toàn hoặc gần hoàn toàn triệu chứng trong 1-2 tháng đầu tiên sau điều trị. Khối u xơ teo nhỏ dần sau 3-6 tháng, tối đa sau 1 năm. Các trường hợp có nhiều nhân xơ cũng có đáp ứng tốt với kỹ thuật này. Nhân xơ tái phát rất hiếm gặp, ~1%.
Phương pháp điều trị này chỉ áp dụng được cho các trường hợp UXTC có nhiều mạch máu (tăng sinh mạch), được xác định bằng siêu âm Doppler hoặc cộng hưởng từ.
## **Những lưu ý trước khi điều trị tắc mạch u xơ tử cung**
  * Khám lâm sàng phụ khoa, tư vấn về phương pháp điều trị. Nếu bị viêm nhiễm phần phụ, cần điều trị nội khoa trước để giảm nguy cơ nhiễm trùng nội mạc tử cung sau tắc mạch.
  * Siêu âm ổ bụng, tử cung, UXTC (đặc biệt là siêu âm Doppler), phần phụ. Trong trường hợp tổn thương phức tạp hoặc còn như cầu sinh con, bệnh nhân cần được chụp cộng hưởng từ để đánh giá chi tiết và chính xác hơn cấu trúc của tử cung và nhân xơ.
  * Xét nghiệm máu, điện tim, Xquang tim phổi.
  * Thụt tháo làm sạch đại tràng bằng nước hoặc thuốc trước khi can thiệp điều trị.
  * Bệnh nhân viết giấy cam đoan chấp nhận điều trị.


## **Diễn biến sau điều trị tắc mạch u xơ tử cung**
Sau khi 2 động mạch tử cung được làm tắc hoàn toàn bệnh nhân sẽ có cảm giác đau tăng dần vùng bụng dưới. Mức độ đau không giống nhau giữa các bệnh nhân. Đau nhiều nhất trong vòng 24-48 giờ đầu sau thủ thuật, sau đó giảm dần và chỉ còn cảm giác tức nặng âm ỉ kéo dài 5-7 ngày.
Ngoài ra có thể sốt nhẹ, nôn, mệt mỏi. Bệnh nhân thường được ra viện sau 2-3 ngày, trở lại làm việc sau 5-7 ngày. Trong 1-3 tuần đầu sau tắc mạch thường ra dịch âm đạo màu hồng nhạt.
Tai biến biến chứng: nhiễm trùng nội mạc tử cung có thể gặp ở <1% số bệnh nhân, có thể được điều trị khỏi bằng kháng sinh liều cao, nếu không có kết quả phải mổ cắt tử cung. Khoảng 2-3% bị vô kinh sau thủ thuật do suy buồng trứng.
## **Những lưu ý sau khi ra viện**
  * Đi lại nhẹ nhàng trong 1 tuần đầu
  * Ăn uống bình thường, kiêng các chất kích thích
  * Dùng thuốc giảm đau nếu cần
  * Không ngâm mình trong bồn tắm 2 tuần đầu
  * Kiêng sinh hoạt vợ chồng trong tháng đầu
  * Đến khám định kỳ theo hẹn của bác sỹ: 3, 6 và 12 tháng sau điều trị
  * Nếu có triệu chứng nhiễm trùng nội mạc tử cung: sốt, mệt mỏi, ra dịch âm đạo nhiều và hôi… cần đến bệnh viện ngay để điều trị chống nhiễm khuẩn tích cực.


## **Các triệu chứng sức khỏe sau điều trị**
**Kinh nguyệt:** hầu hết bệnh nhân có chu kỳ bình thường ngay trong tháng đầu tiên, có thể sau 2-3 tháng nếu bị rối loạn nặng. Một số trường hợp bị vô kinh trong vài tháng đầu. Khoảng 2-3% bị mất kinh hoàn toàn do suy buồng trứng. Một số trường hợp bị giảm lượng kinh nguyệt.
**Khối u:** u xơ tử cung giảm dần kích thước, đạt mức độ tối đa sau 9-12 tháng. Khi siêu âm kiểm tra thấy còn hình ảnh khối u nhỏ, nhưng thực chất đó chỉ là sẹo.
Cần siêu âm màu để biết tình trạng khối u có còn máu nuôi hay không và để đánh giá mạch máu của cơ tử cung lành. Một số ít trường hợp nhân xơ bị hoại tử, rơi vào lòng tử cung và bị đẩy ra ngoài theo đường tự nhiên.
**Trường hợp cần có thai sau điều trị:** cần được khám và kiểm tra siêu âm màu chặt chẽ và tỷ mỷ hơn. Chỉ nên có thai sau 9 -12 tháng kể từ ngày điều trị. Khả năng thụ thai và sinh đẻ sau điều trị tắc mạch u xơ tử cung phụ thuộc từng bệnh nhân.
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [Phương pháp tắc mạch u xơ tử cung](https://bvnguyentriphuong.com.vn/san-phu-khoa/tac-mach-u-xo-tu-cung-phuong-phap-dieu-tri-moi#phng-php-tc-mch-u-x-t-cung)
  * [Những lưu ý trước khi điều trị tắc mạch u xơ tử cung](https://bvnguyentriphuong.com.vn/san-phu-khoa/tac-mach-u-xo-tu-cung-phuong-phap-dieu-tri-moi#nhng-lu-trc-khi-iu-trtc-mch-u-x-t-cung)
  * [Diễn biến sau điều trị tắc mạch u xơ tử cung](https://bvnguyentriphuong.com.vn/san-phu-khoa/tac-mach-u-xo-tu-cung-phuong-phap-dieu-tri-moi#din-bin-sau-iu-tr-tc-mch-u-x-t-cung)
  * [Những lưu ý sau khi ra viện](https://bvnguyentriphuong.com.vn/san-phu-khoa/tac-mach-u-xo-tu-cung-phuong-phap-dieu-tri-moi#nhng-lu-sau-khi-ra-vin)
  * [Các triệu chứng sức khỏe sau điều trị](https://bvnguyentriphuong.com.vn/san-phu-khoa/tac-mach-u-xo-tu-cung-phuong-phap-dieu-tri-moi#cc-triu-chng-sc-khe-sau-iu-tr)



## ️ CT mạch vành

  * [1. Chụp CT đo độ vôi hóa mạch vành (không tiêm thuốc cản quang):](https://bvnguyentriphuong.com.vn/chan-doan-hinh-anh/ct-mach-vanh#1-chp-ct-o-vi-ha-mch-vnh-khng-tim-thuc-cn-quang)
  * [1.1 Đánh giá nguy cơ bệnh động mạch vành ở bệnh nhân không có triệu chứng đau ngực:](https://bvnguyentriphuong.com.vn/chan-doan-hinh-anh/ct-mach-vanh#11-nh-gi-nguy-c-bnh-ng-mch-vnh-bnh-nhn-khng-c-triu-chng-au-ngc)
  * [1.2 Trên bệnh nhân có triệu chứng đau ngực:](https://bvnguyentriphuong.com.vn/chan-doan-hinh-anh/ct-mach-vanh#12-trn-bnh-nhn-c-triu-chng-au-ngc)
  * [2. Chụp CT mạch vành có cản quang:](https://bvnguyentriphuong.com.vn/chan-doan-hinh-anh/ct-mach-vanh#2-chp-ct-mch-vnh-c-cn-quang)
  * [2.1. Lưu ý khi chụp CT mạch vành:](https://bvnguyentriphuong.com.vn/chan-doan-hinh-anh/ct-mach-vanh#21-lu-khi-chp-ct-mch-vnh)


# **Chụp CT mạch vành bao gồm 2 phần:**
  * Khảo sát mức độ vôi hóa mạch vành - không cần tiêm thuốc cản quang;
  * Chụp CT mạch vành có tiêm thuốc cản quang.


Các bác sĩ cũng có thể chỉ định đo độ vôi hóa mạch vành hoặc chụp CT mạch vành đơn độc tùy tình huống lâm sàng.
## **1. Chụp CT đo độ vôi hóa mạch vành (không tiêm thuốc cản quang):**
_Chụp CT không tiêm thuốc cản quang khảo sát vôi hóa mạch vành cho thấy vôi hóa nặng ở động mạch vành trái._
Mức độ vôi hóa động mạch vành trên chụp CT không tiêm thuốc cản quang tương quan tốt với mức độ xơ vữa động mạch vành, tuy nhiên nhiều trường hợp vôi hóa nặng nhưng chỉ ở thành động mạch vành và không gây hẹp lòng động mạch vành (hình 2).
_Một bệnh nhân nam, 65 tuổi, có mảng xơ vữa vôi hóa ở đoạn cuối thân chung và động mạch vành xuống trước trái đoạn 1,2 nhưng không gây hẹp lòng mạch vành đáng kể._
Trái lại, có trường hợp không vôi hóa vẫn bị hẹp lòng động mạch vành do có các mảng xơ vữa không vôi hóa.
Kết quả đo độ vôi hóa được thể hiện bằng điểm vôi hóa điểm vôi hóa mạch vành (coronary calcium score). Điểm vôi hóa được chia làm **4** mức độ:
  * **0 điểm:** không mảng vôi hóa
  * **1 - 99 điểm:** vôi hóa nhẹ (nguy cơ thấp, tỷ lệ tử vong hoặc nhồi máu cơ tim hàng năm < 1%)
  * **100 - 399:** vôi hóa trung bình (nguy cơ trung bình, tỷ lệ tử vong hoặc nhồi máu cơ tim hàng năm 1% - 3%)
  * **≥ 400 điểm:** vôi hóa nặng (nguy cơ cao, tỷ lệ tử vong hoặc nhồi máu cơ tim hàng năm > 3%)


Mức độ nặng còn tùy thuộc vào vị trí vôi hóa nằm ở động mạch vành nào (thân chung động mạch vành trái và đoạn gần của các động mạch vành nguy hiểm hơn đoạn giữa và đoạn xa), cách phân bố, số lượng… Các đốm vôi hóa nhỏ lại thường đi đôi với các mảng xơ vữa hỗn hợp gây hẹp lòng mạch vành đáng kể và có thể nguy hiểm hơn mảng vôi hóa lớn…
Khi điểm vôi hóa **≥ 400** , thậm chí thấp hơn nhưng tập trung thành mảng lớn làm che lấp lòng mạch vành và gây nhiễu hình ảnh, các bác sĩ sẽ không tiêm thuốc cản quang chụp CT khảo sát lòng mạch vành vì nhiễu làm đánh giá không chính xác mức độ hẹp lòng ở những nơi có mảng xơ vữa vôi hóa nặng trong khi đó bệnh nhân lại phải chịu các nguy cơ của thuốc cản quang và phơi nhiễm với tia X. Những trường hợp này nên chụp mạch vành qua thông tim.
Đo điểm vôi hóa mạch vành được chỉ định theo hai tình huống dưới đây:
### **1.1 Đánh giá nguy cơ bệnh động mạch vành ở bệnh nhân không có triệu chứng đau ngực:**
Trên các bệnh nhân không triệu chứng, nhưng có các yếu tố nguy cơ của bệnh động mạch vành như **hút thuốc lá, tăng huyết áp, rối loạn lipid máu** … cần tính nguy cơ bệnh động mạch vành toàn bộ để có kế hoạch tầm soát bệnh động mạch vành, điều chỉnh các yếu tố nguy cơ và phòng ngừa bệnh động mạch vành.
Điểm vôi hóa mạch vành sẽ hỗ trợ cho các bác sĩ xác định nguy cơ và quyết định phòng ngừa tiên phát bệnh động mạch vành cho những bệnh nhân này .
### **1.2 Trên bệnh nhân có triệu chứng đau ngực:**
Điểm vôi hóa mạch vành cũng được sử dụng cho tiên đoán bệnh động mạch vành tắc nghẽn trên bệnh nhân có triệu chứng đau ngực.
Có thể chia bệnh động mạch vành thành **bệnh động mạch vành tắc nghẽn**(obstructive CAD) và **bệnh động mạch vành không tắc nghẽn** (non-obstructive CAD). Gọi là bệnh động mạch vành tắc nghẽn khi động mạch vành hẹp đáng kể **(≥ 50 - 70%)** , gây hậu quả thiếu máu cục bộ khi nghỉ hoặc khi gắng sức. Bệnh động mạch vành không tắc nghẽn có động mạch vành hẹp nhưng không đáng kể, không gây thiếu máu cục bộ cơ tim khi nghỉ lẫn khi gắng sức.
Mức độ vôi hóa mạch vành không tương quan chặt với mức độ hẹp lòng động mạch vành: vôi hóa nặng không nhất thiết gây hẹp lòng động mạch vành (hình 2), không vôi hóa cũng không loại trừ hẹp động mạch vành trên bệnh nhân có triệu chứng.
Kết quả điểm vôi hóa mạch vành cũng chỉ gợi ý về tình trạng xơ vữa động mạch vành, không cung cấp được các thông tin về mức độ hẹp lòng động mạch vành do xơ vữa cũng như các ảnh hưởng về mặt chức năng của hẹp động mạch vành. Tuy nhiên với những ưu điểm dễ thực hiện, không cần tiêm thuốc cản quang, không phụ thuộc các thuốc đang dùng cũng như khả năng gắng sức… các bác sĩ có thể chỉ định cho khảo sát vôi hóa mạch vành khi các test đánh giá chức năng hoặc giải phẫu mạch vành không xâm nhập không thể thực hiện được hoặc kết quả không kết luận được để lập kế hoạch điều trị cho bệnh nhân.
  * **Tìm hiểu thêm:** [Điều trị cho bệnh nhân hẹp động mạch vành](http://bvnguyentriphuong.com.vn/cac-chuyen-khoa/khoi-ngoai/ngoai-tong-hop/dieu-tri-cho-benh-nhan-bi-hep-dong-mach-vanh.html)


## **2. Chụp CT mạch vành có cản quang** :
Muốn biết chắc chắn có hẹp động mạch vành hay không cần chụp **CT động mạch vành có tiêm thuốc cản quang**.
Theo kết quả của các nghiên cứu, CT mạch vành có khả năng loại trừ hẹp mạch vành **97 - 100%** , khiến CT mạch vành trở thành một phương pháp rất đáng tin cậy cho loại trừ bệnh động mạch vành tắc nghẽn.
CT mạch vành có thể đánh giá cả lòng lẫn thành động mạch vành, nghĩa là có thể khảo sát được các đặc tính về hình thái và cấu trúc của mảng xơ vữa.
Thêm vào đó, các bài kiểm tra gắng sức khi âm tính chỉ loại trừ bệnh động mạch vành tắc nghẽn, không loại trừ được các trường hợp có mảng xơ vữa gây hẹp động mạch vành không tắc nghẽn (hình 3). Nhận diện được các mảng xơ vữa không gây tắc nghẽn động mạch vành trên CT mạch vành có thể hữu ích trong đánh giá nguy cơ và lên kế hoạch điều trị phòng ngừa tích cực…
_Hình CCTA của một bệnh nhân nam, 42 tuổi, đau ngực không điền hình, chụp CT mạch vành: A/Hình Curved MPR của động mạch vành phải cho thấy có 2 mảng xơ vữa vôi hóa ở đoạn 2 trong đó mảng xơ vữa thứ 2 (mũi tên xanh) gây hẹp lòng động mạch vành 50-70%. B/ Hình cắt ngang lòng động mạch vành đoạn tham khảo (ref) ngay trên chỗ hẹp. C/ Hình cắt ngang lòng động mạch vành phải đoạn 2 qua mảng xơ vữa thứ 2._
Như vậy, tùy theo các đặc điểm về **tuổi, phái, các yếu tố nguy cơ tim mạch, đặc điểm đau ngực và bệnh cảnh lâm sàng** của từng người bệnh, các bác sĩ có thể chỉ định cho bệnh nhân chụp CT mạch vành có cản quang để xác định bệnh nhân có bị hẹp mạch vành hay không.
Các bệnh nhân trước đây đã từng được đặt s**tent mạch vành** hoặc **phẫu thuật bắc cầu nối mạch vành** , nếu các bác sĩ nghi ngờ có tái hẹp trong stent mạch vành hoặc cầu nối cũng có thể chỉ định chụp CT mạch vành để xác định chẩn đoán (hình 4).
_A/ Hình CT mạch vành của 1 bệnh nhân nam, 73 tuổi, đau ngực không đặc hiệu, có 1 stent ( > 5 năm) ở động mạch vành LAD1-2, không bị tái hẹp; B -C/ Hình 3D của 1 bệnh nhân nữ 73 tuổi, có 3 cầu mạch vành, 2 cầu bên trái và 1 cầu bên phải, cầu không bị tái hẹp._
### **2.1. Lưu ý khi chụp CT mạch vành:**
  * Trước khi chụp CT mạch vành: cần nhịn ăn 4 tiếng trước chụp, cần phải có kết quả xét nghiệm chức năng thận trước khi chụp.
  * Sau khi chụp xong: uống nước nhiều trong vòng 1 - 2 ngày để thuốc cản quang thải hết qua nước tiểu.
  * Không chụp CT mạch vành có tiêm thuốc cản quang cho người có tiền sử dị ứng với thuốc cản quang trước đây, người suy thận với độ lọc cầu thận **< 30ml/phút/m2**, người bị cường giáp chưa điều trị ổn định.


**2.2 Các tai biến do thuốc cản quang khi chụp CT mạch vành:**
  * Phản ứng xảy ra sớm **< 1h** sau tiêm thuốc cản quang: dị ứng, ói, phù thanh quản, sốc phản vệ.
  * Trong vòng 1h đến 7 ngày có thể bị sẩn đỏ, sưng, ngứa da.
  * Suy chức năng thận do thuốc cản quang


## **Kết luận:**
Tóm lại, chụp CT mạch vành là một kỹ thuật chẩn đoán bệnh động mạch vành có giá trị, giúp các bác sĩ lập kế hoạch điều trị cho bệnh nhân. Tuy vậy, chụp CT mạch vành vẫn luôn có những nguy cơ xuất phát chủ yếu từ **phơi nhiễm với tia xạ** và dùng thuốc cản quang. Vì vậy các bác sĩ luôn cân nhắc lợi hại trước khi quyết định chụp CT mạch vành cho từng bệnh nhân cụ thể.
Xem thêm: [**Chụp cắt lớp vi tính CT scan**](https://bvnguyentriphuong.com.vn/chan-doan-hinh-anh/chup-cat-lop-vi-tinh-ct-scan)
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [1. Chụp CT đo độ vôi hóa mạch vành (không tiêm thuốc cản quang):](https://bvnguyentriphuong.com.vn/chan-doan-hinh-anh/ct-mach-vanh#1-chp-ct-o-vi-ha-mch-vnh-khng-tim-thuc-cn-quang)
  * [1.1 Đánh giá nguy cơ bệnh động mạch vành ở bệnh nhân không có triệu chứng đau ngực:](https://bvnguyentriphuong.com.vn/chan-doan-hinh-anh/ct-mach-vanh#11-nh-gi-nguy-c-bnh-ng-mch-vnh-bnh-nhn-khng-c-triu-chng-au-ngc)
  * [1.2 Trên bệnh nhân có triệu chứng đau ngực:](https://bvnguyentriphuong.com.vn/chan-doan-hinh-anh/ct-mach-vanh#12-trn-bnh-nhn-c-triu-chng-au-ngc)
  * [2. Chụp CT mạch vành có cản quang:](https://bvnguyentriphuong.com.vn/chan-doan-hinh-anh/ct-mach-vanh#2-chp-ct-mch-vnh-c-cn-quang)
  * [2.1. Lưu ý khi chụp CT mạch vành:](https://bvnguyentriphuong.com.vn/chan-doan-hinh-anh/ct-mach-vanh#21-lu-khi-chp-ct-mch-vnh)



## ️ Khuyến cáo về can thiệp mạch vành trong thời gian dịch COVID-19

Khuyến cáo từ Hội Tim mạch can thiệp Việt Nam.
Toàn văn xin xem [tại đây](https://drive.google.com/open?id=1NY5wKC07nZIfIgEatdxXxENRrY79zus7)./.
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh
[youtube.com/bvntp](http://youtube.com/bvntp)

## ️Chụp động mạch vành- khi nào cần thực hiện

  * [Chụp mạch vành là gì](https://bvnguyentriphuong.com.vn/tim-mach-can-thiep/chup-dong-mach-vanh-khi-nao-can-thuc-hien#chp-mch-vnh-l-g)
  * [Khi nào cần chụp động mạch vành](https://bvnguyentriphuong.com.vn/tim-mach-can-thiep/chup-dong-mach-vanh-khi-nao-can-thuc-hien#khi-no-cn-chp-ng-mch-vnh)
  * [Cần chuẩn bị những gì trước khi tiến hành chụp động mạch vành](https://bvnguyentriphuong.com.vn/tim-mach-can-thiep/chup-dong-mach-vanh-khi-nao-can-thuc-hien#cn-chun-b-nhng-g-trc-khi-tin-hnh-chp-ng-mch-vnh)
  * [Trước khi tiến hành thủ thuật](https://bvnguyentriphuong.com.vn/tim-mach-can-thiep/chup-dong-mach-vanh-khi-nao-can-thuc-hien#trc-khi-tin-hnh-th-thut)
  * [Trong quá trình chụp động mạch vành](https://bvnguyentriphuong.com.vn/tim-mach-can-thiep/chup-dong-mach-vanh-khi-nao-can-thuc-hien#trong-qu-trnh-chp-ng-mch-vnh)
  * [Sau khi chụp động mạch vành](https://bvnguyentriphuong.com.vn/tim-mach-can-thiep/chup-dong-mach-vanh-khi-nao-can-thuc-hien#sau-khi-chp-ng-mch-vnh)
  * [Các kết quả chụp động mạch vành cho biết điều gì](https://bvnguyentriphuong.com.vn/tim-mach-can-thiep/chup-dong-mach-vanh-khi-nao-can-thuc-hien#cc-kt-qu-chp-ng-mch-vnh-cho-bit-iu-g)


## **Chụp mạch vành là gì**
Chụp động mạch vành là một kỹ thuật sử dụng tia X khảo sát các mạch máu của tim nhằm đánh giá liệu có sự hạn chế lưu lượng máu đến tim hay không.
Chụp động mạch vành là một phần của đặt ống thông tim – kỹ thuật có thể giúp chẩn đoán và điều trị các bệnh về tim và mạch máu.
Trong chụp động mạch vành, thuốc cản quang được tiêm vào mạch máu, khi đó mạch máu sẽ hiển thị chi tiết trên hình chụp. Trong một số trường hợp, bác sĩ có thể nong mạch vành ngay trong quá trình chụp động mạch vành.
## **Khi nào cần chụp động mạch vành**
Bác sĩ có thể yêu cầu chụp động mạch vành nếu:
  * Các triệu chứng của bệnh động mạch vành;
  * Đau ở ngực, hàm, cổ hoặc cánh tay không thể giải thích bằng các xét nghiệm chẩn đoán khác;
  * Các cơn đau thắt ngực không ổn định;
  * Bệnh tim bẩm sinh;
  * Có kết quả bất thường trong điện tim gắng sức;
  * Các vấn đề về mạch máu khác hoặc chấn thương ngực;
  * Một vấn đề van tim cần can thiệp phẫu thuật.


Do có nguy cơ xuất hiện một số biến chứng, chụp động mạch thường được thực hiện sau khi thực hiện các kỹ thuật khảo sát tim không xâm lấn như **điện tâm đồ** , [**siêu âm tim**](https://bvnguyentriphuong.com.vn/chan-doan-hinh-anh/mot-so-kien-thuc-ve-sieu-am-tim) hoặc **điện tim gắng sức**.
## **Nguy cơ**
Như với hầu hết các kỹ thuật được thực hiện trên tim và mạch máu, chụp động mạch vành có một số nguy cơ như [**phơi nhiễm bức xạ từ tia X**](https://bvnguyentriphuong.com.vn/chan-doan-hinh-anh/tia-x-co-thuc-su-an-toan). Mặc dù các biến chứng khác là rất hiếm như:
  * Đau tim;


  * Đột quỵ;
  * Tổn thương động mạch;
  * Nhịp tim không đều (loạn nhịp tim);
  * Phản ứng dị ứng với thuốc trong quá trình chụp;
  * Tổn thương thận;
  * Chảy máu nhiều;
  * Nhiễm trùng.


## **Cần chuẩn bị những gì trước khi tiến hành chụp động mạch vành**
Trong một số trường hợp cấp cứu, chụp động mạch vành được thực hiện ngay. Các trường hợp khác thường được lên lịch trước để bệnh nhân có thời gian để chuẩn bị. Bác sĩ sẽ lưu ý về những loại thuốc đang sử dụng và có những hướng dẫn chuẩn bị cụ thể bao gồm:
  * **Không ăn hoặc uống** bất cứ thứ gì sau nửa đêm trước khi chụp động mạch;
  * **Mang theo tất cả các loại thuốc đang sử dụng** kèm theo nhãn thuốc. Hỏi bác sĩ về việc có nên dùng thuốc trước khi tiến hành chụp động mạch hay không;
  * Nếu bị tiểu đường, hãy **hỏi bác sĩ về việc sử dụng insulin** hoặc các loại thuốc uống khác.


## **Trước khi tiến hành thủ thuật**
Trước khi chụp động mạch, bác sĩ sẽ xem kỹ hồ sơ bao gồm cả tiền sử bệnh lý, dị ứng và các loại thuốc đang sử dụng. Ngoài ra, việc kiểm tra thể chất và dấu sinh hiệu như huyết áp và mạch cũng rất quan trọng.
Người bệnh cần đi tiểu để làm trống bàng quang và thay áo choàng chuyên dụng. Các vật dụng như kính áp tròng, kính mắt, trang sức và kẹp tóc cần phải loại bỏ.
## **Trong quá trình chụp động mạch vành**
Bệnh nhân nằm ngửa trên bàn X-quang, dây đai an toàn được cố định trên ngực và chân. Đầu đèn X-quang sẽ di chuyển xung quanh để khảo sát từ nhiều góc độ.
Một kim luồn được chèn vào tĩnh mạch cánh tay để đưa thuốc an thần vào bên trong mạch máu giúp bệnh nhân thoải mái hơn trong quá trình chụp. Các thiết bị hỗ trợ khác như điện cực ở ngực, máy đo huyết áp, máy đo oxy sẽ giúp theo dõi các chỉ số của cơ thể để quá trình chụp được đảm bảo an toàn.
Ống thông sẽ được đưa vào ở vùng nách hoặc bẹn. Khu vực này được sát trùng và gây tê cục bộ. Một vết rạch nhỏ được thực hiện tại vị trí đặt ống thông. Ống nhựa ngắn được đưa vào lòng động mạch. Ống thông được luồn qua ống nhựa đi vào mạch máu đến tim hoặc động mạch vành.
Luồn ống thông không gây đau đớn và bệnh nhân không cảm thấy việc di chuyển khắp cơ thể. Thuốc cản quang được tiêm qua ống thông. Trong quá trình tiêm thuốc có thể có cảm giác hơi nóng. Hãy thông báo với bác sĩ nếu cảm thấy đau hoặc có cảm thấy bất thường.
Thuốc cản quang dễ được nhìn thấy trên hình ảnh X quang. Khi thuốc di chuyển qua các mạch máu, bác sĩ có thể quan sát dòng chảy và xác định bất kỳ tắc nghẽn hoặc chít hẹp mạch máu nào. Tùy thuộc vào những gì phát hiện được trong khi chụp động mạch, bác sĩ có thể quyết định thực hiện thêm các thủ thuật khác như nong mạch bằng bóng hoặc **đặt stent động mạch** bị hẹp. Các kỹ thuật không xâm lấn khác như siêu âm có thể giúp bác sĩ đánh giá tắc nghẽn được xác định.
Quá trình chụp động mạch mất khoảng một giờ và lâu hơn nếu kết hợp với các thủ thuật khác.
## **Sau khi chụp động mạch vành**
Khi chụp động mạch xong, ống thông được lấy ra khỏi cánh tay hoặc bẹn. Vết mổ được đóng lại. Bệnh nhân sẽ được đưa đến phòng hồi sức để quan sát và theo dõi. Khi tình trạng ổn định, bệnh nhân được trở về phòng và vẫn sẽ được theo dõi thường xuyên.
Bệnh nhân có thể cần nằm thẳng trong vài giờ để tránh chảy máu đối với trường hợp ống thông được đặt ở bẹn. Trong thời gian này, có thể cần chèn áp lực ở vết mổ để ngăn chảy máu và đẩy nhanh quá trình hồi phục.
Bệnh nhân có thể được về nhà trong ngày hoặc ngay ngày sau đó. **Lưu ý** cần uống nhiều nước để giúp loại bỏ thuốc cản quang ra khỏi cơ thể. 
Hỏi bác sĩ về việc tiếp tục dùng thuốc, tắm rửa và thực hiện các hoạt động bình thường khác. Cần tránh các hoạt động nặng trong vài tuần.
Nơi mạch máu đặt ống thông vẫn có thể chảy máu trong một thời gian ngắn, vì vậy vùng da kề cạnh có thể hơi sưng và bầm tím. Liên hệ với bác sĩ nếu:
  * Chảy máu, bầm tím mới hoặc sưng tại vị trí đặt ống thông;
  * Tăng mức độ đau hoặc khó chịu ở vị trí đặt ống thông;
  * Có dấu hiệu nhiễm trùng như đỏ da, chảy dịch hoặc sốt;
  * Có sự thay đổi về nhiệt độ hoặc màu sắc của chân hoặc cánh tay bên đặt ống thông;
  * Yếu hoặc tê ở chân hoặc cánh tay nơi đặt ống thông;
  * Đau ngực hoặc khó thở.


Nếu vị trí đặt ống thông chảy máu ồ ạt và không có biện pháp nào để ngừng chảy máu, hãy liên hệ cơ sở y tế gần nhất để được hỗ trợ.
## **Các kết quả chụp động mạch vành cho biết điều gì**
Chụp động mạch có thể cho biết các vấn đề với mạch máu như:
  * Cho biết có bao nhiêu động mạch vành bị tắc hoặc hẹp bởi các mảng xơ vữa;
  * Xác định vị trí tắc nghẽn trong mạch máu;
  * Hiển thị lưu lượng máu bị chặn qua các mạch máu;
  * Kiểm tra kết quả phẫu thuật bắc cầu động mạch vành trước đó;
  * Kiểm tra lưu lượng máu qua tim và mạch máu.


Việc biết được những thông tin này có thể giúp bác sĩ xác định mức độ nguy hiểm mà bệnh lý ở tim và phương pháp điều trị nào là tốt nhất cho bệnh nhân.
Xem thêm: [**Chụp CT mạch vành**](https://bvnguyentriphuong.com.vn/chan-doan-hinh-anh/ct-mach-vanh)
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [Chụp mạch vành là gì](https://bvnguyentriphuong.com.vn/tim-mach-can-thiep/chup-dong-mach-vanh-khi-nao-can-thuc-hien#chp-mch-vnh-l-g)
  * [Khi nào cần chụp động mạch vành](https://bvnguyentriphuong.com.vn/tim-mach-can-thiep/chup-dong-mach-vanh-khi-nao-can-thuc-hien#khi-no-cn-chp-ng-mch-vnh)
  * [Cần chuẩn bị những gì trước khi tiến hành chụp động mạch vành](https://bvnguyentriphuong.com.vn/tim-mach-can-thiep/chup-dong-mach-vanh-khi-nao-can-thuc-hien#cn-chun-b-nhng-g-trc-khi-tin-hnh-chp-ng-mch-vnh)
  * [Trước khi tiến hành thủ thuật](https://bvnguyentriphuong.com.vn/tim-mach-can-thiep/chup-dong-mach-vanh-khi-nao-can-thuc-hien#trc-khi-tin-hnh-th-thut)
  * [Trong quá trình chụp động mạch vành](https://bvnguyentriphuong.com.vn/tim-mach-can-thiep/chup-dong-mach-vanh-khi-nao-can-thuc-hien#trong-qu-trnh-chp-ng-mch-vnh)
  * [Sau khi chụp động mạch vành](https://bvnguyentriphuong.com.vn/tim-mach-can-thiep/chup-dong-mach-vanh-khi-nao-can-thuc-hien#sau-khi-chp-ng-mch-vnh)
  * [Các kết quả chụp động mạch vành cho biết điều gì](https://bvnguyentriphuong.com.vn/tim-mach-can-thiep/chup-dong-mach-vanh-khi-nao-can-thuc-hien#cc-kt-qu-chp-ng-mch-vnh-cho-bit-iu-g)



## ️ Điều trị cho bệnh nhân bị hẹp động mạch vành

  * [Chụp mạch vành:](https://bvnguyentriphuong.com.vn/tim-mach-can-thiep/dieu-tri-cho-benh-nhan-bi-hep-dong-mach-vanh#chp-mch-vnh)
  * [Nong mạch vành:](https://bvnguyentriphuong.com.vn/tim-mach-can-thiep/dieu-tri-cho-benh-nhan-bi-hep-dong-mach-vanh#nong-mch-vnh)
  * [Sau khi thực hiện thủ thuật bệnh nhân được theo dõi như sau:](https://bvnguyentriphuong.com.vn/tim-mach-can-thiep/dieu-tri-cho-benh-nhan-bi-hep-dong-mach-vanh#sau-khi-thc-hin-th-thut-bnh-nhn-c-theo-di-nh-sau)
  * [Áp dụng các phương pháp phòng ngừa để tránh tái phát:](https://bvnguyentriphuong.com.vn/tim-mach-can-thiep/dieu-tri-cho-benh-nhan-bi-hep-dong-mach-vanh#p-dng-cc-phng-php-phng-nga-trnh-ti-pht)


**Có 3 cách điều trị cho bệnh nhân bị hẹp động mạch vành:**
  * Dùng thuốc;
  * Mổ bắc cầu;
  * Can thiệp mạch vành qua da.


Can thiệp động mạch vành qua da là biện pháp không cần mổ, vừa làm giảm triệu chứng vừa giải quyết được nguyên nhân là sự hẹp lòng mạch. Khi can thiệp mạch vành, bệnh nhân được chụp mạch vành để đáng giá vị trí và mức độ tổn thương, sau đó bệnh nhân sẽ được nong rộng lòng mạch chỗ hẹp bằng bóng và đặt nột giá đỡ bằng kim loại (Stent) vĩnh viễn vào trong mạch giúp mạch máu ít khả năng bị tái hẹp trở lại.
## ****
Bệnh nhân hoàn toàn tỉnh táo trong quá trình thực hiện thủ thuật. Vị trí đâm kim và đưa ống thông vào cơ thể là động mạch vùng bẹn hay động mạch cổ tay. Bệnh nhân được gây mê trước khi đâm kim Sau khi ống thông đã được đưa vào động mạch vành thì dung dịch thuốc cản quang sẽ được bơn vào động mạch vành qua hệ thống ống thông và đầu chụp sẽ quay xung quanh vùng ngực bệnh nhân để lấy hình ảnh mạch vành ở mọi góc độ.
## **Nong mạch vành:**
Nếu có chỗ hẹp động mạch vành cần nong rộng thị bác sĩ sẽ luồn dây dẫn mềm rất nhỏ qua ống thông tới mạch vành, lách qua chỗ hẹp có tác dụng như đường ray cho các dụng cụ khác trượt lên. Bóng nong sẽ được luồn qua ống thông trượt trên dây dẫn đi tới vị trí hẹp và được bơm lên, trong lúc bơm bóng bênh nhân có thấy đau ngực thì báo cho bác sĩ biết. Sau khi lòng mạch vành đã mở rộng thì bóng sẽ đước làm xẹp xuống và rút ra. Nếu cần được đặt stent thì bóng gắn stent được luồn vào ống thông và được đưa đến chỗ hẹp. Bóng sẽ được bơm lên làm nở stent áp sát vào lòng mạch máu làm lòng mạch máu mở rộng ra, sau đó bóng sẽ được làm xẹp, tách khỏi stent và được hút ra ngoài, để stent ở lại vị trí đặt. Kết quả sau nong và đặt stent là mở rộng lòng mạch máu ở chỗ hẹp, làm máu qua chỗ hẹp nhiều hơn, giúp giảm triệu chứng đau ngực, cũng như cải thiện tiên lượng tốt hơn.
## **Sau khi thực hiện thủ thuật bệnh nhân được theo dõi như sau:**
  * Vị trí đâm kim để ống thuông đưa vào: sau khi can thiệp bệnh nhân sẽ được rút dụng cụ ở vị trí đâm kim và ép chặt ở vị trí này trong 20 - 30 phú để cầm máu và sau đó được giữ thẳng chân bên chọc kim trong 24 giờ.
  * Khi ho phải dùng tay ép chặt vị trí băng ép. Nếu có chảy máu, đau, tụ máu lan rộng ở vị trí chọc hay tê chân thị phải báo cho bác sĩ.
  * Sau thủ thuật phải uống nhiếu nước đẩ thải thuốc cản quang.
  * Nếu có dấu hiệu đau ngực, khó thở hay hồi hộp bệnh nhân nên báo ngay cho bác sĩ.
  * Theo dõi bệnh nhân sau can thiệp mạch vành:
  * Khi xuất viện, bệnh nhân sẽ được bác sĩ kê đơn thuốc để uống trong thời gian dài.
  * Dùng thuốc đầy đủ và khám bệnh định kỳ theo hướng dẫn của bác sĩ chuyên khoa tim mạch.
  * Không được tự ý bỏ thuốc hoặc đổi thuốc nếu không có ý kiến của bác sĩ chuyên khoa tim mạch.
  * Khi có xuất hiện đau ngực trở lại bệnh nhân phải đến khám ngay tại cơ sở y tế gần nhất, nhưng tốt hơn là gặp lại bác sĩ đã đặt strent cho mình.
  * Nghỉ ngơi và tập luyện theo hướng dẫn của bác sĩ chuyên khoa tim mạch.
  * Để phát hiện thiếu máu cơ tim tái phát phải kiểm tra gắng sức 6 tháng sau can thiệp.


## **Áp dụng các phương pháp phòng ngừa để tránh tái phát:**
  * Điều trị tăng huyết áp, tiểu đường, rối loạn mỡ máu.
  * Không hút thuốc, không uống rượu bia.
  * Không ăn mỡ động vật.


**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [Chụp mạch vành:](https://bvnguyentriphuong.com.vn/tim-mach-can-thiep/dieu-tri-cho-benh-nhan-bi-hep-dong-mach-vanh#chp-mch-vnh)
  * [Nong mạch vành:](https://bvnguyentriphuong.com.vn/tim-mach-can-thiep/dieu-tri-cho-benh-nhan-bi-hep-dong-mach-vanh#nong-mch-vnh)
  * [Sau khi thực hiện thủ thuật bệnh nhân được theo dõi như sau:](https://bvnguyentriphuong.com.vn/tim-mach-can-thiep/dieu-tri-cho-benh-nhan-bi-hep-dong-mach-vanh#sau-khi-thc-hin-th-thut-bnh-nhn-c-theo-di-nh-sau)
  * [Áp dụng các phương pháp phòng ngừa để tránh tái phát:](https://bvnguyentriphuong.com.vn/tim-mach-can-thiep/dieu-tri-cho-benh-nhan-bi-hep-dong-mach-vanh#p-dng-cc-phng-php-phng-nga-trnh-ti-pht)



## ️ Tim mạch can thiệp - Những tiến bộ

  * [Những tiến bộ trong điều trị các bệnh tim bẩm sinh](https://bvnguyentriphuong.com.vn/tim-mach-can-thiep/tim-mach-can-thiep-nhung-tien-bo#nhng-tin-b-trong-iu-tr-cc-bnh-tim-bm-sinh)
  * [Một số tiến bộ trong điều trị loạn nhịp tim](https://bvnguyentriphuong.com.vn/tim-mach-can-thiep/tim-mach-can-thiep-nhung-tien-bo#mt-s-tin-b-trong-iu-tr-lon-nhp-tim)
  * [Những tiến bộ trong phẫu thuật tim mạch](https://bvnguyentriphuong.com.vn/tim-mach-can-thiep/tim-mach-can-thiep-nhung-tien-bo#nhng-tin-b-trong-phu-thut-tim-mch)
  * [Triển vọng việc sử dụng tế bào gốc trong điều trị bệnh tim – mạch](https://bvnguyentriphuong.com.vn/tim-mach-can-thiep/tim-mach-can-thiep-nhung-tien-bo#trin-vng-vic-s-dng-t-bo-gc-trong-iu-tr-bnh-tim-mch)


## **Những tiến bộ trong điều trị các bệnh tim bẩm sinh**
Bệnh tim bẩm sinh gặp ngày một nhiều trong đời sống xã hội. Nhờ sự phát triển không ngừng của khoa học kỹ thuật, rất nhiều trường hợp bệnh tim bẩm sinh đã được phát hiện kịp thời và được chữa trị rất hiệu quả, nhiều trường hợp có thể khỏi hoàn toàn. Trước đây, phẫu thuật mở là phương pháp điều trị chủ yếu. Ngày nay, với tiến bộ của khoa học kỹ thuật, phương pháp điều trị can thiệp nội mạch qua ống thông ngày càng phát triển, nhiều bệnh lý tim bẩm sinh được điều trị bằng phương pháp ít xâm lấn hơn, đó là phương pháp can thiệp nội mạch qua ống thông.
– **Đó****n****g lỗ thông liên nhĩ** **bằ****n****g dụng cụ Amplatzer** qua đường ống thông (Hình 1).
Đây là một loại thiết bị đặc biệt bằng lưới kim loại nitinol, có hình dáng hai dù áp vào nhau và được nối với nhau bởi một eo. Khi đưa vào thì dụng cụ đã được thu gọn vào trong ống thông. Ống này được đưa vào tĩnh mạch đùi phải, đưa lên tâm nhĩ phải và qua ỗ thông liên nhĩ để sang tâm nhĩ trái. Qua đó đẩy dù lên, đầu tiên mở cánh phía tâm nhĩ trái, sau đó kéo lại mắc vách liên nhĩ và mở tiếp cánh còn lại bên tâm nhĩ phải để ép hai dù lại với nhau và như vậy vách liên nhĩ đã được đóng kín. Phương pháp này giúp tránh được cuộc mổ trên tim hở mà vẫn cho kết quả tương tự theo nhiều nghiên cứu trên thế giới.
**– Đóng ống động mạch trong** **‘bện****h còn ống động mạch’** **bằ****n****g dụng cụ Amplatzer** **h****oặ****c bằng cuộn búi dây** **ki****m loại**(coil). Cũng gần giống nguyên tắc trên nhưng dụng cụ có hình dáng khác để phù hợp với ống động mạch.
**– Đóng lỗ thông liên thất phần màng** bằng dụng cụ Amplatzer phức tạp hơn và đang trong giai đoạn thử nghiệm. Đây cũng là phương pháp hứa hẹn nhiều triển vọng và mang lại lợi ích đáng kể cho người bệnh.
– Một số bệnh lý bẩm sinh khác cững có thể được điều trị qua đường ống thông khá hiệu quả mà không cần phải mổ như: **n****o****n****g van động mạch phổi** **b****ị hẹp qua da, nong van** **độ****n****g mạch chủ bị hẹp** **qu****a da, nong hẹp eo động** **mạ****c****h chủ, đóng một số lỗ** **r****ò bất thường của động** **mạ****c****h vành hoặc các động** **mạ****c****h khác** …
– Bệnh cơ tim phì đại tắc nghẽn. Bệnh này trước đây thường phải mổ khoét vách liên thất, gặp nhiều biến chứng phức tạp. Nay có thể làm mỏng vách liên thất bằng cách tiêm cồn vào nhánh động mạch vành nuôi vách liên thất một cách chọn lọc qua đường ống thông. Phương pháp này rất ít xâm lấn so với mổ hở và cho kết quả rất khả quan.
## **Một số tiến bộ trong điều trị loạn nhịp tim**
– Trong thực hành bệnh tim-mạch, rối loạn nhịp tim có lẽ là vấn đề phức tạp nhất. Ngày nay, những tiến bộ không ngừng của khoa học kỹ thuật đã cho phép điều trị triệt để một số loạn nhịp tim như: nhịp nhanh trên thất, **hội chứng** **W****olff – Parkinson – White;** **nhịp nhanh thất** … và đặc biệt hiện nay đang chú trọng **điều trị** **rung nhĩ bằng phương pháp** **cắt đốt 3D**.
Hội chứng Wolff-Parkinson-White là một tình trạng bẩm sinh liên quan đến sự dẫn truyền bất thường của mô tim giữa các tâm nhĩ và các tâm thất, nói cách khác là có sự bất thường trong hệ thống điện của tim, dẫn đến nhịp nhanh trên thất.
**– Máy phá rung trực tiếp cấy trong buồng tim**(ICD) là biện pháp hữu hiệu ngăn ngừa được đột tử ở những đối tượng có nguy cơ rung thất hoặc nhịp nhanh thất ác tính.
**– Máy tạo nhịp tim** là thiết bị hữu ích đối với những người bị rối loạn nhịp tim khi hệ thống điện bình thường của tim bị trục trặc. Loại máy này được sử dụng nhiều nhất cho người có nhịp tim chậm do **hội chứng suy nút xoang** **hoặc block tim**. Trong những thập kỷ gần đây, máy tạo nhịp tim đã được cải tiến và khắc phục được nhiều nhược điểm, trở thành một thiết bị an toàn, hiệu quả và giúp người bệnh trở về với cuộc sống hàng ngày gần như bình thường.
– Ngoài ra, một loại máy tạo nhịp tim đ(lc biệt còn có thể giúp cải thiện chức năng tim cho người bệnh suy tim, gọi là máy sử dụng trong phương pháp **điều trị tái đồng bộ hóa cơ tim**(CRT). Máy tạo nhịp tim này có tác dụng tạo nhịp tim đồng bộ giữa 2 buồng tim trái và phải (ở bệnh nhân suy tim n(lng thường có sự co bóp không đồng bộ giữa 2 buồng tim).
## **Những tiến bộ trong phẫu thuật tim mạch**
– Việc điều trị bệnh tim bằng phương pháp phẫu thuật trước đây chủ yếu sử dụng đường mở ngực giữa xương ức. Phương pháp này có ưu điểm dễ dàng bộc lộ tim, tiếp cận các cấu trúc bên trong như van tim, các thành tim để sửa chữa những khiếm khuyết bệnh lý mà người bệnh mắc phải. Đây là tiêu chuẩn “vàng” trong phẫu thuật tim. Tuy vậy, đường mở ngực giữa xương ức vẫn có một số nhược điểm nhất định như đau nhiều, mất máu nhiều hơn, làm tăng thời gian nằm hồi sức và thở máy, từ đó làm tăng thời gian nằm viện, tính thẩm mỹ chưa cao.
– Bên cạnh đó còn một biến chứng quan trọng nữa là nhiễm trùng xương ức. 20 năm trở lại đây, phẫu thuật tim dần tiếp cận với xu hướng chung của ngoại khoa như giảm dần mức độ xâm lấn trên người bệnh mà vẫn bảo đảm được kết quả điều trị tốt nhất. Nhờ những thành quả của khoa học, **p****hẫu****thuật tim nội soi** ra đời và phát triển mạnh mẽ. Số lượng các trung tâm áp dụng kỹ thuật này cũng như tỷ lệ người bệnh được mổ nội soi so với người bệnh mổ hở không ngừng tăng cao.
– Trong đó, nổi bật là **p****hẫ****u** **thuật****v****a****n tim**(van hai lá, van động mạch chủ), **p****hẫ****u thuật tim bẩm sinh**(thông liên nhĩ, thông liên thất, còn ống động mạch), **p****hẫ****u thuật điều trị hẹp động mạch vành**. Lợi ích của phẫu thuật tim nội soi là giảm đau, giảm chảy máu, giảm truyền máu, giảm thời gian thở máy và nằm hồi sức giảm thời gian nằm viện và có tính thẩm mỹ cao.
## **Triển vọng việc sử dụng tế bào gốc trong điều trị bệnh tim – mạch**
Mặc dù nền y học đã có nhiều cố gắng nhằm cải thiện tình trạng sức khỏe cho người bệnh tim mạch nhưng tương lai của những bệnh nhân bị suy tim ứ huyết nặng vẫn ảm đạm. Thời gian gần đây, các tiến bộ trong sinh học phân tử, đặc biệt là phương pháp tế bào gốc đã thúc đẩy một hướng tiếp cận mới trong hỗ trợ điều trị với hy vọng là chúng ta có thể làm tăng sinh các tế bào cơ tim và các mạch máu nuôi cơ tim để thay thế cho các tế bào cơ tim đã bị mất chức năng. Đây sẽ là một hướng đi có nhiều tiềm năng trong tương lai. Những nghiên cứu còn đang được tiến hành và hy vọng về một tương lai của tế bào gốc là rất khả quan.
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh
[youtube.com/bvntp](http://youtube.com/bvntp)
  * [Những tiến bộ trong điều trị các bệnh tim bẩm sinh](https://bvnguyentriphuong.com.vn/tim-mach-can-thiep/tim-mach-can-thiep-nhung-tien-bo#nhng-tin-b-trong-iu-tr-cc-bnh-tim-bm-sinh)
  * [Một số tiến bộ trong điều trị loạn nhịp tim](https://bvnguyentriphuong.com.vn/tim-mach-can-thiep/tim-mach-can-thiep-nhung-tien-bo#mt-s-tin-b-trong-iu-tr-lon-nhp-tim)
  * [Những tiến bộ trong phẫu thuật tim mạch](https://bvnguyentriphuong.com.vn/tim-mach-can-thiep/tim-mach-can-thiep-nhung-tien-bo#nhng-tin-b-trong-phu-thut-tim-mch)
  * [Triển vọng việc sử dụng tế bào gốc trong điều trị bệnh tim – mạch](https://bvnguyentriphuong.com.vn/tim-mach-can-thiep/tim-mach-can-thiep-nhung-tien-bo#trin-vng-vic-s-dng-t-bo-gc-trong-iu-tr-bnh-tim-mch)



## Đặt stent mạch vành


## ️ Tràn dịch màng ngoài tim

  * [Nguyên nhân tràn dịch màng tim là gì?](https://bvnguyentriphuong.com.vn/noi-tim-mach/tran-dich-mang-ngoai-tim#nguyn-nhn-trn-dch-mng-tim-l-g)
  * [Xét nghiệm nào phát hiện ra tràn dịch màng ngoài tim? ](https://bvnguyentriphuong.com.vn/noi-tim-mach/tran-dich-mang-ngoai-tim#xt-nghim-no-pht-hin-ra-trn-dch-mng-ngoi-tim)


Bình thường có một lượng nhỏ chất lỏng xung quanh tim, chất này được tạo ra bởi cấu trúc giống như túi bao quanh tim. Thực chất nó là khoang giữa hai lớp của màng ngoài tim. Màng ngoài tim đóng vai trò như một hàng rào bảo vệ, thúc đẩy chức năng tim hoạt động hiệu quả và ngăn chặn sự dịch chuyển quá mức của tim. Chất lỏng dư thừa tích tụ trong cấu trúc túi này gọi là tràn dịch màng ngoài tim. Nhưng chất lỏng dư thừa này đến từ đâu? Thông thường, khi màng ngoài tim bị viêm, chất lỏng sẽ tăng tiết ra và tích tụ trong túi. Chất lỏng này cũng có thể là máu mà không do viêm như sau chấn thương ngực, phẫu thuật hoặc các biến chứng của các thủ thuật tim khác. Máu xung quanh tim được gọi là máu màng tim. 
Tràn dịch màng ngoài tim gây áp lực cho tim, ảnh hưởng đến chức năng của tim. Nếu không được điều trị, có thể dẫn đến suy tim hoặc tử vong.
## **Nguyên nhân tràn dịch màng tim là gì?**
  * Chấn thương vùng ngực
  * Nhiễm trùng: vi khuẩn lao, HIV, nấm…
  * Bệnh miễn dịch hệ thống: lupus, viêm khớp dạng thấp…
  * Liên quan đến điều trị như thuốc hoặc sau các phẫu thuật, thủ thuật vùng ngực, tia xạ.
  * Các vấn đề về tim: nhồi máu cơ tim, phình tách động mạch chủ ngực trong cơn đau ngực có thể gây tràn dịch màng ngoài tim có máu.
  * Ung thư: di căn của ung thư đến màng ngoài tim có thể gặp như ung thư vú, ung thư phổi, bệnh bạch cầu…
  * Suy thận: Nồng độ urê trong máu quá cao ([urê huyết](https://bvnguyentriphuong.com.vn/noi-than-tiet-nieu/ure-mau-va-nhung-dieu-can-biet)) có thể gây viêm màng ngoài tim.


## **Xét nghiệm nào phát hiện ra tràn dịch màng ngoài tim?**
Hiện nay có nhiều phương pháp chẩn đoán hình ảnh giúp xác định tràn dịch màng ngoài tim như Xquang, chụp cắt lớp vi tính ngực, cộng hưởng từ…Phương pháp đầu tay để chẩn đoán và đánh giá tràn dịch màng ngoài tim chính là siêu âm tim. Đây không chỉ là một phương pháp chẩn đoán nhanh, chính xác, chi phí phù hợp mà còn có độ nhạy, độ đặc hiệu cao. 
Hình ảnh trên siêu âm giúp ước lượng mức độ dịch, đôi khi còn có các đặc điểm giúp xác định loại dịch như máu với các dịch khác, đánh giá đáp ứng của tim với tình trạng dư thừa dịch trong khoang màng ngoài tim. Hơn thế nữa siêu âm tim cũng là phương pháp hữu hiệu nhất để theo dõi diễn biến đáp ứng trong quá trình điều trị. Đặc biệt trong các trường hợp có chèn ép tim nguy hiểm, có chỉ định đặt dẫn lưu màng ngoài tim cấp cứu, siêu âm tim giúp hướng dẫn xác định vị trí chọc dò, giảm tối đa nguy cơ tai biến thủ thuật. Hiện nay theo các khuyến cáo của các hiệp hội y học trên thế giới, siêu âm vẫn là có vai trò quan trọng không thể thiếu trong bệnh lý tràn dịch màng ngoài tim, đặc biệt khi có biến chứng ép tim.
Tìm hiểu thêm: [Siêu âm tim](https://bvnguyentriphuong.com.vn/chan-doan-hinh-anh/cac-phuong-phap-sieu-am-tim-va-khi-nao-can-sieu-am-tim)
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [Nguyên nhân tràn dịch màng tim là gì?](https://bvnguyentriphuong.com.vn/noi-tim-mach/tran-dich-mang-ngoai-tim#nguyn-nhn-trn-dch-mng-tim-l-g)
  * [Xét nghiệm nào phát hiện ra tràn dịch màng ngoài tim? ](https://bvnguyentriphuong.com.vn/noi-tim-mach/tran-dich-mang-ngoai-tim#xt-nghim-no-pht-hin-ra-trn-dch-mng-ngoi-tim)



## ️ Can thiệp mạch máu là gì?

  * [Can thiệp mạch máu là gì?](https://bvnguyentriphuong.com.vn/tim-mach-can-thiep/can-thiep-mach-mau-la-gi#can-thip-mch-mu-l-g)
  * [Tiến hành thủ thuật](https://bvnguyentriphuong.com.vn/tim-mach-can-thiep/can-thiep-mach-mau-la-gi#tin-hnh-th-thut)


## **Can thiệp mạch máu là gì?**
Trong thuật ngữ nong mạch, "angio" có nghĩa là mạch máu và "plasty" là phẫu thuật. Trong PCI, chữ "P" là viết tắt của da hoặc "qua da" trong khi mạch vành là các mạch máu xung quanh cung cấp máu cho tim.
Can thiệp mạch là một phương pháp điều trị thông thường cho bệnh tim mạch vành (_coronary heart disease_ /CHD) và đau tim (acute coronary syndrome).
Trong những tình trạng bệnh lý này có sự tích tụ của mảng bám, hoặc xơ vữa động mạch trên thành của các động mạch. Khi mảng bám tích tụ khiến cho các động mạch hẹp lại và có thể bị tắc nghẽn.
Trong cơn đau tim, mảng bám có thể vỡ ra làm tràn cholesterol vào động mạch dẫn đến hình thành huyết khối chặn lòng mạch làm giảm lưu lượng máu.
So với phẫu thuật tim, nong mạch vành là một thủ thuật ít xâm lấn. Bác sĩ có thể đề nghị nong mạch vành để:
  * Điều trị tình trạng căng thẳng bất thường
  * Tăng lưu lượng máu đến tim;
  * Giảm các cơn đau thắt ngực;
  * Cải thiện việc cung cấp máu cho cơ tim trong hoặc sau cơn đau tim;
  * Hỗ trợ thêm hoạt động cho những người bị đau ngực.


## **Phân loại**
Có hai loại nong mạch chính:
Tạo hình bóng bằng bóng, bao gồm sử dụng áp lực của một quả bóng bơm hơi để làm sạch mảng bám làm hẹp động mạch. Điều này hiếm khi được thực hiện đơn lẻ trừ trường hợp không thể đặt stent ở vị trí hẹp.
Stent trong lòng động mạch là một ống hoặc stent được làm từ lưới thép không gỉ. Stent giúp ngăn ngừa hẹp động mạch tái phát sau khi nong mạch vành. Stent có thể được làm bằng kim loại trần hoặc có lớp phủ thuốc. Stent có phủ thuốc (DES) giúp ngăn ngừa việc các mảng bám tích tụ lại trong lòng động mạch ngay tại ví trí đặt stent. Hiện nay, hầu hết các trường hợp nong mạch đều sử dụng DES và rất ít sử dụng stent kim loại trần.
## **Chuẩn bị**
Can thiệp mạch là một thủ thuật ít xâm lấn, tuy nhiên vẫn cần chuẩn bị theo các hướng dẫn của bác sĩ. Bệnh nhân cần thông báo cho bác sĩ về bất kỳ loại thuốc và chất bổ sung đang sử dụng. Trong một số trường hợp có thể cần phải ngừng dùng các loại thuốc này, đặc biệt là thuốc làm loãng máu trước khi thực hiện thủ thuật.
Ngoài ra, bệnh nhân cần nhịn ăn trong vài giờ trước khi tiến hành nong mạch. Các xét nghiệm thận cũng có thể cần được thực hiện trước đó nhằm tránh việc thuốc cản quang được sử dụng trong quá trình tiến hành có thể ảnh hưởng đến chức năng thận.
## **Tiến hành thủ thuật**
Trước khi bắt đầu nong mạch vành, bác sĩ sẽ sát khuẩn và làm tê khu vực mà ống thông đi vào cơ thể, vị trí đặt ống thông thường là háng hoặc cổ tay. Ống thông được luồn vào động mạch và di chuyển phía động mạch vành, toàn bộ quá trình luồn ống được theo dõi bởi hệ thống X-quang tăng sáng truyền hình.
Khi đặt ống thông vào đúng vị trí, thuốc tương phản được tiêm qua động mạch, giúp xác định tắc nghẽn xung quanh tim. Khi xác định được vị trí tắc nghẽn, ống dẫn có bóng ở đầu được đưa vào qua ống thông thứ hai. Khi đã ở vị trí cần can thiệp, bóng được bơm phồng đẩy mảng bám tích tụ ra và làm nở rộng lòng động mạch. Stent được đặt để giữ cho động mạch không bị hẹp trở lại. Quá trình nong mạch vành có thể mất từ ​​30 phút đến vài giờ.
## **Phục hồi**
Khi nong mạch hoàn tất, ống thông và băng chẹn sẽ được tháo bỏ. Khu vực đặt ống thông sẽ có cảm giác đau nhức, bầm tím và có thể chảy máu.
Thông thường, bệnh nhân cần nằm viện trong một khoảng thời gian để theo dõi. Sau khi xuất viện cần hạn chế nâng vật nặng hay vận động quá sức trong khoảng một tuần sau đó.
Tái khám sau khi nong mạch vành có vai trò quan trọng trong việc đánh giá sự phục hồi của từng cá nhân, điều chỉnh thuốc và xây dựng kế hoạch điều trị liên tục cho sức khỏe tim mạch của bệnh nhân.
## **Nguy cơ**
Nhìn chung, nong mạch vành là một phương pháp an toàn không có biến chứng. Ước tính cho biết tỷ lệ biến chứng chỉ là 5%, con số này còn thấp hơn ở các viện lớn chuyên về can thiệp tim mạch.
Mặc dù các biến chứng do nong mạch vành rất hiếm, nhưng có thể bao gồm:
  * Chảy máu kéo dài từ vị trí đặt ống thông;
  * Tổn thương mạch máu, thận hoặc động mạch;
  * Phản ứng dị ứng với thuốc cản quang;
  * Đau tức ngực;
  * Rối loạn nhịp tim, hoặc nhịp tim bất thường;
  * Tắc nghẽn mạch máu cần can thiệp khẩn cấp;
  * Huyết khối;
  * Đột quỵ;
  * Đau tim;
  * Rách hoặc tổn thương động mạch hoặc mạch máu lớn;
  * Tử vong.


Những người có nguy cơ biến chứng cao hơn từ can thiệp mạch vành khi đồng thời có các tình trạng sau:
  * Tuổi cao;
  * Bệnh tim;
  * Một số động mạch bị tắc;
  * Bệnh thận mãn tính.


Cũng có khả năng động mạch bị chặn lại với mảng bám do sự chậm nội mạc hóa động mạch vành ở vị trí đặt stent và phản ứng của lớp Polymer là nguyên nhân gây ra huyết khối muộn và rất muộn trong stent.
## **Tóm tắt**
Can thiệp mạch là một thủ thuật ít xâm lấn sử dụng để thông các động mạch bị tắc và cải thiện lưu lượng máu trong tim. Phương pháp nong mạch vành thường dùng để điều trị các vấn đề về tim cấp tính.
Đây là một can thiệp cần thiết, mặc dù động mạch có thể bị tắc trở lại và có tỉ lệ rủi ro nhỏ các biến chứng trong một số trường hợp.
Xem tiếp: [**Kỹ thuật chụp hình mạch máu được tiến hành như thế nào?**](https://bvnguyentriphuong.com.vn/tim-mach-can-thiep/ky-thuat-chup-hinh-mach-mau-duoc-tien-hanh-nhu-the-nao)
**Bệnh viện Nguyễn Tri Phương** - Bệnh viện Đa khoa Hạng I Thành phố Hồ Chí Minh
[youtube.com/bvntp](http://youtube.com/bvntp)
  * [Can thiệp mạch máu là gì?](https://bvnguyentriphuong.com.vn/tim-mach-can-thiep/can-thiep-mach-mau-la-gi#can-thip-mch-mu-l-g)
  * [Tiến hành thủ thuật](https://bvnguyentriphuong.com.vn/tim-mach-can-thiep/can-thiep-mach-mau-la-gi#tin-hnh-th-thut)



## ️ Chụp động mạch phổi: ý nghĩa lâm sàng kết quả

  * [Nhận định chung](https://bvnguyentriphuong.com.vn/tim-mach-can-thiep/chup-dong-mach-phoi-y-nghia-lam-sang-ket-qua#nhn-nh-chung)
  * [Khi nào cần chụp động mạch phổi](https://bvnguyentriphuong.com.vn/tim-mach-can-thiep/chup-dong-mach-phoi-y-nghia-lam-sang-ket-qua#khi-no-cn-chp-ng-mch-phi)
  * [Chuẩn bị chụp động mạch phổi](https://bvnguyentriphuong.com.vn/tim-mach-can-thiep/chup-dong-mach-phoi-y-nghia-lam-sang-ket-qua#chun-b-chp-ng-mch-phi)
  * [Cảm giác của bệnh nhân khi chụp động mạch phổi](https://bvnguyentriphuong.com.vn/tim-mach-can-thiep/chup-dong-mach-phoi-y-nghia-lam-sang-ket-qua#cm-gic-ca-bnh-nhn-khi-chp-ng-mch-phi)
  * [Những nguy cơ khi chụp động mạch phổi](https://bvnguyentriphuong.com.vn/tim-mach-can-thiep/chup-dong-mach-phoi-y-nghia-lam-sang-ket-qua#nhng-nguy-c-khi-chp-ng-mch-phi)
  * [Ý nghĩa lâm sàng kết quả chụp động mạch phổi](https://bvnguyentriphuong.com.vn/tim-mach-can-thiep/chup-dong-mach-phoi-y-nghia-lam-sang-ket-qua#-ngha-lm-sng-kt-qu-chp-ng-mch-phi)
  * [Yếu tố ảnh hưởng đến chụp động mạch phổi](https://bvnguyentriphuong.com.vn/tim-mach-can-thiep/chup-dong-mach-phoi-y-nghia-lam-sang-ket-qua#yu-t-nh-hng-n-chp-ng-mch-phi)
  * [Điều cần biết thêm](https://bvnguyentriphuong.com.vn/tim-mach-can-thiep/chup-dong-mach-phoi-y-nghia-lam-sang-ket-qua#iu-cn-bit-thm)


## **Nhận định chung**
Chụp động mạch phổi là kỹ thuật hình ảnh sử dụng thuốc cản quang và thiết bị đặc biệt để khảo sát lưu lượng máu trong các động mạch phổi.
Trong quá trình chụp, một ống nhỏ gọi là “kim luồn” được đặt vào mạch máu ở vùng bẹn (tĩnh mạch đùi) hoặc ngay trên khuỷu tay (tĩnh mạch cánh tay). Mục đích là để dẫn thuốc cản quang vào bộ phận cần được khảo sát. Sau đó, thuốc cản quang (có thành phần iod) được tiêm vào cơ thể. Sau khi chụp, dữ liệu hình ảnh sẽ được in ra thành các tấm film và đồng thời được lưu trữ trong máy tính.
Chụp động mạch phổi là để khảo sát các nhánh động mạch phổi và các mạch máu trong phổi, nó có thể giúp phát hiện tình trạng hẹp hoặc tắc nghẽn các mạch máu trong phổi.
## **Khi nào cần chụp động mạch phổi**
Chụp động mạch phổi có thể được thực hiện để khảo sát các nhánh động mạch phổi, để tìm kiếm các bệnh lý về phổi hoặc tìm các nguyên nhân khác gây tắc nghẽn hoặc hẹp mạch máu.
## **Chuẩn bị chụp động mạch phổi**
Trước khi thực hiện, hãy thông báo với bác sĩ về những tình trạng sau đây:
  * Đang có thai hoặc nghi ngờ có thai.
  * Đang cho con bú. Bạn cần phải sử dụng sữa công thức cho bé trong 1-2 ngày đầu sau khi chụp mạch máu phổi có tiêm thuốc tương phản. Vì những chất này thường được đào thải khỏi cơ thể nhanh nhất là 24h.
  * Bị dị ứng với thuốc cản quang iốt.
  * Trước đây đã từng có một phản ứng dị ứng nghiêm trọng (sốc phản vệ) từ bất kỳ tác nhân nào, chẳng hạn như nọc độc của ong đốt hoặc do ăn thức ăn lạ.
  * Bị hen suyễn.
  * Bị dị ứng với bất kỳ loại thuốc nào.
  * Có bất kỳ vấn đề đông cầm máu hoặc đang dùng thuốc làm loãng máu.
  * Có tiền sử bệnh thận hoặc tiểu đường, đặc biệt nếu dùng metformin (như Glucophage) để kiểm soát bệnh tiểu đường. Thuốc cản quang được sử dụng trong chụp động mạch có thể gây tổn thương thận trên những người có chức năng thận kém.
  * Không được ăn hoặc uống bất kỳ thứ gì trong 4 đến 8 giờ trước khi chụp động mạch. Trong một số trường hợp, bạn có thể phải tạm ngưng aspirin, các chất làm loãng máu khác trong vài ngày trước khi thực hiện và trong 1 ngày sau khi hoàn thành thủ thuật. Nếu đang dùng những loại thuốc này, hãy thông báo với bác sĩ để họ được biết.
  * Chụp động mạch phổi có thể được thực hiện đối với bệnh nhân nội trú hoặc ngoại trú. Nếu là bệnh nhân ngoại trú, trong một số trường hợp bạn có thể cần phải ở lại bệnh viện theo dõi vài giờ sau khi hoàn thành thủ thuật. 
  * Thủ thuật này có thể mất vài giờ, vì vậy bạn nên đi tiểu trước khi bước vào phòng chụp.
  * Ngoài ra trước khi chụp động mạch, bạn cần phải thực hiện 1 số xét nghiệm máu, chẳng hạn như xét nghiệm về chức năng đông máu, nitơ, urê máu (BUN) và creatinine máu.
  * Bạn cần phải ký vào một mẫu đơn đồng thuận sau khi đã được tư vấn các rủi ro tiềm ẩn của quá trình này và đồng ý thực hiện.
  * Hãy trao đổi với bác sĩ về bất kỳ mối quan tâm nào của bạn: các xét nghiệm nào cần hoàn thành trước khi chụp, rủi ro của quá trình này, cách thực hiện hoặc kết quả sẽ có ý nghĩa gì.


## **Cảm giác của bệnh nhân khi chụp động mạch phổi**
Bạn có thể cảm thấy một vết chích hoặc tê nhẹ ở vị trí kim luồn được đặt. Hầu hết mọi người không bị đau khi kim nằm trong mạch máu.
Bạn có thể cảm thấy áp lực trong mạch máu khi thuốc chảy vào. Hãy thông báo cho bác sĩ biết nếu đang cảm thấy đau.
Bạn có thể sẽ cảm thấy một chút nóng nhẹ khi thuốc cản quang được đưa vào cơ thể. Cảm giác này chỉ kéo dài trong vài giây. Đối với một số người thì cảm giác này rất khó chịu và đối với những người khác thì lại rất bình thường.
Bạn có thể cảm thấy muốn ho nhưng cần cố gắng giữ hơi thở cho đến khi được yêu cầu thở.
Bạn có thể bị đau đầu, đỏ bừng mặt hoặc có vị mặn hoặc kim loại trong miệng sau khi tiêm thuốc cản quang. Tuy nhiên những cảm giác này không tồn tại lâu. Một số người có thể cảm thấy đau bụng hoặc có thể nôn, nhưng điều này thì không thường gặp.
Sau khi hoàn thành xong thủ thuật, bạn có thể cảm thấy đau nhẹ và bầm tím tại vị trí đặt kim.
## **Những nguy cơ khi chụp động mạch phổi**
Nguy cơ của các biến chứng nặng từ kỹ thuật chụp động mạch phổi là rất nhỏ, nhưng đôi lúc cũng có một số vấn đề xảy ra. Trong hầu hết các trường hợp, các vấn đề xảy ra trong vòng 2 giờ đầu sau khi chụp. Nếu sự có sự cố xảy ra trong quá trình thực hiện, thủ thuật có thể không được hoàn thành. Một số trường hợp hiếm gặp, có thể cần điều trị khẩn cấp bao gồm cả việc phải phẫu thuật.
Có nguy cơ xảy ra phản ứng dị ứng với thuốc cản quang chứa thành phần iod. Phản ứng có thể nhẹ (ngứa, phát ban) hoặc nghiêm trọng (khó thở hoặc sốc đột ngột). Hầu hết các phản ứng có thể được điều trị bằng thuốc. Bạn cần phải thông báo với bác sĩ nếu cơ thể từng bị sốt cỏ khô, hen suyễn, hoặc dị ứng iốt hoặc dị ứng thực phẩm nào đó.
Chảy máu từ vị trí kim luồn có thể xảy ra. Ngoài ra, cục máu đông có thể hình thành nơi kim luồn. Điều này có thể gây ra một số tắc nghẽn dòng máu từ cánh tay hoặc chân.
Thuốc cản quang iốt được sử dụng trong kỹ thuật này có thể gây mất nước hoặc tổn thương trực tiếp đến thận. Đây là một mối quan tâm đặc biệt cho những người có vấn đề về thận, tiểu đường hoặc có tình trạng mất nước. 
Luôn có những tổn thương nhỏ cho các tế bào hoặc mô khi tiếp xúc với bất kỳ tia bức xạ nào, ngay cả ở mức độ thấp được sử dụng cho kỹ thuật này.
## **Ý nghĩa lâm sàng kết quả chụp động mạch phổi**
Chụp động mạch phổi là kỹ thuật hình ảnh sử dụng thuốc cản quang và thiết bị đặc biệt để khảo sát lưu lượng máu trong các động mạch phổi. Bác sĩ có thể cho biết một số kết quả ngay sau khi chụp xong và kết quả hoàn chỉnh thường được trả cho bệnh nhân trong ngày.
## **Yếu tố ảnh hưởng đến chụp động mạch phổi**
Có những lý do khiến bạn không được thực hiện kỹ thuật này:
  * Có thai. Chụp động mạch phổi thường không được thực hiện trong thai kỳ vì tia bức xạ làm ảnh hưởng xấu sự phát triển của thai nhi.
  * Đang có một mạch máu bị tắc nghẽn hoặc một vấn đề mạch máu khác cần phải xử trí ưu tiên.
  * Có tình trạng tăng áp động mạch phổi.
  * Không thể nằm yên trong quá trình thủ thuật.
  * Có nhịp tim bất thường. 


## **Điều cần biết thêm**
Chụp cắt lớp vi tính động mạch phổi (CTA) hoặc chụp cộng hưởng từ mạch máu phổi (MRA) có thể là một lựa chọn thay vì chụp động mạch. Hai kỹ thuật này ít xâm lấn hơn so với kỹ thuật chụp động mạch phổi. Một số kỹ thuật chụp cộng hưởng từ và tất cả các kỹ thuật chụp cắt lớp vi tính khảo sát mạch máu phổi yêu cầu tiêm chất tương phản. CTA cũng liên quan đến phơi nhiễm phóng xạ. Một số bác sĩ có thể muốn kết quả từ chụp động mạch trước khi phẫu thuật để điều trị những mạch máu bị tổn thương hoặc các bất thường khác.
Đối với những người có vấn đề về thận, tiểu đường hoặc có tình trạng mất nước, bác sĩ sẽ có phương án điều chỉnh để ngăn ngừa tổn thương thận. Nếu bạn có tiền sử về các vấn đề về thận, các xét nghiệm máu (creatinine, nitơ urê máu) có thể được thực hiện trước khi chụp động mạch để đảm bảo rằng thận đang hoạt động tốt.
Trong một vài trường hợp hiếm, bạn cần phải trải qua phẫu thuật để sửa chữa lỗ rò trên mạch máu nơi đặt kim luồn. Ngoài ra còn có một chất có thể được sử dụng để giúp bịt lỗ rò và cầm máu. Các chất này thường được cơ thể hấp thụ trong vài tháng.
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [Nhận định chung](https://bvnguyentriphuong.com.vn/tim-mach-can-thiep/chup-dong-mach-phoi-y-nghia-lam-sang-ket-qua#nhn-nh-chung)
  * [Khi nào cần chụp động mạch phổi](https://bvnguyentriphuong.com.vn/tim-mach-can-thiep/chup-dong-mach-phoi-y-nghia-lam-sang-ket-qua#khi-no-cn-chp-ng-mch-phi)
  * [Chuẩn bị chụp động mạch phổi](https://bvnguyentriphuong.com.vn/tim-mach-can-thiep/chup-dong-mach-phoi-y-nghia-lam-sang-ket-qua#chun-b-chp-ng-mch-phi)
  * [Cảm giác của bệnh nhân khi chụp động mạch phổi](https://bvnguyentriphuong.com.vn/tim-mach-can-thiep/chup-dong-mach-phoi-y-nghia-lam-sang-ket-qua#cm-gic-ca-bnh-nhn-khi-chp-ng-mch-phi)
  * [Những nguy cơ khi chụp động mạch phổi](https://bvnguyentriphuong.com.vn/tim-mach-can-thiep/chup-dong-mach-phoi-y-nghia-lam-sang-ket-qua#nhng-nguy-c-khi-chp-ng-mch-phi)
  * [Ý nghĩa lâm sàng kết quả chụp động mạch phổi](https://bvnguyentriphuong.com.vn/tim-mach-can-thiep/chup-dong-mach-phoi-y-nghia-lam-sang-ket-qua#-ngha-lm-sng-kt-qu-chp-ng-mch-phi)
  * [Yếu tố ảnh hưởng đến chụp động mạch phổi](https://bvnguyentriphuong.com.vn/tim-mach-can-thiep/chup-dong-mach-phoi-y-nghia-lam-sang-ket-qua#yu-t-nh-hng-n-chp-ng-mch-phi)
  * [Điều cần biết thêm](https://bvnguyentriphuong.com.vn/tim-mach-can-thiep/chup-dong-mach-phoi-y-nghia-lam-sang-ket-qua#iu-cn-bit-thm)



