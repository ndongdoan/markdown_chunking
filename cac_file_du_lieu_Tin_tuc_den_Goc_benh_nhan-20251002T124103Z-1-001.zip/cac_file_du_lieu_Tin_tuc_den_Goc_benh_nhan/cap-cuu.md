## CÁC NGUYÊN LÝ TIẾP CẬN & QUẢN LÝ ĐIỀU TRỊ SUY HÔ HẤP CẤP TẠI CẤP CỨU

Xem toàn bộ tài liệu [**tại đây**](https://bvnguyentriphuong.com.vn/uploads/112023/files/C%C3%81C%20NGUY%C3%8AN%20L%C3%9D%20TI%E1%BA%BEP%20C%E1%BA%ACN%20CH%E1%BA%A8N%20%C4%90O%C3%81N%20-%20%C4%90I%E1%BB%80U%20TR%E1%BB%8A%20SUY%20H%C3%94%20H%E1%BA%A4P%20C%E1%BA%A4P.pdf)
#### Nội dung trong file:

CÁC NGUYÊN LÝ TI ẾP CẬN & QU ẢN LÝ ĐI ỀU 
TRỊ SUY HÔ H ẤP CẤP TẠI CẤP CỨU 
Ths. Bs H ồ Hoàng Kim  
Bệnh vi ện Nguy ễn Tri Phương  
Suy hô h ấp thể hiện sự suy gi ảm kh ả năng duy trì trao đ ổi khí đ ầy đủ của phổi 
và đư ợc đặc trưng b ởi sự bất thường của áp l ực riêng ph ần các  khí trong máu . 
Thông thư ờng thì nó đư ợc định nghĩa là  PaO2 <  8 kPa [60 mmHg] có ho ặc 
không có tăng CO2 máu [PaCO2 >6 kPa (46 mmHg)].  
Suy hô h ấp cấp có th ể xảy ra trên n ền chức năng hô h ấp bình thư ờng trư ớc đó 
hoặc đã có quá trình b ệnh lý m ạn tính đã x ảy ra. 
Mặc dù đôi khi ranh gi ới suy hô h ấp cấp hay m ạn có th ể không rõ ràng nhưng 
việc quản lý đi ều trị suy hô h ấp thư ờng ph ụ thuộc vào m ức độ và th ời gian c ủa các 
triệu chứng. 
Sinh lý  
Xét v ề mặt sinh lý, hô h ấp được thực hiện thông qua s ự điều hoà và ph ối hợp 
của 3 b ộ phận – bộ máy; suy hô h ấp cấp xuất hiện khi m ột hoặc nhi ều bộ phận này 
bị suy gi ảm hay m ất chức năng do tác đ ộng bệnh lý – chấn thương – độc chất: 
1. Bộ phận điều hoà và đi ều khi ển hô h ấp: Hệ thống th ần kinh trung ương 
(CNS) s ẽ điều hành nh ịp độ (tốc độ hô hấp – nhịp thở; kiểu thở) và biên đ ộ 
(thể tích thông khí – thở nông hay sâu). Nó xác đ ịnh thông khí phút, là tích s ố 
của thể tích và t ốc độ khí lưu thông. Do đó, trung khu đi ều hòa hô h ấp tăng 
lên d ẫn đến tăng thông khí, trong khi ức chế trung khu hô h ấp dẫn đến giảm 
thông khí.  
2. Bộ phận có ch ức năng ho ạt động như là m ột máy “bơm” khí và các “ ống dẫn” 
của nó – các cơ hô h ấp chính và ph ụ (thành ng ực) cũng như h ệ thống các 
đường dẫn khí  (nhu mô ph ổi). Hai y ếu tố ảnh hư ởng đến hiệu suất của bộ 
phận này – sức cản và đ ộ giãn n ở. Tăng s ức cản của đường th ở hoặc giảm độ 
giãn n ở của phổi hoặc thành ng ực làm gi ảm hiệu quả của "máy bơm" và tăng 
công th ở (WOB). WOB tăng kéo dài có th ể dẫn đến mệt mỏi khi th ở, giảm 
thông khí và suy hô h ấp. 3. Thành ph ần thứ ba của bộ máy hô h ấp, bộ trao đ ổi khí bao g ồm các “túi khí ” 
(phế nang) đư ợc bao quanh b ởi các mao m ạch ph ổi – đơn v ị phổi. Khi b ộ 
phận thứ 2 được điều khi ển tốt bởi bộ phận thứ 1 sẽ cung c ấp khí đ ến phế 
nang, khi quá trình trao đ ổi khí x ảy ra th ụ động qua độ chênh  áp su ất giữa các 
thành ph ần khí trong máu và trong ph ế nang . Hai y ếu tố quyết định hi ệu quả 
của việc trao đổi khí này – bề mặt tiếp xúc gi ữa phế nang và mao m ạch và 
thời gian v ận chuy ển của máu trong mao m ạch ph ổi. Th ời gian vận chuy ển 
của máu trong mao m ạch ph ổi kho ảng 0,7 giây là đ ủ để trao đ ổi khí tr ừ khi có 
vấn đề với bề mặt phế nang -mao m ạch. Các tình tr ạng làm tăng đ ộ dày c ủa bề 
mặt tiếp xúc ph ế nang -mao m ạch (ví d ụ như d ịch trong ph ế nang, viêm k ẽ) 
làm gi ảm kh ả năng vận chuy ển khí. Tuy nhiên, do kh ả năng khu ếch tán c ủa 
CO2 g ấp kho ảng 20 l ần so v ới O2, nh ững bất thường như v ậy của bộ trao đ ổi 
khí thư ờng dẫn đến tình tr ạng giảm oxy máu đơn thu ần trừ khi có tình tr ạng 
“kiệt quệ” hô hấp xảy ra do tăng WOB.  
Phân lo ại suy h ô hấp cấp. 
Có hai phương pháp phân lo ại suy hô h ấp cấp tại cấp cứu; đó là phương pháp 
sinh lý – dựa trên b ất thường về khí máu và phương pháp sinh lý b ệnh – dựa và quá 
trình b ệnh nền tảng gây ra suy hô h ấp. 
Phương pháp sinh lý h ọc; thì suy hô h ấp cấp được phân thành 2 lo ại: 
1. Loại I ho ặc suy hô h ấp thiếu oxy máu đư ợc định nghĩa là tình tr ạng thi ếu oxy 
máu (PaO2 <60 mmHg) v ới PaCO2 bình thư ờng ho ặc thấp. 
2. Loại II ho ặc suy hô h ấp tăng CO2 máu đư ợc định nghĩa là s ự hiện diện của 
tăng CO2 máu (PaCO2 >46 mmHg) có hoặc không có tình tr ạng thi ếu oxy 
máu cùng t ồn tại 
Phương pháp sinh lý b ệnh, suy hô h ấp được phân thành b ốn loại.  
1. Loại I, b ất thường sinh lý b ệnh là  tình tr ạng “ngập lụt” phế nang – tức là ph ế 
nang tràn đ ầy các d ịch xu ất tiết hay viêm hay máu - dẫn đến shunt trong ph ổi 
– giảm kh ả năng khu ếch tán . Những bệnh nhân này b ị suy hô h ấp do thi ếu oxy 
chiếm ưu th ế, mặc dù trong nh ững trư ờng hợp rất nặng, tình tr ạng ứ đọng CO2 
có th ể tăng lên. Các nguyên nhân ph ổ biến bao g ồm phù ph ổi do tim và không 
do tim, viêm ph ổi và xu ất huy ết phế nang.  
 Bảng1. Phân lo ại suy hô h ấp và nguyên nhân  
Phân lo ại theo 
sinh lý b ệnh Phân lo ại theo 
sinh lý  Nguyên nhân  
Loại I – (V/Q) 
không phù h ợp 
Shunt - nối tắt 
Giảm kh ả năng 
khuếch tán  Suy hô h ấp cấp 
giảm oxy máu - 
AHRF  Dịch phù tràn ng ập ph ế nang và mô k ẽ 
(phù ph ổi do tim và không do tim, ARDS) . 
Mủ/nhiễm trùng – nhiễm trùng ph ế nang 
và mô k ẽ (viêm ph ổi, viêm ph ổi kẽ). 
Máu – xuất huy ết phế nang  
Protein – phế nang ch ứa đầy protein  
Loại II – suy hô 
hấp do gi ảm 
thông khí ph ế 
nang.  Suy hô h ấp tăng 
CO2 máu.  Ức chế thần kinh trung ương – dùng thu ốc 
quá li ều và ng ộ độc, nhi ễm trùng, ch ấn 
thương, đ ột quỵ. 
Tủy sống – bại liệt, cắt ngang, viêm t ủy. 
Thần kinh ngo ại biên – Hội ch ứng 
Guillain -Barre, t ổn thương thần kinh 
hoành, xơ c ứng teo cơ m ột bên . 
Thành ng ực – gù v ẹo cột sống, ch ấn 
thương thành ng ực, viêm c ột sống dính 
khớp. 
Cơ – nhược cơ, b ệnh cơ, h ạ kali máu, h ạ 
phosphat máu, viêm đa cơ . 
Giảm thông khí ph ế nang – COPD, xơ 
nang n ặng, xơ ph ổi giai đo ạn cu ối, tắc 
nghẽn đường th ở. 
Loại III – suy hô 
hấp do x ẹp phổi Suy hô h ấp giảm 
oxy máu  Xẹp ph ổi sau ph ẫu thu ật (shunt trong 
phổi), xẹp phổi thuỳ đáy do b ệnh lý trong 
ổ bụng, thuyên t ắc phổi. 
Loại IV – suy hô 
hấp do gi ảm tưới 
máu cơ hô h ấp do 
shock  Suy hô h ấp tăng 
CO2 máu  Shock tim; shock gi ảm th ể tích; shock 
phân ph ối. 
 Bảng 2. Phân lo ại sinh lý b ệnh và H ội chứng lâm sàng.  
Phân lo ại Type I  Type II  Type III  Type IV  
Cơ ch ế chính 
gây suy hô h ấp Fio2 th ấp, thông khí/tư ới 
máu (V/Q) không phù h ợp 
Shunt - nối tắt 
Giảm kh ả năng khu ếch tán  Giảm thông khí  Shunt - nối tắt 
Giảm thông khí  
V/Q không tương 
hợp Giảm tư ới máu ho ặc 
cung c ấp oxy không 
đầy đủ cho các mô 
ngoại biên (shock 
tuần hoàn)  
Vị trí t ổn 
thương b ệnh 
học Thành ph ần không khí hít 
vào 
Đơn v ị phế nang -mao m ạch 
Khả năng v ận chuy ển oxy 
của máu  Đường th ở 
Hệ thần kinh trung 
ương (CNS)  
Hệ thần kinh cơ  
Thành ng ực Đơn v ị phế nang -
mao m ạch b ị xẹp 
kèm theo tình tr ạng 
giảm thông khí khu 
vực. Hệ tim m ạch 
Tưới máu mô ngo ại 
vi. 
Các h ội chứng 
lâm sàng  Phù ph ổi do tim  
Hội chứng suy gi ảm hô h ấp 
cấp tính - ARDS  
Viêm ph ổi 
Bệnh ph ổi mô k ẽ 
Thuyên t ắc phổi 
Tăng áp đ ộng m ạch ph ổi 
Xẹp phổi 
Xuất huy ết phế nang  
Ngộ độc khí carbon 
monoxide  
Shunt gi ải phẫu Bệnh ph ổi tắc ngh ẽn 
mãn tính  
Hen 
Suy như ợc thần kinh 
trung ương (nhi ễm 
độc) 
Chấn thương ho ặc 
tổn thương th ần kinh 
trung ương  
Rối loạn thần kinh cơ  
Hội chứng béo phì -
giảm thông khí  Phẫu thu ật hoặc chấn 
thương vùng ng ực 
hoặc vùng b ụng trên  
Giảm đau sau ph ẫu 
thuật không đ ầy đủ 
Khối u màng ph ổi 
hoặc viêm  
Khối u dư ới cơ 
hoành ho ặc viêm  
Béo phì  Sốc nhi ễm trùng 
(phân ph ối) 
Sốc giảm thể tích 
Sốc tim  
Quá trình oxy hóa t ế 
bào b ị tổn thương  
Trạng thái tăng 
chuy ển hóa   
2. Loại II là do gi ảm thông khí ph ế nang. Trong lo ại suy hô h ấp này, b ất thường 
sinh lý b ệnh là gi ảm thông khí do m ột quá trình trong h ệ thần kinh trung ương 
(vỏ não, dư ới vỏ não, thân não ho ặc tủy sống), th ần kinh ngo ại biên, cơ, các 
tấm synap th ần kinh cơ ho ặc phế nang (gi ảm thông khí ph ế nang). Nh ững 
bệnh nhân này thư ờng bi ểu hiện suy hô h ấp tăng CO2 có ho ặc không có tình 
trạng thi ếu oxy máu.  
3. Loại III x ảy ra do x ẹp phổi. Vì tình tr ạng này thư ờng xảy ra sau ph ẫu thu ật 
nên còn đư ợc gọi là suy hô h ấp chu ph ẫu. Bệnh nhân có bi ểu hiện suy hô h ấp 
thiếu oxy.  
4. Loại IV x ảy ra do gi ảm tưới máu cơ hô h ấp như trong s ốc tuần hoàn. Ở người 
bình thư ờng <5% cung lư ợng tim đư ợc sử dụng cho công hô h ấp. Ở những 
bệnh nhân b ị sốc, do công th ở tăng lên, có th ể sử dụng tới 40% cung lư ợng 
tim đ ể thở. Những bệnh nhân này bi ểu hiện suy hô h ấp tăng CO2 ch ủ yếu do 
kiệt quệ hô hấp. 
Tiếp cận bệnh nhân Suy hô h ấp cấp giảm oxy máu – AHRF  
Các cơ ch ế sinh lý b ệnh có th ể góp ph ần hoặc dẫn đến thiếu oxy máu là : 
1. Lượng oxy th ở vào th ấp 
2. Thông khí/tư ới máu (V/Q) b ất tương x ứng 
3. Shunt (trong ph ổi hay ngoài ph ổi). 
4. Giảm thông khí.  
5. Bất thường khu ếch tán  
6. Giảm oxy tĩnh m ạch hỗn hợp – hoặc mất cung c ầu oxy.  
Trong b ối cảnh lâm sàng  thực hành t ại cấp cứu, các b ất thường sinh lý b ệnh ph ổ 
biến gây ra tình tr ạng thi ếu oxy máu bao g ồm mất cân b ằng V/Q, shunt và gi ảm 
thông khí . Nhi ều quá trình sinh lý b ệnh có th ể cùng t ồn tại trên cùng m ột bệnh nhân. 
Những bất thường khu ếch tán đơn thu ần là không ph ổ biến. 
Sự giảm rõ r ệt hàm lư ợng oxy trong máu quay tr ở lại phổi (oxy tĩnh m ạch hỗn 
hợp), x ảy ra khi lư ợng oxy cung c ấp giảm ho ặc tăng ti êu th ụ mô, cũng có th ể dẫn 
đến nhu c ầu vận chuy ển nhi ều oxy hơn t ừ khí hít vào vào máu đ ể bình thư ờng hóa 
PaO2. N ếu phổi bình thư ờng thì đi ều này không có tác d ụng đáng k ể. Tuy nhiên, khi có sự bất thường về V/Q ho ặc shunt, ảnh hư ởng này s ẽ tăng lên do máu  bị shunt có 
hàm lư ợng oxy th ấp hơn bình thư ờng. 
Sự chênh l ệch oxy ph ế nang -động m ạch (PAO2− PaO2) và đáp ứng với liệu 
pháp oxy giúp xác đ ịnh nguyên nhân gây suy hô h ấp do thi ếu oxy máu. Đ ộ khác bi ệt 
(chênh l ệch) oxy ph ế nang -động m ạch (A -a) đư ợc tính b ằng công th ức: 
D(A-a) = (FiO2(Patm – PH2O) – PaCO2/0.8) – PaO2.  
Bình thư ờng A -a chênh l ệch là 5 –15 mmHg. Công th ức [Tu ổi (theo năm)/4] + 4 có th ể được sử dụng để 
tính chênh l ệch A -a được điều chỉnh theo tu ổi. 
Sự khác bi ệt A-a tăng lên là k ết quả của sự bất thường trong trao đ ổi khí trong 
phổi (các quá trình trong ph ổi). M ức độ tăng thư ờng rõ r ệt hơn v ới các quá trình  
bệnh lý t ại phổi đơn thu ần so v ới các quá trình h ỗn hợp tại phổi và ngoài ph ổi. 
Khi đánh giá b ệnh nhân AHRF, bư ớc đầu tiên là xác đ ịnh nồng độ CO2. CO2 
cao (>46 mmHg), ngo ại trừ nhiễm kiềm chuy ển hóa là nguyên nhân làm tăng CO2 
bù tr ừ, gợi ý tình tr ạng gi ảm thông khí. S ự khác bi ệt A-a giúp phân bi ệt tình tr ạng 
giảm thông khí đơn thu ần với quá trình h ỗn hợp. Trong trư ờng hợp không có tăng 
CO2, s ự gia tăng chênh l ệch A -a cho th ấy sự gia tăng chênh l ệch A -a gợi ý ho ặc là 
shunt, V/Q không kh ớp hoặc bất thư ờng khu ếch tán. H ạ oxy máu do n ồng độ oxy 
thở vào th ấp không làm tăng chênh l ệch A -a và đáp ứng với liệu pháp oxy b ổ sung. 
Trong b ệnh cảnh có gradie nt A-a cao, vi ệc cải thiện quá trình oxy hóa b ằng oxy li ệu 
pháp s ẽ gợi ý sự không phù h ợp V/Q, không c ải thiện sẽ gợi ý m ột shunt.  
Nguyên nhân – bệnh sinh  
Nguyên nhân c ủa suy hô h ấp cấp giảm oxy máu có th ể được phân lo ại rộng rãi là:  
a) Bệnh lý nhu mô  
1. Tăng áp l ực mao m ạch: phù ph ổi do tim và quá t ải dịch 
2. Tăng tính th ấm mao m ạch: h ội chứng suy hô h ấp cấp tính (ARDS) do 
nguyên nhân t ại phổi và ngoài ph ổi 
3. Viêm: nhi ễm trùng (viêm ph ổi thùy và ph ế quản, viêm ph ổi kẽ), viêm ph ế 
nang (viêm ph ổi kẽ cấp tính, vi êm m ạch cấp tính) và xu ất huy ết (phế nang)  
4. Xẹp phổi 
b) Màng ph ổi: tràn khí màng ph ổi và tràn d ịch màng ph ổi 
c) Liên quan đ ến đường th ở: hen n ặng cấp tính  
d) Mạch máu: t ắc mạch ph ổi và s ốc tuần hoàn . Bất tương x ứng V/Q:  
Sự không phù h ợp V/Q là nguyên nhân ph ổ biến nhất gây ra tình tr ạng thi ếu 
oxy máu ở những bệnh nhân nguy k ịch và đó là s ự thay đ ổi tỷ lệ thông khí và tư ới 
máu đi ển hình trong ph ổi. Tình tr ạng thi ếu oxy máu do m ất cân b ằng V/Q có th ể 
được điều trị với oxy li ệu pháp.  
Shunt - nối tắt:  
Ví dụ điển hình n hất về tỷ lệ V/Q gi ảm là shunt gi ải phẫu, xảy ra khi thông 
khí suy gi ảm hoàn toàn m ặc dù lưu lư ợng máu đ ầy đủ. Bởi vì máu mao m ạch không 
được tiếp xúc v ới các đơn v ị phổi được thông khí, tình tr ạng thi ếu oxy máu do shunt 
không đáp ứng oxy li ệu pháp. Khi t ỷ lệ shunt tăng lên, thi ếu oxy ti ến triển sẽ kém 
đáp ứng với oxy. Khi shunt tăng lên trên 50%, PaO2 v ề cơ bản không ph ụ thuộc vào 
tỷ lệ oxy hít vào (FiO2). Khi đó, li ệu pháp oxy b ổ sung thư ờng không hi ệu quả. 
Hạn chế khuếch tán : 
Nó xảy ra khi oxy không th ể di chuy ển qua ph ế nang vào máu mao m ạch m ặc 
dù tỷ lệ V/Q không thay đ ổi. Các tình tr ạng làm dày màng (ví d ụ, bệnh ph ổi kẽ hoặc 
tăng áp ph ổi) ho ặc tốc độ lưu lư ợng máu mao m ạch (ví d ụ, tăng cung lư ợng tim có 
thể xảy ra khi g ắng sức) có th ể làm x ấu đi s ự khuếch tán và d ẫn đến thiếu oxy máu. 
Oxy b ổ sung có th ể điều chỉnh tình tr ạng thi ếu oxy máu do h ạn chế khuếch tán.  
Giảm thông khí : 
Oxy li ệu pháp c ải thiện thi ếu oxy máu do gi ảm thông khí nhưng không c ải 
thiện tăng CO2 máu.  
Phân su ất oxi hít vào th ấp:  
Với việc giảm PiO2 ở độ cao (k ể cả trên máy bay), tình tr ạng thi ếu oxy trong 
máu là do PAO2 th ấp và đư ợc cải thiện khi b ổ sung oxy.  
Sự không tương x ứng gi ữa cung c ấp và tiêu th ụ oxy:  
Khi nhu c ầu oxy c ủa các mô ngo ại biên b ị vượt quá do ngu ồn cung c ấp—như 
trong tình tr ạng tăng chuy ển hóa, cung lư ợng tim th ấp, kh ả năng v ận chuy ển oxy 
thấp—có th ể dẫn đến tình tr ạng thi ếu oxy máu. Trong nh ững trư ờng hợp này, vi ệc 
cung c ấp oxy b ổ sung và đi ều trị nhằm mục đích đi ều chỉnh sự mất cân bằng cung 
cầu cơ b ản sẽ cải thiện tình tr ạng thi ếu oxy.Bảng 3. Cơ ch ế sinh lý b ệnh của Suy hô h ấp thiếu oxy c ấp tính – AHRF  
Cơ ch ế của giảm oxy máu  Các đ ặc trưng lâm sàng  Ví dụ 
Bất tương x ứng V/Q (thông 
khí và tư ới máu)  Độ chênh A -a rộng 
Cải thiện với O2 li ệu pháp  
Tác đ ộng hạn chế lên PaCO2 tr ừ khi > 
30% kho ảng ch ết "Ngập lụt" ph ế nang (viêm ph ổi, phù ph ổi, xuất 
huyết phổi và b ệnh ác tính)  
Xẹp phổi 
Shunt – nối tắt Độ chênh A -a rộng 
Không c ải thiện đáng k ể với O2 li ệu 
pháp  
Khi t ỷ lệ shunt >50%, PaO2 không 
phụ thuộc vào FiO2  Shunt trong tim (ASD, PFO)  
Shunt trong ph ổi (AVM ph ổi, hội chứng gan ph ổi) 
PE lớn 
Xẹp phổi, viêm ph ổi, phù ph ổi, ARDS  
Tắc ngh ẽn đường hô h ấp trung tâm  
Bệnh đư ờng hô h ấp nhỏ nặng/cơn hen n ặng. 
Hạn chế khuếch tán  Độ chênh A -a rộng 
Cải thiện với O2 li ệu pháp  Bệnh ph ổi mô k ẽ 
Khí ph ổi thủng 
Bệnh m ạch máu ph ổi 
Hạn chế thông khí  Độ chênh A -a bình thư ờng 
Cải thiện với O2 li ệu pháp  Bệnh th ần kinh cơ  
Các b ệnh lý thành ng ực 
Rối loạn thần kinh trung ương  
Thuốc an th ần 
Bệnh ph ổi tắc ngh ẽn 
Giảm phân su ất FiO2  Độ chênh A -a bình thư ờng 
Cải thiện với O2 li ệu pháp  Độ cao 
Thông khí trên máy bay  
Bất cân b ằng cung c ầu oxy  
(Hạn chế phân ph ối) Độ chênh A -a rộng Thiếu máu  – bệnh lý hemoglobin – độc chất 
Các b ệnh lý tăng chuy ển hoá  
Cung lư ợng tim gi ảm – shock.  Chiến lược tiếp cận về bản chất sinh lý b ệnh của suy hô h ấp cấp giảm oxi máu  
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 SUY HÔ H ẤP CẤP CÓ TĂNG CO2 MÁU KHÔNG?  
Độ chênh A -a O2 có r ộng không?  CÓ GI ẢM THÔNG KHÍ  
Đến lưu đ ồ TĂNG CO2 
MÁU  
PaO2 đư ợc điều ch ỉnh v ới O2  Giảm FiO2 hít vào  
Do đ ộ cao; gi ảm 
FiO2; trong bu ồng 
máy bay  
SHUNT – NỐI TẮT BẤT XỨNG V/Q  
HẠN CH Ế KHU ẾCH TÁN  
HẠN CH Ế PHÂN PH ỐI  
PvO2 bình thư ờng PvO2 không bình thư ờng 
BẤT XỨNG V/Q  
HẠN CH Ế KHU ẾCH TÁN  HẠN CH Ế PHÂN PH ỐI – 
mất cung c ầu Shunt trong tim  
Shunt trong ph ổi 
ARDS n ặng 
Viêm ph ổi 
Xẹp ph ổi 
Đông đ ặc ph ổi 
Phù ph ổi cấp… 
Shock tu ần hoàn  
Tăng chi ết xuất O2  
Thiếu máu  
Ngộ độc: khí CO…  
Tăng chuy ển hoá  Lâm sàng và C ận lâm 
sàng giúp phân bi ệt 
Bệnh lý mô k ẽ - xơ hoá ph ổi… 
Thuyên t ắc ph ổi 
Khí ph ế thủng 
"Ngập lụt" ph ế nang (viêm ph ổi, 
phù ph ổi, xu ất huy ết phổi và b ệnh 
ác tính)  
Xẹp ph ổi 
 KHÔNG  CÓ 
CÓ KHÔNG  
KHÔNG  CÓ Các nguyên t ắc điều trị - can thi ệp suy hô h ấp cấp giảm oxi máu – AHRF.  
Bên c ạnh nguyên t ắc quản lý đi ều trị AHRF là t ập trung ch ủ yếu vào đi ều trị 
rối loạn bệnh lý g ốc, tất cả các b ệnh nhân thi ếu oxy nên đư ợc cung c ấp liệu pháp 
oxy b ổ sung đ ể duy trì vi ệc cung c ấp đủ oxy đ ến các m ô. M ục tiêu oxy t ối ưu v ẫn 
đang đư ợc nghiên c ứu và tranh lu ận - chiến lược tiếp cận oxy th ận trọng vẫn ưu tiên 
khuy ến cáo, v ới mục tiêu PaO2 trong kho ảng từ 55 đến 80 mmHg.  
Mặc dù giá tr ị khí máu đ ộng m ạch vẫn là tiêu chu ẩn vàng đ ể đánh giá nguyên 
nhân và công c ụ theo dõi đi ều trị suy hô h ấp cấp, khí máu tĩnh m ạch ngo ại biên có 
thể sử dụng vì d ễ dàng th ực hiện nhưng không nên s ử dụng duy nh ất máu tĩnh m ạch 
thay cho máu đ ộng m ạch trong ch ẩn đoán suy hô h ấp cấp tính, đ ặc biệt đối với 
AHRF.  
Còn trên theo dõi t ại giường, SpO2 trong ph ạm vi 90% đ ến 98% là an toàn và 
cân nh ắc sử dụng chi ến lược tự do hơn (ví d ụ: 92% –98%) ở những bệnh nhân có làn 
da sẫm màu hơn.  
Điều trị suy hô h ấp do thi ếu oxy có th ể đạt được thông qua nhi ều phương th ức 
khác nhau. Thi ết bị dễ có nhất là li ệu pháp oxy thông thư ờng - COT, qua ống thông 
mũi ho ặc mặt nạ tiêu chu ẩn với tốc độ dòng ch ảy lên t ới 6 L oxy m ỗi phút.  
Tuy nhiên, c ần lưu ý là nh ững bệnh nhân b ệnh nặng đôi khi tăng thông khí 
phút cao hơn t ốc độ cung c ấp oxy đ ạt được (> 6 lít m ỗi phút), d ẫn đến sự pha loãng 
với khí phòng ngu ồn cung c ấp oxy. Đ ể khắc phục vấn đề này, canula mũi lưu lư ợng 
cao (HFNC) v ới tốc độ dòng oxy b ổ sung lên t ới 60 L m ỗi phút hay m ặt nạ không 
thở lại có túi oxy cũng có th ể giúp t ập trung FiO2 t ối đa đ ể ngăn ng ừa sự pha loãng.  
Theo đó, s ử dụng li ệu pháp oxy thông thư ờng cho b ệnh nhân b ị thiếu oxy 
nhưng công th ở bình thư ờng. Ở những bệnh nhân c ần cung c ấp oxy b ổ sung l ớn hơn 
6 l/p (ho ặc kho ảng 40% FiO2)  hoặc tăng công th ở, sử dụng HFNC.  
NIV nên là  phương pháp đi ều trị đầu tiên cho tình tr ạng thi ếu oxy máu ở bệnh 
nhân phù ph ổi cấp do tim ho ặc đợt cấp của COPD.    
Ở những bệnh nhân có đáp ứng không đ ầy đủ với các li ệu pháp trên ho ặc có 
dấu hiệu huy ết động không ổn định, c ần phải đặt nội khí qu ản và th ở máy.  
Không nên trì hoãn đ ặt NKQ ở bệnh nhân đáp ứng kém ho ặc có các ch ỉ số 
tiên lư ợng th ất bại cao đ ối với HFNC (ROX) hay CPAP/BiPAP (HACOR).  
Suy hô h ấp tăng CO2 máu.  Suy hô h ấp tăng CO2 x ảy ra khi ph ổi không th ể loại bỏ carbon dioxide (CO2) 
để giữ mức ở mức bằng ho ặc dưới 45 mm Hg. Nguyên t ắc quan tr ọng là ph ải hiểu 
nguyên nhân là do r ối loạn chức năng hô h ấp hoặc thần kinh nguyên phát và r ằng 
liệu PaCO2 tăng cao này là do bù tr ừ kiềm chuy ển hóa nguyên phát.  
Suy hô h ấp tăng CO2 c ấp tính đư ợc chẩn đoán kh i PaCO2 là 45 mm Hg và 
pH máu nhi ễm toan - pH dư ới 7,35. Suy hô h ấp tăng CO2 m ạn tính đư ợc chẩn đoán 
khi PaCO2 là 45 mmHg, m ức tăng PaCO2 không ph ải do bù tr ừ kiềm chuy ển hóa 
nguyên phát và pH máu bình thư ờng ho ặc gần bình thư ờng. 
Nguyên t ắc đáp ứng bù tr ừ ở Suy hô h ấp tăng CO2 máu:  
Type suy hô h ấp Tăng PaCO2  Tăng HCO3  Mức giảm pH  
Tăng CO2 c ấp 10 mmHg  1 mEq/l  0.08 
Tăng CO2 m ạn 10 mmHg  3.5 mEq/l  0.03 
 
Nguyên nhân thư ờng gặp của suy hô h ấp cấp tăng CO2 máu  
Nguyên nhân c ủa suy hô h ấp tăng CO2 máu có th ể được phân lo ại rộng rãi là:  
a) Bệnh lý h ệ thần kinh trung ương:  
1. Vỏ não: các d ạng đột quỵ, nhiễm trùng, ch ấn thương, đ ộc chất và viêm 
não t ủy lan t ỏa cấp tính  
2. Suy y ếu hệ thống lư ới thân não: các d ạng đột quỵ, viêm màng não n ền, 
chấn thương và h ội chứng giảm thông khí do béo phì  
3. Tủy sống: ch ấn thương, viêm t ủy do nhi ễm trùng và sau tiêm ch ủng và 
viêm t ủy bại liệt 
b) Bệnh lý h ệ thần kinh ngo ại biên: H ội chứng Guillain -Barre, t ổn thương dây 
thần kinh hoành, xơ c ứng teo cơ m ột bên và b ệnh đa dây th ần kinh ở bệnh 
nhân b ệnh nặng nguy k ịch 
c) Thần kinh cơ: b ệnh như ợc cơ 
d) Cơ: b ệnh cơ n ặng, b ệnh chuy ển hóa (h ạ kali máu, gi ảm phosphat máu, gi ảm 
magie) và viêm đa cơ  
e) Thành ng ực: ch ấn thương ng ực nặng, gù v ẹo cột sống và viêm c ột sống dính 
khớp 
f) Giảm thông khí ph ế nang do ngu yên nhân ph ổi: COPD, xơ nang n ặng, xơ ph ổi 
giai đo ạn cuối và t ắc ngh ẽn đường th ở. 
Cơ ch ế của tăng CO2 máu có th ể nhớ nhanh:  “không th ở - won’t breathe , không 
thể thở được – can’t breathe , không th ở đủ - can’t breathe enough ”.Bảng 4. Cơ ch ế tăng CO2 máu t ại cấp cứu 
Phân lo ại Bản chất Sinh lý b ệnh Lâm sàng  
Won’t breathe  Giảm thông khí  Giảm hệ thống “drive” 
hô hấp ở TKTW  • Thuốc an th ần (rư ợu, benzodiazepin, thu ốc 
opiate)  
• Rối loạn trung ương (viêm não, đ ột quỵ, u 
tủy, giảm thông khí do béo phì)  
Can’t breathe  Giảm thông khí  Chức năng cơ hô h ấp 
bị suy gi ảm do ch ức 
năng th ần kinh cơ b ị 
thay đ ổi • Bệnh như ợc cơ, ALS, GBS, ch ấn thương t ủy 
sống 
• Chất độc: botulism, ng ộ độc phốt pho h ữu 
cơ 
• Rối loạn tuy ến giáp  
Can’t breathe  Giảm thông khí  Các b ệnh lý r ối loạn 
thành ng ực và màng 
phổi. • Gù v ẹo cột sống, tràn d ịch màng ph ổi lượng 
lớn, liệt cơ hoành, ph ẫu thu ật cắt bỏ xương 
ức/thành ng ực trước đó, béo phì . 
Can’t breathe  Tăng phân su ất 
khoảng ch ết Tắc ngh ẽn đư ờng th ở 
dẫn đến tỷ lệ V/Q tăng 
cao. • Khí ph ế thũng, tăng bơm khí vào ph ổi, hen 
nặng, tắc ngh ẽn đường hô h ấp trung tâm.  
Can’t breathe  Tăng phân su ất 
khoảng ch ết Bệnh m ạch máu ph ổi 
dẫn đến tỷ lệ V/Q tăng 
cao • Thuyên t ắc phổi nặng, b ệnh m ạch máu ph ổi, 
bệnh ph ổi kẽ, ARDS  
Can’t breathe 
enough  Gia tăng s ản xuất 
CO2  Sản xu ất CO2 l ấn át 
quá trình đào th ải CO2 
của phổi • Sốt, gắng sức quá m ức, nhi ễm trùng huy ết, 
tăng dinh dư ỡng, nhi ễm độc giáp  
 
 Chiến lược tiếp cận suy hô h ấp tăng CO2 theo sinh lý và sinh lý b ệnh: 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
Các nguyên t ắc quản lý đi ều trị Suy hô h ấp tăng CO2 ở cấp cứu. 
Mục tiêu chính c ủa việc quản lý b ệnh nhân suy hô h ấp cấp tăng CO2 là h ỗ trợ 
hô hấp để tăng công thở - cải thiện thông khí. Đ ối với những bệnh nhân thích h ợp, 
NIV thư ờng là li ệu pháp đ ầu tiên; tuy nhiên c ần lưu ý:  
1. Đầu tiên, b ệnh nhân đư ợc điều trị NIV ph ải còn nh ịp thở tự nhiên  PaCO2 MÁU TĂNG  Giảm th ải CO2  Tăng S ẢN XU ẤT CO2  
Tăng ho ạt động 
cơ hô h ấp 
Tăng chuy ển hoá  
Tăng lư ợng ăn CH  Độ chênh A -a O2 r ộng? 
Giảm thông khí ph ế nang  Giảm thông khí phối hợp thêm  
Xem s ức cơ – PI max  PaO2 có th ể điều ch ỉnh v ới O2?  
Vấn đề Thần kinh 
– cơ xương  Vấn đề Thần Kinh 
Trung Uơng  Bất xứng V/Q  SHUNT – NỐI TẮT 
Như ợc cơ 
Guillane Barre  
Bệnh cơ chuy ển 
hoá (K, P…)  
Viêm đa cơ  
Bệnh lý th ần kinh 
ngoại biên b ệnh 
nặng 
Bệnh lý thành 
ngực Các th ể đột quỵ 
Nhiễm độc 
CTSN  
Bệnh não 
chuy ển hoá….  
Viêm nhi ễm 
TKTƯ  
Hội chứng gi ảm 
thông khí béo 
phì Bệnh ph ổi mô k ẽ 
ARDS  
Khí ph ế thủng 
Xơ ph ổi tiến 
triển 
Thuyên t ắc ph ổi 
Thuy ển tắc khí  
Xẹp ph ổi Shunt trong ph ổi 
Shunt trong tim  
Viêm ph ổi nặng 
Xẹp ph ổi lớn 
Phù ph ổi cấp 
Đông đ ặc ph ổi 
Tắc đàm, máu…  
 CÓ KHÔNG  
GIẢM BÌNH THƯ ỜNG CÓ KHÔNG  2. Thứ hai, b ệnh nhân ph ải được chứng minh kh ả năng b ảo vệ đường th ở và tháo 
mặt nạ NIV trong trư ờng hợp nôn vì hít d ịch dạ dày gây nguy cơ l ớn cho 
những ngư ời nhận NIV.  
3. Có nh ững tình hu ống bệnh nhân có v ẻ không thích h ợp (hôn mê do tăng CO2 
quá cao) có th ể được thử dùng NIV, nhưng nh ững bệnh nhân này c ần được 
theo dõi ch ặt chẽ, lý tưởng nh ất là trong môi trư ờng chăm sóc tích c ực. 
Bằng ch ứng gần đây, HFNC có th ể được sử dụng an toàn ở những bệnh nhân 
suy hô h ấp tăng CO2 không dung n ạp được hoặc không ph ải là ứng cử viên cho NIV.  
Mục tiêu ph ạm vi bão hòa oxy bình thư ờng ho ặc cao hơn có kh ả năng d ẫn đến 
thay đ ổi tình tr ạng co m ạch do thi ếu oxy sinh lý ở bệnh nhân COPD, đi ều này có th ể 
làm x ấu đi tình tr ạng thông khí kho ảng ch ết và tăng CO2 máu. M ục tiêu ph ạm vi 
SpO2 t ừ 88% đ ến 92% trong nhóm b ệnh nhân này và theo dõi c ẩn thận HFNC ho ặc 
NIV.  
SpO2, SaO2, PaCO2 và tình tr ạng lâm sàng nên đư ợc theo dõi ch ặt chẽ khi 
dùng NIV ho ặc HFNC. C ần phải lấy khí máu hàng lo ạt để đánh giá pH và PaCO2.  
Nếu trong quá trình th ử điều trị với NIV ho ặc HFNC, đ ộ pH không tr ở về bình 
thường, PaCO2 không c ải thiện hoặc tình tr ạng lâm sàng c ủa bệnh nhân x ấu đi m ặc 
dù đư ợc hỗ trợ thông khí đ ầy đủ (bao g ồm đảm bảo mặt nạ vừa khít, thông khí phút 
và đi ều chỉnh cài đ ặt NIV), thì đ ặt nội khí qu ản và thông khí cơ h ọc xâm l ấn nên 
được chỉ định và không nên trì hoãn.  
NIV thường hi ệu quả với đợt cấp COPD trong vòng 1 đ ến 4 gi ờ và nên h ạn 
chế hỗ trợ NIV đ ối với suy hô h ấp tăng CO2 trong hơn 4 gi ờ và tiến hành đ ặt nội khí 
quản và th ở máy n ếu không th ấy lợi ích gì trong khung th ời gian này. Có th ể sử dụng 
các đi ểm HACOR đ ể tiên lư ợng nguy cơ th ất bại NIV.  
Tóm l ại 
Suy hô h ấp cấp là h ội chứng lâm sàng ph ổ biến nhất và ph ức tạp tại cấp cứu. 
Bác sĩ c ấp cứu nên n ắm và th ực hiện song hành các nguyên lý ti ếp cận chẩn đoán và 
quản lý đi ều trị. 
Suy hô h ấp cấp giảm oxi máu đư ợc xác định khi PaO2 dư ới 60 mm Hg ho ặc 
SaO2 dư ới 88% và có th ể do bất xứng V/Q, shunt, gi ảm thông khí, h ạn chế khuếch 
tán ho ặc áp l ực oxy th ở vào th ấp. Suy hô h ấp tăng CO2 c ấp được xác đ ịnh khi PaCO2 45 mm Hg và pH dư ới 
7,35 và có th ể do gi ảm thông khí ph ế nang,  tăng t ỷ lệ khoảng ch ết hoặc tăng s ản xuất 
carbon dioxide.  
Các thao tác ch ẩn đoán s ớm, ch ẳng hạn như đo SpO2 và khí máu đ ộng m ạch, 
có th ể phân bi ệt loại suy hô h ấp và hư ớng dẫn các bư ớc tiếp theo trong đánh giá và 
quản lý. 
Việc điều trị nên hư ớng vào tình trạng rối loạn chính và nh ằm mục đích duy 
trì đủ oxy cho mô và đ ộ pH bình thư ờng bằng các phương th ức hỗ trợ như HFNC, 
thông khí không xâm l ấn hoặc thông khí cơ h ọc xâm l ấn. 
Tài li ệu tham kh ảo 
1. Madeline Lagina, MD, MPHa, Thomas S. Valley, MD, MSc. Diagnosis  and Management of Acute 
Respiratory Failure. Crit Care Clin – 2024. https://doi.org/10.1016/j.ccc.2024.01.002/  
2. Pierachille Santus, Dejan Radovanovic, Marina Saad, Camilla Zilianti, Silvia Coppola, Davide 
Alberto Chiumello, Matteo Pecchiari. Acute dyspnea in the emergency department: a clinical 
review. Internal and Emergency Medicine (2023) 18:1491 –1507. https://doi.org/10.1007/s1173 9-
023-03322 -8. 
3. Elizabeth DeVos, MD, MPH, Lisa Jacobson, MD. Approach to Adult Patients with Acute Dyspnea. 
Emerg Med Clin N Am 34 (2016) 129 –149. http://dx.doi.org/10.1016/j.emc.2015.08.008 .  
4. John  Victor Peter. Acute Respiratory Failure. Clinical Pathways in Emergency Medicine: Volume 
I. Springer India 2016.  
5. Sabina A. Braithwaite and Amanda L. Wessel. Dyspnea. Rosen's Emergency Medicine: Concepts 
and Clinical Practice, Tenth Edition.  
6. V. Courtney B roaddus MD and Antonio Gomez MD . Chapter 44, Hypoxemia . Murray & Nadel's 
Textbook of Respiratory Medicine, 44, 578 -589. 
7. Richard M. Schwartzstein MD and Lewis Adams PHD . Dyspnea. Murray & Nadel's Textbook of 
Respiratory Medicine, 36, 497 -507. 
8. Bernie Y. Sunw oo MBBS and Babak Mokhlesi MD, MSC . Hypercapnia. Murray & Nadel's 
Textbook of Respiratory Medicine, 45, 590 -599

## Tài liệu đào tạo cấp cứu cơ bản

**[Tài liệu đào tạo cấp cứu cơ bản](https://bvnguyentriphuong.com.vn/uploads/072022/files/c2_-TAI-LIEU-CAP-CUU.pdf)
#### Nội dung trong file:

BỘ Y TẾ  
CỤC QUẢN LÝ KHÁM CHỮA BỆNH  
DỰ ÁN TĂNG CƯ ỜNG CH ẤT LƯ ỢNG NGU ỒN 
NHÂN L ỰC TRONG KHÁM CH ỮA BỆNH 
 
 
 
 
 
 
 
 
 
 
TÀI LI ỆU ĐÀO T ẠO CẤP CỨU CƠ B ẢN 
 
 
 
 
 
 
 
 
 
 
 
 
NHÀ XU ẤT BẢN Y H ỌC 
 
 BỘ Y TẾ 
CỤC QU ẢN LÝ KHÁM, CH ỮA BỆNH 
 
 
 
 
 
 
 
 
 
 
TÀI LI ỆU ĐÀO T ẠO CẤP CỨU CƠ B ẢN 
 
 
 
 
 
 
 
 
 
 
 
 
NHÀ XU ẤT BẢN Y H ỌC 
HÀ N ỘI - 2014  
 
 
 
 CHỦ BIÊN 
PGS.TS. Lương Ngọc Khuê 
PGS.TS. Đặng Quốc Tuấn       
THAM GIA BIÊN SOẠN 
TS. Đỗ Ngọc Sơn 
TS. Đào Xuân Cơ 
ThS. Nguyễn Trung Nguyên 
ThS. Nguyễn Thành                                        
THƯ  KÝ 
ThS. Nguyễn Thị Thanh Ngọc 
ThS. Nguyễn Phương Mai
 
 
 
 
 
  
LỜI NÓI Đ ẦU 
Theo quy ch ế cấp cứu, Hồi sức  và ch ống độc do B ộ Y tế ban hành kèm theo 
quyết định 1/2008/QĐ -BYT ngày 21 tháng 1 năm 2008, các b ệnh vi ện tuy ến tỉnh tr ở 
lên sẽ thành l ập khoa C ấp cứu, các b ệnh viện sẽ có khoa c ấp cứu. Do đó nhu c ầu về đào 
tạo các bác sĩ có ki ến thức về cấp cứu là r ất lớn và c ấp bách,  nhất là hi ện nay ph ần lớn 
các bác sĩ đư ợc tuy ển vào các b ệnh vi ện phần lớn là bác sĩ đa khoa, chưa đư ợc đào t ạo 
về chuyên khoa nhưng đã ph ải làm n gay các công vi ệc về chuyên khoa.  
Tài li ệu này đư ợc biên so ạn với mục đích cung c ấp cho h ọc viên các hi ểu biết, kỹ 
năng cơ b ản, cần thiết nhất về chẩn đoán, x ử trí cấp cứu các tình hu ống bệnh lý thư ờng 
gặp tại khoa c ấp cứu. 
Tóm lư ợc nội dung  
Tài li ệu này c ung c ấp cho h ọc viên  các hi ểu biết, kỹ năng ở trình đ ộ chuyên khoa 
định hư ớng và ch ẩn đoán, x ử trí cấp cứu các tình hu ống bệnh thư ờng gặp trong c ấp cứu 
và m ột số thủ thuật cơ b ản trong c ấp cứu nội khoa và ch ấn thương.  
Phạm vi áp d ụng tài li ệu 
Tài li ệu này được sử dụng tại các b ệnh vi ện đa khoa t ỉnh, thành trên c ả nước. Cục 
QLKCB đư ợc sự hỗ trợ của tổ chức JICA đã thành l ập nhóm chuyên gia so ạn thảo 
chương trình và tài li ệu đào t ạo liên t ục về Cấp cứu bao g ồm các chuyên gia v ề Cấp cứu, 
sự hỗ trợ kỹ thuật của chuyên gia Nh ật bản từ tổ chức JICA.  
     Đây là tài li ệu biên so ạn lần đầu nên không tránh đư ợc thiếu sót. B ộ Y tế mong 
nhận được nhi ều ý ki ến đóng góp c ủa các đ ồng nghi ệp, các thày cô giáo và h ọc viên đ ể 
tài liệu học tập này đư ợc hoàn ch ỉnh hơn cho l ần xuất bản sau.  
                                                                  TM. BAN BIÊN T ẬP 
                                                                         Trưởng ban  
                                                        PGS.TS. LƯƠNG NG ỌC KHUÊ  
                Cục trư ởng C ục Qu ản lý Khám, ch ữa bệnh 
  
  
 
  
MỤC LỤC 
 
Nội dung  Trang  
A. LÝ THUY ẾT  
I. Cấp cứu nội khoa   
1. Nh ận định và ki ểm soát ban đ ầu bệnh nhân c ấp cứu 4 
2. Các k ỹ thuật kiểm soát đư ờng th ở 14 
3. Ch ẩn đoán và x ử trí cấp cứu ban đ ầu suy hô h ấp cấp 26 
4. Xử trí cấp cứu sốc 34 
5. Cấp cứu ngừng tu ần hoàn cơ b ản 39 
6. Cấp cứu ngừng tu ần hoàn nâng cao  46 
7. Chẩn đoán và xử trí cấp cứu nhồi máu cơ tim cấp có ST  chênh lên     55                  
 
II. C ấp cứu chấn thương    
8. Cấp cứu chấn thương s ọ não 53 
9. Cấp cứu chấn thương c ột sống 64 
10. Cấp cứu chấn thương ng ực 74 
11. Cấp cứu chấn thương b ụng 87 
12. Chẩn đoán và x ử trí cấp cứu ban đ ầu sốc chấn thương ở người lớn 
13. Xử trí cấp cứu chấn thương xương, ph ần mềm và chi th ể đứt rời 93 
III. C ấp cứu khác   
14. Xử trí cấp cứu bệnh nhân b ỏng 106 
15. Nguyên t ắc chẩn đoán, x ử trí ng ộ độc cấp 111 
16. Vận chuy ển bệnh nhân c ấp cứu 122 
B. TH ỰC HÀNH   
1. Kỹ thuật kiểm soát đư ờng th ở 136 
2. Kỹ thuật cấp cứu ngừng tu ần hoàn  137 
3. Kỹ thuật vận chuy ển bệnh nhân  138 
4. Kỹ thuật xử trí vết thương xuyên th ấu 139 
5. Kỹ thuật bất động xương gãy và c ột sống 140 
 
   
 
 
 
 
 
PHẦN I 
BÀI GI ẢNG LÝ THUY ẾT Bài 1  
NHẬN ĐỊNH VÀ  KIỂM SOÁT BAN Đ ẦU 
BỆNH NHÂN C ẤP CỨU 
 
 
MỤC TIÊU  
 Sau khi h ọc xong h ọc viên có kh ả năng:  
       1. Trình bày được các nguyên tắc chính khi tiếp cận và xử trí bệnh 
nhân cấp cứu.  
       2. Trình bày được các nguyên tắc cần tuân thủ để tránh các sai lầm.  
       3. Rèn luyện kỹ năng thăm khám và cấp cứu bệnh nhân theo 2 bước 
(primary và secondary).  
       4. Rèn luyện tác phong khẩn trương và phản ứng theo trình tự.  
 
NỘI DUNG  
    
      1. Khái niệm về cấp cứu  
   - Cấp cứu thường được dùng để chỉ các tình trạng bệnh nội/  ngoại cần 
được đánh giá và điều trị ngay. Các tình trạng cấp cứu có thể là:  
          + Nguy kịch  (khẩn cấp) (critical): bệnh nhân có bệnh lý, tổn thương, rối 
loạn đe dọa tính mạng, nguy cơ tử vong nhanh chóng nếu không được can thiệp 
cấp cứu ngay.  
   + Cấp cứu  (emergency): bệnh nhân có bệnh lý, tổn thương, rối loạn  có 
thể tiến triển nặng lên nếu không được can thiệp điều trị nhanh chóng  
          - Công tác thực hành cấp cứu có nhiệm vụ đánh giá, xử trí và điều trị cho 
các bệnh nhân có bệnh lý/tổn thương/rối loạn cấp cứu.  
2. Các đặc thù của cấp cứu  
2.1. Rất nhiều kh ó khăn, thách thức:  
          - Hạn chế về thời gian: tính chất bệnh lý cấp cứu diễn biến cấp tính và có 
thể nặng lên nhanh chóng, do vậy đòi hỏi công tác cấp cứu phải rất khẩn trương 
trong thu thập thông tin, đánh giá và đưa ra chẩn đoán, xử trí và can th iệp cấp 
cứu; Bản thân bệnh nhân và gia đình cũng lo lắng và có xu hướng đòi hỏi thực 
hiện đón tiếp và cấp cứu thật nhanh.  
          - Cần đánh giá nhanh và ra quyết định với lượng thông tin hạn chế, chưa 
đầy đủ: do đòi hỏi phải có quyết định chẩn đoán và x ử trí nhanh chóng ngay sau 
khi tiếp cận bệnh nhân (ngoài bệnh viện hoặc trong bệnh viện tại khoa cấp cứu) 
cho nên người bác sỹ và y tá cấp cứu thường phải đưa ra chẩn đoán và quyết định 
xử trí, chăm sóc dựa vào các thông tin ban đầu sơ bộ, chưa đầy đủ.  Đây là một 
thách thức thực sự khi phải đưa ra các quyết định nhiều khi mang tính chất sống 
còn cho tính mạng hoặc một phần cơ thể của bệnh nhân trong khoảng thời gian 
ngắn và chưa có thông tin đầy đủ.  
          - Không gian và môi trường làm việc: Môi trường  làm việc tại khoa cấp 
cứu luôn có nhiều áp lực không kể áp lực về thời gian: không gian làm việc 
thường nằm ngay gần cổng bệnh viện, không gian mở thường thông thương với 
bên ngoài, đông bệnh nhân, đông người thân của bệnh nhân và có thể còn nhiều 
đối tượ ng khác, dòng người di chuyển vừa đông vừa nhanh (bệnh nhân, người than của bệnh nhân, nhân viên…) nên dễ có lộn xộn, nhiều tiếng ồn và khó 
kiểm soát trật tự, vệ sinh và an ninh.  
          - Trong cấp cứu trước khi đến viện, nhân viên y tế có thể phải làm  việc ngoài 
trời, trong môi trường sinh hoạt không có hỗ trợ về y tế, thời tiết có thể không thuận 
lợi, đôi khi có thể nguy hiểm ngay cả cho nhân viên y tế (cháy nổ, hiện trường tai 
nạn giao thông…)  
          - Nhiều lo lắng và dễ bị phân tâm: Người nhân v iên y tế có thể phải quan 
tâm giải quyết nhiều việc khác nhau: tiếp nhận giấy tờ, thủ tục hành chính, trật 
tự, phân luồng bệnh nhân…Nhiều khi các mối bận tâm này làm người nhân viên 
y tế khó tập trung vào công tác chuyên môn cứu chữa người bệnh. Các áp lực  
công việc cũng như các áp lực từ phía bệnh nhân và người thân của bệnh nhân 
cũng có thể làm các nhân viên y tế gặp khó khăn để đảm bảo tuân thủ các quy 
trình và tiêu chí cấp cứu.  
          - Nhân viên y tế có nguy cơ bị đe dọa về tinh thần và bạo lực đến từ các bệnh 
nhân kích động, hung hãn, từ gia đình và người thân đang bị mất bình tĩnh…  
          2.2. Không nhất thiết chỉ quan tâm tìm chẩn đoán  để có điều trị mà đa 
phần trường hợp yêu cầu cấp thiết lại là suy nghĩ để xác nhận hoặc loại trừ các 
bệnh lý/r ối loạn nặng đe dọa tính mạng hoặc đe dọa bộ phận/chi của bệnh nhân.  
          2.3. Nhận định và phản ứng  có thể phải tiến hành song song nhiều quy 
trình (ví dụ vừa cấp cứu vừa hỏi, vừa khám…), còn phương pháp thăm khám và 
đánh giá tuần tự, lần lượt từng q uy trình có thể lại không phù hợp và nhiều khi 
là quá chậm trễ đối với yêu cầu cấp cứu.  
          2.4. Nguy cơ bị quá tải, hậu quả là dễ có bệnh nhân bị bỏ sót  (ra viện 
mà chưa được xem):  
Lượng bệnh nhân đến cấp cứu rất thay đổi theo thời điểm trong ngày, 
giữa các ngày trong tuần, giữa các mùa…và rất khó dự đoán chính xác được 
lượng bệnh nhân đến cấp cứu. Trên thực tế là thường xuyên có các thời điểm 
các khoa cấp cứu bị quá tải bệnh nhân và quá tải công việc. Khi một khoa cấp 
cứu bị quá tải lên đến 140% côn g suất thì sẽ có nguy cơ bỏ sót bệnh nhân và sai 
sót (bệnh nhân không được cấp cứu kịp thời, có bệnh nhân ra viện mà chưa 
được thăm khám đầy đủ…)  
          2.5. Tính ưu tiên cấp cứu  (giữa các  bệnh nhân; giữa các động tác, can 
thiệp, chăm sóc) mà không phả i theo thứ tự thông thường:  
Do có nhiều thời điểm bị quá tải nên các khoa cấp cứu sẽ phải triển khai 
quy trình phân loại bệnh nhân và các nhân viên cấp cứu sẽ phải rèn luyện kỹ 
năng phân loại bệnh nhân và phân loại các công việc, kỹ thuật can thiệp cấp cứu  
cho phù hợp với yêu cầu ưu tiên cấp cứu. Phản ứng xử lý cấp cứu theo tính ưu 
tiên cấp cứu (bệnh nhân nào cần cấp cứu hơn thì được khám trước, can thiệp 
nào cấp thiết hơn thì ưu tiên thực hiện trước…) giúp đảm bảo các bệnh nhân 
được tiếp cận cấp cứu kịp th ời tương ứng với tình trạng và yêu cầu cấp cứu của 
từng bệnh nhân.  
          2.6. Phải tiếp cận và sắp xếp giải quyết khi có bệnh nhân tử vong  
Tại khoa cấp cứu, nhân viên y tế thường xuyên phải tiếp nhận, cấp cứu và 
giải quyết các việc liên quan đến bệnh n hân ngừng tuần hoàn và tử vong. Khi có 
bệnh nhân tử vong, người bác sỹ cấp cứu phải giải quyết nhiều việc: xác nhận 
tử vong, thông báo và chuẩn bị tâm lý cho người than của bệnh nhân tử 
vong…Đồng thời người bác sỹ cũng sẽ luôn phải đặt ra các câu hỏi và tì m câu 
trả lời: tại sao bệnh nhân tử vong? Bệnh nhân tử vong có nguy cơ lây bệnh cho 
người khác (nhân viên y tế, gia đình và người thân…).            3. Các nguyên tắc chính khi tiếp nhận và xử trí bệnh nhân cấp cứu  
          - Một bác sỹ cấp cứu, y tá cấp c ứu đang trong ca làm việc cần đảm bảo 
bao quát để kiểm soát cả bệnh phòng/khu vực và tất cả các bệnh nhân mà mình 
phụ trách. Điều đó đòi hỏi người nhân viên y tế phải rèn luyện kỹ năng quan sát 
nhanh, phương pháp tổ chức làm việc hợp lý và biết tiết kiệm c ũng như phân 
phối sức lực để đảm bảo cả ca trực.  
          - Một trong các nhiệm vụ khó khăn của bác sỹ cấp cứu là phải ra các 
quyết định, nhất là khi các quyết định đó thường rất quan trọng đến bệnh tật, 
diễn biến và tính mạng của bệnh nhân. Các quyết đị nh điều mà các bác sỹ cấp 
cứu thường phải đối mặt:  
 Triage: b ệnh nhân nào c ần được thăm khám trư ớc? 
 Cần các can thi ệp điều trị nào đ ể ổn định bệnh nhân?  
 Các thông tin nào c ần cho ch ẩn đoán?  
 Cần các đi ều trị cấp cứu nào?  
 Bệnh nhân có c ần nhập viện không ? Hay có th ể ra viện? 
 Thông báo cho b ệnh nhân và cho gia đình ngư ời thân như th ế nào?  
- Khi tiếp cận một bệnh nhân cấp cứu cần tuân thủ các nguyên tắc nhất 
định để đảm bảo ra được các quyết định nhanh, kịp thời và chính xác nhất có 
thể, không bỏ sót các c ấp cứu, bệnh lý nguy hiểm.  
3.1. Phân loại ưu tiên  
- Khi tiếp nhận một bệnh nhân cấp cứu, người nhân viên y tế trước hết 
cần xác định xem bệnh nhân có nguy cơ tử vong hiển hiện không? Nếu không 
có nguy cơ tử vong rõ ràng thì câu hỏi tiếp theo là bệnh nhân c ó gì bất ổn cần 
can thiệp ngay không?  
- Các bệnh nhân vào cấp cứu cần được phân loại theo các mức độ ưu tiên 
để được tiếp nhận cấp cứu cho phù hợp. Có nhiều bảng phân loại khác nhau, 
nhiều mức độ phân loại khác nhau.  
- Trên thực tế thì điểm quan trọng nh ất là phải xác định xem bệnh nhân 
thuộc loại nào trong số 3 tình trạng sau:  
+ Nguy kịch (khẩn cấp) (critical):  bệnh nhân có bệnh lý, tổn thương, rối 
loạn đe dọa tính mạng, nguy cơ tử vong nhanh chóng nếu không được can thiệp 
cấp cứu ngay. Các bệnh nhân ngu y kịch cần được tập trung cấp cứu ngay, có thể 
phải huy động thêm cả các nhân viên khác cùng đến tham gia cấp cứu.  
+ Cấp cứu (emergency):  bệnh nhân có bệnh lý, tổn thương, rối loạn có 
thể tiến triển nặng lên nếu không được can thiệp điều trị nhanh chóng. C ác bệnh 
nhân cấp cứu cần được tập trung cấp cứu nhanh chóng và theo dõi sát sao, bệnh 
nhân cần được đặt trong tầm mắt cảnh giới theo dõi của nhân viên y tế.  
+ Không cấp cứu: bệnh nhân có các bệnh lý, tổn thương, rối loạn mà ít có 
khả năng tiến triển nặng, đe dọa tính mạng. Các bệnh nhân không cấp cứu có 
thể chờ để khám lần lượt sau khi các bệnh nhân nguy kịch/cấp cứu đã được tiếp 
nhận và tạm ổn định.  
3.2. Ổn định bệnh nhân trước khi tập trung vào thăm khám chi tiết:  
- Cần tiếp cận bệnh nhân cấp cứu theo trì nh tự vừa đảm bảo ổn định bệnh 
nhân vừa đảm bảo thăm khám được đầy đủ, không bỏ sót tổn thương.  
- Thăm khám cần tiến hành qua 2 bước (2 cấp) tuần tự (primary survey 
và secondary survey)  -Bước 1 (primary survey):  nhận định và kiểm soát ổn định các chức năng  sống 
- Mục tiêu là tìm các rối loạn/tổn thương đe dọa các chức năng sống và thực 
hiện ngay các can thiệp cần thiết để đảm bảo ổn định các chức năng sống.  
+ Tập trung vào đánh giá và kiểm soát tuần tự ABCD (đường thở, hô hấp, 
tuần hoàn, thần kinh).  
+ Nhan h chóng xác định các tổn thương/rối loạn quan trọng làm ảnh 
hưởng các chức năng sống và có thể xử trí được ngay: tràn khí màng phổi áp 
lực, vết thương mạch máu, ép tim cấp do tràn dịch/máu màng ngoài tim, rối 
loạn toan/kiềm máu nặng, rối loạn kali máu, hạ đường máu…  
+ Thực hiện ngay các điều trị, thủ thuật và can thiệp cấp cứu để ổn định 
các chức năng sống: khai thông đường thở, đặt NKQ, bóp bóng, thở ô xy, đặt 
đường truyền tĩnh mạch, bồi phụ thể tích, cầm máu, chọc màng phổi, chọc dịch 
màng ngoài tim, sốc điện chuyển nhịp nhanh…  
- Các thông tin về tiền sử, bệnh sử, thuốc đang dùng, xét nghiệm nhanh… 
có thể rất có ích cho các quyết định xử trí, tuy nhiên không nên mất nhiều thời 
gian vào hỏi, thăm khám, làm xét nghiệm/thăm dò và không vì hỏi, thăm khám, 
làm xét nghiệm/thăm dò mà làm chậm trễ quá trình đánh giá và kiểm soát các 
chức năng sống.  
Bước 2 (secondary survey) : thăm khám một cách hệ thống và chi tiết theo trình 
tự  
- Mục tiêu là đánh giá đầy đủ các tổn thương/rối loạn/bệnh lý để có kế 
hoạch xử trí cấp  cứu và xử trí điều trị triệt để hợp lý.   
- Để đảm bảo không bỏ sót các tổn thương, dấu hiệu/triệu chứng… cần 
tuân thủ nguyên tắc và trình tự thăm khám:  
+ Đứng cạnh bệnh nhân để thu thập bệnh sử.  
+ Thăm khám lâm sàng một cách tập trung và liên tục, tránh bị ngắt 
quãng.  
+Nên thăm khám một cách hệ thống, tuần tự từ đầu đến chân (đầu mặt cổ, 
ngực, bụng, khung chậu, chi, lưng…) và thăm khám hết tất cả các hệ thống cơ 
quan (thần kinh, hô hấp, tim mạch, bụng và tiêu hóa, thận -tiết niệu, sinh dục, tai 
mũi họng, mắt, răng hàm mặt…).  
+ Nên tập trung thăm khám kỹ vào các bộ phận liên quan đến các lí do 
chính làm bệnh nhân đến cấp cứu cũng như tập trung vào tìm kiếm các dấu hiệu 
giúp cho định hướng chẩn đoán.  
+ Chỉ nên làm các thăm dò, xét nghiệm giúp loại trừ hoặc khẳng định 
chẩn đoán, hoặc giúp định hướng chuyển/nhập viện bệnh nhân  
3.3. Ra quyết định về chẩn đoán và định hướng xử trí: ưu tiên chẩn 
đoán và xử trí các rối loạn/tổn thương nguy hiểm và cố gắng chẩn đoán loại trừ 
các cấp cứu.  
- Người bác sỹ cấp cứu thườ ng xuyên phải tận dụng triệt để lượng thông 
tin có, xử lý hiệu quả tối đa các thông tin này dựa vào kiến thức, kỹ năng và 
kinh nghiệm. Một trong các tính chuyên khoa của cấp cứu là xử lý hiệu quả và 
nhanh chóng đưa ra được các quyết định mà chỉ dựa vào lượ ng thông tin ít ỏi có 
được.  
- Trong điều kiện bị áp lực về thời gian và thiếu thông tin, nên tuân thủ một 
số nguyên tắc nhất định để có thể tiến đến các chẩn đoán và xử trí hợp lý nhất:  
+ Chẩn đoán nếu có thể, nếu không có chẩn đoán: chẩn đoán và xử trí cá c 
rối loạn/tổn thương nguy hiểm và tập trung vào kiểm soát hoặc loại trừ các cấp 
cứu. + Đưa ra các chẩn đoán bệnh lý cấp cứu nguy hiểm, chẩn đoán nhiều khả 
năng nhất trước; Người bác sỹ nên tư duy qua 3 bước:  
. Tính toán và liệt kê tất cả các khả năng có thể 
. Sau đó xác định các nguyên nhân/tổn thương/rối loạn nào là nguy cơ 
nặng nề, nguy hiểm nhất và lên kế hoạch chẩn đoán và xử trí theo định hướng 
này. 
. Xác định xem liệu có các nguyên nhân/tổn thương/rối loạn khác cần 
phải được xử lý không  
+ Tập hợp cá c thông tin để xác nhận hoặc loại trừ chẩn đoán bệnh cấp 
cứu nguy hiểm trước, rồi đến các chẩn đoán nhiều khả năng nhất  
+ Tránh chẩn đoán kiểu “chộp được”, nên tìm chẩn đoán theo sơ đồ cây 
chẩn đoán (algorithm)  
+ Điều trị có thể giúp thêm cho chẩn đoán: đ áp ứng với điều trị hoặc 
ngược lại không đáp ứng với điều trị cũng đều là các thông tin tốt giúp thêm 
cho định hướng chẩn đoán.  
+ Chỉ nên làm các thăm dò, xét nghiệm giúp loại trừ hoặc khẳng định 
chẩn đoán, hoặc giúp định hướng chuyển/nhập viện bệnh nhân  
+ Nên sử dụng các quy trình, hướng dẫn xử trí, điều trị cấp cứu để tiết 
tiệm sức và trí não trong giờ trực  
+ Nên bỏ ra ít nhất 2 -3 phút tập trung suy nghĩ cho mỗi bệnh nhân  
3.4. Định hướng chuyển:  vào viện/ra viện hay lưu theo dõi  
- Trước mỗi bệnh nhân cấp cứu, người bác sỹ chắc chắn sẽ phải quyết 
định xem bệnh nhân sẽ được bố trí chỗ như thế nào: nhập viện hay ra viện hay 
lưu theo dõi? Nếu nhập viện thì cho nhập vào khoa nào? Cho nhập viện ngay 
hay chờ theo dõi thêm?  
- Trong nhiều trường hợp thì quyết định cho vào viện hay cho ra viện là 
một quyết định rất khó khăn. Nhất là khi không có sự thống nhất giữa ý đồ của 
bác sỹ và nguyện vọng của bệnh nhân/gia đình bệnh nhân.  
- Để việc quyết định đỡ khó khăn và giảm thiểu sai sót, rủi ro, cần tuân 
theo một số nguyê n tắc hoặc trả lời một số câu hỏi:  
+ Bệnh nhân có cần nằm viện không?  
+ Nếu cho ra viện: có đủ an toàn cho bệnh nhân không và cần theo dõi 
như thế nào?  
+ Để bệnh nhân lưu lại theo dõi thêm tại khoa cấp cứu nếu chưa có quyết 
định hoặc còn phân vân hoặc khi  bệnh nhân/gia đình bệnh nhân lo lắng  
+ Suy nghĩ cẩn thận trước khi quyết định  
+ Tránh đưa ra quyết định khi đang căng thẳng hoặc đang cáu giận: tạm 
dừng lại trấn tĩnh vài phút rồi sau đó mới quay lại giải quyết tiếp và quyết định  
3.5. Chú ý đến cửa sổ điề u trị/thời gian vàng trong cấp cứu:  
- Phần lớn các cấp cứu có thể cải thiện tiên lượng tử vong/bệnh tật/biến 
chứng nếu được tiếp cận và can thiệp sớm trong một giới hạn thời gian nhất định 
(“thời gian vàng”). Người nhân viên cấp cứu cần rất chú ý và phấn đ ấu để có thể 
tiếp cận và can thiệp điều trị bệnh nhân sớm trong khoảng thời gian này.  
- Một số ví dụ:  
+ Ngừng tuần hoàn (NTH) và sốc điện: Sốc điện cấp cứu phá rung thất sẽ 
có hiệu quả nhất nếu được thực hiện trong vòng 5 phút đầu sau ngừng tim. Hồi 
sinh t im phổi kết hợp với sốc điện sớm trong vòng 3 đến 5 phút đầu tiên sau khi 
NTH có thể đạt tỷ lệ cứu sống lên đến 50% -75%.  + Hội chứng động mạch vành cấp: cửa sổ thời gian cho dùng thuốc tiêu 
sợi huyết là 12 giờ đối với NMCT có ST chênh lên (STEMI).  
+ Tắc m ạch não: cửa sổ thời gian cho dùng thuốc tiêu sợi huyết 
(Alteplase) là 3 giờ.  
+ Sốc nhiễm khuẩn/nhiễm khuẩn nặng: cần cho kháng sinh đường tiêm 
trong vòng 1 giờ, điều trị tích cực sớm theo mục tiêu trong 6 giờ đầu.  
+ Vết thương động mạch/ga rô mạch: cần c an thiệp lập lại tưới máu trong 
vòng 6 giờ. Nếu để muộn trên 6 giờ thì nguy cơ phải cắt cụt rất cao.  
4. Các nguyên tắc để tránh sai lầm:  
- Tránh rào cản lớn nhất đối với chẩn đoán đúng: bị ảnh hưởng của chẩn 
đoán trước đó  
- Tránh bị ảnh hưởng bởi suy nghĩ của người khác: bị nhiễu chẩn đoán và 
nhiễu từ người khác (bias)  
- Chú ý đến các dấu hiệu sống, các ghi chép của tuyến trước và ghi chép 
của y tá  
- Tránh “gập” hồ sơ vào quá sớm, khi mà chưa có chẩn đoán rõ ràng: cần 
cho bệnh nhân vào danh sách chưa có chẩ n đoán hoặc chẩn đoán chưa rõ ràng 
và có cảnh báo, theo dõi thích hợp  
- Thận trọng vào các thời điểm nguy cơ cao: khi bệnh nhân ký để ra sớm, 
khi đông bệnh nhân, giờ cao điểm hoặc thời điểm mệt mỏi.  
- Thận trọng với nhóm bệnh nhân nguy cơ cao: lang thang,  nghiện rượu, 
nghiện thuốc, bạo lực, bị lạm dụng, rối loạn tâm thần  
- Thận trọng với bệnh nhân quay lại: bệnh nhân có thể có các vấn đề cấp 
cứu mà chưa được phát hiện hoặc chưa được xử trí đúng. Bệnh nhân quay lại 
cũng là cơ hội tốt để chúng ta có thể sửa chữa các sai sót hoặc bỏ sót trong chẩn 
đoán và xử trí của lần đến cấp cứu trước.  
- Chú ý đến các chẩn đoán quan trọng có nguy cơ cấp cứu cao (cần nghĩ 
đến và loại trừ trước): nhồi máu cơ tim cấp, tắc động mạch phổi, tắc động/tĩnh 
mạch, xuất huyết dưới nhệ n, chảy máu não ở bệnh nhân ngộ độc, viêm màng 
não, viêm ruột thừa, chửa ngoài tử cung, xoắn tinh hoàn, chấn thương gân hoặc 
thần kinh…  
- Thận trọng khi thấy có chẩn đoán đặt ra trước đó không phù hợp (không 
tương ứng với dấu hiệu, triệu chứng… của bệnh nh ân). 
 
TÀI LI ỆU THAM KH ẢO 
 
1. Vũ Văn Đính: Nguyên lý cơ bản hồi sức cấp cứu. Trong quyển: Hồi 
sức nội khoa. NXB Y học 2003.  
2. Nguyễn Đạt Anh, Nguyễn Văn Chi, Phùng Nam Lâm: Phân loại bệnh nhân 
cấp cứu theo mức độ ưu tiên. Tạp chí lâm sàng bệnh viện Bạch ma i, 2004  
3. Russell Jones T. Approach to the Emergency Department Patient. In: 
Current D & T Emergency Medicine, 2008.  
 
CÂU H ỎI LƯ ỢNG GIÁ  
Câu 1:  Các tiêu chí đánh giá b ệnh nhân c ấp cứu là 
A. Dấu hiệu sinh t ồn B. Đặc điểm hình thái t ổn thương  
C. Mức độ nặng của bệnh  
D. Khả năng đi l ại của bệnh nhân  
E. Tất cả các tiêu chí trên  
Câu 2: Trên hiện trường vụ tai nạn sập nhà cao tầng có 1 nạn nhân trong 
tình trạng tỉnh, tụ máu dưới da đầu, gãy xương đùi kín, đau bụng vùng mạng 
sườn phải, mạch nhanh nhỏ 120 lần/phút   huyết áp 70/40 mmHg. Hãy chọn 
loại biển đeo cho nạn nhân: 
A.  Đen 
B. Đỏ 
C.  Vàng       
D. Xanh 
Câu 3: Một bệnh nhân nam 65 tuổi vào viện vì đau ngực khám thấy 
bệnh nhân tỉnh, đau dữ dội vùng ngực trái, nhịp tim 120lần/ phút, huyết áp 
90/60 mmHg. Hãy phân nhóm bệnh nhân: 
A. Cấp cứu khẩn cấp 
B. Nặng - cần được đánh giá đầy đủ 
C. Nhóm cần theo dõi phát hiện tình trạng cấp cứu sắp xảy ra  
D. Không có tình trạng cấp cứu 
Câu 4. Một bệnh nhân nữ 50 tuổi vào viện vì nôn máu đỏ lẫn ít máu cục 
2 lần kèm đi ngoài phân đen khám bệnh nhân tỉnh, niêm mạc nhợt, không tiếp 
tục nôn máu  mạch 110lần/ phút, huyết áp 100/70mmHg, bụng mềm không 
phản ứng. Hãy phân nhóm bệnh nhân: 
A. Cấp cứu khẩn cấp 
B. Nặng - cần được đánh giá đầy đủ 
C. Nhóm cần theo dõi phát hiện tình trạng cấp cứu sắp xảy ra d) Không 
có tình trạng cấp cứu 
 
 
 
 
 
 
 
 
 
 
 Bài 2  
CÁC K Ỹ THU ẬT KIỂM SOÁT ĐƯỜNG TH Ở 
 
MỤC TIÊU  
Sau khi h ọc xong h ọc viên có kh ả năng:  
  1. Kể tên đư ợc những rối loạn gây t ắc ngh ẽn đường th ở thường gặp. 
  2. Trình bày đư ợc cách x ử trí tắc ngh ẽn đường th ở. 
           
NỘI DUNG  
   1. Đại cương  
Khai thông đư ờng th ở là một thủ thuật cấp cứu rất quan trong đ ối với các 
thầy thu ốc cấp cứu nhằm đảm bảo ô xy và thông khí đ ầy đủ cho b ệnh nhân. Các 
điểm chính c ủa chăm sóc đư ờng th ở là bảo vệ đường th ở, giải phóng t ắc ngh ẽn, 
và kỹ thuật hút đ ờm giãi.  
Các th ủ thuật khai thông đư ờng th ở có th ể rất đơn gi ản như thay đ ổi tư 
thế đầu bệnh nhân (k ỹ thuật ngửa đầu nâng c ằm, ấn giữ hàm). Khai thông 
đường th ở là một ưu tiên đ ầu tiên. Sau đó ti ến hành thông khí mi ệng - miệng, 
miệng - mask, ho ặc bóng ambu. Cu ối cùng là các bi ện pháp b ảo vệ đường th ở 
như canuyn h ọng mi ệng, đ ặt nội khí qu ản, ho ặc mở khí qu ản 
Các k ỹ thuật đặt nội khí qu ản (đư ờng mũi, đư ờng mi ệng), n ội khí qu ản 
theo trình t ự nhanh, m ở khí qu ản qua màng nh ẫn giáp, m ở khí qu ản qua da đư ợc 
trình bày chi ti ết trong các bài riêng  
  2. Nguyên nhân gây t ắc ngh ẽn đư ờng th ở 
2.1. Nguyên nhân n ội sinh  
- Do s ập các t ổ chức phần mềm vùng h ọng mi ệng (gi ảm trương l ực cơ, 
gẫy xương hàm)  
- Phù thanh qu ản/co th ắt thanh qu ản 
- Viêm s ụn nắp thanh qu ản cấp, viêm thanh qu ản cấp, bạch hầu thanh 
quản 
- Liệt dây thanh âm hai bên  
- ị ứng gây phù niêm m ạc họng và khí qu ản, thư ờng do ph ản ứng dị ứng 
khi b ị ong đ ốt, kháng sinh ho ặc các thu ốc hạ huyết áp ( ức chế men chuy ển) 
- Chấn thương thanh qu ản, kh ối u thanh qu ản 
2.2. Nguyên nhân ngo ại sinh  
- Phù thanh qu ản 
- Ổ mủ vùng h ầu họng 
- Khối máu t ụ (do r ối loạn đông máu, ch ấn thương, ph ẫu thu ật) 
- U tuy ến giáp  
- U hạch 
- U ho ặc dị vật thực quản 
2.3. Di v ật 
- Thức ăn 
- Đồ chơi v ới trẻ em ho ặc bất kì đ ồ vật gì v ới các ngư ời bệnh sa sút trí tu ệ 
hoặc ngư ời bệnh tâm th ần 
3. Các k ỹ thuật khai thông đư ờng th ở 3.1. Tư th ế bệnh nhân   
* Khi b ệnh nhân trong tình tr ạng không đáp ứng (bao g ồm ng ừng tu ần hoàn)
  
- Nhanh chóng phát hi ện chấn thương c ổ hoặc mặt nếu có ch ấn thương 
cột sống cổ để cổ ở tư thế ngửa trung gian.  
- Nếu bệnh nhân đang n ằm nghiêng ho ặc sấp thì dùng k ỹ thuật “lật khúc 
gỗ” (lật đồng th ời cả đầu, thân  và chân tay cùng lúc) đ ể đưa b ệnh nhân v ề tư 
thế  nằm ng ửa. 
- Mở đường th ở bằng m ột trong hai cách : ngửa đầu / nh ấc cằm nếu không 
nghi ng ờ có ch ấn thương c ột sống cổ hoặc ấn giữ hàm: chủ yếu do nhân viên y 
tế được huấn luy ện thực hiện (nếu nghi ng ờ có ch ấn thương c ột sống cổ). 
- Một nguyên nhân thư ờng gặp nhất gây t ắc ngh ẽn đường th ở là tụt lưỡi, 
chỉ áp dụng m ột trong hai cách trên có th ể đã đủ kéo lư ỡi về phía trư ớc và m ở 
thông đư ờng th ở (Hình  4) . 
 
 
Hình 4 . Kỹ thuật ngửa đầu nhấc cằm: (A) T ắc ngh ẽn đường th ở do tụt lưỡi; (B) 
Đường th ở thông khi th ực hiện kỹ thuật. 
 
 
Hình 5 . Kỹ thuật ấn giữ hàm A 
B  
* Các trư ờng h ợp khác : Bệnh nhân suy hô h ấp, phù não, TBMN : tư th ế 
fowler. B ệnh nhân phù ph ổi cấp : ng ồi thõng chân  
3.2. X ử trí tắc ngh ẽn đư ờng th ở   
Việc phát hi ện sớm tắc ngh ẽn đường th ở có tính quy ết định. Các d ị vật có 
thể gây t ắc ngh ẽn đường thở một phần hoặc hoàn toàn :   
- Tắc ngh ẽn một phần:  
+ Trao đ ổi khí có th ể gần bình thư ờng, b ệnh nhân v ẫn tỉnh và ho đư ợc, 
cần động viên b ệnh nhân t ự làm s ạch đư ờng th ở bằng cách ho.   
+ Nếu vẫn còn t ắc ngh ẽn, trao đ ổi khí x ấu đi, b ệnh nhân ho không hi ệu 
quả khó th ở tăng lên, tím thì c ần can thi ệp gấp.  
- Tắc ngh ẽn hoàn toàn :   
+ Bệnh nhân không th ể nói, ho, th ở ; hôn mê và c ần được cấp cứu ngay.  
Nếu các c ố gắng đi ều chỉnh tư th ế bệnh nhân th ất bại hoặc thấy có d ị vật ở 
miệng, h ầu thì áp d ụng các bi ện phá p sau :  
 
Hình 6.  Dấu hiệu kinh đi ển của dị vật đường th ở 
 
3.2.1. Ép b ụng (nghi ệm pháp Heimlich)   
 Ép vào vùng thư ợng vị nhanh làm đ ẩy cơ hoành lên trên gây tăng áp l ực lồng 
ngực và t ạo một luồng khí m ạnh tống dị vật ra kh ỏi đường th ở, tương t ự như ho:  
- Nếu bệnh nhân đang ng ồi hoặc đứng : Đ ứng sau b ệnh nhân và dùng cánh 
tay ôm eo b ệnh nhân, m ột bàn tay n ắm lại, ngón cái ở trên đư ờng gi ữa, đặt lên 
bụng hơi trên r ốn, dư ới mũi ức. Bàn tay kia ôm lên bàn tay đã n ắm và dùng đ ộng 
tác gi ật (để ép) lên trên và ra sau m ột cách th ật nhanh và d ứt khoát l ặp lại động tác 
tới khi gi ải phóng đư ợc tắc ngh ẽn hoặc tri giác b ệnh nhân x ấu đi.  
- Khi b ệnh nhân hôn mê : đặt bệnh nhân n ằm ng ửa, mặt ngửa lên trên, n ếu 
nôn đ ể đầu bệnh nhân nghiêng m ột bên và lau mi ệng. Ngư ời cấp cứu quỳ gối ở 
hai bên hông b ệnh nhân, đ ặt một cùi bàn tay lên b ụng  ở giữa rốn và mũi ức, 
bàn tay kia úp lên trên, đưa ngư ời ra phía trư ớc ép nhanh lên phía trên, làm l ại 
nếu cần. 
- Khi ch ỉ một ngư ời cấp cứu và ph ải ép tim, hô h ấp nhân t ạo thì qu ỳ gối ở 
một bên c ạnh hông b ệnh nhân đ ể dễ di chuy ển và dùng tay ép như trên. N ếu có 
2 ngư ời một ngư ời hô h ấp nhân t ạo và ép tim, m ột ngư ời làm nghi ệm pháp.  - Nếu chỉ có m ột mình n ạn nhân: T ự ép bụng bằng cách ấn nắm tay lên 
bụng ho ặc ép b ụng vào các b ề mặt chắc như bồn rửa, lưng gh ế, mặt bàn, v.v...  
 
Hình 7 . Thủ thuật Heimlich khi b ệnh nhân t ỉnh 
 
Hình 8 . Thủ thuật Heimlich khi b ệnh nhân hôn mê  
 
Sau m ỗi đợt ép b ụng : Dùng 2 đ ến 3 ngón tay đ ể móc khoang mi ệng ki ểm 
tra. Sau khi l ấy được dị vật hô h ấp lại cho b ệnh nhân , nếu có k ết quả đánh giá 
hô hấp, tuần hoàn và th ực hiện các can thi ệp thích h ợp. Nếu không th ể hô hấp 
được cho b ệnh nhân l ập lại quá trình : Ép b ụng, ki ểm tra đư ờng th ở và hô h ấp 
nhân t ạo, nh ắc lại tới khi gi ải phóng đư ợc đường th ở và hô h ấp nhân t ạo được 
  
 
Hình 9 : Kỹ thuật lấy bỏ dị vật 
 
3.2.2. V ỗ lưng và ép ng ực: Vì nghi ệm pháp Heimlich có th ể dễ dàng gây 
chấn thương b ụng khi dùng cho tr ẻ nhỏ, kết hợp vỗ lưng và ép ng ực ở các đ ối 
tượng này đ ể loại trừ dị vật. Ch ỉ động tác v ỗ lưng đã có th ể tống đư ợc dị vật, 
nếu không có hi ệu quả thì nối tiếp bằng ép ng ực, sau đó ki ểm tra đư ờng th ở.   
- Đặt trẻ nhỏ nằm trên tay tư th ế sấp dọc theo tr ục của tay và đ ầu trẻ ở thấp. 
- Dùng ph ần phẳng của bàn tay v ỗ nhẹ và nhanh 5 cái lên vùng gi ữa hai 
xương b ả vai. 
- Nếu vỗ lưng không đ ẩy được dị vật ra, l ật trẻ nằm ng ửa và ép ng ực 5 cái. 
Vị trí và cách ép như v ới ép tim nhưng v ới nhịp độ chậm hơn.  
- Làm s ạch đư ờng th ở giữa các l ần vỗ lưng - ép ng ực, quan sát khoang 
miệng dùng tay l ấy bất cứ dị vật nào n ếu nhìn th ấy, không dùn g ngón tay đưa 
sâu đ ể lấy dị vật.   
Hình  10 . Kỹ thuật vỗ lưng (A) ép ng ực (B) ở trẻ nhỏ 
 
* Đánh giá hi ệu qu ả:  
- Sau m ỗi động tác làm s ạch đư ờng th ở, xác đ ịnh theo d ị vật đã đư ợc tống 
ra chưa và đư ờng th ở đã đư ợc giải phóng chưa, n ếu chưa đư ợc lặp lại trình t ự 
các đ ộng tác thích h ợp tới khi thành công.  
- Loại trừ dị vật thành công khi th ấy : (1) th ấy chắc chắn dị vật được tống 
ra (2) B ệnh nhân th ở rõ và nói đư ợc (3) B ệnh nhân t ỉnh hơn (4) màu da b ệnh 
nhân tr ở về bình thư ờng. 
- Nếu các đ ộng tác này đư ợc làm liên t ục không có hi ệu quả thì th ực hiện 
các bi ện pháp  khác m ạnh m ẽ hơn n ếu có: Dùng đèn soi thanh qu ản và l ấy dị vật 
bằng kẹp Margill, m ở khí qu ản qua màng nh ẫn giáp, m ở khí qu ản qua da. Các 
kỹ thuật này là nâng cao, đòi h ỏi các nhân viên đư ợc đào t ạo đặc biệt tiến hành.  
  4. Các k ỹ thuật bảo vệ đường th ở 
4.1. Đặt Canuyn h ầu 
* Mục đích :  
- Giúp duy trì s ự thông thoáng c ủa đường th ở và thông khí đ ầy đủ, đặt 
biệt khi dùng bóng Ambu và mask. Canuyn đ ặt đúng cũng giúp hút đ ờm dãi d ễ 
dàng hơn.  
- Chỉ nên đư ợc thực hiện khi các bi ện pháp cơ b ản hỗ trợ các ch ức năng 
sống đã đư ợc thực hiện. 
- Dụng cụ này làm thông thoáng đư ờng th ở bằng cách tách lư ỡi ra kh ỏi 
thành h ọng. A 
B * Dụng cụ : 
- Canuyn: có 2 lo ại : canuyn mi ệng hầu và canuyn mũi h ầu. 
- Đè lư ỡi. 
- Chất bôi trơn canuyn.  
4.1.1. Canuyn mi ệng h ầu: có lo ại Guedel và Berman v ới các c ỡ khác 
nhau.  
- Chọn cỡ thích h ợp bằng cách đ ặt đầu ngoài c ủa canuyn ở ngang góc 
miệng bệnh nhân, n ếu đầu trong canuyn t ới góc hàm là phù h ợp.  
- Canuyn đ ặt đúng khi: Đ ầu trong n ằm ở góc lư ỡi và trên n ắp thanh môn, 
mép ở đầu ngoài c ủa canun ở bên ngoài cung răng. Có 2 k ỹ thuật đặt: 
+ Nh ấc hàm đ ể làm tách lư ỡi ra kh ỏi thành sau h ọng, xoay canuyn 1800 
trước khi đ ặt, khi đ ầu canuyn ch ạm hàm ếch cứng thì xoay tr ở lại 1800  làm cho 
bề cong c ủa canun x ếp theo khoang mi ệng. 
+ Dùng đè lư ỡi để ấn lưỡi, canuyn đư ợc trượt trên lư ỡi theo đ ộ cong c ủa 
vòm mi ệng. 
- Nếu đặt canuyn sai v ị trí làm đ ẩy lưỡi ra sau gây t ắc ngh ẽn thêm do đó 
người đặt cần được huấn luy ện trư ớc. 
- Chống ch ỉ định : B ệnh nhân t ỉnh ho ặc bán mê (có th ể gây kh ạc, nôn, co 
thắt thanh qu ản), ch ấn thương khoang mi ệng, ch ấn thương xương hàm dư ới 
hoặc phần hộp sọ thuộc xương hàm trên, t ổn thương choán ch ỗ hoặc dị vật ở 
miệng họng. 
 
 
 
Hình  11 . Canuyn mi ệng họng: (A)  Loại Guedel (B) Lo ại Connel; (C) v ị trí 
 
4.1.2. Canuyn mũi h ầu 
- Giống Canuyn mi ệng h ọng ở chỗ tách lư ỡi ra kh ỏi thành sau h ọng 
nhưng khác là canuyn này đư ợc đặt qua mũi t ạo một con đư ờng từ lỗ mũi ngoài 
đến gốc lưỡi. 
- Chỉ định khi không đ ặt được canuyn miệng hầu, ch ống ch ỉ định khi có 
chấn thương ho ặc tổn thương choán ch ỗ, dị vật ở vùng mũi, tr ẻ nhỏ (do l ỗ mũi 
nhỏ).  
- Có nhi ều cỡ khác nhau nhưng quan tr ọng là chi ều dài c ủa canuyn. 
Chiều dài thích h ợp tương x ứng với kho ảng cách t ừ  dái tai t ới chân cánh mũi. 
Cách đ ặt: Ngửa nhẹ đầu về phía sau, bôi trơn canuyn, đưa canuyn th ẳng 
góc v ới bình di ện của mặt bệnh nhân, t ừ từ tiến canuyn qua c ửa mũi, đ ảm bảo 
mặt vát c ủa canuyn hư ớng về phía vách mũi, n ếu thấy đưa vào khó có th ể xoay nhẹ, nếu vẫn khó r ất có th ể do vẹo vách mũi thì đ ặt lỗ mũi bên kia ho ặc dùng 
canun c ỡ nhỏ hơn. Đ ặt xong có th ể kiểm tra v ị trí bằng cách dùng đè lư ỡi để 
nhìn. không c ần cố định canuyn thêm.  
 
 
Hình 12 : Canuyn mũi -họng: (A) Các c ỡ khác nhau; (B) V ị trí 
 
     4.2. M ặt nạ thanh qu ản 
- Mặt nạ thanh qu ản là m ột loại đường th ở cố định vừng ch ắc hơn so v ới 
mặt nạ mũi mi ệng nhưng kém hơn so v ới nội khí qu ản. 
- Mặt nạ thanh qu ản thư ờng đư ợc sản xuất dưới dạng ống silicon (ho ặc 
nhựa). Ph ần cuff (m ặt nạ thanh qu ản) đư ợc nối với bóng cuff. N ếu đặt đúng v ị 
trí thì 3 l ỗ mở sẽ hướng th ẳng vào thanh qu ản. Đôiư v ới ngư ời lớn thư ờng dùng 
cỡ số 4, số 1 cho tr ẻ sơ sinh ho ặc trẻ < 6,5 kg; s ố 2 cho tr ẻ từ 6,5-20 kg; s ố 3 
cho tr ẻ > 30 kg.  
- Nên dùng m ặt nạ thanh qu ản cho các b ệnh nhân hôn mê. Tư th ế đầu 
ngửa. Cho b ệnh nhân há mi ệng và đ ầu của cuff ép sát vào vòm h ọng. Đ ẩy mặt 
nạ vào sâu cho đ ến khi th ấy cảm giác vư ớng. M ặt nạ được đặt đúng khi sau khi 
bơm cuff th ấy luồng hơi th ở của bệnh nhân ph ụt lên.  
- Chống ch ỉ định: ch ấn thương c ột sống cổ nên b ệnh nhân  không ư ỡn 
được cổ, bệnh nhân không há đư ợc miệng, ch ấn thương h ầu họng, nh ững bệnh 
nhân có nguy cơ s ặc cao, và khi c ần phải duy trì đư ờng th ở kéo dài.  
 
 
Hình 13 . Mặt nạ thanh qu ản 
 A B  
Hình 14 . Vị trí m ặt nạ thanh qu ản 
 
    4.3. Các bi ện pháp khác : Đặt nội khí qu ản, m ở khí qu ản, ch ọc, mở màng 
nhẫn giáp . 
TÀI LI ỆU THAM KH ẢO 
Current Emergency Diagnosis  & Treatment, 5th Edition . The McGraw -
Hill Companies 2004.    
CÂU H ỎI LƯ ỢNG GIÁ  
Câu 1: Tư th ế hợp lý làm thông thoáng đư ờng hô h ấp ở bệnh nhân không 
có ch ấn thươ ng cổ mặt là: 
A. Bệnh nhân n ằm ng ửa, cổ ở tư thế trung gian.  
B. Bệnh nhân n ằm ng ửa, cổ ưỡn 
C. Bệnh nhân n ằm đầu cao 30 đ ộ 
D. Cả 3 tư th ế trên đ ều được 
Câu 2: Một bệnh nhân nghi ng ờ sặc phải dị vật, vào vi ện trong tình tr ạng 
tỉnh, khó th ở, tím nh ẹ. Thái đ ộ xử trí cần làm trư ớc tiên là:  
A. Chuy ển ngay b ệnh nhân lên tuy ến chuyên khoa đ ể soi và l ấy dị vật 
B. Bóp bóng và d ặt nội khí qu ản 
C. Làm các nghi ệm pháp t ống dị vật ra ngoài  
D. Để bệnh nhân n ằm ng ửa, cổ ưỡn và th ở oxy 
Câu 3: Một BN vào vi ện vì suy hô h ấp khó th ở thanh qu ản, BN  đã có 
chẩn đoán U h ạ họng-thanh qu ản. Các bi ện pháp c ấp cứu nào sau đây là đúng:  
A. Bóp bóng có Oxy.  
B. Bóp bóng và đ ặt nội khí qu ản 
C. Bóp bóng và m ở màng nh ẫn giáp  
D. Bóp bóng và m ở khí qu ản cấp cứu Câu 4: Một BN vào vi ện vì tai n ạn giao thông có CT s ọ não, v ỡ xương 
hàm. BN có d ấu hiệu suy hô h ấp. Thái đ ộ xử trí nào sau đây là đúng:  
A. Cho BN th ở Oxy và chuy ển BN đ ến cơ s ở chuyên khoa  
B. Cho BN th ở Oxy và chu ẩn bị đặt NKQ  
C. Tiến hành m ở màng nh ẫn giáp  
D. Tiến hành  m ở khí qu ản cấp cứu  Bài 3  
CHẨN ĐOÁN VÀ X Ử TRÍ C ẤP CỨU BAN Đ ẦU SUY HÔ H ẤP CẤP 
 
MỤC TIÊU  
Sau khi h ọc xong h ọc viên có kh ả năng:  
1. Trình bày đư ợc các nguyên nhân suy hô h ấp thường gặp. 
2. Nhận biết được khó th ở và định hư ớng ch ẩn đoán đư ợc một số nguyên 
nhân chính.  
NỘI DUNG  
1. Đại cương  
Suy hô h ấp cấp là m ột cấp cứu nội khoa, x ảy ra khi h ệ thống hô h ấp 
không th ể đáp ứng đư ợc nhu c ầu chuy ển hóa c ủa cơ th ể 
Có d ạng suy hô h ấp: thi ếu ô xy máu, tăng CO2 máu và h ỗ hợp 
- Thiếu ô xy máu khi PaO2  50-60mmHg  
- Tăng CO2 máu khi Pa CO2  50 mmHg kèm theo tình tr ạng toan máu 
pH < 7,36  
- Thể hỗn hợp là v ừa có gi ảm ô xy hóa máu và tăng CO2 máu là d ạng suy 
hô hấp hay g ặp trên b ệnh nhân n ặng 
Suy hô h ấp cấp có th ể xảy ra trên m ột bệnh nhân chưa có b ệnh ph ổi từ trước 
hoặc trên b ệnh nhân có suy hô h ấp mạn tính  
2. Chẩn đoán  
2.1. Chẩn đoán xác đ ịnh 
- Khó th ở:  
+ Là tri ệu chứng báo hi ệu quan tr ọng và nh ạy 
+ Khó th ở nhanh (> 25 l ần/ phút) ho ặc chậm ( < 12 l ần/ phút) ho ặc loạn 
nhịp thở (Kussmaul, Cheyne - Stockes ... ), biên đ ộ thở nhanh ho ặc giảm 
- Tím: Xu ất hiện khi Hb kh ử > 5g/ dL, là bi ểu hiện của suy hô h ấp nặng 
+ Sớm: tím quanh môi, môi, đ ầu chi  
+ Nặng, mu ộn: tím lan r ộng ra toàn thân  
+ Không có tím ho ặc tím xu ất hiện mu ộn nếu ngộ độc khí CO  
- Vã m ồ hôi 
- Rối loạn tim m ạch: 
+ Mạch nhanh, có t hể rối loạn nhịp (rung nhĩ, cơn nh ịp nhanh trên th ất, 
rung th ất... ) 
+ Huyết áp tăng, n ếu nặng có th ể tụt huy ết áp 
+ Thường kết hợp triệu chứng suy hô h ấp và suy tu ần hoàn. Th ực tế cần 
phân bi ệt suy hô h ấp là nguyên nhân hay h ậu quả 
- Rối loạn thần kinh và  ý thức: là tri ệu chứng nặng của SHH  
+Nhẹ: lo lắng, h ốt hoảng, th ất điều 
+Nặng: v ật vã ho ặc ngủ gà, lờ đờ, hôn mê, co gi ật Lưu ý:  
 + Các d ấu hiệu và tri ệu chứng lâm sàng có th ể chỉ xuất hiện khi đã suy hô 
hấp nặng, khi đã có các r ối loạn trao đ ổi khí n ặng nề và nguy hi ểm. Triệu chứng 
thở nhanh, m ạch nhanh, tăng huy ết áp có th ể chỉ xuất hiện khi SaO 2 đã gi ảm rất 
thấp < 70 -80%. Tím có th ể chỉ xuất hiện khi PaO 2 < 45 mmHg, đ ặc biệt khi 
bệnh nhân b ị thiếu máu  
 + Các d ấu hiệu và tri ệu chứng lâm sàng c ủa suy hô hấp là không đ ặc hiệu, có 
thể cũng xu ất hiện trong các trư ờng hợp không có suy hô h ấp 
2.2. Chẩn đoán m ức độ 
  Bảng 1: phân lo ại mức độ suy hô h ấp 
Yếu tố TRUNG 
BÌNH  NẶNG NGUY K ỊCH 
Glasgo
w 15 13 - 15  < 13, l ờ đờ, 
hôn mê  
Mạch 100 - 120 120 - 140 >140  
Nhịp 
thở 25 - 30 30 - 40 > 40 ho ặc < 
10 
Nói  Câu dài  Câu ng ắn - 
Tím  + ++ +++ 
Vã m ồ 
hôi + ++ +++ 
HA bình 
thường tăng giảm 
pH 7,35 - 
7,45 7,25 - 
7,35 < 7,25  
PaO 2 > 60 55 - 60 < 55 
PaCO 2 45 - 55 55 - 60 > 60 
 
2.3. Chẩn đoán nguyên nhân  
- Định hư ớng ch ẩn đoán:  
Hỏi tiền sử bệnh: hen ph ế quản, COPD, b ệnh lý tim m ạch... 
Đặc điểm lâm sàng:  
+ Co kéo cơ hô h ấp: tiếng rít, khó th ở thanh qu ản, ran rít, co th ắt phế 
quản 
+ Biên đ ộ thở yếu (như ợc cơ, m ệt cơ), m ạnh (toan chuy ển hóa)  
+ Cách xu ất hiện: 
  Đột ngột: dị vật, nang, tràn khí màng ph ổi. 
  Nhanh: OAP, hen ph ế quản, viêm ph ổi... 
  Từ từ: u ph ổi, tràn d ịch màng ph ổi, suy tim m ất bù...  + Đau ng ực: tràn khí màng ph ổi, nhồi máu ph ổi, viêm màng ph ổi, nhồi 
máu cơ tim  
+ Sốt (nhi ễm trùng): viêm ph ổi, viêm ph ế quản... 
Thăm khám : cần khám k ỹ về hô hấp,  tim m ạch, th ần kinh  
+ Thăm khám k ỹ phổi:  
Ran ẩm, ran rít.  
Hội chứng 3 gi ảm, đông đ ặc, tam ch ứng của tràn khí màng ph ổi 
+ Thăm khám tim m ạch: d ấu hiệu và tri ệu chứng suy tim, b ệnh tim...  
+ Thăm khám th ần kinh: ý th ức, triệu chứng liệt cơ hô h ấp... 
Các xét nghi ệm cơ b ản: 
+ XQ ph ổi: rất có ý nghĩa trong đ ịnh hư ớng ch ẩn đoán. Tuy nhiên c ần ổn 
định tình tr ạng bệnh nhân trư ớc khi đưa b ệnh nhân đi ch ụp phim . Nhiều bệnh lý 
có bi ểu hiện triệu ch ứng trên X quang ph ổi. Tuy nhiên có m ột số bệnh lý 
thường không có tri ệu chứng X quang rõ: nh ồi máu ph ổi, hen ph ế quản, tắc 
đường hô h ấp trên, ức chế hô hấp hoặc liệt hô h ấp 
+ Khí máu đ ộng m ạch: rất cần thiết cho ch ẩn đoán xác đ ịnh suy hô h ấp, 
phân lo ại suy hô h ấp và đánh giá m ức độ nặng của suy hô h ấp. Tuy nhiên không 
nên vì làm xét nghi ệm khí máu đ ộng m ạch mà làm ch ậm trễ các can thi ệp và x ử 
trí cấp cứu cho b ệnh nhân.  
+ Điện tim: giúp ch ẩn đoán m ột số bệnh tim và tìm các d ấu hiệu điện tim 
của bệnh lý ph ổi, các r ối loạn nhịp tim do suy hô h ấp... 
Các xét nghi ệm khác tùy theo trư ờng hợp cụ thể và tình tr ạng nặng của 
bệnh nhân có cho phép không:  
+ Siêu âm tim  
+ Chụp nhấp nháy ph ổi 
+ Chụp CT scan ph ổi 
+ Định lư ợng D – Dimer  
- Các nguyên nhân gây suy hô h ấp thư ờng gặp: 
+ Dị vật đường th ở: thường xu ất hiện đột ngột với triệu chứng xâm nh ập, 
khó th ở ra, th ở có tiếng rít, co rút và s ử dụng các cơ hô h ấp phụ. Trư ờng hợp tắc 
nghẽn nặng có th ể gây r ối loạn ý th ức, ng ừng th ở ngừng tim  
+ Tràn khí màng ph ổi: khó th ở đột ngột xuất hiện sau m ột gắng sức hoặc 
tự phát. N ếu có tr ụy mạch ph ải nghĩ đ ến tràn khí màng ph ổi áp l ực. Khám lâm 
sàng có th ể thấy một bên l ồng ng ực căng, gi ảm RRFN và gõ vang. C ần xử trí 
dần lưu khí c ấp cứu đặc biệt khi có tràn khí áp l ực 
+ Đợt cấp của bệnh ph ổi tắc ngh ẽn mạn tính (COPD) đ ặc trưn g bởi tăng 
tiết đờm nh ầy mủ, co th ắt phế quản. Đặc điểm suy hô h ấp hỗn hợp vừa có gi ảm 
ô xy máu và tăng CO2. Ch ẩn đoán d ựa trên ti ền sử bệnh nhân có ti ền sử bệnh 
phổi tắc ngh ẽn mạn tính, xu ất hiện khó th ở, ho kh ạc đờm tăng, đ ờm đục, có th ể 
có sốt. Khám có thể thấy có ran rít ran ngáy, khí ph ế thũng, s ử dụng các cơ hô 
hấp phụ 
+ Viêm ph ổi thư ờng có d ạng suy hô h ấp do gi ảm ô xy máu. Ch ẩn đoán 
dựa vào lâm sàng b ệnh nhân có s ốt, ho kh ạc đờm đục, khó th ở, đau ng ực kiểu màng ph ổi. Khám ph ổi thấy có h ội chứng đông đặc ở vùng ph ổi viêm, ran ẩm, 
ran n ổ, tiếng th ổi ống. Xét nghi ệm máu có th ể thấy bạch cầu tăng, CRP tăng, 
procalcitinin và máu l ắng tăng. X quang ph ổi khẳng định ch ẩn đoán, đánh giá 
được mức độ và giúp theo dõi s ự tiến triển  
+ Hội chứng suy hô h ấp tiến triển (ARDS) là bi ểu hiện của một đáp ứng 
viêm h ệ thống do t ổn thương t ại phổi hoặc các nguyên nhân ngoài ph ổi. Suy hô 
hấp thiếu ô xy máu n ặng là h ậu quả của tăng shunt do các ph ế nang b ị lấp đầy. 
Lâm sàng th ấy suy hô h ấp tiến triển nhanh, gi ảm ô xy hóa máu năng (P/F<200). 
X quang ph ổi thấy tổn thương lan t ỏa hai bên ph ổi 
+ Tổn thương não do ch ấn thương thư ờng bi ểu hiện bằng suy hô h ấp có 
tăng CO2 máu, có th ể biến chứng bởi suy hô h ấp có gi ảm ô xy máu khi có kèm 
sặc phổi hoặc bệnh ph ổi mạn 
+ Suy tim ứ huyết mất bù: ch ủ yếu là suy hô h ấp giảm ô xy máu, tuy 
nhiên có th ể gặp thể tăng CO2 trên các b ệnh nhân có b ệnh ph ổi mạn tính kèm 
theo 
3. Xử trí cấp cứu 
3.1. Nguyên t ắc xử trí cấp cứu: phát hi ện ngay tình tr ạng suy hô h ấp nguy 
kịch để can thi ệp thủ thuật theo trì nh tự của dây truy ền cấp cứu ABCD, dùng 
thuốc điều trị, theo dõi và ki ểm soát t ốt chức năng s ống của bệnh nhân  
- Khai thông đư ờng th ở: 
+ Cổ ưỡn (dẫn lưu tư th ế) 
+ Canuyn Grudel ho ặc Mayo ch ống tụt lưỡi 
+ Hút đ ờm dãi, hút r ửa phế quản 
+ Tư th ế nằm nghiêng a n toàn n ếu có nguy cơ s ặc 
+ Nghi ệm pháp Heimlich n ếu có d ị vật đường th ở 
+ Nội khí qu ản (ho ặc mở khí qu ản): bi ện pháp h ữu hiệu khai thông 
đường th ở 
- Chỉ định đặt nội khí qu ản: 
Tắc ngh ẽn đường hô h ấp trên  
Mất phản xạ bảo vệ đường th ở 
Khả năng kh ạc đờm giảm nhiều hoặc mất 
Thiếu oxy máu n ặng không đáp ứng th ở oxy 
Cần thông khí nhân t ạo xâm nh ập 
- Kiểm soát thông khí : Các trư ờng hợp cần hỗ trợ thông khí  
+ Giảm thông khí:  
Toan hô h ấp với pH < 7,25  
Có nguy cơ gi ảm thông khí ho ặc giảm thông khí s ẽ tiến triển nặng thêm:  
PaCO 2 tăng d ần 
Thở nhanh và có c ảm giác thi ếu khí  
Liệt hoặc mệt cơ hoành (th ở bụng ngh ịch thư ờng, dung tích s ống < 15 
ml/kg, áp l ực hít vào t ối đa ≥ - 30 cmH 2O) + Thiếu oxy máu n ặng kém đáp ứng với thở oxy  
3.2. Ô xy li ệu pháp  
- Nguyên t ắc: ph ải đảm bảo ô xy hóa máu SpO2 > 90%  
- Các d ụng cụ thở  
+ Canuyn mũi: là d ụng cụ có dòng ô xy th ấp 1 - 5 l/phút. N ồng độ ô xy 
dao đ ộng từ 24%-48%. Thích h ợp cho các b ệnh nhân có m ức độ suy hô h ấp 
trung bình, b ệnh nhân COPD ho ặc các nguyên nhân suy hô h ấp không có s hunt 
hoặc shunt trong ph ổi thấp 
+ Mặt nạ ô xy: là d ụng cụ tạo dòng th ấp 5-10 l/phút. N ồng độ ô xy dao 
động 35% - 60%. Thích h ợp cho các b ệnh nhân suy hô h ấp mức độ trung bình 
do tổn thương màng ph ế nang mao m ạch (ALI, ARDS). Th ận trọng khi dùng 
cho b ệnh nhâ n nôn do tăng nguy cơ hít ch ất nôn vào ph ổi 
+ Mặt nạ không th ở lại: là d ụng cụ tạo dòng ô xy th ấp 8-15 l/phút. N ồng 
độ ô xy cao dao đ ộng ở mức cao 60% -100% tùy thu ộc vào nhu c ầu dòng c ủa 
bệnh nhân và đ ộ kín c ủa mặt nạ. Thích h ợp cho b ệnh nhân suy hô h ấp mức độ 
nặng do t ổn thương màng ph ế nang mao m ạch (phù ph ổi, ALI, ARDS), b ệnh 
nhân viêm ph ổi nặng. Th ận trọng khi dùng cho b ệnh nhân nôn do tăng nguy cơ 
hít ch ất nôn vào ph ổi 
+ Mặt nạ venturi: là d ụng cụ tạo ô xy dòng cao, có th ể đáp ứng đư ợc nhu 
cầu dòng c ủa bệnh nhân. N ồng độ ô xy t ừ 24%- 50%. Ưu đi ểm là dùng cho 
những bệnh nhân c ần nồng độ ô xy chính xác (COPD)  
3.3. Thông khí nhân t ạo 
- Thông khí nhân t ạo không xâm nh ập áp l ực dương: h ỗ trợ thông khí cho 
bệnh nhân qua m ặt nạ (mũi, mũi mi ệng, toàn b ộ mặt…) 
  Chỉ định: Suy hô h ấp do phù ph ổi cấp huy ết động, đ ợt cấp của COPD 
và HFQ khi  
  + Suy hô h ấp nặng có d ấu hiệu mệt cơ: thở gắng sức + TS th ở > 
30/min  
  + Toan hô h ấp cấp ( pH < 7,25 -7,30)  
  + Tình tr ạng oxy hoá máu t ồi đi  (t ỷ lệ PaO2/FiO2 < 200)  
  Chống ch ỉ định:  
  + Ngừng th ở 
  + Tình tr ạng n ội khoa không ổn định (T ụt HA hay TMCB cơ tim 
không ki ểm soát đư ợc) 
  + Mất khả năng bào v ệ đường th ở 
  + Đờm dãi quá nhi ều 
  + Vật vã hay không h ợp tác  
  + Tình tr ạng bệnh nhân không cho phép đ ặt mặt nạ hay không b ảo đảm 
tình tr ạng kín khít c ủa mặt nạ 
- Thông khí nhân t ạo xâm nh ập:  khi TKNT không xâm nh ập có ch ống 
chỉ định ho ặc thất bại. 
3.4. Điều trị thuốc 
- Thuốc giãn ph ế quản (ch ất chủ vận 2; thu ốc kháng cholinergic): ch ỉ 
định với suy hô h ấp do có co th ắt phế quản (COPD, hen ph ế quản). Nên ưu tiên dùng đư ờng khí dung trư ớc, nếu không đáp ứng thì chuy ển sang truy ền tĩnh 
mạch 
- Corticoid: ch ỉ định cho các đ ợt cấp của hen ph ế quản, COPD  
- Kháng sinh: khi có d ấu hiệu của viêm (viêm ph ổi, đợt cấp COPD có 
bằng ch ứng nhi ễm khu ẩn) 
- Lợi tiểu: suy tim ứ huyết, phù ph ổi cấp huy ết động, quá t ải thể tích 
 
 
TÀI LI ỆU THAM KH ẢO 
 
1. Stone CK., Humphries RL: Respiratory Distress. Current diagnosis & 
treatment of emergency medicine. 6th edition 2008. Mc Graw Hill Lange, 2008: 
181-190 
2. Rosen’ Emergency medicine:  Concepts and Clinical Practice, 6th 
edition, Mosby 2006  
3. Kaynar  AM: Respiratory Failure . www.Emedicine.com . Cập nh ật: 
13/04/2010  
 
CÂU H ỎI LƯ ỢNG GIÁ  
Câu 1: Các lo ại suy hô h ấp là:  
A. Suy hô h ấp do gi ảm ô xy hóa máu  
B. Suy hô h ấp do tăng CO2  
C. Suy hô h ấp hỗn hợp 
D. Tất cả các lo ại trên  
Câu 2: Ch ẩn đoán nguyên nhân suy hô h ấp cấp dựa vào:  
A. Hỏi bệnh sử đầy đủ 
B. Thăm khám lâm sàng c ẩn thận 
C. Chụp X quang ph ổi 
D. Làm khí máu đ ộng m ạch 
E. Siêu âm tim  
F. Tất cả các ý trên  
Câu 3: X ử trí suy hô h ấp cấp cần: 
A. Đảm bảo tư th ế cho b ệnh nhân d ễ chịu nhất 
B. Đảm bảo đường th ở được thông thoáng  
C. Đảm bảo đủ thông khí  
D. Thở ô xy 
E. Điều trị nguyên nhân  
F. Tất cả các ý trên  
  
Bài 4  
XỬ TRÍ C ẤP CỨU SỐC 
 
MỤC TIÊU  
Sau khi h ọc xong h ọc viên có kh ả năng:  
1. Trình bày đư ợc chẩn đoán xác đ ịnh tình tr ạng sốc, phân lo ại sốc. 
2. Nêu đư ợc nguyên t ắc xử trí cấp cứu sốc. 
3. Trình bày đư ợc các bi ện pháp x ử trí cấp cứu sốc. 
 
NỘI DUNG  
1. Đại cương  
 Sốc là b ệnh cảnh hay g ặp chính c ủa khoa C ấp cứu và H ồi sức. Đặc điểm sinh 
lý bệnh chính c ủa sốc là gi ảm tư ới máu h ệ thống của toàn cơ th ể dẫn tới giảm 
cung c ấp oxy cho các mô cơ th ể. Từ đó dẫn tới sự mất cân b ằng gi ữa cung c ấp 
và trao đ ổi oxy, thi ếu oxy t ế bào gây t ăng chuy ển hóa y ếm khí, tăng gi ải phóng 
ra các ch ất trung gian, đ ộc tố phù t ế bào, ho ạt hóa các ph ản ứng viêm. Ban đ ầu 
tình tr ạng thi ếu oxy này có th ể hồi phục, nhưng r ất nhanh chóng s ẽ không h ồi 
phục hậu quả là ch ết tế bào, t ổn thương cơ quan đích, suy đa  tạng và t ử vong. 
Do v ậy quan tr ọng nh ất là ph ải phát hi ện sớm và đi ều trị kịp thời. 
2. Ch ẩn đoán  
2.1. Tri ệu chứng chung c ủa sốc 
- Phát hi ện sớm các d ấu hiệu về sốc: m ạch nhanh, t ụt HA, thi ểu niệu, 
thay đ ổi về ý thức, toan chuy ển hóa, da l ạnh, vã m ồ hôi, n ổi vân tím  
- Ý thức hốt hoảng do gi ảm lượng máu lên não, có th ể có cơn ng ất. Ở giai 
đoạn mu ộn có th ể lơ mơ, hôn mê  
-  < 40 mmHg so v ới HA n ền. Bi ểu hiện sớm hơn là t ụt HA tư th ế.  
- Thiểu niệu: gi ảm lưu lư ợng máu t ới thận gây gi ảm m ức lọc cầu thận, 
giai đo ạn sớm suy th ận chức năng giai đo ạn mu ộn gây ho ại tử ống th ận suy th ận 
thực tổn. 
- Thở nhanh sau do tăng chuy ển hóa ho ặc do toan chuy ển hóa  
- Da lạnh, ẩm do co m ạch, trong s ốc nhi ễm khu ẩn do giãn m ạch thư ờng 
có th ể có nổi vân tím  
- Bụng chư ớng dần do gi ảm tưới máu t ạng trong ổ bụng, thi ếu máu m ạc treo  
- Toan chuy ển hóa: do chuy ển hóa y ếm khí sinh lactic, và m ất khả năng 
thanh l ọc lactate c ủa gan, th ận, cơ…vv.  
Các tri ệu chứng nguyên nhân gây s ốc: 
- Sốc giảm thể tích: ỉa chảy, mất máu, ch ấn thương…  
- Sốc tim:  đau ng ực, gan to tĩnh m ạch cổ nổi, phù chi dư ới, rale ph ổi - Sốc nhi ễm khu ẩn: sốt, thể trạng nhi ễm trùng nhi ễm độc, viêm ph ổi, áp 
xe tay chi, nhi ễm trùng ti ết niệu, nhi ễm trùng trong ổ bụng 
- Sốc phản vệ như các bi ểu hiện dị ứng, ti ền sử dùng thu ốc..vv  
- Sốc tắc ngh ẽn: nh ồi máu ph ổi lớn, huy ết khối tĩnh m ạch sâu.  
2.2. Xét nghi ệm đánh giá tình tr ạng sốc 
- Khí máu: đánh giá tình tr ạng toan máu  
- Acid lactic đ ể đánh giá tình tr ạng tư ới máu mô  
- Xét nghi ệm đánh giá t ổn thương cơ quan đích: ch ức năng gan th ận, 
đông máu, hô h ấp..vv  
3. Phân lo ại các lo ại sốc: 
Sau khi đã nh ận ra tình tr ạng sốc, ph ải nhanh chóng phân lo ại và tìm 
nguyên nhân gây s ốc. 
Có 4 lo ại sốc chính  
- Sốc giảm th ể tích: gi ảm th ể tích tu ần hoàn ( ỉa ch ảy, m ất máu, 
bỏng, ..vv) làm gi ảm tiền gánh gi ảm cung lư ợng tim, t ụt HA. Cơ th ể sẽ phản 
ứng lại bằng tăng nh ịp tim, co m ạch máu đ ể duy trì HA tư ới máu cho nh ững 
tạng quan tr ọng như não, tim, ph ổi, thận. Tri ệu chứng lâm sàng thư ờng nh ịp tim 
nhanh, nh ợt nhạt, lạnh nh ợt đầu chi, vã m ồ hôi, m ất nước, tụt HA tư th ế. 
- Sốc tim: gi ảm cung lư ợng tim (NMCT, viêm cơ tim…vv) gây t ụt HA, 
cơ th ể cũng ph ản ứng lại bằng cách co m ạch, th ể tích tu ần hoàn trong trư ờng 
hợp này có th ể bình thư ờng ho ặc tăng. Tri ệu chứng thư ờng là suy tim như gan 
to tĩnh m ạch cổ nổi, phù ph ổi, đầu chi l ạnh nh ợt do co m ạch, đau ng ực, tim 
nghe có ti ếng th ổi. 
- Sốc giãn m ạch: giãn m ạch hệ thống do các y ếu tố trung gian ho ạt mạch, 
độc tố (vd s ốc nhi ễm khu ẩn, sốc phản vệ ..) cơ th ể cũng ph ản ứng lại bằng cách 
tăng nh ịp tim đ ể duy trì HA. Th ể tích tuần hoàn có th ể thiếu hoặc bình thư ờng. 
Triệu chứng thư ờng là tăng nh ịp tim, giãn m ạch đầu chi, n ổi vân tím, th ể trạng 
nhiễm trùng nhi ễm độc hoặc có y ếu tố dị ứng kèm tho  
- Sốc tắc ngh ẽn: nh ồi máu ph ổi, hoặc ép tim c ấp làm tim không th ể tống 
máu vào đ ại tuần hoàn. Tri ệu chứng ch ủ yếu ứ trệ tuần hoàn tim ph ải như khó 
thở, gan to tĩnh m ạch cổ nồi phù đ ồng th ời có gi ảm tưới máu đ ầu chi.  
- Sốc giai đo ạn mu ộn: Cho dù b ất kể do nguyên nhân gì n ếu để muộn đều 
dẫn tới tình tr ạng hôn mê, gi ảm cung lư ợng tim, giãn m ạch, th ể tích tu ần hoàn 
giảm ho ặc tăng, t ổn thương đa t ạng, toan chuy ển hóa và t ử vong.  
 
Bảng 1. Các đ ặc điểm sinh lý c ủa các lo ại sốc 
Phân lo ại 
sốc C
I S
V
R P
V
R S
v
O
2 R
A
P R
V
P P
A
P P
a
O
P 
Sốc tim 
(ví d ụ ↓ ↑ N ↓ ↑ ↑ ↑ ↑ NMCT 
hay ép 
tim) 
Sốc gi ảm 
thể tích 
(vd m ất 
máu)  ↓ ↑ N ↓ ↓ ↓ ↓ ↓ 
Sốc phân 
bố (vd s ốc 
phản v ệ, 
sốc nhi ễm 
khuẩn) N
-
↑ ↓ N N
-
↑ N
-
↓ N
-
↓ N
-
↓ N
-
↓ 
Sốc t ắc 
nghẽn (vd 
tắc đm 
phổi) ↓ N
-
↑ ↑ N
-
↓ ↑ ↑ ↑ N
-
↓ 
CI: ch ỉ số tim 
PVR: s ức cản mạch ph ổi 
RAP: áp l ực nhĩ ph ải 
PAOP: áp l ực đm ph ổi bít, N 
bình thư ờng SVR: sức cản mạch h ệ 
thống 
SvO 2: bão hòa oxy tm 
pha tr ộn 
PAP áp l ực đm ph ổi 
 
4. Cách ti ếp cận bệnh nhân s ốc 
- Khi nh ận ra b ệnh nhân s ốc, ph ải tiến hành h ồi sức ngay đ ồng th ời tìm 
hiểu hỏi tiền sử, khám lâm sàng tìm các tri ệu ch ứng g ợi ý, và làm các xét 
nghiệm kh ẳng định tình tr ạng và nguyên nhân gây s ốc. 
- Thăm dò huy ết động đóng vai trò r ất quan tr ọng trong ch ẩn đoán, theo 
dõi, và đi ều trị sốc đặc biệt trong nh ững trư ờng hợp sốc hỗn hợp và s ốc ở giai 
đoạn mu ộn, nhi ều yếu tố nhiễu ảnh hư ởng tới triệu chứng 
+ Đặt catheter tĩnh m ạch trung tâm: đánh giá ti ền gánh th ất phải, gián ti ếp 
đánh giá ti ền gánh th ất trái. 
+ Siêu âm tim: đánh giá ch ức năng tim, lo ại trừ nhanh ép tim c ấp, các 
máy siêu âm tim hi ện đại còn có th ể đánh giá đư ợc cung lư ợng tim.  
+ Đặt catheter S wan Ganz ho ặc PiCCO: đánh giá ti ền gánh th ất trái (áp 
lực mao m ạch ph ổi bít), đo đư ợc cung lư ợng tim, đo đư ợc sức cản mạch hệ 
thống (h ậu gánh). Riêng v ới PiCCO còn có th ể đo đư ợc lượng nư ớc trong ph ổi. 
5. Xử trí bệnh nhân s ốc 
- Ổn định ch ức năng s ống: Đ ảm bảo oxy hóa máu (th ở oxy, đ ặt NKQ, 
TKNT), ki ểm soát đư ờng th ở và đặt NKQ s ớm nếu bệnh nhân hôn mê trong tình 
trạng sốc, đặt đường truy ền tĩnh m ạch cỡ lớn hoặc catheter tĩnh m ạch trung tâm, 
truyền dịch theo áp l ực TMTT, l ấy máu làm xét nghi ệm: công th ức máu , chức 
năng gan th ận, cấy máu.  - Các bi ện pháp h ồi sức huy ết động 
+ Đặt ống thông TMTT duy trì CVP t ừ 11 tới 16 cmH20 truy ền dịch 
muối đẳng trương, cao phân t ử hay máu tùy tình tr ạng và lo ại sốc. 
+ Nếu HA không c ải thiện cân nh ắc sử dụng các thu ốc trợ tim và co m ạch 
Bảng 2. Cơ ch ế tác đ ộng của các thu ốc trợ tim và co m ạch 
Loại thu ốc Liều 
truyền C
O MA
P S
V
R 
I. Co m ạch 
Noradrenal
ine 0,05-0,5 
mcg/kg/ph
út -/+ ++ +
+
+ 
Dopamine  5-20 
mcg/kg/ph
út ++ + +
+ 
Adrenaline  0,05-2 
mcg/kg/ph
út ++ ++ +
+
+ 
Phenylephr
ine 2-10 
mcg/kg/ph
út 0 ++ +
+
+ 
Vasopressi
n 0,04 đơn 
vị/phút  0 +++ +
+
+ 
II. Co bóp cơ tim  
Dobutamin
e 2,5-10 
mcg/kg/ph
út ++
+ -/+ -
/
0 
CO: cung lư ợng tim  
MAP: HA trung bình  
SVR: s ức cản mạch hệ thống 
 
- Điều trị đặc hiệu cho t ừng lo ại sốc 
+ Sốc giảm th ể tích: bù đủ khối lượng tu ần hoàn, ngăn ch ặn ngu ồn 
mất, cầm máu…  
+ Sốc tim: tr ợ tim, bơm bóng ngư ợc động m ạch ch ủ, đặt thiết bị hỗ trợ 
thất..vv. Can thi ệp mạch vành, dùng thu ốc chống đông, ch ống ngưng t ập tiểu 
cầu nếu NMCT  
+ Sốc phản vệ: dùng s ớm adrenaline n ếu có r ối loạn huy ết động, corticoid, 
loại trừ dị nguyên kh ỏi cơ th ể + Sốc nhi ễm trùng: dùng kháng sinh s ớm, lo ại trừ ổ nhiễm khu ẩn, liệu 
pháp đi ều trị sớm theo m ục tiêu  
+ Sốc tắc ngh ẽn: ch ọc tháo d ịch màng ngoài tim..vv  
 
TÀI LI ỆU THAM KH ẢO 
Current Emergency Diag nosis  & Treatment, 5th Edition . The McGraw -
Hill Companies 2004.    
CÂU H ỎI LƯ ỢNG GIÁ  
Câu 1. Các bi ểu hiện lâm sàng c ủa bệnh nhân s ốc là (nhi ều ý đúng):  
A. Bệnh nhân lơ mơ, m ệt lả, hốt hoảng, có th ể hôn mê.  
B. Da xanh tái, l ạnh, ẩm mồ hôi, n ổi vân tím, đ ầu chi lạnh, tím  
C. Huyết áp t ụt, HA tâm thu dư ới 90mm Hg có th ể thấy tình tr ạng kẹt 
huyết áp, m ạch nhanh nh ỏ, thở nhanh.  
D. Tiểu nhi ều, khát nhi ều.  
Câu 2. Các đ ộng tác c ấp cứu ban đ ầu nào sau đây là đúng đ ối với bệnh 
nhân s ốc (nhi ều ý đúng):  
A. Cho b ệnh nh ân nằm đầu thấp nếu còn t ụt huy ết áp. 
B. Thở oxy qua xông mũi ho ặc mặt nạ.  
C. Đặt đường truy ền tĩnh m ạch ngo ại biên ch ắc chắn và truy ền dịch ngay  
D. Mắc máy theo dõi liên t ục nhịp tim, HA, SpO2, nh ịp thở  
Câu 3. Bệnh nhân v ẫn tiếp tục nặng lên, HA t ụt, tím. Các x ử trí cấp cứu 
tiếp theo là (nhi ều ý đúng) :  
A. Cho tăng oxy lên 10 lít/phút vì b ệnh nhân tím, th ở chậm, ng ừng th ở. 
B. Nâng cao đ ầu vì giư ờng bệnh nhân khó th ở. 
C. Bóp bóng qua m ặt nạ (mask) có oxy.  
D. Chuẩn bị và ph ụ giúp bác s ỹ đặt nội khí qu ản. 
E. Tạm ng ừng truy ền thu ốc nâng huy ết áp (noradrenalin, dopamine, 
dobutamin,..) vì nh ịp tim nhanh.  
Câu  4. Theo dõi sát b ệnh nhân s ốc nặng là (nhi ều ý đúng:  
A. Theo dõi m ạch, huy ết áp 3 gi ờ/lần . 
B. Theo dõi m ạch huy ết áp 20 phút/l ần. 
C. Theo dõi nh ịp thở, SpO2  3 gi ờ/lần. 
D. Theo dõi nh ịp thở, SpO2 20 phút/l ần 
E. Theo dõi nư ớc tiểu 6 gi ờ/lần . 
Câu 5.  Các bi ểu hiện nào sau đây c ủa bệnh nhân s ốc thể hiện bệnh nhân 
được chăm sóc t ốt (nhi ều ý đúng):  
A. Bệnh nhân t ỉnh táo, toàn tr ạng chung t ốt lên 
B. Huyết áp 7 5/55 mmHg, m ạch 135 l ần/phút  C. Thở 14 lần/phút không ph ải thở oxy qua xông mũi ho ặc mặt nạ.  
D. Nước tiểu 20 ml/gi ờ, tăng li ều truy ền thu ốc nâng huy ết áp   
Bài 5  
CẤP CỨU NGỪNG TUẦN HOÀN CƠ BẢN 
 
MỤC TIÊU  
Sau khi h ọc xong h ọc viên có kh ả năng:  
1. Nêu được các dấu hiệu chẩn đoán xác định ngừng tuần hoàn 
 
2. Mô tả các bước tiến hành hồi sinh tim phổi cơ bản 
 
3. Liệt kê các nguyên nhân gây ngừng tuần hoàn thường gặp và có thể điều 
trị nhanh chóng 
NỘI DUNG  
 
1. Đại cương 
Hồi sinh tim phổi cần được bắt đầu ngay lập tức sau khi phát hiện bệnh 
nhân ngừng tuần hoàn (NTH). Do khoảng thời gian từ khi gọi cấp cứu đến khi 
kíp cấp cứu có mặt để cấp cứu bệnh nhân thường trên 5 phút, nên khả năng cứu 
sống được bệnh nhân ngừng tim phụ thuộc chủ yếu vào khả năng và kỹ năng 
cấp cứu của kíp cấp cứu tại chỗ. 
Sốc điện cấp cứu phá rung thất sẽ có hiệu quả nhất nếu được thực hiện 
trong vòng 5 phút đầu sau ngừng tim. Hồi sinh tim phổi kết hợp với sốc điện 
sớm trong vòng 3 đến 5 phút đầu tiên sau khi ngừng tuần hoàn có thể đạt tỷ lệ 
cứu sống lên đến 50% -75%. 
2. Chẩn đoán: 
2.1. Chẩn đoán xác định: dựa vào 3 dấu hiệu: mất ý thức đột ngột, 
ngừng thở, mất mạch cảnh. 
2.2. C hẩn đoán phân biệt: 
Phân biệt vô tâm thu với rung thất sóng nhỏ: cần xem điện tim trên ít 
nhất 2 chuyển đạo 
Phân biệt phân ly điện cơ với sốc, trụy mạch: cần bắt mạch ở 2 vị trí trở lên 
Phân biệt mất mạch cảnh/mạch bẹn do tắc mạch: cần bắt mạch ở 2 vị trí 
trở lên 
2.3. C hẩn đoán nguyên nhân: 
Song song với cấp cứu hồi sinh tim phổi cơ bản, cần nhanh chóng tìm 
kiếm nguyên nhân gây ngừng tuần hoàn để giúp cấp cứu có hiệu quả và ngăn  
ngừa tái phát.Các nguyên nhân gây ngừng tuần hoàn thường gặp và có thể điều trị nhanh 
chóng: 
 
11 T 
trong tiếng Việt 6“H” 
trong tiếng 
Anh 11 T 
trong 
tiếng Việt 5 “T” 
trong tiếng 
Anh Thiếu thể tích tuần 
hoàn Hypovolemi
a Trúng độc 
cấp Toxins 
Thiếu oxy mô Hypoxia Tamponad
e tim Tamponade 
(cardiac) Toan hóa máu Hydrogen 
ion 
(acidosis) Tràn khí 
màng 
phổi áp lực Tension 
pneumothorax 
Tăng / Tụt kali 
máu Hyper-/ 
 
Hypokalemi
a Tắc mạch 
(mạch 
 
vành, 
mạch phổi) Thrombosis 
 
(coronary and 
pulmonary) 
Tụt hạ đường 
huyết Hypoglycem
ia Thương 
tích Trauma 
Thân nhiệt thấp Hypothermi
a   
Để cho dễ nhớ, gọi tắt là 5T 6H (tiếng Anh) hay 11 T (tiếng Việt) 
3. Xử trí cấp cứu: 
3.1. Nguyên tắc chung: 
- Xử trí cấp cứu ngừng tuần hoàn được khởi động ngay  từ khi phát hiện trường 
hợp nghi ngờ ngừng tuần hoàn. Người cấp cứu vừa tiến hành chẩn đoán, gọi người 
hỗ trợ vừa bắt đầu các biện pháp hồi sinh tim phổi cơ bản ngay. 
- Cần có 1 người là chỉ huy để phân công, tổ chức công tác cấp cứu đúng trình 
tự và đồng bộ. 
- Cần ghi chép các thông tin cần thiết và tiến trình cấp cứu 
- Thiết lập không gian cấp cứu đủ rộng và hạn chế tối đa các nhân viên hoặc 
những người không tham gia cấp cứu vào và làm  cản trở công tác cấp cứu 
3.2. Tiến hành ngay hồi sinh tim phổi cơ bản (ABC): đồng thời gọi hỗ trợ 
khi phát hiện bệnh nhân nghi ngờ bị ngừng tuần hoàn (không cử động, không 
phản ứng khi lay gọi… ) 
3.2.1. Kiểm soát đường thở: đặt ngửa đầu, cổ ưỡn, thủ thuật kéo hàm 
dưới/nâng cằm 
(jawthrust/chinlift)  
3.2.2. Kiểm soát và hỗ trợ tuần hoàn: ép tim ngoài lồng ngực 
Kiểm tra mạch cảnh (hoặc mạch bẹn) trong vòng 10 giây. Nếu không 
thấy mạch: tiến hành ép tim ngay. 
Ép tim ở 1/2 dưới xương ức, lún 1/3-1/2 ngực (4-5 cm với người lớn) đủ để sờ 
thấy mạch khi ép; tần số 100 lần/phút. Phương châm là “ép nhanh, ép mạnh, không 
gián đoạn và để ngực phồng lên hết sau mỗi lần ép” STT  N
ộ
i
 
d
u
n
g Đúng Sai 
1 Đầu tiên gọi to để mọi người đến hỗ trợ   
2 Làm nghiệm pháp Heimlich nếu nghi ngờ có 
dị vật đường thở   
3 Tiến hành ép tim sau khi thổi ngạt 2 cái liên 
tiếp   
4 Ngừng ép tim khi bóp bóng   
5 Khi có 2 người: ép tim 5 cái  thối ngạt 1 cái   
6 Ngừng 5 giây sau phút đầu để kiểm tra mạch 
cảnh mạch bẹn   
7 Ép tim trẻ em 100 - 120 nhịp/phút, người lớn 
80 - 100 nhịp /phút   
8 Sốc điện là phương pháp hiệu quả nhất   
   
3.3. Cấp cứu tại Khoa cấp cứu: 
3.3.1. Nhanh chóng ghi điện tim và theo dõi điện tim trên máy theo dõi. 
Phân loại 3 loại điện tim: rung thất/nhịp nhanh thất, vô tâm thu, phân ly điện cơ. 
3.3.2. Tiến hành sốc điện ngay nếu là rung thất 
Máy sốc điện 1 pha: số 360 J; Máy sốc điện 2 pha: 120-200 J, sốc điện 
không đồng bộ 
Tiến hành ngay 5 chu kỳ ép tim/thổi ngạt sau mỗi lần sốc điện 
4. Phòng bệnh 
Ngừng tuần hoàn thường xảy ra đột ngột, không dự đoán trước được. 
Tất cả các nhân viên cấp cứu, nhân viên y tế cứu hộ phải được tập luyện và 
chẩn bị sẵn sàng cấp cứu ngừng tuần hoàn. Các xe cấp cứu, các cơ sở cấp cứu 
cần có các phương tiện và thuốc cấp cứu cần thiết cho cấp cứu ngừng tuần hoàn. 
 
TÀI LI ỆU THAM KH ẢO 
1.  American He art Association. 2010 AHA Guideline for CPR  and EC 
2.  Circulation. 2010;112 (suppl 4):S1. (trang web: 
www .circulationaha.org)
 
CÂU H ỎI LƯ ỢNG GIÁ  
Câu 1. Liệt kê 3 dấu hiệu của ngừng tuần hoàn: 
A.  .................................................... 
B.................................................. 
 C................................................... 
Câu 2. Chẩn đoán ngừng tuần hoàn (chọn ý đúng): 
A.  Là chẩn đoán của bác sỹ 
B. Dựa vào lâm sàng 
C.  Dựa vào điện tim và điện tâm đồ 
D. Tất cả các ý trên đều đúng 
Câu 3. Những câu trả lời dưới đây là đúng hay sai 
 
 
 
 
 
 
 
 Câu 4: Cách dùng Adrenalin trong cấp cứu NTH (ch ọn 1 ý đúng) 
A.  1- 2 mg/ tiêm TM/ lần cách nhau 3 – 5 phút 
B. 2 mg/ tiêm TM/ lần cách nhau 3 – 5 phút c)  1 mg/ tiêm TM/ lần cách 
nhau 3 – 5 phút d) 1 mg/ tiêm TM/ lần cách nhau 2 phút 
C. Truyền Adrenalin TM liên tục 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
  
Bài 6  
CẤP CỨU NG ỪNG TU ẦN HOÀN NÂNG CAO  
  
MỤC TIÊU  
Sau khi h ọc xong h ọc viên có kh ả năng:  
1. Trình bày đư ợc phác đ ồ cấp cứu nâng cao ng ừng tu ần hoàn (NTH).  
2. Kể tên 11 nguyên nhân ch ủ yếu cần phát hi ện trong c ấp cứu NTH.  
3. Thực hiện đư ợc cấp cứu nâng cao NTH trên  mô hình, bao g ồm ph ối 
hợp các k ỹ thuật cấp cứu: đặt nội khí qu ản (NKQ), bóp bóng, s ốc điện và dùng 
thuốc theo tình hu ống lâm sàng và đi ện tâm đ ồ. 
             
              NỘI DUNG  
 
1. Đại cương   
Hồi sinh tim ph ổi cơ b ản (BLS) giúp duy trì dòng máu tuy n hỏ nhưng vô 
cùng quan tr ọng cho não và tim. Hồi sinh tim ph ổi nâng cao (ACLS) nh ằm 
kiểm soát tư ới máu não và tim t ốt hơn n ữa và nhanh chóng tái l ập lại tuần hoàn 
mà quan tr ọng nh ất là ti ến hành s ốc điện càng s ớm càng t ốt. Sốc điện cấp cứu 
phá rung th ất sẽ có hi ệu quả nhất nếu được thực hiện trong vòng 5 phút đ ầu sau 
ngừng tim. H ồi sinh tim ph ổi kết hợp với sốc điện sớm trong vòng 3 đ ến 5 phút 
đầu tiên sau khi ng ừng tu ần hoàn có th ể đạt tỷ lệ cứu sống lên đ ến 50% -75%.   
2. Ch ẩn đoán  
2.1. Chẩn đoán xác định : dựa vào 3 dấu hiệu: mất ý thức đột ngột, 
ngừng thở, mất mạch cảnh.  
2.2. Chẩn đoán phân biệt  
- Phân biệt vô tâm thu với rung thất sóng nhỏ: cần xem điện tâm đồ trên ít 
nhất 2 chuyển đạo.  
- Phân biệt phân ly điện cơ với sốc, trụy mạch: cần bắt mạch ở 2 vị t rí trở 
lên. 
- Phân biệt mất mạch cảnh/mạch bẹn do tắc mạch: cần bắt mạch ở 2 vị trí 
trở lên.  
2.3. Chẩn đoán nguyên nhân  
Song song với cấp cứu hồi sinh tim phổi, cần nhanh chóng tìm kiếm 
nguyên nhân gây NTH để giúp cấp cứu có hiệu quả và ngăn ngừa tái phát.  Lưu 
ý 11 nguyên nhân thường gặp và có thể điều trị nhanh chóng (xem quy trình cấp 
cứu cơ bản NTH).  
3. Xử trí 
3.1. Nguyên t ắc chung  
- Xử trí cấp cứu NTH được khởi động ngay từ khi phát hiện trường hợp 
nghi ngờ NTH.  
- Cần có 1 người là chỉ huy để phân công , tổ chức công tác cấp cứu đúng 
trình tự và đồng bộ.  - Cần ghi chép các thông tin cần thiết và tiến trình cấp cứu.  
- Thiết lập không gian cấp cứu đủ rộng và hạn chế tối đa các nhân viên 
hoặc những người không không tham gia cấp cứu vào và làm cản trở côn g tác 
cấp cứu.  
3.2. Tiến hành : tiến hành ngay  hồi sinh tim phổi cơ bản đồng thời gọi hỗ 
trợ khi phát hiện bệnh nhân nghi ngờ bị NTH (không cử động, không phản ứng 
khi lay gọi… ) [ xem quy tình cấp cứu cơ bản NTH ]. 
3.3. Ghi điện tâm đồ sớm  ngay khi có thể và  sốc điện ngay nếu có chỉ 
định 
          3.3.1 Nhanh chóng ghi  và theo dõi điện tâm đồ trên máy theo dõi . Nhận 
định 3 dạng điện tim: rung thất/nhịp nhanh thất, vô tâm thu, phân ly điện cơ  
          3.3.2. Rung thất hoặc nhịp nhanh thất vô mạch:  
  - Tiến hành ngay hồi sinh tim phổi cơ bản, đặt NKQ càng sớm càng tốt 
và đảm bảo thông khí có hiệu quả. Đặt ngay đường truyền tĩnh mạch lớn, theo 
dõi điện tâm đồ trên máy monitor nếu có. Nếu có loạn nhịp dùng ngay thuốc 
chống loạn nhịp thich hợp.  
  - Tiến hành sốc  điện ngay: sốc điện không đồng bộ. Sốc 360 J (Máy 
sốc điện 1 pha); 150 -200J (Máy sốc điện 2 pha); Tiến hành ngay 5 chu kỳ ép 
tim/thổi ngạt sau mỗi lần sốc điện.  
  - Các thuốc dùng trong xử trí rung thất: adrenaline, amiodarone, 
Magne sulfate, Lidocaine (x ylocaine), Vasopressine, Procainamid.  
 3.3.3. Xử trí vô tâm thu:  
            - Vô tâm thu là tình trạng hình ảnh sóng điện tâm đồ là đường thẳng 
nhưng phải kiếm tra ít nhất ở 2 chuyển đạo để không nhầm với rung thất sóng 
nhỏ.  
          - Tiến hành ngay hồ i snh tim phổi cơ bản, đặt NKQ càng sớm càng tốt và 
đảm bảo thông khí có hiệu quả. Đặt ngay đường truyền tĩnh mạch lớn, theo dõi 
điện tâm đồ trên máy monitor nếu có. Nếu có loạn nhịp dùng ngay thuốc chống 
loạn nhịp thích hợp.  
          - Đánh giá và tìm ki ếm tình trạng vẫn còn dòng tuần hoàn nhưng yếu (giả 
phân ly điện cơ ) bằng siêu âm tim nhanh.  
          - Nhanh chóng tim kiếm các nguyên nhân gây ra NTH. (Xem quy trình 
cấp cứu cơ bản NTH) và xử trí theo nguyên nhân.  
          - Nếu có thể đặt ngay tạo nh ịp ngoài qua da.  
          - Các thuốc dùng trong xử trí vô tâm thu: adrenalin, atropin.  
          3.2.4. Xử trí phân ly điện cơ:  
          - Phân ly điện cơ là tình trạng có hình ảnh sóng điện tâm đồ nhưng không 
bắt được mạch cảnh.  
          - Tiến hành n gay hồi sinh tim phổi cơ bản, đặt NKQ càng sớm càng tốt và 
đảm bảo thông khí có hiệu quả. Đặt ngay đường truyền tĩnh mạch lớn, theo dõi 
điện tâm đồ trên máy monitor nếu có. Nếu có loạn nhịp dùng ngay thuốc chống 
loạn nhịp thich hợp. Đánh giá và tim kiếm tì nh trạng vẫn còn dòng tuần hoàn 
nhưng yếu ( giả phân ly điện cơ ) bằng siêu âm tim nhanh.  
           - Nhanh chóng tim kiếm các nguyên nhân gây ra NTH. ( xem quy trình 
cấp cứu cơ bản NTH) và xử trí theo nguyên nhân.  
           - Các thuốc dùng trong xử trí  phân ly diện cơ: adrenalin, atropin ( nếu 
nhịp tim chậm), natri bicacbonat truyền tĩnh mạch nếu có toan hóa máu.  
4. Phòng b ệnh NTH thư ờng xảy ra đ ột ngột, không d ự đoán trư ớc được. Tất cả các nhân 
viên c ấp cứu, nhân viên y t ế cứu hộ phải được tập luy ện và chẩn bị sẵn sàng c ấp 
cứu NTH. Các xe c ấp cứu, các cơ s ở cấp cứu cần có các phương ti ện và thu ốc 
cấp cứu cần thiết cho c ấp cứu NTH.  
TÀI LI ỆU THAM KH ẢO 
1. American Heart Association. 20 10 AHA Guideline for CPR and ECC.  
2. Circulation. 20 10;112 (suppl 4):S 1. (trang web: www.circulationaha.org ) 
A- PHÁC Đ Ồ XỬ TRÍ C ẤP CỨU NÂNG CAO  
ĐỐI VỚI RUNG  THẤT VÀ NH ỊP NHANH TH ẤT VÔ M ẠCH 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 BẮT ĐẦU CÁC BƯ ỚC ABCD C ỦA HỒI SINH TIM PH ỔI CƠ B ẢN (BLS + Sốc điện kh ử rung)  
 Đánh giá  đáp ứng của nạn nhân  
 Khởi động hệ thống cấp cứu ngừng tim  
 Gọi máy kh ử rung  
A: Đư ờng th ở (Airway):  Áp d ụng các bi ện pháp khai thông đư ờng th ở 
B: Hô h ấp (Breathing):  Tiến hành 2 nh ịp thổi ngạt, mỗi nhịp thổi ngạt trong vòng 1 giây   
C: Tu ần hoàn  (Circulation ): Ép tim ngoài l ồng ng ực: Tiến hành 30 l ần ép tim/ 2 l ần thông khí t ới khi chu ẩn bị song máy kh ử rung 
D: Kh ử rung  (Defibrillation ): Đánh giá và ti ến hành làm s ốc điện nếu có rung th ất và nh ịp nhanh th ất vô m ạch, đánh 
1 lần  sốc điện (360 J v ới máy s ốc điện monophasic hay 150 -200J v ới máy s ốc điện biphasic)  
Adrenalin: 1mg tiêm tĩnh m ạch nhanh (ho ặc 2-2,5 mg bơm qua ống NKQ), 
tiêm nh ắc lại 3-5 phút/l ần  
Hoặc Vasopressin : 40U tiêm tĩnh m ạch x 1 li ều và dùn g 1 lần duy nh ất (a): Cấp độ bằng chứng :  
Cấp I  - Điều trị hay can thiệp  luôn được 
chấp nhận, với tính an toàn được chứng minh 
và chắc chắn có lợi;  
Cấp IIa  - Chấp nhận được, an toàn, hiệu quả; 
điều trị chuẩn hoặc can thiệp được lựa chọn;  
Cấp IIb  - Chấp nhận được, an toàn, hiệu  
quả; được coi là điều trị chuẩn, n hưng chỉ là 
lựa chọn được xem  xét hay can thiệp thay 
thế;   
Cấp III  - Không hiệu quả và đôi khi  có hại. 
 TIẾN HÀNH CÁC BƯ ỚC ABCD C ỦA ACLS   
(Thực hiện các đánh giá và đi ều trị nâng cao hơn)  
A: Đường th ở (Airway):  Đặt cannun đư ờng th ở (vd NK Q) càng s ớm càng t ốt 
B: Hô h ấp (Breathing):   
 Đảm bảo cannun đư ờng th ở đặt đúng v ị trí bằng khám lâm sàng và test kh ẳng 
định 
 Cố định tốt cannun, nên s ử dụng các thi ết bị cố định can nun đư ờng th ở đặc chủng 
 Đảm bảo tình tr ạng oxy hóa máu và thông khí có hi ệu qủa  
C: Tuần hoàn  (Circulation) : 
 Đặt đường truy ền tĩnh m ạch 
 Phát hi ện nhịp tim và theo dõi trên màn monitor  
 Dùng thu ốc chống lo ạn nhịp thích h ợp để điều trị tình tr ạng lo ạn nhịp (nếu có)  
D: Chẩn đoán phân bi ệt (Diferential diagnosis):  Tìm ki ếm và x ử trí nguyên 
nhân gây ng ừng tim có th ể điều trị được  (12 T)  
 
Thử đánh l ại sốc điện khử rung 
1 x 360 J (hay 200 - 250J khi dùng máy biphasic) trong vòng 30 -60 giây  Rung th ất & nh ịp nhanh th ất vẫn tồn tại hay tái phát ?  
Khử rung x 1 l ần đánh s ốc điện  
(360J đ ối với monophasic, 150 -200 J đ ối với biphasic  
Tiến hành ngay tr ở lại BLS  x 2 phút             
(30 lần ép tim/ 2 l ần thôn g khí)  Có nh ịp trên điện tâm đ ồ ? 
Vô tâm thu  Phục hồi lại tuần 
hoàn t ự nhiên ?  
Còn ho ạt 
động đi ện 
song vô 
mạch 
  Đánh giá các d ấu 
hiệu sinh t ồn  
 Hỗ trợ đường th ở 
 Hỗ trợ hô hấp 
 Dùng thu ốc thích 
hợp để xử trí HA, 
tần số tim và lo ạn 
nhịp  
Xem xét  dùng thu ốc chống lo ạn nhịp:                                               (a)                                                                                           
 Amiodaron  (IIb):  300 mg tiêm tĩnh m ạch nhanh (có th ể tiêm nh ắc lại với liều 150 mg)  PHÁC ĐỒ XỬ TRÍ CẤP CỨU NÂNG CA O ĐỐI VỚI  
TÌNH TRẠNG CÓ HOẠT ĐỘNG ĐIỆN SONG KHÔNG CÓ MẠCH 
 
 
 
 
 
 
 
 
 
 
 
 
 
Ph¸t hiÖn (vµ xö trÝ ) c¸c nguyªn nh©n th­êng gÆp  g©y t×nh tr¹ng cßn 
ho¹t ®éng ®iÖn song v« m¹ch (11T)                              
 
Thiếu thể tích tuần hoàn 
(Truyền dịch ) Tắc mạch  vành hay NMCT cấp rộng  
Thiếu ô xy mô ( thở O 2, 
thở máy)  Tràn khí màng phổi áp lực ( Chọc giảm 
áp màng phổi ) 
Toan  hoá máu ( Truyền 
Bicarbonat )    (b) Tràn dịch màng ngoài tim gây ép tim cấp 
(Chọc dịch màng tim ) 
Tăng kali máu ( CaCl 2, vv) 
và Tụt giảm kali m áu 
(Truyền kali ) Trúng độc do quá liều thuốc hoặc  do 
uống nhầm các thuốc như  tricyclic, 
digitalis, chẹn bêta giao cảm...  
Tụt hạ glucose máu    Tắc mạch phổi lớn ( Phẫu thuật, thuốc 
tiêu huyết khối  
Thân nhiệt thấp   Thương tích   
 
 
 
 Tình tr ạng có ho ạt động đi ện song vô m ạch (Pulseless Electrical Activity [PEA])  
(Có nh ịp tim trên màn monitor song không b ắt được mạch) 
PEA bao g ồm các lo ại nhịp:  
Phân ly đi ện-cơ (Electromechanical dissociation (EMD)  
Giả phân ly đi ện cơ (Pseudo -EMD)  
Các nh ịp tự thất 
Các nh ịp thoát th ất 
Nhịp chậm vô tâm thu (Bradyasystolic rhythms)  
Các nh ịp tự thất xẩy ra sau s ốc điện khử rung tim (Post defibrillation idioventricular rhythms)  
 
Bắt đầu các bư ớc ABCD c ủa Hồi sinh tim ph ổi cơ b ản (BLS + Sốc điện kh ử rung)  
1. Đánh giá  đáp ứng của nạn nhân  
2. Khởi động hệ thống cấp cứu ngừng tim  
3. Gọi máy kh ử rung  
A: Đư ờng th ở (Airway):  áp dụng các bi ện pháp khai t hông đư ờng th ở 
B: Hô h ấp (Breathing):  Tiến hành 2 nh ịp thổi ngạt, mỗi nhịp thổi ngạt trong vòng 1 giây   
C: Tu ần hoàn  (Circulation ): ép tim ngoài l ồng ng ực: Tiến hành 30 l ần ép tim/ 2 l ần thông khí (hay th ổi ngạt)  
D: Kh ử rung (Defibrillation ): Đánh giá và  đánh s ốc điện nếu có rung th ất và nh ịp nhanh th ất vô m ạch  
Tiến hành các bư ớc ABCD c ủa ACLS  (Thực hiện các đánh giá và đi ều trị nâng cao hơn)  
A: Đường th ở (Airway): Đ ặt cannun đư ờng th ở (vd NKQ) càng s ớm càng t ốt 
B: Hô h ấp (Breathing):  
 Đảm bảo cannun đư ờng th ở đặt đúng v ị trí bằng khám lâm sàng và test kh ẳng định 
 Cố định tốt cannun, nên s ử dụng các thi ết bị cố định canun đư ờng th ở đặc chủng 
 Đảm bảo tình tr ạng oxy hóa máu và thông khí có hi ệu qủa  
C: Tuần hoàn  (Circulation) :  
 Đặt đường truy ền tĩnh m ạch 
 Phát hiện nhịp tim và theo dõi trên màn monitor  
 Dùng thu ốc chống lo ạn nhịp thích h ợp để điều trị tình tr ạng lo ạn nhịp (nếu có)  
 Đánh giá và tìm ki ếm tình tr ạng vẫn còn dòng tu ần hoàn dù y ếu  (Tình tr ạng gi ả phân ly đi ện cơ)          (a) 
D: Chẩn đoán phân bi ệt (Diferential diagnosis):  Tìm ki ếm và x ử trí nguyên nhân gây ng ừng tim có th ể điều trị được   
 
Atropin  1 mg tiêm tĩnh m ạch (n ếu tần số  tim chậm)                                                                
Tiêm nh ắc lại 3-5 phút/l ần nếu cần, đến khi đ ạt tổng liều 0,04 mg/kg  
 Adrenalin:  1 mg tiêm tĩnh m ạch nhanh, dùng nh ắc lại 3-5 phút/l ần.     
 PHÁC ĐỒ XỬ TRÍ CẤP CỨU NÂNG CAO ĐỐI VỚI VÔ TÂM THU  
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
a): Đánh giá các chỉ số lâm sàng chỉ dẫn không còn chỉ định cấp cứu ( vd 
dấu hiệu chứng tỏ BN đã tử vong).  
b) Đặt máy t ạo nh ịp không đư ợc khuy ến cáo ch ỉ định thư ờng quy đ ể 
điều trị vô tâm thu ngo ại trừ trong các trư ờng hợp được chọn lọc như vô tâm thu 
xẩy ra trong quá trình làm th ủ thuật 
c): Adrenalin  1mg tiêm tĩnh mạch 3 -5 phút/lần. Nếu không có hiệu 
quả, có thể dùng liều cao hơn (tới 0,2 mg/kg) nhưng không được Hội tim 
mạch  Mỹ khuyến cáo.  V« t©m thu  
BẮT ĐẦU CÁC BƯ ỚC ABCD C ỦA HỒI SINH TIM PH ỔI CƠ B ẢN (BLS + Sốc điện kh ử rung)  
 Đánh giá  đáp ứng của nạn nhân  
 Khởi động hệ thống cấp cứu ngừng tim  
 Gọi máy kh ử rung  
A: Đư ờng th ở (Airway):  áp dụng các bi ện pháp khai thông đư ờng th ở 
B: Hô h ấp (Breathing):  Tiến hành 2 nh ịp thổi ngạt, mỗi nhịp thổi ngạt trong vòng 1 giây   
C: Tu ần hoàn  (Circulation ): ép tim ngoài l ồng ng ực: Tiến hành 30 l ần ép tim/ 2 l ần thông khí  
                                                Khẳng định lại chắc chắn bệnh nhân có tình tr ạng vô tâm thu                                          
D: Kh ử rung  (Defibrillation ): Đánh giá và ti ến hành s ốc điện nếu có rung th ất và nh ịp nhanh th ất vô m ạch   
Tìm ki ếm nhanh  ngay t ại hiện trư ờng bằng ch ứng cho quy ết định không c ần tiến hành c ấp cứu        (a) 
 
TIẾN HÀNH CÁC BƯ ỚC ABCD C ỦA ACLS  (Thực hiện các đánh giá và đi ều trị nâng cao hơn)  
A: Đường th ở (Airway): Đ ặt cannun đư ờng th ở (vd NKQ) càng sớm càng t ốt 
B: Hô h ấp (Breathing):  
 Đảm bảo cannun đư ờng th ở đặt đúng v ị trí bằng khám lâm sàng và test kh ẳng định 
 Cố định tốt cannun, nên s ử dụng các thi ết bị cố định canun đư ờng th ở đặc chủng 
 Đảm bảo tình tr ạng oxy hóa máu và thông khí có hi ệu qủa  
C: Tuần hoàn  (Circulation) :  
 Đặt đường truy ền tĩnh m ạch 
 Phát hi ện nhịp tim và theo dõi trên màn monitor  
 Dùng thu ốc chống lo ạn nhịp thích h ợp để điều trị tình tr ạng lo ạn nhịp (nếu có)  
 Đánh giá và tìm ki ếm tình tr ạng vẫn còn dòng tu ần hoàn dù y ếu  (Tình tr ạng gi ả phân ly đi ện cơ)  
D: Chẩn đoán phân bi ệt (Diferential diagnosis): Tìm ki ếm và x ử trí nguyên nhân gây ng ừng tim có th ể điều trị được   
 
Tạo nhịp qua da  (nếu có th ể thực hiện được, cần tiến hành ngay)      (b) 
 
Adrenalin 1mg tiêm nhanh tĩnh m ạch (2-2,5mg  bơm qua ống NKQ)  
                                    Tiêm nh ắc lại 3-5 phút /l ần.                                    (c) 
 
Atropin  1 mg tiêm tĩnh m ạch (ho ặc 2-2,5 mg bơm qua ống NKQ)  
Tiêm nh ắc lại 3-5 phút /l ần đến khi đ ạt tới tổng  li ều 0,04 mg/kg  
 
Tình trạng vô tâm thu v ẫn tiếp diễn 
 
Cân nh ắc ngừng cấp cứu khi:  
 Tiến hành c ấp cứu đúng nhưng không k ết quả 
 Không ph ải là BN b ị  ngạt nước hoặc hạ thân nhi ệt  
 Không tìm th ấy nguyên nhân có th ể phục hồi hoặc không ph ải là BN ngộ độc  cấp  
 Đủ tiêu chu ẩn ngừng cấp cứu theo phác đ ồ cấp cứu tại cơ s ở 
  
CÂU H ỎI LƯ ỢNG GIÁ  
Câu 1. Một bệnh nhân b ị ngừng tu ần hoàn, đang đư ợc ép tim và th ổi ngạt. 
Sau khi ghi đi ện tim, hình ảnh đi ện tim là rung th ất. Hãy l ựa chọn 1 thái đ ộ xử 
trí đúng:  
A. Xylocain 1mg/kg tiêm tĩnh m ạch 
B. Đấm vào vùng trư ớc tim 
C. Sốc điện đồng bộ 200 J  
D. Sốc điện không đ ồng bộ 200 J  
Câu 2. Các đi ều nào sau đây là đúng trong rung th ất: 
A. Trên monitor, hình ảnh rung th ất có th ể giống với hình ảnh đi ện tim b ị 
nhiễu  
B. Vẫn có th ể sờ thấy mạch trong rung th ất 
C. Tim không còn t ống máu trong rung th ất 
D. Có th ể điều trị hiệu quả rung th ất bằng sốc điện 
Câu 3. Rối loạn nhịp tim nào hay g ặp nhất trong phút đ ầu tiên c ủa ngừng 
tuần hoàn ở người lớn: 
A. Nhịp hấp hối 
B. Vô tâm thu  
C. Blốc nhĩ th ất cấp 3 
D. Rung th ất 
Câu 4. Cần tiến hàn h cấp cứu ngừng tu ần hoàn khi th ấy dấu hiệu nào sau 
đây (ch ỉ ra một dấu hiệu đúng):  
A. Tím tái ho ặc nhợt nhạt 
B. Mất mạch quay  
C. Mất mạch cảnh  
D. Nghe không th ấy rõ ti ếng tim  
                                                         Bài 7  
CHẨN ĐOÁN VÀ XỬ TRÍ CẤP CỨU NHỒI MÁU CƠ TIM CẤP 
                                        CÓ ST CHÊNH LÊN 
 
 
MỤC TIÊU  
Sau khi h ọc xong h ọc viên có kh ả năng:  
 
1. Trình bày được các triệu chứng và chẩn đoán nhồi máu cơ tim cấp 
có ST chênh lên. 
2. Trình bày được các biện pháp xử trí cấp cứu nhồi máu cơ tim cấp. 
 
NỘI DUNG  
1. Đại cương 
Nhồi máu cơ tim (NMCT) cấp là hậu quả của tắc đột ngột động mạch 
vành. Đây là một cấp cứu tim mạch có tỷ lệ gặp ngày  cảng tăng ở nước ta. 
NMCT có  thể có những biến chứng nặng như suy tim, rối loạn nhịp tim, rối 
loạn dẫn truyền, hoặc các biến chứng cơ học, đe dọa tính mạng bệnh nhân. 
NMCT  có ST chênh lên là trường hợp bệnh nhân có biểu hiện hội chứng 
vành cấp và có ST chênh lên trên điện tim. Các trường hợp có biểu hiện hội 
chứng vành cấp nhưng điện tim không có ST chênh lên có thể là cơn đau thắt 
ngực không ổn định hoặc NMCT  không có ST chênh lên. 
Mặc dù có nhiều tiến bộ trong chẩn đoán và điều trị, nhưng tỷ lệ tử vong 
của NMCT  vẫn còn cao. Hiện nay, một trong những vấn đề được quan tâm 
nhất trong điều trị NMCT  là thực hiện thật sớm việc điều trị tái tưới máu, bằng 
can thiệp hoặc bằng thuốc. Do đó việc chẩn đoán và điều trị NMCT  phải 
được tiến hành hết sức khẩn trương. 
2. Chẩn đoán 
2.1. C hẩn đoán xác định 
- Triệu chứng lâm sàng điển hình là cơn đau thắt ngực: đau sau xương ức, 
lan lên vai và ra tay trái, đau kéo dài và không hết khi ngậm nitroglycerin. Cơn 
đau kéo dài > 20 phút. Tuy nhiên cũng có những trường hợp đau ngực không 
điển hình (đau vùng thượng vị, đau lan lên hàm dưới, hoặc chỉ có cảm giác 
nặng ngực), do đó cần làm điện tim cho tất cả những người nghi ngờ có NMCT.- Mới xuất hiện các thay đổi của ST hoặc sóng T hoặc mới xuất 
hiện bloc nhánh trái: 
ST chênh lên (khi không có bloc nhánh trái hoặc dày thất trái) ≥ 0,1 mV 
ở 2 chuyển đạo liên tiếp (trừ chuyển đạo V2,V3); ở V2, V3: ≥ 0,2 mV ở người 
40 tuổi trở lên, ≥ 0,25 mV ở người dưới 40 tuổi, ≥ 0,15 mV ở nữ giới. 
- Xuất hiện sóng Q bệnh lý trên điện tim. 
- Siêu âm tim: mới xuất hiện bất thường vận động vùng. 
- Tăng các dấu ấn sinh học của hoại tử cơ tim: troponin, CK/CK-MB. 
Chẩn đoán xác định nhồi máu cơ tim dựa vào: triệu chứng lâm sàng đặc 
trưng của thiếu máu cục bộ cơ tim (cơn  đau ngực) kết hợp với ST chênh lên và 
tăng dấu ấn sinh học của hoại tử cơ tim. 
2.2. C hẩn đoán phân biệt 
- Viêm cơ tim cấp 
- Tràn dịch màng ngoài tim cấp 
- Bóc tách động mạch chủ 
- Tắc động mạch phổi 
- Các bệnh lý ngoài tim: tràn khí màng phổi, viêm túi mật cấp, cơn đau 
dạ dày cấp, trào ngược dạ dày thực quản. 
Chẩn đoán phân biệt chủ yếu dựa vào điện tim và siêu âm, trong bóc 
tách động mạch chủ, tắc động mạch phổi cần chụp MS CT để chẩn đoán. 
2.3. C hẩn đoán mức độ nặng 
Đánh giá mức độ nặng của NMCT  cấp dựa vào: 
2.3.1. Sự xuất hiện các biến chứng cấp tình 
- Suy tim: đánh giá bằng độ Killip 
Killip I: không có biểu hiện suy tim ứ huyết 
Killip II: có ran ẩm ở 1/3 dưới 2 phổi 
Killip III: có phù phổi cấp 
Killip IV: có sốc tim 
- Rối loạn nhịp tim. 
- Rối loạn dẫn truyền 
- Biến chứng cơ học 
2.3.2. Các bệnh lý kèm theo: 
- Đái tháo đường 
- Suy thận  
 
 
3. Xử trí cấp cứu 
3.1. Các thuốc 
- Ức chế ngưng tập tiểu cầu: 
+ Aspirin 160 – 325 mg. Sau đó duy trì 81 – 325 mg/ngày. 
+ Clopidogrel: bệnh nhân 75 tuổi trở xuống dùng liều đầu 300 mg, sau 
đó dùng 75 mg/ngày; bệnh nhân trên 75 tuổi dùng 75 mg liều đầu, sau đó 75 
mg/ngày. 
- Nitroglycerin tĩnh mạch, chỉ định khi huyết áp bình thường, bắt đầu 
với liều 10 µg/phút, sau đó điều chỉnh theo triệu chứng. Có thể thay bằng 
nitroglycerin ngậm dưới lưỡi nếu không có loại truyền tĩnh mạch. 
- Morphin sulphat 2 – 4 mg tiêm tĩnh mạch nếu tình trạng đau ngực 
không đáp ứng với nitrat. Có thể nhắc lại sau 5 – 15 phút nếu chưa hết đau ngực. 
- Thở oxy 2 – 4 lít/phút. 
- Điều trị chống đông: 
+ Heparin không phân đoạn liều đầu 60 đơn vị/kg tiêm tĩnh mạch (tối đa 
4000 đơn vị), sau đó dùng liều 12 đơn vị/kg/giờ (tối đa 1000 đơn vị/giờ), điều 
chỉnh liều để duy trì aPTT bệnh/chứng = 1,5 – 2,0. 
+ Enoxaparin: bệnh nhân dưới 75 tuổi dùng liều đầu 30 mg tiêm tĩnh 
mạch, sau đó 15 phút tiêm dưới da 1 mg/kg mỗi 12 giờ; bệnh nhân 75 tuổi trở 
lên tiêm dưới da 0,75 mg/kg mỗi 12 giờ (không bolus). 
- Thuốc ức chế bêta giao cảm: 
+ Chỉ định dùng đường uống cho tất cả các bệnh nhân trừ trường hợp có 
chống chỉ định với thuốc ức chế bêta. 
+ Me toprolol tartrat 25-50 mg uống mỗi 6 – 12 giờ. 
- Thuốc ức chế men chuyển angiotensin: 
+ Có thể dùng cho tất cả các bệnh nhân không có chống chỉ định. 
 + Captopril 6,25 – 12,5 mg uống 3 lần/ngày, sau đó có thể tăng đến 25 - 
50 mg 3 lần/ngày tùy theo đáp ứng của bệnh nhân. 
- Statin: 
+ Dùng cho tất cả các bệnh nhân không có chống chỉ định. 
+ Atorvastatin uống liều cao 80 mg/ngày. 
3.2. Điều trị tái tưới máu 
Việc điều trị tái tưới máu cần phải được tiến hành rất sớm. 
3.2.1. Can thiệp mạch vành:  
- Cần tiến hành trong vòng 90 phút sau khi xuất hiện đau ngực, nếu cơ sở 
điều trị có khả năng chụp mạch vành và can thiệp tái tưới máu. 
- Nếu cơ sở điều trị không có khả năng can thiệp mạch vành:  
+ Có thể chuyển bệnh nhân đến cơ sở khác để việc can thiệp mạch vành 
thực hiện được trong vòng 120 phút sau khi bắt đầu đau ngực: khẩn trương 
chuyển ngay để can thiệp kịp thời. 
+ Nếu không có khả năng chuyển đi để thực hiện can thiệp trong vòng 
120 phút kể từ khi đau ngực: chỉ định điều trị tái tưới máu bằng thuốc tiêu sợi 
huyết. 
3.2.2. Dùng thuốc tiêu sợi huyết: 
- Thuốc tiêu sợi huyết được chỉ định trong điều trị NMCT  cấp trong 
trường hợp bệnh nhân đến sớm nhưng không thể tiến hành được can thiệp mạch 
vành trong vòng 120 phút kể từ khi đau ngực. 
- Các c hống chỉ định tuyệt đối: 
+ Tiền sử chảy máu não 
+ Tiền sử đột quỵ loại thiếu máu cục bộ trong vòng 3 tháng gần đây 
+ Có khối u ác tính nội sọ 
+ Đang bị chảy máu hoặc có cơ địa chảy máu 
+ Bóc tách động mạch chủ 
+ Tiền sử chấn thương hàm mặt hoặc sọ não kín trong vòng 3 tháng gần 
đây 
- Các c hống chỉ định tương đối: 
+ Huyết áp > 190/110 
+ Tiền sử đột quỵ loại thiếu máu cục bộ > 3 tháng 
+ INR > 2 
+ Tiền sử chảy máu nội tạng trong vòng 2 – 4 tuần trở lại 
+ Sau  phẫu thuật lớn 
+ Có thai 
+ Có đường chọc vào các mạch không thể ép cầm máu 
- Ngoài các tình huống được nêu ở mục 3.2.1., can thiệp mạch vành 
được ưu tiên áp dụng hơn điều trị tiêu fibrin khi: 
+ Suy  tim ứ huyết nặng 
+ Có  sốc tim 
+ Loạn nhịp thất không ổn định + Bệnh nhân đến viện muộn (sau 3 giờ kể từ khi bắt đầu đau ngực) 
+ Chẩn đoán NMCT  không thật chắc chắn 
- Một số thuốc tiêu sợi huyết: 
Tenecteplase (TNK -tPA): tiêm tĩnh mạch 1 liều tùy theo cân nặng bệnh 
nhân (30 mg nếu <60 kg; 35 mg nếu 60–69 kg; 40 mg nếu 70–79 kg; 45 mg nếu 
80–89 kg; và 50 mg nếu ≥90 kg). 
Alteplase (tPA): bolus 15 mg, truyền tĩnh mạch 0.75 mg/kg trong 30 
phút (tối đa 50 mg), sau đó 0.5 mg/kg (tối đa 35 mg) trong 60 phút tiếp theo; 
tổng liều không quá 100 mg. 
Streptokinase: 1.5 triệu đơn vị truyền tĩnh mạch trong 30 – 60 phút. 
- Điều trị tiêu sợi huyết được coi là thành công khi: 
+ Hết hoàn toàn đau ngực 
+ ST  giảm chênh > 50% 
- Nên chuyển bệnh nhân đến cơ sở có khả năng can thiệp mạch vành 
sau khi điều trị tiêu sợi huyết nếu điều kiện cho phép. 
3.3. Điều trị biến chứng  
Cần theo dõi chặt bệnh nhân để phát hiện và điều trị kịp thời các biến chứng: 
- Sốc tim 
- Suy tim ứ huyết 
- Rối loạn nhịp tim, rối loạn dẫn truyền 
- Biến chứng cơ học 
  
 
TÀI LI ỆU THAM KH ẢO 
 
1. ACCF/A HA   ( 2013): 2013 ACCF/ AHA Guideline for the 
Management of ST- Elevation Myocardial Infarction: A Report of the 
American College of Cardiology Foundation/American Heart Association Task 
Force on Practice Guidelines. Circulation. 2013;127:e362-e425. 
2. Depta J.P., Kates A.M. (2012): Acute Myocardial Infarction. In: The 
Washington Ma nual of Critical Care (Editors: Kollef M,  Isakow W.). Bản dịch 
tiếng Việt: Hồi sức cấp cứu – Tiếp cận theo phác đồ, Nxb Khoa học kỹ thuật, 
Hà Nội 2012: 183 – 205. 
3. ESC Clinical Practice Guidelines (2012): Third Universal Definition of 
Myocardial, Infarction. European Heart Journal 2012;33:2551-2567. 
 
CÂU H ỎI LƯ ỢNG GIÁ  
 
Câu 1:  ST thay đổi như thế nào ở chuyển đạo V2, V3 trong nhồi máu cơ 
tim cấp có ST chênh lên ở người  trên 40 tuổi: 
    A. Chênh lên trên 0,10 mV  
B. Chênh lên trên 0,15 mV  
C. Chênh lên trên 0,20 mV  
D. Chênh lên trên 0,25 mV 
Câu 2: Phân độ Killip IV ở bệnh nhân NMCT khi c ó:  
A. Sốc tim 
       B. Phù phổi cấp 
   C. Suy tim xung huyết với ran ẩm 2 đáy phổi 
D. Không có suy tim53 
 Câu 3: Chỉ định điều trị tái tưới máu cho bệnh nhân NMCT  cấp bằng 
thuốc tiêu sợi huyết khi nào 
A. Bệnh nhân vào viện trong vòng 30 phút đầu sau khi đau ngực, có 
khả năng chuyển đến trung tâm can  thiệp tim mạch và thực hiện được can  
thiệp trong vòng 120 phút kể từ khi đau ngực 
B. Bệnh nhân vào viện trong vòng 30 phút đầu sau khi đau ngực và 
không có khả năng chuyển đến trung tâm can  thiệp tim mạch để thực hiện 
được can thiệp trong vòng 120 phút kể từ khi đau ngực 
C. Bệnh nhân vào viện 3 giờ sau khi đau ngực. 
D. Bệnh nhân có tiền sử xuất huyết não cách đây 9 tháng. 
Câu 4:  Bệnh nhân NMCT  cấp dưới 75 tuổi được dùng liều đầu Clopidogrel 
như thế nào: 
 
A. 300 mg  
B. 225 mg  
C. 150 mg  
D. 75 mg 
Câu 5: Heparin không phân đoạn tiêm tĩnh mạch liều bolus đầu tiên cho 
bệnh nhân NMCTcó thể dung tối đa là bao nhiêu đơn vị 
A. 2000 đơn vị  
B. 3000 đơn vị  
C. 4000 đơn vị  
D. 5000 đơn vị 
 
 
 
 
 
 
 
 
 
 
 
 54 
  
 
 
 
 
 
 
 
 
 
 
 
 
 
 
Bài 8 
CẤP CỨU CHẤN THƯƠNG S Ọ NÃO  
 
MỤC TIÊ U  
Sau khi h ọc xong h ọc viên có kh ả năng:  
1. Nêu đư ợc các d ấu hiệu lâm sàng g ợi ý ch ấn thương s ọ não trên b ệnh 
nhân ch ấn thương  
2. Nêu đư ợc mục tiêu và nguyên t ắc xử trí ch ấn thương s ọ não t ại khoa 
cấp cứu 
3. Mô t ả phác đ ồ xử trí cấp cứu chấn thương s ọ não tại khoa c ấp cứu 
 
NỘI DUNG  
 
I. ĐẠI CƯƠNG  
Chấn thương s ọ não là m ột trong nh ững ch ấn thương hay g ặp hàng đ ầu 
trên th ế giới cũng như t ại Việt Nam. T ại Hoa K ỳ số ca ch ấn thương s ọ não 
nhập viện xấp xỉ 235000 lư ợt một năm. Theo trung tâm ki ểm soát b ệnh tật 
Hoa Kỳ, số tử vong do ch ấn thương s ọ não chi ếm tỷ lệ 30,5% trong t ổng số tử 
vong chung do tai n ạn thương tích.  55 
 Tại Việt Nam cùng v ới sự gia tăng c ủa các tai n ạn thương tích, t ỷ lệ 
chấn thương s ọ não cũng không ng ừng gia tăng. Theo th ống kê t ừ bệnh vi ện 
Việt Đức, ch ỉ trong 2 năm 2009 và 2010 đã có 36.000 trư ờng hợp liên quan 
đến tai n ạn giao thông nh ập viện, trong đó có 12.000 trư ờng hợp chấn thương 
sọ não, chi ếm 37%. Riêng năm 2011 đã có 18.000 trư ờng hợp tai n ạn giao 
thông nh ập viện thì có t ới 14.000 trư ờng hợp chấn thương s ọ não, chi ếm tỷ lệ 
gần 80%.  
Để cấp cứu có hi ệu quả các trư ờng hợp chấn thương nói chung và ch ấn 
thương s ọ não nói riêng đòi h ỏi sự phối hợp chặt chẽ giữa các m ắt xích trong 
dây truy ền cấp cứu, từ cấp cứu trư ớc bệnh vi ện, đến khoa c ấp cứu, từ các nhà 
ngoại khoa ch ấn thương, ph ẫu thu ật thần kinh đ ến các bác s ỹ chuyên khoa h ồi 
sức tích c ực. 
II. CH ẨN ĐOÁN  
2.1. Triệu chứng lâm sàng  
- Yếu tố chấn thương (b ệnh sử):  
+ Đây là y ếu tố quan tr ọng cần khai thác ngay khi b ệnh nhân m ới vào 
cấp cứu (sơ b ộ) và sau khi đã ti ến hành h ỗ trợ ABC cho b ệnh nhân (chi ti ết) 
+ Các y ếu tố cần hỏi khi khai thác b ệnh sử: 
+ Cơ ch ế chấn thương: ngã, tai n ạn giao thông, tai n ạn sinh ho ạt … 
+Hoàn c ảnh xảy ra ch ấn thương  
+Thời gian t ừ khi ch ấn thương đ ến lúc vào vi ện 
+ Ý thức sau khi x ảy ra ch ấn thương  
+ Tất cả bệnh nhân ch ấn thương s ọ não c ần phải được coi như có ch ấn 
thương c ột sống cho đ ến khi có b ằng ch ứng lo ại trừ 
- Ý thức: Thay đ ổi ý th ức là d ấu hiệu quan tr ọng khi khám b ệnh nhân 
CTSN  
BẢNG ĐI ỂM GLASGOW  
Đ
á
p
 
ứ
n
g 4 tu ổi – 
người lớn 1 – 4 tuổi < 1 tu ổi Đ
i
ể
m 
M
Ở
 
M
ẮTự nhiên  Tự nhiên  Tự nhiên  4 
Mở mắt khi 
gọi Mở mắt khi 
gọi Mở mắt 
khi g ọi 3 
Mở mắt khi 
bị kích Mở mắt khi 
bị kích Mở mắt 
khi b ị kích 2 56 
 T thích đau  thích đau  thích đau  
Không đáp 
ứng Không đáp 
ứng Không đáp 
ứng 1 
L
Ờ
I
 
N
Ó
I
, 
Â
M
 
T
H
A
N
H Tỉnh, đ ịnh 
hướng 
(không 
gian, th ời 
gian)  Gọi hỏi trả 
lời đúng, 
tương tác  Bi bô  5 
Gọi hỏi trả 
lời nhưng 
lẫn l ộn 
( không 
gian, th ời 
gian, ngư ời) Nói đư ợc 
nhưng l ẫn 
lộn, có th ể 
dỗ nín đư ợc Quấy 
khóc, kích 
thích  4 
Nói các t ừ 
rời r ạc, 
không hi ểu 
được La hét, 
quấy khóc, 
không d ỗ 
nín đư ợc  Khóc khi 
bị kích 
thích đau  3 
Ú ớ, rên r ỉ 
không rõ t ừ Chỉ phát ra 
âm thanh 
không rõ 
nghĩa, kích 
thích  Rên r ỉ khi 
bị kích 
thích đau  2 
Không đáp 
ứng k ể cả 
khi b ị kích 
thích  Không đáp 
ứng k ể cả 
khi bị kích 
thích  Không đáp 
ứng k ể cả 
khi b ị kích 
thích  1 
V
Ậ
N
 
Đ
Ộ
N
G Làm theo 
lệnh Cử động tự 
nhiên, làm 
theo l ệnh Cử động tự 
nhiên như 
bú tay 
hoặc khua 
tay, đưa 
tay ra n ắm 
đồ vật. 6 
Khu trú 
được vị trí 
đau ( c ấu 
gạt đúng)  Khu trú 
được vị trí 
đau ( c ấu 
gạt đúng) Sờ vào 
người: tr ẻ 
giãy d ụa  5 
Không khu 
trú đư ợc vị 
trí đau 
nhưng c ựa Không khu 
trú đư ợc vị 
trí đau 
nhưng c ựa Kích thích 
đau: tr ẻ 
giãy d ụa  4 57 
 Bảng 1: B ảng đi ểm Glasgow cho ngư ời lớn và tr ẻ em 
Phân 
độ Điểm Glasgow  
Nhẹ GCS: 14 – 15 điểm  
Trung 
bình GCS: 9 – 13 điểm  
Nặng  GCS: 3 – 8 điểm.  
Bảng 2: phân lo ại mức độ nặng của chấn thương s ọ não theo đi ểm Glasgow  
- Tổn thương da đ ầu 
+ Vết rách, lóc da h ộp sọ 
+ Máu t ụ dưới da đ ầu 
- Tổn thương xương s ọ: 
+ Vết thương s ọ não h ở: có th ể thấy chất não  
+ Vết thương lún s ọ 
+ Vỡ xương s ọ  
+ Vật xuyên th ấu hộp sọ: đạn bắn, vật sắc nhọn… 
- Dấu hiệu vỡ nền sọ: 
+ Chảy máu, d ịch não qu ỷ qua tai  
+ Chảy máu mũi, d ịch não t ủy qua mũi  
+ Bầm tím hai ổ mắt: Dấu hiệu đeo kính dâm  
+ Bầm tím vùng xương chũm ( d ấu hiệu Battle)  
- Khám đ ồng tử: 
+ Đồng tử không đ ều hai bên: máu t ụ nội sọ 
+ Đồng tử hai bên dãn, ph ản xạ ánh sáng âm tính: nghĩ đ ến thoát v ị não quậy khi b ị 
kích thích 
đau quậy khi b ị 
kích thích 
đau 
Co c ứng 
mất vỏ Co c ứng 
mất vỏ Co c ứng 
mất vỏ 3 
Duỗi cứng 
mất não  Duỗi cứng 
mất não  Duỗi cứng 
mất não  2 
Nằm im, 
không c ử 
động k ể cả 
khi b ị kích 
thích  Nằm im, 
không c ử 
động k ể cả 
khi b ị kích 
thích  Nằm im, 
không c ử 
động kể cả 
khi b ị kích 
thích  1 58 
 + Dấu hiệu thần kinh khu trú:  
+ Liệt nửa ngư ời 
+ Liệt các dây th ần kinh s ọ 
+ Co g iật 
- Các d ấu hiệu lâm sàng khác:  
+ Co cứng m ất vỏ 
+ Duỗi cứng m ất não  
Cần lưu ý trư ớc một trường hợp chấn thương s ọ não, có th ể có các ch ấn 
thương khác kèm theo ( ví d ụ vỡ tạng đặc, ch ấn thương ng ực kín…) vì v ậy 
cần phải tiến hành khám toàn di ện một cách có  hệ thống để tránh b ỏ sót tổn 
thương  
2.2. Cận lâm sàng  
Chụp XQ s ọ thường quy: Chụp XQ s ọ thường quy có th ể xác đ ịnh tổn 
thương v ỡ xương s ọ và các d ị vật xuyên th ấu vào h ộp sọ tuy nhiên ít có giá tr ị 
để xác đ ịnh các t ổn thương n ội sọ 
Chụp cắt lớp vi tính s ọ não: 
- CT s ọ não nên đư ợc tiến hành trong vòng 1 gi ờ nếu: 
+ Glasgow < 13 đi ểm tại khoa c ấp cứu 
+ Glasgow < 15 đi ểm 2 gi ờ sau ch ấn thương  
+ Nghi ng ờ vết thương s ọ não h ở hoặc vết thương lún s ọ 
+ Dấu hiệu vỡ nền sọ 
+ Nôn nhi ều 
+ Co gi ật sau ch ấn thương  
+ Có dấu hiệu thần kinh khu trú  
- CT s ọ não nên đư ợc tiến hành trong vòng 8 gi ờ nếu: 
+ Bệnh nhân m ất ý th ức hoặc không nh ớ các s ự việc trư ớc khi ch ấn 
thương 30 phút tr ở về trước 
Và 
+ Tuổi > 65  
+ Hoặc có r ối loạn đông máu ( có th ể do dùng ch ống đông)  
+ Hoặc chấn thương do tác đ ộng m ạnh 
- Đối với bệnh nhân < 16 tu ổi cần chụp CT ngay n ếu: 
+ Mất ý th ức hoặc lẫn lộn > 5 phút  
+ Ngủ gà bất thường 
+ Nôn quá 3 l ần 59 
 + Glasgow < 14 đi ểm 
+ Nghi ng ờ vết thương s ọ não h ở hoặc vết thương lún s ọ 
+ Dấu hiệu vỡ nền sọ 
+ Có d ấu hiệu thần kinh khu trú  
+ chấn thương do tác đ ộng m ạnh 
- Các xét nghi ệm khác c ần làm:  
+ Chụp XQ ng ực 
+ Chụp cột sống, đ ặc biệt cột sống cổ 
+ Siêu âm ổ bụng, màng ph ổi 
+ Điện tim, khí máu, sinh hóa, t ế bào …  
III. X Ử TRÍ C ẤP CỨU CH ẤN THƯƠNG S Ọ NÃO  
3.1. Xử trí cấp cứu tại khoa c ấp cứu 
- Mục tiêu x ử trí cấp cứu chấn thương s ọ não t ại khoa c ấp cứu 
+ Bảo vệ đường th ở 
+ Duy trì áp l ực nội sọ bình thư ờng 
+ Giảm áp n ội sọ nếu tăng  
+ Duy trì đ ộ bão hòa oxy > 90%  
+ HA tâm thu > 90 mmHg  
+ Áp lực nội sọ ≤ 20 mmHg  
+ Điều chỉnh đư ờng huy ết, tránh tăng ho ặc giảm 
+ An th ần  
+ Xử trí vết thương  
+ Chống co gi ật 
- Đánh giá ban đ ầu: ý th ức, đư ờng th ở, hô h ấp, tuần hoàn  
- Luôn duy trì các phương ti ện cố định cột sống cổ cho đ ến khi lo ại trừ 
tổn thương c ột sống cổ. Khuy ến cáo s ử dụng Guidel ine tháo b ỏ các phương 
tiện cố định cột sống cổ. 
- Bảo vệ đường th ở: đặt nội khí qu ản nếu cần. Cân nh ắc đặt nội khí 
quản sớm đối với các b ệnh nhân sau:  
+ Glasgow ≤ 8 ho ặc suy gi ảm ý th ức nhanh  
+ Nôn nhi ều 
+ PaO2 < 80 mmHg  
+ PaCO2 > 45 mmHg  
+ Chấn thương hà m mặt  60 
 + Nguy cơ ch ảy máu vào đư ờng th ở 
+ Co gi ật 
- Hỗ trợ hô hấp: 
+ Bóp bóng ambu ho ặc thông khí nhân t ạo bằng máy th ở nếu cần 
+ Bảo đảm cung c ấp đầy đủ oxy cho b ệnh nhân đ ảm bảo PaO2>80 
mmHg  
+ Kích thích dãy d ụa có th ể làm tăng áp l ực nội sọ và làm tr ầm trọng 
thêm t ổn thương não vì v ậy cân nh ắc sử dụng an th ần cho các b ệnh nhân kích 
thích nhi ều. 
- Hỗ trợ tuần hoàn:  
+ Băng ép c ầm máu  
+ Hồi sức dịch bằng các dung d ịch tinh th ể và dung d ịch keo duy trì 
huyết áp trung bình > 65 mmHg. Truy ền máu và các ch ế phẩm máu n ếu cần 
+ Sử dụng các thu ốc vận mạch nâng huy ết áp sau khi đã bù đ ủ dịch 
+ Có th ể đặt đường truy ền tĩnh m ạch trung tâm đ ể theo dõi áp l ực tĩnh 
mạch trung tâm (CVP) và bù d ịch 
- Sau khi x ử trí ABC c ần bộc lộ bệnh nhân, khám toàn thân, tránh b ỏ 
sót tổn thương.  
- Cần lưu ý lo ại trừ các nguyên nhân gây hôn mê khác như h ạ đường 
huyết, ngộ độc. 
- Xử trí vết thương: băng ép, c ầm máu  
- Khi có d ấu hiệu tăng áp l ực nội sọ, có th ể sử dụng Manitol 1,5 – 2 g 
truyền tĩnh m ạch trong 30 -60 phút  
+ Các d ấu hiệu gợi ý tăng áp l ực nội sọ trong ch ấn thương s ọ não 
. Dãn đ ồng tử một bên  
. dãn đ ồng tử cả hai bên, m ất phản xạ ánh sáng  
. điểm Glasgow gi ảm > 2 đi ểm so v ới lúc khám trư ớc 
. co cứng ho ặc duỗi cứng 
. xuất hiện phản xạ Cushing: tăng huy ết áp, nh ịp tim ch ậm, rối loạn 
nhịp thở 
- Đối với các v ết thương xuyên th ấu, tuy ệt đối không rút các v ật xuyên 
thấu ra kh ỏi hộp sọ tại khoa c ấp cứu. 
- Chụp X quang, CT Sanner khi tình tr ạng bệnh nhân cho phép  
- Hội chẩn bác sĩ chuyên khoa ph ẫu thu ật thần kinh, ti ến hành ph ẫu 
thuật khi có ch ỉ định.  
 61 
 Phác đ ồ xử trí bệnh nhân ch ấn thương s ọ não nh ẹ 
Glasgow 13 -15 
  Khai thác ti ền sử bệnh sử 
 Cơ ch ế chấn thương  
 Thời gian b ị chấn thương  
 Mất ý th ức ngay sau ch ấn thương?  
 Quên các s ự kiện trư ớc và sau ch ấn thương?  
 Đau đ ầu: nh ẹ, vừa, trung bình  
Khám t ổng quát lo ại trừ các thương t ổn khác  
Khám phát hi ện các d ấu hiệu thần kinh khu trú  
Chụp XQ c ột sống cổ và các b ộ phận khác (n ếu cần) 
Đo n ồng độ cồn máu và theo tìm đ ộc chất nước tiểu 
nếu nghi ng ờ 
Tiêu chu ẩn nh ập viện 
- Không ch ụp được CT  
- CT s ọ bất thường 
- Vết thương xuyên s ọ 
- Tiền sử mất ý th ức kéo 
dài 
- Ý thức xấu đi 
- đau đ ầu mức độ trung 
bình và n ặng 
- Ngộ độc rượu và ma túy  
- Vỡ xương s ọ 
- Dò d ịch não t ủy 
- Có các ch ấn thương 
khác ph ối hợp 
- Khó theo dõi t ại nhà  
- Có d ấu hiệu TK khu trú  
- Glasgow < 15  
 
 Chụp CT s ọ não n ếu: 
- Glasgow < 15 đi ểm 
sau 2 gi ờ kể từ khi 
chấn thương  
- Nghi ng ờ vết 
thương s ọ não h ở 
hoặc lún s ọ 
- Có d ấu hiệu vỡ nền 
sọ 
- Nôn hơn 2 l ần 
- > 65 tu ổi 
 Tiêu chu ẩn ra vi ện 
-Không có tiêu chu ẩn 
nhập viện (như bê n) 
- Dặn bệnh nhân taosi 
khám n ếu có v ấn đề 
- Hẹn lịch khám l ại 
 62 
 Phác đ ồ xử trí bệnh nhân ch ấn thương s ọ não v ừa 
Glasgow 9 – 12 
 
 Khám ban đ ầu 
 Như trong ch ấn thương s ọ não nh ẹ 
 Chụp CT s ọ cho t ất cả các trư ờng hợp CTSN v ừa 
 Nhập viện, vào khoa ph ẫu thu ật thần kinh  
Sau khi nh ập viện 
 Khám th ần kinh thư ờng xuyên  
 Chụp lại CT s ọ não n ếu diễn biến xấu đi 
 Chụp lại CT s ọ não trư ớc khi cho xu ất viện 
 
Tình tr ạng bệnh nhân 
cải thiện 
 Xuất viện 
 Tái khám  Tình tr ạng bệnh 
nhân x ấu đi 
 Chụp lại CT s ọ não 
 Xử trí như ch ấn 
thương s ọ não 
nặng 63 
 Phác đ ồ xử trí bệnh nhân ch ấn thương s ọ não n ặng 
Glasgow 3 - 8 điểm 
 
Đánh giá và x ử trí 
1. Cột sống cổ, ABCDEs  
 A: bảo vệ đường th ở, ưỡn cổ nhấc cằm, canyl mi ệng hầu, mũi h ầu, đặt NKQ, 
mặt nạ thanh qu ản.. 
 B: hỗ trợ hô hấp: oxy li ệu pháp, bóp bóng, th ở máy xâm nh ập, không xâm 
nhập.  Duy trì đ ộ bão hòa oxy > 90%, CO2 35 -45 mmHg  
 C: hỗ trợ tuần hoàn: đ ặt đường truy ền, truy ền dịch tinh th ể, dịch cao phân t ử, 
duy trì huy ết áp. Ki ểm soát ch ảy máu, băng ép, n ẹp, duy trì HA tâm thu > 90 
mmHg  
 D: khám th ần kinh: Glasgow, đ ồng tử, dấu hiện thần kinh khu trú. Giảm áp 
nội sọ bằng manitol 20% n ếu có d ấu hiệu tăng ALNS. Ch ống co gi ật 
 E: bộc lộ khám toàn thân, không b ỏ sót tổn thương, ủ ấm 
2. Đánh giá thì 2  
 Hỏi tiền sử, bệnh sử 
 Khám chấn thương nhanh  
 Dấu hiệu sinh tồn  
 Khám lâm sàng chi tiết  
3. Hội chẩn chuyên khoa ph ẫu thu ật thần kinh  
4. Ch ụp CT s ọ não khi tình tr ạng bệnh nhân cho phép và các xét nghi ệp cần thiết 
khác  
5. Chu yển phẫu thu ật càng s ớm càng t ốt khi có ch ỉ định  64 
  
TÀI LIỆU THAM KHẢO  
1. Robert S. Hockberger, Ron M. Walls, James G. Adams. Rosen’s 
emergency medicine: concepts and clinical practice. 2010  
2. John Bailitz, Faran Bokhari, Tom Scaletta, Jeffrey Scheider. 
Emergent Management of Trauma. 2011  
3. Barbara Aehlert . Paramedic Practice Today  above and beyond. 2010  
4. Will Chapleau  , Angel Burba , Peter Pons , David Page . The 
Paramedic  2009  
5. American College of Surgeons . Advanced Trauma Life Support for 
Doctors. 2008  
6. Forrest O. Moore et al. Surgical Critical Care and Emergency 
Surgery, Clinical Questions and Answers. 2012  
 
CÂU HỎI LƯỢNG GIÁ  
1. Tri ệu chứng lâm sàng nào sau đây g ợi ý tình trang tăng áp l ực nội sọ 
trên b ệnh nhân ch ấn thương s ọ não: 
A. Suy hô h ấp 
B. Điểm Glasgow gi ảm hơn 2 đi ểm 
C. Gáy c ứng 
D. Liệt nửa ngư ời 
2. Chọn câu tr ả lời đúng sai  
Tăng thông khí d ẫn đến dãn m ạch não và tăng áp l ực nội sọ, vì v ậy đối 
với bệnh nhân ch ấn thương s ọ não, c ần tránh tăng thông khí và duy trì PaCO2 
35-35mmHg ̉  
A. Đúng  
B. Sai  
3. Trên b ệnh nhân ch ấn thương s ọ não Tr ị số áp lực nội sọ (mmHg) nào 
sau đây có ch ỉ định can thi ệp giảm áp:  
A. 10  
B. 20  
C. 30 
D. 40 
 
 65 
  
 
 
Bài 9 
CẤP CỨU CHẤN THƯƠNG CỘT SỐNG  
 
MỤC TIÊU  
Sau khi h ọc xong h ọc viên có kh ả năng:  
1. Mô t ả được các tri ệu chứng lâm sàng, c ận lâm sàng c ủa chấn thương 
cột sống 
2. Nêu đư ợc các nguyên t ắc xử trí ch ấn thương c ột sống tại khoa c ấp 
cứu 
3. Nêu đư ợc nguyên t ắc bất động cột sống cổ và nguyên t ắc tháo n ẹp cổ 
tại khoa c ấp cứu 
NỘI DUNG  
I. ĐẠI CƯƠNG  
Chấn thương c ột sống là m ột chấn thương thư ờng gặp và là tình trạng 
cấp cứu đe dọa tính mạng, có th ể để lại biến chứ ng, di chứng suốt đời. Ở Hoa 
Kỳ, tỷ lệ chấn thương c ột sống xấp xỉ 50000 trư ờng hợp một năm. Ở Việt 
Nam chưa có con s ố thống kê chính th ức, tuy nhiên v ới tỷ lệ tai n ạn giao 
thông r ất cao ở nước ta ch ắc chắn tỷ lệ chấn thương c ột sống không ph ải là 
nhỏ.  
Theo các th ống kê, đa s ố các b ệnh nhân b ị chấn thương c ột sống đều 
đang ở trong đ ộ tuổi lao đ ộng, chính vì v ậy cấp cứu chấn thương c ột sống 
nhanh chóng, đúng cách có th ể giúp h ạn chế tỷ lệ tàn tật, di ch ứng.  
Các nguyên nhân thư ờng gặp dẫn đến chấn thươn g cột sống: 
- Tai n ạn giao thông 48%  
- Ngã cao 21%  
- Xung đ ột 15%  
- Chấn thương trong th ể thao 14%  
Trong đó  
- Chấn thương c ột sống cổ 55% 
- Cột sống ng ực 15%  
- Cột sống th ắt lưng: 15%  
- Cùng c ụt 15%  
Cơ ch ế chấn thương  66 
 - Ưỡn c ột sống quá mức  
- Ngửa c ột sống quá mức  
- Do lực tác động từ bên vào c ột sống 
- Do lực ép xuống theo chiều dọc c ột sống 
- Do lực kéo dãn theo chiều dọc c ột sống 
II. CH ẨN ĐOÁN  
2.1. Nguyên t ắc khám c ấp cứu trư ờng h ợp nghi ng ờ chấn thương 
cột sống 
- Trong tất cả các trường hợp chấn thương cần coi như có chấn thương 
cột sống cổ  
- Khi khám c ần bộc lộ và khám toàn b ộ cột sống  
- Các b ệnh nhân có thay đ ổi ý th ức, say rư ợu, đa ch ấn thương c ần duy 
trì các phương ti ện cố định cột sống cổ cho đ ến khi có b ằng ch ứng ch ắc chắn 
loại trừ chấn thương  
2.2. Triệu chứng lâm sàng  
- Đau vùng c ột sống, đau tăng khi s ờ nắn cột sống 
- Biến dạng cột sống 
- Các d ấu hiệu đụng dập, bầm tím vùng c ột sống 
- Liệt:  
+ Tứ chi: c ột sống cổ 
+ Liệt 2 chi dư ới 
+ Liệt cơ hô h ấp 
+ Rối loạn cơ trò n 
+ Cương dương  
- Mất/giảm vận động, c ảm giác ở chi 
2.3. Định khu t ổn thương t ủy sống 
 67 
 
 
 
Vị trí 
tổn 
thương  Vận động Cảm 
giác Phản 
xạ 
C4 Cơ hoành/hô h ấp Trên 
hõm ức  
C5 Cơ delta/nhún vai  Dưới 
xương 
đòn Nhị đầu 
C6 Cơ nh ị đầu/gấp 
khuỷu tay/ng ửa cổ 
tay Ngón cái  Nhị đầu 
C7 Cơ tam đ ầu/ du ỗi 
khuỷu tay  Ngón 
giữa Tam 
đầu 
C8 Cơ g ấp/gấp ngón tay  Ngón út   
T1 Gian đ ốt/ xòe ngón  Mặt 
trong 
cánh tay   
T4 Cơ gian sư ờn/hô h ấp Núm vú   
T8  Mũi ức  
T10 Cơ th ẳng bụng Rốn  68 
 T12  Gò mu   
L1/L2  Cơ đái ch ậu/duỗi 
hông  Vùng 
trên đùi   
L3 Cơ tứ đầu/duỗi gối Vùng 
giữa đùi  Bánh 
chè 
L4 Cơ tứ đầu/duỗi gối Ngón 
chân cái  Bánh 
chè 
L5 Cơ du ỗi ngón 
chân/g ấp ngón chân 
cái Ngón 
giữa bàn 
chân   
S1 Cơ nh ị đầu và cơ dép/ 
duỗi bàn chân  Ngón 
chân út  Gân 
Achilles  
S2/S3/S4  Cơ th ắt hậu môn/ru ột 
và bàng quang  Đáy ch ậu Co th ắt 
hậu 
môn 
 
2.4. Đánh giá ch ức năng v ận động 
Điểm   Biểu hiện lâm sàng  
0  Liệt hoàn toàn  
1  Nhìn th ấy cơ m ấp máy ho ặc sờ thấy cơ v ận động 
2  Không th ể vận động kháng tr ọng lực 
3  Có th ể vận động kháng tr ọng lực 
4  Giảm nhẹ, phát hi ện khi b ệnh nhân co cơ kháng tr ở lực 
5  Bình thư ờng 
 69 
 2.5 Đ ịnh khu t ổn thương c ột sống dựa vào Ch ức năng hô h ấp 
Mức độ giảm dung tích 
sống (VC)   Vị trí tổn thương c ột sống tương 
ứng 
95%  Cột sống cổ, đoạn cao: C1 -C4 
75%  Cột sống cổ, đoạn thấp: C5 -C7 
50%  Cột sống ng ực đoạn cao: N1 -N9  
0%  Thấp dưới đốt ngực 10 
 
2.6. Các h ội chứng tổn thương t ủy sống 
Hội chứng trung tâm:  
- Tổn thương trung tâm t ủy sống 
- Tổn thương c ảm giác v ận động chi trên nhi ều hơn chi dư ới 
- Tổn thương v ận động gốc chi  nhiều hơn ng ọn chi  
- Cảm giác b ỏng rát ở hai chi trên  
Hội chứng Brown -Sequard  
- Tổn thương m ột nửa tủy sống 
- Hay g ặp trong v ết thương xuyên th ấu tủy sống ho ặc u chèn ép ½ t ủy 
sống 
- Mất vận động, nh ận cảm rung, c ảm giác b ản thể cùng bên v ới tổn 
thương t ủy 
- Mất cảm giác đau và c ảm nh ận nhi ệt độ đối bên v ới tổn thương t ủy 
Hội chứng sừng trư ớc 
- Tổn thương s ừng trư ớc tủy sống 
- Liệt vận động ( nhi ều mức độ) và m ất cảm giác đau ở vùng dư ới tổn 
thương  
- Còn c ảm nh ận được rung đ ộng và c ảm giác b ản thể 
Hội chứng sừng sau  
- Hiếm gặp 
- Tổn thư ờng sừng sau t ủy sống 
- Mất cảm giác ở vùng dư ới tổn thương  
- Chức năng v ận động ít b ị ảnh hư ởng 
Hội chứng chóp t ủy 
- Tổn thương t ủy sống vùng cùng c ụt 
- Bí đái do m ất phản xạ bàng quang  70 
 - Liệt vận động và m ất cảm giác hai ch i dưới ( nhi ều mức độ) 
 
Hội chứng đuôi ng ựa 
- Do tổn thương các r ễ thần kinh xu ất phát t ừ cột sống th ắt lưng cùng  
- Bí đái do m ất phản xạ bàng quang  
- Liệt vận động và m ất cảm giác hai chi dư ới ( nhi ều mức độ) 
- Mất phản xạ hai chi dư ới 
Hội chứng sốc tủy (spinal shock)  
- Thường xu ất hiện sau khi t ổn thương t ủy sống 24h  
- Nguyên nhân do t ổn thương t ủy sống hoàn toàn  
- Mất toàn b ộ phản xạ, cảm giác v ận động dư ới tổn thương  
- Đại tiện không t ự chủ, bí đái, cương dương  
- Không liên quan đ ến giảm thể tích 
- Có thể phục hồi hoặc không ph ục hồi 
Hội chứng sốc Thần kinh (Neurogenic shock)  
- Tổn thương t ủy sống từ đốt ngực 6 tr ở lên 
- Tổn thương t ủy sống gây m ất trương l ực giao c ảm thành m ạch và t ụt 
huyết áp 
- Nhịp tim bình thư ờng ho ặc chậm 
- Biểu hiện dãn m ạch ngo ại biên 
2.7. Cận lâm sàng  
- Ngoài các xét nghi ệm thư ờng quy, các thăm dò ch ẩn đoán hình ảnh có 
giá tr ị lớn trong ch ẩn đoán và x ử trí ch ấn thương c ột sống 
- Các thăm dò ch ẩn đoán hình ảnh cần làm là:  
+ Chụp XQ  thường 3 tư th ế: thẳng, nghiêng, há m ồm 
+ Chụp cắt lớp vi tính c ột sống 
+ Chụp cộng hư ởng từ cột sống 
+ Siêu âm phát hi ện các t ổn thương khác: Tràn d ịch tràn máu màng 
phổi, chấn thương t ạng, tràn máu ổ bụng 
III. X Ử TRÍ C ẤP CỨU CH ẤN THƯƠNG C ỘT SỐNG 
3.1. Xử trí cấp cứu tại khoa c ấp cứu 
a) Bất động cột sống cổ 
- Bất cứ trường hợp chấn thương nào cũng nên coi như có ch ấn thương 
cột sống cổ 71 
 - Không nên vì các t ổn thương “b ắt mắt” khác như ch ảy máu, bi ến 
dạng chi mà quên c ột sống, đ ặc biệt là c ột sống cổ 
- Bất động cột sống cổ bằng nẹp cổ hoặc các phương ti ện cố định tương 
đương  
b) Khám ban đ ầu (thì 1) chú tr ọng vào đư ờng th ở, hô h ấp, tuần hoàn 
(ABCDE) đ ể phát hi ện và x ử trí ngay các tình tr ạng đe d ọa tính m ạng bệnh 
nhân  
Xử trí đư ờng th ở: 
- Bảo đảm cột sống đư ợc bất động trong khi x ử trí cấp cứu 
- Đặt nội khí quản (mi ệng/mũi), m ặt nạ thanh qu ản 
- Mở khí qu ản cấp cứu qua màng nh ẫn giáp n ếu cần 
Hỗ trợ hô hấp: 
- Phát hi ện tràn khí màng ph ổi và ch ọc hút d ẫn lưu khí c ấp, nếu có 
- Bóp bóng qua n ội khí qu ản 
- Thông khí nhân t ạo 
- Oxy li ệu pháp  
Hỗ trợ tuần hoàn:  
- Đặt đường truy ền tĩnh m ạch. Trong trư ờng hợp bệnh nhân n ặng có 
thể đặt hai đư ờng truy ền lớn (14 – 16 G) ho ặc đặt catheter TM trung tâm ho ặc 
đường truy ền trư ớc xương chày  
- Truy ền dịch tinh th ể, dịch cao phân t ử để bù kh ối lượng tu ần hoàn 
trong trư ờng hợp sốc. Truy ền máu và các ch ế phẩm máu trong trư ờng hợp 
mất máu n ặng 
- Cầm máu: băng ép, b ất động chi gãy, garo …  
Đánh giá tình tr ạng tinh th ần kinh  
Bộc lộ toàn b ộ bệnh nhân, tránh b ỏ sót tổn thương  
c) Khám chi ti ết (thì 2)  
- Khám ch ấn thương t ừ đầu đến chân, kh ông b ỏ sót các t ổn thương 
khác  
- Tiến hành các xét nghi ệm, chi ếu chụp để xử trí tiếp 
- Hội chẩn với chuyên khoa ngo ại chấn thương, chuyên khoa ngo ại cột 
sống.  
3.2. Thuốc 
- Hiện nay chưa có thu ốc điều trị giúp c ải thiện tiên lư ợng của tổn 
thương t ủy sống 72 
 - Mục đích s ử dụng các thu ốc chủ yếu để hỗ trợ dự phòng t ổn thương 
tủy sống th ứ phát do gi ảm tưới máu, phù t ủy… 
- Việc sử dụng corticoid trong ch ấn thương c ột sống hi ện vẫn còn chưa 
thống nh ất và có nhi ều ý ki ến tranh cãi  
- Một số tác gi ả ủng hộ việc sử dụng corticoid r ằng corticoid có th ể 
giúp làm gi ảm tình tr ạng phù n ề tủy sống nếu dùng li ều cao trong 8 gi ờ đầu. 
Liều lượng Methylprednisolone: Bolus 30mg/kg/15ph, duy trì 5,4 mg/kg/h x 
23 h (The  National  Association  of  Spinal  Cord  Injury  Studies)  
3.3. Các phương ti ện cố định cột sống  
a) Nẹp cổ 
- Luôn nh ớ bất động cột sống cổ cho các trư ờng hợp chấn thương, đ ặc 
biệt những ch ấn thương do l ực tác đ ộng lớn, bệnh nhân thay đ ổi ý th ức, trẻ 
em, ngư ời già, có tri ệu chứng nghi ng ờ tổn thương c ột sống 
- Trước khi đeo n ẹp cổ: luôn b ất động cột sống cổ bằng cách dùng hay 
tay gi ữ vững đầu và c ổ bệnh nhân  
- Phải chọn cỡ nẹp cổ phù h ợp. Nẹp cổ cỡ lớn quá không b ảo đảm bất 
động cột sống, n ẹp cổ cỡ nhỏ quá có th ể làm t ổn thương thêm c ột sống 
- Nẹp cổ mềm không có tác d ụng cố định cột sống 
- Khi tháo n ẹp cổ, cần tuân th ủ chặt chẽ các protocol  
b) Cáng c ứng 
- KHÔNG dùng cáng m ềm để vận chuy ển bệnh nhân ch ấn thương.  
- Sử dụng kỹ thuật log-roll đ ể đặt bệnh nhân lên cáng c ứng.  
- Khi đ ặt bệnh nhân trên cáng c ứng cần phải có các phương ti ện (dây, 
đai) c ố định (bu ộc) bệnh nhân ch ắc chắn. Lưu ý khi c ố định ph ải cố định thân 
mình c ủa bệnh nhân trư ớc sau đó m ới đến cố định đầu. 
- Khi đ ến bệnh vi ện, chuy ển bệnh nhân ra kh ỏi cáng c ứng càng s ớm 
càng t ốt. Bệnh nhân n ằm cáng c ứng lâu h ơn 2 gi ờ có nguy cơ cao b ị loét do t ỳ 
đè 
- Khi không có s ẵn phương ti ện cố định đầu, có th ể sử dụng hai cu ộn 
khăn t ắm ( ho ặc ga) để hai bên đ ầu bệnh nhân sau đó c ố định bằng băng cu ộn 
hoặc băng dính  
3.5. Tháo b ỏ các phương ti ện cố định cột sống cổ tại khoa c ấp cứu 
a) Các b ệnh nhân không có tri ệu chứng lâm sàng  c) Phương ti ện cố định đầu 
Chỉ dùng n ẹp cổ không đ ủ hiệu quả bất động cột sống cổ 
Cần kết hợp nẹp cổ, cố định đầu và cáng c ứng 73 
 Phải có đ ủ các tiêu chu ẩn sau m ới đư ợc tháo n ẹp cổ (NEXUS 
Guidelines)  
- Tỉnh đáp ứng tốt 
- Không đau, nh ạy cảm/cảm ứng cột sống cổ 
- Không có d ấu hiêu TK khu trú  
- Không say rư ợu 
- Không có các ch ấn thương gây chú ý khác (ví d ụ chảy máu ngoài, gãy 
chi…)  
b) Các b ệnh nhân có tri ệu chứng lâm sàng:  
- Luôn duy trì các phương ti ện bất động cột sống cổ cho đ ến khi có 
bằng ch ứng lo ại trừ tổn thương  
- Cần tiến hành các thăm dò ch ẩn đoán hình ảnh để xác đ ịnh tổn thương  
+ XQ 3 tư th ế: trước-sau, bên, há m ồm 
+ CT 
+ MRI  
- Hội chẩn chuyên khoa ngo ại chấn thương, ph ẫu thu ật thần kinh, c ột 
sống 
c) Các b ệnh nhân không đánh giá đư ợc  
- Các b ệnh nhân này bao g ồm 
+ Bệnh nhân hôn mê  
+ Bệnh nhân đ ặt NKQ, an th ần 
+ Bệnh nhân say rư ợu 
+ Có v ết thương ch ấn thương gây chú ý  
Luôn duy trì các phương ti ện bất động CS c ổ cho đ ến khi có b ằng 
chứng lo ại trừ đồng th ời Theo dõi lâm sàng, Tiến hành các thăm dò ch ẩn đoán 
hình ảnh và Hội chẩn chuyên khoa  tiến hành các thăm dò ch ẩn đoán hình ảnh 
 74 
 Tiêu chu ẩn tháo phương ti ện bất động cột sống cổ dựa vào lâm sàng  
(chỉ áp dụng cho b ệnh nhân t ỉnh hoàn toàn, Glassgow >14 ) 
Vikas V. Patel, Evalina Burger 2010  
 
  
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 Hỏi tiền sử tỉ mỉ 
Khám lâm sàng toàn di ện 
Bệnh nhân t ỉnh, đ ịnh hư ớng 
Không đau c ổ 
Không tăng đau khi khám c ổ 
Không có d ấu hiệu TK khu trú  
Say rư ợu 
Hoặc 
Có ch ấn thương 
gây chú ý khác  
Cột sống cổ an toàn  
Tháo n ẹp cổ Làm test quay 
cổ 45 độ sang 
trái và sang ph ải Không đ ủ tiêu chu ẩn tháo n ẹp cổ 
Tiếp tục duy trì n ẹp cổ 
Chẩn đoán hình ảnh có không  
Thành công  Thất bại 75 
  
 
 
 
TÀI LIỆU THAM KHẢO  
1. R.  Roberts,  Jerris  R.  Hedges. Clinical  procedures  in  emergency  
medicine 2010  
2. Robert S. Hockberger, Ron M. Walls, James G. Adams. Rosen’s 
emergency me dicine: concepts and clinical practice. 2010  
3. John Bailitz, Faran Bokhari, Tom Scaletta, Jeffrey Scheider. 
Emergent Management of Trauma. 2011  
4. Colin R Anderson, Ken WS Ashwell, Han Collewijn et al. The 
Spinal Cord: A Christopher and Dana Reeve Foundat ion Text and Atlas. 2009  
5. Barbara Aehlert . Paramedic Practice Today  above and beyond. 2010  
6. Will Chapleau  , Angel Burba , Peter Pons , David Page . The 
Paramedic  2009  
7. American College of Surgeons . Advanced Trauma Life Support for 
Doctors. 2008  
 
CÂU HỎI LƯỢNG GIÁ  
1. Bệnh nhân nam 35 tuổi vào cấp cứu sau tai nạn giao thông, bệnh 
nhân tỉnh, gãy kín xương cẳng tay trái và xương cẳng chân trái. Tê bì chân tay  
Việc đầu tiên cần làm là:  
A. đo dấu hiệu sinh tồn mạch, huyết áp, nhiệt độ  
B. khai thông đường thở  
C. đặt đường truyền TM  
D. cố định c ột sống cổ  
E. nẹp, bất động cẳng tay và cẳng chân bên trái  
F. không có câu nào đúng  
2. Chọn câu tr ả lời đúng sai  
Trong trường hợp chấn thương cột sống cổ, chỉ cần cho bệnh nhân đeo 
nẹp cổ đúng cách là có thể bảo đảm bất động cột sống cổ  
A. Đúng  
B. Sai  
3. M ột bệnh nhân đư ợc đưa vào c ấp cứu do tai n ạn giao thông, g ọi 
bệnh nhân m ở mắt, kích thích đau g ạt đúng,  nói rõ ti ếng khi g ọi hỏi nhưng 76 
 lộn xộn. Bệnh nhân đã đư ợc nhân viên c ấp cứu 115 n ẹp cổ, đang n ằm cáng 
cứng, không tím môi, m ạch rõ chưa th ấy dấu hiệu thần kinh khu trú. Can 
thiệp nào sau đây không đư ợc tiến hành  
A. đo dấu hiệu sinh tồn  
B. oxy li ệu pháp  
C. tháo b ỏ nẹp cổ 
D. khám toàn thân  
        E. đưa b ệnh nhân đi ch ụp CT s ọ não 77 
  
Bài 10 
CẤP CỨU CHẤN THƯƠNG NG ỰC 
 
MỤC TIÊU  
Sau khi h ọc xong h ọc viên có kh ả năng:  
1. Nêu đư ợc nguyên t ắc xử trí cấp cứu chấn thương ng ực tại khoa c ấp 
cứu 
2. Mô t ả triệu chứng của sáu lo ại chấn thương ng ực đe d ọa tính m ạng 
bệnh nhân ngay l ập tức 
3. Nêu đư ợc các bi ện pháp x ử trí các ch ấn thương ng ực tại khoa c ấp 
cứu 
 
NỘI DUNG  
I. ĐẠI CƯƠNG  
Nhiều bệnh nhân b ị chấn thương ng ực nặng ch ết trước khi h ọ đến bệnh 
viện, Tuy nhiên, m ột tỷ lệ lớn còn s ống và c ần khám đánh gi á xử trí cấp cứu 
ngay l ập tức. Vi ệc cấp cứu đúng cách và kh ẩn trương có tính ch ất quy ết định. 
Chấn thương ng ực có th ể ở nhiều mức độ khác nhau, t ừ tổn thương nh ẹ 
như ch ấn động ng ực đến các t ổn thương n ặng như v ết thương th ấu tim ho ặc 
đụng dập các m ạch máu lớn trong l ồng ng ực.  
Theo th ống kê ch ấn thương ng ực thư ờn gặp do tai n ạn giao thông, 
trong đó dư ới 10% các ch ấn thương ng ực kín và x ấp xỉ 30% v ết thương th ấu 
ngực hoặc chấn thương ng ực hở cần phải can thi ệp phẫu thu ật ngay l ập tức. 
Các ch ấn thương ng ực đe dọa tính m ạng ngay l ập tức bao g ồm : 
- Tắc ngh ẽn đường th ở 
- Tràn khí màng ph ổi áp l ực 
- Tràn máu màng ph ổi lớn  
- Vết thương ng ực hở 
- Mảng sư ờn di đ ộng  
- Ép tim c ấp  
II. CH ẨN ĐOÁN VÀ X Ử TRÍ CH ẤN THƯƠNG NG ỰC 
2.1. Nguyên t ắc xử trí cấp cứu chấn thương ng ực: 
a. Xử trí cấp cứu trư ớc bệnh vi ện 
- Bất động cột sống cổ 78 
 - Đánh giá và x ử trí ABC  : đường th ở hô hấp tuần hoàn  
- Chọc hút d ẫn lưu khí màng ph ổi nếu nghi ng ờ 
- Oxy li ệu pháp, ch ống sốc 
- Nếu có v ật xuyên th ấu vào ng ực không đư ợc rút ra, c ố định ch ắc chắn 
vật xuyên th ấu và v ận chuy ển đến bệnh vi ện cùng b ệnh nhân  
- Vận chuy ển nhanh đ ến bệnh vi ện 
- Đánh giá l ại liên t ục trên đư ờng vận chuy ển 
b. Xử trí cấp cứu tại khoa c ấp cứu 
Thăm khám thì đ ầu (primary survey)  
Đánh giá và x ử trí theo trình t ự các bư ớc ABCD . Đánh giá nhanh (2 
phút), ti ến hành x ử trí ngay sau khi phát hi ện tổn thương và nh ắc lại đánh giá 
bất cứ lúc nào khi b ệnh nhân không ổn định. 
Luôn lưu ý b ảo đảm bất động cột sống cổ cho đ ến khi lo ại trừ tổn 
thương. Trong trư ờng hợp nẹp cổ gây khó khăn cho  thủ thuật đặt nội khí qu ản, 
có th ể tháo ph ần trư ớc của nẹp cổ, duy trì b ất động cột sống cổ bằng tay, l ắp 
lại nẹp cổ khi đã ti ến hành xong th ủ thuật 
Airway (A): Đư ờng th ở 
- Xác đ ịnh có hay không t ắc ngh ẽn đường th ở.  
- Lưu ý t ổn thương đư ờng hô h ấp trên.  
- Nếu có ph ải xử trí ngay đ ảm bảo đường th ở luôn thông thoáng.  
- Kiểm soát đư ờng th ở nâng cao  : Đặt Nội khí qu ản, mặt nạ thanh qu ản, 
ống kết hợp.  
Breathing (B): Hô h ấp 
Phát hi ện và x ử trí ngay ngay các d ấu hiệu và nguyên nhân gây suy hô 
hấp cấp do ch ấn thương ng ực:  
- Tắc ngh ẽn đường th ở 
- Tràn khí màng ph ổi áp l ực 
- Vết thương ng ực hở 
- Tràn máu màng ph ổi lớn  
- Mảng sư ờn di đ ộng  
- Chèn ép tim c ấp    
Oxy li ệu pháp  : qua kính mũi ho ặc các lo ại mặt nạ 
Hỗ trợ hô hấp : thông khí nhân t ạo xâm nh ập và không xâ m nh ập 
Circulation (C): Tu ần hoàn  
- Kiểm soát ch ảy máu: băng ép c ầm máu, b ất động chi gãy, garo  79 
 - Xử trí sốc: 
+ Hồi sức dịch 
+ Đầu thấp chân cao  
+Phẫu thu ật cầm máu đ ối với các cháy máu trong  
2. Thăm khám thì hai ( secondary survey)  
Tiến hành khi các d ấu hiệu đe d ọa tính m ạng đã đư ợc chẩn đoán, x ử trí 
hoặc loại trừ. Cần đánh giá l ại toàn b ộ, chi ti ết và làm thêm các thăm dò khác 
để phát hi ện tổn thương như ch ụp XQ, siêu âm, CT, xét nghi ệm. 
3. Tiếp cận đa chuyên khoa:  
Để đạt được chất lượng xử trí cấp cứu cao nh ất cho các b ệnh nhân ch ấn 
thương ng ực nói riêng và các b ệnh nhân ch ấn thương nói chung, c ần có cơ 
chế phối hợp nhịp nhàng gi ữa các chuyên khoa: C ấp cứu – Hồi sức – Ngoại 
khoa – Chẩn đoán hình ảnh  
2.2. T ắc ngh ẽn đư ờng th ở 
( xem thêm bài ki ểm soát đư ờng thở) 
Xử trí đư ờng th ở :  
- Ưỡn cổ nhấc cằm ho ặc ấn hàm  
- Lấy bỏ dị vật: thủ thuật Hemlich, hút mi ệng, h ầu họng, g ắp dị vật 
bằng panh magi (n ếu có th ể)  
- Đặt đường th ở phụ miệng h ầu ( canyl mayo/Guedel) ho ặc mũi h ầu 
( nếu có)  
- Kiểm soát đư ờng th ở nâng c ao : Đặt Nội khí qu ản, mặt nạ thanh qu ản, 
ống kết hợp.  
- Các trư ờng hợp đường th ở khó :  
+ Mở khí qu ản một thì c ấp cứu 
+ Mở màng nh ẫn giáp c ấp cứu 
2.3. Tràn khí màng ph ổi áp l ực 
2.3.1. Chẩn đoán:  
- Suy hô h ấp cấp tính: th ở nhanh, tím môi và đ ầu chi, gi ảm oxy hóa 
máu 
- Rối loạn huy ết động: nh ịp tim nhanh, t ụt huy ết áp, tĩnh m ạch cổ nổi 
- Triệu chứng tràn khí màng ph ổi  
+ Lồng ng ực căng ph ồng m ột bên,  
+ Rì rào ph ế nang gi ảm ho ặc mất,  
+ Gõ vang tr ống,  
+ Có thể thấy tràn khí dư ới da 80 
 + Khí qu ản bị đẩy lệch sang bên đ ối diện 
2.3.2 . Xử trí tại khoa c ấp cứu 
Đánh giá và x ử trí ABC  
- Chọc giảm áp màng ph ổi: 
+ Sử dụng kim c ỡ lớn ( 10 -16 G) n ối với xylanh ch ọc vào khoang 
màng ph ổi,  
+ điểm ch ọc ở khoang liên sư ờn 2 đư ờng gi ữa đòn  
+ hướng kim đi vuông góc v ới mặt da 
+ chân không trong tay cho đ ến khi th ấy khí tràn vào xylanh  
+  Nối kim v ới hệ thống hút áp l ực thấp hoặc để hở 
- Mở màng ph ổi tối thiểu 
- Hút liên t ục áp l ực thấp 
- Phát hi ện và x ử trí các thương t ổn khác đi kèm  
2.4. V ết thương ng ực hở 
2.4.1. Ch ẩn đoán  
- Dấu hiệu “phì phò” qua v ết thương h ở ở ngực, có th ể thấy máu và 
dịch sủi qua v ết thương khi b ệnh nhân th ở 
- Giảm giãn n ở của thành ng ực trong thì hít vào.  
- Rì rào ph ế nang gi ảm ho ặc mất.  
2.4.2. X ử trí tại khoa c ấp cứu 
- Đánh giá và x ử trí ABC nâng cao  
- Bịt vết thương ng ực hở bằng cách t ạo một van môt chi ều trên v ết 
thương làm cho khí ch ỉ đi từ trong khoang màng ph ổi đi ra mà không đi 
ngược trở lại được. Th ủ thuật này giúp ngăn ng ừa vết thương ng ực hở tiến 
triển thành tràn khí màng ph ổi áp l ực. Sử dụng m ột miếng nilon m ỏng, s ạch 
(Vô khu ẩn càng t ốt), hình vuông. Dùng băng dính dán kín 3 c ạnh của miếng 
nilon. C ạnh còn l ại chỉ dán kín 2/3. Hi ện nay đã có các s ản phẩm thương m ại 
có cơ ch ế tác d ụng tương t ự ví dụ nút b ịt ngực Asherman  
- Có th ể dẫn lưu màng ph ổi hoặc mở màng ph ổi cấp cứu nếu có tràn 
dịch, tràn khí màng ph ổi nhiều 
- Phát hi ện các thương t ổn khác đi kèm  
- Hội chẩn chuyên khoa ngo ại  
2.5. Tràn máu màng ph ổi nhi ều 
2.5.1. Ch ẩn đoán  
- Khó th ở, giảm độ bão hòa oxy máu  
- Di động lồng ng ực giảm 81 
 - Bên t ổn thươn g: rì rào ph ế nang gi ảm ho ặc mất, gõ đ ục, rung thanh 
tăng 
- Có th ể có các d ấu hiệu chấn thương ng ực: bầm tím, gãy xương sư ờn, 
vết thương ng ực hở… 
- Tụt huy ết áp do s ốc mất máu  
- Dấu hiệu thiếu máu: da xanh niêm m ạc nhợt, mạch nhanh, không th ấy 
mất máu ở các cơ quan khác  
2.5.2. X ử trí tại khoa c ấp cứu 
- Đánh giá và x ử trí ABC  
- Truy ền dịch tinh th ể hoặc truy ền máu n ếu cần 
- Dẫn lưu b ằng kim ho ặc mở màng ph ổi tối thiểu nếu tràn máu m ức độ 
nhiều 
- Lưu ý ch ống sốc, bù d ịch, máu trư ớc khi ti ến hành th ủ thuật dẫn lưu  
- Tiến hành ch ụp CT, XQ khi tình tr ạng bệnh nhân cho phép  
- Hội chẩn chuyên khoa ngo ại 
2.6.  M ảng sư ờn di đ ộng 
2.6.1. Ch ẩn đoán:  
- Một đoạn ngực mất tính liên t ục của xương (hay có ≥3 xương sư ờn kề 
nhau b ị gẫy ≥ 2 đi ểm trên 1 xương sư ờn).  
- Di động bất thư ờng của một đoạn ngực khi b ệnh nhân t ự thở, vùng 
tổn thương  di động ngư ợc chi ều với lồng ng ực khi hô h ấp 
- Thở nông do b ệnh nhân đau không dám th ở mạnh 
- Sờ nắn vùng xương sư ờn gãy có ti ếng lạo xạo.  
- Dấu hiệu gãy nhi ều xương sư ờn trên XQ.  
2.6.2. X ử trí tại khoa c ấp cứu  
- Xử trí và b ảo đảm ABC, oxy li ệu pháp  
- Giảm đau giúp b ệnh nhân c ải thiện rối loạn hô h ấp gây ra do m ảng 
sườn di đ ộng 
- Nhiều bằng ch ứng cho th ấy thở CPAP không xâm nh ập giúp b ệnh 
nhân b ị mảng sư ờn di đ ộng cải thiện tốt tình tr ạng oxy hóa máu và tránh đư ợc 
đặt nội khí qu ản. 
- Xử trí m ảng sư ờn di đ ộng bằng cách đ ặt túi cát ho ặc nằm nghiêng 
sang bên t ổn thương không còn đư ợc áp d ụng trong c ả cấp cứu trư ớc bệnh 
viện và ở khoa c ấp cứu do làm gi ảm sự dãn n ỡ phổi và làm x ẹp phổi bên b ị 
tổn thương.  
- Lưu ý tràn khí màng ph ổi có th ể xảy ra ở bên ph ổi bị tổn thương.  82 
 - Cố định m ảng sư ờn di đ ộng bằng ph ẫu thu ật sớm còn đang ti ếp tục 
được tranh lu ận. Nhi ều tác gi ả ủng hộ phẫu thu ật khi:  
+ Bệnh nhân khó cai máy do m ảng sư ờn di đ ộng 
+ Đau kéo dài  
+ Lồng ng ực mất vững nặng 
+ Chức năng hô h ấp có xu hư ớng xấu đi 
2.7. Ép tim c ấp 
2.7.1. Ch ẩn đoán  
- Khó th ở dữ dội, suy hô h ấp cấp 
- Huyết áp t ụt 
- Có th ể có vết thương h ở hoặc vết thương xuyên th ấu vùng ng ực, bụng 
- Tĩnh m ạch cổ nổi ( có th ể không có d ấu hiệu này n ếu bệnh nhân có 
tình tr ạng sốc, nh ất là s ốc mất máu)  
- Tiếng tim nghe m ờ, nhịp tim nhanh  
- Điện tim: gi ảm điện thế ngoại biên  
- Siêu âm: d ịch màng ngoài tim  
2.7.2. X ử trí tại khoa c ấp cứu 
- Đánh giá và x ử trí ABC nâng cao  
- Kiểm soát đư ờng th ở: đặt nội khí qu ản nếu cần 
- Hỗ trợ hô hấp: oxy li ệu pháp, th ở máy 
- Hỗ trợ tuần hoàn: đ ặt hai đư ờng truy ền cỡ lớn, truy ền dịch tinh th ể, 
cao phân t ử, máu và các ch ế phẩm máu n ếu cần 
- Đặt đường truy ền tĩnh m ạch trung tâm, h ồi sức dịch và theo dõi áp l ực 
tĩnh mạch trung tâm  
- Chọc hút d ẫn lưu d ịch, máu màng ngoài tim. C ần lưu ý tràn d ịch 
màng tim ép tim c ấp trong ch ấn thương thư ờng do v ết thương ng ực hở hoặc 
xuyên th ấu gây ch ảy máu vào màng ngoài tim, d ịch màng ngoài tim nhi ều 
máu c ục, máu tươi thư ờng gây t ắc dẫn lưu vì v ậy một số tác gi ả ủng hộ việc 
dẫn lưu màng ngoài tim b ằng th ủ thuật mở màng tim t ối thiểu hoặc mở ngực 
tại phòng m ổ  
- Phát hi ện và x ử trí tràn khí màng ph ổi đi kèm  
- Không rút v ật xuyên th ấu ra kh ỏi lồng ng ực tại khoa c ấp cứu, cố định 
chắc chắn, hội chẩn chuyên khoa ngo ại chấn thương chuy ển phòng m ổ. 
   3. Nh ững tổn thương khác trong ch ấn thương ng ực: 
   3.1. Đ ụng dập tim  
Chẩn đoán:  83 
 - Cơ ch ế chấn thương: va đ ập trực tiếp vào vùng tim, v ỡ xương ức.  
- Thường dễ bị bỏ sót do l ẫn trong b ệnh cảnh chấn thương  
- Đau ng ực vùng trư ớc tim, d ễ nhầm với đau do g ẫy xương ức hoặc 
xương sư ờn.  
- Men tim tăng: CPK, CPK -MB, SGOT, SGPT, Troponin I, T  
- ECG: lo ạn nhịp tim, ST chênh lên và sóng T âm, tuy nhiên ít khi có 
hình ảnh đi ển hình như trong nh ồi máu cơ tim .  
- Siêu âm: gi ảm vận động thành cơ tim, tràn d ịch màng tim.  
Xử trí: 
- ABCDE  
- Đặt Catheter TMTT, s ử dụng thu ốc vận mạch (ví d ụ Dobutamin) x ử 
trí sốc tim  
- Bệnh nhân c ần đư ợc điều trị và theo dõi như m ột trường hợp nh ồi 
máu cơ tim, tuy nhiên các thu ốc chống đông máu thư ờng ch ống ch ỉ định 
trong b ệnh cảnh ch ấn thương c ấp 
- Theo dõi lâm sàng, đi ện tim, men tim liên t ục 
- Hội chẩn chuyên khoa ngo ại lồng ng ực. 
3.2. D ập vỡ động m ạch ch ủ do ch ấn thương  
  Chẩn đoán:  
- Tỷ lệ tử vong cao, lên t ới 90% sau ch ấn thươn g 
- Cơ ch ế chấn thương: va đ ập trực tiếp hoặc tổn thương do gia t ốc giảm 
đột.  
- Đau ng ực hoặc đau lưng vùng c ột sống ng ực 
- Triệu chứng sốc, không ki ểm soát đư ợc  
- Mạch m ột nửa thân mình gi ảm ho ặc mất 
- Huyết áp hai tay khác nhau  
- XQ ng ực: có th ể có tru ng th ất rộng, g ẫy xương sư ờn số 1 hoặc 2, ph ế 
quản gốc bên ph ải bị đẩy lên cao, ph ế quản gốc bên trái xu ống th ấp, trục khí 
quản lệch sang ph ải, tràn máu màng ph ổi trái.  
- CT ng ực: độ nhạy 92-100%, đ ộ đặc hiệu 82-100%.  
Xử trí: 
- Cần phẫu thu ật cấp cứu sớm nhất. 
- Nếu phải chuy ển bệnh nhân: b ệnh nhân ph ải được an th ần thở máy, 
giữ huyết áp t ối đa <100 mmHg, đ ề phòng v ỡ bằng các thu ốc propanolol ho ặc 
Nitroprusside.  
3.3. V ỡ cơ hoành  84 
 Chẩn đoán:  
- Có th ể có suy hô h ấp: ph ụ thuộc vào di ện cơ hoành t ổn thương và sự 
thoát v ị của tạng bụng lên ph ổi.  
-  Nghe ph ổi có th ể thấy tiếng nhu đ ộng của dạ dày ru ột, mất rì rào ph ế 
nang.  
- XQ: bóng hơi d ạ dầy lên khoang màng ph ổi; ống thông d ạ dày n ằm trên 
ngực.  
- Nội soi l ồng ng ực chẩn đoán chính xác 98% v ỡ cơ hoành.  
Xử trí: 
- ABC  
- Đặt sonde d ạ dày d ẫn lưu th ức ăn và d ịch vị 
- Hội chẩn chuyên khoa ngo ại, mổ sớm 
- Phẫu thu ật mở bụng đưa t ạng thoát v ị xuống ổ bụng và khâu ph ục hồi 
cơ hoành.  
- Có th ể mở ngực hoặc nội soi l ồng ng ực để xử trí tổn thương.  
3.4. T ổn thương thanh -khí-phế quản 
Chẩn đoán:  
- Chấn thương vào vùng c ổ, ngực.  
- Khó th ở, có th ể dữ dội.  
- Ho ra máu.  
- Tràn khí dư ới da, tràn khí màng ph ổi áp l ực hoặc tràn khí màng ph ổi 
mức độ nhiều (khí ra liên t ục theo d ẫn lưu), d ẫn lưu kéo dài không h ết khí 
- CT lồng ng ực có th ể chẩn đoán các t ổn thương khí ph ế quản và trung 
thất 
- Nội soi đư ờng th ở cho phép ch ẩn đoán chính xác.  
 Xử trí: 
- ABC  
- Khuy ến cáo đ ặt nội khí qu ản qua n ội soi t ại giường nếu có đi ều kiện 
- Khi b ệnh nhân có ch ấn thương thanh – khí qu ản: ưu tiên m ở khí qu ản 
cấp cứu dưới chỗ tổn thương. N ếu phải đặt nội khí qu ản cần được tiến hành 
thận trọng bởi nhân viên y t ế có kinh nghi ệm vì nguy cơ cao gây t ổn thương 
thêm, th ậm chí đ ứt rời thanh – khí qu ản 
- Hội chẩn ngo ại khoa m ổ cấp cứu xử trí tổn thương càng s ớm càng t ốt. 
3.5. Ch ấn thương th ực quản 
 Chẩn đoán:  85 
 - Cơ ch ế chấn thương: l ực tác đ ộng đột ngột vào vùng b ụng trên ho ặc 
vết thương đâm xuyên vào vùng th ực quản.  
- Chụp thực quản có thu ốc cản quang ho ặc nội soi th ực quản. 
Xử trí: 
- Phẫu thuật cấp cứu thực quản, dẫn lưu trung th ất hoặc màng ph ổi. 
- Chống ch ỉ định đ ặt sonde d ạ dày n ếu vết thương xuyên th ấu thực 
quản 
- Mở thông d ạ dày. 
- Kết hợp kháng sinh tích c ực 
3.6. Đ ụng dập ph ổi 
Chẩn đoán:  
- Có tổn thương: b ầm dập thành ng ực, gẫy xương sư ờn, ho ặc mảng sư ờn 
di động.  
- XQ ng ực: các đám tăng t ỉ trọng không đ ồng nh ất ở bên ph ổi tổn 
thương.  
- CT scanner: cho phép phân bi ệt với tổn thương do trào ngư ợc, xẹp phổi. 
Xử trí: 
- Kiểm soát đau t ốt. 
- Thở oxy và lý li ệu pháp ng ực. 
- Đặt nội khí qu ản và th ở máy n ếu có s uy hô h ấp nặng. 
 
TÀI LI ỆU THAM KH ẢO 
1. Robert S. Hockberger, Ron M. Walls, James G. Adams. Rosen’s 
emergency medicine: concepts and clinical practice. 2010  
2. John Bailitz, Faran Bokhari, Tom Scaletta, Jeffrey Scheider. 
Emergent Management of Trauma. 2011  
3. Barbara Aehlert . Paramedic Practice Today  above and beyond. 2010  
4. Will Chapleau  , Angel Burba , Peter Pons , David Page . The 
Paramedic  2009  
5. American College of Surgeons . Advanced Trauma Life Support for 
Doctors. 2008  
6. Forrest O. Moore et al. Surgical Critical Care and Emergency 
Surgery, Clinical Questions and Answers.  2012  
7. Paul E. Pepe, Marc Eckstein. Reappraising the prehospital care of 
the patient with major trauma.  Emergency Medicine Clinics of North 
America , Volume 16, Issue 1, Pages 1 -15 86 
 8. Nguy ễn Hữu Tú. Ch ấn thương ng ực. Hư ớng d ẫn cấp cứu ch ấn 
thương. B ộ Y tế 2008  
 
CÂU H ỎI LƯ ỢNG GIÁ  
1. Trong ch ấn thương ng ực, lo ại chấn thương nào sau đây là ch ấn 
thương đe d ọa tính m ạng ngay l ập tức 
A. Đụng dập phổi 
B. Mảng sư ờn di đ ộng 
C. Đụng dập tim đơn thu ần 
D. Tràn khí màng ph ổi áp l ực 
E. B,D 
F. A,C 
2. Trong Ép tim c ấp do tràn máu màng ngoài tim, bi ện pháp x ử trí nào 
sau đây  c ần phải được thực hiện trư ớc : 
A. Chọc hút d ẫn lưu màng ngoài tim  
B. Mở lồng ng ực cấp cứu 
C. Đánh giá và x ử trí đư ờng th ở hô hấp tuần hoàn  
D. Đặt đường truy ền TM trung tâm s ử dụng thu ốc vận mạch 
        3. Trong ch ấn thương ng ực, Bi ện pháp x ử trí nào sau đây không đư ợc 
tiến hành t ại khoa c ấp cứu : 
A. Mở màng ph ổi tối thiểu 
B. Mở ngực cấp cứu 
C. Rút v ật xuyên th ấu kh ỏi lồng ng ực 
D. Các th ủ thuật trên đ ều được tiến hành t ại khoa c ấp cứu 
 
 87 
 Bài 1 1 
CẤP CỨU CHẤN THƯƠNG B ỤNG 
 
MỤC TIÊU  
Sau khi h ọc xong h ọc viên có kh ả năng:  
1. Nêu đư ợc các tri ệu chứng lâm sàng g ợi ý ch ấn thương b ụng 
2. Mô t ả các bi ện pháp thăm dò c ấp cứu lâm sàng, c ận lâm sàng xác 
định ch ấn thương ổ bụng và nguyên t ắc thực hiện 
3. Nêu đư ợc các nguyên t ắc xử trí cấp cứu chấn thương b ụng kín, h ở 
 
NỘI DUNG  
I. ĐẠI CƯƠNG  
Các cơ quan trong ổ bụng không có h ệ thống khung xương che đ ỡ, nên 
rất dễ tổn thương trong ch ấn thương. Các t ạng đặc dễ bị chấn thương hơn các 
tạng rỗng tuy nhiên n ếu các t ạng rỗng bị tổn thương, d ịch đư ờng tiêu hóa s ẽ 
đi vào ổ bụng gây các bi ến chứng rất nặng như viêm phúc m ạc cấp, sốc nhi ễm 
khuẩn. 
Chấn thương b ụng có th ể là ch ấn thương kín ho ặc hở. Tại khoa c ấp cứu, 
chấn thương b ụng kín g ặp nhi ều hơn ch ấn thương b ụng hở, tuy nhiên  chấn 
thương b ụng kín cũng không kém ch ấn thương b ụng hở về mức độ nặng và t ỷ 
lệ tử vong.  
Chấn thương b ụng kín thư ờng d ễ bị bỏ sót n ếu có các ch ấn thương 
khác đi kèm như hôn mê do ch ấn thương s ọ não, gãy chi ch ảy máu nhi ều… 
Khi b ệnh nhân có ch ấn thương ng ực ở vùng th ấp ( t ừ 2 núm vú tr ở 
xuống) c ần nghĩ đ ến và ph ải loại trừ chấn thương b ụng đi kèm.  
Trong ch ấn thương b ụng kín, Lách là t ạng hay b ị tổn thương nh ất, sau 
đó đến gan và các t ạng khác theo th ứ tự sau: 
- Thận 
- Ruột non  
- Bàng quang  
- Đại tràng  
- Tụy  
II. CH ẨN ĐOÁN  
2.1. Triệu chứng lâm sàng  88 
 Bệnh nhân có y ếu tố chấn thương ( tai n ạn giao thông, ngã cao, tai n ạn 
lao đ ộng, xung đ ột…) đi kèm các tri ệu chứng lâm sàng sau c ần nghĩ đ ến chấn 
thương b ụng: 
2.1.1. Các tri ệu chứng ở bụng: 
- Đau b ụng, bu ồn nôn  
- Nôn ra máu  
- Phản ứng thành b ụng, c ảm ứng phúc m ạc 
- Bụng chư ớng 
- Co cứng cơ thành b ụng 
- Vết bầm tím xây sát thành b ụng 
- Vật xuyên th ấu bụng 
- Vết thương b ụng hở 
- Phòi t ạng ổ bụng ra ngoài  
2.1.2. Các d ấu hiệu ngoài b ụng gợi ý ch ấn thương b ụng 
- Triệu chứng m ất máu không phù h ợp với mức độ mất máu ngoài  
- Sốc không tương x ứng với mức độ chấn thương  
- Vết thương, ch ấn thương vùng th ấp của ngực 
- Gãy xương sư ờn 7-9 
- Chấn thương xương ch ậu 
2.2. Các thăm dò c ận lâm sàng  
2.2.1. Siêu âm ổ bụng cấp cứu: 
- Đây là thăm dò không xâm nh ập có th ể tiến hành ngay t ại khoa c ấp 
cứu 
- Có giá tr ị phát hi ện dịch, máu trong ổ bụng 
- Phát hi ện được tổn thương các t ạng đặc: gan, lách  
- Khó phát hi ện các thương t ổn cơ hoành, t ạng rỗng ho ặc tổn thương 
tụy. 
2.2.2. Siêu âm ch ấn thương nhanh  (Focused assessment with 
sonography for trauma, FAST)  
- Mục đích c ủa FAST là phát hi ện dịch tự do trong:  
+ Khoang gan th ận 
+ Khoang lách th ận 
+ Túi cùng Douglas  
+ Màng ngoài tim  89 
 - Ưu đi ểm: 
+ Nhanh, không xâm nh ập, có th ể tiến hành nhi ều lần 
+ Có th ể tiến hành t ại khoa c ấp cứu cho b ệnh nhân n ặng, nguy k ịch 
- Nhược điểm: ch ỉ phát hi ện được khi lư ợng máu/d ịch trong ổ bụng > 
100ml  
+ Kết quả âm tính không lo ại trừ được chảy máu trong  
+ Khó xác đ ịnh trong trư ờng hợp vướng hơi, béo phì  
- Bệnh nhân khô ng ổn định: 
+ FAST dương tính: m ở bụng ( phòng m ổ) 
+ FAST âm tính: tìm các ngu ồn chảy máu khác  
- Bệnh nhân ổn định: 
+ FAST dương tính: CT b ụng 
+ FAST âm tính: làm l ại sau 20 -30 phút  
2.2.3. Ch ọc rửa thăm dò ổ bụng 
- Tiến hành t ại phòng c ấp cứu: ch ọc rửa kín  
- Thường ch ỉ định khi không có các phương ti ện chẩn đoán khác như: 
Siêu âm, c ắt lớp vi tính  
- Trước khi ti ến hành th ủ thuật cần đặt sonde d ạ dày và sonde ti ểu 
- Vị trí ch ọc: đư ờng trắng gi ữa, dư ới rốn 0,5 cm  
- Nên ch ọc bằng catheter, rút kim sau khi đã lu ồn catheter vào ổ bụng 
- Nếu hút đư ợc > 10ml máu : dương tính  
- Nếu âm tính, bơm 1000 ml nư ớc mu ối sinh lý ấm vào ổ bụng sau đó 
hút d ịch ra g ửi xét nghi ệm. Ch ẩn đoán ch ảy máu trong ổ bụng khi có > 
100000 HC/ml ho ặc > 500 b ạch cầu/ml 
- Kết quả chọc rửa thăm  dò ổ bụng không lo ại trừ được các t ổn thương 
sau phúc m ạc và cơ hoành.  
2.2.4. Ch ụp x quang ng ực, bụng 
Có th ể phát hi ện:  
- Gãy xương sư ờn,  
- Tràn d ịch tràn khí màng ph ổi 
- Tổn thương xương ch ậu 
- Liềm hơi ổ bụng: v ỡ tạng rỗng ( ch ụp tư th ế đứng) 
2.2.5. C hụp cắt lớp vi tính ổ bụng 
- Có giá tr ị trong ch ẩn đoán ch ấn thương, nh ất là ch ấn thương b ụng kín.  90 
 - Cần cân nh ắc chỉ định ch ụp nếu bệnh nhân trong tình tr ạng huy ết 
động không ổn định. 
2.2.6. Các xét nghi ệm cấp: công th ức máu  (Hồng cầu, hematocrite, 
hemogl obine  ), khí máu, nhóm máu, nư ớc tiểu ( tìm h ồng cầu niệu)... 
III. X Ử TRÍ C ẤP CỨU 
3.1. Thăm khám thì đ ầu ( primary survey)  
Đánh giá và x ử trí theo trình t ự các bư ớc ABCD. Đánh giá nhanh (2 
phút), ti ến hành x ử trí ngay sau khi phát hi ện tổn thương và nh ắc lại đánh giá 
bất cứ lúc nào khi b ệnh nhân không ổn định. 
Airway (A): Đư ờng th ở 
- Xác đ ịnh có hay không t ắc ngh ẽn đường th ở.  
- Lưu ý t ổn thương đư ờng hô h ấp trên.  
- Nếu có t ắc ngh ẽn phải xử trí ngay, đ ảm bảo đường th ở thông thoáng.  
- Kiểm soát đư ờng th ở từ cơ bản đến nâng cao:  
+ Hút sạch máu đ ờm dãi, móc d ị vật 
+ Ưỡn cổ nhấc cằm ho ặc ấn hàm  
+ Đặt canuyl mi ệng hầu hoặc mũi h ầu 
+ Đặt Nội khí qu ản, mặt nạ thanh qu ản, ống kết hợp.  
Breathing (B): Hô h ấp 
- Phát hi ện và x ử trí ngay ngay các d ấu hiệu và nguyên nhâ n gây suy hô 
hấp cấp  
- Oxy li ệu pháp  : qua kính mũi ho ặc các lo ại mặt nạ 
- Hỗ trợ hô hấp :  
+ Bóp bóng qua m ặt nạ  
+ Thông khí nhân t ạo xâm nh ập và không xâm nh ập 
- Dẫn lưu d ịch, khí màng ph ổi nếu có ch ỉ định 
Circulation (C): Tu ần hoàn  
- Xử trí: ch ảy máu ngoà i ( nếu đi kèm ch ấn thương b ụng) 
+ Băng ép c ầm máu, garo.  
+ Bất động chi gãy  
- Xử trí sốc: 
+ Hồi sức dịch : đặt hai đư ờng truy ền lớn, truy ền dịch tinh th ể, dung 
dịch cao phân t ử, máu và các ch ế phẩm máu n ếu cần 
+ Đầu thấp chân cao, ủ ấm 91 
 + Đặt đường truy ền TM  trung tâm, dùng thu ốc vận mạch sau khi bù đ ủ 
dịch 
+ Đầu thấp chân cao, ủ ấm 
+ Đặt hai đư ờng truy ền tĩnh m ạch cỡ lớn (16 -18G) ho ặc đường truy ền 
trước xương chày  
+ Truy ền dịch tinh th ể, dịch cao phân t ử, máu và các ch ế phẩm máu 
nếu cần 
+ Đặt đường truy ền tĩnh m ạch trung tâm, truy ền dịch và theo dõi CVP  
+ Cân nh ắc sử dụng các thu ốc vận mạch khi bù đ ủ dịch mà không nâng 
được huy ết áp, tuy nhiên trong hoàn c ảnh ch ấn thương c ần tránh đ ể huyết áp 
tâm thu > 100 mm Hg vì có th ể làm tăng ch ảy máu  
+ Hội chẩn chuyên khoa ngo ại càng s ớm càng t ốt, chuy ển phòng m ổ để 
xử trí ch ảy máu trong  
Disability (D): Tình tr ạng th ần kinh  
- Điểm Glasgow  
- Đồng tử 
- Sử dụng kỹ thuật log-roll đánh giá toàn b ộ cột sống và các t ổn thương 
phía lưng  
 Exposure (E): B ộc lộ 
- Cởi bỏ quần áo b ệnh nhân khám t ừ đầu đến chân, không b ỏ sót tổn 
thương, nh ất là các v ết thương phía lưng, th ắt lưng  
- Giữ ấm 
- Giảm đau (n ếu cần) 
2. Thăm khám thì hai ( secondary survey)  
- Hỏi tiền sử, bệnh sử 
- Bộc lộ khám toàn thân  
- Mời chuyên khoa ngo ại hội chẩn 
- Tiến hành các thăm dò khác:  
+ Xét nghi ệm máu  
+ Siêu âm ổ bụng 
+ Chụp XQ ng ực, bụng 
+ CT ổ bụng 
+ Chọc rửa thăm dò ổ bụng 
- Chuy ển phòng m ổ theo ý ki ến chuyên khoa ngo ại 
- Vết thương phòi t ạng:   92 
 + Không đư ợc cố gắng nhét t ạng vào ổ bụng,  
+ Đắp gạc làm ẩm bằng nư ớc mu ối sinh lý vô khu ẩn, băng và chuy ển 
phòng m ổ 
- Vết thương xuyên th ấu ổ bụng:  
+ Không rút v ật xuyên th ấu ra kh ỏi bụng tại khoa c ấp cứu.  
+ Cố định ch ắc chắn vật xuyên th ấu và chuy ển phòng m ổ 
- Vết thương b ụng hở:  
+ Kích thư ớc vết thương không ph ản ánh đư ợc tổn thương bên trong  
+ Không thăm dò v ết thương t ại khoa c ấp cứu.  
+ Băng l ại, chuy ển phòng m ổ.  
+ Việc thăm dò v ết thương ph ải được tiến hành t ại phòng m ổ do các 
phẫu thu ật viên th ực hiện.  
TÀI LI ỆU THAM KH ẢO 
1. Heena P. Santry and Marc de Moya. T rauma Resuscitation. 
Penetrating Trauma. 2012  
2. Suresh Agarwal, Lejla Hadzikadic, and Peter Burke. Hypotensive 
Resuscitation  in Penetrating Trauma: Rules of the Game. Trauma 
Resuscitation. Penetrating Trauma. 2012  
3. John Bailitz, Faran Bokhari, Tom Scal etta, Jeffrey Scheider. 
Emergent Management of Trauma. 2011  
4. Barbara Aehlert . Paramedic Practice Today  above and beyond. 2010  
 
 
CÂU H ỎI LƯ ỢNG GIÁ  
1. Khi ch ẩn đoán ch ấn thương b ụng, thăm dò ổ bụng nào sau đây 
không đư ợc tiến hành ngay t ại khoa c ấp cứu 
A. Chọc rửa thăm dò ổ bụng 
B. FAST 
C. Thăm dò v ết thương b ụng hở 
D. Tất cả các bi ện pháp trên  
2. M ục tiêu x ử trí ch ấn thương b ụng tại khoa c ấp cứu là 
A. Chống sốc 
B. Xử trí bảo đảm ABC  
C. Lấy bỏ vật xuyên th ấu khỏi ổ bụng 
D. Chuy ển bệnh nhân vào phòng m ổ càng s ớm càng t ốt 93 
 E.A và B  
3. M ột bệnh nhân vào c ấp cứu với vết thương phòi ru ột ở bụng, b ệnh 
nhân kêu la d ữ dội, việc đầu tiên c ần làm là:  
A. Đánh giá và x ử trí ngay t ạng phòi ra kh ỏi ổ bụng 
B. Siêu âm ổ bụng cấp cứu 
C. Đánh giá và x ử trí ABC  
D. Chụp CT b ụng  
 
 
 
 
 
 
 
 
 
 
 
 
 
Bài 1 2 
CHẨN ĐOÁ N VÀ XỬ TRÍ CẤP CỨU BAN ĐẦU  
SỐC CHẤN THƯƠNG  Ở NGƯỜI LỚN  
MỤC TIÊU  
Sau khi h ọc xong h ọc viên có kh ả năng:  
1. Trình bày được các nguyên nhân gây sốc chấn thương  
2. Trình bày cơ chế bệnh sinh của sốc chấn thương và phân loại sốc 
mất máu  
3. Trình bày được chẩ n đoán sốc chấn thương  
4. Trình bày được các bước kiểm soát chấn thương  
 
NỘI DUNG  
   
  I. ĐẠI CƯƠNG  94 
   Sốc là một tình trạng giảm tưới máu tổ chức, với nhiều hiện lâm sàng như 
rối loạn huyết động và suy tạng. Ở cấp độ tế bào, sốc là hậu quả của thiếu hụt 
chuyển hóa cơ bản, đặc biệt là oxy dẫn tới chuyển hóa yếm khí.  
  Trong chấn thương, mất máu là nguyên nhân thường gặp nhất dẫn đến sốc. 
Các nguyên nhân tham gia vào thúc đẩy quá trình này gồm có thiếu oxy, tắc 
nghẽn cơ học (ép tim cấp, tràn khí màng phổi áp  lực), chấn thương cột sống 
cổ nặng và suy tim. Sốc là một nguyên thường gặp và có thể cứu sống được ở 
các bệnh nhân chấn thương và nguyên nhân gây tử vong đứng hàng thứ hai 
sau chấn thương sọ não trong chấn thương  
  II. SINH LÍ BỆNH VÀ PHÂN LOẠI  
  1. Sin h lí bệnh  
  Bất tương xứng giữa cung cấp và nhu cầu ô xy là cơ chế tiên phát của sốc. 
Đáp ứng bù trừ của sinh lí mất máu là cố gắng đảm bảo cung cấp oxy mô. 
Kích thích hệ thần kinh giao cảm dẫn đến tăng nhịp tim, co mạch và tăng co 
bóp cơ tâm thất.  
  Khi sốc diễn tiến, tưới máu các tạng quan trọng ( tim, não) được ưu tiên 
đảm bảo và giảm ở các cơ quan khác ( da, ruột, thận…). Nếu quá trình này 
không được khôi phục dẫn đến toan chuyển hóa nặng hơn, do tăng lactat máu, 
cùng với thiếu oxy là nguyên nhân dẫn đ ến mất khả năng co mạch ngoại vi và 
trụy mạch.  
  Hằng năm, trên toàn thế giới có hơn 2,5 triệu người chết do chấn thương 
nặng và các tai nạn giao thông. Hầu hết các trường hợp chết do chấn thương 
xẩy ra trong những giờ đầu sau chấn thương, 34 – 50% tử vong  xẩy ra tại các 
bệnh viện. Kiểm soát tối ưu chấn thương có thể làm giảm phòng tránh được 
tử vong lên đến 76%.  
  2. Phân loại. Theo Advanced Trauma Life Support (ATLS)  
  Chia sốc máu máu do chấn thương thành 4 loại với các đặc điểm nhấn 
mạch triệu chứng sớ m của tình trạng sốc. Lưu ý, Trong chấn thương huyết áp 
chỉ hạ thấp khi mất quá 30% thể tích máu của cơ thể.  
CHỈ 
SỐ ĐỘ I ĐỘ 
II ĐỘ 
III ĐỘ 
IV 
Lượn
g 
máu 
mất 
(ml) 1 < 
750 750-
1500  1500
-
2000  >200
0 
Lượn
g 
máu 
mất 
(%tổ< 
15% 15-
30% 30-
40% >40
% 95 
 ng 
lượn
g 
máu)  
Nhịp 
tim 
(lần/
phút)  < 
100 >100  >120  >140  
Huyế
t áp Bình 
thườ
ng Bình 
thườ
ng   
Áp 
lực 
mạch 
(mm
Hg) Bình 
thườ
ng 
hoặc 
    
Nhịp 
thở 
(lần/
phút)  14-
20 20-
30 30-
40 > 35 
Nước 
tiểu 
(ml/h
) >30 20-
30 5-15 Khôn
g 
đáng 
kể 
Ý 
thức Hơi 
lo 
lắng Lo 
lắng, 
kích 
thích  Kích 
thích 
và 
lẫn 
lộn Lú 
lẫn 
và lờ 
đờ 
Bù 
dịch Tinh 
thể Tinh 
thể Tinh 
thể 
và 
máu  Tinh 
thể 
và 
máu 
 
  III. TRIỆU CHỨNG LÂM SÀNG  
   1. Triệu chứng lâm sàng  
  Mất máu là nguyên nhân thường gặp nhất trong sốc chấn thương. Các vị trí 
có thể chảy máu nặng: trong  ổ bụng, khoang sau phúc mạc, khoang màng 
phổi và mất máu ra ngoài.  
  Phải nhận biết sốc chấn thương từ trước khi có dấu hiệu tụt huyết áp. Các 
dấu hiệu của sốc chấn thương tùy thuộc vào tốc độ, thể tích và thời gian chảy 96 
 máu. Ngoài ra còn có các triệu ch ứng cấp tính khác kèm theo như: tràn khí 
màng phổi, thiếu máu cơ tim  
- Các triệu chứng của mất máu:  
 + Mạch nhanh, nhỏ, huyết áp hạ  
 + Áp lực tĩnh mạch trung tâm thấp  
 + Da niêm mạc nhợt nhạt, lạnh. đầu gối có mảng tím nếu mất máu nhiều.  
 + Tim môi và đầu chi th ường khó thấy khi mất máu nhiều  
 + Khám lâm sàng để tầm soát các tổn thương, nguyên nhân và vị trí chảy 
máu: trong ổ bụng, trong cơ, khoang sau phúc mạc, màng phổi…  
- Các biểu hiện khác:  
  + Vật vã, lờ đờ, rối loạn ý thức, hôn mê. Các rối loạn ý thứ c có thể do sốc, 
cũng có thể do say rượu hoặc liên quan đến chấn thương sọ não  
  + Thở nhanh, khó thở, suy hô hấp  
  + Khát n ước, đái ít, vô niệu (lượng nước tiểu < 0,5 ml/kg/h)  
  + Hạ thân nhiệt  
  + Gãy xương….  
  Sốc chấn thương không do mất máu thường kh ó chẩn đoán ( ép tim cấp với 
tam chứng Beck: tụt huyết áp, tĩnh mạch cổ nổi và tiếng tim mờ thường biểu 
hiện muộn).  
  Tràn khí mạng phổi áp lực thường có biểu hiện: suy hô hấp, mất rì rào phế 
nang một bên, tràn khí dưới da, khí quản bị đẩy lệch về một bên , tụt huyết áp 
là hậu quả của giảm tiền gánh do chèn ép vào tĩnh mạch chủ dưới.  
  Ở những bệnh nhân chấn thương tủy cổ cao có thể gặp sốc thần kinh. Tụt 
huyết áp thường nhẹ, hậu quả của giảm trương lực mạch ngoại vi.  
  2. Cận lâm sàng  
  - Xét nghiệm công thức máu và hóa sinh cơ bản, bicarbonate và 
lactat máu.  
  - Siêu âm ổ bụng  
  - Xquang hoặc cắt lớp vi tính: ngực, bụng, khung chậu…  
  3. Chẩn đoán phân biệt  
  Mất máu là nguyên nhân thường gặp nhất trong sốc chấn thương. 
Cần phải chẩn đoán phân sốc mất máu  với: 
  - Ép tim cấp  
  - Tràn khí màng phổi áp lực  
  - Đụng dập phổi  
  - Nhồi máu cơ tim cấp  
  - Tắc mạch mỡ hoặc mạch hơi  
  IV. KIỂM SOÁT CH ẤN THƯƠNG  
1. Cấp cứu ngo ại viện 97 
 Vận chuy ển nhanh b ệnh nhân t ới bệnh vi ện là quan tr ọng và không làm 
mất thời gian v ào nh ững thao tác th ừa.  
- Ba nhi ệm vụ quan tr ọng cần phải làm:  
+ Đối với từng n ạn nhân: phát hi ện các ch ấn thương n ặng và ch ấn 
thương đe d ọa tính m ạng 
+ Đối với nhiều nạn nhân: Phân lo ại ( triage) các đi ều trị ngay l ập tức 
cứu sống nạn nhân  
+ Đảm bảo đường th ở, hô h ấp – tuần hoàn và v ận chuy ển tới bệnh vi ện 
đủ điều kiện chẩn đoán, đi ều trị đa ch ấn thương  
- Cần tìm ki ếm các tri ệu chứng gi ảm tưới máu t ừ trước khi có t ụt huy ết 
áp. 
2. Kiểm soát ban đ ầu sốc chấn thương  
- Nguyên t ắc điều trị: tập trung vào:  
+ Hồi phục thể tích lòng m ạch 
+ Thở oxy  
+ Cầm máu  
- Đánh giá và đi ều trị chấn thương ph ải được thực hiện đồng th ời (phác 
đồ). Đánh giá theo trình t ự A ( Airway), B (Breathing), C ( Circulation) và 
tình tr ạng ch ảy máu và can thi ệp ngay l ập tức: 
+ Nẹp cố định cột sống cổ 
+ Tối ưu hóa oxy máu  
+ Đặt đường truy ền lớn để truyền dịch  
+ Cầm máu  
+ Lấy máu làm xét nghi ệm và đ ịnh nhóm máu  
2.1. Cầm máu  
- Băng ép n ếu có ch ảy máu ra ngoài ho ặc dùng clam đ ể kẹp các m ạch 
máu khi nhìn th ấy, không k ẹp mù.  
- Garô đ ể cầm máu t rong c ắt cụt chi, đ ặc biệt khi các bi ện pháp khác 
không th ể cầm máu đư ợc. Để tránh thi ếu máu, ga rô ph ải được nới lỏng định 
kỳ ( sau m ỗi 45 phút).  
- Siêu âm đánh giá d ịch ổ bụng, tìm ngu ồn chảy máu. Siêu âm thay th ế 
cho ph ần lớn trư ờng hợp chọc rửa ổ bụng.  
- Gãy xương ch ậu mất vững và ch ấn thương m ạch máu là nguyên nhân 
dẫn đến sốc mất máu. B ất động cố định xương ch ậu để làm gi ảm ch ảy máu.  
2.2. Bù dịch  
- Bù 2000 ml dịch NaCl 0,9% qua đường ngoại vi ( kim luồn 16G ) 
hoặc catheter tĩnh mạch trung tâm. Ngoà i ra có thể dùng dung dịch cao phân 
tử.  
- Truyền ngay chế phẩm máu nếu có. Truyền máu với tỉ lệ huyết tương 
/ khối tiểu cầu / khối hồng cầu = 1/1/1  
- Mục tiêu của hồi sức dịch dựa vào đáp ứng của bệnh nhân. Huyết áp 
trung bình (HATB) khoảng 65mmHg và huyế t áp tâm thu khoảng 90 mmHg 98 
 trừ trường hợp có chấn thương sọ não kèm theo phải đưa HATB > 105 
mmHg và huyết áp tâm thu > 120 mHg.  
2.3. Thuốc vận mạch  
Sử dụng thuốc vận mạch sớm ngay từ đầu, khi chưa bù đủ dịch trong 
sốc mất máu thường làm nặng hơn.  
3. Kiểm soát sốc chấn thương không do mất máu  
- Tràn khí màng phổi:  thường có cả chấn thương ngực kín và chấn 
thương thấu ngực.  
+ Xử trí tràn máu hoặc tràn khí màng phổi do chấn thương:  đặt dẫn lưu 
lớn ( 36F)  
+ Xử trí tràn khí màng phổi áp lực có tụt huyết áp : ngay lập tức hút dẫn 
lưu khí bằng kim 12 hoặc 14 G, vị trí chọc khoang liên sườn 2 đường giữa 
đòn. 
- Ép tim cấp: có thể do chấn thương thấu ngực hoặc chấn thương ngực 
kín nặng  
+ Chẩn đoán : siêu âm tại giường có thể thực hiện ngay lập tức, nhanh 
chóng và  chính xác.  
+ Xử trí: chọc tháo dịch màng tim. Khi khôi phục được huyết áp, tình 
trạng lâm sàng cải thiện cần chỉ định mở ngực cấp cứu để dẫn lưu máu 
khoang màng tim  
4. Theo dõi: Đảm bảo các chỉ số:   
- Huyết áp: HATV > 65 mmHg trong chấn thương hở và > 10 5 mmHg 
đối với chấn thương kín.  
- Nhịp tim: 60 – 100 lần/ phút  
- Bão hòa oxy ( SPO 2): > 94%.  
- Nước tiểu: duy trì > 0,5 ml/kg/h  
- CVP: 8 – 12 mmHg  
- Lactat , kiềm thiếu hụt và độ bão hòa oxy máu tĩnh mạch trộn: theo 
dõi mỗi 4h để đảm bảo tưới máu tạng th ích hợp hoặc cải thiện khi hồi sức.  
- Truyền máu:  
+ Truyền 2 đơn vị khối hồng cầu nếu hemoglobin (Hb) < 80g/l nếu 
bệnh nhân không có nguy cơ mạch vành cấp hoặc nếu Hb < 100 g/l nếu có 
nguy cơ bệnh mạch vành cấp  
+ Truyền một khối tiểu cầu máy hoặc 6 đơn vị  tiểu cầu thường khi tiểu 
cầu < 50 G/l  
+ Truyền 2 đơn vị huyết tương tươi động lạnh khi INR > 2  
+ Truyền 10 đơn vị cryo nếu fibrinogen < 100 mg/dl  99 
  
TÀI LI ỆU THAM KH ẢO 
1. Garcia A . Critical care issues in the early management of severe 
trauma. Surg Clin North Am.  2006 Dec;86(6):1359 -87. 
2. Christoph er Colwell. Initial evaluation and management of shock in 
adult trauma. Uptodate 2013  
CÂU H ỎI LƯ ỢNG GIÁ  
 
Câu 1 . Chẩn đoán s ốc chấn thương d ựa vào:  
A. Tụt huy ết áp 
B. Da lạnh và n ổi vân tím  
C. Nước tiểu dưới < 0,5 ml/kg/h  
D. Tất cả các đi ều trên  
Câu 2 . Chẩn đoán phân bi ệt sốc mất máu trong ch ấn thương:  
  Ép tim cấp  
  A. Tràn khí màng phổi áp lực  
  B. Đụng dập phổi  
  C. Nhồi máu cơ tim cấp  
  D. Tắc mạch mỡ hoặc mạch hơi  
  E. Tất cả các ý trên  
Câu 3.  Kiểm soát ban đầu sốc chấn thương  
        A. Hồi phục thể tích lòng m ạch 
       B. Thở oxy  
       C. Cầm máu  
Câu 4.  Mục tiêu của hồi sức dịch  
A. Huyết áp trung bình (HATB) ≥ 65mmHg  
B. HATB > 105 mmHg và huyết áp tâm thu > 120 mHg  
C. HATB ≥ 105 mmHg và huyết áp tâm thu ≥ 120 mmHg khi có chấn 
thương sọ não  
D. a và c 
 
 
 
 
 
 100 
  
 
Bài 1 3 
CẤP CỨU CHẤN THƯƠNG XƯƠNG, MÔ M ỀM VÀ CHI TH Ể ĐỨT RỜI 
 
MỤC TIÊU  
Sau khi h ọc xong h ọc viên có kh ả năng:  
1. Nêu đư ợc các nguyên t ắc chung x ử trí cấp cứu gãy xương  
2. Mô t ả một số biện pháp c ố định các xương gãy và nguyên t ắc xử trí 
cấp cứu chấn thương xương ch ậu 
3. Nêu đư ợc các bư ớc xử trí cấp cứu vết thương đ ứt rời 
4. Mô t ả triệu chứng lâm sàng và nêu đư ợc nguyên t ắc xử trí cấp cứu 
hội chứng chèn ép khoang  
 
NỘI DUNG  
I. ĐẠI CƯƠNG  
Chấn thương xương và mô m ềm có b ệnh cảnh rất đa d ạng: 
- Chấn thương khu trú: gãy m ột chi, rách, d ập nát cơ c ủa một chi 
- Đa ch ấn thương: gãy xương ch ậu, xương đùi k ết hợp với chấn thương 
ngực bụng, s ọ não…  
- Chấn thương xương k ết hợp chấn thương mô m ềm ở một hoặc nhi ều 
vị trí 
- Chấn thương xương: gãy xương kín, h ở, trật khớp, sai kh ớp 
- Chấn thương mô m ềm: rách, d ập nát cơ và t ổ chức, vết thương đ ứt rời, 
hội chứng khoang  
Phạm vi bài này ch ủ yếu đề cập đến chấn thương xương và mô m ềm ở 
chi, gãy xương đùi và gãy xương ch ậu. Đối với chấn thương xương đ ầu, cột 
sống tham kh ảo phần chấn thương s ọ não và ch ấn thương c ột sống. 
II. GÃY XƯƠNG  
2.1. Nguyên t ắc đánh giá và x ử trí cấp cứu bệnh nhân ch ấn thương 
xương  
- Bất động cột sống cổ 
- Đánh giá và x ử trí Đư ờng th ở – Hô h ấp – Tuần hoàn (ABC)  
- Cầm máu n ếu có ch ảy máu ngoài: băng ép, garô  
 101 
  
 
Xương sư ờn  125 ml  
Xương quay ho ặc 
trụ  250 – 500 
ml 
Xương cánh tay   500 – 750 
ml 
Xương chày, mác   500 – 
1000 ml  
Xương đùi   1000 – 
2000 ml  
Xương ch ậu  1500 - 
3000ml   
Lượng máu có th ể mất trong các lo ại gẫy xương  
- Chống sốc: 
+ Đầu thấp chân cao, ủ ấm 
+ Đặt hai đư ờng truy ền tĩnh m ạch cỡ lớn (16 -18G) ho ặc đường truy ền 
trước xương chày  
+ Truy ền dịch tinh th ể, dịch cao phân t ử hoặc máu, và các ch ế phẩm 
máu 
- Khám ch ấn thương toàn thân, không b ỏ sót tổn thương  
- Bất động chi gãy  
- Giảm đau  
- Làm các xét nghi ệm thư ờng quy, t ại giường: công th ức máu, sinh hóa  
- Khi tình tr ạng bệnh nhân cho phép, ti ến hành các xét nghi ệm và thăm 
dò khác: XQ, siêu âm, c ắt lớp vi tính..  
- Hội chẩn chuyên khoa ch ấn thương, bó b ột hoặc phẫu thu ật nếu có ch ỉ 
định 
2.2. G ãy xương  
- Các d ấu hiệu gãy xương:  
+ Biến dạng chi  
+ Gập góc, m ất cấu trúc gi ải phẫu 
+ Bầm tím d ập nát chi  
+ Ngắn chi  
+ Sưng n ề 102 
 + Đau chói, m ất vận động 
+ Sờ nắn tăng c ảm giác đau, có ti ếng lạo xạo 
+Trong gãy xương h ở, có th ể thấy đầu xương l ộ ra ngoài ổ gãy 
- Xử trí: ngoài các nguyên t ắc xử trí chung nêu trên c ần tiến hành b ất 
động chi gãy, gi ảm đau, ch ụp XQ xác đ ịnh tổn thương sau đó h ội chẩn 
chuyên khoa ngo ại chấn thương đ ể quyết định bi ện pháp đi ều trị. 
- Nguyên t ắc cố định chi gãy  
+ Đánh giá: m ạch cảm giác v ận động của chi trư ớc và sau khi c ố định 
+ Bộc lộ, đánh giá (có th ể chụp ảnh) vùng t ổn thương trư ớc khi c ố định 
+ Gãy xương: b ất động 1 kh ớp trên và 1 kh ớp dưới xương gãy  
+ Tổn thương kh ớp: bất động xương trên và dư ới khớp tổn thương  
+ Rửa sạch, băng  ép, c ầm máu v ết thương xương kh ớp hở trước khi c ố 
định 
+ Không c ố nhét ph ần xương h ở trở lại vào trong da  
+ Bất động chi gãy ở tư th ế chức năng ho ặc tư th ế bệnh nhân th ấy dễ 
chịu 
+ Nếu chi b ị biến dạng, g ập góc nhi ều, không b ắt được mạch dư ới vị trí 
tổn thương, chi tím, l ạnh có th ể kéo n ắn trở lại tư th ế giải phẫu trư ớc khi c ố 
định. N ếu phải nắn chi tr ở lại tư th ế giải phẫu, cần dùng thu ốc giảm đau, dãn 
cơ vừa nắn vừa kéo dãn. Khi kéo c ần dùng l ực nhẹ nhàng, không c ố nắn khi 
bị vướng ho ặc bị mắc.  
+ Nẹp cố định cần được đệm lót êm đ ặc biệt ở hai đ ầu nẹp 
+ Nhấc cao chi sau khi đã b ất động ( n ếu không có ch ống ch ỉ định) 
- Gãy xương, kh ớp hở 
+ Rửa sạch vết thương b ằng nư ớc mu ối sinh lý vô khu ẩn, cắt lọc nếu 
cần 
+ Băng ép c ầm máu, n ếu băng ép không c ầm đư ợc máu t iến hành garo 
phía trên t ổn thương  
+ Chụp ảnh ho ặc ghi chép l ại tổn thương  
+ Băng kín v ết thương h ở 
+ Đánh giá m ạch cảm giác, v ận động của chi b ị thương  
+ Nắn trở lại tư th ế giải phẫu (nếu có th ể)  
+ Nếu có các v ật xuyên th ấu vào chi, xương, ổ khớp, không  được rút ra 
tại khoa c ấp cứu, cố định ch ắc, chuy ển xử lý tại phòng m ổ 
+ Bất động bằng các phương ti ện cố định 
+ Đánh giá l ại mạch cảm giác, v ận động 103 
 + Tiêm phòng u ốn ván và kháng sinh d ự phòng  
+ Hội chẩn chuyên khoa ngo ại càng s ớm càng t ốt 
2.3. Cố định m ột số gãy xương thư ờng gặp 
2.3.1.  Bất động xương đòn và xương b ả vai: Dùng băng thun r ộng 10 -
12cm băng c ố định 2 xương đòn b ắt chéo sau lưng như hình s ố 8. 
 
 
Băng s ố tám c ố định xương đòn  
2.3.2.  Cố định xương sư ờn: nếu chỉ gãy xương sư ờn đơn thu ần, không 
có mảng sư ờn di đ ộng, không có ch ấn thương ng ực. Ch ỉ cần giảm đau cho 
bệnh nhân, vào vi ện theo dõi, xu ất viện sau khi có ý ki ến hội chẩn chuyên 
khoa ngo ại.  
2.3.3.  Cố định xương cánh tay:  
- Đặt hai n ẹp 
+ 1 nẹp bên trong, đ ầu trên lên t ới hố nách, đ ầu dưới quá khu ỷu tay.  
+ 1 nẹp bên ngoài, đ ầu trên quá m ỏm vai, đ ầu dưới quá khu ỷu tay  
- Sau đó băng c ố định lại buộc ép cánh tay vào ngư ời. 
- Dùng băng tam giác treo tay n ạn nhân và bu ộc cố định vào trư ớc ngực, 
 
Cố định xương cánh tay  
2.3.4.  Cố định xương c ẳng tay  
+ Nếu khớp khu ỷu co đư ợc, để cánh tay sát thân mình, c ẳng tay vuông 
góc v ới cánh tay, sau đó b ất động 
+ Nếu khớp khu ỷu không co đư ợc, để cánh c ẳng tay th ẳng, sau đó c ố 
định  104 
  
  
 
Cố định xương c ẳng tay  
 
2.3.5.  Cố định cổ tay, bàn tay  
  
 
 
2.3.6.  Cố định xương ngón tay  
 
 
 
2.3.7.  Cố định xương c ẳng chân  
+ Đặt 2 nẹp ở mặt trong và m ặt ngoài chi gãy, đi t ừ giữa đùi t ới quá c ổ 
chân. N ếu có n ẹp thứ 3 thì đ ặt ở mặt sau c ẳng chân  
+ Băng cố định nẹp vào chi ở bàn c ổ chân, dư ới và trên kh ớp gối, giữa 
đùi. 105 
 
  
 
Bất động xương c ẳng chân b ằng nẹp 
 
2.3.8.  Cố định gãy xương đùi: Dùng 3 n ẹp để cố định 
+ Nẹp ở mặt ngoài đi t ừ hố nách đ ến quá gót chân.  
+ Nẹp ở mặt trong đi t ừ bẹn đến quá gót chân  
+ Nẹp ở mặt sau đi t ừ trên mào ch ậu đến quá gót chân  
+ Băng c ố định nẹp vào chi ở bàn chân, c ổ chân, 1/3 trên c ẳng chân, 
trên g ối, bẹn, bụng và dư ới nách.  
+ Buộc chi gãy đã c ố định vào chi lành  
 
 
Bất động xương đùi b ằng nẹp 
 
 
 
Nếu không b ắt được mạch dư ới chỗ tổn thương, ph ải dùng n ẹp kéo liên 
tục ( nẹp thomas, Sager, hare)  106 
 
  
  
 
Nẹp Hare   Nẹp Sager   Nẹp Thomas  
2.4. Ch ấn thương xương ch ậu 
- Vỡ xương ch ậu là m ột chấn thương n ặng thư ờng nằm trong b ệnh cảnh 
đa ch ấn thương.  
- Lượng máu m ất do v ỡ xương ch ậu có th ể rất lớn ( có th ể tới 3000ml 
hoặc hơn) vì v ậy nguy cơ s ốc mất máu r ất cao  
- Tỷ lệ tử vong trong ch ấn thương xương ch ậu kèm s ốc mất máu có th ể 
lên tới 50%, vì v ậy việc đánh giá và  hỗ trợ tuần hoàn có vai trò c ực kỳ quan 
trọng 
- Các tri ệu chứng gợi ý ch ấn thương khung ch ậu 
+ Đau vùng h ạ vị, tiểu khung, đau xương ch ậu 
+ Vết bầm tím quanh r ốn 
+ Vết bầm tím d ọc hai bên sư ờn 
+ Sờ nắn khung ch ậu có đi ểm đau chói,  
+ Ép nh ẹ 2 cánh ch ậu: đau, m ất vững 
+ Thăm tr ực tràng, âm đ ạo có máu  
+ Niệu đạo rỉ máu 
- Mục tiêu x ử trí gãy xương ch ậu tại khoa c ấp cứu: 
+ Hồi sức ABCD, đ ặc biệt lưu ý h ỗ trợ tuần hoàn ch ống sốc truy ền 
máu s ớm nh ất có th ể 
+ Khám ch ấn thương toàn di ện, không b ỏ sót các t ổn thương khác  
+ Bất động khung ch ậu bằng cách s ử dụng m ột tấm vải ( có th ể lấy ga 
trải giư ờng gấp lại có b ề rộng bằng kho ảng cách t ừ gai ch ậu trư ớc trên đ ến 
xương mu) qu ấn quanh khung ch ậu và bu ộc chặt. 
+ Hội chẩn chuyên khoa ch ấn thương, chuy ển ph ẫu thu ật càng s ớm 
càng t ốt khi có ch ỉ định 107 
 
 
2.5 H ội chứng khoang  
- Hội chứng chèn ép khoang ( g ọi tắt là h ội chứng khoang) là tình tr ạng 
tăng cao áp l ực trong m ột khoang gi ải phẫu dẫn đến sự suy gi ảm tuần hoàn và 
thiếu máu c ục bộ trong khoang, n ếu kéo dài gây ra các thươn g tổn của các 
tạng trong khoang.  
- Khi nh ắc đến hội chứng khoang, ngư ời ta thư ờng nghĩ đ ến hội chứng 
khoang ở chi do chèn ép gi ữa các l ớp cân m ạc gây t ổn thương cơ và th ần kinh 
ở trong khoang. Tuy nhiên h ội chứng khoang còn có th ể xuất hiện ở khoang 
màng phổi, màng tim, màng b ụng. Trong ph ạm vi bài này ch ỉ đề cập đến hội 
chứng khoang ở chi liên quan đ ến chấn thương  
- Nguyên nhân thư ờng gặp: 
+ Băng, n ẹp, bó b ột quá ch ặt 
+ Chảy máu trong khoang do v ết thương m ạch máu  
+ Bỏng 
+ Viêm sưng t ấy các bó cơ  
+ Tổn thương ph ối hợp gãy xương, ch ấn thương rách cơ…  
- Mốc thời gian  
+ Chèn ép khoang c ấp tính có th ể xuất hiện từ giờ thứ hai đ ến 6 ngày 
sau ch ấn thương  
+ Chèn ép khoang kéo dài 6 gi ờ đủ để gây ho ại tử cơ  
+ Thời gian gi ải ép mà v ẫn giữ được chi an toàn là trong k hoảng 6-13 
giờ.  
+ Sau 15 -36 gi ờ, phẫu thu ật giải chèn ép không an toàn, thư ờng dễ gây 
biến chứng 
+ Sau 36 gi ờ thường ph ải cắt cụt chi 
- Dấu hiệu lâm sàng  
+ Đau nhức tự nhiên khu trú ở vùng khoang b ị chèn ép, v ới tính ch ất 
đau d ữ dội, như có m ạch đập, dai d ẳng. Không đáp ứng với các lo ại thu ốc 108 
 giảm đau, b ất động chi gãy không làm gi ảm đau. V ận động làm căng cơ gây 
tăng đau  
+ Sưng , căng ph ồng vùng b ị chèn ép, s ờ chạm vào gây đau d ữ dội.  
+Tê bì  vùng da do dây th ần kinh n ằm trong khoang chi ph ối, sau đó 
giảm cảm giác và m ất cảm giác (d ấu hiệu mu ộn) 
+ Da vùng chi tái 
+Không b ắt được mạch dưới vùng t ổn thương (d ấu hiệu mu ộn) 
- Nguyên t ắc xử trí hội chứng chèn ép khoang t ại khoa c ấp cứu 
+ ABCDE  
+ Chẩn đoán s ớm hội chứng khoang  
+ Tháo ho ặc nới băng, n ẹp, bột quá ch ặt 
+ Giữ chi ở ngang m ức tim  
+ Kháng sinh d ự phòng  
+ Giảm đau  
+ Điều trị và theo dõi h ội chứng tiêu cơ vân c ấp 
+ Hội chẩn chuyên khoa ngo ại, rạch cân cơ gi ảm áp càng s ớm càng t ốt 
khi có ch ỉ định  
2.5. Trật khớp 
- Lâm sàng  
+ Liên quan đ ến chấn thương  
+ Đau, sưng vùng b ị tổn thương  
+ Khớp bị tổn thương m ất vận động. 
+ Dấu hiệu lò xo: khi làm động tác thụ động thay đổi tư thế biến dạng 
của chi, khi buông tay ra thì vị trí chi thể lại trở lại tư thế biến dạng ban đầu  
+ Dấu hiệu biến dạng: Thay đ ổi hình dáng ở các khớp, đây là d ấu hiệu 
chắc chắn dễ nhận biết và r ất có giá tr ị trong ch ẩn đoán.  
+ Ổ khớp rỗng. 
- Nguyên t ắc xử trí: 
+ Đánh giá và b ảo đảm ABC  
+ Cố định như c ố định xương gãy  
+ Tiến hành các xét nghi ệm và thăm dò ch ẩn đoán hình ảnh để chẩn 
đoán xác đ ịnh và  đưa ra k ế hoạch đi ều trị 
+ Giảm đau  
+ Hội chẩn chuyên khoa và n ắn chỉnh kh ớp sớm 
III. X Ử TRÍ V ẾT THƯƠNG Đ ỨT RỜI 109 
 3.1. Phân lo ại 
- Vết thương đ ứt rời hoàn toàn: ph ần chi đ ứt rời và m ỏm cụt hoàn toàn 
không có b ất cứ cấu trúc gi ải phẫu nào liên k ết với nhau  
 
Vết thương đ ứt rời hoàn toàn  
- Vết thương đ ứt rời không hoàn toàn: ph ần chi đ ứt rời và m ỏm cụt còn 
cấu trúc gi ải phẫu nối với nhau: xương, cân cơ…  
 
Vết thương đ ứt rời không hoàn toàn  
 
3.2. X ử trí cấp cứu chung:  
- Bảo đảm ABC  
- Đặt hai đư ờng truy ền lớn hỗ trợ tuần hoàn, ch ống sốc 
- Kháng sinh d ự phòng  
- Tiêm phòng u ốn ván  
- Xét nghi ệm, thăm dò ch ẩn đoán hình ảnh khi tình tr ạng bệnh nhân 
cho phép  
- Hội chẩn chuyên khoa ngo ại chấn thương x ử trí tiếp: ghép da, khâu, 
nối chi…  
3.3. X ử trí cấp cứu ph ần mỏm cụt: 
- Cầm máu b ằng cách băng ép ho ặc garo  
- Dùng nư ớc muối sinh lý vô khu ẩn rửa sạch m ỏm cụt 
- Cắt lọc nếu bẩn hoặc dập nát nhi ều 110 
 - Đắp gạc tẩm nư ớc mu ối sinh lý vô khu ẩn, băng kín m ỏm cụt 
- Chườm lạnh đầu mỏm cụt (không đ ể đá tiếp xúc tr ực tiếp với mỏm 
cụt) 
3.4. X ử trí ph ần chi th ể đứt rời: 
- Rửa sạch bằng nư ớc mu ối sinh lý vô khu ẩn 
- Quấn gạc tẩm nư ớc mu ối sinh lý vô khu ẩn 
- Bỏ vào túi nilon s ạch dán kín  
- Bỏ toàn b ộ túi nilon trên vào ch ậu nước đá 
- Chuy ển ghép n ối chi ( phòng m ổ hoặc chuy ển tuy ến trên)  
3.5. V ết thương c ắt cụt không hoàn toàn:  
- Cầm máu: băn g ép, garo  
- Rửa sạch bằng nư ớc mu ối sinh lý vô khu ẩn 
- Đặt lại tư th ế giải phẫu 
- Đắp gạc tẩm nư ớc mu ối sinh lý vô khu ẩn, băng kín  
- Nẹp bất động 
TÀI LIỆU THAM KHẢO  
1. Dave Hehemann, Mark Hardy. Keys to Optimal Management of 
Open Fractures. American Coll ege of Foot and Ankle Surgeons. 2010  
2. Anthony Brown and Michael Cadogan. Orthopaedic Emergency. 
2011  
3. Guideline for essential trauma care WHO 2004  
4. Aneel Bhangu, Caroline Lee, and Keith Porter. Emergencies in 
Trauma. Oxford University Press, 2010  
 
CÂU HỎI LƯỢNG GIÁ  
1. Bi ện pháp x ử trí cấp cứu nào sau đây không đư ợc tiến hành khi x ử 
trí vết thương xương h ở 
A. Sử dụng kháng sinh d ự phòng  
B. Kéo n ắn chi gãy tr ở lại tư th ế giải phẫu 
C. Sát khu ẩn vết thương h ở bằng Povidin 10%  
D. Rửa sạch vết thương h ở bằng nư ớc mu ối sinh lý 0,9%  
2. Ch ọn biện pháp c ấp cứu đúng nh ất để bảo quản phần chi th ể đứt rời 
A. Cho vào túi nilon s ạch, b ọc lại, cho vào ch ậu nước đá 
B. Ngâm vào nư ớc mu ối sinh lý 0,9% b ảo quản ở nhiệt độ 4-8 độ C 111 
 C. Quấn gạc tẩm nư ớc mu ối sinh lý 0.9% v ô khu ẩn, bỏ vào túi 
nilon, cho vào ch ậu nư ớc đá 
D. Quấn gạc vô khu ẩn, cho vào ch ậu nước đá 
3. Vỡ xương ch ậu là m ột chấn thương có nguy cơ đe d ọa tính m ạng 
bệnh nhân ngay l ập tức vì lý do nào sau đây:  
A. Gây đau nhi ều 
B. Gây viêm phúc m ạc 
C. Sốc mất máu  
D. Khó h ồi phục 112 
 Bài 1 4 
XỬ TRÍ C ẤP CỨU BỆNH NHÂN B ỎNG 
 
MỤC TIÊU  
Sau khi h ọc xong h ọc viên có kh ả năng:  
1. Trình bày đư ợc các nguyên nhân gây b ỏng. 
2. Đánh giá đư ợc tình tr ạng nguy k ịch của bệnh nhân t ại khoa c ấp cứu. 
3. Phân đ ộ nặng của bỏng (di ện tích, đ ộ sâu, v ị trí). 
4. Nắm đư ợc cách x ử trí cấp cho b ệnh nhân b ỏng tại khoa c ấp cứu.  
 
NỘI DUNG  
1. Đại cương  
- Bỏng đư ợc xem như m ột loại chấn thương trên da hay các mô khác. 
Bỏng xu ất hiện khi m ột vài hay t ất cả các t ế bào b ị tiêu di ệt bởi: sức nóng, 
lạnh, đi ện, phóng x ạ, hay các tác nhân hóa h ọc khác.  
- Cấp cứu bệnh nhân b ỏng bao g ồm: đánh giá d ấu hiệu nguy k ịch tới 
tính m ạng bệnh nhân, đánh giá t ổn thương b ỏng, sơ c ứu và c ấp cứu.  
2. Ch ẩn đoán  
2.1. Nguyên nhân gây b ỏng 
2.1.1. B ỏng do nóng:  bệnh nhân ti ếp xúc với dụng cụ chứa chất nóng b ị 
vỡ, chất lỏng nóng, nh ững vật dụng nóng, hơi nóng…  
2.1.2. B ỏng do l ạnh: do tiếp xúc v ới băng đá làm b ỏng tế bào. 
2.1.3. B ỏng do hóa ch ất: bệnh nhân ti ếp xúc v ới một số loại hóa ch ất: 
acid, ki ềm mạch ho ặc iod, phospho dùng tro ng công nghi ệp vôi tôi…  
2.1.4. B ỏng do đi ện: điện giật, sét đánh.  
2.1.5. B ỏng do hít:  xảy ra khi có các v ụ nổ hay hít ph ải các hơi máy.  
2.1.6. B ỏng do phóng x ạ: năng lư ợng phóng x ạ hay các phóng x ạ gây 
ra bỏng thư ờng gặp là "b ỏng m ặt trời".  
2.2. Đánh gi á tình tr ạng nguy k ịch do b ỏng gây ra  
- Ý thức: tỉnh táo, ho ảng hốt, lo âu, s ợ hãi, đau đ ớn, vật vã, hôn mê.  
- Thần kinh: co gi ật 
- Hô h ấp: nạn nhân b ị bỏng vùng m ặt, cổ nhất là khi b ị kẹt trong nhà b ị 
cháy d ễ bị phù m ặt cổ và các bi ến chứng đư ờng hô h ấp do hít ph ải khói, hơi, 
khí đ ộc (xem xét s ự thông thoáng đư ờng hô h ấp, dị vật chấn thương đư ờng hô 
hấp kèm theo, đánh giá tình tr ạng hô h ấp, SpO 2… 113 
 - Tuần hoàn: tình tr ạng sốc: mạch nhanh, huy ết áp t ụt, dấu hiệu giảm tưới 
máu.  
2.3. Đánh giá đ ộ nặng của vùng bỏng: theo Wallace  
- Đầu 9%  
- Thân mình: trư ớc 18%; thân minh sau 18%  
- Chi trên 9%; chi dư ới 18%  
- Bộ phận sinh d ục ngoài 1%.  
2.4. Ch ẩn đoán đ ộ sâu c ủa bỏng 
Độ 1: đỏ da, đau (như cháy n ắng) rát do đ ầu mút dây th ần kinh b ị kích 
thích, lo ại bỏng này thư ờng lành h ẳn sau 3 ngày.  
Độ 2a (nông) ph ỏng nư ớc lan r ộng kh ắp bề mặt vết bỏng, đau nhi ều, rỉ 
nước. 
Độ 2b (sâu): đau ít hơn đ ộ 2a, có vùng tê, t ổn thương da dính ch ặt bề 
mặt, ấn kính (+). S ẹo hình thành trong 3 tu ần, có th ể sẹo sâu, ho ặc sẹo lồi xấu.  
Độ 3: vùng b ỏng tr ắng bóng, đ ỏ tươi ho ặc nâu không đau, vùng t ổn 
thương bám ch ặt, cần phải ghép da.  
Cần chú ý nh ững vùng t ổn thương b ị che khu ất, xác đ ịnh nguyên nhân 
gây b ỏng: b ỏng đi ện, hóa ch ất, nước sôi, l ửa. 
Bỏng hóa ch ất: tiên lư ợng ph ụ thuộc vào vi ệc rửa sớm, bỏng m ắt phải 
được chuy ển ngay cho chuyên ngành m ắt. 
3. Xử trí 
3.1. Nguyên t ắc xử trí 
- Đảm bảo các bư ớc A, B, C… trong x ử trí cấp cứu ngư ời bệnh 
- Nhanh chóng lo ại trừ các tác nhân gây b ỏng ra kh ỏi cơ th ể nếu còn  
- Hạn ch ế tối thiểu mức độ nhiễm bẩn cho v ết bỏng, băng bó v ết 
thương, v ận chuy ển đến chuyên khoa b ỏng. 
3.2. Các bư ớc  
3.2.1. Bư ớc 1: nhanh chóng lo ại trừ các tác nhân gây b ỏng ra kh ỏi cơ 
thể nạn nhân (n ếu cần): xé b ỏ quần áo đang cháy âm ỉ hoặc bị thấm đẫm nư ớc 
nóng, xăng, d ầu, hóa ch ất.  
- Bọc vùng b ỏng ch ắc chắn rồi đổ nước lạnh lên  
- Tháo b ỏ những v ật cứng trên vùng b ỏng như gi ầy, ủng, vòng nh ẫn 
trước khi v ết bỏng sưng n ề. 
- Che ph ủ vùng b ỏng bằng đắp gạc vaseline  
3.2.2. Bư ớc 2: cấp cứu đảm bảo các ch ức năng s ống 114 
 * Đảm bảo hô h ấp: đảm bảo sự thông thoáng đư ờng th ở tùy theo tình 
trạng suy hô h ấp có th ể phải: thở oxy mũi mask, đ ặt ống nội khí qu ản, nếu suy 
hô hấp nặng hơn ho ặc rối loạn ý th ức, thông khí nhân t ạo…  
* Đảm bảo tuần hoàn:  
- Đặt đường truy ền tĩnh m ạch đủ lớn, tốt nhất là ống thô ng tĩnh m ạch 
trung tâm.  
- Đảm bảo thể tích tu ần hoàn: natri clorua 0,9%, dung d ịch keo, 
albumin 5%, dung d ịch ringerlactat, lưu ý c ần đảm bảo tuần hoàn ngay trong 
1 - 3 giờ đầu. 
- Theo dõi m ạch, HA, nư ớc tiểu là theo gi ờ là thông s ố quan tr ọng nh ất 
bù đủ thể tích (ph ải đảm bảo ≥ 1ml/kg/gi ờ). 
- Với những b ệnh nhân t ỉnh táo, không b ị nôn và không có nh ững 
chống ch ỉ định do ch ấn thương khác thì có th ể cho b ệnh nhân l ấy nước theo 
nhu c ầu (nư ớc sạch, dung d ịch oresol, nư ớc hoa qu ả tươi…).  
* Các bi ện pháp c ấp cứu khác  
+ An th ần, giảm đau: n ếu bỏng gây đau nhi ều thư ờng dùng morphin tiêm 
dưới da xa nơi b ỏng, b ỏng rộng, đau nhi ều có th ể tiêm tĩnh m ạch (lưu ý đ ảm bảo 
hô hấp). 
+ Kháng sinh: c ần đặt ra, chú ý nguy cơ nhi ễm trùng y ếm khí: các 
kháng sinh có th ể dùng: Amo xicillin/clavulanat, n ếu bỏng rộng, sâu nên cho 
cephalosporin, aminoglycosid, carbapeneur, fluoroquinolon.  
+ Dự phòng loét đư ờng tiêu hóa do stress: (dùng ức chế H2, PPI S). 
+ Bỏng do cháy, có r ối loạn ý th ức, có t ổn thương ti ểu cầu tiêm vitamin 
B12 sau khi  lấy máu đ ịnh lư ợng CO và CN  
3.2.3. X ử trí cấp cứu vết bỏng 
- Băng ch ỗ bỏng bằng băng vô khu ẩn: có th ể dùng g ạc vô khu ẩn băng 
lại để hạn chế chỗ mất nhiệt của bệnh nhân.  
- Bỏng sâu: R ạch ra b ỏng để tuần hoàn máu đư ợc bình thư ờng tránh 
thiếu tưới máu.  
- Bỏng bàn tay thì cho bàn tay vào túi nh ựa rồi băng l ỏng cổ tay, làm như 
vậy cho phép n ạn nhân v ẫn cử động đư ợc các ngón tay d ễ dàng, tránh làm b ẩn 
vết bỏng. 
- Bỏng ở cổ chân, c ổ tay thì ph ủ vết vỏng bằng gạc vô khu ẩn sau đó 
có th ể nẹp cố định. 
- Không ch ọc phá các túi ph ỏng nư ớc. 
- Không bôi d ầu mỡ, dung d ịch cồn, kém kháng sinh vào v ết bỏng. 
3.2.4. C ấp cứu một số trường hợp bỏng đặc biệt 115 
 - Điện giật, sét đánh: Thư ờng bỏng rất sâu và gây ng ừng tim, sau c ấp 
cứu tại hiện trư ờng nạn nhân đư ợc đưa t ới khoa c ấp cứu có th ể vẫn có lo ạn 
nhịp tim, c ần theo dõi và x ử trí lo ạn nhịp. 
- Bỏng hóa ch ất: Một số loại hóa ch ất như acid, ki ềm mạch ho ặc iod, 
phospho dùng trong công nghi ệp hoặc vôi nư ớc tôi có th ể gây nên t ổn thương 
bỏng nặng và làm n ạn nhân r ất dau đ ớn: Vi ệc xử lý tại hiện trư ờng đảm bảo 
khi đ ến khoa c ấp cứu cần phải : 
+ Rửa lại liên t ục bằng nư ớc càng nhi ều càng t ốt, nếu không các t ổ 
chức ở vùng b ỏng sẽ hoại tử hoàn toàn, n ếu nguyên nhân gây b ỏng là acid 
thì rửa vết bỏng b ằng dung d ịch, bicarbonat, nguyên nhân là kiềm thì r ửa 
dung d ịch có pha gi ấm, chanh.  
+ Nếu bỏng hóa ch ất ở mắt thì r ửa bằng nư ớc sạch. 
+ Phải tháo b ỏ quần áo b ị dính hóa ch ất. 
+ Nếu bỏng ch ảy máu nhi ều thì x ử trí như v ết thương ch ảy máu.  
Bác s ỹ khoa c ấp cứu cần hội chẩn ngay v ới bác s ỹ chuyên kho a sâu v ề 
bỏng trong và sau khi th ực hiện các x ử trí trên đ ể bệnh nhân đư ợc hồi sức và 
điều trị theo chuyên khoa sâu v ề bỏng. 
4. Tai bi ến và bi ến chứng 
4.1. T ổn thương ph ổi do suy hô h ấp cấp tiến triển trong nh ững ngày 
đầu: Bỏng rộng, hóa ch ất, bỏng đư ờng hô hấp, khí đ ộc. 
4.2. Nhi ễm khu ẩn, đặc biệt với bệnh nhân b ỏng nặng, b ỏng sâu.  
5. Kinh nghi ệm th ực tế 
- Chẩn đoán đ ộ sâu thư ờng không ch ắc chắn. 
- Tránh đi ều trị tại chỗ làm thay đ ổi vùng b ỏng như dùng eosine, thu ốc 
mỡ, không đ ặt các v ật liệu thấm hút lên v ùng b ỏng, không đ ảm bảo vô khu ẩn. 
- Không dùng kháng sinh d ự phòng nh ất loạt tạo dòng vi khu ẩn kháng 
thuốc. 
- Bù d ịch ph ải theo hư ớng dẫn, dựa theo b ệnh nhân c ụ thể, không theo 
công th ức cứng nh ắc. 
- Không quên tiêm phòng u ốn ván.  
- Lưu ý các trư ờng hợp bỏng hít ph ải khí đ ộc CO, CN (khi ngư ời bệnh 
bị bỏng lửa trong môi trư ờng kín có nhi ều chất dẻo cháy).  
TÀI LI ỆU THAM KH ẢO 
1. Vũ Văn Đính (2009). C ẩm nang c ấp cứu, Nhà xu ất bản Y h ọc, tr 
487-492. 
2. Namias N (2007). Burn Care. Current Opinion Critical Care: 1 3:405.  
3. Carsin H (2010). Current advances in the initial management of 
major thermal burns. Intensive care medicine 26:848.  116 
  
CÂU H ỎI LƯ ỢNG GIÁ  
Câu 1:  Tình tr ạng của cơ th ể bị phỏng ph ụ thuộc vào:  
A. Đ ộ sâu c ủa bỏng 
B. Di ện tích c ủa vết bỏng 
C. V ị trí của vết bỏng trên cơ th ể 
D. C ả 3 ý trên  
Câu 2:  Các nguyên nhân gây b ỏng 
A. …………  
B. …………  
C. …………  
D. …………  
E. …………  
G. …………  
Câu 3:  Ngộ độc khí đ ộc(CO, CN) hay g ặp trong các trư ờng hợp 
A. B ỏng lửa trong môi trư ờng kín  
B. Bỏng do đi ện giật, sét đánh  
C. Bỏng hóa ch ất (acid, bazo)  
D. C ả 3 ý trên  
Câu 4 : Việc cấp cứu bệnh nhân b ỏng tại khoa c ấp cứu bao g ồm các vi ệc quan 
trọng sau: 
A. Nhanh chóng lo ại trừ tác nhân gây b ỏng ra kh ỏi cơ th ể nạn nhân 
(nếu cần) 
B. Đ ảm bảo các ch ức năng s ống. 
C. X ử trí cấp cứu vết bỏng. 
D. Ti ến hành vá da c ấp cứu. 
E. Cả 4 ý trên.  117 
 Bài 1 5 
NGUYÊN T ẮC CH ẨN ĐOÁN,  XỬ TRÍ NG Ộ ĐỘC CẤP 
 
MỤC TIÊU  
Sau khi h ọc xong h ọc viên có kh ả năng:  
1. Trình bày đư ợc các lo ại ngộ độc hay g ặp trong c ấp cứu. 
2. Nêu đư ợc nguyên t ắc xử trí các lo ại ngộ độc thư ờng gặp. 
3. Trình bày đư ợc các bi ện pháp x ử trí ng ộ độc cấp. 
 
NỘI DUNG  
1. NGUYÊN T ẮC CHUNG:  
1.1. Có 2 nhóm công vi ệc:  
1. Hồi sức toàn di ện và đi ều trị các tri ệu chứng 2. Các bi ện pháp ch ống 
độc đặc hiệu:  
1.2. Khi nào làm gì ? Khi b ệnh nhân chưa có tri ệu chứng (đ ến sớm): ưu 
tiên các bi ện pháp ch ống độc. Khi b ệnh nhân đã có tri ệu chứng: ưu tiên các 
biện pháp h ồi sức và đi ều trị triệu chứng.  
2. CÁC CÔNG VI ỆC CỤ THỂ: 
2.1. C ấp cứu ban đ ầu hay ổn định b ệnh nhân  
Nhiệm vụ: ngay khi ti ếp xúc v ới bệnh nhân, trong vòng vài ba phút đ ầu 
tiên, xác đ ịnh và th ực hiện ngay các bi ện pháp c ần tiến hành nh ằm bảo đảm 
tính m ạng và ổn định tr ạng thái b ệnh nhân (không đ ể bệnh nhân ch ết trong 
khi đang thăm khám…). Vi ệc xác đ ịnh đư ợc thực hiện bằng: nhìn b ệnh nhân, 
sờ mạch và lay g ọi bệnh nhâ n. Các tình hu ống cần giải quy ết ngay thu ộc về 3 
hệ cơ quan s ống còn : Hô h ấp, tuần hoàn và th ần kinh. C ụ Thể: 
2.1.1 Hô H ấp:  
- Nếu có suy hô h ấp: thở chậm, ng ừng th ở, thở nhanh nông , xanh tím, 
vã m ồ hôi, co kéo các cơ hô h ấp, cần can thi ệp hỗ trợ hô hấp. 
- Mục đích can thi ệp nhằm: Khai thông đư ờng th ở, bảo đảm thông khí, 
bổ xung oxy trong khí th ở vào đ ể bảo đảm tình tr ạng oxy hoá máu  
- Các bi ện pháp can thi ệp: ng ửa cổ, thở oxy, hút đ ờm dãi, đ ặt canun 
mayo, đ ặt nội khí qu ản, m ở khí qu ản, th ổi ngạt, bóp bóng ambu , thở máy, 
dùng các thu ốc giãn ph ế quản… 
2.1.2. Tu ần hoàn:  
Có 2 tình tr ạng cần xử lí cấp: loạn nhịp và t ụt huy ết áp. 
- Loạn nhịp:  118 
 + Nhịp chậm dư ới 60 l ần/phút: atropine 0,5mg tĩnh m ạch, nh ắc lại cho 
đến khi m ạch > 60 l ần /phút ho ặc tổng liều = 2mg; N ếu nhịp chậm không c ải 
thiện, thư ờng kèm v ới tụt huy ết áp: truy ền adrenaline TM 0,2 g/kg/phút, 
điều chỉnh liều theo đáp ứng. 
+ Nhịp nhanh: ghi đi ện tim và x ử trí theo lo ại loạn nhịp: nhanh th ất, 
rung th ất, xo ắn đỉnh: s ốc điện kh ử rung; nhanh xoang, nhanh trên thất: 
digoxin, prostigmin,…  
- Truỵ mach – tụt huy ết áp: 
Trước hết xác đ ịnh có gi ảm th ể tích tu ần hoàn không; n ếu có truy ền 
dịch bảo đảm th ể tích. Khi đã lo ại trừ giảm th ể tích mà v ẫn tụt HA thì cho 
thuốc vận mạch. Thư ờng là Dopamin (5 -15 g/kg/phút); n ếu tụt HA do viêm 
cơ tim nhi ễm độc: dobutamin: b ắt đầu 10 g/kg/phút, tăng li ều nếu chưa đáp 
ứng, m ỗi lần tăng 10 g/kg/phút cho đ ến khi đ ạt kết qu ả hoặc đạt 
40g/kg/phút; n ếu cần phối hợp với dopamin; n ếu tụt HA do giãn m ạch gi ảm 
trương l ực thành m ạch: Noradr enaline b ắt đầu 0,2 g/kg/phút, đi ều chỉnh theo 
đáp ứng. Ph ối hợp thu ốc khác khi c ần: thư ờng là v ới dopamin li ều < 5 
g/kg/phút và Adrenaline b ắt đầu 0,2 g/kg/phút. Khi dùng thu ốc vận mạch 
phải có bơm tiêm đi ện, theo dõi sát và đi ều chỉnh liều kịp thời sau mỗi 15-30 
phút đ ể nhanh chóng đ ạt mục đích nâng Huy ết áp v ới liều thuosc v ận mạch 
tối ưu. 
2.1.3. Th ần kinh : co gi ật hay hôn mê?  
- Co gi ật: cắt cơn gi ật bằng các lo ại thuốc:  
+ Seduxen ống 10 mg tiêm TM (tr ẻ em tiêm 1/3 đ ến một nửa ống) nh ắc 
lại cho d ến khi cắt được cơn gi ật. Sau đó truy ền TM ho ặc tiêm b ắp duy trì 
khống ch ế cơn gi ật. Có th ể thay thu ốc duy trì b ằng gacdenal viên 0,1g u ống 
từ 1 đến 20 viên/ ngày tu ỳ theo m ức độ co gi ật.  
+ Thiopental l ọ 1g; Tiêm TM 2 - 4 mg/kg (bolus), nh ắc lại cho đ ến khi 
cắt cơn gi ật; duy trì 2mg/kg/gi ờ (không quá li ều này vì có nguy cơ viêm gan 
nhiễm độc); ho ặc thay b ằng gacdenal 1 -20 viên/ ngày. Đi ều chỉnh li ều tuỳ 
theo b ệnh nhân. Có trư ờng hợpp co gi ật do ng ộ độc hoá ch ất bảo vệ thực vật 
đã ph ải dùng gardenal kéo dài hàn g tháng, li ều cao nh ất 2,4g / ngày (2 viên 
mỗi 2 gi ờ), giảm dần sau 1 tháng xu ống 1 viên/ ngày và duy trì ti ếp nhi ều 
tháng sau  
- Hôn mê:   
+ Glucose ưu trương 50% 50mlTM, sau đó truy ền duy trì glucose 10% 
1000ml/24 gi ờ với mục đích nuôi dư ỡng. Kèm vitamin B1 100mg tiêm b ắp 
hoặc tĩnh m ạch 
+ Naloxol 0,4mg TM ch ậm  để lọai trừ quá li ều heroin  
+ Bảo đảm hô h ấp chống tụt lưỡi, hít ph ải trào ngư ợc… 119 
 2.2. H ỏi bệnh, khám toàn di ện, làm các xét nghi ệm. Ch ẩn đoán, l ập 
và th ực hiện kế hoạch đi ều trị. 
2.2.1. H ỏi bệnh:  
Khoảng 95% ch ẩn đoán nguyên nhân ng ộ độc được quy ết định do h ỏi 
bệnh; c ần kiên trì, h ỏi ngư ời bệnh, ngư ời nhà, nhi ều lần, để nắm đư ợc thông 
tin trung th ực. Yêu c ầu ngư ời nhà mang đ ến vật chứng nghi gây đ ộc(đồ ăn 
uống, v ỏ lọ, bao bì thu ốc, hoá ch ất…) 
Người bệnh ho ặc ngư ời nhà b ệnh nhân có th ể không nh ớ rõ, ho ặc lẫn 
lộn các s ự kiện hoặc thậm chí c ố tình cung c ấp thông tin sai nh ằm đánh l ạc 
hướng. Vì v ậy thầy thu ốc phải luôn luôn đ ối chiếu bệnh sử với thăm khám 
lâm sàng đ ể thu nh ận được các thông tin chính xác . 
Cần xác đ ịnh: 
a. Nhiễm độc ở đâu, khi nào, t ại sao nhi ễm, nhi ễm như th ế nào: n ặng, 
nhẹ, nhiều, ít đ ộc chất…), có ai khác ch ứng ki ến không.  
b. Đã x ảy ra các tri ệu chứng, d ấu hiệu gì sau khi nhi ễm độc (trư ớc khi 
gặp bác sĩ), ví d ụ nôn, co giât, hôn mê, ho,  khó th ở…  
c. Cùng v ới độc chất có ăn u ống thêm gì khác không, có u ống nhi ều 
loại thuốc không?  
d. Đã đư ợc xử trí, đi ều trị gì chưa?  
e. Tiền sử bệnh tật (của bệnh nhân và gia đình) như th ế nào? Bao g ồm 
tiền sử dị ứng, các b ệnh mãn tính có th ể tương tác v ới độc chất? các tình 
huống xảy ra trư ớc khi nhi ễm độc  (stress…, n ợ nần…) 
 
Nhó
m CĐ  H
A M N
h
ị
p 
t
h
ở N
h
i
ệ
t
 
đ
ộ Ý
 
t
h
ứ
c Đ
ồ
n
g 
t
ử C
o
 
b
ó
p M
ồ
 
h
ô
i K
h
á
c 
Kích 
thích  
TK 
giao 
cảm 
(amp
hetam
in, 
ectasy    t
h
a
y
 
đ
ổ
i D
ã
n   Đ
ỏ
 
d
a 120 
 ,…) 
An 
thần, 
rượu 
(TK 
giao 
cảm)     t
h
a
y
 
đ
ổ
i C
o   
 
p
h
ả
n
 
x
ạ 
Antic
holine
rgic 
(atrop
in)     t
h
a
y
 
đ
ổ
i D
ã
n   k
h
ô
, 
đ
ỏ
,  
ứ
  
n
ư
ớ
c
 
t
i
ể
u 
Choli
nergic  
(OP, 
carba
mate)    ~ ~ t
h
a
y
 
đ
ổ
i C
o
 
n
h
ỏ   T
ă
n
g
 
t
i
ế
t 
 
d
ị
c
h
, 121 
 m
á
y
 
c
ơ 
Opiod
s     ~ C
o
 
n
h
ỏ   
 
p
h
ả
n
 
x
ạ 
Thèm 
opioi
ds    - ~ D
ã
n   n
ô
n
, 

 
h
o
ạ
t
  
đ
ộ
n
g
, 
c
h
ả
y
 
d
ã
i 
Thèm 
rượu 
hay 
thuốc     ~ D
ã
n   n
ô
n
, 122 
 an 
thần 
(HC 
cai) r
u
n
,  
c
o
 
g
i
ậ
t 
 
Bảng 1.1:  Tóm t ắt một số hội chứng ng ộ độc 
2.2.2. Khám toàn di ện phát hi ện các tri ệu chứng, tập hợp thành các h ội 
chứng bệnh lý ng ộ độc để giúp cho vi ệc chẩn đoán nguyên nhân.  
Với các BN có suy gi ảm ý th ức, cần chẩn đoán lo ại trừ các nguyên 
nhân do t ổn thương c ấu trúc (TBMN, ch ấn thương s ọ não...)  
a. Hội chứng thần kinh giao cảm (Kích thích adrenergic) :   mạch nhanh,   
huyết áp tăng, thở nhanh,  nhiệt độ tă ng,  đồng tử dãn,  da ướt,  niêm mạc khô, 
kích thích vật vã, hoang tưởng,  ví dụ ngộ độc amphetamine,  cocaine, 
ephedrine, phencyclidine.  
b. Hội chứng th ần kinh phó giao c ảm bao g ồm:  hạ huyết áp,  m ạch 
giảm,  thân nhi ệt giảm, đồng tử co, gi ảm vận động co bóp, ph ản xạ gân xương 
- cơ gi ảm,  b ệnh nhân lơ mơ và  hôn mê.  
Ví  d ụ  ngộ  độc  nhóm  các  thu ốc  ng ủ (barbiturates) và an th ần  
(benzodiazepin),   clonidine, m ột vài thu ốc hạ áp, ethanol, opioids.  
c. Hội chứng cholinergic (kháng men cholinesteraza)  
Dấu hiệu Muscarine:  m ạch giãn,  huy ết áp thay đ ổi,  đồng tử co nh ỏ, 
tăng ti ết dịch tiêu hoá, d ịch ph ế quản, ph ế nang, m ồ hôi. 
Dấu hiệu Nicotin:  huy ết áp tăng, m ạch tăng,  máy cơ, y ếu và li ệt cơ 
(cơ hô h ấp). 
Dấu hiệu thần kinh trung ương:   kích thích v ật vã. Ví dụ NĐC photpho 
hữu cơ, carbamates, physostigmine, nicotine.  
d. Hội chứng anticholinergic:   mạch nhanh,  huy ết áp tăng, nhi ệt thân 
tăng, đ ồng tử giãn, da nóng đ ỏ,  khô, gi ảm co bóp, v ật vã, kích thích ph ản xạ 
gân xương tăng.   Ví d ụ NĐC Atropine  
e. Co gi ật: co gi ật toàn thân, các cơn ngày càng mau và m ạnh:  NĐC 
với nhi ều loại thu ốc hay ch ất độc như thu ốc diệt chu ột loại mono sodium 
trifluoroactate và trifluoroacetamide, mã ti ền, INH, phenothiazines, 
theophylline, thu ốc chống trầm cảm vòng, phencyclidine, strychnine.  123 
 f. Hạ huyết áp: Do NĐC nhi ều loại như: thu ốc điều trị tăng huy ết áp, 
theophylline, s ắt, phenothizines, barbiturates, thu ốc chống trầm cảm, các ch ất: 
cyanide, carbon monocide, hydrogen sulfite, arsenic, n ấm độc. 
g. Rối loạn nhịp tim: Xuất hiện trong ng ộ độc các thu ốc và ch ất độc 
sau : 
- Nhịp chậm xoang: beta -blocker, verapamil, phospho h ữu cơ, digitalis 
glycosides, opioids, clonidin, sedative -hyporotics.  
- Block nhĩ th ất: beta -blocker, digitalis glycosides, tricyclic 
antidepressants lithium, ch ẹn canxi, lithium.  
- Nhịp nhanh xoang: theophylline, cafeine, cocaine, anphetamine, kích 
thích beta (salbutamol), antihistamine, anticholinergic, tricyclic 
antidepressants, s ắt. 
- Phức bộ QRS dãn r ộng:  thu ốc chống tr ầm cảm tricyclic, quinidine và 
một số thuốc chống rối loạn nh ịp tim, phenothiazine, aconitin (c ủ ấu tầu), 
tăng K+. 
+ QRS dãn r ộng có th ể là hậu quả của thiếu oxy hay r ối loạn điện giải 
như tăng, h ạ kali máu, h ạ Mg. C ần điều chỉnh trư ớc những rối loạn này trư ớc. 
Nếu những rối loạn còn t ồn tại thì dùng lidocaine (xylocaine) và các thu ốc 
chống rối loạn nhịp tim khác và quan tâm đ ến cho d ịch NaHCO 3 trong ng ộ 
độc quinidine và thu ốc chống trầm cảm tricyclic.  
2.3. Áp d ụng các bi ện pháp h ạn chế hấp thu  
2.3.1.  Ch ất độc qua đư ờng hô h ấp đưa n ạn nhân ra kh ỏi nơi nguy 
hiểm, vùng thoáng khí.  
2.3.2. Da, niêm m ạc:  
- Cởi bỏ quần áo b ẩn lẫn hóa ch ất độc, tắm rửa bằng xối nước ấm và xà 
phòng, g ội đầu. Chú ý n ếu có nhi ều ngư ời cùng b ị ngộ độc hóa ch ất thì ph ải 
xối nước đồng lo ạt cùng m ột lúc, tránh đ ể trì hoãn, đ ợi chờ. 
- Rửa mắt khi ch ất độc bắn vào: c ần  rửa mắt liên t ục 15 phút b ằng 
dòng nư ớc mu ối 0,9% ch ảy liên t ục trước khi đưa đi khám  chuyên khoa m ắt. 
2.3.3. Chất độc qua đư ờng tiêu hoá  
          2.3.3.1. Gây nôn : Chỉ định: nếu mới uống, ăn ph ải chất độc và n ạn nhân 
còn t ỉnh táo, chưa có tri ệu chứng ng ộ độc. Chống ch ỉ định:  nạn nhân l ờ đờ, 
hôn mê hay co gi ật , ng ộ độc axít hay ki ềm  m ạnh. Gây nôn b ằng cách: cho 
nạn nhân u ống 100 – 200 ml nư ớc sạch rồi dùng tăm bông, ho ặc ống xông 
ngoáy h ọng, cúi th ấp đầu nôn, tránh s ặc vào ph ổi.  Quan sát ch ất nôn, gi ữ lại 
vào m ột lọ gửi xét nghi ệm. 
          2.3.3.2. Uống than ho ạt:  
          - Cho than ho ạt với liều 1g/kg cân n ặng hoà trong 100 ml nư ớc sạch 
cho n ạn nhân u ống. Sau 2 gi ờ có th ể uống nh ắc lại nếu thấy cần. 124 
           - Kèm theo than ho ạt bao gi ờ cũng ph ải cho sorbitol v ới một lượng gấp 
2 lần than ho ạt. 
           - Có th ể uống hỗn hợp than ho ạt + Sorbitol ( Antipois - B. Mai c ủa 
TTCĐ ) ngư ời lớn 1 l ọ 120 ml, tr ẻ em 1/2 l ọ 60 ml và tr ẻ em dư ới 2 tu ổi 
không dùng.  
          2.3.3.3. Rửa dạ dày: 
- Hiệu quả nhất trong 60 phút đ ầu bị NĐC  
- Còn hi ệu quả trong 3 gi ờ đầu và đã u ống than ho ạt 
- Còn hi ệu quả trong 8 gi ờ đầu với ngộ độc: tricyclic, phenobarbital, 
salycylates, ho ặc uống m ột số lượng lớn. 
- Chỉ định: 
+ Hầu hết các thu ốc uống dạng nư ớc, bột viên, mi ếng nh ỏ 
+ Cho các b ệnh nhân không gây nôn đư ợc 
- Chống ch ỉ định: 
+ Sau u ống các ch ất ăn mòn : acids, ki ềm mạnh. 
+ Sau u ống các hoá ch ất : dầu hoả, ét xăng, paraffin.  
+ Tuy nhiên n ếu có k ỹ thuật thật tốt phòng tránh các  biến chứng vẫn có 
thể rửa dạ dày. 
+ Bệnh nhân hôn mê, co gi ật trừ khi đư ợc đặt ống NKQ bơm bóng và 
dùng thu ốc chống co gi ật. 
- Kỹ thuật: 
+ Bệnh nhân n ằm nghiêng trái, đ ầu thấp. 
+ Xông d ạ dày c ỡ 37- 40F cho ngư ời lớn; 26 -35F cho tr ẻ con, bôi trơn 
đưa qua m iệng hay mũi vào t ới dạ dày. 
+ Nước đưa vào m ỗi lần 200ml v ới ngư ời lớn, 100ml v ới trẻ em, sóc 
bụng rồi tháo ra. Không dùng máy hút đi ện. Nh ắc lại nhi ều lần cho t ới khi 
sạch dạ dày. 
+ Dùng nư ớc sạch, ấm pha v ới mu ối 5g mu ối/lít nư ớc, tổng số lượng 
nước rửa thường 5 -10 lít v ới các trư ờng hợp uống thu ốc trừ sâu, 3 -5 lít nư ớc 
với hầu hết các trư ờng hợp khác.  
2.3.3.4. Nhuận tràng:  
- Nhằm kích thích co bóp ru ột tống ch ất độc ra ngoài. Thư ờng dùng là 
sorbitol 1 -4g/kg u ống ngay sau dùng than ho ạt, hoặc trộn vào t han ho ạt.  
          2.4. Các bi ện pháp tăng th ải trừ độc chất. 
          - Bao g ồm các bi ện pháp: l ợi tiểu tích c ực, uống than ho ạt hàng lo ạt, 
lọc ngoài th ận, thay huy ết tương, thay máu. Ch ỉ thực hiện ở bệnh vi ện. 125 
      Lợi tiểu tích c ực: chỉ định: ngộ độc các lo ại độc chất được đào th ải 
qua đư ờng ti ết niệu: gardenal. Seduxen…, ho ặc tình tr ạng tiêu cơ vân trong 
ngộ độc (ong đ ốt, rắn hổ mang c ắn…). Chống ch ỉ định: suy tim, suy th ận thể 
thiểu niệu hoặc vô ni ệu. Th ực hiện: truy ền dịch với tốc độ 150-200ml/gi ờ ở 
người lớn, 20 - 100ml/gi ờ ở trẻ em-tùy theo cân n ặng và t ổng số dịch truy ền. 
Dịch truy ền thư ờng là d ịch đẳng trương (m ột nửa là glucose 5%; m ột nửa là 
natri clorua 0,9%; n ếu là gardenal thì truy ền glucose 5%, natriclorua 0,9% và 
natribicarrbonat 1,4% theo  tỉ lệ 2:2:1 v ới khối lượng toàn b ộ bằng 50 -80ml/kg 
cân n ặng). 
          Theo dõi lư ợng nư ớc tiểu theo gi ờ > nếu không đ ạt 100 -200 ml/ gi ờ 
cho ngư ời lớn và 2 -4 ml/kg cân n ặng cho tr ẻ em thì cho thêm thu ốc lợi tiểu 
mạnh (furosemide). Đi ều chỉnh lư ợng dịch truyền và thu ốc lợi tiểu theo theo 
lượng nư ớc tiểu/giờ. 
          Lọc ngoài th ận: khi l ợi tiểu tích c ực không có tác d ụng, ho ặc BN suy 
thận, ho ặc độc chất không hòa tan trong nư ớc và không th ải qua th ận. Ch ỉ 
định ch ống ch ỉ định ph ụ thuốc vào bi ện pháp l ọc, và từng độc chất riêng.  
          Thường đư ợc áp d ụng nh ất là Intermittent hemodialysis (HD)  và lọc 
máu liên t ục tĩnh m ạch –tĩnh m ạch (CVVH); Lọc máu h ấp ph ụ (bằng cột lọc 
than ho ạt hoặc cột lọc resin đang đư ợc nghiên c ứu triển khai t ại Trung tâm 
Chống Đ ộc 
          Thay huy ết tương ho ặc thay máu : có th ể được chỉ định khi các bi ện 
pháp th ải trừ khác không có hi ệu quả và th ực hiện vào th ời điểm độc chất có 
nồng độ trong máu cao nh ất. Ví d ụ ngộ độc paraquat khi BN nh ập viện trong 
vòng 2 -4 giờ đầu. Đã b ắt đầu ứng dụng tại Trung tâm Ch ống đ ộc và đang 
được nghiên c ứu. 
          2.5. S ử dụng thu ốc giải độc. (xem thêm bài Thu ốc giải độc ở 
chương trình Ch ống độc chuyên sâu)  
    Thuốc giải độc là bi ện pháp đi ều trị có hi ệu quả cao, n ếu đư ợc dùng 
sớm và đúng cách, vì  vậy cần dự trữ và tận dụng thu ốc giải độc trong đi ều trị 
ngộ độc cấp. 
2.5.1. Đinh nghĩa : Thu ốc giải độc (antidote) là các ch ất có tác d ụng 
đặc hiệu chống lại tác đ ộng ho ặc hiệu quả độc hại của một độc chất  
2.5.2. Cơ ch ế tác d ụng 
- Giải độc qua tương tác hoá h ọc  
- Giải độc qua tác d ụng dư ợc lý. 
- Cạnh tranh th ể cảm thụ  
- Đối kháng tác d ụng 
- Phục hồi chức năng bình thư ờng  
2.5.3. V ấn đề liều lượng:   126 
 Rất nhi ều thu ốc giải độc chưa xác đ ịnh đư ợc liều tối ưu. các li ều 
khuy ến cáo thư ờng d ựa trên th ực nghi ệm trên súc v ật và trên ngư ời khỏe 
mạnh bình thư ờng. 
Người ngộ độc sẽ đáp ứng khác v ới ngư ời khác; và lư ợng thu ốc giải 
độc phải tương đương (đ ể trung hòa đ ộc chất…) ho ặc thậm chí nhi ều hơn đ ộc 
chất ( để tranh ch ấp thụ cảm th ể, để đối kháng tác d ụng, đ ể phục hồi chức 
năng…).  
Dùng không đ ủ thuốc giải độc sẽ không có tác d ụng; ngư ợc lại dùng 
quá li ều thu ốc giải độc có th ể sẽ trở thành tác nhân gây ng ộ độc. Vì v ậy ngư ời 
bác sĩ đi ều trị phải quy ết định li ều lượng cho t ừng ngư ời bệnh và theo dõi 
chặt phản ứng của người bệnh khi dùng thu ốc giải độc. 
    Hiện ở Việt Nam đã có m ột số thuốc giải độc đặc hiệu có phác đ ồ điều 
trị cụ thể đã đư ợc kiểm ch ứng qua lâm sàng: PAM và atropin trong ng ộ độc 
phospho h ữu cơ; N Acetylcystein trong ng ộ độc paracetamol; Naloxon trong 
quá liều thu ốc phi ện, D penicilamin và các ch ất gắp kim lo ại nặng khác trong 
điều trị ngộ độc chì, huy ết thanh kháng n ọc các lo ại rắn: hổ chúa, h ổ mang, 
cạp nia, l ục tre, choàm qu ạp… 
2.6. Các bi ện pháp đi ều trị triệu chứng, h ồi sức toàn di ện: gan, th ận, 
huyết học, nư ớc điện giải…. Giáo d ục phòng ch ống tái phát trư ớc khi ra vi ện. 
 
TÀI LI ỆU THAM KH ẢO 
1. Vũ Văn Đính và c ộng sự (2002), “Các nguyên t ắc xử trí ng ộ độc 
cấp”, Hồi sức cấp cứu toàn t ập, Tr. 348 -356, NXB Y H ọc, Hà N ội. 
2. M. Ellenhorn, D.G. Barceloux (1 988), “General approach to the 
poisoned patient”, Medical Toxicology , 1st edition, Elsevier Science 
Publishing Company, PP.1 -102. 
3. Richard C. Dart (2004), “Initial Management of the Poisoned 
Patient”, Medical Toxicology , 3rd edition, Lippincott Williams & Wilkins, PP. 
21-39. 
 
CÂU H ỎI LƯ ỢNG GIÁ  
Khoanh tròn vào m ột hoặc nhi ều ý đúng:  
1. Xử trí ng ộ độc cấp gồm: 
A. 2 loại công vi ệc: hồi sức và ch ống độc 
B. 6 nhóm công vi ệc 
C. Cần ưu tiên h ồi sức 
D. Cần ưu tiên ch ống độc 127 
      2. Chẩn đoán ngộ độc cấp quan trọn g nhất và phần lớn nhất là dựa vào  
A. Hỏi bệnh và khám lâm sàng giúp phát hi ện các đ ầu mối 
B. Chẩn đoán hình ảnh 
C. Xét nghi ệm độc chất  
D. Xét nghi ệm thông thư ờng 
 3. Chỉ định rửa dạ dày:  
A. Cho m ọi ngộ độc qua đư ờng tiêu hóa đ ến trư ớc 6 gi ờ 
B. Ngộ độc đường tiêu hóa không quan tr ọng th ời điểm  đến viện 
C. Bệnh nhân nghi ăn u ống ph ải chất độc đến trư ớc 2 gi ờ, không có 
chống ch ỉ định. 
D. Không có câu nào đúng  
4. Than ho ạt là 
A. Than c ủi được nghi ền nhỏ 
B. Than đá nghi ền nhỏ 
C. Than đư ợc xử lý đặc biệt có kh ả năng h ấp phụ cao h ầu hết các đ ộc 
chất  
D. Chỉ  là ch ất bột màu đen gi ống than  
 5. Thái đ ộ xử trí ng ộ độc cấp 
A. Trước hết là đi ều trị thuốc giải độc (nếu có) theo k ết quả xét nghi ệm 
độc chất 
B. Loại trừ độc chất bằng các bi ện pháp c ần được làm ngay.  
C. Rửa dạ dày cho BN ng ộ độc đường uống càng s ớm càng t ốt. 
D. Chỉ là điều trị triệu chứng 
E. Không có câu nào đúng  
6. Tư th ế của bệnh nhân khi r ửa dạ dày 
A. Nằm ng ửa ưỡn cổ 
B. Nằm nghiêng sang ph ải 
C. Nằm nghiêng sang trái, đ ầu thấp 
D. Nằm thẳng 
7. Bệnh nhân ngộ độc cấp thuốc ngủ, khi vận chuyển đến bệnh viện cần để 
nằm ở tư thế:  
A. Nằm ng ửa 
B. Nằm đầu cao  
C. Nằm đầu thấp 128 
 D. Nằm nghiêng an toàn  
8. Gây nôn là biện pháp  
A. Có th ể tiến hành cho b ất cứ bệnh nhân ng ộ độc nào  
B. Chỉ tiến hành ở trẻ em 
C. Chỉ tiến hành sau khi không có than ho ạt 
D. Không có câu nào đúng  
9. Trước một bệnh nhân ng ộ độc, việc đầu tiên là:  
A. Tránh không đ ể lây nhi ễm cho ngư ời cấp cứu 
B. Bảo đảm các ch ức năng s ống cho n ạn nhân  
C. Cho b ệnh nhân th ở o xy đ ề phòng suy hô h ấp 
D. Đ ặt một đường truyền tĩnh m ạch ngăn ng ừa tụt huy ết áp do thi ếu 
dịch 
10. Các bi ện pháp tăng đào th ải độc chất là 
A. Gây nôn và r ửa dạ dày 
B. Bài ni ệu tích c ực 
C. Lọc máu  
D. Thay huy ết tương  
E. Các câu B, C và D  
11. Trong đi ều trị ngộ độc cấp 
A. Thuốc giải độc là bi ện pháp hi ệu quả nhất nếu có s ẵn và đư ợc dùng 
sớm 
B. Tất cả mọi chất độc đều có thu ốc giải độc của nó 
C. Thuốc giải độc cho co gi ật do ng ộ độc  là seduxen, phenobarrbital  
D. Dùng thu ốc giải độc phải tuân th ủ liều tối ưu đư ợc xác đ ịnh bởi nhà 
sản xuất. 
12. Nhóm  công vi ệc thứ 6 là 
A. Điều trị triệu chứng. 
B. Hồi sức  toàn di ện 
C. Điều trị toàn di ện bao g ồm tiếp tục các bi ện pháp h ồi sức - điều trị 
triệu chứng, nuôi dư ỡng, chăm sóc và giáo d ục phòng ch ống tái nhi ễm. 
D. Không có câu nào đúng  
 129 
  
Bài 1 6 
VẬN CHUY ỂN BỆNH NHÂN C ẤP CỨU 
 
MỤC TIÊU  
Sau khi h ọc xong h ọc viên có kh ả năng:  
1. Trình bày đư ợc phân lo ại các cách di d ời và v ận chuy ển bệnh nhân.  
2. Trình bày đư ợc vận chuy ển bệnh nhân trong b ệnh vi ện và chuy ển viện. 
3.Trình bày đư ợc các tư th ế an toàn.  
 
NỘI DUNG  
1. Đại cương  
  - Để vận chuy ển bệnh nhân t ừ nơi này sang nơi khác, nhân viên c ứu hộ cần 
có m ột kế hoạch rõ ràng. C ần nhẩm trư ớc trong đ ầu chi ến lược thu nh ận và v ận 
chuy ển bệnh nhân. Thu nh ận là xác đ ịnh vị trí, che ch ở và bảo vệ an toàn cho 
bệnh nhân. Trong kế hoạch nhân viên c ứu hộ cần phải biết những hạn chế của 
mình cũng như nh ững ngu ồn có th ể huy đ ộng khác và cách ti ếp cận đư ợc 
những ngu ồn đó. S ử dụng các trang thi ết bị sẵn có b ất cứ khi nào có th ể. 
  - Vận chuy ển bệnh nhân n ặng luôn có nguy cơ nh ất định do vận chuy ển 
cho b ệnh nhân và nhân viên v ận chuy ển 
  - Mục tiêu c ủa vận chuy ển cấp cứu: 
- Cố gắng hạn chế các nguy cơ x ấu do v ận chuy ển cho b ệnh nhân  
- Tránh ch ấn thương, nguy hi ểm cho nhân viên  
2. Phân lo ại 
- Di dời bệnh nhân kh ỏi hiện trư ờng  
- Vận chu yển từ hiện trư ờng về bệnh vi ện 
- Vận chuy ển trong b ệnh vi ện  
- Vận chuy ển giữa các b ệnh vi ện 
3. Nâng và di d ời bệnh nhân c ấp cứu tại hiện trư ờng 
- Khó khăn n ếu bệnh nhân b ị kẹt tại những ch ỗ khó ti ếp cận, nguy hi ểm 
- Cần tránh t ổn thư ơng cho nhân viên y tế (nhân viên y t ế bị thương 
hoặc tử vong s ẽ không còn c ứu được bệnh nhân !) 
- Trước khi chuy ển đi b ệnh nhân ph ải được: 130 
 Có tư  thế thích h ợp 
Phủ kín, ph ủ ấm.. 
Đảm bảo an toàn  
3.1. Khi l ập kế hoạch thu nh ận và v ận chuy ển bệnh nhân : cần lưu ý 
đến 4 y ếu tố sau: 
- Tình tr ạng bệnh nhân, bao g ồm cả tình tr ạng trư ớc mắt và nh ững nguy 
cơ có th ể xảy ra đe do ạ sự sống của bệnh nhân.  
- Sự nguy hi ểm của môi trư ờng xung quanh và nh ững hạn chế khác có 
thể làm t ổn thương đ ến sự an toàn c ủa bệnh nhân và nhân viên c ứu hộ. 
- Các phương ti ện và/ ho ặc những nhân viên c ứu hộ sẵn có t ại thời điểm đó.  
- Sức khỏe và kh ả năng cũng như các h ạn chế chuyên môn c ủa nhân 
viên c ứu hộ tham gia v ận chuy ển.  
3.2. Nguyên t ắc nâng - khiêng  
  Khi ti ến hành v ận chuy ển bệnh nhân, c ần tuân theo hai nguyên t ắc cơ b ản 
về nâng và khiêng như sau:  
  - Thứ nhất là dùng các nhóm cơ dài nh ất, khỏe nhất để vận chuy ển bệnh 
nhân (cơ nh ị đầu, cơ t ứ đầu và nhóm cơ mông). Khi cơ co v ới một tốc độ 
trung bình, hi ệu suất co cơ s ẽ đạt tối đa. M ột điểm quan tr ọng là sử dụng chân 
chứ không ph ải lưng đ ể nâng b ệnh nhân.  
  - Thứ hai là gi ữ cho tay và chân sát v ới thân ngư ời để trọng tâm cơ th ể 
không b ị lệch. Gi ữ trọng lư ợng ph ải nâng g ần với thân mình. Đi ều này s ẽ 
giúp nhân viên c ứu hộ không b ị mất sức khi v ận chuy ển bệnh nhân.  
  Đánh giá tình hình đ ể đảm bảo rằng, các nhân viên c ứu hộ có th ể nâng 
bệnh nhân lên và vư ợt qua b ất kỳ tình hu ống khó khăn nào.  
  Khi nâng b ệnh nhân, cơ th ể của nhân viên c ứu hộ sẽ hoạt động như m ột 
cần trục cơ khí. Đ ể thắng tr ọng lư ợng ngh ỉ của một bệnh nhân đang c ần được 
nâng lên, c ần có m ột chỗ đứng ho ặc một vị trí và m ột lực cần thiết. 
3.3. Hư ớng dẫn nâng - khiêng an toàn  
  - Ước lượng tr ọng lư ợng ph ải nâng và lư ợng sức mình. Ch ỉ nâng tr ọng 
lượng mà mình có th ể nâng đư ợc. Tr ọng lư ợng tối đa mà m ột ngư ời có th ể 
nâng ph ụ thuộc vào tu ổi, giới, khối cơ và hoàn c ảnh th ực tế. 
  - Sử dụng các phương ti ện sẵn có m ột cách hi ệu quả. 
  - Đặt cả hai chân trên m ặt đất với một chân hơi đ ặt lên trư ớc so v ới chân 
kia đ ể tạo một vị trí vững ch ắc. 
  - Phân b ố trọng lư ợng bệnh nhân đ ều lên 2 chân.  
  - Khi ph ải nâng th ấp dư ới đầu gối, tỳ người lên đ ầu gối và đùi; gi ữ lưng 
thẳng. Không t ỳ vào th ắt lưng đ ể nâng b ệnh nhân.  131 
   - Giữ vững đầu. Di chuy ển nhẹ nhàng. Di chuy ển đột ngột, xóc n ảy làm cơ 
hoạt động quá s ức và dẫn đến tổn thương cơ.  
  - Lên gân b ụng khi nâng b ệnh nhân và kéo v ề phía hông. Gi ữ cho vai th ẳng 
trục với lưng và khung ch ậu. 
  - Giữ thẳng đầu gối khi nâng đ ể đảm bảo đùi và hông t ạo ra l ực nâng chính.  
  - Chuy ển động th ẳng, tránh xoay, v ặn. Gi ữ cho v ai vuông góc v ới khung ch ậu.  
  - Đi ch ậm, sử dụng các đ ộng tác ph ối hợp. Khi v ận chuy ển bệnh nhân ho ặc 
khiêng cáng, bư ớc chân không nên dài ho ặc rộng hơn vai.  
  - Bất cứ khi nào có th ể, nên đi v ề phía trư ớc, tránh đi lùi đ ể tạo điều kiện 
thuận lợi cho s ự cân b ằng và vi ệc vận chuy ển được nhẹ nhàng.  
  - Khi đ ặt cáng ho ặc ván khiêng xu ống, c ần tuân th ủ các nguyên t ắc như khi 
nâng đ ể duy trì s ự an toàn.  
  - Phối hợp chặt chẽ và thư ờng xuyên v ới các đ ồng nghi ệp khác trong su ốt 
quá trình v ận chuy ển. Đi ều này s ẽ duy trì s ự phối hợp và giúp đ ỡ lẫn nhau 
giữa các nhân viên c ứu hộ khi g ặp địa hình không b ằng ph ẳng ho ặc những trở 
ngại khác.  
  Cần chú ý ngoài nâng b ệnh nhân nhân viên y t ế còn ph ải nâng c ả trọng 
lượng của các thi ết bị đi kèm (cáng, võng, bình oxy..)Khi c ần lựa chọn, hãy 
chọn thiết bị sẵn có nh ẹ nhất, nhỏ nhất để hạn chế sức lực của mình.  
3.4. Nâng  
 Để nâng tr ọng lư ợng lên, c ần đặt chân m ở rộng m ột cách tho ải mái, căng 
cơ bụng để khóa lưng trong tư th ế  cong vào trong m ột cách nh ẹ nhàng. Đ ứng 
dạng ch ân ở cuối cáng (võng) và đ ặt chân vuông góc v ới mạt đất. Dồn trọng 
lượng cơ th ể vào bàn chân ho ặc ngay phía sau. Đ ứng lên trong tư th ế khóa 
lưng và nâng thân mình trư ớc khi b ắt đầu nâng hông lên.  
3.5. H ướng dẫn khiêng an toàn  
(Tránh mang vác tr ực tiếp- cố gắng dùng xe có bánh lăn  
- Ước lượng trọng lượng ph ải nâng và l ượng sức nhân viên  
- Phối hợp nhịp nhàng và trao đ ổi rõ ràng v ới đồng nghi ệp 
- Sử dụng kỹ thuật nâng an toàn  
- Đặt gan bàn tay và t ất cả các ngón tay ti ếp xúc hoàn toàn v ới vật được 
nâng lê n. Đảm bảo các ngón tay hư ớng về cùng m ột góc. Đ ặt hai tay cách 
nhau kho ảng 10”.  Khi có t ừ bốn nhân viên c ứu hộ trở lên v ận chuy ển cáng, 
mỗi ngư ời trong s ố họ chỉ dùng m ột bàn tay đ ể khiêng cáng.  
3.6. H ướng dẫn kéo - đẩy an toàn  
  - Phải “khóa lưng” và tr ánh xoay v ặn khi ti ếp cận bệnh nhân. Thêm vào đó, 
tránh quá ư ỡn lưng khi v ới lên trên cao. Tránh vươn quá xa v ề phía trư ớc trên 
15 - 20” đ ể đỡ bất kỳ vật nặng có kích thư ớc khá l ớn nào. Cũng nên tránh m ọi 
sự gắng sức quá m ức trên 1 phút  132 
 - Kéo:  
+ Nên kéo th eo hướng th ẳng trục với cơ th ể 
+ Tỳ gối và gi ữ trọng lực gần với cơ th ể 
- Đẩy: 
+ Lực đẩy nên phát ra t ừ khoảng gi ữa vai và th ắt lưng 
+ Nếu cần đẩy cao: c ần chỉnh lại vị trí đứng phù h ợp 
+ Nếu trọng lượng cần đẩy ở thấp: qu ỳ gối và đ ẩy 
3.7. Phân lo ại di dời bệnh nhân  
- Di dời khẩn cấp 
- Di dời cấp cứu 
- Di dời không c ấp cứu 
- Di dời một số nhóm b ệnh nhân đ ặc biệt 
+ Ch ấn thương c ột sống, tu ỷ 
+ Sốc 
+ Có thai..  
3.7.1. Di dời khẩn cấp: 
- Cần di d ời bệnh nhân ngay trư ớc khi thăm khám đánh giá, chăm sóc, 
ổn định tình tr ạng bệnh nhân  
- Tình hu ống: 
+ Hiện trường nguy hi ểm: đám cháy, n ổ, chất độc .. 
+ Không ti ến hành c ấp cứu được do v ị trí và t ư thế bệnh nhân  
+ Cần chuy ển bệnh nhân phía ngoài đ ể tiếp cận bệnh nhân n ặng nguy 
kịch phia trong  
- Kỹ thuật di d ời khẩn cấp: 
+ Cần tránh làm n ặng thêm các t ổn thương (đ ặc biệt cột sống - tuỷ) 
+ Nên kéo b ệnh nhân theo tr ục dọc cơ th ể 
+ Ba kỹ thuật cơ b ản: 
. Nắm cổ áo - vai áo và kéo  
. Đặt bệnh nhân n ằm trên chăn ho ặc áo khoác và kéo chăn  
 . Luồn tay d ưới nách b ệnh nh ân, n ắm cẳng tay b ệnh nhân và kéo t ừ phía 
sau 
3.7.2. Di dời không c ấp cứu: 
- Khi hoàn c ảnh hi ện trường thu ận lợi 
- Tình tr ạng bệnh nhân ổn định 133 
 - Lập kế hoạch di d ời 
- Trước khi ti ến hành di d ời bệnh nhân, đ ội trưởng đội cứu hộ phải đảm 
bảo các bư ớc sau:  
+ Có đ ủ nhân l ực cần thiết. 
+ Các chư ớng ng ại vật đã đư ợc phát hi ện hoặc được di d ời. 
+ Các trang thi ết bị tốt nhất đã s ẵn sàng.  
+ Các bư ớc thực hiện được thảo luận kỹ. 
4. Vận chuy ển bệnh nhân c ấp cứu trong – ngoài b ệnh vi ện 
  - Thực tế thường xuyên ph ải vận chuy ển bệnh nhân n ặng trong và gi ữa các b ệnh 
viện vì nhu c ầu chăm sóc đi ều trị, hồi sức tích c ực, thăm dò ch ẩn đoán..  
  - Bệnh nhân luôn có nguy cơ n ặng lên và g ặp nguy hi ểm trong khi v ận chuy ển 
  - Quyết định vận chuy ển phải thực sự có lợi cho b ệnh nhân. Luôn ph ải cân 
nhắc giữa ích l ợi và nguy cơ c ủa vận chuy ển 
  - Hạn chế các nguy cơ cho b ệnh nhân trong quá trình v ận chuy ển: 
+ Chu ẩn bị kế hoạch vận chuy ển chu đáo: đánh giá và d ự đoán đư ợc  
nhu c ầu chăm sóc và can thi ệp có th ể phải thực hiện trong kh i vận chuy ển  
+ Nhân viên v ận chuy ển thích h ợp: xử lý đư ợc các di ễn biến trong khi 
vận chuy ển 
+ Ph ương ti ện vận chuy ển thích h ợp: đáp ứng được các di ễn biến trong 
khi v ận chuy ển 
4.1. V ận chuy ển trong trong b ệnh vi ện 
- Tốt nhất là vi ệc vận chuy ển đư ợc đảm nhi ệm bởi đội vận chuy ển 
chuyên nghi ệp 
- Chuy ển đến các khoa thăm dò ch ức năng, ch ẩn đoán hình ảnh 
- Các phòng can thi ệp 
- Phòng m ổ 
- Khoa đi ều trị tích c ực 
4.1.1. Thảo luận trước khi chuy ển: 
- Thảo luận giữa các bác s ỹ, giữa bác s ỹ với y tá, gi ữa y tá  với y tá v ề 
tình tr ạng bệnh nhân, đi ều trị (duy trì liên t ục sự chăm sóc và đi ều trị bệnh 
nhân)  
- Xác đ ịnh nơi nh ận đã s ẵn sàng đón b ệnh nhân  
- Thông báo cho bác s ỹ chính: b ệnh nhân s ẽ chuy ển đi, ai s ẽ chuy ển 
bệnh nhân, các nguy cơ có th ể khi rời khỏi kho a  
- Hồ sơ bệnh án: ghi ch ỉ định vận chuy ển, ghi di ễn biến trong quá trình 
vận chuy ển  134 
 4.1.2. Nhân viên v ận chuy ển: 
- Tối thiểu phải có hai nhân viên đ ể vận chuy ển bệnh nhân  
- Một y tá h ồi sức cấp cứu hoặc y tá chuyên v ề vận chuy ển  
- Một ngư ời phụ: kỹ thuật viên, y tá th ường (bác s ỹ) 
- Có thêm 1 bác s ỹ trong trư ờng hợp ệnh nhân nhân n ặng nguy cơ r ối 
loạn các ch ức năng s ống ho ặc nguy cơ c ần can thi ệp 
4.1.3. Phương ti ện: 
- Máy theo dõi đi ện tim/máy phá rung  
- Phương ti ện can thi ệp hô h ấp và bóng m ặt nạ 
- Bình oxy đ ủ dùng trên 30 phút  
- Thuốc tối thiểu cấp cứu: adrenalin, atropin, lidocain  
- Thuốc duy trì: an th ần, salbutamol, v ận mạch 
- Tiêm truy ền (máy truy ền dịch, bơm tiêm đi ện) 
- Nếu thở máy:  máy th ở khi v ận chuy ển phải đảm bảo các ch ức năng 
cơ bản như máy đang th ở tại khoa h ồi sức cấp cứu  
4.1.4. Theo dõi trong khi v ận chuy ển: 
- Đảm bảo theo dõi như  đang đ ược theo dõi t ại khoa h ồi sức cấp cứu 
- Theo dõi liên t ục và ghi đ ịnh kỳ: điện tim, n ồng độ oxy máu (SpO2)  
- Theo dõi và ghi đ ịnh kỳ: HA, m ạch, nhịp thở 
- Theo dõi đ ặc biệt tuỳ theo b ệnh nhân:EtCO 2, đo HA liên t ục, áp l ực 
động m ạch ph ổi liên t ục, áp l ực nội sọ,áplực tĩnh m ạch trung tâm, cung lư ợng 
tim 
- Cần đặc biệt lưu ý 2 th ời điểm: 
+ Khi r ời khoa chuy ển: chuy ển bệnh nhân t ừ giường lên cáng  
+ Khi đ ến khoa ti ếp nhận: chuy ển bệnh nhân t ừ cáng lên gi ường 
4.2. V ận chuy ển giữa các b ệnh vi ện: 
- Nguy cơ cao cho b ệnh nhân trong quá trình v ận chuy ển 
- Phải cân nh ắc giữa ích l ợi và nguy cơ c ủa vận chuy ển 
4.2.1. Lí do chính đ ể chuy ển bệnh nhân gi ữa các bệnh vi ện:   
- Bệnh nhân c ần được chăm sóc h ồi sức tích c ực hơn  
- Cần có k ỹ thuật thăm dò chuyên khoa cao hơn so v ới cơ s ở y tế đang 
điều trị 
- Cần có k ỹ thuật can thi ệp chuyên khoa cao hơn so v ới cơ s ở y tế đang 
điều trị 135 
 4.2.2. Thảo luận trước khi ch uyển 
- Bác s ỹ với bác s ỹ: 
+ Tình tr ạng bệnh nhân, đi ều trị  
+ Xác đ ịnh ch ỉ định vận chuy ển, chi ến lược xử trí 
+ Xác đ ịnh nơi nh ận đã chu ẩn bị sẵn sàng đón b ệnh nhân  
+ Cách th ức và ph ương ti ện vận chuy ển 
+ Chu ẩn bị phương ti ện dụng cụ  
- Hồ sơ bệnh án:  
+ Bệnh án tóm t ắt (tình tr ạng, di ễn biến, điều trị) 
+ Tóm t ắt phần theo dõi, chăm sóc th ực hiện điều trị của y tá (duy trì 
liên t ục theo dõi, chăm sóc, đi ều trị) 
+ Các phim xquang, CT scan, MRI  
4.2.3. Nhân viên v ận chuy ển: 
- Tối thiểu hai nhân viên (không  kể lái xe)  
- Một nhân viên là y tá h ồi sức cấp cứu có kinh nghi ệm, bác s ỹ, kỹ 
thuật viên v ận chuy ển (làm đ ược: đặt NKQ, x ử lý lo ạn nhịp, cấp cứu ngừng 
tuần hoàn, ng ừng th ở)  
- Nếu không có bác s ỹ đi cùng: c ần có ph ương ti ện liên l ạc trên xe và 
duy trì l iên lạc với bác s ỹ  
4.2.4. Các ph ương ti ện tối thiểu: 
- Các ph ương ti ện bảo vệ đường th ở và duy trì thông khí:  
+ Bóng và m ặt nạ 
+ Dụng cụ bảo vệ, khai thông đ ường th ở 
+ Đèn đ ặt NKQ, ống NKQ  
+ Bình oxy đ ủ dùng trên 1 gi ờ 
+ Máy hút đ ờm, xông hút đ ờm 
- Máy theo dõi đi ện tim/máy phá rung  
- Dụng cụ tiêm truy ền tĩnh m ạch 
- Thuốc cấp cứu, thu ốc duy trì đi ều trị 
- Phương ti ện liên l ạc với bệnh vi ện chuy ển, bệnh vi ện nhận 
4.2.5. Theo dõi trong khi v ận chuy ển: 
- Các theo dõi t ối thiểu 
+ Theo dõi điện tim liên t ục 
+ Theo dõi định kỳ: HA - Nhịp thở 136 
 + Nên có: SpO2 
- Tuỳ theo b ệnh nhân:  
+ Đo HA liên t ục - ALĐM ph ổi liên t ục - ALNS  
+ ALTMTT - cung l ượng tim  
- Nếu thông khí nhân t ạo: báo đ ộng tối thiểu (AL cao -tuột, hở đường 
thở) 
- Ghi chép di ễn biến trong khi v ận chuy ển 
4.2.5. Cần đặc biệt lưu ý 2 th ời điểm: 
Khi r ời khoa chuy ển: chuy ển bệnh nhân t ừ giường lên cáng, xe ô tô  
Khi đ ến khoa ti ếp nhận: 
Khi chuy ển bệnh nhân t ừ cáng sang gi ường 
Bàn giao h ồ sơ bệnh án - xquang  
Bàn giao các y l ệnh - thực hiện các y l ệnh (thuốc đang dùng, đã dùng -
thuốc pha trong d ịch truy ền..) 
 Đảm bảo sự liên t ục về theo dõi - điều trị - kế hoạch thăm dò ch ẩn đoán, 
điều trị 
5. Tư thế bệnh nhân trư ớc và trong khi v ận chuy ển đến bệnh vi ện 
5.1. Tư th ế bệnh nhân  
- Trước và trong khi v ận chuy ển là giai đo ạn bệnh nhân c ấp cứu và 
chấn thương có nguy cơ b ị tiến triển nặng thêm (do rung, l ắc, ..) 
- Cần đặt tư thế bệnh nhân phù h ợp với tình tr ạng th ần kinh, thông khí, 
huyết động, th ương t ổn.   
+ Góp ph ần đảm bảo hô h ấp, huy ết động 
+ Hạn chế tiến triển nặng, th ương t ổn thêm  
+ Làm quá trình c ấp cứu dễ thực hiện hơn  
 Cần theo dõi di ến biến và ch ọn lại tư thế cho phù h ợp với tình tr ạng m ới 
của bệnh nhân.  
- Bệnh nhân t ỉnh thư ờng ch ọn cho mình t ư thế thích h ợp nhất, cảm thấy 
dễ chịu nhất.Cần tôn trọng tư  thế lựa chọn của bệnh nhân n ếu thấy tư thế ấy 
phù h ợp 
- Trong b ệnh cảnh ch ấn thương:  
Luôn ph ải chú ý đ ến chấn thương c ột sống, đ ặc biệt là ch ấn thương c ột 
sống cổ 
Cần giữ thẳng trục đầu - cổ - thân 
Nẹp cổ nếu nghi ng ờ chấn thương c ột sống cổ 137 
 5.2. B ốn nhóm t ư thế cơ bản 
- Nằm ng ửa 
- Nằm nghiêng  
- Ngồi 
- Nằm sấp 
5.2.1. N ằm ng ửa- ngang  
 Ngừng tu ần hoàn - ngừng th ở (cổ ưỡn) 
Chấn thương c ột sống: cho phép th ực hiện các bi ện pháp c ấp cứu hô 
hấp- tuần hoàn  
5.2.2. N ằm ng ửa, chân cao  
Áp d ụng: ch ảy máu nhi ều - giảm thể tích n ặng (b ệnh nhân t ỉnh) 
Chống ch ỉ định: g ẫy chân ho ặc xương ch ậu 
5.2.3. N ằm ng ửa, đùi g ấp 
Áp d ụng: v ết thương ho ặc chấn thư ơng b ụng kín.  
Tác d ụng: gi ảm đau b ụng (do làm l ỏng các cơ b ụng) 
5.2.4. N ằm ng ửa, đầu cao 10 -30 độ 
Áp d ụng: chấn thương s ọ não  
Tác d ụng: tăng tu ần hoàn tĩnh m ạch trở về, giảm phù não  
Nguy cơ ảnh hưởng không t ốt lên HA  
5.2.5. N ằm nghiêng an toàn  
Áp d ụng: rối loạn ý th ức (không r ối loạn hô h ấp, tuần hoàn)  
Tác d ụng: Gi ải phóng đư ờng th ở, hạn chế nguy cơ hí t vào ph ổi 
5.2.6. Tư th ế sản khoa (n ằm nghiêng an toàn sang trái)  
 Áp d ụng cho b ệnh nhân mang thai trên 7 tháng có tác d ụng gi ảm chèn ép 
của tử cung vào tĩnh m ạch ch ủ dưới 
5.2.7. Ng ồi - chân thõng:  
Áp d ụng trong trư ờng hợp phù ph ổi cấp 
Tác d ụng: gi ảm tuần hoàn tĩnh m ạch trở về tim 
5.2.8. N ửa ngồi - chân th ẳng 
Áp d ụng: khi khó th ở và bệnh nhân còn t ỉnh (HPQ, b ệnh ph ổi mãn..).  
Tác d ụng: cơ hoành d ễ di động hơn, gi ảm đè ép c ủa các t ạng ổ bụng  
5.2.9. N ửa ngồi- chân g ấp 
Áp d ụng: ch ấn thương b ụng-ngực.  
Tác d ụng: ng ồi làm đ ễ cho th ở- gấp chân làm chùng cơ b ụng 138 
 5.2.10. Ng ồi ngả ra trước 
Viêm n ắp thanh qu ản (ch ưa đặt NKQ).  
Tác d ụng: gi ảm cản trở hô hấp giảm nguy cơ t ắc đường khí do phù n ề 
nắp thanh qu ản. Trong trư ờng hợp chảy máu mũi s ẽ làm h ạn chế chảy máu 
mũi sau  
5.2.11. N ằm sấp 
 Hiếm áp d ụng, áp d ụng: v ết thương ho ặc vết bỏng lưng quá đau  
Khó ch ịu cho b ệnh nhân - nguy cơ n ặng thêm hô h ấp 
Khó theo dõi b ệnh nhân  
6. Vận chuy ển bệnh nhân trong b ệnh cảnh ch ấn thương  
Cầm máu  
Vết thương c ắt cụt hoặc gần cắt cụt: garô vòng quanh chi  
Các v ết thương khác: ép tr ực tiếp vào đ ộng m ạch ch ảy máu ho ặc ép 
ngay sát trên ch ỗ vết thương b ằng băng đo HA bơm lên trên s ố HA t ối đa. 
Nếu có t ổn thương x ương gây ch ảy máu: nên n ẹp bằng nẹp hơi v ừa các 
tác d ụng cố định xương v ừa cầm máu.  
Gãy xư ơng và tr ật khớp gây bi ến dạng chi cũng c ần đặt lại đúng tư  thế và 
nẹp lại trước khi v ận chuy ển. Động tác x ử trí này giúp phòng các bi ến chứng: 
gãy x ương kín b ị chuy ển thành gãy xư ơng h ở, hoại tử vùng da b ị căng, kéo xo ắn 
hoặc ép đ ộng mạch. B ặng ph ủ bằng băng vô khu ẩn cho các gãy x ương h ở  
Tư th ế vận chuy ển tùy thu ộc tổn thương:  
Tổn thương chi trên đơn thu ần: nên ch ọn tư th ế nửa ngồi (sẽ thoải mái 
cho b ệnh nhân hơn)  
Tổn thương chi dư ới: nên ch ọn tư th ế nằm ng ửa, kê chân cao kho ảng 
10-20 độ (tác d ụng gi ảm phù n ề) 
Không đư ợc để chi tổn thương rơi ra ngoài cáng, chi đung đưa khi v ận 
chuy ển 
 
TÀI LIỆU THAM KHẢO  
1. Sơ cấp cứu trong môi trư ờng lao đ ộng, H ội chữ thập đỏ Việt Nam, 
Hà N ội, 2001  
2. Guideline for the transfer of critically ill pat ients  
3. Les dossier du généraliste  
4. Lifting and moving patients. Trong: care and transportation 1997  
5. Recommandations concernant les transports médicalisés 
intrahospitaliers. Conference de consensus de la SFAR 1994  139 
  
CÂU HỎI LƯỢNG GIÁ  
Câu 1: Tư th ế phù hợp cho m ột bệnh nhân c ấp cứu vì khó th ở là (1 ý 
đúng):  
A. Đặt bệnh nhân tư th ế nằm ng ửa đầu bằng. 
B. Đặt bệnh nhân ở tư thế nằm ng ửa đầu thấp  
C. Đặt bệnh nhân ở tư thế nằm ng ửa đầu cao  
D. Đặt bệnh nhân ở tư thế nằm nghiêng an toàn  
E. Đặt bệnh nhân ở tư thế nằm sấp 
Câu 2. Tư th ế phù h ợp cho m ột bệnh nhân c ấp cứu vì t ụt huy ết áp do 
mất máu là (1 ý đúng):  
A. Đặt bệnh nhân tư th ế nằm ng ửa đầu bằng. 
B. Đặt bệnh nhân ở tư thế nằm ng ửa chân cao  
C. Đặt bệnh nhân ở tư thế nằm ng ửa đầu cao  
D. Đặt bệnh nhân ở tư thế nằm đầu cao, nghiêng an toàn  
E. Đặt bệnh nhân ở tư thế nằm sấp 
Câu 3. Tư th ế phù h ợp cho m ột bệnh nhân c ấp cứu nghi ng ờ có ch ấn 
thương c ột sống là (1 ý đúng):  
A. Đặt bệnh nhân ở tư thế nằm ng ửa đầu bằng, trên cáng c ứng. 
B. Đặt bệnh nhân ở tư thế nằm ng ửa chân cao  
C. Đặt bệnh nhân ở tư thế nằm ng ửa đầu cao  
D. Đặt bệnh nhân ở tư thế nằm đầu cao, nghiêng an toàn  
E. Đặt bệnh nhân ở tư thế nằm sấp 
Câu 4. Các k ỹ thuật khiêng cáng an toàn là (nhi ều ý đúng):  
A. Trong khi khiêng cáng ph ải bước chân dài và nhanh.  
B. Khiêng cáng xu ống dốc hay xu ống cầu thang phía đ ầu bệnh nhân đi 
trước. 
C. Khiêng cáng lên d ốc hay lên c ầu thang phía đ ầu bệnh nhân đi trư ớc. 
D. Khiêng cáng xu ống dốc hay xu ống cầu thang phía chân b ệnh nhân 
đi trư ớc 
E. Theo dõi b ệnh nhân trong quá trình  vận chuy ển là không c ần thi ết, 
chỉ cần chuy ển bệnh nhân th ật nhanh.  
Câu 5.  Các tiêu trí nào sau đây th ể hiện bệnh nhân đư ợc vận chuy ển 
tốt (nhi ều ý đúng):  
A. Các phương ti ện dụng cụ, thuốc cấp cứu được chu ẩn bị đầy đủ. 140 
 B. Tư th ế bệnh nhân trong quá trình  vận chuy ển là không quan tr ọng. 
C. Các ch ức năng s ống của bệnh nhân đư ợc theo dõi ch ặt chẽ.  
D. Xử trí có k ết quả các bi ến cố xảy ra trong quá trình v ận chuy ển. 
E. Vận chuy ển an toàn ngư ời bệnh đến địa điểm đã đ ịnh và bàn giao 
đầy đủ. 141 
  
 
 
 
 
 
 
PHẦN II 
THỰC HÀNH  142 
 THỰC HÀNH KI ỂM SOÁT ĐƯ ỜNG TH Ở 
 
Họ tên h ọc viên:  
Lớp: 
Khóa h ọc: 
Thời gian:  
 
STT  Các bư ớc thực hiện Đã hoàn 
thành  
1 Xác đ ịnh nguyên nhân gây t ắc ngh ẽn đường th ở  
2 Đặt đúng tư th ế bệnh nhân   
3 Kỹ thuật ngửa đầu nhấc cằm  
4 Kỹ thuật ấn giữ hàm  
5 Kỹ thuật Heimlich tư th ế đứng (ngư ời lớn + tr ẻ 
em)  
6 Kỹ thuật Heimlich tư th ế nằm (ngư ời lớn + tr ẻ 
em)  
7 Kỹ thuật đặt canuyn h ọng mi ệng, mũi h ọng  
8 Kỹ thuật đặt mặt nạ thanh qu ản  
 
 143 
 THỰC HÀNH CẤP CỨU NG ỪNG TU ẦN HOÀN NÂNG CAO  
 
Họ tên h ọc viên:  
Lớp: 
Khóa h ọc: 
Thời gian:  
 
 
STT  Các bư ớc thực hiện Đã hoàn 
thành  
1 Xác đ ịnh bệnh nhân ng ừng tu ần hoàn   
2 Khởi động dây chuy ền cấp cứu  
3 Chuẩn bị   
4 Tiến hành khai thông đư ờng th ở  
5 Xác đ ịnh đúng v ị trí đặt mask   
6 Đặt mask và bóp bóng đúng k ỹ thuật  
7 Xác đ ịnh vị trí ½ dư ới xương ức  
8 Cách đ ặt tay đúng   
9 Tiến hành ép tim ngoài l ồng ng ực  
10 Đánh giá hi ệu quả của động tác ép tim   
11 Hoàn thành h ồ sơ bệnh án   
 144 
 THỰC HÀNH VẬN CHUY ỂN BỆNH NHÂN C ẤP CỨU 
 
 
Họ tên h ọc viên:  
Lớp: 
Khóa h ọc: 
Thời gian:  
 
 
STT Các bư ớc thực hiện Đã hoàn 
thành  
1 Xác đ ịnh nhanh chóng tình tr ạng bệnh nhân   
2 Quyết định phương th ức vận chuy ển  
3 Thực hành v ận chuy ển theo tình hu ống   
4 Chuy ển bệnh nhân n ặng  
Nâng b ệnh nhân   
Khiêng b ệnh nhân   
Chuy ển bệnh nhân t ừ cáng san g giư ờng  
5 Chuy ển bệnh nhân nh ẹ   
 
 145 
 THỰC HÀNH  
KỸ THU ẬT XỬ LÝ V ẾT THƯƠNG XUYÊN TH ẤU 
 
1. Yêu c ầu 
- Học viên nêu đư ợc nguyên t ắc xử lý các v ết thương xuyên th ấu tại khoa 
cấp cứu 
- Tiến hành thành th ạo kỹ thuật bất động vật xuyên th ấu 
- Nắm đư ợc tầm quan t rọng của việc đánh giá và x ử trí theo các bư ớc ABC  
2. Phương pháp th ực hành:  
- Học viên v ừa thao tác v ừa mô t ả bằng lời với giảng viên các k ỹ thuật 
đang th ực hiện 
- Sau khi h ọc viên th ực hành xong, gi ảng viên phân tích các đi ểm đạt và 
chưa đ ạt trong k ỹ thuật để học viên rút kinh nghi ệm 
- Học viên và giáo viên h ỏi đáp sau th ực hành  
3. Phương ti ện thực hành:  
- Người nộm: 1 
- Băng cu ộn: 10 cm x 5m ( băng chi, ng ực)  
- Băng cu ộn 5 cm x 2,5m ( băng m ặt) 
4. Các bư ớc thực hành  
Đeo phương ti ện phòng h ộ cá nhân   
Cố định cột sống cổ bằng tay   
Đánh giá và ki ểm soát đư ờng th ở 
 Hút đ ờm dãi  
 Đặt canyl mi ệng hầu  
Đánh giá và h ỗ trợ hô hấp 
 Oxy li ệu pháp  
 Cố định vật xuyên th ấu ngực nếu có  
Đánh giá và h ỗ trợ tuần hoàn  
 Bắt mạch cảnh 
 Màu da  
 Kiểm soát ch ảy máu: băng ép   
Đeo nẹp cổ 
 Đo kích c ỡ nẹp phù h ợp  146 
 Khám thương nhanh  
 Phát hi ện vật xuyên th ấu chi  cố định 
 Phát hi ện vật xuyên th ấu mắt  cố định  
Chuẩn bị cáng c ứng  
Nghiêng b ệnh nhân  
 kỹ thuật log-roll 
 kiểm tra c ột sống lưng   
Cố định thân mình b ệnh nhân vào cáng   
Cố định đầu  
Đánh giá m ạch cảm giác v ận động chi   
Đặt đường truy ền, xét nghi ệm, hội chẩn  
Theo dõi   
 147 
 THỰC HÀNH  
KỸ THU ẬT CỐ ĐỊNH XƯƠNG GÃY VÀ C ỘT SỐNG 
 
1. Yêu c ầu: 
- Học viên ti ến hành thành th ạo kỹ thuật bất động cột sống cổ, cột sống 
lưng và xương ch ậu Học viên s ử dụng thanh th ạo các d ụng cụ: nẹp cổ, nẹp đầu, 
ván c ứng, ga bu ộc khung ch ậu 
- Nắm đư ợc tầm quan tr ọng của việc đánh giá và x ử trí theo các bư ớc ABC  
2. Phương pháp th ực hành:  
- Học viên v ừa thao tác v ừa mô t ả bằng lời với giảng viên các k ỹ thuật 
đang th ực hiện 
- Sau khi h ọc viên th ực hành xong, gi ảng viên phân tích các đi ểm đạt và 
chưa đ ạt trong k ỹ thuật để học viên rút kinh nghi ệm 
- Học viên và giáo viên h ỏi đáp sau th ực hành  
3. Phương ti ện thực hành:  
- Ván c ứng kèm dây bu ộc: Allied HPI XTRA Backboard  with Straps  
- Nẹp cổ cứng ngư ời lớn: Stifneck Select Collars - Adult  
- Bộ cố định đầu: Head Immobilizer with Straps  
- Một tấm toan y t ế được gấp lại theo kích thư ớc: 40 x 150 cm  
- Panh có m ấu để cố định toan: 6 chi ếc 
- Người nộm: 1 
4. Các bư ớc thực hành  
Đeo phương ti ện phòng h ộ cá nhân   
Cố định cột sống cổ bằng tay   
Đánh giá và ki ểm soát đư ờng th ở 
 Hút đ ờm dãi  
 Đặt canyl mi ệng hầu  
Đánh giá và h ỗ trợ hô hấp 
 Oxy li ệu pháp   
Đánh giá và h ỗ trợ tuần hoàn 
 Bắt mạch cảnh 
 Màu da  
 Kiểm soát ch ảy máu: băng ép   148 
 Đeo n ẹp cổ 
 Đo kích c ỡ nẹp phù h ợp  
Khám thương nhanh  
 Phát hi ện khung ch ậu mất vững  
Chuẩn bị cáng c ứng 
 Trải tấm toan c ố định khung ch ậu  
Nghiêng b ệnh nhân  
 kỹ thuật log-roll 
 kiểm tra c ột sống lưng   
Buộc tấm toan, c ố định khung ch ậu 
 Dùng panh có m ấu để cặp  
Cố định thân mình b ệnh nhân vào cáng   
Cố định đầu  
Đánh giá m ạch cảm giác v ận động chi   
Đặt đường truy ền  
Theo dõi**

## Thai ngoài tử cung: trường hợp song thai đặc biệt với một thai trong tử cung và một thai ngoài tử cung cùng tồn tại tại bệnh viện Nguyễn Tri Phương

  * [Xử trí kịp thời, cứu sống cả mẹ và thai](https://bvnguyentriphuong.com.vn/cap-cuu/thai-ngoai-tu-cung-truong-hop-song-thai-dac-biet-voi-mot-thai-trong-tu-cung-va-mot-thai-ngoai-tu-cung-cung-ton-tai-tai-benh-vien-nguyen-tri-phuong#x-tr-kp-thi-cu-sng-c-m-v-thai)
  * [Tại sao có thể mang thai ở 2 vị trí khác nhau?](https://bvnguyentriphuong.com.vn/cap-cuu/thai-ngoai-tu-cung-truong-hop-song-thai-dac-biet-voi-mot-thai-trong-tu-cung-va-mot-thai-ngoai-tu-cung-cung-ton-tai-tai-benh-vien-nguyen-tri-phuong#ti-sao-c-th-mang-thai-2-v-tr-khc-nhau)
  * [Thông điệp từ khoa Sản - Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/cap-cuu/thai-ngoai-tu-cung-truong-hop-song-thai-dac-biet-voi-mot-thai-trong-tu-cung-va-mot-thai-ngoai-tu-cung-cung-ton-tai-tai-benh-vien-nguyen-tri-phuong#thng-ip-t-khoa-sn-bnh-vin-nguyn-tri-phng)


Thai ngoài tử cung là một biến chứng nguy hiểm trong thai kỳ, khi phôi thai phát triển bên ngoài tử cung, thường gặp nhất ở vòi trứng. Đặc biệt, trường hợp thai ngoài rất hiếm gặp: song thai với một thai trong tử cung và một thai ngoài tử cung cùng tồn tại, chỉ xảy ra ở khoảng 1/30.000 trường hợp mang thai tự nhiên và khoảng trên 1/100 trường hợp thụ tinh ống nghiệm. Đây là một thách thức lớn nhưng cũng là cơ hội để minh chứng khả năng xử trí hiệu quả của bác sĩ lâm sàng.
Ngày 22/12/2024, Khoa Phụ sản – Bệnh viện Nguyễn Tri Phương tiếp nhận một bệnh nhân nữ 30 tuổi trong tình trạng đau bụng dữ dội, huyết áp giảm nghiêm trọng. Bệnh nhân có tiền sử sinh thường 2 con, trễ kinh 3 tuần nhưng chưa khám thai. Kết quả siêu âm cho thấy có một phôi thai sống trong tử cung (khoảng 6–7 tuần), dịch tự do trong ổ bụng lượng nhiều nghĩ máu và khối dạng nang thành không đều ở hố chậu phải.
## **Xử trí kịp thời, cứu sống cả mẹ và thai**
Sau khi khai thác tình trạng bệnh, các bác sĩ khoa Sản bệnh viện Nguyễn Tri Phương ban đầu đánh giá đây là 1 trường hợp cần phẫu thuật cấp cứu và truyền máu khẩn vì bệnh nhân có dấu hiệu sốc mất máu, nghi ngờ xuất huyết nội do nang hoàng thể vỡ. Ca phẫu thuật ghi nhận hơn 1.100 ml máu trong ổ bụng và phát hiện có khối thai vỡ tại vòi trứng phải. Các bác sĩ đã thực hiện cắt vòi trứng phải để cầm máu, đồng thời bảo toàn phôi thai trong tử cung.
Sau phẫu thuật, ngày 23/12/2024, siêu âm kiểm tra cho thấy phôi thai trong tử cung phát triển tốt # 7 tuần 1 ngày. Bệnh nhân hồi phục ổn định và được xuất viện trong những ngày tiếp theo.
## **Tại sao có thể mang thai ở 2 vị trí khác nhau?**
Nguyên nhân thực sự của tình trạng này vẫn chưa được biết rõ. Tuy nhiên, có hai giả thuyết như sau:
  * Thứ nhất, hai trứng có thể được thụ tinh độc lập bởi hai tinh trùng khác nhau cùng một lúc nhưng hai phôi lại làm tổ ở những vị trí khác nhau, một trong tử cung và một bên ngoài tử cung.
  * Thứ hai, sau khi thai ngoài tử cung đã phát triển, một trứng khác có thể được thụ tinh và làm tổ vào buồng tử cung.


Việc chẩn đoán thai ngoài tử cung và thai trong tử cung cùng tồn tại rất khó khăn trong các trường hợp cấp cứu phụ khoa vì các triệu chứng dễ bị che lấp và nhầm lẫn với các biến chứng thai kỳ sớm khác do có một thai trong tử cung. 
## **Thông điệp từ khoa Sản - Bệnh viện Nguyễn Tri Phương**
Thai ngoài tử cung có thể xuất hiện ở bất kỳ ai, đặc biệt những người có tiền sử viêm vùng chậu, phẫu thuật vòi trứng hoặc sử dụng kỹ thuật hỗ trợ sinh sản. Triệu chứng thường gặp gồm đau bụng, ra máu âm đạo bất thường, chóng mặt hoặc ngất xỉu.
Với đội ngũ bác sĩ chuyên môn và tận tâm, Khoa Phụ sản – Bệnh viện Nguyễn Tri Phương luôn sẵn sàng tiếp nhận và xử trí các ca bệnh phức tạp. Chúng tôi tự hào mang lại sự an tâm cho mẹ và bé trong suốt thai kỳ.
***** Lời khuyên:** Nếu bạn trễ kinh, có dấu hiệu bất thường hoặc nghi ngờ mình mang thai, hãy đến ngay bệnh viện để kiểm tra. Đừng chủ quan – khám thai sớm chính là chìa khóa bảo vệ sức khỏe của bạn và bé yêu.
**Bệnh viện Nguyễn Tri Phương**
☎ **Số****điện thoại:** 028.3923.4349
**Địa chỉ** : 468 Nguyễn Trãi, P.8, Q.5, TP.HCM
Hãy chia sẻ thông tin này để bảo vệ sức khỏe của bạn và những người thân yêu! ❤
_(Bài viết được thực hiện bởi Khoa Phụ sản – Bệnh viện Nguyễn Tri Phương)_
  * [Xử trí kịp thời, cứu sống cả mẹ và thai](https://bvnguyentriphuong.com.vn/cap-cuu/thai-ngoai-tu-cung-truong-hop-song-thai-dac-biet-voi-mot-thai-trong-tu-cung-va-mot-thai-ngoai-tu-cung-cung-ton-tai-tai-benh-vien-nguyen-tri-phuong#x-tr-kp-thi-cu-sng-c-m-v-thai)
  * [Tại sao có thể mang thai ở 2 vị trí khác nhau?](https://bvnguyentriphuong.com.vn/cap-cuu/thai-ngoai-tu-cung-truong-hop-song-thai-dac-biet-voi-mot-thai-trong-tu-cung-va-mot-thai-ngoai-tu-cung-cung-ton-tai-tai-benh-vien-nguyen-tri-phuong#ti-sao-c-th-mang-thai-2-v-tr-khc-nhau)
  * [Thông điệp từ khoa Sản - Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/cap-cuu/thai-ngoai-tu-cung-truong-hop-song-thai-dac-biet-voi-mot-thai-trong-tu-cung-va-mot-thai-ngoai-tu-cung-cung-ton-tai-tai-benh-vien-nguyen-tri-phuong#thng-ip-t-khoa-sn-bnh-vin-nguyn-tri-phng)



## ️ Xử trí chảy máu cam: cúi đầu phía trước hay ngửa đầu ra sau?

Chảy máu mũi (hay chảy máu cam) đứng hàng đầu về tần số gặp trong chảy máu đường hô hấp trên tự phát. Niêm mạc mũi rất dễ chảy máu vì có nhiều mạch máu tập trung và mạng lưới mao mạch cung cấp rất dày.
Chảy máu mũi (hay chảy máu cam) đứng hành đầu về tần số gặp trong chảy máu đường hô hấp trên tự phát.
Vị trí thường chảy là**điểm mạch Kisselbach** , đây là nơi các mạch máu đi nông ở 1/3 trước dưới vách mũi và quy tụ tại một điểm, cách lỗ mũi trước khoảng 1,5cm.
**Điểm mạch Kiesselbach (Kiesselbach Plexus) quy tụ 4 mạch máu:**
+ Động mạch cảnh ngoài bao gồm:
ĐM bướm khẩu cái (**Sphenopalatine artery)**
ĐM khẩu cái lớn **(Greater palatine artery)**
+ Động mạch cảnh trong bao gồm:
ĐM sàng trước **(Anterior ethmoid artery)**
ĐM sàng sau **(Posterior ethmoid artery)**.
Chảy máu mũi hay gặp ở độ tuổi trên 40, do thành mạch lúc này đàn hồi kém. Một số bệnh như tăng huyết áp, tình trạng dị ứng…hoặc rối loạn vận mạch làm làm gia tăng nguy cơ chảy máu. Ở trẻ em, chảy máu là do ngoáy mũi, viêm nhiễm tại mũi, nhiễm trùng toàn thân (sốt do virut, viêm gan mạn tính, tiểu đường,…). Tuy nhiên, chảy máu mũi không rõ nguyên nhân chiếm tỷ lệ lớn nhất. Đây là loại chảy máu mũi tự nhiên, lượng máu chảy ít, tự cầm, hay tái diễn, thường xảy ra khi gắng sức hoặc đi ngoài trời nắng.
Chính vì thế trước một người chảy máu mũi nên biết cách cầm máu trước, khi ổn định mới tiến hành tìm hiểu nguyên nhân. Tại nhà, nếu chảy máu mũi nhẹ: máu chảy nhỏ giọt ra phía trước của mũi, số lượng ít nên để người bệnh**ngồi cúi về trước, dùng ngón cái và ngón trỏ bóp chặt hai cánh mũi trong 10 phút, máu có thể tự cầm.** Theo kinh nghiệm dân gian, những nơi có sẵn lá nhọ nồi hay lá chuối non có thể giã nhỏ rồi nhét vào bên mũi chảy máu, vì chúng có chứa các chất kích thích hoạt động của tiểu cầu.
Nếu máu vẫn tiếp tục chảy nhiều ra trước mũi và xuống dưới miệng thì tuyệt đối**không được nuốt máu vào bụng** tránh chướng bụng và những chất độc do máu phân huỷ tạo thành, cho uống thuốc an thần như seduxen (nếu có). Nếu ở xa trung tâm y tế có thể tự tìm đoạn vải dài, sạch ấn sâu vào trong hốc mũi chảy máu rồi khẩn trương vận chuyển người bệnh đến trung tâm y tế gần nhất để cầm máu và tìm nguyên nhân để điều trị.
Ngửa đầu ra sau khi xử trí chảy máu cam là không phù hợp, vì nó làm ta không đánh giá được lượng máu mất là bao nhiêu. Lượng máy chảy ra khi ngửa đầu có khi sẽ được nuốt vào dạ dày, máu trong dạ dày có thể gây kích thích nôn. Ở trẻ nhỏ, máu chảy ngược về phía sau có thể gây tắc nghẽn hô hấp.
Chảy máu mũi rất hay tái phát, do vậy để phòng tránh, bệnh nhân cần thực hiện đúng hướng dẫn của bác sĩ như: tiếp tục điều trị những viêm nhiễm tại mũi, khám và điều trị theo các chuyên khoa khác đã được xác định là nguyên nhân gây ra chảy máu mũi.
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh

## Sự nguy hiểm khi trẻ nuốt phải nam châm


## Phải làm gì khi gặp người bị chấn thương cột sống?

  * [Nguyên tắc cấp cứu nạn nhân nghi ngờ bị chấn thương vùng cổ hoặc vùng lưng](https://bvnguyentriphuong.com.vn/cap-cuu/phai-lam-gi-khi-gap-nguoi-bi-chan-thuong-cot-song#nguyn-tc-cp-cu-nn-nhn-nghi-ng-b-chn-thng-vng-c-hoc-vng-lng)
  * [Nếu bắt buộc phải di dời bệnh nhân ngay thì thực hiện các biện pháp sau](https://bvnguyentriphuong.com.vn/cap-cuu/phai-lam-gi-khi-gap-nguoi-bi-chan-thuong-cot-song#nu-bt-buc-phi-di-di-bnh-nhn-ngay-th-thc-hin-cc-bin-php-sau)


Do tình hình phát triển của đô thị và vùng nông thôn Việt Nam ngày nay, số lượng xe gắn máy gia tăng cũng như tốc độ xây dựng đang phát triển để hình thành những đô thị mới. Điều này đi đôi với việc chấn thương cột sống và tủy sống cũng gia tăng theo.
Đây là một loại tổn thương dễ dẫn đến tàn phế và để lại nhiều di chứng. Do đó, khi có chấn thương cột sống xảy ra, điều quan trọng là phải thực hiện cấp cứu ban đầu cho đúng và phù hợp để tránh gây tổn thương thêm.
### Nguyên tắc cấp cứu nạn nhân nghi ngờ bị chấn thương vùng cổ hoặc vùng lưng
  * Không di chuyển hoặc để nạn nhân tự di chuyển. Trừ những trường hợp nạn nhân đang trong những tình huống có thể nguy hiểm đến tính mạng.
  * Không cúi gập hay quay phần lưng, cổ và đầu của nạn nhân.
  * Để tránh sốc, giữ ấm toàn thân nạn nhân, nhưng vẫn không thay đổi tư thế của nạn nhân.
  * Gọi cấp cứu ngay lập tức.


### Nếu bắt buộc phải di dời bệnh nhân ngay thì thực hiện các biện pháp sau
  * Luôn giữ người nạn nhân trên một đường thẳng.
  * Nếu có thể nên cần 4 người. Lần lượt giữ cố định tại vị trí đầu và cổ, vai, thắt lưng và chân của nạn nhân. Nếu như không có đủ 4 người thì cần có 1 người giữ đầu của nạn nhân và người còn lại giữ lưng nạn nhân.
  * Khi người giữ đầu nạn nhân hô to “Quay” thì cùng lúc cả 4 người cùng lúc thực hiện. Hành động quay người nạn nhân một cách nhẹ nhàng. Vẫn giữ đầu, cổ và thân của nạn nhân thẳng hàng.
  * Cột chặt người nạn nhân trên một tấm ván, vác tấm ván và nạn nhân một cách an toàn.


  * [Nguyên tắc cấp cứu nạn nhân nghi ngờ bị chấn thương vùng cổ hoặc vùng lưng](https://bvnguyentriphuong.com.vn/cap-cuu/phai-lam-gi-khi-gap-nguoi-bi-chan-thuong-cot-song#nguyn-tc-cp-cu-nn-nhn-nghi-ng-b-chn-thng-vng-c-hoc-vng-lng)
  * [Nếu bắt buộc phải di dời bệnh nhân ngay thì thực hiện các biện pháp sau](https://bvnguyentriphuong.com.vn/cap-cuu/phai-lam-gi-khi-gap-nguoi-bi-chan-thuong-cot-song#nu-bt-buc-phi-di-di-bnh-nhn-ngay-th-thc-hin-cc-bin-php-sau)



## Tài liệu đào tạo cấp cứu ban đầu

**[Tài liệu đào tạo cấp cứu ban đầu](https://drive.google.com/file/d/1-ETrqOALY7Jjr3YCV7cxbLykWXiE-077/view?usp=drive_link) (Tổ chức Y tế thế giới)**

## ️ Giới thiệu khoa Cấp cứu bệnh viện Nguyễn Tri Phương

  * [I. Thông tin lãnh đạo khoa Cấp Cứu Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/cap-cuu/gioi-thieu-khoa-cap-cuu-benh-vien-nguyen-tri-phuong#i-thng-tin-lnh-o-khoa-cp-cu-bnh-vin-nguyn-tri-phng)
  * [II. Thông tin giới thiệu về khoa](https://bvnguyentriphuong.com.vn/cap-cuu/gioi-thieu-khoa-cap-cuu-benh-vien-nguyen-tri-phuong#ii-thng-tin-gii-thiu-v-khoa)


## **I. Thông tin lãnh đạo khoa Cấp Cứu Bệnh viện Nguyễn Tri Phương**
**1. Trưởng khoa**
BS.CK2: **Đỗ Quốc Hùng**
  * Tốt nghiệp BS: Năm 1993 trường Đại Học Y Dược TP Hồ Chí Minh
  * Năm cấp bằng BS.CK1: 2002 - Chuyên ngành: Nội Tổng Quát tại Trường Đại Học Y Dược TPHCM
  * Năm cấp bằng BS.CK2: 2012 - Chuyên ngành: Lão khoa tại Trường Đại Học Y Dược TPHCM
  * Thời gian công tác tại bệnh viện: 27 năm.


Trong suốt thời gian này, BS.CK2 Đỗ Quốc Hùng đã công tác qua nhiều chuyên khoa, phòng (khoa cấp cứu, khoa hô hấp, khoa lão, PTGMHS, khoa hồi sức tích cực – chống độc, khoa khám bệnh, phòng chỉ đạo tuyến, khoa cơ xương khớp), giữ chức vụ Phó Khoa Hồi Sức Tích Cực Chống Độc, Phó khoa Phẫu Thuật Gây Mê Hồi Sức, Phó khoa Lão, Trưởng khoa Lão, Phụ trách điều hành khoa Cơ Xương Khớp, Trưởng khoa Khám Bệnh, trưởng Phòng Chỉ Đạo Tuyến, trưởng khoa Cấp Cứu .
Với vai trò lảnh đạo khoa và phòng tôi luôn gương mẫu trong công tác, luôn học tập nâng cao trình độ chuyên môn nghiệp vụ, luôn quan tâm đời sống vật chất, tinh thần của nhân viên trong khoa phòng, luôn tạo môi trường làm việc thân thiện , hòa đồng nhằm phát huy tốt năng lực từng cá nhân trong khoa phòng.
  * Nhận được nhiều giấy khen từ Bệnh viện và Công đoàn, là chiến sĩ thi đua cơ sở qua nhiều năm liền.
  * Chiến sĩ thi đua cấp thành phố, bằng khen của chủ tịch ủy ban nhân dân TP Hồ Chí Minh.


Đã thực hiện các công trình NCKH:
  * Khảo sát [**Albumin niệu vi lượng**](https://bvnguyentriphuong.com.vn/cac-chuyen-khoa/khoa-kham-benh/tong-quan-ve-tieu-albumin-vi-luong.html) trên bệnh nhân có và không có tăng huyết áp.
  * Nghiên cứu nồng độ acide uric huyết thanh ở bệnh nhân tăng huyết áp cao tuổi
  * Khảo sát đặc điểm của rối loạn [**lipid máu**](https://bvnguyentriphuong.com.vn/cac-chuyen-khoa/khoi-noi/noi-tim-mach/roi-loan-lipid-mau.html) ở đối tượng bệnh nhân trên 60 tuổi nhập khoa lão.
  * Khảo sát tỷ lệ tử vong dựa vào hệ thống điểm APACHE II cho tất cả bệnh nhập nhập ICU bệnh viện Nguyễn Tri Phương


**2. Phó trưởng khoa**
BS.CK1: **Nguyễn Hữu Nhân Duyên**
  * Tốt nghiệp BS năm: 2008
  * Năm cấp bằng BS.CK1: 2016
  * Thời gian công tác tại bệnh viện: 10 năm.


Từ 2008 đến nay công tác tại Khoa Cấp Cứu, đảm nhận chức vụ phó khoa Cấp Cứu từ năm 2017
Chấp hành tốt chủ trương, chính sách, pháp luật của nhà nước.
Trực tiếp tham gia tích cực công tác điều trị, xử trí cấp cứu cho bệnh nhân tại khoa Cấp Cứu.
Lãnh đạo trực tiếp công tác khám chữa bệnh tại khoa cấp cứu.
Xây dựng các qui trình, qui định, chịu trách nhiệm chính về chuyên môn tại khoa cấp cứu.
Tạo được sự đoàn kết, thống nhất, tương trợ trong tập thể khoa.
**3. Điều dưỡng trưởng khoa**
DD.CK1: **Nguyễn Thị Lan Minh**
  * Năm tốt nghiệp trình độ Cử nhân: 2009
  * Năm nhận bằng Điều dưỡng CKI: 2016.
  * Thời gian công tác tại bệnh viện: 27 năm.


Đã công tác qua nhiều chuyên khoa (khoa Nhi , KSNK, Ngoại, PTGMHS, Cấp Cứu), giữ chức vụ ĐDTK trên 15 năm.
Nhận được nhiều giấy khen từ BV và Công đoàn, là chiến sĩ thi đua cơ sở qua nhiều năm liền.
## **II. Thông tin giới thiệu về khoa**
Khoa Cấp được hình thành từ khi mới thành lập bệnh viện, với qui mô nhỏ. Theo quá trình phát triển của bệnh viện đến nay tại Khoa có 20 gường bệnh cấp cứu, phân 3 khu:
  * Khu tiếp nhận sàng lọc, khai báo y tế : 2 giường.
  * Khu khám sàng lọc, cách ly : 4 giường.
  * Khu vực an toàn: 14 gường ( 05 giường bệnh nặng).


Khoa Cấp Cứu với đội ngũ y Bác sĩ trẻ, năng động, tâm huyết với nghề, không ngại khó, luôn luôn có mặt tại khoa 24/7 sẵn sàng hết lòng phục vụ công tác cấp cứu bệnh nhân. Với tinh thần tự hoàn thiện bản thân, nhân viên luôn phấn đấu học tập trau dồi chuyên môn, hiện tại khoa có 1 BS CKII, 4 BS CKI, 1 ThsBS, đến 2022 tất cả các điều dưỡng đều đạt trình độ CĐDD trở lên. 
Khoa được trang bị khá đầy đủ các trang thiết bị sử dụng trong cấp cứu:
  * 2 máy sốc điện,
  * 1 máy thở,
  * 4 máy monitor,
  * 2 máy ECG,
  * 2 máy hút đàm,
  * 8 bơm tiêm điện,
  * 4 máy đo Spo2,
  * 1 máy siêu âm,
  * 5 máy phun khí phun.


Khoa thực hiện tốt công tác cấp cứu nội ngoại viện, tiếp nhận khám và cấp cứu từ 100- 150 bệnh nhân/1 ngày.
Từ 2017 khoa Cấp Cứu phối hợp với các khoa lâm sàng xây dựng và đưa vào thực hiện các qui trình báo động đỏ cấp cứu chấn thương (code red) cấp cứu ngừng tim trong bệnh viện (code blue), tiêu sợi huyết cấp cứu hoặc can thiệp mạch máu não bằng phương pháp kéo huyết khối ở Bệnh nhân [**đột quỵ**](https://bvnguyentriphuong.com.vn/cac-chuyen-khoa/khoi-noi/noi-tim-mach/phan-loai-cac-dang-dot-quy.html) (code Stroke), can thiệp mạch vành cấp cứu ở các bệnh nhân nhồi máu cơ tim cấp. Đã thực hiện thành công ở nhiều trường hợp và số lượng ngày càng tăng dần.
Trong mùa dịch bệnh khoa cũng đã hoàn chỉnh phòng cách ly, phân công nhân viên khám sàng lọc cho tất cả các bệnh nhân vào Cấp cứu, đảm bảo an toàn cho bệnh nhân, nhân viên, tránh lây nhiễm chéo.
Khoa Cấp cứu của bệnh viện cũng được gọi là khoa “Đầu sóng ngọn gió” nên áp lực cho nhân viên y tế rất cao, vì vậy nhân viên khoa luôn đặt mình trong nhiều hoàn cảnh mà có thái độ giao tiếp ứng xử đúng mực và luôn có sự hỗ trợ của đồng nghiệp phía sau.
Nhiều năm liền Khoa đạt danh hiệu “ Tập thể lao động xuất sắc”. Nhân viên khoa tham gia đầy đủ các phong trào do BV phát động: văn nghệ, hội thao, hiến máu tình nguyện, khám chữa bệnh từ thiện. 
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [I. Thông tin lãnh đạo khoa Cấp Cứu Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/cap-cuu/gioi-thieu-khoa-cap-cuu-benh-vien-nguyen-tri-phuong#i-thng-tin-lnh-o-khoa-cp-cu-bnh-vin-nguyn-tri-phng)
  * [II. Thông tin giới thiệu về khoa](https://bvnguyentriphuong.com.vn/cap-cuu/gioi-thieu-khoa-cap-cuu-benh-vien-nguyen-tri-phuong#ii-thng-tin-gii-thiu-v-khoa)



## Phiếu tóm tắt thông tin điều trị các bệnh lý cấp cứu

**1. Phiếu tóm tắt thông tin điều trị là gì?**
Phiếu tóm tắt thông tin điều trị giúp cho người bệnh theo dõi và cùng tham gia vào quá trình điều trị với bác sĩ và nhân viên y tế 
Phiếu tóm tắt thông tin điều trị được xây dựng cho một bệnh xác định. Thiết kế theo dạng tờ rơi trên 1 tờ giấy khổ A4 hoặc A5 (1 trang hoặc 2 trang). Các thông tin chính được rút ra từ hướng dẫn chẩn đoán và điều trị của bệnh viện. Nội dung bao gồm:
  * Các triệu chứng lâm sàng;
  * Xét nghiệm CLS;
  * Chẩn đoán;
  * Phương pháp điều trị;
  * Biến chứng;
  * Điều trị biến chứng và Hướng dẫn chăm sóc, cách dùng thuốc, dinh dưỡng, sinh hoạt;
  * Phòng ngừa;
  * Truyền thông giáo dục sức khỏe. 


**2. Sử dụng phiếu tóm tắt thông tin như thế nào?**
Thông qua phiếu tóm tắt thông tin điều trị Người bệnh có thể biết được và tự theo dõi được quá trình điều trị bằng cách đánh dấu vào danh mục (hoặc bảng kiểm). Dựa trên các mục đã được đánh dấu, người bệnh có thể biết được các hoạt động thăm khám, xét nghiệm, chẩn đoán hình ảnh, nội soi, thăm dò chức năng, thủ thuật, phẫu thuật, phương pháp điều trị, loại thuốc điều trị... đã thực hiện hoặc dự kiến thực hiện. Từ việc theo dõi này, người bệnh có thể hỏi nhân viên y tế lý do chưa nhận được dịch vụ y tế trong phiếu tóm tắt và tiến trình điều trị đang đến giai đoạn nào.
Phiếu có thể tích hợp thêm các hướng dẫn, khuyến cáo tóm tắt về chế độ dinh dưỡng, phòng tránh tái phát, biến chứng của bệnh và các vấn đề cần lưu ý khác, giúp việc điều trị, chăm sóc hiệu quả hơn
**[Phiếu tóm tắt thông tin điều trị Bệnh lý Chấn thương đầu](https://bvnguyentriphuong.com.vn/uploads/072022/files/1_%20L%E1%BB%9CI%20D%E1%BA%B6N%20CH%E1%BA%A4N%20TH%C6%AF%C6%A0NG%20%C4%90%E1%BA%A6U.pdf)
#### Nội dung trong file:

BỆNH VI ỆN NGUY ỄN TRI PHƯƠNG  
KHOA CẤP CỨU PHIẾU TÓM T ẮT 
THÔNG TIN ĐI ỀU TR Ị 
HƯỚNG D ẪN THEO DÕI TẠI NHÀ   
BỆNH NHÂN  CHẤN THƯƠNG Đ ẦU  
Bệnh nhân v à thân nhân phải tiếp tục theo dõi bệnh nhân tại nhà và đưa bệnh nhân vào 
ngay Bệnh viện để điều trị khi người bệnh có những biểu hi ện sau: 
1. Nhức đầu dữ dội  
2. Ói mửa nhiều lần  
3. Yếu một bên tay chân  
4. Giật tay chân  
5. Da đầu sưng lớn dần  
6. Lơ mơ, lúc tỉnh lúc mê  
7. Ngủ kêu không thức dậy  
8. Lỗ tai hay lỗ mũi chảy dịch trong  
9. Tính tình thay đổi  
10. Co giật**
**[Phiếu tóm tắt thông tin điều trị Bệnh lý Đau bụng cấp](https://bvnguyentriphuong.com.vn/uploads/072022/files/2_%20L%E1%BB%9CI%20D%E1%BA%B6N%20%C4%90AU%20B%E1%BB%A4NG%20C%E1%BA%A4P.pdf)
#### Nội dung trong file:

BỆNH VI ỆN NGUY ỄN TRI PHƯƠNG  
KHOA CẤP CỨU PHIẾU TÓM T ẮT 
THÔNG TIN ĐI ỀU TR Ị 
HƯỚNG D ẪN THEO DÕI T ẠI NHÀ  
BỆNH NHÂN  ĐAU B ỤNG C ẤP  
Đau bụng là một triệu chứng phức tạp, trong đó có một số trường hợp có thể có diễn tiến 
mới, sau khi đã tạm ổn. Do đó, để đảm bảo an toàn cho bệnh nhân sau khi được sơ cứu và 
xuất viện, bệnh nhân và thân nhân cần lưu ý theo cách hướng dẫn sau:  
1. Tuân thủ sự giải thích, hướng dẫn của Bác sĩ khi cho xuất viện  
2. Uống thuốc theo toa được cấp (nếu có). Không tự ý sử dụng các thuốc khác.  
3. Tái khám lại ngay khi có một trong các tình huống sau:  
a. Đau bụng:  
- Vẫn còn đau sau khi uống thuốc.  
- Đau trở  lại sau khi tạm giảm đau.  
- Đau tăng hơn.  
b. Có một trong các triệu chứng kèm theo như:  
- Buồn nôn, tiêu chảy.  
- Sốt. 
- Cảm giác mệt mỏi, bất an.  
- Hoặc có bất thường kh ác 
Khoa Cấp cứu sẵn sàng tiếp nhận 24/24 giờ, để khám và xử trí tiếp tục cho Ông (Bà)**
**[Phiếu tóm tắt thông tin điều trị Bệnh lý Sốt](https://bvnguyentriphuong.com.vn/uploads/072022/files/3_%20L%E1%BB%9CI%20D%E1%BA%B6N%20BN%20S%E1%BB%90T.pdf)
#### Nội dung trong file:

BỆNH VI ỆN NGUY ỄN TRI PHƯƠNG  
KHOA CẤP CỨU PHIẾU TÓM T ẮT 
THÔNG TIN ĐI ỀU TR Ị 
HƯỚNG D ẪN THEO DÕI T ẠI NHÀ  
BỆNH NHÂN  SỐT CẤP TÍNH   
Có nhiều nguyên nhân gây ra tình trạng sốt. Trong đó, có nhiều nguyên nhân lành tính, 
nhưng cũng có nhiều nguyên nhân có thể diễn tiến nặng. Người bệnh và thân nhân cần lưu 
ý theo dõi và nhập viện ngay khi có 1 trong các dấu hiệu sau:  
- Chảy máu răng, chảy máu mũi  
- xuất hiện chấm xuất huyết dưới da  
- ói ra máu, tiêu phân đen  
- sốt cao không giảm khi uống thuốc hạ sốt  
- đau bụng  
- hoa mắt, chóng mặt, nôn ói nhiều lần  
Khoa Cấp cứu sẵn sàng tiếp nhận 24/24 giờ, để khám và xử trí tiếp tục cho Ông (Bà)**
**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/) **- Đa khoa Hạng I Thành phố Hồ Chí Minh

## Sách: 3 Phút Sơ Cứu “phiên bản Lite”

Bác sĩ Hung Ngo kết hợp với Ford Việt Nam thiết kế bộ flashcard dùng cho điện thoại. 

## ️ Các bước sơ cứu khi gãy xương

Bạn có biết rằng khi bạn là một đứa trẻ, bạn sẽ có khoảng 10% nguy cơ gãy xương. Khi bạn trên 50 tuổi, nguy cơ của bạn tăng lên 25% đến 50%. Gãy xương có thể gặp ở mọi đối tượng với nguy cơ khá cao vì thế bạn cần chuẩn bị cho mình kiến thức nhất định. Dưới đây là các bước sơ cứu khi gãy xương vô cùng cần thiết mà nếu không may gặp phải trường hợp này bạn không thể không áp dụng.
**Nguyên nhân chủ yếu gây gãy xương thường là chấn thương trong khi chơi thể thao, té ngã, tai nạn xe hơi**
**Nguyên nhân và triệu chứng gãy xương**
Có nhiều nguyên nhân dẫn đến gãy xương, nguyên nhân chủ yếu thường là chấn thương trong khi chơi thể thao, té ngã, tai nạn xe hơi hoặc bất kỳ hoạt động vận động nào khác. Có một số loại bệnh có thể làm cho xương dễ gãy hơn bình thường như bệnh loãng xương, bệnh xương thủy tinh, tuyến cận giáp hoạt động quá mức và một số loại ung thư.
Triệu chứng của gãy xương thường cảm thấy đau dữ dội, tê hoặc sưng tại khu vực bị thương. Thông thường, các cơn đau sẽ tăng hơn khi bạn di chuyển vùng bị thương và sẽ xuất hiện các vết bầm máu tại vùng bị thương. Nghiêm trọng hơn, xương có thể nhô ra qua da và gây chảy máu nặng.
**Các bước sơ cứu gãy xương**
Khi phát hiện những người xung quanh bạn bị tai nạn bạn cần phải gọi cấp cứu ngay. Trong khi bạn chờ đợi xe cấp cứu đến, bạn có thể làm một số bước sơ cứu sau:
**Bạn nên sơ cứu bệnh nhân trước khi xe cấp cứu đến**
**Bước 1:**
Không di chuyển nạn nhân trừ khi cần thiết nhằm ngăn chặn những chấn thương khác có thể xảy ra đồng thời bất động vùng xương bị gãy. Đừng di chuyển nạn nhân bị thương nếu họ bị thương ở lưng hoặc cổ. Để cố định vùng bị thương, bạn có thể tự làm một thanh nẹp bằng cách gấp một mảnh bìa cứng hoặc tạp chí và nhẹ nhàng đặt dưới chân tay. Sau đó dùng vải quấn cẩn thận.
**Bước 2:**
Nếu chảy máu, bạn có thể cầm máu bằng cách quấn chặt vùng bị thương bằng băng vô trùng hoặc vải. Đè chặt lên vết thương.
**Bước 3:**
Nếu người bị thương có dấu hiệu của tình trạng sốc, bạn cần quấn họ trong một tấm chăn và nâng chân cao hơn đầu khoảng 30cm. Dấu hiệu của tình trạng này là chóng mặt, yếu ớt, da nhợt nhạt, lạnh ẩm, khó thở và nhịp tim tăng lên.
**Gãy xương cần được các bác sĩ chuyên khoa khám và điều trị càng sớm càng tốt**
**Bước 4:**
Để giúp làm giảm sưng, bạn có thể chườm một túi nước đá hay gạc lạnh trên vùng bị sưng. Tuy nhiên, bạn không nên đặt đá trực tiếp lên da, hay gói chúng trong một miếng vải.
**Bước 5:**
Bình tĩnh chờ xe cấp cứu đến.
**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/) **- Đa khoa Hạng I Thành phố Hồ Chí Minh

## ️ Tiếp cận triệu chứng đau ngực - cấp cứu ban đầu

**1. Các nguyên nhân đau ngực cấp tính**
**1.1. Thiếu máu cục bộ cơ tim hoặc nhồi máu cơ tim**
Nguyên nhân nghiêm trọng và phổ biến nhất của đau ngực cấp là thiếu máu cục bộ hoặc nhồi máu cơ tim, xảy ra khi cung cấp oxy cho cơ tim không đủ so với nhu cầu. Thiếu máu cục bộ cơ tim thường diễn ra trong bối cảnh xơ vữa động mạch, nhưng nó cũng có thể phản ánh do thay đổi trở kháng mạch vành. Co thắt mạch vành có thể xảy ra ở các động mạch vành bình thường hoặc ở những bệnh nhân bị bệnh lý mạch vành, các mạch vành nhỏ hơn.
Các nguyên nhân ít gặp khác gây giảm lưu lượng máu động mạch vành do tổn thương lỗ vào các động mạch vành như: viêm động mạch vành, viêm động mạch chủ đoạn gần, bóc tách động mạch vành tự phát, bóc tách động mạch chủ đoạn gần Tắc động mạch vành do viêm nội tâm mạch nhiễm khuẩn hoặc không nhiễm khuẩn, huyết khối từ buồng tim trái, cầu cơ hoặc các bất thường bẩm sinh động mạch vành.
Biểu hiện cổ điển của thiếu máu cục bộ là đau thắt ngực, thường được mô tả là cảm giác ngực bị đè nặng hoặc bị ép chặt, cảm giác nóng rát hoặc khó thở. Cảm giác khó chịu thường lan ra vai trái, cổ hoặc cánh tay. Nó thường tăng cường độ trong khoảng thời gian vài phút. Cơn đau có thể bắt đầu khi tập thể dục hoặc căng thẳng về tâm lý, nhưng hội chứng vành cấp thường xảy ra mà không có yếu tố khởi phát rõ ràng.
Các hướng dẫn của Đại học Tim mạch Hoa Kỳ (ACC) và Hiệp hội Tim mạch Hoa Kỳ (AHA) liệt kê những mô tả cơn đau **không phải** là đặc điểm của thiếu máu cục bộ cơ tim:
  * Đau màng phổi (tức là đau buốt hoặc như dao cắt do cử động hô hấp hoặc ho)
  * Vị trí khó chịu chính hoặc duy nhất ở vùng bụng giữa hoặc bụng dưới
  * Đau có thể khu trú ở đầu ngón tay, đặc biệt là trên mỏm thất trái
  * Đau tái phát khi cử động hoặc sờ nắn thành ngực hoặc cánh tay
  * Đau liên tục kéo dài nhiều giờ
  * Cơn đau rất ngắn kéo dài vài giây hoặc ít hơn
  * Đau lan xuống hai chi dưới


Tuy nhiên, một số trường hợp có thể xảy ra nhồi máu cơ tim với triệu chứng không điển hình, đặc biệt ở người lớn tuổi, phụ nữ, và bệnh nhân đái tháo đường.
**1.2.****Bệnh màng ngoài tim**
Bề mặt lá tạng cũng như lá thành màng ngoài tim ít nhạy cảm với cảm giác đau. Do đó các viêm màng ngoài tim không do nhiễm trùng thường ít gây đau hoặc không đau. Ngược lại, viêm màng ngoài tim do nhiễm khuẩn thường liên quan tới màng phổi bao quanh, do đó bệnh nhân thường đau kiểu màng phổi khi hít thở, ho hoặc thay đổi tư thế. Nuốt có thể gây ra cơn đau do đoạn gần thực quản là nằm phía sau tim.
Vị trí trung tâm cơ hoành được nhận cảm bởi dây thần kinh hoành, dây này xuất phát tầng cổ c3-5 của tuỷ cổ, vì vậy viêm màng ngoài tim hay có cảm giác đau ở vai và cổ. Liên quan tới vùng bên cơ hoành có thể gây ra các triệu chứng ở bụng và lưng dễ nhầm lẫn với viêm tuỵ hoặc viêm túi mật.
Viêm màng ngoài tim đôi khi còn gây ra cơn đau dữ dội, liên tục, giống như nhồi máu cơ tim cấp.
**1.3.****Bệnh lý mạch máu**
**–****Bóc tách động mạch chủ cấp tính:**
Thường gây ra cơn đau xé đột ngột, vị trí của cơn đau phản ánh vị trí và sự tiến triển của quá trình bóc tách. Bóc tách động mạch chủ lên có xu hướng biểu hiện bằng cơn đau ở đường giữa của ngực trước, và bóc tách động mạch chủ xuống có xu hướng biểu hiện với đau ở phía sau ngực. Bóc tách động mạch chủ hiếm gặp, với tỷ lệ hàng năm ước tính là 3/100.000, và thường xảy ra khi có các yếu tố nguy cơ bao gồm hội chứng Marfan và Ehlers-Danlos, van động mạch chủ hai mảnh tăng huyết áp,…
**–****Thuyên tắc phổi:**
Thường gây ra tình trạng đột ngột khó thở và đau ngực kiểu màng phổi, mặc dù chúng có thể không có triệu chứng. Tỷ lệ mắc hàng năm là khoảng 1/1000, con số này có thể là thấp hơn. Thuyên tắc phổi lớn xu hướng gây ra cơn đau nặng và dai dẳng vùng dưới sườn. Các thuyên tắc nhỏ hơn dẫn đến nhiễm trùng phổi có thể gây ra đau ngực do màng phổi bên. Thuyên tắc phổi đáng kể về mặt huyết động có thể gây hạ huyết áp, ngất và các dấu hiệu của suy tim phải. Tăng áp động mạch phổi có thể gây đau ngực tương tự như cơn đau thắt ngực, có thể là do thiếu máu cục bộ và phì đại thất phải.
**1.4. Các bệnh lý tại phổi**
Các tình trạng phổi gây ra đau ngực thường biểu hiện khó thở và các triệu chứng màng phổi, vị trí đau phản ánh nơi tổn thương. Viêm khí quản có xu hướng kết hợp với đau rát vùng giữa, trong khi viêm phổi có thể gây đau trên trường phổi. Cơn đau do tràn khí màng phổi khởi phát đột ngột và thường kèm theo khó thở. Tràn khí màng phổi nguyên phát thường xảy ra ở nam thanh niên cao, gầy; tràn khí màng phổi thứ phát xảy ra ở bệnh phổi như bệnh phổi tắc nghẽn mãn tính, hen. Các đợt cấp của bệnh hen phế quản có thể biểu hiện với cảm giác khó chịu ở ngực, đặc trưng là đau thắt.
**1.5. Các bệnh lý tiêu hoá**
  * Sự kích thích thực quản do trào ngược axit có thể tạo ra cảm giác nóng rát khó chịu và nặng lên bởi rượu, aspirin và một số loại thực phẩm. Các triệu chứng thường trở nên tồi tệ hơn khi nằm nghiêng và thuyên giảm khi ngồi thẳng hoặc khi bệnh nhân sử dụng các liệu pháp giảm axit. Co thắt thực quản có thể gây ra cảm giác tức ngực do bóp nghẹt, tương tự như đau thắt ngực.
  * Rách xước thực quản Mallory-Weiss có thể xảy ra ở những bệnh nhân bị nôn kéo dài.
  * Nôn nhiều cũng có thể gây vỡ thực quản (hội chứng Boerhaave) kèm theo viêm trung thất.
  * Đau ngực do bệnh loét dạ dày tá tràng thường xảy ra từ 60 đến 90 phút sau bữa ăn và thường thuyên giảm nhanh chóng bằng các liệu pháp giảm axit. Vị trí cơn đau thường ở thượng vị nhưng có thể lan vào ngực và vai.
  * Viêm túi mật tạo ra một loạt các hội chứng đau và thường gây ra đau bụng trên bên phải, nhưng đau ngực và lưng do rối loạn này không phải là bất thường. Cơn đau thường được mô tả là đau nhức hoặc đau quặn.
  * Viêm tụy thường gây ra cơn đau vùng thượng vị dữ dội, đau nhức có thể lan ra sau lưng.


**1.6.****Bệnh lý****c****ơ xương và các nguyên nhân khác**
  * Đau ngực có thể do rối loạn cơ xương liên quan đến thành ngực, chẳng hạn như viêm cơ ức đòn chũm. Do các tình trạng ảnh hưởng đến các dây thần kinh của thành ngực, chẳng hạn như bệnh đĩa đệm cổ, do herpes zoster hoặc sau khi tập thể dục nặng. Hội chứng cơ xương khớp gây đau ngực thường do áp lực trực tiếp lên vùng bị ảnh hưởng hoặc do cử động cổ của bệnh nhân. Bản thân cơn đau có thể thoáng qua hoặc có thể là một cơn đau âm ỉ kéo dài hàng giờ.
  * Rối loạn cảm giác hoảng sợ cũng là một nguyên nhân chính gây khó chịu ở ngực. Các triệu chứng thường bao gồm: tức ngực, thường kèm theo khó thở và cảm giác lo lắng kéo dài 30 phút hoặc lâu hơn.


**2.****Đánh giá ban đầu**
Trước khi đi tìm nguyên nhân bác sỹ cần giải đáp các vấn đề sau:
**–****Ổn định lâm sàng** : Bệnh nhân có cần được điều trị ngay lập tức cho tình trạng suy tuần hoàn hoặc suy hô hấp không?
**–****Tiên lượng:** Nếu bệnh nhân hiện đã ổn định về mặt lâm sàng, thì nguy cơ họ có tình trạng đe dọa tính mạng như hội chứng vành cấp, thuyên tắc phổi, hoặc bóc tách động mạch chủ là bao nhiêu?
**–****Phân loại** **mức độ an toàn** : Nếu nguy cơ đe dọa tính mạng thấp, liệu có an toàn để đưa bệnh nhân ra viện để quản lý ngoại trú không, hay họ nên làm thêm xét nghiệm hoặc quan sát để hướng dẫn xử trí?
**3.****Khai thác tiền sử, bệnh sử**
Trong trường hợp bệnh nhân không cần cấp cứu ngay vì suy tuần hoàn hay hô hấp, thì bác sỹ nên bắt đầu đánh giá từ khai thác tiền sử để :
  * Nắm bắt đặc điểm cơn đau: về đặc điểm tính chất và cường độ, yếu tố khởi phát, thời gian xuất hiện, yếu tố làm nặng hoặc giảm nhẹ cơn đau,… giúp góp phần gợi ý nguyên nhân.
  * Nắm các bệnh lý đã phát hiện: đái tháo đường, rối loạn lipid máu, xơ vữa động mạch, COPD, hen, Marfan, …
  * Tiền sử sử dụng chất kích thích: cocaine,…


**4.****Khám lâm sàng**
  * **Khám hệ tim mạch** : chú ý tiếng tim, các tiếng thổi bất thường ở tim, tiếng thổi tâm thu do hẹp van động mạch chủ hoặc hẹp dưới van động mạch chủ có thể là nguyên nhân của đau thắt ngực, tiếng cọ màng tim giúp chẩn đoán viêm màng ngoài tim, tiếng tim nhanh, ngựa phi, trong suy tim đặc biệt là hậu quả của nhồi máu cơ tim cấp.
  * **Khám phổi:** tiếng ran trong viêm phổi hoặc phù phổi, tiếng cọ màng phổi trong viêm màng phổi, hội chứng ba giảm trong tràn dịch màng phổi, gõ trong và mất rung thanh trong tràn khí màng phổi.
  * **Khám thành ngực****:** có thể thấy các dấu hiệu của viêm khớp ức xườn (hội chứng Tietze), các nốt nổi theo đường đi của thần kinh liên sườn trong bệnh zona thần kinh liên sườn.
  * **Khám bụng:** tìm và phân biệt các nguyên nhân từ ổ bụng, dạ dày gây cơn đau dễ nhầm lẫn với đau ngực.
  * **Khám mạch:** đặc biệt thấy các dấu hiệu mất mạch đột ngột, các chi trong tách thành động mạch chủ…
  * Khám thần kinh và các thăm khám khác toàn diện giúp cung cấp thêm thông tin cho chẩn đoán.


**5.****Các cận lâm sàng thăm dò**
  * Điện tâm đồ 12 chuyển đạo
  * Xét nghiệm máu
  * Marker sinh học cơ tim (TnT; CK-MB,…)
  * D-Dimer
  * BNP, NT Pro- BNP
  * X-quang tim phổi
  * Siêu âm tim, siêu âm đánh dấu mô
  * Chụp CT scan động mạch phổi, CT động mạch vành, động mạch chủ,…
  * Chụp động mạch vành


**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh

## ️【HƯỚNG DẪN】Cách sơ cứu người bị hạ canxi máu

  * [Nguyên nhân gây hạ canxi máu](https://bvnguyentriphuong.com.vn/cap-cuu/huong-dancach-so-cuu-nguoi-bi-ha-canxi-mau#nguyn-nhn-gy-h-canxi-mu)
  * [Nhận biết hạ canxi máu như thế nào?](https://bvnguyentriphuong.com.vn/cap-cuu/huong-dancach-so-cuu-nguoi-bi-ha-canxi-mau#nhn-bit-h-canxi-mu-nh-th-no)
  * [Khi bị hạ canxi cần làm gì?](https://bvnguyentriphuong.com.vn/cap-cuu/huong-dancach-so-cuu-nguoi-bi-ha-canxi-mau#khi-b-h-canxi-cn-lm-g)


## **Nguyên nhân gây hạ canxi máu**
  * Những người có chế độ ăn uống thiếu canxi hoặc thiếu vitamin D làm giảm khả năng hấp thu canxi, gặp phải các vấn đề ở đường tiêu hóa như bị cắt đoạn ruột, hội chứng giảm hấp thu… là một trong những nguyên nhân thường gặp ở người bị thiếu canxi.
  * Dùng nhiều thuốc lợi tiểu furosemid, thuốc kháng sinh nhóm aminosid
  * Bệnh lý rối loạn nội tiết, bệnh tuyến giáp


## **Nhận biết hạ canxi máu như thế nào?**
Khi bị hạ canxi máu, người bệnh gặp phải các triệu chứng như tê môi, lưỡi, tê các đầu ngón tay, ngón chân. Tiếp đó sẽ có sự co cơ, ngón tay không xòe ra được, bàn chân duỗi ra như đang đạp xe. Cơ mặt và cơ toàn thân cũng bị ảnh hưởng gây đau đớn, thậm chí các cơ hô hấp bị co thắt có thể làm suy hô hấp, khó thở. Nếu nặng, người bệnh có thể bị co giật toàn thân.
Đa số các cơn hạ canxi xảy ra khi có các kích thích như tức giận giữ, buồn bã, căng thẳng quá mức hay cảm sốt.
Cho người bệnh uống canxi sủi nếu có
## **Khi bị hạ canxi cần làm gì?**
Khi phát hiện người bệnh bị hạ canxi máu, những người xung quanh cần:
  * Vỗ nhẹ má để người bệnh tỉnh táo, có thể ấn huyệt nhân trung giữa mũi và miệng nếu chưa tỉnh.
  * Nếu người bệnh mang theo canxi sủi thì pha vào nước giúp người bệnh uống
  * Nếu không có thuốc, cần đưa ngay đến các cơ sở y tế gần nhất để được xử trí kịp thời.


Để phòng tránh hạ canxi máu, cần có chế độ dinh dưỡng đủ chất, bổ sung các thực phẩm như tôm, cua, ốc, sữa, bắp cải… trong bữa ăn hàng ngày. Nên tắm nắng để tổng hợp vitamin D cho cơ thể hấp thu canxi tốt hơn. Người bệnh cũng không nên quá xúc động, hạn chế các kích thíc bên ngoài vì có thể khiến cơn hạ canxi xảy ra nhanh và thường xuyên hơn.
**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/) **- Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [Nguyên nhân gây hạ canxi máu](https://bvnguyentriphuong.com.vn/cap-cuu/huong-dancach-so-cuu-nguoi-bi-ha-canxi-mau#nguyn-nhn-gy-h-canxi-mu)
  * [Nhận biết hạ canxi máu như thế nào?](https://bvnguyentriphuong.com.vn/cap-cuu/huong-dancach-so-cuu-nguoi-bi-ha-canxi-mau#nhn-bit-h-canxi-mu-nh-th-no)
  * [Khi bị hạ canxi cần làm gì?](https://bvnguyentriphuong.com.vn/cap-cuu/huong-dancach-so-cuu-nguoi-bi-ha-canxi-mau#khi-b-h-canxi-cn-lm-g)



## ️ Đường dùng tốt nhất cho adrenaline là gì? Histamin đóng vai trò gì trong sốc phản vệ?

Epinephrine là thuốc chính được sử dụng trong cấp cứu ngừng tim do tác dụng co mạch mạnh cũng như làm tăng cung lượng tim. Epinephrine được coi là thuốc vận mạch.
**- Tiêm dưới da và tiêm bắp**
Đường dùng chính xác và liều của adrenaline vẫn còn đang tranh luận. Một nghiên cứu cho thấy tiêm dưới da adrenalin có tác dụng chậm hơn so với tiêm bắp (thời gian trung bình: nhóm tiêm bắp, 8 phút, nhóm dưới da, phút 34).
**- Adrenaline hít**
Nghiên cứu sử dụng adrenaline hít bằng bình phun áp lực. Một báo cáo cho thấy adrenaline liều hít 3 mg hiệu quả lâm sàng ít rõ ràng hơn và ngắn hơn tiêm dưới da.
**- Đường tĩnh mạch**
Adrenalin tĩnh mạch có thể gây loạn nhịp và nhồi máu cơ tim. thường xảy ra khi adrenaline đưa vào quá nhanh, không pha loãng hoặc lượng thuốc quá liều. chỉ dùng đường tĩnh mạch khí sốc phản vệ không đáp ứng với adrenaline tiêm bắp hoặc trụy tim mạch. Chỉ dùng ở những đơn vị hồi sức
**- Liều adrenaline phù hợp?**
Một số bất đồng tồn tại về liều khuyến cáo của adrenaline. Mặc dù gần như tất cả các phác đồ đều đồng ý 0,01 mg / kg ở trẻ sơ sinh và trẻ em, hướng dẫn Bắc Mỹ liều ở người lớn 0,3-0,5 ml adrenalin pha loãng 1: 1000 (0,3-0,5 mg), trong khi châu Âu đề nghị 0,5-1,0 mg. Không có thử nghiệm so sánh tiến hành. Đối với hầu hết các bệnh nhân chỉ cần một liều, mặc dù liều lặp lại có thể dùng sau 5 phút đến khi các triệu chứng được cải thiện.
**- Adrenaline có bất kỳ tương tác thuốc nào cần chú ý?**
Sốc phản vệ có thể nặng hơn bởi thuốc chẹn β, loại thuốc này làm giảm hiệu quả của adrenaline. liều adrenaline nên giảm một nửa vì dùng beta blocker làm tăng nguy cơ liên quan kích thích adrenoceptors α và phản xạ phó giao cảm, bao gồm nhịp tim chậm , tăng huyết áp, co thắt động mạch vành và co thắt phế quản. β Blockers, bao gồm cả thuốc nhỏ mắt cần ngừng với bệnh nhân có nguy cơ phản vệ. thuốc chống trầm cảm ba vòng và thuốc ức chế monoamine oxidase khi dùng với adrenaline làm tăng nguy cơ rối loạn nhịp tim. Liều adrenaline nên giảm một nửa ở những bệnh nhân này.
**- Khi nào cần tiêm adrenaline?**
Bằng chứng trong các tài liệu cho thấy adrenaline nên dùng sớm nhất có thể. Số bệnh nhân chết khi tiêm phút thứ 30 ít hơn so với tiêm ở phút 45…
Mức độ nghiêm trọng của các phản ứng trước đó không xác định được mức độ nghiêm trọng của các phản ứng tiếp theo, các phản ứng tiếp theo có thể giống nhau, tốt hơn hoặc tệ hơn.
**- Histamin đóng vai trò gì trong sốc phản vệ?**
Men tryptic thường xuất hiện trong các mô và có vẻ như các phản ứng phản vệ hoặc dị ứng do giải phóng histamin phụ thuốc vào 1 số phản ứng enzym này. Một số quan sát sơ bộ chỉ ra rằng heparin có thể là một chất ức chế quá trình xảy ra phản ứng dị ứng và phản vệ do ngăn quá trình phản ứng của các enzym này
Nếu chúng ta không tìm thấy phương pháp phòng ngừa giải phóng histamin hoặc phương pháp này là không khả thi trong thực hành lâm sàng thì có ít nhất 3 phương án ngăn giải phóng histamin: 
  * Formaldehyde có thể bất hoạt histamine, có thể là do sự hình thành của một sản phẩm ngưng tụ không hoạt động.
  * GebauerFuelnegg nghiên cứu thấy sulfanilic diazotized axit có thể làm bất hoạt histamine. Nhưng nghiên cứu sâu hơn thấy không có tác dụng trên động vật sống
  * Histaminase hoặc diamine oxidase, là một enzym có thể bất hoạt histamin trong điều kiện thích hợp và trong điều kiệ n sinh lý bình thường


Hiện đã có nhiều nghiên cứu cho ra đời enzyme nầy để làm thuốc giải độc histamine trong trường hợp dị ứng. Nó bị phá hủy bởi dich tiêu hóa và dịch dạ dày
Nhưng nghiên cứu trên thành phầm tiêm thấy không đủ nhanh để bất hoạt quá trình dị ứng. Nghiên cứu ra enzyme tinh khiết vẫn đang có hi vọng
Nếu chúng ta không thể ngăn chặn sự giải phóng histamine, cũng không tiêu diệt nó kịp thời trước khi được giải phóng, liệu chúng ta có thể giảm thiểu hoặc chống lại ảnh hưởng của nó lên các mô?
Quá trình dị ứng do giải phóng histamin tác động lên hệ thống cơ quan của cơ thể, không có 1 thuốc nào 1 mình nó có thể chống lại được. Ví dụ, epinephrine không giải quyết khâu giãn mạch và tăng tính thấm của histamine mà nó chống co thắt cơ trơn. Hormon thùy sau tuyến yên, tuyến thượng thận và acid ascorbic có thể
Chống tác động của histamine trên mao mạch nhưng không giải quyết được các tính chất khác của histamine. Thymoxyethyldiethylamine xuất hiện để chống lại sự kích thích cơ trơn của histamin…Vì vậy trong cấp cứu sốc phản vệ cần phối hợp nhiều loại thuốc để ức chế và loại bỏ histamin
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh

## ️ Những thứ cần phải có trong bộ dụng cụ sơ cứu

  * [Những thức cần thiết trong bộ sơ cứu](https://bvnguyentriphuong.com.vn/cap-cuu/nhung-thu-can-phai-co-trong-bo-dung-cu-so-cuu#nhng-thc-cn-thit-trong-b-s-cu)
  * [Tùy chỉnh bộ dụng cụ sơ cứu](https://bvnguyentriphuong.com.vn/cap-cuu/nhung-thu-can-phai-co-trong-bo-dung-cu-so-cuu#ty-chnh-b-dng-c-s-cu)


## **Những thức cần thiết trong bộ sơ cứu**
Hội Chữ thập đỏ Hoa Kỳ gợi ý rằng một bộ sơ cứu cho một gia đình bốn người bao gồm những vật dụng sau:
  * Hướng dẫn sơ cứu.
  * 2 băng ép thấm hút (5 x 9 inch).
  * 25 băng dính (các loại kích cỡ).
  * 1 băng dính vải (10 thước x 1 inch).
  * 5 gói thuốc mỡ kháng sinh.
  * 5 gói lau sát trùng.
  * 2 gói aspirin (mỗi gói 81 mg).
  * 1 chăn khẩn cấp.
  * 1 cuộn gạc vải.
  * 1 miếng gạc lạnh tức thì.
  * 2 đôi găng y tế.
  * 2 gói thuốc mỡ hydrocortisone.
  * 1 băng gạc 3 inch.
  * 1 băng lăn.
  * 5 miếng gạc vô trùng 3 x 3 inch.
  * 5 miếng gạc vô trùng (4 x 4 inch).
  * Nhiệt kế bằng pin.
  * 2 băng tam giác.
  * Nhíp.


Loại bỏ, vứt bỏ hoặc sử dụng và thay thế bất kỳ vật dụng nào trước khi chúng hết hạn. Đặt lịch nhắc trên điện thoại thông minh của bạn để cập nhật vật phẩm trong bộ dụng cụ của bạn sáu tháng một lần hoặc khi nhu cầu chăm sóc sức khỏe của gia đình bạn thay đổi.
## **Tùy chỉnh bộ dụng cụ sơ cứu**
Hãy nghĩ đến nhu cầu chăm sóc sức khỏe của gia đình bạn khi lắp cùng một bộ sơ cứu. Ví dụ:
  * Nếu bạn có một thành viên trong gia đình bị dị ứng nghiêm trọng, hãy bao gồm thuốc kháng histamine và thuốc tiêm epinephrine.
  * Nếu bạn có các thành viên lớn tuổi trong gia đình có làn da mỏng manh, bao gồm một cuộn băng dính giấy có thể hữu ích để bảo vệ làn da.
  * Nếu bạn hoặc một thành viên trong gia đình sống chung với bệnh tiểu đường, hãy bao gồm một hộp nước trái cây, viên nén và gel glucose, và một bộ dụng cụ tiêm glucagon khẩn cấp.
  * Aspirin dạng nhai, dạng viên có thể giúp ích cho người bị bệnh mạch vành, miễn là người đó không bị dị ứng với aspirin.


Chuyên gia cũng đề xuất đính kèm một ghi chú vào bộ dụng cụ của bạn với hướng dẫn về nơi tìm các vật dụng khác xung quanh nhà và cách hành động trong những trường hợp khẩn cấp cụ thể. Ví dụ, bạn có thể sử dụng một ghi chú để nhắc bạn nơi cất giữ đồ uống và thực phẩm có đường trong trường hợp khẩn cấp về bệnh tiểu đường.
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [Những thức cần thiết trong bộ sơ cứu](https://bvnguyentriphuong.com.vn/cap-cuu/nhung-thu-can-phai-co-trong-bo-dung-cu-so-cuu#nhng-thc-cn-thit-trong-b-s-cu)
  * [Tùy chỉnh bộ dụng cụ sơ cứu](https://bvnguyentriphuong.com.vn/cap-cuu/nhung-thu-can-phai-co-trong-bo-dung-cu-so-cuu#ty-chnh-b-dng-c-s-cu)



## ️ Hướng dẫn cách sơ cứu khi bị trật khớp với 4 bước

**1. Cách sơ cứu khi bị trật khớp**
**Bước 1: Hạn chế tối đa việc di chuyển**
Khi bị trật khớp, bạn nên tránh di chuyển để giảm lực tác động vào vị trí bị tổn thương. Bên cạnh đó, không được nắn, chỉnh hoặc cố cử động khớp bị trật vì có thể làm tình trạng bệnh trầm trọng hơn.
_Trật khớp thường gặp sau chấn thương, té ngã, tai nạn…_
**Bước 2: Cố định khớp**
Cố định ở tư thế mà khớp đang ở vị trí đó. Nếu trật khớp vùng tay, khuỷu tay có thể có định bằng cách cột tay vào thân người. Nếu trật khớp ở chân thì có thể cột hai chân lại với nhau, dùng chân lành làm nẹp cố định.
**Bước 3: Chườm lạnh vùng khớp bị thương**
Việc chườm lạnh vùng khớp bị thương có thể giúp giảm sưng phù. Có thể dùng đá lạnh chườm trực tiếp lên da hoặc cho đá vào miếng vải để chườm. Lưu ý, không nên chườm nóng, đắp muối, bóp thuốc rượu vì có thể làm tình trạng xấu đi.
**Bước 4: Di chuyển người bệnh tới cơ sở y tế**
_Cần sơ cứu đúng cách để giảm đau và ngừa biến chứng_
Sau khi sơ cứu xong, người nhà cần đưa người bệnh tới ngay các cơ sở y tế, bệnh viện để các bác sĩ thăm khám, kiểm tra. Ngoài thăm khám lâm sàng, bác sĩ sẽ chỉ định làm thêm các chẩn đoán chuyên sâu như chụp X-quang để xác định mức độ tổn thương. Tùy vào từng trường hợp cụ thể, bác sĩ sẽ tư vấn phương pháp điều trị phù hợp.
**2. Cách điều trị trật khớp hiệu quả**
Chuyên gia khuyến cáo, không nên chủ quan khi bị trật khớp bởi nếu không phát hiện và chữa trị sớm có thể gây ra một vài biến chứng nguy hiểm như rách cơ, dâychằng cùng những bó gân gia cố phần khớp bị tổn thương.
Trật khớp còn có thể gây ra các tổn thương cho mạch máu cũng như thần kinh ở quanh khớp. Nếu không được điều trị dứt điểm, hiện tượng này rất dễ tái phát. Nếu trật khớp nặng có thể tái phát đi tái phát lại nhiều lần. Điều trị trật khớp tùy thuộc vào vị trí và mức độ nặng của tổn thương. Bác sĩ có thể chỉ định một số biện pháp nắn chỉnh để đưa xương trở lại đúng vị trí. Sau đó người bệnh có thể cần phải nẹp hoặc băng cố định vài tuần và dùng thuốc giảm đau hoặc thuốc giãn cơ.
_Cần tới bệnh viện để bác sĩ đưa ra phương pháp điều trị phù hợp_
Sau khi tháo bỏ băng hoặc nẹp, bệnh nhân sẽ được phục hồi chức năng để khôi phục vận động và sức mạnh của khớp. Cần tránh hoạt động mạnh ở bên khớp tổn thương cho đến khi khớp hồi phục hoàn toàn.
Tuy nhiên, phương pháp phẫu thuật ít được sử dụng bởi trật khớp thường gặp ở mức độ nhẹ và hồi phục trong thời gian ngắn.
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh

## ️ Cấp cứu ngừng hô hấp và tuần hoàn: khi nào ngưng cấp cứu?

**1. Khái niệm ngừng tuần hoàn**
Ngừng tuần hoàn là trạng thái ngừng tim đột ngột, ngừng cung cấp máu cho cơ thể, đặc biệt là các cơ quan quan trọng như não, phổi,... Có 3 trạng thái ngừng tuần hoàn là vô tâm thu, rung thất và phân ly điện cơ. Ngừng tuần hoàn có thể xảy ra khi nạn nhân bị điện giật, đuối nước, đa chấn thương, sốc phản vệ,... hoặc là hậu quả cuối cùng của một bệnh lý mạn tính giai đoạn cuối như xơ gan, suy tim, suy thận, ung thư,...
Trong điều kiện nhanh nhất có thể, cần cấp cứu ngừng hô hấp và tuần hoàn để cung cấp máu mang oxy đến cho tế bào não, đặc biệt là trong vòng 5 phút đầu kể từ thời điểm ngừng tim. Việc cấp cứu ngừng tuần hoàn cần tiến hành tại chỗ, thực hiện ngay và đúng kỹ thuật.
**2. Nguyên nhân ngừng tuần hoàn**
Nguyên nhân do tim: Mắc bệnh thiếu máu cơ tim, tắc mạch vành cấp, các bệnh cơ tim, viêm cơ tim, chấn thương tim chèn ép tim cấp hoặc kích thích trực tiếp vào tim;
Nguyên nhân tuần hoàn: Tắc mạch phổi, thiếu khối lượng tuần hoàn cấp và cơ chế phản xạ dây phế vị;
Nguyên nhân hô hấp: Do tràn khí màng phổi nặng, thiếu oxy cấp gây vô tâm thu (do dị vật, tắc đường thở), ưu thán (thừa CO2);
Nguyên nhân rối loạn chuyển hóa: Rối loạn chuyển hóa kali, tăng catecholamin cấp, tăng canxi máu cấp, hạ thân nhiệt;
Nguyên nhân do thuốc, nhiễm độc: Tác động trực tiếp của thuốc gây ngừng tim, tác dụng phụ của thuốc;
Nguyên nhân khác: Điện giật, đuối nước,...
**3. Chẩn đoán ngừng hô hấp và tuần hoàn**
Dựa trên các triệu chứng cơ bản:
-Mất ý thức: Bệnh nhân khi được hỏi không có đáp ứng trả lời, không có phản xạ thức tỉnh;
-Ngừng thở hoặc thở ngáp: Xác định khi lồng ngực và bụng bệnh nhân không có cử động thở;
-Ngừng tim: Mất mạch cảnh hoặc mất mạch bẹn;
-Triệu chứng khác: Da nhợt nhạt hoặc tím tái, giãn đồng tử hoặc mất phản xạ đồng tử với ánh sáng. Nếu bệnh nhân đang được phẫu thuật sẽ thấy máu ở vết mổ tím đen và ngừng chảy. Nếu bệnh nhân đang thở máy, hôn mê thì monitor tim sẽ báo động và SpO2 giảm đột ngột.
Ngừng tim là dấu hiệu người bệnh đang ngừng hô hấp và tuần hoàn
**4. Cấp cứu ngừng hô hấp và tuần hoàn**
Phác đồ cấp cứu ngừng hô hấp và tuần hoàn dựa trên 3 bước cơ bản (A-B-C) như sau:
A: Airway: làm thông đường thở;
B: Breathing: thông khí nhân tạo;
C: Circulation: ép tim ngoài (hoặc trong) lồng ngực.
Nếu có điều kiện, có thể cho bệnh nhân dùng thuốc (D: Drugs) và sốc điện ngay.
**4.1 A - Airway: Kiểm soát đường thở**
Đặt bệnh nhân nằm ngửa trên nền cứng, đầu và cổ ở tư thế ưỡn tối đa, mặt quay về một bên;
Người cấp cứu dùng tay mở miệng bệnh nhân ra, dùng các ngón tay móc sạch đờm dãi và dị vật trong miệng nếu có thể. Với dị vật nằm sâu và khó lấy, không nên cố lấy ra vì sẽ làm mất thời gian, có thể đẩy dị vật vào sâu thêm hoặc gây tắc đường thở hoàn toàn;
Có thể áp dụng nghiệm pháp Heimlich để làm văng dị vật đường thở ra ngoài. Cách thực hiện là: Người cấp cứu ôm xốc nạn nhân từ phía sau, một bàn tay thu lại thành nắm, đặt dưới mũi ức của nạn nhân, bàn tay còn lại đặt chồng lên bàn tay kia, ôm xốc nạn nhân lên sao cho nắm tay thúc mạnh vào thượng vị hướng về phía lồng ngực bệnh nhân. Nếu không thể sốc nạn nhân lên vì thể trạng quá nặng, có thể đặt nạn nhân nằm ngửa trên nền cứng, người cấp cứu ngồi trên người nạn nhân, 2 bàn tay đặt chồng lên nhau trên vùng thượng vị của nạn nhân và thúc mạnh về phía ngực. Với trẻ em, có thể cầm 2 chân dốc ngược rồi dùng tay vỗ mạnh vào vùng giữa 2 xương bả vai để làm bật dị vật ra ngoài.
**4.2 B - Breathing: Thông khí cơ học - nhân tạo (hô hấp nhân tạo)**
Có thể chọn kỹ thuật thổi miệng - miệng hoặc miệng - mũi.
Áp dụng thổi miệng - miệng: Người cấp cứu dùng 1 bàn tay đặt lên trán bệnh nhân, ấn ngửa đầu bệnh nhân ra sau, đồng thời dùng ngón trỏ và ngón cái kẹp mũi bệnh nhân lại. Bàn tay thứ 2 nâng hàm dưới của bệnh nhân lên trên, ra trước, đồng thời mở miệng bệnh nhân ra. Người cấp cứu sau khi hít sâu thực hiện áp chặt miệng vào miệng nạn nhân, đồng thời thổi hết không khí dự trữ qua miệng;
Áp dụng thổi miệng – mũi: Người cấp cứu dùng tay nâng xương hàm dưới của bệnh nhân lên trên, ra trước, khép miệng bệnh nhân lại; tay còn lại đặt lên trán nạn nhân, ấn ngửa đầu nạn nhân ra sau. Sau khi đã hít sâu, người cấp cứu áp chặt miệng vào mũi nạn nhân rồi thổi hết không khí dự trữ qua mũi;
Tần số thổi đảm bảo 10 – 12 lần/phút.
Trong điều kiện có trang bị dụng cụ, bệnh nhân có thể được đặt ống nội khí quản hoặc úp masque bóp bóng. Người cấp cứu dùng masque úp khít lên mũi và miệng nạn nhân. Masque được nối với bóng bóp. Nên bóp bóng cho bệnh nhân khoảng 20 nhịp/phút. Tốt nhất là bóp bóng nối với nguồn oxy với lưu lượng là 6 – 8 lít/phút.
**4.3 C - Circulation: Ép tim ngoài lồng ngực**
Đặt người bệnh nằm ngửa trên nền cứng;
Người sơ cứu nên đứng dạng 2 chân 2 bên người bệnh, mặt hướng về phía người bệnh;
Đặt cùi lòng bàn tay trên điểm 1/3 xương ức, cách mũi ức khoảng 2 ngón tay, tay nọ đặt trên tay kia, các ngón tay đan nhau;
Động tác ép tim tiến hành theo chiều thẳng đứng, 2 tay chống ép thăng bằng trọng lượng cơ thể, biên độ ép xuống mỗi lần khoảng 4 – 5cm. Sau khi ép xuống cần thả ra để thời gian để tim giãn nở sao cho tần số ép tim lý tưởng là 80 – 100 lần/phút;
Hai động tác ép tim và thổi ngạt phải thực hiện xen kẽ theo các chu kỳ hồi sức tim phổi. Một chu kỳ hồi sức tim phổi gồm 30 lần ép tim, sau đó là 2 lần thổi ngạt.
**4.4 D - Drugs: Điều trị bằng thuốc**
Adrenalin: Là thuốc hồi sức cơ bản. Nên dùng ngay liều cao 1 – 3mg tiêm tĩnh mạch, cách nhau 3 – 5 phút/lần, kết hợp với ép tim. Khi không thể tiêm tĩnh mạch, có thể dùng liều gấp đôi là 3 – 6mg, pha trong 10ml huyết thanh mặn 0,9% và bơm vào khí quản (tiêm qua màng giáp nhẫn hoặc ống nội khí quản) rồi bóp bóng thông khí mạnh 2 – 3 lần. Tuyệt đối không được tiêm adrenalin trực tiếp vào tim;
Hạn chế truyền natri cacbonat, chi truyền khi ngừng tim trên 15 phút hoặc biết trước bệnh nhân có toan chuyển hóa hoặc tăng kali máu. Nên dùng liều đầu 1mmol/kg và cứ 10 phút sau lại cho 0,5mmol/kg;
Chỉ dùng lidocain 1 – 2mg/kg sau khi đã dùng adrenalin và chống rung thất bại;
Bù dịch tĩnh mạch chỉ bắt buộc khi bệnh nhân mất máu hoặc thiếu khối lượng tuần hoàn. Nên dùng huyết thanh mặn 0,9%, không dùng dung dịch đường;
Dùng Atropin khi có ngộ độc phospho hữu cơ hoặc có nhịp chậm;
Dùng canxi cho bệnh nhân ngừng tuần hoàn khi có hạ canxi máu từ trước, ngộ độc bởi các chất ức chế canxi hoặc bị tăng canxi máu;
Kích thích tim bằng máy chỉ thực hiện khi nhịp chậm, không đáp ứng với thuốc;
Bảo vệ não để tránh tụt huyết áp quá lâu, tránh sốt cao và co giật, tránh tăng đường máu và độ thẩm thấu máu.
**4.5 Phá rung bằng sốc điện**
Rung thất là tình trạng các thớ cơ tim rung lên hỗn loạn, không còn khả năng tống máu đi nuôi cơ thể và được coi là ngừng tuần hoàn. Phá rung bằng sốc điện là sử dụng dòng điện có cường độ lớn nhưng có hiệu điện thế thấp phóng qua trục của tim nhằm xóa sạch các ổ phát xung hỗn loạn, khôi phục lại tính tự động bình thường của hệ thống thần kinh tim.
Liều sốc điện thông thường là: Lần 1: 120j; lần 2: 150j; lần 3: 200j; lần 4: 200j nếu chưa phá được rung thất.
**5. Đánh giá hiệu quả cấp cứu ngừng hô hấp và tuần hoàn**
Cấp cứu có hiệu khi đạt mục đích cung cấp máu và oxy cho tuần hoàn não, tuần hoàn vành và các tổ chức tế bào. Biểu hiện lâm sàng là niêm mạc môi bệnh nhân ấm vào hồng trở lại, đồng tử co lại nếu thời gian thiếu oxy não ngắn và còn khả năng hồi phục. Hiệu quả hồi sức tốt hơn nếu có các dấu hiệu của sự sống như thở trở lại, tim đập lại, tri giác hồi phục,...
**6. Khi nào ngừng cấp cứu?**
Nếu đã áp dụng đúng và đầy đủ các biện pháp cấp cứu trên, không có điều kiện vận chuyển bệnh nhân đi xa hoặc gọi tuyến trên chi viện, cấp cứu trong vòng 60 phút mà đồng tử không co lại, tim không đập lại thì cho phép ngừng cấp cứu và bệnh nhân tử vong. Cần lưu ý, các trường hợp ngừng hô hấp và tuần hoàn trong điều kiện đặc biệt, khả năng chịu đựng thiếu oxy não có thể kéo dài hơn như ngừng tim trong điều kiện hạ thân nhiệt (do mổ với tuần hoàn ngoài cơ thể, ngừng tim ngoài trời do băng tuyết, chết đuối trong nước lạnh,...) hoặc ngừng tim mà trước đó có sử dụng các thuốc làm giảm tiêu thụ oxy não hoặc trẻ sơ sinh thì cần phải cấp cứu kiên trì hơn vì vẫn có thể cứu sống bệnh nhân.
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh

## ️ Có nên xoa dầu nóng khi bị bong gân?

Có nên xoa dầu nóng khi bị bong gân là thắc mắc được rất nhiều người đặt ra. Bài viết dưới đây chúng tôi sẽ giúp giải đáp thắc mắc này.
Bong gân là chấn thương dây chằng (mô nối hai hoặc nhiều xương tại một khớp). Chấn thương này rất hay gặp phải do té ngã, tai nạn giao thông hoặc chơi thể thao, đi bộ sai cách, chạy quá nhanh, chống đỡ khi bị ngã, vận động sai thư thế…
Bong gân được chia làm 3 cấp độ: Nhẹ – vừa và nặng. Trường hợp bong gân nhẹ: dây chằng bị giãn nhưng không rách hoặc đứt; Mức độ vừa: một phần hoặc chùm dây chằng bị rách; Mức độ nặng: Dây chằng của một khớp bị đứt.
Thông thường khi bị bong gân, người bệnh sẽ thấy xuất hiện triệu chứng sưng, tụ máu bầm tại chỗ bị chấn thương kèm theo đau khớp không thể cử động hoặc vận động, cơn đau có thể xuất hiện ngắn hoặc đau kéo dài khiến bệnh nhân không thể di chuyển được.
**Có nên xoa dầu nóng khi bị bong gân?**
Nếu biết cách xử lý kịp thời, vùng bị sưng đau sẽ nhanh hồi phục, ngược lại nếu xử lý không đúng có thể khiến tình trạng bệnh nghiêm trọng hơn.
**Có nên xoa dầu nóng khi bị bong gân?**
Nhiều người có thói quen xoa dầu nóng khi bị bong gân, trật khớp với mong muốn giảm đau và sưng. Thế nhưng đây lại là một biện pháp xử trí bong bân không đúng.
Khi bị bong gân, các dây chằng quanh khớp bị căng giãn, bầm dập dẫn đến sung huyết. Vì thế, dầu nóng sẽ làm tăng tình trạng xung huyết, xuất huyết tại chỗ, gây phù nề hơn và tổn thương nặng hơn. Do đó không nên sử dụng các loại cao, dầu nóng, rượu thuốc, mật gấu, salonpas khi bị bong gân.
**Khi bị bong gân không nên chườm nóng, thay vào đó là chườm lạnh sẽ giúp giảm sưng viêm**
**Cách xử trí đúng khi bị bong gân**
Khi bị bong gân, người bệnh có thể tự sơ cứu tại nhà bằng các bước như:
Tạm ngừng các hoạt động, không được di chuyển tránh để phần khớp bị bong gân tổn thương nặng hơn
Chườm đá vào chỗ bong gân 10-15 phút để giảm đau, tránh co mạch, xuất huyết, phù nề. Lưu ý không nên chườm trực tiếp đá lạnh vào vị trí bị tổn thương, nên sử dụng khăn vải mỏng để tránh nước đá lạnh tiếp xúc trực tiếp gây bỏng lạnh cho da.
Băng cố định phần khớp bị tổn thương. Băng vừa phải, không băng quá lỏng hoặc quá chặt.
Nếu bong gân phần chi dưới thì nằm kê cao chân. Nếu bong gân phần chi trên thì treo tay bất động, tránh gây ảnh hưởng đến phần bị tổn thương.
Đối với các trường hợp bong gân do chơi thể thao, có thể dùng ethyl clotua để xịt vào vùng bong gân có tác dụng giảm đau, làm lạnh và tê. Ngoài ra, có thể sử dụng thuốc uống alaxan để giảm đau. Chú ý không được dùng aspirin vì thuốc có thể làm ngưng kết tiểu cầu, gây chảy máu cho người bị bong gân.
Sau khi sơ cứu, nếu bong gân ở độ 1, người bệnh có thể vận động trở lại sau khi đã hết đau. Tuy nhiên, nếu là bong gân độ 2, 3 người bệnh nên tìm đến bệnh viện hoặc cơ sở y tế để có biện pháp xử trí phù hợp, tránh ảnh hưởng đến chức năng dây chằng.
**Lưu ý sau khi bị bong gân**
Để ngăn chặn tình trạng bong gân tái lại sau điều trị, người bệnh cần chú ý những điều sau:
Tránh mang giày gót cao khi đi trên mặt bằng gồ ghề, chọn giày phù hợp khi đi lại.
Thận trọng khi đi xuống dốc, cầu thang, nhất là với người già và trẻ nhỏ.
Khởi động làm nóng trước khi tập luyện thi đấu thể thao.
Thường xuyên vận động khớp để tăng sức bền bỉ và thích nghi với những động tác nhanh.
Tránh vận động hoặc chuyển tư thế đột ngột.
Bên cạnh đó, người bệnh cần kết hợp với chế độ dinh dưỡng đủ chất, hạn chế rượu bia, chất kích thích để mau chóng hồi phục.
**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/) **- Đa khoa Hạng I Thành phố Hồ Chí Minh

## ️ Cách sơ cứu khi bị đột quỵ

Đột quỵ có thể nhận biết qua những dấu hiệu cảnh báo trước. Nếu sơ cứu đúng cách, người bệnh có thể giảm biến chứng cũng như nguy cơ tử vong.Vậy cách sơ cứu khi bị đột quỵ là gì? Bạn có thể tham khảo những thông tin dưới đây.
**Người đột quỵ đột ngột đau nhức đầu dữ dội, chóng mặt, mất thăng bằng, mất khả năng phối hợp vận động**
**Những triệu chứng của đột quỵ**
Đột ngột đau nhức đầu dữ dội, chóng mặt, mất thăng bằng, mất khả năng phối hợp vận động.
Đột ngột yếu, tê, liệt mặt, tay hoặc chân (có thể là ở một bên của cơ thể)
Đột ngột mất thị lực, đặc biệt là chỉ ở một mắt. Không nói được hay khó khăn trong nói hay hiểu ngôn ngữ.
**Cách sơ cứu người bị đột quỵ**
Ngay khi thấy người bệnh có những dấu hiệu trên, bạn cần đưa đi cấp cứu kịp thời cứu sống người bị đột quỵ. Cứ mỗi phút người đột quỵ không được điều trị đặc hiệu thì có khoảng 2 triệu nơron thần kinh mất đi. Thời gian can thiệp muộn các tế bào thần kinh càng chết đi nhiều và hậu quả tàn phế cũng như tử vong sẽ cao hơn so với người được điều trị sớm.
**Ngay khi thấy người bệnh có những dấu hiệu của bệnh đột quỵ, bạn cần đưa đi cấp cứu kịp thời cứu sống người bị đột quỵ**
Khoảng 3-4 giờ đầu là “thời gian vàng” từ khi khởi phát đột quỵ để cứu sống người bệnh. Vì sau 3-4 giờ, nơi vùng não xảy ra tai biến và mô não cận kề vùng tai biến sẽ bị hư hại và khó phục hồi. Các chuyên gia khuyến cáo, khi phát hiện người bệnh đột quỵ, người nhà bệnh nhân cần đưa ngay bệnh nhân đi cấp cứu kịp thời, sẽ giúp giảm tỷ lệ tử vong; giảm số ngày điều trị và cũng giảm di chứng, tăng cơ hội sống không cần giúp đỡ.
Mức độ di chứng để lại cho bệnh nhân còn phụ thuộc rất nhiều vào thời điểm và cách thức người bệnh được phát hiện, chẩn đoán và điều trị. Nếu bệnh nhân được chuyển đến bệnh viện trong 3 giờ đầu ngay sau khi đột quỵ, và được điều trị thuốc làm tan huyết khối, sự phục hồi khả quan hơn rất nhiều.
**Cách xử lý khi đợi xe cấp cứu**
Nếu người bệnh tỉnh.
Đặt người bệnh ở tư thế đầu nằm nghiêng, đầu hơi nâng nhẹ.
Không cho bệnh nhân ăn hay uống bất cứ thứ gì.
Nếu bị liệt, khi vận chuyển, cần đặt người bệnh nằm nghiêng về bên người không bị liệt.
Lau đờm dãi, bỏ các vật trong miệng có thể khiến bệnh nhân khó thở như răng giả, thức ăn còn sót lại…
Nếu người bệnh ở trạng thái lơ mơ:
Cách sơ cứu khi bị đột quỵ lúc này kiểm tra mạch, nhịp thở của người bệnh. Chú ý nên đặt bệnh nhân ở tư thế nằm nghiêng về một bên không liệt và luôn để đầu ở tư thế nâng nhẹ.
**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/) **- Đa khoa Hạng I Thành phố Hồ Chí Minh

## ️ Các bước sơ cứu khi trật khớp cổ

Trật khớp cổ là hiện tượng thường gặp ở cả người lớn và trẻ em. Chỉ cần xoay cổ đột ngột, ngủ không đúng tư thế, hắt xì quá mạnh,… là bạn đã có nguy cơ rơi vào trường hợp bị trật khớp cổ. Các bước sơ cứu khi bị trật khớp cổ chuẩn nhất được bác sĩ tư vấn.
**1. Các bước sơ cứu khi bị trật khớp cổ**
**Chỉ cần xoay cổ đột ngột, ngủ không đúng tư thế, hắt xì quá mạnh,… là bạn đã có nguy cơ rơi vào trường hợp bị trật khớp cổ**
**Bước 1 – Hạn chế cử động**
Bạn phải giữ yên phần cổ và không được cố xoay đầu theo hướng ngược lại để đưa khớp cổ trở về vị trí ban đầu. Nếu không, bạn sẽ tạo ra lực tác động dẫn đến tổn thương khớp, cơ, dây chằng, dây thần kinh hoặc các mạch máu chung quanh vùng trật khớp.
**Bước 2 – Cố định lại khớp cổ bị trật**
Bạn có thể dùng một miếng vải, dây chun, nẹp để cố định vùng cổ bị đau. Tùy vào vị trí trật khớp mà bạn tìm nơi cố định hợp lý nhằm nâng đỡ cho phần khớp bị trật (Lưu ý: Bạn chỉ nhờ sự giúp đỡ của người có kinh nghiệm trị bị trật cổ).
**Trật khớp cổ gây ảnh hưởng đến khả năng vận động và sinh hoạt của người bệnh**
**Bước 3 – Chườm lạnh**
Không chườm nóng hoặc đắp muối, bạn hãy dùng bọc đá lạnh để chườm trực tiếp lên vùng da đang sưng đau. Việc làm này có thể giúp bạn giảm thiểu cơn đau và triệu chứng phù nề.
**Bước 4 – Đi đến bệnh viện**
Bất kể cấp độ trật khớp ra sao, bạn cũng nên đi đến cơ sở y tế cần nhất để kiểm tra kỹ lưỡng nhằm tránh các biến chứng về sau.
**2. Cách phòng ngừa tình trạng trật khớp cổ**
**Bạn nên đến cơ sở chuyên khoa để thăm khám khi trật khớp cổ**
+ Chỉ tham gia vào những môn thể thao nhẹ nhàng và phù hợp với sức khỏe của mình, chẳng hạn như đi bộ, đạp xe đạp, bơi lội, đánh quần vợt …
+ Không chọn các công việc lao động quá nặng nhọc khi không cần thiết, tránh chơi thể thao quá sức.
+ Khi chơi các môn thể thao đòi hỏi hoạt động mạnh hoặc có tính đối kháng cao bạn nên mang đồ bảo hộ để bảo vệ cho các vùng xương khớp yếu ớt trên cơ thể.
+ Luôn để tâm nhắc nhở trẻ nhỏ trong lúc chạy nhảy và chơi đùa để tránh các tai nạn đáng tiếc có thể xảy ra.
**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/)** - Đa khoa Hạng I Thành phố Hồ Chí Minh

## ️ Cách hô hấp nhân tạo và xoa bóp tim ngoài lồng ngực

  * [Cách hô hấp nhân tạo](https://bvnguyentriphuong.com.vn/cap-cuu/cach-ho-hap-nhan-tao-va-xoa-bop-tim-ngoai-long-nguc#cch-h-hp-nhn-to)
  * [Cách xoa bóp tim ngoài lồng ngực](https://bvnguyentriphuong.com.vn/cap-cuu/cach-ho-hap-nhan-tao-va-xoa-bop-tim-ngoai-long-nguc#cch-xoa-bp-tim-ngoi-lng-ngc)
  * [Lưu ý khi hô hấp nhân tạo](https://bvnguyentriphuong.com.vn/cap-cuu/cach-ho-hap-nhan-tao-va-xoa-bop-tim-ngoai-long-nguc#lu-khi-h-hp-nhn-to)


Khi nạn nhân bị ngưng thở (quan sát thấy lồng ngực nạn nhân không phập phồng), ngay lập tức phải tiến hành hô hấp nhân tạo tại chỗ cho đến khi tự thở được hoặc xác định nạn nhân chắc chắn đã chết thì mới dừng lại.
## **Cách hô hấp nhân tạo**
Khi hô hấp nhân tạo, để nạn nhân nằm ở nơi thoáng đãng, nới rộng quần áo và dây thắt lưng, đệm dưới cổ cho đầu hơi ngửa ra sau để đảm bảo đường hô hấp được thông thoáng, lấy dị vật trong miệng nạn nhân nếu có.
Một tay bịt mũi nạn nhân, tay kia kéo hàm xuống dưới để miệng hở ra, ngậm chặt miệng nạn nhân rồi thổi liên tục hai hơi đối với người lớn, một hơi với trẻ em dưới 8 tuổi, sau đó để lồng ngực tự xẹp xuống rồi lại thổi tiếp.
Người lớn và trẻ em trên 8 tuổi, mỗi phút phải thổi ngạt 20 lần. Trẻ dưới 8 tuổi, mỗi phút phải thổi ngạt 20 – 30 lần.
_Hô hấp nhân tạo_
## **Cách xoa bóp tim ngoài lồng ngực**
Khi nạn nhân bị ngưng tim (áp tai vào lồng ngực không nghe tim đập và sờ mạch không thấy mạch đập), ngay lập tức phải tiến hành cấp cứu nạn nhân tại chỗ bằng cách bóp tim ngoài lồng ngực.
Để nạn nhân nằm trên mặt phẳng cứng, người tiến hành ép tim quỳ gối bên trái nạn nhân. Hai bàn tay chồng lên nhau rồi để trước tim, tương ứng với điểm giữa hai núm vú hoặc khoang liên sườn 4 – 5 bên ngực trái, từ từ ấn sâu xuống khoảng 1/3 cho đến một nửa bề dày lồng ngực, sau đó nới lỏng tay ra.
Người lớn và trẻ em trên 1 tuổi, số lần ép tim trong một phút khoảng 100 lần. Trẻ dưới 1 tuổi, mỗi phút ép tim hơn 100 lần. Trẻ sơ sinh có thể phải ép tim đến 120 lần/phút.
Khi nạn nhân vừa ngưng tim vừa ngưng thở: Phải kết hợp cả ép tim với thổi ngạt, cứ 15 lần ép tim lại thổi ngạt hai lần, với trẻ sơ sinh là ba lần ép tim thổi ngạt một lần.
Sau khi bệnh nhân tự thở được cần đưa ngay đến cơ sở y tế gần nhất để được điều trị kịp thời.
_Xoa bóp tim ngoài lồng ngực_
## **Lưu ý khi hô hấp nhân tạo**
Hô hấp nhân tạo chỉ được thực hiện cho người bị nạn mà tim còn đập (nhưng có thể gây ra thương tổn nguy hiểm).
Không được hô hấp nhân tạo nếu:
– Tim nạn nhân ngừng đập.
– Bạn không biết cách hô hấp nhân tạo. 
**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/) **- Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [Cách hô hấp nhân tạo](https://bvnguyentriphuong.com.vn/cap-cuu/cach-ho-hap-nhan-tao-va-xoa-bop-tim-ngoai-long-nguc#cch-h-hp-nhn-to)
  * [Cách xoa bóp tim ngoài lồng ngực](https://bvnguyentriphuong.com.vn/cap-cuu/cach-ho-hap-nhan-tao-va-xoa-bop-tim-ngoai-long-nguc#cch-xoa-bp-tim-ngoi-lng-ngc)
  * [Lưu ý khi hô hấp nhân tạo](https://bvnguyentriphuong.com.vn/cap-cuu/cach-ho-hap-nhan-tao-va-xoa-bop-tim-ngoai-long-nguc#lu-khi-h-hp-nhn-to)



## ️ Sơ cứu nhanh khi bị trật khớp

Trật khớp là một tai nạn thường gặp. Nguyên nhân thường do bị chấn thương, bị đánh hoặc trượt ngã khi lao động, đang chơi thể thao. Trật khớp do khớp bị trật sai lệch vị trí có thể gây đau đột ngột dữ dội. Do đó, cần được sơ cứu nhanh trước khi đưa đến cơ sở y tế.
_Khi bị trật khớp cần được sơ cứu ngay_
## **Cách sơ cứu khi bị trật khớp**
Trật khớp có thể xảy ra tại các khớp lớn như vai, đầu gối, khuỷu tay hay mắt cá chân hoặc ở các khớp nhỏ hơn như ngón tay, ngón tay cái hoặc ngón chân. Cách sơ cứu như sau:
– Không di chuyển để tránh lực tác động, không nắn hoặc cố cử động khớp bị trật, hoặc bắt nó trở lại vị trí, điều này có thể gây tổn thương khớp và cơ, dây chằng, dây thần kinh hoặc các mạch máu ở xung quanh
– Cố định khớp: Cố định ở tư thế mà khớp đang ở vị trí đó. Nếu khớp bị trật ở vùng tay, khuỷu tay có thể có định bằng cách cột tay vào thân người, dùng thân người làm vật cố định nâng đỡ cho tay. Nếu khớp trật ở chân thì có thể cột hai chân lại với nhau, dùng chân lành làm nẹp cố định cho chân bị trật khớp.
– Chườm lạnh lên vùng khớp bị thương để tránh và giảm sưng phù. Có thể dùng đá lạnh chườm trực tiếp lên da hoặc cho đá vào miếng vải để chườm. Không nên chườm nóng, đắp muối, bóp thuốc rượ
u hay mật gấu vì có thể làm tình trạng xấu đi.
– Nhanh chóng, nhẹ nhàng vận chuyển người bị trật khớp đến cơ sở y tế để các bác sĩ kiểm tra và điều trị.
**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/) **- Đa khoa Hạng I Thành phố Hồ Chí Minh

## ️ Cách sơ cứu khi bị gãy xương tay

  * [Cách sơ cứu khi gãy xương tay](https://bvnguyentriphuong.com.vn/cap-cuu/cach-so-cuu-khi-bi-gay-xuong-tay#cch-s-cu-khi-gy-xng-tay)
  * [Cách sơ cứu trường hợp gãy xương kín](https://bvnguyentriphuong.com.vn/cap-cuu/cach-so-cuu-khi-bi-gay-xuong-tay#cch-s-cu-trng-hp-gy-xng-kn)
  * [Cách sơ cứu trường hợp gãy xương hở ](https://bvnguyentriphuong.com.vn/cap-cuu/cach-so-cuu-khi-bi-gay-xuong-tay#cch-s-cu-trng-hp-gy-xng-h)


Gãy xương tay là tai nạn cần được sơ cứu kịp thời hiệu quả càng sớm càng tốt, sẽ giúp người bệnh giảm được 70% biến chứng. Tuy nhiên, cần biết cách sơ cứu khi bị gãy xương tay đúng mới có thể giúp ích cho người bệnh. Dưới đây là một vài lưu ý khi sơ cứu gãy xương tay bạn đọc có thể tham khảo.
**hận biết dấu hiệu gãy xương tay**
_Bị gãy xương cần được sơ cứu kịp thời hiệu quả_
Gãy xương thường gây mất vận động làm người bệnh đau đớn dữ dội, tuy nhiên dựa theo mức độ nghiêm trọng và đặc điểm vết thương người ta chia gãy xương làm 2 loại chính. Đó là gãy xương kín và gãy xương hở.
+ Gãy xương kín: Là tình trạng gãy xương ở bên trong mô mềm, không nhìn thấy được nhưng có thể nhận biết qua dấu hiệu là sưng tấy tại vùng bị gãy, tụ máu và không thể vận động.
+ Gãy xương hở: Là tình trạng gãy xương trồi ra bên ngoài, ảnh hưởng tới mô mềm có thể nhìn thấy được, đối với những loại vết thương hở cần được chăm sóc điều trị hợp lý để ngăn chặn tình trạng nhiễm trùng có thể xảy ra.
Dù là vết gãy xương hở hay kín thì ngay khi gặp phải tình trạng gãy xương người bệnh cần thực hiện xử lí gấp để nhằm: giảm bớt đau đớn, giảm chấn thương nghiêm trọng đối với da và các dây thần kinh, ngăn ngừa biến chứng nguy hiểm xảy ra đối với người bệnh
## **Cách sơ cứu khi gãy xương tay**
Tùy vào đặc điểm xương bị gãy mà có cách sơ cứu khác nhau như:
### **_Cách sơ cứu trường hợp gãy xương kín_**
_Cần biết cách sơ cứu khi bị gãy xương tay đúng cách_
Đối với trường hợp gãy xương kín thì nên sơ cứu cho bệnh nhân ngay đó là cố định đúng chỗ gãy bằng nẹp gỗ chắc chắn để không làm lệch xương trong quá trình đưa bệnh nhân tới bệnh viện. Bạn không nên cố cởi bỏ quần áo người bị gãy xương vì làm vậy sẽ nguy hiểm làm lệch vị trí cũng như gây đau đớn cho bệnh nhân.
### **_Cách sơ cứu trường hợp gãy xương hở_**
Đối với vết thương gãy xương hở thì sẽ gây nên tình trạng tổn thương phần mềm gây chảy máu, chính vì vậy việc cần làm trước tiên là nên cầm máu trước tiên, nếu xương trồi ra ngoài thì không nên dùng tay điều chỉnh mà cần đỡ tay đưa lên cổ và nẹp lại cố định, đưa bệnh nhân tới bệnh viện càng sớm càng tốt tránh trường hợp mất máu quá nhiều gây tử vong.
Phẫu thuật gãy xương tay tại bệnh viện với đội ngũ bác sĩ giỏi, thiết bị hiện đại
Sau khi hoàn thành sơ cứu cho bệnh nhân gãy xương tay, dù ở trường hợp nào cũng cần đưa bệnh nhân đến bệnh viện gần nhất càng sớm càng tốt.
**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/) **- Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [Cách sơ cứu khi gãy xương tay](https://bvnguyentriphuong.com.vn/cap-cuu/cach-so-cuu-khi-bi-gay-xuong-tay#cch-s-cu-khi-gy-xng-tay)
  * [Cách sơ cứu trường hợp gãy xương kín](https://bvnguyentriphuong.com.vn/cap-cuu/cach-so-cuu-khi-bi-gay-xuong-tay#cch-s-cu-trng-hp-gy-xng-kn)
  * [Cách sơ cứu trường hợp gãy xương hở ](https://bvnguyentriphuong.com.vn/cap-cuu/cach-so-cuu-khi-bi-gay-xuong-tay#cch-s-cu-trng-hp-gy-xng-h)



## ️ Mẹo trị bong gân

Bong gân thường xảy ra ở khu vực cổ tay, khớp gối và mắt cá chân. Hãy áp dụng những mẹo trị bong gân dưới đây để cảm thấy dễ chịu và giảm đau hiệu quả.
**Các mẹo trị bong gân**
Mẹo trị bong gân 1: Chườm đá lạnh sẽ giúp bạn nhanh chóng loại trừ cảm giác đau đớn. Vì thế, khi bị bong gân bạn nên chườm đá lạnh để làm dịu cơn đau.
Mẹo 2: Làm nóng trái me (có thể đem nướng hay hấp trái me), sau đó lấy cùi trái me đem đắp lên vùng bị bong gân hay sưng phồng. Cách làm này sẽ giúp bạn giảm nhẹ cơn đau và nhanh chóng bình phục.
Mẹo 3: Bạn cũng có thể ngâm trái me trong một cốc nước, sau đó chắt lấy nước của nó. Đem nước này đun nóng lên, rồi cho thêm một thìa muối và 1 thìa đường thốt nốt. Đun sôi hỗn hợp cho đến khi nó cô đặc lại như một dạng keo. Dùng hỗn hợp cô đặc đó đắp lên vùng bị bong gân khi còn nóng, mỗi ngày làm đều đặn một lần, bạn sẽ nhanh chóng khắc phục được tình trạng.
Mẹo trị bong gân 4: Trộn lẫn nước chanh vắt và mật ong, rồi bôi lên vùng bị tổn thương.
_Khi bị bong gân bạn có thể chườm đá lạnh để làm dịu cơn đau_
Mẹo 5: Dùng đường thốt nốt trộn lẫn với bơ sữa. Đun nóng hỗn hợp lên và thoa lên chỗ bị bong gân khi dung dịch còn nóng và dùng dải vải để buộc chỗ đó lại.
Mẹo trị bong gân 6: Dùng bột của lá cây cà ri trộn lẫn với nước cốt chanh, để đắp lên chỗ sưng phồng. Cách làm này còn hiệu quả trong những trường hợp bạn bị sưng mọng nước và đau đớn khi bị bỏng.
Mẹo 7: Dầu của cây đinh hương rất hiệu quả trong việc điều trị chứng bong gân và chuột rút. Hãy sử dụng nó như một loại thuốc đắp và thoa trực tiếp lên vùng bị tổn thương.
Mẹo 8: Dùng cam thảo ngâm trong nước, để qua đêm và hôm sau lấy nước này bôi lên vùng bị bong gân.
Mẹo 9: Dầu của cây kinh giới ô rất hiệu qủa trong việc trị bong gân. Bạn hãy dùng loại dầu này thoa lên vùng bị đau.
Mẹo trị bong gân 10: Dùng bột nghệ trộn với nước chanh và muối, rồi đắp lên vùng bị bong gân, bạn sẽ nhanh chóng thấy được hiệu quả.
Mẹo 11: Dùng củ hành khô thái nhỏ, sau đó đắp lên vùng bị bong gân, rồi lấy một miếng vải để băng kín lại.
Mẹo 12: Dùng hỗn hợp bột lá chanh và bơ để tạo thành một dạng hồ nhão, đắp lên vùng bị tổn thương.
Mẹo 13: Lấy một thìa dầu quả hạnh, 1 thìa dầu tỏi, trộn lẫn với nhau và đắp lên vùng bị bong gân.
Mẹo trị bong gân 14: Hơ nóng một lá bắp cải và dùng một dây vải để băng lá bắp cải lên vùng bị thương.
Mẹo 15: Trộn một thìa muối cùng với 2 thìa bột nghệ, cùng một ít nước. Đun lên cho tới sôi và cô lại thành một dạng bột nhão. Đắp lên vùng bị tổn thương khi lớp hồ nhão này vẫn còn nóng. 
Những cách làm trên chỉ áp dụng với những trường hợp bị bong gân nhẹ, chấn thương chỉ gây ra những rối loạn sinh lý, khớp vẫn vững chứ không bị lỏng lẻo. Còn đối với những trường hợp bong gân nặng, không được tự ý chữa trị mà hãy đến ngay tới bệnh viện để đảm bảo an toàn nhất.
**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/) **- Đa khoa Hạng I Thành phố Hồ Chí Minh

## ️ Hướng dẫn chăm sóc vết loét đúng cách

  * [Thế nào là vết thương, vết loét?](https://bvnguyentriphuong.com.vn/cap-cuu/huong-dan-cham-soc-vet-loet-dung-cach#th-no-l-vt-thng-vt-lot)
  * [2 lưu ý khi chăm sóc vết loét](https://bvnguyentriphuong.com.vn/cap-cuu/huong-dan-cham-soc-vet-loet-dung-cach#2-lu-khi-chm-sc-vt-lot)
  * [Băng bó vết thương](https://bvnguyentriphuong.com.vn/cap-cuu/huong-dan-cham-soc-vet-loet-dung-cach#bng-b-vt-thng)


## **Thế nào là vết thương, vết loét?**
Vết thương có thể là do nguyên nhân cơ học, bỏng hay nguyên nhân hóa học. Loét có thể do một số bệnh, khi nằm lâu, ít thay đổi tư thế, vị trí thường gặp ở 2 mông, bả vai, gót, mắt cá chân và loét do bệnh lý thần kinh.
Loét do nằm lâu, nằm yên ở một vị trí gây tỳ nén kéo dài trên da gây thiếu máu cục bộ. Loét chân là do suy tĩnh mạch hay gây thiếu máu cục bộ, bệnh hệ thần kinh ngoại biên, như bệnh nhân đái tháo đường hay bệnh phong. Nhiều vết thương nhất là các vết loét rất lâu lành gây phiền toái và khó khăn trong chăm sóc, điều trị.
_Vết thương loét có thể là do nguyên nhân cơ học, bỏng hay nguyên nhân hóa học_
Điều trị có thể chia làm 3 giai đoạn:
– Giai đoạn cầm máu ngay sau khi có vết thương.
– Giai đoạn kết hạt và tái tạo biểu mô.
– Giai đoạn tu sửa da và tạo lại hình.
Cầm máu tạo thành những cục gồm tiểu cầu và cục máu gồm fibrin, kết hạt và tái tạo biểu mô tiếp theo và kéo dài khoảng ngày thứ 21 kể từ lúc xảy ra vết thương, tùy thuộc vết thương rộng hẹp, nơi có vết thương yếu tố phát triển do tiểu cầu sinh ra sẽ kích thích các nguyên bào sợi tạo nên mô kết hạt gồm chất nền collagen kèm với các mao mạch và các tế bào biểu bì mọc ra tái tạo nên biểu mô trên bề mặt của vết thương.
Chất nền collagen chắc lại trong quá trình tu sửa da và tạo lại hình và kèm theo là giảm bớt các mao mạch. Giai đoạn này có thể kéo dài tới 2 năm kể từ khi bị thương.
## **2 lưu ý khi chăm sóc vết loét**
Việc chăm sóc vết loét cần chú ý một số yếu tố quan trọng: dinh dưỡng đủ chất, đặc biệt là vitamin C và kẽm cần đủ oxy và việc tưới máu phải tốt. Chăm sóc vết loét phải chú ý tránh nhiễm khuẩn toàn thân (hay tại chỗ). Bên cạnh đó là việc xử lý những nhiễm khuẩn này.
Chăm sóc vết loét cần đến một số yếu tố tế bào hay không phải tế bào như các tiểu cầu và các yếu tố phát triển: thiếu các yếu tố này cũng làm vết thương lâu lành. Như vậy, tuổi tác, điều kiện toàn thân, thuốc dùng, dinh dưỡng, khuyết tật bẩm sinh đều ảnh hưởng đến tốc độ lành vết thương.
Chăm sóc vết loét tại chỗ: Rửa, loại bỏ dịch viêm, dự phòng nhiễm khuẩn. Điều trị vết thương và việc lựa chọn các chế phẩm này phải dựa vào kích thước vết thương, nơi có vết thương, loại vết thương, nông hay sâu và nguyên nhân gây nên, sự nhiễm khuẩn và vết thương đang ở giai đoạn nào.
Chăm sóc vết loét thường dùng dung dịch natri chlorid 0,9%, hypochlorid, hydro peroxyd, povidine-iod, chlorhexidin. Hypocholorid có thể làm chậm lành vết thương khi dùng lâu dài vì chúng làm chậm sản sinh collagen và gây viêm.
Dung dịch natri chlorid thích hợp cho việc rửa hàng ngày những vết thương không nhiễm khuẩn. Có nhiều dung dịch rửa cho phép loại bỏ vảy kết như dextranomer, hydrogel, hydrocolloid. Cắt lọc phần mềm có hiệu quả trong việc loại bỏ mô hoại tử.
Các vết thương có thể sinh ra một lượng lớn dịch rỉ do cơ chế viêm, đặc biệt trong mấy ngày đầu. Do đó, khi chăm sóc vết loét, các chế phẩm hydrocollorid và alginat là những chất hút ẩm hiệu quả được sử dụng phổ biến.
Tất cả các vết thương nhiều ít đều có vi khuẩn. Khi nhiễm Pseudomonas aeruginosa thì có thể làm vết thương lâu lành và bạc sulfadiazin được dùng trong trường hợp này, đặc biệt khi bỏng. Khi chăm sóc vết loét, cần phải điều trị nhiễm khuẩn toàn thân khi có lâm sàng như đau đột ngột, viêm mô tế bào, khi chất thải tăng.
## **Băng bó vết thương**
Bên cạnh đó, việc băng bó vết thương là cần thiết. Một số bông băng hấp thụ các dịch viêm. Bông, len, gạc không dùng được cho vết thương sâu vì có thể có sợi tách ra, dính vào vết thương làm vết thương mất nước.
Các hydrogel, hydrocolloid, polysaccharid, cadexomer-oid, alginat và băng bông bọt là những phẩm vật thích hợp cho những vết thương sâu, có hang, có hốc. Với những vết thương có mùi hôi thối, than hoạt rất có hiệu quả. Metronidazol có hoạt tính chống vi khuẩn yếm khí, những vi khuẩn này tạo mùi hăng hắc và được dùng ngoài để khử mùi khó chịu ở các khối u (mà không dùng ở các vết thương vì có thể gây kháng thuốc).
Còn có những cách khác để điều trị những vết thương hay chăm sóc vết loét đặc biệt như làm cho thể dịch ở chân thoát đi, treo cao chân, gập đi gập lại cổ chân, hay dùng băng để bó, ép đều có ích trong vết loét do suy tĩnh mạch.
Các bioflavonoid, oxpentifylin uống cải thiện được tình trạng suy tĩnh mạch, loét chân làm vết thương mau lành. Ketanserin dùng bôi ngoài hay đường toàn thân đã được dùng và tỏ ra có ích cho những vết thương hay vết loét mà lưu lượng máu ở đó không đủ hoặc phẫu thuật mạch là cần thiết. Loét do nằm lâu một vị trí, việc làm giảm lực nén là rất quan trọng. Có một số vết thương cần ghép da.
_(Bài viết chỉ mang tính chất cung cấp thông tin tham khảo. Để biết chính xác tình trạng vết thương, vết loét cũng như phương pháp điều trị, loại thuốc sử dụng, bạn nên tới bệnh viện để được bác sĩ thăm khám. Không tự ý sử dụng thuốc, tránh khiến vết thương thêm trầm trọng hơn.)_
**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/) **- Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [Thế nào là vết thương, vết loét?](https://bvnguyentriphuong.com.vn/cap-cuu/huong-dan-cham-soc-vet-loet-dung-cach#th-no-l-vt-thng-vt-lot)
  * [2 lưu ý khi chăm sóc vết loét](https://bvnguyentriphuong.com.vn/cap-cuu/huong-dan-cham-soc-vet-loet-dung-cach#2-lu-khi-chm-sc-vt-lot)
  * [Băng bó vết thương](https://bvnguyentriphuong.com.vn/cap-cuu/huong-dan-cham-soc-vet-loet-dung-cach#bng-b-vt-thng)



## ️ Sơ cứu khi bị bỏng bô xe máy

  * [Cách sơ cứu khi bị bỏng bô xe máy](https://bvnguyentriphuong.com.vn/cap-cuu/so-cuu-khi-bi-bong-bo-xe-may#cch-s-cu-khi-b-bng-b-xe-my)
  * [Hạn chế sẹo loang lổ bằng cách nào?](https://bvnguyentriphuong.com.vn/cap-cuu/so-cuu-khi-bi-bong-bo-xe-may#hn-ch-so-loang-l-bng-cch-no)


Vì đa phần người bị tai nạn này là phụ nữ, trẻ em vì khi đi trên đường có va chạm xảy ra, phụ nữ chân yếu tay mềm nên dễ bị tai nạn hơn, xử lý không kịp thời và nhanh nhạy. Trẻ em cũng là đối tượng dễ bị bỏng bô xe do hiếu động.
## **Cách sơ cứu khi bị bỏng bô xe máy**
Khi bị bỏng bô xe máy, theo các chuyên gia y tế, cần phải sơ cứu ngay giống như các trường hợp bị bỏng do nhiệt khác..
Cần nhanh chóng dội nước lạnh sạch lên vùng bị bỏng hoặc ngâm vùng bị bỏng vào nước lạnh sạch càng sớm càng tốt. Để khoảng 15 – 20 phút, sau đó băng ép nhẹ vùng bị bỏng bằng gạc vô trùng.
Khi bị bỏng bô xe máy, thời gian lành vết thương khá lâu, khiến cuộc sống của người gặp tai nạn ảnh hưởng khá nhiều, đặc biệt với những phụ nữ đang mang thai hoặc nuôi con nhỏ.
Thời gian khỏi của vết bỏng phụ thuộc vào tính chất vết bỏng đó nông hay sâu, điều trị đúng hay sai. Nhiều người cho rằng bỏng bô xe máy là loại bỏng nhẹ nhưng trên thực tế, bỏng bô xe máy thường rất dễ bị bỏng sâu (do nhiệt độ của ống bô rất cao) do vậy, thời gian điều trị thường kéo dài, thậm chí 3 – 4 tuần.
Theo các bác sĩ, khi bị bỏng ống bô xe không nên tự điều trị bằng các thuốc tự có hay bằng các kinh nghiệm dân gian như đổ nước mắm, bôi kem đánh răng… vào vết bỏng mà cần phải được bác sĩ xác định tổn thương bỏng nông hay sâu để có phương pháp điều trị thích hợp.
Cho dù diện tích bỏng hẹp, ít ảnh hưởng đến tính mạng nhưng nếu điều trị không tốt có thể làm quá trình liền vết thương chậm, ảnh hưởng đến sinh hoạt và để lại di chứng đặc biệt về thẩm mỹ.
## **Hạn chế sẹo loang lổ bằng cách nào?**
Bỏng bô xe máy thường để lại di chứng không thẩm mỹ sau khi khỏi, đặc biệt là với chị em, đó là những vết sẹo sậm màu và loang lổ trên bắp chân.
Để hạn chế điều này, trước hết vết bỏng phải được điều trị đúng để khỏi càng sớm càng tốt, khỏi càng sớm càng ít để lại sẹo hoặc sẹo sẽ ít xấu hơn.
Một lưu ý là không nên bôi nghệ tươi hay các loại kem có nghệ lên vết bỏng để “hết thâm”, bởi theo thống kê của Viện Bỏng quốc gia, tỷ lệ dị ứng do nghệ tươi khá cao, hơn nữa có một tỷ lệ không ít người sau khi bôi nghệ đã bị tình trạng đen bóng lâu dài ở vết sẹo rất khó khắc phục.
Hiện nay đã có những kỹ thuật và sản phẩm mới có thể khắc phục hoàn toàn hoặc đáng kể tình trạng sẹo thâm hay loang lổ do bỏng bô xe máy, đó là việc sử dụng các sản phẩm từ công nghệ tế bào gốc kết hợp với các sản phẩm ức chế men tyrosinaza bôi lên vết sẹo thâm nếu vết sẹo đó dưới 3 tháng.
Với các vết sẹo đã ngoài 3 tháng, cần sử dụng kỹ thuật dermaroller. Dermaroller có khả năng kích thích sản xuất collagen và elastin trong da mà không gây tổn hại. Phương pháp lăn kim này giúp loại trừ rạn da và vết thâm hiệu quả. Sử dụng đúng các tấm dính bằng gel silicon cũng cho thấy hiệu quả trong việc loại trừ vết thâm.
**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/) **- Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [Cách sơ cứu khi bị bỏng bô xe máy](https://bvnguyentriphuong.com.vn/cap-cuu/so-cuu-khi-bi-bong-bo-xe-may#cch-s-cu-khi-b-bng-b-xe-my)
  * [Hạn chế sẹo loang lổ bằng cách nào?](https://bvnguyentriphuong.com.vn/cap-cuu/so-cuu-khi-bi-bong-bo-xe-may#hn-ch-so-loang-l-bng-cch-no)



## Quy trình: Sơ cấp cứu bỏng do vôi tôi nóng

**KHÁI NIỆM**
Bỏng do vôi tôi nóng là bỏng do tiếp xúc với vôi tôi còn nóng. Tổn thương bỏng do 2 yếu tố: nhiệt độ của phản ứng tôi vôi (1500 C) và kiềm do Ca(OH)2 (pH = 13,1). Vôi sẽ tạo thành mảng bám dính vào da gây khó rửa, thậm chí tới ngày thứ 3 vôi vẫn phát huy tác dụng gây bỏng.
Công tác sơ cấp cứu bỏng vôi nói riêng, bỏng do kiềm nói chung về cơ bản cũng bao gồm các bước như bỏng nhiệt, tuy nhiên cần thêm động tác trung hòa sau khi đã ngâm rửa vùng bỏng bằng nước sạch.
**CHỈ ĐỊNH**
Người bệnh bỏng do vôi tôi nóng.
**CHỐNG CHỈ ĐỊNH**
Không có.
**CHUẨN BỊ**
**Người bệnh**
Được giải thích mục đích của ngâm rửa và đề nghị hợp tác
**Dụng cụ, trang bị**
Dụng cụ thay băng
Dung dịch amoni clorua 5- 10%
Dung dịch trung hoà: các acid nhẹ: acid boric 3-5%, acid lactic 3-5%, nước dấm ăn ( acid acetic 0,5-6% ), nước đường 20%.
Dung dịch rửa vết thương: Nước muối sinh lý 0,9%
**Người thực hiện**
Tại hiện trường, người tham gia cấp cứu có thể là tình nguyện viên, hội viên hội chữ thập đỏ…, hoặc chính người bệnh. 
**CÁC BƯỚC TIẾN HÀNH**
**Sơ cấp cứu tại nơi xảy ra tai nạn**
**Bước 1: nhanh chóng cứu người bệnh ra khỏi hố vôi**
Nhanh chóng đưa nạn nhân khỏi tiếp xúc với vôi tôi nóng. Cởi bỏ quần áo còn dính vôi, loại bỏ vôi cục bám dính trên cơ thể.
**Bước 2: Đánh giá nhanh chóng và duy trì các chức năng sống** như hô hấp, tuần hoàn (đề phòng sặc vôi vào phổi, trụy mạch do bỏng rộng...).
Với bỏng do vôi bột: cần lau sạch vôi bám.
**Bước 3: Ngâm rửa vùng bỏng bằng nước sạch càng sớm càng tốt**
Ngâm rửa kết hợp với gắp bỏ những mẩu hóa chất, dị vật đất cát.. còn bám lại. Thời gian ngâm rửa thường kéo dài hơn so với bỏng nhiệt.
**Bước 4: Trung hòa tác nhân gây bỏng bằng acid nhẹ.**
Thao tác này chỉ tiến hành sau khi đã ngâm rửa vùng bỏng bằng nước sạch. Nếu có thể vận chuyển sớm người bệnh tới cơ sở y tế thì không cần tiến hành thao tác này (ưu tiên động tác ngâm rửa, việc trung hòa dành cho tuyến y tế cơ sở) mà thực hiện ngay những thao tác tiếp theo.
**Bước 5: Che phủ tạm thời vết bỏng**
Có thể dùng vật liệu sạch để che phủ vết bỏng, sau đó băng ép nhẹ vùng bỏng. Vẫn tiếp tục tưới rửa nước sạch lên vùng bỏng
**Bước 6: Ủ ấm, bù nước điện giải sau bỏng.**
Bù nước điện giải bằng đường uống (uống oréol, nước chè đường ấm, nước cháo loãng, nước khoáng…
Ủ ấm
Giảm đau cho người bệnh (nếu có thể) bằng các thuốc giảm đau toàn thân.
**Bước 6: Vận chuyển nạn nhân dến cơ sở y tế gần nhất.**
Nếu thời gian vận chuyển kéo dài, có thể tiếp tục tưới rửa vùng bỏng
**Tại cơ sở điều trị**
**Vô cảm:** tiêm thuốc giảm đau hoặc gây mê (theo quy trình riêng).
**Nhanh chóng đánh giá tổn thương toàn thân**(lấy mạch, nhiệt độ, huyết áp...). Tiến hành cấp cứu như suy hô hấp, suy tuàn hoàn.
**Thay băng xử trí kỳ đầu**
Tính diện tích bỏng, chẩn đoán độ sâu.
Xử trí tại chỗ vết bỏng lần đầu: 
Tiếp tục ngâm rửa nếu người bệnh đén sớm trong vòng 1 giờ sau bỏng.
Rửa da lành xung quanh vết bỏng bằng nước đun sôi để nguội, bằng nước xà phòng.
Rửa vết bỏng bằng nước xà phòng 5% làm sạch các vết bỏng.
Cắt mô hoại tử bong rời, cắt bỏ vòm nốt phồng, lấy bỏ dị vật.
Rửa dung dịch NaCl 0,9%. Sát khuẩn bằng dung dịch PVP, berberin...
Thấm khô
Đắp gạc tẩm các dung dịch trung hoà:; dung dịch acid boric 3%, acid acetic 0,5-6%, nước đường 20% hoặc mật ong... nếu có điều kiện: dùng dung dịch đệm natri citrat, đệm phosphat
Đắp gạc hút, băng ép vừa chặt
Thay băng hàng ngày: Có thể sử dụng các thuốc kháng khuẩn; các thuốc giúp chuyển hoại tử ướt thành hoại tử khô. Lưu ý vết thương bỏng do vôi tôi thường hoại tử ướt, tiết dịch nhiều, dễ nhiễm khuẩn gram âm (trực khuẩn mủ xanh…). Thuốc tại chỗ hay dùng với vết bỏng vôi là maduxin.
Cắt bỏ hoại tử sớm để hạn chế nhiễm khuẩn nhiễm độc khi có bỏng sâu. 
**Toàn thân**
Chống sốc bỏng, chống nhiễm khuẩn, nhiễm độc bằng bù dịch, lợi tiểu; kháng sinh toàn thân; nuôi dưỡng tốt. 
**THEO DÕI VÀ XỬ TRÍ TAI BIẾN**
**Theo dõi tình trạng toàn thân**
Mạch, nhiệt độ, huyết áp, nước tiểu theo giờ, theo 24 giờ.
Tình trạng nhiễm độc cấp ở người bệnh bỏng vôi (sốt cao, rối loạn tinh thần…): giải độc, lợi niệu.
**Tại chỗ**
Tình trạng nhiễm khuẩn, đặc biệt là nhiễm khuẩn mủ xanh: dùng thuốc làm khô hoại tử, cắt hoại tử sớm, chống nhiễm khuẩn tại chỗ…
Tình trạng chèn ép kiểu ga rô do bỏng sâu chi thể: rạch hoại tử giải phóng chèn ép
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh

## ️ Sơ cứu vết thương mạch máu

**Dấu hiệu phát hiện vết thương mạch máu**
Vết thương mạch máu lớn thường gây thiếu máu cấp tính. Do mất máu nhanh và nhiều dễ dẫn tới sốc do mất máu. Biểu hiện của sốc mất máu là: nạn nhân hốt hoảng, vật vã, lo âu, vã mồ hôi, mạch nhanh, nhỏ, huyết áp tụt và kẹt.
Với vết thương hở có máu chảy ra ngoài, máu có thể chảy vọt thành tia hoặc chảy rỉ đều dễ nhận biết. Nếu vết thương đã được garô hoặc băng, khi tháo ra, thấy máu chảy dữ dội cũng dễ chẩn đoán, nếu không thấy chảy máu thì phải cảnh giác, kiểm tra mạch đập để xác định có tổn thương mạch máu hay không.
Vết thương không chảy máu ra ngoài có thể gặp hai trường hợp: một là vết thương mạch máu đã ngừng chảy máu; hai là tụ máu dưới da.
Vết thương đứt mạch máu bàn tay trái
Vết thương mạch máu nhờ sơ cứu đã cầm được máu: nhìn chỉ như vết thương phần mềm, rất dễ bị bỏ qua. Vì vậy, bạn cần tìm dấu hiệu thiếu máu ngoại biên như: chi bị thương lạnh, nhợt, không có mạch hoặc mạch đập yếu hơn bên lành, vận động giảm hoặc mất.
_Vết thương mạch máu có thể gây thiếu máu cấp tình nếu không xử lý kịp thời_
Đôi khi vết thương mạch máu có thể tự cầm do: đầu mạch máu bị đứt co rút vào trong các tổ chức phần mềm, lớp nội mạc lộn vào trong lòng mạch, tạo điều kiện hình thành cục máu đông bịt đầu mạch máu lại.
Có khi do chảy máu quá nhiều làm cho huyết áp tụt cũng làm cho máu ngừng chảy, nhưng nếu không cầm máu ngay thì khi hồi sức, huyết áp lên máu lại tiếp tục chảy. Có trường hợp do khối máu tụ chèn ép các mạch máu làm cho máu ngừng chảy.
Tụ máu dưới da có hai hình thái: khối máu tụ lan rộng, đập theo nhịp tim, để lâu bệnh nhân có dấu hiệu thiếu máu. Khối máu tụ khu trú: trường hợp điển hình nếu bị thương ở cẳng chân là bắp chân căng vì khối máu được các cân bao bọc chi hạn chế nên không to lên được nhưng rất căng, làm ngăn cản máu động mạch đến và máu tĩnh mạch về nên chi vùng ngoại vi lạnh, tím, không có mạch, rất đau.
Trường hợp này nếu không xử lý kịp thời sẽ gây hoại thư. Khối máu tụ thường có biến chứng: bị nhiễm khuẩn, nung mủ gây ra triệu chứng sưng, nóng, đỏ, đau rất dễ nhầm với một áp-xe nóng; bọc máu tụ bị vỡ ra ngoài gây chảy máu dữ dội, đe doạ tính mạng của nạn nhân.
Vết thương mạch máu có thể gây biến chứng nguy hiểm như: tử vong do thiếu máu cấp tính, nhiễm độc, hoại thư, co rút cơ, di chứng phồng động mạch và thông động – tĩnh mạch.
**Sơ cứu như thế nào?**
Khi gặp nạn nhân bị vết thương mạch máu, bạn cần nhanh chóng sơ cứu để cứu sống nạn nhân bằng cách: đặt garô, băng ép, ép mạch máu. Cách làm các thủ thuật đó như sau: Đặt garô là phương pháp cầm máu tốt nhưng đòi hỏi thực hiện đúng các quy tắc sau: Đặt chỗ dễ nhìn thấy nhất, gần vết thương nhất, ưu tiên chuyển nạn nhân đến bệnh viện trước kèm theo phiếu ghi giờ đặt garô.
_Sau khi sơ cứu cần đưa bệnh nhân đến bệnh viện để được điều trị tốt nhất_
Trong quá trình đặt garô, cứ một giờ nới lỏng garô trong vài phút cho máu chảy xuống nuôi dưỡng phần dưới chỗ bị thương, sau đó lại tiếp tục siết garô khi máu bắt đầu chảy trở lại.
Khi tháo garô để điều trị thực thụ phải chuẩn bị sẵn phương tiện để cầm máu và hồi sức. Chỉ đặt garô trong các trường hợp sau đây: chi bị dập nát không còn khả năng bảo tồn; đặt garô ở nơi xảy ra tai nạn, nhưng gần một bệnh viện, thời gian vận chuyển bệnh nhân đến bệnh viện dưới một giờ; đặt tạm thời trong một thời gian ngắn để chuẩn bị mổ.
– Băng ép cầm máu: Dùng một cuộn băng hay một chiếc khăn gấp nhỏ lại thành một cục đặt lên vết thương và băng ép lên trên để cầm máu, dùng băng cuộn băng chặt quanh chi cho đến khi không thấy máu thấm băng. Băng ép cầm máu tốt nhất là dùng loại băng chun. Phương pháp này đơn giản dễ thực hiện, có tác dụng cầm máu tốt lại không gây hậu quả xấu đối với vùng bị tổn thương.
– Dùng ngón tay ép lên mạch máu: Bạn dùng ngón tay ép lên đường đi của mạch máu phía trên (gần tim hơn vết thương) vào nền xương. Vị trí thường được dùng để ấn mạch: ở chi trên là sau xương đòn, nếu chảy máu của động mạch dưới đòn ở vùng vai, cánh tay. Tại hõm nạch, nếu chảy máu của động mạch nách và động mạch cánh tay, ở vùng cánh tay.
Tại bờ trong cơ nhị đầu, ở nếp gấp khuỷu, nếu chảy máu của động mạch quay và động mạch trụ, ở vùng cẳng tay. Chi dưới: điểm giữa nếp bẹn, nếu chảy máu của động mạch đùi do vết thương ở dưới đùi. Tại hõm khoeo, nếu chảy máu của động mạch vùng cẳng chân…
Ngoài ra, bạn có thể gấp khuỷu tay hay đầu gối tối đa và ép vào thân để cầm máu, biện pháp này áp dụng khi chưa có điều kiện băng ép hoặc đặt garô. Dùng kẹp cầm máu kẹp các mạch máu. Sơ bộ chống choáng: bằng cách ủ ấm cho nạn nhân, cho nạn nhân uống thuốc trợ tim, giảm đau.
Điều trị ở bệnh viện gồm: Hồi sức tích cực, trường hợp mất máu nhanh và nhiều phải vừa truyền máu vừa mổ để cầm máu. Dùng kháng sinh chống nhiễm khuẩn và tiêm phòng uốn ván.
Tại chỗ: mở rộng vết thương để tìm đầu mạch máu bị đứt thắt lại, cắt lọc sạch những tổ chức dập nát ở phần mềm, lấy dị vật, máu tụ, loại bỏ các ngóc ngách của vết thương. Áp dụng một trong những cách cầm máu vĩnh viễn như: thắt các đầu mạch máu bị đứt ở ngay vết thương; thắt mạch máu ở xa vết thương; ghép mạch máu; cắt cụt chi.
**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/) **- Đa khoa Hạng I Thành phố Hồ Chí Minh

## ️ Xử lý nhanh khi bị ngộ độc thực phẩm

**Nhận biết ngộ độc thực phẩm**
Việc dùng phải thức ăn để qua ngày, không được giữ ở nhiệt độ phù hợp hay thức ăn nấu chưa chín có thể dẫn tới ngộ độc.
Những triệu chứng phổ biến nhất để nhận biết một ca ngộ độc là: chóng mặt buồn nôn, ói, tiêu chảy, đau bụng.
Thông thường bạn sẽ mắc phải các triệu chứng này sau khoảng 3-4 giờ sau khi ăn nhầm thực phẩm bị hỏng. 
_Buồn nôn khi ngộ độc thực phẩm_
**Mất nước do tiêu chảy và nôn**
Điều quan trọng nhất khi giúp đỡ người bị ngộ độc thực phẩm là giữ cho họ không bị mất quá nhiều nước. việc mất nước sẽ khiến người bệnh mệt mỏi hơn và kéo dài thời gian bình phục. Mất nước thường xảy ra vì khi ngộ độc cơ thể sẽ có phản ứng nôn ói và đi ngoài. Bạn nên tập thói quen uống nhiều nước ngay từ bây giờ để góp phần giúp cơ thể có thể chịu đựng tốt nếu chẳng may trải qua một cơn ngộ độc.
Đối với người bệnh bị tiêu chảy nhiều, nên cho uống nước muối sinh lý. Loại muối này dễ tìm ở các hiệu thuốc tây. Nếu bệnh nhân có bệnh sỏi thận thì nên tham khảo ý kiến dược sĩ, bác sĩ.
Sau khi tình trạng ngộ độc đỡ dần, để đẩy nhanh sự hồi phục, bạn nên:
– Ăn những bữa ăn nhỏ 
– Dùng các loại thực phẩm dễ tiêu như cháo, súp 
– Nghỉ ngơi nhiều 
– Tránh xa bia rượu, cà phê, chất kích thích
Nếu tình trạng mất nước trở nên nghiêm trọng với các triệu chứng: chóng mặt, mờ mắt, không thể đi ngoài dù rất đau bụng thì bạn cần được đưa tới bệnh viện ngay. 
Tại đó, các bác sĩ sẽ truyền dịch cho bạn và theo dõi sức khỏe của bạn cho tới khi các triệu chứng trên đỡ dần.
_Khi bị tiêu chảy do ngộ độc thực phẩm cần uống nhiều nước_
**Phòng ngừa ngộ độc thực phẩm**
Việc ăn uống là do sự chủ động của chúng ta thế nên cách phòng bệnh cũng không quá khó nếu bạn thực hiện các nhắc nhở sau: 
– Luôn giữ các loại thực phẩm từ sữa, rau củ sống trong tủ lạnh. Salads trộn cũng cần được giữ trong tủ lạnh
– Rã đông thịt bằng cách hạ dần nhiệt độ tủ lạnh, không để thịt ra ngoài phòng rồi rã đông
– Nếu làm các món nhồi, nên hấp chín nhân trước khi nhồi và nấu lại, hoặc chỉ nhồi nhân vào sát lúc nấu
– Luôn rửa sạch tay trước khi làm bếp, sau khi đi vệ sinh và trước khi ăn. 
– Cần nấu chín kỹ các loại thịt như: thịt gà, thịt bò, thịt heo. Tuyệt đối không ăn các món chín tái vì rất dễ gây ngộ độc.
**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/) **- Đa khoa Hạng I Thành phố Hồ Chí Minh

## ️ Dấu hiệu ngộ độc thực phẩm cần phải nắm

  * [4. Mệt mỏi và chán ăn](https://bvnguyentriphuong.com.vn/cap-cuu/dau-hieu-ngo-doc-thuc-pham-can-phai-nam#4-mt-mi-v-chn-n)
  * [5. Buồn nôn và nôn](https://bvnguyentriphuong.com.vn/cap-cuu/dau-hieu-ngo-doc-thuc-pham-can-phai-nam#5-bun-nn-v-nn)
  * [6. Ớn lạnh, sốt](https://bvnguyentriphuong.com.vn/cap-cuu/dau-hieu-ngo-doc-thuc-pham-can-phai-nam#6-n-lnh-st)


Ngộ độc thực phẩm (hoặc trúng thực theo cách gọi dân gian) là gì? Đây là tình trạng xảy ra do tiêu thụ thực phẩm hoặc đồ uống không hợp vệ sinh nhiễm vi khuẩn, virus hoặc ký sinh trùng gây hại. Các sinh vật có hại trong thực phẩm thường bị phá hủy trong quá trình nấu ăn. Tuy nhiên, nếu bạn không thực hành vệ sinh tốt và bảo quản thực phẩm đúng cách thì ngay cả thực phẩm nấu chín cũng còn tồn tại các vi sinh vật ấy và có thể gây ngộ độc.
Việc ăn thực phẩm có chứa độc tố độc hại cũng có thể gây ngộ độc thực phẩm. Những nguyên nhân gây ngộ độc thực phẩm này có thể xuất hiện tự nhiên trong thực phẩm như một số loài nấm hoặc vi khuẩn trong thực phẩm đã bị hỏng.
Triệu chứng ngộ độc có thể xuất hiện từ vài giờ đến vài ngày kể từ lúc bạn ăn thức ăn nhiễm độc. Triệu chứng nặng nhẹ, kéo dài hay mau khỏi phụ thuộc vào các loại tác nhân gây ngộ độc, lượng thức ăn tiêu thụ và hệ miễn dịch của bạn.
## **1. Đau bụng**
Đau bụng là một trong những biểu hiện của ngộ độc thực phẩm.
Trong trường hợp ngộ độc thực phẩm, các sinh vật gây hại có thể tạo ra độc tố gây kích ứng niêm mạc dạ dày và ruột. Điều này có thể dẫn đến viêm đau ở dạ dày, làm xuất hiện triệu chứng đau bụng. Triệu chứng đau do co thắt cơ dạ dày vùng trên rốn hoặc ruột non quanh rốn để tăng tốc độ chuyển động tự nhiên của ống tiêu hóa nhằm loại bỏ các sinh vật gây hại càng nhanh càng tốt.
Tuy nhiên, đau bụng là triệu chứng phổ biến của nhiều bệnh lý và tình trạng sức khỏe. Do đó, khi triệu chứng này xuất hiện một mình vẫn chưa đủ để kết luận rằng bạn bị ngộ độc thực phẩm.
## **2. Tiêu chảy**
Tiêu chảy là biểu hiện ngộ độc thực phẩm phổ biến, chính là tình trạng đi phân lỏng trên 3 lần trong khoảng thời gian 24 giờ. Đây là một triệu chứng trúng thực điển hình, xảy ra khi tình trạng viêm khiến cho ruột làm việc kém hiệu quả trong quá trình tái hấp thu nước và các chất lỏng khác tiết ra trong quá trình tiêu hóa.
Tiêu chảy cũng có thể đi kèm với các triệu chứng của ngộ độc thực phẩm khác như cảm giác luôn muốn đi vệ sinh, đầy hơi hoặc đau bụng. Tiêu chảy nhiều có thể khiến cơ thể mất nước và các khoáng chất, nặng hơn có thể tụt huyết áp. Do đó, điều quan trọng là bạn cần bổ sung nước đầy đủ để duy trì lượng nước cho cơ thể, ổn định tuần hoàn.
## **3. Đau đầu**
Đau đầu, chóng mặt cũng có thể là dấu hiệu bị ngộ độc thực phẩm.
Nhức đầu do căng thẳng, uống quá nhiều rượu, thức ăn có nhiều bột ngọt, mất nước và mệt mỏi. Dấu hiệu ngộ độc thực phẩm là vừa bị nôn mửa và tiêu chảy dễ dẫn đến đau đầu. Đặc biệt triệu chứng này thường xảy ra khi bệnh nhân mất nước và sốt.
## **4. Mệt mỏi và chán ăn**
Mệt mỏi chán ăn bất thường có thể là biểu hiện ngộ độc thức ăn.
Trong một phần của phản ứng miễn dịch, cơ thể giải phóng các chất hóa học được gọi là cytokine. Cytokine có vai trò quan trọng điều hòa phản ứng miễn dịch cơ thể đối với nhiễm trùng bằng cách truyền thông tin cho các tế bào miễn dịch tìm đến và tiêu diệt mầm bệnh. Quá trình này.dẫn đến các biểu hiện như sốt, đau cơ, chán ăn, mệt mỏi.
## **5. Buồn nôn và nôn**
Buồn nôn và nôn là dấu hiệu tự nhiên thường xảy ra ở những người bị ngộ độc thực phẩm. Điều này xuất hiện khi cơ bụng và cơ hoành co bóp mạnh, khiến bạn phải đưa những chất có trong dạ dày ra khỏi miệng. Đây là một cơ chế bảo vệ xảy ra khi cơ thể bạn cố gắng loại bỏ các sinh vật hoặc độc tố nguy hiểm mà nó phát hiện là có hại.
Trong thực tế, dấu hiệu ngộ độc thực phẩm thường dẫn đến các cơn nôn mửa kéo dài. Sau đó, có người sẽ giảm dần mức độ, có người lại nôn mửa liên tục nhiều hơn. Cách tốt nhất là bạn hãy đến gặp bác sĩ hoặc dược sĩ để tránh tình trạng nôn mửa gây mất nước.
## **6. Ớn lạnh, sốt**
Sốt là dấu hiệu ngộ độc thực phẩm khi nhiệt độ cơ thể bạn tăng cao hơn 38ºC. Đây cũng là triệu chứng phổ biến trong nhiều bệnh và xuất hiện như một phần phòng thủ tự nhiên của cơ thể. Sự gia tăng nhiệt độ này làm tăng hoạt động của các tế bào bạch cầu giúp bạn chống lại tình trạng nhiễm trùng.
Sốt còn được gây ra bởi pyrogens làm kích hoạt sự gia tăng nhiệt độ, được giải phóng bởi hệ thống miễn dịch hoặc vi khuẩn truyền nhiễm đã xâm nhập vào cơ thể bạn. Chất này gây sốt bằng cách gửi tin nhắn lừa bộ não khiến nó nghĩ rằng cơ thể lạnh hơn bình thường. Điều này khiến cơ thể bạn tạo ra nhiều nhiệt hơn và mất ít nhiệt hơn, do đó làm tăng nhiệt độ cơ thể.
Thực tế, tình trạng ớn lạnh thường đi kèm với những cơn sốt, vì pyrogens lừa cơ thể bạn nghĩ rằng cơ thể đang lạnh và cần phải làm nóng.
## **7. Đau cơ**
Bạn có thể bị đau cơ bắp khi nhiễm trùng do ngộ độc thực phẩm. Điều này xảy ra do hệ thống miễn dịch của cơ thể đã được kích hoạt, gây viêm. Trong quá trình này, cơ thể giải phóng histamine, một hóa chất giúp mở rộng các mạch máu để cho phép nhiều tế bào bạch cầu đi qua để chống lại nhiễm trùng.
Histamine giúp tăng lưu lượng máu đến các khu vực bị nhiễm bệnh trên cơ thể. Cùng với các chất khác liên quan đến phản ứng miễn dịch, chẳng hạn như cytokine, histamine có thể đến các bộ phận khác trên cơ thể và kích hoạt các thụ thể gây đau. Điều này khiến cho một số bộ phận của cơ thể bạn nhạy cảm hơn với cơn đau và dẫn đến những cơn đau âm ỉ mà bạn thường gặp phải khi bị ốm.
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [4. Mệt mỏi và chán ăn](https://bvnguyentriphuong.com.vn/cap-cuu/dau-hieu-ngo-doc-thuc-pham-can-phai-nam#4-mt-mi-v-chn-n)
  * [5. Buồn nôn và nôn](https://bvnguyentriphuong.com.vn/cap-cuu/dau-hieu-ngo-doc-thuc-pham-can-phai-nam#5-bun-nn-v-nn)
  * [6. Ớn lạnh, sốt](https://bvnguyentriphuong.com.vn/cap-cuu/dau-hieu-ngo-doc-thuc-pham-can-phai-nam#6-n-lnh-st)



## ️ Bảo quản một số vật dụng, dụng cụ tại khoa cấp cứu

Trong cấp cứu người bệnh hàng ngày, ngoài nhân tố con người thì các trang thiết bị y tế đóng vai trò vô cùng quan trọng, có thể xem như “cánh tay phải” của người thầy thuốc. Nếu chúng ta biết quý trọng nó để có cách bảo quản, sử dụng đúng thì sẽ phát huy hết tính năng của nó, duy trì được tuổi thọ lâu dài. Ngược lại, nếu thờ ơ, không biết cách bảo quản thì chúng sẽ nhanh bị hỏng và trục trặc trong quá trình sử dụng.
**1. Bơm tiêm điện:**
Là thiết bị điện tử nên khi sử dụng phải nhẹ nhàng, gắn vào cọc truyền chắc chắn, vững. Không được để nước, dịch ngấm vào máy. Chỉ sử dụng khăn khô mềm để lau thân máy. Khi không sử dụng thì luôn nhớ trả piston và xoay cần giữ bơm tiêm về vị trí ban đầu. Nạp điện đầy đủ cho máy.
**2. Bộ đặt nội khí quản**
Bao gồm cán, lưỡi, bóng đèn và pin
Thường xuyên kiểm tra bóng đèn và các khớp nối giữa bóng đèn với lưỡi, lưỡi và cán, phải đảm bảo dẫn điện tốt. Tuyệt đối không để dịch, máu tồn tại giữa các vị trí trên. Sau khi sử dụng thì tháo pin ra khỏi cán. Luôn giữ các bộ phận khô ráo, sạch, không để rỉ rét.
**3. Máy sốc tim:**
Đặt máy trên giá tư thế thăng bằng, vững. Không để dịch hoặc các loại chất lỏng khác ngấm vào máy. Xoay các núm điều chỉnh nhẹ nhàng, đúng chiều như hướng dẫn. Sau sử dụng vệ sinh thân máy bằng khăn vải mềm, khô, lau sạch kem dẫn điện ở các bản điện cực, các dây điện cực phải vuốt thằng không để quấn vào nhau và treo lên giá. Nạp điện đầy đủ.
**4. Monitor:**
Cũng như máy sốc tim, monitor cần được đặt trên giá bằng phẳng, vững chắc.
Vận chuyển nhẹ nhàng theo tư thế như khi sử dụng. Không để các chất lỏng ngấm vào máy, vệ sinh thân máy bằng khăn vải mềm, khô, dùng khăn che đậy máy khi không sử dụng. Thao tác các phím, núm điều chỉnh trên máy phải rất nhẹ nhàng. Lau sạch các điện cực không để rỉ rét. Vuốt thẳng và treo các dây điện cực lên giá. Nạp điện thường xuyên cho máy. 
Trên đây chỉ là một số máy móc, dụng cụ thường xuyên được dùng trong cấp cứu, hồi sức. Tất cả chúng ta đều phải có trách nhiệm bảo quản các tài sản để đảm bảo luôn sẵn sàng sử dụng tốt, cấp cứu người bệnh kịp thời.
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh

## ️ Nhận biết và xử trí tai biến mạch máu não tại cộng đồng

Tai biến mạch não là gì?
Tai biến mạch máu não (hay còn gọi là đột quỵ não) là một tình trạng thiếu hụt chức năng não một cách cấp tính xảy ra khi khi lượng máu cung cấp cho não đột ngột bị gián đoạn do mạch máu bị vỡ hoặc bị tắc nghẽn gây nên. Khi đó, não không được máu "nuôi dưỡng" sẽ mất khả năng kiểm soát các chức năng của cơ thể, nếu không được điều trị kịp thời, người bị tai biến mạch não sẽ có nguy cơ tử vong, thậm chí nếu có may mắn sống sót thì phần lớn bọn họ đều phải chịu những di chứng nặng nề suốt đời như sống thực vật, liệt nửa người, nói ngọng hoặc mất hẳn khả năng nói chuyện,… Hiện nay, tai biến mạch não là 1 trong những bệnh có nguy cơ gây tử vong và tàn tật cao hàng đầu (chỉ sau các bệnh ung thư và tim mạch).
Tùy vào nguyên nhân trực tiếp gây đột quỵ mà người ta phân chia tai biến mạch não thành 2 loại là : đột quỵ do tắc nghẽn mạch máu nuôi não (còn gọi là nhồi máu não) và đột quỵ do vỡ mạch máu (gọi là xuất huyết não).
Tai biến mạch máu não có nguy hiểm không?
Các tế bào não là những tế bào có khả năng chịu đựng tình trạng thiếu oxy kém nhất trong cơ thể. Vì thế, khi bị đột quỵ não, tại phần não bộ bị thiếu oxy thì tế bào não sẽ bị chết đi chỉ sau vài phút. Sau khi đột quỵ xảy ra, cứ mỗi phút trôi qua sẽ có khoảng gần 2 triệu tế bào não bị chết và làm người bệnh già hơn khoảng 3 tuần tuổi. Chính vì vậy, “Thời gian chính là Não”. Người bệnh cần được điều trị tái tưới máu lại cho não càng sớm càng tốt.
Theo báo cáo của tổ chức đột quỵ thế giới, mỗi năm trên thế giới có khoảng 16 triệu người bị tai biến mạch máu não và khoảng 6 triệu người tử vong vì căn bệnh này; cũng như để lại nhiều di chứng nặng nề, tạo gánh nặng cho gia đình và xã hội.
Những ai có nguy cơ cao bị tai biến mạch não?
Những người bị đái tháo đường (nguy cơ gấp 4 lần so với người bình thường)
Bệnh nhân tăng huyết áp (nguy cơ gấp 3 lần so với người bình thường) hoặc có mắc các bệnh tim mạch (nguy cơ tăng gấp 6 lần)
Những người béo phì hoặc có rối loạn mỡ máu
Những người có lối sống thiếu lành mạnh như lười vận động, hút nhiều thuốc lá ; sử dụng nhiều rượu bia, chất kích thích.
Những người có người thân đã từng hoặc đang bị tai biến mạch não cũng có nguy cơ bị tai biến cao hơn.
Nam giới có nguy cơ đột quỵ cao hơn nữ giới, tuổi bị đột quỵ của nam giới cũng sớm hơn, phụ nữ thường bị đột quỵ khi đã cao tuổi hoặc có mắc nhiều bệnh phối hợp khác. Tuy nhiên khả năng phục hồi sau đột quỵ của nữ giới thấp hơn và nguy cơ tử vong khibị đột quỵ cũng cao hơn so với nam giới.
Tai biến mạch máu não có phòng ngừa được không?
Thực hành 1 lối sống lành mạnh: thường xuyên có các hoạt động thể lực hợp lý như tập thể dục, chơi thể thao; không uống rượu bia, hút thuốc, không sử dụng các chất kích thích, chế độ ăn uống hạn chế uống nước ngọt, hạn chế ăn nhiều các thức ăn có nhiều chất béo, đồ ăn nhanh …
Kiểm soát tốt các bệnh lý có nguy cơ dẫn đến tái biến mạch não: đái tháo đường, tăng huyết áp, rối loạn lipid máu, các bệnh tim mạch (suy tim, rung nhĩ…)
Thường xuyên khám sức khỏe định kỳ để sớm phát hiện ra các vấn đề sức khỏe (VD: đái tháo đường hay tăng huyết áp) để có thể kiểm soát tốt từ sớm, nhất là ở các đối tượng có nhiều yếu tố nguy cơ, người cao tuổi.
Nhận biết tai biến mạch não tại cộng đồng:
Triệu chứng của đột quỵ não rất đã dạng, phong phú (tùy theo vị trí não bộ bị tổn thương mà có triệu chứng khác nhau). Các triệu triệu chứng thường gặp gồm có: liệt (thường là liệt nửa người, có khi là liệt tứ chi), rối loạn thị giác, rối loạn ngôn ngữ (nói ngọng hoặc không nói được hoặc không hiểu được người khác nói gì), đau đầu (rất thường gặp, có thể > 50% bệnh nhân có triệu chứng này), rối loạn ý thức thậm chí hôn mê...
Do vậy, khi thấy người thân đột ngột có những biểu hiện sau:
Mặt: lệch so với trước, biểu hiện rõ khi cười nói.
Tay: vụng về khi vận động, yếu, liệt nửa người.
Nói: khó khăn, phát âm không chuẩn so với trước.
Dần mất ý thức, lơ mơ
cần nhanh chóng đưa bệnh nhân đến cơ sở y tế gần nhất để khám và điều trị
Gần đây, trên mang xã hội Facebook có lan truyền 1 thông tin về cách sơ cứu người bị tai biến mạch não như sau: “khi phát hiện người thân bị đột quỵ não, hay cấp cứu bằng cách: có thể dùng một cây kim may chích vào đầu ngón tay, cách móng tay độ một milimét cho đến khi có máu rỉ ra. Như thế, khi máu đã chảy từ cả mười đầu ngón tay, chỉ chờ vài phút thì bệnh nhân sẽ tỉnh dậy. Bước tiếp theo là châm vào hai bên dái tai mỗi bên 2 mũi, cho đến khi máu nhỏ giọt ra. Sau vài phút, bệnh nhân sẽ tỉnh lại”. Tuy nhiên, theo ý kiến của nhiều chuyên gia, cách sơ cứu như vậy là hoàn toàn sai lầm, không có lợi ích gì, thậm chí còn có thể gây nguy hiểm cho bệnh nhân do nhiều người tin vào cách làm này, không chịu đưa bệnh nhân đi cấp cứu làm bỏ qua thời gian vàng để điều trị cho bệnh nhân.
Xử trí tại hiện trường:
- Đánh giá mức độ ý thức của bệnh nhân:
+ Nếu bệnh nhân bất tỉnh và thở bình thường, hoặc nếu không hoàn toàn tỉnh táo, đặt bệnh nhân nằm nghiêng ở một vị trí thuận lợi (tư thế nằm nghiêng an toàn) với đầu cao (nếu huyết áp bình thường) hoặc đầu thấp (nếu tụt huyết áp).
- Gọi thêm người hỗ trợ và gọi số điện thoại cấp cứu 115 hoặc số điện thoại dịch vụ cấp cứu y tế tại địa phương bạn ngay lập tức.
- Chăm sóc cho bệnh nhân còn tỉnh:
+ Hỗ trợ bệnh nhân còn tỉnh táo ở một tư thế thoải mái nhất
+ Đắp chăn cho bệnh nhân để làm giảm mất nhiệt nếu thời tiết lạnh
- Theo dõi bệnh nhân:
+ Trong khi đợi xe cứu thương đến hoặc đợi người hỗ trợ đưa bệnh nhân đi bệnh viện, cần theo dõi bệnh nhân chặt chẽ nhằm phát hiện bất cứ sự thay đổi tình trạng nào.
+ Nếu có bất cứ dấu hiệu suy giảm tình trạng ý thức nào của bệnh nhân, đặt bệnh nhân nằm nghiêng ở một vị trí thuận lợi (tư thế nằm nghiêng an toàn).
Điều trị đặc hiệu tại cơ sở y tế:
- Tái thông mạch máu càng sớm càng tốt.
- Điều trị bằng liệu pháp oxy cao áp (HBOT): nhờ tác dụng của áp suất cao, các phân tử oxy có thể vượt qua được chỗ mạch máu bị tắc nghẽn cung cấp cho các nhu mô não đang bị thiếu ôxy giúp bảo vệ và phục hồi 1 phần chức năng não bị tổn thương do đột quỵ.
- Tập vận động và phục hồi chức năng.
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh

## ️ Sơ cứu khi phát hiện người đột quỵ

  * [Dấu hiệu và triệu chứng thường gặp của đột quỵ não là gì?](https://bvnguyentriphuong.com.vn/cap-cuu/so-cuu-khi-phat-hien-nguoi-dot-quy#du-hiu-v-triu-chng-thng-gp-ca-t-qu-no-l-g)
  * [Sơ cứu và điều trị](https://bvnguyentriphuong.com.vn/cap-cuu/so-cuu-khi-phat-hien-nguoi-dot-quy#s-cu-v-iu-tr)
  * [Làm thế nào để sơ cứu người bị đột quỵ não?](https://bvnguyentriphuong.com.vn/cap-cuu/so-cuu-khi-phat-hien-nguoi-dot-quy#lm-th-no-s-cu-ngi-b-t-qu-no)


### Dấu hiệu và triệu chứng thường gặp của đột quỵ não là gì?
Theo dõi các dấu hiệu đột quỵ nếu bạn nghĩ rằng mình hoặc người khác sắp bị đột quỵ. Chú ý thời điểm các dấu hiệu này bắt đầu. Việc phát hiện chậm trễ dấu hiệu đột quỵ sẽ gây ảnh hưởng rất lớn đến kết quả điều trị và có thể dẫn đến tử vong. Các dấu hiệu đó bao gồm:
  * Gặp khó khăn khi nói và hiểu lời người khác: Khi bị đột quỵ, bạn có thể gặp khó khăn khi nói hoặc hiểu lời nói của người khác.
  * Tê liệt ở mặt, cánh tay hoặc chân: Bạn có thể bị yếu hoặc tê liệt đột ngột ở mặt, cánh tay hoặc chân. Điều này thường xảy ra ở một bên cơ thể. Hãy cố gắng giơ cả hai tay lên đầu cùng lúc. Nếu một cánh tay bắt đầu buông thõng xuống, đó có thể là triệu chứng của đột quỵ não. Ngoài ra, một bên miệng của bạn có khả năng bị xệ xuống khi bạn mỉm cười.
  * Gặp vấn đề về thị lực ở một hoặc cả hai mắt: Một hoặc cả hai mắt của bạn có thể đột ngột bị mờ hoặc nhìn đôi (song thị).
  * Đau đầu: Đau đầu đột ngột dữ dội, kèm theo nôn mửa, chóng mặt hoặc thay đổi ý thức, có thể là dấu hiệu cảnh báo bạn đang bị đột quỵ.
  * Khó khăn khi đi lại: Bạn có thể bị vấp ngã hoặc chóng mặt đột ngột, mất thăng bằng hay mất sự phối hợp của cơ thể.


Hãy gọi cấp cứu 115 ngay khi bạn thấy ai đó có những dấu hiệu đột quỵ não.
## Sơ cứu và điều trị
### Làm thế nào để sơ cứu người bị đột quỵ não?
Nếu nghi ngờ một người bị đột quỵ, bạn cần gọi cấp cứu ngay. Trong lúc chờ xe cấp cứu đến, bạn nên thực hiện những bước sau để sơ cứu đột quỵ cho bệnh nhân:
  * Đặt người bị đột quỵ nằm ở nơi an toàn, thoải mái, nằm nghiêng một bên, đầu hơi nâng cao.
  * Kiểm tra xem họ có đang thở không. Nếu không, bạn hãy thực hiện hồi sức tim phổi (CPR) cho bệnh nhân. Nếu họ khó thở, hãy nới lỏng hoặc cởi bớt quần áo không cần thiết như cà vạt hay khăn quàng cổ.
  * Trò chuyện và trấn an bệnh nhân.
  * Đắp chăn cho họ để giúp giữ ấm.
  * Không cho họ ăn hay uống bất cứ thứ gì.
  * Nếu người bệnh có biểu hiện yếu chi, bạn không được di chuyển họ.
  * Quan sát cẩn thận bất cứ sự thay đổi nào của bệnh nhân và nói lại những triệu chứng đột quỵ của người bệnh cho nhân viên y tế, ví dụ như bị ngã hoặc đập vào đầu.


**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [Dấu hiệu và triệu chứng thường gặp của đột quỵ não là gì?](https://bvnguyentriphuong.com.vn/cap-cuu/so-cuu-khi-phat-hien-nguoi-dot-quy#du-hiu-v-triu-chng-thng-gp-ca-t-qu-no-l-g)
  * [Sơ cứu và điều trị](https://bvnguyentriphuong.com.vn/cap-cuu/so-cuu-khi-phat-hien-nguoi-dot-quy#s-cu-v-iu-tr)
  * [Làm thế nào để sơ cứu người bị đột quỵ não?](https://bvnguyentriphuong.com.vn/cap-cuu/so-cuu-khi-phat-hien-nguoi-dot-quy#lm-th-no-s-cu-ngi-b-t-qu-no)



## Sơ cấp cứu bỏng do giật điện

**KHÁI NIỆM**
Bỏng điện là tình trạng tổn thương tại chỗ và toàn thân do dòng điện dẫn truyền qua cơ thể, biến điện năng thành nhiệt năng và gây nên tình trạng rối loạn điện giải trong và ngoài tế bào dẫn đến tổn thương các tế bào (hiệu ứng đục lỗ).
Bỏng tia lửa điện không phải là bỏng điện mà là bỏng nhiệt khô.
Bỏng do dòng điện cao thế thường gây ngừng hô hấp trước ngừng tim, tình trạng nặng nề, tỷ lệ tử vong và tàn phế cao. Bỏng do dòng điện hạ thế (điện sinh hoạt) thường gây ngừng tim trước ngừng hô hấp, tỷ lệ tử vong và tàn phế ít hơn.
**CHỈ ĐỊNH**
Người bệnh bị bỏng do dòng điện
**CHỐNG CHỈ ĐỊNH**
Dòng điện đi qua cơ thể (bị điện giật) nhưng không gây tổn thương bỏng tại chỗ và toàn thân hoặc bỏng do tia lửa điện.
**CHUẨN BỊ**
**Người thực hiện**
Cấp cứu tại hiện trường: người cấp cứu là tình nguyện viên, hội viên Hội chữ thập đỏ
Tại cơ sở y tế : bá sỹ, điều dưỡng
**Phương tiện**
Các phương tiện cấp cứu ngừng hô hấp và tuần hoàn.
Địa điểm, buồng bệnh
Cấp cứu nạn nhân bị điện giật có ngừng tim, ngừng thở (sốc điện) ngay tại nơi xảy ra tai nạn 
Điều trị nạn nhân bỏng điện tại buồng hồi sức cấp cứu; buồng điều trị bỏng; buồng bệnh ngoại khoa hay buồng bệnh khác có trang bị phương tiện theo yêu cầu.
**Người bệnh**
Cấp cứu người bệnh bị điện giật: Càng sớm càng tốt tách người bệnh ra khỏi nguồn điện, để ở nơi thoáng, trên nền cứng. 
Điều trị bỏng điện: chỉ tiến hành sau khi nạn nhân đã được hồi sức cấp cứu sốc điện (nếu có), nạn nhân tim đập trở lại và tự thở lại. 
**CÁC BƯỚC TIẾN HÀNH**
**Sơ cấp cứu tại nơi xảy ra tai nạn**
**Bước 1: bình tĩnh, nhanh chóng tách nạn nhân khỏi nguồn điện**
Tìm mọi cách ngắt nguồn điện, tháo cầu chì, cắt cầu dao, kéo phích cắm khỏi ổ điện. 
Dùng vật không dẫn điện tách người bệnh khỏi nguồn điện.
Khi cấp cứu nên gọi thêm người đến hỗ trợ, cả khi người cấp cứu là nhân viên y tế.
**Bước 2: đánh gia và cấp cứu ban đầu**
Tiến hành theo nguyên tắc về cấp cứu ban đầu: ABCDE (theo hiệp hội cấp cứu chấn thương quốc tế- primary trauma care foundation):
**_(airway):_** đường thở. Cần nhận biết người bệnh có tỉnh không, tiếp xúc được không? Bảo đảm người bệnh thực sự lưu thông đường thở. 
**_(breading): hô hấp_**
Đánh giá rối loạn hô hấp dựa vào tần số thở, sự gắng sức khi thở. Nếu ngừng thở phải tiến hành ngay hô hấp nhân tạo.
**_(circulation): tuần hoàn_**
Kiểm tra mạch ngoại vi ở cổ tay, nếp bẹn, cổ. Kiểm tra phát hiện có ngừng tim hay không (ép tai vào lồng ngực để nghe nhịp tim). Nếu có ngừng tim: tiến hành ép tim ngoài lồng ngực
**_(Disability): thần kinh._**
Cần đánh giá nhanh nạn nhân ở các mức độ nặng dần như sau: tỉnh, đáp ứng bằng lời khi hỏi, đáp ứng bằng kích thích đau (áp dụng khi hỏi mà không thấy trả lời), không đáp ứng bằng hỏi hoặc kích thích đau: nạn nhân hôn mê sâu 
**_(eposure): bộc lộ_**
Bộc lộ, kiểm tra tổn thương, kiểm tra tổn thương toàn thân khác để xử trí. Đặc biệt kiểm tra tình trạng gãy xương và chấn thương sọ não hay gặp ở bệnh nhân bỏng điện cao thế do hay kèm theo ngã
**Bước 3:** Hà hơi thổi ngạt- ép tim ngoài lồng ngực khi nạn nhân ngừng thở ngừng tim: làm ngay, không được vận chuyển. **Gồm các động tác thứ tự sau** :
_V**ỗ mạnh 3 - 5 cái vùng ngực.**_
**_Đặt_**** _nạn nhân_**** _lên nền cứng_** _(_ ván cứng, mặt đất), nới lỏng quần áo và các thứ chằng buộc làm cản trở hô hấp. Để nạn nhân nằm ngửa, cổ ngửa và nghiêng đầu sang 1 bên trên nền cứng, lau sạch đờm dãi và dị vật đường thở nếu có.
Tiến hành ép tim ngoài lồng ngực và hô hấp nhân tạo bằng thổi ngạt miệng - miệng hay miệng - mũi cho đến khi nào tim đập lại người bệnh tự thở được mới chuyển đến cơ sở điều trị.
**Bước 4:** chuyển tới bệnh viện gần nhất khi nạn nhân đã thở và tim đập trở lại. Trên đường vận chuyển tiếp tục hồi sức.
**Xử trí vết bỏng** chỉ tiến hành sau khi nạn nhân tim đập, thở trở lại. Có thể dùng khăn mặt, khăn tay, vải màn... sạch để phủ lên. Băng bảo vệ vết bỏng bằng băng sạch. Với bỏng mặt, bỏng sinh dục: chỉ cần phủ một lớp gạc. 
**Tại cơ sở điều trị**
Khám và phân loại người bệnh, chú ý khám kỹ cả toàn thân và tại chỗ.
Điều trị sốc bỏng (nếu có).
Phát hiện và điều trị chấn thương phối hợp (sọ não, bụng kín, ngực kín, gãy xương chi thể, xương chậu…) nên cần khám xét kỹ, tránh bỏ sót.
Khám tại chỗ xác định điểm vào và điểm ra của dòng điện; trên đường đi của dòng điện thường có hoại tử dưới da như cân, cơ, xương đặc biệt mạch máu, thần kinh.
Tổn thương tại chỗ tại điểm vào, điểm ra của bỏng điện ban đầu thường không tương ứng và không phản ánh đầy đủ tổn thương thật sự do dòng điện gây ra, do đó cần tiên lượng chính xác tổn thương. 
Hoại tử bỏng thường sâu đến cân, cơ, mạch máu, thần kinh và dễ gây chèn ép khoang dẫn đến thiếu máu ngoại vi thứ phát. Do đó, nếu có hoại tử sâu, đặc biệt kín chu vi chi thể thì cần rạch hoại tử sớm để giải phóng chèn ép.
Bỏng điện dễ gây chảy máu thứ phát nên cần phải để garô chờ, nếu mạch máu dứt hoặc hoại tử thì khâu buộc thắt để cầm máu.
Tiến hành cắt lọc hoại tử càng sớm càng tốt, vết thương cần để hở, không khâu kín tránh hoại thư sinh hơi.
Các chi thể hoại tử nếu không có khả năng bảo tồn phải cắt cụt hay tháo khớp sớm tránh biến chứng suy thận cấp hay ngộ độc do hoại tử bỏng sâu.
Dùng các thuốc trợ tim mạch, hô hấp, lợi tiểu (khi đã bổ sung đủ dịch) và kháng sinh dự phòng, điều trị nhiễm khuẩn. Tiêm SAT dự phòng uốn ván sớm. Hạn chế sử dụng các thuốc gây độc cho thận.
Thay băng hàng ngày, chuyển vạt da che phủ khuyết hổng hay ghép da sau khi có mô hạt vùng bỏng sâu.
Phục hồi chức năng sớm ngay trong giai đoạn điều trị bỏng.
**THEO DÕI VÀ XỬ TRÍ TAI BIẾN, BIẾN CHỨNG**
**Toàn thân**
Ngừng thở, ngừng tim (sốc điện) đột ngột, tái phát: Hồi sinh tổng hợp. Ép tim ngoài lồng ngực, tiêm adrenalin buồng tim, bóp bóng hỗ trợ hô hấp, đặt nội khí quản thở máy.
Suy thận cấp: (do tan máu, tiêu cơ…): bù dịch thể, dịch kiềm bicacbonat, chạy thận nhân tạo, thẩm phân và lọc máu, lợi tiểu, cắt bỏ hoại tử sớm. 
Nhiễm khuẩn huyết: dự phòng hiệu quả nhất là loại bỏ hoại tử bỏng, kết hợp liệu pháp tổng hợp: tăng nuôi dưỡng, miễn dịch, kháng sinh…
Theo dõi diễn biến của các chấn thương, tổn thương kết hợp nếu có
**Tại chỗ**
Tổn thương bỏng sâu chèn ép gây hội chứng khoang: rạch hoại tử giải phóng chèn ép.
Chảy máu thứ phát: Cần phải để garô chờ, cắt bỏ hoại tử sớm. Nếu mạch máu đứt: cầm máu, thắt mạch.
Hoại tử thứ phát do tổn thương tiếp tục tiến triển làm lộ gân, cơ, xơng, khớp, mạch máu, thần kinh, nội tạng (do tiếp tục tổn thương bởi dòng điện, do chảy máu hoại tử thứ phát mạch máu..): tranh thủ che phủ sớm khi có điều kiện (ghép da, dùng vạt, nối vi phẫu…)
Nhiễm khuẩn; hoại thư sinh hơi: rạch rộng, rửa oxy già, cắt bỏ hoại tử, dùng kháng sinh tại chỗ và toàn thân.
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh

## ️ Dị vật đường thở và cách xử trí

Dị vật đường thở là một tai nạn sinh hoạt có thể xảy ra ở mọi lứa tuổi, đặc biệt ở trẻ từ 1-6 tuổi và có nhiều trường hợp dẫn tới hậu quả rất đau lòng.
Dị vật đường thở ở trẻ nhỏ thường do trẻ tò mò, thích nhét các vật lạ vào miệng hoặc mũi mà hay gặp là hạt lạc, hạt ngô, hạt dưa, hạt na, hạt hồng bì, mẩu xương, vỏ tôm, vỏ cua, đốt xương cá, mảnh đồ nhựa, kim, cặp tóc... Và vì phản xạ đóng, mở thanh quản để bảo vệ đường thở chưa hoàn thiện nên những dị vật này rất dễ mắc vào thanh quản, khí quản hoặc phế quản của trẻ, gây khó thở, rất nguy hiểm với tính mạng.
Dị vật đường thở thường có 3 hướng diễn biến: Tự khỏi. Diễn biến đến viêm phổi thùy do dị vật và thường phải cắt thùy phổi. Gây suy hô hấp cấp tính dẫn đến tử vong.
Hình ảnh dị vật trong đường thở của một người bệnh
Với dị vật đường thở, tùy từng trường hợp mà có cách xử trí hợp lý để sơ cấp cứu, trong đó có **nghiệm pháp Heimlich** thường đạt hiệu quả cao:
Mục đích: Là thủ thuật dùng tay người cứu hộ gây một áp lực mạnh trong đường dẫn khí để đẩy một dị vật gây tắc khí quản ra khỏi đường hô hấp trên; dị vật gây tắc khí quản thường xảy ra đang lúc ăn, sau khi ăn no hoặc say rượu, sặc bột ở trẻ em.
Chỉ định: Sặc bột hoặc dị vật. Ngạt thở do một mảnh thức ăn lấp thanh quản, khí quản. Đặc biệt chú ý tới người bệnh yếu mới khỏi bệnh chưa tự ăn được.
Chống chỉ định: Không có
Các bước tiến hành:
* Người bệnh đứng, hơi ngả đầu ra phía trước
- Phương pháp 1: Thầy thuốc đứng sau người bệnh, vòng tay ra phía trưóc (vùng thượng vị) của người bệnh, bàn tay phải nắm lại và bàn tay trái cầm lấy nắm tay phải áp sát vào vùng thượng vị, giật mạnh vòng tay về phía cơ hoành từ dưới lên trên. Có thể làm lại thủ thuật nhiều lần.
- Phương pháp 2: Một tay vòng ra phía trước đỡ người bệnh, một tay đập mạnh vào lưng (vùng giữa hai xương bả) nhiều lần.
* Người bệnh ngồi trên ghế
- Phương pháp 1: Người cứu hộ đứng phía sau lưng ghế, vòng hai tay ra phía trước rồi thực hiện như trên.
- Phương pháp 2: Đấm lưng như trong tư thế người bệnh nằm.
* Người bệnh nằm ngửa: Để đầu người bệnh nghiêng về một bên, áp một tay vào vùng thượng vị, bàn tay kia đặt bắt chéo trên bàn tay dưới rồi đẩy mạnh từ bụng lên phía ngực.
* Người bệnh nằm sấp: Dùng hai bàn tay ấn mạnh (hoặc nắm tay đấm mạnh) vào vùng liên bả nhiều lần. Trẻ em về nguyên tắc cũng làm như vậy: Trẻ sơ sinh nhấc hai chân dưói lên rồi lấy bàn tay vỗ vào lưng. Trẻ nhỏ: Người lớn quỳ chân đặt úp em bé vào đùi rồi đập cườm tay vào lưng.
## Theo dõi và xử trí tai biến
Khi người bệnh thở lại, chuyển ngay người bệnh đến bệnh viện để tiếp tục hút đờm dãi, soi đường thở (thanh quản, khí quản, phế quản) để lấy dị vật nhỏ khác còn lại.
Thở oxy mũi.
Đặt ống nội khí quản tiếp (nếu cần).
**Người bệnh không thở lại, hoặc thở yếu, vẫn tím: Thổi ngạt.**
**Người bệnh ngừng tuần hoàn: Bóp tim ngoài lồng ngực và thổi ngạt.**
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh

## ️ Chẩn đoán và xử trí phản vệ theo thông tư số 51/2017/TT-BYT

**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh

## ️ Sốc nhiệt điều trị như thế nào?

  * [Phân loại, yếu tố nguy cơ và dịch tễ học](https://bvnguyentriphuong.com.vn/cap-cuu/soc-nhiet-dieu-tri-nhu-the-nao#phn-loi-yu-t-nguy-c-v-dch-t-hc)
  * [Điều trị sốc nhiệt](https://bvnguyentriphuong.com.vn/cap-cuu/soc-nhiet-dieu-tri-nhu-the-nao#iu-tr-sc-nhit)


## Phân loại, yếu tố nguy cơ và dịch tễ học
Tùy thuộc vào nguyên nhân của nó, sốc nhiệt có thể được phân loại thành cổ điển (thụ động) hoặc gắng sức. Cả hai loại đều xuất phát từ sự thất bại trong việc làm giảm nhiệt độ cơ thể quá mức, nhưng các cơ chế nền tảng của chúng là khác nhau. Sốc nhiệt cổ điển là do tiếp xúc với nhiệt môi trường và cơ chế tản nhiệt kém, trong khi sốc nhiệt do gắng sức có liên quan đến hoạt động thể chất và kết quả của nó khi sản xuất quá mức nhiệt do chuyển hóa áp đảo cơ chế làm mất nhiệt theo sinh lý (Bảng 1-2).
Bảng 1. Đặc điểm dịch tễ học và lâm sàng của Sốc nhiệt cổ điển và gắng sức.  
---  
Đặc điểm | Sốc nhiệt cổ điện | Sốc nhiệt gắng sức  
Nhóm tuổi | Trước dậy thì, người cao tuổi | Sau dậy thì và năng động  
Tần suất xảy ra | Dịch tễ (đợt nóng) | Lẻ tẻ (bất kỳ thời điểm nào trong năm)  
Hoạt động đồng thời | Ít vận động | Nặng nhọc  
Tình trạng sức khỏe | Bệnh mạn tính | Nhìn chung là khỏe  
Thuốc | Thường được sử dụng (thuốc theo toa) | Thông thường không được sử dụng (đôi khi hỗ trợ thuốc tăng hiệu suất, bất hợp pháp)  
Cơ chế | Hấp thụ nhiệt môi trường và tản nhiệt kém | Sản xuất nhiệt quá mức, áp đảo các cơ chế làm mất nhiệt  
Đổ mồ hôi | Có thể không (da khô) | Thường có (da ẩm ướt)  
Rối loạn chức năng thần kinh trung ương | Thường gặp | Thường gặp  
Rối loạn acid-base | Nhiễm kiềm hô hấp | Nhiễm toan chuyển hóa  
Tiêu cơ vân | Không thường gặp | Thường xuyên  
Rối loạn chức năng gan |  | Rõ rệt đến nặng  
Suy thận | Không thường gặp (<5%) | Thường gặp (25−30%)  
|  | Rõ rệt đến nặng  
ARDS | Thường gặp | Thường gặp  
Creatine kinase | Tăng nhẹ | Tăng cao rõ rệt  
Calci | Bình thường | Thấp (hạ calci máu)  
Kali | Bình thường | Thường cao (tăng kali máu)  
Bảng 2. Các yếu tố nguy cơ tiềm ẩn của sốc nhiệt.*  
---  
Loại sốc nhiệt và yếu tố nguy cơ | Giải thích  
Sốc nhiệt Cổ điển  
Thời tiết | Đợt nóng, với những ngày và đêm nóng liên tiếp.  
Yếu tố sinh lý | Suy tim làm cản trở điều chỉnh tim mạch bình thường đối với stress nhiệt: không thể duy trì thể tích nhát bóp có thể chấp nhận khi bị nóng, giãn mạch ngoại biên không đầy đủ do thay đổi cấu trúc và suy giảm cơ chế giãn mạch qua trung gian nitric oxide, giảm mật độ mao mạch và giảm chất lượng của vi tuần hoàn da, giảm tốc độ tiết mồ hôi và giảm lượng mồ hôi để đáp ứng với stress nhiệt.  
Yếu tố xã hội | Cách ly xã hội, không gian sống không có máy điều hòa và không thông thoáng, mất khả năng tự chăm sóc bản thân, nằm bất động trên giường.  
Bệnh lý nền | Đợt cấp các bệnh tâm thần, tim mạch, mạch máu não và phổi và bệnh đa xơ cứng do tiếp xúc với stress nhiệt.  
Thuốc | Thuốc chẹn beta, thuốc lợi tiểu, thuốc chẹn kênh calci, thuốc nhuận tràng, thuốc kháng cholinergic, salicylate, thuốc đồng vận tuyến giáp, benztropine, trifluoperazine, butyrophenone, đồng vận alpha, chất ức chế monoamine oxidase, thuốc kích thích giao cảm, thuốc chống trầm cảm ba vòng, SSRI.  
Sốc nhiệt do Gắng sức  
Yếu tố xã hội | Nỗ lực quá mức, áp lực từ đồng nghiệp và huấn luyện viên.  
Yếu tố khả năng | Thể lực thấp (nỗ lực thể chất không phù hợp với thể lực; “tập luyện kiểu tự sát”), thích nghi (thích ứng) kém với nhiệt, hiệu quả làm việc thấp, thừa cân (giảm tỷ lệ diện tích da trên khối lượng và khả năng lưu trữ nhiệt cao hơn trong lớp mỡ), quần áo bảo hộ (giảm hiệu quả của mồ hôi).  
Yếu tố mắc phải | Nhiễm virus hoặc vi khuẩn (ngay cả khi dưới lâm sàng), mất nước, thiếu ngủ, rối loạn chức năng tuyến mồ hôi (ví dụ, bỏng sâu, sẹo trên da >40% tổng diện tích bề mặt cơ thể).  
Yếu tố bẩm sinh | Giảm tiết mồ hôi vô căn mạn tính hoặc gia đình, loạn sản ngoại bì.  
Lạm dụng ma túy | Amphetamine và giống amphetamine (ví dụ, ephedra), MDMA, cocaine, PCP và LSD, các chất kích thích tổng hợp thuộc nhóm cathinone (ví dụ: α-PHP), rượu.  
## Điều trị sốc nhiệt
Bảng 3. Hướng dẫn điều trị sốc nhiệt.*  
---  
Điều trị | Bàn luận  
Điều trị tại hiện trường  
| Thực hiện theo giao thức ACLS; cho oxy ở tốc độ 4 lít/phút để tăng độ bão hòa oxy lên >90%.  
Nhiệt độ lõi cơ thể | Theo dõi nhiệt độ trực tràng và thực hiện làm mát trong trường hợp tăng thân nhiệt; đối với sốc nhiệt do gắng sức thì ngâm nước lạnh; đối với sốc nhiệt cổ điển thì làm mát dẫn truyền hoặc bay hơi.  
Dịch truyền | Truyền dung dịch muối đẳng trương IV (1−2 lít/giờ); mất nước không phải là vấn đề chính.  
Thuốc động kinh | Cho benzodiazepine IV (5 mg) cho đến khi hết cơn co giật (không quá 20 mg).  
Chuyển đến bệnh viện | Đối với sốc nhiệt cổ điển, vận chuyển ngay lập tức đến ED; đối với sốc nhiệt do gắng sức, vận chuyển đến ED sau khi làm mát nhiệt độ cơ thể xuống <39.0°C.  
Điều trị trong ED  
Nhiệt độ lõi cơ thể | Theo dõi nhiệt độ trực tràng hoặc bàng quang và thực hiện làm mát cho đến khi nhiệt độ lõi <38.0°C; sử dụng bộ đồ mặc làm mát hoặc dịch lạnh (4°C, 1000 mL/30 phút) truyền qua đường trung tâm; thuốc hạ sốt gây hại hại và nên tránh; dantrolene chưa được chứng minh là có hiệu quả.  
Thuốc động kinh | Cho benzodiazepine IV (5 mg, lặp lại) hoặc phenytoin IV (liều tải, 15-20 mg/kg trong 15 phút) cho đến khi cắt cơn co giật.  
Xét nghiệm | Thực hiện CBC, phân tích nước tiểu, cấy máu, xét nghiệm chức năng thận và chức năng gan (ALT, AST, ammonia, INR); xét nghiệm glucose, điện giải, khí máu động mạch và cân bằng acid-base, chức năng đông máu, CK, LDH, myoglobin, CRP.  
Theo dõi tuần hoàn | Đối với suy tuần hoàn, truyền dịch (30 mL/kg), theo dõi CVP hoặc thực hiện theo dõi huyết động xâm lấn, duy trì huyết áp động mạch trung bình ở mức >65 mm Hg (hoặc> 75 mm Hg nếu bệnh nhân cao tuổi hoặc tăng huyết áp), tất cả đều có mục tiêu là nồng độ lactate bình thường và lượng nước tiểu >50 mL/kg/giờ; xem xét thuốc vận mạch khi thất bại với dịch truyền.  
Điều trị trong ICU  
Các biện pháp chung |  Thực hiện CPR theo giao thức ACLS; ECMO có thể được sử dụng khi cần Theo dõi nhiệt độ trực tràng, bàng quang hoặc máu; tiếp tục làm mát để duy trì nhiệt độ lõi ở <38.0°C bằng cách truyền dịch lạnh (4°C, 1000 mL/30 phút) qua đường trung tâm hoặc sử dụng làm mát máu ngoài cơ thể cho tăng thân nhiệt kháng trị; thuốc hạ sốt gây hại và nên tránh; dantrolene chưa được chứng minh là có hiệu quả. Thực hiện các xét nghiệm: CBC, glucose, khí máu động mạch và cân bằng acid-base, chức năng đông máu, CK, LDH, chức năng gan (ALT, AST, ammonia, INR), myoglobin, chức năng thận, phân tích nước tiểu, CRP, cấy máu; lặp lại mỗi 12 giờ trong 48 giờ đầu tiên, sau đó mỗi 24 giờ.  
Suy tim | Thực hiện CPR theo giao thức ACLS; thực hiện theo dõi huyết động xâm lấn và siêu âm tim; đối với suy đa cơ quan nhẹ, sử dụng dobutamine IV (1 μg/kg/phút, sau đó 2-20 μg/kg/phút khi cần) hoặc milrinone IV (liều tải, 50 μg/kg trong 10 phút, sau đó 0.2-0.75 μg/kg/phút) hoặc adrenaline IV (1 μg/phút); đối với suy đa cơ quan nặng, ECMO có thể được sử dụng khi cần.  
Tổn thương thận cấp | Truyền dịch tinh thể để duy trì lượng nước tiểu >50 mL/kg/giờ; cho furosemide IV (10-20 mg ở bệnh nhân chưa dùng thuốc lợi tiểu trước đó; liều tiếp theo phụ thuộc vào lượng nước tiểu); chạy thận nhân tạo hoặc CVVH trong trường hợp quá tải thể tích, nhiễm toan nặng, tăng kali máu hoặc urea máu; điều chỉnh tốc độ truyền dịch theo huyết áp và lượng nước tiểu; theo dõi điện giải và điều chỉnh khi cần.  
Bệnh não và phù não | Khi GCS <8 điểm† , đặt nội khí quản và thở máy; cho tăng thông khí nhẹ (PCO2 34-36 mm Hg), dùng dung dịch muối ưu trương 3% IV (liều khởi đầu, 100 mL/30 phút, sau đó theo tổng lượng nước cơ thể của bệnh nhân để tăng mức natri 12 mmol/ngày) hoặc mannitol 20% IV (0.25-2 g/kg trong 30 phút); giữ đầu cao 45 độ, dùng thuốc an thần; bệnh nhân bị tăng ammoniac máu cần điều trị lọc máu hoặc MARS; tình trạng cải thiện với làm mát; xem xét theo dõi ICP.  
Tiêu cơ vân | Truyền dịch IV, 1-2 lít/giờ (điều trị tích cực trong giờ đầu tiên), sau đó 300 mL/giờ; furosemide IV (10-20 mg ở bệnh nhân không dùng lợi tiểu trước đó; liều sau đó phụ thuộc vào lượng nước tiểu) trong trường hợp quá tải dịch; natri bicarbonate, 30 mmol/giờ (để đạt được pH nước tiểu >6.5); dự kiến xuất hiện myoglobin niệu; tăng calci máu và nhiễm kiềm chuyển hóa (pH >7.5).  
DIC và các bất thường đông máu khác | Đối với chảy máu và huyết khối, dùng huyết tương tươi đông lạnh (liều bolus, 10-15 mL/kg, sau đó 200-400 mL theo chỉ số đông máu); truyền tủa lạnh (5-10 U mỗi lần) nếu mức fibrinogen <180 mg/dL; truyền tiểu cầu đậm đặc (truyền một liều điều trị) nếu số lượng tiểu cầu <20 trên mm3 hoặc nếu có chảy máu và số lượng tiểu cầu <50 trên mm3 ; ở những bệnh nhân bị suy gan, xem xét PCC để đạt được mục tiêu INR ≤1.5; tiêm liều PCC theo chỉ số INR và cân nặng của bệnh nhân; tránh heparin; cảnh giác với hạ thân nhiệt và nhiễm toan chuyển hóa.  
ARDS | Thực hiện đặt nội khí quản và thở máy; tránh quá tải dịch.  
Suy gan | Theo dõi chức năng gan và tri giác trong ít nhất 4 ngày; điều trị hỗ trợ: ổn định huyết động, N-acetylcystein IV (liều bolus, 150 mg/kg trong 200 mL dung dịch glucose 5% trong 20 phút, sau đó 50 mg/kg trong 500 mL dung dịch glucose 5% trong 4 giờ, sau đó 100 mg/kg trong 1000 mL dung dịch glucose 5% trong 16 giờ); truyền nước muối ưu trương 3% IV hoặc mannitol IV (0.25-2 g/kg dung dịch 20% trong 30 phút), lọc máu, thuốc nhuận tràng (ví dụ, lactulose uống, 30 mL mỗi 2 giờ cho đến khi tiêu chảy xảy ra), rifaximin uống (400 mg 3 lần một ngày) trong trường hợp suy gan tối cấp; hiếm khi cần ghép gan, và không có bằng chứng cho thấy ghép gan có hiệu quả.  
Thay đổi điện tâm đồ | Theo dõi liên tục các rối loạn nhịp tim có thể; Thay đổi điện tâm đồ là không đặc hiệu.  
SIRS | Điều trị tương tự như nhiễm khuẩn huyết; xem xét kháng sinh.  
## Kết luận
**Sốc nhiệt là một tình trạng đe dọa tính mạng nếu không được nhận ra kịp thời và điều trị hiệu quả**. Một số biện pháp phòng ngừa đơn giản, chẳng hạn như tránh hoạt động nặng nhọc trong môi trường nóng và giảm tiếp xúc với stress nhiệt, cũng như thay đổi thái độ trong thể thao và giải quyết các vấn đề kinh tế xã hội làm tăng nguy cơ, những biện pháp này có thể làm giảm tỷ lệ mắc sốc nhiệt cổ điển và gắng sức. Hiểu biết của chúng tôi về sinh lý bệnh của sốc nhiệt và tiếp cận điều trị dựa trên cơ chế vẫn chưa đầy đủ. Nghiên cứu trong tương lai có khả năng tập trung vào ba lĩnh vực: xác định các đặc tính di truyền có thể làm giảm khả năng đối phó với stress nhiệt của một người, tìm kiếm các dấu ấn sinh học mới có thể dự đoán tốt hơn các kết cục ngắn hạn và dài hạn của sốc nhiệt và phát triển các điều trị bổ trợ mới có thể kiểm soát hiệu quả phản ứng viêm và chống lại các biến chứng đa cơ quan.
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [Phân loại, yếu tố nguy cơ và dịch tễ học](https://bvnguyentriphuong.com.vn/cap-cuu/soc-nhiet-dieu-tri-nhu-the-nao#phn-loi-yu-t-nguy-c-v-dch-t-hc)
  * [Điều trị sốc nhiệt](https://bvnguyentriphuong.com.vn/cap-cuu/soc-nhiet-dieu-tri-nhu-the-nao#iu-tr-sc-nhit)



## ️ Hướng đẫn chẩn đoán và xử trí khi bị ong đốt

Nọc ong có khoảng 40 thành phần bao gồm các enzyme như phospholipase A2, hyaluronidase, cholinesterase, serotonin, catecholamin, peptid, melitin, các peptit hủy tế bào mast, apamin, các amin có hoạt tính sinh học. 
Melittin: chiếm 50% trọng lượng của nọc khô, làm tổn thương màng tế bào do có tác dụng như một chất tẩy.
Apamin: độc tố thần kinh tác động chủ yếu lên tủy sống; phospholipase A2 có tác dụng làm vỡ hồng cầu, hyaluronidase có tác dụng hủy acid hyaluronic của tổ chức liên kết làm nọc ong lan nhanh. 
Đa số các thành phần của nọc ong có trọng lƣợng phân tử thấp (từ 1,2 – 170 kd) nên có thể lọc đƣợc qua màng lọc của phương pháp lọc máu tĩnh mạch – tĩnh mạch liên tục. 
Liều độc: phụ thuộc rất nhiều vào loại ong và số vết đốt. 
Mức độ nặng phụ thuộc vào loại ong, số nốt đốt và vị trí đốt. Ở người lớn bị ong vò vẽ đốt từ trên 30 vết đốt trở lên là nặng, trẻ em bị từ trên 10 nốt đốt là nặng.
Tử vong do ong đốt chiếm từ 40-100 ngƣời/ năm tại Mỹ nhưng con số thực tế cao hơn. Tử vong có thể xảy ra rất sớm trong vòng giờ đầu do sốc phản vệ (chiếm từ 3-8% ngƣời bị ong đốt) và tử vong muộn trong những ngày sau do độc tố của nọc ong. 
**Không có thuốc điều trị đặc hiệu, chủ yếu là điều trị triệu chứng**
- Tại vết đốt: chườm lạnh, giảm đau bằng kem kháng histamin (VD kem Phenergan) 2-3 lần/ngày.
- Giảm phù nề: prednisolon 40-60 mg uống một lần hoặc methylprednisolon 40mg tiêm tĩnh mạch 1-2 lần/ngày, có thể giảm liều dần theo nguyên tắc ”vuốt đuôi” trong 3-5 ngày.
**Nếu bị sốc phản vệ điều trị theo phác đồ xử trí sốc phản vệ:**
+ Quan trọng nhất là nhanh chóng tiêm bắp addrenalin ngƣời lớn 0,3- 0,5 mg, trẻ em: 0,01 mg/kg; nếu trẻ nặng > 50 kg thì liều tối đa 1 lần 0,5 mg, nhắc lại sau 5 -15 phút nếu cần. Nếu tiêm bắp 3 lần mà HA vẫn thấp thì pha truyền với liều từ 0,1-1 mcg/kg/phút. chỉnh liều để đạt HA mong muốn.
+ Cho thở oxy 8-10l/ph, nếu suy hô hấp cần dặt nội khí quản, thở máy
+ Đặt bệnh nhân nằm thẳng đầu thấp
+ Truyền dịch: natriclorua 0,9% nhanh 20 ml/kg trong, đánh giá lại, truyền lại khi cần
+ Abuterol: khí dung khi co thắt phế quản liều 0,15 mg/kg (tối thiểu 2,5 mg) pha vào 3 ml nƣớc muối, khí dung nhắc lại khi cần
+ Kháng H1: Dimedrol ống 10 mg (diphenylhydramin): 1 mg/kg TB hoặc TM (tối đa 40 mg).
+ Kháng H2: Ranitidin 50 mg TM (hoặc famotidin 20mg TM)
+ Solumedrol 1 mg/kg (tối đa 125 mg).
**Phòng suy thận cấp:**
**- Bài niệu tích cực** là 1 trong những biện pháp điều trị ong đốt cơ bản và hiệu quả 
Nhẹ: Cho bệnh nhân uống nhiều nƣớc, 2000-3000ml nƣớc/24 giờ, ngay sau khi bị ong đốt nếu bệnh nhân còn tỉnh táo, nên dùng dung dịch ORESOL.
Nặng: có tụt huyết áp, hoặc bị > 10 nốt đốt: Tăng cường thải độc bằng phương pháp bài niệu tích cực (xem bài chẩn đoán và xử trí chung với ngộ độc cấp).
**- Lọc máu** : Nếu bài niệu tích cực, lợi tiểu không kết quả, suy thận, cho chạy thận nhân tạo ngắt quãng.
Ngừời lớn nếu bị ong vò vẽ đốt > 50 nốt, hoặc trẻ em bị đốt > 30 nốt và có biểu hiện ngộ độc nọc ong, chỉ định lọc máu liên tục CVVH máu càng sớm càng tốt để loại bỏ nọc ong tránh đƣợc vòng xoắn bệnh lý. Khi có tan máu, vàng da, suy gan, suy thận, rối loạn đông máu xét chỉ định thay huyết tương và lọc máu liên tục.
- Rối loạn đông máu, thiếu máu, giảm tiểu cầu: truyền huyết tương tươi đông lạnh, hồng cầu khối, tiểu cầu theo tình trạng người bệnh
- Suy hô hấp: do phù phổi cấp, chảy máu phổi: thở ôxy liều cao, thở máy không xâm nhập CPAP+PS, hoặc đặt nội khí quản, thở máy có PEEP. 
- Tiêm phòng uốn ván nếu vùng ong đốt bị nhiễm bẩn (SAT 2000 đv tiêm dưới da).
- Lấy ngòi ong ra khỏi da bệnh nhân: nếu ong mật đốt, lấy sớm sau khi bị đốt.
- Dị ứng nhẹ (mày đay): uống hoặc tiêm kháng histamin, corticoid.
**Chú ý:** Khi bị nhiều nốt đốt gây tình trạng tụt huyết áp nên tiêm bắp ngay adrenalin 0,3-0,5 ml dung dịch 1/1000 (vì rất khó phân biệt được là do sốc phản vệ hay độc tố toàn thân), kết hợp kháng histamine (Dimedrol ống 10 mg) 1- 5 ống.
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh

## ️ Tiếp cận bệnh nhân tai biến mạch máu não

**Định nghĩa: TBMMN là khi:**
- Đột ngột xuất hiện các dấu hiệu thần kinh khu trú ( tổn thương chức năng thần kinh)
- Các dấu hiệu TKKT tồn tại >24 giờ hoặc BN tử vong trong vòng 24h ( Để loại trừ thiếu mãu não thoáng qua)
- Không có yếu tố chấn thương.
Định hướng nguyên nhân,định khu tổn thương rất quan trọng vì nó giúp chỉ định CLS cần thiết và chính xác, cũng như hướng điều trị ban đầu cho BN
Khám BN vào viện vì dấu hiệu thần kinh khu trú: Yếu nửa người, méo miệng, nói ngọng, co giật,…
**1. Khám toàn trạng.**
Lưu ý: ý thức của BN, HC thiếu máu, HC xuất huyết dưới da.
**2. Khám thần kinh:**
2.1. Ý thức: Theo thang điểm Glasgow
2.2. Khám vận động:
- Làm nghiệm pháp Barre chi trên, gọng kìm, Mingazzini chi dưới để phát hiện dấu hiệu liệt kín đáo cũng như đánh giá sơ bộ cơ lực.
- Khám cơ lực: đánh giá cơ lực từng bên và so sánh gốc chi và ngọn chi, bên phải và bên trái( lưu ý hỏi bên thuận của BN để tránh đánh giá nhầm cơ lực), chi trên và chi dưới.
- Khám trương lực cơ: bao gồm độ ve vẩy, độ gấp duỗi và độ cứng chắc
- Khám phản xạ gân xương: gồm phản xạ cơ nhị đầu, cơ tam đầu, phản xạ gân bánh chè và phản xạ gân gót. Cần đánh giá tăng hay giảm PXGX, nếu tăng thì tăng ở mức độ nào: nhạy, đa động, lan tỏa hay rung giật.
- Khám phản xạ da niêm mạc: phản xạ da bụng.
- Khám các phản xạ bệnh lý: Babinski và các dấu hiệu tương đương( 5 dấu hiệu), Hoffman.
Sau khi khám vận động xong có thể kết luận: BN có liệt hay không? Liệt này là liệt cứng hay mềm, hoàn toàn hay không hoàn toàn, toàn bộ hay không toàn bộ, đồng đều hay không đồng đều? Có dấu hiệu tổn thương bó tháp?
2.4.Khám 12 đôi dây TK sọ.
2.5.Khám HC màng não, HC tăng áp lực nội sọ
2.6. Khám HC tiền đình- tiểu não
2.7. Khám cảm giác.
+ Cảm giác chủ quan
+ Cảm giác khách quan
-Khám cảm giác nông: cảm giác xúc giác thô sơ, cảm giác đau, nhiệt.
- Khám cảm giác sâu: cảm giác rung, cảm giác bản thể.
-Khám cảm giác phối hợp.
Sau khi khám cần kết luận BN có rối loạn cảm giác không, vị trí thế nào, RL cảm giác loại nào.
2.8. Khám dinh dưỡng và cơ tròn: xem BN có teo cơ, loét, phù hay không? Xem BN có rối loạn cơ tròn không?
2.9. Hộp sọ và cột sống: Tầm soát yếu tố chấn thương ở BN.
**3. Khám cơ quan khác:**
Đặc biệt chú ý Tim mạch: Nhịp tim có đều, có tiếng thổi bệnh lý( Rung nhĩ và bệnh van tim là nguy cơ của huyết khối, gây nhồi máu não)
**4. Định hướng chẩn đoán và chẩn đoán phân biệt:**
- Nghĩ đến TB MMN nếu bệnh diễn biến đột ngột( BN nhớ chính xác lúc ấy khoảng mấy giờ, BN đang làm gì, hoàn cảnh xung quanh thế nào), bệnh nền có THA, ĐTĐ, RL lipid máu, thể trạng béo phì,…
- Các nguyên nhân khác: áp xe não, u não,.. sẽ có diễn biến từ từ hơn.
- Cần chẩn đoán phân biệt với: Hạ đường huyết, Rối loạn điện giải.
**5. Chẩn đoán thể TBMMN và định khu tổn thương.**
- TBMMN có hai thể là nhồi máu não và xuất huyết não.
- Xuất huyết não:
+ Thời gian khởi phát đến khi triệu chứng đạt đỉnh từ vài phút đến vài giờ.
+ Có thể có tam chứng xuất huyết: Đau đầu, nôn hoặc buồn nôn, rối loạn ý thức.
+ Có thể có HC màng não( XH dưới nhện, Chảy máu vào não thất)
+ Cơn THA ác tính( HA lúc khởi phát triệu chứng >220/110mmHg
+ Có yếu tố ưa chảy máu: giảm tiểu cầu, xơ gan, dùng thuốc chống đông,..
- Nhồi máu não:
+ Thời gian khởi phát đến khi triệu chứng đạt đỉnh từ vài giờ đến hàng ngày.
+ Không có tam chứng xuất huyết
+ Không HCMN
+ Có yếu tố tăng đông: Rung nhĩ, bệnh van tim,..
- Định khu tổn thương:
+ Bao trong: Liệt nửa người với các tính chất toàn bộ, đồng đều và thuần túy.( 3 có)
+ Vỏ não: Liệt nửa người với các tính chất không toàn bộ, không đồng đều và không thuần túy.( 3 không)
+ Thân não: Có HC giao bên( liệt nửa người một bên và liệt dây TK sọ bên đối diện.
+ Tủy cổ cao: có HC Brown Sequard( liệt nửa người, mất cảm giác sâu bên tổn thương và mất cảm giác nông bên đối diện)
Trong đó:
+ Liệt toàn bộ: Liệt cả tay, chân, mặt.
+ Liệt đồng đều: cơ lực đồng đều giữa gốc chi và ngọn chi, giữa tay chân và mặt.
+Liệt thuần túy: Chỉ có liệt vận động mà không có RLCG, liệt dây TK sọ khác( trừ dây VII), thất ngôn, động kinh,…
+Liệt hoàn toàn: cơ lực = 0
+ Liệt cứng: Trương lực cơ tăng, Liệt mềm: TLC giảm.
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh

## ️ Phân biệt giữa hạ đường huyết và hạ canxi máu

  * [Thế nào là tụt đường huyết?](https://bvnguyentriphuong.com.vn/cap-cuu/phan-biet-giua-ha-duong-huyet-va-ha-canxi-mau#th-no-l-tt-ng-huyt)
  * [Tụt canxi là gì?](https://bvnguyentriphuong.com.vn/cap-cuu/phan-biet-giua-ha-duong-huyet-va-ha-canxi-mau#tt-canxi-l-g)
  * [Phân biệt giữa hạ đường huyết và hạ canxi như thế nào?](https://bvnguyentriphuong.com.vn/cap-cuu/phan-biet-giua-ha-duong-huyet-va-ha-canxi-mau#phn-bit-gia-h-ng-huyt-v-h-canxi-nh-th-no)
  * [Triệu chứng hạ canxi là gì?](https://bvnguyentriphuong.com.vn/cap-cuu/phan-biet-giua-ha-duong-huyet-va-ha-canxi-mau#triu-chng-h-canxi-l-g)
  * [Triệu chứng hạ đường huyết](https://bvnguyentriphuong.com.vn/cap-cuu/phan-biet-giua-ha-duong-huyet-va-ha-canxi-mau#triu-chng-h-ng-huyt)
  * [Nên làm gì khi bị hạ đường huyết hoặc tụt canxi?](https://bvnguyentriphuong.com.vn/cap-cuu/phan-biet-giua-ha-duong-huyet-va-ha-canxi-mau#nn-lm-g-khi-b-h-ng-huyt-hoc-tt-canxi)
  * [Đối với tình trạng tụt canxi](https://bvnguyentriphuong.com.vn/cap-cuu/phan-biet-giua-ha-duong-huyet-va-ha-canxi-mau#i-vi-tnh-trng-tt-canxi)
  * [Đối với tình trạng hạ đường huyết](https://bvnguyentriphuong.com.vn/cap-cuu/phan-biet-giua-ha-duong-huyet-va-ha-canxi-mau#i-vi-tnh-trng-h-ng-huyt)


### Thế nào là tụt đường huyết?
Hạ đường huyết là một biến chứng xuất hiện phổ biến ở bệnh nhân tiểu đường. Đây là tình trạng mà lượng đường trong máu người bệnh bị hạ xuống mức thấp hơn bình thường. Tụt đường huyết được xem là nhẹ nếu chỉ số đường huyết ở mức từ 55 – 69 mg/dL.
Tuy nhiên, nếu đường huyết giảm xuống dưới 55 mg/dL, đây là tình trạng rất nghiêm trọng và có thể gây nên nhiều biến chứng nặng như co giật và hôn mê. Tụt đường huyết thường xảy ra khi hai hormone điều chỉnh đường huyết là insulin và glucagon thiếu cân bằng. “Thủ phạm” của vấn đề này có thể kể đến là:
  * Ăn kiêng quá đà, ăn trễ hoặc thường xuyên bỏ bữa
  * Bệnh nhân tiểu đường dùng quá nhiều insulin hoặc các thuốc tiểu đường khác
  * Tập thể dục quá mức
  * Uống nhiều bia rượu


### Tụt canxi là gì?
Hạ canxi xảy ra khi nồng độ canxi toàn phần trong huyết thanh hơn mức 8,8 mg/dL nhưng protein huyết tương vẫn bình thường, hoặc hàm lượng canxi ion hoá bão hoà trong máu ở dưới mức 4,7 mg/dL.
Nguyên nhân phổ biến dẫn đến tụt canxi máu là suy tuyến cận giáp, khiến lượng hormone tuyến cận giáp được tiết ra ít hơn lượng trung bình. Mức hormone tuyến cận giáp thấp sẽ khiến mức canxi trong cơ thể cũng xuống thấp.
Suy tuyến cận giáp còn có thể do di truyền, biến chứng sau phẫu thuật cắt bỏ tuyến giáp hoặc bệnh ung thư ở đầu và cổ. Ngoài ra còn có một vài nguyên nhân khác khiến bạn bị tụt canxi, chẳng hạn như:
  * Chế độ ăn uống không cung cấp đủ canxi hoặc vitamin D
  * Bị nhiễm trùng
  * Căng thẳng, lo lắng
  * Bị bệnh thận
  * Do ung thư đang lan rộng
  * Mức magie hoặc phosphate trong cơ thể không ổn định; truyền phosphat hoặc canxi từ ngoài vào
  * Bị tiêu chảy, táo bón hoặc một số bệnh rối loạn đường ruột khiến việc hấp thụ canxi của cơ thể bị hạn chế
  * Bệnh nhi có mẹ bị tiểu đường
  * Tác dụng phụ của một số thuốc như rifampin, phenytoin và phenobarbital
  * Vận động thể chất quá mức.


## Phân biệt giữa hạ đường huyết và hạ canxi như thế nào?
Vì hạ đường huyết và hạ canxi huyết khác nhau về bản chất nên có thể đo chỉ số đường huyết và chỉ số canxi huyết để biết người bệnh đang gặp phải tình trạng nào. Tuy nhiên, dựa vào triệu chứng vẫn hoàn toàn phân biệt giữa hạ đường huyết và hạ canxi. Trong đó, mỗi tình trạng sẽ bao gồm các dấu hiệu nhận biết như sau:
### Triệu chứng hạ canxi là gì?
Một số người sẽ không xuất hiện bất kỳ triệu chứng tụt canxi nào. Song, phần lớn người bị tình trạng này sẽ có các biểu hiện như sau:
  * Co thắt hoặc cứng cơ bắp
  * Hạ huyết áp
  * Mệt mỏi
  * Gặp vấn đề về trí nhớ
  * Tâm trạng thay đổi thất thường, dễ lo âu, khó chịu, bồn chồn
  * Khó nói, khó nuốt
  * Run tay chân
  * Có cảm giác châm chích ở đầu ngón tay, ngón chân hoặc dị cảm


Tụt canxi nặng có thể gây co giật, rối loạn nhịp tim, co thắt thanh quản, suy tim.
### Triệu chứng hạ đường huyết
Một số biểu hiện phổ biến của tụt đường huyết như:
  * Run rẩy, bồn chồn, lo lắng, hoặc hoang mang
  *   * Chóng mặt, đổ mồ hôi
  * Đau đầu
  * Buồn nôn và nôn mửa
  * Ngứa ran hoặc tê môi, lưỡi hoặc má
  * Tim đập nhanh
  * Dạ nhợt nhạt


Trong một số trường hợp nặng, hạ đường huyết sẽ có một số dấu hiệu như:
  * Lú lẫn hoặc xuất hiện các hành vi bất thường
  * Rối loạn thị giác như mờ mắt, nhìn đôi
  * Co giật
  * Mất ý thức
  * Ngất xỉu, hôn mê


Có thể thấy hạ đường huyết và tụt canxi khác nhau ở chỗ hạ đường huyết có biểu hiện đói, đổ mồ hôi, buồn nôn, nôn; chân tay sẽ run nhưng không co quắp. Trong trường hợp nặng, người bị hạ đường huyết có thể ngất xỉu, hôn mê; biểu hiện này không có ở người bị tụt canxi máu.
## Nên làm gì khi bị hạ đường huyết hoặc tụt canxi?
Qua những thông tin trên, có thể thấy rằng hạ đường huyết và hạ canxi có bản chất và nguyên nhân khác nhau. Vì vậy mà mỗi trường hợp sẽ có hướng xử lý khác nhau.
### Đối với tình trạng tụt canxi
Hạ canxi cần được điều trị bằng cách bổ sung canxi nhanh chóng. Nếu nhẹ, bệnh nhân được dùng canxi đường uống, còn nặng phải truyền dịch sau đó mới chuyển sang đường uống.
Bên cạnh đó, cần phải tìm ra nguyên nhân và điều trị để tránh tình trạng tụt canxi tái phát. Chẳng hạn như nếu bạn không bổ sung đủ canxi hoặc vitamin D thì điều chỉnh chế độ ăn uống là điều đầu tiên bạn cần làm. Nếu bạn dùng thuốc và dẫn đến tụt canxi, hãy báo với bác sĩ để được điều chỉnh liều lượng hoặc đổi sang một loại thuốc khác…
### Đối với tình trạng hạ đường huyết
Trong trường hợp chỉ số đường huyết dao động từ 55 – 69 mg/dL, người bệnh có thể áp dụng cách điều trị hạ đường huyết tại nhà theo quy tắc 15-15 như sau:
Bổ sung 15g carbs và kiểm tra lại lượng đường trong cơ thể sau 15 phút bằng một số món như:
  * 1 ly sữa
  * 1 nửa ly nước trái cây hoặc soda thông thường
  * 1 muỗng đường, mật ong hoặc siro
  * Kẹo cứng, kẹo dẻo hoặc kẹo cao su (cần xem kỹ lượng đường có chứa trong đó ở trên nhãn thực phẩm)
  * 2 – 3 viên glucose (cần đọc kỹ hướng dẫn sử dụng)


Nếu chỉ số vẫn thấp thì tiếp tục thực hiện cách này cho đến khi đạt trên 70 mg/dL. Sau khi đã ổn định lại lượng đường trong máu, người bệnh nên tiếp tục dùng thêm bữa ăn nhẹ hoặc bữa chính để đảm bảo tụt đường huyết không tái phát.
Đối với tình trạng tụt đường huyết nghiêm trọng (dưới 55 mg/dL), người bệnh cần được tiêm glucagon nếu có sẵn hoặc đưa đến bệnh viện để được chăm sóc y tế kịp thời.
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [Thế nào là tụt đường huyết?](https://bvnguyentriphuong.com.vn/cap-cuu/phan-biet-giua-ha-duong-huyet-va-ha-canxi-mau#th-no-l-tt-ng-huyt)
  * [Tụt canxi là gì?](https://bvnguyentriphuong.com.vn/cap-cuu/phan-biet-giua-ha-duong-huyet-va-ha-canxi-mau#tt-canxi-l-g)
  * [Phân biệt giữa hạ đường huyết và hạ canxi như thế nào?](https://bvnguyentriphuong.com.vn/cap-cuu/phan-biet-giua-ha-duong-huyet-va-ha-canxi-mau#phn-bit-gia-h-ng-huyt-v-h-canxi-nh-th-no)
  * [Triệu chứng hạ canxi là gì?](https://bvnguyentriphuong.com.vn/cap-cuu/phan-biet-giua-ha-duong-huyet-va-ha-canxi-mau#triu-chng-h-canxi-l-g)
  * [Triệu chứng hạ đường huyết](https://bvnguyentriphuong.com.vn/cap-cuu/phan-biet-giua-ha-duong-huyet-va-ha-canxi-mau#triu-chng-h-ng-huyt)
  * [Nên làm gì khi bị hạ đường huyết hoặc tụt canxi?](https://bvnguyentriphuong.com.vn/cap-cuu/phan-biet-giua-ha-duong-huyet-va-ha-canxi-mau#nn-lm-g-khi-b-h-ng-huyt-hoc-tt-canxi)
  * [Đối với tình trạng tụt canxi](https://bvnguyentriphuong.com.vn/cap-cuu/phan-biet-giua-ha-duong-huyet-va-ha-canxi-mau#i-vi-tnh-trng-tt-canxi)
  * [Đối với tình trạng hạ đường huyết](https://bvnguyentriphuong.com.vn/cap-cuu/phan-biet-giua-ha-duong-huyet-va-ha-canxi-mau#i-vi-tnh-trng-h-ng-huyt)



## ️ Các phương pháp Hô hấp nhân tạo

  * [1. Phương pháp hô hấp nhân tạo là gì?](https://bvnguyentriphuong.com.vn/cap-cuu/cac-phuong-phap-ho-hap-nhan-tao#1-phng-php-h-hp-nhn-to-l-g)
  * [2. Các nguyên nhân dẫn đến ngạt thở và dấu hiệu nhận biết](https://bvnguyentriphuong.com.vn/cap-cuu/cac-phuong-phap-ho-hap-nhan-tao#2-cc-nguyn-nhn-dn-n-ngt-th-v-du-hiu-nhn-bit)
  * [3. Có mấy phương pháp hô hấp nhân tạo?](https://bvnguyentriphuong.com.vn/cap-cuu/cac-phuong-phap-ho-hap-nhan-tao#3-c-my-phng-php-h-hp-nhn-to)
  * [3.1. Phương pháp hô hấp nhân tạo và xoa bóp tim ngoài lồng ngực](https://bvnguyentriphuong.com.vn/cap-cuu/cac-phuong-phap-ho-hap-nhan-tao#31-phng-php-h-hp-nhn-to-v-xoa-bp-tim-ngoi-lng-ngc)
  * [3.2. Phương pháp hô hấp nhân tạo Nielsen](https://bvnguyentriphuong.com.vn/cap-cuu/cac-phuong-phap-ho-hap-nhan-tao#32-phng-php-h-hp-nhn-to-nielsen)
  * [3.3. Phương pháp hô hấp nhân tạo Sylvester](https://bvnguyentriphuong.com.vn/cap-cuu/cac-phuong-phap-ho-hap-nhan-tao#33-phng-php-h-hp-nhn-to-sylvester)
  * [3.4. Phương pháp hô hấp nhân tạo Schaeffer](https://bvnguyentriphuong.com.vn/cap-cuu/cac-phuong-phap-ho-hap-nhan-tao#34-phng-php-h-hp-nhn-to-schaeffer)
  * [4. Diễn tiến của phương pháp hô hấp nhân tạo](https://bvnguyentriphuong.com.vn/cap-cuu/cac-phuong-phap-ho-hap-nhan-tao#4-din-tin-ca-phng-php-h-hp-nhn-to)
  * [4.1. Tiến triển tốt](https://bvnguyentriphuong.com.vn/cap-cuu/cac-phuong-phap-ho-hap-nhan-tao#41-tin-trin-tt)
  * [4.2. Tiến triển xấu](https://bvnguyentriphuong.com.vn/cap-cuu/cac-phuong-phap-ho-hap-nhan-tao#42-tin-trin-xu)


## **1. Phương pháp hô hấp nhân tạo là gì?**
Hô hấp nhân tạo tiếng anh là artificial respiration, đây là phương pháp hỗ trợ người không còn khả năng tự thở vì nguyên nhân nào đó. Phương pháp hô hấp nhân tạo có mục đích là làm cho không khí ở ngoài vào phổi và không khí ở trong phổi ra ngoài để cung cấp oxy cho người bệnh.
Ngừng thở là một cấp cứu khẩn cấp vì bệnh nhân không tự hô hấp được dẫn đến thiếu oxy cung cấp cho các tế bào, trong đó quan trọng nhất chính là thiếu oxy cho các tế bào thần kinh và dẫn đến chết não.
Phương pháp hô hấp nhân tạo bắt buộc phải thực hiện ngay lập tức khi người bệnh ngừng thở, thực hiện ngay tại nơi nạn nhân bị thương hoặc tai nạn trước khi nghĩ đến việc đưa đến các cơ sở y tế. Điều này giúp tăng khả năng cứu sống bệnh nhân.
## **2. Các nguyên nhân dẫn đến ngạt thở và dấu hiệu nhận biết**
Ngạt thở là một cấp cứu vô cùng nguy hiểm, một số nguyên nhân có thể dẫn đến hiện tượng này:
  * Đuối nước: Ngạt thở xảy ra do nước tràn ngập trong phổi, cản trở không khí đi vào phổi để thực hiện quá trình hô hấp.
  * Vùi lấp: Một số tai nạn như sập hầm, chiến tranh bom nổ, động đất... làm nạn nhân bị vùi lấp bởi nhiều thứ khác nhau, dẫn đến ngực bị chèn ép, đất cát lấp đầy trong mũi, miệng, đường thở gây ngạt thở nhanh chóng.
  * Hít khí độc: Ngạt thở xảy ra do người bệnh hít phải không khí thiếu oxy và thay bằng các loại khí độc khác như khí CO.
  * Tắc nghẽn đường hô hấp trên: đường thở bị tắc nghẽn và cản trở hô hấp, ngạt thở.


Dấu hiệu nhận biết người bị ngạt như sau:
  * Các động tác hô hấp ngừng hoàn toàn, lồng ngực hoặc thành bụng bất động.
  * Nạn nhân nằm yên hoặc mê man, không tỉnh.
  * Da trắng bệt hoặc tím tái
  * Sờ tay chân lạnh
  * Bắt mạch không được hoặc tim ngừng đập.
  * khi nào thì bị đuối nước khô
  * Đuối nước là tai nạn nguy hiểm dễ dẫn tới ngạt thở


## 3. Có mấy phương pháp hô hấp nhân tạo?
Các phương pháp hô hấp nhân tạo đều có những nguyên tắc chung là:
  * Thực hiện càng sớm càng tốt: Ngay khi phát hiện nạn nhân ngừng thở thì phải thực hiện các phương pháp hô hấp nhân tạo càng nhanh càng tốt, mỗi giây mỗi phút thiếu oxy não sẽ dẫn đến chết não và tiên lượng phục hồi khó khăn.
  * Loại bỏ nguyên nhân gây ngạt thở: Nhanh chóng loại bỏ các nguyên nhân gây ngạt trước khi tiến hành các phương pháp hô hấp nhân tạo.
  * Kiên trì thực hiện: cần thực hiện hô hấp nhân tạo cho đến khi nạn nhân tự thở hoặc trong khoảng thời gian nhất định tùy trường hợp.
  * Kỹ thuật hô hấp nhân tạo phải đúng, đủ mạnh, đủ tần số.
  * Môi trường xung quanh phải thoáng khí, không để nạn nhân nằm ở chỗ gió lạnh hoặc quá đông người xung quanh.


Có nhiều phương pháp hô hấp nhân tạo khác nhau và tùy trường hợp mà người cấp cứu sẽ lựa chọn một phương pháp thích hợp và hiệu quả nhất.
### **3.1. Phương pháp hô hấp nhân tạo và xoa bóp tim ngoài lồng ngực**
Phương pháp hô hấp nhân tạo này còn có tên gọi là khác là hà hơi thổi ngạt và đa số phải kết hợp với ép tim ngoài lồng ngực. Các bước thực hiện như sau:
Đặt nạn nhân nằm ngửa ở nơi thoáng đãng, nới rộng quần áo và dây thắt lưng.
Bảo đảm đường thở thông thoáng bằng cách lấy hết dị vật trong mũi miệng, để đầu nạn nhân hơi ngửa (đặt đệm dưới cổ). Nếu bệnh nhân tăng tiết đàm nhớt, nôn ói thì cần phải lau, hút sạch bằng một miếng vải đưa vào miệng bệnh nhân.
Có thể thổi ngạt trực tiếp hoặc gián tiếp thông qua một miếng vải mỏng đặt trên miệng bệnh nhân.
Tiến hành hà hơi thổi ngạt: Một tay bịt mũi, một tay kéo hàm xuống dưới để mở miệng nạn nhân. Sau đó hít hơi thật sâu rồi ngậm chặt miệng nạn nhân và thổi hết hơi.
Quan sát lồng ngực bệnh nhân có di chuyển lên xuống trong lúc thổi ngạt hay không và tiến hành lặp lại liên tục.
Tần số hà hơi thổi ngạt đối với người lớn và trẻ em trên 8 tuổi là khoảng 20 lần/phút. Đối với trẻ dưới 8 tuổi khoảng 20 - 30 lần/phút.
Nếu phát hiện bệnh nhân vừa ngừng thở kèm theo ngưng tim thì phải tiến hành xoa bóp tim ngoài lồng ngực kết hợp với hà hơi thổi ngạt. Tần suất vừa ép tim vừa thổi ngạt là 30:2 (30 lần ép tim thì thổi ngạt 2 lần)
Tiến hành phương pháp hô hấp nhân tạo này cho đến khi bệnh nhân tự thở, đưa ngay đến cơ sở y tế hoặc cấp cứu trong khoảng 30 phút mà không hiệu quả thì nên ngừng lại vì bệnh nhân đã tử vong.
Phương pháp hô hấp nhân tạo và xoa bóp tim ngoài lồng ngực có tên gọi là khác là hà hơi thổi ngạt và đa số phải kết hợp với ép tim ngoài lồng ngực
### **3.2. Phương pháp hô hấp nhân tạo Nielsen**
Đảm bảo đường thở thông thoáng, loại bỏ dị vật hoặc đàm nhớt, chất nôn ói... Đặt nạn nhân nằm sấp, đầu nghiêng sang một bên và gối lên 2 bàn tay nạn nhân. Người thực hiện quỳ gối ở phía đầu nạn nhân. Các bước tiến hành phương pháp hô hấp nhân tạo Nielsen:
Tạo thì thở ra: Ép mạnh hai bàn tay vào lưng nạn nhân, lòng bàn tay đè lên hai xương bả vai. Người cấp cứu hơi ngả về phía trước, hai cánh tay ấn thẳng (vuông góc với thành ngực) rồi buông ra đột ngột.
Tạo thì hít vào: Người cấp cứu nắm tay nạn nhân ở gần mỏm khuỷu và tiến hành kéo cánh tay lên trên, về phía đầu (nhưng không nhấc đầu lên) rồi trả về tư thế lúc đầu.
Tần số hô hấp nhân tạo là khoảng 10 – 12 lần/phút.
Phương pháp hô hấp nhân tạo Nielsen áp dụng trong cấp cứu bệnh nhân ngạt thở do đuối nước, bệnh nhân nằm sấp để dễ dàng tống nước trong bụng ra ngoài.
### **3.3. Phương pháp hô hấp nhân tạo Sylvester**
Phương pháp hô hấp nhân tạo Sylvester thường sử dụng trong các trường hợp ngạt thở do vùi lấp hoặc do nạn nhân không nằm sấp (ví dụ như bà bầu hay người có vết thương vùng bụng).
Yêu cầu đầu tiên là phải đảm bảo thông thoáng đường thở, không có dị vật hoặc đàm nhớt gây cản trở hô hấp.
Tư thế nạn nhân: Nằm ngửa, đầu quay về một bên. Có thể kê gối hoặc đệm dưới vai nạn nhân, đầu nạn nhân hơi ngửa về phía sau, cằm hướng lên trên. Người thực hiện quỳ ở phía đầu nạn nhân. Tiến hành phương pháp hô hấp nhân tạo Sylvester:
Tạo thì thở ra: Người thực hiện nắm chặt 1⁄3 dưới hai cẳng tay nạn nhân gấp lên trước ngực. Tư thế người cấp cứu nhổm về phía trước, hai tay duỗi thẳng và ép mạnh lên thành ngực nạn nhân để tống không khí ra ngoài.
Tạo thì hít vào: Người cấp cứu ngồi xuống, đồng thời kéo hai tay nạn nhân về phía đầu, đồng thời ngả cả người ra sau.
Tần số hô hấp nhân tạo khoảng 15-20 lần/phút.
### **3.4. Phương pháp hô hấp nhân tạo Schaeffer**
Tư thế: Đặt nạn nhân nằm sấp trên mặt phẳng thẳng, hai tay đưa lên phía đầu, mặt quay sang một bên, đảm bảo thông thoáng đường thở. Người cứu nạn quỳ gối ở phía sau lưng của nạn nhân, có thể ngồi nhẹ lên bắp chân của nạn nhân (trường hợp nạn nhân nằm trên ghế).
Tiến hành phương pháp hô hấp nhân tạo: Người thực hiện đặt 2 bàn tay lên lưng nạn nhân ngay phía trên khung chậu, xòe 2 bàn tay ra.
Tạo thì thở ra: Người thực hiện hơi nâng người lên, hai tay ép mạnh lên lưng nạn nhân trong khoảng 2 giây. Động tác này giúp đẩy cơ hoành lên trên, ép khí trong phổi đi ra ngoài.
Tạo thì hít vào: Từ từ buông 2 tay ra khỏi hoàn toàn lưng nạn nhân để cơ hoành hạ xuống, phổi nở ra do không khí tự nhiên đi vào.
Tần số hô hấp nhân tạo khoảng 15-20 lần/phút).
## **4. Diễn tiến của phương pháp hô hấp nhân tạo**
Hô hấp nhân tạo
Tiến triển tốt sau hô hấp nhân tạo là bệnh nhân đã tự thở được, các động tác hô hấp dần hồi phục
### **4.1. Tiến triển tốt**
Nạn nhân tự thở được, các động tác hô hấp dần hồi phục.
Nhịp thở lúc đầu có thể hơi yếu, ngập ngừng và người cấp cứu phải tiếp tục hô hấp nhân tạo cho đến khi bệnh nhân thở mạnh, thở sâu hơn.
Đưa nạn nhân đến cơ sở y tế gần nhất càng sớm càng tốt.
### **4.2. Tiến triển xấu**
Những dấu hiệu sinh tồn càng lúc càng xấu đi báo hiệu khả năng tử vong của nạn nhân. Chỉ ngừng hô hấp nhân tạo khi:
Thân nhiệt nạn nhân dưới 25 độ.
Đồng tử giãn rộng.
Xuất hiện các mảng bầm tím trên da (do máu tụ).
Tay chân cứng đờ (dấu hiệu muộn).
Hô hấp nhân tạo là một kỹ thuật hồi sức cấp cứu quan trọng, giúp bệnh nhân trong các trường gặp tai nạn, ngạt thở có tiên lượng sống tốt. Theo đó, hiện nay có rất nhiều phương pháp hô hấp nhân tạo, tùy từng trường hợp bệnh nhân gặp nạn mà có các phương pháp hô hấp nhân tạo khác nhau.
Xem thêm: [**Ghi nhớ những mẹo sơ cứu ban đầu cần thiết**](https://bvnguyentriphuong.com.vn/cap-cuu/ghi-nho-nhung-meo-so-cuu-ban-dau-can-thiet)
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [1. Phương pháp hô hấp nhân tạo là gì?](https://bvnguyentriphuong.com.vn/cap-cuu/cac-phuong-phap-ho-hap-nhan-tao#1-phng-php-h-hp-nhn-to-l-g)
  * [2. Các nguyên nhân dẫn đến ngạt thở và dấu hiệu nhận biết](https://bvnguyentriphuong.com.vn/cap-cuu/cac-phuong-phap-ho-hap-nhan-tao#2-cc-nguyn-nhn-dn-n-ngt-th-v-du-hiu-nhn-bit)
  * [3. Có mấy phương pháp hô hấp nhân tạo?](https://bvnguyentriphuong.com.vn/cap-cuu/cac-phuong-phap-ho-hap-nhan-tao#3-c-my-phng-php-h-hp-nhn-to)
  * [3.1. Phương pháp hô hấp nhân tạo và xoa bóp tim ngoài lồng ngực](https://bvnguyentriphuong.com.vn/cap-cuu/cac-phuong-phap-ho-hap-nhan-tao#31-phng-php-h-hp-nhn-to-v-xoa-bp-tim-ngoi-lng-ngc)
  * [3.2. Phương pháp hô hấp nhân tạo Nielsen](https://bvnguyentriphuong.com.vn/cap-cuu/cac-phuong-phap-ho-hap-nhan-tao#32-phng-php-h-hp-nhn-to-nielsen)
  * [3.3. Phương pháp hô hấp nhân tạo Sylvester](https://bvnguyentriphuong.com.vn/cap-cuu/cac-phuong-phap-ho-hap-nhan-tao#33-phng-php-h-hp-nhn-to-sylvester)
  * [3.4. Phương pháp hô hấp nhân tạo Schaeffer](https://bvnguyentriphuong.com.vn/cap-cuu/cac-phuong-phap-ho-hap-nhan-tao#34-phng-php-h-hp-nhn-to-schaeffer)
  * [4. Diễn tiến của phương pháp hô hấp nhân tạo](https://bvnguyentriphuong.com.vn/cap-cuu/cac-phuong-phap-ho-hap-nhan-tao#4-din-tin-ca-phng-php-h-hp-nhn-to)
  * [4.1. Tiến triển tốt](https://bvnguyentriphuong.com.vn/cap-cuu/cac-phuong-phap-ho-hap-nhan-tao#41-tin-trin-tt)
  * [4.2. Tiến triển xấu](https://bvnguyentriphuong.com.vn/cap-cuu/cac-phuong-phap-ho-hap-nhan-tao#42-tin-trin-xu)



## ️ Ghi nhớ những mẹo sơ cứu ban đầu cần thiết

– **BỊ BỎNG** bạn cần nhúng vết bỏng vào nước sạch rồi dùng muối tinh đắp lên để tới khi muối khô và rơi ra.
– **NGÃ TÍM CHÂN** : Dùng đá chườm
– **BỊ ĐỨT TAY** : Dùng đầu lọc thuốc lá dịt chặt và giơ ngón tay lên cao.
–**BỤI BAY VÀO MẮT** : Mở to mắt, nhúng mắt vào nước và chớp để lấy bụi ra khỏi mắt. Nghiêm cấm dụi mắt vì có thể gây tổn thương giác mạc.
– **BỊ GÃY XƯƠNG TAY, CHÂN** : Cầm máu ngay lập tức (nếu bị chảy máu), sau đó cố định chỗ gãy bằng cách dùng một miếng gỗ thẳng, một bìa cứng làm nẹp để tránh cử động các khớp phía trên và dưới tổn thương, đồng thời giúp giảm đau. Nếu bệnh nhân không di chuyển được, cần gọi nhân viên y tế đến sơ cứu rồi chuyển bệnh nhân đến cơ sở y tế. Tuyệt đối không di chuyển bênh nhân khi chưa đảm bảo an toàn.
Nếu chảy máu nhiều có thể áp dụng các cách sau
Đầu tiên, để vùng chảy máu cao hơn mức tim
– **CHẢY MÁU CAM** : Dùng bông thấm máu. Ngồi hoặc đứng để đầu cao hơn tim. Nghiêng đầu về phía trước. Chườm đá ở vùng mũi. Không hỉ mũi tránh làm máu chảy nhiều hơn. Không nghiêng đầu ra sau tránh máu chảy vào họng gây bị nôn.
Nếu máu vẫn chảy quá 10 phút dù đã làm những bước nói trên 2 lần, bệnh nhân cần đến bác sĩ. Khi đã hết chảy máu cam, không nên nâng vật nặng hoặc làm việc căng thẳng, không hỉ mũi trong vòng 24 giờ và khi nằm cần để đầu cao hơn tim.
– **BONG GÂN** : Cầm máu và hạn chế phù nề tối đa. Có thể dùng băng thun băng ép khớp bị bong gân, giúp khớp có chỗ tựa và giữ cố định cho khớp. Cần chườm đá và cố định chỗ bị bong gân. Nên chườm lạnh bên ngoài bằng nước đá (hoặc nước lạnh) trong 4 giờ đầu. Việc chườm đá làm dịu đau và co mạch, ngưng chảy máu, bớt phù nề. Những ngày kế tiếp nên ngâm chỗ bị bong gân trong nước ấm từ 3 – 4 lần trong ngày.
– **BỊ CÔN TRÙNG CẮN** : Rửa sạch vết thương bằng xà phòng và nước. Đắp một miếng gạc lạnh hoặc sử dụng dạng xịt tạo màng sinh học Nacurgo giúp sát khuẩn, bảo vệ vết thương, cải thiện tình trạng sưng, viêm, ngứa. Không gãi ở chỗ vết cắn vì có thể sẽ làm ngứa thêm và có thể khiến chỗ vết cắn bị nhiễm khuẩn. 
– **HỖ TRỢ DI CHUYỂN NHỮNG NGƯỜI CÂNG NẶNG LỚN HƠN BẠN:**
Thông thường, bạn cần để nguyên người bị thương tại chỗ để đợi bác sĩ tới. TUYỆT ĐỐI không di chuyển những người bị thương phần đầu, cổ và cột sống. Trong các trường hợp khác, bạn có thể phải di chuyển người bị nạn tới nơi an toàn. Nếu người bị nạn quá nặng, sau đây là cách di chuyển họ:
  1. Quay người bị nạn về phía mình, kéo tay họ quàng lên vai mình
  2. Quì xuống hoặc ngồi xổm xuống, sao cho phần bụng-ngực người bị nạn nằm trên vai của bạn.
  3. Giữ thẳng hông và đứng dậy. Không nghiêng người về phía trước để tránh bị chấn thương lưng.
  4. Người bị nạn sẽ nằm trên vai bạn và bạn có thể di chuyển ra xung quanh.


## – **CỨU NGƯỜI ĐUỐI NƯỚC**
Khi phát hiện người bị đuối nước, bạn hãy thực hiện các bước dưới đây:
  * Hô hào sự trợ giúp từ những người xung quanh và gọi số điện thoại khẩn cấp 112 cũng như số điện thoại cấp cứu y tế 115 càng sớm càng tốt.
  * Nếu không biết bơi, bạn hãy mang phao cứu hộ và giữ khoảng cách với nạn nhân để đảm bảo an toàn cho chính bản thân bạn trước.
  * Nếu nạn nhân còn tỉnh táo, bạn hãy dùng một vật dụng đủ cứng để kéo người bị nạn lên như mái chèo. Bạn cũng cần đứng thật vững và đủ xa để không bị kéo ngược xuống nước đồng thời giữ mái chèo thật chặt để người đuối nước có thể nắm lấy.
  * Bạn lưu ý không nên dùng tay của mình để cứu nạn nhân. Khi nạn nhân kéo người bạn, bạn nên buông tay để bảo vệ chính mình.
  * Nếu bạn không có vật dụng gì thì hãy quăng cho nạn nhân một sợi dây hoặc một cái phao nổi để người đó nắm lấy.


Nếu bạn là một người chắc chắn về kỹ năng bơi lội của mình thì có thể bơi ra ngoài chỗ nạn nhân rồi thực hiện các bước dưới đây:
  * Mặc áo phao cứu sinh đồng thời buộc một sợi dây quanh eo trước khi ra chỗ nạn nhân. Một người sẽ đứng ở trên bờ hoặc trên một chiếc thuyền gần đó để giữ sợi dây.
  * Giữ khoảng cách với nạn nhân rồi ném phao hoặc dây về phía người bị đuối nước hoặc dùng một cây sào, mái chèo, dây thừng để tiếp cận nạn nhân.
  * Bạn không nên chạm vào người nạn nhân bị đuối nước đang hoảng loạn. Sau khi nạn nhân tiếp cận được phao nổi hoặc những vật dụng khác, bạn hãy bơi thẳng về phía bờ và kéo nạn nhân ở phía sau.
  * Nếu nạn nhân bất tỉnh thì bạn kéo nạn nhân vào bờ an toàn và thực hiện các bước sơ cứu cơ bản. Trong thời tiết lạnh, bạn hãy cởi bỏ quần áo ướt của nạn nhân và che người họ bằng một tấm chăn rồi theo dõi các triệu chứng hạ thân nhiệt. Nếu nạn nhân không thở, bạn hãy thực hiện hồi sức tim phổi.


**Bệnh nhân bị đuối nước cần phải được đưa đến bệnh viện để bác sĩ theo dõi và thăm khám, đặc biệt là khi bị sặc nước để xem có gặp tình trạng đuối nước khô hay không.**
_Đuối nước khô là thuật ngữ để mô tả các trường hợp tử vong sau khi hít hoặc nuốt phải chất lỏng vào trong phổi, khiến dây thanh quản bị co thắt và đóng lại gây cản trở đường thở._
Xem thêm: [**Cách nhận biết và điều trị nhiễm trùng vết cắn do động vật**](https://bvnguyentriphuong.com.vn/dieu-duong/cach-nhan-biet-va-dieu-tri-nhiem-trung-vet-can-do-dong-vat)
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh

## ️ Sơ cứu vết thuơng chảy máu nghiêm trọng

  * [Đặt nạn nhân nằm xuống và che đắp để ngăn ngừa mất nhiệt cơ thể](https://bvnguyentriphuong.com.vn/cap-cuu/so-cuu-vet-thuong-chay-mau-nghiem-trong#t-nn-nhn-nm-xung-vchep-ngn-nga-mt-nhit-c-th)
  * [Nếu đeo găng tay, hãy lấy đi bất kỳ chất bẩn hoặc mảnh vỡ nhìn thấy được ra khỏi vết thương](https://bvnguyentriphuong.com.vn/cap-cuu/so-cuu-vet-thuong-chay-mau-nghiem-trong#nu-eo-gng-tay-hy-ly-i-bt-k-cht-bn-hoc-mnh-v-nhn-thy-cra-khivt-thng)
  * [Đè trực tiếp lên vết thương cho đến khi hết chảy máu](https://bvnguyentriphuong.com.vn/cap-cuu/so-cuu-vet-thuong-chay-mau-nghiem-trong#-trc-tip-ln-vt-thng-cho-n-khi-ht-chy-mu)
  * [Không gỡ bỏ các gạc hoặc băng](https://bvnguyentriphuong.com.vn/cap-cuu/so-cuu-vet-thuong-chay-mau-nghiem-trong#khng-g-b-cc-gc-hoc-bng)
  * [Có thể đè vào động mạch chính nếu cần](https://bvnguyentriphuong.com.vn/cap-cuu/so-cuu-vet-thuong-chay-mau-nghiem-trong#c-th-vo-ng-mch-chnh-nu-cn)
  * [Bất động phần cơ thể bị thương khi máu đã ngừng chảy](https://bvnguyentriphuong.com.vn/cap-cuu/so-cuu-vet-thuong-chay-mau-nghiem-trong#bt-ng-phn-c-th-b-thng-khi-mu-ngng-chy)


Chảy máu là hiện tượng mất máu từ hệ thống mạch máu (tĩnh mạch, động mạch hay mao mạch), bao gồm cả chảy máu trong và chảy máu ngoài. Lưu lượng máu trong động mạch chịu áp lực cao nhất.
Khi bị vết thương chảy máu ngoài, việc cần làm đầu tiên là phải cầm máu. Tùy vào mức độ của vết thương, nếu vết thương sâu rộng và mất máu nhiều, nạn nhân cần được can thiệp y tế ngay lập tức.
Lưu ý khi hỗ trợ nạn nhân sơ cứu vết thương chảy máu, người hỗ trợ nên sử dụng găng tay tiệt trùng để bảo vệ cả bản thân và nạn nhân.
**Đối với vết thương bên ngoài**
  * ### **Đặt nạn nhân nằm xuống và****che****đắp để ngăn ngừa mất nhiệt cơ thể**


Nếu có thể, đặt đầu nạn nhân hơi thấp hơn so với thân hoặc nâng cao chân và nâng cao vị trí chảy máu.
  * ### **Nếu đeo găng tay, hãy lấy đi bất kỳ chất bẩn hoặc mảnh vỡ nhìn thấy được****ra khỏi****vết thương**


Đừng lấy đi bất kỳ vật lớn hoặc nằm sâu trong vết thương. Nên nhớ mối quan tâm chính của bạn là cầm máu.
  * ### **Đè trực tiếp lên vết thương cho đến khi hết chảy máu**


Sử dụng băng vô trùng hoặc vải sạch đè liên tục trong ít nhất 20 phút và không được mở ra xem máu đã ngừng chảy hay chưa. Duy trì áp lực bằng cách bó chặt vết thương bằng băng hoặc vải sạch với băng dính (nếu có). Sử dụng bàn tay của bạn nếu không có sẵn gì khác. Nếu có thể, đeo găng tay cao su hoặc găng tay Latex hoặc sử dụng một túi nilon sạch để bảo vệ bạn khỏi nhiễm trùng.
  * ### **Không gỡ bỏ các gạc hoặc băng**


Nếu máu tiếp tục chảy và thấm ướt băng hoặc gạc mà bạn đang chẹn trên vết thương, không được bỏ chúng đi. Thay vào đó, hãy đè thêm băng gạc mới lên trên.
  * ### **Có thể đè vào động mạch chính nếu cần**


Nếu máu vẫn tiếp tục chảy mặc dù đã đè trực tiếp lên vết thương, hãy đè lên động mạch cung cấp máu đến khu vực đó.
Điểm đè của cánh tay là ở mặt trong cánh tay ngay phía trên khuỷu và ngay dưới nách. Điểm đè của chân là ngay phía sau đầu gối và ở vùng bẹn. Tại các vị trí này, động mạch chính được đè lên xương. Giữ các ngón tay của bạn phẳng khi đè. Tiếp tục đè bàn tay còn lại lên trên bàn tay kia để tăng áp lực.
  * ### **Bất động phần cơ thể bị thương khi máu đã ngừng chảy**


Để các băng gạc ở nguyên vị trí và đưa nạn nhân đến phòng cấp cứu càng sớm càng tốt.
**Chảy máu bên trong**
Hiện tượng này có thể xảy ra khi nạn nhân bị đập mạnh vào đầu, ngực hay bụng do ngã hoặc bị xe đâm. Người không có chuyên môn thường khó nhận biết các dấu hiệu của chảy máu trong.Nếu bạn nghi ngờ chảy máu bên trong, hãy gọi 115 hoặc số khẩn cấp tại địa phương bạn. Các dấu hiệu chảy máu bên trong bao gồm:
  * Chảy máu từ các khoang cơ thể (ổ bụng, lồng ngực…).
  * Nôn hoặc ho ra máu.
  * Bầm tím ở vùng cổ, ngực, bụng.
  * Có vết thương xuyên sọ, ngực hoặc bụng.
  * Bụng chướng, có thể cứng hoặc co thắt cơ bụng.
  * Gãy xương.
  * Sốc, biểu hiện với suy yếu, lo lắng, khát nước hoặc da mát lạnh.


**_Chuyển nạn nhân tới cơ sở y tế nếu điều kiện cho phép:_**
Nếu vết thương nhỏ và nạn nhân có thể di chuyển bằng ô tô xe máy thông thường thì chuyển ngay nạn nhân tới cơ sở y tế gần đó.
Nếu vết thương nặng hay tình trạng nạn nhân xấu thì gọi cấp cứu càng sớm càng tốt.
Trong khi chờ đợi hoặc trên đường vận chuyển phải theo dõi sát tình trạng hô hấp, tuần hoàn của nạn nhân. Giữ ấm cho nạn nhân.
Cố gắng tránh tiếp xúc trực tiếp với máu hoặc các loại dịch khác từ cơ thể nạn nhân. Sử dụng găng tay dùng một lần nếu có thể. Nếu không có găng thì dùng túi nilon thông thường để thay thế.
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [Đặt nạn nhân nằm xuống và che đắp để ngăn ngừa mất nhiệt cơ thể](https://bvnguyentriphuong.com.vn/cap-cuu/so-cuu-vet-thuong-chay-mau-nghiem-trong#t-nn-nhn-nm-xung-vchep-ngn-nga-mt-nhit-c-th)
  * [Nếu đeo găng tay, hãy lấy đi bất kỳ chất bẩn hoặc mảnh vỡ nhìn thấy được ra khỏi vết thương](https://bvnguyentriphuong.com.vn/cap-cuu/so-cuu-vet-thuong-chay-mau-nghiem-trong#nu-eo-gng-tay-hy-ly-i-bt-k-cht-bn-hoc-mnh-v-nhn-thy-cra-khivt-thng)
  * [Đè trực tiếp lên vết thương cho đến khi hết chảy máu](https://bvnguyentriphuong.com.vn/cap-cuu/so-cuu-vet-thuong-chay-mau-nghiem-trong#-trc-tip-ln-vt-thng-cho-n-khi-ht-chy-mu)
  * [Không gỡ bỏ các gạc hoặc băng](https://bvnguyentriphuong.com.vn/cap-cuu/so-cuu-vet-thuong-chay-mau-nghiem-trong#khng-g-b-cc-gc-hoc-bng)
  * [Có thể đè vào động mạch chính nếu cần](https://bvnguyentriphuong.com.vn/cap-cuu/so-cuu-vet-thuong-chay-mau-nghiem-trong#c-th-vo-ng-mch-chnh-nu-cn)
  * [Bất động phần cơ thể bị thương khi máu đã ngừng chảy](https://bvnguyentriphuong.com.vn/cap-cuu/so-cuu-vet-thuong-chay-mau-nghiem-trong#bt-ng-phn-c-th-b-thng-khi-mu-ngng-chy)



## ️ Cấp cứu vết thương mạch máu

  * [Dấu hiệu phát hiện vết thương mạch máu](https://bvnguyentriphuong.com.vn/cap-cuu/cap-cuu-vet-thuong-mach-mau#du-hiu-pht-hin-vt-thng-mch-mu)
  * [Sơ cứu như thế nào?](https://bvnguyentriphuong.com.vn/cap-cuu/cap-cuu-vet-thuong-mach-mau#s-cu-nh-th-no)


## **Dấu hiệu phát hiện vết thương mạch máu**
Vết thương mạch máu lớn thường gây thiếu máu cấp tính. Do mất máu nhanh và nhiều dễ dẫn tới sốc do mất máu. Biểu hiện của sốc mất máu là: nạn nhân hốt hoảng, vật vã, lo âu, vã mồ hôi, mạch nhanh, nhỏ, huyết áp tụt và kẹt.
Với vết thương hở có máu chảy ra ngoài, máu có thể chảy vọt thành tia hoặc chảy rỉ đều dễ nhận biết. Nếu vết thương đã được garô hoặc băng, khi tháo ra, thấy máu chảy dữ dội cũng dễ chẩn đoán, nếu không thấy chảy máu thì phải cảnh giác, kiểm tra mạch đập để xác định có tổn thương mạch máu hay không.
Vết thương không chảy máu ra ngoài có thể gặp hai trường hợp: một là vết thương mạch máu đã ngừng chảy máu; hai là tụ máu dưới da.
Vết thương đứt mạch máu bàn tay trái
Vết thương mạch máu nhờ sơ cứu đã cầm được máu: nhìn chỉ như vết thương phần mềm, rất dễ bị bỏ qua. Vì vậy, bạn cần tìm dấu hiệu thiếu máu ngoại biên như: chi bị thương lạnh, nhợt, không có mạch hoặc mạch đập yếu hơn bên lành, vận động giảm hoặc mất.
_Vết thương mạch máu có thể gây thiếu máu cấp tình nếu không xử lý kịp thời_
Đôi khi vết thương mạch máu có thể tự cầm do: đầu mạch máu bị đứt co rút vào trong các tổ chức phần mềm, lớp nội mạc lộn vào trong lòng mạch, tạo điều kiện hình thành cục máu đông bịt đầu mạch máu lại.
Có khi do chảy máu quá nhiều làm cho huyết áp tụt cũng làm cho máu ngừng chảy, nhưng nếu không cầm máu ngay thì khi hồi sức, huyết áp lên máu lại tiếp tục chảy. Có trường hợp do khối máu tụ chèn ép các mạch máu làm cho máu ngừng chảy.
Tụ máu dưới da có hai hình thái: khối máu tụ lan rộng, đập theo nhịp tim, để lâu bệnh nhân có dấu hiệu thiếu máu. Khối máu tụ khu trú: trường hợp điển hình nếu bị thương ở cẳng chân là bắp chân căng vì khối máu được các cân bao bọc chi hạn chế nên không to lên được nhưng rất căng, làm ngăn cản máu động mạch đến và máu tĩnh mạch về nên chi vùng ngoại vi lạnh, tím, không có mạch, rất đau.
Trường hợp này nếu không xử lý kịp thời sẽ gây hoại thư. Khối máu tụ thường có biến chứng: bị nhiễm khuẩn, nung mủ gây ra triệu chứng sưng, nóng, đỏ, đau rất dễ nhầm với một áp-xe nóng; bọc máu tụ bị vỡ ra ngoài gây chảy máu dữ dội, đe doạ tính mạng của nạn nhân.
Vết thương mạch máu có thể gây biến chứng nguy hiểm như: tử vong do thiếu máu cấp tính, nhiễm độc, hoại thư, co rút cơ, di chứng phồng động mạch và thông động – tĩnh mạch.
## **Sơ cứu như thế nào?**
Khi gặp nạn nhân bị vết thương mạch máu, bạn cần nhanh chóng sơ cứu để cứu sống nạn nhân bằng cách: đặt garô, băng ép, ép mạch máu. Cách làm các thủ thuật đó như sau: Đặt garô là phương pháp cầm máu tốt nhưng đòi hỏi thực hiện đúng các quy tắc sau: Đặt chỗ dễ nhìn thấy nhất, gần vết thương nhất, ưu tiên chuyển nạn nhân đến bệnh viện trước kèm theo phiếu ghi giờ đặt garô.
_Sau khi sơ cứu cần đưa bệnh nhân đến bệnh viện để được điều trị tốt nhất_
Trong quá trình đặt garô, cứ một giờ nới lỏng garô trong vài phút cho máu chảy xuống nuôi dưỡng phần dưới chỗ bị thương, sau đó lại tiếp tục siết garô khi máu bắt đầu chảy trở lại.
Khi tháo garô để điều trị thực thụ phải chuẩn bị sẵn phương tiện để cầm máu và hồi sức. Chỉ đặt garô trong các trường hợp sau đây: chi bị dập nát không còn khả năng bảo tồn; đặt garô ở nơi xảy ra tai nạn, nhưng gần một bệnh viện, thời gian vận chuyển bệnh nhân đến bệnh viện dưới một giờ; đặt tạm thời trong một thời gian ngắn để chuẩn bị mổ.
  * Băng ép cầm máu: Dùng một cuộn băng hay một chiếc khăn gấp nhỏ lại thành một cục đặt lên vết thương và băng ép lên trên để cầm máu, dùng băng cuộn băng chặt quanh chi cho đến khi không thấy máu thấm băng. Băng ép cầm máu tốt nhất là dùng loại băng chun. Phương pháp này đơn giản dễ thực hiện, có tác dụng cầm máu tốt lại không gây hậu quả xấu đối với vùng bị tổn thương.
  * Dùng ngón tay ép lên mạch máu: Bạn dùng ngón tay ép lên đường đi của mạch máu phía trên (gần tim hơn vết thương) vào nền xương. Vị trí thường được dùng để ấn mạch: ở chi trên là sau xương đòn, nếu chảy máu của động mạch dưới đòn ở vùng vai, cánh tay. Tại hõm nạch, nếu chảy máu của động mạch nách và động mạch cánh tay, ở vùng cánh tay.


Tại bờ trong cơ nhị đầu, ở nếp gấp khuỷu, nếu chảy máu của động mạch quay và động mạch trụ, ở vùng cẳng tay. Chi dưới: điểm giữa nếp bẹn, nếu chảy máu của động mạch đùi do vết thương ở dưới đùi. Tại hõm khoeo, nếu chảy máu của động mạch vùng cẳng chân…
Ngoài ra, bạn có thể gấp khuỷu tay hay đầu gối tối đa và ép vào thân để cầm máu, biện pháp này áp dụng khi chưa có điều kiện băng ép hoặc đặt garô. Dùng kẹp cầm máu kẹp các mạch máu. Sơ bộ chống choáng: bằng cách ủ ấm cho nạn nhân, cho nạn nhân uống thuốc trợ tim, giảm đau.
Điều trị ở bệnh viện gồm: Hồi sức tích cực, trường hợp mất máu nhanh và nhiều phải vừa truyền máu vừa mổ để cầm máu. Dùng kháng sinh chống nhiễm khuẩn và tiêm phòng uốn ván.
Tại chỗ: mở rộng vết thương để tìm đầu mạch máu bị đứt thắt lại, cắt lọc sạch những tổ chức dập nát ở phần mềm, lấy dị vật, máu tụ, loại bỏ các ngóc ngách của vết thương. Áp dụng một trong những cách cầm máu vĩnh viễn như: thắt các đầu mạch máu bị đứt ở ngay vết thương; thắt mạch máu ở xa vết thương; ghép mạch máu; cắt cụt chi.
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [Dấu hiệu phát hiện vết thương mạch máu](https://bvnguyentriphuong.com.vn/cap-cuu/cap-cuu-vet-thuong-mach-mau#du-hiu-pht-hin-vt-thng-mch-mu)
  * [Sơ cứu như thế nào?](https://bvnguyentriphuong.com.vn/cap-cuu/cap-cuu-vet-thuong-mach-mau#s-cu-nh-th-no)



## ️ Hướng dẫn sơ cứu tại chỗ một số dạng ngộ độc thường gặp

  * [Xử trí khi bị ngộ độc bằng đường ăn uống](https://bvnguyentriphuong.com.vn/cap-cuu/huong-dan-so-cuu-tai-cho-mot-so-dang-ngo-doc-thuong-gap#x-tr-khi-b-ng-c-bng-ng-n-ung)
  * [Xử trí khi bị rắn độc cắn](https://bvnguyentriphuong.com.vn/cap-cuu/huong-dan-so-cuu-tai-cho-mot-so-dang-ngo-doc-thuong-gap#x-tr-khi-b-rn-c-cn)
  * [Xử trí khi bị ong đốt](https://bvnguyentriphuong.com.vn/cap-cuu/huong-dan-so-cuu-tai-cho-mot-so-dang-ngo-doc-thuong-gap#x-tr-khi-b-ong-t)
  * [Xử trí khi hít phải hơi, khí độc](https://bvnguyentriphuong.com.vn/cap-cuu/huong-dan-so-cuu-tai-cho-mot-so-dang-ngo-doc-thuong-gap#x-tr-khi-ht-phi-hi-kh-c)
  * [Cấp cứu cho người bị chất độc xâm nhập qua da, qua mắt: ](https://bvnguyentriphuong.com.vn/cap-cuu/huong-dan-so-cuu-tai-cho-mot-so-dang-ngo-doc-thuong-gap#cp-cu-cho-ngi-b-cht-c-xm-nhp-qua-da-qua-mt)


Một số dạng ngộ độc như ngộ độc thực phẩm, ong đốt, hít phải khí độc, rắn cắn,… đều là những dạng ngộ độc thường gặp trong cuộc sống. Khi gặp những tình huống này bạn cần bình tĩnh để xử trí vết thương, giảm thiểu hậu quả do ngộ độc gây ra.
## **Xử trí khi bị ngộ độc bằng đường ăn uống**
Khi bị ngộ độc thực phẩm, bạn có thể gây nôn cho bệnh nhân trong 30 phút đầu nếu bệnh nhân tỉnh táo, chưa nôn, có thể hợp tác tốt. Cho bệnh nhân uống than hoạt tính hoặc Antipois-Bmai và đưa nạn nhân đến viện sớm và mang theo mẫu chất độc như vỉ thuốc đã bóc, lọ hóa chất,…
_Lưu ý:_ không gây nôn trong trường hợp hôn mê, co giật, uống xăng dầu, axit, kiềm.
## **Xử trí khi bị rắn độc cắn**
Khi bị rắn độc cắn bạn cần bình tĩnh và thực hiện theo hướng dẫn sau:
  * Băng ép và bất động toàn bộ chi bị cắn nếu bị rắn hổ cắn, rắn cạp nia, rắn hổ chúa cắn . Không băng ép nếu bị rắn lục cắn.
  * Hạn chế vận động, đi lại nếu có thể.
  * Nhanh chóng đến viện để được dùng thuốc giải độc. Không mất thời gian đi tìm thầy lang thuốc lá.


## **Xử trí khi bị ong đốt**
Ong đốt thường gây sưng, đau, tấy ở vết thương. Nhưng nếu nghiêm trọng bạn có thể bị sốc phản vệ (ong mật đốt) hoặc nếu bị đốt vào vùng hầu họng sẽ gây phù nề, chèn ép họng gây khó thở hoặc nếu là ong vò vẽ với số lượng nhiều (trên 20 nốt) hoặc đốt ở người có cơ địa bệnh lý sẵn như viêm gan, suy thận,… sẽ gây nguy hiểm cho bệnh nhân. Với trường hợp nà bạn phải đưa
## **Xử trí khi hít phải hơi, khí độc**
Khi cấp cứu cho người hít phải hơi, khí độc bạn cần được trang bị các biện pháp bảo hộ ăn toàn như áo, mũ, khẩu trang, bình dưỡng khí nếu nạn nhân vẫn đang trong vùng khí độc.
  * Thực hiện mở rộng các cửa, quạt thông khí, giếng,… trước khi cứu hộ giải phóng bớt khí độc và đưa nạn nhân ra khỏi vùng nhiễm độc đó.
  * Sau đó đặt nạn nhân tợi nơi thoáng khí, cởi bỏ quần áo nhiễm độc.
  * Nếu nạn nhân ngừng thở bạn cần hỗ trợ hô hấp bằng phương tiện hiện có tại chỗ.


## **Cấp cứu cho người bị chất độc xâm nhập qua da, qua mắt:**
Nếu bị chất độc xâm nhập qua da hoặc mắt thì bạn cần xử lý ngay bằng cách:
_–_ Đối với chất độc xâm nhập qua da:
  * Cởi bỏ quần áo nhiễm độc;
  * Rửa da với nhiều nước, xà phòng cho đến khi sạch. Bạn nên dùng nước ấm nếu trời lạnh;
  * Tránh để hóa chất lan ra vùng da lành hoặc lan sang người cứu hộ.


_–_ Đối với chất độc xâm nhập qua mắt:
  * Nghiêng đầu về bên mắt bị nhiễm độc. Tưới rửa mắt bằng nước sạch trong ít nhất 15 phút.
  * Nạn nhân cần phối hợp bằng cách chớp mắt trong khi rửa. Tuyệt đối không dụi mắt.


Xem thêm: [**Sơ cứu ngộ độc thực phẩm**](https://bvnguyentriphuong.com.vn/cap-cuu/so-cuu-ngo-doc-thuc-pham)
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [Xử trí khi bị ngộ độc bằng đường ăn uống](https://bvnguyentriphuong.com.vn/cap-cuu/huong-dan-so-cuu-tai-cho-mot-so-dang-ngo-doc-thuong-gap#x-tr-khi-b-ng-c-bng-ng-n-ung)
  * [Xử trí khi bị rắn độc cắn](https://bvnguyentriphuong.com.vn/cap-cuu/huong-dan-so-cuu-tai-cho-mot-so-dang-ngo-doc-thuong-gap#x-tr-khi-b-rn-c-cn)
  * [Xử trí khi bị ong đốt](https://bvnguyentriphuong.com.vn/cap-cuu/huong-dan-so-cuu-tai-cho-mot-so-dang-ngo-doc-thuong-gap#x-tr-khi-b-ong-t)
  * [Xử trí khi hít phải hơi, khí độc](https://bvnguyentriphuong.com.vn/cap-cuu/huong-dan-so-cuu-tai-cho-mot-so-dang-ngo-doc-thuong-gap#x-tr-khi-ht-phi-hi-kh-c)
  * [Cấp cứu cho người bị chất độc xâm nhập qua da, qua mắt: ](https://bvnguyentriphuong.com.vn/cap-cuu/huong-dan-so-cuu-tai-cho-mot-so-dang-ngo-doc-thuong-gap#cp-cu-cho-ngi-b-cht-c-xm-nhp-qua-da-qua-mt)



## ️ Xử trí cấp cứu đợt cấp COPD

  * [III. XỬ TRÍ CẤP CỨU](https://bvnguyentriphuong.com.vn/cap-cuu/cap-cuu-dot-cap-copd#iii-x-tr-cp-cu)


## **I. ĐẠI CƯƠNG**
– Là đợt mất bù cấp của bệnh phổi tắc nghẽn mạn tinh (COPD) gây suy hô hấp. Đặc điểm của đợt cấp là tình trạng khó thở tăng nặng thêm; ho và tăng thể tích đờm và/hoặc đờm mủ và tình trạng này thường đi kèm giảm oxy máu và tình trạng xấu đi của tăng C02 máu.
– Nguyên nhân: hay gặp nhất là nhiễm khuẩn (Haemophilus influenzae, phế cầu, Moraxella catarrhalis). Trong các đợt cấp nặng có thể gặp phế cầu kháng thuốc sinh beta-lactamase. Các nguyên nhân khác; nhiễm virus, mệt cơ hô hấp, nhồi máu phổi.
Các yếu tố sau làm tăng nguy cơ vào đợt cấp:
• Lớn tuổi
• COPD nặng (khó thở nhiều, FEV1 thấp, paO2 thấp)
• Tiền sử nhiều đợt cấp
• Dùng kháng sinh và GCS toàn thân trong năm qua
• Tăng tiết nhiều đàm
• Vi khuẩn định cư ngoài đợt cấp
• Bệnh lý đồng mắc (bệnh tim mạch, yếu cơ, trào ngược DD).
## **II. CHẨN ĐOÁN**
1. Chẩn đoán xác định
– Tiền sử của bệnh phổi tắc nghẽn mạn tính.
– Khó thở, nhịp thở nhanh > 25 chu kì/phút, có thể có tím khi suy hô hấp nặng.
– Ho khạc đờm nhiều, đờm đục (nhiễm khuẩn).
– Có thể có sốt kèm các dấu hiệu nhiễm trùng.
– Khám phổi: co kéo cơ hô hấp phụ, lồng ngực hình thùng, ran ngáy, ran rít, có thể nghe thấy ran ẩm hoặc ran nổ, rì rào phế nang giảm.
– Nhịp tim nhanh, huyết áp tăng (suy hô hấp nặng) hoặc có thể tụt (suy hô hấp nguy kịch).
– Có thể có các dấu hiệu của suy tim phải: phù, gan to, tĩnh mạch cổ nổi.
– Độ bão hòa oxy mạch (Sp02) có thể < 90%.
– Xquang: phổi sáng, cơ hoành hạ thấp, xương sườn nằm ngang, khoang liên sườn giãn rộng, hình phế quản đậm, tim hình giọt nước (hoặc tim to khi có suy tim nặng).
– Điện tim: trục phải, dày thất phải, P phế.
– Khí máu: pH máu giảm, PaC02 tăng, có thể kèm theo giảm oxy hóa máu.
2. Chẩn đoán phân biệt
– Cơn hen phế quản.
– Cơn hen tim.
– Tràn khí màng phổi ở bệnh nhân COPD.
3. Chẩn đoán mức độ nặng
• Nặng:
– Khó thở liên tục, tím.
– Nói được câu ngắn.
– Co kéo cơ hô hấp phụ rõ rệt.
– Tần số thở > 30/phút, Sp02 < 90%.
– Tần số tim > 110 chu kì/phút, huyết áp tăng.
– Pa02 < 60mmHg, PaC02 > 45mmHg, Sa02 < 90%.
• Nguy kịch:
– Rối loạn ý thức (lú lẫn, ngủ gà, thậm chí hôn mê).
– Kiệt sức cơ hô hấp: hô hấp nghịch thường, không ho được.
– Tụt huyết áp.
– Pa02 < 45mmHg, PaC02 > 70mmHg, pH < 7,30.
## **III. XỬ TRÍ CẤP CỨU**
1. Nguyên tắc xử trí
Phát hiện ngay tình trạng suy hô hấp nguy kịch để can thiệp thủ thuật theo trình tự của dây chuyền cấp cứu ABCD, dùng thuốc điều trị, theo dõi và kiểm soát tốt chức năng sống của bệnh nhân.
2. Điều trị đợt cấp COPD có suy hô hấp trung bình và nặng tại khoa cấp cứu
– Tư thế: bệnh nhân ngồi hoặc nằm ngửa tư thế đầu cao.
– Đánh giá mức độ nặng, làm khí máu và chụp Xquang phổi.
– Thở oxy: dùng oxy với lưu lượng thấp (1-2 lít/phút) hoặc qua mặt nạ venturi Fi02 30-40%. Làm lại khí máu sau 30-60 phút.
– Thuốc giãn phế quản:
+ Tăng liều hoặc dùng thường xuyên hơn.
+ Kết hợp thuốc kích thích beta-2 giao cảm (salbutamol hoặc terbutalin 5-10mg/lần) và thuốc ức chế phó giao cảm (ipratropium 0,5-1 mg/lần) khí dung, nhắc lại nếu cần thiết.
+ Cân nhắc dùng thêm thuốc nhóm methylxanthin nếu cần.
– Corticoid: 30-40mg prednisolon/ngày (hoặc corticoid khác với liều tương đương) trong 7-10 ngày, dùng đường tiêm tĩnh mạch hoặc đường uống
– Kháng sinh: chỉ định khi bệnh nhân có sốt hoặc đờm đục hoặc có bạch cầu đa nhân trung tính tăng. Dùng kháng sinh nhóm beta-lactam chống được vi khuẩn sinh beta-lactamase hoặc cephalosporin thế hệ 2, 3. Lựa chọn kháng sinh thứ hai là fluoroquinolone. Có thể dùng đường uống hoặc tiêm truyền.
– Cân nhắc chỉ định thông khí nhân tạo không xâm nhập khi:
+ Tình trạng khó thở xấu đi: thở gắng sức + tần số thở > 30 chu kì/phút.
+ Toan hô hấp cấp (pH < 7,25-7,30).
+ Tinh trạng oxy hoá máu tồi đi (tỉ lệ Pa02/Fi02 < 200).
– Theo dõi:
+ Theo dõi cân bằng dịch và tình trạng dinh dưỡng.
+ Cân nhắc heparine trọng lượng phân tử thấp đường dưới da.
– Xác định và điều trị các bệnh kèm theo (suy tim, loạn nhịp tim, nhồi máu phổi).
– Theo dõi sát tình trạng của bệnh nhân.
– Chỉ định chuyển Hồi sức tích cực:
+ Tình trạng khó thở nặng không đáp ứng với điều trị trên.
+ Rối loạn ý thức.
+ Thiếu oxy máu không cải thiện hoặc tiếp tục xấu đi: Pa02 < 40mmHg; toan hô hấp nặng hoặc xấu đi, pH < 7,25 mặc dù đã cho đủ oxy và thông khí đủ.
+ Cần thông khí xâm nhập kéo dài.
+ Rối loạn huyết động cần dùng vận mạch.
3**. Điều trị đợt cấp COPD có suy hô hấp nguy kịch**
– Thông khí nhân tạo: thường cần phải tiến hành thông khí nhân tạo xâm nhập ngay.
– Thuốc giãn phế quản nên cho theo đường tĩnh mạch với liều cao.
– Kháng sinh đường tiêm.
– Nếu có tụt huyết áp hay có suy tim nặng: dobutamin, có thể phối hợp với dopamin.
– Cân nhắc vận chuyển khoa hồi sức tích cực điều trị.
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [III. XỬ TRÍ CẤP CỨU](https://bvnguyentriphuong.com.vn/cap-cuu/cap-cuu-dot-cap-copd#iii-x-tr-cp-cu)



## ️ Ong đốt: Những dấu hiệu báo nguy hiểm!

  * [Xử trí khi bị ong đốt](https://bvnguyentriphuong.com.vn/cap-cuu/ong-dot-khi-nao-la-nguy-hiem#x-tr-khi-b-ong-t)
  * [Theo dõi dấu hiệu nguy hiểm](https://bvnguyentriphuong.com.vn/cap-cuu/ong-dot-khi-nao-la-nguy-hiem#theo-di-du-hiu-nguy-him)
  * [Phòng tránh ong đốt như thế nào?](https://bvnguyentriphuong.com.vn/cap-cuu/ong-dot-khi-nao-la-nguy-hiem#phng-trnh-ong-t-nh-th-no)


Nước ta có nhiều loại ong, các loại ong thường gây nhiễm độc là ong vò vẽ, ong bắp cày, ong mật và một số ong chưa rõ loại ở các vùng rừng núi. Các loại ong vò vẽ, ong bắp cày và một số loại ong vùng rừng núi rất độc và nguy hiểm.
Hằng năm vào mùa hè số người bị ong đốt tăng lên rất nhiều do đây là mùa có nhiều loại hoa quả như dứa, nhãn, vải… thu hút ong. Ngoài ra, do trẻ em được nghỉ học đi chơi thường hay chọc phá tổ ong và bị ong đốt.
## **Xử trí khi bị ong đốt**
  * Khi bị ong đốt cần nhanh chóng ra khỏi khu vực có ong.
  * Lấy vòi chích của ong ra bằng cách khều nhẹ hoặc dùng nhíp lấy ra vì hầu hết sau khi đốt, ong đều để lại vòi chích và túi nọc ở vết đốt trên da. Tránh nặn ép bằng tay vì có thể làm nọc độc lan ra
  * Rửa sạch vùng da bị đốt bằng xà phòng và nước ấm. Bôi dung dịch sát trùng như Povidine 10% hoặc cồn 70 độ lên vết đốt mỗi ngày 2 lần.
  * Uống nhiều nước để loại thải các độc tố.
  * Chườm lạnh lên vết đốt để giảm đau và giảm sưng.


## **Theo dõi dấu hiệu nguy hiểm**
Sau khi xử trí như trên người bị ong đốt cần được chăm sóc và theo dõi cẩn thận và cần đưa ngay nạn nhân đến đến cơ sở y tế gần nhất khi có một trong các dấu hiệu sau:
  * Số lượng vết đốt nhiều (từ 10 nốt trở lên).
  * Bị ong vò vẽ, ong bắp cày, ong rừng đốt.
  * Bị đốt vào các vùng mặt, cổ, miệng, họng (có thể gây tắc thở hoặc mù mắt).
  * Nạn nhân có các biểu hiện khó chịu như: Đau nhiều, sưng nề nhiều vùng bị đốt, mẩn ngứa, khó thở, mệt nhiều, đái ít, vàng mắt, vàng da,


## **Phòng tránh ong đốt như thế nào?**
Tránh tiếp xúc với ong nếu không cần thiết. Không chọc phá tổ ong (nhất là trẻ em hay tò mò, nghịch ngợm). Ong thường làm tổ ở nơi lộ thiên, trên những cành cây hay bụi cây hoặc quanh nhà, dưới mái nhà, do đó không nên để hoang nhà cửa khiến ong dễ đến làm tổ, thường xuyên vệ sinh, phát quang bụi rậm quanh nhà.
Khi ong bay đến, không chạy, cần đứng hoặc ngồi im và không cử động (ong sẽ không bay theo nữa). Khi đi vào rừng, đi dã ngoại cần tránh mặc quần áo màu sặc sỡ. Không dùng nước hoa, dầu gội đầu, các mỹ phẩm, có mùi thơm và ngọt sẽ thu hút ong. Không đi chân đất, không mặc quần áo quá rộng. Đội mũ có lưới che, đi găng tay, mặc quần áo dày và kín.
Xem thêm: [**10 mẹo sơ cứu có thể giúp bạn khi cần thiết**](https://bvnguyentriphuong.com.vn/cap-cuu/10-meo-so-cuu-co-the-giup-ban-khi-can-thiet)
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [Xử trí khi bị ong đốt](https://bvnguyentriphuong.com.vn/cap-cuu/ong-dot-khi-nao-la-nguy-hiem#x-tr-khi-b-ong-t)
  * [Theo dõi dấu hiệu nguy hiểm](https://bvnguyentriphuong.com.vn/cap-cuu/ong-dot-khi-nao-la-nguy-hiem#theo-di-du-hiu-nguy-him)
  * [Phòng tránh ong đốt như thế nào?](https://bvnguyentriphuong.com.vn/cap-cuu/ong-dot-khi-nao-la-nguy-hiem#phng-trnh-ong-t-nh-th-no)



## ️ Những xử trí ban đầu khi mắc Covid nhưng chưa thể nhập viện (tham khảo)

Đây là tài liệu dịch tóm lược từ tài liệu của nhóm các nhà khoa học [INDIA COVID SOS.](https://www.indiacovidsos.org/) Bài viết chỉ nhằm cung cấp thông tin chăm sóc cơ bản, không thể thay thế được tư vấn và chăm sóc của cán bộ y tế. Xin hãy liên hệ với bác sĩ của bạn, với các cán bộ y tế có trình độ đáng tin cậy, các chuyên gia đúng chuyên ngành và những người có thẩm quyền. **Trong trường hợp khẩn cấp, hãy gọi cấp cứu 115.**
Hầu hết mọi người sẽ chỉ bị bệnh nhẹ khi nhiễm COVID-19. Tuy nhiên, một số người có nguy cơ bị nặng hơn, bao gồm cả những người:
  * Trên 50 tuổi; 
  * Bị bệnh mãn tính như bệnh phổi, bệnh tim hoặc tiểu đường;
  * Có hệ thống miễn dịch suy yếu; 
  * Người đang mang thai.


Những người bị nhiễm COVID-19 có thể lây truyền sớm nhất là hai ngày trước khi có triệu chứng đầu tiên và muộn nhất là vài tuần sau khi bị bệnh.
**8 ĐIỀU CẦN LÀM KHI CHỜ TỚI BỆNH VIỆN**
  1. Ghi lại **ngày đầu tiên** xuất hiện triệu chứng.
  2. **Tự cách ly** trong phòng riêng, mở cửa sổ để tăng thông gió. Luôn đeo khẩu trang. 
  3. Uống nhiều nước, uống oresol để bù nước.
  4. Tập thể dục nhẹ nhàng. Xem các chương trình giải trí, thư giãn.
  5. Nằm nghiêng hoặc nằm sấp nếu tư thế này làm cho bạn thấy dễ chịu.
  6. Đo nhịp thở bằng cách đặt bàn tay lên ngực, thư giãn, thở đều và đếm số lần lồng ngực nhô lên trong 1 phút.
  7. Kiểm tra **độ bão hòa oxy** ít nhất 3-4 lần/ngày (bằng máy đo kẹp ngón tay, khi nghỉ ngơi). Xem cách đo ở hướng dẫn
  8. Uống Paracetamol nếu sốt **≥ 38,5 oC**.
     * _Người lớn ≤ 70 kg: 1-1,5 viên 500 mg/lần; > 70 kg: 2 viên 500 mg/lần. 3-4 lần/ngày, cách tối thiểu 4-6h/lần, không quá 4 lần/ngày._
     * _Trẻ em: 10-15 mg/kg/lần,_ cách _4-6 h/lần, không quá 4 lần/ngày. Liều tối đa tính theo cân nặng không được vượt quá 500 mg._
     * _Không uống THÊM các thuốc cảm cúm khác có chứa paracetamol hoặc acetaminophen._
     * _Người có tiền sử dị ứng với Paracetamol hoặc đang bị viêm gan không nên dùng._


_* Hướng dẫn cách đo SpO2 _
**9 DẤU HIỆU CẦN TỚI bệnh viện cấp cứu** COVID hoặc bệnh viện gần nhất ngay
  1. Độ bão hòa oxy trong máu **< 94% **
  2. Nhịp thở **> 24 lần/phút**
  3. Đau ngực, cảm giác thắt ngực
  4. Khó thở khi vận động
  5. Không thể nói đầy đủ câu
  6. Bị lẫn lộn về thời gian và địa điểm
  7. Da xanh, môi nhợt
  8. Không tự đi, không tự cầm nắm, ăn uống được
  9. Lạnh đầu ngón tay, ngón chân


**Cần cẩn trọng hơn** với người cao tuổi, người có bệnh nền, phụ nữ mang thai, suy dinh dưỡng, béo phì, thiếu máu nặng, khuyết tật, sống một mình, rối loạn tâm thần.
Trong trường hợp **có dấu hiệu bệnh Covid** và chưa tới được cơ sở y tế, tham khảo thêm các hướng dẫn sau (xin nhớ rằng những thông tin tham khảo luôn ít quan trọng hơn phác đồ điều trị do ngành y tế sở tại ban hành):
**Ngoài ra, bạn hãy tìm sự trợ giúp từ trung tâm y tế địa phương càng sớm càng tốt. **
**Tham khảo:[đường dây nóng phòng chống dịch Covid tại Tp.HCM](https://bvnguyentriphuong.com.vn/hoi-dap/so-dien-thoai-duong-day-nong-trong-phong-chong-dich-covid-tai-tphcm)**
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh

## ️ Thở máy không xâm nhập là gì? Khi nào chỉ định thở máy không xâm nhập?

  * [Thở máy không xâm nhập là gì?](https://bvnguyentriphuong.com.vn/cap-cuu/tho-may-khong-xam-nhap-la-gi-khi-nao-chi-dinh-tho-may-khong-xam-nhap#th-my-khng-xm-nhp-l-g)
  * [Khi nào cần tiến hành?](https://bvnguyentriphuong.com.vn/cap-cuu/tho-may-khong-xam-nhap-la-gi-khi-nao-chi-dinh-tho-may-khong-xam-nhap#khi-no-cn-tin-hnh)
  * [Những ai không được thở máy không xâm nhập?](https://bvnguyentriphuong.com.vn/cap-cuu/tho-may-khong-xam-nhap-la-gi-khi-nao-chi-dinh-tho-may-khong-xam-nhap#nhng-ai-khng-c-th-my-khng-xm-nhp)
  * [Phương pháp này chống chỉ định trong các trường hợp sau đây:](https://bvnguyentriphuong.com.vn/cap-cuu/tho-may-khong-xam-nhap-la-gi-khi-nao-chi-dinh-tho-may-khong-xam-nhap#phng-php-ny-chng-ch-nh-trong-cc-trng-hp-sau-y)
  * [Những rủi ro khi tiến hành thở máy không xâm nhập](https://bvnguyentriphuong.com.vn/cap-cuu/tho-may-khong-xam-nhap-la-gi-khi-nao-chi-dinh-tho-may-khong-xam-nhap#nhng-ri-ro-khi-tin-hnh-th-my-khng-xm-nhp)
  * [Quy trình tiến hành](https://bvnguyentriphuong.com.vn/cap-cuu/tho-may-khong-xam-nhap-la-gi-khi-nao-chi-dinh-tho-may-khong-xam-nhap#quy-trnh-tin-hnh)
  * [Chuẩn bị gì trước khi tiến hành?](https://bvnguyentriphuong.com.vn/cap-cuu/tho-may-khong-xam-nhap-la-gi-khi-nao-chi-dinh-tho-may-khong-xam-nhap#chun-b-g-trc-khi-tin-hnh)
  * [Quá trình thở máy không xâm nhập diễn ra như thế nào?](https://bvnguyentriphuong.com.vn/cap-cuu/tho-may-khong-xam-nhap-la-gi-khi-nao-chi-dinh-tho-may-khong-xam-nhap#qu-trnh-th-my-khng-xm-nhp-din-ra-nh-th-no)
  * [Sau khi tiến hành thở máy sẽ thế nào?](https://bvnguyentriphuong.com.vn/cap-cuu/tho-may-khong-xam-nhap-la-gi-khi-nao-chi-dinh-tho-may-khong-xam-nhap#sau-khi-tin-hnh-th-my-s-th-no)


### Thở máy không xâm nhập là gì?
Thở máy không xâm nhập hay thở máy qua mặt nạ là phương pháp thở bằng máy mà không cần tiến hành đặt nội khí quản hay mở khí quản. Với phương pháp này, bệnh nhân sẽ thở tự nhiên nhưng bị đặt một áp lực dương trong suốt chu kỳ hô hấp.
**Thở máy không xâm nhập bao gồm 2 loại:**
  * Máy thở BiPAP có hai mức áp lực dương, thay đổi giữa thì hít vào và thì thở ra.
  * Máy thở CPAP chỉ tạo một mức áp lực dương liên tục khi bơm không khí.


Áp lực này sẽ giúp nở phổi, cải thiện trao đổi khí, đảm bảo người sử dụng có thể thở đúng cách, nhận đủ lượng oxy cần thiết, cải thiện mức độ oxy trong máu, giảm lượng carbon dioxide. Từ đó giải quyết tình trạng khó thở.
Các loại máy thở không xâm nhập BiPAP và máy thở CPAP đều có kích thước nhỏ gọn, dễ sử dụng ngay tại nhà, hiệu quả tốt và chi phí thấp.
### Khi nào cần tiến hành?
Thở máy không xâm nhập là một trong những phương pháp điều trị phổ biến nhất cho chứng ngưng thở khi ngủ. Ngoài ra, bệnh nhân sẽ được chỉ định thở máy không xâm nhập khi mắc phải một số bệnh lý gây suy hô hấp nghiêm trọng, đe dọa đến tính mạng có thể kể đến như:
  * Suy hô hấp trong đợt cấp của bệnh phổi tắc nghẽn mãn tính (COPD)
  * Phù phổi cấp do suy tim sung huyết
  * Hội chứng giảm thông khí do béo phì
  * Viêm phổi
  * Bệnh hen suyễn bùng phát
  * Thở kém sau khi phẫu thuật
  * Đợt cấp của bệnh rối loạn thần kinh – cơ làm rối loạn nhịp thở
  * Suy hô hấp, giảm oxy máu ở bệnh nhân có suy giảm miễn dịch


Khi áp dụng chế độ thở này bắt buộc bệnh nhân phải tỉnh táo và cơ hô hấp còn hoạt động. Lựa chọn phương pháp này sẽ giúp làm giảm nguy cơ biến chứng và tác dụng phụ không mong muốn so với việc đặt nội khí quản hoặc mở khí quản.
Trong một số trường hợp, thở máy không xâm nhập có thể là phương pháp được sử dụng ngay sau khi rút nội khí quản sớm, để bệnh nhân vẫn hô hấp được bình thường trước khi cai máy thở hoàn toàn. Những người không muốn đặt ống thở nhưng muốn được hỗ trợ thở cũng có thể sử dụng phương pháp này.
### Những ai không được thở máy không xâm nhập?
**Nếu bệnh nhân bị khó thở nghiêm trọng, suy giảm ý thức hoặc khó nuốt, thở máy không xâm nhập có thể không phù hợp.**
### Phương pháp này chống chỉ định trong các trường hợp sau đây:
  * Ngừng tim, ngừng thở.
  * Gặp một số bất ổn về nội khoa như thiếu máu cơ tim hay rối loạn nhịp tim không kiểm soát được.
  * Không tự bảo vệ được đường thở, tổn thương cơ chế ho, không khạc đàm được, khó nuốt và có nguy cơ hít cao.
  * Tăng tiết dịch nhiều.
  * Bệnh nhân khó chịu và không hợp tác với máy thở.


Thay vào đó, bác sĩ sẽ chỉ định sử dụng máy thở xâm nhập, đưa ống thở trực tiếp xuống cổ họng (mở khí quản hoặc đặt nội khí quản).
### Những rủi ro khi tiến hành thở máy không xâm nhập
Thở máy không xâm nhập thường rất an toàn và có ít tác dụng phụ, giảm nguy cơ biến chứng hơn so với thủ thuật đặt nội khí quản hay mở khí quản. Hầu hết các vấn đề xảy ra đều do vấn đề từ mặt nạ. Cụ thể như sau:
  * Tổn thương hoặc bị kích ứng da do mặt nạ, khó chịu: đổi mặt nạ hoặc chỉnh dây đai
  * Đầy bụng nhẹ: dùng thuốc simethacone và giảm áp lực máy nếu bệnh nhân chịu đáp ứng
  * Khô miệng, khô mũi: nhỏ nước muối sinh lý, tăng thêm độ ẩm, kiểm tra giảm rò khí
  * Sung huyết mũi: dùng thuốc chống viêm không steroid (NSAIDs), thuốc chống dị ứng kháng histamin để chống phù nề
  * Loét cánh mũi: nới lỏng dây đai, thay mặt nạ mới
  * Da nổi mụn trứng cá: bôi kháng sinh tại chỗ
  * Mặt nạ có thể bị rò rỉ làm giảm áp lực: khuyên bệnh nhân ngậm chặt miệng, buộc dây đai ở cằm và đổi sang mặt nạ trùm cả mũi và miệng
  * Kích ứng mắt gây đỏ: điều chỉnh dây đai và chọn mặt nạ thích hợp
  * Đau xoang hoặc tai: giảm áp lực máy
  * Chứng lo sợ bị giam giữ Claustrophobia: dùng mặt nạ nhỏ hơn và kê thuốc an thần.


Ngoài ra, những biến chứng lớn hiếm gặp bao gồm viêm phổi hít, giảm huyết áp, khí phế thũng. Lúc này, bác sĩ sẽ hướng dẫn giảm áp lực khí, bỏ thở máy hoặc đặt dẫn lưu màng phổi tùy từng trường hợp cụ thể.
## Quy trình tiến hành
### Chuẩn bị gì trước khi tiến hành?
Trước khi tiến hành thở máy không xâm nhập, cả người chăm sóc và bệnh nhân nên làm quen với các bộ phận của máy thở. Các bộ phận của máy thở BiPAP và CPAP bao gồm: động cơ thổi khí vào ống, đường ống kết nối động cơ của máy với mặt nạ, mặt nạ dạng trùm mũi hoặc trùm cả mũi – miệng của bệnh nhân. Hãy xem xét kỹ tất cả các bộ phận, cách nối chúng khớp với nhau và hiểu hoạt động của máy.
Khi mua máy sử dụng tại nhà, bạn có thể nhờ người bán thiết bị y tế tư vấn để chọn loại máy phù hợp và hướng dẫn rõ ràng về cách sử dụng, tần suất làm sạch các bộ phận của máy. Ngoài ra, hãy thử và chọn ra loại mặt nạ có kích thước phù hợp.
Trước khi tiến hành phương pháp thở máy không xâm nhập, máy thở BiPAP hoặc CPAP, cần phải hiệu chỉnh áp lực của máy. Điều này cần bác sĩ chuyên khoa hô hấp, y tá hướng dẫn thực hiện. Bác sĩ sẽ đề ra các thông số cụ thể của máy, phù hợp với từng tình trạng bệnh khác nhau.
### Quá trình thở máy không xâm nhập diễn ra như thế nào?
Dù sử dụng tại nhà hay được chỉ định tại bệnh viện thì hãy tuân theo chỉ định của bác sĩ về thời điểm cần tiến hành. Có những người chỉ cần thở máy trong một khoảng thời gian nhất định, hoặc khi có triệu chứng thì người khác lại phải duy trì mọi lúc.
Trong quá trình thở máy, bệnh nhân sẽ phải đeo mặt nạ hoặc bịt mũi được kết nối với máy thở. Ban đầu, bạn có thể cảm thấy không thoải mái và lạ lẫm khi nhận được một luồng không khí khác đi vào phổi nhưng sẽ quen dần. Nếu bị khó thở, hãy nói ngay với nhân viên y tế hoặc người chăm sóc để điều chỉnh lại cài đặt áp suất trên máy.
Một điều quan trọng nữa là không ăn hoặc uống bất cứ thứ gì trong khi thở máy không xâm nhập, bởi nguy cơ cao có thể hít phải thức ăn hoặc chất lỏng vào phổi.
Tiếng ồn từ hầu hết các máy thở đều rất nhẹ nhàng, vì vậy nếu nó kêu lớn thì hãy gọi nhân viên y tế kiểm tra lại. Nếu bạn bị khó ngủ vì âm thanh từ máy, nên thử sử dụng nút bịt tai để ngủ ngon giấc hơn.
### Sau khi tiến hành thở máy sẽ thế nào?
Nếu các triệu chứng khó thở được cải thiện, bác sĩ sẽ giảm dần áp lực luồng khí trên máy hoặc giảm thời gian sử dụng máy thở trước khi ngừng hẳn.
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [Thở máy không xâm nhập là gì?](https://bvnguyentriphuong.com.vn/cap-cuu/tho-may-khong-xam-nhap-la-gi-khi-nao-chi-dinh-tho-may-khong-xam-nhap#th-my-khng-xm-nhp-l-g)
  * [Khi nào cần tiến hành?](https://bvnguyentriphuong.com.vn/cap-cuu/tho-may-khong-xam-nhap-la-gi-khi-nao-chi-dinh-tho-may-khong-xam-nhap#khi-no-cn-tin-hnh)
  * [Những ai không được thở máy không xâm nhập?](https://bvnguyentriphuong.com.vn/cap-cuu/tho-may-khong-xam-nhap-la-gi-khi-nao-chi-dinh-tho-may-khong-xam-nhap#nhng-ai-khng-c-th-my-khng-xm-nhp)
  * [Phương pháp này chống chỉ định trong các trường hợp sau đây:](https://bvnguyentriphuong.com.vn/cap-cuu/tho-may-khong-xam-nhap-la-gi-khi-nao-chi-dinh-tho-may-khong-xam-nhap#phng-php-ny-chng-ch-nh-trong-cc-trng-hp-sau-y)
  * [Những rủi ro khi tiến hành thở máy không xâm nhập](https://bvnguyentriphuong.com.vn/cap-cuu/tho-may-khong-xam-nhap-la-gi-khi-nao-chi-dinh-tho-may-khong-xam-nhap#nhng-ri-ro-khi-tin-hnh-th-my-khng-xm-nhp)
  * [Quy trình tiến hành](https://bvnguyentriphuong.com.vn/cap-cuu/tho-may-khong-xam-nhap-la-gi-khi-nao-chi-dinh-tho-may-khong-xam-nhap#quy-trnh-tin-hnh)
  * [Chuẩn bị gì trước khi tiến hành?](https://bvnguyentriphuong.com.vn/cap-cuu/tho-may-khong-xam-nhap-la-gi-khi-nao-chi-dinh-tho-may-khong-xam-nhap#chun-b-g-trc-khi-tin-hnh)
  * [Quá trình thở máy không xâm nhập diễn ra như thế nào?](https://bvnguyentriphuong.com.vn/cap-cuu/tho-may-khong-xam-nhap-la-gi-khi-nao-chi-dinh-tho-may-khong-xam-nhap#qu-trnh-th-my-khng-xm-nhp-din-ra-nh-th-no)
  * [Sau khi tiến hành thở máy sẽ thế nào?](https://bvnguyentriphuong.com.vn/cap-cuu/tho-may-khong-xam-nhap-la-gi-khi-nao-chi-dinh-tho-may-khong-xam-nhap#sau-khi-tin-hnh-th-my-s-th-no)



## ️ Xử trí khi dùng insulin quá liều

  * [Cách tránh nhầm lẫn khi sử dụng Insulin](https://bvnguyentriphuong.com.vn/cap-cuu/xu-tri-khi-dung-insulin-qua-lieu#cch-trnh-nhm-ln-khi-s-dng-insulin)
  * [Các triệu chứng báo hiệu sử dụng insulin quá liều](https://bvnguyentriphuong.com.vn/cap-cuu/xu-tri-khi-dung-insulin-qua-lieu#cc-triu-chng-bo-hiu-s-dng-insulin-qu-liu)
  * [Bạn nên làm gì trong tình huống sử dụng insulin quá liều?](https://bvnguyentriphuong.com.vn/cap-cuu/xu-tri-khi-dung-insulin-qua-lieu#bn-nn-lm-g-trong-tnh-hung-s-dng-insulin-qu-liu)
  * [Cách phòng tránh sử dụng Insulin quá liều](https://bvnguyentriphuong.com.vn/cap-cuu/xu-tri-khi-dung-insulin-qua-lieu#cch-phng-trnh-s-dng-insulin-qu-liu)


Toát mồ hôi, run tay, lo lắng và căng thẳng và có những dấu hiệu của nhầm lẫn là những triệu chứng cơ bản cho thấy lượng đường trong máu (glucose) giảm. Tình trạng đó có thể gọi đó là **hạ đường huyết** (hypoglycemia). Tình trạng này thường xảy ra khi bạn dùng quá nhiều insulin.
Hạ đường huyết xảy ra với nhiều bệnh nhân mắc bệnh tiểu đường. Nó có thể gây hậu quả nghiêm trọng. Tuy nhiên, phần lớn các vấn đề có liên quan đến sử dụng insulin có thể được điều chỉnh. Để hạn chế thấp nhất các tình huống xấu, bạn nên tuân thủ những nguyên tắc cơ bản dưới đây.
## **Cách tránh nhầm lẫn khi sử dụng Insulin**
Có một vài lý do dẫn tới việc sử dụng quá nhiều insulin. Điều này thường xảy ra khi:
  * Bạn đọc nhầm hướng dẫn sử dụng trên lọ (vials) hoặc ống tiêm (syringes): Khi bạn chưa quen với sản phẩm dược phẩm mới, bạn rất dễ mắc sai lầm này.
  * Sử dụng nhầm loại insulin: Ví dụ như bạn thường sử dụng 30 đơn vị loại insulin tác dụng kéo dài (long-acting insulin) và 10 đơn vị insulin tác dụng ngắn (short-acting insulin). Bạn có thể rất dễ nhầm lẫn liều dùng hai loại này với nhau.
  * Sử dụng insulin mà không dùng bữa: việc tiêm insulin (cả loại insulin tác dụng kéo dài hay ngắn hạn) thường thực hiện trước bữa ăn hoặc trong khi ăn. Hàm lượng đường trong máu của bạn tăng sau khi ăn. Khi bạn tiêm insulin mà không ăn gì sẽ dẫn tới hạ đường huyết ở mức độ nghiêm trọng và nguy hiểm.
  * Tiêm insulin vào tay hoặc chân trước khi tập thể thao: các hoạt động thể lực có thể dẫn tới giảm lượng glucose trong máu và thay đổi cách cơ thể bạn hấp thụ insulin. Bạn nên chú ý tiêm insulin vào vùng không ảnh hưởng tới việc luyện tập của bạn.


## **Các triệu chứng báo hiệu sử dụng insulin quá liều**
Khi bạn bị hạ đường huyết do sử dụng insulin quá liều, bạn có thể cảm thấy:
  * Lo lắng, bồn chồn
  * Nhầm lẫn, lú lẫn
  * Rất đói
  * Mệt mỏi
  * Khó chịu, bực nhọc
  * Toát mồ hôi
  * Run tay


Nếu lượng đường trong máu của bạn tiếp tục giảm, bạn có thể bị co giật.
## **Bạn nên làm gì trong tình huống sử dụng insulin quá liều?**
**Đừng mất bình tĩnh**. Đa số các trường hợp sử dụng insulin quá liều có thể được điều trị tại nhà. Hãy theo các bước chỉ dẫn sau đây (nếu bạn có thể):
  * Kiểm tra lượng đường trong máu: Bạn sẽ cần phải biết bạn nên xử lý từ đâu.
  * Uống một nửa cốc soda hoặc nước hoa quả có vị ngọt, ăn một chiếc kẹo cứng hoặc uống một viên đường dạng viên nén hoặc dạng gel.
  * Nếu bạn bỏ bữa, hãy ăn cái gì đó ngay. Nếu bạn ăn thứ gì đó có 15 đến 20g carbohydrates, bạn sẽ có thể tăng lượng đường trong máu.
  * Nghỉ ngơi
  * Kiểm tra lại lượng đường trong máu sau 15 đến 20 phút. Nếu chỉ số đường máu vẫn thấp, hãy dùng thêm 15 đến 20g đường chuyển hóa nhanh và ăn thứ gì đó có thể.
  * Chú ý theo dõi tình hình của bạn sau đó vài giờ. Nếu những triệu chứng trên vẫn còn, hãy kiểm tra lại lượng đường trong máu 1 giờ sau khi ăn. Hãy tiếp tục ăn thêm các thứ khác nếu lượng đường trong máu vẫn thấp.
  * Hãy nhờ tới các hỗ trợ y tế nếu lượng đường trong máu vẫn thấp sau hai giờ hoặc bạn không cảm khá hơn.
  * Đừng lo lắng về việc bạn làm tăng lượng đường trong máu quá cao trong thời gian ngắn. Việc tăng đường huyết sẽ không ảnh hưởng nhiều tới sức khỏe nhưng việc hạ đường huyết quá thấp có thể sẽ gây ảnh hưởng nghiêm trọng.
  * Nếu bạn không tỉnh táo hoặc quá nhầm lẫn, bị co giật…những người xung quanh bạn cần giúp đỡ bạn. 


Khi có người thân hoặc người quen đang điều trị với insulin, bạn nên nắm những hướng dẫn sau:
+ Nếu họ bất tỉnh, nên gọi cấp cứu 115 ngay lập tức
+ Có thể tiêm cho người bệnh glucagon. Đó là thuốc có chức năng ngược lại với insulin. Nếu người bệnh đã từng bị hạ đường huyết, khuyên họ nên hỏi bác sỹ để có dự trữ trong nhà glucagon phòng khi cần.
+ Nếu họ vẫn còn tỉnh táo để có thể tự thực hiện theo hướng dẫn, hãy giúp lấy nước hoa quả có vị ngọt để uống.
+ Nếu tình trạng của họ không được cải thiện sau một giờ điều trị tại nhà, nên gọi cấp cứu 115.
## **Cách phòng tránh sử dụng Insulin quá liều**
Dưới đây là một vài hướng dẫn để bạn có thể phòng tránh:
  * Hãy tuân thủ sơ đồ sử dụng insulin một cách nghiêm ngặt: mọi việc sẽ trở nên dễ dàng nếu bạn luôn theo đúng quy trình.
  * Hãy ăn đúng bữa: kể cả khi bạn không cảm thấy đói hãy ăn một chút bánh mì hoặc uống một cốc sữa, ăn một chút hoa quả. Không bỏ bữa khi bạn dùng insulin.
  * Hãy chuẩn bị: trong trường hợp bạn có thể bị hạ đường huyết. Hãy chuẩn bị sẵn trong túi bạn hoặc người đi cùng các viên kẹo ngọt. Bạn cũng nên mang theo trong xe hoặc trong túi du lịch cùng với bạn.
  * Hãy cho bạn bè và người thân biết về triệu chứng và cách xử trí khi bạn bị hạ đường huyết. Điều này sẽ giúp họ biết cách xử trí trong trường hợp bạn bị hạ đường huyết và rơi vào tình trạng không tỉnh táo.
  * Đeo một chiếc vòng đeo tay nhận diện báo động y tế để xác nhận rằng mình đang mắc bệnh tiểu đường và đang sử dụng insulin.


Xem thêm: [**Hạ đường huyết: Những yếu tố nguy cơ và cách xử trí**](https://bvnguyentriphuong.com.vn/khoa-kham-benh/lam-gi-khi-bi-ha-duong-huyet)
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [Cách tránh nhầm lẫn khi sử dụng Insulin](https://bvnguyentriphuong.com.vn/cap-cuu/xu-tri-khi-dung-insulin-qua-lieu#cch-trnh-nhm-ln-khi-s-dng-insulin)
  * [Các triệu chứng báo hiệu sử dụng insulin quá liều](https://bvnguyentriphuong.com.vn/cap-cuu/xu-tri-khi-dung-insulin-qua-lieu#cc-triu-chng-bo-hiu-s-dng-insulin-qu-liu)
  * [Bạn nên làm gì trong tình huống sử dụng insulin quá liều?](https://bvnguyentriphuong.com.vn/cap-cuu/xu-tri-khi-dung-insulin-qua-lieu#bn-nn-lm-g-trong-tnh-hung-s-dng-insulin-qu-liu)
  * [Cách phòng tránh sử dụng Insulin quá liều](https://bvnguyentriphuong.com.vn/cap-cuu/xu-tri-khi-dung-insulin-qua-lieu#cch-phng-trnh-s-dng-insulin-qu-liu)



## ️ Sơ cấp cứu ban đầu chấn thương cột sống

Nếu nghi ngờ chấn thương ở cổ, lưng (cột sống), không nên di chuyển nạn nhân ngay vì có thể gây di lệch ổ gẫy và chèn ép vào tủy sống gây ra liệt vĩnh viễn hoặc các biến chứng nghiêm trọng khác. Nhiều trường hợp không phát hiện được chấn thương cột sống cho đến khi phát hiện tổn thương trên X- quang.
Cần nghĩ đến chấn thương cột sống trong trường hợp tai nạn sau:
  * Có bằng chứng về chấn thương vùng đầu và/hoặc có rối loạn ý thức.
  * Ngã từ độ cao hơn 2 lần chiều cao nạn nhân.
  * Tham gia giao đấu thể thao, võ thuật.
  * Nạn nhân phàn nàn về cơn đau dữ dội vùng cổ hoặc lưng, không thể cử động cổ.
  * Chấn thương đã tác động một lực đáng kể vào vùng cổ hoặc lưng.
  * Nạn nhân than phiền về yếu, tê, liệt; đại, tiểu tiện không tự chủ; thở bụng hoặc co cứng dương vật.
  * Cổ hoặc cơ thể bị xoắn hoặc ở tư thế bất thường do thay đổi tư thế đột ngột.


Nếu nghi ngờ ai đó bị chấn thương cột sống, hãy làm theo các bước sau:
**Gọi hỗ trợ:** 115 với người sử dụng dịch vụ di động ở bất kỳ địa phương nào mà không cần mã vùng, nghe hướng dẫn từ nhân viên y tế hoặc gọi xe cứu thương nơi gần nhất.
Cố định cột sống cổ nếu nghi ngờ chấn thương cột sống cổ: Nếu nạn nhân tỉnh táo, khuyến khích họ nằm yên hoàn toàn. Dùng nẹp cột sống chuyên dụng hoặc vật liệu có sẵn: túi cát, vật nặng, khăn vải cuộn chặt để cố định hai bên cột sống cổ, lưng, dùng băng keo hoặc dây để cột lại. Đặc biệt chú ý với nẹp cổ, nẹp phải tỳ vào xương đòn, khối cơ vai, đầu trên tỳ vào xương hàm dưới ở hai bên và chẩm ở mặt sau (hình 1). Khi nạn nhân đã nằm trên ván cứng có thể đặt hai bao cát ở hai bên cổ chiều dài từ tai đến xương đòn rồi cố định bằng dây buộc ở trán, vai, cánh chậu, gối và cổ chân.
Hình 1. Cố định cột sống cổ bằng nẹp chuyên dụng và bằng túi cát
Nếu nạn nhân có biểu hiện ngừng tuần hoàn: thở ngáp, ngừng thở hoặc mất mạch, bắt đầu hồi sinh tim phổi, khai thông đường thở bằng cách dùng ngón tay nhẹ nhàng đẩy xương hàm và nâng về phía trước (hình 2a); không dùng kỹ thuật ngửa đầu nâng cằm (hình 2b).
Giữ mũ bảo hiểm: nếu nạn nhân đang đội mũ bảo hiểm, đừng cố gắng bỏ nó ra. Chỉ tháo kính chắn gió mũ bảo hiểm nếu cần tiếp cận đường thở. Bởi vì cố gắng cởi bỏ mũ bảo hiểm có thể làm nặng tình trạng chấn thương cột sống.
Nếu nạn nhân có biểu hiện nôn hay sặc dịch tiêu hóa, máu, dị vật. Tiến hành đánh giá tình trạng hô hấp, nếu nạn nhân vẫn còn thở cho nạn nhân nằm nghiêng (một người cố định đầu và cổ, người còn lại phối hợp cùng nhau nghiêng nạn nhân đảm bảo giữ cho đầu, cổ và lưng nạn nhân thẳng trong khi nghiêng nạn nhân) sau đó dùng tay móc dị vật trong miệng và đường thở (hình 3)
Hình 3. Đặt nạn nhân nằm nghiên để bảo vệ đường thở
Đa số các trường hợp chấn thương vùng ngực, lưng – thắt lưng và thắt lưng không cần phải bất động bằng nẹp ngay tại hiện trường. Nạn nhân cần được đặt lên một miếng ván cứng và cố định vào ván theo các mốc như trên khi di chuyển.
Các chi gãy cần được bất động trên và dưới ổ gãy một khớp trước khi đặt nạn nhân lên cáng để di chuyển.
Vận chuyển nhanh chóng đến bệnh viên bằng ván cứng: Cần ít nhất 4 người. Một người (A) đứng trên đầu nạn nhân, hai người đứng bên phía nạn nhân sẽ xoay lưng, một người đứng bên đối diện. (A) chỉ huy, mọi người cùng lăn nghiêng nạn nhân qua như lăn một khúc cây trong khi (A) giữ cho đầu nạn nhân xoay chuyển đồng trục với cơ thể. Nạn nhân phải được xoay nghiêng đồng trục sao cho cơ thể không bị vặn khi xoay. Sau đó đặt miếng ván cứng bên cạnh, cho nạn nhân trở lại tư thế nằm ngửa trên cáng làm sao cho nạn nhân thẳng trục (Hình 4).
Hình 4. Dịch chuyển tư thế nạn nhân
Dùng các dây cột ngang cố định nạn nhân vào ván (hình 5), dùng bao cát hoặc quần áo nạn nhân hoặc các vật dụng khác kê hai bên đầu nạn nhân. Đặt nạn nhân đã được cố định trên miếng ván cứng lên cáng và chuyển nạn nhân tới bệnh viện.
Hình 5. Cố định toàn thân nạn nhân trên nền cứng
**Những việc không nên làm ở nạn nhân bị nghi ngờ chấn thương cột sống:**
  * Không bao giờ đặt nằm sấp khi nghi ngờ có chấn thương cột sống cổ.
  * Không xốc, vác, cõng nạn nhân
  * Không chở nạn nhân bằng xe đạp, xe moto, xích lô, taxi
  * Không khiêng, di chuyển nạn nhân bằng ghế tựa thấp, võng, hoặc kê gối dưới đầu khiến cổ gập.


Xem thêm: [**Sự cần thiết của bộ dụng cụ sơ cứu**](https://bvnguyentriphuong.com.vn/cap-cuu/su-can-thiet-cua-bo-dung-cu-so-cuu)
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh

## ️ Chảy máu mũi - nguyên nhân, xử trí

**CÁC NGUYÊN NHÂN GÂY CHẢY MÁU MŨI**
**1. Toàn thân**
- Bệnh lý tim mạch: Tăng huyết áp, dị dạng mạch máu…
- Bệnh lý về máu: Suy tủy, rối loạn chức năng đông cầm máu, suy tủy…
- Bệnh lý mạn tính: Xơ gan, suy thận
- Do dùng thuốc: Thuốc chống đông máu, dùng Corticoid kéo dài
- Nguyên nhân khác: Suy giảm miễn dịch, ngộ độc, các bệnh lý di truyền
**2. Tại chỗ**
- Viêm nhiễm: Viêm mũi xoang cấp, viêm mũi xoang dị ứng đợt bội nhiễm…
- Chấn thương: Ngoáy mũi, va đập, tai nạn, sau phẫu thuật mũi xoang…
- Do khối U: U mao mạch, U hốc mũi, Ung thư vòm mũi họng, ung thư sàng hàm…
- Do dị vật: Thường gặp ở trẻ em, để lâu dẫn đến viêm loét hoại tử…
- Giải phẫu bất thường: dị dạng mạch máu, phình mạch…
- Nhiễm độc: Hít phải các hóa chất độc hại như acid, kim loại nặng…
**3. Chảy máu mũi vô căn: không****do các****nguyên nhân****kể trên.**
**XỬ TRÍ CẦM MÁU**
* Khi gặp chảy máu mũi thì nguyên tắc đầu tiên là phải dùng mọi biện pháp để cầm máu, sau đó mới đi tìm nguyên nhân, tránh để tình trạng chảy máu kéo dài sẽ ảnh hưởng đến tính mạng bệnh nhân. 
- Nhét meche: gồm nhét meche mũi trước đối với những trường hợp chảy máu nhẹ và vừa
- Nhét meche mũi sau với các trường hợp chảy máu nặng
- Đặt bóng kép
- Đốt cầm máu bằng Bipolar đối với các trường hợp chảy máu nhẹ và vừa và tiến hành dưới quan sát qua nội soi khi xác định được nguồn chảy máu.
Đối với các trường hợp chảy máu nặng, kéo dài và phức tạp, chúng tôi có những kỹ thuật chuyên sâu như: đốt động mạch bướm khẩu cái dưới nội soi hay can thiệt nút mạch đối với những trường hợp chảy máu nặng khó cầm. Đây là những kỹ thuật chuyên sâu không phải tuyến bệnh viện nào cũng làm được.
*** CÁCH XỬ TRÍ ĐỐI VỚI BỆNH NHÂN KHI CHẢY TẠI NHÀ CHƯA ĐẾN ĐƯỢC VIỆN:**
1. Bệnh nhân phải ở tư thế ngồi, tuyệt đối không nằm, đầu hơi cúi ra trước, không được ngửa đầu ra sau để tránh máu chảy xuống họng, không được nuốt máu xuống dạ dày sẽ gây kích thích nôn. Dùng ngón tay ép chặt cánh mũi bên chảy từ 5 đến 10 phút.
2. Nếu sau đó vẫn chảy tiếp tục ép chặt cánh mũi 2 bên và đến ngay cơ sở y tế gần nhất ( Không được nhét bông hay các dụng cụ khác vào mũi vì các thành phần của bông hay dụng cụ khác có thể làm kích thích chảy máu thêm).
3. Quá trình di chuyển phải có người nhà đi theo để có thể xử trí các tình huống bất thường có thể xảy ra trên quá trình di chuyển đến bệnh viện cũng như quá trình điều trị tại bệnh viện.
Có thể bạn quan tâm: [**Khối u trong mũi khiến thiếu niên thường xuyên chảy máu cam**](https://bvnguyentriphuong.com.vn/thong-tin-benh-vien/khoi-u-trong-mui-khien-thieu-nien-thuong-xuyen-chay-mau-cam)
**Bệnh viện Nguyễn Tri Phương** - Bệnh viện Đa khoa Hạng I Thành phố Hồ Chí Minh

## ️ Giận vợ đêm Noel, người chồng 17 tuổi tự đâm mình thủng gan

Khoa Cấp cứu, Bệnh viện Nguyễn Tri Phương tiếp nhận anh N. vào lúc 20 giờ 15 phút. Khi đó, bệnh nhân đã rơi vào tình trạng nguy kịch, da tái nhợt nhạt, huyết áp không đo được nữa. Con dao được rút ra khỏi người bệnh nhân.
Để kịp thời cứu anh N., tiếng chuông báo động đỏ toàn bệnh viện rung lên khẩn cấp. Chỉ 5 phút sau, bệnh nhân kịp đưa vào phòng mổ.
Xin xem toàn bộ bài viết [tại đây](https://www.phunuonline.com.vn/gian-vo-dem-noel-nguoi-chong-tu-dam-minh-thung-gan-a1424481.html)./.
**Bệnh viện Nguyễn Tri Phương** - Bệnh viện Đa khoa Hạng I Thành phố Hồ Chí Minh
  * 468 Nguyễn Trãi, Phường 8, Quận 5, Tp. Hồ Chí Minh
  * Hotline: (84-028) 39234332
  * Mạng xã hội **Facebook** : [**Bệnh viện Nguyễn Tri Phương**](https://www.facebook.com/BVNTP/)
  * Đăng ký (Subcribe) kênh **Youtube** : [https://youtube.com/bvntp](https://youtube.com/bvntp?fbclid=IwAR3q_UvPI4OZAebT1uQGPKKwk3RmCzAFLkBJm9lb7EwIz0EHtgiLhKM5bxU)
  * Quan tâm Zalo Official: [zalo.me/1744466261097093886](https://zalo.me/1744466261097093886?fbclid=IwAR3E-fLqdh-x1cYSvuDY6E5Eyxfjo5ZSs4p0hDWAyBG-ROlTkxXkXvdEWAY)



## ️ Nam thanh niên nhập viện với chùm chìa khóa cắm trên đỉnh đầu

Ngày 1/2, thông tin từ khoa Ngoại Thần kinh, Bệnh viện Nguyễn Tri Phương TPHCM cho biết, tại đây vừa phẫu thuật thành công một trường hợp hy hữu, bệnh nhân bị chiếc chìa khóa xe máy cắm sâu vào hộp sọ sau một cuộc ẩu đả trong hơi men.
Bác sĩ Chuyên khoa 2 Lê Thể Đăng, Phó trưởng khoa Ngoại Thần kinh, cho biết, thanh niên 20 tuổi được đưa đến bệnh viện cấp cứu với tình trạng chiếc chìa khóa xe máy cắm sâu vào đỉnh đầu. Thời điểm nhập viện, bệnh nhân trong tình trạng la hét hoảng loạn, đau đầu dữ dội, máu chảy từ vết thương lượng nhiều.
Khai thác bệnh sử của bác sĩ qua lời kể của thân nhân, sau nhậu say, bệnh nhân xảy ra xô xát, lời qua tiếng lại với các thành viên trong nhóm. Trong lúc các bên đang mất kiểm soát hành vi, nam thanh niên bị một người đánh vào đầu bằng chùm chìa khóa. Trên phim chụp cắt lớp vi tính sọ não, MSCT-scan sọ não, phần kim loại của chiếc chìa khóa cắm vào đỉnh đầu xuyên qua xương sọ, rách màng não và xuất huyết trong não.
Nhận định đây là một tình trạng nguy hiểm cho bệnh nhân, chìa khóa chỉ di lệch một chút sẽ dẫn đến tổn thương các cấu trúc quan trọng của não bộ gây khiếm khuyết thần kinh. Bác sĩ khoa Ngoại Thần kinh đã thực hiện cuộc phẫu thuật cấp cứu. Mất khoảng 2 giờ trong phòng mổ ê kíp đã lấy thành công chiếc chìa khóa ra ngoài, cầm máu và xử lý phần não dập xuất huyết cho bệnh nhân. Sau phẫu thuật tình trạng bệnh nhân đã ổn định, tri giác, sức khỏe bình phục tốt.
Toàn bộ bài viết xin xem [tại đây](https://dantri.com.vn/suc-khoe/nam-thanh-nien-nhap-vien-voi-chum-chia-khoa-cam-tren-dinh-dau-20210201225327159.htm?gidzl=enJn1SL2-JUX2lO7mrxwCgW8y0pL2_eplbsb1jbTh3Io3wCAs5ggQha4erdT0QvdwbQWLZXJPZu6mKBtCG)./.
**Bệnh viện Nguyễn Tri Phương** - Bệnh viện Đa khoa Hạng I Thành phố Hồ Chí Minh
  * 468 Nguyễn Trãi, Phường 8, Quận 5, Tp. Hồ Chí Minh
  * Hotline: (84-028) 39234332
  * Mạng xã hội **Facebook** : [**Bệnh viện Nguyễn Tri Phương**](https://www.facebook.com/BVNTP/)
  * Đăng ký (Subcribe) kênh **Youtube** : [https://youtube.com/bvntp](https://youtube.com/bvntp?fbclid=IwAR3q_UvPI4OZAebT1uQGPKKwk3RmCzAFLkBJm9lb7EwIz0EHtgiLhKM5bxU)
  * Quan tâm Zalo Official: [zalo.me/1744466261097093886](https://zalo.me/1744466261097093886?fbclid=IwAR3E-fLqdh-x1cYSvuDY6E5Eyxfjo5ZSs4p0hDWAyBG-ROlTkxXkXvdEWAY)



## ️ Dự phòng và xử trí say nắng say nóng

  * [Các biện pháp phòng chống say nắng, say nóng](https://bvnguyentriphuong.com.vn/cap-cuu/du-phong-va-xu-tri-say-nang-say-nong#cc-bin-php-phng-chng-say-nng-say-nng)
  * [Xử trí say nắng, say nóng](https://bvnguyentriphuong.com.vn/cap-cuu/du-phong-va-xu-tri-say-nang-say-nong#x-tr-say-nng-say-nng)


Xem lại: [**Tổng quan về say nắng, say nóng**](https://bvnguyentriphuong.com.vn/cap-cuu/say-nang-say-nong)
## **Các biện pháp phòng chống say nắng, say nóng**
- Khi phải ra ngoài khi trời nắng nóng, bạn cần che kín cơ thể bằng cách mặc quần áo rộng, nhẹ và sáng màu, đội mũ rộng vành, sử dụng kem chống nắng.
- Uống đầy đủ nước khi trời nắng nóng hoặc phải lao động nặng dưới ánh nắng mặt trời gay gắt. Thường xuyên uống nước dù chưa cảm thấy khát. Có thể ống nước có pha một chút muối hoặc uống dung dịch oresol, nước trái cây, tránh xa nước ngọt có ga, đồ uống năng lượng.
- Không làm việc quá lâu dưới trời nắng hoặc làm việc trong môi trường nóng bức, tránh các hoạt động thể lực quá sức. Nên nghỉ ngơi định kỳ sau khoảng 45 phút hay 1 tiếng làm việc liên tục ở nơi nắng nóng, nghỉ ngơi ở nơi thoáng mát từ 10 - 15 phút.
- Luôn trang bị đầy đủ các thiết bị chống nắng, chống nóng khi lao động, làm việc dưới trời nắng như quần áo bảo hộ lao động, mũ bảo hộ, nón rộng vành, kính râm...
- Làm thoáng mát môi trường làm việc, đặc biệt ở các công xưởng, hầm, lò... rất có ý nghĩa trong việc phòng chống bị say nắng, say nóng.
- Khi vừa đi nắng về, đây là thời điểm cơ thể tiết ra nhiều mồ hôi, nhiệt cơ thể độ cao, nếu tắm ngay sẽ làm thay đổi thân nhiệt đột ngột, rất nguy hiểm, có thể dẫn đến đột quỵ.
- Vào mùa nắng nóng, chúng ta cần uống nhiều nước, ăn các loại thức ăn mát, rau củ quả chứa nhiều kali như: rau đay, mồng tơi, rau má, cà chua..., mặc quần áo rộng rãi, thoáng mát, dễ thoát mồ hôi.
- Không được để trẻ em hoặc bất kỳ ai trong xe hơi đỗ, tắt máy, trong thời tiết nắng nóng dù chỉ để trong thời gian ngắn, do nhiệt độ trong xe hơi có thể tăng hơn 11 độ C chỉ trong 10 phút.
## **Xử trí say nắng, say nóng**
**Một điều phải nhấn mạnh** là khoảng thời gian 1 giờ sau khi bị say nắng, say nóng ở mức độ nặng được gọi là “thời điểm vàng” để cấp cứu, bởi nếu cấp cứu ngay trong khoảng thời gian này thì hiệu quả gần như đạt 100%. Ngược lại, nếu chậm cấp cứu, làm mát cho bệnh nhân trong vòng 3 giờ sau khi bị đột quỵ não do nóng thì 100% nạn nhân sẽ tử vong. Chính vì thế, trong cấp cứu say nắng, say nóng phải hết sức chú ý đến việc cấp cứu ban đầu tại hiện trường. Bằng mọi biện pháp phải hạ nhanh nhiệt độ cơ thể trong “thời điểm vàng”. Đây là điều kiện tiên quyết để bệnh nhân thoát khỏi tử vong do say nắng, say nóng. Chỉ chuyển bệnh nhân về tuyến sau hoặc chuyển tới cơ sở hồi sức cấp cứu gần nhất nếu các biện pháp cấp cứu ban đầu không hiệu quả, không cải thiện nhanh về lâm sàng. Chú ý trên đường vận chuyển vẫn phải duy trì các biện pháp cấp cứu cơ bản, trong đó lưu ý các biện pháp hạ thân nhiệt.
Vì vậy khi gặp người bị say nắng, say nóng, chúng ta phải thực hiện các bước như sau:
1. Đưa bệnh nhân vào chỗ mát, thoáng khí (chỗ bóng râm, lên xe mát hay nhà mát, …) đồng thời gọi hỗ trợ, đặc biệt gọi cấp cứu hỗ trợ
2. Khai thông đường thở, hô hấp nhân tạo và ép tim ngoài lồng ngực nếu người bệnh hôn mê, không bắt được mạch
3. Áp dụng ngay lập tức các biện pháp làm mát để hạ nhiệt độ của cơ thể
- Đo nhiệt độ cơ thể nếu có nhiệt kế
- Cởi bỏ quần áo và áp nước ấm lên người bệnh nhân sau đó dùng quạt để tăng quá trình bốc hơi ( bệnh nhân nên nằm nghiêng hoặc được đỡ ở tư thế tay chống gối để bề mặt da có thể hứng được nhiều gió càng tốt.
4. Đắp khăn lạnh, hoặc áp gói nước đá vào nách, bẹn, cổ
5.Cho uống nhiều nước hoặc dung dịch điện giải nếu bệnh nhân tỉnh táo, có thể uống được
6.Chuyển bệnh nhân bằng xe điều hòa hoặc phải mở cửa sổ, quá trình vận chuyển tiếp tục làm mát nhiệt độ bệnh nhân
Hình minh họa xử trí khi gặp người bệnh bị say nắng, say nóng
Xem thêm: [**Sốc nhiệt**](https://bvnguyentriphuong.com.vn/dieu-duong/nhung-trieu-chung-cua-soc-nhiet)
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [Các biện pháp phòng chống say nắng, say nóng](https://bvnguyentriphuong.com.vn/cap-cuu/du-phong-va-xu-tri-say-nang-say-nong#cc-bin-php-phng-chng-say-nng-say-nng)
  * [Xử trí say nắng, say nóng](https://bvnguyentriphuong.com.vn/cap-cuu/du-phong-va-xu-tri-say-nang-say-nong#x-tr-say-nng-say-nng)



## ️ Sơ cấp cứu rắn độc cắn

1. Cách sơ cứu ban đầu khi bị rắn cắn: 
Sau khi bị rắn độc cắn cần sơ cứu ngay, tiến hành trước khi vận chuyển bệnh nhân đến bệnh viện. Có thể người khác giúp đỡ hoặc do bản thân bệnh nhân tự làm. 
1.1. Mục tiêu của sơ cứu: 
• Loại bỏ bớt nọc độc và làm chậm sự dịch chuyển của nó từ vết cắn xâm nhập vào trong cơ thể.
• Bảo vệ tính mạng của bệnh nhân, ngăn chặn và xử trí sớm các biến chứng trước khi bệnh nhân đến được cơ sở y tế.
• Vận chuyển bệnh nhân một cách nhanh nhất, an toàn nhất đến cơ sở y tế.
• Không gì hại thêm cho bệnh nhân. 
1.2. Các bước sơ cứu nên làm: 
• Trấn an người bệnh. 
• Không để bệnh nhân tự đi lại. Bất động chân, tay bị cắn bằng nẹp (vì vận động làm cho nọc độc xâm nhập vào trong cơ thể nhanh hơn). 
• Cởi bỏ đồ trang sức ở chân, tay bị cắn (vì có thể gây chèn ép khi vùng đó bị sưng nề). 
• Áp dụng biện pháp băng ép bất động với một số loại rắn hổ (rắn cạp nong, cạp nia, hổ mang chúa, rắn biển và một số giống rắn hổ mang thường), băng ép bất động để làm chậm sự xuất hiện triệu chứng liệt. 
- Dùng các băng chun giãn, băng vải hoặc tự tạo từ khăn, quần áo. Băng tương đối chặt nhưng không quá mức (còn sờ thấy động mạch đập). Bắt đầu băng từ ngón chân, tay đến hết toàn bộ chân, tay bị cắn. Dùng nẹp cứng (nẹp, miếng gỗ, que, miếng bìa cứng,...) cố định chân, tay bị cắn. 
- Không băng ép khi rắn lục cắn vì có thể làm vết thương nặng thêm.
• Có thể chích nặn rửa vết cắn dưới vòi nước sạch với xà phòng rồi sát trùng. 
• Nếu bệnh nhân khó thở thì hô hấp nhân tạo (hà hơi thổi ngạt hoặc bằng phương tiện y tế có tại chỗ như bóp bóng, máy thở xách tay,..). Nếu có dấu hiệu ngừng tuần hoàn thì tiến hành hồi sinh tổng hợp ngay tại chỗ và chờ nhân viên y tế đến. 
• Vận chuyển bệnh nhân bằng phương tiện đến cơ sở y tế đồng thời duy trì băng ép, bất động, để vùng bị cắn thấp hơn vị trí của tim, nếu ở chân, tay thì có thể để thõng tay hoặc chân.… 
• Chú ý: Bất cứ trường hợp nào bị rắn cắn, ngay cả khi xác định là rắn lành, đều cần xử trí và theo dõi tại bệnh viện như trường hợp rắn độc cắn, ít nhất trong 12 giờ đầu. Nếu trễ sau 24-48 giờ, kết quả điều trị rất kém hoặc không hiệu quả. 
1.3. Không sử dụng các biện pháp sau: 
• Garô: Garô là biện pháp làm tắc nghẽn hoàn toàn động mạch. Nó gây đau và rất nguy hiểm và không thể duy trì lâu (không quá 40 phút), chân tay rất dễ bị thiếu máu nguy hiểm. Nhiều trường hợp sau đó phải cắt cụt chân tay vì garô. Ngoài ra khi đến bệnh viện, bác sĩ tháo băng garo ra thì chất độc sẽ cùng lúc ùa về tim khiến bệnh nhân bị sốc, đe dọa tính mạng. 
• Trích, rạch, châm, chọc tại vùng vết cắn: các biện pháp này không có lợi ích, rõ ràng gây hại thêm cho bệnh nhân (tổn thương thêm mạch máu, dây thần kinh,...nhiễm trùng nặng thêm). 
• Hút nọc độc: Không có lợi ích. 
• Chườm đá (chườm lạnh): Đã được chứng minh là có thể gây hại. 
• Sử dụng các loại thuốc dân gian, cổ truyền, chữa bằng mẹo: Không có ích lợi, khi đắp có thể gây nhiễm trùng, khi uống có thể gây hại cho nạn nhân. 
• Cố gắng bắt hoặc giết rắn: Nếu rắn đã chết hoặc bắt được rắn phải đem cùng với bệnh nhân đến bệnh viện để nhận dạng.
2. Đề phòng rắn cắn 
• Biết về loại rắn trong vùng, biết khu vực rắn thích sống hoặc ẩn nấp. 
• Đi ủng, dày cao cổ và quần dài, đặc biệt khi đi trong đêm tối, đội thêm mũ rộng vành nếu đi trong rừng hoặc đi ở khu vực nhiều cây cỏ. 
• Càng tránh xa rắn thì càng tốt, đầu rắn đã chết vẫn có thể cắn người. Không bắt rắn, đuổi hoặc dồn ép rắn trong khu vực khép kín. 
• Không sống ở gần các nơi rắn thích cư trú hoặc thích đến như các đống gạch vụn, đống đỏ nát, đống rác, nơi nuôi các động vật của gia đình. 
• Để tránh bị rắn biển cắn, người dân không nên bắt rắn ở trong lưới hoặc dây câu. 
• Dùng đèn nếu ở trong bóng tối hoặc vào ban đêm.
Xem thêm: [**10 mẹo sơ cứu có thể giúp bạn khi cần thiết**](https://bvnguyentriphuong.com.vn/cap-cuu/10-meo-so-cuu-co-the-giup-ban-khi-can-thiet)
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh

## ️ Sơ cứu ngộ độc thực phẩm

  * [Nhóm có nguy cơ cao bao gồm](https://bvnguyentriphuong.com.vn/cap-cuu/so-cuu-ngo-doc-thuc-pham#nhm-c-nguy-c-cao-bao-gm)
  * [Việc cần làm khi bạn bị ngộ độc thực phẩm](https://bvnguyentriphuong.com.vn/cap-cuu/so-cuu-ngo-doc-thuc-pham#vic-cn-lm-khi-bn-b-ng-c-thc-phm)
  * [Gọi 115 hoặc gọi trợ giúp y tế khẩn cấp nếu](https://bvnguyentriphuong.com.vn/cap-cuu/so-cuu-ngo-doc-thuc-pham#gi-115-hoc-gi-tr-gip-y-t-khn-cp-nu)


## **Triệu chứng**
Các triệu chứng của ngộ độc thực phẩm thay đổi tùy vào nguồn ô nhiễm, và tùy theo bạn có mất nước hoặc có hạ huyết áp hay không.
Nhìn chung triệu chứng thường bao gồm:
  * Tiêu chảy.
  * Buồn nôn.
  * Đau bụng.
  * Nôn ói (đôi khi).
  * Mất nước (đôi khi).


Khi bị mất nước nặng, bạn có thể cảm thấy:
  * Chóng mặt hoặc muốn xỉu, đặc biệt khi đứng dậy.
  * Tim đập nhanh.


Khả năng ngộ độc thực phẩm sau khi ăn tùy thuộc vào tác nhân gây bệnh, số lượng ăn vào, tuổi tác và sức khỏe của bạn.
## **Nhóm có nguy cơ cao bao gồm**
  * **Người lớn tuổi.** Khi bạn già đi, hệ thống miễn dịch không còn đáp ứng với nhiễm trùng một cách nhanh chóng và hiệu quả như khi còn trẻ.
  * **Trẻ sơ sinh và trẻ nhỏ.** Hệ thống miễn dịch của trẻ em chưa phát triển đầy đủ.
  * **Người có bệnh mạn tính.** Việc mắc bệnh mạn tính, như bệnh tiểu đường hoặc AIDS hoặc đang được hóa trị hay xạ trị ung thư sẽ làm giảm đáp ứng miễn dịch của bạn.


## **Việc cần làm khi bạn bị ngộ độc thực phẩm**
  * **Gây nôn** (nếu người bệnh không có biểu hiện nôn): Để hạn chế độc tố ngấm vào cơ thể, biện pháp sơ cứu đầu tiên nên làm là kích thích để người bị ngộ độc nôn những thức ăn trong dạ dày ra ngoài. Có thể dùng tay đã rửa sạch đặt vào lưỡi người bệnh để kích thích gây nôn.
  * Nghỉ ngơi và uống **nhiều chất lỏng**.
  * **Không** sử dụng thuốc chống tiêu chảy vì thuốc có thể làm chậm việc đào thải vi khuẩn khỏi cơ thể.


Ngộ độc thực phẩm thường tự cải thiện trong vòng 48 giờ. Tuy nhiên, bạn hãy gọi cho bác sĩ nếu bệnh kéo dài hơn 2 hoặc 3 ngày hoặc nếu bạn đi đại tiện có máu.
Có thể bổ sung điện giải, thường dùng và dễ kiếm là oresol, để dùng oresol an toàn, cần chú ý:
- Cần đọc kĩ hướng dẫn cách dùng, liều lượng... nếu hướng dẫn pha với 200 ml thì cần pha chính xác 200 ml vì như thế sẽ đạt nồng độ thẩm thấu phù hợp, pha quá ít hay nhiều nước hơn cũng sẽ nguy hiểm, thậm chí tử vong.
- Chỉ sử dụng dung dịch đã pha trong 24 giờ, bảo quản kĩ tránh nhiễm bẩn, bởi, dung dịch có thể bị nhiễm khuẩn nếu để quá lâu và gây nguy hiểm cho người bệnh.
- Không chia nhỏ gói oresol rồi pha vì rất có thể các thành phần không đồng nhất và dễ gây nhầm lẫn thể tích khi pha.
- Không đun sôi dung dịch đã pha vì khi đó sẽ làm mất tác dụng của thuốc, bay hơi làm tăng độ thẩm thấu.
- Không pha với nước khoáng vì nước này có sẵn thành phần khoáng sẽ làm sai lệch nồng độ, nên pha oresol với nước đun sôi để nguội.
- Khi nhiều người cùng bị ngộ độc, không cho các người bệnh uống chung nước, uống chung oresol vì có thể làm tăng tình trạng của những người bị nhẹ
## **Gọi 115 hoặc gọi trợ giúp y tế khẩn cấp nếu**
  * **Bạn có các triệu chứng nghiêm trọng,** ví dụ như bệnh tiến triển từ đi tiêu phân nước sang đi tiêu đầy máu trong vòng 24 giờ.
  * **Bạn thuộc nhóm nguy cơ cao.**
  * **Bạn nghi ngờ****bị****ngộ độc Botulin****(botulism poisoning).** Ngộ độc Botulin là một loại ngộ độc thực phẩm có khả năng gây tử vong. Độc tố Botulin thường được tìm thấy trong thực phẩm đóng hộp, đặc biệt là đậu xanh và cà chua. Triệu chứng của ngộ độc thường bắt đầu từ 12 đến 36 giờ sau khi ăn thực phẩm bị ô nhiễm, có thể bao gồm đau đầu, hoa mắt, yếu cơ và cuối cùng là liệt. Một số người còn biểu hiện buồn nôn và nôn ói, táo bón, bí tiểu, khó thở, và khô miệng. Những triệu chứng này đòi hỏi chăm sóc y tế ngay lập tức.


Xem thêm: [**10 mẹo sơ cứu có thể giúp bạn khi cần thiết**](https://bvnguyentriphuong.com.vn/cap-cuu/10-meo-so-cuu-co-the-giup-ban-khi-can-thiet)
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [Nhóm có nguy cơ cao bao gồm](https://bvnguyentriphuong.com.vn/cap-cuu/so-cuu-ngo-doc-thuc-pham#nhm-c-nguy-c-cao-bao-gm)
  * [Việc cần làm khi bạn bị ngộ độc thực phẩm](https://bvnguyentriphuong.com.vn/cap-cuu/so-cuu-ngo-doc-thuc-pham#vic-cn-lm-khi-bn-b-ng-c-thc-phm)
  * [Gọi 115 hoặc gọi trợ giúp y tế khẩn cấp nếu](https://bvnguyentriphuong.com.vn/cap-cuu/so-cuu-ngo-doc-thuc-pham#gi-115-hoc-gi-tr-gip-y-t-khn-cp-nu)



## ️Xử trí khi điện giật

  * [Triệu chứng vào những tác động khác của dòng điện](https://bvnguyentriphuong.com.vn/cap-cuu/xu-tri-khi-dien-giat#triu-chng-vo-nhng-tc-ng-khc-ca-dng-in)
  * [Khi nào cần đi đến bác sĩ](https://bvnguyentriphuong.com.vn/cap-cuu/xu-tri-khi-dien-giat#khi-no-cn-i-n-bc-s)


Xem lại: [**Những điều cần biết khi bị giật điện**](https://bvnguyentriphuong.com.vn/dieu-duong/nhung-dieu-can-biet-ve-dien-giat)
**Có nhiều yếu tố góp phần vào mức độ nghiêm trọng của tổn thương do điện giật, bao gồm:**
  * Cường độ dòng điện
  * Loại dòng điện – một chiều hay xoay chiều.
  * Dòng điện truyền qua bộ phận nào của cơ thể.
  * Nạn nhân bị điện giật trong bao lâu
  * Mức độ kháng điện.


## **Triệu chứng vào những tác động khác của dòng điện**
Các triệu chứng của bị điện giật thì phụ thuộc vào nhiều yếu tố. Các tổn thương do dò điện thấp thường thì chỉ ngoài da, trong khi tổn thương do tiếp xúc lâu với dòng điện thì có thể gây ra bỏng nặng hơn.
Tổn thương thứ phát do điện giật cũng có thể xảy ra. Nạn nhân có thể có phản xạ giật mạnh người ra khỏi dòng điện, dẫn đến việc mất thăng bằng hay ngã, từ đó có thể là tổn thương một bộ phận khác trên cơ thể.
**Các tác dụng phụ ngắn**
Tùy thuộc vào mức độ nặng, những tổn thương nguyên phát do điện giật có thể có:
  * Bỏng
  * Rối loạn nhịp tim
  * Co giật.
  * Cảm giác tê ngứa
  * Ngất
  * Đau đầu.


Một vài người có thể chỉ có cảm giác khó chịu mà không có tổn thương nào về cơ thể có thể thấy được, nhưng cũng có những nạn nhân đau rất nhiều và có tổn thương cơ thể thấy rõ.
Những nạn nhân không có tổn thương đáng kể hay nhịp tim bất thường trong vòng 24-48 giờ sau khi bị điện giật, thì thường sẽ không tiến triển thêm.
**Các tác dụng phụ nghiêm trọng khác bao gồm:**
  * Hôn mê
  * Đau tim
  * Ngưng hô hấp


**Tác dụng phụ mạn tính**
Một nghiên cứu chỉ ra rằng những người bị điện giật thì thường không gặp những vấn đề về tim mạch trong vòng 5 năm sau khi gặp tai nạn, so với những người không bị.
Một người có thể gặp các triệu chứng khác nhau, từ tâm ly đến thần kinh và các triệu chứng của cơ thể.
**Các triệu chứng bao gồm:**
**Tâm lý** |  **Thần kinh** |  **Cơ thể**  
---|---|---  
Rối loạn khủng hoảng hậu chấn thương |  Mất trí nhớ  
Trầm cảm |  Khó tập trung |  Mệt mỏi  
Lo âu |  Cảm giác ngứa |  Đau đầu  
Mất ngủ |  Ngất |  Vận động giới hạn  
Dễ mất tập trung |  Mất thăng bằng |  Co cơ  
Mất trí nhớ |  Đau thần kinh tọa |  Cứng khớp  
Các cơn hoảng loạn |  Rối loạn phối hợp vận động |  Đổ mồ hôi đêm  
Những nạn nhân bị bỏng điện cần liên hệ ngay với trợ giúp y tế.
## **Sơ cứu**
Đối với những các dòng điện nhỏ, ví dụ như các vật điện gia dụng, thì thường không cần phải điều trị y tế. Tuy nhiên, những nạn nhân cũng nên gặp bác sĩ sau khi bị điện giật.
Nếu như nạn nhân bị giật do dòng điện cao thế, cần gọi cấp cứu ngay lập tức
Trong các trường hợp bị điện giật nặng, trung tâm quản lý và phòng chống bệnh tật (CDC) đưa ra các lời khuyên sau:
  * Không được chạm vào nạn nhân do có thể họ đang tiếp xúc trực tiếp với dòng điện.
  * Gọi cấp cứu hoặc nhờ người khác gọi giúp.
  * Nếu an toàn, ngắt nguồn điện ngay. Nếu không an toàn, sử dụng một vật cách điện (gỗ, bìa giấy, hay nhựa) để di chuyển nguồn điện ra xa.
  * Khi đã tách nạn nhân ra khỏi nguồn điện, kiểm tra mạch của nạn nhân và nhìn xem họ còn thở không. Nếu như nạn nhân thở nông, thực hiện (CPR) ngay lập tức.
  * Nếu như nạn nhân bất tỉnh và tím tái, cho nạn nhân nằm xuống, đầu thấp hơn mình và giữ chân bệnh nhân nâng lên cao.
  * Không nên chạm vào vết bỏng hay di dời quần áo bị cháy.


**Các bước thực hiện CPR:**
  * Để 2 tay lên chồng lên nhau và đặt lên giữa ngực nạn nhân. Dùng trọng lượng cơ thể, ấn mạnh và nhanh xuống, duy trì lực ấn xuống sâu khoảng 4-5 cm. Mục tiêu là phải đạt được 100 lần nhấn trong vòng 60 giây.
  * Hà hơi thổi ngạt. Phải chắc chắn rằng họng nạn nhân trống, ngửa cổ nạn nhân ra sau, nâng cằm, kẹp chặt mũi, sau đó thổi một hơi vào miệng nạn nhân đủ để lồng ngực phồng lên. Thổi hai hơi và tiếp tục thực hiện nhấn lồng ngực.
  * Lặp lại quá trình trên cho đến khi trợ giúp y tế tới nơi hay cho tới khi nạn nhân thở trở lại.


## **Chẩn đoán**
Tại khoa cấp cứu, bác sĩ sẽ thăm khám kỹ càng để đánh giá khả năng có tổn thương ở ngoài hay là bên trong cơ thể hay không. Các xét nghiệm có thể thực hiện là:
  * Điện tâm đồ (ECG) để theo dõi nhịp tim.
  * **[Chụp cắt lớp điện toán (CT)](https://bvnguyentriphuong.com.vn/chan-doan-hinh-anh/chup-cat-lop-vi-tinh-ct-scan)** để khảo sát não, cột sống và lồng ngực.
  * Xét nghiệm máu.
  * Thử thai (chỉ dùng cho phụ nữ mang thai)


## **Khi nào cần đi đến bác sĩ**
Không phải ai bị điện giật cũng cần phải được đưa đi cấp cứu. Hãy làm theo chỉ dẫn sau đây:
  * Gọi cấp cứu nếu như nạn nhân bị giật bởi dòng điện hơn 500 V.
  * Gọi cấp cứu nếu như nạn nhân bị giật bởi dòng điện thấp nhưng bị bỏng. Không nên cố gắng điều trị vết bỏng tại nhà.
  * Nếu như nạn nhân bị giật điện nhưng không bị bỏng, nên đi khám bác sĩ để chắc chắn không có tổn thương nào xảy ra.


## **Tiên lượng**
Tổn thương do điện giật không phải lúc nào cũng thấy được. Tùy thuộc vào hiệu điện thế của dòng điện mà tổn thương có thể nhẹ cho đến gây ra tử vong. Tuy nhiên, nếu như nạn nhân vẫn còn sống sau khi bị điện giật thì vẫn nên đi khám ở các cơ sở y tế để chắc chắn rằng không có thương tổn nào.
Nếu như phát hiện hay nghĩ rằng có ai đó vừa bị điện giật nặng thì nên gọi cấp cứu ngay. Kể cả khi bị điện giật nhẹ thì vẫn nên đi khám lại.
## **Tóm tắt**
Điện giật và thương tổn chúng gây ra có nhiều cấp độ từ nhẹ đến rất nặng.
Nhiều tai nạn điện giật xảy ra ngay tại nhà, nên phải cẩn thận kiểm tra các thiết bị điện gia dụng trong nhà thường xuyên để có thể phát hiện hỏng hóc.
Đối với những người làm việc trong môi trường liên quan đến lắp ráp các hệ thống điện thì cần nên đặc biệt cẩn thận và luôn tuân theo các quy định an toàn.
Nếu như có ai đó vừa bị điện giật xong thì nên được sơ cứu ngay nếu như an toàn, và gọi cấp cứu ngay sau đó.
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [Triệu chứng vào những tác động khác của dòng điện](https://bvnguyentriphuong.com.vn/cap-cuu/xu-tri-khi-dien-giat#triu-chng-vo-nhng-tc-ng-khc-ca-dng-in)
  * [Khi nào cần đi đến bác sĩ](https://bvnguyentriphuong.com.vn/cap-cuu/xu-tri-khi-dien-giat#khi-no-cn-i-n-bc-s)



## ️ Say nắng, say nóng

  * [Thế nào là say nắng, say nóng](https://bvnguyentriphuong.com.vn/cap-cuu/say-nang-say-nong#th-no-l-say-nng-say-nng)
  * [Biểu hiện khi bị say nắng, say nóng](https://bvnguyentriphuong.com.vn/cap-cuu/say-nang-say-nong#biu-hin-khi-b-say-nng-say-nng)
  * [Những yếu tố thuận lợi dễ bị say nắng say nóng](https://bvnguyentriphuong.com.vn/cap-cuu/say-nang-say-nong#nhng-yu-t-thun-li-d-b-say-nng-say-nng)


## **Thế nào là say nắng, say nóng**
Khi chịu tác động của gánh nặng nhiệt, cơ thể người có các phản ứng đáp ứng và huy động các cơ chế điều nhiệt, nếu quá tải nhiệt gia tăng quá mức sẽ gây ra tổn thương đối với cơ thể. Tổn thương do nắng – nóng mà điển hình là hội chứng say nắng, say nóng là tình trạng rối loạn cân bằng nước, điện giải toàn thân, rối loạn điều hòa thân nhiệt dẫn đến những rối loạn bệnh lý khác.
**Say nóng** là tình trạng tăng than nhiệt do nhiệt độ môi trường tăng cao và/ hoặc tăng hoạt động thể lực quá mức, vượt quá khả năng điều hòa của trung khu điều nhiệt làm trung khi điều nhiệt bị rối loạn mất kiểm soát. Say nóng có thể phát triển thành say nắng (sốc nhiệt).
**Say nắng** hay còn gọi là sốc nhiệt ( heat troke) là tình trạng tăng than nhiệt nghiêm trọng (>40 độ C) kèm theo rối loạn hoạt động của các cơ quan như thần kinh, tuần hoàn, hô hấp do tác động của nắng nóng và/ hoặc các hoạt động thể lực quá mức. Say nắng luôn đi kèm với say nóng. Sốc nhiệt thường được chia thành 2 thể:
Sốc nhiệt kinh điển xảy ra do nhiệt độ môi trường quá cao > 40 độ C, kèm theo hoặc không kèm theo nắng gắt kéo dài liên tục.
Sốc nhiệt do gắng sức thường xảy ra ở người trẻ, khỏe mạnh, các vận động viên điền kinh gắng sức quá mức trong thi đấu và tập luyện.
Trên thực tế, có thể phân biệt sự khác nhau giữa say nắng và say nóng. Say nóng thường diễn ra từ từ, nhiệt độ trung bình cơ thể tăng dần, có thể quan sát nhận ra được các biểu hiện căng thẳng nhiệt và thân nhiệt thường không vượt quá 40 độ C. Ngược lại say nắng thường diễn ra đột ngột, không có dấu hiệu báo trước, thường kèm theo tổn thương thần kinh nặng và có thể gây tử vong.Say nóng thường gặp về buổi chiều có nhiều tia hồng ngoại, khi làm việc ở những nơi nhiệt độ, độ ẩm cao , thông gió kém, còn say nắng thường xuất hiện khi làm việc dưới trời nắng nóng, độ ẩm cao, không khí lưu thông kém, thường vào thời điểm giữa trưa trời nắng gay gắt có nhiều tia tử ngoại.
## **Biểu hiện khi bị say nắng, say nóng**
Đặc điểm chung của say nắng và say nóng và say nắng là dẫn đến tình trạng tăng thân nhiệt và triệu chứng tổn thương thần kinh trung ương.Triệu chứng kinh điển là tăng thân nhiệt >40 độ C và suy chức năng thần kinh xảy ra đột ngột ở 80% các trường hợp. Cụ thể:
* Các dấu hiệu nhẹ ban đầu: nhịp tim nhanh, thở nhanh, đỏ da (do cơ chế thải nhiệt- giãn mạch dưới da), có thể vã mồ hôi, kèm theo hoa mắt, chóng mặt, đau đầu, buồn nôn. Chú ý ở người già các dấu hiệu thường kín đáo và không đặc hiệu ở giai đoạn sớm.
* Các biểu hiện nặng hơn nếu không được xử trí kịp thời: tụt huyết áp, rối loạn chức năng thần kinh bao gồm thay đổi tri giác, kích động, mê sảng, lú lẫn, co giật và hôn mê. Khi thân nhiệt tăng quá cao còn gây mất điên giải nặng, rối loạn thăng bằng nội môi, có thể xuất huyết (xuất huyết kết mạc, đái ra máu, ỉa ra máu ) do rối loạn đông máu nặng, nặng hơn nữa là suy đa phủ tạng dẫn đến tử vong.
## **Những yếu tố thuận lợi dễ bị say nắng say nóng**
- Trẻ em hoặc người già vì khả năng điều nhiệt, thích nghi kém với nắng nóng
- Sự thiếu thích nghi với khí hậu
- Tập luyện và làm việc trong môi trường nắng nóng
- Mặc quần áo không phù hợp (quá dày, không thấm nước, hấp thụ nhiệt…)
- Không uống đầ đủ nước, hoặc môi trường quá nóng
- Đang dùng một số loại thuốc làm giảm tiết mồ hôi: lợi tiểu, chẹn beta, kháng cholinergic, ethanol, kháng histamine
- Một số tình trạng bệnh lý, sốt, rối loạn nội tết tố, béo phì, ….
Xem thêm: [**Dự phòng và xử trí say nắng, say nóng**](https://bvnguyentriphuong.com.vn/cap-cuu/du-phong-va-xu-tri-say-nang-say-nong)
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [Thế nào là say nắng, say nóng](https://bvnguyentriphuong.com.vn/cap-cuu/say-nang-say-nong#th-no-l-say-nng-say-nng)
  * [Biểu hiện khi bị say nắng, say nóng](https://bvnguyentriphuong.com.vn/cap-cuu/say-nang-say-nong#biu-hin-khi-b-say-nng-say-nng)
  * [Những yếu tố thuận lợi dễ bị say nắng say nóng](https://bvnguyentriphuong.com.vn/cap-cuu/say-nang-say-nong#nhng-yu-t-thun-li-d-b-say-nng-say-nng)



## ️ Sơ cứu vết thương ngực hở

  * [2. Nguyên nhân:](https://bvnguyentriphuong.com.vn/cap-cuu/so-cuu-vet-thuong-nguc-ho#2-nguyn-nhn)
  * [4. Nhận biết các loại vết thương ngực:](https://bvnguyentriphuong.com.vn/cap-cuu/so-cuu-vet-thuong-nguc-ho#4-nhn-bit-cc-loi-vt-thng-ngc)
  * [5. Sơ cứu tùy loại tổn thương:](https://bvnguyentriphuong.com.vn/cap-cuu/so-cuu-vet-thuong-nguc-ho#5-s-cu-ty-loi-tn-thng)
  * [5.1. Vết thương thành ngực:](https://bvnguyentriphuong.com.vn/cap-cuu/so-cuu-vet-thuong-nguc-ho#51-vt-thng-thnh-ngc)
  * [5.2. Vết thương tràn khí màng phổi kín:](https://bvnguyentriphuong.com.vn/cap-cuu/so-cuu-vet-thuong-nguc-ho#52-vt-thng-trn-kh-mng-phi-kn)
  * [5.3. Vết thương tràn khí màng phổi hở](https://bvnguyentriphuong.com.vn/cap-cuu/so-cuu-vet-thuong-nguc-ho#53-vt-thng-trn-kh-mng-phi-h)
  * [5.4. Vết thương tràn khí màng phổi van:](https://bvnguyentriphuong.com.vn/cap-cuu/so-cuu-vet-thuong-nguc-ho#54-vt-thng-trn-kh-mng-phi-van)
  * [6. Theo dõi nạn nhân](https://bvnguyentriphuong.com.vn/cap-cuu/so-cuu-vet-thuong-nguc-ho#6-theo-di-nn-nhn)


## **1. Định nghĩa**
Vết thương ngực là các tổn thương lồng ngực trong đó có mất sự liên tục của da thành ngực.
## **2. Nguyên nhân:**
– Vết thương ngực do hoả khí: do đạn thẳng,mảnh pháo…
– Vết thương ngực không do hoả khí: do vật nhọn đâm…
## **3. Phân loại:**
– Vết Thương Thành Ngực: Không làm thủng lá thành màng phổi.
– Vết Thương Thấu Ngực: Làm thủng lá thành màng phổi.
## **4. Nhận biết các loại vết thương ngực** :
– Vết thương thành ngực: độ sâu vết thương không tới lá thành màng phổi.
– Vết thương ngực kín: miệng vết thương thường nhỏ. Đường ống vết thương đã được bịt kín lại nhờ tổ chức phần mềm của thành ngực, không có hiện tượng không khí ra vào qua lỗ vết thương. Có thể sờ thấy dấu hiệu “lép bép” do tràn khí dưới da quanh vết thương và vùng ngực,cổ.
– Vết thương ngực hở: tại chỗ vết thương thấy có tiếng “phì phò” và sùi bọt máu theo nhịp thở của bệnh nhân.
– Vết thương ngực van: khi bệnh nhân hít vào thì thấy tiếng rít của không khí vào màng phổi qua lỗ vết thương ở thành ngực (van ngoài) hay nghe thấy trên phổi bằng ống nghe (van trong). Khi thở ra không thấy hiện tượng đó
## **5. Sơ cứu tùy loại tổn thương:**
– Khi nhìn thấy có dị vật còn cắm vào ngực nạn nhân,**TUYỆT ĐỐI** không được làm mọi cách rút ra,có thể gây chảy máu trầm trọng,tử vong nhanh chóng.
– Giữ nguyên cả dị vật nhanh chóng đưa nạn nhân đến Bệnh viện gần nhất.
### **5.1. Vết thương thành ngực:**
– Vết thương nhỏ: chỉ cần băng vô khuẩn, không cần cắt lọc .
– Vết thương lớn, có nhiều tổ chức giập nát: mổ cắt lọc, cầm máu, lấy dị vật, khâu lại phần mềm (tránh làm rách màng phổi khi cắt lọc).
### **5.2. Vết thương tràn khí màng phổi kín:**
– Xử lý vết thương như trong vết thương thành ngực nói chung.
– Xử trí Tràn khí màng phổi và Tràn dịch màng phổi: mục đích là hút sạch dịch và khí đồng thời làm phổi nở ra hoàn toàn.
### **5.3. Vết thương tràn khí màng phổi hở**
Cấp cứu tại chỗ: Bằng mọi cách (dùng ngón tay, đệm gạc… hay các vật dụng tại chỗ khác) bịt kín ngay lỗ vết thương thành ngực để biến vết thương tràn khí màng phổi mở thành vết thương tràn khí màng phổi kín.
### **5.4. Vết thương tràn khí màng phổi van:**
Cấp cứu tại chỗ: phải giảm áp ngay khoang màng phổi bằng cắm một kim to (tốt nhất là kim có van thoát khí ra theo một chiều) vào khoang màng phổi qua khe liên sườn 2 trên đường giữa đòn. Đồng thời nếu là tràn khí do van ngoài thì phải tìm cách bịt kín ngay lỗ van đó lại để biến nó thành vết thương ngực kín.
## **6. Theo dõi nạn nhân**
Trong khi chờ đội cấp cứu đến, hãy tiếp tục theo dõi đường thở, sự hô hấp và tuần hoàn của nạn nhân. Tìm kiếm và điều trị các triệu chứng sốc. Các triệu chứng của sốc bao gồm da lạnh, xanh xao, mạch nhanh hoặc thở nhanh, buồn nôn hoặc nôn, chóng mặt hoặc ngất xỉu, và tăng lo lắng hoặc kích động.
Nếu bạn nghi ngờ nạn nhân có thể bị sốc, hãy nới lỏng quần áo chật và ủ ấm cho nạn nhân. Cố gắng để nạn nhân nằm yên. Nếu có thể hãy nâng cao hai chân nạn nhân lê cao để máu lưu thông về tim dễ hơn.
Nếu nạn nhân có thay đổi ý thức, bạn cần nhanh chóng hành động. Đặt nạn nhân ở tư thế nằm nghiêng an toàn. Không đặt nạn nhân ở tư thế nằm nghiêng chấn thương tủy sống và cột sống cổ kèm theo. Theo dõi nhịp thở của người đó.
Nếu nạn nhân bất tỉnh, ngừng thở, đặt nạn nhân nằm ngửa và thực hiện hồi sức tim phổi.
Theo dõi và ghi lại dấu hiệu quan trọng của nạn nhân — mức độ ý thức, nhịp thở và mạch/nhịp tim—cho đến khi trợ giúp khẩn cấp đến.
Xem thêm: [**Phẫu thuật điều trị vết thương ngực – bụng qua đường ngực**](https://bvnguyentriphuong.com.vn/phac-do-dieu-tri/phau-thuat-dieu-tri-vet-thuong-nguc-bung-qua-duong-nguc)
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [2. Nguyên nhân:](https://bvnguyentriphuong.com.vn/cap-cuu/so-cuu-vet-thuong-nguc-ho#2-nguyn-nhn)
  * [4. Nhận biết các loại vết thương ngực:](https://bvnguyentriphuong.com.vn/cap-cuu/so-cuu-vet-thuong-nguc-ho#4-nhn-bit-cc-loi-vt-thng-ngc)
  * [5. Sơ cứu tùy loại tổn thương:](https://bvnguyentriphuong.com.vn/cap-cuu/so-cuu-vet-thuong-nguc-ho#5-s-cu-ty-loi-tn-thng)
  * [5.1. Vết thương thành ngực:](https://bvnguyentriphuong.com.vn/cap-cuu/so-cuu-vet-thuong-nguc-ho#51-vt-thng-thnh-ngc)
  * [5.2. Vết thương tràn khí màng phổi kín:](https://bvnguyentriphuong.com.vn/cap-cuu/so-cuu-vet-thuong-nguc-ho#52-vt-thng-trn-kh-mng-phi-kn)
  * [5.3. Vết thương tràn khí màng phổi hở](https://bvnguyentriphuong.com.vn/cap-cuu/so-cuu-vet-thuong-nguc-ho#53-vt-thng-trn-kh-mng-phi-h)
  * [5.4. Vết thương tràn khí màng phổi van:](https://bvnguyentriphuong.com.vn/cap-cuu/so-cuu-vet-thuong-nguc-ho#54-vt-thng-trn-kh-mng-phi-van)
  * [6. Theo dõi nạn nhân](https://bvnguyentriphuong.com.vn/cap-cuu/so-cuu-vet-thuong-nguc-ho#6-theo-di-nn-nhn)



## ️ 10 mẹo sơ cứu có thể giúp bạn khi cần thiết

  * [3/ Ép tim thổi ngạt](https://bvnguyentriphuong.com.vn/cap-cuu/10-meo-so-cuu-co-the-giup-ban-khi-can-thiet#3-p-tim-thi-ngt)
  * [6/ Tổn thương mắt](https://bvnguyentriphuong.com.vn/cap-cuu/10-meo-so-cuu-co-the-giup-ban-khi-can-thiet#6-tn-thng-mt)
  * [7/ Mảnh vụn, dăm](https://bvnguyentriphuong.com.vn/cap-cuu/10-meo-so-cuu-co-the-giup-ban-khi-can-thiet#7-mnh-vn-dm)
  * [9/ Vết thương do sứa](https://bvnguyentriphuong.com.vn/cap-cuu/10-meo-so-cuu-co-the-giup-ban-khi-can-thiet#9-vt-thng-do-sa)
  * [10/ Cầm máu khi bị chảy máu cam](https://bvnguyentriphuong.com.vn/cap-cuu/10-meo-so-cuu-co-the-giup-ban-khi-can-thiet#10-cm-mu-khi-b-chy-mu-cam)


## **1/ Vết thương**
Bất cứ khi nào phải xử lý với một vết thương, nên cố gắng nâng vết thương lên trên mức tim. Điều này làm giảm bớt tình trạng mất máu. Nếu vết thương ở hông hoặc mông, hãy nằm xuống và nâng người lên bằng gối. Nếu không thể nâng cao vết thương, hãy cố gắng giữ nó ở ngang mức tim hoặc càng gần so với mức tim càng tốt.
## **2/ Bỏng độ 1**
Bỏng độ 1, còn được gọi là bỏng bề mặt, chỉ tác động đến lớp ngoài cùng của da. Nó có thể gây đau đớn, nhưng thật sự không nghiêm trọng. Để điều trị chúng, rửa sạch vết thương bằng nước ấm. Mặc dù nước đá có cảm giác tốt hơn, nhưng ra gây tổn thương mô nhiều hơn. Sau khi làm sạch vết bỏng có thể chườm túi nước đá hoặc chườm lạnh. Sử dụng bơ hoặc mỡ là một phương pháp dân gian hay dùng nhưng điều đó thực sự có thể gây ra nhiều tổn thương cho vết thương vì làm chậm quá trình thoát nhiệt. Một hỗn hợp sệt được làm bằng cách trộn nước và soda cũng có thể giúp thoát nhiệt từ vết bỏng.
## **p tim thổi ngạt**
Chỉ nên sơ cứu xoa bóp tim ngoài lồng ngực nếu bạn chắc chắn rằng bệnh nhân không còn thở, mạch ngừng đập và không có bác sỹ nào xung quanh. Trong khi 1 người gọi xe cứu thương, còn 1 người xoa bóp tim với tần suất 100 nhịp mỗi phút. Đối với trẻ em, bạn chỉ nên xoa bóp hồi sinh tim nhẹ nhàng bằng ngón tay với tần suất thấp hơn. Biện pháp hô hấp nhân tạo hay còn gọi là thổi ngạt nên thực hiện khi tim đã có dấu hiệu đập trở lại. Hoặc bạn có thể thực hiện 30 lần xoa bóp tim rồi 2 lần thổi ngạt và lặp lại liên tục.
## **4/ Ong chích**
Nhanh chóng ra khỏi khu vực có ong, lấy vòi chích của ong ra bằng cách khều nhẹ hoặc dùng nhíp kẹp. Tránh nặn ép bằng tay vì có thể làm nọc độc lan rộng. Rửa sạch vùng da bị đốt bằng xà phòng và nước ấm. Bôi dung dịch sát trùng như povidine 10% hoặc cồn 70 độ lên vết đốt mỗi ngày hai lần.
Uống nhiều nước để thải độc tố. Chườm lạnh lên vết đốt để giảm đau và giảm sưng. Sau khi xử trí, người bị ong đốt cần được chăm sóc và theo dõi, đưa đến cơ sở y tế.
## **5/ Gãy xương**
Khi bị gãy xương, đừng cố gắng nắn lại cho thẳng, giữ cho chân tay được ổn định và bất động bằng cách sử dụng nẹp và đệm. Mặc dù chấn thương có thể chỉ gây trật khớp đơn giản hoặc bong gân, nhưng cần phải đi khám để đảm bảo chấn thương không nghiêm trọng hơn hoặc thậm chí tránh gây thêm chấn thương nặng nề.
## **6/ Tổn thương mắt**
Khi bị tổn thương ở mắt, điều quan trọng nhất cần làm là che mắt và sau đó tìm kiếm sự giúp đỡ. Đừng cố gắng tự làm sạch mắt vì điều này có thể có nguy cơ làm tổn thương nặng nề hơn nữa thậm chí gây mù vĩnh viễn. Trường hợp nếu mắt bị dính hóa chất nên rửa với thật nhiều nước sạch ngay lập tức.
## **7/ Mảnh vụn, dăm**
Mảnh vụn chứa đầy vi trùng và có thể dễ dàng lây nhiễm vào vùng da hở. Nếu bạn có một mảnh vỡ nằm sâu bên trong da, trước tiên nên làm sạch khu vực đó bằng chất khử trùng và sau đó gắp mảnh vỡ bằng dụng cụ được khử trùng qua nước sôi. Sau đó, rửa vùng tổn thương bằng xà phòng và nước.
## **8/ Rắn cắn**
Khi bị rắn cắn, điều quan trọng nhất là bình tĩnh. Bạn cần phải giữ nhịp tim thấp để làm chậm sự lây lan của chất độc. Tương tự như vậy, uống thuốc giảm đau thực sự có thể làm loãng máu và làm cho nọc độc sẽ hoạt động nhanh hơn. Liên hệ với cấp cứu ngay lập tức để được tiêm kháng độc thích hợp; nếu bạn cần di chuyển, hãy đi bộ, không nên chạy.
## **9/ Vết thương do sứa**
Có thể thử rửa vết thương bằng nước muối, nước nóng, giấm hoặc đắp vết thương bằng dung dịch baking soda và nước. Than hoạt tính cũng có thể giúp hút nọc độc của sứa. Đừng cố gắng gãi vì nó chỉ làm vết thương tệ đi!
## **Cầm máu khi bị chảy máu cam**
Giữ đầu thẳng để máu chảy xuôi xuống và giảm áp lực lên mũi. Dùng đá lạnh chườm lên bên cánh mũi để tĩnh mạch co lại, ngăn chảy máu. Sau đó, dùng tay bóp chặt mũi trong vòng 15 phút và tạm thở bằng miệng tới khi máu ngừng chảy. Nếu không thể cầm máu hoặc vết thương quá nặng do chấn thương va đập, hãy đến trung tâm y tế gần nhất để các bác sỹ xử lý vết thương.
Xem thêm: [**Sơ cứu bỏng (Clip)**](https://www.youtube.com/watch?v=roG9CkFf1Gk)
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [3/ Ép tim thổi ngạt](https://bvnguyentriphuong.com.vn/cap-cuu/10-meo-so-cuu-co-the-giup-ban-khi-can-thiet#3-p-tim-thi-ngt)
  * [6/ Tổn thương mắt](https://bvnguyentriphuong.com.vn/cap-cuu/10-meo-so-cuu-co-the-giup-ban-khi-can-thiet#6-tn-thng-mt)
  * [7/ Mảnh vụn, dăm](https://bvnguyentriphuong.com.vn/cap-cuu/10-meo-so-cuu-co-the-giup-ban-khi-can-thiet#7-mnh-vn-dm)
  * [9/ Vết thương do sứa](https://bvnguyentriphuong.com.vn/cap-cuu/10-meo-so-cuu-co-the-giup-ban-khi-can-thiet#9-vt-thng-do-sa)
  * [10/ Cầm máu khi bị chảy máu cam](https://bvnguyentriphuong.com.vn/cap-cuu/10-meo-so-cuu-co-the-giup-ban-khi-can-thiet#10-cm-mu-khi-b-chy-mu-cam)



## ️ Giao thức xử trí bệnh nhân COVID tại khoa Cấp cứu

Giao thức này được dùng để hướng dẫn cho Nhân viên của Khoa Cấp cứu MMC trong việc quản lý bệnh nhân bị bệnh nặng do nhiễm COVID-19. Sử dụng bằng chứng hiện tại và sự đồng thuận khi không có bằng chứng, tài liệu này có nghĩa là hợp lý hóa, tiêu chuẩn hóa và tối ưu hóa sự chăm sóc mà chúng tôi cung cấp cho những bệnh nhân này. Giao thức có thể được cập nhật khi có dữ liệu mới.
**Toàn văn xin xem[ tại đây](https://drive.google.com/open?id=1R1dlzgUhy__gBPrilEuJNUfIBV89Q0KU)./.**
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh

## ️ Các phản ứng do truyền máu

  * [Các triệu chứng thường gặp](https://bvnguyentriphuong.com.vn/cap-cuu/cac-phan-ung-do-truyen-mau#cc-triu-chng-thng-gp)
  * [Những phản ứng sớm / cấp do truyền máu](https://bvnguyentriphuong.com.vn/cap-cuu/cac-phan-ung-do-truyen-mau#nhng-phn-ng-sm-cp-do-truyn-mu)
  * [Phản ứng dị ứng đơn giản](https://bvnguyentriphuong.com.vn/cap-cuu/cac-phan-ung-do-truyen-mau#phn-ng-d-ng-n-gin)
  * [Phản ứng phản vệ do truyền máu](https://bvnguyentriphuong.com.vn/cap-cuu/cac-phan-ung-do-truyen-mau#phn-ng-phn-v-do-truyn-mu)
  * [Phản ứng sốt không do tan máu](https://bvnguyentriphuong.com.vn/cap-cuu/cac-phan-ung-do-truyen-mau#phn-ng-st-khng-do-tan-mu)
  * [Tan máu cấp do truyền máu](https://bvnguyentriphuong.com.vn/cap-cuu/cac-phan-ung-do-truyen-mau#tan-mu-cp-do-truyn-mu)
  * [Nhiễm trùng huyết do truyền máu](https://bvnguyentriphuong.com.vn/cap-cuu/cac-phan-ung-do-truyen-mau#nhim-trng-huyt-do-truyn-mu)
  * [Tổn thương phổi cấp liên quan đến truyền máu (TRALI – Transfusion-related acute lung injury) ](https://bvnguyentriphuong.com.vn/cap-cuu/cac-phan-ung-do-truyen-mau#tn-thng-phi-cp-lin-quan-n-truyn-mu-trali-transfusionrelated-acute-lung-injury)
  * [Quá tải tuần hoàn do truyền máu (TACO – Transfusion-associate circulatory overload)](https://bvnguyentriphuong.com.vn/cap-cuu/cac-phan-ung-do-truyen-mau#qu-ti-tun-hon-do-truyn-mu-taco-transfusionassociate-circulatory-overload)
  * [Những phản ứng muộn do truyền máu](https://bvnguyentriphuong.com.vn/cap-cuu/cac-phan-ung-do-truyen-mau#nhng-phn-ng-mun-do-truyn-mu)
  * [Tan máu muộn sau truyền máu](https://bvnguyentriphuong.com.vn/cap-cuu/cac-phan-ung-do-truyen-mau#tan-mu-mun-sau-truyn-mu)
  * [Bệnh ghép chống chủ do truyền máu (TAGVHD – Transfusion-associated graft versus host disease)](https://bvnguyentriphuong.com.vn/cap-cuu/cac-phan-ung-do-truyen-mau#bnh-ghp-chng-ch-do-truyn-mu-tagvhd-transfusionassociated-graft-versus-host-disease)
  * [Xuất huyết giảm tiểu sau truyền máu (PTP – Posttransfusion purpura)](https://bvnguyentriphuong.com.vn/cap-cuu/cac-phan-ung-do-truyen-mau#xut-huyt-gim-tiu-sau-truyn-mu-ptp-posttransfusion-purpura)
  * [Các bảng tóm tắt](https://bvnguyentriphuong.com.vn/cap-cuu/cac-phan-ung-do-truyen-mau#cc-bng-tm-tt)
  * [Phản ứng cấp tính](https://bvnguyentriphuong.com.vn/cap-cuu/cac-phan-ung-do-truyen-mau#phn-ng-cp-tnh)
  * [Di chứng và thời điểm gặp bác sĩ](https://bvnguyentriphuong.com.vn/cap-cuu/cac-phan-ung-do-truyen-mau#di-chng-v-thi-im-gp-bc-s)


## **Các triệu chứng thường gặp**
Theo một bài báo năm 2020, các dấu hiệu thường gặp nhất cho thấy một người đang bị phản ứng phụ bao gồm:
  * Lạnh run
  * Phát ban
  * 

Tuy nhiên, các triệu chứng này có thể tự mất đi hoặc được xử lý đơn giản. Các dấu hiệu cho thấy đang bị phản ứng trầm trọng hơn bao gồm:
  * Suy hô hấp
  * Tụt huyết áp
  * Sốt cao
  * Tiểu máu


## **Những phản ứng sớm / cấp do truyền máu**
Những phản ứng này bao gồm:
### **Phản ứng dị ứng đơn giản**
Ngay cả khi một người được truyền đúng nhóm máu, _phản ứng dị ứng_ vẫn có thể xảy ra. Theo một bài báo năm 2013 trên Tạp chí Huyết học Anh quốc (British Journal of Hematology), những phản ứng này xảy ra là do:
  * Máu của người cho chứa vài protein huyết thanh đặc trưng mà đối với máu của người nhận là chất gây dị ứng.
  * Máu của người cho có chứa chất gây dị ứng từ thức ăn, như đậu phộng hay gluten.
  * Kháng thể trong máu người cho phản ứng với kháng thể trong máu người nhận.


**Triệu chứng:** Các triệu chứng thường nhẹ và bao gồm:
  * Mày đay
  *   * Phát ban


**Điều trị:** Điều trị dị ứng nhẹ gồm:
  * Ngưng truyền máu
  * Dùng thuốc Kháng histamin


### **Phản ứng phản vệ do truyền máu**
Phản ứng phản vệ xảy ra ở những người thiếu hụt Immunoglobulin A (IgA) và có kháng thể IgA trong huyết thanh. Những kháng thể kháng IgA trong máu người nhận có thể phản ứng với kháng thể IgA trong máu của người cho.
**Triệu chứng:** thường gặp là:
  * Đỏ da
  *   * Phát ban
  * Sưng tấy
  * Khó thở
  * Khò khè
  * Môi tái
  * Nôn ói
  * Tiêu chảy
  * Tụt huyết áp


**Điều trị:** Nếu xuất hiện những triệu chứng trên, điều dưỡng hay bác sĩ phải nhưng ngay việc truyền máu. Sau đó, phải nhận diện các triệu chứng đặc hiệu, có thể xử trí thêm:
  * Epinephrine tĩnh mạch
  * Steroid tĩnh mạch
  * Thuốc kháng histamin
  * Thuốc dãn phế quản


### **Phản ứng sốt không do tan máu**
Theo CDC _, Phản ứng sốt không do tan máu_ là phản ứng thường gặp nhất khi truyền máu. Đây là sự gia tăng thân nhiệt không giải thích được trong suốt 04 giờ sau truyền máu. Sốt có thể một phần là do tế bào bạch cầu của người nhận phản ứng với máu được truyền.
**Triệu chứng:** Những triệu chứng phụ thuộc vào độ nặng và có thể gồm:
  * Thân nhiệt trên 38oC (100.4oF)
  * Sốt và lạnh run


Nếu xuất hiện triệu chứng khác, bạn cần báo ngay với bác sĩ.
**Điều trị:** Nếu _Phản ứng sốt không do tan máu_ xảy ra trong quá trình truyền máu, nhân viên y tế phải dừng việc truyền máu.
Điều trị phụ thuộc vào triệu chứng. Tuy nhiên, theo CDC, các phản ứng thường nhẹ và đáp ứng nhanh với điều trị.
Đánh giá cẩn thận tất cả các trường hợp sốt bởi nó có thể là biểu hiện của một phản ứng nặng nề hơn. Dùng aspirin hay acetaminophen theo liều khuyến cáo.
### **Tan máu cấp do truyền máu**
Theo CDC, phản ứng này có thể xảy ra trong suốt quá trình, ngay sau truyền máu hay trong vòng 24 giờ sau truyền máu. Phản ứng này xảy ra khi một người nhận máu sai nhóm.
Một bài báo năm 2019 công bố _Tan máu cấp do truyền máu_ khiến cơ thể phá hủy các tế bào hồng cầu được cho.
**Triệu chứng** : Triệu chứng có thể gồm:
  * Lạnh run
  * Tụt huyết áp
  * Suy thận
  * Đau lưng


Các triệu chứng ít gặp hơn:
  * Đau hông lưng
  * Tiểu đỏ hay nâu


**Điều trị:** Nếu _Tan máu cấp do truyền máu_ xảy ra, điều dưỡng hay bác sĩ phải ngưng truyền máu ngay. Điều trị dựa trên mức độ nặng của phản ứng và có thể gồm:
  * Dịch truyền tĩnh mạch
  * Lọc máu
  * Kiểm soát chảy máu
  * Điều trị nâng đỡ


### **Nhiễm trùng huyết do truyền máu**
Theo một bài báo năm 2012, _Nhiễm trùng huyết do truyền máu_ thường xảy ra do vi trùng hiện diện trong máu người cho, thường nhất là từ các sản phẩm của tiểu cầu.
Những loại vi trùng trong tiểu cầu gây ra _Nhiễm trùng huyết do truyền máu_ thường là _Staphylococcus aureus_ hoặc __Staphylococcus epidermidis.__
**Triệu chứng:**
  * Lạnh run
  * Tụt huyết áp


**Điều trị:**_Nhiễm trùng huyết do truyền máu_ cần được nhận diện sớm. Điều trị bao gồm:
  * Kiểm soát dịch truyền
  * Hỗ trợ hô hấp
  * Liệu pháp kháng sinh


### **Tổn thương phổi cấp liên quan đến truyền máu (TRALI – Transfusion-related acute lung injury)**
Phản ứng này thường xuất hiện nhanh chóng. Nó xảy ra khi kháng thể trong máu người cho, ví dụ kháng thể kháng bạch cầu của người, phản ứng với bạch cầu của người nhận. Hậu quả là gây ra phù phổi hay quá tải dịch ở phổi.
Theo Hội Chữ thập đỏ Hoa Kỳ, vẫn chưa có xét nghiệm nào xác định được thành phần nào trong máu gây ra _Tổn thương phổi cấp liên quan đến truyền máu._
**Triệu chứng:**
  * Khó thở trầm trọng
  * Tụt huyết áp


**Điều trị:** Điều trị phụ thuộc vào độ nặng
  * Trường hợp nhẹ, chỉ cần liệu pháp oxy đơn thuần.
  * Trường hợp trầm trọng, có thể cần phải thông khí nhân tạo.


Theo một bài báo năm 2012, hầu hết các trường hợp thường được xử lý ổn trong 48-72 giờ. Tuy nhiên, _Tổn thương phổi cấp liên quan đến truyền máu_ có thể gây tử vong với tần suất tử vong khoảng 05-25%.
### **Quá tải tuần hoàn do truyền máu (TACO – Transfusion-associate circulatory overload)**
_Quá tải tuần hoàn do truyền máu_ xảy ra nếu hệ thống tuần hoàn của người nhận không đủ khả năng chịu đựng được lượng máu được truyền hay tốc độ truyền. Các bác sĩ gọi đây là _Quá tải thể tích,_ và những người có vấn đề về tim mạch hay thận sẽ gặp phải.
Khi _Quá tải tuần hoàn do truyền máu,_ người nhận sẽ bị Phù phổi, tức là lòng phổi bị lấp đầy bởi dịch.
**Triệu chứng:** Triệu chứng của _Quá tải tuần hoàn do truyền máu_ xảy ra trong vài giờ đầu hay trong suốt quá trình truyền máu. Triệu chứng có thể gồm:
  * Thở nhanh
  * Khó thở
  * Huyết áp tăng
  * Nhịp tim nhanh


**Điều trị:**
Nếu _Quá tải tuần hoàn do truyền máu_ xảy ra khi truyền máu, nhân viên ý tế phải ngưng truyền máu ngay. Theo LabMedicine, điều trị _Quá tải tuần hoàn do truyền máu_ phụ thuộc vào độ nặng:
  * Cho bệnh nhân nằm đầu cao thường là đủ cho bệnh nhân nhẹ.
  * Điều trị lợi tiểu để giảm lượng dịch có thể giúp giải quyết _Quá tải tuần hoàn do truyền máu._
  * Đặt nội khí quản để đảm bảo hô hấp là cần thiết trong vài trường hợp trầm trọng.


## **Những phản ứng muộn do truyền máu**
### **Tan máu muộn sau truyền máu**
_Tan máu muộn sau truyền máu_ xảy ra khi cơ thể người nhận tạo ra các kháng thể chống lại kháng nguyên trên hồng cầu. Phản ứng này xảy ra vào khoảng 1 ngày đến 4 tuần sau truyền máu.
Những kháng thể này có thể được tạo ra từ những lần mang thai hay truyền máu trước đó. Những kháng thể đặc trưng này tăng dần tới mức độ không thể đo lường được. Những người có kháng thể này sẽ có nguy cơ bị _Tan máu muộn sau truyền máu_ cao hơn.
**Triệu chứng:** thường là
  * Vàng da
  * Đau bụng
  * Tiểu sậm màu
  * Tăng huyết áp
  * Thở gắng sức


**Điều trị:** Theo LabMedicine, các phản ứng này có xu hướng ít trầm trọng và không cần điều trị. Nếu phản ứng trở nên rầm rộ, bồi hoàn dịch là rất quan trọng
### **Bệnh ghép chống chủ do truyền máu (TAGVHD – Transfusion-associated graft versus host disease)**
Theo CDC, _Bệnh ghép chống chủ do truyền máu (TAGVHD)_ xảy ra khi tế bào lympho-T, một dạng bạch cầu, từ máu người cho gia tăng số lượng nhanh chóng khi vào máu người nhận. Sau đó chúng sẽ tấn công các tế bào của người nhận.
Tuy nhiên, phản ứng này hiếm khi xảy ra, và nó càng ít xảy ra hơn nữa kể từ lúc có phương pháp chiếu xạ các sản phẩm của máu. Chiếu xạ máu nghĩa là các thành phần của máu được chiếu dưới ánh sáng cực tím.
**Triệu chứng:**_(theo CDC)_
  * Mày đay
  * Buồn nôn
  * Nôn ói
  * Tiêu chảy
  * Đau bụng
  * Suy tủy


**Điều trị:**
Các bác sĩ nhận định TAGVHD là thách thức trong điều trị, hậu quả là tỉ lệ tử vong từ 90 - 100%. Việc phòng ngừa là biện pháp tốt nhất. Chiếu xạ máu giúp ngăn ngừa nguy cơ xảy ra phản ứng này.
### **Xuất huyết giảm tiểu sau truyền máu (PTP – Posttransfusion purpura)**
CDC cho biết _Xuất huyết gỉam tiểu cầu_ sau truyền máu hiếm xảy ra. Nó xảy ra khi người nhận tạo ra các kháng thể kháng tiểu cầu. Hậu quả là các tiểu cầu bị phá hủy và số lượng tiểu cầu suy giảm.
**Triệu chứng:**
  * Chảy máu trong đường tiêu hóa hay đường tiết niệu
  * Sốt và lạnh run


**Điều trị:**
  * Điều trị nâng đỡ
  * Globulin miễn dịch (immunoglobin) và steroid đường tĩnh mạch


## **Các bảng tóm tắt**
Theo các tác giả của Quyển [_Transfusion Medicine for Pathologists: A Comprehensive Review for Board Preparation, Certification, and Clinical Practice_](https://books.google.co.uk/books?id=z-JgDwAAQBAJ&pg=PA37&lpg=PA37&dq=Chapter+3+-+Transfusion+reactions+castillo&source=bl&ots=qIetYlpPsw&sig=ACfU3U2_OV-IbL3SnUEmomreBYauW74jIQ&hl=en&sa=X&ved=2ahUKEwjcnu_4ycrqAhWStHEKHeTmBdEQ6AEwCnoECAcQAQ#v=onepage&q=Chapter%203%20-%20Transfusion%20reactions%20castillo&f=false) , phải luôn nhớ rằng các phản ứng do truyền máu hiếm khi gây tử vong. Tỉ lệ tử vong do các phản ứng dao động từ 01 ca trên 0,6 triệu đến 2,3 triệu ca. Tóm tắt về các phản ứng do truyền máu được trình bày như sau:
## **Phản ứng cấp tính**
**Phản ứng** |  **Tần suât** |  **Triệu chứng** |  **Thời điểm khới phát** |  **Độ trầm trọng** |  **Điều trị**  
---|---|---|---|---|---  
**Phản ứng dị ứng đơn giản** |  01 - 03% ca truyền máu |  Mày đay, ngứa, phát ban |  Trong suốt quá trình hoặc trong vòng 04 giờ |  Kháng histamin  
**Phản ứng phản vệ do truyền máu** |  01 trên 20.000 – 30.000 ca truyền máu |  Đỏ da, ngứa, phát ban, sưng tấy, khó thở, khò khè, môi tái, nôn ói, tiêu chảy, tụt huyết áp |  Từ vài giây đến vài phút đầu tiên khi bắt đầu truyền máu |  Có nguy cơ tử vong |  Epinephrine (TM), steroid (TM), thuốc giãn phế quản  
**Phản ứng sốt không do tan máu** |  01 - 03% số đơn vị máu được truyền |  Tăng thân nhiệt ít nhất 01% kèm lạnh run |  Trong vòng 04 giờ |  Thuốc hạ sốt  
**Tan máu cấp do truyền máu** |  02-08% trên 10.000 đơn vị máu được truyền |  Sốt, đau hông lưng, tụt huyết áp, suy thận và khó thở |  Trong suốt quá trình, ngay sau khi kết thúc hoặc trong vòng 24 giờ sau truyền máu |  Có nguy cơ tử vong |  Điều trị hỗ trợ bằng dịch truyền, lợi tiểu khi cần, kiếm soát chảy máu  
**Nhiễm trùng huyết do truyền máu** |  01 trên 3000 – 5000 đơn vị tiểu cầu |  Sốt, lạnh run và tụt huyết áp |  Trong vòng 04 giờ |  Có nguy cơ tử vong |  Kháng sinh, kiểm soát dịch truyền và hỗ trợ hô hấp  
**Tổn thương phổi cấp liên quan đến truyền máu (TRALI)** |  0,4% trên 100.000 đơn vị huyết thanh |  Khó thở, sốt và huyết áp tăng |  Trong suốt quá trình hoặc trong vòng 06 giờ |  Có nguy cơ tử vong |  Hỗ trợ hô hấp  
**Quá tải tuần hoàn do truyền máu (TACO)** |  06% ở những bệnh nhân có bệnh nền nặng |  Thở nhanh, nông hoặc ho |  Trong suốt quá trình hoặc trong vòng 04 - 06 giờ |  Có nguy cơ tử vong |  Nằm đầu cao và dùng thuốc lợi tiểu  
## **Phản ứng muộn**
**Phản ứng** |  **Tần suât** |  **Triệu chứng** |  **Thời điểm khới phát** |  **Độ trầm trọng** |  **Điều trị**  
---|---|---|---|---|---  
**Tán huyết muộn do truyền máu** |  01 trên 2500 ca |  Sốt, vàng da, tiểu sậm màu, đau bụng, thở gắng sức, huyết áp cao |  03 – 10 ngày |  Theo dõi sát, bù nước  
**Bệnh ghép chống chủ do truyền máu (TAGVHD)** |  |  Mày đay, đau bụng, buồn nôn, nôn, sốt và suy tủy |  02 ngày đến 06 tuần sau truyền máu |  Có nguy cơ tử vong |  Dự phòng: chiếu xạ các sản phẩm của máu  
**Xuất huyết giảm tiểu sau truyền máu (PTP)** |  01 trên 25.000 – 100.000 ca |  Giảm số lượng tiểu cầu và chảy máu |  05 – 10 ngày |  Có nguy cơ tử vong |  Điều trị băng đỡ bằng Globulin miễn dịch (immunoglobin) và steroid đường tĩnh mạch  
## **Triển vọng**
Triển vọng phụ thuộc vào loại phản ứng phải đối mặt. Tuy nhiên, những phản ứng nghiêm trọng do truyền máu hiếm xảy ra.
Các đơn vị cung cấp dịch vụ y tế, ngân hàng máu và bệnh viện thực hiện các biện pháp dự phòng tốt để ngừa các phản ứng do truyền máu xảy ra.
## **Di chứng và thời điểm gặp bác sĩ**
Phụ thuộc vào loại phản ứng mà di chứng có thể bao gồm:
  * Suy thận
  * Tổn thương phổi
  * Huyết khối


Bạn nên đến gặp bác sĩ đếu gặp phải bất kì phản ứng nào đã nêu trong bài báo này.
## **Tổng kết**
Theo CDC, hằng năm các bác sĩ đã truyền 17,2 triệu đơn máu ở Mỹ, và hầu hết không xảy ra phản ứng nào.
Nếu người được truyền máu có các triệu chứng như thở nhanh, tụt huyết áp, tiểu đỏ hoặc nâu, đau hông lưng, hay các tác dụng phụ nghiêm trọng khác, họ nên đến gặp bác sĩ ngay lập tức.
Xem thêm: [**Hướng dẫn định nhóm máu tại giường (dành cho NVYT)**](https://www.youtube.com/watch?v=nOsD4UPhGhk)
**Bệnh viện Nguyễn Tri Phương -** Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [Các triệu chứng thường gặp](https://bvnguyentriphuong.com.vn/cap-cuu/cac-phan-ung-do-truyen-mau#cc-triu-chng-thng-gp)
  * [Những phản ứng sớm / cấp do truyền máu](https://bvnguyentriphuong.com.vn/cap-cuu/cac-phan-ung-do-truyen-mau#nhng-phn-ng-sm-cp-do-truyn-mu)
  * [Phản ứng dị ứng đơn giản](https://bvnguyentriphuong.com.vn/cap-cuu/cac-phan-ung-do-truyen-mau#phn-ng-d-ng-n-gin)
  * [Phản ứng phản vệ do truyền máu](https://bvnguyentriphuong.com.vn/cap-cuu/cac-phan-ung-do-truyen-mau#phn-ng-phn-v-do-truyn-mu)
  * [Phản ứng sốt không do tan máu](https://bvnguyentriphuong.com.vn/cap-cuu/cac-phan-ung-do-truyen-mau#phn-ng-st-khng-do-tan-mu)
  * [Tan máu cấp do truyền máu](https://bvnguyentriphuong.com.vn/cap-cuu/cac-phan-ung-do-truyen-mau#tan-mu-cp-do-truyn-mu)
  * [Nhiễm trùng huyết do truyền máu](https://bvnguyentriphuong.com.vn/cap-cuu/cac-phan-ung-do-truyen-mau#nhim-trng-huyt-do-truyn-mu)
  * [Tổn thương phổi cấp liên quan đến truyền máu (TRALI – Transfusion-related acute lung injury) ](https://bvnguyentriphuong.com.vn/cap-cuu/cac-phan-ung-do-truyen-mau#tn-thng-phi-cp-lin-quan-n-truyn-mu-trali-transfusionrelated-acute-lung-injury)
  * [Quá tải tuần hoàn do truyền máu (TACO – Transfusion-associate circulatory overload)](https://bvnguyentriphuong.com.vn/cap-cuu/cac-phan-ung-do-truyen-mau#qu-ti-tun-hon-do-truyn-mu-taco-transfusionassociate-circulatory-overload)
  * [Những phản ứng muộn do truyền máu](https://bvnguyentriphuong.com.vn/cap-cuu/cac-phan-ung-do-truyen-mau#nhng-phn-ng-mun-do-truyn-mu)
  * [Tan máu muộn sau truyền máu](https://bvnguyentriphuong.com.vn/cap-cuu/cac-phan-ung-do-truyen-mau#tan-mu-mun-sau-truyn-mu)
  * [Bệnh ghép chống chủ do truyền máu (TAGVHD – Transfusion-associated graft versus host disease)](https://bvnguyentriphuong.com.vn/cap-cuu/cac-phan-ung-do-truyen-mau#bnh-ghp-chng-ch-do-truyn-mu-tagvhd-transfusionassociated-graft-versus-host-disease)
  * [Xuất huyết giảm tiểu sau truyền máu (PTP – Posttransfusion purpura)](https://bvnguyentriphuong.com.vn/cap-cuu/cac-phan-ung-do-truyen-mau#xut-huyt-gim-tiu-sau-truyn-mu-ptp-posttransfusion-purpura)
  * [Các bảng tóm tắt](https://bvnguyentriphuong.com.vn/cap-cuu/cac-phan-ung-do-truyen-mau#cc-bng-tm-tt)
  * [Phản ứng cấp tính](https://bvnguyentriphuong.com.vn/cap-cuu/cac-phan-ung-do-truyen-mau#phn-ng-cp-tnh)
  * [Di chứng và thời điểm gặp bác sĩ](https://bvnguyentriphuong.com.vn/cap-cuu/cac-phan-ung-do-truyen-mau#di-chng-v-thi-im-gp-bc-s)



## ️ Quy trình nhập Cấp cứu tại Bệnh viện Nguyễn Tri Phương

**Bệnh viện Nguyễn Tri Phương** - Bệnh viện Đa khoa Hạng I Thành phố Hồ Chí Minh
  * 468 Nguyễn Trãi, Phường 8, Quận 5, Tp. Hồ Chí Minh
  * Hotline: (84-028) 39234332
  * Mạng xã hội **Facebook** : [**Bệnh viện Nguyễn Tri Phương**](https://www.facebook.com/BVNTP/)
  * Đăng ký (Subcribe) kênh **Youtube** : [https://youtube.com/bvntp](https://youtube.com/bvntp?fbclid=IwAR3q_UvPI4OZAebT1uQGPKKwk3RmCzAFLkBJm9lb7EwIz0EHtgiLhKM5bxU)
  * Quan tâm Zalo Official: [zalo.me/1744466261097093886](https://zalo.me/1744466261097093886?fbclid=IwAR3E-fLqdh-x1cYSvuDY6E5Eyxfjo5ZSs4p0hDWAyBG-ROlTkxXkXvdEWAY)



## ️ Sơ cấp cứu hồi sức tim phổi: mạng sống có thể do bạn quyết định!

  * [Các con số và ý nghĩa của việc hồi sức tim phổi:](https://bvnguyentriphuong.com.vn/cap-cuu/so-cap-cuu-hoi-suc-tim-phoi-mang-song-co-the-do-ban-quyet-dinh#cc-con-s-v-ngha-ca-vic-hi-sc-tim-phi)
  * [Hồi sức tim phổi là gì?](https://bvnguyentriphuong.com.vn/cap-cuu/so-cap-cuu-hoi-suc-tim-phoi-mang-song-co-the-do-ban-quyet-dinh#hi-sc-tim-phi-l-g)
  * [Tại sao phải cần hồi sức tim phổi?](https://bvnguyentriphuong.com.vn/cap-cuu/so-cap-cuu-hoi-suc-tim-phoi-mang-song-co-the-do-ban-quyet-dinh#ti-sao-phi-cn-hi-sc-tim-phi)
  * [Các bước thực hiện hồi sức tim phổi?](https://bvnguyentriphuong.com.vn/cap-cuu/so-cap-cuu-hoi-suc-tim-phoi-mang-song-co-the-do-ban-quyet-dinh#cc-bc-thc-hin-hi-sc-tim-phi)
  * [Trước khi bắt đầu](https://bvnguyentriphuong.com.vn/cap-cuu/so-cap-cuu-hoi-suc-tim-phoi-mang-song-co-the-do-ban-quyet-dinh#trc-khi-bt-u)
  * [Nhớ thứ tự các bước: ép ngực- khai thông đường thở- thổi ngạt](https://bvnguyentriphuong.com.vn/cap-cuu/so-cap-cuu-hoi-suc-tim-phoi-mang-song-co-the-do-ban-quyet-dinh#nh-th-t-cc-bc-p-ngc-khai-thng-ng-th-thi-ngt)
  * [Ép ngực: khôi phục dòng máu lưu thông](https://bvnguyentriphuong.com.vn/cap-cuu/so-cap-cuu-hoi-suc-tim-phoi-mang-song-co-the-do-ban-quyet-dinh#p-ngc-khi-phc-dng-mu-lu-thng)
  * [Khai thông đường thở ](https://bvnguyentriphuong.com.vn/cap-cuu/so-cap-cuu-hoi-suc-tim-phoi-mang-song-co-the-do-ban-quyet-dinh#khai-thng-ng-th)
  * [Hà hơi thổi ngạt](https://bvnguyentriphuong.com.vn/cap-cuu/so-cap-cuu-hoi-suc-tim-phoi-mang-song-co-the-do-ban-quyet-dinh#h-hi-thi-ngt)


## **Các con số và ý nghĩa của việc hồi sức tim phổi:**
Ngưng tim ngoài viện từ lâu là một thách thức đối với ngành Y nói chung. Theo các nghiên cứu trong và ngoài nước, tỉ lệ cứu sống được một trường hợp ngưng tim ngoài viện còn rất khiêm tốn, điển hình: tại Mỹ, trong các nghiên cứu năm 2007 và 2010 cho thấy tỷ lệ bệnh nhân sống sót ra viện chiếm khỏang **5% - 10%** , tại Việt Nam theo nghiên cứu tại khoa cấp cứu Bệnh viện Bạch Mai năm 2008 tỷ lệ này là **0%**.
Gần đây nhất, kết quả nghiên cứu tại bệnh viện chúng tôi năm 2019 ghi nhận con số có cải thiện ít nhiều với **4%**. Tuy các số liệu còn chưa có tính thống nhất nhưng kết quả này nhìn chung phản ánh phần nào tình hình cấp cứu ngừng tuần hoàn tại Việt Nam còn chưa cao.
Trong số các trường hợp ngưng tuần hoàn được chứng kiến, chỉ có số ít người chứng kiến tiến hành hồi sức tim phổi (HSTP) cho bệnh nhân, đa số trường hợp còn lại người chứng kiến chỉ cố gắng nhanh chóng chuyển bệnh nhân đến bệnh viện. Đáng tiếc thay, không ít trường hợp bệnh nhân thở ngáp hoặc nằm im không thở nhưng người chứng kiến vì chưa biết nên tưởng nhầm là bệnh nhân vẫn đang thở bình thường hoặc đang ngủ, và do đó không tiến hành hồi sức tim phổi. 
## **Hồi sức tim phổi là gì?**
Hồi sức tim phổi là một kỹ thuật cứu lấy mạng sống hữu ích trong nhiều trường hợp khẩn cấp, ví dụ đau tim, điện giật, chết đuối, ngạt khí… trong đó hơi thở hoặc nhịp tim của người bệnh đã ngừng. Hiệp hội Tim mạch Hoa Kỳ khuyến cáo tất cả mọi người - những người không được đào tạo và cả nhân viên y tế - nên bắt đầu hồi sức tim phổi bằng phương pháp ép ngực.
Nếu bạn sợ rằng kiến ​​thức hoặc khả năng của bạn chưa hoàn thành 100% thì nên làm điều gì đó tốt hơn nhiều so với không làm gì cả. Hãy nhớ rằng, sự khác biệt giữa việc bạn làm gì đó và không làm gì, là mạng sống của ai đó.
Đây là những lời khuyên từ Hiệp hội Tim mạch Hoa Kỳ:
  * **Không được đào tạo.** Nếu bạn không được đào tạo về HSTP, thì hãy tiến hành chỉ dùng tay. Điều đó có nghĩa là ép ngực không bị gián đoạn từ 100 đến 120 lần mỗi phút cho đến khi nhân viên y tế đến (sẽ được mô tả chi tiết hơn dưới đây). Bạn không cần phải cố gắng giúp thở.
  * **Được đào tạo và sẵn sàng để thực hiện.** Nếu bạn được đào tạo tốt và tự tin vào khả năng của mình, hãy kiểm tra xem có nhịp đập và nhịp thở không. Nếu không có nhịp thở hoặc nhịp đập trong vòng 10 giây, hãy bắt đầu ép ngực. Bắt đầu HSTP với 30 lần ép ngực trước khi giúp thở hai lần.
  * **Được đào tạo nhưng đã lâu.** Nếu trước đây bạn đã được đào tạo HSTP nhưng bạn không tự tin vào khả năng của mình, thì chỉ cần thực hiện ép ngực với tốc độ 100 đến 120 lần một phút. (Chi tiết được mô tả dưới đây.)


Lời khuyên trên áp dụng cho người lớn, trẻ em và trẻ nhỏ (từ 04 tuổi) cần HSTP.
## **Tại sao phải cần hồi sức tim phổi?**
HSTP có thể giữ cho máu cung cấp oxy được đưa đến não và các cơ quan quan trọng khác cho đến khi điều trị y tế chuyên sâu có thể khôi phục nhịp tim bình thường.
Khi tim ngừng đập, việc thiếu oxy có thể gây tổn thương não vĩnh viễn chỉ trong vài phút và một người có thể chết trong vòng tám đến mười phút.
## **Các bước thực hiện hồi sức tim phổi?**
### **Trước khi bắt đầu**
Trước khi bắt đầu HSTP, hãy kiểm tra:
  * Môi trường xung quanh bạn hiện có an toàn?
  * Người bệnh còn ý thức hay không?
  * Nếu người đó bất tỉnh, vỗ hoặc lắc vai và hỏi to
  * Nếu người này không trả lời và có đang sẵn hai người, hãy nhờ một người gọi 115 và lấy AED, và người kia bắt đầu HSTP.
  * Nếu bạn ở một mình và có thể sử dụng ngay điện thoại, hãy gọi 115 trước khi bắt đầu HSTP. Lấy AED, nếu có sẵn.
  * Ngay khi có AED, hãy thực hiện một cú sốc điện nếu thiết bị có hướng dẫn, sau đó bắt đầu HSTP.


### **Nhớ thứ tự các bước: ép ngực- khai thông đường thở- thổi ngạt**
#### **Ép ngực: khôi phục dòng máu lưu thông**
Kỹ thuật này giúp duy trì sự tuần hoàn của lượng máu có chứa oxy trong cơ thể, từ đó giúp phòng tránh nguy cơ tổn thương não và các cơ quan nội tạng.
  * Đặt người nằm ngửa trên một bề mặt vững chắc.
  * Quỳ bên cạnh cổ và vai của người đó.
  * Đặt phần mô mềm của lòng một bàn tay lên giữa ngực của người đó, giữa hai núm vú. Đặt bàn tay khác của bạn lên trên bàn tay đầu tiên. Giữ khuỷu tay của bạn thẳng và phần vai thẳng góc với hai tay của bạn.
  * Sử dụng trọng lượng cơ thể trên của bạn khi bạn đẩy thẳng xuống (ép) ngực trong khoảng 5 - 6cm . Đẩy mạnh với tốc độ 100 đến 120 lần ép một phút.
  * Nếu bạn chưa được đào tạo về HSTP, hãy tiếp tục ép ngực cho đến khi người bệnh có dấu hiệu cử động hoặc cho đến khi nhân viên y tế đến. Nếu bạn đã được huấn luyện về HSTP, hãy tiếp tục khai thông đường thở và giúp thở.


#### **Khai thông đường thở**
Nếu bạn được đào tạo về HSTP và bạn đã thực hiện 30 lần ép ngực, hãy khai thông đường thở của người đó bằng cách sử dụng động tác ngửa đầu, nâng cằm. Đặt lòng bàn tay lên trán của người đó và nhẹ nhàng ngửa đầu ra sau. Sau đó, bằng tay kia, nhẹ nhàng nâng cằm về phía trước để mở thông đường thở. Nếu có dị vật trong miệng hoặc đàm nhớt, cố gắng lấy ra, nên nhớ đừng cố đẩy dị vật vào sâu.
#### **Hà hơi thổi ngạt**
Thổi ngạt có thể là thực hiện bằng miệng-miệng hoặc bằng cách miệng-mũi nếu miệng bị thương nặng hoặc không thể mở được.
  * Khi đường thở mở thông (sử dụng động tác ngửa đầu, nâng cằm), hãy bịt lỗ mũi của người bệnh để thở bằng miệng-miệng và che kín miệng của người bệnh bằng miệng của bạn.
  * Chuẩn bị cho hai hơi thổi ngạt. Lần thổi đầu tiên, thổi kéo dài một giây đồng thời quan sát xem ngực người bệnh có phồng lên không. Nếu phồng lên, tiếp tục với hơi thở thứ hai. Nếu ngực không phồng lên, lặp lại động tác ngửa đầu, nâng cằm và sau đó thổi ngạt lần thứ hai. Ba mươi lần ép ngực sau đó hai nhịp thổi ngạt được coi là một chu kỳ. Cẩn thận không cung cấp quá nhiều lần thổi ngạt hoặc thở với lực quá mạnh.
  * Tiếp tục ép ngực để khôi phục dòng máu lưu thông.
  * Ngay khi có máy khử rung tim bên ngoài tự động (AED), hãy áp dụng nó và làm theo lời hướng dẫn. Thực hiện một cú sốc, sau đó tiếp tục HSTP - bắt đầu bằng ép ngực - thêm hai phút trước khi thực hiện cú sốc thứ hai. Nếu bạn không được đào tạo để sử dụng AED, 115 có thể hướng dẫn bạn sử dụng. Nếu AED không có sẵn, hãy đến bước 5 bên dưới.
  * Tiếp tục HSTP cho đến khi có dấu hiệu cử động hoặc nhân viên y tế khẩn cấp đến.


Trên đây là toàn bộ quy trình HSTP bạn cần làm khi có trường hợp ngưng tuần hoàn ngoài bệnh viện.
## **Tóm tắt:**
Để học HSTP đúng cách, hãy tham gia khóa đào tạo sơ cứu được công nhận, bao gồm HSTP và cách sử dụng máy khử rung tim bên ngoài tự động (AED). Nếu bạn chưa được huấn luyện và có thể sử dụng ngay điện thoại, hãy gọi 115 trước khi bắt đầu. Người điều phối có thể hướng dẫn bạn các cách thực hiện thích hợp cho đến khi có trợ giúp.
Xem thêm: [**Sự cần thiết của bộ dụng cụ sơ cứu**](https://bvnguyentriphuong.com.vn/cap-cuu/su-can-thiet-cua-bo-dung-cu-so-cuu)
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [Các con số và ý nghĩa của việc hồi sức tim phổi:](https://bvnguyentriphuong.com.vn/cap-cuu/so-cap-cuu-hoi-suc-tim-phoi-mang-song-co-the-do-ban-quyet-dinh#cc-con-s-v-ngha-ca-vic-hi-sc-tim-phi)
  * [Hồi sức tim phổi là gì?](https://bvnguyentriphuong.com.vn/cap-cuu/so-cap-cuu-hoi-suc-tim-phoi-mang-song-co-the-do-ban-quyet-dinh#hi-sc-tim-phi-l-g)
  * [Tại sao phải cần hồi sức tim phổi?](https://bvnguyentriphuong.com.vn/cap-cuu/so-cap-cuu-hoi-suc-tim-phoi-mang-song-co-the-do-ban-quyet-dinh#ti-sao-phi-cn-hi-sc-tim-phi)
  * [Các bước thực hiện hồi sức tim phổi?](https://bvnguyentriphuong.com.vn/cap-cuu/so-cap-cuu-hoi-suc-tim-phoi-mang-song-co-the-do-ban-quyet-dinh#cc-bc-thc-hin-hi-sc-tim-phi)
  * [Trước khi bắt đầu](https://bvnguyentriphuong.com.vn/cap-cuu/so-cap-cuu-hoi-suc-tim-phoi-mang-song-co-the-do-ban-quyet-dinh#trc-khi-bt-u)
  * [Nhớ thứ tự các bước: ép ngực- khai thông đường thở- thổi ngạt](https://bvnguyentriphuong.com.vn/cap-cuu/so-cap-cuu-hoi-suc-tim-phoi-mang-song-co-the-do-ban-quyet-dinh#nh-th-t-cc-bc-p-ngc-khai-thng-ng-th-thi-ngt)
  * [Ép ngực: khôi phục dòng máu lưu thông](https://bvnguyentriphuong.com.vn/cap-cuu/so-cap-cuu-hoi-suc-tim-phoi-mang-song-co-the-do-ban-quyet-dinh#p-ngc-khi-phc-dng-mu-lu-thng)
  * [Khai thông đường thở ](https://bvnguyentriphuong.com.vn/cap-cuu/so-cap-cuu-hoi-suc-tim-phoi-mang-song-co-the-do-ban-quyet-dinh#khai-thng-ng-th)
  * [Hà hơi thổi ngạt](https://bvnguyentriphuong.com.vn/cap-cuu/so-cap-cuu-hoi-suc-tim-phoi-mang-song-co-the-do-ban-quyet-dinh#h-hi-thi-ngt)



## ️ Cứu sống bệnh nhân ngưng tim ngưng thở ngoại viện

Lúc 23h00 ngày 10/8/2020 . Khoa Cấp cứu bệnh viện Nguyễn Tri Phương tiếp nhận bệnh nhân nam là bác Nguyễn Văn D . 67 tuổi, địa chỉ Quận 6.
Chị L (con của bệnh nhân) cho hay. Bệnh nhân có tiền sử COPD đang điều trị, tuy nhiên 1 tháng nay thấy sức khỏe trong người ổn định và ngại đến bệnh viện do dịch Covid nên bệnh nhân sử dụng thuốc không điều độ. Cách nhập viện 20P thì bệnh nhân đột ngột lên cơn khó thở. Thấy bố khó thở nhiều, linh tính thấy tình trạng không ổn nên chị L cùng người nhà lập tức kêu taxi đến cấp cứu bệnh viện Nguyễn Tri Phương. Trên xe taxi thì bác D bắt đầu tím tái,ngưng thở và không còn tiếp xúc được nữa 
Sau 10p hồi sức liên tục thì bệnh nhân có tim trở lại. Bệnh nhân được đặt nội khí quản, thở máy và tiếp tục điều trị chuyên sâu thì bệnh nhân có dấu hiệu tỉnh có thể tiếp xúc bằng mắt sau 2h điều trị
Bác D rất cảm ơn các bác sĩ và nhân viên y tế bệnh viện Nguyễn Tri Phương đã đưa mình từ cõi chết trở về. Bác D tâm sự : “sau lần này tôi hứa sẽ điều trị đầy đủ và sẽ tuân theo lời khuyên của bác sĩ, tuyệt đối không tự ý ngưng thuốc, cảm ơn các bác sĩ đã nỗ lực tận tình cứu chữa cho tôi”.
Có thể xem thêm trường hợp này tại trang tin báo Tuổi trẻ đã đưa: [https://tuoitre.vn/cuu-benh-nhan-thoat-cua-tu-sau-10-phut-hoi-suc-tim-phoi-20200818202455337.htm](https://tuoitre.vn/cuu-benh-nhan-thoat-cua-tu-sau-10-phut-hoi-suc-tim-phoi-20200818202455337.htm)
Hình ảnh bác D đã phục hồi hoàn toàn, có thể đi lại và sinh hoạt bình thường, dự kiến sẽ xuất viện trong thời gian tới. Bác D đồng ý cho phép ban biên tập đăng hình của bác như một lời cảm ơn đến Bệnh viện.
**Bệnh viện Nguyễn Tri Phương** - Bệnh viện Đa khoa Hạng I Thành phố Hồ Chí Minh
  * 468 Nguyễn Trãi, Phường 8, Quận 5, Tp. Hồ Chí Minh
  * Hotline: (84-028) 39234332
  * Mạng xã hội **Facebook:** **[Bệnh viện Nguyễn Tri Phương](https://www.facebook.com/BVNTP/)**
  * Đăng ký (Subcribe) kênh **Youtube:**[ https://youtube.com/bvntp](https://youtube.com/bvntp?fbclid=IwAR3q_UvPI4OZAebT1uQGPKKwk3RmCzAFLkBJm9lb7EwIz0EHtgiLhKM5bxU)
  * Quan tâm Zalo Official: [zalo.me/1744466261097093886](https://zalo.me/1744466261097093886?fbclid=IwAR3E-fLqdh-x1cYSvuDY6E5Eyxfjo5ZSs4p0hDWAyBG-ROlTkxXkXvdEWAY)



## ️ Sốt xuất huyết - Hãy luôn đề phòng!



## **Nguyên nhân:**
Sốt xuất huyết là bệnh truyền nhiễm cấp tính do virus Dengue gây ra. Nguyên nhân lây lan bệnh là do muỗi vằn truyền virus Dengue từ người bệnh sang người khỏe mạnh. Virus Dengue có 4 type huyết thanh là DEN-1, DEN-2, DEN-3 và DEN-4
## **Triệu chứng:**
Thông thường ở trẻ em và thanh thiếu niên ít xuất hiện các triệu chứng trong khoảng thời gian đầu khi tiếp xúc với virus sốt xuất huyết. Một các trường hợp nặng, các triệu chứng sẽ xuất hiện sau khoảng 4 đến 7 ngày kể từ khi bị muỗi đốt.
Các triệu chứng của sốt xuất huyết như:
  * Sốt cao trên 40oC.
  * Đau đầu, đau cơ, xương khớp.
  * Nôn hoặc buồn nôn,
  * Đau sau mắt.
  * Sưng các hạch bạch huyết.
  * Phát ban.


Thông thường, bệnh nhân phục hồi sau khoảng từ 7 đến 10 ngày. Tuy nhiên trong một số trường hợp tình trạng bệnh nhân có thể xấu đi, thậm chí đe dọa đên tính mạng:
  * Mạch máu bị tổn thương, dễ vỡ.
  * Số lượng tiểu cầu giảm mạnh.
  * Đau bụng quằn quại.
  * Nôn liên tục.
  * Chảy máu từ nướu hay mũi.
  * Máu trong nước tiểu, phân hoặc nôn ra máu.
  * Xuất huyết dưới da.
  * Khó thở hoặc thở nhanh.
  * Da lạnh và rịn mồ hôi.
  * Mệt mỏi, khó chịu, bồn chồn


**Nếu có các triệu chứng của sốt xuất huyết, cần nhập viện ngay để có những theo dõi và điều trị kịp thời.**
## **Biến chứng:**
  * Trường hợp nghiêm trọng, sốt xuất huyết có thể gây tổn thương phổi, gan, tim. Tụt huyết áp đột ngột có thể gây sốc và trong một số trường hợp có thể dẫn đến tử vong.
  * Sốt xuất huyết ở trẻ em có thể bị chẩn đoán nhầm lẫn với các loại nhiễm siêu vi khác, tỉ lệ tử vong ở nhóm trẻ có sốt cao (6,3%)
  * Ở bệnh nhân lớn tuổi, sức đề kháng yếu thời gian nằm viện dài ngày có thể dẫn đến nhiễm trùng, nguy cơ tử vong cao hơn.
  * Sốt xuất huyết ở phụ nữ mang thai có thể dẫn đến sẩy thai, trẻ sanh non, nhẹ cân…


## **Phòng ngừa:**
  * Tiêm vắc-xin ở những người độ tuổi từ 9 đến 45 ở những vùng có tỉ lệ mắc sốt xuất huyết cao. Vắc-xin có tác dụng bảo vệ tốt với những đối tượng đã từng mắc sốt xuất huyết trước đó. Các chuyên gia khuyến cáo rằng không áp dụng ở trẻ nhỏ bởi tiêm vắc- xin làm tăng mức độ trầm trọng khi mắc phải sốt xuất huyết 2 năm sau khi tiêm ngừa.
  * Cách tốt nhất để ngăn ngừa sốt xuất huyết là tránh bị muỗi đốt, bằng các biện pháp như:


+ Loại bỏ nơi sinh sản của muỗi, diệt lăng quăng/bọ gậy bằng cách:
Đậy kín tất cả các dụng cụ chứa nước, thả cá vào các vật dụng chứa nước lớn.
Thau rửa các dụng chụ chứa nước vừa và nhỏ hàng tuần.
Thu gom, hủy các vật dụng phế thải trong nhà và xung quanh nhà, dọn vệ sinh môi trường, lật úp các dụng cụ chứa nước khi không cần thiết.
+ Mặc đồ bảo hộ, áo dài tay, quần dài, mang vớ, găng tay…
+ Ngủ màn (mùng) kể cả ban ngày, sử dụng thuốc bôi hay xịt chống muỗi, sử dụng rèm che, màn tẩm thuốc diệt muỗi.
+ Để người bị sốt xuất huyết nằm trong màn, tránh muỗi đốt lây lan cho người khác.
Dịp hè thời tiết thay đổi, nhiều ao tù nước đọng là dịp để muỗi sinh sôi, truyền bệnh. Vậy hãy thực hiện các biện phải bảo vệ gia đình và người thân của bạn tránh khỏi sốt xuất huyết. Đối với công cuộc bảo vệ và giữ gìn sức khỏe, phòng bệnh sẽ luôn luôn tốt hơn chữa bệnh.
Xem thêm: [**Những điều cần biết về bệnh tay, chân và miệng**](https://bvnguyentriphuong.com.vn/khoa-kham-benh/nhung-dieu-can-biet-ve-benh-tay-chan-va-mieng)
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh



## ️ Sự cần thiết của bộ dụng cụ sơ cứu

  * [Bộ sơ cứu tại nhà và du lịch.](https://bvnguyentriphuong.com.vn/cap-cuu/su-can-thiet-cua-bo-dung-cu-so-cuu#b-s-cu-ti-nh-v-du-lch)
  * [Cách tạo bộ sơ cứu](https://bvnguyentriphuong.com.vn/cap-cuu/su-can-thiet-cua-bo-dung-cu-so-cuu#cch-to-b-s-cu)
  * [Cách sử dụng bộ sơ cứu](https://bvnguyentriphuong.com.vn/cap-cuu/su-can-thiet-cua-bo-dung-cu-so-cuu#cch-s-dng-b-s-cu)
  * [Nơi cất giữ bộ sơ cứu:](https://bvnguyentriphuong.com.vn/cap-cuu/su-can-thiet-cua-bo-dung-cu-so-cuu#ni-ct-gi-b-s-cu)
  * [Bộ dụng cụ sơ cứu tại nhà và đi du lịch](https://bvnguyentriphuong.com.vn/cap-cuu/su-can-thiet-cua-bo-dung-cu-so-cuu#b-dng-c-s-cu-ti-nh-v-i-du-lch)
  * [Vật dụng phải có trong bộ sơ cứu](https://bvnguyentriphuong.com.vn/cap-cuu/su-can-thiet-cua-bo-dung-cu-so-cuu#vt-dng-phi-c-trong-b-s-cu)
  * [Bộ sơ cứu gia đình:](https://bvnguyentriphuong.com.vn/cap-cuu/su-can-thiet-cua-bo-dung-cu-so-cuu#b-s-cu-gia-nh)
  * [​​Bộ sơ cứu du lịch](https://bvnguyentriphuong.com.vn/cap-cuu/su-can-thiet-cua-bo-dung-cu-so-cuu#b-s-cu-du-lch)


## **Bộ sơ cứu tại nhà và du lịch.**
Bộ dụng cụ sơ cứu tại nhà thường được sử dụng để điều trị các loại chấn thương nhẹ sau:
  * Bỏng;
  * Vết cắt, xước;
  * Châm chích;
  * Mảnh vụn;
  * Bong gân.


Bộ dụng cụ sơ cứu khi đi du lịch cần phải đầy đủ hơn. Ngoài các vật dụng y tế cá nhân, bộ dụng cụ này nên có các vật dụng giúp giảm bớt các triệu chứng của nhiễm trùng đường hô hấp như :
  *   * Nghẹt mũi;
  * Đau họng.
  * Nên có các vật dụng- thuốc để điều trị :
  * Vết đứt;
  * Đau nhẹ;
  * Các vấn đề về dạ dày-ruột;
  * Các vấn đề về da;
  * Dị ứng.


## **Cách tạo bộ sơ cứu**
Cố gắng giữ cho bộ dụng cụ của bạn nhỏ và đơn giản. Dự trữ nó với các vật dụng nhiều đa năng. Hầu hết bất cứ vật dụng có hình ảnh dễ nhận diện tính năng đều nên được sử dụng cho một bộ sơ cứu gia đình. Nếu phải di chuyển, thì tốt nhất là một hộp đựng chống nước, chống rơi. Túi nylon, bộ dụng cụ cá nhân, hoặc hộp đựng đồ trang điểm đều có thể tận dụng tốt. Không cần phải chi nhiều tiền cho một chiếc “túi y tế” sang trọng. Hãy sử dụng túi có nhiều ngăn, đặt dụng cụ vết thương vào một ngăn và thuốc vào ngăn khác.
## **Cách sử dụng bộ sơ cứu**
Đảm bảo rằng bạn biết cách sử dụng các vật dụng trong bộ dụng cụ của mình, đặc biệt là thuốc. Huấn luyện những người khác trong gia đình bạn sử dụng bộ dụng cụ này bởi bạn có thể là người cần sơ cứu.
Đóng gói và dùng vật dụng che chắn như găng tay cao su để bảo vệ bạn khỏi chất dịch cơ thể của người khác. Kiểm tra bộ dụng cụ hai lần một năm và thay thế thuốc hết hạn. Tìm số điện thoại của trung tâm hỗ trợ y tế gần nhất và giữ số điện thoại này cùng với bộ dụng cụ của mình.
## **Nơi cất giữ bộ sơ cứu:**
Nơi tốt nhất để giữ bộ sơ cứu là trong nhà bếp. Hầu hết các hoạt động của gia đình đều diễn ra ở đây. Phòng tắm nhiều ẩm khiến thời hạn sử dụng của các vật dụng bị rút ngắn. Đối với bộ dụng cụ dùng cho những chuyến đi xa. Giữ nó trong vali, ba lô hoặc túi khô, tùy thuộc vào hoạt động. Một bộ sơ cứu để sử dụng hàng ngày trong ô tô phải giống như bộ sơ cứu tại nhà. Tương tự đối với ở trong thuyền (bên trong túi chống thấm nước), xe du lịch, nhà di động, lều trại, cabin, nhà nghỉ...
## **Bộ dụng cụ sơ cứu tại nhà và đi du lịch**
### **Vật dụng phải có trong bộ sơ cứu**
Có thể mua tất cả các mặt hàng cho bộ dụng cụ sơ cứu của mình tại một cửa hàng thuốc có sẵn. Yêu cầu dược sĩ giúp đỡ trong việc lựa chọn các mặt hàng.
### **Bộ sơ cứu gia đình:**
Một bộ sơ cứu gia đình nên bao gồm:
  * Băng cá nhân (tất cả các kích cỡ);
  * Xịt gây tê hoặc kem bôi cho trường hợp phát ban ngứa và côn trùng cắn;
  * Miếng gạc vô trùng - để che phủ và làm sạch vết thương;
  * Băng quấn để quấn các khớp bị bong gân, quấn gạc vào vết thương, quấn nẹp;
  * Thuốc kháng histamine - diphenhydramine (Benadryl gây buồn ngủ) hoặc loratadine (Claritin không gây buồn ngủ) đối với các phản ứng dị ứng, phát ban ngứa (Tránh dùng kem bôi kháng histamine vì chúng có thể làm trầm trọng thêm tình trạng phát ban ở một số người);
  * Corticosteroid tại chỗ, chẳng hạn như Hydrocortisone 1% khi phát ban;
  * Gel hoặc kem bôi ngoài da để giảm bỏng;
  * Găng tay - để bảo vệ chống nhiễm trùng, có thể dùng làm túi đá khi chứa đầy nước và đông lạnh;
  * Kem bôi kháng sinh - bôi lên vết thương đơn giản;
  * Miếng dán không dính (Telfa) - để che vết thương và vết bỏng;
  * Túi nylon - như một hộp đựng các vật phẩm bị ô nhiễm, có thể trở thành một túi đá;
  * Chốt cố định - để cố định băng quấn hình tam giác;
  * Cây kéo;
  * Khăn, garô;
  * Nhíp - để lấy mảnh hoặc ngòi hoặc bọ ve.


### **​​Bộ sơ cứu du lịch**
Bộ sơ cứu du lịch bao gồm :
  * Băng dính (tất cả các kích cỡ);
  * Miếng gạc vô trùng;
  * Thuốc kháng axit - cho chứng khó tiêu;
  * Chống tiêu chảy (ví dụ: Imodium, Pepto-Bismol);
  * Kem bôi kháng histamine;
  * Chất khử trùng (oxy già..) - để làm sạch vết thương và tay;
  * Aspirin - giảm đau nhẹ, đau tim;
  * Diphenhydramine (Benadryl) hoặc loratadine (Claritin) - thuốc uống kháng histamine;
  * Corticosteroid tại chỗ, như Hydrocortisone 1% dùng cho phát ban;
  * Gel hoặc kem bôi ngoài để giảm bỏng;
  * Sách về sơ cứu;
  * Bật lửa - để khử trùng dụng cụ và có thể nhóm lửa trong vùng hoang dã (để giữ ấm và tạo khói để báo hiệu sự giúp đỡ);
  * Thuốc ho;
  * Bộ dụng cụ nha khoa - dành cho răng bị gãy, trám răng;
  * Găng tay;
  * Đèn pin nhỏ;
  * Ibuprofen;
  * Thuốc diệt côn trùng;
  *   * Thuốc thông mũi dạng xịt - để nghẹt mũi do cảm lạnh hoặc dị ứng;
  * Băng vết thương không dính (Telfa);
  * Thuốc bôi kháng sinh polysporin;
  * Thẻ điện thoại có thời gian sử dụng ít nhất 60 phút (và không phải ngày hết hạn gần nhất) và danh sách những người quan trọng cần liên hệ trong trường hợp khẩn cấp;
  * Mặt nạ bỏ túi để hô hấp nhân tạo;
  * Chốt an toàn (lớn và nhỏ);
  * Cây kéo;
  * Nhiệt kế;
  * Cái nhíp


Xem thêm: [**10 mẹo sơ cứu có thể giúp bạn khi cần thiết**](https://bvnguyentriphuong.com.vn/cap-cuu/10-meo-so-cuu-co-the-giup-ban-khi-can-thiet)
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [Bộ sơ cứu tại nhà và du lịch.](https://bvnguyentriphuong.com.vn/cap-cuu/su-can-thiet-cua-bo-dung-cu-so-cuu#b-s-cu-ti-nh-v-du-lch)
  * [Cách tạo bộ sơ cứu](https://bvnguyentriphuong.com.vn/cap-cuu/su-can-thiet-cua-bo-dung-cu-so-cuu#cch-to-b-s-cu)
  * [Cách sử dụng bộ sơ cứu](https://bvnguyentriphuong.com.vn/cap-cuu/su-can-thiet-cua-bo-dung-cu-so-cuu#cch-s-dng-b-s-cu)
  * [Nơi cất giữ bộ sơ cứu:](https://bvnguyentriphuong.com.vn/cap-cuu/su-can-thiet-cua-bo-dung-cu-so-cuu#ni-ct-gi-b-s-cu)
  * [Bộ dụng cụ sơ cứu tại nhà và đi du lịch](https://bvnguyentriphuong.com.vn/cap-cuu/su-can-thiet-cua-bo-dung-cu-so-cuu#b-dng-c-s-cu-ti-nh-v-i-du-lch)
  * [Vật dụng phải có trong bộ sơ cứu](https://bvnguyentriphuong.com.vn/cap-cuu/su-can-thiet-cua-bo-dung-cu-so-cuu#vt-dng-phi-c-trong-b-s-cu)
  * [Bộ sơ cứu gia đình:](https://bvnguyentriphuong.com.vn/cap-cuu/su-can-thiet-cua-bo-dung-cu-so-cuu#b-s-cu-gia-nh)
  * [​​Bộ sơ cứu du lịch](https://bvnguyentriphuong.com.vn/cap-cuu/su-can-thiet-cua-bo-dung-cu-so-cuu#b-s-cu-du-lch)



## ️ Những điều cần biết về viêm phúc mạc

  * [Phúc mạc là gì?](https://bvnguyentriphuong.com.vn/cap-cuu/nhung-dieu-can-biet-ve-viem-phuc-mac#phc-mc-l-g)
  * [Nguyên nhân gây viêm phúc mạc](https://bvnguyentriphuong.com.vn/cap-cuu/nhung-dieu-can-biet-ve-viem-phuc-mac#nguyn-nhn-gy-vim-phc-mc)
  * [Chẩn đoán viêm phúc mạc](https://bvnguyentriphuong.com.vn/cap-cuu/nhung-dieu-can-biet-ve-viem-phuc-mac#chn-on-vim-phc-mc)
  * [Điều trị viêm phúc mạc](https://bvnguyentriphuong.com.vn/cap-cuu/nhung-dieu-can-biet-ve-viem-phuc-mac#iu-tr-vim-phc-mc)


## **Phúc mạc là gì?**
Khoang bụng chứa các cơ quan chính của **hệ tiêu hóa** như dạ dày và ruột. Ngoài ra cũng chứa các cơ quan khác như **gan** và **thận**.
Phúc mạc là một màng thanh mạc lớn nhất trong cơ thể. Phúc mạc bao bọc tất cả các cơ quan trong ổ bụng và hố chậu, lót mặt trong thành bụng, mặt dưới cơ hoành và mặt trên hoành chậu hông. Phúc mạc xếp dọc theo thành bụng nhưng cũng hình thành các nếp gấp đi vào bên trong. Bằng cách gấp lại, phúc mạc lót giữa các cơ quan tạo một màng bảo vệ, giảm ma sát.
## **Triệu chứng**
**Viêm phúc mạc** cần được chăm sóc y tế khẩn cấp. Triệu chứng chính là đau bụng đột ngột, dữ dội và cơn đau trở nên nghiêm trọng hơn. Một số ảnh hưởng của viêm phúc mạc có liên quan đến các tác động nghiêm trọng trong cơ thể như mất nước và sốc. Các triệu chứng khác bao gồm:
  *   * Buồn nôn và ói mửa;
  * Bệnh tiêu chảy;
  * Ăn mất ngon;
  * Nhịp tim nhanh;
  * Không thể “xì hơi”, gặp khó khăn trong việc tiểu tiện.


### **Bụng chướng**
Bụng chướng cũng là triệu chứng của viêm phúc mạc. Khi vỡ gây viêm phúc mạc, dịch lấp đầy khoang bụng và ruột, dẫn đến mất dịch từ phần còn lại của cơ thể.
Khi bệnh gan là nguyên nhân gây viêm phúc mạc, bụng chướng có thể xảy ra vì một lý do khác xảy ra mà không có nguyên nhân gây thủng trong các loại viêm phúc mạc khác. Tình trạng này được biết đến viêm phúc mạc do vi khuẩn tự phát.
Dạng viêm phúc mạc này có các triệu chứng khác nhau. Khó chịu là triệu chứng chính của viêm phúc mạc do vi khuẩn tự phát và do áp lực của dịch báng tăng lên. Đối với những người mắc bệnh **gan****cổ trướng** bị nhiễm trùng có xuất hiện các cơn đau từ nhẹ đến trung bình và thường không nghiêm trọng.
## **Biến chứng**
Nếu không điều trị kịp thời, viêm phúc mạc có thể dẫn đến các tình trạng nguy hiểm hơn như **nhiễm trùng huyết** và **sốc nhiễm trùng**. Do đó, tình trạng này có thể nhanh chóng trở nên nguy hiểm đến tính mạng.
## **Nguyên nhân gây viêm phúc mạc**
Nhiễm trùng thứ phát gây ra hầu hết các trường hợp viêm phúc mạc và một số ít trường hợp là nhiễm trùng nguyên phát ở phúc mạc.
Một tổn thương trong ruột thường là nguyên nhân gây viêm phúc mạc ví dụ như ruột thừa vỡ hoặc thủng do loét dạ dày nghiêm trọng.
Những người đang chạy thận nhân tạo bằng phương pháp trao đổi **dịch màng bụng** cũng có thể bị nhiễm trùng. Các nguyên nhân khác bao gồm:
  * Viêm tụy;
  * Viêm ruột do các tình trạng như **bệnh Crohn** ;
  * Viêm túi thừa, hoặc viêm túi trong thành ruột lớn;
  * Chấn thương gây chấn thương bụng, như vết thương do dao hoặc súng.


Viêm phúc mạc có thể xảy ra với những người có dịch dư thừa trong bụng do bệnh mãn tính đặc biệt là bệnh gan. Ngoài ra, phúc mạc cũng có thể bị ảnh hưởng bởi bệnh ung thư.
## **Chẩn đoán viêm phúc mạc**
Những người nghi ngờ viêm phúc mạc nên đến bác sĩ để chẩn đoán càng sớm càng tốt. Việc khai báo đúng các triệu chứng có thể giúp các bác sĩ chẩn đoán và điều trị chính xác
Người bị viêm phúc mạc có thể không nhận thấy bất kỳ triệu chứng nào nhưng bác sĩ có thể phát hiện tình trạng trước khi các triệu chứng trở nên trầm trọng hơn.
Trong quá trình lọc màng bụng cho bệnh thận, bệnh nhân sẽ có nguy cơ bị nhiễm trùng qua thành bụng. Các bác sĩ sẽ theo dõi sự xuất hiện và có thể chẩn đoán và điều trị viêm phúc mạc ngay lập tức nếu chất dịch này bị đục.
Đối với bất kỳ trường hợp nghi ngờ viêm phúc mạc, bác sĩ kiểm tra các dấu hiệu bằng cách tiến hành kiểm tra bụng. Các kỹ thuật chuyên sâu hơn được thực hiện để kiểm tra nhiễm trùng bao gồm:
  * Mẫu máu để xác nhận phản ứng miễn dịch;
  * Mẫu máu để kiểm tra các biến chứng vi khuẩn rộng hơn;
  * Chụp **X-quang** hoặc **siêu âm** để giúp xác định vị trí vỡ trong ruột;
  * **Chụp CT** có thể cung cấp hình ảnh chi tiết hơn.


## **Chọc hút**
Một thủ thuật chẩn đoán khác là chọc hút bằng cách lấy chất dịch trực tiếp từ bụng để kiểm tra nhiễm trùng.
Chất dịch dư thừa trong bụng có thể lấp đầy khoang bụng giữa các cơ quan. Tình trạng này được gọi là cổ trướng, và chất dịch được gọi là chất dịch cổ trướng.
Xét nghiệm bao gồm gửi mẫu chất dịch để phân tích số lượng **bạch cầu** và hóa sinh. Phòng xét nghiệm cũng có thể tìm kiếm hoặc nuôi cấy các vi khuẩn khác dưới kính hiển vi. Không phải tất cả các trường hợp viêm phúc mạc cần phải đặt nội soi.
Theo một nghiên cứu tại Hoa Kỳ, viêm phúc mạc do vi khuẩn tự phát được tìm thấy ở khoảng **20%** những người nhập viện với cổ trướng vì bệnh xơ gan.
## **Điều trị viêm phúc mạc**
Viêm phúc mạc được xem là một tình trạng cấp cứu và cần được tiến hành điều trị tại bệnh viện. Các lựa chọn điều trị sẽ bao gồm:
  * **Thuốc kháng sinh:** Chúng có thể được đưa trực tiếp vào máu bằng cách tiêm tĩnh mạch (IV). Thông thường bệnh nhân sẽ được sử dụng kháng sinh đa năng trước khi chờ xét nghiệm để xác định nguyên nhân gây viêm phúc mạc. Nếu các loại thuốc kháng sinh phổ rộng không có tác dụng mong muốn, bác sĩ có thể sử dụng các loại thuốc kháng sinh nhắm đích cụ thể hơn.
  * **Phẫu thuật:** Bác sĩ sẽ xem xét phẫu thuật trong trường hợp trong một số nguyên nhân.
  * Các liệu pháp hỗ trợ rộng hơn: Những liệu pháp này có thể bao gồm từ hỗ trợ sinh hoạt đến hỗ trợ chế độ ăn uống.


## **Phòng ngừa**
Viêm phúc mạc không phải lúc nào cũng có thể phòng ngừa được và tình trạng này có thể xảy ra mà không có các triệu chứng báo trước.
Vệ sinh cá nhân tốt là điều rất quan trọng đặc biệt đúng đối với những người mắc bệnh thận đang tiến hành phương pháp lọc màng bụng. Viêm phúc mạc có thể gây ra theo cách này, vì vậy các chế phẩm vệ sinh trước khi lọc máu cần được đảm bảo để ngăn ngừa viêm phúc mạc.
Điều trị nhanh chóng có thể giúp ngăn ngừa một số trường hợp viêm phúc mạc tiềm ẩn. Nếu thủng ruột hoặc vỡ ruột là nguyên nhân, can thiệp nhanh chóng có thể ngăn chặn tình trạng phát triển.
Trong tất cả các trườngng hợp, cần liên hệ các cơ sở y tế gần nhất nếu bắt đầu có triệu chứng đau bụng dữ dội.
Xem thêm: 
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [Phúc mạc là gì?](https://bvnguyentriphuong.com.vn/cap-cuu/nhung-dieu-can-biet-ve-viem-phuc-mac#phc-mc-l-g)
  * [Nguyên nhân gây viêm phúc mạc](https://bvnguyentriphuong.com.vn/cap-cuu/nhung-dieu-can-biet-ve-viem-phuc-mac#nguyn-nhn-gy-vim-phc-mc)
  * [Chẩn đoán viêm phúc mạc](https://bvnguyentriphuong.com.vn/cap-cuu/nhung-dieu-can-biet-ve-viem-phuc-mac#chn-on-vim-phc-mc)
  * [Điều trị viêm phúc mạc](https://bvnguyentriphuong.com.vn/cap-cuu/nhung-dieu-can-biet-ve-viem-phuc-mac#iu-tr-vim-phc-mc)



## Codeblue: Cứu sống bệnh nhân ngưng tim, ngưng thở trên đường chuyển viện

Khi còn ở nhà, trước khi nhập viện 1 giờ, bệnh nhân đột ngột nặng ngực, khó thở. Người nhà gọi xe taxi đưa vào bệnh viện, nhưng trước khi vào đến cấp cứu, bệnh nhân gục xuống xe, tím tái, người nhà kêu không thấy trả lời.
_BS CKII Nguyễn Quang Dũng – TK Cấp cứu BV Nguyễn Tri Phương, cho biết bệnh nhân Dương V. K. (71 tuổi, Quận 6) đã được cứu sống, bình phục và không bị tổn thương não, dù đã ngưng tim ngưng thở hơn 5 phút trên đường vào viện. Ảnh: An Quý_
“Chúng tôi tiếp nhận bệnh nhân này trong tình trạng ngưng tim, ngừng thở. Các bác sĩ tiến hành hồi sức cấp cứu tim phổi tích cực như nhấn tim, bóp bóng giúp thở. Trên màn hình giám sát của máy sốc điện lúc đó là một đường thẳng, trong y khoa gọi là vô tâm thu, tức là không tim không còn đập. Tuy nhiên, chúng tôi vẫn không từ bỏ vì vẫn hy vọng cứu sống bệnh nhân do người nhà cho biết, bệnh nhân vừa mới gục xuống chừng 5 phút,” BS. Dũng nhớ lại.
Hơn 15 phút sau, may mắn những cố gắng của ê kíp cấp cứu không uổng phí, tim bệnh nhân đập trở lại. Bệnh nhân tiếp tục được đặt ống nội khí quản để giúp thở. Kết quả đo điện tâm sau hồi sức cho thấy bệnh nhân có dấu hiệu bị nhồi máu cơ tim cấp vùng phía dưới của quả tim.
“Bệnh nhân được hội chẩn và chuyển lên khoa Tim mạch can thiệp để điều trị can thiệp mạch vành. Tuy nhiên, bệnh nhân không có điều kiện về kinh tế để điều trị can thiệp mạch vành. Nên giai đoạn đầu, bệnh nhân được các bác sĩ điều trị bảo tổn bằng thuốc. Trong thời gian đó, bệnh nhân tiếp tục phải thở máy, uống thuốc. Bệnh nhân liên tục khó thở, phù phổi do suy tim. Bệnh nhân có những lần bị loạn nhịp tim, phải sốc điện tim nhiều lần,” BS. Dũng cho biết thêm.
_Bệnh nhân K. đã bình phục và được tái khám lần đầu vào ngày 29/8 sau khi xuất viện._
Được biết, chi phí điều trị can thiệp mạch vành tùy thuộc vào stent có thuốc hay không, bao nhiêu stent cần đặt, mà ước tính từ 50 – 90 triệu đồng, bảo hiểm y tế hỗ trợ một phần. Quỹ Từ Tâm đã hỗ trợ bệnh viện và bệnh nhân trong điều trị can thiệp mạch vành.
Kết quả chụp mạch vành cho thấy, ba mạch máu nuôi tim đều bị hẹp nặng, trong đó có một nhánh – động mạch vành phải, động mạch nuôi phần phía dưới quả tim - tắt hoàn toàn. Bệnh nhân đã được can thiệp đặt 2 stent thành công. Bệnh nhân hiện đã xuất viện sau 12 ngày nằm viện và không có di chứng bị tổn thương não sau cái ngưng tim, ngừng thở suốt 5 phút trên đường vào cấp cứu.
Từ tháng 7/2018, Khoa Cấp cứu (BV Nguyễn Tri Phương) đã triển khai Codeblue - quy trình phản ứng nhanh cứu sống bệnh nhân bị ngưng tim, ngưng thở không chỉ áp dụng cho các khoa phòng có bệnh nhân lâm vào tình trạng này mà còn cứu sống được rất nhiều ca từ ngoài chuyển vào. Đội này gồm 1 bác sĩ, 1 điều dưỡng và 1 nhân viện vận chuyển mang theo máy sốc điện.
Ngưng tim hiện nay chủ yếu do loạn nhịp tim và trong điều trị hồi sức tim phổi, khâu quan trọng nhất là phải nhấn tim sớm và sốc điện dành cho những trường hợp rung thất, loạn nhịp tim nặng.
**Trích nguồn Sức khỏe và đời sống**

