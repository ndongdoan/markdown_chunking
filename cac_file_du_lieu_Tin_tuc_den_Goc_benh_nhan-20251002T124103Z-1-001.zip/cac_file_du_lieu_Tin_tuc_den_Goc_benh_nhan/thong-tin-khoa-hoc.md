## Chiêu sinh lớp đào tạo liên tục chuyên đề “Thận Học - Lọc Máu” năm 2025

**Xem toàn bộ:[Thông báo Chiêu sinh](https://bvnguyentriphuong.com.vn/uploads2025/files/2025%20CS%20-%20Th%C3%B4ng%20b%C3%A1o%20chi%C3%AAu%20sinh%20Th%E1%BA%ADn%20L%E1%BB%8Dc%20m%C3%A1u.pdf)**

## Tổ chức lớp bồi dưỡng 'Quản lý chất lượng bệnh viện' cho nhân viên y tế

  * [HÌNH THỨC TỔ CHỨC](https://bvnguyentriphuong.com.vn/thong-tin-khoa-hoc/to-chuc-lop-boi-duong-quan-ly-chat-luong-benh-vien-cho-nhan-vien-y-te#hnh-thc-t-chc)
  * [Thông tin khóa học:](https://bvnguyentriphuong.com.vn/thong-tin-khoa-hoc/to-chuc-lop-boi-duong-quan-ly-chat-luong-benh-vien-cho-nhan-vien-y-te#thng-tin-kha-hc)
  * [NỘI DUNG TẬP HUẤN ](https://bvnguyentriphuong.com.vn/thong-tin-khoa-hoc/to-chuc-lop-boi-duong-quan-ly-chat-luong-benh-vien-cho-nhan-vien-y-te#ni-dung-tp-hun)


Trường Đại học Nguyễn Tất Thành phối hợp cùng Bệnh viện Nguyễn Tri Phương tổ chức lớp bồi dưỡng "Quản lý chất lượng bệnh viện" cho nhân viên y tế.
**MỤC ĐÍCH, YÊU CẦU**
**Mục đích:** Trang bị kiến thức và kỹ năng quản lý chất lượng bệnh viện cho lãnh đạo bệnh viện, lãnh đạo khoa phòng và nhân viên mạng lưới chất lượng bệnh viện, từ đó có năng lực triển khai dự án cải tiến thực tiễn.
**Yêu cầu:**
  * Việc tổ chức lớp tập huấn phải thiết thực, hiệu quả và tiết kiệm.
  * Các thành phần tham dự cần tham gia một cách nghiêm túc và đầy đủ thời lượng của chương trình tập huấn.


## **HÌNH THỨC TỔ CHỨC**
### **Thông tin khóa học:**
**Lịch học:**
  * Khóa học diễn ra từ ngày 18/06/2025 đến ngày 10/07/2025.
  * Thứ 4 và thứ 5 hàng tuần (vào các ngày 18, 19, 25, 26 tháng 6 và các ngày 2, 3, 9, 10, 16 tháng 7). 


**Lưu ý:** Học viên vắng quá 02 buổi sẽ không được cấp chứng chỉ.
**Thời gian:** : Chiều từ 13h30 đến 17h00.
**Tổng thời lượng đào tạo:** 36 giờ, chia thành 9 buổi.
**Địa điểm:** Hội trường A, lầu 5, Bệnh viện Nguyễn Tri Phương.
**Giảng viên:**
Khoa Y học cổ truyền - Quản lý Y tế, Trường Đại học Nguyễn Tất Thành: 
  * GS. TS. Nguyễn Văn Tập.
  * TS. Lê Thanh Chiến.
  * TS. Phí Vĩnh Bảo.
  * TS. Phạm Văn An.


Bệnh viện Nguyễn Tri Phương: 
  * BSCK2. Lương Công Minh - Phó Giám đốc Bệnh viện


## **NỘI DUNG TẬP HUẤN**
**Buổi 1:**
  * Đại cương về quản lý chất lượng. 
  * Vai trò của người lãnh đạo, quản lý trong quản lý chất lượng bệnh viện.
  * Động viên và khuyến khích nhân viên trong cải tiến chất lượng bệnh viện.
  * Hướng dẫn công tác quản lý chất lượng bệnh viện.
  * Đo lường chất lượng bệnh viện.
  * Lập kế hoạch chiến lược.


**Buổi 2:** Xây dựng đề án cải tiến chất lượng bệnh viện (PDCA) 
  * Cách xác định vấn đề tồn tại và ưu tiên trong quản lý chất lượng để lập kế hoạch cải tiến.
  * Liệt kê các quy trình về quản lý nguồn lực và chuyên môn bệnh viện.
  * Bảng kế hoạch cải tiến chất lượng bệnh viện (PDCA), biểu mẫu.
  * Thực hành lập kế hoạch cải tiến chất lượng (PDCA) theo nhóm và trình bày kết quả.


**Buổi 3-8:** Hướng dẫn và thực hành lập kế hoạch cải tiến chất lượng (PDCA) theo nhóm 3 học viên và trình bày kết quả. 
**Buổi 9:** Tổng kết và báo cáo PDCA.
Quý đồng nghiệp đăng ký tham gia vui lòng liên hệ: 0947516761 (Bác sĩ Tài)
**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/)** - Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [HÌNH THỨC TỔ CHỨC](https://bvnguyentriphuong.com.vn/thong-tin-khoa-hoc/to-chuc-lop-boi-duong-quan-ly-chat-luong-benh-vien-cho-nhan-vien-y-te#hnh-thc-t-chc)
  * [Thông tin khóa học:](https://bvnguyentriphuong.com.vn/thong-tin-khoa-hoc/to-chuc-lop-boi-duong-quan-ly-chat-luong-benh-vien-cho-nhan-vien-y-te#thng-tin-kha-hc)
  * [NỘI DUNG TẬP HUẤN ](https://bvnguyentriphuong.com.vn/thong-tin-khoa-hoc/to-chuc-lop-boi-duong-quan-ly-chat-luong-benh-vien-cho-nhan-vien-y-te#ni-dung-tp-hun)



## Tổ chức lớp Tập huấn xây dựng và triển khai cải tiến chất lượng theo Lean Six Sigma

**Tổng quan về LEAN và tầm quan trọng của khóa học**
Lean Six Sigma là hệ thống bao gồm những triết lý, tư duy, cách tiếp cận, phương pháp, công cụ, kỹ thuật, cho cải tiến chất lượng và quản trị vận hành được các chuyên gia, các nhà khoa học trên toàn thế giới phát triển trong hơn 20 năm nay.
Lean Six Sigma đã được ứng dụng rộng rãi, mang đến hiệu quả thiết thực cho rất nhiều tổ chức, trong nhiều lĩnh vực khác nhau trên toàn thế giới.
Trong y tế Lean Six Sigma được hiểu như những phương pháp, công cụ cải tiến giúp tối đa hóa sự hài lòng của bệnh nhân, nhân viên y tế , ngăn chặn rủi ro sai sót về mức 2 sai sót trên 1 tỷ cơ hội gây ra sai sót, mang lại mức an toàn rất cao cho người bệnh và nhân viên y tế. Đồng thời tối ưu chi phí vận hành cho tổ chức thông qua hoạt động loại trừ lãng phí như những quy trình, công việc thừa không cần thiết, chờ đợi không cần thiết, di chuyển, thao tác không cần thiết, làm sai phải làm đi làm lại... 
Lợi ích mà tổ chức nhận được khi triển khai Lean Six Sigma là gia tăng doanh thu thông qua gia tăng sự hài lòng, sự trung thành, sự truyền miệng tích cực của bệnh, góp phần cũng cố uy tín và danh tiếng của đơn vị y tế. Song song hoạt động loại bỏ lãng phí sẽ góp phần gia tăng lợi nhuận. 
Lợi ích vô hình cho tổ chức khi áp dụng Lean Six Sigma là làm cho con người gắn bó với nhau hơn thông qua quá trình làm việc trong các nhóm dự án cải tiến, dần dần hình thành văn hóa cải tiến. Đó là lúc tổ chức phát huy tối đa tiềm lực con người và tạo vốn tri thức cho tổ chức của mình
**Thông tin thanh toán phí tham dự:**
  * Chuyển khoản:
    * Số tài khoản: 007 100 1193 993 - Ngân hàng Vietcombank
    * Tên tài khoản: [Bệnh viện Nguyễn Tri Phương](http://bvnguyentriphuong.com.vn)
    * Cú pháp chuyển khoản: Họ tên + Lớp Chất lượng.


**Quét mã QR Code để đăng ký tham gia:**

## Thông báo chiêu sinh khóa học đào tạo thực hành để cấp giấy phép hành nghề

Bệnh viện Nguyễn Tri Phương trân trọng thông báo về việc tuyển sinh chương trình đào tạo thực hành để cấp giấy phép hành nghề đối với các đối tượng sau:
**1. Bác sĩ y khoa**
  * **Số lượng chiêu sinh** : 20 học viên/khóa
  * **Thời gian thực hành** : 12 tháng


**2. Điều dưỡng**
  * **Số lượng chiêu sinh** : 20 học viên/khóa
  * **Thời gian thực hành** : 06 tháng


**3. Kỹ thuật y học xét nghiệm (KTY xét nghiệm)**
  * **Số lượng chiêu sinh** : 20 học viên/khóa
  * **Thời gian thực hành** : 06 tháng


**Hình thức và môi trường thực hành**
  * Học viên sẽ thực hành **toàn bộ thời gian tại Bệnh viện Nguyễn Tri Phương** , được bố trí tại nhiều chuyên khoa khác nhau.
  * Môi trường đào tạo năng động, thân thiện, hỗ trợ tối đa cho học viên trong suốt quá trình thực hành.


**Thời gian tuyển sinh**
  * **Điều dưỡng và KTY xét nghiệm** : tuyển sinh hàng tháng.
  * **Bác sĩ y khoa** : tuyển sinh mỗi 2 tháng.


**Hướng dẫn nộp hồ sơ**
  * Thông tin chi tiết về quy trình, hồ sơ đăng ký được cập nhật tại website: bvnguyentriphuong.com.vn (Mục **Thông tin khóa học**).


**Liên hệ**
  * **Địa chỉ** : 468 Nguyễn Trãi, Phường An Đông, Quận 5, Thành phố Hồ Chí Minh
  * **Điện thoại** : (028) 39234332 – 73077307
  * **Website** : www.bvnguyentriphuong.com.vn


**Bệnh viện Nguyễn Tri Phương – Năng động, Thân thiện, Phát triển** Hân hạnh đồng hành cùng học viên trên con đường sự nghiệp y khoa!
Thông báo chiêu sinh xem [tại đây](https://bvnguyentriphuong.com.vn/uploads2025/userfiles/59/files/TH%C3%94NG%20B%C3%81O%20TUY%E1%BB%82N%20SINH%20ch%C6%B0%C6%A1ng%20tr%C3%ACnh%20%C4%91%C3%A0o%20t%E1%BA%A1o%20th%E1%BB%B1c%20h%C3%A0nh%20c%E1%BA%A5p%20gi%E1%BA%A5y%20ph%C3%A9p%20h%C3%A0nh%20ngh%E1%BB%81%20n%C4%83m%202025.docx)
#### Nội dung trong file:

THÔNG BÁO TUYỂN SINH
Chương trình thực hành cấp giấy phép hành nghề khám bệnh, chữa bệnh năm 2025

Bệnh viện Nguyễn Tri Phương trân trọng thông báo về việc tuyển sinh chương trình đào tạo thực hành để cấp giấy phép hành nghề đối với các đối tượng sau:
1. Bác sĩ y khoa
Số lượng chiêu sinh: 20 học viên/khóa
Thời gian thực hành: 12 tháng
2. Điều dưỡng
Số lượng chiêu sinh: 20 học viên/khóa
Thời gian thực hành: 06 tháng
3. Kỹ thuật y học xét nghiệm (KTY xét nghiệm)
Số lượng chiêu sinh: 20 học viên/khóa
Thời gian thực hành: 06 tháng
Hình thức và môi trường thực hành
Học viên sẽ thực hành toàn bộ thời gian tại Bệnh viện Nguyễn Tri Phương, được bố trí tại nhiều chuyên khoa khác nhau.
Môi trường đào tạo năng động, thân thiện, hỗ trợ tối đa cho học viên trong suốt quá trình thực hành.
Thời gian tuyển sinh
Điều dưỡng và KTY xét nghiệm: tuyển sinh hàng tháng.
Bác sĩ y khoa: tuyển sinh mỗi 2 tháng.
Hướng dẫn nộp hồ sơ
Thông tin chi tiết về quy trình, hồ sơ đăng ký được cập nhật tại website: bvnguyentriphuong.com.vn (Mục Thông tin khóa học).
Liên hệ
Địa chỉ: 468 Nguyễn Trãi, P. An Đông, Quận 5, TP. Hồ Chí Minh
Điện thoại: (028) 39234332 – 73077307
Website: www.bvnguyentriphuong.com.vn
📌 Bệnh viện Nguyễn Tri Phương – Năng động, Thân thiện, Phát triển
Hân hạnh đồng hành cùng học viên trên con đường sự nghiệp y khoa!.
Mẫu đơn đăng ký thực hành [tại đây.](https://bvnguyentriphuong.com.vn/uploads2025/userfiles/59/files/M%E1%BA%ABu%20%C4%90%C6%A1n%20xin%20th%E1%BB%B1c%20h%C3%A0nh%20\(M%E1%BA%ABu\).docx)
Thành phần hồ sơ tại Phiếu nhận hồ sơ xem [tại đây.](https://bvnguyentriphuong.com.vn/uploads2025/userfiles/59/files/Phi%E1%BA%BFu%20nh%E1%BA%ADn%20h%E1%BB%93%20s%C6%A1%20h%E1%BB%8Dc%20vi%C3%AAn.doc)
#### Nội dung trong file:

Định dạng file https://bvnguyentriphuong.com.vn/uploads2025/userfiles/59/files/Phi%E1%BA%BFu%20nh%E1%BA%ADn%20h%E1%BB%93%20s%C6%A1%20h%E1%BB%8Dc%20vi%C3%AAn.doc không được hỗ trợ (chỉ hỗ trợ PDF, DOCX, TXT, MD).

## Hội thảo Ứng dụng đặt điện cực não sâu ghi điện não đồ (SEEG) trong phẫu thuật động kinh

Bệnh viện Nguyễn Tri Phương trân trọng kính mời Quý đồng nghiệp, Quý đối tác và những ai quan tâm đến lĩnh vực Ngoại Thần kinh tham dự Hội thảo khoa học:
**"Ứng dụng đặt điện cực não sâu ghi điện não đồ (SEEG) trong phẫu thuật động kinh"**
**Thời gian:**
  * Ngày 21/8/2025: 13:00 – 16:30
  * Ngày 22/8/2025: 08:00 – 16:00


**Địa điểm:** Hội trường lầu 5 – Khu A, Bệnh viện Nguyễn Tri Phương, 468 Nguyễn Trãi, P. An Đông, TP.HCM
**Nội dung nổi bật:**
  * Ứng dụng kích thích trong SEEG để tối ưu hóa phẫu thuật.
  * Nguyên tắt thiết kế SEEG, lựa chọn đường đi và chọn điện cực.
  * Kết quả phẫu thuật động kinh tại Bệnh viện Nguyễn Tri Phương.
  * Thảo luận chuyên sâu cùng các chuyên gia đầu ngành trong và ngoài nước
  * Trực tuyến Phẫu thuật thị phạm ca lâm sàng tại Bệnh viện Nguyễn Tri Phương.


**Chủ tọa và báo cáo viên:**
  * BS.CKII. Võ Đức Chiến – Giám đốc Bệnh viện Nguyễn Tri Phương.
  * TS.BS. Phạm Anh Tuấn – Trưởng khoa Ngoại Thần kinh, Bệnh viện Nguyễn Tri Phương; Trưởng Bộ môn Ngoại Thần kinh, Trường Đại học Y Dược TP.HCM.
  * PGS.TS. Hsiang-Yu Yu – Đơn vị Động kinh, Trung tâm Thần kinh, Bệnh viện Cựu chiến binh Đài Bắc, Đài Loan.
  * PGS.TS. Cheng-Chia Lee – Khoa Ngoại Thần kinh, Trung tâm Thần kinh, Bệnh viện Cựu chiến binh Đài Bắc, Đài Loan.
  * ThS.BS. Lê Thụy Minh An – Khoa Nội Thần kinh, Bệnh viện Nguyễn Tri Phương; GV bộ môn Thần kinh, Trường Đại học Y Dược, TP.HCM.


**Đăng ký tham dự ngay:**
Quét mã QR trên poster hoặc liên hệ:
**Số điện thoại:**
  * 0348.314.284 (BS. Hạnh Vi)
  * 0762.622.868 (BS. Hiền Nguyễn)


**Email:** emu.ntp@gmail.com
**Website:** bvnguyentriphuong.com.vn
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh

## Nội quy đào tạo thực hành với đối tượng thực hành khám bệnh, chữa bệnh

**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/)** - Đa khoa Hạng I Thành phố Hồ Chí Minh

## Thông báo chiêu sinh: 'Chương trình thực hành 6 tháng để cấp giấy phép hành nghề xét nghiệm y học đối với chức danh Kỹ thuật y

Kèm theo Mẫu Đơn thực hành [tại đây](https://bvnguyentriphuong.com.vn/uploads2025/files/M%E1%BA%ABu%20%C4%90%C6%A1n%20xin%20th%E1%BB%B1c%20h%C3%A0nh%20%C4%91%E1%BB%91i%20v%E1%BB%9Bi%20ch%E1%BB%A9c%20danh%20K%E1%BB%B9%20thu%E1%BA%ADt%20y%20\(1\).docx)

## Thông báo Danh sách học viên Khóa 3 Chương trình thực hành lâm sàng tại bệnh viện để lấy giấy phép hành nghề đối với bác sĩ y khoa và điều dưỡng

Bệnh viện Nguyễn Tri Phương thông báo Danh sách học viên Khóa 3 Chương trình thực hành lâm sàng tại bệnh viện để lấy giấy phép hành nghề đối với bác sĩ y khoa và điều dưỡng.
Danh sách học viên Khóa III ** _"Lớp đào tạo thực hành đối tượng Bác sĩ y khoa 12 tháng":_**
Danh sách học viên khóa III ** _"Lớp đào tạo thực hành đối tượng Điều dưỡng 6 tháng"_**

## Công nhận hoàn thành lớp Thận - Lọc máu 2024

Quyết định công nhận học viên đã hoàn thành lớp đào tạo liên tục chuyên đề "Thận học - Lọc máu" năm 2024 tại Bệnh viện Nguyễn Tri Phương
Chi tiết xem [(File đính kèm)](https://bvnguyentriphuong.com.vn/uploads/112023/files/ctxh/Th%E1%BA%ADn%20h%E1%BB%8Dc%20-%20L%E1%BB%8Dc%20m%C3%A1u/QD%20C%C3%B4ng%20nh%E1%BA%ADn%20ho%C3%A0n%20th%C3%A0nh%20l%E1%BB%9Bp%20Th%E1%BA%ADn%20-%20L%E1%BB%8Dc%20m%C3%A1u%202024.pdf)

## BỆNH VIỆN NGUYỄN TRI PHƯƠNG THÔNG BÁO CHIÊU SINH ĐÀO TẠO LIÊN TỤC LỚP 'NỘI SOI' , 'THAY KHỚP'.

Căn cứ công văn 5827/SYT-TCCB ngày 22 tháng 10 năm 2010 về việc phê duyệt chương trình đào tạo liên tục cho cơ sở đào tạo Bệnh viện Nguyễn Tri Phương; Căn cứ Thông tư số 22/2013/TT-BYT ngày 09/8/2013 của Bộ Y tế về Hướng dẫn việc đào tạo liên tục cho cán bộ y tế; Căn cứ Thông tư số 26/2020/TT-BYT ngày 28/12/2020 của Bộ Y tế về sửa đổi, bổ sung một số điều của Thông tư số 22/2013/TT-BYT ngày 09/8/2013 của Bộ Y tế về Hướng dẫn việc đào tạo liên tục cho cán bộ y tế; Căn cứ Quyết định 5266/QĐ-SYT ngày 12/11/2015 của Sở Y tế thành phố Hồ Chí Minh về ủy quyền cho Giám đốc Bệnh viện Nguyễn Tri Phương tổ chức thẩm định, phê duyệt tài liệu đào tạo và ký cấp chứng chỉ đào tạo liên tục cho học viên đạt yêu cầu sau mỗi khóa học; Căn cứ vào Quyết định số 717/QĐ-NTP về việc ban hành chương trình và tài liệu liên tục của các lớp “Thay khớp”," Nội soi khớp", phòng Chỉ đạo tuyến kết hợp khoa Ngoại Chấn thương Chỉnh hình bệnh viện Nguyễn Tri Phương tổ chức tuyển sinh như sau: **ĐỐI TƯỢNG THAM GIA:** Bác sĩ chuyên khoa Chấn thương Chỉnh hình, chuyên khoa Ngoại. **THỜI GIAN KHÓA HỌC:** Chiêu sinh hàng quý Đào tạo trong 03 (ba) tháng **Thời gian học** : Lý thuyết: Học viên học trực tiếp, tập trung, từ 07 giờ 30 đến 16 giờ 30 các ngày trong tuần. Thực hành: học viên đăng ký trong quá trình học, học viên được giảng dạy và thực tập lâm sàng tại khoa Chấn thương chỉnh hình và khoa Phẫu thuật - Gây mê Hồi sức, bệnh viện Nguyễn Tri Phương. _**Địa điểm tổ chức lớp:**_ Bệnh viện Nguyễn Tri Phương (468 Nguyễn Trãi, Phường 7, Quận 5, Thành phố Hồ Chí Minh). T _**hông tin khóa học:**_ Trưởng ban Giảng huấn: ThS.BSCKII. Võ Châu Duyên – Trưởng khoa Chấn thương chỉnh hình Bệnh viện Nguyễn Tri Phương. Nội dung: Cập nhật kiến thức Thay khớp, Nội soi khớp, ngoài những nội dung bài giảng chính, khóa học có cập nhật thêm các kiến thức mới từ Hội nghị chuyên ngành trong và ngoài nước. **HỒ SƠ ĐĂNG KÝ:** 03 tấm hình 3x4cm (mặt sau ghi rõ họ tên, ngày tháng năm sinh, đơn vị) Đơn đăng ký theo mẫu (đính kèm) Bản sao Căn cước công dân (công chứng) Biên lai/thông tin chuyển khoản. Bản sao văn bằng chuyên môn (công chứng) Thông tin liên hệ: CN. Chung Thị Lam Phương: 0938.387.326 Nơi nhận đơn: Phòng Chỉ Đạo tuyến – Bệnh viện Nguyễn Tri Phương (lầu 01 – Khu E). Trân trọng thông báo./.
[Thông báo chiêu sinh lớp "Thay khớp" đính kèm](https://bvnguyentriphuong.com.vn/uploads2025/files/2025%20CS%20-%20Th%C3%B4ng%20b%C3%A1o%20chi%C3%AAu%20sinh%20Thay%20kh%E1%BB%9Bp%2020250522.pdf)
[Thông báo chiêu sinh lớp " Nội soi khớp" đính kèm](https://bvnguyentriphuong.com.vn/uploads2025/files/2025%20CS%20-%20Th%C3%B4ng%20b%C3%A1o%20chi%C3%AAu%20sinh%20N%E1%BB%99i%20soi%20kh%E1%BB%9Bp%2020250522.pdf)

## Bệnh viện Nguyễn Tri Phương tổ chức thi kết thúc khóa đối với BS 18 tháng gắn với trạm y tế

Ngày 03/8/2023: Cuộc thi đánh giá kết thúc thời gian thực hành đã diễn ra nghiêm túc. Kho đề trắc nghiệm được nhận từ tất cả các chuyên khoa mà các BS 18 tháng đã tham gia khi lấy CCHN đa khoa tại BV Nguyễn Tri Phương
Kết quả phổ điểm khá hợp lý, thí sinh có điểm cao nhất được 9.25đ. Các bảng điểm đã được tổng hợp và báo cáo về lãnh đạo Sở Y Tế, bao gồm:
- Điểm đánh giá quá trình thực hành
- ĐIểm đánh giá lý thuyết từng khoa
- Điểm chuyên cần
- Điểm thi kết thúc khóa ./.

## Cảnh báo giả mạo giấy tờ thực hành lấy thời gian hành nghề tại BV Nguyễn Tri Phương

Bệnh viện đã nhận được phản hồi từ Sở Y tế Thành phố Hồ Chí Minh để xác nhận về tính xác thực của giấy xác nhận thực hành dưới đây. 
Qua kiểm tra hồ sơ lưu, Bệnh viện khẳng định đây là **giấy tờ làm giả.**
Mọi học viên khi thực tập tại Bệnh viện **luôn có hồ sơ gốc** và việc đối chiếu với các cơ quan chức năng là thường xuyên và liên tục, và Bệnh viện sẵn sàng hỗ trợ để xác nhận lại bất cứ hồ sơ nào có dấu hiệu nghi ngờ không phù hợp.

## Thông báo chiêu sinh Chương trình thực hành đối với chức danh Bác sĩ y khoa và Điều dưỡng năm 2024

1. Thông báo về việc đăng ký chương trình thực hành khám bệnh, chữa bệnh đối với chức danh Bác sĩ y khoa. [Tải Thông báo tại đây](https://bvnguyentriphuong.com.vn/uploads/112023/files/Th%C3%B4ng%20b%C3%A1o%20%C4%91%C4%83ng%20k%C3%BD%20nh%E1%BA%ADp%20h%E1%BB%8Dc%20ch%C6%B0%C6%A1ng%20tr%C3%ACnh%20BS%20y%20khoa.pdf)
#### Nội dung trong file:


2. Thông báo về việc đăng ký thực hành lâm sàng đối với chức danh điều dưỡng. [Tải Thông báo tại đây](https://bvnguyentriphuong.com.vn/uploads/112023/files/Th%C3%B4ng%20b%C3%A1o%20%C4%91%C4%83ng%20k%C3%BD%20nh%E1%BA%ADp%20h%E1%BB%8Dc%20ch%C6%B0%C6%A1ng%20tr%C3%ACnh%20%C4%91i%E1%BB%81u%20d%C6%B0%E1%BB%A1ng.pdf)
#### Nội dung trong file:


3. [Tải mẫu đơn xin thực hành](https://bvnguyentriphuong.com.vn/uploads/112023/files/M%E1%BA%ABu%20%C4%90%C6%A1n%20xin%20th%E1%BB%B1c%20h%C3%A0nh.docx)
#### Nội dung trong file:

CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM
Độc lập - Tự do - Hạnh phúc

Thành phố Hồ Chí Minh, ngày.... tháng... năm 20....

ĐƠN ĐỀ NGHỊ
Thực hành tại cơ sở khám bệnh, chữa bệnh

Kính gửi: 	
 - Ban Giám đốc Bệnh viện Nguyễn Tri Phương;
                				 - Ban quản lý đào tạo.
Họ và tên: ...................................................................................................................
Ngày, tháng, năm sinh: ..............................................................................................
Số chứng minh nhân dân/số căn cước công dân/số căn cước/số định danh cá nhân/số hộ chiếu: .............................
Ngày cấp ...................................................... Nơi cấp: ...............................................
Địa chỉ cư trú: ............................................................................................................
Điện thoại: ...................................................... Email (nếu có): ................................
Văn bằng chuyên môn:...........................................................................................
Chuyên khoa đăng ký thực hành:   ...........................................................................
Thời gian đăng ký thực hành: ....................................................................................
Để có đủ điều kiện được cấp giấy phép hành nghề khám bệnh, chữa bệnh theo quy định, tôi đề nghị Ban Giám đốc Bệnh viện cho phép và tạo điều kiện cho tôi được tham gia thực hành khám bệnh, chữa bệnh tại cơ sở khám bệnh, chữa bệnh.
Tôi xin cam kết sẽ thực hiện đúng các quy định của pháp luật về việc thực hành khám bệnh, chữa bệnh và các quy định khác có liên quan của cơ sở khám bệnh, chữa bệnh./.
	NGƯỜI LÀM ĐƠN



BAN QUẢN LÝ ĐÀO TẠO                                              Ý KIẾN BAN GIÁM ĐỐC
4. Danh sách học viên ** _"Lớp đào tạo thực hành đối tượng Bác sĩ y khoa 12 tháng":_**


5. Danh sách học viên khóa I và Khóa II / 2024 **_"Lớp đào tạo thực hành đối tượng Điều dưỡng 6 tháng"_**



## BV Nguyễn Tri Phương chuẩn bị tiếp nhận lại hồ sơ thực hành lấy thời gian hành nghề

# Sở Y tế công bố danh sách cơ sở khám bệnh, chữa bệnh đáp ứng yêu cầu là cơ sở hướng dẫn thực hành cập nhật đến ngày 08/7/2024
Như vậy, BV Nguyễn Tri Phương dự kiến sẽ bắt đầu nhận hồ sơ mới đăng ký thực hành lấy thời gian hành nghề từ 01/8/2024

## Thông báo về lớp học Kỹ năng giao tiếp - ứng xử và văn hóa công sở cho cán bộ y tế (có cấp giấy chứng nhận)

**Tải thông báo chiêu sinh[TẠI ĐÂY](https://bvnguyentriphuong.com.vn/uploads/072022/files/TBCS_L%E1%BB%9Bp%20k%E1%BB%B9%20n%C4%83ng%20giao%20ti%E1%BA%BFp%20-%20%E1%BB%A9ng%20x%E1%BB%AD.pdf)
#### Nội dung trong file:

UBNDTiNHTRAVINH
TRI.IONG D+I HQC TRA VINH
S5:2775lTB-DHTVCQNG HOA XA HQI CHO NGHIA VIET NAM
D0cl6p - Trr do - H4nh Phtic
Trd Vinh, ngdy 23 thdng 06 ndm 2023
THONG nAo crutu srNn
Ldp K! nd.ng giao tiip - ftng xft vd vdn hoti c1ng s0 cho cdn bQ y ft
C6n cr? Vdn bin hqp nh6t s(i 0I/VBHN-BYT ngdy 13 thr4ng 01 nim202l cria B0 trucrng
B0 Y tti vd trqp nhSt th6"g tu hu<ing din viQc ddo tao 1i6n tuc cho c6n b0 y tii.
Cnn cri euytit dinh sO 2201QD-K2DT ngdy 30 thrlng 12 nim 2015 cta Cgc Khoa hgc
c6ng nghQ - B0 Y t6 v6 viQc c6p md co sd ddo tao li6n tuc cho Trudng Dai hqc Trd Vinh;
Cin cri Quyiit dinh s5 6I64iQD-DHTV ngiy 03 th6ng 11 ndm 2021 cta Hieu trudng
Truong E9i hgc Tri vinh v0 viQc ban hd,nh, chunng trinh <ldo tao li6n lrc "K! ndng giao ti6p
- fmg xri vi v6n ho6 c6ng sd cho c6n bQ y 16".
Trudng D4i hgc Tri Vinh th6ng b6o chi€u sinh <Ido t4o lop K! nlng giao ti6p - tmg xt
vd v6n ho6 c6ng sd cho c6n b0 y t6 - Kho6 1 nhu sau:
l. D6i tugng tuy6n sinh: C6n b0, nhdn vi6n c6ng t6c tqi c6c co sd kh6m, chta b€nh c6 nhu
cdu tham gia kho6 hoc.
2. Chutrng trinh diro t4o: T6ng khlii lugng chuong trinh hqcld24 tii:t (L!'thuydt: 08 tidt,
Thrc hdnh 16 fiA).
3. Thli gian, ilia di6m, hinh thric diro t4o:
- Thdi gian khai gi6ng, nhfp hgc (dg ki6n): 2510712023.
- Hinh thric hqc t{p: hqc tflp trung.
- Eia diiim frqc t$p: t9i U6i truong BQnh viQn NguySn Tri Phuong, st5 468 Nguy5n Trai,
Phuong 8, Quin 5, Thdnh phli Hd Chi Minh.
- Thdi gian hgc: 03 ngiy (hgc vdo Th't 7 vit Cht Nha0.
4. Chrimg chi/ chrlmg nh$n cu6i kh6a hgc:
Hoc vi6n hoan thdnh kh6a hgc sE dugc Truong Dpi hoc Trd Vinh cdp chring nhdn tllo
teo li6n tUc theo quy <tinh hi€n hdnh.
5. IIgc phi vi hinh thric nQp hgc phi:
.i. Hqc phi: 1.500.000 d6ngftqc vi6n.
* Hinh thric nQp hgc phi:
- NQp trgc ti6p: tqi trung tam Ddo t4o -ngudn drdn lgc y t6 theo nhu cdu xd hQi, Tod
nhA-E2 (i'hdng 821.111); sti tZ6 Nguy6n ThiQn Thenh, Kh6m 4, Phuong 5, Tp' Tri
Vinh, Tinh Tri Vinh.
- NQp chuy6n khoin:
+ TCn tdi khoan: Trudng Dqi hqc Trd Vinh.
+ i6 iai tfro*, 735100d00i5086 t4i ng6n hang TMCP D6u tu vi Ph6t tri6n chi ntr6nh
TriVinh (BIDV).
+ NOi dung chuy6n khodn: HQ vd tdn hgc vi6n - KNGTIIX\IFIKI'
16. Hd so dlng ky:
- 01 Phiiiu tt6ng ky (theo miu).
- 01 Bin sao bing c6p chuy€n m6n (c6 chimg thgc).
- 0l CMND hoflc CCCD (c6 chimg thgc).
7. Thoi gian, tlia tli6m ph6t hirnh vi nhfn hd so:
* T[]i hpn nhfn nd ror tu ngiy ph6t hdnh th6ng b6o di5n hiit ngdy 20107t2023.
* Dla tli6m phit hirnh vir lhfln h6 so:
Trung tf,m Diro Qo ngudn nhfln lgc y t6 theo nhu ciu xn hQi
- Di; chi: Tod nna eZ (Phdng E2t.t11), SO 126 Nguy6n ThiQn Thenh, Kh6m 4,
Phucrng 5, Tp. Trd Vinh, tinh Trd Vinh.
- DiQn thoai: (0294) 3855246 - 419, 0938.776.186 (ThS. LC Thenh NguyQn).
- D6 bi6t them th6ng tin chi titit xin vui ldng li6n hQ dia chi tr6n ho{c 0907.868.999
(TS.BS. Nguy6n Thanh Binh).
Noi nh$n:
- BGH (b/c);
- ,0, 69nh vign/ trung tdm y tii;
- Cdc don vi li€n quan;
- Lru: W, DTNNL.6
PhanQu0'c NghiaTRUdNG
oAt HOC
TRi VINHz4
@\\
+
.\
.r\
2**

## Hợp tác Viện - Trường: chiến lược căn cơ phát triển nguồn nhân lực y tế chất lượng cao

Đây là chiến lược căn cơ được Ban Giám đốc qua các thời kỳ của Bệnh viện Nguyễn Tri Phương đánh giá cao. Cụ thể nhiều trưởng khoa lâm sàng là các trưởng Bộ môn hay Cán bộ Giảng của các Trường Đại học Y Dược TP.HCM hay Trường Đại học Y khoa Phạm Ngọc Thạch.
Bệnh viện đã được công nhận là cơ sở thực hành của các trường Đại học, Cao đẳng. 
  * Đại học Y khoa Phạm Ngọc Thạch (Lần 1 - 3: tháng 12/2019; lần 4: tháng 04/2021; lần 5: tháng 05/2022; lần 7: tháng 5/2023)
  * Đại học Nguyễn Tất Thành (tháng 08/2022)
  * Đào tạo liên tục Phẫu thuật tạo hình thẩm mỹ cơ bản - Đại học Trà Vinh (tháng 08/2022)
  * Đại học Quốc tế Hồng Bàng (tháng 5/2023)
  * Đại học Y Dược TP.HCM (tháng 5/2023)
  * Đại học Hùng Vương (tháng 5/2023)
  * Cao đẳng Sài Gòn Gia Định (tháng 5/2023)


**Số lượng sinh viên, học viên thực hành từ năm 2019 đến năm 2023 là hơn 12.000 sinh viên. **

## Chiêu sinh lớp Thận học - Lọc máu năm 2024

  1. **ĐỐI TƯỢNG THAM GIA:**
     * Bác sĩ, Điều dưỡng từ các bệnh viện trong và ngoài có nhu cầu.


  1. **THỜI GIAN KHÓA HỌC:** khai giảng vào ngày **03/5/2023 (thứ sáu)**
     * Dự kiến: **Từ tháng 5/2024 đến tháng 11/2024 (06 tháng)**


**Thời gian học:**
  *     * Lý thuyết: từ 13 giờ 30 đến 16 giờ 30 các ngày thứ 3 (dành cho bác sĩ) và thứ 6 (dành cho điều dưỡng) hàng tuần.
    * Thực hành: tùy theo học viên đăng ký vào một trong hai nhóm sau:
      * __Nhóm 01__ Chiều thứ 3 và chiều thứ 5 / Cả ngày thứ 3 / Cả ngày thứ 5
      * __Nhóm 02__ Chiều thứ 4 và chiều thứ 6 / Cả ngày thứ 4 / Cả ngày thứ 6


**Thông tin khóa học**
Trưởng ban Giảng huấn: PGS.TS.BS.Phạm Văn Bùi – Chủ tịch Hội Lọc Máu TP. Hồ Chí Minh.
Nội dung: Cập nhật kiến thức Thận học – Lọc máu. Ngoài những nội dung bài giảng chính, khóa học có cập nhật thêm các kiến thức mới từ Hội nghị Lọc Máu trong và ngoài nước.
  1. **HỌC PHÍ:**
     * Bác sĩ: 6.500.000 đồng/học viên
     * Điều dưỡng: 5.000.000 đồng/học viên


  1. **CHỨNG CHỈ:** Chứng chỉ đào tạo liên tục (được Bộ Y tế cấp phép) về Thận Học – Lọc Máu do Bệnh viện Nguyễn Tri Phương cấp.


**Điều kiện cấp chứng chỉ:**
Tham gia 80% thời gian học lý thuyết và thực hành.
Đạt yêu cầu bài thi lý thuyết và đánh giá thực hành chuyên môn cuối khóa.
  1. **HỒ SƠ ĐĂNG KÝ:**


  * 02 tấm hình 3x4cm (mặt sau ghi rõ họ tên, ngày tháng năm sinh, đơn vị)
  * Cá nhân: Đơn đăng ký theo mẫu (đính kèm) + Biên lai/thông tin chuyển khoản.
  * Tổ chức: Danh sách đăng ký theo mẫu (đính kèm) + Biên lai/ thông tin chuyển khoản.
  * Photo công chứng “ _Bằng chuyên môn Bác sĩ (đa khoa)/ Điều dưỡng_ ”.


  1. **THỜI GIAN VÀ NƠI NHẬN ĐƠN:**


  * Thời gian nhận đơn kể từ ngày ra thông báo đến hết ngày **03/5/2024**


(Giờ hành chính, từ thứ 2 đến thứ 6)
  * Thông tin liên hệ:


  * _CN. Chung Thị Lam Phương: 0 938.387.326_
  * _CN. Lưu Quốc Trung: 0909.381.444_


  * Nơi nhận đơn:


  * _Trực tiếp: Phòng Chỉ Đạo tuyến – Bệnh viện Nguyễn Tri Phương (lầu 01 – Khu E)._
  * _Qua Email:_**_thanhoclocmau@gmail.com_** _(gửi Danh sách học viên tham gia có chữ ký và mộc dấu của Thủ trưởng đơn vị trước, và gửi bổ sung bằng văn bản giấy sau)_


_Mẫu đăng ký danh sách dành cho cá nhân hoặc tập thể (đính kèm)[Mẫu đăng ký Thận Lọc máu 2024](https://bvnguyentriphuong.com.vn/uploads/112023/files/2024%20M%E1%BA%ABu%20%C4%91%C4%83ng%20k%C3%BD%20Th%E1%BA%ADn%20L%E1%BB%8Dc%20m%C3%A1u%2002-Apr-2024\(1\).docx)_
  1. **THANH TOÁN:**


  * Tiền mặt: Phòng Tài Chính Kế Toán, Bệnh viện Nguyễn Tri Phương (tầng trệt khu D)
  * Chuyển khoản: 


  * STK: **007 100 1193 993**
  * Ngân hàng Vietcombank, chi nhánh Hùng Vương
  * Nội dung: “**Tên học viên – Lớp Thận 2024** ”
  * Hạn cuối thanh toán học phí: **Ngày 03/5/2024.**


**_Ghi chú:_**
  * Chỉ xuất hóa đơn tài chính trong tháng (Đối tượng có nhu cầu xuất hóa đơn cần cung cấp thông tin đầy đủ)
  * Mọi chi tiết về tài chính, liên hệ: _Cn.Nguyễn Thị Hồng Nhung 0902.921678_



## Thông báo tổ chức lớp Dược lâm sàng 2023

**I. ĐỐI TƯỢNG THAM GIA:**
1. Dược sĩ trong bệnh viện có nhu cầu.
2. Dược sĩ từ các bệnh viện khác có nhu cầu.
**II. THỜI GIAN, NỘI DUNG ĐÀO TẠO:**
**1. Giảng viên:**
Giảng viên chính: TS. DS. Võ Thị Hà – Giảng viên BM Dược lý – Dược lâm sàng - ĐH Y Khoa Phạm Ngọc Thạch; Phụ trách Tổ DLS, Phó Khoa Dược - Bv NTP.
Hỗ trợ: Các dược sĩ lâm sàng của Bệnh viện Nguyễn Tri Phương.
**2. Thời gian và hình thức chiêu sinh:**
_**Hình thức chiêu sinh**_ : chiêu sinh liên tục.
  * Chiêu sinh tuần 1, 3 hàng tháng: chương trình Module 01
  * Chiêu sinh tuần 2, 4 hàng tháng: chương trình Module 02
  * Chiêu sinh tuần 1, 2, 3, 4 hàng tháng: chương trình Module 03


_**Thời gian thực hành mỗi module:**_ trong giờ hành chính, từ thứ 2 đến thứ 6.
_**Chỉ tiêu tuyển sinh mỗi module:**_
  * Module 1: Tối đa: 4 học viên/tuần
  * Module 2: Tối đa: 4 học viên/tuần
  * Module 3: Tối đa: 2 học viên/tuần 


**III. THỜI GIAN NHẬN HỒ SƠ:**
Thời gian bắt đầu thực hành: từ đầu mỗi tháng, dự kiến sẽ bắt đầu học từ tháng 4/2023
**IV. NỘI DUNG ĐÀO TẠO:**
**Nội dung** |  **Mục tiêu**  
---|---  
Module 1 (01 tuần từ thứ 2 đến thứ 6, giờ hành chính) –**TỔNG QUAN HOẠT ĐỘNG DƯỢC LÂM SÀNG** | 
  * Tìm hiểu các hoạt động dược lâm sàng tại bệnh viện
  * Tìm hiểu các hoạt động thông tin thuốc
  * Tìm hiểu các hoạt động quản lý phản ứng có hại của thuốc
  * Kiến tập hoạt động dược lâm sàng tại Phòng phát thuốc bảo hiểm y tế
  * Kiến tập hoạt động tư vấn thuốc cho bệnh nhân ngoại trú
  * Kiến tập hoạt động dược lâm sàng nội trú tại khoa lâm sàng 
  * Kiến tập hoạt động phân tích bệnh án nội trú

|  Sau khi tham gia thực tập Module 1, học viên có thể:
  * Mô tả được các hoạt động dược lâm sàng tại bệnh viện 
  * Mô tả được quy trình, kinh nghiệm và các nguồn tài liệu phục vụ cho hoạt động thông tin thuốc
  * Mô tả được quy trình và kinh nghiệm khi quản lý phản ứng có hại tại bệnh viện
  * Mô tả được các bước và kinh nghiệm khi dược sĩ duyệt đơn cho bệnh nhân ngoại trú
  * Mô tả được các bước và kinh nghiệm khi tư vấn cho bệnh nhân ngoại trú
  * Mô tả được quy trình và kinh nghiệm khiđi bệnh phòng và hội chẩn cùng bác sĩ. 
  * Mô tả được các bước và kinh nghiệm khi phân tích bệnh án nội trú

  
Module 2 (01 tuần từ thứ 2 đến thứ 6, giờ hành chính)**– QUẢN LÝ KHÁNG SINH** | 
  * Kinh nghiệm triển khai chương trình quản lý kháng sinh tại bệnh viện
  * Sử dụng kháng sinh vancomycin và colistin 
  * Một số ca lâm sàng hội chẩn liên quan nhiễm khuẩn một số gram âm, gram dương điển hình
  * Một số tình huống ADR điển hình liên quan kháng sinh 

|  Sau khi tham gia thực tập Module 2, học viên có thể:
  * Trình bày được các kinh nghiệm triển khai chương trình quản lý kháng sinh tại bệnh viện
  * Trình bày được kinh nghiệm hội chẩn liên quan sử dụng kháng sinh vancomycin và colistin 
  * Trình bày được kinh nghiệm hội chẩn liên quan điều trị nhiễm khuẩn một số gram âm, gram dương điển hình
  * Trình bày được kinh nghiệm xử lý một số tình huống ADR điển hình liên quan kháng sinh

  
Module 3 (01 tuần từ thứ 2 đến thứ 6, giờ hành chính)**– DƯỢC LÂM SÀNG NGOẠI TRÚ TRÊN NGƯỜI BỆNH THÔNG THƯỜNG VÀ NGƯỜI BỆNH TĂNG HUYẾT ÁP** | 
  * Quy trình và các biểu mẫu hoạt động của phân tích đơn và tư vấn người bệnh ngoại trú
  * Kỹ năng giao tiếp
  * Kỹ năng phỏng vấn tiền sử thuốc của bệnh nhân
  * Kỹ năng phân tích đơn thuốc
  * Kỹ năng tư vấn bệnh nhân thông thường
  * Kỹ năng tư vấn bệnh nhân tăng huyết áp 

|  Sau khi tham gia thực tập Module 3, học viên có thể:
  * Xây dựng được quy trình dược lâm sàng ngoại trú
  * Thực hiện được việc phân tích đơn thuốc ngoại trú
  * Thực hiện được việc tư vấn bệnh nhân ngoại trú

  
**Kinh phí: 1.000.000đ/tuần/học viên**
(Học viên tự túc chi phí ăn, ở. Chi phí chưa bao gồm tài liệu)
**Cách thức đăng ký:**
**Kết thúc khóa** có cấp chứng nhận thời gian tham gia 
Tải mẫu đơn đăng ký: [**TẠI ĐÂY**](https://bvnguyentriphuong.com.vn/uploads/072022/files/mau%20don%20dang%20ky%20thuc%20hanh.docx)
#### Nội dung trong file:

CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM
Độc lập – Tự do – Hạnh phúc
-----o0o----

ĐƠN ĐĂNG KÝ
KHÓA HỌC THỰC HÀNH “DƯỢC LÂM SÀNG”


Tôi tên	:	…………………………………………….	Giới tính: ……………
Sinh ngày	:………… tháng ………… năm…………… 

Hiện công tác tại đơn vị	:	……………………………………………………………..
Khoa	:	………………………………………………………………
Địa chỉ cơ quan	:	……………………………………………………………….
Điện thoại	:		
E.mail	:		

Tôi xin đăng ký khóa thực hành “Dược Lâm Sàng” tại Bệnh viện Nguyễn Tri Phương. Tôi cam đoan mục đích tham gia khóa đào tạo, thực hành không để cấp chứng chỉ hành nghề.
Module đăng ký học:	Module ….., từ ngày …/…/202… đến ngày …/…/202…
				Module ….., từ ngày …/…/202… đến ngày …/…/202…
				Module ….., từ ngày …/…/202… đến ngày …/…/202…
Địa chỉ liên hệ của học viên	:		
Điện thoại	:	………………………….. E.mail	:		
(Vui lòng ghi thông tin đầy đủ và chính xác để tiện cho việc cấp chứng nhận sau này, xin cung cấp địa chỉ email để nhận tài liệu học tập)

	………….., ngày …… tháng …… năm 202….
	Người làm đơn
	(Ký, ghi rõ họ và tên)
Hồ sơ bao gồm:
Đơn đăng ký;
Bản photo (có chứng thực) Bằng tốt nghiệp Bác sĩ (đa khoa) hoặc Điều dưỡng hoặc Dược
Chứng minh nhân dân/ Căn cước công dân (photo có chứng thực)
2 tấm hình 3x4 (ghi họ tên và ngày tháng năm sinh phía sau)
**Thông tin hướng dẫn đăng ký và sắp xếp lịch học vui lòng liên hệ:**
  * CN Vũ Minh Tuấn: 0907.10.10.25
  * CN Dương Trần Cát Uyên: 0969.011.426



## Khung đào tạo hành nghề đa khoa (SYT Tp.HCM)

Xem toàn bộ văn bản [**tại đây**](https://bvnguyentriphuong.com.vn/uploads/112023/files/1678-qd_signed_pdf%20Ban%20hanh%20Khung%20chuong%20trinh%20huong%20dan%20thuc%20hanh%20KBCB%2012%20thang%20doi%20voi%20Bac%20si%20y%20khoa.pdf)
#### Nội dung trong file:



## THAY ĐỔI LỊCH KHAI GIẢNG LỚP THẬN HỌC - LỌC MÁU NĂM 2023

**THÔNG BÁO**
**Về việc thay đổi thời gian khai giảng**
**lớp Thận học – Lọc máu năm 2023 tại bệnh viện**
  * Căn cứ Thông báo chiêu sinh ngày 27 tháng 01 năm 2023 về việc chiêu sinh Lớp Đào tạo liên tục chuyên đề “Thận học – Lọc máu” năm 2023 của Bệnh viện Nguyễn Tri Phương
  * Theo kế hoạch, lớp học sẽ được khai giảng vào ngày 05/4/2023 (Thứ tư). Tuy nhiên, do giảng viên bận lịch công tác nước ngoài đột xuất không sắp xếp được thời gian nên tạm thời chưa thể khai giảng Lớp Đào tạo liên tục chuyên đề “Thận học – Lọc máu” đúng thời gian dự kiến.


Bệnh viện Nguyễn Tri Phương thông báo về việc thay đổi thời gian khai giảng lớp Thận học – Lọc máu năm 2023 tại bệnh viện như sau:
  * Lớp sẽ khai giảng vào **_13h30 thứ sáu_** , **_ngày 05/5/2023._**
  * Địa điểm: Hội trường A, lầu 5 khu A, bệnh viện Nguyễn Tri Phương


(468 Nguyễn Trãi, Phường 8, Quận 5, Thành phố Hồ Chí Minh).
  * Khai giảng chung cho tất cả học viên.


**Thông tin liên hệ:**
  * CN. Chung Thị Lam Phương: 0938.387.326
  * CN. Lê Thị Hiền Lương: 0949.661.679
  * _Thông báo[tại đây](https://bvnguyentriphuong.com.vn/uploads/072022/files/TB%20-%20Thay%20%C4%91%E1%BB%95i%20th%E1%BB%9Di%20gian%20khai%20gi%E1%BA%A3ng%20Th%E1%BA%ADn%20l%E1%BB%8Dc%20m%C3%A1u%202023\(1\).pdf)_



## Bệnh viện Nguyễn Tri Phương tiếp nhận các BS tham gia lấy CCHN gắn với TTYT đợt 2

Sáng ngày 28/12/2022, theo phân công của Sở Y Tế Tp.HCM, BV Nguyễn Tri Phương đã cùng TTYT Q6 và TTYT Nhà Bè tiếp nhận 12 BS tham gia đợt 2 trong chương trình đào tạo lấy CCHN gắn với trạm y tế cơ sở.
Cùng tham gia buổi tiếp nhận, các BS tham gia đợt 1 cũng đã chia sẻ nhiều suy nghĩ, kinh nghiệm với mong muốn các BS trẻ luôn quý trọng thời gian tham gia chương trình và đạt được thành công ngày thêm rõ nét./.

## Tiếp tục tiếp nhận thực tập dược lâm sàng tại bệnh viện Nguyễn Tri Phương năm 2022

**I. ĐỐI TƯỢNG THAM GIA:**
1. Dược sĩ trong bệnh viện có nhu cầu.
2. Dược sĩ từ các bệnh viện khác có nhu cầu.
**II. THỜI GIAN, NỘI DUNG ĐÀO TẠO:**
**1. Giảng viên:**
Giảng viên chính: TS. DS. Võ Thị Hà – Giảng viên BM Dược lý – Dược lâm sàng, ĐH Y Khoa Phạm Ngọc Thạch; Phụ trách Tổ DLS, BV NTP.
Hỗ trợ: Các dược sĩ lâm sàng của Bệnh viện Nguyễn Tri Phương.
**2. Thời gian và hình thức chiêu sinh:**
Hình thức chiêu sinh: chiêu sinh liên tục.
Chiêu sinh tuần 1, 3 hàng tháng: chương trình Module 01
Chiêu sinh tuần 2, 4 hàng tháng: chương trình Module 02
Chiêu sinh tuần 1, 2, 3, 4 hàng tháng: chương trình Module 03
Thời gian thực hành mỗi module: trong giờ hành chính, từ thứ 2 đến thứ 6.
Chỉ tiêu tuyển sinh mỗi module: 
Module 1: Tối đa: 4 học viên/tuần
Module 2: Tối đa: 4 học viên/tuần
Module 3: Tối đa: 2 học viên/tuần 
**III. THỜI GIAN NHẬN HỒ SƠ:**
Thời gian bắt đầu thực hành: từ đầu mỗi tháng, dự kiến sẽ bắt đầu học từ tháng 10/2022
**IV. NỘI DUNG ĐÀO TẠO:**
**Nội dung** |  **Mục tiêu**  
---|---  
Module 1 (01 tuần từ thứ 2 đến thứ 6, giờ hành chính) –**TỔNG QUAN HOẠT ĐỘNG DƯỢC LÂM SÀNG** | 
  * Tìm hiểu các hoạt động dược lâm sàng tại bệnh viện
  * Tìm hiểu các hoạt động thông tin thuốc
  * Tìm hiểu các hoạt động quản lý phản ứng có hại của thuốc
  * Kiến tập hoạt động dược lâm sàng tại Phòng phát thuốc bảo hiểm y tế
  * Kiến tập hoạt động tư vấn thuốc cho bệnh nhân ngoại trú
  * Kiến tập hoạt động dược lâm sàng nội trú tại khoa lâm sàng 
  * Kiến tập hoạt động phân tích bệnh án nội trú

|  Sau khi tham gia thực tập Module 1, học viên có thể:
  * Mô tả được các hoạt động dược lâm sàng tại bệnh viện 
  * Mô tả được quy trình, kinh nghiệm và các nguồn tài liệu phục vụ cho hoạt động thông tin thuốc
  * Mô tả được quy trình và kinh nghiệm khi quản lý phản ứng có hại tại bệnh viện
  * Mô tả được các bước và kinh nghiệm khi dược sĩ duyệt đơn cho bệnh nhân ngoại trú
  * Mô tả được các bước và kinh nghiệm khi tư vấn cho bệnh nhân ngoại trú
  * Mô tả được quy trình và kinh nghiệm khiđi bệnh phòng và hội chẩn cùng bác sĩ. 
  * Mô tả được các bước và kinh nghiệm khi phân tích bệnh án nội trú

  
Module 2 (01 tuần từ thứ 2 đến thứ 6, giờ hành chính)**– QUẢN LÝ KHÁNG SINH** | 
  * Kinh nghiệm triển khai chương trình quản lý kháng sinh tại bệnh viện
  * Sử dụng kháng sinh vancomycin và colistin 
  * Một số ca lâm sàng hội chẩn liên quan nhiễm khuẩn một số gram âm, gram dương điển hình
  * Một số tình huống ADR điển hình liên quan kháng sinh 

|  Sau khi tham gia thực tập Module 2, học viên có thể:
  * Trình bày được các kinh nghiệm triển khai chương trình quản lý kháng sinh tại bệnh viện
  * Trình bày được kinh nghiệm hội chẩn liên quan sử dụng kháng sinh vancomycin và colistin 
  * Trình bày được kinh nghiệm hội chẩn liên quan điều trị nhiễm khuẩn một số gram âm, gram dương điển hình
  * Trình bày được kinh nghiệm xử lý một số tình huống ADR điển hình liên quan kháng sinh

  
Module 3 (01 tuần từ thứ 2 đến thứ 6, giờ hành chính)**– DƯỢC LÂM SÀNG NGOẠI TRÚ TRÊN NGƯỜI BỆNH THÔNG THƯỜNG VÀ NGƯỜI BỆNH TĂNG HUYẾT ÁP** | 
  * Quy trình và các biểu mẫu hoạt động của phân tích đơn và tư vấn người bệnh ngoại trú
  * Kỹ năng giao tiếp
  * Kỹ năng phỏng vấn tiền sử thuốc của bệnh nhân
  * Kỹ năng phân tích đơn thuốc
  * Kỹ năng tư vấn bệnh nhân thông thường
  * Kỹ năng tư vấn bệnh nhân tăng huyết áp 

|  Sau khi tham gia thực tập Module 3, học viên có thể:
  * Xây dựng được quy trình dược lâm sàng ngoại trú
  * Thực hiện được việc phân tích đơn thuốc ngoại trú
  * Thực hiện được việc tư vấn bệnh nhân ngoại trú

  
**Kinh phí: 1.000.000đ/tuần/học viên**
(Học viên tự túc chi phí ăn, ở. Chi phí chưa bao gồm tài liệu)
**Cách thức đăng ký:**
**Kết thúc khóa** có cấp chứng nhận thời gian tham gia 
Tải mẫu đơn đăng ký: [**TẠI ĐÂY**](https://drive.google.com/file/d/1-YdFbiXxXhdNBfrMdmtCp_xevV1q-6M8/view?usp=sharing)
**Thông tin hướng dẫn đăng ký và sắp xếp lịch học vui lòng liên hệ:**
  * CN Vũ Minh Tuấn: 0907.1010.25
  * CN Dương Trần Cát Uyên: 0969.011.426



## Chiêu sinh lớp đào tạo liên tục chuyên đề ' Thận học - Lọc máu' năm 2023

  1. **ĐỐI TƯỢNG THAM GIA:**
     *        * Bác sĩ, Điều dưỡng từ các bệnh viện trong và ngoài có nhu cầu.
  2. **THỜI GIAN KHÓA HỌC:** khai giảng vào ngày **05/4/2023**
     *        * Giai đoạn: **Từ tháng 4/2023 đến tháng 9/2023. (3 tháng thực hành + 3 tháng lý thuyết)**


**Thời gian học:**
  *     *       * Lý thuyết: từ 13 giờ 30 đến 16 giờ 30 các ngày thứ 4 và thứ 6 hàng tuần.
      * Thực hành: tùy theo học viên đăng ký vào một trong hai nhóm sau:
  * __Nhóm 01__ buổi chiều thứ 3 và thứ 5/cả ngày thứ 3 hoặc thứ 5
  * __Nhóm 02__ buổi chiều thứ 4 và thứ 6/cả ngày thứ 4 hoặc thứ 6


**Thông tin khóa học**
  * Trưởng ban Giảng huấn: PGS.TS.BS.Phạm Văn Bùi – Chủ tịch Hội Lọc Máu TP. Hồ Chí Minh.
  * Nội dung: Cập nhật kiến thức Thận Học – Lọc Máu. Ngoài những nội dung bài giảng chính, khóa học có cập nhật thêm các kiến thức mới từ Hội nghị Lọc Máu trong và ngoài nước.


  1. **HỌC PHÍ:**
     *        * Bác sĩ: 6.500.000 đồng/học viên
       * Điều dưỡng: 5.000.000 đồng/học viên
       * Điều dưỡng cập nhật CME 06 tháng: 2.000.000 đồng/học viên (cập nhật 03 tháng thực hành) (đã có chứng chỉ Thận Học – Lọc Máu 03 tháng do Bệnh viện Nguyễn Tri Phương cấp)
  2. **BẰNG CẤP:** Chứng chỉ đào tạo liên tục  _(CME được Bộ Y tế cấp phép)_ về Thận Học – Lọc Máu do Bệnh viện Nguyễn Tri Phương cấp.


**Điều kiện cấp bằng:**
  * Hoàn tất 80% thời gian học lý thuyết và thực hành.
  * Hoàn thành tốt bài thi lý thuyết và đánh giá thực hành chuyên môn cuối khóa.


  1. **HỒ SƠ ĐĂNG KÝ:**


  * 02 tấm hình 3x4cm (mặt sau ghi rõ họ tên, ngày tháng năm sinh, đơn vị)
  * Cá nhân: Đơn đăng ký theo mẫu (đính kèm) + Biên lai/thông tin chuyển khoản.
  * Tổ chức: Danh sách đăng ký theo mẫu (đính kèm) + Biên lai/ thông tin chuyển khoản.
  * Photo công chứng “ _Bằng chuyên môn Bác sĩ (đa khoa)/ Điều dưỡng_ ”.
  * Photo công chứng “ _Chứng chỉ đào tạo liên tục Thận Học – Lọc Máu”_ khóa 03 tháng lý thuyết  _(dành cho điều dưỡng đã có chứng chỉ học 03 tháng do Bệnh viện Nguyễn Tri Phương cấp) (nếu có)_


  1. **THỜI GIAN VÀ NƠI NHẬN ĐƠN:**


  * Thời gian nhận đơn kể từ ngày ra thông báo đến hết ngày **31/3/2023**


(Giờ hành chính, từ thứ 2 đến thứ 6)
  * Thông tin liên hệ:


  * _CN. Chung Thị Lam Phương: 0_ _938.387.326_
  * _CN. Lê Thị Hiền Lương: 0949.661.679_


  * Nơi nhận đơn:


  * _Trực tiếp: Phòng Chỉ Đạo tuyến – Bệnh viện Nguyễn Tri Phương (lầu 01 – Khu E)._
  * _Qua Email:_**_cdt_ntp@bvnguyentriphuong.com_** _(gửi Danh sách học viên tham gia có chữ ký và mộc dấu của Thủ trưởng đơn vị trước, và gửi bổ sung bằng văn bản sau)_


_Mẫu đăng ký danh sách dành cho cá nhân hoặc tập thể (đính kèm)_
  1. **THANH TOÁN:**


  * Tiền mặt: Phòng Tài Chính Kế Toán, Bệnh viện Nguyễn Tri Phương (tầng trệt khu D)
  * Chuyển khoản: 


  * **007 100 1193 993**
  * Ngân hàng Vietcombank, chi nhánh Hùng Vương
  * Nội dung: “**Tên học viên – Lớp Thận 2023**
  * Hạn cuối thanh toán học phí: **Ngày 31/04/2023.**


**_Ghi chú:_**
  * Chỉ xuất hóa đơn tài chính trong tháng (Đối tượng có nhu cầu xuất hóa đơn cần cung cấp thông tin đầy đủ)
  * Mọi chi tiết về tài chính, liên hệ: _CN.Nguyễn Thị Hồng Nhung 0902.921678_
  * Đơn đăng ký. 
  * Link đính kèm.[ TẠI ĐÂY](https://bvnguyentriphuong.com.vn/uploads/072022/files/Th%C3%B4ng%20b%C3%A1o%20chi%C3%AAu%20sinh%20NCKH%202023.pdf)
#### Nội dung trong file:





## Thông báo chiêu sinh lớp 'PHƯƠNG PHÁP NGHIÊN CỨU KHOA HỌC'

Để tải Thông báo chiêu sinh và Đơn đăng ký vui lòng:

## Thông báo chiêu sinh lớp 'CẬP NHẬT KIẾN THỨC VỀ THẬN HỌC 2022'

Nhằm đảo bảo an toàn tối đa và cải thiện chất lượng sống cũng như nguy cơ tử vong cho các bệnh nhân bệnh thận, lọc máu định kỳ, Bệnh viện Nguyễn Tri Phương kết hợp cùng Liên chi Hội Thận học - Lọc máu Thành phố Hồ Chí Minh tổ chức lớp học về “Cập nhật kiến thức về Thận học 2022” như sau:
  * Ban Giảng huấn:
    * **STEPHEN MARTIN** – PGS Thận học, Bộ môn Nội, Khoa Y ĐH Johns Hopkins; từ 2013 - nay Phó Khoa, Khoa Giáo dục, ĐH Johns Hopkins; Từ 2009 - Hiện nay: Bác sỹ BV Johns Hopkins và Trung tâm Y khoa Johns Hopkins.
    * **LILI CHAN** PGS, Khoa Thận, Trường Y Icahn tại Mount Sinai, New York; từ 2010 – nay, Đồng Giám đốc Trung tâm BioMe Phenomics; từ 2020 – nay, Phó Giám đốc Nghiên cứu Lâm sàng tại Khoa Thận học Trường Y Icahn tại Mount Sinai, New York. 
    * **PHẠM VĂN BÙI** PGS.TS, Chủ tịch Liên chi Hội Thận học - Lọc máu Thành phố Hồ Chí Minh, cố vấn chuyên môn Bệnh viện Nguyễn Tri Phương.
  * Chương trình tập huấn dành cho đối tượng: 
    * Các bác sĩ làm việc trong lĩnh vực Thận học – Lọc máu, Hồi sức tích cực, Nội khoa.
    * Các nhà quản lý có liên quan đến hoạt động Thận học – Lọc máu trong bệnh viện.
  * Thời gian và địa điểm dự kiến sẽ diễn ra:
    * Ngày 01/12/2022, thời gian học: sáng 8h00 - 12h00.
    * Địa điểm dự kiến: Hội trường A, Bệnh viện Nguyễn Tri Phương.
  * Tính tương đương CME: 06 tiết 
  * Kinh phí tham gia: 
    * Số tiền: 500.000đ/học viên (bao gồm tài liệu, tiệc trà, phí cấp chứng nhận).
    * Hình thức: Thanh toán tại phòng Tài chính kế toán – Bệnh viện Nguyễn Tri Phương hoặc chuyển khoản. 

**Thông tin chuyển khoản**  
---  
Số tài khoản |  0071001193993  
Ngân hàng |  Vietcombank – CN Hùng Vương  
Cú pháp nội dung CK |  _“tên học viên hoặc tên Đơn vị” +_ DK Lop Cap nhat kien thuc ve Than hoc 2022 – SL: _“số lượng”_ hoc vien __Ví dụ:__
  * BV Pham Van A DK Lop Cap nhat kien thuc ve Than hoc 2022 – SL: 03 hoc vien.
  * Nguyen Van A DK Lop cap nhat kien thuc ve Than hoc 2022.

  
**_Lưu ý_** : _ghi nhớ và cung cấp thời gian chuyển khoản để đối chiếu và xuất hóa đơn._
  * Hồ sơ đăng ký:
    * 01 đơn đăng ký _(tải[**TẠI ĐÂY**](https://bvnguyentriphuong.com.vn/uploads/072022/files/mau%20don%20dang%20ky%20thuc%20hanh.pdf)
#### Nội dung trong file:

CỘNG HÒA XÃ H ỘI CH Ủ NGHĨA VI ỆT NAM  
Độc lập – Tự do – Hạnh phúc  
-----o0o---- 
 
ĐƠN ĐĂNG KÝ  
KHÓA H ỌC “CẬP NH ẬT KI ẾN TH ỨC VỀ THẬN HỌC 2022 ” 
 
Kính g ửi: BGĐ Bệnh vi ện Nguy ễn Tri Phương  
Phòng Qu ản lý Ch ất lượng 
 
Tôi tên : …………………………………………….  Giới tính : ……………  
Sinh ngày  :…………  tháng  …………  năm……………   
 
Hiện công tác t ại đơn v ị : ……………………………………………………………..  
Khoa  : ………………………………………………………………  
Địa chỉ cơ quan  : ……………………………………………………………….  
Điện tho ại :  ................................ ................................ ................................   
E.mail  :  ................................ ................................ ................................   
 
Tôi xin đăng ký theo khóa h ọc “Cập nhật kiến thức về Thận học 2022”, đư ợc tổ chức tại 
Bệnh vi ện Nguy ễn Tri Phương . 
Địa chỉ liên h ệ của học viên  :  ................................ ................................ .........................   
Điện tho ại : …………………………..  E.mail  :  ................................ ..........................   
(Vui lòng ghi thông tin đ ầy đủ và chính xác đ ể tiện cho vi ệc cấp chứng nh ận sau này, xin 
cung c ấp địa chỉ email đ ể nhận tài li ệu học tập) 
 
 ………….., ngày …… tháng …… năm 202 2. 
 Người làm đơn  
 (Ký, ghi rõ h ọ và tên))_
    * 02 tấm hình 3x4 _(có ghi họ tên phía sau)_
    * 01 Bằng chuyên môn bác sĩ đa khoa _(photo có công chứng)_
    * 01 Chứng minh nhân dân/Căn cước công dân _(photo có công chứng)_
  * Nộp hồ sơ tại phòng Quản lý chất lượng (lầu 01 – Khu A – Bệnh viện Nguyễn Tri Phương).


Đăng ký tham gia, vui lòng liên hệ phòng Quản Lý Chất Lượng: (0283)7307.7307, bấm tiếp số máy lẻ (20661) hoặc gặp CN Tuấn (0907101025). Hạn cuối đăng ký ngày 28/11/2022.
Ghi chú:
  * Tải thông báo chiêu sinh: 
  * Tải đơn đăng ký: 


**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/) **- Đa khoa Hạng I Thành phố Hồ Chí Minh

## Chương trình: 'Tháng đào tạo Bệnh Thần kinh – Cơ 2022'

**Hội Thần kinh Việt Nam**
**Hội Bệnh Thần kinh cơ và chẩn đoán điện Việt Nam**
**Trân trọng thông báo chương trình: “Tháng đào tạo Bệnh Thần kinh – Cơ 2022"**
- Giảng viên phụ trách chính: **GS Umapathi từ Viện Khoa học Thần kinh Quốc gia Singapore**
  * Chuyên gia cao cấp Viện khoa học thần kinh Quốc gia Singapore.
  * Giáo sư Đại học quốc gia Singapore (NUS); Đại học Nanyang; Trường DUKE-NUS. 
  * Giáo sư thường xuyên tham gia giảng dạy tại các nước Đông Nam Á (Singapore, Thái Lan, Malaysia, Philippines, Myanmar), Đông Á, Nam Á và Bắc Phi.
  * Thành viên chủ chốt của consortium GBS/CIDP- diabetic neuropathy - Hội thần kinh ngoại biên thế giới. 


Từ 2015 đến 2019, VANEM phối hợp cùng Giáo sư và Viện Khoa học Thần kinh Quốc gia Singapore đã tổ chức tổng cộng 6 workshop hands-on về thần kinh cơ, đột quỵ ở Hà Nội và TPHCM. 
**Chương trình đầu dự kiến tổ chức tại Bệnh viện Nguyễn Tri Phương**
- Thời gian dự kiến từ 30/8/2022 đến 31/8/2022
- Hình thức: Giảng dạy trên ca bệnh 
- Địa điểm:Hội trường B, lầu 5, khu A Bệnh viện Nguyễn Tri Phương 
- Ban tổ chức: hội VANEM – khoa Nội thần kinh Bệnh viện Nguyễn Tri Phương
**Nội dung dự kiến:**
  * Ngày 30/8: Bệnh rễ - dây - đám rối thần kinh, Bệnh neuron vận động.
  * Ngày 31/8: Bệnh cơ, Bệnh tiếp hợp thần kinh cơ, Neuro ophthalmology, Neuro ontology 


**- Đối tượng:**
  * Sinh viên đại học
  * Học viên sau đại học 
  * Bác sĩ thần kinh – cơ 
  * Bác sĩ điện sinh lý thần kinh 
  * Bác sĩ mắt và nhóm neuro ophthalmology 
  * Bác sĩ tai mũi họng và nhóm neuro ontology


- Các ACE đồng nghiệp có các ca bệnh hay – khó muốn tham gia lớp học tại Bệnh viện Nguyễn Tri Phương xin liên hệ:
  * BS CKII Nguyễn Văn Sang– khoa Nội thần kinh Bệnh viện Nguyễn Tri Phương. Email: nguyenvansang2010@gmail.com
  * Th.BS Hoàng Tiến Trọng Nghĩa – Điều phối viên, Thư ký Hội Bệnh Thần kinh cơ và Chẩn đoán điện Việt Nam. Email: dr.hnghia@gmail.com


**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh

## Những lưu ý về việc thực hành lấy thời gian hành nghề

  * [Bác sĩ thực hành 18 tháng tại cơ sở khám, chữa bệnh hợp pháp trên địa bàn Thành phố Hồ Chí Minh, không có hộ khẩu tại Thành phố Hồ Chí Minh. Vậy có được Sở Y tế Thành phố Hồ Chí Minh cấp Chứng chỉ hành nghề không?](https://bvnguyentriphuong.com.vn/thong-tin-khoa-hoc/nhung-luu-y-ve-viec-thuc-hanh-lay-thoi-gian-hanh-nghe#bc-s-thc-hnh-18-thng-ti-c-s-khm-cha-bnh-hp-php-trn-a-bn-thnh-ph-h-ch-minh-khng-c-h-khu-ti-thnh-ph-h-ch-minh-vy-c-c-s-y-t-thnh-ph-h-ch-minh-cp-chng-ch-hnh-ngh-khng)
  * [Đi thực tập lâm sàng tại bệnh viện Nguyễn Tri Phương, học viên cần lưu ý gì?](https://bvnguyentriphuong.com.vn/thong-tin-khoa-hoc/nhung-luu-y-ve-viec-thuc-hanh-lay-thoi-gian-hanh-nghe#i-thc-tp-lm-sng-ti-bnh-vin-nguyn-tri-phng-hcvin-cn-lu-g)
  * [Cách nộp hồ sơ và thời gian bắt đầu thực tập tại Bệnh viện Nguyễn Tri Phương?](https://bvnguyentriphuong.com.vn/thong-tin-khoa-hoc/nhung-luu-y-ve-viec-thuc-hanh-lay-thoi-gian-hanh-nghe#cch-np-h-s-v-thi-gian-bt-u-thc-tp-ti-bnh-vin-nguyn-tri-phng)


## _**Bác sĩ thực hành 18 tháng tại cơ sở khám, chữa bệnh hợp pháp trên địa bàn Thành phố Hồ Chí Minh, không có hộ khẩu tại Thành phố Hồ Chí Minh. Vậy có được Sở Y tế Thành phố Hồ Chí Minh cấp Chứng chỉ hành nghề không?**_
Căn cứ theo Khoản 9 Điều 1 Thông tư 41/2015/TT-BYT sửa đổi bổ sung Điều 7 Thông tư 41/2011/TT-BYT, có 02 trường hợp như sau:
- Trong trường hợp người hành nghề sau khi thực hành 18 tháng tại cơ sở khám chữa bện hợp pháp trên địa bàn Thành phố Hồ Chí Minh thuộc diện quản lý của Sở Y tế Thành phố Hồ Chí Minh, hiện vẫn tiếp tục làm việc tại cơ sở khám, chữa bệnh trên địa bàn Thành phố Hồ Chí Minh và thuộc diện quản lý của Sở Y tế Thành phố Hồ Chí Minh thì nộp hồ sơ xin cấp Chứng chỉ hành nghề tại Sở Y tế Thành phố Hồ Chí Minh (không phụ thuộc hộ khẩu)
- Trong trường hợp người hành nghề sau khi thực hành 18 tháng tại cơ sở khám chữa bện hợp pháp trên địa bàn Thành phố Hồ Chí Minh không thuộc diện quản lý của Sở Y tế Thành phố Hồ Chí Minh, hiện vẫn đang tiếp tục làm việc thì nộp hồ sơ đề nghị cấp CCHN về Cơ quan quản lý cơ sở KB,CB đó. Ví dụ: BV Chợ Rẫy, BV Thống Nhất… thuộc Bộ Y tế; BV 175, BV 7A… thuộc Bộ Quốc Phòng.
- Trong trường hợp người hành nghề sau khi thực hành 18 tháng tại cơ sở khám chữa bệnh hợp pháp trên địa bàn Thành phố Hồ Chí Minh, hiện tại không tiếp tục làm việc cho bất kỳ cơ sở khám, chữa bệnh nào khác trên địa bàn Thành phố Hồ Chí Minh thì nộp hồ sơ xin cấp Chứng chỉ hành nghề tại Sở Y tế nơi có đăng ký hộ khẩu thường trú.
## _**Đi thực tập lâm sàng tại bệnh viện Nguyễn Tri Phương, học viên cần lưu ý gì?**_
1. Quy định về giờ giấc: Các học viên thực tập tại các khoa lâm sàng phải tuân thủ qui định của BV về thời gian thực tập. Trực theo sự phân công của bệnh viện.
2. Quy định về trang phục: Đi thực tập bắt buộc phải mặc đồng phục chuyên môn đúng theo qui định. Bắt buộc phải đeo bảng tên (thẻ học viên) khi đi thực tập. Không mặc quần áo blouse ra ngoài khu vực bệnh viện.
3. Chấp hành nội quy, quy chế bệnh viện và khoa thực tập, tuân thủ theo sự phân công của người hướng dẫn.
4. Có thái độ đúng mực với giảng viên, nhân viên y tế, bạn học. Có thái độ ân cần niềm nở, nhanh nhẹn sẵn sàng giúp đỡ đối với người bệnh, gia đình người bệnh.
5. Tham gia sinh hoạt chuyên môn theo yêu cầu: cần đầy đủ, đúng giờ, đúng trang phục theo đúng quy định.
6. Thực hiện nghiêm quy chế kiểm soát nhiễm khuẩn bệnh viện, giữ gìn trật tự vệ sinh chung.
7. Trong giờ học lâm sàng phải ở đúng vị trí được phân công, không tụ tập, đứng, ngồi ngoài hành lang.
8. Thực hiện đúng các qui định về học lâm sàng; có sổ tay lâm sàng, thực hiện đủ chỉ tiêu tay nghề, làm đầy đủ các kế hoạch chăm sóc, bài tập được giao trong suốt quá trình thực tập lâm sàng.
9. Thực hiện và giữ gìn vệ sinh phòng học lâm sàng. Nghiêm túc tuân thủ các nội quy tại bệnh viện, khoa phòng mà mình thực tập. 
10. Thực hiện đúng quy định về phát ngôn và quy chế chuyên môn trong bệnh viện.
## _**Cách nộp hồ sơ và thời gian bắt đầu thực tập tại Bệnh viện Nguyễn Tri Phương?**_
  * Bệnh viện thực hiện chiêu sinh thực hành liên tục cho đến khi đủ số lượng học viên/ người hướng dẫn theo quy định.
  * Chỉ nhận hồ sơ nộp trực tiếp (không nhận hồ sơ qua đường bưu điện) vì liên quan đến hướng dẫn và bố trí lịch học cụ thể cho từng học viên.
  * Thông thường bắt đầu thực tập vào ngày đầu tháng (sau khi đã hoàn tất hồ sơ và thủ tục về học phí đào tạo).
  * Bệnh viện có những hướng dẫn cụ thể về biểu mẫu và nội dung khóa học trên trang web, học viên cần xem và thực hiện đúng theo các thông tin đã được đăng tải.


**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [Bác sĩ thực hành 18 tháng tại cơ sở khám, chữa bệnh hợp pháp trên địa bàn Thành phố Hồ Chí Minh, không có hộ khẩu tại Thành phố Hồ Chí Minh. Vậy có được Sở Y tế Thành phố Hồ Chí Minh cấp Chứng chỉ hành nghề không?](https://bvnguyentriphuong.com.vn/thong-tin-khoa-hoc/nhung-luu-y-ve-viec-thuc-hanh-lay-thoi-gian-hanh-nghe#bc-s-thc-hnh-18-thng-ti-c-s-khm-cha-bnh-hp-php-trn-a-bn-thnh-ph-h-ch-minh-khng-c-h-khu-ti-thnh-ph-h-ch-minh-vy-c-c-s-y-t-thnh-ph-h-ch-minh-cp-chng-ch-hnh-ngh-khng)
  * [Đi thực tập lâm sàng tại bệnh viện Nguyễn Tri Phương, học viên cần lưu ý gì?](https://bvnguyentriphuong.com.vn/thong-tin-khoa-hoc/nhung-luu-y-ve-viec-thuc-hanh-lay-thoi-gian-hanh-nghe#i-thc-tp-lm-sng-ti-bnh-vin-nguyn-tri-phng-hcvin-cn-lu-g)
  * [Cách nộp hồ sơ và thời gian bắt đầu thực tập tại Bệnh viện Nguyễn Tri Phương?](https://bvnguyentriphuong.com.vn/thong-tin-khoa-hoc/nhung-luu-y-ve-viec-thuc-hanh-lay-thoi-gian-hanh-nghe#cch-np-h-s-v-thi-gian-bt-u-thc-tp-ti-bnh-vin-nguyn-tri-phng)



## Trường ĐH Y khoa Nguyễn Tất Thành ghé thăm BV và chúc tết Quý Mão 2023

Ban Giám đốc BV xin trân trọng sự quan tâm của Nhà trường và cùng nhìn đến một năm mới hợp tác thành công hơn nữa, hiệu quả hơn nữa./.

## Công bố đơn vị đào tạo lần thứ 6 đối với BV Nguyễn Tri Phương

Xem toàn bộ công bố [**tại đây**](https://bvnguyentriphuong.com.vn/uploads/072022/files/4817_Cong%20bo%20cap%20nhat%20bo%20sung%20noi%20dung%20thuc%20hanh%20Dai%20hoc%20nganh%20Y%20da%20khoa%20va%20CTDT%20Phau%20thuat%20tao%20hinh%20tham%20my%20co%20ban_Lan%206.pdf)
#### Nội dung trong file:


**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh

## Trường Đại học Trà Vinh đến thăm và chúc tết bệnh viện

Sáng ngày 13/01/2023. Đại diện Đoàn Trường Đại học Trà Vinh - Tiến sĩ Nguyễn Thanh Bình đã đến thăm và chúc tết bệnh viện.
Tiến sĩ Nguyễn Thanh Bình thay mặt Đoàn đại diện trường Đại học Trà Vinh chúc mừng những thành quả bệnh viện đã đạt được trong năm qua đồng thời ghi nhận và trân trọng những đóng góp của toàn thể nhân viên bệnh viện. Nhân dịp Tết đến, Tiến sĩ Nguyễn Thanh Bình đã chúc Đảng ủy, Ban Giám đốc và toàn thể nhân viên Bệnh viện Nguyễn Tri Phương được bình an, mạnh khỏe và hạnh phúc để tiếp tục nỗ lực cống hiến cho sự nghiệp chăm sóc sức khỏe cho các bệnh nhân
Phát biểu đáp từ, Bác sĩ Chuyên khoa II Võ Đức Chiến – Bí thư Đảng ủy, Giám đốc Bệnh viện đã thay mặt toàn thể nhân viên Bệnh viện gửi lời cảm ơn chân thành đến Tiến sĩ Nguyễn Thanh Bình cùng đoàn Trường Đại học Trà Vinh đã đến thăm, chúc Tết và tặng quà cho Bệnh viện; đây là sự quan tâm và động lực giúp Bệnh viện hoàn thành tốt những mục tiêu phát triển bệnh viện trong năm tới.
**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/) **- Đa khoa Hạng I Thành phố Hồ Chí Minh

## ️ BV Nguyễn Tri Phương đón nhận và phối hợp đào tạo BS 18 tháng cùng TTYT quận, huyện

Đây là một khóa học có rất nhiều ý nghĩa mà cá nhân **PGS TS BS Tăng Chí Thượng** - Giám đốc Sở Y Tế TPHCM đã có những lời nhắn gửi rất thân tình cho các BS trẻ tham gia chương trình:
**_"8g30 ngày 16/2 sẽ diễn ra Lễ đón bác sĩ trẻ về tăng cường y tế cơ sở, đây là hoạt động đầu tiên và rất nhiều ý nghĩa đối với Ngành Y tế trong việc nâng cao năng lực y tế cơ sở. Các em là những người tiên phong mang làn gió mới cho y tế cơ sở, Sở Y tế tin rằng các tân bác sĩ sẽ có những tháng ngày thật ý nghĩa trên con đường sự nghiệp hành nghề của mình._**
**_Sở Y tế tin rằng các BV được giao nhiệm vụ hướng dẫn thực hành sẽ hoàn thành tốt trách nhiệm đối với y tế cơ sở trong việc hướng dẫn, theo dõi quá trình thực hành của bác sĩ trẻ. Cả nước cùng theo dõi và mong đợi Ngành y tế TPHCM sẽ thành công với chương trình đào tạo thực hành cho các bác sĩ mới tốt nghiệp đồng thời mở ra hướng mới để góp phần nâng cao năng lực cho y tế cơ sở._**
**_Sở Y tế xin cám ơn các Sở, ban ngành và lãnh đạo TP đã đồng thuận và tạo điều kiện tốt nhất để Ngành y tế TP hiện thực hoá chương trình này. Chúc các bác sĩ trẻ sẽ nỗ lực học tập và cống hiến hết mình cho sự nghiệp chăm sóc sức khoẻ nhân dân, các bạn sẽ “được” nhiều hơn là “mất” khi tham gia chương trình này, trong đó cái được lớn nhất chính là khoảng thời gian trải nghiệm với nghề ngay tại y tế cơ sở, sẽ có cơ hội học tập từ thực tiễn, cơ hội gần dân và hiểu dân, cơ hội học tập kinh nghiệm từ các anh chị đồng nghiệp đi trước, học tập các thầy cô,… để rồi sau này cho dù các bạn công tác ở bất kỳ vị trí nào, những trải nghiệm này sẽ giúp bạn rất nhiều để thích ứng với cuộc sống và công việc."_**
Bên cạnh đó, Sở Y tế đã cũng đã đề ra kế hoạch tiếp đón các BS trẻ về các TTYT quận, huyện. Các khâu chuẩn bị đã được triển khai tại các điểm cầu một cách chỉn chu, nhanh chóng theo đúng kế hoạch đề ra
BV Nguyễn Tri Phương kính chúc các tân BS sẽ thật thành công khi tham gia khóa học lần đầu tiên được tổ chức theo hình thức phối hợp BV Đa khoa - TTYT với mục tiêu "Chuẩn mực - Gần dân - Thực tế".
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh

## Thông báo về việc tiếp nhận sinh viên thực tập lại


## ️ Thông báo tổ chức lớp Dược lâm sàng 2022

**I. ĐỐI TƯỢNG THAM GIA:**
1. Dược sĩ trong bệnh viện có nhu cầu.
2. Dược sĩ từ các bệnh viện khác có nhu cầu.
**II. NỘI DUNG KHÓA HỌC:**
**1. Giảng viên:**
  * Giảng viên chính: TS. DS. Võ Thị Hà – Giảng viên BM Dược lý – Dược lâm sàng, ĐH Y Khoa Phạm Ngọc Thạch; Phụ trách Tổ DLS, BV NTP.
  * Hỗ trợ: Các dược sĩ lâm sàng của Bệnh viện Nguyễn Tri Phương.


**2. Thời gian và hình thức chiêu sinh:**
  * Hình thức chiêu sinh: chiêu sinh liên tục.


  * Chiêu sinh tuần thứ 1 của tháng: chương trình Module 01
  * Chiêu sinh tuần thứ 2 của tháng: chương trình Module 02
  * Chiêu sinh tuần thứ 3 của tháng: chương trình Module 03


  * Thời gian thực hành mỗi module: trong giờ hành chính, từ thứ 2 đến thứ 6. 
  * Chỉ tiêu tuyển sinh mỗi module: tối đa 0 học viên/module/tuần
  * Thời gian bắt đầu thực hành: từ đầu mỗi tháng, dự kiến sẽ bắt đầu học từ tháng 03/2022


**3. Địa điểm và học phí:**
- Học phí: 1.000.000 đồng/học viên/module _(thanh toán trực tiếp khi đến đăng ký)_
- Địa điểm học: Khoa Dược – Bệnh viện Nguyễn Tri Phương (468 Nguyễn Trãi, Phường 8, Quận 5, Tp. Hồ Chí Minh)
**III. THỜI GIAN VÀ THỦ TỤC ĐĂNG KÝ**
**1. Hồ sơ đăng ký:**
  * Đơn đăng ký theo mẫu
  * Bằng chuyên môn dược _(photo có công chứng)_
  * 02 tấm hình 03x04 _(ghi họ tên, ngày tháng năm sinh phía sau)_


**2. Thời gian, địa điểm nhận hồ sơ:**
  * Thời gian nhận đơn: trước 01 tuần đối với module đăng ký _(trong giờ hành chính từ thứ 2 đến thứ 6)_
  * Địa điểm nhận đơn: Phòng Quản lý chất lượng – Bệnh viện Nguyễn Tri Phương _(lầu 1 – khu A)_


Tải mẩu đơn đăng ký [**TẠI ĐÂY**](https://drive.google.com/file/d/1D_qNPVQpufBtRWpWlwg_Qr1sm6fwP_wR/view?usp=sharing)
**Thông tin hướng dẫn đăng ký và sắp xếp lịch học vui lòng liên hệ:**
  * CN Vũ Minh Tuấn: 0907.1010.25
  * CN Dương Trần Cát Uyên: 0969.011.426



## Thông báo về việc công bố cơ sở khám bệnh, chữa bệnh đáp ứng yêu cầu là cơ sở thực hành trong đào tạo khối ngành sức khỏe lần 5


## Thông báo về việc công bố cơ sở khám bệnh, chữa bệnh đáp ứng yêu cầu là cơ sở thực hành trong đào tạo khối ngành sức khỏe lần 3


## ️ Vai trò của xét nghiệm định lượng anti-Xa trong điều trị kháng đông

Báo cáo khoa học kỹ thuật nhắc lại con đường đông máu, các xét nghiệm giúp theo dõi tình trạng đông máu ở bệnh nhân tăng đông có điều trị heparin. Các xét nghiệm bao gồm: ACT test, aPTT và anti-Xa
Theo dõi bằng anti-Xa giúp: 
  * Giúp đạt được ngưỡng điều trị heparin nhanh hơn, chính xác hơn vì sự sai khác giữa các máy đo khác nhau và các labo khác nhau thấp hơn
  * Áp dụng ở các bệnh nhân phải chạy ECMO, bệnh nhân thông tim can thiệp cần dùng heparin, bệnh nhân CoVID nặng
  * Theo dõi bằng anti Xa giúp: giảm lượng máu cần truyền, giảm tỷ lệ tử vong


Với LMWH (heparin trọng lượng phân tử thấp) bắt buộc theo dõi liều dùng bằng Anti-Xa
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh

## Thông báo 'vv khai giảng lớp 'Tập huấn an toàn phòng mổ''


## Lớp Thận Học – Lọc Máu năm 2022

**THÔNG BÁO CHIÊU SINH**
Về việc tổ chức Lớp đào tạo liên tục chuyên đề “Thận Học - Lọc Máu” năm 2022
Căn cứ công văn 5827/SYT-TCCB ngày 22 tháng 10 năm 2010 của Sở Y tế về việc phê duyệt chương trình đào tạo liên tục cho cơ sở đào tạo Bệnh viện Nguyễn Tri Phương,
Căn cứ Công văn 8686/BYT-K2ĐT ngày 15 tháng 12 năm 2010 của Bộ Y tế về việc công nhận đủ điều kiện đào tạo liên tục ngành y tế (đợt 3),
Căn cứ Quyết Định5203/QĐ-BYT ngày  tháng  _2019_ về việc Bãi bỏ Quy trình 51 Quy định về nhân sự cho đơn vị lọc máu tại hướng dẫn quy trình kỹ thut thn nhân tạo ban hành kèm theo quyết định 2482/QĐ-BYT ngày 13 tháng 4 năm 2018 của bộ trưởng Bộ Y Tế
Căn cứ Kế hoạch số 01/NTP-CĐT ngày 09 tháng 02 năm 2022 của Bệnh viện Nguyễn Tri Phương về việc Tổ chức Lớp Đào Tạo Liên Tục chuyên đề “Thận học – lọc máu”,
Để đảm bảo theo quy định của Bộ Y tế về chương trình đào tạo liên tục cho cơ sở đào tạo Bệnh viện Nguyễn Tri Phương. Bệnh viện sẽ tổ chức lớp học thời gian 03 tháng cho đối tượng Bác sĩ và Điều dưỡng như sau:
**I. Thông tin khóa học:**
- Thời gian học: 03 tháng (231 tiết), từ ngày 06/04/2022 đến 05/07/2022 gồm lý thuyết và thực hành.
- Khai giảng: (có làm Pre-Test)
+ Lớp bác sĩ ngày 06/04/2022 (thứ tư) lúc 13 giờ 30 phút 
+ Lớp điều dưỡng ngày 08/04/2022 (thứ tư) lúc 13 giờ 30 phút
Địa điểm: tại hội trường B, lầu 5, bệnh viện Nguyễn Tri Phương.
- Hình thức học: 
+ Lý thuyết: học tập trung hoặc trực tuyến qua phần mềm Microsoft Teams.
+ Thực hành: tại khoa Thận - Lọc máu theo tiêu chuẩn Nhật Bản tại Bệnh viện Nguyễn Tri Phương (tùy theo lịch đăng ký cụ thể của mỗi học viên)
- Lịch học dự kiến: 
+ Lý thuyết:
  * Thứ 4 hàng tuần lúc 13 giờ 30 phút (Đối tượng Bác sĩ)
  * Thứ 6 hàng tuần lúc 13 giờ 30 phút (Đối tượng Điều dưỡn


+ Thực hành: (bác sĩ và điều dưỡng)
  * Nhóm 1: buổi chiều thứ 3 và thứ 5 / cả ngày thứ 3 hoặc cả ngày thứ 5
  * Nhóm 2: buổi chiều thứ 4 và thứ 6 / cả ngày thứ 4 hoặc cả ngày thứ 6


+ Thời gian học sẽ thông báo cụ thể khi nhập học.
**- Điều kiện cấp bằng:**
+ Kết thúc khóa học học viên hoàn thành trên 85% thời gian học lý thuyết và thực hành.
+ Đạt yêu cầu về bài thi lý thuyết và đánh giá thực hành chuyên môn cuối khóa.
Chứng chỉ đào tạo liên tục  _(CME được Bộ Y tế cấp phép)_ về Thận Học - Lọc Máu do [Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/) cấp.
**II. Nộp hồ sơ và học phí:**
  1. **Hồ sơ đăng ký:**


- 2 tấm hình 3*4 (mặt sau ghi rõ họ tên, ngày tháng năm sinh)
- Đơn đăng ký học theo mẫu file đính kèm
Photo công chứng “ _Bằng chuyên môn Bác sĩ (đa khoa)/ Điều dưỡng_ ”
__Thời gian nhận đơn kể từ ngày ra thông báo đến ngày 30/03/2022__
  1. **Học phí:**


- Bác sĩ: 6.500.000 đồng/học viên
- Điều dưỡng: 5.000.000 đồng/học viên
- Đóng học phí một lần bằng tiền mặt hoặc chuyển khoản, xuất hóa đơn theo quy định hiện hành.
• Trực tiếp đóng tại Phòng Tài Chính Kế Toán - Bệnh viện Nguyễn Tri Phương.
• Chuyển khoản:
- Tên tài khoản: Bệnh viện Nguyễn Tri Phương
- Số tài khoản: 0251002787729 – Ngân hàng Ngoại Thương Việt Nam (VietcomBank), chi nhánh Bình Tây TP. Hồ Chí Minh. 
- Nội dung chuyển khoản: “Tên cá nhân” hoặc “Tên đơn vị” + “CK học phí lớp Thận Học – Lọc Máu 2022”.
• Thông tin để xuất hóa đơn:
**Tên đơn vị** |  **Địa chỉ** |  **Mã số thuế** |  **Họ tên học viên** |  **Nội dung** |  **Số tiền** |  **Email**  
---|---|---|---|---|---|---  
__Hạn chót thanh toán học phí ngày 06/04/2022__
**III. Quy định về Phòng chống dịch COVID-19:**
Để đảm bảo công tác Phòng chống dịch COVID-19 học viên vào học tập tại Bệnh viện Nguyễn Tri Phương cần nghiêm túc thực hiện các quy định như sau:
- Tuân thủ các quy định phòng chống dịch tại bệnh viện
- Tham gia đúng thời gian của khóa học
- Trong quá trình thực tập tại bệnh viện Nguyễn Tri Phương học viên cần được xét nghiệm SARS-COV-2 định kỳ như nhân viên của Khoa Thận – Lọc máu (chi phí xét nghiệm do học viên tự chi trả hoặc có thể xét nghiệm tại đơn vị công tác và báo kết quả về Khoa Thận – Lọc máu).
Các đơn vị, cá nhân có nhu cầu đăng ký trước trực tiếp tại t _ổ Nghiên cứu Khoa học trực thuộc Phòng Chỉ Đạo tuyến –_[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/) _(lầu 01 – Khu A)._
Hoặc đăng ký qua email: _daotaolocmau2022.bvntp@gmail.com_ _(gửi Danh sách học viên tham gia có chữ ký và mộc của Thủ trưởng đơn vị trước và gửi bổ sung bằng văn bản sau)_
_Mẫu danh sách đăng ký:_
Họ Tên |  Ngày Sinh |  Chức Danh |  Đơn vị công tác |  Đăng ký thực hành |  Số điện thoại  
---|---|---|---|---|---  
  1. **Mọi chi tiết xin liên hệ:**


CV. Nguyễn Mạnh Hùng - Điện thoại: 0918 967 339 
BS. Phạm Đặng Hoài Nam – Điện thoại: 0939 301 923
CV. Đinh Thị Hồng Nhung - Điện thoại: 0989 300 080
_(Vui lòng liên hệ giờ hành chính từ thứ hai đến thứ sáu hàng tuần)_
Trân trọng./.
Link đính kèm:
[/uploads/082021/files/Th%C3%B4ng%20b%C3%A1o%20L%E1%BB%9Bp%20L%E1%BB%8Dc%20m%C3%A1u%202022.pdf](https://bvnguyentriphuong.com.vn/uploads/082021/files/Th%C3%B4ng%20b%C3%A1o%20L%E1%BB%9Bp%20L%E1%BB%8Dc%20m%C3%A1u%202022.pdf)
#### Nội dung trong file:

1 
 SỞ Y TẾ THÀNH PHỐ HỒ CHÍ MINH  
BỆNH VIỆN NGUYỄN TRI PHƯƠNG  CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM  
Độc lập – Tự do – Hạnh phúc  
Số:         /TB-NTP  Thành phố Hồ  Chí Minh, ngày 07 tháng 03 năm 2022  
THÔNG BÁO  
Về việc điều chỉnh nội dung  liên quan lớp học Thậ n học – Lọc máu 2022  
Kính gửi:  Ban Giám Đốc  bệnh viện  ..............................   
Căn cứ công v ăn 5827/SYT -TCCB ngày 22 tháng 10 năm 2010 của Sở Y tế về 
việc phê duyệt chương trình đào tạo liên tục cho cơ sở đào tạo Bệnh viện Nguyễn T ri 
Phương,  
Căn cứ Công văn 8686/BYT -K2ĐT ngày 1 5 tháng 12 năm 2010 của Bộ Y tế về 
việc công nhận đủ điều kiện đào tạo liên tục ngành y tế (đợt 3 ), 
Căn cứ Quyết Định  số 5203/QĐ -BYT ngày  04 tháng  11 năm 2019  về việc Bãi bỏ 
Quy trìn h 51 “Quy định về nhân sự cho đơn vị lọc máu tại hướng dẫn quy trình kỹ th uật 
thận nhân tạo ban hành kèm theo quyết định 2482/QĐ -BYT ngày 13 tháng 4 năm 2018 
của bộ trưởng Bộ Y Tế ”, 
Căn cứ Kế hoạch số 01/NTP -CĐT ngày 09 tháng 02 năm 2022  của Bệnh viện 
Nguyễn Tri Phương về việc Tổ chức Lớp Đào Tạo Liên Tục chuyên đề “Thận học – lọc 
máu” , 
Để đảm bảo theo quy định của Bộ Y tế về chương trình đào tạo liên tục cho cơ sở 
đào tạo Bệnh viện Nguyễn Tri Phương . Bệnh viện sẽ tổ chức lớp học thời gian 03 tháng  
cho đ ối tượng Bác sĩ và Điều dưỡng  như sau:  
I. Thông tin khóa h ọc: 
- Thời gian  học: 03 tháng (231 ti ết), từ ngày 06/04/2022 đ ến 05/07/2022  gồm lý thuy ết 
và th ực hành . 
- Khai gi ảng: (có làm Pre -Test)  
+ Lớp Bác sĩ ngày 06/04/2022 (th ứ tư): lúc 13 gi ờ 30 phút 
+ Lớp Điều dưỡng ngày 08/04/2022 (th ứ tư): lúc 13 gi ờ 30 phút 
Địa điểm: tại Hội trường B,  lầu 5, b ệnh vi ện Nguy ễn Tri Phương.  
- Hình th ức học:  
+ Lý thuy ết: học tập trung  hoặc trực tuy ến qua ph ần mềm Microsoft Teams . 
+ Thực hành : tại khoa Th ận - Lọc máu theo tiêu chuẩn Nh ật Bản tại Bệnh vi ện 
Nguy ễn Tri Phương (tùy theo l ịch đăng ký c ụ thể của mỗi học viên)  
 - Lịch học dự kiến:  2 
  + Lý thuyết:  
 Thứ 4 hàng tuần lúc 13 giờ 30  phút (Đối tượng Bác sĩ)  
 Thứ 6 hàng tuần lúc 13 giờ 30  phút (Đối tượng Điều dưỡng)  
 + Thực hành: (bác sĩ và điều dưỡng)  
 Nhóm 1: buổi chiều  thứ 3 và thứ 5 / cả ngày thứ 3 hoặc cả ngày thứ 5  
 Nhóm  2: buổi chiều thứ 4 và thứ 6 / cả ngày thứ 4 hoặc cả ngày thứ 6  
+ Thời gian h ọc sẽ thông báo c ụ thể khi nh ập học. 
- Điều kiện cấp bằng:  
+ Kết thúc khóa học học viên hoàn thành  trên 85 % thời gian học lý thuyết và thực 
hành.  
+ Đạt yêu cầu  về bài thi lý thuy ết và đánh giá thực hành chuyên môn cuối khóa.  
+ Chứng chỉ đào tạo liên tục  (CME được Bộ Y tế cấp phép)  về Thận Học - Lọc 
Máu do  Bệnh viện Nguyễn Tri Phương  cấp. 
II. N ộp hồ sơ và h ọc phí:  
 Hồ sơ đăng ký : 
- 2 tấm hình 3*4 ( mặt sau ghi rõ h ọ tên, ngày tháng năm sinh)  
- Đơn đăng ký h ọc theo m ẫu file đính kèm  
- Photo công ch ứng “Bằng chuyên môn Bác sĩ (đa khoa)/ Đi ều dưỡng” 
Thời gian nh ận đơn k ể từ ngày ra thông báo đ ến ngày 30/03/2022  
 Học phí:  
- Bác sĩ: 6.500.000 đồng/học viên  
- Điều dưỡng:  5.000.000 đồng/học viên  
- Đóng học phí một lần bằng tiền mặt hoặc chuyển khoản, xuất hóa đơn theo quy 
định hiện hành.  
• Trực  tiếp đóng tại  Phòng Tài Chính Kế Toán - Bệnh viện Nguyễn Tri Phương.  
• Chuyển khoản:  
- Tên tài khoản: Bệnh viện Nguyễn Tri Phương  
- Số tài khoản: 0251002787729 – Ngân hàng Ngoại Thương Việt Nam (VietcomBank),  
chi nhánh Bình Tây TP. Hồ Chí Minh.   
- Nội dung chuyển khoản: “ Tên cá nhân” hoặc “Tên đơn vị” + “CK học phí lớp 
Thận Học – Lọc Máu 2022” . 
• Thông tin để xuất hóa đơn:  3 
 
Tên đơn vị  Địa chỉ  Mã số thuế  Họ tên 
học viên  Nội dung  Số tiền  Email  
Hạn chót thanh toán học phí ngày 06/04 /2022 . 
III. Quy định về Phòng chống dịch COVID -19: 
 Để đảm bảo công tác Phòng chống dịch COVID -19 học viên vào học tậ p tại Bệnh 
viện Nguyễn Tri Phương cần nghiêm túc thực hiện các quy định như sau:  
 - Tuân thủ các quy định phòng chống dịch tại bệnh viện  
 - Tham gia đúng thời gian của khóa học  
 - Trong quá trình thực tập tại bệnh viện Nguyễn Tri Phương học viên cần được x ét 
nghiệm SARS -COV -2 định kỳ như nhân viên của Khoa Thận – Lọc máu (chi phí xét 
nghiệm do học viên tự chi trả hoặc có thể xét nghiệm tại đơn vị công tác và báo kết quả về 
Khoa Thận – Lọc máu).  
 Các đơn vị, cá nhân có nhu cầu đăng ký trước trực tiếp tại t ổ Nghiên cứu Khoa học 
trực thuộc Phòng Chỉ Đạo tuyến – Bệnh viện Nguyễn Tri Phương  (lầu 01 – Khu A).  
Hoặc đăng ký qua email: daotaolocmau2022 .bvntp@gmail.com  (gửi Danh sách 
học viên tham gia có chữ ký và mộc của Thủ trưởng đơn vị trước và gửi bổ sung bằng văn 
bản sau)  
Mẫu danh sách đăng ký:  
Stt Họ Tên  Ngày Sinh  Chức Danh  Đơn vị 
công tác  Đăng ký 
thực hành  Số điện 
thoại  
 Mọi chi tiết xin liên hệ : 
CV. Nguy ễn Mạnh Hùng - Điện thoại: 0918. 967.339  
 BS. Phạm Đặng Hoài Nam – Điện thoại: 0939. 301.923 
CV. Đinh Thị Hồng Nhung - Điện thoại:  0989. 300.080 
 (Vui lòng liên h ệ giờ hành chí nh từ thứ hai đ ến thứ sáu hàng tu ần) 
Trân trọng./.   
Nơi nhận:  
- Như trên  
- Các bệnh vi ện công, tư  
có khoa Th ận, Lọc máu  
- Khoa Th ận-Lọc Máu BVNTP  
- Lưu VT, CĐT  (ĐTHN /50b) 
                        “NMH ” 
   4 
 CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM  
Độc lập – Tự do – Hạnh phúc  
-----o0o---- 
ĐƠN ĐĂNG KÝ  
THAM GIA LỚP ĐÀO TẠO LIÊN TỤC CHUYÊN ĐỀ  
THẬN HỌC – LỌC MÁU NĂM 2022  
Kính gửi:  Bệnh viện Nguyễn Tri Phương  
 
Họ và tên  :  ................................ ................................ .............  Giới tính  ...................   
Sinh ngày  :  ............  tháng  ..........  năm ..................  Nơi sinh:  ................................ ........   
Địa chỉ  :  ................................ ................................ ................................ ...............   
Điện thoại  :  ................................ ....... E.mail  :  ................................ ........................   
Hiện công tác tại đơn vị  :  ................................ ................................ ............................   
Khoa  :  ................................ ................................ ............................   
Đối tượ ng :   Bác sĩ                  Điều dưỡng  
(Vui lòng ghi thông tin đầy đủ và chính xác để tiện cho việc cấp bằng sau này, xin cung 
cấp địa chỉ email để nhận tài liệu học tập)  
Tôi xin đăng ký theo khóa học “Lớp đào tạo liên tục chuyên đề Thận học – Lọc máu  
năm 2022”,  được tổ chức tại Bệnh viện Nguyễn Tri Phương.  
Thời gian tham gia đào tạo: từ  …… / …… /20……  đến  …… / …… / 20……  
Tôi xin cam kết tuân thủ quy chế và quy định của Bệnh viện.  
 ………………, ngày …… tháng …… năm …………  
 Người làm đơn  
 (Ký, ghi rõ họ và tên)  
 
 
 
 
 
 
 
 
 
 
Hồ sơ bao gồm:  
 Đơn đăng ký;  
 Bằng tốt nghi ệp Bác sĩ ho ặc điều dưỡng (có công ch ứng). 
 02 tấm hình 3x4 (ghi h ọ tên, ngày tháng năm sinh)
Đơn đăng ký;
[/uploads/082021/files/2022%20-%20M%E1%BA%AAU%20%C4%90%C4%82NG%20K%C3%9D%20L%E1%BB%9AP%20L%E1%BB%8CC%20M%C3%81U.docx](https://bvnguyentriphuong.com.vn/uploads/082021/files/2022%20-%20M%E1%BA%AAU%20%C4%90%C4%82NG%20K%C3%9D%20L%E1%BB%9AP%20L%E1%BB%8CC%20M%C3%81U.docx)
#### Nội dung trong file:

CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM
Độc lập – Tự do – Hạnh phúc
-----o0o----
ĐƠN ĐĂNG KÝ
THAM GIA LỚP ĐÀO TẠO LIÊN TỤC CHUYÊN ĐỀ
THẬN HỌC – LỌC MÁU NĂM 2022
Họ và tên	:		Giới tính	
Sinh ngày	:		tháng	năm	Nơi sinh:	
Địa chỉ	:		
Điện thoại	:		E.mail	:		
Hiện công tác tại đơn vị	:		
Khoa	:		
Đối tượng	: 	 Bác sĩ                  Điều dưỡng
(Vui lòng ghi thông tin đầy đủ và chính xác để tiện cho việc cấp bằng sau này, xin cung cấp địa chỉ email để nhận tài liệu học tập)
Tôi xin đăng ký theo khóa học “Lớp đào tạo liên tục chuyên đề Thận học – Lọc máu năm 2022”, được tổ chức tại Bệnh viện Nguyễn Tri Phương.
Thời gian tham gia đào tạo: từ …… / …… /20……  đến  …… / …… /20……
Tôi xin cam kết tuân thủ quy chế và quy định của Bệnh viện.
	………………, ngày …… tháng …… năm …………
	Người làm đơn
	(Ký, ghi rõ họ và tên)











Hồ sơ bao gồm:
Đơn đăng ký;
Bằng tốt nghiệp Bác sĩ hoặc điều dưỡng (có công chứng).
02 tấm hình 3x4 (ghi họ tên, ngày tháng năm sinh)

## ️ BV Nguyễn Tri Phương tham gia ký kết hợp tác đào tạo BS 18 tháng với TTYT quận huyện

**Tại đầu cầu Quận 6**
**Tại đầu cầu Huyện Cần Giờ**
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh

## Khoa Y - Đại học Nguyễn Tất Thành thăm và chúc tết Bệnh viện

Ngày 19/01/2022 nhân tết Nhâm Dần, Khoa Y - trường ĐH Nguyễn Tất Thành đã thăm và chúc tết Ban Giám đốc , đại diện Ban đào tạo của Bệnh viện
PGS Lê Thị Kim Nhung, đại diện Khoa Y đã có những lời chúc tết đến Bệnh viện và mong muốn hợp tác viện - trường sẽ ngày thêm tốt đẹp, hiệu quả
Đại diện BV Nguyễn Tri Phương - BS CKII Võ Đức Chiến, đã gửi lời cảm ơn chân thành đến lãnh đạo Khoa Y - trường ĐH Nguyễn Tất Thành và mong muốn thêm nhiều hoạt động kết hợp đào tạo hiệu quả sẽ được triển khai trong năm 2022.

## BV Nguyễn Tri Phương nhận hồ sơ thực tập lấy chứng chỉ hành nghề mới

Trong thời gian qua, Thành phố đã thực hiện nhiều hoạt động giãn cách song song với bao phủ vắc xin để dần tiến đến tình trạng "bình thường mới" với tinh thần sống chung an toàn cùng Covid
Với những học viên tham gia thực tập, BV nhắc nhở và yêu cầu luôn thực hiện nghiêm túc:
  1. Tất cả học viên thực hiện khai báo y tế liên tục và trung thực, đeo [khẩu trang](https://bvnguyentriphuong.com.vn/kiem-soat-nhiem-khuan/cac-loai-khau-trang), đeo bảng tên, rửa tay thường xuyên và thực hiện những phòng ngừa chuẩn tại môi trường bệnh viện. Mỗi học viên đều có cài phần mềm NCOVI và BLUEZONE trong điện thoại cá nhân.
  2. Trong quá trình thực tập tại Bệnh viện, học viên chỉ tập trung thực hành tại khoa, phòng được phân công; không tụ tập ở các hành lang và không di chuyển sang các khu vực khác trong Bệnh viện trừ khi tham gia chuyển bệnh hoặc hoạt động chuyên môn theo yêu cầu; không đi ra ngoài Bệnh viện trong giờ thực tập tại Bệnh viện.
  3. Học viên thực hiện nghiêm túc về vấn đề quyền phát ngôn trong Bệnh viện, không đăng tải trên các mạng xã hội những thông tin chưa được Bệnh viện xét duyệt về vấn đề phòng chống dịch COVID-19 tại Bệnh viện.
  4. Học viên chủ động thông báo cho Ban đào tạo biết bất cứ khi nào có triệu chứng nghi ngờ (ho, sốt, khó thở và đặc biệt đột ngột mất vị giác, mất khứu giác...) cũng như chủ động ngưng thực tập có báo cáo khi cần thiết.


**Với những học viên trong thời gian sắp đến - có nhu cầu tham gia thực tập để lấy thời gian cấp chứng chỉ hành nghề, BV sẽ nhận hồ sơ thực tập với các yêu cầu sau:**
**1. Đã tiêm tối thiểu 01 mũi vắc xin ngừa Covid**
**2. Chấp thuận tham gia theo sự điều phối của BV nếu cần tăng cường các công tác điều trị Covid**
Trong thời gian thực tập - BV sẽ cố gắng trong khả năng cho phép
1. Bao phủ đủ 02 mũi vắc xin ngừa Covid (nếu chưa đủ)
2. Cung cấp đầy đủ các phương tiện phòng hộ
3. Thực hiện các chế độ cần thiết bảo hộ như 01 nhân viên y tế của BV
**Bệnh viện sẽ chính thức nhận lại hồ sơ thực tập lấy chứng chỉ hành nghề mới từ 01/10/2021**
* [Thông báo chiêu sinh thực hành 18 tháng lấy Chứng chỉ hành nghề đa khoa đối với bác sĩ](https://bvnguyentriphuong.com.vn/thong-tin-khoa-hoc/thong-bao-chieu-sinh-thuc-hanh-18-thang-lay-chung-chi-hanh-nghe-da-khoa-doi-voi-bac-si)
* [Đào tạo cấp thời gian thực hành đối với Bác sĩ](https://bvnguyentriphuong.com.vn/thong-tin-khoa-hoc/dao-tao-cap-thoi-gian-thuc-hanh-bac-si)
* [Đào tạo cấp thời gian thực hành đối với Điều dưỡng, Kỹ thuật viên, Nữ hộ sinh](https://bvnguyentriphuong.com.vn/thong-tin-khoa-hoc/cap-thoi-gian-thuc-hanh-dd-ktv-nhs)
Kính báo

## Thông báo chiêu sinh khóa 'Dược lâm sàng' năm 2021

Để xem chi tiết nội dung khóa học và toàn nội dung văn bản[**TẠI ĐÂY**](https://drive.google.com/file/d/1_H1LpEOBCktKRtv8cxq7vpAoWkKMJYNi/view?usp=sharing)
Tải mẩu đơn đăng ký [**TẠI ĐÂY**](https://drive.google.com/file/d/1D_qNPVQpufBtRWpWlwg_Qr1sm6fwP_wR/view?usp=sharing)
**Thông tin hướng dẫn đăng ký và sắp xếp lịch học vui lòng liên hệ:**
  * CN Vũ Minh Tuấn: 0907.1010.25
  * CN Dương Trần Cát Uyên: 0969.011.426



## Hợp tác viện - trường ngày càng hiệu quả với Đại học Nguyễn Tất Thành

Bệnh viện Nguyễn Tri Phương là bệnh viện đa khoa hạng I trực thuộc SYT TP.HCM với đầy đủ các chuyên khoa nội, ngoại, sản, nhi và các chuyên khoa mũi nhọn khác. Song song với công tác điều trị bệnh, BV NTP cũng đã chú trọng trong công tác đào tạo và giảng dạy cho sinh viên và học viên trong nhiều năm qua. BV NTP tự hào là trung tâm thực hành, đào tạo huấn luyện và giảng dạy cho nhiều sinh viên và học viên từ các địa phương trong cả nước. 
Để tăng thêm hiệu quả mối quan hệ Viện – Trường, giúp cho sự phát triển của cả bệnh viện và cả trường, TS BS Lê Cao Phương Duy – PGĐ BV được bổ nhiệm là trưởng phân môn tim mạch của trường ĐH Y Khoa Nguyễn Tất Thành.
Buổi lễ ra mắt ra mắt Ban Giảng huấn Đại học Nguyễn Tất Thành tại bệnh viện Nguyễn Tri Phương đã kết thúc thành công tốt đẹp, và tin rằng hoạt động hợp tác giảng dạy giữa BV NTP và trường ĐH Nguyễn Tất Thành sẽ ngày càng hiệu quả hơn.
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh

## Lớp thực hành 18 tháng lấy Chứng chỉ hành nghề đa khoa

Nhằm triển khai công tác đào tạo thực hành, cấp chứng nhận thời gian thực hành, nay bệnh viện Nguyễn Tri Phương mở khóa đào tạo lấy thời gian hành nghề đa khoa như sau
  1. **ĐỐI TƯỢNG THAM GIA**


  1. Bác sĩ mới tốt nghiệp
  2. Bác sĩ tốt nghiệp đa khoa chưa có chứng chỉ hành nghề


  1. **NỘI DUNG**


  1. Phân bổ thời gian


  1. Khối nội trong 5 tháng


  * Nội tim mạch: 1 tháng 
  * Nội tiêu hóa: 1 tháng 
  * Nội thần kinh: 1 tháng
  * Nội hô hấp: 1 tháng
  * Cấp cứu: 1 tháng


  1. Khối ngoại trong 3 tháng


  * Ngoại Chấn thương chỉnh hình: 1 tháng
  * Ngoại Tiêu hóa: 1 tháng
  * Ngoại Tổng hợp: 1 tháng


  1. Khối Sản – Nhi trong 7 tháng


  * Sản (3 tháng): khu vực phòng sanh, phòng khám thai, phòng khám phụ khoa – mỗi khu vực 1 tháng, nhận xét chung cả quá trình
  * Nhi (4 tháng): thực hiện được chăm sóc ở đơn nguyên sơ sinh (có thể thay bằng 1 tháng thực tập ở phòng sanh chú trọng chăm sóc sơ sinh sau đẻ), phòng bệnh nhi: + phòng tiêm chủng: 03 tháng


  1. Chuyên khoa lẻ (3 tháng)


  * YHCT và PHCN: 1 tháng (mỗi chuyên khoa 0,5 tháng)
  * Mắt: 1/2 tháng
  * Tai Mũi Họng: 1/2 tháng
  * Da liễu (đơn vị Thẫm Mỹ Da): 1/2 tháng
  * Răng hàm mặt (phòng khám): 1/2 tháng


  1. Địa điểm, thời gian và học phí:


  * Học phí: 
    * **Đóng theo tháng:** 3.000.000đ/tháng
    * **Đóng theo gói: 42.000.000đ/ 18 tháng**
  * Địa điểm: Bệnh viện Nguyễn Tri Phương


_(468 Nguyễn Trãi, Phường 8, Quận 5, Tp. Hồ Chí Minh)_
  * Thời gian bắt đầu từ 19/4/2021, tiếp nhận liên tục cho đến khi đủ người tham gia theo quy định


  1. Nội dung khóa học: Dựa trên “Chuẩn năng lực cơ bản của bác sĩ đa” công bố theo Quyết định Số: 1854/QĐ-BYT của Bộ Y Tế


  1. **THỜI GIAN VÀ THỦ TỤC ĐĂNG KÝ**
    1. **Hồ sơ đăng ký:**
       * Đơn đăng ký theo mẫu ([file đính kèm](https://drive.google.com/file/d/18QPPwR3vxckSrArFk1tmtfG5fi00U8Fe/view?usp=sharing))
       * Bằng chuyên môn _(photo có công chứng)_
       * Chứng minh nhân dân / Căn cước công dân _(photo có công chứng)_
       * 02 tấm hình 03x04 _(ghi họ tên, ngày tháng năm sinh phía sau)_
       * Giấy khám sức khỏe chứng nhận đảm bảo đủ điều kiện theo học
    2. Thời gian, địa điểm nhận hồ sơ:
       * Thời gian nhận đơn: tối thiểu trước 01 tuần trước thời gian bắt đầu
       * Địa điểm nhận đơn: Phòng Quản lý chất lượng – Bệnh viện Nguyễn Tri Phương _(lầu 1 – khu A)_


  1. **LIÊN HỆ THÊM THÔNG TIN**


Phòng Quản lý chất lượng – Bệnh viện Nguyễn Tri Phương _(lầu 1 – khu A, Số nội bộ: 2060)./._

## Thông báo chiêu sinh thực hành 18 tháng lấy Chứng chỉ hành nghề đa khoa đối với bác sĩ

Để tài file thông báo chiêu sinh vui lòng bấm 
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh

## Thông báo tổ chức lại lớp thực hành Dược lâm sàng

Hiện tại, phòng tư vấn Dược lâm sàng của BV Nguyễn Tri Phương đã hoàn thành nâng cấp và sẵn sàng tiếp nhận học viên tham gia khóa đào tạo thực tế về Dược lâm sàng.
Khóa học có 03 moudle như sau
**Module 1 (1 tuần từ thứ 2 đến thứ 6, giờ hành chính)**
Tuần 1 cung cấp cho các học viên cơ hội tham quan, kiến tập và thực hiện các hoạt động dược lâm sàng cơ bản tại Bệnh viện Nguyễn Tri Phương.
**Mục tiêu tuần 1**
**Sau khi tham gia thực tập Tuần 1, học viên có thể:**
  * Trình bày được các hoạt động dược lâm sàng tại bệnh viện
  * Trình bày được vai trò của dược sĩ khi duyệt đơn cho bệnh nhân ngoại trú
  * Thực hiện được hoạt động tư vấn cho bệnh nhân ngoại trú
  * Thực hiện được hoạt động phân tích bệnh án nội trú
  * Trình bày được quy trình, kinh nghiệm và các nguồn tài liệu phục vụ cho hoạt động thông tin thuốc
  * Trình bày được quy trình và kinh nghiệm khi quản lý phản ứng có hại tại bệnh viện
  * Trình bày được quy trình và kinh nghiệm triển khai hoạt động dược lâm sàng khi đi bệnh phòng và hội chẩn cùng bác sĩ. 


**Module 2 (1 tuần từ thứ 2 đến thứ 6, giờ hành chính)**
Tuần 2 cung cấp cho các học viên cơ hội tham quan, kiến tập và thực hiện các hoạt động cảnh giác dược tại Bệnh viện Nguyễn Tri Phương.
**Mục tiêu tuần 2**
Sau khi tham gia thực tập Tuần 1, học viên có thể:
  * Diễn giải được các dấu hiệu lâm sàng và cận lâm sàng
  * Xử lý được các tình huống dị ứng liên quan kháng sinh, hội chứng người đỏ, suy thận, tăng thải thận, ADR trên huyết học do thuốc
  * Trình bày được quy trình và kinh nghiệm triển khai hoạt động dược lâm sàng tại phòng tư vấn và khi đi bệnh phòng và hội chẩn cùng bác sĩ. 


**Module 3 (1 tuần từ thứ 2 đến thứ 6, giờ hành chính)**
Tuần 3 cung cấp cho các học viên cơ hội tham quan, kiến tập và thực hiện các hoạt động quản lý kháng sinh tại Bệnh viện Nguyễn Tri Phương.
**Mục tiêu tuần 3**
Sau khi tham gia thực tập Tuần 3, học viên có thể:
  * Trình bày được các kinh nghiệm triển khai chương trình quản lý kháng sinh tại bệnh viện
  * Thực hiện được tư vấn sử dụng kháng sinh vancomycin và colistin
  * Thực hiện được tư vấn sử dụng kháng sinh điều trị nhiễm khuẩn Gram âm. Gram dương
  * Xử lý được các tình huống ADR liên quan kháng sinh
  * Trình bày được quy trình và kinh nghiệm triển khai hoạt động dược lâm sàng tại phòng tư vấn và khi đi bệnh phòng và hội chẩn cùng bác sĩ. 


Mỗi tuần - chỉ tối đa 02 học viên, vì vậy học viên cần đăng ký trước để có thể sắp xếp lịch học.
**Thông tin hướng dẫn đăng ký và sắp xếp lịch học vui lòng liên hệ:**
  * CN Vũ Minh Tuấn: 0907.1010.25
  * CN Dương Trần Cát Uyên: 0969.011.426



## Thông báo ngưng tiếp nhận lớp thực hành Dược lâm sàng

Hiện tại, BV Nguyễn Tri Phương đã nhận số lượng học viên đủ cho các khóa học thực tế về Dược lâm sàng đến hết tháng 05/2021. Xin trân trọng cảm ơn sự tín nhiệm của các quý học viên.
Vì thời gian đến sẽ phải sửa chữa nâng cấp phòng hoạt động Dược lâm sàng nên BV sẽ phải tạm ngưng nhận học viên đối với khóa học thực tập thực tế Dược lâm sàng do BV tổ chức.
Thông báo này có giá trị áp dụng từ ngày 01/6/2021 cho đến khi có thông báo mới.
BV rất mong nhận được thông cảm vì sự bất tiện này!

## Tổ chức lớp học 'Tâm thế nhà lãnh đạo 4.0' cho cán bộ quản lý của Bệnh viện

Bệnh viện đã hân hạnh được chào đón anh Trương Minh Tứ, Trưởng Đại diện Ericsson Việt Nam là giảng viên trong buổi học đầu tiên
Những bài giảng được trích lọc từ cuốn "Đắc nhân tâm" của Dale Carnegie, đồng thời tác giả là Trainer của Trường Doanh nhân Đắc Nhân Tâm.
Nhiều trải nghiệm, chia sẻ quý báu cũng như phản hồi tích cực từ người học đã được ghi nhận trong buổi học đầu tiên.
Trân trọng cảm ơn Boehringer đã đồng hành cũng Bệnh viện trong hoạt động ý nghĩa này và tin rằng những buổi học tiếp theo sẽ còn đem lại nhiều điều bổ ích - thú vị cho các cán bộ quản lý của Bệnh viện.
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh

## Thông báo tạm ngưng nhận hồ sơ thực hành lấy chứng chỉ hành nghề

Hiện nay số lượt đăng ký thực hành đào tạo lấy chứng chỉ hành nghề (bác sĩ, điều dưỡng, kỹ thuật viên) tại BV Nguyễn Tri Phương đã khá nhiều, BV vẫn đang tiếp tục sắp xếp người hướng dẫn cũng như cơ sở thực tập phù hợp đồng thời đảm bảo với quy định giãn cách cần thiết phòng chống dịch Covid-19.
Với những học viên đang tham gia thực tập, BV nhắc nhở và yêu cầu luôn thực hiện nghiêm túc:
  1. Tất cả học viên thực hiện khai báo y tế liên tục và trung thực, đeo khẩu trang, đeo bảng tên, rửa tay thường xuyên và thực hiện những phòng ngừa chuẩn tại môi trường bệnh viện. Mỗi học viên đều có cài phần mềm NCOVI và BLUEZONE trong điện thoại cá nhân. 
  2. Trong quá trình thực tập tại Bệnh viện, học viên chỉ tập trung thực hành tại khoa, phòng được phân công; không tụ tập ở các hành lang và không di chuyển sang các khu vực khác trong Bệnh viện trừ khi tham gia chuyển bệnh hoặc hoạt động chuyên môn theo yêu cầu; không đi ra ngoài Bệnh viện trong giờ thực tập tại Bệnh viện.
  3. Học viên thực hiện nghiêm túc về vấn đề quyền phát ngôn trong Bệnh viện, không đăng tải trên các mạng xã hội những thông tin chưa được Bệnh viện xét duyệt về vấn đề phòng chống dịch COVID-19 tại Bệnh viện.
  4. Học viên chủ động thông báo cho Ban đào tạo biết bất cứ khi nào có triệu chứng nghi ngờ (ho, sốt, khó thở và đặc biệt đột ngột mất vị giác, mất khứu giác...) cũng như chủ động ngưng thực tập có báo cáo khi cần thiết.


Đồng thời Ban đào tạo BV Nguyễn Tri Phương kính báo sẽ tạm ngưng nhận hồ sơ mới, dự kiến là trong tháng 06/2021, hoặc cho đến khi có thông báo khác.
Xin cảm ơn sự tin tưởng của quý học viên đối với BV Nguyễn Tri Phương trong công tác đào tạo vừa qua và trân trọng kính chào./.

## ️ Tâm thế nhà lãnh đạo 4.0


## Đào tạo cấp thời gian thực hành đối với Điều dưỡng, Kỹ thuật viên, Nữ hộ sinh

**1. Mục tiêu lớp học:**
- Đào tạo thực hành trong 09 tháng cho các điều dưỡng, nữ hộ sinh, kỹ thuật viên nhằm đạt được yêu cầu về năng lực chuyên môn và đạo đức nghề nghiệp để tham gia hành nghề trong lĩnh vực đăng ký
- Xác nhận thực hành cho các điều dưỡng, nữ hộ sinh, kỹ thuật viên trong lĩnh vực đăng ký để bổ sung hồ sơ xin cấp chứng chỉ hành nghề theo quy định.
**2. Đối tượng:**
  * Điều dưỡng đa khoa
  * Nữ hộ sinh
  * Kỹ thuật viên xét nghiệm, kỹ thuật viên chẩn đoán hình ảnh, kỹ thuật viên phục hồi chức năng


**3. Chương trình đào tạo:** Nội dung đào tạo bao gồm 09 tháng thực theo chương trình cụ thể của từng đối tượng
**4. Thời gian học:** 09 tháng kể từ khi hoàn tất các hồ sơ đăng ký, hình thức xét tuyển liên tục cho đến khi đủ chỉ tiêu.
**5. Địa điểm học:** BV Nguyễn Tri Phương, 468 Nguyễn Trãi, Phường 8, Quận 5, Tp.HCM
**6. Đăng ký:** học viên chuẩn bị các hồ sơ như sau:
**-** Bản sao bằng tốt nghiệp có công chứng trong vòng 06 tháng (01 bản).
**-** Bản sao CMND/CCCD có công chứng.trong vòng 06 tháng (01 bản)
- 02 hình 3x4cm chụp trong vòng 06 tháng
- Đơn xin thực hành (theo [file đính kèm](https://drive.google.com/file/d/18QPPwR3vxckSrArFk1tmtfG5fi00U8Fe/view?usp=sharing))
- Giấy khám sức khỏe theo thông tư 14 xác nhận đủ điều kiện sức khỏe tham gia học tập
* Hồ sơ nộp trong giờ hành chính, tại phòng Quản lý chất lượng - lầu 1 khu A
**7. Kinh phí:** có 02 hình thức thu kinh phí
a. Thu phí đào tạo theo tháng
  * Điều dưỡng: 2.000.000đ/tháng
  * Nữ hộ sinh: 2.000.000đ/tháng
  * Kỹ thuật viên: 2.000.000đ/tháng


b. Đóng theo gói (đóng 01 lần trọn gói hoặc 02 lần vào đầu và giữa thời gian học)
  * Điều dưỡng: 10.000.000đ/ 09 tháng
  * Nữ hộ sinh: 10.000.000đ/ 09 tháng
  * Kỹ thuật viên: 10.000.000đ/ 09 tháng


c. Ưu đãi dành riêng cho đối tượng điều dưỡng (từ tháng 3/2021 cho đến khi có thông báo mới)
  * Cam kết thực hành thêm 03 tháng tại BV Nguyễn Tri Phương (tức là thời gian ký hợp đồng đào tạo là 12 tháng thay vì 09 tháng)
  * Đóng tiền toàn khóa là 5.000.000đ/ toàn khóa


_* Lưu ý:_
-  _Học viên khi đến tham dự phải có đồng phục chuyên môn. Học viên tự lo chi phí ăn, ở, đi lại và các chi phí khác trong thời gian học tập theo quy định hiện hành._
_- Học viên phải chấp hành các quy chế đào tạo của BV, trong trường hợp không đảm bảo quy định BV sẽ ngưng đào tạo và không hoàn trả học phí đã đóng._
Để có thêm thông tin hướng dẫn - vui lòng gọi đến số điện thoại tổng đài (028) 73077307 - số nội bộ 2060 để xin tư vấn về đào tạo cấp thời gian thực hành

## THÔNG BÁO TỔ CHỨC ĐÀO TẠO LIÊN TỤC CHẨN ĐOÁN HÌNH ẢNH HỆ THẦN KINH

Bệnh viện Nguyễn Tri Phương thông báo kế hoạch đào tạo về Chẩn Đoán Hình Ảnh như sau:
Thời gian: 8:00-12h30 ngày 30/11/2019
Địa điểm: Hội trường A, lầu 5, thành phố Hồ Chí Minh
**1. Chương trình cụ thể**
**TH****Ờ****I GIAN** |  **NỘI DUNG**  
---|---  
08:15- 08:45 |  Đón tiếp Đại biểu **_Ban tổ chức_**  
08:45 - 09:00 |  Khai Mạc chương trình đào tạo liên tục thần kinh học lâm sàng lần II **_PGS.TS. Nguyễn Thi Hùng_**  
**09:00 - 12:15** |  **Thứ 7, ngày 30/11/2019 Diễn giả: GS. Jacques Clarisse (CH Pháp)**  
09:00 – 09:30 |  MRI NÃO BỘ: Các tiến bộ của chuỗi xung T2* EPI  
09:30 – 10:30 |  MRI TỦY SỐNG: chọn các chuỗi xung thích hợp, các bệnh lý thường gặp  
10:30 – 10:45 |  Giải lao  
10:45 - 11:15 |  MRI CỘT SỐNG CỔ: chọn các chuỗi xung thích hợp, các bệnh lý thường gặp  
11:15 – 12:00 |  MRI CỘT SỐNG THẮT LƯNG: chọn các chuỗi xung thích hợp, các bệnh lý thường gặp  
12:00 – 12:15 |  **Thảo luận và Bế Mạc**  
12:15 - 12:30 |  **Phát tặng sách “Hình ảnh học sọ não” của GS. Jacques Clarisse**  
**2. Kinh phí tham gia:** 200.000đ/người (bao gồm chi phí cấp chứng nhận, tea break)
**3. Các hình thức đăng ký và đóng phí**
  1. Đăng ký trực tiếp tại phòng Quản lý chất lượng, đóng phí tham gia tại phòng Tài chính kế toán
  2. Đăng ký trực tuyến thông qua mail qlcl.bvntp@gmail.com bao gồm họ tên, năm sinh và đơn vị công tác, chuyển khoản ngân hàng: 
     * Số tài khoản: 0071001193993 – Ngân hàng Ngoại Thương Việt Nam (VietcomBank), chi nhánh Hùng Vương – Tp. Hồ Chí Minh
     * Nội dung chuyển khoản: "Họ tên" "năm sinh" "đơn vị công tác" "phi tham gia CDHA he than kinh"
  3. Hạn cuối đăng ký: 27/11/2019



## TỔ CHỨC ĐÀO TẠO LIÊN TỤC 'KỸ NĂNG CÔNG BỐ KHOA HỌC'

Thời gian: 8:30-16h30 ngày 04/01/2020
Địa điểm: Hội trường A, lầu 5, khu A - 468 Nguyễn Trãi, Q5, thành phố Hồ Chí Minh
Thành phần tham gia:
  1. Danh sách đăng ký từ Hội đau Thành phố Hồ Chí Minh
  2. Danh sách tham gia tự đăng ký


Ban giảng huấn: Giáo sư Nguyễn Văn Tuấn
Phó Giáo sư Nguyễn Thi Hùng

## CHƯƠNG TRÌNH THỰC TẬP VỀ DƯỢC LÂM SÀNG

**Lợi ích khi tham gia chương trình**
  * Rèn luyện kỹ năng thực hành trực tiếp 
  * Xây dựng mối quan hệ nghề nghiệp 
  * Tiếp nhận kinh nghiệm, tài liệu hữu ích
  * Có chứng nhận 


**Nội dung: xem thêm chi tiết** được trình bày ở Bảng 1 bên dưới.
(Lưu ý: Nội dung chương trình có thể điều chỉnh, thay đổi để phù hợp với nhu cầu của học viên.)
**Module 1 (1 tuần từ thứ 2 đến thứ 6, giờ hành chính)**
Tuần 1 cung cấp cho các học viên cơ hội tham quan, kiến tập và thực hiện các hoạt động dược lâm sàng cơ bản tại Bệnh viện Nguyễn Tri Phương. 
**Mục tiêu tuần 1**
**Sau khi tham gia thực tập Tuần 1, học viên có thể:**
  * Trình bày được các hoạt động dược lâm sàng tại bệnh viện 
  * Trình bày được vai trò của dược sĩ khi duyệt đơn cho bệnh nhân ngoại trú
  * Thực hiện được hoạt động tư vấn cho bệnh nhân ngoại trú
  * Thực hiện được hoạt động phân tích bệnh án nội trú
  * Trình bày được quy trình, kinh nghiệm và các nguồn tài liệu phục vụ cho hoạt động thông tin thuốc
  * Trình bày được quy trình và kinh nghiệm khi quản lý phản ứng có hại tại bệnh viện
  * Trình bày được quy trình và kinh nghiệm triển khai hoạt động dược lâm sàng khi đi bệnh phòng và hội chẩn cùng bác sĩ. 


**Module 2 (1 tuần từ thứ 2 đến thứ 6, giờ hành chính)**
Tuần 2 cung cấp cho các học viên cơ hội tham quan, kiến tập và thực hiện các hoạt động cảnh giác dược tại Bệnh viện Nguyễn Tri Phương. 
**Mục tiêu tuần 2**
Sau khi tham gia thực tập Tuần 1, học viên có thể:
  * Diễn giải được các dấu hiệu lâm sàng và cận lâm sàng 
  * Xử lý được các tình huống dị ứng liên quan kháng sinh, hội chứng người đỏ, suy thận, tăng thải thận, ADR trên huyết học do thuốc
  * Trình bày được quy trình và kinh nghiệm triển khai hoạt động dược lâm sàng tại phòng tư vấn và khi đi bệnh phòng và hội chẩn cùng bác sĩ. 


**Module 3 (1 tuần từ thứ 2 đến thứ 6, giờ hành chính)**
Tuần 3 cung cấp cho các học viên cơ hội tham quan, kiến tập và thực hiện các hoạt động quản lý kháng sinh tại Bệnh viện Nguyễn Tri Phương. 
**Mục tiêu tuần 3**
Sau khi tham gia thực tập Tuần 3, học viên có thể:
  * Trình bày được các kinh nghiệm triển khai chương trình quản lý kháng sinh tại bệnh viện
  * Thực hiện được tư vấn sử dụng kháng sinh vancomycin và colistin 
  * Thực hiện được tư vấn sử dụng kháng sinh điều trị nhiễm khuẩn Gram âm. Gram dương
  * Xử lý được các tình huống ADR liên quan kháng sinh 
  * Trình bày được quy trình và kinh nghiệm triển khai hoạt động dược lâm sàng tại phòng tư vấn và khi đi bệnh phòng và hội chẩn cùng bác sĩ. 


**Bảng 1. Nội dung của các module đào tạo dược lâm sàng tại BV Nguyễn Tri Phương**
NỘI DUNG  
---  
**TUẦN 1** Tổng quan Hoạt động DLS |  Tìm hiểu các hoạt động DLS tại bệnh viện  
Tham quan hoạt động DLS tại phòng phát thuốc BHYT  
Kiến tập hoạt động tư vấn thuốc cho bệnh nhân ngoại trú  
Tìm hiểu quy trình phân tích bệnh án nội trú  
Tìm hiểu quy trình hoạt động thông tin thuốc  
Tìm hiểu quy trình quản lý phản ứng có hại của thuố  
Kiến tập hoạt động DLS tại bệnh phòng  
Tham gia hội chẩn trên khoa lâm sàng  
**TUẦN 2** **Cảnh giác dược** |  Kỹ năng đánh giá các dấu hiệu lâm sàng và chỉ số cận lâm sàng  
Dị ứng kháng sinh từ góc nhìn can thiệp dược  
Hội chứng người đỏ khi sử dụng Vancomycin  
Suy thận trên bệnh nhân dùng colistin và vancomycin   
ADR trên huyết học  
Tăng thanh thải thận và việc dùng thuốc  
Kiến tập hoạt động DLS tại phòng tư vấn và bệnh phòng  
Tham gia hội chẩn trên khoa lâm sàng  
**TUẦN 3** Kháng sinh |  Chương trình quản lý kháng sinh tại bệnh viện  
Hướng dẫn dùng vancomycin và colistin - ca lâm sàng thực tế  
Ca lâm sàng nhiễm khuẩn Gram âm, Gram dương  
Ca lâm sàng ADR liên quan kháng sinh  
Kiến tập hoạt động DLS tại phòng tư vấn và bệnh phòng  
Tham gia hội chẩn trên khoa lâm sàng  
**Kinh phí: 1.000.000đ/tuần/học viên**(Học viên tự túc chi phí ăn, ở. Chi phí chưa bao gồm tài liệu)
**Cách thức đăng ký:** chiêu sinh liên tục với lựa chọn thời gian theo nhu cầu từng học viên
**Kết thúc khóa** có cấp chứng nhận thời gian tham gia 
**Liên hệ:**
- Phòng Quản lý chất lượng, lầu 1, khu A, bệnh viện Nguyễn Tri Phương
- Cần thêm thông tin xin thể liên hệ: BS Minh - 0983848985

## KHAI GIẢNG LỚP QUẢN LÝ NHÀ NƯỚC NGẠCH CHUYÊN VIÊN 

Mục đích của lớp học là “nhằm trang bị, cập nhật và củng cố bổ sung những kiến thức cần thiết về quản lý nhà nước và kỹ năng thực thi công việc, đồng thời tăng cường ý thức phục vụ nhân dân nhằm nâng cao năng lực công tác của công chức, viên chức trong thực hiện nhiệm vụ, quyền hạn và trách nhiệm được giao, góp phần xây dựng nền hành chính chuyên nghiệp, hiện đại, đáp ứng yêu cầu cải cách hành chính, xây dựng Nhà nước pháp quyền xã hội chủ nghĩa và hội nhập quốc tế. Đồng thời, tạo một bước căn bản nâng cao về chất cho hoạt động bồi dưỡng, phát triển năng lực làm việc của người học, từng bước thay đổi về tinh thần, thái độ phục vụ, bảo đảm chỉ số hài lòng của nhân dân đối với công chức và công sở” góp phần nâng cao chất lượng nguồn nhân lực tại Bệnh viện nói riêng và của ngành Y tế thành phố nói chung.
Tham dự lễ khai giảng lớp học có đông đủ các học viên tham gia đồng thời có sự quan tâm của Đảng ủy bệnh viện với sự có mặt của đồng chí Nguyễn Trung Thành - Phó bí thư Đảng ủy. Đồng chí Thành thay mặt Đảng ủy bệnh viện thể hiện rõ sự quan tâm của lãnh đạo đối với công tác bồi dưỡng cán bộ, coi đây là trọng tâm để tạo nên điểm mạnh trong thay đổi chất lượng hoạt động và chất lượng dịch vụ tại bệnh viện, đồng thời gửi gắm mong muốn lớp học sẽ diễn ra thành công tốt đẹp với sự thu hoạch phong phú từ mỗi học viên.

## PHẪU THUẬT THAY KHỚP HÁNG ĐƯỜNG TRÊN (CÓ MỔ XÁC)

  1. **_Đơn vị phụ trách tổ chức:_**
     * Khoa Chấn thương chỉnh hình
     * Phụ trách chính: Ts Bs Tăng Hà Nam Anh
  2. **_Đối tượng Bác sĩ:_**
     * Bác sĩ chuyên khoa chấn thương chỉnh hình toàn quốc
  3. **_Thời gian:_**
     * 19-20/12/2019
     * 12 tiết lý thuyết
     * 16 tiết thực hành (Tham gia 01 ngày 19/12/2019: 04 tiết lý thuyết và 8 tiết thực hành)


**_Địa điểm:_**
  * Trung Tâm Phẫu Thuật Thực Nghiện ĐHYD TpHCM
  * Phòng huấn luyện – khoa chấn thương chỉnh hình, BVNTP
  * Khoa phẫu thuật gây mê hồi sức, BVNTP


**_Thành phần giảng viên:_**
  * TS . BS Tăng Hà Nam Anh, Trưởng khoa CTCH
  * Ths Bs Võ Châu Duyên, Phó khoa CTCH
  * Ths Bs Trần Anh Vũ, BS điều trị, giảng viên
  * Bs CK1 Phạm Thế Hiển, Bs Điều Trị, giảng viên
  * _Giảng Viên mời:_
    * Kris Van Thuyne


**_Nội dung giảng dạy_**
**SUPERPATH TECHNIQUE COURSE**
**FROM CADAVERIC PRACTICE TO LIVE SURGERY**
**19 - 20 /12 /2019**
**_DAY 1:_****_19/12/2019_**
  * **7:30:AM - Training Center of Experimental Surgery - Ho Chi Minh City Medicine and Pharmacy University**


  1. The SuperPATH - equipment details and function: Kris Van Thuyne
  2. Preoperation to get full function, faster by SuperPATH : dr Hiển
  3. The SuperPATH technique: 
    1. Patient position – your assistant positions: 
    2. Incision and land mark
    3. Femoral side technique
    4. Acetabula side technique
    5. Reduction technique
  4. The SuperPATH: tip and tricks – Dr Nam Anh


  * Lunch time
  * **13:00 PM - cadaveric surgery**
  * 3 table, 6 hips
  * 15-20 participants
  * Dr Nam Anh – Foreign Dr: introduction 
    * Table 1: Dr Nam Anh – Dr Duyên
    * Table 2: Dr Tuấn - Dr Hiển
    * Table 3: Dr Vũ – Dr Ngọc


**_DAY 2:_****_20/12/2019_ Nguyen Tri Phuong Hospital**
  * 8:00 : The live surgery – 1 CASES
  * Q&A
  * 10:00 AM : 10 years orthopaedic department


**Học phí và đăng ký:**
  * Thu phí CME: 1.500.000/ người: nếu học 1 buổi ngày 20/12/2019 (loại 1)
  * Thu Phí CME: 5.000.000 nếu học 2 buổi gồm ngày 19-20/12/2019, có thực hành phẫu thuật trên xác tươi (loại 2).


(Bao gồm phí cấp CME, tea break, chi phí hội trường và phẫu thuật truyền hình trực tiếp)
**_Hồ sơ đăng ký_**
  * Đơn đăng ký (tải về [tại đây](https://drive.google.com/file/d/1B8KHi9mHFiu64zXk1mQqOT6S4yg2wQU4/view))
  * Photo (có công chứng) bằng BS đa khoa
  * 02 ảnh 3x4 có khi họ tên ngày tháng năm sinh mặt sau


**_Thủ tục đăng ký_**
  * Nộp hồ sơ trực tiếp tại phòng Quản lý chất lượng – lầu 1 khu A bệnh viện Nguyễn Tri Phương
  * Nộp tiền (sau khi đã nộp hồ sơ đầy đủ): 
    * Trực tiếp tại phòng Tài chính kế toán hoặc
    * Chuyển khoản: 
      * Số tài khoản: 0071001193993 – Ngân hàng Ngoại Thương Việt Nam (VietcomBank), chi nhánh Hùng Vương – Tp. Hồ Chí Minh.
      * _Nội dung chuyển khoản:_ “tên đơn vị công tác” “họ tên học viên” “năm sinh” “Hoc phi thay khop hang thang 12” “loai 1/ loai 2” (xem phần Kinh phí về từng loại học phí)


**_Thời gian đăng ký_**
  * Nhận hồ sơ liên tục từ ngày ra thông báo đến 13/12/2019.



## LỚP ĐÀO TẠO VỀ PHƯƠNG PHÁP LÃNH ĐẠO, XÂY DỰNG NHÓM LÀM VIỆC

Trong chương trình hợp tác năm 2019 giữa tổ chức REI và Bệnh viện Nguyễn Tri Phương, chúng tôi trân trọng giới thiệu chương trình đào tạo tại Bệnh viện Nguyễn Tri Phương trong buổi chiều ngày **_20/11/2019._**
Thành phần ban giảng huấn gồm có:
  1. Bà **Madero, Merrily Dente** – Chuyên gia lãnh đạo, quản lý và xử lý các vấn đề phức tạp của tổ chức, doanh nghiệp.
  2. Tiến sĩ **Meredith, Cheryl Lynn** – Chuyên gia về quản lý và tổ chức, Giám đốc điều hành nhân sự cấp cao.


Chương trình làm việc dự kiến như sau:
**_"Be the Leader that Others will Follow"_** This class provides practical guidance on many diverse and effective leadership styles.It will also provide application to use Situational Leadership in many different work environments, situations and with a variety of people.Using classroom activities, student will be able to practice Situational Leadership principles. |  14:00  
---|---  
**_"Building Effective Teams"_** In this session participants will understand the importance of team relationships in organizational success. In classroom activities and case studies, participants will learn how to diagnose team problems and build teams that are engaged, accountable and focused on results. |  15:30  
**Đối tượng hướng đến**
  1. Lãnh đạo khoa, phòng; Điều dưỡng trưởng
  2. Lãnh đạo các đoàn thể
  3. Trưởng nhóm


**Kinh phí**
  * Phí nhận giấy chứng nhận và tea break: 100.000đ/người


**Thủ tục đăng ký**
  * Đăng ký trực tiếp tại phòng Quản lý Chất lượng, lầu 1 khu A bệnh viện Nguyễn Tri Phương (CN Tuấn 0907101025 CN Uyên 0969011426)
  * Hoặc gửi danh sách tham gia qua mail: qlcl.bvntp@gmail.com trong đó có các thông tin: Họ tên, ngày thàng năm sinh và đơn vị công tác


**Thủ tục đóng phí tham gia**
  1. Trực tiếp tại phòng Tài chính kế toán hoặc
  2. Chuyển khoản: 
    1. Số tài khoản: 0071001193993 – Ngân hàng Ngoại Thương Việt Nam (VietcomBank), chi nhánh Hùng Vương – Tp. Hồ Chí Minh.
    2. _Nội dung chuyển khoản:_ “tên đơn vị công tác” “họ tên học viên” “năm sinh” “dao tao phuong phap lanh dao”.



## THÔNG BÁO THAY ĐỔI NGÀY KHAI GIẢNG LỚP 'THẬN HỌC - LỌC MÁU 2020'

Do tình hình công tác chuyên môn đột suất cũng như công tác phòng chống dịch Covid-19.
Bệnh viện Nguyễn Tri Phương thông báo đến các học viên lớp Thận Học Lọc Máu 2020 về thời gian khai giảng lớp sẽ được thay đổi như sau:
Ngày khai giảng lớp sẽ chuyển sang ngày: 19/08/2020 (thứ 4).
  * Thời gian: 13 giờ 30 đến 16 giờ.
  * Địa điểm: hội trường A1, lầu 5, Bệnh viện Nguyễn Tri Phương.


Các học viên tham gia khóa học vui lòng gửi xe tại bãi xe khu E, Đường Nguyễn Tri Phương./.
Mọi thắc mắc cần giải đáp, vui lòng gọi: 0907101025 (Tuấn)

## Thông báo chiêu sinh lớp NCKH 2021

Nhằm nâng cao kiến thức, kỹ năng nghiên cứu khoa học cho đối tượng nhân viên y tế trong và ngoài bệnh viện có nhu cầu. Nay bệnh viện Nguyễn Tri Phương mở lớp huấn luyện về **“Phương pháp Nghiên cứu khoa học”.**
File đăng ký xin tải [tại đây](https://drive.google.com/file/d/1P4tuYy9KU5r-RSXPI605AvPgdb7cClU4/view?usp=sharing)./.

## Đào tạo cấp thời gian thực hành đối với Bác sĩ

**1. Mục tiêu lớp học:**
- Đào tạo thực hành trong 18 tháng cho các bác sĩ nhằm đạt được yêu cầu về năng lực chuyên môn và đạo đức nghề nghiệp để tham gia hành nghề khám chữa bệnh trong lĩnh vực đăng ký
- Xác nhận thực hành cho các bác sĩ trong lĩnh vực đăng ký để bổ sung hồ sơ xin cấp chứng chỉ hành nghề theo quy định.
**2. Đối tượng:** Bác sĩ đa khoa muốn xác nhận thực hành để xin cấp CCHN sau đây:
  * Khám chữa bệnh Nội khoa
  * Khám chữa bệnh chuyên khoa Ngoại
  * Khám chữa bệnh chuyên khoa Sản phụ khoa


**3. Chương trình đào tạo:** Nội dung đào tạo bao gồm 18 tháng thực hành chuyên khoa theo chương trình cụ thể của từng chuyên khoa
**4. Thời gian học:** 18 tháng kể từ khi hoàn tất các hồ sơ đăng ký, hình thức xét tuyển liên tục cho đến khi đủ chỉ tiêu.
**5. Địa điểm học:** BV Nguyễn Tri Phương, 468 Nguyễn Trãi, Phường 8, Quận 5, Tp.HCM
**6. Đăng ký:** học viên chuẩn bị các hồ sơ như sau:
**-** Bản sao bằng tốt nghiệp đại học có công chứng trong vòng 06 tháng (01 bản).
**-** Bản sao CMND/CCCD có công chứng.trong vòng 06 tháng (01 bản)
- 02 hình 3x4cm chụp trong vòng 06 tháng
- Đơn xin thực hành (theo [file đính kèm](https://drive.google.com/file/d/18QPPwR3vxckSrArFk1tmtfG5fi00U8Fe/view?usp=sharing))
- Giấy khám sức khỏe theo thông tư 14 xác nhận đủ điều kiện sức khỏe tham gia học tập
* Hồ sơ nộp trong giờ hành chính, tại phòng Quản lý chất lượng - lầu 1 khu A
**7. Kinh phí:** có 02 hình thức thu kinh phí
a. Thu phí đào tạo theo tháng
  * Nội khoa: 2.500.000đ/tháng
  * Ngoại khoa: 3.500.000đ/tháng
  * Sản phụ khoa: 3.500.000đ/tháng


b. Đóng theo gói (đóng 01 lần trọn gói hoặc 02 lần vào đầu và giữa thời gian học)
  * Nội khoa: 36.000.000đ/18 tháng
  * Ngoại khoa: 48.000.000đ/18 tháng
  * Sản phụ khoa: 48.000.000đ/tháng


_* Lưu ý:_
_Học viên khi đến tham dự phải có đồng phục chuyên môn. Học viên tự lo chi phí ăn, ở, đi lại và các chi phí khác trong thời gian học tập theo quy định hiện hành._
_- Học viên phải chấp hành các quy chế đào tạo của BV, trong trường hợp không đảm bảo quy định BV sẽ ngưng đào tạo và không hoàn trả học phí đã đóng._
Để có thêm thông tin hướng dẫn - vui lòng gọi đến số điện thoại tổng đài (028) 73077307 - số nội bộ 2060 để xin tư vấn về đào tạo cấp thời gian thực hành

## CHƯƠNG TRÌNH ĐÀO TẠO Y KHOA LIÊN TỤC ĐỘNG KINH LÂM SÀNG

# Mục tiêu khóa học
Khóa học cung cấp những kiến thức cơ bản và cập nhật trong chẩn đoán và điều trị động kinh. Giúp học viên có thể áp dụng trong thực hành lâm sàng hàng ngày.
# Đối tượng tham dự
BS chuyên khoa Thần kinh
BS đa khoa có định hướng về chuyên khoa Thần kinh
Số lượng học viên dự kiến: 70
# Địa điểm tổ chức
BV Nguyễn Tri Phương, hội trường A (lầu 5, khu A)
# Thời gian
6-7/4/2019
**CME:** có cấp CME tương đương 12 tiết (mã đào tạo liên tục do Bộ Y tế cấp phép)
# Ban Giảng huấn
  * Quốc tế: ASEPA
  * Địa phương: BV Nguyễn Tri Phương phối hợp cùng Hội Thần kinh TP.HCM


# Chương trình dự kiến
**Saturday, April 6** |  **Topic** |  **Speaker**  
---|---|---  
0730 – 0830 |  Đăng ký (Registration)  
0830 – 0845 |  Phát biểu khai mạc (Opening speech) Giới thiệu khóa học (Introduction of course format) |  **John Dunne** Giáo sư, Khoa Y, Đại học Tây Úc Chủ tịch, Viện Động kinh Châu Á, Liên hội chống động kinh quốc tế (ILAE) Tổng thư ký, Uỷ ban Châu Á Thái Bình Dương, ILAE Đại biểu Úc châu, Liên đoàn quốc tế về Sinh lý thần kinh lâm sàng Chủ tịch, Uỷ ban Điện não và Sinh lý thần kinh lâm sàng, Hội Thần kinh Úc và New Zealand  
0845 – 0900 |  Pre test  
0900 – 1000 |  **Có phải bệnh động kinh không? (Is it epilepsy?)** |  **CT Tan** Chuyên ngành Thần kinh, Đại học Malaya tốt nghiệp đại học tại đại học Melbourne. Ông được đào tạo Thần kinh tại Viện Thần kinh học, London, Vương quốc Anh.  
1000 – 1030 |  Nghỉ giải lao (Tea break)  
1030 – 1130 |  **Phân loại động kinh (What type of epilepsy is it and does it matter?)** |  **CY Fong** Khoa Nhi, Đại học Trung tâm y khoa Malaysia, 59100 Kuala Lumpur, MALAYSIA  
1130 – 1230 |  **Điều trị có cần thiết không? Và chọn lựa đầu tay (Is treatment needed, and initial treatment choices)** |  John Dunne  
1230 – 1330 |  Nghỉ trưa (Lunch)  
1330 – 1430 |  **Vấn đề phụ nữ: thai kỳ, ngừa thai, cho con bú (Women’s issues:** Pregnancy, contraception, breastfeeding) |  **M Wijayath** Chuyên gia Thần kinh/ Động kinh, Bệnh viện Westmead, NSW, Australia Chuyên gia Thần kinh/ Động kinh, Bệnh viện Nepean, Kingswood, NSW  
1430 – 1530 |  **Dược động học – tại sao phải quan tâm (Pharmacokinetics - why it matters?)** |  **Patrick Carney** • Cao đẳng hoàng gia Úc về các nhà lâm sàng • Tổ chức các nhà thần kinh học Úc và New Zealand • Tổ chức động kinh của Úc (thư kí 2016-18) • Tổ chức động kinh Mỹ  
1530 – 1600 |  Nghỉ giải lao (Tea Break)  
1600 |  Câu hỏi/ Trường hợp lâm sàng từ khán giả (Questions/Cases from audience)  
**Sunday, April 7**  
0830 – 0930 |  **Cần làm gì khi vẫn còn cơn động kinh (What to do when seizures continue)** |  CT Tan  
0930 – 1030 |  **Trạng thái động kinh (Status epilepticus)** |  **Sasha Dionisio** Chuyên gia Động kinh và BS chuyên khoa thần kinh Founder of the Mater Advanced Epilepsy Unit, Brisbane  
1030 – 1130 |  Nghỉ giải lao (Tea break)  
1130 – 1230 |  **Những chẩn đoán không phải động kinh (Psychogenic-non-epileptic events)** |  **Hanka Laue-Gizzi** Nhà thần kinh học Nhà diễn thuyết liên kết với đại học NSW Bác sĩ y khoa (Đại học Martin Luther, Halle- Wittenberg, Đức)  
1230 – 1330 |  Nghỉ trưa (Lunch)  
1330 – 1430 |  **Cơn động kinh và hành vi (Seizures and behavioural challenges)** |  John Dunne  
1430 – 1445 |  Post test  
1445 – 1530 |  Câu hỏi/ Trường hợp lâm sàng từ khán giả (Questions/Cases from audience)  
1530 |  Kết thúc (Close)  
**ĐĂNG KÝ VÀ HỌC PHÍ**
**Hồ sơ đăng ký:**
  * 02 tấm hình 3*4 ( mặt sau ghi rõ họ tên, ngày tháng năm sinh)
  * Đơn đăng ký học theo mẫu
  * Bằng tốt nghiệp bác sĩ đa khoa (photo, không cần chứng thực)


**Thời gian và nơi nhận đơn:**
  * Đăng ký trực tiếp: hạn cuối 21/03/2019, thời gian làm việc trong giờ hành chính, đăng ký tại phòng Quản Lý Chất Lượng (lầu 1 khu A).
  * Đăng ký qua email : qlcl.bvntp@gmail.com

Stt |  Họ tên |  Cơ quan công tác (nếu có) |  Số điện thoại cá nhân  
---|---|---|---  
  * Mọi chi tiết thắc mắc xin vui lòng liên hệ: CN. Trương Thùy Trang, điện thoại: 0938 468 009


**Học phí tham gia:** 500.000đ/học viên (đóng trực tiếp tại lớp học)
Mẫu đơn đăng ký có thể tải về [tại đây](https://drive.google.com/open?id=1RLhPDyu16IeJ9jKyfWN3b1pBdl1_a8M2).

## Đào tạo liên tục 'Thay khớp háng đường trước trực tiếp'

  1. **_Đơn vị phụ trách tổ chức:_**
     * Khoa Chấn thương chỉnh hình
     * Phụ trách chính: Ts Bs Tăng Hà Nam Anh
  2. **_Đối tượng Bác sĩ:_**
     * Bác sĩ chuyên khoa chấn thương chỉnh hình toàn quốc
  3. **_Thời gian:_**
     * Một ngày từ 7h30 -16h30 ngày 28/11/2019
     * CME 4 tiết lý thuyết và 8 tiết thực hành
  4. **_Địa điểm:_**
     * Phòng huấn luyện – khoa chấn thương chỉnh hình
     * Phòng mổ kỹ thuật cao, khoa Phẫu thuật gây mê hồi sức
  5. **_Thành phần giảng viên:_**
     * TS . BS Tăng Hà Nam Anh, Trưởng khoa CTCH
     * Ths Bs Võ Châu Duyên, Phó khoa CTCH
     * Ths Bs Trần Anh Vũ, BS điều trị, giảng viên
     * Bs CK1 Phạm Thế Hiển, Bs Điều Trị, giảng viên
     * _Giảng Viên mời:_
       * TS BS Paweł Skowronek – Ba Lan, Trưởng khoa chấn thương chỉnh hình, Giám đốc y khoa, Đại học Kochanowski - Phần Lan
  6. **_Tài Liệu Giảng Dạy_**


  * **Minimally Invasive Surgery in Total Hip Arthroplasty** , Author(s): Joachim Pfeil (auth.), Prof. Dr. Joachim Pfeil, Prof. Dr. W.E. Siebert (eds.) Publisher: Springer-Verlag Berlin Heidelberg, Year: 2010, ISBN: 3642008968,9783642008962,9783642008979
  * **Essentials in Total Hip Arthroplasty** , Author(s): Javad Parvizi MD, Brian Klatt MD, Publisher: Slack Incorporated, Year: 2013, ISBN: 1556428707,9781556428708
  * **Complications after Primary Total Hip Arthroplasty: A Comprehensive Clinical Guide** , Author(s): Matthew P. Abdel, Craig J. Della Valle (eds.), Publisher: Springer International Publishing, Year: 2017, ISBN: 978-3-319-54911-8, 978-3-319-54913-2
  * **White Paper on Joint Replacement: Status of Hip and Knee Arthroplasty Care in Germany** , Author(s): Hans-Holger Bleß, Miriam Kip (eds.), Publisher: Springer-Verlag, Year: 2018, ISBN: 978-3-662-55917-8, 978-3-662-55918-5
  * **The adult hip: Hip arthroplasty surgery** , Author(s): John J. Callaghan, Aaron G. Rosenberg, Harry E. Rubash et al.Publisher: Lippincott Williams & Wilkins, Year: 2015,ISBN: 978-1451183696
  * **Hip Joint Restoration: Worldwide Advances in Arthroscopy, Arthroplasty, Osteotomy and Joint Preservation Surgery** , Author(s): Joseph C. McCarthy, Philip C. Noble, Richard N. Villar (eds.),Publisher: Springer-Verlag New York, Year: 2017, ISBN: 978-1-4614-0693-8, 978-1-4614-0694-5


  1. **_Hồ sơ đăng ký_**


  * Đơn đăng ký (có thể tải trực tiếp tại link bên dưới)
  * Photo (có công chứng) bằng BS đa khoa
  * 02 ảnh 3x4 có khi họ tên ngày tháng năm sinh mặt sau


  1. **_Thủ tục đăng ký_**


  * Nộp hồ sơ trực tiếp tại phòng Quản lý chất lượng – lầu 1 khu A bệnh viện Nguyễn Tri Phương
  * Nộp tiền (sau khi đã nộp hồ sơ đầy đủ): 1.500.000đ/người
    * Trực tiếp tại phòng Tài chính kế toán hoặc
    * Chuyển khoản:
      * Số tài khoản: 0071001193993 – Ngân hàng Ngoại Thương Việt Nam (VietcomBank), chi nhánh Hùng Vương – Tp. Hồ Chí Minh.
      * _Nội dung chuyển khoản:_ “tên đơn vị công tác” “họ tên học viên” “năm sinh” “Hoc phi thay khop hang thang 11”.


  1. **_Thời gian đăng ký_**


Nhận hồ sơ liên tục từ ngày ra thông báo đến 21/11/2019.
* Đơn đăng ký tải về [tại đây](https://drive.google.com/open?id=1B8KHi9mHFiu64zXk1mQqOT6S4yg2wQU4)./.

## NHẬN CME LỚP ĐÀO TẠO CHUYÊN ĐỀ CHẤT LƯỢNG NƯỚC CHẠY THẬN

Lớp học đã tổ chức thành công và đón tiếp hơn 100 học viên đến từ thành phố Hồ Chí Minh và các vùng lân cận
Nội dung các bài giảng có thể tải tại đây: [bài 1](https://drive.google.com/open?id=0B0XXxBQy3MzQSEdQWFR3ZzFtZWxnTVRkcWF3UGVyWnE1T01z), [bài 2](https://drive.google.com/open?id=0B0XXxBQy3MzQQTQwSnJfVDh3SGlwWmZ4eUFtN1hGNEZudDY4)
Chứng chỉ CME có thể nhận tại phòng Quản Lý Chất Lượng - lầu 1 khu A, BV Nguyễn Tri Phương.
Vui lòng liên hệ nếu cần thêm chi tiết hoặc cần hẹn trước: CN Minh Tuấn (02873077307- số nội bộ 20662) CN Cát Uyên (02873077307- số nội bộ 2060)

## THÔNG BÁO KHÓA HỌC 'THẬN HỌC - LỌC MÁU'

  * Căn cứ Thông báo chiêu sinh số 01/NTP-QLCL ngày 18 tháng 06 năm 2019 về việc chiêu sinh Lớp Đào tạo liên tục chuyên đề “Thận học – Lọc máu” của Bệnh viện Nguyễn Tri Phương;
  * Căn cứ vào lịch công tác của ban giảng huấn;
  * Theo lịch đã thông báo, lớp học sẽ được khai giảng vào ngày 10/7/2019 (Thứ tư). Tuy nhiên, do giảng viên bận lịch công tác nước ngoài đột xuất không sắp xếp được thời gian nên tạm thời chưa thể khai giảng Lớp Đào tạo liên tục chuyên đề “Thận học – Lọc máu” đúng thời gian dự kiến.


Bệnh viện Nguyễn Tri Phương thông báo dời lịch khai giảng như sau:
Thời gian : 13h30’ ngày 24/7/2019 (Thứ tư).
Địa điểm : Hội Trường A, Lầu 5 Bệnh viện Nguyễn Tri Phương
468 Nguyễn Trãi, Phường 8, Quận 5, Thành phố Hồ Chí Minh.
  * Liên hệ : Phòng Quản lý Chất lượng, Bệnh Viện Nguyễn Tri Phương
  * CN. Trương Thùy Trang, Điện thoại: 0938 468 009
  * NV. Vũ Minh Tuấn, Điện thoại: 0907 101 025 


(Vui lòng liên hệ giờ hành chánh từ thứ hai đến thứ sáu hàng tuần)
Thông báo có thể tải về [tại đây](https://drive.google.com/file/d/1HkTejq7M10mLbfLJdZ4AIF3_XJNhDeKy/view?usp=sharing)./.

## HỘI THẢO ĐÀO TẠO VỀ CHƯƠNG TRÌNH THỰC HÀNH LÂM SÀNG CHO BS MỚI TỐT NGHIỆP

Căn cứ theo nội dung hợp tác viện – trường giữa Bệnh viện Nguyễn Tri Phương và Đại học Tân Tạo (Long An);
Căn cứ đề xuất của Giáo sư Thạch Nguyễn, Phó hiệu trưởng Đại học Tân Tạo về việc tăng cường hợp tác trong việc đào tạo các bác sĩ (BS) mới tốt nghiệp, 
BV Nguyễn Tri Phương xây dựng kế hoạch tổ chức hội thảo về đào tạo tay nghề cho bác sĩ mới tốt nghiệp như sau:
  * Thảo luận về chương trình đào tạo thực hành lâm sàng cho BS nội tổng quát


Thời gian: 4,5/9/2019 từ 15:00-16:00, hội trường A
Thành phần bệnh viện tham gia: lãnh đạo khoa, phòng toàn bệnh viện và các nhân viên y tế có tham gia đào tạo thực hành lâm sàng, BS 18 tháng (danh sách cụ thể)
Thành phần khách mời: một số các bệnh viện lân cận có quan tâm đến việc đào tạo thực hành lâm sàng cho bác sĩ mới tốt nghiệp
Chủ tọa: GS Phạm Nguyễn Vinh
Báo cáo tham luận về tình hình đào tạo thực hành lâm sàng cho BS mới ra trường chuyên ngành Nội tổng quát với mô hình kết hợp ĐH Y Dược Tp.HCM tại BV Nguyễn Tri Phương: BS Đỗ Tuấn Linh, trưởng phòng KHTH
Nội dung hướng đến: Tạo ra những đồng thuận ban đầu về phương pháp đào tạo và chất lượng đào tạo cho các bác sĩ vừa tốt nghiệp có thời gian thực hành – cấp chứng chỉ hành nghề Nội tổng quát.
  * Thảo luận về chương trình đào tạo thực hành lâm sàng cho BS ngoại tổng quát


Thời gian: 3,6/9/2019 từ 15:00-16:00, hội trường A
Thành phần bệnh viện tham gia: lãnh đạo khoa, phòng toàn bệnh viện và các các nhân viên y tế có tham gia đào tạo tay nghề, BS 18 tháng (danh sách cụ thể)
Chủ tọa: GS Lê Quang Nghĩa
Báo cáo tham luận về tình hình đào tạo thực hành lâm sàng cho BS mới ra trường chuyên ngành Ngoại tổng quát với mô hình kết hợp ĐH Y Dược Tp.HCM tại BV Nguyễn Tri Phương: BS Lê Đức Định Miên, phó trưởng phòng KHTH
Thành phần khách mời: một số các bệnh viện lân cận có quan tâm đến việc đào tạo tay nghề cho bác sĩ mới tốt nghiệp
Nội dung hướng đến: Tạo ra những đồng thuận ban đầu về phương pháp đào tạo và chất lượng đào tạo cho các bác sĩ vừa tốt nghiệp có thời gian thực hành – cấp chứng chỉ hành nghề Ngoại tổng quát
Tài liệu phục vụ nghiên cứu, thảo luận:
  1. Core Entrustable Professional Activities (EPAs) for Entering Residency
  2. First Aid for The USMLE Step 2 CS Clinical Skills – 6th Edition
  3. Chương trình đào tạo 18 tháng cho bác sĩ mới tốt nghiệp tại BV Nguyễn Tri Phương
  4. Các tiêu chí đào tạo lâm sàng do GS Thạch Nguyễn tuyển chọn và biên dịch


​Chúng tôi rất trân trọng kính mời các đồng nghiệp có quan tâm, đến tham gia buổi hội thảo về chuyên đề trên (vào cửa tự do)./.

## CHƯƠNG TRÌNH TẬP HUẤN CME VỀ KIỂM SOÁT NHIỄM KHUẨN

**Ngày 3 tháng 04 năm 2019**
**Hội trường A - Bệnh viện Nguyễn Tri Phương, lầu 5 khu A**
**Thời gian** |  **Nội dung chương trình** |  **Phụ trách**  
---|---|---  
13h00 – 13h15 |  Khai mạc chương trình |  Ban Giám Đốc Bệnh Viện  
13h15 – 14h15 |  Chất lượng Bệnh Viện và KSNK. Các văn bản quy phạm pháp luật liên quan đến KSNK và cách áp dụng |  PGS.TS Lê Thị Anh Thư – Chủ tịch Hội KSNK TPHCM.  
14h45 – 15h00 |  Hướng dẫn sử dụng sản phẩm công ty Johnson & Johnson. |  Công ty TNHH Johnson & Johnson VN.  
15h00 – 16h00 |  Kiểm soát nhiễm khuẩn khi có dịch bệnh |  PGS.TS Lê Thị Anh Thư – Chủ tịch Hội KSNK TPHCM.  
16h _ 16g15 |  VST TT3916/BYT |  BS CKII Nguyễn Lan Phượng  
16h15 – 16h30 |  Thảo luận  
Tải về toàn bộ thông báo [tại đây](https://drive.google.com/open?id=19Z4ZWxZLQO8LOSLFh79n_Zzxb9x1x5GC).

## THÔNG BÁO ĐÀO TẠO LIÊN TỤC

Nhằm đảo bảo an toàn tối đa và cải thiện chất lượng sống cũng như nguy cơ tử vong cho các bệnh nhân lọc máu định kỳ, Bệnh viện Nguyễn Tri Phương kết hợp cùng Hội Lọc máu Thành phố Hồ Chí Minh tổ chức lớp học về “Chất lượng nước trong chạy thận nhân tạo và kiểm soát nhiễm khuẩn giữa các tua chạy thận” như sau:
  * Ban Giảng huấn: 
    * Shubhada Narendra Ahya – Giáo sư nội khoa, Trưởng khoa Thận học, Phân môn thận Đại học Northwestern, Khoa Y Feinberg, Chicago, Illionois
    * PGS.TS.BS.Phạm Văn Bùi – Chủ tịch Hội Lọc Máu Thành phố Hồ Chí Minh.
  * Chương trình tập huấn dành cho đối tượng: Ban Giám đốc, cán bộ Quản lý chất lượng, cán bộ quản lý trang thiết bị, nhân viên kiểm soát nhiễm khuẩn; bác sĩ, điều duỡng đang công tác trong lĩnh vực thận nhân tạo – lọc máu.
  * Chương trình dự kiến sẽ diễn ra: 
    * Ngày 24/10/2019, thời gian học: sáng 8h-11h30.
    * Địa điểm dự kiến: Hội trường A bệnh viện Nguyễn Tri Phương.
  * Tính tương đương CME: 04 tiết (mã đào tạo liên tục C10.2)
  * Kinh phí tham gia: 300.000đ/học viên (bao gồm tài liệu, tiệc trà, phí cấp chứng nhận) – đóng trực tiếp tại lớp học


Đăng ký tham gia, vui lòng liên hệ phòng Quản Lý Chất Lượng: (0283)9234349 – 9234332 số máy lẻ (2060) hoặc gặp CN Tuấn (0907101025). Hạn cuối đăng ký ngày 18/10/2019. 
Đơn đăng ký tham gia có thể tải [tại đây](https://drive.google.com/file/d/1JPkU1vR9lyaB8Y4LSTu1D-G5yTV4Nclp/view?usp=sharing)./.

## Tổ chức lớp Đào tạo liên tục chuyên đề “Nội soi khớp và Thay khớp nhân tạo” năm 2019

**Đối tượng tham gia:**
  * Bác sĩ định hướng hoặc chuyên khoa chấn thương chỉnh hình
  * Bác sĩ đa khoa có nhu cầu đào tạo liên tục để phát triển chuyên khoa chấn thương chỉnh hình về sau


**Thời gian khóa học:**
  * Thời gian toàn khóa : tối thiểu 02 tháng.
  * Thời gian hàng ngày : Từ 8h đến 16h.
  * Địa điểm học tập : Tại Khoa Chấn thương chỉnh hình


Tại Khoa Phẫu thuật Gây mê hồi sức
Tại hội trường Khoa Chấn thương chỉnh hình.
**Nội dung khóa học:**
  * Giảng viên: các bác sĩ của bệnh viện Nguyễn Tri Phương – bộ môn CTCH Trường ĐH Y Dược Thành phố Hồ Chí Minh.
  * Hình thức đào tạo: lý thuyết và thực hành theo hình thức cầm tay chỉ việc


**Học phí:**
  * 5.000.000đ/tháng/học viên
  * Nộp tiền toàn khóa 01 lần


**Bằng cấp:**
  * Chứng chỉ đào tạo liên tục về Nội soi khớp và Thay khớp nhân tạo do bệnh viện Nguyễn Tri Phương cấp (CME được Bộ Y Tế cấp phép) đối với học viên đã hoàn thành khóa học.
  * Tùy vào thời gian thực tế sẽ tương ứng số tiết đào tạo liên tục được cấp.


**Hồ sơ đăng ký:**
  * 02 tấm hình 3*4 ( mặt sau ghi rõ họ tên, ngày tháng năm sinh)
  * Đơn đăng ký học theo mẫu
  * Bằng tốt nghiệp bác sĩ đa khoa
  * Giấy xác nhận hoàn thành khóa học định hướng chuyên khoa


**Thời gian và nơi nhận đơn:**
  * Bệnh viện chiêu sinh liên tục, thời gian làm việc trong giờ hành chính, đăng ký tại phòng Chỉ Đạo Tuyến (lầu 1 khu E).
  * Mọi chi tiết xin liên hệ: CN. Trần Ngọc Trí, Điện thoại: 0938 153 918


Hoặc đăng ký qua email: cdt_ntp@bvnguyentriphuong.com.vn
Trong trường hợp có nhu cầu chuyển khoản :
  * Thông tin tài khoản : Bệnh Viện Nguyễn Tri Phương


468 Nguyễn Trãi, Phường 8, Quận 5, TP.HCM
  * Số tài khoản : 0251002787729 Ngân hàng Ngoại thương Việt Nam (Vietcombank) - Chi nhánh Bình Tây


Tải toàn bộ thông báo [tại đây](https://drive.google.com/open?id=1zCkd-h2F8IgSBjc4CpUX5e1wtftcn49k).

## Lớp chuyên đề Vai trò điện não đồ trong Động kinh

**_Giảng viên:_**
  * Cán bộ giảng khoa Nội thần kinh Bệnh viện Nguyễn Tri Phương.
  * Ban giảng huấn từ ASEPA, bao gồm:
    * John W. Dunne , Australia
    * Piero Perucca, Australia
    * Chong-Tin Tan, Malaysia
    * Archer John Stephen ; Melbourne, Australia
    * Lim Kheng Seang; Kuala Lumpur, Malaysia
    * FATHIL SYAFIQ B. ABDUL KARIM; Kuala Lumpur, Malaysia
    * Norimichi HIGURASHI, Nhật Bản
    * Dr. Ramesh Konanki, New Delhi, Ấn độ
    * Josephine, Philipine
    * Kannan Ramamorthy, Ấn độ
    * Kiley Michell Ann, Australia


**Ngày 12/10/2019**
**Time** |  **Topics** |  **Speakers**  
---|---|---  
08.00 – 08.45 |  Registration  
08.45 – 09.00 |  Welcome and Introduction  
09.00 – 09.40 09.40 – 10.30 |  Technical 1 – The Basics Breakout Session 1 |  John Dunne Teaching Faculty  
10.30 – 11.00 |  Coffee/Tea Break  
11.00 – 11.30 11.30 – 12.30 |  Normal EEG 1 – Awake Breakout Session 2 |  Lakshminarayanan Teaching Faculty  
12.30 – 13.30 |  Lunch  
13.30 – 14.00 14.00 – 15.00 |  Normal EEG 2 – Sleep Breakout Session 3 |  CT Tan Teaching Faculty  
15.00 – 15.30 |  Coffee/Tea Break  
15.30 – 16.00 16.00 – 17.00 |  Technical 2 – Localization and Artefacts Breakout Session 4 |  John Archer Teaching Faculty  
**Ngày 13/10/2019**
**Time** |  **Topics** |  **Speakers**  
---|---|---  
09.00 – 09.30 09.30 – 10.30 |  Non-Epileptiform Patterns Breakout Session 5 |  J Gutierrez Teaching Faculty  
10.30 – 11.00 |  Coffee/Tea Break  
11.00 – 11.30 11.30 – 12.30 |  Generalized Epileptiform Patterns Breakout Session 6 |  KS Lim Teaching Faculty  
12.30 – 13.30 |  Lunch  
13.30 – 14.00 14.00 – 15.00 |  Focal Epileptiform Patterns and Normal Variants Breakout Session 7 |  Ramesh Konanki Teaching Faculty  
15.00 – 15.30 |  Coffee/Tea Break  
15.30 – 15.50 15.50 – 16.10 16.10 – 17.00 |  How to Read and How to Report an EEG Clinical Utility of EEG EEG Quiz |  John Dunne Michelle Kiley  
17.00 – 17.10 |  Closing Remarks  
**HỌC PHÍ ĐÀO TẠO**
  * Tham gia và nhận giấy chứng nhận: 500.000đ/người
  * Tham gia nhận giấy chứng nhận và cấp CME: 700.000đ/người


*CME được BYT cấp phép đào tạo
**HÌNH THỨC ĐĂNG KÝ**
**Hồ sơ đăng ký****cấp****:**
  * 02 tấm hình 3*4 ( mặt sau ghi rõ họ tên, ngày tháng năm sinh)
  * Đơn đăng ký tham gia theo mẫu 
  * Bằng tốt nghiệp chuyên môn bác sĩ đa khoa, KTV… (photo, không cần chứng thực), **_nếu xin cấp CME_**


**Thời gian và nơi****đăng ký****:**
  * Đăng ký trực tiếp: hạn cuối 04/10/2019, thời gian làm việc trong giờ hành chính, đăng ký tại phòng Quản Lý Chất Lượng (lầu 1 khu A).
  * Đăng ký qua email : qlcl.bvntp@gmail.com theo mẫu sau

Stt |  Họ tên |  Cơ quan công tác (nếu có) |  Số điện thoại cá nhân |  Có đăng ký cấp CME (đánh ‘ x’ )  
---|---|---|---|---  
  * Mọi chi tiết thắc mắc xin vui lòng liên hệ: CN. Vũ Minh Tuấn, điện thoại: 0907.1010.25


***Thanh toán:**
  * _Trực tiếp_ : Phòng Tài Chính Kế Toán – Bệnh viện Nguyễn Tri Phương.
  * _Chuyển khoản_ : Số tài khoản: 0071001193993 – Ngân hàng Ngoại Thương Việt Nam (VietcomBank), chi nhánh Hùng Vương – Tp. Hồ Chí Minh.
  * _Nội dung chuyển khoản:_ “tên học viên” + “CK hoc phi lop Dien Nao Do trong Dong kinh”.
  * _Hạn cuối thanh toán học phí_ : ngày 09/10/2019


​Mẫu đơn đăng ký có thể tải [tại đây](https://drive.google.com/file/d/1_8pFJIzKh8ZpOyn6rync33fJmF1BARaI/view?usp=sharing)./.

## Tổ chức lớp bồi dưỡng kiến thức liên tục (CME) Thận học - Lọc máu năm 2019

  1. **Đối tượng tham gia:**
     * Bác sĩ, Điều dưỡng từ các bệnh viện trong và ngoài có nhu cầu.
  2. **Thời gian khóa học:** khai giảng 10/07/2019
     * **Giai đoạn:** Từ 10/07/2019 đến ngày 10/01/2020.


_(12 buổi lý thuyết và 24 buổi thực hành)_
  * **Thời gian học:**
    * Lý thuyết: từ 13 giờ 30 đến 16 giờ 30 các ngày thứ 4 và thứ 6 hằng tuần.
    * Thực hành: tùy theo học viên đăng ký vào 01 trong 03 nhóm sau:
      * __Nhóm 01__ _:_ buổi chiều thứ 3 và thứ 5 / cả ngày thứ 3 hoặc thứ 5
      * __Nhóm 02__ _:_ buổi chiều thứ 4 và thứ 6 / cả ngày thứ 4 hoặc thứ 6
  * **Nội dung khóa học:**


  * Trưởng ban Giảng huấn: PGS. TS. BS. Phạm Văn Bùi – Chủ tịch Hội Lọc Máu Tp. Hồ Chí Minh.
  * Nội dung chi tiết: cập nhật kiến thức Thận Học – Lọc Máu. Ngoài những nội dung bài giảng chính, khóa học có cập nhật thêm các kiến thức mới từ Hội nghị Lọc Máu trong và ngoài nước.


**Học phí:**
  1. Bác sĩ: 5.000.000 đồng/học viên (cập nhật 03 tháng lý thuyết).
  2. Điều dưỡng: 4.500.000 đồng/học viên (cập nhật 03 tháng lý thuyết và 03 tháng thực hành)
  3. Điều dưỡng cập nhật CME 06 tháng: 1.500.000 đồng/học viên (cập nhật 03 tháng thực hành)


_(đã có chứng chỉ Thận Học – Lọc Máu 03 tháng do Bệnh viện Nguyễn Tri Phương cấp)_
**Bằng cấp – Chứng nhận:** Chứng chỉ đào tạo liên tục _(CME được Bộ Y tế cấp phép)_ về Thận Học – Lọc Máu do Bệnh viện Nguyễn Tri Phương cấp.
**Điều kiện cấp bằng:**
  * Hoàn tất 80% thời gian học lý thuyết và thực hành.
  * Hoàn thành tốt bài thi lý thuyết và đánh giá thực hành chuyên môn cuối khóa.


**Hồ sơ đăng ký:**
  * 02 tấm hình 3x4 (mặt sau ghi rõ họ tên, ngày tháng năm sinh)
  * Đơn đăng ký theo mẫu
  * Photo công chứng “ _Bằng chuyên môn Bác sĩ / Điều dưỡng_ ”.
  * Bản chính _“Chứng chỉ đào tạo liên tục Thận Học – Lọc Máu”_ khóa 03 tháng lý thuyết _(dành cho điều dưỡng đã có chứng chỉ học 03 tháng do Bệnh viện Nguyễn Tri Phương cấp)_


**Thời gian và nơi nhận đơn:**
  * Thời gian nhận đơn kể từ ngày ra thông báo đến ngày 03/07/2019


_(Trong giờ hành chính từ thứ 2 đến thứ 6)_
  * Nơi nhận đơn:
    * _Trực tiếp:_ Phòng Quản Lý Chất Lượng – Bệnh viện Nguyễn Tri Phương _(lầu 01 – Khu A)._
    * _Qua Email:_ qlcl.bvntp@gmail.com (gửi Danh sách học viên tham gia có chữ ký và mộc của Thủ trưởng đơn vị trước và gửi bổ sung bằng văn bản sau)


**Thanh toán:**
  * _Trực tiếp_ : Phòng Tài Chính Kế Toán – Bệnh viện Nguyễn Tri Phương.
  * _Chuyển khoản_ : Số tài khoản: 0071001193993 – Ngân hàng Ngoại Thương Việt Nam (VietcomBank), chi nhánh Hùng Vương – Tp. Hồ Chí Minh.
  * _Nội dung chuyển khoản:_ “tên đơn vị” + “CK học phí lớp Thận Học – Lọc Máu 2019”.
  * _Hạn cuối thanh toán học phí_ : ngày 03/07/2019


**Liên hệ thêm thông tin:**
  * Phòng Quản Lý Chất Lượng – Bệnh viện Nguyễn Tri Phương (lầu 01, khu A)
    * CN Trương Thùy Trang: 0934.468.009
    * CN Vũ Minh Tuấn: 0907.1010.25


​* Toàn văn thông báo có thể xem [tại đây](https://drive.google.com/open?id=1rtYCEiLXo5jsdo6Fc-LsDHRZfokTGT3Y)./.

## Bài giảng của giáo sư Ahya (Hoa Kỳ) - đào tạo về chất lượng nước trong chạy thận (15/11/2018)

Link tải tài liệu:
https://drive.google.com/file/d/1MRwC_7SnUZvTnxxVkmYvJnM7o-HkxvE4/view?usp=sharing
Phòng Quản Lý Chất Lượng./.

## Cập nhật chương trình lớp phục hồi chức năng thần kinh sau đột quỵ - 2018

**Thời khóa biểu lớp tập huấn “Phục hồi chức năng thần kinh sau đột quỵ”**
**Bệnh viện Nguyễn Tri Phương**
**(Từ 05/11/2018 – 09/11/2018)**
**Ngày 1: 05/11/2018 (hội trường A)**
**Khai giảng lớp học**  
---  
8:00 - 8:30 |  **Đón tiếp đại biểu và học viên**  
8:30 – 8:45 |  **Phát biểu khai mạc của đại diện Bệnh viện Nguyễn Tri Phương** BS CK II. Võ Đức Chiến, _Giám đốc Bệnh viện Nguyễn Tri Phươnng_  
8:45 – 9:00 |  **Giới thiệu về chương trình AVANT** TS. Lê Văn Tuấn, Trưởng Bộ môn Nội Thần Kinh Đại Học Y Dược Tp HCM  
**Chương trình tập huấn**  
9:00- 9:30 |  **Tổng quan đột quỵ** Bs CK II, Trần Trung Thành, _Trưởng Khoa Nội Thần Kinh, Bệnh viện Nguyễn Tri Phương_  
9:30 – 10:40 |  **Định khu tổn thương đột quỵ não** TS. Lê Văn Tuấn, Trưởng Bộ môn Nội Thần Kinh Đại Học Y Dược Tp HCM  
10:40 – 10:55 |  **Nghỉ giải lao**  
10:55 – 11:30 |  **Cơ chế PHCN thần kinh sau đột quỵ** TS. Lê Văn Tuấn, Trưởng Bộ môn Nội Thần Kinh Đại Học Y Dược Tp HCM  
11:30 - 11:45 |  **Những tiến bộ về ngoại khoa trong điều trị xuất huyết não tự phát** TS. Phạm Anh Tuấn, Trưởng khoa Ngoại Thần Kinh, Bệnh viện Nguyễn Tri Phương Bộ môn Ngoại Thần Kinh Đại Học Y Dược Tp HCM  
11:45 - 12:00 |  Câu hỏi và giải đáp  
12:00 – 13:30 |  Ăn trưa và nghỉ trưa  
13:30 – 14:30 |  **Ứng dụng các nguyên tắc PHCN vận động vào thực tiễn** TS. Lê Văn Tuấn, Trưởng Bộ môn Nội Thần Kinh Đại Học Y Dược Tp HCM  
14:30 – 14:45 |  Nghỉ giải lao  
14:45 – 16:30 |  **Phục hồi chức năng sau đột quỵ não: các khiếm khuyết thường gặp, nhóm PHCN** Bs CK II. Nguyễn Đăng Khoa, _Trưởng khoa VLTL, Bệnh viện Chợ Rẫy_  
**Ngày 2: 06/11/2018 (hội trường khoa CTCH)**
8:30 – 9:00 |  Làm bài kiểm tra trước khóa học  
---|---  
9:00 – 9:45 |  **Vận động trị liệu cho bệnh nhân đột quỵ (Bài 1)**
  * _Các bài tập ở tư thế nằm_
  * _Dịch chuyển sớm_
  * _Các bài tập ở tư thế ngồi_

Bs CK II. Nguyễn Đăng Khoa, _Trưởng khoa VLTL, Bệnh viện Chợ Rẫy_ CN Trương Thị Minh Hiền, _Khoa VLTL, Bệnh viện Chợ Rẫy_  
9:45 – 10:00 |  Nghỉ giải lao  
10:00 – 12:00 |  **Thực hành vận động trị liệu cho bệnh nhân đột quỵ (Bài 1)** Bs CK II. Nguyễn Đăng Khoa, _Trưởng khoa VLTL, Bệnh viện Chợ Rẫy_ CN Trương Thị Minh Hiền  
12:00 – 13:30 |  Ăn trưa – Nghỉ trưa  
13:30 – 14:30 |  **Vận động trị liệu cho bệnh nhân đột quỵ (Bài 2)**
  * _Tập di chuyển_
  * _Tập thăng bằng_
  * _Tập đứng_
  * _Tập đi_
  * _Tập lên, xuống cầu thang_

Bs CK II. Nguyễn Đăng Khoa, CN Trương Thị Minh Hiền  
14:30 – 14:45 |  Nghỉ giải lao  
14:45 – 16:00 |  **Thực hành vận động trị liệu cho bệnh nhân đột quỵ (Bài 2)** Bs CK II. Nguyễn Đăng Khoa CN Trương Thị Minh Hiền  
16:00 – 16:30 |  Câu hỏi và giải đáp  
**Ngày 3: 07/11/2018 (hội trường A)**
8:30 – 10:00 |  **Thực hành vận động trị liệu (Bài 2)** Bs CK II. Nguyễn Đăng Khoa CN Trương Thị Minh Hiền  
---|---  
10:00 – 10:15 |  Nghỉ giải lao  
10:15 – 12:00 |  **Một số test luợng giá trong vận động trị liệu và hoạt động trị liệu. Thực hành các test lượng giá** Bs CK II. Nguyễn Đăng Khoa, CN Trương Thị Minh Hiền  
12:00 - 13:30 |  Ăn trưa- Nghỉ trưa  
13:30 – 14:30 |  **Hoạt động trị liệu cho bệnh nhân đột quỵ (Bài 1)**
  * _Các bài tập HĐTL ở tư thế nằm_
  * _Các bài tập HĐTL ở tư thế ngồi_

Bs. CK I. Đinh Quang Thanh CN Lê Hồng Cẩm, _Bệnh viện PHCN và điều trị bệnh nghề nghiệp._ CN Lê Thị Hạ Quyên, _BV PHCN và điều trị bệnh nghề nghiệp, TPHCM_  
14:30 - 14:45 |  Nghỉ giải lao   
14:45 – 16:30 |  **Thực hành hoạt động trị liệu (Bài 1)** Bs. CK I. Đinh Quang Thanh CN Lê Thị Hạ Quyên, CN Lê Hồng Cẩm  
**Ngày 4: 08/11/2018 (hội trường khoa CTCH)**
8:30 - 9:15 |  **Thất ngôn sau đột quỵ não** Bs. CK I. Đinh Quang Thanh, _Truởng khoa VLTL, Bệnh viện PHCN và điều trị bệnh nghề nghiệp, TPHCM_  
---|---  
9:15 – 10:15 |  **Hoạt động trị liệu cho bệnh nhân đột quỵ ( Bài 2)**
  * **_Các hoạt động hàng ngày (ADL):_**_Mặc quần áo, đánh răng, vệ sịnh cá nhân…_

Bs. CK I. Đinh Quang Thanh, CN Lê Thị Hạ Quyên, CN Lê Hồng Cẩm  
10:15 – 10:30 |  Nghỉ giải lao  
10:30 – 12:00 |  **Thực hành hoạt động trị liệu (Bài 2)** Bs. CK I. Đinh Quang Thanh CN Lê Thị Hạ Quyên, CN Lê Hồng Cẩm  
12:00-13:30 |  Ăn trưa- Nghỉ trưa  
13:30 - 14:30 |  **Hoạt động trị liệu cho bệnh nhân đột quỵ ( Bài 3)**
  * _Các bài tập nhận thức-cảm giác_

BS Đinh Quang Thanh, CN Lê Thị Hạ Quyên, CN Lê Hồng Cẩm  
14:30 - 15:30 |  **Thực hành hoạt động trị liệu cho bệnh nhân đột quỵ ( Bài 3)** Bs. CK I. Đinh Quang Thanh CN Lê Thị Hạ Quyên, CN Lê Hồng Cẩm  
15:30 -15:45 |  Nghỉ giải lao  
15:45 -16:30 |  **Thực hành hoạt động trị liệu cho bệnh nhân đột quỵ (Bài 1, 2, 3)** Bs. CK I. Đinh Quang Thanh CN Lê Thị Hạ Quyên, CN Lê Hồng Cẩm  
**Ngày 5: 09/11/2018 (hội trường A)**
8:30 – 10:00 |  **Rối loạn nuốt sau đột quỵ : Phát hiện sớm, lượng giá, xử trí, các bài tập** Bs. CKI Đinh Quang Thanh  
---|---  
10:00 – 10:15 |  Nghỉ giải lao  
10:15 – 10:45 |  **Sa sút trí tuệ sau đột quỵ** PGS TS Vũ Anh Nhị, Nguyên Trưởng Bộ môn Nội Thần Kinh _Đại Học Y Dược TP.HCM_  
10:45 – 12:00 |  **Thực hành rối lọan nuốt** BS. CK I. Đinh Quang Thanh CN Lê Thị Hạ Quyên, CN Lê Hồng Cẩm  
12:00 - 13:30 |  Ăn trưa- Nghỉ trưa  
13:30 – 15:30 |  **Ôn tập và giải đáp thắc mắc – Bài kiểm tra đánh giá** **Chấm bài và Giải đáp bài kiểm tra** BS. CKI Đinh Quang Thanh, BS. CKII. Nguyễn đăng Khoa  
15:30 – 15:45 |  Nghỉ giải lao  
15:45 – 16:30 |  **Bế mạc khóa tập huấn** **Phát chứng chỉ** Đại diện Ban Giám đốc BV Nguyễn Tri Phương BS. CK I Đinh Quang Thanh  
* Hội trường A: lầu 5 khu A
* Hội trường khoa Chấn Thương Chỉnh Hình (CTCH): lầu 2 khu B

## Lớp tập huấn “Phục hồi chức năng thần kinh sau đột quỵ”

**CHƯƠNG TRÌNH DỰ KIẾN NHƯ SAU**
**Ngày 1: 05/11/2018**
**Khai giảng lớp học**  
---  
8:00 - 8:30 |  **Đón tiếp đại biểu và học viên**  
8:30 – 8:45 |  **Phát biểu khai mạc của đại diện Bệnh viện Nguyễn Tri Phương** BS CK II. Võ Đức Chiến, _Giám đốc Bệnh viện Nguyễn Tri Phươnng_  
8:45 – 9:00 |  **Giới thiệu về chương trình AVANT** TS. Trần Viết Lực, _Trưởng Khoa Lão, Bệnh viện Lão khoa Trung ương_  
**Chương trình tập huấn**  
9:00- 9:30 |  **Tổng quan đột quỵ** Bs CK II, Trần Trung Thành, _Trưởng Khoa Nội Thần kinh, Bệnh viện Nguyễn Tri Phương_  
9:30 – 10:40 |  **Định khu tổn thương đột quỵ não** TS. Trần Viết Lực, _Trưởng khoa Khám bệnh, Bệnh viện Lão khoa Trưng ương_  
10:40 – 10:55 |  **Nghỉ giải lao**  
10:55 – 11:30 |  **Cơ chế PHCN thần kinh sau đột quỵ** TS. Trần Viết Lực, _Trưởng khoa Khám bệnh, Bệnh viện Lão khoa Trưng ương_  
11:30 – 12:00 |  Câu hỏi và giải đáp  
12:00 – 13:30 |  Ăn trưa và nghỉ trưa  
13:30 – 14:30 |  **Ứng dụng các nguyên tắc PHCN vận động vào thực tiễn** TS. Trần Viết Lực, _Trưởng khoa Khám bệnh, Bệnh viện Lão khoa Trưng ương_  
14:30 – 14:45 |  Nghỉ giải lao  
14:45 – 16:30 |  **Phục hồi chức năng sau đột quỵ não: các khiếm khuyết thường gặp, nhóm PHCN** Bs CK II. Nguyễn Đăng Khoa, _Trưởng khoa VLTL, Bệnh viện Chợ Rẫy_  
**Ngày 2: 06/11/2018**
8:30 – 9:00 |  Làm bài kiểm tra trước khóa học  
---|---  
9:00 – 9:45 |  **Vận động trị liệu cho bệnh nhân đột quỵ (Bài 1)**
  * _Các bài tập ở tư thế nằm_
  * _Dịch chuyển sớm_
  * _Các bài tập ở tư thế ngồi_

Bs CK II. Nguyễn Đăng Khoa, _Trưởng khoa VLTL, Bệnh viện Chợ Rẫy_ CN Trương Thị Minh Hiền, _Khoa VLTL, Bệnh viện Chợ Rẫy_  
9:45 – 10:00 |  Nghỉ giải lao  
10:00 – 12:00 |  **Thực hành vận động trị liệu cho bệnh nhân đột quỵ (Bài 1)** Bs CK II. Nguyễn Đăng Khoa, _Trưởng khoa VLTL, Bệnh viện Chợ Rẫy_ CN Trương Thị Minh Hiền  
12:00 – 13:30 |  Ăn trưa – Nghỉ trưa  
13:30 – 14:30 |  **Vận động trị liệu cho bệnh nhân đột quỵ (Bài 2)**
  * _Tập di chuyển_
  * _Tập thăng bằng_
  * _Tập đứng_
  * _Tập đi_
  * _Tập lên, xuống cầu thang_

Bs CK II. Nguyễn Đăng Khoa, CN Trương Thị Minh Hiền  
14:30 – 14:45 |  Nghỉ giải lao  
14:45 – 16:00 |  **Thực hành vận động trị liệu cho bệnh nhân đột quỵ (Bài 2)** Bs CK II. Nguyễn Đăng Khoa CN Trương Thị Minh Hiền  
16:00 – 16:30 |  Câu hỏi và giải đáp  
**Ngày 3: 07/11/2018**
8:30 – 10:00 |  **Thực hành vận động trị liệu (Bài 2)** Bs CK II. Nguyễn Đăng Khoa CN Trương Thị Minh Hiền  
---|---  
10:00 – 10:15 |  Nghỉ giải lao  
10:15 – 12:00 |  **Một số test luợng giá trong vận động trị liệu và hoạt động trị liệu. Thực hành các test lượng giá** Bs CK II. Nguyễn Đăng Khoa, CN Trương Thị Minh Hiền  
12:00 - 13:30 |  Ăn trưa- Nghỉ trưa  
13:30 – 14:30 |  **Hoạt động trị liệu cho bệnh nhân đột quỵ (Bài 1)**
  * _Các bài tập HĐTL ở tư thế nằm_
  * _Các bài tập HĐTL ở tư thế ngồi_

Bs. CK I. Đinh Quang Thanh CN Lê Hồng Cẩm, _Bệnh viện PHCN và điều trị bệnh nghề nghiệp._ CN Lê Thị Hạ Quyên, _BV PHCN và điều trị bệnh nghề nghiệp, TPHCM_  
14:30 - 14:45 |  Nghỉ giải lao   
14:45 – 16:30 |  **Thực hành hoạt động trị liệu (Bài 1)** Bs. CK I. Đinh Quang Thanh CN Lê Thị Hạ Quyên, CN Lê Hồng Cẩm  
**Ngày 4: 08/11/2018**
8:30 - 9:15 |  **Thất ngôn sau đột quỵ não** Bs. CK I. Đinh Quang Thanh, _Truởng khoa VLTL, Bệnh viện PHCN và điều trị bệnh nghề nghiệp, TPHCM_  
---|---  
9:15 – 10:15 |  **Hoạt động trị liệu cho bệnh nhân đột quỵ ( Bài 2)**
  * **_Các hoạt động hàng ngày (ADL):_**_Mặc quần áo, đánh răng, vệ sịnh cá nhân…_

Bs. CK I. Đinh Quang Thanh, CN Lê Thị Hạ Quyên, CN Lê Hồng Cẩm  
10:15 – 10:30 |  Nghỉ giải lao  
10:30 – 12:00 |  **Thực hành hoạt động trị liệu (Bài 2)** Bs. CK I. Đinh Quang Thanh CN Lê Thị Hạ Quyên, CN Lê Hồng Cẩm  
12:00-13:30 |  Ăn trưa- Nghỉ trưa  
13:30 - 14:30 |  **Hoạt động trị liệu cho bệnh nhân đột quỵ ( Bài 3)**
  * _Các bài tập nhận thức-cảm giác_

BS Đinh Quang Thanh, CN Lê Thị Hạ Quyên, CN Lê Hồng Cẩm  
14:30 - 15:30 |  **Thực hành hoạt động trị liệu cho bệnh nhân đột quỵ ( Bài 3)** Bs. CK I. Đinh Quang Thanh CN Lê Thị Hạ Quyên, CN Lê Hồng Cẩm  
15:30 -15:45 |  Nghỉ giải lao  
15:45 -16:30 |  **Thực hành hoạt động trị liệu cho bệnh nhân đột quỵ (Bài 1, 2, 3)** Bs. CK I. Đinh Quang Thanh CN Lê Thị Hạ Quyên, CN Lê Hồng Cẩm  
**Ngày 5: 09/11/2018**
8:30 – 10:00 |  **Rối loạn nuốt sau đột quỵ : Phát hiện sớm, lượng giá, xử trí, các bài tập** Bs. CKI Đinh Quang Thanh  
---|---  
10:00 – 10:15 |  Nghỉ giải lao  
10:15 – 10:45 |  **Sa sút trí tuệ sau đột quỵ** TS. Trần Công Thắng, _Khoa Nội Thần Kinh Bệnh viện Đại Học Y Dược TP.HCM_  
10:45 – 12:00 |  **Thực hành rối lọan nuốt** BS. CK I. Đinh Quang Thanh CN Lê Thị Hạ Quyên, CN Lê Hồng Cẩm  
12:00 - 13:30 |  Ăn trưa- Nghỉ trưa  
13:30 – 15:30 |  **Ôn tập và giải đáp thắc mắc – Bài kiểm tra đánh giá** **Chấm bài và Giải đáp bài kiểm tra** BS. CKI Đinh Quang Thanh, BS. CKII. Nguyễn Đăng Khoa  
15:30 – 15:45 |  Nghỉ giải lao  
15:45 – 16:30 |  **Bế mạc khóa tập huấn** **Phát chứng chỉ** Đại diện Ban Giám đốc BV Nguyễn Tri Phương BS. CK I Đinh Quang Thanh

## Bế mạc lớp Phục hồi chức năng thần kinh sau đột quỵ tại Bệnh viện Nguyễn Tri Phương

Lớp học PHCN thần kinh sau đột quỵ đã trang bị nhiều kiến thức bổ ích và gắn liền với thực tế công việc của các nhân viên y tế trong lĩnh vực Phục Hồi Chức Năng và Thần kinh 
  * Hôm nay ngày 09/11/2018 lớp đã tiến hành bế mạc với sự tham gia:
    * Ban tổ chức: 
      * Tiến sĩ Bác sĩ Nguyễn Đình Xướng – Phó Giám đốc Bv Nguyễn Tri Phương
      * Bác sĩ Chuyên khoa II Lương Công Minh – Trưởng phòng QLCL - Bv Nguyễn Tri Phương


  * Ban Giảng huấn: 
    * Bác sĩ Chuyên khoa I Đinh Quang Thanh – Trưởng Khoa VLTL – Bv PHCN và điều trị bệnh nghề nghiệp Tp. HCM


Một số hình ảnh trao CME cho các học viên của lớp 
Xin trân trọng cảm ơn công ty EVER Pharma, Ban Giảng huấn và Ban tổ chức lớp học./.
Vũ Minh Tuấn - Phòng QLCL

## Thông báo 'vv điều chỉnh thời gian lớp học Thận học - Lọc máu' Cập nhật lần 2

**DOWNLOAD**
Thông báo "vv điều chỉnh thời gian lớp học Thận học - Lọc máu" [Tải file tại đây](https://drive.google.com/open?id=1YIpp4QYQOYNoP4d5At7yE98U0ksZ41IB)

## Thông báo 'vv đào tạo thực hành để cấp chứng chỉ hành nghề'

**DOWNLOAD**
Thông báo "vv đào tạo thực hành để cấp chứng chỉ hành nghề"[ tải file tại đây](https://drive.google.com/open?id=1iOa-CWATvn4wYhO4bzoOjXe74uXFTt0c)

## Tổ chức thành công lớp cập nhật kiến thức về chạy thận nhân tạo

Nhằm đảo bảo an toàn tối đa và cải thiện chất lượng sống cũng như nguy cơ tử vong cho các bệnh nhân lọc máu định kỳ, Bệnh viện Nguyễn Tri Phương kết hợp cùng Hội Lọc máu Thành phố Hồ Chí Minh tổ chức lớp học về “Chất lượng nước trong chạy thận nhân tạo và kiểm soát nhiễm khuẩn trong đơn vị chạy thận nhân tạo” với sự tham gia của giáo sư đến từ Hoa Kỳ: **Shubhada Narendra Ahya – Giáo sư nội khoa, Trưởng khoa Thận học, Phân môn thận Đại học Northwestern, Khoa Y Feinberg, Chicago, Illionois.**
Lớp học rất vui khi nhận được sự quan tâm của Sở Y Tế thành phố Hồ Chí Minh và sự tham dự phát biểu khai mạc của PGS.TS.BS Tăng Chí Thượng, Phó Giám đốc Sở. Qua đó, cũng thể hiện sự quan tâm của lãnh đạo ngành y tế thành phố đối với chất lượng chạy thận hiện nay.
Lớp học chân thành cảm ơn sự hỗ trợ của Hội Lọc máu thành phố Hồ Chí Minh đã giúp kết nối với giáo sư Ahya và đem lại rất nhiều thông tin bổ ích cho nhân viên y tế đến từ nhiều đơn vị trong và ngoài thành phố đang hoạt động trong lĩnh vực thận nhân tạo./.
BS Lương Công Minh, phòng Quản lý chất lượng

## Thông báo về lớp học về đề tài Thận học - Lọc máu

** THÔNG BÁO**
Về việc đăng ký tham gia lớp học về đề tài “Chất lượng nước trong chạy thận nhân tạo và kiểm soát nhiễm khuẩn giữa các tua chạy thận”
Nhằm đảo bảo an toàn tối đa và cải thiện chất lượng sống cũng như nguy cơ tử vong cho các bệnh nhân lọc máu định kỳ, Bệnh viện Nguyễn Tri Phương kết hợp cùng Hội Lọc máu Thành phố Hồ Chí Minh tổ chức lớp học về “Chất lượng nước trong chạy thận nhân tạo và kiểm soát nhiễm khuẩn giữa các tua chạy thận” như sau:
  * Ban Giảng huấn:
    * Shubhada Narendra Ahya – Giáo sư nội khoa, Trưởng khoa Thận học, Phân môn thận Đại học Northwestern, Khoa Y Feinberg, Chicago, Illionois
    * PGS.TS.BS.Phạm Văn Bùi – Chủ tịch Hội Lọc Máu Thành phố Hồ Chí Minh.
  * Chương trình tập huấn dành cho đối tượng: Ban Giám đốc, cán bộ Quản lý chất lượng, cán bộ quản lý trang thiết bị, nhân viên kiểm soát nhiễm khuẩn; bác sĩ, điều duỡng đang công tác trong lĩnh vực thận nhân tạo – lọc máu.
  * Chương trình dự kiến sẽ diễn ra:
    * Ngày 15/11/2018, thời gian học: sáng 8h-11h30.
    * Địa điểm dự kiến: Hội trường A bệnh viện Nguyễn Tri Phương.
  * Tính tương đương CME: 04 tiết (mã đào tạo liên tục C10.2)
  * Kinh phí tham gia: 200.000đ/học viên (bao gồm tài liệu, tiệc trà, phí cấp chứng nhận)


Đăng ký tham gia, vui lòng liên hệ phòng Quản Lý Chất Lượng: (0283)9234349 – 9234332 số máy lẻ (2060) hoặc gặp BS Minh (0983848985). Hạn cuối đăng ký ngày 29/10/2018. 
Trân trọng cảm ơn./.
HỘI LỌC MÁU TP.HCM P.GIÁM ĐỐC
PGS.TS Phạm Văn Bùi (đã ký) TS.BS Nguyễn Đình Xướng (đã ký)

## Lớp cập nhật kiến thức về Huyết học - Miễn dịch

Bệnh viện Nguyễn Tri Phương xin thông báo về chương trình cập nhật kiến thức về lĩnh vực huyết học – miễn dịch như sau:
  1. **Báo cáo viên:** Giáo sư Andy Nghia Nguyen, chuyên ngành Huyết học, Đại Học Texas tại Houston, bệnh viện Hermann Memorial, Houston TX (do Đại học Tân Tạo giới thiệu, hỗ trợ).
  2. **Nội dung báo cáo**


  * Giải trình tự Gene thế hệ mới (phương thức giải trình tự đồng thời và lượng lớn các đoạn ngắn nucleotide), trong đó bàn đến:
    * Introduction to acute myeloid leukemia (AML); karyotypic and molecular abnormalities
    * The Cancer Genome Atlas (TCGA) database with data from 200 cases of de novo AML
    * Clustering analysis on this database to correlate the presence of 23 common mutations to prognosis of de novo CN-AML cases
  * Hỗ trợ truyền máu nhanh cho bệnh nhân mổ tim: Bộ xét nghiệm TAT về đông máu và quy trình truyền máu nhanh và toàn diện để điều trị hiệu quả bệnh lý đông máu trên đối tượng bệnh nhân có phẫu thuật nối tắt tim - phổi.


**Chương trình lớp học:**
  * Chương trình dự kiến sẽ diễn ra:
    * Ngày 14/01/2019 (thứ 2


  * Thời gian: từ 8h30-11h00.


  * Địa điểm dự kiến: Hội trường A bệnh viện Nguyễn Tri Phương.
  * Kinh phí tổ chức (bao gồm in ấn tài liệu, dịch thuật, tiệc trà giữa buổi, công tác tổ chức và chi phí hội trường): 150.000đ/người.


**Cách thức đăng ký**
  * Thông tin của người tham gia xin gửi về email: qlcl_ntp@bvnguyentriphuong.com.vn hoặc qlcl.bvntp@gmail.com
  * Để phục vụ việc phát giấy chứng nhận tham gia, cũng như tiện việc gửi bài giảng, vui lòng cấp thông tin đầy đủ theo mẫu sau:

**Họ tên** |  **Năm sinh** |  **Đơn vị công tác** |  **Email cá nhân**  
---|---|---|---  
  * Kinh phí tổ chức: đóng trực tiếp tại lớp học, có phiếu thu của bệnh viện.


Thông tin hỗ trợ: có thể liên hệ tại Phòng Quản Lý Chất Lượng – bệnh viện Nguyễn Tri Phương hoặc qua số điện thoại (0283) 9234349 – 9234332 số máy lẻ (2060) hoặc liên hệ với BS Lương Công Minh (0983848985).
Hạn cuối đăng ký ngày 10/01/2019. 
Trân trọng cảm ơn./.

## Thông báo 'vv Tổ chức lớp đào tạo liên tục chuyên đề ' Thận học - Lọc máu'. Cập nhật mới

**DOWNLOAD FILE**
Thông báo "vv tổ chức lớp đào tạo liên tục chuyên đề Thận học Lọc máu" [**Tải file tại đây**](https://drive.google.com/open?id=17znnAzXZ-FHRPDqzqQeDqVk4jOX85_8v)

## Thông báo chiêu sinh lớp học Lọc máu và Kế hoạch mở lớp 

**DOWNLOAD**
-Thông báo chiêu sinh : "vv Tổ chức lớp đào tạo liên tục chuyên đề Thận học - Lọc máu" . [Tải file tại đây](https://drive.google.com/open?id=1UpfKfSFR5yRsO49Ae_HTFqXBU-KzG4y-)
-Kế hoạch: "Mở lớp Thận học - Lọc máu" [Tải file tại đây](https://drive.google.com/open?id=1ree2ImZWsgKGNQJCpL1HR2gm1ssANRBw)

## THÔNG BÁO CHIÊU SINH ' THẬN HỌC - LỌC MÁU ' 2017


