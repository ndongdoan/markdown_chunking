## Ban hành quy chế làm việc của Bệnh viện Nguyễn Tri Phương

Xem toàn bộ quy chế [**tại đây**](https://bvnguyentriphuong.com.vn/uploads/112023/files/Quy%20ch%E1%BA%BF%20l%C3%A0m%20vi%E1%BB%87c%20cu%E1%BA%A3n%20B%E1%BB%87nh%20vi%E1%BB%87n%20Nguy%E1%BB%85n%20Tri%20Ph%C6%B0%C6%A1ng.pdf)
#### Nội dung trong file:



## KHÁI QUÁT VỀ THÔNG TƯ 43 - BÁO CÁO SỰ CỐ Y KHOA

Đường link báo cáo: [tại đây](https://drive.google.com/file/d/1GZCiz-BTBkt3qn4xVxxfaRt3WQK-pIFS/view?usp=sharing)./.

## Quy chế thực hiện dân chủ tại Bệnh viện Nguyễn Tri Phương

Xem toàn bộ quy chế [**tại đây**](https://bvnguyentriphuong.com.vn/uploads/112023/files/QD%20BAN%20HANH%20QUY%20CHE%20THUC%20HIEN%20DAN%20CHU.pdf)
#### Nội dung trong file:



## NHẬN DIỆN CỦA BỆNH VIỆN NGUYỄN TRI PHƯƠNG

Logo của BV đã đăng ký bản quyền: tải [tại đây](https://drive.google.com/file/d/1nqccs8Wy-4KEJ3IRZLnVnCj5x654mYCb/view?usp=sharing)
Sogan của BV: "**Năng động - Thân thiện - Phát triể** n".
Thiết kế cho các báo cáo PowerPoint: tải [tại đây](https://drive.google.com/file/d/1pbJnk_1nA7z-wfRge-U28KoOKo088D0_/view?usp=drive_link).

## Ban hành quy định về quy tắc ứng xử của viên chức, người lao động

Xem toàn bộ văn bản [**tại đây**](https://bvnguyentriphuong.com.vn/uploads/112023/files/Quy%20%C4%91%E1%BB%8Bnh%20v%E1%BB%81%20quy%20t%E1%BA%AFc%20%E1%BB%A9ng%20x%E1%BB%AD%20BVNTP%2022022024.pdf)
#### Nội dung trong file:



