## Công dụng tuyệt vời từ muối

Ngoài ra, muối không chỉ rẻ, hữu dụng, mà nó còn rất đa năng. Với một lọ muối nhỏ, các bạn xem thử có thể làm được những gì với những gợi ý sau.
**Muối dùng chăm sóc nhà cửa**
  * Muối diệt kiến: Nhà bạn nhiều kiến, bạn có thể rắc muối ở cửa ra vào, ngách cửa sổ và bất cứ chỗ nào kiến chui vào trong nhà. Cách này có thể đuổi kiến hiệu quả.
  * Hay thêm môt chút muối vào nước cắm hoa thì hoa sẽ được tươi lâu hơn.
  * Muối còn giúp bít lỗ trên tường. Muốn bít các lỗ đinh hoặc vết lở trên tường thạch cao, lấy 2 muỗng muối và 2 muỗng bột bắp trộn với khoảng 5 muỗng nước.
  * Muối diệt cỏ: Nếu cỏ dại mọc ở kẽ hở giữa các khối gạch hay khối đá trong vườn. Bạn hãy rắc muối vào các kẽ này rồi tưới nước.


**Muối dùng để lau chùi đồ dùng gia đình**
  * Trong việc lau chùi, muối cũng rất hữu dụng như: tẩy vết trắng trên bàn gỗ để lại bởi ly nước và đĩa nóng bằng cách trộn muối với dầu thực vật rồi đem chà nhẹ lên vết dơ.
  * Chùi chảo gang dính mỡ: Rắc nhiều muối vào chảo rồi lấy khăn giấy chùi sạch.
  * Rửa tách trà/ cà phê cáu bẩn: Lấy muối trộn với xà-bông rửa chén rồi chà nhẹ lên vết cáu bẩn. Hay trộn dung dịch baking soda pha muối dùng để lau tủ lạnh sẽ làm mất mùi bên trong mà không phải dùng hóa chất.
  * Làm sạch những chỗ sắt rỉ: Muối và chanh với đủ nước để làm thành bột nhão. Sau đó chà lên chỗ sắt rỉ, để cho khô, rồi lầy khăn mềm và khô chà sạch.


**Muối dùng giặt, tẩy vết bẩn trên quần áo**
Tẩy vết rượu vang: Lấy khăn hay giấy thấm rượu lau càng, nhiều càng tốt, rồi rắc ngay muối lên chỗ rượu vang đổ. Muối sẽ giúp hút hết rượu ra khỏi các sợi vải của khăn bàn. Sau bữa ăn, ngâm khăn bàn vào nước lạnh trong 30 phút trước khi đem giặt (cách này cũng hiệu nghiệm cho quần áo).
Gột vết dơ của mồ hôi trên quần áo: Pha bốn muỗng ăn muối vào trong 750ml nuớc nóng, rồi nhúng miếng bọt biển vào trong dung dịch, chà lên vết dơ trên quần áo hay nhúng quần áo vào nước muối lạnh, sau đó giặt với nước xà-bông ấm rồi bỏ vào nước đem đun sôi có thể loại bỏ áo bị dính máu.
**Chăm sóc cá nhân**
Làm kem đánh răng: Trộn một phần muối với hai phần baking soda. Dùng bàn chải đáng răng chà hỗn hợp lên răng giống như thường lệ. Bạn cũng có thể súc miệng bằng dung dịch nước muối hoặc dùng nước muối để làm sạch răng giả.
Làm nước súc miệng: Pha môt phần muối và một phần baking soda vào trong nước sẽ giúp làm mất mùi hôi miệng.
Trị các bệnh về miệng: Nếu miệng bị loét, hãy súc miệng với nước muối ấm nhiều lần trong ngày.
Trị vết muỗi cắn: Vã nước muối lên chỗ muỗi đốt cho đỡ ngứa. Có thể dùng cao dán gồm muối trôn với dầu ô liu cũng hiệu nghiệm.
Trị viêm họng: Thường xuyên súc miệng với nước pha muối.
**Làm đẹp bằng muối**
Tẩy tế bào chết bằng muối biển: Đây là phương pháp tự nhiên và an toàn cho da, đồng thời làm mịn da khô và đem lại cho bạn cảm giác mềm mại tuyệt vời. Để tẩy tế bào chết bạn thực hiện như sau: Trộn 1/4 chén muối với 1/2 đến 3/4 chén dầu hạnh nhân, dầu vừng.
Mặt nạ từ muốn biển: Đây là loại mặt nạ rất hữu ích cho làn da dễ bị nhờn hoặc mụn trứng cá vì nó có tác dụng giảm viêm, cân bằng lượng dầu trên da và chữa những vết mụn. Để đắp mặt nạ muối biển bạn chỉ cần hòa tan muối vào nước theo tỉ lệ 1:3 rồi trộn với 3 muỗng cà phê mật ong nguyên chất tinh khiết. Sau đó, đắp mặt nạ và chờ trong vòng 15 phút rồi rửa sạch lại bằng nước ấm.
Muối biển dùng để tẩy rửa cơ thể rất tốt. Chúng giúp loại bỏ các tạp chất dính trên da bạn suốt một ngày dài làm việc mệt mỏi, giúp cơ thể thư giãn và cảm thấy nhẹ nhõm. Hãy cho một ít muối biển vào bồn tắm của bạn, thêm một ít tinh dầu thơm và ngâm mình trong bồn khoảng 20-30 phút. Muối biển sẽ làm ẩm da của bạn, giúp loại bỏ độc tố và bụi bẩn trên cơ thể.
**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/) **- Đa khoa Hạng I Thành phố Hồ Chí Minh

## Nước gạo tốt cho da

Hơn nữa, nước gạo chứa nhiều vitamin và khoáng chất thiết yếu, trong đó làm sáng và mềm da. Dưới đây là cách dùng nước gạo để đạt hiệu quả tốt, theo boldsky.
**Làm nước hoa hồng**
Dùng nước gạo thoa lên da như nước hoa hồng có tác dụng thu nhỏ lỗ chân lông và làm sáng da. Nhúng một miếng bông vào nước gạo rồi thoa lên da. Chờ 15 phút đến khi thấy da chặt và tróc cám gạo ra, rửa sạch bằng nước lạnh.
**Làm sữa rửa mặt**
Nước gạo có hiệu quả trong việc loại bỏ sự tích tụ bụi bẩn trên da, mà không gây kích ứng da. Trộn nước gạo nấu chín với vài giọt tinh dầu và ½ chén nước. Rửa sạch khuôn mặt bằng loại hỗn hợp này. Sau đó, rửa sạch với nước lạnh và sau đó lau khô.
**Làm thuốc trị mụn**
Nước gạo có đặc tính làm loại bỏ chất bẩn bị đọng từ các lớp da, giảm sản xuất bã nhờn và làm dịu viêm. Trộn một muỗng canh nước gạo lên men với vài giọt nước cốt chanh và 5 giọt tinh dầu cây trà. Sử dụng một miếng bông, thoa hỗn hợp lên da. Chờ cho đến khi nó khô và sau đó rửa sạch.
**Mặt nạ chống lão hóa**
Mặt nạ bằng nước gạo chứa phức hợp vitamin B được gọi là "inositol". Hợp chất này làm chậm quá trình lão hóa của da, thúc đẩy tái tạo tế bào và kích thích lưu thông máu, từ đó cung cấp cho làn da sáng rạng rỡ. Lấy một muỗng canh nước gạo lên men, trộn với một nhúm bột nghệ, thêm vài giọt nước cốt chanh. Trộn thành bột nhão. Áp dụng nó lên mặt và cổ. Chờ 30 phút và sau đó rửa sạch với nước lạnh.
**Tẩy tế bào chết**
Nước gạo chứa axit ferulic có thể làm tróc tế bào da chết và bảo vệ da chống lại các gốc tự do. Lấy một muỗng canh nước gạo trộn một thìa sữa chua và một vài giọt dầu hạnh nhân. Thoa hỗn hợp này lên khuôn mặt, để trong 30 phút rồi rửa sạch.
**Chữa chàm**
Nước gạo có thể làm việc kỳ diệu trên da bị chàm. Ngâm một chiếc khăn sạch trong nước gạo tươi. Nhẹ nhàng thoa nó trên các khu vực bị ảnh hưởng. Sau 15 phút, rửa sạch bằng nước lạnh. Lặp lại thường xuyên nếu có thời gian.
**Giúp tóc bóng**
Không chỉ giúp mang lại làn da đẹp, nước gạo còn mang lại cuộc cách mạng hóa cho mái tóc. Trộn nước gạo với vài giọt tinh dầu hoa oải hương và hương thảo. Sau khi gội đầu sạch, dùng hỗn hợp này thoa lên tóc như dầu xả. Mát xa tóc trong 5 phút và sau đó xả lại bằng nước sạch. Tóc của bạn sẽ trở nên sáng bóng.
**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/) **- Đa khoa Hạng I Thành phố Hồ Chí Minh

## Lý do vì sao bạn bị sưng phù ở bắp chân

Kết quả là bạn sẽ bị phù ở tay, ngón tay, mặt và bụng. Cuối cùng cẳng chân cũng sẽ chịu ảnh hưởng. Trọng lực sẽ kéo lượng nước đó xuống dưới, và chúng sẽ có ở chân, mắt cá nhân và bắp chân.
Nếu bạn nhận thấy mìng bị sưng phù, tác nhân có thể là chế độ ăn mặn. Tuy nhiên một số thói quen tinh vi hơn cũng có thể là nguyên do. Chúng ta sẽ tìm hiểu một số lý do và cách khắc phục.
**Bạn thường hay ăn hàng**
Bạn càng ăn ngoài nhiều thay vì nấu cơm ở nhà thì càng có nguy cơ bị phù. Trung bình các bữa ăn nhà hàng chứa khoảng 2.300 mg muối, bằng với lượng muối khuyến nghị ăn trong một ngày của FDA – khoảng một thìa cà phê muối.
Bởi vì cơ thể con người là một thể là một thể thống nhất, bạn có uống rất nhiều nước hoặc uống những chất lợi tiểu như cà phê hoặc trà cũng không làm chứng phù biến mất. Bạn phải đợi đến khi triệu chứng hết đi. Thận cần 24 đến 48 tiếng để xử lý bữa ăn mặn và phụ thuộc lượng muối bạn hấp thu.
**Bạn ăn nhiều thức ăn đã qua xử lý**
Trung bình người Mỹ hấp thụ 3.400 mg muối một ngày, hơn 75% lượng muối từ khẩu phần đến từ thức ăn chế biến sẵn. Vậy nên trong trường hợp bạn không cho thêm muối vào thức ăn thì muối có khả năng cũng đến từ những thức ăn chế biến sẵn mà bạn ăn hàng ngày, bao gồm thực phẩm có vẻ lành mạnh chẳng hạn nước sốt salad hoặc súp đóng hộp. 
Để ngăn ngừa ăn quá nhiều muối, hãy bắt đầu việc tự làm nước sốt salad và súp để kiểm soát lượng muối. Bạn cũng có thể chú ý đến nhãn dinh dưỡng trên thực phẩm đóng gói để loại trừ những loại có 650mg muối hoặc hơn ra khỏi khẩu phần.
**Bạn ngồi quá nhiều hoặc đứng quá nhiều hàng ngày**
Tính chất công việc càng tĩnh thì càng nhiều chất lỏng dồn vào chân. Những người làm bàn giấy nên đặt ra báo thức cho khung thời gian giãn cơ và đi bộ vài vòng cứ mỗi một hoặc hai tiếng để cải thiện máu lưu thông. Và nên nhớ nghỉ ngơi thường xuyên nếu bạn hay phải đi công tác bằng ô tô.
Nếu một ngày đi làm không cho phép bạn vận động giữa giờ nhiều, đó cũng là tác nhân gây tích mỡ vùng dưới cơ thể. 
Có thể thử tất chân có tác dụng nén để giúp hệ tuần hoàn đưa máu trở lại cơ thể. Một cách khác dễ hơn là thỉnh thoảng nâng chân lên dù chỉ một chút, chẳng hạn đặt một chiếc ghế nhỏ dưới gầm bàn làm việc, thỉnh thoảng gác chân lên.
**Bạn đi máy bay**
Bên cạnh việc bạn bị ‘nhồi’ vào một không gian hẹp và không thể di chuyển nhiều, thay đổi áp suất cabin có thể để nhiều chất lỏng từ động mạch và tĩnh mạch vào mô. Nếu có thể thì hãy di chuyển giữa các lối đi lại. Tim sẽ bơm máu nhanh hơn và các mạch máu và cơ chân sẽ khó co lại hơn.
**Bạn có vấn đề về sức khỏe khác**
Sưng phù có thể là một triệu chứng của những bệnh nghiêm trọng hơn tạo huyết khối tĩnh mạch sâu. Đây gọi là sự hình thành cục máu ở một trong những tĩnh mạch sâu của cơ thể. Nếu khối máu vỡ ra nó có thể chặn máu chảy về phổi, gây ra huyết tắc phổi tiềm tàng có thể gây tử vong. Thông thường vấn đề này gây ra sưng chân không đối xứng nhưng không phải lúc nào cũng vậy. Ngồi quá nhiều, gần đây mới được phẫu thuật, hút thuốc và một số loại thuốc như thuốc tránh thai, đều có thể khiến bạn có nguy cơ có cục máu đông.
Một trong như vấn đề sức khỏe gây ra phù chân là bệnh tim. Khi cơ chế bơm máu của tim không hoạt động hết 100%, nó khiến chất dịch tụ lại ở chân. Những người có vấn đề về hệ tuần hoàn thì tĩnh mạch không co giãn như bình thường, chúng không bơm máu về tim đủ nhanh.
Nếu bạn nghi ngờ mình có một trong số những vấn đề trên, gặp bác sĩ để chẩn đoán và điều trị
**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/) **- Đa khoa Hạng I Thành phố Hồ Chí Minh

## Những thói quen không ngờ khiến não teo tóp

  * [Ăn quá nhiều đường](https://bvnguyentriphuong.com.vn/kien-thuc-cho-nguoi-benh/nhung-thoi-quen-khong-ngo-khien-nao-teo-top#n-qu-nhiu-ng)
  * [Đeo những vật dụng gây khó chịu khi ngủ](https://bvnguyentriphuong.com.vn/kien-thuc-cho-nguoi-benh/nhung-thoi-quen-khong-ngo-khien-nao-teo-top#eo-nhng-vt-dng-gy-kh-chu-khi-ng)


Bộ não là phần quan trọng nhất của cơ thể giúp kiểm soát các hoạt động và phản xạ của cơ thể. Để não bộ được khỏe mạnh, bạn cần tránh những thói quen xấu có thể gây ảnh hưởng tới não dưới đây.
## **Bỏ bữa sáng**
Bữa sáng là bữa đầu tiên trong ngày. Bạn cần có bữa sáng đủ dinh dưỡng và không bao giờ được bỏ bữa.
## **Ăn quá nhiều**
Ăn nhiều hơn nhu cầu cần thiết của cơ thể được gọi là ăn quá nhiều. Thói quen này rất nguy hiểm vì nó có thể làm tăng nguy cơ mắc một số bệnh nghiêm trọng gồm béo phì. Khi bạn bị thừa cân, não không nhận đủ các dưỡng chất cần thiếtgiúp não phát triển và khỏe mạnh.
## **Ngủ muộn**
Cơ thể và trí não của bạn cần được nghỉ ngơi ít nhất 6-7 giờ mỗi ngày. Ngủ muộn hàng ngày có thể gây hại cho cơ thể, đặc biệt là não. Khi bạn ngủ đủ, não bạn được nghỉ ngơi và điều này là rất quan trọng để phục hồi các tế bào bị tổn thương của cơ thể. Bạn cần duy trì thói quen ngủ sớm và dậy sớm.
## **Ăn quá nhiều đường**
Đường có nhiều thành phần gây hại, có thể gây các rối loạn liên quan tới tim.Ăn quá nhiều đường là một trong những thói quen gây tổn thương cho não bạn nên tránh. Hấp thu nhiều đường có thể gây bệnh tiểu đường và nhiều bệnh khác.
## **Đeo những vật dụng gây khó chịu khi ngủ**
Bạn không nên đeo cà vạt, tất, khăn hoặc những vật tương tự khác khi ngủ vì nó có thể làm ảnh hưởng tới việc cung cấp oxy cho cơ thể, đặc biệt là não. Thiếu oxy lên não gây thiếu dinh dưỡng và lo âu.
## **Hút thuốc**
Hút thuốc có thể gây hại cho sức khỏe não bộ. Cần ngừng hút thuốc để duy trì cơ thể khỏe mạnh.
## **Nói quá nhiều**
Nói quá nhiều nhất là khi bị bệnh gây lo âu, mệt mỏi, kết quả là khiến tâm trí bất an. Hãy nói ít hơn để não được nghỉ ngơi và tận hưởng sự cân bằng cuộc sống. Nói ít hơn, bạn sẽ thấy nhiều thay đổi xung quanh.
## **Mất nước**
Mất nước gây ra tình trạng thiếu nước trong cơ thể và nó cũng có thể gây ảnh hưởng tới não và hoạt động của não. Uống đủ nước và duy trì độ ẩm thích hợp để não không bị tổn thương.
**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/) **- Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [Ăn quá nhiều đường](https://bvnguyentriphuong.com.vn/kien-thuc-cho-nguoi-benh/nhung-thoi-quen-khong-ngo-khien-nao-teo-top#n-qu-nhiu-ng)
  * [Đeo những vật dụng gây khó chịu khi ngủ](https://bvnguyentriphuong.com.vn/kien-thuc-cho-nguoi-benh/nhung-thoi-quen-khong-ngo-khien-nao-teo-top#eo-nhng-vt-dng-gy-kh-chu-khi-ng)



## Nguyên nhân khiến bạn luôn cảm thấy đói

**1. Bạn đã nạp quá nhiều carbohydrate**
Ăn một bữa giàu carbohydrate vào buổi tối hôm trước có thể là một nguyên nhân khiến bạn luôn cảm thấy đói cồn cào vào ngày hôm sau, thậm chí sau cả khi vừa đánh chén thứ gì đó. Lí do vì, khi chúng ta nạp quá nhiều carbohydrate trong một lần ăn, chúng được hấp thu nhanh chóng vào cơ thể dưới dạng các loại đường. Việc tăng nồng độ các loại đường, đặc biệt là glucose, trong máu dẫn đến việc bùng phát sản sinh insulin, hormone kích thích các tế bào của chúng ta thâu tóm glucose.
Khi tất cả đường bị loại bỏ nhanh chóng khỏi máu, nó kích hoạt cơn đói và cảm giác thèm thực phẩm carbohydrate hơn nữa. Bạn có thể bất ngờ tỉnh giấc vào ban đêm với cơn đói cồn cào nếu điều đó xảy ra.
Hãy nghĩ đến khoai lang, gạo lức ăn kèm một khẩu phần protein hợp lý như một miếng cá hoặc thịt gà, cùng một khẩu phần rau quả không chứa tinh bột như súp lơ hay các loại rau xanh khác. Chúng sẽ giúp carbohydrate được tiêu hóa và hấp thu chậm hơn, khiến bạn cảm thấy no lâu hơn và không gây ra sự tăng đột biến insulin làm giảm đường huyết của bạn.
**2. Bạn cần ngủ thêm**
Ngủ không đủ giấc có thể tác động trực tiếp đến việc chúng ta cảm thấy đói đến mức nào và chúng ta ăn bao nhiêu. Các nhà nghiên cứu phát hiện, thời lượng ngủ quá ít làm giảm lượng hoóc môn ức chế cơn đói leptin và làm tăng lượng hoóc môn kích thích cơn đói ghrelin. Đây là lí do tại sao ngủ ít cũng có thể dẫn đến tình trạng tăng cân.
Trong trường hợp này, bạn cần nạp thêm magiê để giúp thư giãn các cơ, có thể giúp chúng ta có giấc ngủ thư thái và đủ giấc.
**3. Bạn đang khát**
Đôi khi, cơn khát có thể thực sự bị nhầm lẫn là cơn đói. Chúng ta cảm thấy mình vô cùng thèm thứ gì đó và diễn dịch nó là cơn đói, trong khi tất cả những gì chúng ta cần chỉ là một hoặc 2 cốc nước.
Lí do vì, nước cũng rất cần cho các tế bào của chúng ta sử dụng các chất dinh dưỡng hấp thu từ thức ăn. Việc thiếu chất dinh dưỡng sẵn có khiến cơ thể của chúng ta thèm nhiều thức ăn hơn. Đây chính là lí do bạn cần phải đảm bảo rằng bản thân uống nước khắp cả ngày và không chỉ khi xuất hiện cảm giác thèm.
Uống nước giữa các bữa ăn nhìn chung cũng khiến chúng ta cảm thấy no hơn và có thể giúp kiểm soát sự thèm ăn của mình. Tuy nhiên, điều quan trọng là bạn không nên uống nhiều nước ngay trước, trong và sau bữa ăn vì việc đó hòa loãng các dịch tiêu hóa và có thể tác động tiêu cực đến quá trình tiêu hóa của bạn.
**4. Bạn đang trong chu kỳ kinh nguyệt**
Các nhà nghiên cứu phát hiện, sự ngon miệng và lượng thực phẩm hấp thu của một người phụ nữ tăng lên trong nửa sau chu kỳ kinh nguyệt, chẳng hạn như sau thời điển rụng trứng và trong khoảng thời gian dẫn tới hành kinh.
Để giúp cân bằng đường huyết và kiểm soát sự thèm ăn trong giai đoạn này, điều thiết yếu là người phụ nữ cần tập trung ăn các thực phẩm giàu protein vào mỗi bữa như cá, thịt, trứng, các loại hạt và đậu, đồng thời giảm thiểu việc hấp thu các loại carbohydrate và đường đã qua xử lý và tinh chế. Ngoài ra, do caffeine và chất cồn cũng có thể tác động rất lớn đến sự cân bằng hoóc môn, nên người phụ nữ cần tránh thu nạp các loại đồ uống này tới mức tối đa.
**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/) **- Đa khoa Hạng I Thành phố Hồ Chí Minh

## Sổ sức khỏe điện tử trong Ứng dụng VNeID

Sổ sức khỏe điện tử VNeID là một tiện ích của ứng dụng VNeID được thiết kế để lưu trữ và quản lý thông tin sức khỏe cá nhân của công dân Việt Nam. Đây là một bước tiến quan trọng trong việc chuyển đổi số trong lĩnh vực y tế, giúp tiết kiệm chi phí và nâng cao hiệu quả quản lý sức khỏe.
Tiện ích sổ sức khỏe điện tử (SKĐT) VNeID được xây dựng bởi Bộ công an phối hợp với Bộ Y tế, BHXH Việt Nam và UBND các địa phương... tích hợp dữ liệu từ Cơ sở dữ liệu quốc gia về bảo hiểm y tế (BHYT), giúp thuận tiện hơn trong việc quản lý và thanh quyết toán chi phí khám, chữa bệnh. Đây là một phần trong nỗ lực số hóa của chính phủ để cải thiện trải nghiệm khám chữa bệnh và giảm thiểu thủ tục giấy tờ.
Căn cứ theo Quyết định số 2733/QĐ-BYT của Bộ Y tế hướng dẫn thí điểm triển khai sổ sức khỏe điện tử trên ứng dụng VNeID, sổ SKĐT VNeID có giá trị tương đương với sổ giấy và có thể được dùng thay thế sổ giấy khi người dân đi khám chữa bệnh tại các cơ sở y tế, cơ sở khám chữa bệnh công lập và tư nhân, bao gồm cả hình thức khám chữa bệnh ngoại trú, nội trú và khám từ xa.
**Những lợi ích khi sử dụng Sổ sức khỏe điện tử VNeID**
Sử dụng Sổ SKĐT VNeID sẽ giúp mang lại nhiều tiện ích cho người dân, giúp cải thiện trải nghiệm khám chữa bệnh và quản lý sức khỏe cá nhân. 
(1) Lưu trữ thông tin hồ sơ sức khỏe cá nhân toàn diện: Bao gồm các thông tin cá nhân và lịch sử khám chữa bệnh, tiền sử mắc bệnh, tiêm chủng, dị ứng, kết quả xét nghiệm và tóm tắt bệnh án... Điều này sẽ giúp người dân dễ dàng theo dõi và quản lý hồ sơ sức khỏe của mình.
(2) Tiết kiệm chi phí và thời gian: Giảm thiểu chi phí do in ấn, lưu trữ giấy tờ y tế và tiết kiệm thời gian cho cả bệnh nhân và nhân viên y tế trong việc tra cứu và cập nhật thông tin khám chữa bệnh.
(3) Thuận lợi hơn trong khám chữa bệnh: Người dân có thể xuất trình Sổ SKĐT VNeID thay cho sổ giấy khi đi khám chữa bệnh. Ngoài ra, bạn cũng có thể xuất trình giấy chuyển tuyến và giấy hẹn khám trên VNeID khi cần thiết.
(4) Tăng cường hiệu quả chẩn đoán và điều trị: Bác sĩ và nhân viên y tế có thể khai thác thông tin trong hồ sơ sức khỏe một cách nhanh chóng và chính xác, hỗ trợ chẩn đoán và điều trị hiệu quả hơn.
(5) An toàn và bảo mật thông tin: Thông tin sức khỏe cá nhân được bảo mật cao, chỉ có người dùng và các cơ sở y tế được phép truy cập.
Ngoài các thông tin về sức khỏe cá nhân, VNeID còn tích hợp các giấy tờ cá nhân khác như giấy tờ tùy thân, lý lịch tư pháp, giúp định danh công dân trên môi trường kỹ thuật số. Sổ sức khỏe điện tử VNeID không chỉ giúp người dân quản lý sức khỏe cá nhân một cách hiệu quả mà còn góp phần nâng cao chất lượng khám chữa bệnh, dịch vụ y tế.
**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/)** - Đa khoa Hạng I Thành phố Hồ Chí Minh

## Nguyên tắc giúp bạn ổn định với bệnh gout

Gout từng biết đến là căn bệnh của vua chúa, vì liên quan với sử dụng rượu và chế độ ăn phong phú, và bây giờ trở thành bệnh phổ biến. Gout là một loại viêm khớp gây ra do hàm lượng axit uric trong máu cao và có thể gây đau. Bệnh có thể tiến triển nhiều năm không triệu chứng cho tới khi có cơn gout bùng phát trong vài ngày hoặc vài tuần.
Nếu hàm lượng axit uric trong máu vẫn cao kéo dài, bệnh có thể tiến triển thành gout mạn tính với nhiều triệu chứng hơn. Sự tích lũy tinh thể axit uric cứng (hạt tophi) có thể được hình thành gây sưng và biến dạng. Cơn gout tái phát có thể phá hủy xương và sụn.
Gout là một bệnh kéo dài cả đời. Một đợt gout cấp có thể khiến bạn không đi được trong vài ngày. Nhưng nếu kiểm soát đúng cách, bạn có thể kiểm soát tốt hơn những ảnh hưởng của tình trạng đau kéo dài vài ngày và sống một cuộc sống khỏe mạnh.
Điều quan trọng là phải duy trì những thói quen lành mạnh và có những lựa chọn thông minh trong cuộc sống. Dưới đây là những thay đổi trong chế độ ăn và lối sống giúp bạn có thể “chung sống hòa bình” với gout.
**1. Không bỏ thuốc**
Dùng thuốc hạ axit uric đều đặn theo chỉ định. Để thuốc giảm đau ở nơi thuận tiện. Dùng thuốc ngay khi có dấu hiệu đỏ hoặc đau. Bạn cũng cần tìm hiểu các giải pháp kiểm soát đau.
**2. Theo dõi hàm lượng axit uric**
Không bỏ lỡ những cuộc hẹn với bác sĩ. Kiểm tra hàm lượng axit uric máu. Kiểm soát những bệnh đồng mắc khác như tiểu đường, huyết áp cao...
**3. Thực hiện một số thay đổi trong chế độ ăn**
Ăn uống cân bằng. Lựa chọn thực phẩm sai có thể làm bệnh trầm trọng thêm. Hạn chế hấp thu những thực phẩm giàu purin như thịt, cá mòi, cá thu, sò, ốc, đậu xanh... Chúng làm tăng hàm lượng axit uric máu và làm tồi tệ thêm các triệu chứng bệnh gout.
Tránh carbohydrate tinh chế như bánh mì trắng, bánh quy. Tránh những loại nước trái cây nhân tạo và đồ uống có ga chứa nhiều fructose vì fructose làm tăng đáng kể hàm lượng axit uric máu. Duy trì chế độ ăn lành mạnh chứa ít mỡ. Sử dụng sữa và sữa đông ít béo.
Ăn nhiều thực phẩm giàu chất chống oxy hóa như nho, dứa, anh đào, quất... Chúng giúp loại bỏ axit uric và cũng phòng ngừa viêm khớp. Nghiên cứu chỉ ra rằng quả anh đào có thể giảm nguy cơ bị các đợt gout tấn công, đặc biệt khi được kết hợp với thuốc hạ axit uric allopurinol.
**4. Uống nhiều nước**
Uống ít nhất 8-10 cốc nước mỗi ngày giúp loại bỏ axit uric dư thừa ra khỏi cơ thể, và giảm nguy cơ hình thành tinh thể trong khớp, do vậy giảm nguy cơ cơn gout gây đau.
**5. Bỏ thuốc lá và rượu**
Cai thuốc lá và uống rượu vì cả hai thói quen này đều làm trầm trọng thêm các triệu chứng gout. Hút thuốc cản trở trao đổi chất của cơ thể. Cồn, đặc biệt là bia và rượu vang, có xu hướng làm tăng axit uric trong máu cao nhất. Sử dụng đồ uống chứa cồn cũng có thể dẫn tới tích tụ dịch.
**6. Tích cực hoạt động**
Lối sống ít vận động là một trong những yếu tố chủ yếu chịu trách nhiệm về bệnh gout. Tập luyện thường xuyên không chỉ có lợi cho cơ thể mà cả tâm trí bạn và có thể giúp kiểm soát tình trạng bệnh này. Nó giúp loại bỏ những bệnh lối sống đồng mắc như cholesterol cao, tiểu đường, huyết áp cao, v.v…
**7. Duy trì cân nặng lành mạnh**
Duy trì cân nặng ở mức vừa phải. Nếu bạn bị thừa cân hoặc béo phì thì cần giảm cân. Nhưng không nên tuân theo chế độ ăn hà khắc. Giảm cân nhanh chóng có thể gây đa xê-tôn và gây cơn gout. Vì vậy cần giảm cân hợp lý và dần dần.
**8. Tránh các tác nhân**
Tránh xa những thực phẩm có thể gây cơn gout. Bệnh nhân gout nên tránh cà chua. Các nhà nghiên cứu thấy rằng đó là tác nhân phổ biến hàng thứ 4 gây cơn gout sau hải sản, rượu và thịt đỏ.
Một số thuốc chống tăng huyết áp và thuốc lợi tiểu gây mất kali có thể làm tăng hàm lượng axit uric. Tránh dùng những thuốc này. Nếu đang phải dùng, hãy hỏi bác sĩ về lựa chọn thay thế. Những cơn gout cấp thường xảy ra chủ yếu vào buổi tối. Có thể suy đoán rằng mất nước ban đêm, nhiệt độ cơ thể giảm hoặc giảm hàm lượng cortisol ban đêm có thể là yếu tố góp phần.
Các phương pháp phòng bệnh, đặc biệt vào buổi tối có thể hiệu quả hơn trong việc phòng ngừa cơn gout bùng phát.
**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/) **- Đa khoa Hạng I Thành phố Hồ Chí Minh

## Hiến xác và hiến tạng: Nghĩa cử cao đẹp, nhưng không giống nhau

  * [Hiến tạng – Tặng lại sự sống](https://bvnguyentriphuong.com.vn/kien-thuc-cho-nguoi-benh/hien-xac-va-hien-tang-nghia-cu-cao-dep-nhung-khong-giong-nhau#hin-tng-tng-li-s-sng)
  * [Hiến xác – Đóng góp cho y học](https://bvnguyentriphuong.com.vn/kien-thuc-cho-nguoi-benh/hien-xac-va-hien-tang-nghia-cu-cao-dep-nhung-khong-giong-nhau#hin-xc-ng-gp-cho-y-hc)
  * [Điểm chung: Sự hy sinh thầm lặng](https://bvnguyentriphuong.com.vn/kien-thuc-cho-nguoi-benh/hien-xac-va-hien-tang-nghia-cu-cao-dep-nhung-khong-giong-nhau#im-chung-s-hy-sinh-thm-lng)


_Trong xã hội hiện đại, khi y học ngày càng phát triển, cụm từ “hiến xác” và “hiến tạng” đã trở nên quen thuộc hơn với nhiều người. Tuy nhiên, không ít người vẫn nhầm lẫn giữa hai khái niệm này. Cả hai đều là những hành động nhân văn, thể hiện tấm lòng cao cả, nhưng chúng có những mục đích và ý nghĩa rất khác nhau._
### **Hiến tạng – Tặng lại sự sống**
Hiến tạng là việc một người đồng ý cho đi các bộ phận trên cơ thể mình (như tim, gan, thận, phổi, giác mạc…) sau khi qua đời – hoặc trong một số trường hợp đặc biệt, có thể hiến khi còn sống – để cấy ghép cho người bệnh đang chờ đợi sự sống.
Ở Việt Nam, mỗi năm có hàng nghìn bệnh nhân suy tạng nằm chờ ghép, nhưng số người tình nguyện hiến tạng sau khi chết vẫn còn rất ít. Trong khi đó, một người chết não có thể cứu sống được từ 6 đến 8 người khác nhờ việc hiến tạng. Một nghĩa cử tưởng như đơn giản, nhưng lại mang lại cơ hội sống quý giá cho bao người.
### **Hiến xác – Đóng góp cho y học**
Khác với hiến tạng, hiến xác là việc hiến toàn bộ thi thể cho y học sau khi qua đời. Thi thể này sẽ được các trường đại học y hoặc viện nghiên cứu sử dụng để phục vụ cho việc giảng dạy, nghiên cứu, đào tạo sinh viên y khoa. Nhờ đó, các bác sĩ tương lai có cơ hội tiếp cận thực tế, học hỏi và nâng cao kỹ năng chuyên môn.
Người hiến xác không thể cứu sống ai như người hiến tạng, nhưng họ góp phần âm thầm đào tạo nên thế hệ bác sĩ giỏi, gián tiếp giúp cứu sống nhiều người trong tương lai.
### **Điểm chung: Sự hy sinh thầm lặng**
Dù hiến tạng hay hiến xác, cả hai hành động đều thể hiện tinh thần nhân văn sâu sắc, sẵn sàng cho đi vì lợi ích của cộng đồng và xã hội. Cả hai đều cần sự chuẩn bị kỹ càng, từ việc đăng ký tình nguyện đến sự đồng thuận của gia đình.
Tại Việt Nam, bạn có thể liên hệ với **[Trung tâm Điều phối quốc gia về ghép bộ phận cơ thể người](https://vnhot.vn/)** hoặc các để tìm hiểu và đăng ký hiến tạng, hiến xác.
**Hiện có 2 địa chỉ chính thức được phép đăng ký và phát hành thẻ hiến tạng tại Việt Nam để đáp ứng nguyện vọng đăng ký hiến tạng cứu người khi qua đời của người dân gồm:**
1. Đơn vị Điều phối ghép các bộ phận cơ thể người tại Bệnh viện Chợ Rẫy
Địa chỉ: 201B Nguyễn Chí Thanh Quận 5 TPHCM
Điện thoại: (84- 8) 3855 4137 xin số 1184 hoặc 1284
(84- 8) 3956 0139
Điện thoại 24/24: 0913 677 016
Email: dieuphoigheptangbvcr@gmail.com
https://www.choray.vn
2. Trung tâm điều phối quốc gia về ghép bộ phận cơ thể người
Địa chỉ: 40 Tràng Thi – Hà Nội
Điện thoại: +84 4 39386692
Điện thoại 24/24: 0915 060 550
Email: gheptang@vncchot.vn
<https://www.facebook.com/dieuphoigheptangvietnam>
### **Thay lời kết**
Hiến xác và hiến tạng – hai con đường khác nhau, nhưng cùng hướng tới một đích đến: sự sống và tri thức. Đó là món quà vô giá mà một con người có thể để lại cho đời, ngay cả khi đã nhắm mắt xuôi tay.
  * [Hiến tạng – Tặng lại sự sống](https://bvnguyentriphuong.com.vn/kien-thuc-cho-nguoi-benh/hien-xac-va-hien-tang-nghia-cu-cao-dep-nhung-khong-giong-nhau#hin-tng-tng-li-s-sng)
  * [Hiến xác – Đóng góp cho y học](https://bvnguyentriphuong.com.vn/kien-thuc-cho-nguoi-benh/hien-xac-va-hien-tang-nghia-cu-cao-dep-nhung-khong-giong-nhau#hin-xc-ng-gp-cho-y-hc)
  * [Điểm chung: Sự hy sinh thầm lặng](https://bvnguyentriphuong.com.vn/kien-thuc-cho-nguoi-benh/hien-xac-va-hien-tang-nghia-cu-cao-dep-nhung-khong-giong-nhau#im-chung-s-hy-sinh-thm-lng)



## 10 bí quyết chăm sóc sức khỏe đôi mắt

Theo Trung tâm Phòng chống Mù lòa Mỹ (PBA), tỉ lệ mắc bệnh về mắt tại quốc gia này đang tăng nhanh chóng. Mỗi năm có khoảng 50.000 người mắc bệnh, không phải do di truyền mà do chính con người gây ra.
10 khuyến cáo dưới đây được xem là đơn giản, dễ thực hiện và có hiệu quả tăng cường thị lực do PBA đề xuất.
**Nói không với mỡ và đồ ngọt**
Thực phẩm có hàm lượng mỡ cao như bánh mì kẹp thịt, thức ăn nhanh, khoai tây rán cũng như bánh kẹo và các loại thực phẩm giàu mỡ, đường, nhất là acid béo omega-6 được xem là thủ phạm gia tăng bệnh thoái hóa điểm vàng liên quan đến tuổi tác (ARMD).
**Tăng cường nhóm quả mọng**
Đặc biệt là quả việt quất (bluebery), bởi đây là trái cây giàu chất chống oxy hóa. Một cốc sữa chua bổ sung quả mọng ăn vào buổi sáng sẽ hạn chế nguy cơ mắc bệnh ARMD.
**Hành đỏ**
Thay vì dùng hành vàng, khi nấu nướng nên dùng hành đỏ. Bởi hành đỏ có chứa hàm lượng quercetin rất cao, chất chống oxy hóa có tác dụng bảo vệ mắt, giảm thiểu nguy cơ mắc bệnh đục thủy tinh thể.
**Bổ sung vitamin tổng hợp mỗi ngày**
Theo nhiều nghiên cứu, phụ nữ bổ sung vitamin C từ 10 năm trở lên sẽ giảm được tới 77% rủi ro mắc bệnh đục thủy tinh thể. Nên bổ sung vitamin tổng hợp và coi đây là thực đơn không thể thiếu trong chế độ ăn uống hàng ngày. Liều dùng thấp nhất 150mg vitamin C.
**Không nên để điều hòa chiếu thẳng vào mắt**
Khi đang lái xe, ngồi trong xe hoặc trong phòng không nên để cho luồng không khí từ máy điều hòa chiếu thẳng vào mắt. Người lái nếu phơi nhiễm nguồn khí lạnh này dài kỳ có thể dẫn đến trầy xước giác mạc, khô mắt và nhiều căn bệnh nan y khác.
**Nên đặt màn hình máy tính thấp hơn tầm nhìn của mắt**
Với vị trí này sẽ giảm căng thẳng cho mắt. Mắt luôn ở trạng thái nửa nhắm, nửa mở so với căng tròn, mở toàn bộ khi đặt ở vị trí cao hơn tầm nhìn của mắt và về lâu dài sẽ hạn chế hiện tượng gây kích thích, khô mắt.
**Mỗi tuần ăn hai bữa cá**
Cá là thực phẩm giàu acid béo omega-3, có tác dụng ngăn ngừa hội chứng khô mắt. Nếu không có điều kiện ăn cá thì nên bổ sung dầu cá để cấp thêm nguồn omega-3 cho cơ thể.
**Nên ăn nhiều khoai lang**
Khoai lang, nhất là khoai lang tím là nhóm thực phẩm giàu vitamin A, có tác dụng cải thiện tầm nhìn của mắt vào ban đêm.
**Tăng cường thực phẩm giàu lutein**
Giống như cá, mỗi tuần nên ăn hai bữa thực phẩm giàu lutein. Lutein có nhiều trong các loại thực vật rau xanh dạng lá như: rau cải, xà lách; hoặc trong các loại trái cây: cam, bắp cải, súp lơ và broccoli và trong lòng đỏ trứng gà. Trong cơ thể con người, lutein có nhiều ở mắt và cùng với những chất tương tự, có tên là carotenoid, tạo màu cho điểm vàng của mắt, giúp mắt sáng thêm và nhìn rõ đồ vật đặt trước mặt.
**Tránh xa thuốc lá**
Nếu đã trót hút và nghiện thì nên có kế hoạch bỏ càng sớm càng tốt vì thuốc lá là một nguyên nhân chính gây đục thủy tinh thể, tăng hội chứng khô mắt và bệnh tăng nhãn áp. Ngoài ra, hút thuốc còn gây ra nhiều chứng bệnh nan y, nhất là ung thư tim mạch và ảnh hưởng đến những người xung quanh như: người già, trẻ nhỏ và phụ nữ mang thai, bởi trong khói thuốc có chứa tới hàng trăm hóa chất độc hại khác nhau.

## Biện pháp dinh dưỡng ngăn rụng tóc

**Trứng:**
Thường xuyên dưỡng tóc với protein là vô cùng cần thiết nếu bạn muốn sở hữu mái tóc khỏe và dày. Với phương pháp dưỡng tóc bằng protein, nguyên liệu tuyệt vời nhất chính là trứng.
Cách 1: Dùng 1 hoặc 2 quả trứng gà (tùy theo độ dài của mái tóc) và đánh đều, thoa đều trứng lên tóc ướt trong 5 - 10 phút rồi xả lại với nước ấm và dầu gội. Dùng 2 - 3 lần/tuần.
Cách 2: Trộn đều lòng đỏ 1 quả trứng với 1 thìa bất cứ loại tinh dầu dành cho tóc nào bạn ưa thích và 2 thìa nước. Dùng hỗn hợp này massage trên toàn bộ da đầu. Thực hiện 1 lần/tuần.
**Lô hội:**
Ép lấy gel từ 1 hoặc 2 lá lô hội tươi và chà xát gel lô hội lên da đầu, để trong nửa giờ trước khi xả lại với nước ấm, gel lô hội giúp chân tóc chắc khỏe hơn. Bạn cũng có thể trộn gel lô hội với 1 quả trứng và 1 ít rượu trắng, thoa hỗn hợp lên da đầu và sau 10 - 15 phút, gội lại với dầu gội. Bạn cũng có thể uống 1 thìa nước ép lô hội mỗi ngày trước bữa ăn sáng để có thể có được mái tóc suôn mượt, óng ả và làn da mịn màng hơn.
**Quả bơ:**
Cách 1: Lấy 1/2 quả bơ chín và 1 quả chuối nghiền nát và dùng hỗn hợp đó massage da đầu rồi ủ trong nửa giờ, xả sạch lại tóc với dầu gội và dầu xả. Khi tóc khô, bạn sẽ nhận thấy mái tóc trở nên thật sự mềm mại, bóng mượt và khỏe khoắn.
Cách 2: Dùng 2 thìa dầu ô liu trộn cùng 1 quả bơ chín nghiền nát. Thoa hỗn hợp lên tóc đã được gội sạch và ủ trong 20 phút. Cuối cùng xả sạch lại hoàn toàn và sử dụng thêm 1 ít dầu xả.
**Nước cam:**
Cam có thể được sử dụng để loại bỏ gàu cũng như dầu thừa trên da đầu và làm cho tóc chắc khỏe hơn. Lấy vỏ cam nghiền và ngâm với nước để tạo thành 1 hỗn hợp sền sệt. Sử dụng hỗn hợp này như 1 loại mặt nạ dưỡng tóc 1 lần/tuần. Bạn cũng có thể trộn đều 1 lượng bằng nhau nước cam và nước táo, thoa đều lên tóc, để nửa giờ rồi xả sạch với nước. Làm 1 lần/tuần và bạn sẽ sớm cảm nhận được 1 mái tóc dày hơn, suôn mượt hơn.
**Dầu dừa:**
Đun ấm dầu dừa và dùng đầu ngón tay massage da đầu theo chuyển động tròn sẽ giúp tăng lưu thông tuần hoàn máu - một yếu tố quan trọng thúc đẩy mọc tóc. Sau đó ủ tóc bằng 1 chiếc khăn đã được làm ẩm với nước ấm trong nửa giờ rồi gội sạch lại tóc với dầu gội như bình thường. Thực hiện 1 lần/tuần để có thể được tận hưởng mái tóc dày dặn, sáng bóng, suôn mượt.
**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/) **- Đa khoa Hạng I Thành phố Hồ Chí Minh

## 5 Điều không ngờ gây hại cho tim của bạn

  * [1. Ngồi hàng giờ trước tivi](https://bvnguyentriphuong.com.vn/kien-thuc-cho-nguoi-benh/5-dieu-khong-ngo-gay-hai-cho-tim-cua-ban#1-ngi-hng-gi-trc-tivi)
  * [3. Không dùng chỉ nha khoa](https://bvnguyentriphuong.com.vn/kien-thuc-cho-nguoi-benh/5-dieu-khong-ngo-gay-hai-cho-tim-cua-ban#3-khng-dng-ch-nha-khoa)
  * [4. Không ăn trái cây và rau](https://bvnguyentriphuong.com.vn/kien-thuc-cho-nguoi-benh/5-dieu-khong-ngo-gay-hai-cho-tim-cua-ban#4-khng-n-tri-cy-v-rau)
  * [5. Uống nhiều rượu](https://bvnguyentriphuong.com.vn/kien-thuc-cho-nguoi-benh/5-dieu-khong-ngo-gay-hai-cho-tim-cua-ban#5-ung-nhiu-ru)


**Trái tim là cơ quan quan trọng nhất của cơ thể. Để có một trái tim khỏe mạnh bạn cần xây dựng một lối sống lành mạnh vì thế nếu bạn duy trì những thói quen không tốt dưới đây sẽ làm ảnh hưởng xấu đến cơ quan quan trọng này đấy:**
## **1. Ngồi hàng giờ trước tivi**
Ngay cả khi bạn tập thể dục đều đặn, nhưng nếu ngồi hàng giờ trước màn hình tivi vẫn có thể dẫn đến nguy cơ bị đau tim và đột quỵ. Nguyên nhân là do sự thiếu vận động trong thời gian dài sẽ làm ảnh hưởng tiêu cực đến mức độ mỡ và đường trong máu. Vì vậy hãy đứng dậy và di chuyển ít nhất 15 phút một lần.
## **2. Ngủ ngáy**
Thói quen ngủ đêm gây phiền nhiễu này có thể là dấu hiệu của chứng ngưng thở khi ngủ, có liên quan đến huyết áp cao, loạn nhịp tim, đột quỵ hay suy tim. Khi thường xuyên gặp trường hợp này bạn nên đi khám tại chuyên khoa tai mũi họng hoặc tim mạch để hỏi ý kiến bác sĩ và kiểm tra chứng ngưng thở khi ngủ để có biện pháp xử trí giúp bạn nghỉ ngơi tốt hơn.
## **3. Không dùng chỉ nha khoa**
Khoa học đã chỉ ra rằng bệnh nướu răng và bệnh tim có liên quan chặt chẽ với nhau, đặc biệt các trường hợp bệnh nướu răng gây mất răng. Nguyên nhân là do vi khuẩn gây nướu răng có thể xâm nhập vào máu, gây cục máu đông ở động mạch chủ dẫn đến nguy cơ nhồi máu cơ tim ở những người mắc bệnh nướu gây mất răng cao hơn so với những người không mắc bệnh răng. Bạn nên vệ sinh răng miệng thường xuyên bằng chỉ nha khoa và kiểm tra với nha sĩ định kỳ.
## **4. Không ăn trái cây và rau**
Trái cây và rau là thực phẩm rất tốt cho sức khỏe tim mạch. Nhiều nghiên cứu đã chỉ ra rằng những người ăn hơn 5 bữa trái cây và rau mỗi ngày có nguy cơ mắc bệnh tim và đột quỵ thấp hơn khoảng 20% so với những người ăn chúng ít hơn 3 bữa mỗi ngày. Vì vậy hãy thêm rau và trái cây vào tất cả các bữa ăn chính và ăn vặt của bạn. Ngoài ra, cách chế biến thành các món salad yêu thích cũng giúp bạn ăn được nhiều rau hơn.
## **5. Uống nhiều rượu**
Bạn đã từng nghe uống rượu vừa phải có thể tốt cho sức khỏe tim mạch tuy nhiên khi uống quá nhiều có thể dẫn đến nguy cơ cao huyết áp, mỡ máu cao và suy tim. Phụ nữ không uống nhiều hơn một ly mỗi ngày, và nam giới không quá hai ly một ngày. Cụ thể, đối với bia, một cốc tương đương 355 ml, một ly rượu thường là 148 ml, rượu mạnh là 45 ml.
**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/) **- Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [1. Ngồi hàng giờ trước tivi](https://bvnguyentriphuong.com.vn/kien-thuc-cho-nguoi-benh/5-dieu-khong-ngo-gay-hai-cho-tim-cua-ban#1-ngi-hng-gi-trc-tivi)
  * [3. Không dùng chỉ nha khoa](https://bvnguyentriphuong.com.vn/kien-thuc-cho-nguoi-benh/5-dieu-khong-ngo-gay-hai-cho-tim-cua-ban#3-khng-dng-ch-nha-khoa)
  * [4. Không ăn trái cây và rau](https://bvnguyentriphuong.com.vn/kien-thuc-cho-nguoi-benh/5-dieu-khong-ngo-gay-hai-cho-tim-cua-ban#4-khng-n-tri-cy-v-rau)
  * [5. Uống nhiều rượu](https://bvnguyentriphuong.com.vn/kien-thuc-cho-nguoi-benh/5-dieu-khong-ngo-gay-hai-cho-tim-cua-ban#5-ung-nhiu-ru)



## Phòng tránh ung thư bằng các cách tự nhiên

_Không uống nước quá nóng_ : Thói quen uống trà, cà phê nóng bốc khói có thể làm tăng gấp đôi nguy cơ gây ung thư vòm họng do nước nóng làm tổn thương đến các tế bào ở cơ quan này.
_Nên ăn chuối_ : Theo một nghiên cứu của Viện Kardinska (Thụy Điển) trên 61.000 phụ nữ, những người ăn chuối 4-6 lần/tuần sẽ giảm được nửa nguy cơ ung thư gan so với những người không ăn. Đó là vì chuối giàu chất chống ôxy hóa fenolics, giúp chống ung thư.
Một số loại rau củ khác như cà rốt, củ cải cũng có những tác dụng tương tự.
_Nên ăn nghệ_ : Các nghiên cứu ở Mỹ cho thấy, bột nghệ chứa hoạt chất curcumin giúp ngăn ngừa các tế bào ung thư vú phát tán. Curcumin và phenethyl isothiocyanate (PEITC), một chất tự nhiên có trong nghệ và rau họ cải, làm chậm sự phát triển của các tế bào ung thư tuyến tiền liệt.
_Tập thể dục 30 phút/ngày_ : Thể dục nhẹ nhàng khoảng 30 phút mỗi ngày và ít nhất 5 ngày/tuần là chiến thuật chính bảo vệ bạn khỏi ung thư. Theo một nghiên cứu tại Scotland, thể dục làm giảm một nửa khả năng nhiễm ung thư ruột kết.
Phụ nữ tập thể dục thường xuyên có thể giảm được 1/3 nguy cơ ung thư nhờ điều hòa mức hoóc môn có liên quan đến sự phát triển bệnh này, thay đổi tốc độ tiêu hóa thức ăn trong ruột.
_Cắt giảm mỡ thừa_ : Khi bạn béo hoặc thừa cân so với chuẩn trọng lượng (BMI), bạn có nguy cơ nhiễm các loại ung thư dạ dày, gan, thận và thực quản, ung thư tử cung, buồng trứng và ung thư vú sau thời mãn kinh. Béo phì là một trong những nguyên nhân lớn nhất gây ung thư đối với những người không hút thuốc lá. Hãy cố đạt mức chuẩn trọng lượng BMI dưới 25.
_Ăn sốt cà chua_ : Trong cà chua có lycopene, một hoạt chất chống ôxy hóa có tác dụng ngăn nhiều loại ung thư. Chất này cũng được tìm thấy trong các loại quả ruột màu hồng như dưa hấu và nho hồng.
Sốt cà chua được xử lý nhiệt làm cơ thể dễ hấp thu lycopene hơn, điều này giải thích lý do nam giới ăn nhiều sốt cà chua, pizza, pasta có tỷ lệ mắc bệnh ung thư tuyến tiền liệt thấp.
_Theo dõi thói quen đại tiện_ : Thói quen này có thể giúp bạn nhận thấy những dấu hiệu ban đầu của bệnh ung thư đường ruột. Bất kỳ ai trên 50 tuổi có biểu hiện đại tiện bất thường kéo dài trong 4-6 tuần, có ra máu hoặc đau bụng đều nên đến cơ sở y tế kiểm tra chứ không nên tự ý dùng thuốc.
_Tận hưởng ánh nắng mặt trời:_ Nên để da tiếp nhận vitamin D hằng ngày một cách tự nhiên dưới ánh nắng ban mai để giảm 1/2 nguy cơ ung thư vú, ruột kết và buồng trứng. Việc đi dạo 10-15 phút trong ánh nắng nhẹ vài ngày trong tuần cũng tương đương với việc uống 400 mg vitamin D mỗi ngày. Tuy nhiên, cần tránh ánh nắng mặt trời từ 11 giờ sáng đến 3 giờ chiều; hoặc xoa kem chống nắng.
_Kiểm soát lượng protein_ : Thịt đỏ như thịt bò, lợn, cừu và các sản phẩm thịt đã qua chế biến công nghiệp (xúc xích, thịt hun khói …) sẽ làm tăng nguy cơ ung thư ruột. Các loại thịt trên kích thích quá trình sản xuất hợp chất N-nitroso (NOCs) - nguyên nhân gây ung thư trong động vật.
_Hấp rau xanh_ : Súp lơ xanh, giá, súp lơ trắng, bắp cải, củ cải rất giàu hoạt chất chống ung thư sulforaphane, có tác dụng kích hoạt enzyme trong gan để diệt các hoạt chất gây ung thư. Cách chế biến tốt nhất là hấp rau vì sulforaphane được giữ lại nhiều nhất khi nấu trong vòng 10 phút ở nhiệt độ 60 độ C, hoặc hấp trong vòng 4 phút đủ chín vừa.
_Không uống rượu say_ : Đồ uống có cồn làm tăng nguy cơ ung thư họng, gia tăng hàm lượng oestrogen gây ung thư vú.
_Theo dõi những biến chuyển trên da_ : Những thay đổi ở nốt ruồi, tàn nhang, sẹo có thể là dấu hiệu của ung thư da, vì vậy bạn nên kiểm tra toàn thân thường xuyên, trong đó đặc biệt chú ý đến vùng da dưới vú, lưng, da đầu, móng tay, ngón tay. Thường xuyên quan sát đôi chân (nơi ung thư da thường xuất hiện ở phụ nữ) và nhờ người khác kiểm tra lưng, thân, đầu, cổ.
_Hạ nhiệt lò nướng_ : Nướng thịt (thay vì rán) giúp giảm lượng calories trong thịt, nhưng nướng ở nhiệt độ cao trong thời gian dài sẽ sinh ra hợp chất heterocyclic amines (HCAs), có khả năng gây hại cho DNA, làm thay đổi cấu trúc tế bào và tăng khả năng ung thư. Vì vậy khi nướng thịt nên để nhỏ lửa như om.
Ướp thịt trước khi nướng để làm giảm đáng kể hàm lượng HCAs trong thịt. Việc lật thường xuyên cũng làm giảm khả năng hình thành HCAs.
_Thường xuyên ăn tỏi:_ Giúp phòng chống ung thư nhờ chất allyl sulphur. Nhưng việc nấu tỏi ở nhiệt độ cao lại làm giảm khả năng này.
_Bỏ hút thuốc_ : Khói thuốc có trên 60 chất sinh ung thư. Nhưng nếu ngừng hút hẳn, bạn có khả năng giảm được 1/2 nguy cơ ung thư phổi và giảm dần nguy cơ ung thư họng, thực quản, bàng quang, thận và tuyến tụy.
_Thường xuyên kiểm tra sức khỏe_ : Nếu bạn dưới 49 tuổi nên kiểm tra kính phết cổ tử cung sau mỗi 3 năm, và nếu bạn ở độ tuổi 50-64 thì nên kiểm tra định kỳ 5 năm/lần. Chụp X-quang vú để kiểm tra ung thư vú định kỳ 3 năm/lần trong độ tuổi 50-70.
_Thường xuyên đi khám răng_ : Giúp nhận ra những dấu hiệu sớm của ung thư miệng. Hãy đi khám ngay nếu bạn có một trong những triệu chứng sau trong vòng 3 tuần không giảm: sưng nhưng không đau, hoặc nổi u trong miệng, đau họng hoặc khó nuốt.
_Thận trọng với thực phẩm tăng đường máu_ : Nên cảnh giác với thức ăn có chỉ số GL cao (GL là một chỉ tiêu đo tốc độ tăng lượng đường trong máu). Đó là bánh mì trắng, mì ống, khoai tây chiên, khoai tây, bánh quy, bánh ngọt làm thải ra insuline gây ung thư. Nên ăn thực phẩm GL thấp như đậu, trái cây, rau và ngũ cốc nguyên hạt.
**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/) **- Đa khoa Hạng I Thành phố Hồ Chí Minh

## Phòng ngừa biến chứng động mạch vành ngay từ hôm nay

Bệnh động mạch vành dễ gây biến chứng nguy hiểm đe dọa tính mạng người bệnh vì vậy cần chủ động phòng ngừa biến chứng động mạch vành càng sớm càng tốt.
_**Kiểm soát trọng lượng cơ thể:** _Béo phì hay béo bụng là một yếu tố nguy cơ quan trọng của ĐMV. Điều cơ bản để đạt được và duy trì một trọng lượng cơ thể hợp lý khỏe mạnh là có một chế độ ăn lành mạnh và luyện tập thể lực đều đặn. Để có một trọng lượng cơ thể phù hợp, cần phải có sự cân bằng về năng lượng mà bệnh nhân ăn hoặc uống vào với năng lượng mà bệnh nhân tiêu hao qua các hoạt động thể lực. Để giảm cân, bệnh nhân cần phải tiêu hao năng lượng nhiều hơn qua các hoạt động thể lực và ăn ít năng lượng hơn.
_Kiểm soát tốt cân nặng ngừa biến chứng bệnh mạch vành_
**_Bỏ hút thuốc lá:_ **Ngừng hút thuốc lá là một yếu tố quan trọng nhất giúp bệnh nhân có thể làm giảm nguy cơ bị tái phát nhồi máu cơ tim. Hút thuốc lá làm giảm nồng độ oxy trong máu, làm tổn thương và suy yếu thành động mạch. Lợi ích của việc ngừng hút thuốc lá gần như đạt được tức thì. Ngay khi bệnh nhân ngừng hút thuốc, nguy cơ tái phát bệnh bắt đầu giảm. Sau 5 năm cai thuốc lá, nguy cơ bị nhồi máu cơ tim tái phát sẽ giảm một nửa so với trường hợp bệnh nhân tiếp tục hút thuốc. Các bệnh nhân nhồi máu cơ tim cấp cần đánh giá tiền sử hút thuốc lá và tư vấn cai thuốc lá hay tránh tái hút thuốc lá trước khi ra viện.
**_Kiểm soát huyết áp:_ **Cần kiểm soát huyết áp < 140/90mmHg (< 130/80mmHg ở bệnh nhân tiểu đường hay bệnh thận mạn tính) bằng thuốc và thay đổi lối sống. Thay đổi lối sống (giảm cân, thay đổi chế độ ăn, tăng hoạt động thể lực và ăn nhạt) nên thực hiện cho tất cả các bệnh nhân có huyết áp ≥ 120/80mmHg. Không nên dùng thuốc chẹn kênh canxi nhóm dihydropyridin có tác dụng ngắn để điều trị tăng huyết áp. Các bệnh nhân tăng huyết áp nên có một chế độ ăn ít muối và nhiều rau, hoa quả và các chế phẩm ít chất béo, cũng như có một chương trình tập thể dục đều đặn.
_**Điều trị đái tháo đường** :_ Kiểm soát chặt đường huyết bằng insulin hay thuốc hạ đường huyết uống và chế độ ăn để đạt HbA1C < 7%.
_Kiểm soát lượng cholesterol trong cơ thể giúp ngừa biến chứng động mạch vành_
**_Điều trị rối loạn lipid máu:_ **Nên khuyên các bệnh nhân ăn chế độ có chứa ít cholesterol, ít chất béo bão hòa, nhiều chất xơ hòa tan, nhiều rau và hoa quả. Các thuốc statin đã được chứng minh là biện pháp can thiệp bằng thuốc có hiệu quả nhất.
**_Hormon liệu pháp:_** Hormon liệu pháp với estrogen phối hợp với progestin không nên sử
dụng cho các bệnh nhân mới bị mãn kinh sau nhồi máu cơ tim cấp như là một biện pháp phòng ngừa thứ phát các biến cố bệnh ĐMV. Các bệnh nhân mãn kinh đã sử dụng thuốc tại thời điểm bị nhồi máu cơ tim cấp không nên tiếp tục dùng thuốc. Tuy nhiên, các bệnh nhân đã sử dụng thuốc 1-2 năm muốn tiếp tục sử dụng thuốc vì các chỉ định khác nên cân nhắc giữa nguy cơ và lợi ích mang lại từ việc sử dụng thuốc. Hormon liệu pháp không nên dùng tiếp tục khi bệnh nhân phải nằm dưỡng bệnh tại giường.
**_Hoạt động thể lực:_** Các bệnh nhân hồi phục sau nhồi máu cơ tim cấp nên tập thể dục tối thiểu 30 phút mỗi ngày hay ít nhất 5 lần/tuần (đi bộ, đi xe đạp, hay các hoạt động thể lực khác), đồng thời tăng các hoạt động thông thường hàng ngày (làm vườn, làm công việc nội trợ).
**_Chống ôxy hóa:_ **Các vitamin chống ôxy hóa như vitamin E, C… không nên sử dụng cho bệnh nhân hồi phục sau nhồi máu cơ tim cấp để phòng ngừa thứ phát.
**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/) **- Đa khoa Hạng I Thành phố Hồ Chí Minh

## Phòng khám tư vấn và điều trị giảm cân tại bệnh viện Nguyễn Tri Phương

  * [Bệnh béo phì được định nghĩa như thế nào?](https://bvnguyentriphuong.com.vn/kien-thuc-cho-nguoi-benh/phong-kham-tu-van-va-dieu-tri-giam-can-tai-benh-vien-nguyen-tri-phuong#bnh-bo-ph-c-nh-ngha-nh-th-no)
  * [1 Đối với người lớn](https://bvnguyentriphuong.com.vn/kien-thuc-cho-nguoi-benh/phong-kham-tu-van-va-dieu-tri-giam-can-tai-benh-vien-nguyen-tri-phuong#1-i-vi-ngi-ln)
  * [2 Đối với trẻ em](https://bvnguyentriphuong.com.vn/kien-thuc-cho-nguoi-benh/phong-kham-tu-van-va-dieu-tri-giam-can-tai-benh-vien-nguyen-tri-phuong#2-i-vi-tr-em)
  * [Thừa cân và bệnh béo phì gây ra những hậu quả gì?](https://bvnguyentriphuong.com.vn/kien-thuc-cho-nguoi-benh/phong-kham-tu-van-va-dieu-tri-giam-can-tai-benh-vien-nguyen-tri-phuong#tha-cn-v-bnh-bo-ph-gy-ra-nhng-hu-qu-g)


## Bệnh béo phì được định nghĩa như thế nào?
**Thừa cân và béo phì** được WHO - tổ chức y tế thế giới định nghĩa là sự tích tụ chất béo bất thường hoặc quá mức có thể làm giảm sức khỏe.
Chỉ số khối cơ thể (**BMI**) là một chỉ số đơn giản về cân nặng theo chiều cao thường được sử dụng để phân loại thừa cân và béo phì ở người trưởng thành.
### **1 Đối với người lớn**
Thừa cân là chỉ số BMI lớn hơn hoặc bằng 25 và béo phì là chỉ số BMI lớn hơn hoặc bằng 30.
### **2 Đối với trẻ em**
Đối với trẻ em dưới 5 tuổi: Thừa cân là cân nặng theo chiều cao lớn hơn 2 độ lệch chuẩn trên trung bình. Tiêu chuẩn tăng trưởng trẻ em của WHO; và béo phì là cân nặng theo chiều cao lớn hơn 3 độ lệch chuẩn trên trung bình Tiêu chuẩn tăng trưởng trẻ em của WHO.
Trẻ em từ 5 - 18 tuổi: Thừa cân là BMI theo tuổi lớn hơn 1 độ lệch chuẩn trên trung bình tham chiếu tăng trưởng của WHO; và béo phì lớn hơn 2 độ lệch chuẩn trên trung bình trên tham chiếu tăng trưởng của WHO.
## Thừa cân và bệnh béo phì gây ra những hậu quả gì?
BMI tăng là một yếu tố nguy cơ chính đối với các bệnh không truyền nhiễm như:
  * **Bệnh tim mạch** (chủ yếu là bệnh tim và đột quỵ), là nguyên nhân hàng đầu gây tử vong trong năm 2012;
  * Bệnh tiểu đường;
  * **Rối loạn cơ xương khớp** (đặc biệt là viêm xương khớp - một bệnh thoái hóa khớp rất cao);
  * Một số bệnh ung thư (bao gồm nội mạc tử cung, vú, buồng trứng, tuyến tiền liệt, gan, sỏi mật, thận và đại tràng).


Thừa cân ở trẻ em có liên quan đến nguy cơ mắc bệnh béo phì, tử vong sớm và tàn tật ở tuổi trưởng thành cao hơn. Nhưng ngoài việc tăng nguy cơ trong tương lai, trẻ béo phì còn gặp khó khăn về hô hấp, tăng nguy cơ gãy xương, tăng huyết áp, các dấu hiệu sớm của bệnh tim mạch, kháng insulin và ảnh hưởng tâm lý.
**[Phác đồ chẩn đoán và điều trị béo phì (Bộ Y Tế)](https://bvnguyentriphuong.com.vn/uploads/072022/files/Beophi-Q%C4%902892BYT.pdf)
#### Nội dung trong file:

0 
BỘ Y TẾ  
___________  
 
Số:         /QĐ-BYT CỘNG HOÀ XÃ HỘI CHỦ NGHĨA VIỆT NAM  
Độc lập - Tự do - Hạnh phúc  
________________________________  
Hà Nội, ngày     tháng    năm 202 2 
 
QUYẾT ĐỊNH  
Về việc ban hành tài liệu chuyên môn  
“Hướng dẫn chẩn đoán và điều trị bệnh béo phì ” 
 
BỘ TRƯỞNG BỘ Y TẾ  
Căn cứ Luật Khám bệnh, chữa bệnh năm 2009;  
Căn cứ Nghị định số 75/2017/NĐ -CP ngày 20 tháng 6 năm 2017 của Chính 
phủ quy định chức năng, nhiệm vụ, quyền hạn và cơ cấu tổ chức của Bộ Y tế;  
Theo đề nghị của Cục trưởng Cục Quản lý khám, chữa bệnh.  
QUYẾT ĐỊNH:  
Điều 1. Ban hành kèm theo Quyết định này tài liệu chuyên môn “ Hướng dẫn 
chẩn đoán và điều trị bệnh béo phì ”. 
Điều 2. Tài liệu chuyên môn “ Hướng dẫn chẩn đoán và điều trị bệnh béo 
phì” được áp dụng tại các cơ sở khám bệnh, chữa bệnh trong cả nước.  
Điều 3. Quyết định này có hiệu lực kể từ ngày ký, ban hành. Bãi bỏ bài 
“Bệnh béo phì” trong “Hướng dẫn chẩn đoán và điều trị bện h nội tiết – chuyển 
hóa” được ban hành tại Quyết định số 3879/QĐ -BYT ngày 30 tháng 09 năm 2014 
của Bộ trưởng Bộ Y tế.  
Điều 4. Các ông, bà: Chánh Văn phòng Bộ, Chánh thanh tra Bộ, Tổng Cục 
trưởng, Cục trưởng và Vụ trưởng các Tổng cục, Cục, Vụ thuộc Bộ Y tế,  Giám 
đốc Sở Y tế các tỉnh, thành phố trực thuộc trung ương, Giám đốc các Bệnh viện 
trực thuộc Bộ Y tế, Thủ trưởng Y tế các ngành chịu trách nhiệm thi hành Quyết 
định này./.  
 
Nơi nhận : 
- Như Điều 4;  
- Q. Bộ trưởng (để b/c);  
- Các Thứ trưởng;  
- Cổng thông tin điện tử Bộ Y tế; Website Cục KCB;  
- Lưu: VT, KCB.  KT. BỘ TRƯỞNG  
THỨ TRƯỞNG  
 
 
[d 
aky]  
 
 
Nguyễn Trường Sơn  
 
  
  
syt_sonla_vt_So Y te Son La_22/10/2022 22:04:031 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
   
 
 
 
 
 
 
 
HƯỚNG D ẪN CH ẨN ĐOÁN VÀ  
ĐIỀU TR Ị BỆNH BÉO PHÌ  
 
 
(Ban hành kèm theo Quy ết định số          /QĐ-BYT  
ngày      tháng     năm 202 2 của Bộ trưởng Bộ Y tế) 
 
 
 
 
 
 
 
 
Hà N ội, 2022  
 
 
 
 
syt_sonla_vt_So Y te Son La_22/10/2022 22:04:032 
 
CHỈ ĐẠO BIÊN SOẠN  
PGS.TS. Nguyễn Trường Sơn  
CHỦ BIÊN  
PGS.TS. Lương Ngọc Khuê  
GS.TS. Tr ần Hữu Dàng  
THAM GIA BIÊN SO ẠN VÀ TH ẨM Đ ỊNH 
TS. Nguy ễn Quang B ảy 
TS. Lê Văn Chi  
TS. Phan Hư ớng Dương  
PGS.TS. Nguy ễn Thị Bích Đào  
TS. Lâm Văn Hoàng  
TS. Nguy ễn Trọng Khoa  
TS. Nguy ễn Công Long  
TS. Tr ần Thừa Nguyên  
TS. Bùi Thanh Phúc  
PGS.TS. Đ ỗ Trung Quân  
GS.TS. Thái H ồng Quang  
PGS.TS. H ồ Thị Kim Thanh  
TS. Nghiêm Nguy ệt Thu  
GS.TS. Nguy ễn Hải Thủy 
PGS.TS. Nguy ễn Khoa Di ệu Vân  
Thư ký  
TS. Tr ần Thừa Nguyên  
ThS. Trương Lê Vân Ng ọc 
CN. Đ ỗ Thị Thư 
  syt_sonla_vt_So Y te Son La_22/10/2022 22:04:033 
MỤC LỤC 
 
 
1. ĐẠI CƯƠNG  ................................ ................................ ................................ ............  4 
2. NGUYÊN NHÂN SINH B ỆNH BÉO PHÌ  ................................ ..............................  4 
2.1. Nguyên nhân v ề dinh dư ỡng ................................ ................................ ...............  4 
2.2. Nguyên nhân di truy ền ................................ ................................ ........................  5 
2.3. Nguyên nhân n ội tiết ................................ ................................ ...........................  5 
2.4. Nguyên nhân mô b ệnh học ................................ ................................ .................  5 
2.5. Nguyên nhân do sử dụng thuốc ................................ ................................ ..........  5 
2.6. Nguyên nhân khác  ................................ ................................ ..............................  5 
3. SINH LÝ B ỆNH BÉO PHÌ ................................ ................................ .......................  5 
4. CHẨN ĐOÁN  ................................ ................................ ................................ ...........  6 
4.1. Chỉ số khối cơ th ể (BMI - Body mass index)  ................................ ......................  6 
4.2. Vòng b ụng................................ ................................ ................................ ...........  7 
4.3. Phương pháp DEXA h ấp thụ năng lư ợng kép  ................................ ....................  7 
5. CÁC D ẠNG BÉO PHÌ  ................................ ................................ .............................  8 
5.1. Béo phì d ạng nam (béo phì ph ần trên cơ th ể, béo phì ki ểu bụng, béo phì hình 
quả táo, béo phì trung tâm)  ................................ ................................ ...........................  8 
5.2. Béo phì d ạng nữ (béo phì ph ần dưới cơ th ể, béo phì hình qu ả lê) .....................  8 
5.3. Béo phì h ỗn hợp ................................ ................................ ................................ .. 8 
6. ĐIỀU TR Ị BÉO PHÌ  ................................ ................................ ................................ . 8 
6.1. Mục tiêu và nguyên t ắc chung  ................................ ................................ ............  8 
6.1.1.  Mục tiêu  ................................ ................................ ................................ .................  8 
6.1.2. Nguyên t ắc chung  ................................ ................................ ................................ .... 9 
6.2. Điều trị cụ thể ................................ ................................ ................................ ... 10 
6.2.1.  Tiết thực ................................ ................................ ................................ ..... 10 
6.2.2.  Chế độ vận động trong đi ều trị béo phì ................................ ......................  12 
6.2.3.  Tâm lý li ệu pháp trong đi ều trị béo phì................................ ......................  14 
6.2.4.  Thuốc ................................ ................................ ................................ .........  15 
6.2.5.  Điều trị phẫu thu ật trong béo phì  ................................ ...............................  17 
7. BÉO PHÌ Ở TRẺ EM VÀ THANH THI ẾU NIÊN  ................................ ................  23 
8. KẾT LU ẬN ................................ ................................ ................................ .............  23 
Phụ lục: Thuốc điều trị béo phì  ................................ ................................ ......................  24 
TÀI LI ỆU THAM KH ẢO ................................ ................................ ..............................  26 
 
 
 
 
 
 
 syt_sonla_vt_So Y te Son La_22/10/2022 22:04:034 
HƯỚNG D ẪN CH ẨN ĐOÁN VÀ ĐI ỀU TR Ị BỆNH BÉO PHÌ  
 
1. ĐẠI CƯƠNG  
Béo phì là tình tr ạng tích t ụ mỡ thừa hoặc bất thư ờng, có th ể ảnh hư ởng xấu đến sức 
khỏe. Ở nhiều nước trên th ế giới, tình tr ạng béo phì ngày  càng  gia tăng , đặc biệt trong 10 
năm tr ở lại đây. B ệnh béo phì có s ự thay đ ổi theo gi ới, tuổi, tình tr ạng kinh t ế, xã h ội, 
yếu tố chủng tộc. Tỷ lệ béo phì đang gia tăng nhanh t ại Việt Nam kho ảng 2,6% năm 2010 
lên đ ến 3,6% năm 2014 tương đương v ới tốc độ tăng trư ởng 38% .  
Nghiên c ứu đư ợc công b ố vào năm 2018 v ề bệnh không lây nhi ễm, ăn u ống và dinh 
dưỡng ở Việt Nam trong th ời gian t ừ 1975 – 2015 cho th ấy tần suất thừa cân, béo phì 
trên ngư ời lớn ở Việt Nam là 2 ,3% vào năm 1993 và tăng lên đáng k ể 15% vào năm 
2015, t ỷ lệ ở thành th ị gấp gần 2 lần so v ới nông thôn (22 ,1% so v ới 11,2%). Ngoài ra, 
nghiên c ứu cũng ghi nh ận lối sống của ngư ời Việt Nam thay đ ổi rất nhiều trong nh ững 
năm g ần đây như ít v ận động hơn, trong ch ế độ ăn có nhi ều mu ối, ăn nhi ều mì ăn li ền, 
uống nhi ều nước ngọt, ăn ít rau và h ải sản. M ột thống kê t ại Việt Nam 2021 cho k ết quả 
tương t ự với tỷ lệ thừa cân, béo phì ở Hà N ội và H ồ Chí Minh chi ếm 18% t ổng số lượng 
người thừa cân, béo phì trên toàn qu ốc. 
Rất đáng lưu ý là t ỷ lệ thừa cân, béo phì ở trẻ em tu ổi học đường 5-19 tu ổi tăng t ừ 8,5% 
năm 2010 lên thành 19,0% năm 2020, trong đó  tỷ lệ thừa cân béo phì khu v ực thành th ị 
là 26,8%, nông thôn là 18,3% và mi ền núi là 6,9%.  
Béo phì đư ợc các t ổ chức y tế bao g ồm Tổ chức Y t ế Thế giới (WHO) và Hi ệp hội Y 
khoa Hoa K ỳ (American Medical Association) công nh ận là m ột bệnh m ạn tính đòi h ỏi 
phải quản lý và đi ều trị lâu dài.  
Béo phì có tác đ ộng bất lợi lên t ất cả các v ấn đề sức khỏe, làm gi ảm thời gian s ống, gây 
ra nhi ều bệnh lý m ạn tính không lây như : đái tháo đư ờng, b ệnh lý tim m ạch, tăng lipid 
máu, h ội chứng ngưng th ở lúc ng ủ, làm gi ảm ch ất lượng sống,... Những bi ện pháp ngăn 
ngừa, điều trị thừa cân, béo phì và duy trì th ực hiện việc kiểm soát cân n ặng lâu dài có 
thể cải thiện tình tr ạng sức khỏe, giảm biến chứng cho ngư ời bệnh. 
Béo phì gây ra các v ấn đề trầm trọng đến sức khỏe, là thủ phạm gây hơn 200 b ệnh khác 
nhau, như b ệnh tim m ạch, đ ột quị, đái tháo đư ờng, thoái hóa kh ớp, gan nhi ễm m ỡ và  
nhiều bệnh ung thư, đ ặc biệt là ung thư đư ờng tiêu hóa …Tình tr ạng tự chữa béo phì 
không có hi ệu quả, nhiều biến cố nặng và t ốn kém  
2. NGUYÊN NHÂN SINH BỆNH  BÉO PHÌ  
2.1. Nguyên nhân v ề dinh dư ỡng 
a) Nguyên nhân dinh dư ỡng của béo phì là đa d ạng, ch ủ yếu do:  
- Tăng quá m ức lượng năng lư ợng ăn vào  
- Ăn quá nhi ều: nghĩa là ăn m ột lượng th ức ăn nhi ều hơn nhu c ầu của cơ th ể.  
b) Người ăn quá m ức có th ể do nhi ều nguyên nhân khác nhau như:  
+ Thói quen của gia đình  
+ Sự chủ quan c ủa ngư ời ăn nhi ều 
- Chế độ ăn “giàu” ch ất béo  
- Ở trẻ em: tiêu th ụ quá nhi ều chất ngọt làm tăng nguy cơ béo phì  syt_sonla_vt_So Y te Son La_22/10/2022 22:04:035 
- Nuôi con b ằng sữa mẹ ít hơn 3 tháng thư ờng đi kèm v ới tăng nguy cơ béo phì ở trẻ 
em khi đ ến trư ờng.  
2.2. Nguyên nhân di truy ền  
Tế bào m ỡ dễ dàng phân chia theo m ột trong hai cách:  
- Quá s ản: vừa tăng th ể tích, v ừa tăng s ố lượng tế bào m ỡ (tăng g ấp 3 - 4 lần), xảy ra 
cho tr ẻ em ho ặc tuổi dậy thì, khó đi ều trị. 
- Phì đ ại: tế bào m ỡ to ra do gia tăng s ự tích t ụ mỡ nhưng không tăng s ố lượng hay g ặp 
ở người lớn, tiên lư ợng tốt hơn.  
2.3. Nguyên nhân n ội tiết 
- Tổn thương h ạ đồi do ch ấn thương, b ệnh lý ác tính, viêm nhi ễm, suy sinh d ục, giảm 
gonadotropin.     
- Hội chứng béo phì - sinh d ục 
- Suy giáp  
- Cường thư ợng th ận 
- U tụy tiết insulin  
- Hội chứng bu ồng trứng đa nang  
2.4. Nguyên nhân mô b ệnh h ọc 
- Tăng s ản quá m ức số lượng tế bào m ỡ mà kích thư ớc tế bào m ỡ có th ể bình thư ờng.  
- Phì đ ại tế bào m ỡ mà số lượng tế bào m ỡ không tăng ho ặc chỉ tăng khi các t ế bào m ỡ 
phì to h ết cỡ. 
2.5. Nguyên nhâ n do sử dụng thuốc 
- Hormon steroide  
- Kháng tr ầm cảm cổ điển (3 vòng, 4 vòng, IMAO)  
- Benzodiazepine  
- Lithium  
- Thuốc chống lo ạn thần 
2.6. Nguyên nhân khác  
- Lối sống tĩnh t ại, lười hoạt động th ể lực 
- Bỏ hút thu ốc lá. C ần chủ động phòng th ừa cân , béo phì khi b ỏ thuốc lá 
- Hút thu ốc khi mang thai: con cái c ủa các bà m ẹ hút thu ốc khi mang thai có nguy cơ 
gia tăng tr ọng lư ợng đáng k ể về sau này.  
Tuy nhiên, bệnh nhân béo phì có th ể do có nhi ều nguyên nhân ph ối hợp 
3. SINH LÝ BỆNH BÉO PHÌ   
- Bilan năng lư ợng: Bilan năng lư ợng cân bằng nếu cung c ấp (th ức ăn) b ằng tiêu th ụ 
(vận động cơ, ho ạt động các cơ quan). Béo phì xu ất hiện do m ất cân b ằng này ho ặc 
do cung c ấp gia tăng ho ặc do tiêu th ụ giảm 
- Sự điều hòa th ể trọng: quá trình này thông qua nhi ều hormone , đặc biệt là leptin  syt_sonla_vt_So Y te Son La_22/10/2022 22:04:036 
- Yếu tố di truyền: Béo phì có y ếu tố gia đình: 69% ngư ời béo phì có cha ho ặc mẹ béo 
phì, 18% có c ả hai  
- Vai trò vùng dư ới đồi 
+ Các tác nhân alpha -adrenergic, kích thích sự  ăn làm tăng cân,  tác động lên nhân 
cạnh thất  
+ Các tác nhân be ta-adrenergic : ngược lại làm chán ă n 
- Beta-endorphine: các th ụ thể này làm d ễ sự tiết insulin, gây ăn nhi ều làm tăng cân . 
+ Naloxone: đối kháng beta -endorphine, làm giảm ăn nhất là các thức ăn có vị ngon  
+ Serotonine: đối kháng với alpha -adrenergic , làm giảm ăn . 
- Các hormone:  
+ Insulin là hormone làm tân sinh mỡ  
+ Glucagon tác dụng đối kháng insulin  
+ Enkephalin và catecholamin từ tuyến thượng thận cũng có vai trò trong điều hòa 
thể trọng  
+ Hormone sinh dục và thượng thận có vai trò trong phân bố mỡ  
- Vai trò c ủa stress: làm tăng b eta-endorphine và adrenal in ở người béo phì, t ừ đó làm 
tăng đư ờng huy ết, tác d ụng phối hợp của 2 hormone này thi ết lập sự liên h ệ giữa 
stress, béo phì và đái tháo đư ờng típ 2.  
- Thái đ ộ ăn uống: trung tâm đói và no do vùng dư ới đồi điều khi ển, thái đ ộ ăn uống 
có th ể bị thay đ ổi do t huốc, chẳng hạn thu ốc thần kinh (amphetamine) làm gi ảm ngon 
miệng, ch ống trầm cảm 3 vòng làm tăng s ự ngon mi ệng. Các y ếu tố tâm lý liên quan 
đến môi trư ờng như giáo d ục, đời sống gia đình, môi trư ờng công vi ệc...có th ể làm 
rối loạn thái đ ộ ăn uống, từ đó có thể làm ăn nhi ều hoặc chán ăn.  
- Thuốc: nhi ều loại thu ốc làm tăng cân như các thu ốc an th ần kinh, mu ối lithium, 
corticoid e, đồng hóa protein, sinh progesteron, và có khi osestrogene (làm tăng ngon 
miệng). 
4. CHẨN ĐOÁN  
4.1. Chỉ số khối cơ th ể (BMI - Body mass index ) 
Chiều cao đ ứng: đư ợc đo b ằng thư ớc. Ngư ời được đo đ ứng th ẳng trong tư th ế thoải mái, 
mắt nhìn v ề phía trư ớc, hai gót chân sát nhau ch ụm lại thành hình ch ữ V, đo m ột đường 
thẳng từ đỉnh đầu đến gót chân. K ết quả tính b ằng đơn v ị mét và sai s ố không quá 0,1 
cm.  
Trọng lư ợng cơ th ể: Cân n ặng: Ngư ời được đo m ặc quần áo m ỏng nh ẹ, bỏ guốc dép và 
đứng lên cân theo đúng v ị trí, ch ỉ số trên màn hình s ẽ báo tr ọng lư ợng cơ th ể. Đo tr ọng 
lượng cơ th ể chính xác đ ến 0,1 kg. Đơn v ị biểu thị trọng lư ợng: kg.  
BMI (kg/ m2) = Cân n ặng (kg)/ Chiều cao (m2) 
  syt_sonla_vt_So Y te Son La_22/10/2022 22:04:037 
Bảng 4.1. Đánh giá tình tr ạng th ừa cân, béo phì theo tiêu chu ẩn của WHO  
áp dụng cho người Châu Á  
 
BMI  (kg/m2) Phân lo ại 
< 18,5  Thiếu cân  
18,5 – 22,9 Bình thư ờng 
23-24,9 Thừa cân  
25 - 29,9 Béo phì đ ộ I 
≥ 30 Béo phì đ ộ II 
4.2. Vòng b ụng 
Dụng cụ sử dụng thư ớc dây chia v ạch do Vi ệt Nam s ản xuất đạt tiêu chu ẩn của Cục đo 
lường Vi ệt Nam.  
Cách đo: B ệnh nhân đứng th ẳng hai chân, hai bàn chân cách nhau 10cm, tr ọng lư ợng cơ 
thể đều trên hai chân, b ộc lộ vùng đo, cho b ệnh nhân th ở đều đặn, đo lúc th ở ra nh ẹ, tránh 
co cơ.  
Vòng b ụng: đư ợc đo ngang qua đư ờng gi ữa bờ trên xương ch ậu và b ờ dưới xương sư ờn 
cuối cùng. S ai số không quá 0,1 cm. K ết quả tính b ằng centi mét (cm).  
Đánh giá k ết quả: béo phì d ạng nam  (béo phì ph ần trên cơ th ể, béo phì ki ểu bụng, béo 
phì hình qu ả táo, béo phì trung tâm) khi vòng b ụng ≥ 90 cm ở nam và  ≥80 cm ở nữ. 
(Theo B ộ Y tế và H ội Nội tiết & Đái tháo đư ờng Việt Nam).  
4.3. Phương pháp DEXA h ấp thụ năng lư ợng kép  
Phương pháp h ấp thụ năng lư ợng kép được xem là “ tiêu chu ẩn vàng ” để đánh giá lượng 
mỡ cơ th ể. DEXA đã đư ợc sử dụng rộng rãi đ ể nghiên c ứu quá trình kh ử khoáng xương 
(bone demineralization) và loãng xương và th ể hiện một tiến bộ đáng k ể trong đánh giá 
lượng m ỡ cơ th ể vì nó d ễ sử dụng trong các môi trư ờng lâm sàng và đ ộ chính xác cao 
hơn giúp phân bi ệt mô n ạc và m ỡ so với các phương pháp trư ớc đó như đo kháng l ực 
dưới nước toàn thân (hydrodensitometry). DEXA đ ịnh nghĩa m ột công ngh ệ theo đó s ự 
suy gi ảm bức xạ ở 2 năng lư ợng đư ợc sử dụng để xác đ ịnh 2 thành ph ần của mô suy 
giảm, ho ặc xương và mô m ềm ho ặc mô n ạc và m ỡ. Nhiều chuyên gia cho r ằng DEXA là 
một trong nh ững "tiêu chu ẩn vàng" đ ể đánh giá m ỡ cơ th ể.  
Các nghiên c ứu có giá tr ị đã ch ỉ ra rằng đánh giá lư ợng m ỡ cơ th ể của DEXA thư ờng so 
sánh t ốt với mô hình 4 ngăn trong đó lư ợng m ỡ cơ th ể được ước tính t ừ các phép đo  mật 
độ cơ th ể  như đo kháng l ực dưới nước (hydrodensitometry), t ổng lư ợng nư ớc toàn cơ 
thể (thường bằng cách pha loãng deuterium) và các giá tr ị độ khoáng xương b ằng DEXA. 
Tuy nhiên, các nghiên c ứu cho th ấy DEXA có th ể đánh giá th ấp lượng m ỡ cơ th ể ở người 
có tỷ lệ mỡ cơ th ể thấp và đánh giá quá cao lư ợng m ỡ cơ th ể ở người tỷ lệ mỡ cơ th ể cao 
hơn ở cả người lớn và tr ẻ em.  
Gần đây, DEXA đã đư ợc sử dụng để đánh giá s ự phân b ố mỡ trong cơ th ể trong t ừng 
vùng. M ỡ bụng thư ờng đư ợc đo gi ữa thân đ ốt sống L1 và L 4 trên hình ảnh ch ụp DEXA. 
Nghiên c ứu đã ch ỉ ra rằng kh ối lượng m ỡ bụng đư ợc đo b ằng DEXA và CT có m ối tương 
quan cao, m ặc dù DEXA đánh giá th ấp một cách có h ệ thống kh ối lượng m ỡ bụng đo 
được trên CT. 256 Tuy nhiên, DEXA không th ể phân bi ệt mỡ dưới da v ới mỡ nội tạng. syt_sonla_vt_So Y te Son La_22/10/2022 22:04:038 
Đánh giá m ỡ cơ th ể của DEXA đòi h ỏi rất ít b ức xạ (1 μSv), vì v ậy cho phép đo l ặp đi 
lặp lại thích h ợp sử dụng trong môi trư ờng lâm sàng. Quá trình đo b ằng DEXA cũng r ất 
nhanh chóng và d ễ dàng, áp d ụng cho c ả người khỏe mạnh và ngư ời bệnh. Đánh giá 
lượng m ỡ cơ th ể của DEXA đòi h ỏi các thi ết bị chuyên d ụng có chi phí v ừa phải nhưng 
không quá l ớn để dễ dàng trang b ị trong m ột phòng khám béo phì. DEXA là m ột công 
cụ thích h ợp để đo lư ờng thành ph ần mỡ cơ th ể và sự phân ph ối mỡ nhưng đư ợc dành 
riêng cho m ục đích nghiên c ứu tại thời điểm hiện tại cho đ ến khi có thêm d ữ liệu về dự 
đoán nguy  cơ và hi ệu quả chi phí.  
5. CÁC DẠNG BÉO PHÌ  
5.1. Béo phì d ạng nam (béo phì ph ần trên cơ th ể, béo phì ki ểu bụng, béo phì hình 
quả táo, béo phì trung tâm)  
- Mỡ phân b ố nhiều ở bụng, thân, vai, cánh tay, c ổ, mặt. 
- Vẻ mặt hồng hào  
- Cơ v ẫn phát tri ển khác v ới hội chứng Cushing  
- Dạng béo phì này thư ờng xảy ra ở người ăn nhi ều. 
Béo phì d ạng nam thư ờng dễ dẫn đến các bi ến chứng về chuy ển hóa như  hội chứng 
chuy ển hóa,  tiền đái tháo đư ờng,đái tháo đư ờng típ 2, bệnh gút , bệnh tim, tăng huyết áp, 
bệnh túi m ật, ung thư  vú,...  
5.2. Béo phì d ạng nữ (béo phì ph ần dư ới cơ th ể, béo phì hình qu ả lê) 
- Mỡ phân b ố chủ yếu ở phần dưới của cơ th ể (khung ch ậu, vùng th ắt lưng, mông, đùi)  
- Da xanh  
- Cơ ít phát tri ển 
- Thường bị suy như ợc 
- Thường kèm suy tĩnh m ạch, rối loạn kinh nguy ệt ở nữ 
5.3. Béo phì h ỗn hợp 
Mỡ phân b ố khá đ ồng đều. Các trư ờng hợp quá béo phì thư ờng là béo phì h ỗn hợp. 
6. ĐIỀU TRỊ BÉO PHÌ  
6.1. Mục tiêu và nguyên t ắc chung  
6.1.1.  Mục tiêu  
- Mục tiêu chung: Vi ệc quản lý và đi ều trị béo phì có m ục tiêu r ộng hơn là gi ảm cân 
đơn thu ần mà còn c ần giảm nguy cơ các biến chứng và c ải thiện sức khỏe. Nh ững 
điều này có th ể đạt được bằng cách gi ảm cân v ừa phải, cải thiện hàm lư ợng dinh 
dưỡng trong ch ế độ ăn uống và k ể cả vận động và t ập thể dục mức độ trung bình. 
Điều trị tốt béo phì có th ể làm gi ảm nhu c ầu điều trị bệnh đồng m ắc. Đi ều trị thích 
hợp cho béo phì ngoài vi ệc kiểm soát cân n ặng nên bao g ồm điều trị các bi ến chứng: 
quản lý r ối loạn lipid máu, t ối ưu hóa ki ểm soát đư ờng huy ết ở bệnh nhân đái tháo 
đường típ 2, đi ều trị tăng huy ết áp, qu ản lý r ối loạn hô h ấp (như  hội chứng ngưng th ở 
khi ng ủ), chú ý đ ến kiểm soát cơn đau và nhu c ầu vận động trong viêm kh ớp, qu ản lý 
rối loạn tâm lý xã h ội, bao g ồm rối loạn cảm xúc, r ối loạn ăn u ống và gi ảm lòng t ự 
trọng,  và suy nghĩ tiêu c ực về hình ảnh cơ th ể. Bối cảnh kinh t ế xã hội của bệnh nhân 
cũng c ần được tính đ ến trong vi ệc thiết lập chi ến lược điều trị. syt_sonla_vt_So Y te Son La_22/10/2022 22:04:039 
- Mục tiêu gi ảm cân th ực tế: Giảm cân 5 –15% trong kho ảng th ời gian 6 tháng là th ực 
tế và đã đư ợc chứng minh mang l ại lợi ích s ức khỏe. Có th ể cân nh ắc giảm cân nhi ều 
hơn (20% trở lên) đ ối với những ngư ời có m ức độ béo phì cao hơn (BMI ≥ 35 kg/m2). 
Duy trì gi ảm cân và phòng ng ừa và đi ều trị các b ệnh đồng m ắc là hai tiêu chí chính 
để thành công.  
- Theo dõi ngư ời bệnh: Béo phì là m ột bệnh mạn tính. Ngư ời bệnh cần được theo dõi 
và tái khám thư ờng xuyên đ ể ngăn ng ừa tăng cân tr ở lại và đ ể theo dõi nguy cơ b ệnh 
tật cũng như đi ều trị các b ệnh đồng m ắc nếu xuất hiện (ví d ụ: đái tháo đư ờng típ 2, 
bệnh tim m ạch). 
6.1.2. N guyên t ắc chung  
- Can thi ệp lối sống là n ền tảng đảm bảo duy trì gi ảm cân bền vững, an toàn bao g ồm 
các bi ện pháp can thi ệp dinh dư ỡng, tập luy ện thể lực, thay đ ổi hành vi, h ỗ trợ tâm lý . 
- Điều trị bằng thu ốc khi can thi ệp lối sống trong 3 tháng không giúp gi ảm đư ợc 5% 
cân n ặng, ngư ời bệnh có BMI ≥ 25 kg/m2. 
- Phối hợp chặt chẽ của nhi ều chuyên khoa đ ể đạt được hiệu quả điều trị và duy trì giảm 
cân đ ạt yêu c ầu bền vững.  
- Phối hợp đa chuyên khoa là n ền tảng trong mô hình chăm sóc đi ều trị béo phì : Béo 
phì là m ột tình tr ạng ph ức tạp có ngu ồn gốc đa y ếu tố. Các y ếu tố sinh h ọc mà c ả tâm 
lý và xã h ội cùng tác đ ộng dẫn đến quá cân và các bi ến chứng liên quan. Qu ản lý béo 
phì không th ể chỉ tập trung vào vi ệc giảm cân (và BMI). Qu ản lý các b ệnh đồng m ắc, 
cải thiện chất lượng cu ộc sống và s ức khỏe của bệnh nhân béo phì c ũng đư ợc đưa vào 
mục tiêu đi ều trị. Quản lý béo phì toàn di ện nên đư ợc thực hiện bởi một đội ngũ thích 
hợp gồm nhi ều chuyên khoa và bao g ồm các chuyên gia khác nhau đ ể có th ể giải 
quyết các khía c ạnh khác nhau c ủa béo phì và các r ối loạn liên quan. Ngư ời bệnh nên 
hiểu rằng, vì béo phì là m ột bệnh mãn tính, nên vi ệc quản lý cân n ặng sẽ cần phải kéo 
dài su ốt đời. 
Xây d ựng nhóm các chuyên gia đa chuyên khoa: nh ững bác sĩ đư ợc đào t ạo đặc biệt về 
quản lý béo phí, chuyên gia dinh dư ỡng, nhà tr ị liệu hành vi, chu yên gia hư ớng dẫn vận 
động th ể lực, điều dưỡng về bệnh béo phì, bác sĩ ph ẫu thu ật. syt_sonla_vt_So Y te Son La_22/10/2022 22:04:0310 
 
Sơ đồ 6.1. Hư ớng dẫn theo dõi và đi ều trị bệnh béo phì  
6.2. Điều trị cụ thể 
6.2.1.  Tiết thực  
a. Nguyên t ắc điều trị tiết thực 
- Phải điều trị kiên trì, lâu dài, ph ối hợp nhi ều phương pháp  
- Phải điều trị tích c ực khi có tăng huy ết áp, suy tim … 
- Điều trị phải giảm cân m ột cách t ừ từ, bền vững đáp ứng nhu c ầu của ngư ời bệnh 
b. Chế độ ăn gi ảm năng lư ợng 
- Giảm tổng lư ợng năng lư ợng (calo) ăn vào nên là y ếu tố chính c ủa bất kỳ can thi ệp 
giảm cân nào . 
- Điều chỉnh hành vi ăn u ống cá nhân và ph ải thay đ ổi dần dần, cộng với sự hỗ trợ của 
gia đình, xã hội, môi trư ờng sống … 
- Chế độ ăn cân đ ối giữa các ch ất sinh nhi ệt, không quá nhi ều glucid, t ỷ lệ thay đ ổi tùy 
cá th ể theo b ệnh lý m ắc kèm, thói quen ăn u ống 
- Cung c ấp đầy đủ các vitamin c ần thiết: vitamin tan trong d ầu, kali, s ắt, acid amin  
- Hạn chế số bữa ăn trong ngày (3 b ữa là đ ủ), hạn chế ăn lo ại glucid h ấp thu nhanh và 
các ch ất béo bão hoà, mu ối dưới 5g/ngày  
- Kiêng rư ợu 
 
syt_sonla_vt_So Y te Son La_22/10/2022 22:04:0311 
Bảng 6.1. Phân b ố các ch ất dinh dư ỡng mỗi ngày  
 
Chất dinh dư ỡng Tỷ lệ phân b ố 
Lipid  < 30%   tổng calori  
Protid  15 - <20%  tổng calori  
Glucid  50 - 55% tổng calori  
Muối <5g 
Calci  Theo nhu c ầu dinh dư ỡng khuy ến ngh ị 
Chất xơ 20-30g 
Bảng 6. 2. Phân lo ại tiêu th ụ năng lư ợng dựa trên m ức độ lao đ ộng và gi ới tính  
 
Mức độ lao đ ộng/ 
 
Nhu c ầu năng 
lượng (kcal)  Lao đ ộng 
nhẹ 
 Lao đ ộng 
vừa 
 Lao đ ộng 
nặng 
Nam  Nhân viên văn 
phòng (giáo viên, 
luật sư, bác s ỹ, 
kế toán, giáo 
viên... ), nhân 
viên bán hàng, 
người thất 
nghiệp. Công nhân công 
nghiệp nhẹ, sinh 
viên, công nhân 
xây d ựng, nông 
dân, ngư dân, 
quân đ ội không 
trong  thời gian 
chiến đấu. Nông dân trong v ụ 
thu ho ạch, công nhân 
lâm nghi ệp, lao đ ộng 
thể lực đơn gi ản, 
chiến sỹ quân đ ội 
trong chi ến đấu/ 
luyện tập, công nhân 
mỏ, luyện thép, v ận 
động viên th ể thao 
trong th ời gian luy ện 
tập. 
30 kcal/kg  35 kcal/kg  45 kcal/kg  
Nữ Nhân viên văn 
phòng, giáo viên, 
nội trợ (không 
phải chăm sóc tr ẻ 
nhỏ), hầu hết các 
nghề khác.  Công nhân công 
nghiệp nhẹ, nhân 
viên bán hàng, 
sinh viên, ph ụ nữ 
nội trợ đang 
chăm sóc tr ẻ nhỏ. Nông dân trong v ụ 
thu ho ạch, vũ công, 
vận động viên th ể 
thao trong th ời gian 
luyện tập. 
25 kcal/kg  30 kcal/kg  40 kcal/kg  
Cách tính th ực đơn dành cho ngư ời béo mu ốn giảm cân đư ợc tính theo cân n ặng lý tưởng: 
Cân n ặng lý tư ởng (CNLT) = (chi ều cao)2 (m2) × 22  
Chế độ ăn: 
Lao đ ộng nh ẹ = CNLT × (20 -25 calo)  
Lao đ ộng trung bình = CNLT × (25 - 30 calo)  
Lao đ ộng nặng = CNLT × (30 -35 calo)  syt_sonla_vt_So Y te Son La_22/10/2022 22:04:0312 
Mục tiêu là gi ảm cân t ừ từ khoảng 2 - 3 kg/tháng. Ph ối hợp giáo d ục với chế độ ăn cho 
bệnh nhân, ph ải theo dõi thư ờng xuyên cân n ặng và có bi ện pháp h ỗ trợ tâm lý cho b ệnh 
nhân.  
Tăng cư ờng vận động và t ập thể dục: áp d ụng tùy theo tu ổi và các bi ến chứng đã có ở 
bệnh nhân hay không, t ập thể lực rất hữu ích m ặc dù tiêu t ốn năng  lượng tương đ ối ít 
trong khi t ập luy ện. 
Phải chia ch ế độ ăn làm 2 giai đ ọan: giai đo ạn giảm cân và giai đoạn duy trì.  
Điều trị béo phì chưa có bi ến chứng ch ủ yếu dựa vào ki ểm soát ch ế độ ăn. 
6.2.2.  Chế độ vận động trong điều trị béo phì  
a. Hướng dẫn tập luy ện: 
Cần thăm dò tim m ạch trư ớc khi b ắt đầu chương trình v ận động, nh ất là v ới ngư ời lớn 
tuổi, có y ếu tố nguy cơ tim m ạch. 
Để buổi tập an toàn và hi ệu quả, nên th ực hiện đủ 3 giai đo ạn:  
- Khởi động (5 -10 phút): làm nóng cơ th ể với những động tác đơn gi ản, cư ờng độ thấp. 
Khởi động các kh ớp từ trên xu ống dư ới. 
- Tập luy ện: thực hiện các bài t ập vận động từ 20 đến 30 phút.  
- Làm ngu ội (5-10 phút): thư giãn, th ả lỏng cơ th ể với những động tác ch ậm rãi, đưa 
cơ th ể về trạng thái ban đ ầu. 
b. Cường độ tập luy ện: 
Tập luy ện hoạt động thể chất sức bền (aerobic ) là m ột biện pháp thi ết yếu trong các 
chương trình gi ảm cân cho ngư ời béo phì. Nên th ực hiện các bài t ập cường độ trung bình 
ít nhất 150 phút m ỗi tuần, 3 đ ến 5 lần một tuần, bắt đầu bằng bài t ập cường độ thấp và 
tăng d ần cường độ và số lượng tập thể dục theo m ức độ thể dục cá nhân. T ập luy ện đề 
kháng nên đư ợc áp d ụng trong các chương trình gi ảm cân đ ể tăng kh ối lượng cơ và thúc 
đẩy giảm mỡ cơ th ể, và đư ợc đề nghị thực hiện bằng các bài t ập sử dụng các nhóm cơ 
lớn 2-4 lần một tuần. 
Dùng công th ức tính nh ịp tim khi t ập để xác đ ịnh m ức độ phù h ợp của cường độ tập 
luyện: 
Nhịp tim khi t ập = (220 - tuổi) x (từ 50% đến 70%) 
Ví dụ: một ngư ời 40 tu ổi được xem là v ận động phù h ợp nếu khi t ập luy ện nhịp tim đ ạt 
mức: (220 - 40) x 0 ,5 = 90 lần/phút.  
Người bệnh cũng có th ể tự đánh giá m ức độ vận động đã phù h ợp chưa qua gi ọng nói: 
khi tập luy ện không th ấy hụt hơi, v ẫn trò chuy ện được nhưng không th ể hát đư ợc. 
c. Thời gian t ập luy ện: 
Có th ể tập vào b ất kỳ thời điểm nào trong ngày, mi ễn là phù h ợp với nếp sinh ho ạt của 
mình.  
Mỗi ngày trung bình 30 - 40 phút. Ho ặc vận động nhi ều lần trong ngày, m ỗi lần tối thiểu 
10 phút. Nên v ận động tối thiểu 5 ngày/tu ần, tốt hơn nên t ập đều đặn mỗi ngày.  
d. Loại hình t ập luy ện: 
Nên l ựa chọn các lo ại hình t ập luy ện có tính nh ịp nhàng đ ều đặn, thời gian kéo dài như: 
đi bộ, đạp xe, bơi l ội, dưỡng sinh…  syt_sonla_vt_So Y te Son La_22/10/2022 22:04:0313 
Tuy v ậy, có th ể tập bất cứ loại hình nào phù h ợp với sức khỏe, tuổi tác, s ở thích và đi ều 
kiện sống. 
Nếu có bi ến chứng ở mắt, tim , thận, bàn chân, nên h ỏi ý ki ến bác sĩ v ề loại hình luy ện 
tập thích h ợp. Thông thư ờng trong các trư ờng hợp này lo ại hình luy ện tập phù h ợp nhất 
là đi b ộ. 
Nếu không có đi ều kiện tập liên t ục 30 phút, có th ể chia ra 2 -3 lần/ngày, m ỗi lần 5-10 
phút. Mi ễn sao t ập đều đặn. 
Luyện tập để tăng cư ờng sức khỏe thể chất và tinh th ần, ngoài công vi ệc hàng ngày. Ví 
dụ một bà n ội trợ đi ch ợ nấu ăn, quét d ọn nhà c ửa sẽ tiêu hao m ột số năng lư ợng, nhưng 
vẫn cần duy trì luy ện tập thể lực mỗi ngày.  
      Bảng 6.3. Tham kh ảo năng lư ợng kcalo tiêu th ụ được sau 30 ph út tập thể dục 
 
Cân n ặng (kg)  50 60 70 80 90 100 
Hoạt động trong phòng t ập 
Aerobic: trung bình  149 177 206 234 263 291 
Đạp xe: 16 km/h  163 195 226 258 289 321 
Chạy: 10km/h  260 310 360 410 460 510 
Máy leo thang: trung bình  158 190 222 253 285 317 
Giãn  duỗi / yoga Hatha  106 127 148 169 190 211 
Đi bộ: bình thư ờng 4km/h  78 93 108 123 138 153 
Đi bộ: nhanh 7km/h  149 177 206 234 263 291 
Tập tạ: trung bình  79 95 111 127 143 158 
Thể thao       
Cầu lông  119 143 166 190 214 238 
Bi-a 66 79 92 106 119 132 
Nhảy 145 174 203 232 261 290 
Nhảy dây  264 317 370 422 475 528 
Bóng đá  185 222 259 296 333 370 
Bơi l ội 25 m/phút  123 146 170 193 217 240 
Thái c ực quy ền 106 127 148 169 190 211 
Quần vợt 185 222 259 296 333 370 
e. Một số lưu ý  trong v ận động 
- Nhiều ngư ời có cuộc sống tĩnh t ại, có r ất ít k ỹ năng ho ạt động th ể lực và r ất khó đ ể 
thúc đ ẩy hoạt động của họ. Vì v ậy, các đ ối tượng này đư ợc khuy ến cáo nên b ắt đầu 
với chế độ vận động. Gi ảm thời gian tĩnh t ại là phương pháp ti ếp cận mới nhằm tăng 
cường ho ạt động. B ệnh nhân đư ợc khuy ến khích tham gia các ho ạt động th ể lực hàng 
ngày, ví d ụ như nên đi c ầu thang b ộ hơn là đi thang máy ho ặc thang cu ốn. Khuy ến 
khích các ho ạt động th ể lực tại các đ ịa điểm an toàn như: công viên, nhà thi đ ấu, bể syt_sonla_vt_So Y te Son La_22/10/2022 22:04:0314 
bơi, câu l ạc bộ sức khỏe,… Tuy nhiên, n ếu không d ễ thực hiện, thì t ận dụng kho ảng 
không t ại nhà v ới các thi ết bị như: xe đ ạp tại chỗ hay th ảm lăn ho ặc các hình th ức vận 
động phù h ợp. 
- Điều cần thiết là tránh ch ấn thương khi v ận động cư ờng độ cao. Nh ững ngư ời béo  phì 
nặng cần bắt đầu với bài tập đơn gi ản sau đó tăng d ần đều. Th ầy thu ốc phải quy ết 
định ch ọn bài kiểm tra thể lực nào là c ần thiết trước khi ch ọn một chế độ vận động 
cho b ệnh nhân. Quy ết định này nên đư ợc dựa vào tu ổi tác, tri ệu chứng và các y ếu tố 
nguy cơ n ổi trội. 
- Đối với hầu hết ngư ời bệnh nhân béo phì, ho ạt động th ể lực nên đư ợc bắt đầu một 
cách ch ậm rãi và tăng d ần. Ho ạt động kh ởi đầu có th ể là đi b ộ hay bơi ch ậm. Tuỳ 
thuộc vào th ời gian m ắc bệnh, tr ọng lư ợng gi ảm đư ợc, thể trạng,… bệnh nhân có th ể 
được tham gia các ho ạt động nặng hơn, ví d ụ như: đi b ộ- tập thể hình, đi xe đ ạp, bơi 
thuyền, ch ạy, nh ảy aerobic, nh ảy dây,…Vi ệc chạy bộ với cường độ cao có th ể dẫn 
đến chấn thương. Các môn th ể thao đ ối kháng, ví d ụ như: qu ần vợt, bóng chuy ền,…là 
hình th ức hoạt động thích thú cho nhi ều ngư ời nhưng ph ải cẩn thận để tránh ch ấn 
thương, đ ặc biệt ở người già.  
- Chế độ điều trị có th ể thay đ ổi nhằm phù h ợp với các hình th ức khác c ủa hoạt động 
thể lực, tuy nhiên, đi b ộ đặc biệt vẫn được ưa chu ộng vì tính an toàn và tính kh ả thi. 
Hiệu quả điều trị được nâng lên n ếu bệnh nhân không dùng các th ức ăn cao năng 
lượng. 
- Bệnh nhân nên nh ờ các chuyên gia s ức khỏe lên k ế hoạch và l ập thời khóa bi ểu mỗi 
1 tuần, đồng th ời ghi nh ận các thông s ố sức khỏe khi v ận động. 
6.2.3.  Tâm lý liệu pháp trong điều trị béo phì  
- Tâm lý li ệu pháp có th ể được áp d ụng không ch ỉ như m ột can thi ệp hành vi đư ợc lập 
trình đ ể kiểm soát cân n ặng, mà còn cho m ục đích thay đ ổi hành vi liên quan đ ến 
lượng th ức ăn và ho ạt động th ể chất. 
- Điều trị béo phì t ừ lâu đã đư ợc biết đến là hi ệu quả hơn k hi các can thi ệp về lối sống 
bao g ồm cả liệu pháp hành vi đư ợc thực hiện. Do đó, t ất cả những ngư ời béo phì nên 
trải qua li ệu pháp hành vi, cùng v ới liệu pháp dinh dư ỡng và tăng cư ờng ho ạt động 
thể chất. Các phương pháp c ụ thể được sử dụng trong li ệu pháp hành vi bao g ồm tự 
giám sát, c ủng cố, kiểm soát kích thích, hành vi thay th ế và sự tái tạo nhận thức. 
- Khi đi ều trị bệnh béo phì, đi ều rất quan tr ọng là ch ẩn đoán và đi ều trị bất kỳ rối loạn 
ăn uống nào đang có.  
- Khi đi ều trị béo phì, ph ải chấm dứt hoặc giảm hút thu ốc và u ống rư ợu. Nh ững ngư ời 
béo phì nên đư ợc khuyên b ỏ hút thu ốc. Rư ợu có th ể sinh năng lư ợng kho ảng 7,0 kcal 
mỗi gam. Ngoài ra, h ầu hết rượu được uống vào đư ợc chuy ển thành axetat, c ản trở 
chất béo ngo ại vi phân h ủy và s ử dụng. V ề mặt lâm sàng, rượu làm tăng huy ết áp và 
uống quá nhi ều làm tăng nguy cơ tăng triglycerid máu, kháng insulin, đái tháo đư ờng 
típ 2, h ội chứng chuy ển hóa và béo b ụng. Do đó, vi ệc kiểm soát vi ệc uống rư ợu quá 
mức là r ất quan tr ọng đối với việc ngăn ng ừa và ki ểm soát b ệnh béo phì và h ội chứng 
chuy ển hóa . 
- Hỗ trợ tâm lý b ệnh nhân b ằng cách chuy ện trò ho ặc sinh ho ạt nhóm bên c ạnh các  lời 
khuyên v ề điều chỉnh ch ế độ ăn. B ệnh nhân thư ờng bị trầm cảm, lo l ắng th ất bại trong 
điều trị. syt_sonla_vt_So Y te Son La_22/10/2022 22:04:0315 
6.2.4.  Thuốc  
a. Nguyên t ắc chung  khi s ử dụng thu ốc 
- Khuyến cáo m ục tiêu  chính là giảm 5-10% cân n ặng trong 6 tháng sau khi b ắt đầu 
điều trị.  
- Thay đ ổi hành vi s ức khỏe là n ền tảng trong đi ều trị béo phì. Tuy nhiên thay đ ổi hành 
vi sức khỏe đơn thu ần thư ờng không đ ủ để đạt được mục tiêu đi ều trị béo phì. Thay 
đổi hành vi s ức khỏe nhìn chung ch ỉ giảm 3-5% cân n ặng, và thư ờng không duy trì 
được trong th ời gian dài.  
- Thuốc điều trị béo phì nên đư ợc xem xét đ ể giảm cân n ặng và c ải thiện chuy ển hóa 
và/ho ặc các ch ỉ số sức khỏe khi li ệu pháp thay đ ổi hành vi s ức khỏe đơn thu ần tỏ ra 
không hi ệu quả, không đ ủ hoặc không đ ạt được lợi ích b ền vững.  
- Trong trư ờng hợp không đ ạt được mục tiêu gi ảm cân thông qua can thi ệp lối sống ở 
bệnh nhân có ch ỉ số BMI ≥ 25 kg/m2, cần xem xét đi ều trị bằng thu ốc. Hai lo ại thuốc 
được phê duy ệt trong đi ều trị béo phì bao g ồm: orlistat và liraglutide 3,0 mg.  
- Các thuốc khác không đư ợc phê duy ệt cho  điều trị béo phì . 
b. Những cân nh ắc khi s ử dụng thu ốc điều trị béo phì  
- Các y ếu tố cần xem xét đ ể quyết định lựa chọn loại thuốc phù h ợp cho ngư ời thừa cân 
hoặc béo phì:  
+ Nguyên nhân gây bệnh . 
+ Yếu tố tâm lý xã hội, cảm xúc và ý thích góp phần vào tình trạng bé o phì: nên 
được chẩn đoán và xử trí nếu có thể . 
+ Cơ chế tác dụng, tác dụng phụ, bất lợi, tính an toàn và khả năng dung nạp của mỗi 
thuốc phải được xem xét trong bối cảnh bệnh đồng mắc và các thuốc hiện đang 
điều trị của người bệnh.  
+ Chi phí thuốc cũng như đ ường dùng (uống hay tiêm dưới da) và tần suất sử dụng 
có thể là rào cản cho sự tuân trị: cần được thảo luận.  
+ Rà soát những thuốc đang dùng có thể là tác nhân làm tăng cân: xem xét dùng 
thuốc thay thế nếu phù hợp.  
- Nếu không đ ạt được tình tr ạng gi ảm cân có ý nghĩa lâm sàng v ới thuốc:  cần đánh giá 
lại những yếu tố khác góp ph ần dẫn đến thất bại của việc dùng thu ốc, bao g ồm: 
+ Liều dùng không phù hợp hoặc không tuân trị  
+ Những rào cản của việc thay đổi hành vi sức khỏe  
+ Những vấn đề về tâm lý xã hội hoặc y tế  
- Mỗi cá nhân đáp ứng đi ều trị khác nhau v ới từng lo ại thuốc. Cân nh ắc thay đ ổi thuốc 
hoặc liệu pháp đi ều trị béo phì khác n ếu không đ ạt được hiệu quả giảm cân trên lâm 
sàng đáng k ể sau ba tháng dùng li ều đủ/tối đa, dung n ạp được và không có b ằng ch ứng 
về nguy ên nhân khác gây th ất bại.  
- Khuyến cáo ngưng thu ốc điều trị béo phì n ếu không đ ạt được giảm ≥ 5% cân n ặng 
sau ba tháng dùng li ều điều trị. Tuy nhiên, thu ốc cũng có th ể được sử dụng để duy trì 
sự giảm cân đ ạt được bằng m ột liệu pháp thay đ ổi hành vi s ức khỏe trư ớc đó ho ặc 
một chế độ ăn năng lư ợng rất thấp. syt_sonla_vt_So Y te Son La_22/10/2022 22:04:0316 
- Thuốc điều trị béo phì đư ợc dự định là m ột phần của chi ến lược điều trị lâu dài. Tăng 
cân tr ở lại sau khi ngưng các đi ều trị tích c ực được chứng minh trong các th ử nghiệm 
lâm sàng  đối với các thuốc điều trị béo phì.  
- Không khuy ến cáo dùng thu ốc điều trị béo phì trên ph ụ nữ mang thai và cho con bú, 
hoặc phụ nữ đang chu ẩn bị có thai. Không có d ữ liệu sẵn thông tin v ề thời điểm ngưng 
thuốc điều trị béo phì trư ớc khi th ụ thai. 
c. Thuốc được phê duy ệt cho đi ều trị béo phì  
- Orlistat  
+ Cơ chế: Orlistat, một dẫn xuất của lipstatin bán tổng hợp, được phê duyệt là thuốc 
điều trị béo phì. Đây là một chất ức chế mạnh có chọn lọc men lipase tụy, vì vậy 
ức chế sự thoái giáng triglyceride trong thức ăn thành acid béo tự do có kh ả năng 
hấp thụ. Orlistat không tác động đặc hiệu lên cơ chế no hoặc thèm ăn.  
+ Liều dùng:  120 mg, ba lần mỗi ngày (uống trong hoặc sau ăn 1 giờ) để giảm cân 
hoặc giảm nguy cơ tăng cân trở lại ở người bệnh có BMI ≥ 30 kg/m2 hoặc BMI ≥ 
27 kg/m2 kèm theo bệnh đồng mắc (ví dụ : tăng huyết áp, đái tháo đường  típ 2, rối 
loạn lipid máu, mỡ thừa ở tạng).  
+ Tác dụng phụ: Orlistat có nhiều tác dụng bất lợi trên dạ dày ruột, bao gồm đi cầu 
phân  có mỡ , trung tiện  và tăng thải phân. Orlistat có thể làm ảnh h ưởng đến sự 
hấp thụ vitamin tan trong chất béo (A, D, E, K).  
+ Chống chỉ định : ở người có hội chứng kém hấp thu mạn tính hay ứ mật. Một vài 
bệnh nhân có thể xuất hiện sỏi oxalate niệu với mức độ tăng dần khi dùng orlistat; 
bệnh thận oxalate với suy thận đã được ghi nhận. Một số trường hợp hiếm gặp có 
tổn thương gan nặng hoặc suy gan cấp.  
+ Lưu ý: Vì orlistat có thể làm ảnh hưởng đến sự hấp thu vitamin K, chỉ số INR 
(international normalized ratio) nên được theo dõi sát khi dùng kèm thuốc kháng 
đông đường uống.  Orlistat có thể ảnh hưởng sự hấp thu levothyroxine và/hoặc 
muối iodine, người bệnh đang dùng levothyroxine nên được theo dõi sự thay đổi 
chức năng tuyến giáp. Giảm nồng độ cyclosporine huyết tương đã được ghi nhận 
khi uống kèm orlistat; vì vậy, theo dõi n ồng độ cyclosporine thường xuyên hơn 
được khuyến cáo. Orlistat có thể ảnh hưởng đến sự hấp thu thuốc chống co giật, 
vì vậy người bệnh đang dùng thuốc chống co giật nên được theo dõi những thay 
đổi có thể xảy ra về tần số và/hoặc mức độ nặng của tình trạng co giật.  Ngoài ra, 
vì orlistat  thường gây  ra tác dụng phụ  ở dạ dày ruột nên cũng làm  hạn chế việc sử 
dụng thuốc trong điều trị béo phì.  
- Liraglutide  
+ Cơ chế: Liraglutide là glucagon -like peptide 1 (GLP -1) analog người, sử dụng 
hàng ngày dưới dạng tiêm dưới da tác động trung ương lên neuron pro -
opiomelanocortin (POMC)/CART nhằm tăng cảm giác no, giảm cảm giác đói, với 
tác dụng giảm sự làm trống dạ dày thoáng qua.  
+ Liều d ùng: Liraglutide được phê duyệt ở Việt Nam năm 2021 trong điều trị béo 
phì mạn tính ở liều 3,0mg mỗi ngày, ở người bệnh có hoặc không có đái tháo 
đường  típ 2. Liều khởi đầu khuyến cáo của liraglutide là 0 ,6mg mỗi ngày, tăng 
dần 0 ,6 mg sau mỗi tuần cho đến khi đạt được liều mục tiêu 3 ,0 mg.  syt_sonla_vt_So Y te Son La_22/10/2022 22:04:0317 
+ Tác dụng phụ : thường gặp nhất của liraglutide là buồn nô n do giảm thoáng qua sự 
trống dạ dày. Người bệnh có thể gặp táo bón, tiêu chảy, ợ nóng và/hoặc nôn. Chỉnh 
liều chậm hơn có thể giúp giảm nhẹ tác dụng phụ dạ dày ruột nếu c ó. Nguy cơ 
xuất hiện sỏi mật với liraglutide cao hơn 1.4% so với giả dược.  
+ Chống chỉ định trên bệnh nhân có tiền sử cá nhân hoặc gia đình có ung thư tuyến 
giáp thể tủy hoặc tiền sử cá nhân đa u tuyến nội tiết típ 2 do có sự tăng nguy cơ 
ung thư tuyến giáp thể tủy trong nghiên cứu trên loài gặm nhấm.  
+ Lưu ý: Liraglutide làm chậm sự trống dạ  dày, có thể ảnh hưởng đến sự hấp thu 
các thuốc đường uống dùng đồng thời.  
Thông tin về thuốc điều trị bệnh béo phì chi tiết trong Phụ lục kèm theo.  
6.2.5.  Điều trị phẫu thuật trong béo phì  
Chỉ định của phẫu thu ật giảm cân khi thất bại với các đi ều trị không ph ẫu thu ật ở người 
bệnh có BMI ≥ 35 kg/m2 hay BMI≥ 30 kg/m2 kèm b ệnh lý đ ồng m ắc liên quan béo phì,  
Mỗi phương pháp ph ẫu thu ật béo phì đ ều có ưu như ợc điểm riêng. Tùy t ừng trư ờng hợp 
bệnh nhân c ụ thể phẫu thu ật viên s ẽ tư vấn và l ựa chọn phẫu thu ật phù h ợp. 
a. Phẫu thu ật đặt vòng th ắt dạ dày 
Vào năm 1976 Wilkinson báo cáo k ỹ thuật đặt vòng th ắt dạ dày l ần đầu tiên tuy nhiên 
vòng th ắt không có bu ồng ch ỉnh, ph ẫu thu ật thắt đai d ạ dày có bu ồng ch ỉnh đư ợc Kuzmac 
và Forsell đ ồng th ời báo cáo vào năm 1990. Vòng th ắt dạ dày có 1 bu ồng ch ỉnh đư ợc đặt 
dưới da và n ối với đai d ạ dày b ởi dây d ẫn. Bu ồng ch ỉnh này giúp tùy ch ỉnh đai d ạ dày.  
 
 
Hình 6.1. Phẫu thu ật đặt vòng th ắt dạ dày 
Phẫu thu ật đặt vòng th ắt có ưu đi ểm đơn gi ản, dễ thực hiện, thời gian ph ẫu thu ật ngắn, ít 
biến chứng. Tuy nhiên c ần phải theo dõi lâu dài sau m ổ. Bệnh nhân c ần theo dõi hàng 
tháng trong ít nh ất 3 tháng đ ầu tiên sau m ổ. Bệnh nhân cũng c ần được theo dõi và ch ỉnh 
đai tùy thu ộc mức độ giảm cân trong th ời gian dài. Ph ẫu thu ật đặt vòng th ắt có ưu đi ểm 
rất dễ phục hồi, dễ trả lại giải phẫu đường tiêu hóa.  
Dây d ẫn Buồng ch ỉnh 
“Túi” d ạ dày trên 
vòng th ắt 
Vòng th ắt 
Phần dạ dày 
dưới vòng th ắt syt_sonla_vt_So Y te Son La_22/10/2022 22:04:0318 
Cơ ch ế của việc giảm cân trong ph ẫu thu ật đặt vòng th ắt dạ dày là do vi ệc đặt một vòng 
thắt ở tâm v ị dạ dày do đó lư ợng th ức ăn đưa và o cơ th ể sẽ giảm đi. M ặt khác vi ệc tạo 
một túi ở phía tâm v ị dạ dày v ới áp l ực của vòng th ắt dạ dày cũng tác đ ộng kích ho ạt cơ 
chế tạo cảm giác no ở các b ệnh nhân đư ợc phẫu thu ật giúp làm gi ảm nhu c ầu ăn c ủa bệnh 
nhân.  
b. Phẫu thu ật tạo hình d ạ dày ống đứng 
Năm 2000 McMahon th ực hiện kỹ thuật phẫu thu ật tạo hình d ạ dày ống đứng đầu tiên t ại 
Leeds . 
Phẫu thu ật tạo hình d ạ dày ống đứng làm h ẹp và làm gi ảm thể tích c ủa dạ dày do đó làm 
giảm lượng th ức ăn đưa vào cơ th ể. 
 
Hình 6.2. Kỹ thuật tạo hình dạ dày ống đứng 
Phẫu thu ật tạo hình d ạ dày ống đứng có ưu đi ểm là ph ẫu thu ật không quá ph ức tạp, thời 
gian ph ẫu thu ật ngắn. Do ph ần còn l ại của dạ dày giãn ra sau m ổ nên sau 4 năm có nh ững 
bệnh nhân tăng cân tr ở lại. Một trong nh ững phi ền toái sau m ổ là trào ngư ợc dạ dày thực 
quản. Ở một số bệnh nhân trào ngư ợc nhi ều đến mức phải phẫu thu ật nối tắt sau đó. 
Những bệnh nhân có thoát v ị hoành ho ặc có ti ền sử trào ngư ợc dạ dày th ực quản không 
nên ch ỉ định ph ẫu thu ật này.  
c. Phẫu thu ật nối tắt dạ dày 
Năm 1966 Mason phát tri ển kỹ thuật nối tắt dạ dày. Ph ẫu thu ật của Mason đư ợc thực 
hiện bằng cách c ắt đôi d ạ dày theo chi ều ngang, ru ột non đư ợc đưa lên n ối với phần trên 
của dạ dày. 
 
Hình  6.3. Phẫu thu ật nối tắt dạ dày 
syt_sonla_vt_So Y te Son La_22/10/2022 22:04:0319 
Phẫu thu ật nối tắt dạ dày có nh ững bi ến chứng sau m ổ khi theo dõi trong th ời gian dài 
như thi ếu hụt vitamin và các vi ch ất, loét mi ệng nối hay thoát v ị nội. Tăng cân tr ở lại 
cũng có th ể xuất hiện do giãn d ạ dày và ru ột non.  
d. Phẫu thu ật phân lưu m ật tụy 
Năm 1976, t ại Genoa Scopinaro đã phát tri ển kỹ thuật phân lưu m ật tụy (biliopancreatic 
diversion BPD). K ỹ thuật này bao g ồm cắt gần toàn b ộ dạ dày, phân lưu d ịch m ật và t ụy 
làm gi ảm hấp thu th ức ăn. Khác v ới phẫu thu ật nối tắt hỗng-hồi tràng, k ỹ thuật phân lưu 
mật tụy không có đ ầu ruột non t ận tự do. Ph ần ruột non đư ợc nối với hồi tràng cách góc 
hồi manh tràng 50 cm. Trong vài tháng đ ầu sau m ổ lượng th ức ăn c ủa bệnh nhân có th ể 
không thay đ ổi, nhưng cân n ặng vẫn giảm do gi ảm hấp thu ở ruột. 
 
Hình 6.4. Phẫu thu ật phân lưu m ật tụy 
Phẫu thuật phân lưu m ật tụy ưu th ế hơn so với các ph ẫu thu ật giảm béo khác, tuy nhiên 
phẫu thu ật này có như ợc điểm là có nhi ều biến chứng hơn , bệnh nhân d ễ bị thiếu hụt vi 
chất vitamin, rò, loét mi ệng nối và thoát v ị nội.  
e. Phẫu thu ật đảo dòng tá tràng  
Hess phát tri ển kỹ thuật đảo dòng tá tràng t ừ kỹ thuật phân lưu m ật tụy của Scopinaro. 
DeMeester phát tri ển kỹ thuật này đ ể điều trị luồng trào ngư ợc dịch m ật từ tá tràng lên 
thực quản. DeMeester nh ận thấy bảo tồn cơ th ắt môn v ị làm gi ảm biến chứng loét mi ệng 
nối tá tràng - ruột non. D ạ dày đư ợc tạo hình b ằng cách c ắt theo chi ều dọc, kỹ thuật này 
hiện nay đư ợc áp d ụng ph ổ biến trong ph ẫu thu ật tạo hình d ạ dày ống đ ứng (sleeve 
gastrectomy). Vi ệc tạo hình d ạ dày theo chi ều dọc cũng giúp gi ảm tỷ lệ loét mi ệng nối 
do làm gi ảm thể tích d ạ dày. 
syt_sonla_vt_So Y te Son La_22/10/2022 22:04:0320 
 
Hình 6.5. Phẫu thu ật đảo dòng tá tràng  
Phẫu thu ật đảo dòng tá tràng có hi ệu quả giảm cân cao tuy nhiên phương pháp này có 
nhiều biến chứng sau m ổ. Phẫu thu ật giảm béo d ựa trên gi ảm hấp thu th ức ăn nên sau m ổ 
bệnh nhân có nh ững rối loạn thiếu hụt vitamin và vi ch ất nặng cần bổ sung.  
f. Phẫu thu ật nối tắt dạ dày v ới 1 mi ệng nối (mini gastric bypass)  
Kỹ thuật này đư ợc thực hiện lần đầu tiên b ởi Rutledge vào năm 1998 t ại Mỹ. Với kỹ 
thuật này ph ẫu thu ật viên s ẽ tạo một ống dạ dày d ọc bờ cong nh ỏ và đưa ru ột non lên n ối 
với ống dạ dày này theo ki ểu omega, mi ệng nối dạ dày ru ột cách góc Treitz 200 cm tùy 
thuộc vào BMI c ủa bệnh nhân.  
 
Hình 6.6. Phẫu thu ật nối tắt dạ dày v ới 1 mi ệng nối (mini gastric bypass)  
Phẫu thu ật nối tắt dạ dày v ới một miệng nối là m ột phẫu thu ật hiệu quả tuy nhiên khi theo 
dõi lâu dài ph ẫu thu ật có các bi ến chứng như thi ếu hụt vitamin, vi ch ất, rò, loét mi ệng 
nối (1% đ ến 6%), thoát v ị nội. 
syt_sonla_vt_So Y te Son La_22/10/2022 22:04:0321 
g. Phẫu thu ật khâu g ấp nếp dạ dày:  
Phẫu thu ật khâu g ấp nếp dạ dày đư ợc thực hiện lần đầu tiên b ởi Talebpour t ại Iran vào 
năm 2002. Ph ần bờ cong l ớn dạ dày đư ợc khâu g ấp nếp lại dọc theo chi ều dài b ằng ch ỉ 
không tiêu. Vi ệc khâu t ạo nếp gấp có th ể bắt đầu từ phía tâm v ị hay phía môn v ị. 
 
Hình 6.7.  Phẫu thu ật khâu g ấp nếp dạ dày 
Phương pháp này có ưu đi ểm là không có miệng nối, không ph ải cắt bỏ dạ dày nên t ỷ lệ 
biến chứng viêm phúc m ạc hay rò d ạ dày r ất thấp hoặc gần như không có. Ngoài ra do 
không ph ải sử dụng dụng cụ khâu n ối tiêu hóa t ự động nên chi phí cho cu ộc mổ sẽ thấp 
hơn so v ới các phương pháp khác. Tuy nhiên  tỷ lệ tăng cân tr ở lại do d ạ dày giãn ra cũng 
gặp sau m ổ lên tới 31% sau 3 năm theo Talebpour và c ộng sự. 
Đối với hiệu quả cải thiện các b ệnh ph ối hợp như đái tháo đư ờng, tăng huyết áp hay r ối 
loạn mỡ máu thì hi ệu quả của phẫu thu ật này th ấp hơn so v ới các phương pháp ph ẫu thu ật 
khác.  
h. Phẫu thu ật tạo hình d ạ dày 
 
Hình  6.8. Phẫu thu ật tạo hình d ạ dày 
Phẫu thu ật tạo hình d ạ dày đư ợc Mason phát tri ển từ những năm 1980, ph ẫu thu ật này 
được thực hiện bởi một đai vòng quanh d ạ dày ở phần thấp với một cửa sổ được tạo ra 
syt_sonla_vt_So Y te Son La_22/10/2022 22:04:0322 
bởi dụng cụ cắt nối tự động ở phần thân v ị sát b ờ cong nh ỏ dạ dày. Phẫu thu ật này có 
hiệu quả tương t ự như ph ẫu thu ật đặt vòng th ắt dạ dày nhưng ph ức tạp hơn và có nhi ều 
biến chứng như nôn, trào ngư ợc, loét đai…  
i. Đặt bóng d ạ dày (intragastric ballon  - IRB)  
Đây là m ột phương pháp đi ều trị béo phì t ạm thời và xâm l ấn tối thiểu, ban đ ầu được phát 
triển sau khi quan sát th ấy sự hiện diện của khối choáng ch ỗ dẫn đến giảm cân thông qua 
tăng c ảm giác no. Đây là m ột phương pháp n ội soi, nó đư ợc định vị giữa điều trị thuốc 
và ph ẫu thu ật, hiện đang là li ệu pháp đi ều trị béo phì xâm l ấn tối thiểu đư ợc sử dụng 
nhiều nhất. Bóng trong d ạ dày ho ạt động như m ột thiết bị lấy đầy không gian trong lòng 
dạ dày, làm gi ảm dung tích d ạ dày và gây c ảm giác no. Có nhi ều thiết bị IRB khác nhau, 
có th ể chứa chất lỏng hay không khí, có th ể điều chỉnh th ể tích hay không, nhưng không 
có sự khác bi ệt đáng k ể về giảm cân gi ữa những thi ết bị này.  
 
Hình 6.9. K ỹ thuật đặt bóng d ạ dày 
Nhiều nghiên c ứu đã ch ỉ ra hiệu quả của đặt bóng d ạ dày trong vi ệc giảm cân ng ắn hạn, 
với những cải thiện đáng k ể về các b ệnh đồng m ắc liên quan đ ến béo phì. Đ ặt bóng d ạ 
dày có ch ỉ định rộng rãi, t ừ những người thừa cân (ch ỉ số khối cơ th ể BMI ≥ 27 kg/m²),  
đến những ngư ời béo phì không đáp ứng các tiêu chí cho phẫu thu ật giảm béo  và cho 
người siêu béo phì (BMI ≥ 50 kg/m²), như m ột tiền đề cho ph ẫu thu ật giảm béo. D ựa trên 
những dự liệu an toàn t ốt, đặt bóng d ạ dày cũng có th ể được sử dụng ở những bệnh nhân 
béo phì đ ủ điều kiện phẫu thu ật giảm béo nhưng có nguy cơ cao b ị các tác d ụng phụ của 
phẫu thu ật hoặc không mu ốn trải qua th ủ thuật.  
syt_sonla_vt_So Y te Son La_22/10/2022 22:04:0323 
j. Một số nhận xét v ề việc áp dụng các phương pháp ph ẫu thu ật điều trị béo phì  
Phẫu thu ật tạo hình d ạ dày ống đứng chi ếm tỷ lệ cao nh ất trong các phương pháp ph ẫu 
thuật giảm béo giai đo ạn 2015 -2018 tăng 30,8%, ti ếp theo là ph ẫu thu ật nối tắt dạ dày, 
phẫu thu ật đặt vòng th ắt dạ dày có t ỷ lệ giảm còn 1/3 so v ới các giai đo ạn trư ớc, ph ẫu 
thuật phân lưu m ật tụy tăng s ố lượng gấp đôi trong giai đo ạn 2015 -2018.  
Trong giai đo ạn 2005 đ ến 2009 t ại châu Á có 6 598 b ệnh nhân đư ợc phẫu thu ật giảm béo 
trong đó ph ẫu thu ật đặt vòng th ắt dạ dày chi ếm tỷ lệ cao nh ất 35,9%, ph ẫu thu ật nối tắt 
dạ dày ru ột chiếm tỷ lệ 24,3%, ph ẫu thu ật tạo hình d ạ dày ống đứng chi ếm tỷ lệ 19,5%, 
phẫu thu ật nối tắt dạ dày v ới một miệng nối chiếm tỷ lệ 15,4%.  
Tại Hàn Qu ốc vào năm 2013 có 1686 ca ph ẫu thu ật giảm béo đư ợc thực hiện trong đó 
phẫu thu ật đặt vòng th ắt dạ dày chi ếm tỷ lệ 67,2%, ph ẫu thu ật tạo hình d ạ dày hình ống 
đứng chi ếm tỷ lệ 14,2%, ph ẫu thu ật nối tắt dạ dày h ỗng tràng chi ếm tỷ lệ 12,8%, các 
phương pháp khác chi ếm tỷ lệ 3,3%. Vào năm 2016 t ỷ lệ này t ại Hàn Qu ốc thay đ ổi như 
sau: ph ẫu thu ật tạo hình d ạ dày ống đứng chi ếm tỷ lệ 43,6%, ph ẫu thu ật nối tắt dạ dày 
chiếm tỷ lệ 13,5%, ph ẫu thu ật đặt vòng th ắt dạ dày chi ếm kho ảng 40%.  
7. BÉO PHÌ Ở TRẺ EM VÀ THANH THIẾU NIÊN  
Béo phì ở trẻ em và thanh thi ếu niên đang gia tăng nhanh chóng do thay đ ổi chế độ ăn 
uống, môi trư ờng sống, gi ảm ho ạt động th ể lực. Đây là một bệnh mãn tính khó đi ều trị 
và dễ dàng phát tri ển thành béo phì ở người lớn, đòi h ỏi một chế độ ăn uống lành m ạnh 
và lối sống năng đ ộng trong su ốt cuộc đời. Do đó, nên thi ết lập chính sách nh ằm phát 
hiện và đi ều trị sớm. 
Để đánh giá tình tr ạng béo phì  ở trẻ em và thanh thi ếu niên, đi ều quan tr ọng là  đánh giá xu 
hướng béo phì theo t ốc độ tăng trư ởng và tình tr ạng phát tri ển thông qua vi ệc kiểm tra thư ờng 
xuyên.  Đối với trẻ em từ 2 tuổi trở lên và thanh thi ếu niên, BMI phân bi ệt theo tu ổi và gi ới 
tính và thư ờng đư ợc gọi là BMI theo tu ổi. Tuổi được tính b ằng tháng.  
Bảng 7.1. Phân lo ại tình tr ạng cân n ặng dựa trên BMI theo tu ổi  
và bách phân v ị tương ứng 
 
Phân lo ại Bách phân v ị 
Thiếu cân  < 5 
Bình thư ờng 5 - < 85 
Thừa cân  85 - < 95 
Béo phì  95 
Điều trị béo phì ở trẻ em và thanh thi ếu niên điều quan tr ọng là duy trì cân n ặng thích 
hợp dựa trên vi ệc thay đ ổi lối sống. Orlistat và Liraglutide 3,0 mg là thu ốc được Cục 
Quản lý Th ực phẩm và Dư ợc phẩm Hoa K ỳ (FDA) và Cơ quan dư ợc phẩm Châu Âu 
(EMA) p hê duy ệt để sử dụng cho nh ững ngư ời trên 12 tu ổi. 
8. KẾT LUẬN  
Béo p hì là m ột căn b ệnh làm tăng gánh n ặng về kinh t ế xã hội do tăng nguy cơ m ắc các 
bệnh đi kèm liên quan đ ến béo phì. Vi ệc quản lý đư ợc béo phì là đa y ếu tố, các phương 
pháp đi ều trị béo phì bao g ồm các can thi ệp toàn di ện về lối sống như li ệu pháp dinh 
dưỡng, hoạt động th ể chất, liệu pháp tâm lý và s ử dụng thu ốc.  
  syt_sonla_vt_So Y te Son La_22/10/2022 22:04:0324 
Phụ lục:  Thuốc điều trị bệnh béo phì  
 
 
Nội dung  Orlistat  Liraglutide  
Đường dùng  Uống Tiêm dư ới da 
Liều lượng, s ố lần 120 mg x 3 l ần/ngày  3,0mg/ngày  
Tác đ ộng giảm % cân n ặng 
tại thời điểm 1 năm,  trừ giả 
dược Giảm 2,9% Giảm 5,4% 
Tác đ ộng dài h ạn trên cân 
nặng, tr ừ giả dược  Giảm 2,8kg t ại thời điểm 
4 năm  Giảm 4,2% t ại thời điểm 
3 năm 
% bệnh nhân đ ạt giảm ≥ 5% 
cân n ặng tại thời điểm 1 năm  54% (so v ới 33% ở giả 
dược) 63,2% (so v ới 27,1% ở 
giả dược) 
% bệnh nhân đ ạt giảm ≥ 10% 
cân n ặng tại thời điểm 1 năm  26% (so v ới 14% ở giả 
dược) 33,1% (so v ới 10,6% ở 
giả dược) 
Hiệu quả duy trì gi ảm cân 
trước đó Tăng cân l ại ít hơn 2,4kg 
so với giả dược trong hơn 
3 năm  Giảm thêm  6% cân n ặng 
trừ giả dược lúc 1 năm 
Tác đ ộng trên ti ền đái tháo 
đường  Giảm 37,3% nguy cơ di ễn 
tiến đến đái tháo đư ờng 
típ 2 trong hơn 4 năm Giảm 79% nguy cơ di ễn 
tiến đến đái tháo đư ờng 
típ 2 trong hơn 3 năm  
Tác đ ộng trên huy ết áp t ại 
thời điểm 1 năm, tr ừ giả dược Giảm 1,9 mmHg HATT  
Giảm 1,5 mmHg HATTr  Giảm 2,8 mmHg HATT  
Giảm 0,9 mmHg HATTr  
Tác đ ộng trên lipid t ại thời 
điểm 1 năm, tr ừ giả dược Giảm 0,27 mmol/L 
Cholesterol toàn ph ần 
Giảm 0,21 mmol/L LDL  
Giảm 0,02 mmol/L HDL  
Giảm 0,00 mmol/L TG Giảm 2,3% Cholesterol 
toàn ph ần  
Giảm 2,4% LDL  
Tăng1,9% HDL  
Giảm 3,9% non -HDL  
Giảm 9,3% TG  
Tác đ ộng trên nh ịp tim t ại 
thời điểm 1 năm, tr ừ giả dược Không thay đ ổi Tăng 2,4 nh ịp/phút 
Tác đ ộng trên HbA1C ở bệnh 
nhân đái tháo đư ờng tại thời 
điểm 1 năm, tr ừ giả dược Giảm 0,4% Giảm 1,0% 
Tác đ ộng trên viêm gan 
nhiễm mỡ không do rư ợu  
(Nonalcoholic 
steatohepatitis - NASH)  Không c ải thiện Cải thiện 
Tác đ ộng trên bu ồng tr ứng đa 
nang  (Polycystic Ovary 
Syndrome – PCOS)  Chưa nghiên c ứu  Giảm 5,2kg cân n ặng trừ 
giả dược lúc 6 tháng; 
không có d ữ liệu trên chu 
kì kinh nguy ệt 
Tác đ ộng trên thoái hoá kh ớp 
(Osteoarthritis - OA) Chưa nghiên c ứu  Chưa nghiên c ứu  
Tác đ ộng trên ngưng th ở khi 
ngủ (Obstructive Sleep 
Apnea – OSA)  Chưa nghiên c ứu  Giảm Ch ỉ số ngưng th ở- 
giảm thở (Apnea -
Hypopnea Index -AHI) 
đến 6/giờ syt_sonla_vt_So Y te Son La_22/10/2022 22:04:0325 
Nội dung  Orlistat  Liraglutide  
Chống ch ỉ định  
 - Tắc mật 
- Hội chứng rối loạn 
hấp thu m ạn tính  
- Có thai  - Tiền sử viêm t ụy 
- Tiền sử bản thân hay 
gia đình m ắc ung thư 
tuyến giáp th ể tủy, 
- Tiền sử bản thân m ắc 
hội chứng MEN2  
- Có thai  
Tác d ụng ph ụ thường gặp Tiêu phân l ỏng, m ỡ, trung 
tiện nhiều Buồn nôn, táo bón, tiêu 
chảy, nôn  
Tác d ụng ph ụ hiếm gặp - Suy gan  
- Sỏi thận 
- Tổn thương th ận cấp Viêm t ụy do s ỏi đường 
mật 
Tương tác thu ốc - Vitamin tan trong m ỡ 
- Levothyroxine  
- Cyclosporine  
- Kháng đông u ống, 
chống co gi ật Có th ể ảnh hư ởng đến sự 
hấp thu thuốc do ch ậm 
làm tr ống dạ dày 
 
 
  syt_sonla_vt_So Y te Son La_22/10/2022 22:04:0326 
TÀI LIỆU THAM KHẢO  
Tiếng Vi ệt 
1. Bộ Y tế (2020), "Hư ớng dẫn chẩn đoán và đi ều trị đái tháo đư ờng típ 2”, Ban hành 
theo quy ết định số 5481/QĐ -BYT ngày 30 tháng 12 năm 2020  
2. Bộ Y tế (2021), K ết quả Tổng đi ều tra dinh dư ỡng toàn qu ốc 2017 – 2020, Bộ Y tế 
công b ố kết quả Tổng đi ểu tra Dinh dư ỡng năm 2019 -2020 - Tin n ổi bật - Cổng thông 
tin B ộ Y tế (moh.gov.vn)  
3. Hội Nội tiết- Đái tháo đư ờng Vi ệt Nam (2016), Ch ẩn đoán và đi ều trị một số bệnh 
nội tiết- chuy ển hóa, Nhà xu ất bản Y h ọc. 
Tiếng Anh  
4. Agrawal S. (2016). Obesity, Bariatric and M etabolic Surgery, Springer Cham 
Heidelberg New York Dordrecht London.  
5. American Diabetes Association.12 Older adults: Standards of medical care in 
diabetes - 2021, Diabetes Care 2021; 44 (Suppl.1):S168 -S179  
6. Barlow SE and the Expert Committee. Expert committe e recommendations regarding 
the prevention, assessment, and treatment of child and adolescent overweight and 
obesity: summary report.  Pediatrics  2007;120 Supplement December 2007:S164 —
S192.  
7. Bo-Yeon Kim , Seon Mee Kang , Jee-Hyun Kang  et al,  Committee of Clinical Practice 
Guidelines, Korean Society for the Study of Obesity (KSSO) . 2020 Korean Society 
for the Study of Obesity Guidelines for the Management of Obesity in Korea. J Obes 
Metab Syndr. 2021 Jun 30;30(2):81 -92. doi: 10.7570/jomes21022.  
8. Chanoine JP, Hampl S, Jensen C, Boldrin M, Hauptman J. Effect of orlistat on weight 
and body composition in obe se adolescents: a randomized controlled trial. JAMA 
2005;293: 2873 -83.  
9. Chiu CJ, Birch DW, Shi X, Karmali S. Outcomes of the adjustable gastric band in a 
publicly funded obesity program. Can J Surg. 2013 Aug;56(4):233 -6. doi: 
10.1503/cjs.002712. PMID: 2388 3492; PMCID: PMC3728241.  
10.  Cote AT, Harris KC, Panagiotopoulos C, et al. Childhood obesity and cardiovascular 
dysfunction.  J Am Coll Cardiol  2013; 62 (15):1309 –1319.  
11.  Gallagher, D. A Guide to Methods for Assessing Childhood Obesity. Washington 
(DC): Nationa l Collaborative on Childhood Obesity Research. June 2020.  
12. General Department of Preventive Medicine, Ministry of Health, 2016 National 
Survey on the risk factors of non communicable diseases (STEPS) Viet Nam 2015.  
13. Korea Disease Control and Prevention Agenc y. Growth charts for children and 
adolescents. Cheongju: Korea Disease Con trol and Prevention Agency; 2017.  
14.  Matson KL, Fallon RM. Treatment of obesity in children and adolescents. J Pediatr 
Pharmacol Ther 2012;17:45 -57. 
15. Marceau P, Biron S, Marceau S, Hou ld FS, Lebel S, Lescelleur O, Biertho L, Kral 
JG. Biliopancreatic diversion -duodenal switch: independent contributions of sleeve 
resection and duodenal exclusion. Obes Surg. 2014 Nov;24(11):1843 -9. doi: 
10.1007/s11695 -014-1284 -0. PMID: 24839191.  syt_sonla_vt_So Y te Son La_22/10/2022 22:04:0327 
16. Meneses E,  Zagales I, Fanfan D, Zagales R, McKenney M, Elkbuli A. Surgical, 
metabolic, and prognostic outcomes for Roux -en-Y gastric bypass versus sleeve 
gastrectomy: a systematic review. Surg Obes Relat Dis. 2021 Dec;17(12):2097 -2106. 
doi: 10.1016/j.soard.2021.06.0 20. Epub 2021 Jul 7. PMID: 34642101.  
17. Ohta M. et al (2019). Bariatric/Metabolic Surgery in the Asia -Pacific Region: 
APMBSS 2018 Survey. Obes Surg, 29(2), 534 -541. 
18. Rutledge R. and Walsh T.R. (2005). Continued excellent results with the mini -gastric 
bypass: s ix-year study in 2,410 patients. Obesity surgery, 15(9), 1304 -1308.  
19. Sarela A.I. et al (2012). Long -term follow -up after laparoscopic sleeve gastrectomy: 
8–9-year results. Surgery for Obesity and Related Diseases, 8(6), 679 -684 
20. Sean Wharton  et al. Obesity i n adults: a clinical practice guideline. CMAJ August 04, 
2020; 192 (31) E875 -E891. DOI:  7 
21. Scopinaro N. et al (1998). Biliopancreatic diversion. World j ournal of surgery, 22(9), 
936-946 
22. Tackling obesity in ASEAN - Prevalence, impact, and guidance on interventions, The 
Economist Intelligence Unit Limited 201 7 
23. WHO -WPR World Health Organization. Regional Office for the Western 
Pacific.  (2000) . The Asia-Pacific perspective : redefining obesity and its 
treatment.  Sydney : Health Communications Australia.  6 
24. World Health Organization. Report of a WHO Consultation on Obesity. June 1997. 
Available at: http://whqlibdoc.who.int/hq/1998/WHO_NUT_NCD_98.1_(p1 -
158).pdf  
 syt_sonla_vt_So Y te Son La_22/10/2022 22:04:03**
Sự khởi phát sớm hơn của bệnh tiểu đường loại 2, bệnh tim và mạch máu, trầm cảm liên quan đến tình trạng béo phì ở trẻ em, thanh thiếu niên và người lớn. Người béo phì càng lâu thì các yếu tố nguy cơ liên quan đến béo phì càng trở nên đáng kể. Các bệnh mãn tĩnh có liên quan đến béo phì khó điều trị. Chính vì thế, việc phòng ngừa là vô cùng quan trọng. Ngăn ngừa béo phì sẽ hạn chế nguy cơ:
  * Bệnh tiểu đường tuýp 2
  * Bệnh huyết áp cao
  * Bệnh tim mạch
  * Chứng ngưng thở lúc ngủ
  * Bệnh túi mật
  * Các vấn đề sức khỏe tình dục
  * Bệnh gan nhiễm mỡ không do rượu
  * Viêm xương khớp.


Tập trung ngăn ngừa nguy cơ béo phì và tập thói quen sống lành mạnh có thể làm chậm hoặc ngăn chặn sự phát triển của các bệnh trên. Để giúp người bệnh có thể thành công hơn trong ngăn chặn và cải thiện tình trạng béo phì, Bệnh viện Nguyễn Tri Phương đã thành lập phòng khám tư vấn và điều trị giảm cân
  * [Bệnh béo phì được định nghĩa như thế nào?](https://bvnguyentriphuong.com.vn/kien-thuc-cho-nguoi-benh/phong-kham-tu-van-va-dieu-tri-giam-can-tai-benh-vien-nguyen-tri-phuong#bnh-bo-ph-c-nh-ngha-nh-th-no)
  * [1 Đối với người lớn](https://bvnguyentriphuong.com.vn/kien-thuc-cho-nguoi-benh/phong-kham-tu-van-va-dieu-tri-giam-can-tai-benh-vien-nguyen-tri-phuong#1-i-vi-ngi-ln)
  * [2 Đối với trẻ em](https://bvnguyentriphuong.com.vn/kien-thuc-cho-nguoi-benh/phong-kham-tu-van-va-dieu-tri-giam-can-tai-benh-vien-nguyen-tri-phuong#2-i-vi-tr-em)
  * [Thừa cân và bệnh béo phì gây ra những hậu quả gì?](https://bvnguyentriphuong.com.vn/kien-thuc-cho-nguoi-benh/phong-kham-tu-van-va-dieu-tri-giam-can-tai-benh-vien-nguyen-tri-phuong#tha-cn-v-bnh-bo-ph-gy-ra-nhng-hu-qu-g)



## ️ Nguy cơ đau tim thường tăng lên vào những ngày Lễ

Có rất nhiều nghiên cứu cho thấy rằng những sự kiện được tổ chức với quy mô lớn, tầm cỡ quốc gia gây ra căng thẳng và áp lực đều có khả năng làm tăng nguy cơ đau tim. Ví dụ, người ta đã phát hiện ra rằng ở nước Đức nguy cơ đau tim tăng lên vào những ngày hội bóng đá như World Cup, những trận đá giao hữu quy mô lớn cũng làm tăng nguy cơ bệnh tim mạch rất cao. Hay thậm chí ở Thụy Điển, qua nghiên cứu người ta còn phát hiện rằng các nguy cơ bệnh tim thường xảy ra vào buổi sáng thứ Hai khi bắt đầu một tuần làm việc mới.
Các chuyên gia tim mạch cho rằng căng thẳng có thể làm tăng nguy cơ đau tim và đây không phải là một sự trùng hợp. Cảm xúc mạnh và nhiều căng thẳng làm tăng hoạt động amygdala trong não. Và những sự gia tăng này dẫn đến tình trạng viêm trong các động mạch làm tăng nguy cơ đột quy và các bệnh lý tim mạch. Hay chúng ta biết rằng, khi gặp tình trạng căng thẳng, nguy cơ đau tim có thể xảy ra chỉ trong một khoảng thời gian ngắn. Không chỉ vậy, nếu bạn bị stress và không kiểm soát được sẽ có nhiều khả năng mắc bệnh tim cao, rối loạn nhịp tim hoặc đột quỵ vì khi cơ thể chịu áp lực, não chúng ta phải vận động khiến cơ thể trở nên mệt mỏi, tâm trạng bất an, chán nản… làm tác động đến hệ thần kinh giao cảm tiết ra một số chất làm tim đập mạnh và nhanh hơn dẫn đến tim dễ bị thiếu máu cục bộ.
Đối với những ngày lễ, sự mệt mỏi sau một chuyến bay dài, tình trạng kẹt xe, giao thông ùn tắc hay những cuộc vui đùa kéo dài nhiều giờ, thức khuya và thay đổi thói quen thường xuyên có thể góp phần làm tăng thêm căng thẳng.
Uống rượu, bia, tiêu thụ nhiều thức ăn chứa chất béo quá mức cũng có thể là một yếu tố nguy cơ đau tim và hiện tượng rung nhĩ điều này có thể dẫn đến tình trạng xuất hiện cục máu đông và dẫn đến đột quỵ. Càng lớn tuổi cơ thể chúng ta tích tụ càng nhiều các mảng xơ vữa bám vào các thành mạch. Nếu bạn hút thuốc, bị cholesterol cao, tiểu đường, hoặc thừa cân dẫn đến nguy cơ các bệnh lý về tim mạch vào các dịp lễ thậm chí còn cao hơn khi lượng tiêu thụ chúng vào các dịp lễ tăng lên một cách đáng kể. Nhưng khi ăn uống một cách kiểm soát, không quá đà trong các bữa tiệc và có một tâm lý hưởng thụ kỳ lễ thoải mái chúng ta hoàn toàn có thể tận hưởng một kỳ nghỉ vui vẻ và an toàn.
Khi có cảm giác tim đập nhanh, khó thở, nhịp thở không đều đó có thể là một dấu hiệu của rung nhĩ và nên đến gặp bác sĩ ngay lập tức, đặc biệt khi bạn chưa từng cảm thấy điều này xảy ra trước đây.
Xem thêm: [**Một số lời khuyên về thực phẩm và sức khỏe cho gan**](https://bvnguyentriphuong.com.vn/dinh-duong/mot-so-loi-khuyen-ve-thuc-pham-va-suc-khoe-cho-gan)
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh

## Những lưu ý cho người bệnh cao huyết áp vào mùa lạnh

  * [Ăn uống khoa học](https://bvnguyentriphuong.com.vn/kien-thuc-cho-nguoi-benh/nhung-luu-y-cho-nguoi-benh-cao-huyet-ap-vao-mua-lanh#n-ung-khoa-hc)
  * [Hạn chế rượu bia](https://bvnguyentriphuong.com.vn/kien-thuc-cho-nguoi-benh/nhung-luu-y-cho-nguoi-benh-cao-huyet-ap-vao-mua-lanh#hn-ch-ru-bia)
  * [Giữ tâm lý thoải mái](https://bvnguyentriphuong.com.vn/kien-thuc-cho-nguoi-benh/nhung-luu-y-cho-nguoi-benh-cao-huyet-ap-vao-mua-lanh#gi-tm-l-thoi-mi)
  * [Chú ý việc luyện tập](https://bvnguyentriphuong.com.vn/kien-thuc-cho-nguoi-benh/nhung-luu-y-cho-nguoi-benh-cao-huyet-ap-vao-mua-lanh#ch-vic-luyn-tp)
  * [4 ĐIỀU CẦN TRÁNH](https://bvnguyentriphuong.com.vn/kien-thuc-cho-nguoi-benh/nhung-luu-y-cho-nguoi-benh-cao-huyet-ap-vao-mua-lanh#4-iu-cn-trnh)
  * [Tránh đi ra ngoài vào trời lạnh](https://bvnguyentriphuong.com.vn/kien-thuc-cho-nguoi-benh/nhung-luu-y-cho-nguoi-benh-cao-huyet-ap-vao-mua-lanh#trnh-i-ra-ngoi-vo-tri-lnh)
  * [Tránh thức dậy quá sớm](https://bvnguyentriphuong.com.vn/kien-thuc-cho-nguoi-benh/nhung-luu-y-cho-nguoi-benh-cao-huyet-ap-vao-mua-lanh#trnh-thc-dy-qu-sm)
  * [Tránh tự ý ngừng uống thuốc kể cả khi huyết áp đã bình thường](https://bvnguyentriphuong.com.vn/kien-thuc-cho-nguoi-benh/nhung-luu-y-cho-nguoi-benh-cao-huyet-ap-vao-mua-lanh#trnh-t-ngng-ung-thuc-k-c-khi-huyt-p-bnh-thng)
  * [Tránh tắm nước lạnh](https://bvnguyentriphuong.com.vn/kien-thuc-cho-nguoi-benh/nhung-luu-y-cho-nguoi-benh-cao-huyet-ap-vao-mua-lanh#trnh-tm-nc-lnh)


Thời tiết lạnh rất bất lợi cho người bệnh cao huyết áp. Bởi nhiệt độ thấp khiến các mạch máu trong cơ thể co lại, huyết áp đột ngột tăng cao, dễ dẫn tới các biến chứng nguy hiểm chết người như tai biến mạch máu não, đột quỵ… Bài viết sau sẽ gửi tới độc giả những điều cần lưu ý khi vào mùa thu đông cho người bị cao huyết áp để không gặp phải những biến chứng nguy hiểm nêu trên.
## **5 ĐIỀU CẦN LÀM**
## **Giữ ấm cơ thể**
_Vào mùa lạnh cần mặc đủ ấm ngay cả khi ở trong nhà và khi ra ngoài._
Đây là điều cơ bản nhất mà người bệnh cao huyết áp cũng như bất cứ ai đều phải tuân thủ khi trời lạnh. Mặc đủ ấm ngay cả khi ở trong nhà và khi ra ngoài. Dùng khẩu trang che kín mũi, miệng nếu phải đi ra ngoài có gió lạnh để tránh hít thở không khí lạnh. Đeo tất tay, tất chân, quàng khăn ấm để không bị mất nhiệt, đảm bảo quá trình lưu thông máu diễn ra bình thường.
Tạo môi trường ấm áp khi làm việc, tập luyện và nghỉ ngơi. Có thể dùng máy điều hòa, máy sưởi hoặc bóng điện đỏ cho ấm nhưng tuyệt đối không dùng bếp than tổ ong hoặc than củi để sưởi ấm trong phòng kín dễ gây ngộ độc khí CO rất nguy hiểm.
### **Ăn uống khoa học**
Người bệnh cao huyết áp nên duy trì chế độ ăn nhạt, tránh xa các loại thực phẩm chứa nhiều muối như dưa, cà muối. Bên cạnh đó cũng nên hạn chế các thực phẩm giàu chất béo như nội tạng (tim, gan, óc, thận..), đồ ăn chiên rán nhiều dầu mỡ.
Tăng cường tiêu thụ những thực phẩm giàu dinh dưỡng như thịt nạc, gà, cá, sữa và chế phẩm từ đậu nành. Đừng bỏ qua rau xanh, ngũ cốc nguyên hạt, hoa quả tươi đặc biệt là cam, quýt, dưa hấu, bưởi…vì chúng giàu kali giúp lợi tiểu, hỗ trợ làm giảm huyết áp.
### **Hạn chế rượu bia**
Nhiều người vẫn nghĩ rượu bia là thức uống làm nóng cơ thể. Thực tế đồ uống có cồn là yếu tố nguy cơ hàng đầu trong việc khởi phát cơn tăng huyết áp cũng như các biến chứng của tăng huyết áp.
_Người bị cao huyết áp nên giữ tinh thần thư giãn, thoải mái và cân bằng._
### **Giữ tâm lý thoải mái**
Người bị cao huyết áp nên giữ tinh thần thoải mái, thư giãn, tránh căng thẳng lo âu. Những trạng thái tình cảm như lo lắng, căng thẳng, tức giận…sẽ gây ảnh hưởng đến huyết áp.
### **Chú ý việc luyện tập**
Tập luyện thể dục đều đặn là điều rất cần thiết với người bị cao huyết áp, vừa có tác dụng nâng cao khả năng vừa ổn định huyết áp. Nên lựa chọn các hình thức luyện tập nhẹ nhàng như đi bộ, tập dưỡng sinh, thái cực quyền, khí công, yoga…Khi tập thể dục nên chọn chỗ kín gió, ấm áp và khởi động kỹ trước khi tập. Những ngày thời tiết quá lạnh hãy tập trong nhà.
## **4 ĐIỀU CẦN TRÁNH**
### **Tránh đi ra ngoài vào trời lạnh**
Hạn chế đi ra ngoài vào trời lạnh nếu không có việc cần thiết, đặc biệt là vào ban đêm. Nếu không có nhà vệ sinh trong nhà, nên dậy sớm, mặc đủ ấm, mặc từ từ cho quen với nhiệt độ thấp bên ngoài sau đó mới ra.
### **Tránh thức dậy quá sớm**
Vì cơ thể sau một đêm nghỉ ngơi trên giường sẽ chưa đáp ứng kịp với sự thay đổi bên ngoài. Dậy quá sớm bước ra ngoài gặp cơn gió lạnh sáng sớm cũng sẽ khiến huyết áp tăng cao. Rất nhiều ca đột quỵ hoặc nhồi máu cơ tim buổi sáng gặp ở người cao tuổi dậy sớm tập thể dục.
_Người bệnh cao huyết áp tuyệt đối không được tự ý ngừng uống thuốc nếu không có chỉ định từ bác sĩ._
### **Tránh tự ý ngừng uống thuốc kể cả khi huyết áp đã bình thường**
Có không ít trường hợp tự ý ngừng uống thuốc khi huyết áp đã ổn định, khi thấy huyết áp đã tăng cao thì lại uống. Thói quen này sẽ khiến huyết áp tăng cao trở lại, thậm chí cao hơn cả trước khi điều trị, dễ dẫn tới những biến chứng nguy hiểm như nhồi máu cơ tim, xuất huyết não…
### **Tránh tắm nước lạnh**
Cần tắm nước ấm và khi tắm không nên đột ngột xối nước vào cơ thể mà hãy vớt nước ấm từ từ lên tay, chân rồi mới đến cơ thể để tránh sự thay đổi nhiệt đột ngột.
Đặc biệt người bệnh cần biết “lắng nghe cơ thể”, khi phát hiện có những biểu hiện như mệt mỏi, nhức đầu, chóng mặt, buồn nôn, yếu chi, nói khó, đau tức ngực, mất vận động, mất thị lực thoáng qua…cần kiểm tra huyết áp ngay. Nếu huyết áp có bất thường, cần nhanh chóng đến bệnh viện để điều trị kịp thời.
**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/) **- Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [Ăn uống khoa học](https://bvnguyentriphuong.com.vn/kien-thuc-cho-nguoi-benh/nhung-luu-y-cho-nguoi-benh-cao-huyet-ap-vao-mua-lanh#n-ung-khoa-hc)
  * [Hạn chế rượu bia](https://bvnguyentriphuong.com.vn/kien-thuc-cho-nguoi-benh/nhung-luu-y-cho-nguoi-benh-cao-huyet-ap-vao-mua-lanh#hn-ch-ru-bia)
  * [Giữ tâm lý thoải mái](https://bvnguyentriphuong.com.vn/kien-thuc-cho-nguoi-benh/nhung-luu-y-cho-nguoi-benh-cao-huyet-ap-vao-mua-lanh#gi-tm-l-thoi-mi)
  * [Chú ý việc luyện tập](https://bvnguyentriphuong.com.vn/kien-thuc-cho-nguoi-benh/nhung-luu-y-cho-nguoi-benh-cao-huyet-ap-vao-mua-lanh#ch-vic-luyn-tp)
  * [4 ĐIỀU CẦN TRÁNH](https://bvnguyentriphuong.com.vn/kien-thuc-cho-nguoi-benh/nhung-luu-y-cho-nguoi-benh-cao-huyet-ap-vao-mua-lanh#4-iu-cn-trnh)
  * [Tránh đi ra ngoài vào trời lạnh](https://bvnguyentriphuong.com.vn/kien-thuc-cho-nguoi-benh/nhung-luu-y-cho-nguoi-benh-cao-huyet-ap-vao-mua-lanh#trnh-i-ra-ngoi-vo-tri-lnh)
  * [Tránh thức dậy quá sớm](https://bvnguyentriphuong.com.vn/kien-thuc-cho-nguoi-benh/nhung-luu-y-cho-nguoi-benh-cao-huyet-ap-vao-mua-lanh#trnh-thc-dy-qu-sm)
  * [Tránh tự ý ngừng uống thuốc kể cả khi huyết áp đã bình thường](https://bvnguyentriphuong.com.vn/kien-thuc-cho-nguoi-benh/nhung-luu-y-cho-nguoi-benh-cao-huyet-ap-vao-mua-lanh#trnh-t-ngng-ung-thuc-k-c-khi-huyt-p-bnh-thng)
  * [Tránh tắm nước lạnh](https://bvnguyentriphuong.com.vn/kien-thuc-cho-nguoi-benh/nhung-luu-y-cho-nguoi-benh-cao-huyet-ap-vao-mua-lanh#trnh-tm-nc-lnh)



## Mẹo ngăn ngừa bệnh tim bạn cần biết

  * [1. Kiểm soát cân nặng – Ngưng hút thuốc](https://bvnguyentriphuong.com.vn/kien-thuc-cho-nguoi-benh/meo-ngan-ngua-benh-tim-ban-can-biet#1-kim-sot-cn-nng-ngng-ht-thuc)
  * [2. Giảm chất béo bão hòa – tránh chất béo xấu](https://bvnguyentriphuong.com.vn/kien-thuc-cho-nguoi-benh/meo-ngan-ngua-benh-tim-ban-can-biet#2-gim-cht-bo-bo-ha-trnh-cht-bo-xu)
  * [3. Hạn chế thực phẩm giàu năng lượng, ít giá trị dinh dưỡng](https://bvnguyentriphuong.com.vn/kien-thuc-cho-nguoi-benh/meo-ngan-ngua-benh-tim-ban-can-biet#3-hn-ch-thc-phm-giu-nng-lng-t-gi-tr-dinh-dng)
  * [4. Tập thể dục đều đặn](https://bvnguyentriphuong.com.vn/kien-thuc-cho-nguoi-benh/meo-ngan-ngua-benh-tim-ban-can-biet#4-tp-th-dc-u-n)
  * [5. Tăng cường thực phẩm giàu chất xơ – ít calo](https://bvnguyentriphuong.com.vn/kien-thuc-cho-nguoi-benh/meo-ngan-ngua-benh-tim-ban-can-biet#5-tng-cng-thc-phm-giu-cht-x-t-calo)
  * [6. Ăn các loại hạt và cá giàu omega-3](https://bvnguyentriphuong.com.vn/kien-thuc-cho-nguoi-benh/meo-ngan-ngua-benh-tim-ban-can-biet#6-n-cc-loi-ht-v-c-giu-omega3)
  * [7. Bổ sung các vitamin và khoáng chất tốt cho tim](https://bvnguyentriphuong.com.vn/kien-thuc-cho-nguoi-benh/meo-ngan-ngua-benh-tim-ban-can-biet#7-b-sung-cc-vitamin-v-khong-cht-tt-cho-tim)
  * [8. Tập trung vào vi chất có lợi cho tim mạch](https://bvnguyentriphuong.com.vn/kien-thuc-cho-nguoi-benh/meo-ngan-ngua-benh-tim-ban-can-biet#8-tp-trung-vo-vi-cht-c-li-cho-tim-mch)
  * [9. Quản lý căng thẳng hiệu quả](https://bvnguyentriphuong.com.vn/kien-thuc-cho-nguoi-benh/meo-ngan-ngua-benh-tim-ban-can-biet#9-qun-l-cng-thng-hiu-qu)


Bệnh tim mạch là nguyên nhân hàng đầu gây tử vong trên toàn thế giới. Tuy nhiên, phần lớn các yếu tố nguy cơ **có thể kiểm soát được thông qua lối sống lành mạnh**. Dưới đây là 9 mẹo khoa học giúp **bảo vệ trái tim khỏe mạnh** từ hôm nay:
### **1. Kiểm soát cân nặng – Ngưng hút thuốc**
  * **Duy trì cân nặng lý tưởng** giúp giảm gánh nặng cho tim và huyết áp
  * **Từ bỏ thuốc lá** là hành động quan trọng nhất để giảm nguy cơ nhồi máu cơ tim và đột quỵ
  * Tránh hút thuốc thụ động và môi trường ô nhiễm


_Kiểm soát cân nặng phòng ngừa bệnh tim mạch_
### **2. Giảm chất béo bão hòa – tránh chất béo xấu**
  * Hạn chế **mỡ động vật, bơ, kem, phô mai béo**
  * Ưu tiên chất béo không bão hòa (dầu ô liu, dầu hạt cải, omega-3 từ cá biển)
  * Giảm tiêu thụ thực phẩm chế biến chứa **trans fat (chất béo chuyển hóa)** vì làm tăng LDL và giảm HDL


### **3. Hạn chế thực phẩm giàu năng lượng, ít giá trị dinh dưỡng**
  * Tránh: **đồ chiên rán, snack, khoai tây chiên, thực phẩm đóng hộp nhiều đường muối**
  * Các loại này dễ gây **tăng cân, béo phì, kháng insulin** , góp phần gây **xơ vữa mạch và bệnh mạch vành**


## **4. Tập thể dục đều đặn**
  * Mỗi ngày ít nhất **30 phút hoạt động thể chất vừa phải** (đi bộ nhanh, bơi lội, đạp xe…)
  * Giúp giảm **huyết áp, cholesterol LDL, cải thiện HDL và kiểm soát đường huyết**
  * Cải thiện tâm trạng, giảm stress, tăng tuổi thọ


_Hạn chế những thực phẩm ít chất dinh dưỡng, đô ăn nhanh, chế biến sẵn_
## **5. Tăng cường thực phẩm giàu chất xơ – ít calo**
  * Ưu tiên **rau xanh, trái cây tươi, đậu, ngũ cốc nguyên hạt**
  * Chất xơ giúp **hạ cholesterol, kiểm soát cân nặng, ổn định đường huyết**
  * Nên ăn tối thiểu **25–30g chất xơ mỗi ngày**


## **6. Ăn các loại hạt và cá giàu omega-3**
  * Hạt hạnh nhân, óc chó, hướng dương, hạt lanh… cung cấp **acid béo có lợi**
  * Cá béo như **cá hồi, cá thu, cá mòi** giàu **omega-3** , giúp **chống viêm, ngăn hình thành cục máu đông**
  * Thay mỡ động vật bằng **dầu ô liu, dầu hạt cải**


## **7. Bổ sung các vitamin và khoáng chất tốt cho tim**
  * **Vitamin C, E, D, B3, B6, B12, acid folic** hỗ trợ:
    * Giảm **homocysteine** – một chất làm tăng nguy cơ xơ vữa mạch
    * Cải thiện chuyển hóa cholesterol
  * Có thể bổ sung qua thực phẩm hoặc tư vấn bác sĩ về chế phẩm bổ sung


_Giảm căng thẳng ngừa nguy cơ bệnh tim bộc phát_
## **8. Tập trung vào vi chất có lợi cho tim mạch**
  * **Coenzyme Q10** : Chống oxy hóa, cải thiện năng lượng tim
  * **L-carnitine** : Giúp tim sử dụng acid béo hiệu quả
  * **Niacin (vitamin B3)** : Giảm LDL, tăng HDL
  * **Chromium** : Hỗ trợ chuyển hóa glucose và lipid


Chỉ sử dụng khi **có chỉ định của bác sĩ chuyên khoa**
## **9. Quản lý căng thẳng hiệu quả**
  * Căng thẳng kéo dài làm tăng **huyết áp, nhịp tim, cortisol** → hại tim
  * Học cách **thư giãn, hít thở sâu, tập yoga, thiền**
  * Duy trì **lối sống tích cực, giao tiếp lành mạnh, ngủ đủ giấc**


## **LỜI KẾT**
Chìa khóa để **ngăn ngừa bệnh tim mạch** không nằm ở một biện pháp duy nhất, mà là sự kết hợp giữa **dinh dưỡng hợp lý, vận động thể chất, tinh thần ổn định và kiểm soát tốt các yếu tố nguy cơ**.
**[Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/) **- Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [1. Kiểm soát cân nặng – Ngưng hút thuốc](https://bvnguyentriphuong.com.vn/kien-thuc-cho-nguoi-benh/meo-ngan-ngua-benh-tim-ban-can-biet#1-kim-sot-cn-nng-ngng-ht-thuc)
  * [2. Giảm chất béo bão hòa – tránh chất béo xấu](https://bvnguyentriphuong.com.vn/kien-thuc-cho-nguoi-benh/meo-ngan-ngua-benh-tim-ban-can-biet#2-gim-cht-bo-bo-ha-trnh-cht-bo-xu)
  * [3. Hạn chế thực phẩm giàu năng lượng, ít giá trị dinh dưỡng](https://bvnguyentriphuong.com.vn/kien-thuc-cho-nguoi-benh/meo-ngan-ngua-benh-tim-ban-can-biet#3-hn-ch-thc-phm-giu-nng-lng-t-gi-tr-dinh-dng)
  * [4. Tập thể dục đều đặn](https://bvnguyentriphuong.com.vn/kien-thuc-cho-nguoi-benh/meo-ngan-ngua-benh-tim-ban-can-biet#4-tp-th-dc-u-n)
  * [5. Tăng cường thực phẩm giàu chất xơ – ít calo](https://bvnguyentriphuong.com.vn/kien-thuc-cho-nguoi-benh/meo-ngan-ngua-benh-tim-ban-can-biet#5-tng-cng-thc-phm-giu-cht-x-t-calo)
  * [6. Ăn các loại hạt và cá giàu omega-3](https://bvnguyentriphuong.com.vn/kien-thuc-cho-nguoi-benh/meo-ngan-ngua-benh-tim-ban-can-biet#6-n-cc-loi-ht-v-c-giu-omega3)
  * [7. Bổ sung các vitamin và khoáng chất tốt cho tim](https://bvnguyentriphuong.com.vn/kien-thuc-cho-nguoi-benh/meo-ngan-ngua-benh-tim-ban-can-biet#7-b-sung-cc-vitamin-v-khong-cht-tt-cho-tim)
  * [8. Tập trung vào vi chất có lợi cho tim mạch](https://bvnguyentriphuong.com.vn/kien-thuc-cho-nguoi-benh/meo-ngan-ngua-benh-tim-ban-can-biet#8-tp-trung-vo-vi-cht-c-li-cho-tim-mch)
  * [9. Quản lý căng thẳng hiệu quả](https://bvnguyentriphuong.com.vn/kien-thuc-cho-nguoi-benh/meo-ngan-ngua-benh-tim-ban-can-biet#9-qun-l-cng-thng-hiu-qu)



