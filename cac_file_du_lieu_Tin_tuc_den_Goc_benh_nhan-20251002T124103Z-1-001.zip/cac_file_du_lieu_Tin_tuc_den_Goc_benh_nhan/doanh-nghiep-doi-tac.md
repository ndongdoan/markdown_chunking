## ️ 10 lý do bạn nên chọn Sebbin: Túi ngực cao cấp đến từ Pháp

  * [KINH NGHIỆM TRONG NGHIÊN CỨU VÀ SẢN XUẤT](https://bvnguyentriphuong.com.vn/doanh-nghiep-doi-tac/10-ly-do-ban-nen-chon-sebbin-tui-nguc-cao-cap-den-tu-phap#kinh-nghim-trong-nghin-cu-v-sn-xut)
  * [ĐẢM BẢO AN TOÀN TỪ NGUYÊN LIỆU CHO ĐẾN THÀNH PHẨM](https://bvnguyentriphuong.com.vn/doanh-nghiep-doi-tac/10-ly-do-ban-nen-chon-sebbin-tui-nguc-cao-cap-den-tu-phap#m-bo-an-ton-t-nguyn-liu-cho-n-thnh-phm)
  * [CHẤT LƯỢNG ĐƯỢC KIỂM ĐỊNH ](https://bvnguyentriphuong.com.vn/doanh-nghiep-doi-tac/10-ly-do-ban-nen-chon-sebbin-tui-nguc-cao-cap-den-tu-phap#cht-lng-c-kim-nh)


Túi ngực SEBBIN – một trong những sản phẩm túi ngực hàng đầu được các Bác sĩ uy tín trên toàn thế giới tin dùng. Với bí quyết sản xuất trên 30 năm, các sản phẩm trải qua qui trình thực hiện nghiêm ngặt giúp kiểm soát tốt 100% chất lượng túi ngực với độ an toàn cao nhất. Và sau đây là 10 lý do vì sao bạn nên tin dùng và lựa chọn túi ngực Sebbin:
## KINH NGHIỆM TRONG NGHIÊN CỨU VÀ SẢN XUẤT
1. Sebbin là một trong bốn hãng túi ngực hiện hữu trên thị trường lâu đời nhất (từ năm 1986) với hơn 35 năm kinh nghiệm nghiên cứu và sản xuất. 2. Tỷ lệ biến chứng thấp: Túi ngực Sebbin của Pháp đã được chứng nhận CE Châu Âu kiểm định tỉ lệ biến chứng thấp nhất so với các túi ngực hiện nay trên thị trường (0,7% trong vòng 35 năm so với các loại túi ngực khác hiện đang lưu hành trên thế giới).  3. 14 bài viết khoa học được công bố trên các tạp chí y khoa nổi tiếng: Các Nghiên cứu lâm sàng 10 năm, trên ngàn người tại đa trung tâm, đa quốc gia với hơn 14 bài báo cáo khoa học được đăng tải trên các tạp chí Y khoa, ngành nổi tiếng của thế giới. Tại Korea theo báo cáo của KFDA từ năm 2013-2018 về các ca tai biến của túi ngực Sebbin: Chưa có trường hợp nào. Tất cả kết quả nghiên cứu lâm sàng được tài trợ bởi Groupe SEBBIN đều được cộng đồng chuyên gia đánh giá thông qua các công bố khoa học.
## ĐẢM BẢO AN TOÀN TỪ NGUYÊN LIỆU CHO ĐẾN THÀNH PHẨM
Chất lượng của nguyên liệu là một trong những yếu tố quan trọng tạo nên sản phẩm an toàn. Vậy nên, ngay từ khâu chuẩn bị nguyên liệu, Sebbin đã đầu tư và lựa chọn nguyên liệu hàng đầu đạt chuẩn FDA. Kết hợp với quy trình sản xuất nghiêm ngặt, thành phẩm sẽ đảm bảo chất lượng tốt nhất.
4. Quy trình sản xuất túi ngực Sebbin 100% được làm bằng tay và độ dày phần vỏ được kiểm tra với hơn 24 điểm bằng mắt. Việc kiểm tra bằng mắt được thực hiện ở mỗi bước của qui trình sản xuất. 3% quy trình sản xuất trải qua các kiểm nghiệm phá huỷ cơ học nhằm đảm bảo chất lượng sản phẩm với mục đích là đảm bảo sự an toàn tuyệt đối.
5. Loại gel silicon kết dính với độ đàn hồi cao, dễ dàng thích hợp với cơ thể, giúp người sử dụng thoải mái vận động sau giai đoạn phục hồi. Đây là nguyên liệu đạt tiêu chuẩn Y khoa của US FDA.
6. Túi ngực SEBBIN có công nghệ tạo vỏ bao ngoài độc nhất mang lại độ an toàn cao khi sử dụng lâu dài: kết cấu 8 lớp vỏ.
7. "Cảm giác chạm mềm" – Công nghệ NATURGEL & NANOSKIN là sự kết hợp hoàn hảo để tạo nên kết quả tự nhiên mang lại cảm giác chạm thật, được lấy cảm hứng từ mô vú tự nhiên.
## CHẤT LƯỢNG ĐƯỢC KIỂM ĐỊNH
Là đối tác quan trọng của các Bác sĩ phẫu thuật, qui trình sản xuất của chúng tôi cam kết đáp ứng toàn diện các tiêu chuẩn về CHẤT LƯỢNG:
8. Mỗi túi ngực được xác nhận danh tính bởi một số seri độc nhất cho phép truy xuất nguồn gốc từ nguyên vật liệu thô được sử dụng cho đến khi thực hiện thủ thuật cấy ghép
9. Độ an toàn chất lượng theo tiêu chuẩn ISO: NF EN ISO 9001 & NF EN ISO 13485.
10. Độ an toàn được kiểm chứng bởi Viện độc lập: Nhiều khâu kiểm soát hệ thống đảm bảo chất lượng của túi ngực SEBBIN được tiến hành hàng năm bởi tổ chức độc lập, mà tổ chức này có thể thanh tra không báo trước.
Ngoài ra, để khẳng định kết quả nghiên cứu lâm sàng, chất lượng sản phẩm cũng như đảm bảo tính cam kết lâu dài, Sebbin thực hiện chính sách bảo hành trọn đời, mang lại cho khách hàng sự an tâm về chất lượng sản phẩm.
Sự minh bạch là một trong những giá trị cốt lõi của Sebbin: phòng sản xuất mở cửa cho các đoàn tham quan với tiêu chuẩn vệ sinh nghiêm ngặt. 
Sebbin ngày càng khẳng định vị thế trên thị trường Việt Nam và là đối tác quan trọng của nhiều bác sĩ cũng như các thương hiệu thẩm mỹ nổi tiếng. Với độ an toàn và chất lượng vượt trội, Sebbin tự tin là người bạn đồng hành đáng tin cậy giúp bạn hoàn thiện nét đẹp của mình. Túi ngực Sebbin hiện được phân phối độc quyền tại Việt Nam bởi Công ty **Grassroots Aesthetics Pharma**.
  * [KINH NGHIỆM TRONG NGHIÊN CỨU VÀ SẢN XUẤT](https://bvnguyentriphuong.com.vn/doanh-nghiep-doi-tac/10-ly-do-ban-nen-chon-sebbin-tui-nguc-cao-cap-den-tu-phap#kinh-nghim-trong-nghin-cu-v-sn-xut)
  * [ĐẢM BẢO AN TOÀN TỪ NGUYÊN LIỆU CHO ĐẾN THÀNH PHẨM](https://bvnguyentriphuong.com.vn/doanh-nghiep-doi-tac/10-ly-do-ban-nen-chon-sebbin-tui-nguc-cao-cap-den-tu-phap#m-bo-an-ton-t-nguyn-liu-cho-n-thnh-phm)
  * [CHẤT LƯỢNG ĐƯỢC KIỂM ĐỊNH ](https://bvnguyentriphuong.com.vn/doanh-nghiep-doi-tac/10-ly-do-ban-nen-chon-sebbin-tui-nguc-cao-cap-den-tu-phap#cht-lng-c-kim-nh)



## Đăng Khôi Media chuyên cung cấp giải pháp truyền thông số trên các màn hình tại Bệnh viện

Là giải pháp cho đội ngũ Marketing của các doanh nghiệp, có thể tiếp cận đúng phân khúc khách hàng thông qua các video clip quảng cáo song song với gần 1000 lượt lặp lại quảng cáo và thu hút hàng ngàn lượt xem.
Với hệ điều hành hệ thống màn hình TV tiên tiến, Đăng Khôi Media đảm bảo sẽ đem tới những thước phim quảng cáo bắt mắt, gây thu hút đến với khách hàng mà doanh nghiệp nhắm đến. Cam kết đưa đến cho khách hàng thời gian phát sóng đúng theo kế hoạch và trả báo cáo hình ảnh thực tế, chuẩn xác. Đăng Khôi Media tự hào là đơn vị được hợp tác với các Bệnh viện lớn nhỏ, các hệ thống Nhà thuốc và là nơi tin tưởng của các nhãn hàng uy tín trong nước.
Liên hệ với chúng tôi để được tư vấn chi tiết và hỗ trợ dịch vụ tốt nhất. 
  * Website: <http://www.dangkhoi.com.vn>
  * Hotline: 0989 550130



## ️ TEOSYAL® Puresense Redensity 1: GIẢI PHÁP ĐIỀU TRỊ LÃO HOÁ – CĂNG BÓNG DA TỪ HA VỚI CÔNG NGHỆ ĐỘC QUYỀN TỪ THUỴ SĨ

  * [Lão hoá da là gì? Làm thế nào để ngăn ngừa lão hoá da?](https://bvnguyentriphuong.com.vn/doanh-nghiep-doi-tac/teosyal-puresense-redensity-1#lo-ho-da-l-g-lm-th-no-ngn-nga-lo-ho-da)
  * [TEOSYAL® Puresense Redensity 1: Tân trang nhan sắc với công thức độc quyền 3-trong-1 độc đáo đã đăng ký độc quyền](https://bvnguyentriphuong.com.vn/doanh-nghiep-doi-tac/teosyal-puresense-redensity-1#teosyal-puresense-redensity-1-tn-trang-nhan-sc-vi-cng-thc-c-quyn-3trong1-c-o-ng-k-c-quyn)
  * [Đặc tính kỹ thuật sản phẩm:](https://bvnguyentriphuong.com.vn/doanh-nghiep-doi-tac/teosyal-puresense-redensity-1#c-tnhk-thut-sn-phm)
  * [Những tác dụng hiệu quả đã được chứng minh lâm sàng:](https://bvnguyentriphuong.com.vn/doanh-nghiep-doi-tac/teosyal-puresense-redensity-1#nhng-tc-dng-hiu-qu-c-chng-minh-lm-sng)
  * [TEOSYAL® Puresense Redensity 1: Filler được tin dùng bởi các Bác sĩ trên toàn thế giới. ](https://bvnguyentriphuong.com.vn/doanh-nghiep-doi-tac/teosyal-puresense-redensity-1#teosyal-puresense-redensity-1-filler-c-tin-dng-bi-cc-bc-s-trn-ton-th-gii)


TEOSYAL® Puresense Redensity 1 là sản phẩm được phát triển với công thức độc quyền bởi Teoxane – Thuỵ Sĩ. Redensity I là một trong những sản phẩm “Best seller” trong lĩnh vực trẻ hoá trên toàn thế giới.
## Lão hoá da là gì? Làm thế nào để ngăn ngừa lão hoá da?
Lão hóa da theo thời gian là sự thay đổi mô chậm mà không thể đảo ngược. Dẫn đến chất lượng da thay đổi: giảm độ đàn hồi, độ ẩm và sự rạng rỡ của làn da. Da lúc này bắt đầu xuất hiện nếp nhăn và chảy xệ.
Thời gian dẫn đến những thay đổi tự nhiên về sinh lý, đây là yếu tố bên trong mà ta không thể kiểm soát
Còn các yếu tố bên ngoài làm gia tăng tình trạng lão hoá có thể kể đến như: tia cực tím, thuốc lá, khói bụi ô nhiễm,… cũng là những nguyên nhân chủ yếu gây nên tình trạng mất cân bằng oxi hoá khiến làn da kém đàn hồi & rạng rỡ, mất nước, xuất hiện nếp nhăn. Tuy nhiên đây là những yếu tố có thể quản lý được.
Trong đó những tác nhân chính gây nên tình trạng lão hoá sớm chính là Bức xạ mặt trời (Tia UVA, UVB). Dưới tác động của ánh nắng, da dễ trở nên khô ráp, đen sạm, không đều màu và dễ hình thành nếp nhăn. Trong trường hợp nguy hiểm, tia cực tím có thể dẫn đến viêm da, ung thư da… nếu tiếp xúc với ánh nắng cường độ cao liên tục mà không có biện pháp phòng tránh.
Mức độ lão hoá khác nhau do tiếp xúc với ánh nắng mặt trời như sau:
NHẸ VỪA PHẢI |  MỨC ĐỘ CAO |  NGHIÊM TRỌNG  
---|---|---  
TUỔI: < 25 LOẠI 0 (FWS) TÍNH NĂNG, ĐẶC ĐIỂM: -Làm đều màu da -Da săn chắc và sáng -Định hình khối khuôn mặt -Không có nếp nhăn |  TUỔI: 25-45 LOẠI I (FWS) TÍNH NĂNG, ĐẶC ĐIỂM: -Làm đều màu da -Da xỉn màu và sần sùi -Nếp nhăn/rãnh nhăn mỏng |  TUỔI: 40-60 LOẠI II (FWS) TÍNH NĂNG, ĐẶC ĐIỂM: -Thay đổi tông màu da -Da xỉn màu và sần sùi -Nếp nhăn/rãnh nhăn vừa phải |  TUỔI: > 60 LOẠI III (FWS) TÍNH NĂNG, ĐẶC ĐIỂM: -Thay đổi tông màu da -Da nhũn & chảy xệ -Hình khối mặt kém -Nếp nhăn/rãnh nhăn sâu  
Quá trình oxy hoá diễn ra nhanh hơn dưới tác động của ánh nắng. Không chỉ gia tăng nếp gấp trên da mà còn mất đi hình khối của khuôn mặt… mà còn làm giảm chất lượng da về mặt kết cấu, hydrat hóa, đàn hồi, nước da và sự xuất hiện các nếp nhăn li ti.
Vậy chúng ta nên làm gì để chống lại dấu hiệu lão hoá da? Chiến lược tối ưu là chọn phương pháp kết hợp xử lý các nguyên nhân dẫn đến tình trạng lão hoá da như sau: 
  * Da lão hoá do ánh nắng mặt trời: Làm chậm quá trình mất cân bằng oxy hoá (chống nắng bằng mỹ phẩm hoặc viên uống, quần áo che chắn,…)
  * Da lão hoá theo thời gian: Tái cấu trúc da và cấp ẩm thường xuyên thông qua mỹ phẩm, filler, căng chỉ,…
  * Nếp nhăn, chảy xệ trên da: Điều trị nếp nhăn bằng cách duy trì các chức năng của da mặt


## TEOSYAL® Puresense Redensity 1: Tân trang nhan sắc với công thức độc quyền 3-trong-1 độc đáo đã đăng ký độc quyền
TEOSYAL® Puresense Redensity 1 được biết đến như một khái niệm hoàn toàn mới, là một loại chất làm đầy và kết hợp liệu pháp mesotherapy (là một qui trình thẩm mỹ mà trong đó nhiều mũi tiêm nhỏ tiêm các dược chất, vitamins… đưa vào lớp trung bì của mô dưới da, …) được đặc biệt thiết kế nuôi dưỡng làn da từ bên trong và phục hồi mật độ da.
TEOSYAL® Puresense Redensity 1 là một công thức độc quyền dựa trên nồng độ cao của hyaluronic acid và một tập hợp tinh tế các thành phần với hiệu lực đã được chứng minh trên da.
Công thức được cấp bằng sáng chế của Redensity 1: một hỗn hợp độc đáo của hyaluronic acid không có kết nối chéo (15 mg/ml) và các thành phần dưỡng chất (amino acid, chất chống oxy hóa, vitamin B6), giúp tái bổ sung mật độ da và dưỡng ẩm cho da, kích thích sản sinh collagen và elastin, cho một làn da tươi trẻ và tràn trề sức sống.
_Sản phẩm TEOSYAL PURESENSE REDENSITY ®1_
### **Đặc tính kỹ thuật sản phẩm:**
  * Phức hợp tái cấu trúc da (14 thành phần tự nhiên): 3 chất chống oxy hóa, 8 amino acid, 2 khoáng chất và vitamin B6
  * Hyaluronic acid không có kết nối chéo nồng độ 15mg/ml
  * Lidocaine 0.3%


### Những tác dụng hiệu quả đã được chứng minh lâm sàng:
**Redensity 1** là một loại dược mỹ phẩm có tác dụng tăng cường tái cấu trúc da, cho phép da tái bổ sung mật độ và tái tạo tế bào da. Được đánh giá là một bước tiến mới trong việc tăng cường sắc đẹp: hoạt động từ lớp hạ bì cho đến bề mặt da với những kết quả tự nhiên, rõ rệt, được khoa học chứng minh.
Ảnh hưởng của HA có phân tử lượng cao & hỗn hợp các chất dinh dưỡng trong trị liệu da lão hoá giúp cải thiện chất lượng da, được chứng minh qua các nghiên cứu khoa học:
  * Tăng 98%Collagen IV: Tăng cường lớp DEJ nằm giữa biểu bì và hạ bì và tái cấu trúc mô
  * Tăng 1400 % GAGs*: Tá động hydrat hóa
  * Tăng 26 % Fibrillin-1: Hiệu quả thắt chặt và tái cấu trúc mô
  * Giảm 28 % MAD**: Bảo vệ chống oxy hóa


_*GAG, glycosaminoglycans; **MAD, malondialdehyde (chất đánh dấu mất cân bằng oxi hóa)_
_12. FanianF, và các cộng sự. Trên cơ thể sống tiêm oligonutrients và axit hyaluronic có phân tử lượng cao - kết quả của một thử nghiệm đối chứng ngẫu nhiên. Aesthetic Medicine.2017;3(4):23-34. 13. ChartonE, và các cộng sự. Hoạt động của Phức hợp tái cấu trúc [1] trên lớp hạ bì. Poster presentation, AMWC, Monaco; 2012. 19. KnollB, và các cộng sự. TEOSYAL® REDENSITY I, ANEWLIGHT REFLECTING TREATMENT Một nghiên cứu lâm sàng đa trung tâm và quốc tế cho gel axit hyaluronic không liên kết chéo._
## TEOSYAL® Puresense Redensity 1: Filler được tin dùng bởi các Bác sĩ trên toàn thế giới. 
  * “Sản phẩm này có thể được sử dụng cho mọi dấu hiệu và giai đoạn của quá trình lão hóa và mang lại những kết quả lâm sàng xuất sắc.” – **Bác sĩ Vladlena Averina, Ukraine.**
  * “Redensity 1: sự chăm sóc tự nhiên, có tính ngăn ngừa, dưỡng ẩm và tái bổ sung, cũng như là một điều trị duy trì xuất sắc của việc tiêm hyaluronic acid.” – **Bác sĩ Sandrine Sebban, Pháp.**
  * “Tôi luôn đạt được những kết quả rất tích cực với sản phẩm sáng tạo này, cho phép tái bổ sung mật độ da và phục hồi vẻ tươi sáng của làn da: Redensity 1.” – **Giáo sư Giuseppe Sito, Ý.**


_TEOSYAL PURESENSE REDENSITY®1: Trường hợp lâm sàng_
TEOSYAL® Puresense Redensity 1 giúp tân trang nhan sắc, lấy lại nét thanh xuân nhờ khả năng trẻ hoá tuyệt vời được nghiên cứu bởi các chuyên gia hàng đầu tại Thuỵ sĩ. Sản phẩm với công thức độc quyền hứa hẹn sẽ giúp khách hàng có một làn da trẻ trung như mong muốn.
  * [Lão hoá da là gì? Làm thế nào để ngăn ngừa lão hoá da?](https://bvnguyentriphuong.com.vn/doanh-nghiep-doi-tac/teosyal-puresense-redensity-1#lo-ho-da-l-g-lm-th-no-ngn-nga-lo-ho-da)
  * [TEOSYAL® Puresense Redensity 1: Tân trang nhan sắc với công thức độc quyền 3-trong-1 độc đáo đã đăng ký độc quyền](https://bvnguyentriphuong.com.vn/doanh-nghiep-doi-tac/teosyal-puresense-redensity-1#teosyal-puresense-redensity-1-tn-trang-nhan-sc-vi-cng-thc-c-quyn-3trong1-c-o-ng-k-c-quyn)
  * [Đặc tính kỹ thuật sản phẩm:](https://bvnguyentriphuong.com.vn/doanh-nghiep-doi-tac/teosyal-puresense-redensity-1#c-tnhk-thut-sn-phm)
  * [Những tác dụng hiệu quả đã được chứng minh lâm sàng:](https://bvnguyentriphuong.com.vn/doanh-nghiep-doi-tac/teosyal-puresense-redensity-1#nhng-tc-dng-hiu-qu-c-chng-minh-lm-sng)
  * [TEOSYAL® Puresense Redensity 1: Filler được tin dùng bởi các Bác sĩ trên toàn thế giới. ](https://bvnguyentriphuong.com.vn/doanh-nghiep-doi-tac/teosyal-puresense-redensity-1#teosyal-puresense-redensity-1-filler-c-tin-dng-bi-cc-bc-s-trn-ton-th-gii)



## CÂU HỎI LIÊN QUAN ĐẾN VIỆC SỬ DỤNG ỨNG DỤNG CHO THUÊ PIN DỰ PHÒNG SACNHANH

  1. **Điều kiện để khách hàng có thể bắt****đầu****sử dụng dịch vụ là gì?**


  * Khách hàng vào cửa hàng Google Play hoặc App store, cài đặt ứng dụng của Sacnhanh trên các thiết bị điện tử cần thuê pin dự phòng, nhập số điện thoại và mã OTP gửi qua tin nhắn để đăng nhập vào ứng dụng.
  * Liên kết thanh toán qua ví điện tử Zalopay & Nộp Phí duy trì dịch vụ 200,000 vnd (_được xem như khoản phí đảm bảo để duy trì dịch vụ cho người dùng khi sử dụng pin và hệ thống của Sacnhanh một cách tự động)__._
  * Ngoài ra khách hàng có thể liên hệ điểm đặt trạm hoặc số hotline **028 7778 6888** để được hỗ trợ thanh toán bằng tiền mặt cho dịch vụ Sacnhanh.


  1. **Khách****hàng không nhận được mã OTP qua tin nhắn điện thoại sau khi nhập số điện thoại đăng nhập****?**


  * Trước tiên, vui lòng kiểm tra xem có tín hiệu sóng trên điện thoại của quý không.
  * Tiếp theo, kiểm tra xem quý khách đã nhập chính xác số điện thoại của mình chưa, vui lòng nhấp “**Nhận mã OTP** ” 1 lần và chờ tin nhắn mạng viễn thông báo mã OTP (có thể mạng viễn thông bị nghẽn dẫn đến tin nhắn đến chậm, nếu quý khách bấm nhiều lần dễ phát sinh lỗi “**mã OTP không hiệu lực”)**


  1. **Giá cả****sử dụng****dịch****vụ thuê pin dự phòng Sacnhanh****?**


  * 3.000 VND/ 15 phút sạc,
  * 10.000 VND/1giờ sạc,
  * **5****0.000 VND/** **ngày**.  _(__Như vậy, với_ _5_ _0.000 VND người dùng có thể giữ pin sạc đến 24h hàng ngày_ _)_
  * Sau 03 ngày kể từ thời điểm thuê pin, nếu khách hàng không trả lại pin vào trạm sạc, hệ thống Sacnhanh xác định quý khách đã làm mất pin và quý khách sẽ phải thanh toán **phí phạt mất pin 600.000 VND.**(theo quy định tại **Điều khoản sử dụng dịch vụ** được đăng tải trên ứng dụng và website: <http://www.sacnhanh.com.vn/terms.html>)


Bên cạnh đó, hiện nay Sacnhanh còn đang có nhiều chương trình khuyến mãi để hỗ trợ khách hàng như nhập **Mã khuyến mãi** hoặc xem video quảng cáo để được miễn phí hoặc giảm giá thuê pin.
  1. **Làm sao để thuê****và****trả lại pin?**


Hiện tại hệ thống trạm sạc cho thuê của Sacnhanh đang phủ ở nhiều điểm trong thành phố, quý khách dễ dàng thuê nơi này và trả pin ở nơi khác thông qua hệ thống bản đồ định vị trên App Sacnhanh.
  1. **Làm sao để khách hàng có thể biết được vị trí các trạm****sạc****cho thuê pin?**


Khách hàng có thể xem vị trí ngay trên ứng dụng Sacnhanh:
  * Những icon logo Sacnhanh là địa điểm đang đặt trạm sạc.
  * Khi khách hàng nhấn vào icon logo Sacnhanh sẽ hiển thị ra thông tin địa điểm đặt trạm sạc và dẫn đường đi đến nơi đặt trạm.


  1. **Pin có thể sử dụng để sạc các loại điện****thoại****nào? Tính an toàn cho người sử dụng có được đảm bảo không?**


Pin được thiết kế sẵn 3 cáp sạc cho Android, Iphone và Type C tương thích với hầu hết các Smartphone trên thị trường. Pin đạt tiêu chuẩn quốc tế như CE, FCC, ROHS, UN.
  1. **Cách thức thanh toán khi sử dụng dịch vụ cho thuê Pin như thế nào?**


Công ty khuyến khích khách hàng nạp tiền vào ví cá nhân trên ứng dụng Sacnhanh trước thông qua ví điện tử Zalopay (bằng qua hệ thống nộp tiền mặt của Sacnhanh), với các mức nạp tiền là 50.000 VND, 100.000 VND, 200.000 VND, 300.000 VND. Sau mỗi lần thuê pin thì phí thuê pin sẽ được trừ vào số tiền quý khách đã nạp trước đó.
  1. **Điều kiện để khách hàng liên kết thẻ ngân hàng vào ví Zalopay?**


  * Số điện thoại đăng ký tài khoản ngân hàng và tài khoản Ví Zalopay phải cùng 1 số.
  * Thẻ Ngân hàng liên kết với ví Zalopay/ Momo phải đăng ký **Internet banking và thanh toán trực tuyến** (chức năng này được đăng kí kích hoạt lúc làm tài khoản mới tại ngân hàng, giúp khách hàng thanh toán online cho các dich vụ trên mạng internet và ko phải là chức năng Internet Banking. Nếu quý khách chưa đăng kí vui lòng liên hệ với ngân hàng để đăng kí kích hoạt lại)
  * Thẻ liên kết phải thuộc danh sách ngân hàng được hỗ trợ thanh toán/ nạp tiền trên ví Zalo Pay


  1. **Cách tính chi phí thuê pin?**


– Giá thuê 3.000 VND/ 15 phút; 10.000 VND/giờ; 50.000 VND/ngày. Khi khách hàng trả lại pin, hệ thống sẽ thông báo chi phí thuê pin trên màn hình ứng dụng.
– Phí thuê pin sẽ được trừ vào số dư ví Sacnhanh của ngươi dùng.
  1. **Trong trường hợp khác****h****hàng không nạp tiền trước vào ví****trên ứng dụng****thì có sử dụng dịch vụ được không?**


Khách hàng cần thanh toán **Phí****duy trì dịch vụ****200****.****000****VND** để bắt đầu thuê pin và sử dụng dịch vụ. Đối với khách hàng mới lần đầu sử dụng thì Sacnhanh đã tặng 10.000 VND trong tài khoản. Quý khách cần nạp tiền cho lần sử dụng tiếp theo.
  1. **Nếu khách hàng****muốn****hoàn lại tiền** **duy trì****dịch vụ,****sẽ mất bao lâu?**


  * **Phí duy trì dịch vụ 200,000****VND** được xem như khoản phí đảm bảo để duy trì dịch vụ cho người dùng khi sử dụng pin và hệ thống của Sacnhanh một cách tự động. Khách hàng sẽ được hoàn tiền khi gởi yêu cầu hoàn tiền và ngưng sử dụng dịch vụ.
  * Thời gian hoàn tiền cho khách hàng từ 1 đến 14 ngày, tuỳ thuộc vào quá trình xử lý thủ tục của ngân hàng liên kết mà khách hàng sử dụng.


  1. **Tại sao khách hàng không Scan được để thuê pin****sau khi đã nạp Phí duy trì dịch vụ****?**


  * Trước hết, vui lòng kiểm tra tín hiệu 3G / Wifi trên điện thoại của khách hàng.
  * Nếu tín hiệu hoạt động bình thường, xin vui nhìn xem đèn màu xanh phía trước trạm sạc (thể hiện trạm sạc đã kết nối mạng Internet) có đang nhấp nháy hay không, nếu không, xin vui lòng liên hệ với DVKH Sacnhanh qua hotline **028 7778 6888** để được hỗ trợ.


  1. **Nếu sau 3 ngày người dùng không trả pin thì sẽ bị trừ những chi phí nào?**


  * Chi phí đầu vào của pin là 600.000 VND. Nếu quá thời hạn 3 ngày, khách hàng sử dụng không trả lại pin thì hệ thống Sacnhanh xác định quý khách đã làm mất pin.
  * Theo quy định tại **Điều khoản sử dụng dịch vụ** mà quý khách đã đồng ý khi bắt đầu tải ứng dụng Sacnhanh, công ty uỷ quyền cho Ngân hàng cấn trừ số tiền 600.000 VND trong tài khoản ngân hàng liên kết của người dùng (tham chiếu quy định tại **Điều khoản sử dụng dịch vụ** được đăng tải trên ứng dụng và website: <http://www.sacnhanh.com.vn/terms.html>)


  1. **Cách tính chi phí khi khách hàng làm mất pin và liên hệ để trả lại pin?**


Chi phí sau 3 ngày được tính như sau:
  * Phí thuê pin: 5000 x 3 = 150.000 VND
  * Phí mất pin (khi khách hàng không trả lại pin sau 3 ngày): 6000 VND –> trừ vào tài khoản ngân hàng liên kết 600.000VND. (tham chiếu quy định tại **Điều khoản sử dụng dịch vụ** được đăng tải trên ứng dụng và website: <http://www.sacnhanh.com.vn/terms.html>)
  * Nếu sau thời hạn 3 ngày, khách hàng muốn trả lại pin vui lòng liên hệ DVKH Sacnhanh để được hướng dẫn thủ tục trả pin. Sau khi pin bị mất được trả lại, Sacnhanh sẽ chuyển khoản trả lại quý khách 150.000 VND (_Nghĩa là_  _Khách hàng chỉ cần thanh toán phí thuê pin trong vòng 3 ngày_)


  1. **Khách hàng có thể** **sạc pin lại tại nhà được không****?**


  * Pin không có chức năng sạc lại tại nhà, khách hàng nên trả lại vào trạm sạc sau khi dùng xong để tránh phát sinh thêm chi phí thuê.


  1. **Nếu pin sạc không hoạt động?**


  * Đảm bảo rằng cáp được đẩy vào đúng cách. Nếu cần thiết, kiểm tra ốp lưng điện thoại của bạn có làm cản trở cáp sạc pin.
  * Báo cáo lỗi tự động bằng chức năng báo lỗi trên ứng dụng Sacnhanh (icon dịch vụ khách hàng màu đỏ trên màn hình trang chủ App) và trả lại pin sạc dự phòng trong vòng 3 phút để nhận một pin sạc dự phòng khác.
  * Liên hệ với DVKH Sacnhanh qua số **028 7778 6888** để được hỗ trợ nếu các cách trên đều thất bại.


  1. **Nếu khách hàng không thể trả lại pin sạc dự phòng?**


  * Khi trả lại pin sạc dự phòng, đảm bảo đẩy và lắp pin sạc dự phòng vào khe cắm pin để chắc chắn rằng trạm sạc đã khóa pin. Khách hàng sẽ nghe thấy thông báo từ trạm sạc: “Trả pin thành công. Cám ơn đã sử dụng dịch vụ!”
  * Nếu khách hàng nghe thấy thông báo: “Trả pin thất bại, vui lòng thử lại!”, vui long thử lại hoặc liên hệ với DVKH Sacnhanh qua số **028 7778 6888** để được hỗ trợ.


  1. **Khách hàng có thể sạc nhiều thiết bị cùng một lúc không?**


  * Pin sạc dự phòng có thể sạc nhiều thiết bị bất cứ lúc nào, miễn là có sẵn cáp sạc.
  * Tuy nhiên, điều này sẽ làm chậm quá trình sạc vì quá trình tải điện bị chia sẻ cho 2 hay nhiều thiết bị.



## WECARE 247 triển khai dịch vụ chăm sóc cho người bệnh mắc Covid (F0)

Từ ngày 30/12/2021, WECARE 247 triển khai dịch vụ chăm sóc bệnh nhân mắc bệnh Covid tại BV điều trị Covid Nguyễn Tri Phương với các nội dung như sau:
**1. Công tác chăm sóc người bệnh**
- Theo dõi Người bệnh liên tục (Đặc biệt lưu ý đến: **Mạch, Huyết áp, Nhịp thở, Nhiệt độ, Sp02**), kịp thời thông tin với nhân viên y tế khi có dấu hiệu bất thường 
- Khử khuẩn môi trường xung quanh người bệnh và hỗ trợ vệ sinh cá nhân hằng ngày (tắm, gội, lau người,...) 
- Hỗ trợ Bệnh nhân Covd-19 dùng bình oxy theo y lệnh (nếu có), theo dõi tình trạng của hệ thống cấp oxy theo chỉ dẫn từ nhân viên y tế và hướng dẫn các bài tập hỗ trợ hô hấp
- Chăm sóc F0 việc ăn uống và sử dụng thuốc chỉ theo định của Bác sĩ chuyên môn
- Động viên và chăm sóc sức khỏe tinh thần cho người bệnh 
- Xoa bóp, day ấn huyệt cơ bản hỗ trợ hô hấp 
**2. Mức giá: sẽ được thương thảo hợp lý**
Dự kiến từ 1.000.000đ/ngày
**3. Những cam kết của nhân viên chăm bệnh F0:**
- Hỗ trợ cuộc gọi video với thân nhân (có sự đồng ý của khoa điều trị)
- Theo suốt bệnh nhân đến khi ra viện (trừ khi có thỏa thuận khác)
**4. Thông tin liên hệ:[0938999247](https://wecare247.com.vn/)**

## Teosyal REDENSITY® [II]

**ĐẶC ĐIỂM CHÍNH**
Teosyal REDENSITY® [II] là sản phẩm duy nhất hiện nay được bào chế đặc biệt, có chỉ định trong điều trị thâm quầng mắt nhờ các thành phần độc đáo
REDENSITY [II]: CÔNG THỨC 3-trong-1
  * _Hỗn hợp HMW-HA 15 mg/ml_ : Hỗn hợp phân tử HA khối lượng lớn liên kết chéo & không liên kết chéo, có tính chất lưu biến và lý tính giúp tiêm an toàn và dễ dàng, có kết quả tự nhiên tức thì
  * _Lidocaine (0,3%):_ Gây tê và giảm đau khi tiêm
  * _Hỗn hợp 14 thành phần tự nhiên (8 Amino axit, 3 chất chống oxy hóa, 2 khoáng chất, Vitamin B6):_ Tác động bổ sung tổng hợp của HMW-HA & Hỗn hợp chất dinh dưỡng giúp trì hoãn lão hoá cho vùng da quanh mắt, tái tạo cấu trúc và tế bào, chống oxy hoá, dưỡng ẩm cho da.


CÁC ĐẶC TÍNH CỦA SẢN PHẨM
  * Độ nhầy thích ứng với việc làm đầy vùng thâm quầng 
  * Hút ẩm thấp để giảm sưng tối thiểu 
  * Độ cô đặc nhẹ để giảm áp lực lên mô tối thiểu 
  * Kích thích để trẻ hóa làn da 
  * Lidocaine (0.3%) để gây tê cục bộ , tránh gây đau cho bện nhân
  * Độ an toàn cao: <2 báo cáo về tác dụng phụ và biến chứng trên 10.000 bện nhân thực hiện liệu trình


**THÀNH PHẦN CÔNG THỨC**
Các đặc tính lưu biến độc đáo trẻ hóa, làm đầy cùng trũng dưới mắt, làm căng bóng và làm sáng vùng mắt thâm quầng, cải thiện đặc điểm sinh lý của làn da 
**CHỈ ĐỊNH**
  * Mắt thâm quầng
  * Rãnh lệ
  * Rãnh hốc mắt Palpebromalar
  * Túi bọng tràn hoặc bọng mắt


**SỰ HÀI LÒNG CỦA BÁC SĨ**
Thoải mái khi điều trị cho bác sĩ vì:
  * Gel có độ đặc nhẹ 
  * Độ nhầy nhớt của gel thích ứng đƣợc 
  * Khả năng lan rộng của gel 


Khi sử dụng sẽ đảm bảo:
  * Tiêm dễ dàng để thuận tiện hơn 
  * Tập trung vào quá trình tiêm 
  * Dễ dàng định vị gel 
  * Ít chấn thương các mô 
  * Chỉnh sửa tự nhiên & thẩm mỹ hơn 


**SỰ HÀI LÒNG CỦA BỆNH NHÂN**
Mức độ hài lòng cao của tất cả bệnh nhân theo nhiều khảo sát:
  * 97% bệnh nhân hài lòng 
  * 98% bệnh nhân sẽ giới thiệu liệu trình 
  * 97% bệnh nhân sẽ lặp lại liệu trình


**KẾT LUẬN**
REDENSITY [II], MỘT LOẠI GEL Đ ƯỢC bào chế ĐẶC BIỆT ĐỂ ĐIỀU TRỊ THÂM QUẦNG MẮT 
  * Một giải pháp chữa trị cải tiến với những giải pháp cho những vấn đề dai dẳng 
  * Công thức độc đáo và độc quyền 3-trong-1 để chỉnh sửa làn da đẹp tự nhiên và hiệu quả tức thì 
  * Có thể nhận thấy tính hiệu quả và an toàn khi điều trị thâm quầng mắt 
  * Hiệu quả được chứng minh đã cải thiện chất lượng làn da vùng hốc mắt 
  * Tiêm dễ dàng 
  * Có sự hài lòng của bác sĩ và bệnh nhân trên toàn cầu


**Tìm hiểu thêm các sản phẩm khác tại:[teoxane.vn](http://teoxane.vn)**

## Thận trọng khi thuê người chăm bệnh tự phát

  * [Nhu cầu tìm người chăm bệnh tại bệnh viện là rất lớn](https://bvnguyentriphuong.com.vn/doanh-nghiep-doi-tac/than-trong-khi-thue-nguoi-cham-benh-tu-phat#nhu-cu-tm-ngi-chm-bnh-ti-bnh-vin-l-rt-ln)
  * [Thực trạng và lưu ý khi thuê người chăm bệnh tại bệnh viện](https://bvnguyentriphuong.com.vn/doanh-nghiep-doi-tac/than-trong-khi-thue-nguoi-cham-benh-tu-phat#thc-trng-v-lu-khi-thu-ngi-chm-bnh-ti-bnh-vin)
  * [Dịch vụ WECARE247 có gì khác với chăm bệnh tự phát?](https://bvnguyentriphuong.com.vn/doanh-nghiep-doi-tac/than-trong-khi-thue-nguoi-cham-benh-tu-phat#dch-v-wecare247-c-g-khc-vi-chm-bnh-t-pht)


## Nhu cầu tìm người chăm bệnh tại bệnh viện là rất lớn
Theo ghi nhận, trong vài tháng trở lại đây số ca khám và nhập viện tại các bệnh viện lớn ở TP HCM có dấu hiệu tăng cao. Ở thời điểm hiện tại, các nguyên nhân có thể kể đến là: 
  * Trong tình hình mới - số lượng bệnh nhân khám chữa bệnh và nhập viện có sự gia tăng.
  * Bệnh nhân mắc sốt xuất huyết đang vào đỉnh dịch. Số liệu từ các bệnh viện, cứ 100 người đến khám có 60 người cần nhập viện với triệu chứng: sốt cao, nôn ói. 
  * Dịch Covid-19 có dấu hiệu số ca mắc tăng lại. Theo Sở Y tế TP HCM, số ca nhiễm mới thành phố ghi nhận mỗi ngày trung bình 30-50. 


Tình trạng bệnh nhân ngày càng tăng cùng với thiếu hụt cán bộ nhân viên y tế dẫn đến quá tải, gây khó khăn cho công tác điều trị. Trong khi đó, những người nhập viện đa số là bệnh nặng. Các việc từ vệ sinh cá nhân, đi lại, ăn uống, vận động... đều cần có người hỗ trợ, chăm sóc. Người nhà cũng quá bận rộn, không sắp xếp được thời gian thăm nuôi. Kéo theo nhu cầu tìm người chăm bệnh tại bệnh viện tăng cao. Theo khảo sát, trung bình trong một ngày có đến vài trăm trường hợp cần tìm người chăm bệnh. Có thể nói trong chừng mực nào đấy, những người làm nghề chăm bệnh nhân tại bệnh viện là “cứu cánh” cho nhiều gia đình. 
## Thực trạng và lưu ý khi thuê người chăm bệnh tại bệnh viện
Bên cạnh những lợi ích thì cũng có nhiều rủi ro tiềm ẩn khi thuê người chăm sóc bệnh nhân tại bệnh viện.
Đã hai ngày nay chị Thu Vân (Bình Thạnh - TP HCM) đôn đáo hỏi han tin tức về cô Hương - người chị thuê để chăm sóc mẹ mình.
“Cô Hương vấp dây điện làm rơi bể máy của bệnh viện chỗ đầu giường mẹ chị. Giờ cổ bỏ đi, chị phải đền số tiền đó, nghe nói vài chục triệu chứ không hề ít. Dù được bệnh viện hỗ trợ tìm kiếm. Nhưng vì chị không nắm bất cứ thông tin cũng như giấy tờ gì, việc tìm kiếm rất khó khăn”, chị Vân nghẹn ngào.
Tương tự, anh Sơn cũng gặp tình huống “dở khóc dở cười” khi thuê người chăm bệnh tự phát không qua đơn vị nào. Trong khi, một công ty có quầy tư vấn tại bệnh viện báo giá là 450.000 đồng/ngày, thì anh thuê cô chăm bên ngoài chỉ có 350.000 đồng.
“Nhận thấy có thể tiết kiệm được hơn 100.000 đồng/ ngày, tôi đã chọn thuê bên ngoài. Nhưng đến khi ứng tiền rồi bắt đầu công việc, cô ta chỉ làm qua loa. Chỉ cho cụ uống sữa, không vệ sinh cá nhân, không cho cụ ăn, thậm chí ngủ còn nhiều hơn cụ nữa. Tôi có hỏi tại sao cô ta bảo làm một việc tính thêm tiền. Số tiền tôi trả hôm trước chỉ chăm chừng đó thôi”, anh Sơn bức xúc kể lại.
Hầu hết, những người chăm bệnh tự phát chỉ dựa vào kinh nghiệm bản thân không được đào tạo chuyên môn để chăm sóc người bệnh. Vì thế, trong khi chăm sóc rất dễ xảy ra sai sót. Đã có trường hợp, bệnh tình trầm trọng hơn, do người chăm không quan sát kỹ, để cho người bệnh té ngã, chấn thương khi đi vệ sinh. 
Chưa kể là gặp nhầm kẻ gian, lợi dụng lúc sơ hở trộm cắp những đồ vật có giá trị, gây ảnh hưởng đến tinh thần người bệnh. Và cũng có thể gặp những tình huống như trên. Loại hình chăm bệnh tự phát không có bảo hiểm hay hợp đồng pháp lý. Khi có vấn đề phát sinh, thiệt thòi thuộc về người nhà và bệnh nhân.
Vì vậy để đảm bảo không gặp những tình huống như trên, người nhà cần chú ý ba yếu tố. Thứ nhất, tìm hiểu địa chỉ, website và các đánh giá của khách hàng trước của bên cung cấp dịch vụ. Thứ hai, người chăm bệnh phải có chuyên môn, có chứng chỉ hành nghề và mình cần nắm hồ sơ lý lịch của người đó. Thứ ba, nên ký hợp đồng dịch vụ để đảm bảo quyền lợi khi có vấn đề xảy ra.
## Dịch vụ WECARE247 có gì khác với chăm bệnh tự phát?
Là đơn vị tiên phong xây dựng hệ thống dịch vụ Chăm Người Bệnh chuẩn hóa, có chuyên môn để thay thế hình thức chăm người bệnh tự phát; WECARE247 cung cấp dịch vụ chăm bệnh chuyên nghiệp tại bệnh viện đáp ứng cả ba tiêu chí trên. Bên cạnh đó, công ty này còn có bảo hiểm 2,4 tỷ VNĐ giúp Khách hàng yên tâm hơn khi lựa chọn dịch vụ.
Từ năm 2017 đến nay, WECARE247 đã triển khai gói dịch vụ chăm sóc sức khỏe đa dạng với hàng nghìn người chăm bệnh chuyên nghiệp. Trên tinh thần “coi người bệnh như người nhà”, trung tâm này thường xuyên tổ chức các khóa đào tạo vừa nâng cao các kỹ năng chăm sóc người bệnh.
Vì xây dựng hệ thống dịch vụ chuyên nghiệp, liên kết với nhiều bệnh viện lớn, người bệnh khi sử dụng dịch vụ của WECARE247 sẽ được chăm sóc 24/7 và hỗ trợ đổi nhân sự chăm sóc phù hợp khi yêu câu. 
**Tư vấn gói dịch vụ Chăm Người Bệnh phù hợp, liên hệ ngay: 0938 999 247**
  * [Nhu cầu tìm người chăm bệnh tại bệnh viện là rất lớn](https://bvnguyentriphuong.com.vn/doanh-nghiep-doi-tac/than-trong-khi-thue-nguoi-cham-benh-tu-phat#nhu-cu-tm-ngi-chm-bnh-ti-bnh-vin-l-rt-ln)
  * [Thực trạng và lưu ý khi thuê người chăm bệnh tại bệnh viện](https://bvnguyentriphuong.com.vn/doanh-nghiep-doi-tac/than-trong-khi-thue-nguoi-cham-benh-tu-phat#thc-trng-v-lu-khi-thu-ngi-chm-bnh-ti-bnh-vin)
  * [Dịch vụ WECARE247 có gì khác với chăm bệnh tự phát?](https://bvnguyentriphuong.com.vn/doanh-nghiep-doi-tac/than-trong-khi-thue-nguoi-cham-benh-tu-phat#dch-v-wecare247-c-g-khc-vi-chm-bnh-t-pht)



## Túi ngực Sebbin: Túi ngực Pháp cao cấp, an toàn & tự nhiên nhất thế giới

  * [Bạn biết gì về túi ngực Sebbin?](https://bvnguyentriphuong.com.vn/doanh-nghiep-doi-tac/tui-nguc-sebbin-tui-nguc-phap-cao-cap-an-toan-va-tu-nhien-nhat-the-gioi#bn-bit-g-v-ti-ngc-sebbin)
  * [An toàn là ưu tiên hàng đầu của túi ngực Sebbin.](https://bvnguyentriphuong.com.vn/doanh-nghiep-doi-tac/tui-nguc-sebbin-tui-nguc-phap-cao-cap-an-toan-va-tu-nhien-nhat-the-gioi#an-ton-l-u-tin-hng-u-ca-ti-ngc-sebbin)
  * [Cam kết đến từ Sebbin](https://bvnguyentriphuong.com.vn/doanh-nghiep-doi-tac/tui-nguc-sebbin-tui-nguc-phap-cao-cap-an-toan-va-tu-nhien-nhat-the-gioi#cam-kt-n-t-sebbin)
  * [Vì sao nên lựa chọn túi ngực Sebbin?](https://bvnguyentriphuong.com.vn/doanh-nghiep-doi-tac/tui-nguc-sebbin-tui-nguc-phap-cao-cap-an-toan-va-tu-nhien-nhat-the-gioi#v-sao-nn-la-chn-ti-ngc-sebbin)


Sebbin là dòng sản phẩm túi ngực được nghiên cứu và phát triển hơn 35 năm tại Pháp. Mỗi sản phẩm của Sebbin đều hướng đến tiêu chí an toàn, dài lâu và thân thiện với cơ thể.
_Túi ngực Sebbin – Túi ngực Pháp cao cấp_
## **Bạn biết gì về túi ngực Sebbin?**
Sebbin đã cung cấp và đáp ứng nhu cầu thẩm mỹ của xã hội hiện đại trong hơn 35 năm qua. Suốt chặng đường này, Sebbin luôn hoàn thành vai trò của mình một cách xuất sắc: Không ngừng phát triển, nâng cao chuyên môn trong việc thiết kế và sản xuất các thiết bị y tế, phục vụ cho lĩnh vực phẫu thuật tạo hình thẩm mỹ. Luôn luôn lắng nghe người tiêu dùng là nền tảng cho những sáng kiến của Sebbin trong tương lai.
Với kiến thức khoa học chuyên sâu về silicone, Sebbin phát minh một dòng trọn bộ các thiết bị y tế nhằm đáp ứng nhu cầu thẩm mỹ đa dạng của người tiêu dùng, cũng như điều chỉnh các thiết kế dành riêng cho những nhu cầu nhất định, song song với việc ứng dụng công nghệ độc quyền trong phẫu thuật thẩm mỹ.
Dòng silicone không chỉ bao gồm các chỉ định phẫu thuật ngực (với hơn 400 loại túi ghép ngực hiện sẵn có), mà còn dành cho các trường hợp như: phẫu thuật độn mông, giãn da, ghép túi độn tinh hoàn hoặc bắp chân. Đồng thời Sebbin cũng phát triển các sản phẩm có khả năng cải thiện những khiếm khuyết bẩm sinh ví dụ như stent mũi hoặc các túi ghép được đặt làm theo yêu cầu. 
## **An toàn là ưu tiên hàng đầu của túi ngực Sebbin.**
Quy trình sản xuất túi ngực Sebbin 100% được làm bằng tay và độ dày phần vỏ được kiểm tra với hơn 24 điểm bằng mắt. Việc kiểm tra bằng mắt được thực hiện ở mỗi bước của qui trình sản xuất. 3% quy trình sản xuất trải qua các kiểm nghiệm phá huỷ cơ học nhằm đảm bảo chất lượng sản phẩm.
Sở hữu công nghệ độc quyền "Naturgel" giúp túi ngực Sebbin có độ mềm tự nhiên giống ngực thật nhất so với các loại túi hiện nay và đã được khẳng định bởi các bác sĩ và khách hàng trên toàn thế giới.
Túi ngực Sebbin có kết cấu 8 lớp vỏ, gel silicon kết dính, độ đàn hồi cao, dễ dàng thích hợp với cơ thể, giúp người sử dụng thoải mái vận động sau giai đoạn phục hồi.
_Túi ngực Sebbin thế hệ mới với nhiều ưu điểm vượt trội_
Túi ngực Sebbin của Pháp đã được chứng nhận CE Châu Âu kiểm định tỉ lệ biến chứng thấp nhất so với các túi ngực hiện nay trên thị trường (0,7% trong vòng 35 năm so với các loại túi ngực khác hiện đang lưu hành trên thế giới). Điều này đã được chứng minh qua các Nghiên cứu lâm sàng 10 năm trên ngàn người tại đa trung tâm, đa quốc gia với hơn 14 bài báo cáo khoa học được đăng tải trên các tạp chí Y khoa, ngành nổi tiếng của thế giới. Tại Korea theo báo cáo của KFDA từ năm 2013-2018 về các ca tai biến của túi ngực Sebbin: Chưa có trường hợp nào. Tất cả kết quả nghiên cứu lâm sàng được tài trợ bởi Groupe SEBBIN đều được cộng động chuyên gia đánh giá thông qua các công bố khoa học.
Sự minh bạch là một trong những giá trị cốt lõi của Sebbin: phòng sản xuất mở cửa cho các đoàn tham quan với tiêu chuẩn vệ sinh nghiêm ngặt. 
## **Cam kết đến từ Sebbin**
Là đối tác quan trọng của các Bác sĩ phẫu thuật, qui trình sản xuất của chúng tôi cam kết đáp ứng toàn diện các tiêu chuẩn về CHẤT LƯỢNG.
  * Việc sử dụng các nguyên liệu thô tương thích sinh học, dùng trong y tế, phải đảm bảo tính lâu dài khi được cấy ghép vào cơ thể, tuân theo các thông số kỹ thuật phù hợp với mục đích sử dụng.
  * Cải thiện liên tục các qui trình sản xuất và các bước kiểm soát liên quan, được ghi nhận và lưu hồ sơ trong suốt 30 năm qua trong việc quản lý, tuân theo các tiêu chuẩn NF EN ISO 9001:2015 và NF EN ISO 13485:2016.
  * Các sản phẩm tuân thủ theo những tiêu chuẩn NF EN ISO 14630:2013 và NF EN ISO 14607:2009 đáp ứng chỉ thị 93/42 của Liên Minh Châu Âu - Một hệ thống truy xuất nguồn gốc nhằm xác định nguyên liệu thô từ lúc sản xuất cho đến khi vận chuyển, nhờ vào số seri riêng biệt trên mỗi sản phẩm.


_Túi ngực Sebbin – Túi ngực tự nhiên an toàn nhất thế giới_
Để khẳng định kết quả nghiên cứu lâm sàng về túi ghép ngực trong 10 năm, cũng như đảm bảo tính cam kết lâu dài, Sebbin thực hiện chính sách bảo hành trọn đời, mang lại cho khách hàng sự an tâm về chất lượng sản phẩm.
## **Vì sao nên lựa chọn túi ngực Sebbin?**
  * Tuân thủ nghiêm ngặt theo tiêu chuẩn của Liên Minh Châu Âu.
  * Thực hiện các nghiên cứu lâm sàng trên 10 năm.
  * Các công bố khoa học được công nhận trên toàn thế giới.
  * Sản xuất và kiểm soát chất lượng 100% bằng mắt thường.
  * Chính sách bảo hành giúp quý khách hàng an tâm hơn khi quyết định lựa chọn sản phẩm.


Với các ưu điểm trên, Sebbin đã chiếm trọn trái tim của các khách hàng trong và ngoài nước.
Túi ngực Sebbin hiện được phân phối độc quyền tại Việt Nam bởi Công ty Grassroots Aesthetics Pharma, và dần được khẳng định vị thế trên thị trường nhờ có sự ủng hộ, tin dùng của các chuyên gia đầu ngành phẫu thuật thẩm mỹ. Có thể nói, Sebbin là người bạn đồng hành tuyệt vời đối với cơ thể, giúp bạn tự tin là phiên bản hoàn hảo nhất của chính mình.
  * [Bạn biết gì về túi ngực Sebbin?](https://bvnguyentriphuong.com.vn/doanh-nghiep-doi-tac/tui-nguc-sebbin-tui-nguc-phap-cao-cap-an-toan-va-tu-nhien-nhat-the-gioi#bn-bit-g-v-ti-ngc-sebbin)
  * [An toàn là ưu tiên hàng đầu của túi ngực Sebbin.](https://bvnguyentriphuong.com.vn/doanh-nghiep-doi-tac/tui-nguc-sebbin-tui-nguc-phap-cao-cap-an-toan-va-tu-nhien-nhat-the-gioi#an-ton-l-u-tin-hng-u-ca-ti-ngc-sebbin)
  * [Cam kết đến từ Sebbin](https://bvnguyentriphuong.com.vn/doanh-nghiep-doi-tac/tui-nguc-sebbin-tui-nguc-phap-cao-cap-an-toan-va-tu-nhien-nhat-the-gioi#cam-kt-n-t-sebbin)
  * [Vì sao nên lựa chọn túi ngực Sebbin?](https://bvnguyentriphuong.com.vn/doanh-nghiep-doi-tac/tui-nguc-sebbin-tui-nguc-phap-cao-cap-an-toan-va-tu-nhien-nhat-the-gioi#v-sao-nn-la-chn-ti-ngc-sebbin)



