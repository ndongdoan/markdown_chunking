## BÁO CÁO PHẢN ỨNG CÓ HẠI CỦA THUỐC NĂM 2020

Từ ngày 01/11/2019 đến ngày 31/10/2020 tại Bệnh viện có tổng cộng 127 báo cáo ADR liên quan đến các thuốc, tất cả đều đã được báo cáo về Trung tâm ADR Quốc gia.Cụ thể như sau:
**I. SỐ LƯỢNG BÁO CÁO ADR:**
Số lượng báo cáo theo từng tháng được tổng hợp trong bảng sau:
Tất cả các ADR đều được gửi online về Trung tâm DI&ADR Quốc Gia.
Về chất lượng báo cáo:
Đa số báo cáo ghi đầy đủ các thông tin gồm 4 trường thông tin chính: Thông tin người bệnh, thông tin về ADR, thông tin về thuốc nghi ngờ và thông tin về người báo cáo.
**II. THUỐC NGHI NGỜ GÂY ADR:**
**III. BIỂU HIỆN ADR:**
Đa số các ca ADR đều ở mức độ không nghiêm trọng ( **86,6%**). Một vài ca ở mức độ đe dọa tính mạng và kéo dài thời gian nằm viện(**13,4%**). 
Theo bảng trên, biểu hiện được báo cáo nhiều nhất là ngứa (**58,3****%**), ban đỏ/mẫn đỏ (chiếm **56,7****%**), lạnh, khó thở, mệt, buồn nôn.... Tất cả các trường hợp đều hồi phục không để lại di chứng sau khi xử lý.
**IV. KIẾN NGHỊ VÀ CÁCH XỬ LÝ:**
**1. Về chuyên môn**
Theo phản hồi của Trung tâm DI&ADR Quốc Gia Việt Nam như sau:
**Gợi ý về cách xử trí với các loại phản ứng đã ghi nhận tại bệnh viện**  _(cần áp dụng biện pháp xử trí riêng đối với từng trường hợp cụ thể):_
**- Đối với phản ứng dị ứng nhẹ trên da** : để xử trí phản ứng, cần ngừng dùng thuốc nghi ngờ; cho bệnh nhân sử dụng thuốc chống dị ứng đặc hiệu (glucocorticoid, thuốc kháng histamin H1...), thuốc chống bội nhiễm (nếu cần).
**- Trong trường hợp bệnh nhân gặp phản ứng phản vệ, sốc phản vệ** : để xử trí phản ứng, cần tuân thủ theo phác đồ cấp cứu sốc phản vệ do Bộ Y tế ban hành (chi tiết xin xem Thông tư 51/2017/TT-BYT về Hướng dẫn phòng, chẩn đoán và xử trí phản vệ). Theo tài liệu về sốc phản vệ của “Viện quốc gia Hoa Kỳ về Dị ứng và Bệnh nhiễm trùng” năm 2006, có thể xử trí bằng cách tiêm bắp ngay ở trước bên đùi 0,3-0,5 ml dung dịch adrenalin 1/1000 (trẻ em: 0,01 mg/kg cân nặng) lặp lại mỗi 5-15 phút (có thể ngắn hơn 3-5 phút tuỳ đáp ứng và độ nặng trên lâm sàng), thở oxy, đặt nội khí quản nếu cần, truyền dịch tĩnh mạch (NaCl 0,9%) để tăng thể tích huyết tương, dùng thuốc kháng histamin, hít thuốc chủ vận beta-adrenergic (ví dụ: salbutamol, terbutalin) nếu co thắt phế quản, tiêm tĩnh mạch hydrocortison hoặc prednisolon.
**- Với diclofenac** : Nhìn chung các phản ứng có hại của diclofenac thường nhẹ và thoáng qua. Tuy nhiên, để giảm thiểu các phản ứng có hại khi sử dụng diclofenac, các cán bộ y tế cần cân nhắc điều chỉnh tới liều thấp nhất có hiệu quả và dùng thuốc trong thời gian ngắn nhất có thể. Theo Dược thư Quốc gia Việt Nam 2 năm 2015, cần phải tính toán liều dùng diclofenac một cách thận trọng, tùy theo nhu cầu và đáp ứng của từng cá nhân và cần phải dùng liều thấp nhất có tác dụng. Liều tối đa là 150 mg (ở Mỹ là 200 mg). Theo Cơ sở dữ liệu tra cứu thông tin thuốc trực tuyến Martindale 37th: The Complete Drug Reference, liều thường dùng của diclofenac đường uống hoặc đường trực tràng là 75-150 mg/ngày, chia thành các liều nhỏ. Tờ thông tin sản phẩm của diclofenac tại Anh và Canada cũng khuyến cáo liều diclofenac đặt trực tràng là 100 mg/ngày, trong trường hợp chưa đạt hiệu quả điều trị ở mức liều này có thể tăng liều lên mức tối đa 150 mg/ngày.
**- Với Vancomycin:** Theo Dược thư Quốc gia Việt Nam 2 năm 2015, phản ứng trên da là phản ứng có hại đã được ghi nhận khi sử dụng vancomycin đường uống và đường tiêm. Khi sử dụng vancomycin qua đường tiêm, có thể xuất hiện phản ứng trên da như: ban đỏ ở mặt và phần trên cơ thể (hội chứng “cổ đỏ” hay “người đỏ”), đây là phản ứng **rất hay gặp** , tỷ lệ xuất hiện trên 1/10; nguyên nhân một phần do giải phóng histamin và thường do **truyền thuốc nhanh**. Hội chứng được đặc trưng bởi tụt huyết áp đột ngột, có thể kèm theo nóng bừng và xuất hiện ban đỏ hoặc ban sần ở mặt, cổ, ngực và các chi trên. Thường tự hết sau khi ngừng truyền thuốc.
**2. Khuyến cáo dành cho bệnh viện:**
Tiếp tục theo dõi bệnh nhân cẩn thận khi sử dụng thuốc để có biện pháp xử trí kịp thời (nếu cần) trong trường hợp xuất hiện phản ứng có hại.
- Trao đổi với các cơ sở khám, chữa bệnh khác (trên địa TP. Hồ Chí Minh và/hoặc các tỉnh, thành khác) để thu thập thêm thông tin về các trường hợp ADR liên quan đến thuốc và lô thuốc mà bệnh viện mình đang sử dụng.
- Tiếp tục báo cáo các trường hợp ADR được ghi nhận tại bệnh viện đến Trung tâm DI & ADR Quốc gia.
**Xử lý với trường hợp Sốc phản vệ :**
  * Điều dưỡng và bác sĩ: 


+ Tiến hành theo Phác đồ xử lý sốc phản vệ của Bộ Y tế.
+ Báo cáo sơ bộ ADR theo mẫu
  * Dược sĩ dược lâm sàng: lên trực tiếp Khoa Phòng để tìm hiểu:


+ Đọc hồ sơ bệnh án của bệnh nhân
+ Tiền sử dị ứng thuốc của bệnh nhân: không 
+ Test da: có tiến hành và cho kết quả âm tính. 
+ Kiểm tra chất lượng thuốc: vỏ thuốc, lô thuốc, hạn dùng, chất lượng thuốc theo cảm quan của điều dưỡng.
+ Hoàn chỉnh Báo cáo ADR và gửi ngay trong ngày cho Trung tâm DI&ADR quốc gia
_**Khoa Dược - Tổ dược lâm sàng**_

## Thuốc giả và thuốc không đạt chuẩn

Các loại thuốc không an toàn có thể đến tay bệnh nhân ngay khi có sự kiểm soát và giám sát lỏng lẻo trong các quy định pháp luật, từ đó chúng có thể được tìm thấy một cách dễ dàng tại các hiệu thuốc trực tuyến bất hợp pháp hoặc các khu chợ vỉa hè ở vùng nông thôn Châu Phi. Các loại thuốc giả và thuốc không đạt chuẩn thường được báo cáo ở các nước có mức thu nhập cao (HIC) bao gồm các loại thuốc mới lạ như hormone, steroid và thực phẩm chức năng, trong khi đó, người dân ở các nước thu nhập thấp đến trung bình (LMIC) đã trở thành nạn nhân của các loại thuốc kháng sinh giả và không đạt chuẩn trong việc điều trị các bệnh đe dọa đến tính mạng, như sốt rét, bệnh lao, HIV và AIDS .
Với sự ra đời của Chỉ thị về Thuốc giả (FMD) vào tháng 2 năm 2019 , dược sĩ và chuyên gia chăm sóc sức khỏe cần hiểu rõ sự ảnh hưởng của các loại thuốc giả và thuốc không đạt chuẩn đến việc hành nghề Dược và tác động bất lợi của chúng đối với sức khỏe toàn cầu.
Để đối phó với mối đe dọa toàn cầu từ các loại thuốc giả và thuốc không đạt chuẩn, Hội đồng Y tế Thế giới lần thứ 70 đã đưa ra các thuật ngữ và định nghĩa mới cho danh mục thuốc không đạt chuẩn / thuốc giả/ thuốc sai nhãn mác/ thuốc nhái (SSFFC) . Các điều khoản mới, ’không đạt tiêu chuẩn’,‘ thuốc giả ‘ và ’thuốc không đăng ký’, đã được đề xuất để loại trừ ‘thuốc nhái’ (vi phạm sở hữu trí tuệ) khỏi danh mục. Việc đưa ra các định nghĩa tiêu chuẩn hóa toàn cầu có thể được coi là một bước quan trọng trong việc phát triển và ủng hộ các biện pháp can thiệp để chống lại các loại thuốc giả và không đạt chuẩn.
**1 Thuốc không đạt chuẩn**
Tổ chức Y tế Thế giới (WHO) định nghĩa một loại thuốc không đạt tiêu chuẩn là một sản phẩm y tế được cấp phép nhưng không đáp ứng đủ các tiêu chuẩn vể chất lượng hoặc thông số kỹ thuật đã đăng ký, và được sản xuất bởi một nhà sản xuất đã được biết đến nhưng không có ý định đánh lừa bệnh nhân. Những thuốc này được đưa vào chuỗi cung ứng hợp pháp và tiếp cận đến bệnh nhân trong khi năng lực kỹ thuật về thực hành tốt sản thuốc (GMP) và thực hành tốt phân phối thuốc (GDP) còn bị hạn chế.
**2 Thuốc giả**
WHO định nghĩa thuốc giả là một sản phẩm thuốc được sản xuất với ý đồ cố tình lừa đảo trong việc nhận dạng danh tính, và nguồn gốc thuốc. Thuốc giả được sản xuất trong điều kiện không hợp vệ sinh và không được kiểm soát bởi một nhà sản xuất đã được biết đến. Chúng có thể chứa số lượng thành phần hoạt chất (API) không đúng với hồ sơ đăng ký, các thành phần trơ không hoạt tính và các chất gây ô nhiễm nguy hiểm. Bao bì của thuốc giả gần như giống với thuốc gốc, vì thế rất khó để phân biệt được chúng nếu không thực hiện một loạt các phép kiểm tra để phát hiện ra thành phần của thuốc .
**3 Thuốc kháng sinh giả và không đạt chuẩn**
Một lĩnh vực chính cần quan tâm là số lượng thuốc kháng sinh giả và không đạt chuẩn ngày càng tăng. Hệ thống kiểm tra và giám sát toàn cầu của WHO báo cáo rằng 42% trong tổng số 1.500 trường hợp sản phẩm thuốc không đạt tiêu chuẩn và giả mạo được báo cáo từ năm 2013 đến 2017 là từ khu vực Châu Phi. Thuốc kháng sinh và thuốc chống sốt rét được báo cáo phổ biến nhất, chiếm khoảng 36% tổng số sản phẩm được báo cáo bởi các nước thành viên.
Sự hiện diện của thuốc kháng sinh chất lượng kém trên thị trường đưa đến nguy cơ đáng kể đối với những khu vực có tỷ lệ mắc bệnh sốt rét cao, đồng thời nó cũng là nguyên nhân hàng đầu gây tử vong ở trẻ em . Ở Châu Phi, WHO ước tính có tới 169.000 trẻ em tử vong mỗi năm do viêm phổi và có tới 158.000 trẻ em chết vì sốt rét do sử dụng thuốc kháng sinh giả và không đạt chuẩn, mặc dù rất khó xác định quá trình tiến triển bệnh hay tử vong có liên quan trực tiếp đến việc sử dụng thuốc kháng sinh giả và không đạt chuẩn.
Thuốc kháng sinh không đạt chuẩn có hiệu lực kháng khuẩn giảm (do suy thoái API), sinh khả dụng của thuốc bị thay đổi (do sự thoái hóa của tá dược) hoặc công thức kém (ví dụ như tetracycline kháng sinh thường bị suy giảm hóa học trong điều kiện bảo quản kém ở vùng khí hậu nhiệt đới)
Trong thuốc kháng sinh có chứa nhiều thành phần độc hại, nhưng phổ biến nhất là thành phần trơ như phấn, bột mì hoặc bột talc; tưởng chừng như không có tác dụng điều trị nhưng chúng cũngcó thể chứa các thành phần làm che lấp đi các triệu chứng lâm sàng của bệnh truyền nhiễm. Ví dụ, một nghiên cứu đã báo cáo việc phát hiện Artemisinin giả, một loại thuốc chống sốt rét chỉ chứa Paracetamol Trong nghiên cứu này, sau khi dùng Artemisinin giả, bệnh nhân giảm sốt, gợi ý cho việc điều trị thành công; tuy nhiên trong thực tế, đó là một tác dụng ngắn hạn từ Paracetamol . Sự ngăn cản điều trị này có thể làm tiến triển bệnh , trong một số trường hợp có thể dẫn đến tử vong .
Sử dụng kháng sinh dưới liều điều trị sẽ chỉ tiêu diệt các chủng còn nhạy cảm, làm giảm sự cạnh tranh sinh sản và tạo điều kiện cho các chủng kháng thuốc nhân lên, do đó góp phần vào sự phát triển của tình trạng kháng kháng sinh (AMR). Đối với các chuyên gia chăm sóc sức khỏe trong HIC, người ta thường hiểu rằng nguyên nhân của AMR thường liên quan đến việc tuân thủ điều trị của bệnh nhân hoặc việc lạm dụng kháng sinh quá mức**.** Gần đây, việc thực hành kê đơn thuốc kháng sinh được thực hiện tốt hơn và nâng cao nhận thức cộng đồng về AMR đã được thực hiện để giảm tác hại từ việc nhiễm các vi khuẩn kháng thuốc . Tuy nhiên, thuốc kém chất lượng và hành vi kê đơn không chuẩn xác làm cản trở các nỗ lực thúc đẩy quản lý thuốc kháng sinh, gia tăng áp lực đối với các loại thuốc kháng sinh mới hơn và đắt tiền hơn . Sự hiện diện của thuốc kháng sinh giả và không đạt chuẩn là một vấn đề lớn của xã hội, trong đó tổn hại cá nhân dẫn đến tổn hại cho tập thể, từ đó góp phần gây ra các biến chứng nặng hơn và phát triển các bệnh nhiễm trùng đa kháng thuốc, như bệnh lao (TB) .
**Nguồn trích dẫn:<https://www.nhipcauduoclamsang.com/>**

## ️ Giới thiệu khoa Dược Bệnh viện Nguyễn Tri Phương

  * [I. Thông tin lãnh đạo khoa Dược Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/gioi-thieu-khoa-duoc-benh-vien-nguyen-tri-phuong#i-thng-tin-lnh-o-khoa-dc-bnh-vin-nguyn-tri-phng)
  * [II. Thông tin giới thiệu về khoa Dược Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/gioi-thieu-khoa-duoc-benh-vien-nguyen-tri-phuong#ii-thng-tin-gii-thiu-v-khoa-dc-bnh-vin-nguyn-tri-phng)


## **I. Thông tin lãnh đạo khoa Dược Bệnh viện Nguyễn Tri Phương**
**1. Trưởng khoa**
DS.CK1: **Nguyễn Thu Thảo**
  * Tốt nghiệp dược sĩ năm: 2012
  * Năm cấp bằng ThS/CK1: 2018 Chuyên ngành: Dược lý và dược lâm sàng
  * Thời gian công tác tại bệnh viện: 07 năm


Nghiên cứu khoa học đã tham gia:
  * Khảo sát tình hình kê đơn kháng sinh tại khoa khám bệnh của bệnh viện Nguyễn Tri Phương
  * Nhận xét sơ bộ bước đầu triển khai công tác DLS tại khoa ngoại thần kinh BV Nguyễn Tri Phương
  * Khảo sát việc sử dụng kháng sinh khi áp dụng “Phiếu yêu cầu sử dụng kháng sinh” tại Bv Nguyễn Tri Phương.


**2. Phó trưởng khoa**
DS.CK1: **Đặng Cao Hạnh**
  * Tốt nghiệp dược sĩ năm: 2012
  * Năm cấp bằng ThS/CK1 2019 Chuyên khoa: Dược lý và dược lâm sàng
  * Thời gian công tác tại bệnh viện: 07 năm


Nghiên cứu khoa học đã tham gia:
  * Khảo sát việc sử dụng kháng sinh sinh trong điếu trị viêm phổi mắc phải cộng đồng tại khoa Hô hấp - Bệnh viện Nguyễn Tri Phương


## **II. Thông tin giới thiệu về khoa Dược Bệnh viện Nguyễn Tri Phương**
Khoa Dược là một trong những khoa được đồng hành ngay những ngày đầu khi có quyết định thành lập bệnh viện. Khoa Dược dưới sự lãnh đạo trực tiếp của Giám đốc bệnh viện, quản lý và tham mưu cho giám đốc bệnh viện về toàn bộ công tác dược trong bệnh viện nhằm đảm bảo cung cấp đầy đủ, kịp thời thuốc có chất lượng và tư vấn, giám sát việc thực hiện sử dụng thuốc an toàn, hợp lý.
Trình độ chuyên môn nghiệp vụ của đội ngũ nhân viên ngày càng được nâng cao, hiện có 4 Dược sĩ có trình độ sau đại học, và hơn 10 Dược sĩ có trình độ đại học. Nhân sự thường xuyên được cập nhật kiến thức và thái độ ứng xử nhằm nâng cao mức độ hài lòng của bệnh nhân và để đáp ứng các yêu cầu hoạt động trong các lĩnh vực: Đấu thầu, nghiệp vụ dược, quản lý kho, cung ứng thuốc và dược lâm sàng.
**Điểm mạnh về trang thiết bị:** hệ thống phần mềm quản lý thuốc hiện đại, cảnh báo tương tác thuốc nhằm giảm thiểu các rủi ro.
Những định hướng phát triển trong thời gian tới muốn nhấn mạnh:
Thúc đẩy hoạt động công tác Dược lâm sàng nhằm mục đích sử dụng hợp lý thuốc như:
  * Phát huy tối đa hiệu quả về mặt lâm sàng của thuốc nhằm đạt hiểu quả điều trị cao nhất;
  * Giảm thiểu nguy cơ tác dụng phụ do điều trị gây ra thông qua theo dõi quá trình điều trị và sự tuân thủ của bệnh nhân;
  * Giảm thiểu các chi phí cho việc điều trị tại bệnh viện.


**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [I. Thông tin lãnh đạo khoa Dược Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/gioi-thieu-khoa-duoc-benh-vien-nguyen-tri-phuong#i-thng-tin-lnh-o-khoa-dc-bnh-vin-nguyn-tri-phng)
  * [II. Thông tin giới thiệu về khoa Dược Bệnh viện Nguyễn Tri Phương](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/gioi-thieu-khoa-duoc-benh-vien-nguyen-tri-phuong#ii-thng-tin-gii-thiu-v-khoa-dc-bnh-vin-nguyn-tri-phng)



## DANH MỤC THUỐC NHÌN GIỐNG NHAU – ĐỌC GIỐNG NHAU (Cập nhật tháng 3/2024)

**Định nghĩa LASA**
1.1 Thuốc nhìn gần giống nhau (Look Alike - LA): là thuốc được đóng gói trong bao bì trực tiếp (vỉ, viên, ống, lọ, chai, túi) hoặc bao bì gián tiếp (thùng, hộp) tương tự nhau về hình dạng, màu sắc, kích thước và thiết kế trên bao bì.
1.2 Thuốc đọc viết gần giống nhau (Sound Alike - SA): là thuốc có tên biệt dược hoặc tên hoạt chất phát âm tương tự nhau hay có cách viết tương tự nhau.
**Các yếu tố gây nhầm lẫn và hậu quả**
  * Lỗi nhận thức về thính/thị giác.
  * Đơn/ phiếu ghi không rõ tên thuốc, nồng độ hàm lượng, đường dùng.
  * Lỗi khi nhập dữ liệu từ y lệnh vì hộp thoại sẽ thả rơi những thuốc có những chữ cái thứ tự giống nhau nhưng hoạt chất; hàm lượng; đường dùng khác nhau (Ví dụ: CEF… CEFtriaxone EG 1g; CEFtriaxone Stragen 2g; CEFepim 1g, DUPHA… DUPHAlac; DUPHAston, NOVO…NOVOmix; NOVOrapid…).
  * Yếu tố con người: Không tập trung, không tuân thủ 3 kiểm tra – 3 đối chiếu trong cấp phát thuốc; 5 đúng trong sử dụng thuốc cho bệnh nhân (BN).


**_Những yếu tố trên dẫn đến cấp phát, sử dụng thuốc sai y lệnh, không mang lại hiệu quả điều trị, gây nguy hại cho BN thậm chí tử vong._**
_**Một số biện pháp chống nhầm lẫn**_
Ghi y lệnh rõ ràng tên thuốc, nồng độ - hàm lượng, dạng bào chế, liều dùng.
Sắp xếp các thuốc trong danh mục LASA tại kho hoặc tủ trực sao cho dễ dàng nhận biết và phân biệt được (không nhất thiết phải để xa nhau nhưng phải sắp xếp có khoảng cách, khay/hộp đựng riêng, dán nhãn/biển cảnh báo LASA, lưu ý đến các viên, chai/lọ/ống đã ra lẻ), nhãn/biển cảnh báo LASA phải là công cụ giúp chú ý, phân biệt, tránh nhầm lẫn chứ không mang tính hình thức.
Tuân thủ nguyên tắc 3 kiểm tra – 3 đối chiếu trong lãnh/cấp phát thuốc, nguyên tắc 5 đúng trong sử dụng thuốc cho BN.
Xem toàn bộ khuyến cáo về thuốc LASA cập nhật đến tháng 03/2024 [**tại đây**](https://bvnguyentriphuong.com.vn/uploads/112023/files/danh%20sach%20LASA.pdf)
#### Nội dung trong file:

1 
 BV NGUY ỄN TRI PHƯƠNG  
KHOA DƯ ỢC CỘNG HÒA XÃ H ỘI CH Ủ NGHĨA VI ỆT NAM  
Độc lập – Tự do – Hạnh phúc  
 TPHCM, ngày 08 tháng  03 năm 202 4 
DANH M ỤC THU ỐC NHÌN GI ỐNG NHAU – ĐỌC GI ỐNG NHAU  
 Căn c ứ danh m ục thu ốc hiện có t ại kho l ẻ nội trú, để đảm bảo công tác ch ống 
nhầm lẫn trong quá trình c ấp phát, s ử dụng, khoa Dư ợc thông báo đ ến các  khoa, phòng 
danh m ục thu ốc nhìn gi ống nhau, đ ọc giống nhau (LASA – look alike sound alike). Danh 
mục này  (phụ lục I) sẽ được cập nh ật, bổ sung trong quá trình s ử dụng. Đề nghị các 
khoa, phòng, lưu ý th ực hiện tốt các nguyên t ắc 3 kiểm tra, 3 đối chiếu, 5 đúng  để tránh 
nhầm lẫn khi c ấp phát, s ử dụng thu ốc. 
 Do m ặt hàng thu ốc không c ố định, vi ệc cập nhật danh m ục có th ể không k ịp thời, 
trong th ời gian đó nhân viên gi ữ thuốc kho dư ợc và đi ều dư ỡng qu ản lý t ủ trực chủ 
động làm c ảnh báo LASA khi nh ận thấy có nguy cơ nh ầm lẫn. 
I. NỘI DUNG  
1. Định nghĩa LASA  
1.1 Thu ốc nhìn g ần giống nhau (Look Alike - LA): là thu ốc được đóng gói trong 
bao bì tr ực tiếp (vỉ, viên, ống, lọ, chai, túi) ho ặc bao bì gián ti ếp (thùng, h ộp) tương t ự 
nhau v ề hình d ạng, màu s ắc, kích thư ớc và thi ết kế trên bao bì.  
1.2 Thu ốc đọc viết gần giống nhau (Sound Alike - SA): là thu ốc có tên bi ệt dược 
hoặc tên ho ạt chất phát âm tương t ự nhau hay có cách vi ết tương tự nhau.  
2. Các y ếu tố gây nh ầm lẫn và hậu qu ả 
a. Lỗi nhận thức về thính/th ị giác. 
b. Đơn/ phi ếu ghi không rõ tên thu ốc, nồng độ hàm lư ợng, đư ờng dùng.  
c. Lỗi khi nh ập dữ liệu từ y lệnh vì h ộp tho ại sẽ thả rơi nh ững thu ốc có nh ững 
chữ cái th ứ tự giống nhau nhưng ho ạt chất; hàm lư ợng; đư ờng dùng khác 
nhau (Ví d ụ: CEF… CEFtriaxone EG 1g; CE Ftriaxone Stragen 2g; CEFepim 
1g, DUPHA… DUPHAlac; DUPHAston, NOVO…NOVOmix; 
NOVOrapid…) . 
d. Yếu tố con người: Không t ập trung, không tuân th ủ 3 kiểm tra – 3 đối chiếu 
trong c ấp phát thu ốc; 5 đúng trong s ử dụng thu ốc cho b ệnh nhân (BN).  2 
 Những yếu tố trên d ẫn đến cấp phát, s ử dụng thu ốc sai y l ệnh, không mang l ại 
hiệu quả điều trị, gây nguy h ại cho BN th ậm chí t ử vong . 
3. Một số biện pháp ch ống nh ầm lẫn 
a. Ghi y l ệnh rõ ràng tên thu ốc, nồng độ - hàm lượng, d ạng bào ch ế, liều dùng.  
b. Sắp xếp các thu ốc trong danh m ục LASA  tại kho ho ặc tủ trực sao cho d ễ dàng 
nhận biết và phân bi ệt được (không nh ất thiết phải để xa nhau  nhưng ph ải sắp 
xếp có kho ảng cách, khay/h ộp đựng riêng, dán nhãn/bi ển cảnh báo LASA , 
lưu ý đ ến các viên, chai/l ọ/ống đã ra l ẻ), nhãn/bi ển cảnh báo LASA ph ải là 
công c ụ giúp chú ý, phân bi ệt, tránh nh ầm lẫn chứ không mang tính hình th ức. 
c. Tuân th ủ nguyên t ắc 3 ki ểm tra – 3 đối chi ếu trong lãnh/c ấp phát thu ốc, 
nguyên t ắc 5 đúng trong s ử dụng thu ốc cho BN.  
II. CÁC DANH M ỤC – BIỂU M ẪU BAN HÀNH KÈM  
1. Danh m ục thu ốc nhìn gi ống nhau – đọc giống nhau  được liệt kê t ại Phụ lục 01.  
2. Biểu mẫu nhãn/bi ển cảnh báo LASA đư ợc hướng dẫn tại Phụ lục 02./. 
 
 TRƯ ỞNG KHOA DƯ ỢC 
  
 
 
DS CKI I Nguy ễn Thu Th ảo 
 
  
1 
 Phụ lục 1 
DANH M ỤC THU ỐC NHÌN GI ỐNG NHAU – ĐỌC GI ỐNG NHAU  
(Cập nhật tới ngày  08 tháng 03 năm 202 4) 
Danh m ục đư ợc chia thành 4 nhóm sau:  
A- Thuốc nhìn gi ống nhau, đ ọc giống nhau (LASA)  
B- Thuốc nhìn g ần giống nhau (LA)  
C- Thuốc đọc giống nhau (SA)  
D- Thuốc đọc gần giống nhau (SA)  
 
 
A- CÁC THU ỐC NHÌN GI ỐNG NHAU, Đ ỌC GI ỐNG NHAU  
STT THU ỐC LƯU Ý  
1 
AZENMAROL 1 - AZENMAROL 4  Cùng NSX,  
cùng ho ạt chất, 
cùng d ạng bào  
chế, khác hàm  
lượng 
2 
DIOVAN 80 – DIOVAN 160  Cùng NSX,  
cùng ho ạt chất, 
cùng d ạng bào  
chế, khác hàm  
lượng 
2 
 3 
EXFORGE 5mg/80mg – EXFORGE 10mg/160mg  Cùng NSX,  
cùng ho ạt chất, 
cùng d ạng bào  
chế, khác hàm  
lượng 
4 
FORXIGA 10mg – FORXIGA 5mg  Cùng NSX,  
cùng ho ạt chất, 
cùng d ạng bào  
chế, khác hàm  
lượng 
5 
 
GALVUS MET 50mg/500mg – 
 GALVUS MET 50mg/850mg  Cùng NSX,  
cùng ho ạt chất, 
cùng d ạng bào  
chế, khác hàm  
lượng 
 
3 
 6 
JANUMET 50mg/500 – JANUMET 50mg/850mg – 
JANUMET 50mg/1000/mg  Cùng NSX,  
cùng ho ạt chất, 
cùng d ạng bào  
chế, khác hàm  
lượng 
7 
JANUMET XR 50mg/1000mg – 
JANUMET XR 100mg/1000mg  Cùng NSX,  
cùng ho ạt chất, 
cùng d ạng bào  
chế, khác hàm  
lượng 
8  Cùng NSX,  
cùng ho ạt chất, 
cùng d ạng bào  
chế, khác hàm  
lượng 
JANUVIA 50mg – JANUVIA 100mg  4 
 9 
JARDIANCE 10mg – JARDIANCE 25mg  Cùng NSX,  
cùng ho ạt chất, 
cùng d ạng bào  
chế, khác hàm  
lượng 
10  
TRAJENTA DUO 2.5mg/500mg - TRAJENTA DUO 
2.5mg/850mg - TRAJENTA DUO 2.5mg/1000mg  
 Cùng NSX,  
cùng ho ạt chất, 
cùng d ạng bào  
chế, khác hàm  
lượng 
11 
 
MEDROL 16mg – MEDROL 4mg  Cùng NSX,  
cùng ho ạt chất, 
cùng d ạng bào  
chế, khác hàm  
lượng 
 
5 
 12 
NEXIUM 20mg – NEXIUM 40mg  Cùng NSX,  
cùng ho ạt chất, 
cùng d ạng bào  
chế, khác hàm  
lượng 
13 
PLAVIX 75mg – PLAVIX 300mg  Cùng NSX,  
cùng ho ạt chất, 
cùng d ạng bào  
chế, khác hàm  
lượng 
14 
TWYNSTA 40mg/5mg – TWYNSTA 80mg/5mg  Cùng NSX,  
cùng ho ạt chất, 
cùng d ạng bào  
chế, khác hàm  
lượng 
6 
 15 
SEROQUEL XR 50mg – SEROQUEL  XR 300mg  Cùng NSX,  
cùng ho ạt chất, 
cùng d ạng bào  
chế, khác hàm  
lượng 
16 
NIVALIN 2.5mg/ml – NIVALIN 5mg/ml  Cùng NSX,  
cùng ho ạt chất, 
cùng d ạng bào  
chế, khác hàm  
lượng 
17 
BETADINE 10% VAGINAL DOUCHE  
BETADINE 10% DD SÁT KHU ẨN Cùng NSX,  
cùng ho ạt chất, 
cùng d ạng bào  
chế, cùng  hàm 
lượng, khác 
đường 
dùng/cách 
dùng . 
 
7 
 18 
SYMBICORT 60 DOSES – SYMBICORT 120   
DOSES  – SYMBICORT RAPIHALER  Cùng NSX,  
cùng ho ạt chất, 
cùng d ạng bào  
chế, khác li ều 
đóng gói.  
19 
CANCILINAT 50mg/5ml – CALCILINAT 100mg/10ml  Cùng NSX,  
cùng ho ạt chất, 
cùng d ạng bào  
chế, khác hàm  
lượng 
20 
LUCRIN 3.75/1 MONTH – LUCRIN 11.25/3 MONTH  Cùng NSX,  
cùng ho ạt chất, 
cùng d ạng bào  
chế, khác hàm  
lượng 
8 
 21 
LOVENOX 4000UI – LOVENOX 6000UI  Cùng NSX,  
cùng ho ạt chất, 
cùng d ạng bào  
chế, khác hàm  
lượng 
22 
GEMAPAXAN E 4000IU – GEMAPAXAN E 6000IU  Cùng NSX,  
cùng ho ạt chất, 
cùng d ạng bào  
chế, khác hàm  
lượng 
23 
RECORMON 2000IU – RECORMON 4000IU  Cùng NSX,  
cùng hoạt chất, 
cùng d ạng bào  
chế, khác hàm  
lượng 
 
9 
 24 
NANOKINE 2000IU – NANOKINE 4000IU  Cùng NSX,  
cùng ho ạt chất, 
cùng d ạng bào  
chế, khác hàm  
lượng 
25  
MIRCERA 50mcg – MIRCERA 100mcg  
 Cùng NSX,  
cùng ho ạt chất, 
cùng d ạng bào  
chế, khác hàm  
lượng 
26 
LIPOFUNDIN 10% - LIPOFUNDIN 20%  Cùng NSX,  
cùng ho ạt chất, 
cùng d ạng bào  
chế, khác hàm  
lượng 
10 
 27 
NATRI CLORID 0.9% - NATRI CLORID 3%  Cùng NSX,  
cùng ho ạt chất, 
cùng d ạng bào  
chế, khác hàm  
lượng 
28 
XENETIX 300mg/100ml -  XENETIX 350mg/100ml  Cùng NSX,  
cùng ho ạt chất, 
cùng d ạng bào  
chế, khác hàm  
lượng 
29 
DIAMICRON MR 30mg – DIAMICRON MR 60mg  Cùng NSX,  
cùng ho ạt chất, 
cùng d ạng bào  
chế, khác hàm  
lượng 
 
11 
 30 
TOPAMAX 50mg – TOPAMAX 50mg  Cùng NSX,  
cùng ho ạt chất, 
cùng d ạng bào  
chế, khác hàm  
lượng 
31 
AGIMLISIN 10mg – AGIMLSIN 20mg  Cùng NSX,  
cùng ho ạt chất, 
cùng d ạng bào  
chế, khác hàm  
lượng 
32 
CANCIDAS 50mg – CANCIDAS 70mg  Cùng NSX,  
cùng ho ạt chất, 
cùng d ạng bào  
chế, khác hàm  
lượng 
12 
 33 
GLUCOSE 5% - GLUCOSE 10%  Cùng NSX,  
cùng ho ạt chất, 
cùng d ạng bào 
chế, khác hàm  
lượng 
34 
GLUCOPHAGE 850MG –  
GLUCOPHAGE XR 500MG  Cùng NSX,  
cùng ho ạt chất, 
khác dạng bào  
chế, khác hàm  
lượng 
35 LIPITOR 20mg – LIPITOR 40mg  Cùng NSX,  
cùng ho ạt chất, 
cùng d ạng bào  
chế, khác hàm  
lượng 
 
13 
 36 
KLACID MR  500mg  – KLACID FORTE  500mg  Cùng NSX,  
cùng ho ạt chất, 
cùng hàm 
lượng, khác 
dạng bào ch ế về 
tốc độ giải 
phóng.  
37 
DIPRIVAN h ộp 50ml – DIPRIVAN ống 20ml  Cùng NSX,  
cùng ho ạt chất, 
khác quy cách 
đóng gói,  khác 
hàm lư ợng. 
14 
 38 
PULMICORT 0.5mg/ml (1g/2ml)  
PULMICORT 500mcg/2ml (0.5mg/2ml)  Cùng NSX,  
cùng ho ạt chất, 
cùng d ạng bào 
chế, khác hàm  
lượng. 
39 
 
XARELTO 10MG – XARELTO 20MG – 
XARELTO 15MG  Cùng NSX,  
cùng ho ạt chất, 
cùng d ạng bào 
chế, khác hàm  
lượng. 
40 
 
VISIPAQUE 320 mg I/ml  100ml – 
VISIPAQUE 320 mg I/ml 50ml  Cùng NSX,  
cùng ho ạt chất, 
cùng d ạng bào 
chế, khác dung 
tích. 
 
15 
 41 
 
PRADAXA 150MG – PRADAXA 110MG  Cùng NSX,  
cùng ho ạt chất, 
cùng d ạng bào 
chế, khác hàm  
lượng. 
 
42  
 
CRESTOR 20MG – CRESTOR 10MG  Cùng NSX,  
cùng ho ạt chất, 
cùng d ạng bào 
chế, khác hàm  
lượng. 
 
16 
 43 
 
CONCOR 5MG – CONCOR® COR 2,5MG  Cùng NSX,  
cùng ho ạt chất, 
cùng d ạng bào 
chế, khác hàm  
lượng. 
 
44 
 
CEFOPEFAST –S 1000, CEFOPEFAST 1500, 
CEFOPEFAST 2000  Cùng NSX,  
cùng ho ạt chất, 
cùng d ạng bào 
chế, khác hàm  
lượng. 
 
 
17 
 45 
 
PDSOLONE -125MG , PDSOLONE -40MG  Cùng NSX,  
cùng ho ạt chất, 
cùng d ạng bào 
chế, khác hàm  
lượng. 
 
46 
 
TOBRADEX H ỔN DỊCH NH Ỏ MẮT 5ML – 
TOBRADEX M Ỡ TRA M ẮT 3,5G  Cùng NSX, 
cùng ho ạt chất, 
khác dạng bào 
chế, khác hàm 
lượng. 
47  
 
COLIREX 3MIU – COLIREX 1MIU  Cùng NSX,  
cùng ho ạt chất, 
cùng d ạng bào 
chế, khác hàm  
lượng. 
 
 
 
 
 
 
 
B- THU ỐC NHÌN G ẦN GI ỐNG NHAU (LA)  
18 
 STT THU ỐC LƯU Ý  
1 
DIOVAN 80mg(160mg) – 
CO-DIOVAN 80mg/12.5mg  Cùng nhà s ản 
xuất, 1 dạng 
đơn ch ất, 
1 dạng kết hợp. 
2 
 
KALI CLORID 10% - MAGNESI SULFAT 15%  Cùng nhà s ản 
xuất, 
khác ho ạt chất. 
 
19 
 3 
A.T NITROGLYCERIN – A.T TRANEXAMIC  Cùng nhà s ản 
xuất, 
khác ho ạt chất. 
4 
UNASYN 1.5g -SULPERAZO NE 1g – CEFOBID 1g  Cùng nhà s ản 
xuất, 
khác ho ạt chất. 
5 
 
TENAMYD - CEFTRIAXON 2000 , TENAMYD 
CEFTAZIDIM 1000, TENAMYD CEFOTAXIM 1000  Cùng nhà s ản 
xuất, 
khác ho ạt chất 
20 
 6 
BERODUAL BÌNH X ỊT PHÂN LI ỀU – 
BERODUAL DUNG D ỊCH KHÍ DUNG  Cùng nhà s ản 
xuất, khác cách 
dùng  
6 
DIAZEPAM (IV) – TRAMADOL (IV)  
FENTANYL (IV) – PETHIDINE (IV)  Cùng nhà s ản 
xuất, khác ho ạt 
chất. 
7 
METHYLPREDNISOLON 16mg – 
DOMPERIDON 10mg  Cùng nhà s ản 
xuất, khác ho ạt 
chất, viên r ời 
giống hệt nhau . 
 
21 
 8 
 AUGMENTIN – IBA-MENTIN – KLAMENTIN - AUCLANITYL  Cùng ho ạt chất, 
khác NSX,  tên 
đọc gần giống 
nhau.  
9 
 
MERONEM 1G – MEROPENEM 1,0G  Cùng ho ạt chất, 
khác NSX,  tên 
đọc gần giống 
nhau.  
10 
ATISOLU 40 - ATHYDROCORTISONE  Cùng nhà s ản 
xuất, khác ho ạt 
chất, 
22 
 11 
VITAMIN B1 – ADRENALIN (IV) – GENTAMYCIN 
– MORPHIN  Khác nhà s ản 
xuất, khác ho ạt 
chất, ống ch ứa 
dd tiêm nhìn 
giống nhau  
12 MIACALCIC – SANDOSTATIN  Cùng nhà s ản 
xuất, khác ho ạt 
chất. 
13 NATRI CLORID 0,9% 100ML  PARACETAMOL 
10mg/ml  
 
 Cùng nhà s ản 
xuất, khác ho ạt 
chất. 
 
 
 
23 
 14 
 
DEPO -MEDROL 40MG , SOLU - MEDROL 40MG  Cùng ho ạt chất, 
cùng NSX , 
khác đư ờng 
dùng , tên đ ọc 
gần giống nhau  
C- THU ỐC ĐỌC GI ỐNG NHAU (SA)  
(nhiều hàm lư ợng ho ặc khác dạng bào ch ế) 
STT THU ỐC LƯU Ý  
1 
 Cùng nhà s ản 
xuất, cùng ho ạt 
chất, khác d ạng 
bào ch ế 
VOLTAREN(IV) - 
VOLTAREN (Đ ẶT) 24 
 2 
NEXIUM 20mg (40mg) – NEXIUM 40 (IV)  Cùng nhà s ản 
xuất, cùng ho ạt 
chất, khác d ạng 
bào ch ế 
3 
VENTOLIN (DD KHÍ DUNG) – 
VENTOLIN BÌNH X ỊT PHÂN LI ỀU Cùng nhà s ản 
xuất, cùng ho ạt 
chất, khác d ạng 
bào ch ế 
4 
 Cùng nhà s ản 
xuất, cùng ho ạt 
chất, khác 
đường dùng.  
FOSMICIN(IV) - 
FOSMICIN (NH Ỏ TAI)   
25 
 5 
CEFTRIAXONE EG 1g –  
CEFTRIAXON STRAGEN 2g  Cùng ho ạt chất, 
khác NSX, khác 
hàm lư ợng 
 
 
 
 
 
 
 
D- THU ỐC ĐỌC GẦN GI ỐNG NHAU (SA)  
STT THU ỐC LƯU Ý  
1 
AGICLOVIR 800 – AGIFOVIR 300  Khác ho ạt chất 
2 
NOVORAPID - NOVOMIX  Cùng NSX, 
khác ho ạt chất 
26 
  
 
 
 3 
DUPHASTON 10mg - DUPHALAC  Khác ho ạt chất 
4 
VINPHACINE - VINPHATOXIN  Cùng NSX, 
khác ho ạt chất 
5 TURBE - TURBEZID  Cùng NSX, 
Turbe d ạng 
phối hợp R+H  
Turbezid d ạng 
phối hợp 
R+H+Z  
 
1 
 Phụ lục 2 
BIỂU M ẪU NHÃN/BI ỂN C ẢNH BÁO LASA  
(Dán nhãn/bi ển cảnh báo ngay các t ủ, kệ, khay ch ứa thu ốc  
và dán ở vị trí dễ thấy) 
1. Biển cảnh báo LASA  (dán ngay t ại nơi đ ặt các thu ốc trong danh m ục) 
 
 
 
 
  
 
 
 
2. Nhãn c ảnh báo  
Tùy vào cơ s ố thuốc đang có t ại kho dư ợc, tủ trực các khoa mà nhân viên gi ữ 
thuốc, điều dưỡng tự làm nhãn c ảnh báo theo hư ớng dẫn và m ẫu sau:  
- Viền màu đ ỏ - nền trắng – chữ đen. Đánh d ấu những ch ữ cái khác bi ệt của 
tên thu ốc bằng cách  in đậm, gạch chân  và tăng kích thư ớc đặc điểm phân bi ệt 
giữa hai tên thu ốc. Đối với các thu ốc nhìn gi ống/gần giống nhau  làm theo 
mẫu. Kích thư ớc nhãn tùy thu ộc vào khay, k ệ đựng thu ốc nhưng ph ải đủ lớn 
để gây chú ý.  Nhãn này dán t ại nơi đ ặt các thu ốc trong danh m ục (phụ lục 1), 
cạnh bi ển báo LASA.  
- Ví dụ: 
 
      
 
 
     NGUY CƠ  
NHẦM  
LẪN 
DIAMICRON  30MG  
DIAMICRON 60MG  DOMEVER  25MG  
DOMREME  10MG  
THẬN TR ỌNG: 
MAGNESI SULFAT KABI 15%  
NHÌN GI ỐNG 
KALI CLORID KABI 10%

## Thông tư quy định đấu thầu thuốc tại các cơ sở y tế công lập

Xem toàn bộ Thông tư [**tại đây**](https://bvnguyentriphuong.com.vn/uploads/112023/files/07-TT-BYT-_signed.pdf)
#### Nội dung trong file:



## Chức năng và nhiệm vụ khoa Dược

  * Lập kế hoạch, cung ứng thuốc bảo đảm đủ số lượng, chất lượng cho nhu cầu điều trị và thử nghiệm lâm sàng nhằm đáp ứng yêu cầu chẩn đoán, điều trị và các yêu cầu chữa bệnh khác (phòng chống dịch bệnh, thiên tai, thảm họa). 
  * Quản lý, theo dõi việc nhập thuốc, cấp phát thuốc cho nhu cầu điều trị và các nhu cầu đột xuất khác khi có yêu cầu. 
  * Đầu mối tổ chức, triển khai hoạt động của Hội đồng thuốc và điều trị.
  * Bảo quản thuốc theo đúng nguyên tắc “Thực hành tốt bảo quản thuốc”. 
  * Tổ chức pha chế thuốc, hóa chất sát khuẩn, bào chế thuốc đông y, sản xuất thuốc từ dược liệu sử dụng trong bệnh viện


  * Thực hiện công tác dược lâm sàng, thông tin, tư vấn về sử dụng thuốc, tham gia công tác cảnh giác dược, theo dõi, báo cáo thông tin liên quan đến tác dụng không mong muốn của thuốc.
  * Quản lý, theo dõi việc thực hiện các quy định chuyên môn về dược tại các khoa trong bệnh viện.
  * Nghiên cứu khoa học và đào tạo; là cơ sở thực hành của các trường Đại học, Cao đẳng và Trung học về dược.
  * Phối hợp với khoa cận lâm sàng và lâm sàng theo dõi, kiểm tra, đánh giá, giám sát việc sử dụng thuốc an toàn, hợp lý đặc biệt là sử dụng kháng sinh và theo dõi tình hình kháng kháng sinh trong bệnh viện.
  * Tham gia chỉ đạo tuyến.
  * Tham gia hội chẩn khi được yêu cầu.
  * Tham gia theo dõi, quản lý kinh phí sử dụng thuốc.
  * Quản lý hoạt động của Nhà thuốc bệnh viện theo đúng quy định.
  * Thực hiện nhiệm vụ cung ứng, theo dõi, quản lý, giám sát, kiểm tra, báo cáo về vật tư y tế tiêu hao (bông, băng, cồn, gạc) khí y tế đối với các cơ sở y tế chưa có phòng Vật tư - Trang thiết bị y tế và được người đứng đầu các cơ sở đó giao nhiệm vụ. 


Bệnh nhân có thể để được tư vấn sử dụng thuốc qua số điện thoại: (028)73077311 (giờ hành chánh).
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh

## BÁO CÁO PHẢN ỨNG CÓ HẠI CỦA THUỐC NĂM 2021

Từ ngày 01/01/2021 đến ngày 31/12/2021 tại Bệnh viện có tổng cộng 81 báo cáo ADR liên quan đến thuốc, tất cả đều đã được báo cáo về Trung tâm DI - ADR Quốc gia. Cụ thể như sau:
**SỐ LƯỢNG BÁO CÁO ADR**
Số lượng báo cáo theo từng tháng được tổng hợp trong bảng sau:
Tất cả các ADR đều được gửi online về Trung tâm DI&ADR Quốc Gia. Về chất lượng báo cáo: Đa số báo cáo ghi đầy đủ các thông tin gồm 4 trường thông tin chính: thông tin người bệnh, thông tin về ADR, thông tin về thuốc nghi ngờ và thông tin về người báo cáo. 
**THUỐC NGHI NGỜ GÂY ADR**
**Thuốc và nhóm thuốc**
Các nhóm thuốc chính gây ADR là kháng sinh (**81,8**), thuốc trị giảm đau (**5,5**) và nhóm thuốc khác  (**12,7%).**
**Biểu hiện lâm sàng**
**Quy kết nguyên nhân, xử lý và kết quả**
**KIẾN NGHỊ VÀ CÁCH XỬ LÝ**
  1. **Về chuyên môn**


Theo phản hồi của Trung tâm DI&ADR Quốc Gia Việt Nam như sau:
**Gợi ý về cách xử trí với các loại phản ứng đã ghi nhận tại bệnh viện**  _(cần áp dụng biện pháp xử trí riêng đối với từng trường hợp cụ thể):_
**- Đối với phản ứng dị ứng nhẹ trên da** : để xử trí phản ứng, cần ngừng dùng thuốc nghi ngờ; cho bệnh nhân sử dụng thuốc chống dị ứng đặc hiệu (glucocorticoid, thuốc kháng histamin H1...), thuốc chống bội nhiễm (nếu cần).
**- Trong trường hợp bệnh nhân gặp phản ứng phản vệ, sốc phản vệ** : để xử trí phản ứng, cần tuân thủ theo phác đồ cấp cứu sốc phản vệ do Bộ Y tế ban hành (chi tiết xin xem Thông tư 51/2017/TT-BYT về Hướng dẫn phòng, chẩn đoán và xử trí phản vệ). Theo tài liệu về sốc phản vệ của “Viện quốc gia Hoa Kỳ về Dị ứng và Bệnh nhiễm trùng” năm 2006, có thể xử trí bằng cách tiêm bắp ngay ở trước bên đùi 0,3-0,5 ml dung dịch adrenalin 1/1000 (trẻ em: 0,01 mg/kg cân nặng) lặp lại mỗi 5-15 phút (có thể ngắn hơn 3-5 phút tuỳ đáp ứng và độ nặng trên lâm sàng), thở oxy, đặt nội khí quản nếu cần, truyền dịch tĩnh mạch (NaCl 0,9%) để tăng thể tích huyết tương, dùng thuốc kháng histamin, hít thuốc chủ vận beta-adrenergic (ví dụ: salbutamol, terbutalin) nếu co thắt phế quản, tiêm tĩnh mạch hydrocortison hoặc prednisolon.
**- Với diclofenac** : Nhìn chung các phản ứng có hại của diclofenac thường nhẹ và thoáng qua. Tuy nhiên, để giảm thiểu các phản ứng có hại khi sử dụng diclofenac, các cán bộ y tế cần cân nhắc điều chỉnh tới liều thấp nhất có hiệu quả và dùng thuốc trong thời gian ngắn nhất có thể. Theo Dược thư Quốc gia Việt Nam 2 năm 2015, cần phải tính toán liều dùng diclofenac một cách thận trọng, tùy theo nhu cầu và đáp ứng của từng cá nhân và cần phải dùng liều thấp nhất có tác dụng. Liều tối đa là 150 mg (ở Mỹ là 200 mg). Theo Cơ sở dữ liệu tra cứu thông tin thuốc trực tuyến Martindale 37th: The Complete Drug Reference, liều thường dùng của diclofenac đường uống hoặc đường trực tràng là 75-150 mg/ngày, chia thành các liều nhỏ. Tờ thông tin sản phẩm của diclofenac tại Anh và Canada cũng khuyến cáo liều diclofenac đặt trực tràng là 100 mg/ngày, trong trường hợp chưa đạt hiệu quả điều trị ở mức liều này có thể tăng liều lên mức tối đa 150 mg/ngày.
**- Với Vancomycin:** Theo Dược thư Quốc gia Việt Nam 2 năm 2015, phản ứng trên da là phản ứng có hại đã được ghi nhận khi sử dụng vancomycin đường uống và đường tiêm. Khi sử dụng vancomycin qua đường tiêm, có thể xuất hiện phản ứng trên da như: ban đỏ ở mặt và phần trên cơ thể (hội chứng “cổ đỏ” hay “người đỏ”), đây là phản ứng **rất hay gặp** , tỷ lệ xuất hiện trên 1/10; nguyên nhân một phần do giải phóng histamin và thường do **truyền thuốc nhanh**. Hội chứng được đặc trưng bởi tụt huyết áp đột ngột, có thể kèm theo nóng bừng và xuất hiện ban đỏ hoặc ban sần ở mặt, cổ, ngực và các chi trên. Thường tự hết sau khi ngừng truyền thuốc.
  1. **Khuyến cáo dành cho bệnh viện:**


- Tiếp tục theo dõi bệnh nhân cẩn thận khi sử dụng thuốc để có biện pháp xử trí kịp thời (nếu cần) trong trường hợp xuất hiện phản ứng có hại.
-  Trao đổi với các cơ sở khám, chữa bệnh khác (trên địa TP. Hồ Chí Minh và/hoặc các tỉnh, thành khác) để thu thập thêm thông tin về các trường hợp ADR liên quan đến thuốc và lô thuốc mà bệnh viện mình đang sử dụng.
- Tiếp tục báo cáo các trường hợp ADR được ghi nhận tại bệnh viện đến Trung tâm DI & ADR Quốc gia
**Xử lý với trường hợp Sốc phản vệ:**
  * Điều dưỡng và bác sĩ: 


+ Tiến hành theo Phác đồ xử lý sốc phản vệ của Bộ Y tế.
+ Báo cáo sơ bộ ADR theo mẫu
  * Dược sĩ dược lâm sàng: lên trực tiếp Khoa Phòng để tìm hiểu:


+ Đọc hồ sơ bệnh án của bệnh nhân
+ Tiền sử dị ứng thuốc của bệnh nhân: không 
+ Test da: có tiến hành và cho kết quả âm tính. 
+ Kiểm tra chất lượng thuốc: vỏ thuốc, lô thuốc, hạn dùng, chất lượng thuốc theo cảm quan của điều dưỡng.
+ Hoàn chỉnh Báo cáo ADR và gửi ngay trong ngày cho Trung tâm DI&ADR quốc gia

## Phân loại thuốc: những cách phân loại thường gặp

  * [Phân loại Dược Chính:](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/phan-loai-thuoc-nhung-cach-phan-loai-thuong-gap#phn-loi-dc-chnh)


### **Phân loại Dược Chính:**
  * Một số thuốc gây nghiện, thuốc hướng tâm thần cần phải được bảo quản riêng, chỉ cấp cho bệnh nhân khi có đơn thuốc của bác sĩ có quyền kê đơn.
  * Dược Chính được chia thành các nhóm:
    * Thuốc thường.
    * Thuốc gây nghiện.
    * Thuốc hướng tâm thần.
    * Thuốc phóng xạ.
    * Thuốc corticoid.
    * Thuốc kháng sinh.
    * Thuốc chống ung thư.
    * Thuốc chương trình (lao, phong, tâm thần, sốt rét...).
    * Thực phẩm chức năng.
    * Thuốc đông y.
    * Dịch truyền.


**Phân loại theo kê đơn:**
  * Thuốc kê đơn là thuốc phải có đơn của BS thì mới được phép mua - bán. Thuốc kê đơn có ký hiệu chữ Rx.
  * Phân loại thuốc: theo kê đơn, không kê đơn. Khi bệnh nhân đến quầy mua thuốc tự do thì nhân viên dược không được phép bán các thuốc đã phân loại "kê đơn".


**Phân loại theo Họ Trị Liệu:**
  * Là tên của một nhóm thuốc có cùng chức năng.
  * Ví dụ:
    * Nhóm tiêu hóa (A)
      * A1: Phân nhóm thuốc dạ dày
      * A2: Phân nhóm thuốc đường ruột
      * A3: Phân nhóm thuốc chống táo bón
      *     * Nhóm tim mạch (B)
      * B1: Phân nhóm tăng huyết áp
      * B2: Phân nhóm mạch vành
      * B3: Phân nhóm trợ tim.
      *     * Nhóm thần kinh (C)
      * C1: ...
  * Họ trị liệu chủ yếu giúp cho BS tra cứu nhanh, phục vụ cho Dược Lâm Sàng. Đa phần các kho dược khi nhập thuốc mới không khai báo họ trị liệu.
  * Không nên dùng họ trị liệu để phân loại Dược Chính thuốc.


**Phân loại theo dạng thuốc (tủ thuốc):**
  * Các bệnh viện lớn thường chia kho thuốc thành nhiều kho khác nhau phân biệt theo dạng của thuốc: Kho thuốc viên, kho thuốc ống/chai, kho dịch truyền.
  * Khi nạp danh mục thuốc thì bắt buộc phân loại dạng thuốc.


**Phân loại theo nước sản xuất:**
  * Khi nhập thuốc, cần khai báo nước sản xuất để phân loại.
  * Phân loại đơn giản: trong nước và nước ngoài.
  * Phân loại đầy đủ: kê tên nước sản xuất.
  * Việc thống kê thuốc theo nước sản xuất chỉ chia thành 2 nhóm: trong nước và nước ngoài.


**Phân loại tự do để xếp kho:**
  * Nếu dùng 1 phân hệ Dược để quản lý chung cho tất cả các loại thuốc và vật tư y tế thì cần phân loại theo chủng loại.
  * Phân loại theo hình thức: Thuốc ống, thuốc viên, thuốc gói, dịch truyền, cao dán...
  * Phân loại theo tác dụng: Thuốc đông y, thuốc lao, thuốc ung thư...


**DANH MỤC CHUYÊN MÔN DƯỢC**
  * Danh mục hoạt chất quốc tế (ATC).
  * Danh mục họ trị liệu.
  * Danh mục phân loại dược chính.
  * Danh mục dạng bào chế:
    * Thuốc viên
      * _Viên nén._
      * _Viên nhộng._
      * _Viên đạn (tọa dược)._
      * _Viên sủi._
    * Thuốc nước
      * _Ống uống_
      * _Ống tiêm_
      * _Chai / lọ._
    * Thuốc bột
      * _Ống._
      * _Gói._
    * Dạng sirop
    * Dạng phun
    * Dạng miếng dán
    * Que thử
  * Danh mục liều sử dụng:
    * _Viên_
    * _Muỗng cafe_
    * _Giọt_
  * Danh mục đường sử dụng
    * Dùng đường miệng:
      * _Uống_
      * _Ngậm_
      * _Ngậm dưới lưỡi_
      * _Súc miệng_
      * _Nhai_
      * _Nhỏ dưới lưỡi_
    * Dùng qua da
      * _Chích/tiêm bắp_
      * _Tiêm mạch_
      * _Tiêm dưới da_
      * _Truyền tĩnh mạch._
    * Dùng ngoài da
      * _Băng_
      * _Thoa_
    * Dùng đường thở
      * _Ngửi_
      * _Xông_
      * _Nhỏ mũi._
    * Dùng qua lỗ tự nhiên
      * _Nhét hậu môn_
      * _Đặt âm đạo_
      * _Nhỏ tai_
      * _Nhỏ mắt_
      * _Nhỏ mũi._
    * Dạng cao
      * _Xoa._
      * _Dán._
    * Bơm tiêm pha sẵn
      * _Tiêm._


  * [Phân loại Dược Chính:](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/phan-loai-thuoc-nhung-cach-phan-loai-thuong-gap#phn-loi-dc-chnh)



## Thực hành tốt sản xuất thuốc và Thực hành tốt phân phối thuốc

**GMP là tiêu chuẩn tối thiểu** mà một nhà sản xuất dược phẩm phải đáp ứng được trong qui trình sản xuất thuốc. 
**Tiêu chuẩn GDP** nhấn mạnh rằng thuốc phải được cung cấp bởi hệ thống cung ứng đã được cấp phép, được bảo quản, vận chuyển, và xử lý ở điều kiện thích hợp mà không bị ảnh hưởng chất lượng thuốc.
### **Tại sao phải sản xuất thuốc theo tiêu chuẩn GMP**
Lý giải tại sao phải sản xuất thuốc theo tiêu chuẩn GMP, trong**hướng dẫn thực hành tốt sản xuất thuốc GMP** đã cung cấp các yêu cầu tối thiểu mà nhà sản xuất phải đáp ứng để đảm bảo rằng các sản phẩm của họ luôn có chất lượng cao, từ lô này đến lô khác. Đồng thời ngăn chặn những ảnh hưởng xấu của sản phẩm đến người tiêu dùng.
– Đảm bảo chất lượng sản phẩm, ngăn ngừa một cách chủ động các nguyên nhân chủ quan hoặc khách quan có thể ảnh hưởng đến chất lượng sản phẩm trong quá trình sản xuất, chế biến, từ khi tiếp nhận nguyên liệu đến sản phẩm cuối cùng; tạo lòng tin cho người tiêu dùng.
– Giảm thiểu các sản phẩm không đạt tiêu chuẩn, hàng giả, hàng hàng kém chất lượng lưu hành trên thị trường.
– Giảm chi phí sản xuất do quy trình sản xuất, các trang thiết bị, kỹ thuật đã được xác định chính xác và chuẩn hóa ngay từ khâu đầu tiên; tránh lãng phí nguồn vốn trong quá trình đầu tư.
– Nâng cao trách nhiệm và trình độ chuyên môn của cán bộ, nhân viên trong doanh nghiệp.
– Đáp ứng các yêu cầu về chất lượng sản phẩm áp dụng GMP – WHO giúp thúc đẩy cơ hội kinh doanh, đưa doanh nghiệp bước vào thị trường quốc tế, tăng sức cạnh tranh với các doanh nghiệp trong và ngoài nước.
**Thực hành tốt sản xuất thuốc GMP** là tiêu chuẩn rất quan trọng đối với các nhà máy và cơ sở sản xuất để đảm bảo chất lượng sản phẩm đặc biệt đối với lĩnh vực dược phẩm nhằm tạo ra những sản phẩm tốt nhất và an toàn cho người sử dụng.
**Tổ chức và quản lý "Thực hành tốt phân phối thuốc"**
a) Cơ sở phân phối thuốc phải có tư cách pháp nhân, được cấp giấy chứng nhận đủ điều kiện hành nghề kinh doanh thuốc theo các quy định hiện hành của Luật Dược và các Luật, văn bản pháp quy liên quan và phải đủ năng lực chịu trách nhiệm về các hoạt động của mình.
b) Cơ sở phân phối phải thiết lập một cơ cấu tổ chức thích hợp, được minh họa bằng sơ đồ tổ chức. Trách nhiệm, quyền hạn và mối quan hệ giữa các nhân viên phải được xác định rõ ràng.
c) Phải bố trí đủ nhân sự để tiến hành tất cả các nhiệm vụ thuộc trách nhiệm của cơ sở phân phối.
d) Các nhân viên quản lý và quản lý kỹ thuật phải có đủ quyền hạn và nguồn lực cần thiết để thực hiện nhiệm vụ của mình và để xác định, điều chỉnh những sai lệch so với hệ thống quản lý chất lượng.
đ) Trách nhiệm của từng cá nhân phải được xác định rõ và phải được ghi trong bản mô tả công việc của từng cá nhân. Tất cả nhân viên phải được đào tạo, hiểu rõ trách nhiệm, và công việc của mình. Các nhân viên chịu trách nhiệm về việc bảo quản, phân phối vận chuyển các thuốc gây nghiện, thuốc hướng tâm thần phải có trình độ, năng lực đáp ứng các quy định tại các quy chế liên quan.
e) Trong trường hợp nhà phân phối có ít nhân viên, có thể uỷ quyền hoặc hợp đồng thực hiện một số nhiệm vụ cho những nhân viên hoặc tổ chức phù hợp.
g) Phải có các quy định về an toàn của nhân viên và của tài sản, bảo vệ môi trường, tính toàn vẹn của sản phẩm.

## BÁO CÁO PHẢN ỨNG CÓ HẠI CỦA THUỐC NĂM 2022

Từ ngày 01/01/2022 đến ngày 28/10/2022 tại Bệnh Viện có tổng công 151 báo cáo ADR liên quan đến các thuốc, tắt cả đều đã được báo cáo về Trung tâm ADR Quốc gia cụ thể như sau:
**SỐ LƯỢNG BÁO CÁO ADR**
Số lượng báo cáo theo từng tháng được tổng hợp trong bảng sau:
Tất cả các ADR đều được gửi online về Trung tâm DI&ADR Quốc Gia. Về chất lượng báo cáo: Đasố báo cáo ghi đầy đủ các thông tin gồm 4 trường thông tin chính: thông tin người bệnh, thông tin về ADR, thông tin về thuốc nghi ngờ và thông tin về người báo cáo
**THUỐC NGHI NGỜ GÂY ADR**
**Thuốc và nhóm thuốc**
Các nhóm thuốc chính gây ADR là kháng sinh (**81,8****%**), thuốc trị giảm đau (**5,5****%**) và nhóm thuốc khác (**12,7%).**
**Biểu hiện lâm sàng**
**Quy kết nguyên nhân, xử lý và kết quả**
**KIẾN NGHỊ VÀ CÁCH XỬ LÝ**
  1. **Về chuyên môn**


Theo phản hồi của Trung tâm DI&ADR Quốc Gia Việt Nam như sau:
**Gợi ý về cách xử trí với các loại phản ứng đã ghi nhận tại bệnh viện**  _(cần áp dụng biện pháp xử trí riêng đối với từng trường hợp cụ thể):_
**- Đối với phản ứng dị ứng nhẹ trên da** : để xử trí phản ứng, cần ngừng dùng thuốc nghi ngờ; cho bệnh nhân sử dụng thuốc chống dị ứng đặc hiệu (glucocorticoid, thuốc [kháng histamin](https://bvnguyentriphuong.com.vn/duoc-lam-sang-cho-cong-dong/huong-dan-su-dung-thuoc-khang-histamin) H1...), thuốc chống bội nhiễm (nếu cần).
**- Trong trường hợp bệnh nhân gặp phản ứng phản vệ,[sốc phản vệ](https://bvnguyentriphuong.com.vn/hoi-suc-tich-cuc-chong-doc/soc-phan-ve-1641433881)**: để xử trí phản ứng, cần tuân thủ theo phác đồ cấp cứu [sốc phản vệ](https://bvnguyentriphuong.com.vn/hoi-suc-tich-cuc-chong-doc/soc-phan-ve-1641433881) do Bộ Y tế ban hành (chi tiết xin xem Thông tư 51/2017/TT-BYT về Hướng dẫn phòng, chẩn đoán và xử trí phản vệ). Theo tài liệu về [sốc phản vệ](https://bvnguyentriphuong.com.vn/hoi-suc-tich-cuc-chong-doc/soc-phan-ve-1641433881) của “Viện quốc gia Hoa Kỳ về Dị ứng và Bệnh nhiễm trùng” năm 2006, có thể xử trí bằng cách tiêm bắp ngay ở trước bên đùi 0,3-0,5 ml dung dịch adrenalin 1/1000 (trẻ em: 0,01 mg/kg cân nặng) lặp lại mỗi 5-15 phút (có thể ngắn hơn 3-5 phút tuỳ đáp ứng và độ nặng trên lâm sàng), thở oxy, đặt nội khí quản nếu cần, truyền dịch tĩnh mạch (NaCl 0,9%) để tăng thể tích huyết tương, dùng thuốc [kháng histamin](https://bvnguyentriphuong.com.vn/duoc-lam-sang-cho-cong-dong/huong-dan-su-dung-thuoc-khang-histamin), hít thuốc chủ vận beta-adrenergic (ví dụ: salbutamol, terbutalin) nếu co thắt phế quản, tiêm tĩnh mạch hydrocortison hoặc prednisolon.
**- Với diclofenac** : Nhìn chung các phản ứng có hại của diclofenac thường nhẹ và thoáng qua. Tuy nhiên, để giảm thiểu các phản ứng có hại khi sử dụng diclofenac, các cán bộ y tế cần cân nhắc điều chỉnh tới liều thấp nhất có hiệu quả và dùng thuốc trong thời gian ngắn nhất có thể. Theo Dược thư Quốc gia Việt Nam 2 năm 2015, cần phải tính toán liều dùng diclofenac một cách thận trọng, tùy theo nhu cầu và đáp ứng của từng cá nhân và cần phải dùng liều thấp nhất có tác dụng. Liều tối đa là 150 mg (ở Mỹ là 200 mg). Theo Cơ sở dữ liệu tra cứu thông tin thuốc trực tuyến Martindale 37th: The Complete Drug Reference, liều thường dùng của diclofenac đường uống hoặc đường trực tràng là 75-150 mg/ngày, chia thành các liều nhỏ. Tờ thông tin sản phẩm của diclofenac tại Anh và Canada cũng khuyến cáo liều diclofenac đặt trực tràng là 100 mg/ngày, trong trường hợp chưa đạt hiệu quả điều trị ở mức liều này có thể tăng liều lên mức tối đa 150 mg/ngày.
**- Với Vancomycin:** Theo Dược thư Quốc gia Việt Nam 2 năm 2015, phản ứng trên da là phản ứng có hại đã được ghi nhận khi sử dụng vancomycin đường uống và đường tiêm. Khi sử dụng vancomycin qua đường tiêm, có thể xuất hiện phản ứng trên da như: ban đỏ ở mặt và phần trên cơ thể (hội chứng “cổ đỏ” hay “người đỏ”), đây là phản ứng **rất hay gặp** , tỷ lệ xuất hiện trên 1/10; nguyên nhân một phần do giải phóng histamin và thường do **truyền thuốc nhanh**. Hội chứng được đặc trưng bởi tụt huyết áp đột ngột, có thể kèm theo nóng bừng và xuất hiện ban đỏ hoặc ban sần ở mặt, cổ, ngực và các chi trên. Thường tự hết sau khi ngừng truyền thuốc.
  1. **Khuyến cáo dành cho bệnh viện:**


- Tiếp tục theo dõi bệnh nhân cẩn thận khi sử dụng thuốc để có biện pháp xử trí kịp thời (nếu cần) trong trường hợp xuất hiện phản ứng có hại.
- Trao đổi với các cơ sở khám, chữa bệnh khác (trên địa TP. Hồ Chí Minh và/hoặc các tỉnh, thành khác) để thu thập thêm thông tin về các trường hợp ADR liên quan đến thuốc và lô thuốc mà bệnh viện mình đang sử dụng.
- Tiếp tục báo cáo các trường hợp ADR được ghi nhận tại bệnh viện đến Trung tâm DI & ADR Quốc gia
**Xử lý với trường hợp[Sốc phản vệ](https://bvnguyentriphuong.com.vn/hoi-suc-tich-cuc-chong-doc/soc-phan-ve-1641433881):**
  * Điều dưỡng và bác sĩ:


+ Tiến hành theo Phác đồ xử lý [sốc phản vệ](https://bvnguyentriphuong.com.vn/hoi-suc-tich-cuc-chong-doc/soc-phan-ve-1641433881) của Bộ Y tế.
+ Báo cáo sơ bộ ADR theo mẫu
  * Dược sĩ dược lâm sàng: lên trực tiếp Khoa Phòng để tìm hiểu:


+ Đọc hồ sơ bệnh án của bệnh nhân
+ Tiền sử dị ứng thuốc của bệnh nhân: không
+ Test da: có tiến hành và cho kết quả âm tính.
+ Kiểm tra chất lượng thuốc: vỏ thuốc, lô thuốc, hạn dùng, chất lượng thuốc theo cảm quan của điều dưỡng.
+ Hoàn chỉnh Báo cáo ADR và gửi ngay trong ngày cho Trung tâm DI&ADR quốc gia

## BÁO CÁO PHẢN ỨNG CÓ HẠI CỦA THUỐC NĂM 2019

Từ ngày 01/01/2019 đến ngày 31/12/2019 tại Bệnh viện có tổng cộng 147 báo cáo ADR liên quan đến các thuốc, tất cả đều đã được báo cáo về Trung tâm ADR Quốc gia.Cụ thể như sau:
**I. SỐ LƯỢNG BÁO CÁO ADR:**
Số lượng báo cáo theo từng tháng được tổng hợp trong bảng sau:
Tất cả các ADR đều được gửi online về Trung tâm DI&ADR Quốc Gia. 
Về chất lượng báo cáo: 
Đa số báo cáo ghi đầy đủ các thông tin gồm 4 trường thông tin chính: Thông tin người bệnh, thông tin về ADR, thông tin về thuốc nghi ngờ và thông tin về người báo cáo. 
**II. THUỐC NGHI NGỜ GÂY ADR:**
**III. BIỂU HIỆN ADR:**
Đa số các ca ADR đều ở mức độ không nghiêm trọng ( 90,48%). Một vài ca ở mức độ đe dọa tính mạng và kéo dài thời gian nằm viện( 9,52%). 
Theo bảng trên, biểu hiện được báo cáo nhiều nhất là ngứa (64,0%), ban đỏ/mẫn đỏ (chiếm 61,9%), sưng húp, lạnh, khó thở.... Tất cả các trường hợp đều hồi phục không để lại di chứng sau khi xử lý.
**IV. KIẾN NGHỊ VÀ CÁCH XỬ LÝ:**
**1. Về chuyên môn**
Theo phản hồi của Trung tâm DI&ADR Quốc Gia Việt Nam như sau:
Gợi ý về cách xử trí với các loại phản ứng đã ghi nhận tại bệnh viện (cần áp dụng biện pháp xử trí riêng đối với từng trường hợp cụ thể):
- Đối với phản ứng dị ứng nhẹ trên da: để xử trí phản ứng, cần ngừng dùng thuốc nghi ngờ; cho bệnh nhân sử dụng thuốc chống dị ứng đặc hiệu (glucocorticoid, thuốc kháng histamin H1...), thuốc chống bội nhiễm (nếu cần).
- Trong trường hợp bệnh nhân gặp phản ứng phản vệ, sốc phản vệ: để xử trí phản ứng, cần tuân thủ theo phác đồ cấp cứu sốc phản vệ do Bộ Y tế ban hành (chi tiết xin xem Thông tư 51/2017/TT-BYT về Hướng dẫn phòng, chẩn đoán và xử trí phản vệ). Theo tài liệu về sốc phản vệ của “Viện quốc gia Hoa Kỳ về Dị ứng và Bệnh nhiễm trùng” năm 2006, có thể xử trí bằng cách tiêm bắp ngay ở trước bên đùi 0,3-0,5 ml dung dịch adrenalin 1/1000 (trẻ em: 0,01 mg/kg cân nặng) lặp lại mỗi 5-15 phút (có thể ngắn hơn 3-5 phút tuỳ đáp ứng và độ nặng trên lâm sàng), thở oxy, đặt nội khí quản nếu cần, truyền dịch tĩnh mạch (NaCl 0,9%) để tăng thể tích huyết tương, dùng thuốc kháng histamin, hít thuốc chủ vận beta-adrenergic (ví dụ: salbutamol, terbutalin) nếu co thắt phế quản, tiêm tĩnh mạch hydrocortison hoặc prednisolon.
- Với diclofenac: Nhìn chung các phản ứng có hại của diclofenac thường nhẹ và thoáng qua. Tuy nhiên, để giảm thiểu các phản ứng có hại khi sử dụng diclofenac, các cán bộ y tế cần cân nhắc điều chỉnh tới liều thấp nhất có hiệu quả và dùng thuốc trong thời gian ngắn nhất có thể. Theo Dược thư Quốc gia Việt Nam 2 năm 2015, cần phải tính toán liều dùng diclofenac một cách thận trọng, tùy theo nhu cầu và đáp ứng của từng cá nhân và cần phải dùng liều thấp nhất có tác dụng. Liều tối đa là 150 mg (ở Mỹ là 200 mg). Theo Cơ sở dữ liệu tra cứu thông tin thuốc trực tuyến Martindale 37th: The Complete Drug Reference, liều thường dùng của diclofenac đường uống hoặc đường trực tràng là 75-150 mg/ngày, chia thành các liều nhỏ. Tờ thông tin sản phẩm của diclofenac tại Anh và Canada cũng khuyến cáo liều diclofenac đặt trực tràng là 100 mg/ngày, trong trường hợp chưa đạt hiệu quả điều trị ở mức liều này có thể tăng liều lên mức tối đa 150 mg/ngày.
- Với Vancomycin: Theo Dược thư Quốc gia Việt Nam 2 năm 2015, phản ứng trên da là phản ứng có hại đã được ghi nhận khi sử dụng vancomycin đường uống và đường tiêm. Khi sử dụng vancomycin qua đường tiêm, có thể xuất hiện phản ứng trên da như: ban đỏ ở mặt và phần trên cơ thể (hội chứng “cổ đỏ” hay “người đỏ”), đây là phản ứng rất hay gặp, tỷ lệ xuất hiện trên 1/10; nguyên nhân một phần do giải phóng histamin và thường do truyền thuốc nhanh. Hội chứng được đặc trưng bởi tụt huyết áp đột ngột, có thể kèm theo nóng bừng và xuất hiện ban đỏ hoặc ban sần ở mặt, cổ, ngực và các chi trên. Thường tự hết sau khi ngừng truyền thuốc.
**2. Khuyến cáo dành cho bệnh viện:**
- Tiếp tục theo dõi bệnh nhân cẩn thận khi sử dụng thuốc để có biện pháp xử trí kịp thời (nếu cần) trong trường hợp xuất hiện phản ứng có hại.
- Trao đổi với các cơ sở khám, chữa bệnh khác (trên địa TP. Hồ Chí Minh và/hoặc các tỉnh, thành khác) để thu thập thêm thông tin về các trường hợp ADR liên quan đến thuốc và lô thuốc mà bệnh viện mình đang sử dụng.
- Tiếp tục báo cáo các trường hợp ADR được ghi nhận tại bệnh viện đến Trung tâm DI & ADR Quốc gia.
Xử lý với trường hợp Sốc phản vệ:
- Điều dưỡng và bác sĩ: 
+ Tiến hành theo Phác đồ xử lý sốc phản vệ của Bộ Y tế.
+ Báo cáo sơ bộ ADR theo mẫu
- Dược sĩ dược lâm sàng: lên trực tiếp Khoa Phòng để tìm hiểu:
+ Đọc hồ sơ bệnh án của bệnh nhân
+ Tiền sử dị ứng thuốc của bệnh nhân: không 
+ Test da: có tiến hành và cho kết quả âm tính. 
+ Kiểm tra chất lượng thuốc: vỏ thuốc, lô thuốc, hạn dùng, chất lượng thuốc theo cảm quan của điều dưỡng.
+ Hoàn chỉnh Báo cáo ADR và gửi ngay trong ngày cho Trung tâm DI&ADR quốc gia
_**Khoa Dược - Tổ dược lâm sàng**_

## ️ Tại sao Molnupiravir là thuốc hàng đầu trong điều trị COVID-19?

Công ty dược phẩm Merck đã thông báo rằng một loại thuốc kháng virus mà hãng đang phát triển có thể giảm một nửa số ca nhập viện và số ca tử vong ở những người bị nhiễm COVID-19. Các kết quả vẫn chưa được bình duyệt khoa học. Nhưng nếu được các cơ quan pháp lí thông qua, Molnupiravir sẽ là phương pháp điều trị kháng virus COVID-19 đầu tiên qua đường uống. Mặt khác, các loại thuốc khác hiện đang được cấp phép phải được truyền qua tĩnh mạch hoặc qua đường tiêm.
Một viên thuốc có thể giúp điều trị sớm hơn đối với tình trạng nhiễm trùng của bệnh nhân dễ dàng hơn– và hiệu quả hơn. Nó có thể giúp các bệnh viện không bị quá tải, đặc biệt ở những nơi mà tỷ lệ chích ngừa vẫn còn thấp, chẳng hạn như các quốc gia có thu nhập thấp và trung bình thấp. Khi Molnupiravir thể hiện sự hiệu quả trong giai đoạn 3 của thử nghiệm lâm sàng liên quan đến những người có nguy cơ bệnh nặng và dương tính với COVID-19, các bác sĩ đã dừng việc nhập viện sớm.
Nhưng liệu chuyện thành công trong việc thử nghiệm lâm sàng sẽ trở thành một sự thay đổi toàn cầu trong cuộc chiến chống lại đại dịch hay không thì vẫn chưa rõ . Ngay cả nếu các quốc gia thu nhập thấp hơn có đủ thuốc, họ có thể không đủ khả năng chuẩn đoán để điều trị sớm cho bệnh nhân với Molnupiravir, khi mà việc đó có thể tạo ra sự khác biệt.
Tuần này, hai nhà sản xuất thuốc tại Ấn độ đã tiến hành các thử nghiệm độc lập một loại thuốc có cùng hoạt chất với Molnupiravir (generic) ở những người bị bệnh ở mức độ trung bình do COVID-19, đã phải kết thúc thử nghiệm vì họ không thấy được ”hiệu quả đáng kể” đối với loại thuốc thử nghiệm này, mặc dù họ có kế họach tiếp tục thử nghiệm cho những người bị bệnh nhẹ. Những phát hiện của công ty dược Merk, dù vẫn chưa được nghiên cứu cẩn thận bởi các nhà khoa học và đệ trình lên các cơ quan quản lý để phê duyệt, nhưng thông tin được tiết lộ trong một thông cáo báo chí, họ đã áp dụng cho những người mắc bệnh COVID-19 ở mức độ nhẹ đến trung bình mà không phải nhập viện. Người phát ngôn của công ty Merck chỉ ra rằng những trường hợp mắc COVID-19 ở mức độ vừa phải tại Ấn độ được xác định là ở mức độ nghiêm trọng hơn tại Mỹ và được yêu cầu nhập viện.
**Đánh sớm, đánh mạnh**
Các liệu trình điều trị khác được đưa ra để chống lại COVID-19, như thuốc kháng virus Remdesivir của Gilead Science và một tổ hợp kháng thể đơn dòng từ hãng công nghệ sinh học Regeneron, phải được truyền qua đường tĩnh mạch hoặc qua đường tiêm. Điều đó khiến mọi người khó tiếp cận với các liệu pháp trừ khi họ bệnh đủ nặng để đến bệnh viện. Và Remmdesivir chỉ được chấp nhận cho những người đã nhập viện với COVID-19.
Richard Plemper, một nhà vi-rút học tại Đại học Georgia State ở Atlanta, cho rằng thuốc kháng vi-rút vẫn tốt hơn khi “đánh thuốc sớm, đánh thuốc mạnh”. Bệnh nhân càng trở nặng, thuốc điều trị càng kém hiệu quả. Một viên thuốc uống chống COVID-19 sẽ giúp việc điều trị sớm dễ dàng hơn, khi chỉ cần kê đơn và một chuyến đi đến hiệu thuốc ngay khi các triệu chứng xuất hiện.
COVID-19 không phải là căn bệnh đầu tiên do coronavirus mà gây ra ảnh hưởng nghiêm trọng đến con người. Vào năm 2002-2004, dịch hội chứng hô hấp cấp tính nghiêm trọng (SARS) và đợt bùng phát hội chứng hô hấp Trung Đông (MERS) năm 2012, tuy nhiên cả hai chưa bao giờ lan rộng – điều đó có nghĩa rằng các nhà sản xuất thuốc không có quá nhiều động lực để phát triển thuốc kháng vi-rút chống lại những căn bệnh này.
Vì vậy, khi những trường hợp đầu tiên của COVID-19 xuất hiện vào cuối năm 2019, “không có một danh mục thuốc kháng vi-rút nào có sẵn”, bác sĩ bệnh truyền nhiễm Saye Khoo tại Đại học Liverpool tại Vương quốc Anh cho biết, người đã dẫn đầu một thử nghiệm lâm sàng của Molnupiravir.
Những nỗ lực ban đầu để tìm ra phương pháp điều trị xoay quanh các loại thuốc đã được các cơ quan quản lý phê duyệt và chỉ thu lại một kết quả duy nhất: **Dexamethasone** , một loại steroid nhằm làm giảm phản ứng viêm quá mức ở những người chuyển biến nặng. FAD đã không cho phép loại thuốc sử dụng cho mục đích này, nhưng nó được sử dụng rộng rãi để điều trị những người bệnh nặng nhất.
Nhưng ngay cả khi các nhà nghiên cứu nỗ lực để thử nghiệm các loại thuốc đã được phê duyệt, các công ty dược phẩm và công ty công nghệ sinh học vẫn đang tìm kiếm từ các nguồn có sẵn để tìm bất kỳ hợp chất nào có hoạt tính kháng vi-rút đã biết mà có thể ngăn chặn vi-rút SARS-CoV-2. Những loại thuốc kháng vi-rút phổ rộng này không được điều chế đặc trị cho SARS-CoV-2, nhưng chúng có khả năng. Khác với nhiều loại thuốc được thử nghiệm ban đầu trong đại dịch, giám đốc điều hành của Enanta Pharmaceuticals, một công ty ở Watertown đang tự phát triển thuốc kháng vi-rút COVID 19, ông Jay Luly cho biết, “có một cơ sở lý luận khoa học. Bạn sẽ hiểu chúng đang hoạt động thế nào”.
Cho đến nay, Remdeesivir của công ty Gilead là loại thuốc duy nhất đã nhận được sự chấp thuận từ Cục Quản lý Thực phẩm và Dược phẩm Hoa Kỳ (FDA). Khi được sử dụng tại bệnh viện, tác dụng của nó rất ít. Trong một thử nghiệm lâm sàng giai đoạn 3, các nhà nghiên cứu nhận thấy rằng thuốc này đã rút ngắn thời gian phục hồi trung bình 5 ngày. Công ty Merck hy vọng Molnupiravir sẽ là thuốc tiếp theo nhận được sự cấp phép sử dụng.
**Tiềm năng**
Molnupiravir đã được dùng như một liệu pháp khả thi cho vi-rút viêm não ngựa ở Venezuela tại công ty phi lợi nhuận DRIVE (Drug Innovation Ventures at Emory) của Đại học Emory ở Atlanta. Nhưng vào năm 2015, giám đốc điều hành của DRIVE, ông George Painter, đã đề nghị thuốc này cho một người cộng tác, nhà vi-rút học Mark Denison tại Đại học Vanderbilt ở Nashville, Tennessee, để thử nghiệm thuốc chống lại coronavirus. Denison nhớ lại: “ Tôi đã rất ngạc nhiên vì điều đó”. Ông phát hiện ra rằng nó có tác dụng chống lại nhiều loại coronavirus như MERS và virus viêm gan chuột.
Ông Painter cũng đã tuyển dụng người cộng tác của mình, ông Plemper, để thử nghiệm loại thuốc chống lại bệnh cúm và vi-rút hợp bào hô hấp. Tuy nhiên, các kế hoạch đã thay đổi sau khi đại dịch xảy ra. Công ty DRIVE đã cấp phép hợp chất này cho Ridgeback Biotherapeutics ở Miami, Florida. Ông Plemper cũng xoay quanh coronavirus và thử nghiệm hợp chất này ở chồn sương. Ông nói, nó đã ngăn chặn khả năng sinh sản của vi-rút và sự lây truyền của vi-rút từ những con chồn bị nhiễm bệnh sang những con không bị nhiễm bệnh. Những dữ liệu từ công ty Merck đưa ra dẫn chứng có thể đúng ở người: Molnupiravir dường như rút ngắn thời gian lây nhiễm của SARS-CoV-2 ở những người tham gia khi thử nghiệm lâm sàng với vi-rút.
Molnupiravir, giống như Remdesivir, là một chất tương tự nucleoside, có nghĩa là nó bắt chước một số khối cấu tao của RNA. Nhưng các hợp chất của thuốc hoạt động những cách hoàn toàn khác nhau. Khi vi-rút SARS-CoV-2 xâm nhập vào một tế bào, vi-rút cần tự nhân đôi bộ gen RNA để tạo thành vi-rút mới. Remdesirvir là một “chất kết thúc chuỗi”. Nó ngăn không cho enzyme xây dựng những “chuỗi” RNA bằng cách thêm các liên kết khác. Mặt khác, Molnupiravir được kết hợp vào các sợi RNA đang phát triển và một khi ở bên trong các sợi RNA nó sẽ phá hủy các sợi này. Hợp chất của thuốc có thể thay đổi cấu hình của RNA, đôi khi bắt chước cytidine nucleoside và đôi khi bắt chước uridine. Các sợi RNA đó trở thành bản thiết kế lỗi cho vòng đời tiếp theo của bộ gen vi-rút. Ông Plemper cho rằng, bất cứ nơi nào hợp chất của thuốc được đưa vào và có sự thay đổi cấu trúc đó xảy ra, một đột biến điểm sẽ xảy ra. Khi các điểm đột biến tích lũy đủ, quần thể vi-rút sẽ bị sụp đổ. “Đó là những gì chúng tôi gọi là sự gây đột biến chết người,” ông cho biết thêm. “Về cơ bản , vi-rút tự biến đổi cho đến chết”. Và bởi vì các đột biến tích lũy ngẫu nhiên, sẽ rất khó để vi-rút tiến hóa khả năng kháng Molnupiravir – đây là một điểm cộng cho hợp chất của thuốc.
Nhưng tiềm năng gây đột biến của hợp chất trong tế bào người – khả năng hợp chất có thể tự kết hợp vào DNA – làm dấy lên những lo ngại về an toàn, một số nhà nghiên cứu cho biết. Công ty Merck chưa công bố chi tiết bất kỳ dữ liệu an toàn nào, nhưng ông Daria Hazuda, phó chủ tịch Viện phát hiện bệnh truyền nhiễm và giám đốc khoa học của Merck, nói buổi họp báo vào thứ sáu tuần trước: “Chúng tôi tin rằng rằng thuốc sẽ an toàn nếu được sử dụng đúng mục đích”.
**Chờ đợi khi cơ hội đến**
Các loại thuốc kháng vi-rút khác đang được thực hiện. Gilead Sciences đang phát triển một dạng thuốc viên của Remdesivir. Và Denison cho rằng nếu thuốc kháng vi-rút được dùng cho bệnh nhân cũng nhanh và sớm như Molnupiravir – khi mà các triệu chứng chỉ vừa xuất hiện và lượng vi-rút còn cao – thì nó sẽ cho hiệu quả tương tự. Trong một nghiên cứu được trình bày tại IDWeek, một cuộc họp trực tuyến giữa các chuyên gia về bệnh truyền nhiễm và các nhà dịch tễ học được tổ chức vào đầu tháng này, các nhà nghiên cứu đã báo cáo kết quả của việc tiêm truyền của Remdesivir cho những người ở giai đoạn đầu mắc COVID-19 mỗi 3 ngày. Số lượng người tham vào nghiên cứu này là nhỏ nhưng Remdesivir cho thấy việc làm giảm tỉ lệ nhập viện ở những người có nguy cơ nhiễm cao COVID-19 xuống 87%.
Công ty công nghệ sinh học Atea Pharmaceuticals tại Boston- Massachusetts, cũng đang thử nghiệm một loại thuốc kháng vi-rút. Họ thử nghiệm một loại tương tự nucleoside chống lại bệnh viêm gan C trong một nghiên cứu lâm sàng khi SARS-COVID-2 đã xuất hiện. Đại dịch đã tạm ngưng quá trình thử nghiệm, vì vậy Atea đã quyết định chuyển trọng tâm sang COVID-19. HIện tại họ đã hợp tác với Roche ở Basel-Thụy Sĩ để phát triển hợp chất thuốc của mình.
Công ty Pfizer có trụ sở tại thành phố New York cũng có một khởi đầu thuận lợi. Công ty đã phát triển thuốc kháng vi-rút chống lại SARS từ đầu những năm 2000, nhưng đã gác lại chúng khi đại dịch bùng phát. Khi đại dịch COVID-19 bắt đầu, ông Luly nói “đại dịch đã thổi bay mọi thứ”. Các nhà nghiên cứu hiện đang thử nghiệm một dạng thuốc viên của một hợp chất có chế hoạt động tương tự như các phiên bản gốc. Thử nghiệm đang trong hai phần ba giai đoạn thử nghiệm lâm sàng trong việc điều trị những người mới bị nhiễm bệnh.
**Áp dụng toàn cầu**
Một loại thuốc kháng vi-rút dạng viên uống có hiệu quả sẽ là bước đi đáng kinh ngạc trong cuộc chiến chống lại COVID-19, nhưng vẫn chưa rõ liệu Molnupiravir có dễ dàng tiếp cận cho tất cả mọi người hay không. “Liệu chúng ta sẽ có được giá cả hợp lí cho các nước có thu nhập thấp và trung bình hay không?” ông Rachel Cohen nêu câu hỏi, ông là giám đốc điều hành phòng kế hoạch sản xuất thuốc cho các bệnh bị bỏ qua tại Bắc Mỹ.
Hoa Kỳ đã đồng ý mua 1,7 triệu liệu trình của Molnupiravir với giá 1,2 tỷ đô la Mỹ, tương đương khoảng 700 đô la cho mỗi liệu trình 5 ngày. Mức giá đó khá thấp hơn nhiều so với giá của Remdesivir hoặc các kháng thể đơn dòng, nhưng vẫn còn quá đắt đối với nhiều nơi trên thế giới. Công ty Merck, hiện đang đồng phát triển hợp chất thuốc với công ty Ridgeback, đã đạt được thỏa thuân cấp phép với năm nhà sản xuất thuốc gốc của Ấn độ. Những thỏa thuận này cho phép các nhà sản xuất tự định giá ở Ấn độ và ở 100 quốc gia có thu nhập trung bình và thấp khác.
Nhưng ngay cả khi các nước nghèo có thể mua được thuốc, họ có thể không có khả năng chuẩn đoán để sử dụng thuốc một cách hợp lý. Ông Cohen nói rằng : Nếu Molnupiravir cần được dùng trong năm ngày đầu tiên sau khi triệu chứng khởi phát, “điều đó đòi hỏi chúng tôi phải có khả năng chuẩn đoán người bệnh một cách nhanh chóng”. Đối với các nước đang phát triển – và thậm chí ở một số nước giàu có – “đó thật sự là 1 thách thức rất lớn”.
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh

## ️ Lupeol - Hoạt chất chống viêm

  * [Những nghiên cứu quan trọng khác trong lĩnh vực chống viêm của lupeol:](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/lupeol-hoat-chat-chong-viem#nhng-nghin-cu-quan-trng-khc-trong-lnh-vc-chng-vim-ca-lupeol)
  * [Lupeol và ung thư](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/lupeol-hoat-chat-chong-viem#lupeol-v-ung-th)
  * [Lupeol có độc tính gì không?](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/lupeol-hoat-chat-chong-viem#lupeol-c-c-tnh-g-khng)


Lupeol là một triterpenoids tự nhiên, được tìm thấy trong các loại rau quả như bắp cải trắng, hạt tiêu, dưa chuột, nha đam, cà chua, ô liu, vải, xoài, dâu tây, nho đỏ, ổi… Không chỉ vậy, một số loại thảo dược hay dùng trong điều trị cũng chứa hàm lượng đáng kể như nhân sâm Châu Á, cây chà là, cam thảo, cây me, cây hoàn ngọc…
Cấu trúc hóa học của Lupeol được trình bày trong. Công thức hóa học của Lupeol là C 30 H 50 O và điểm nóng chảy của nó là 215 – 216 ° C.
### Lupeol và viêm
upeol đã được nghiên cứu rộng rãi về tác dụng ức chế của nó đối với tình trạng viêm trong ống nghiệm và trên mô hình động vật bị viêm.
Một nghiên cứu toàn diện được thực hiện bởi Fernández và cộng sự cho thấy, việc dùng lupeol tại chỗ làm giảm nồng độ myeloperoxidase (dấu hiệu đặc hiệu bạch cầu trung tính) do đó làm giảm thâm nhập tế bào vào các mô bị viêm ở chuột, giúp giảm viêm.
Fernández  _và_ cộng sự cũng đã chỉ ra rằng chiết xuất từ ​​cây Pimenta racemosa giàu  _l_ _upeol_ (được sử dụng rộng rãi bởi các bác sĩ ở vùng Caribbean để điều trị bệnh viêm nhiễm) cho thấy hoạt động chống viêm cao trong mô hình động vật. Nghiên cứu này cho thấy hành vi chống viêm của chiết xuất giàu lupeol tương tự như hoạt động của chất ức chế cyclooxygenase chọn lọc, Indomethacin.
Không dừng lại ở đó, Geetha và cộng sự _,_ lần đầu tiên báo cáo về công dụng của lupeol trong điều trị hoặc giảm viêm trong mô hình chuột bị viêm khớp. Tác dụng có lợi của lupeol trong điều trị viêm ở chuột bị viêm khớp được chứng minh là có liên quan đến khả năng điều chỉnh hệ thống miễn dịch và tạo ra các yếu tố gây viêm.
#### Những nghiên cứu quan trọng khác trong lĩnh vực chống viêm của lupeol:
Một phát triển lớn khác trong việc thiết lập tiềm năng chống viêm của lupeol là nghiên cứu gần đây của Vasconcelosvà cộng sự _,_ trong đó lupeol đã được thử nghiệm để điều trị viêm trong mô hình chuột của hen phế quản.
Bệnh hen suyễn là một bệnh viêm mạn tính của đường thở liên quan đến phản ứng miễn dịch Th2. Nghiên cứu này cho thấy hoạt chất lupeol làm giảm đáng kể nồng độ tế bào và bạch cầu ái toan trong dịch phế quản phế nang. Điều trị lupeol cũng cho thấy làm giảm sản xuất chất nhầy và viêm tổng thể trong phổi. Tác dụng chống viêm của lupeol được quan sát là tương đương với dexamethasone, một chất chống viêm nổi tiếng
[https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2764818/](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2764818/)
### Lupeol và ung thư
Một chương trình rộng đã được khởi xướng tại Trường Y và Y tế Công cộng, Đại học Wisconsin-Madison để nghiên cứu tác dụng có lợi của lupeol đối với các loại ung thư khác nhau như ung thư tuyến tiền liệt, da, tụy và vú. Các tác dụng thúc đẩy chống khối u của Lupeol đã được quan sát có liên quan đến khả năng ngăn chặn các con đường truyền tín hiệu quan trọng trong quá trình tạo khối u.
Không dừng ở đó, nghiên cứu trên còn được mở rộng nhằm điều tra tiềm năng hóa trị liệu của lupeol trong điều trị ung thư da ở người trên tiền lâm sàng. Kết quả cho thấy với liều tiêu diệt các tế bào u ác tính, ngăn ngừa di căn, lupeol không độc với các tế bào bình thường và có thể được sử dụng như một chất hóa học trong hóa trị liệu chống lại ung thư da.
Bên cạnh, các nghiên cứu trên, hàng loạt các nghiên cứu chứng minh tác dụng chống lại các tế bào ung thư gan, ung thư vú , ung thư tụy… cũng cho kết quả tương tự.
Hiện nay, tại Việt Nam các nhà khoa học cũng đã nghiên cứu và nuôi trồng được cây hoàn ngọc có chứa hàm lượng cao lupeol để ứng dụng vào phòng và hỗ trợ điều trị các bệnh lý về viêm khớp, tim mạch, ung thư, …
[https://www.scielo.br/j/bjps/a/QRr4cmTQN4F9frHNbwcGXYB/?lang=en](https://www.scielo.br/j/bjps/a/QRr4cmTQN4F9frHNbwcGXYB/?lang=en)
## **Lupeol có độc tính gì không?**
Lupeol đã được báo cáo là không có độc tính trong các nghiên cứu trên động vật. Lupeol dùng đường uống với liều 2 g / kg đã được báo cáo là không gây ra tác dụng phụ ở chuột và chuột, và sau 96 giờ quan sát, không có trường hợp tử vong nào được ghi nhận.
Một nghiên cứu gần đây của Sudhahar  _và cộng sự_ đã chỉ ra rằng những con chuột được cho ăn chế độ ăn bổ sung Lupeol (50 mg / kg / ngày) trong 15 ngày liên tiếp không tạo ra bất kỳ độc tính toàn thân nào.
Preetha  _và cộng sự,_ cho thấy rằng uống Lupeol (100 mg / kg) trong 7 ngày không gây tử vong hoặc bất kỳ độc tính toàn thân nào ở chuột
Kết hợp lại với nhau, những nghiên cứu này cung cấp bằng chứng thuyết phục rằng Lupeol là một tác nhân hóa học và hóa trị liệu không độc hại nhưng rất mạnh.
Với những tác dụng có lợi cho sức khỏe con người, ngày nay lupeol đang được ứng dụng nhiều trong ngành công nghiệp dược phẩm với mục đích điều trị.
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [Những nghiên cứu quan trọng khác trong lĩnh vực chống viêm của lupeol:](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/lupeol-hoat-chat-chong-viem#nhng-nghin-cu-quan-trng-khc-trong-lnh-vc-chng-vim-ca-lupeol)
  * [Lupeol và ung thư](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/lupeol-hoat-chat-chong-viem#lupeol-v-ung-th)
  * [Lupeol có độc tính gì không?](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/lupeol-hoat-chat-chong-viem#lupeol-c-c-tnh-g-khng)



## Thúc đẩy “An toàn trong sử dụng thuốc” cho người bệnh tại Bệnh viện Nguyễn Tri Phương

  * [An toàn của người bệnh và Sai sót thuốc](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/thuc-day-an-toan-trong-su-dung-thuoc-cho-nguoi-benh-tai-benh-vien-nguyen-tri-phuong#an-ton-ca-ngi-bnh-v-sai-st-thuc)
  * [Các hoạt động nâng cao “An toàn trong sử dụng thuốc”](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/thuc-day-an-toan-trong-su-dung-thuoc-cho-nguoi-benh-tai-benh-vien-nguyen-tri-phuong#cc-hot-ng-nng-cao-an-ton-trong-s-dng-thuc)


## An toàn của người bệnh và Sai sót thuốc
An toàn của người bệnh là mối quan tâm hàng đầu của hệ thống chăm sóc y tế trên toàn thế giới và tại Việt Nam. Chiến dịch toàn cầu “Ngày An toàn người bệnh thế giới” đã được phát động từ năm 2017. Chiến dịch kêu gọi các cơ quan đoàn thể chung tay ngăn chặn các sai sót, đặc biệt là các sai sót liên quan đến thuốc (gọi tắt là “Sai sót thuốc”) có thể ảnh hưởng đến sức khỏe của người bệnh. Những sai sót này có thể xuất hiện trong bất kỳ giai đoạn nào trong quá trình phân phối và sử dụng thuốc bởi nhân viên y tế, người bệnh. Sai sót thuốc có thể dẫn đến hậu quả bất lợi hoặc không trên người bệnh.
Những nghiên cứu thống kê trên thế giới cũng cho thấy, tỷ lệ sai sót trong quá trình sử dụng thuốc là không nhỏ. Một nghiên cứu gộp thực hiện ở các bệnh viện tại Hoa Kỳ, Úc, Anh và Đan Mạch trên > 25 000 người bệnh, kết quả cho thấy 3 – 17% người bệnh gặp phải các biến cố có hại do sử dụng thuốc (Adverse drug events - ADE); trong đó khoảng ½ ADE có thể phòng ngừa được và 20% ADE liên quan đến sử dụng thuốc. Trên trang thông tin của Tổ chức Y tế Thế giới (WHO) đã cung cấp Hồ sơ dữ kiện An toàn người bệnh nhân (2019), trong đó cứ 10 người bệnh đến bệnh viện thì có 1 người bệnh bị tổn hại khi chăm sóc ở bệnh viện; và việc xảy ra các biến cố bất lợi do chăm sóc y tế không an toàn là 1 trong 10 nguyên nhân hàng đầu gây tử vong hoặc tàn tật trên thế giới. 
## Các hoạt động nâng cao “An toàn trong sử dụng thuốc”
Nhận thấy tính cấp bách của vấn đề, “An toàn trong sử dụng thuốc” là một trong những nội dung trọng tâm của hoạt động “An toàn người bệnh” tại Bệnh viện Nguyễn Tri Phương. Trong đó, Tổ Dược lâm sàng – Khoa Dược đóng vai trò then chốt trong việc triển khai các hoạt động phối hợp với bác sĩ, điều dưỡng nhằm thúc đẩy “An toàn trong sử dụng thuốc”. Các nội dung triển khai cụ thể của Tổ Dược lâm sàng phối hợp với bác sĩ và điều dưỡng gồm:
Hoạt động |  Mục tiêu |  Một số kết quả  
---|---|---  
1. Hội chẩn và phê duyệt sử dụng thuốc kháng sinh  |  Tối ưu sử dụng kháng sinh hợp lý, an toàn, hiệu quả |  Hội chẩn và phê duyệt đa chuyên ngành các kháng sinh ưu tiên quản lý   
2. Đào tạo các chủ đề về An toàn trong sử dụng thuốc cho điều dưỡng |  Nâng cao kiến thức liên quan các sai sót trong sử dụng thuốc của điều dưỡng |  Các thuốc không được nghiền, bẻ Tượng kỵ thuốc  Sử dụng thuốc qua ống thông đường tiêu hoá  
3. Cảnh giác dược  |  Nâng cao ý thức, kiến thức về an toàn trng sử dụng thuốc cho nhân viên y tế Báo cáo, dự phòng và xử lý các phản ứng cho hại của thuốc (ADR) |  Đào tạo về chẩn đoán, xử lý và báo cáo ADR cho NVYT. Dược sĩ phối hợp cùng bác sĩ, điều dưỡng trong xử lý và báo cáo các ca bệnh gặp ADR.  
4. Thực hành hợp tác với bác sĩ trong điều trị và chăm sóc người bệnh  |  Nâng cao kiến thức về sử dụng thuốc cho bác sĩ Tăng cường thực hành hợp tác giữa bác sĩ – dược sĩ trong chăm sóc người bệnh  |  Mô hình hợp tác bác sĩ – dược sĩ trong giảm đau hậu phẫu sau phẫu thuật cột sống tại Khoa Ngoại thần kinh  Mô hình hợp tác bác sĩ – dược sĩ tại 3 khoa: Hồi sức tích cực – Chống độc, Ngoại thần kinh, Chấn thương chỉnh hình  
5. Tư vấn người bệnh ngoại trú |  Phát hiện, phòng ngừa và xử lý các sai sót thuóc Tăng kiến thức, tuân thủ điều trị và hiệu quả đièu trị cho người bệnh  |  Duyệt đơn ngoại trú Tư vấn người bệnh ngoại trú tại Phòng tư vấn thuốc bởi dược sĩ   
6. Nghiên cứu khoa học |  Đánh giá sử dụng thuóc để phát hiện vấn đề liên quan thuốc và đề xuất can thiệp để cải thiện  |  Nghiên cứu về chủ đề dùng thuốc qua ống thông tiêu hoá Nghiên cứu về tương tác thuốc  Nghiên cứu về sử dụng thuốc điều trị tăng huyết áp ngoại trú   
Dược sĩ trao đổi chuyên môn với các bác sĩ lâm sàng tại Khoa Chấn thương chỉnh hình
Dược sĩ đào tạo điều dưỡng toàn viện về chủ đề “Sử dụng thuốc qua ống thông đường tiêu hóa” 
An toàn của người bệnh là mục tiêu chung của tất cả các nhân viên y tế và của toàn ngành y tế. Thực hành hợp tác giữa dược sĩ – bác sĩ – điều dưỡng là rất quan trọng để triển khai hiệu quả các hoạt động nhằm tăng cường “An toàn trong sử dụng thuốc” cho người bệnh tại Bệnh viện Nguyễn Tri Phương. 
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [An toàn của người bệnh và Sai sót thuốc](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/thuc-day-an-toan-trong-su-dung-thuoc-cho-nguoi-benh-tai-benh-vien-nguyen-tri-phuong#an-ton-ca-ngi-bnh-v-sai-st-thuc)
  * [Các hoạt động nâng cao “An toàn trong sử dụng thuốc”](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/thuc-day-an-toan-trong-su-dung-thuoc-cho-nguoi-benh-tai-benh-vien-nguyen-tri-phuong#cc-hot-ng-nng-cao-an-ton-trong-s-dng-thuc)



## Tiếp tục tiếp nhận thực tập dược lâm sàng tại bệnh viện Nguyễn Tri Phương năm 2022

**I. ĐỐI TƯỢNG THAM GIA:**
1. Dược sĩ trong bệnh viện có nhu cầu.
2. Dược sĩ từ các bệnh viện khác có nhu cầu.
**II. THỜI GIAN, NỘI DUNG ĐÀO TẠO:**
**1. Giảng viên:**
Giảng viên chính: TS. DS. Võ Thị Hà – Giảng viên BM Dược lý – Dược lâm sàng, ĐH Y Khoa Phạm Ngọc Thạch; Phụ trách Tổ DLS, BV NTP.
Hỗ trợ: Các dược sĩ lâm sàng của Bệnh viện Nguyễn Tri Phương.
**2. Thời gian và hình thức chiêu sinh:**
Hình thức chiêu sinh: chiêu sinh liên tục.
Chiêu sinh tuần 1, 3 hàng tháng: chương trình Module 01
Chiêu sinh tuần 2, 4 hàng tháng: chương trình Module 02
Chiêu sinh tuần 1, 2, 3, 4 hàng tháng: chương trình Module 03
Thời gian thực hành mỗi module: trong giờ hành chính, từ thứ 2 đến thứ 6.
Chỉ tiêu tuyển sinh mỗi module: 
Module 1: Tối đa: 4 học viên/tuần
Module 2: Tối đa: 4 học viên/tuần
Module 3: Tối đa: 2 học viên/tuần 
**III. THỜI GIAN NHẬN HỒ SƠ:**
Thời gian bắt đầu thực hành: từ đầu mỗi tháng, dự kiến sẽ bắt đầu học từ tháng 10/2022
**IV. NỘI DUNG ĐÀO TẠO:**
**Nội dung** |  **Mục tiêu**  
---|---  
Module 1 (01 tuần từ thứ 2 đến thứ 6, giờ hành chính) –**TỔNG QUAN HOẠT ĐỘNG DƯỢC LÂM SÀNG** | 
  * Tìm hiểu các hoạt động dược lâm sàng tại bệnh viện
  * Tìm hiểu các hoạt động thông tin thuốc
  * Tìm hiểu các hoạt động quản lý phản ứng có hại của thuốc
  * Kiến tập hoạt động dược lâm sàng tại Phòng phát thuốc bảo hiểm y tế
  * Kiến tập hoạt động tư vấn thuốc cho bệnh nhân ngoại trú
  * Kiến tập hoạt động dược lâm sàng nội trú tại khoa lâm sàng 
  * Kiến tập hoạt động phân tích bệnh án nội trú

|  Sau khi tham gia thực tập Module 1, học viên có thể:
  * Mô tả được các hoạt động dược lâm sàng tại bệnh viện 
  * Mô tả được quy trình, kinh nghiệm và các nguồn tài liệu phục vụ cho hoạt động thông tin thuốc
  * Mô tả được quy trình và kinh nghiệm khi quản lý phản ứng có hại tại bệnh viện
  * Mô tả được các bước và kinh nghiệm khi dược sĩ duyệt đơn cho bệnh nhân ngoại trú
  * Mô tả được các bước và kinh nghiệm khi tư vấn cho bệnh nhân ngoại trú
  * Mô tả được quy trình và kinh nghiệm khiđi bệnh phòng và hội chẩn cùng bác sĩ. 
  * Mô tả được các bước và kinh nghiệm khi phân tích bệnh án nội trú

  
Module 2 (01 tuần từ thứ 2 đến thứ 6, giờ hành chính)**– QUẢN LÝ KHÁNG SINH** | 
  * Kinh nghiệm triển khai chương trình quản lý kháng sinh tại bệnh viện
  * Sử dụng kháng sinh vancomycin và colistin 
  * Một số ca lâm sàng hội chẩn liên quan nhiễm khuẩn một số gram âm, gram dương điển hình
  * Một số tình huống ADR điển hình liên quan kháng sinh 

|  Sau khi tham gia thực tập Module 2, học viên có thể:
  * Trình bày được các kinh nghiệm triển khai chương trình quản lý kháng sinh tại bệnh viện
  * Trình bày được kinh nghiệm hội chẩn liên quan sử dụng kháng sinh vancomycin và colistin 
  * Trình bày được kinh nghiệm hội chẩn liên quan điều trị nhiễm khuẩn một số gram âm, gram dương điển hình
  * Trình bày được kinh nghiệm xử lý một số tình huống ADR điển hình liên quan kháng sinh

  
Module 3 (01 tuần từ thứ 2 đến thứ 6, giờ hành chính)**– DƯỢC LÂM SÀNG NGOẠI TRÚ TRÊN NGƯỜI BỆNH THÔNG THƯỜNG VÀ NGƯỜI BỆNH TĂNG HUYẾT ÁP** | 
  * Quy trình và các biểu mẫu hoạt động của phân tích đơn và tư vấn người bệnh ngoại trú
  * Kỹ năng giao tiếp
  * Kỹ năng phỏng vấn tiền sử thuốc của bệnh nhân
  * Kỹ năng phân tích đơn thuốc
  * Kỹ năng tư vấn bệnh nhân thông thường
  * Kỹ năng tư vấn bệnh nhân tăng huyết áp 

|  Sau khi tham gia thực tập Module 3, học viên có thể:
  * Xây dựng được quy trình dược lâm sàng ngoại trú
  * Thực hiện được việc phân tích đơn thuốc ngoại trú
  * Thực hiện được việc tư vấn bệnh nhân ngoại trú

  
**Kinh phí: 1.000.000đ/tuần/học viên**
(Học viên tự túc chi phí ăn, ở. Chi phí chưa bao gồm tài liệu)
**Cách thức đăng ký:**
**Kết thúc khóa** có cấp chứng nhận thời gian tham gia 
Tải mẫu đơn đăng ký: [**TẠI ĐÂY**](https://drive.google.com/file/d/1-YdFbiXxXhdNBfrMdmtCp_xevV1q-6M8/view?usp=sharing)
**Thông tin hướng dẫn đăng ký và sắp xếp lịch học vui lòng liên hệ:**
  * CN Vũ Minh Tuấn: 0907.1010.25
  * CN Dương Trần Cát Uyên: 0969.011.426



## ️ Thuốc chống loạn thần

Bệnh tâm thần phân liệt là một trong những bệnh loạn thần nặng nhất và phổ biến. Các triệu chứng của tâm thần phân liệt hết sức đa dạng, chủ yếu là những triệu chứng phản ảnh một quá trình chia cắt giũa các thành phần khác nhau của hoạt động tâm thần. Các triệu chứng rối loạn lâm sàng được phân loại thành 2 dạng: - Thể triệu chứng dương tính: hoang tưởng, ảo giác và kích động. - Thể triệu chứng âm tính: cảm xúc thờ ơ, mất ham thích, trí tuệ giảm, tư duy và ngôn ngữ nghèo nàn, các triệu chứng thu mình và cách ly với xã hội. Cơ chế bệnh sinh của tâm thần phân liệt vẫn còn chưa rõ ràng, nhiều giả thuyết đã được đưa ra. Trong đó, thuyết tăng hoạt động hệ phản ứng dopamin được các nhà tâm thần học ủng hộ. Sử dụng thuốc chống loạn thần là liệu pháp thông dụng nhất và có hiệu lực nhất trong điều trị các trạng thái loạn thần cấp và trong việc chống lại khuynh hướng mạn tính hóa và tái phát của bệnh. Các thuốc chống loạn thần đã được sử dụng từ những năm 1950 để điều trị tâm thần phân liệt. Thuốc chống loạn thần có thể được chia làm 2 nhóm bao gồm các thuốc điển hình (thế hệ 1) và các thuốc không điển hình (thế hệ 2). So với thế hệ 2, các thuốc chống loạn thần điển hình có nguy cơ gây ra các rối loạn vận động ngoại tháp, đây cũng là điểm khác biệt chính giữa 2 thế hệ. Ngược lại, các thuốc thế hệ 2 có xu hướng gây rối loạn chuyển hóa như tăng cân, khởi phát tiểu đường, tăng cholestorol máu. Ngoài ra, mỗi thuốc còn có mức độ đối vận khác nhau trên các thụ thể khác nhau của dopamin, serotonin, histamin, muscarinic và adrenergic. Điều này dẫn đến các tác dụng phụ khác nhau của từng loại thuốc trong nhóm. Nhìn chung không có thuốc nào hiệu quả nhất, việc lựa chọn thuốc điều trị phải phụ thuộc vào bệnh cảnh, triệu chứng, mức độ đáp ứng của bệnh nhân và độc tính của thuốc. Bên cạnh điều trị tâm thần phân liệt, nhóm thuốc chống loạn thần còn được dùng trong điều trị tình trạch kích động, rối loạn lưỡng cực, và các tình trạng tâm thần khác. Một số ghi nhớ nhỏ liên quan đến các thuốc trong nhóm: - Sulpiride là thuốc an thần có tác dụng lưỡng cực. Ở liều thấp (200-600mg/ngày) có hiệu lực giải ức chế (trầm uất) và liều mạnh (800-1600mg/ngày) có hiệu lực điều trị rối loạn tâm thần cấp tính. Tác dụng phụ của sulpiride tương tự như các thuốc nhóm điển hình. - Các thuốc high potency (tạm dịch là hiệu lực cao) có nhiều nguy cơ tác dụng phụ ngoại tháp hơn nhóm low potency. Các thuốc low potency có nguy cơ gây hạ huyết áp tư thế và buồn ngủ nhiều hơn nhóm high potency. - Thioridazine là thuốc có nguy cơ tác dụng phụ ngoại tháp ít nhất trong các thuốc nhóm điển hình. - Trifluperazine, fluphenazine và haloperidol là những thuốc chống loạn thần có tính chất chẹn alpha, kháng cholinergic thấp nhất. Tuy nhiên, nguy cơ tác dụng phụ ngoại tháp cao đáng kể. - Clozapine là thuốc chống loạn thần có nguy cơ tác dụng phụ ngoại tháp thấpnhất, tuy nhiên thuốc có tính an thần gây ngủ cao, tính kháng cholonergic mạnh, nguy cơ làm giảm bạch cầu hạt và ức chế tủy xương. Thuốc dùng để điều trị ở những bệnh nhân không đáp ứng với các thuốc khác. - Risperidone, haloperidone, paliperidone và fluphenazine là những thuốc có bào chế dạng tiêm tác động kéo dài. - Ziprasidone không gây tăng cân, đái tháo đường hay rối loạn lipid máu. Tuy nhiên, thuốc có nguy cơ kéo dài khoảng QT và gây loạn nhịp tim. - Aripiprazole là thuốc có tính chủ vận một phần tại thụ thể 5-HT1A và D2 và đối vận tại thụ thể 5-HT2A. Bên cạnh những chỉ định chính, thuốc được chỉ định để điều trị rối loạn tự kỷ ở trẻ em 6-17 tuổi. - Olanzapine có liên quan đến việc gia tăng nguy cơ đột quỵ và tử vong ở người già
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh

## Sarilumab (Kevzara) được chấp nhận để điều trị bệnh đau đa cơ do thấp khớp

Gần đây, cơ quan Quản lý Thực phẩm và Dược Phẩm Hoa Kỳ (FDA) đã phê duyệt Sarilumab (Kevzara) để điều trị bệnh đau đa cơ do thấp khớp (PMR: polymyalgia rheumatica) ở người trưởng thành có đáp ứng không đầy đủ với corticosteroid (Corticoid) hoặc không thể dung nạp corticosteroid ở liều giảm dần, hai nhà đồng phát triển Sanofi và Regeneron cùng công bố. Thuốc này là phương pháp điều trị **sinh học đầu tiên và duy nhất** được FDA chấp thuận cho bệnh viêm thấp khớp này.
Trước đây, FDA đã phê duyệt Sarilumab, một chất đối kháng thụ thể interleukin-6 vào tháng 5 năm 2017 để điều trị bệnh viêm khớp dạng thấp từ trung bình đến nặng ở người lớn không đáp ứng tốt hoặc không dung nạp với thuốc chống thấp khớp làm thay đổi bệnh (DMARD) tương tự như Methotrexat.
#### Quá trình và kết quả nghiên cứu
Phê duyệt của FDA đối với chỉ định mới này dựa trên các kết quả của thử nghiệm SAPHYR giai đoạn 3, đa trung tâm trên bệnh nhân mắc viêm đa khớp dạng thấp (PMR) chủ động và kháng corticosteroid.
Trong nghiên cứu kiểm soát giả dược, mù đôi và ngẫu nhiên, 59 bệnh nhân được điều trị với 200mg Sarilumab cùng với giảm liều corticosteroid trong 14 tuần và 58 bệnh nhân được điều trị giả dược mỗi 2 tuần cùng với giảm liều corticosteroid trong 52 tuần.
Sau 1 năm, 28% bệnh nhân điều trị bằng Sarilumab đã có sự thuyên giảm ổn định, so với 10% ở nhóm giả dược (P = .0193). Medscape Medical News đã từng báo cáo về các kết quả thử nghiệm này vào tháng 11 khi chúng được trình bày trong Cuộc họp thường niên của Hội Thấp khớp học Hoa Kỳ (American College of Rheumatology) năm 2022.
Những biến cố bất lợi của thuốc trong nhóm sử dụng Sarilumab bao gồm: giảm bạch cầu trung tính (15%), giảm bạch cầu (7%), táo bón (7%), ngứa phát ban (5%), đau cơ (7%), mệt mỏi (5%), ngứa tại vị trí tiêm (5%). Hai bệnh nhân có giảm bạch cầu trung tính, tác dụng không mong muốn này đã được giải quyết sau khi ngừng điều trị Sarilumab.
Chủ tịch, giám đốc khoa học tại Regeneron, TS .BS. George D. Yancopolous cho biết trong một bài phát biểu: ”Đau đa cơ dạng thấp có thể là bệnh gây mất khả năng lao động do những cơn đau cấp tính ở các bộ phận trên cơ thể khiến người bệnh mệt mỏi và không có khả năng thực hiện các hoạt động thường ngày”.
Bên cạnh đó: “Corticoid là thuốc hàng đầu trong điều trị bệnh thấp khớp cho đến thời điểm hiện tại, nhưng nhiều bệnh nhân không đáp ứng hoàn toàn với corticoid hoặc không thể giảm dần liều corticoid. Điều này khiến bệnh nhân có nguy cơ gặp phải các biến chứng do sử dụng thuốc kéo dài”.
Với việc phê duyệt thuốc Kevzara cho đau đa cơ dạng thấp, bệnh nhân sẽ có được sự điều trị chấp thuận bởi FDA. Nhờ đó giảm nhẹ các triệu chứng gây mất khả năng hoạt động thường ngày và giảm sự phụ thuộc lâu dài vào corticoid.
_Một số thông tin tổng quan về bệnh đau đa khớp do thấp khớp:_
  * _Độ tuổi trung bình khi các triệu chứng bắt đầu là 70. Phụ nữ bị ảnh hưởng thường xuyên hơn nam giới. Nó thường xảy ra ở người da trắng hơn nhưng tất cả các chủng tộc đều có thể bị PMR._
  * _Các triệu chứng đau đa cơ do thấp khớp điển hình của PMR là đau và cứng ở cánh tay trên, cổ, lưng dưới và đùi._
  * _Các triệu chứng này phát triển nhanh chóng và tồi tệ hơn vào buổi sáng._
  * _Các triệu chứng đau đa cơ do thấp khớp đáp ứng kịp thời với liều thấp corticosteroid, nhưng có thể tái phát khi giảm liều._


<https://www.medscape.com/viewarticle/988936>
<https://stlrheum.com/polymyalgia-rheumatica/>

## ️ Dược lâm sàng và các hoạt động của Dược sĩ lâm sàng là gì?

**I. ĐỊNH NGHĨA**
Dược lâm sàng là thuật ngữ thông dụng trong y văn và thực hành dược. Đó là một chuyên khoa y tế mô tả các hoạt động và dịch vụ của dược sĩ lâm sàng để phát triển và thúc đẩy việc sử dụng hợp lý và đúng đắn các thuốc và vật dụng y tế.
- Dược lâm sàng bao gồm tất cả các dịch vụ mà người dược sĩ lâm sàng thực hành tại bệnh viện, các nhà thuốc cộng đồng, các nhà an dưỡng, các dịch vụ chăm sóc tại nhà, các dưỡng đường và các đơn vị khác, nơi có thuốc được kê đơn và sử dụng. - Thuật ngữ “Dược Lâm sàng” không chỉ nhằm nói đến hoạt động của dược sĩ ở bệnh viện. Một dược sĩ cộng đồng có thể thực hiện các hoạt động dược lâm sàng giống như dược sĩ bệnh viện. - “Dược Lâm Sàng” khác với “Dược” như thế nào ? • Môn học “ Dược” nhấn mạnh trên kiến thức về tổng hợp, hóa học và bào chế thuốc. • Còn “Dược lâm sàng” nghiêng nhiều hơn về việc phân tích các nhu cầu của đông đảo người dùng mong muốn đối với thuốc, các cách dùng thuốc và tác động của thuốc trên bệnh nhân. Như vậy Dược Lâm sàng có sự dịch chuyển trọng tâm từ thuốc sang đối tượng dùng thuốc.
**II. MỤC TIÊU CHUNG** Mục tiêu chung của các hoạt động Dược lâm Sàng là thúc đẩy việc dùng thuốc và vật dụng y tế đúng và hợp lý nhằm
- Phát huy tối đã hiệu quả của thuốc, ví dụ dùng thuốc điều trị hiệu quả nhất cho từng đối tượng bệnh nhân.
- Giảm tối thiểu nguy cơ các tác dụng bất lợi trong điều trị, ví dụ giám sát liệu trình điều trị và sự tuân thủ của bệnh nhân với phác đồ điều trị.
- Giảm tối thiểu các chi phí của điều trị thuốc cho hệ thống y tế quốc gia và cho bệnh nhân, ví dụ đưa ra các điều trị thay thế tốt nhất cho số lượng lớn nhất bệnh nhân.
**III. MỨC ĐỘ TÁC ĐỘNG CỦA DƯỢC SĨ LÂM SÀNG**
Các hoạt động dược lâm sàng có thế tác động đến việc dùng thuốc đúng ở 3 mức độ khác nhau trước, trong và sau khi kê đơn.
**1. Trước khi kê đơn**
• Các thử nghiệm lâm sàng • Danh mục thuốc • Thông tin thuốc
- Dược sĩ lâm sàng có quyền tham gia và tác động đến các chính sách liên quan đến thuốc, nghĩa là ra quyết định thuốc nào xứng đáng được lưu hành trên thị trường, thuốc nào nên được đưa vào trong danh mục thuốc quốc gia và địa phương, chính sách kê đơn nào và hướng dẫn điều trị nào nên được thực thi.
- Dược sĩ lâm sàng cũng liên quan đến các hoạt động của thử nghiệm lâm sàng ở các mức độ khác nhau như tham gia vào hội đồng đạo đức; vào giám sát thử nghiệm; vào sự phân phối và chuẩn bị các thuốc thử nghiệm.
**2. Trong khi kê đơn**
• Hoạt động tư vấn - Dược sĩ lâm sàng có thể tác động đến quan điểm và quyền ưu tiên của người kê đơn trong việc lựa chọn thuốc đúng. - Dược sĩ lâm sàng giám sát, phát hiện và ngăn chặn tương tác thuốc, các phản ứng bất lợi và sai sót về thuốc bằng cách đánh giá các khía cạnh của đơn thuốc (giải thích thêm của người dịch: như chỉ định-lựa chọn thuốc, liều lượng thuốc, tương tác thuốc, cách dùng thuốc…) - Dược sĩ lâm sàng lưu ý đến liều lượng các thuốc có phạm vi điều trị hẹp cần phải giám sát điều trị. - Dược sĩ cộng đồng cũng có thể ra quyết định kê đơn trực tiếp, khi tư vấn với các thuốc OTC (thuốc không cần kê đơn).
**3. Sau khi kê đơn**
• Tư vấn • Chuẩn bị danh sách thuốc cho từng bệnh nhân • Đánh giá sử dụng thuốc • Nghiên cứu kết quả • Nghiên cứu dược kinh tế
- Sau khi đơn thuốc được kê, dược sĩ lâm sàng đóng vai trò chính trong giao tiếp và tư vấn bệnh nhân. - Dược sĩ có thể cải thiện sự nhận thức của bệnh nhân về các điều trị dành cho họ, giám sát đáp ứng điều trị, kiểm tra và cải thiện sự tuân thủ của bệnh nhân với các thuốc kê đơn. - Là thành viên của một nhóm đa chuyên khoa, dược sĩ lâm sàng cũng cung cấp sự chăm sóc thống nhất giữa “bệnh viện đến cộng đồng” và ngược lại, bảo đảm tính liên tục về nguy cơ và lợi ích của việc điều trị bằng thuốc.
**IV. CÁC HOẠT ĐỘNG CỦA DƯỢC SĨ LÂM SÀNG**
Các hoạt động chính của người dược sĩ lâm sàng bao gồm : - **Tư vấn:** Phân tích cách điều trị, tư vấn cho bác sĩ về tính đúng đắn của việc điều trị bằng thuốc và cung cấp sự chăm sóc dược cho bệnh nhân ở cả hai nơi bệnh viện và cộng đồng. - **Lựa chọn thuốc:** Xác định “Danh mục thuốc” hoặc “Danh sách giới hạn thuốc” bằng cách phối hợp với các bác sĩ bệnh viện, các bác sĩ đa khoa và những người ra quyết định. - **Thông tin thuốc:** Tìm kiếm thông tin và đánh giá nghiêm túc các y văn khoa học; tổ chức các dịch vụ thông tin thuốc cho cả hai đối tượng thầy thuốc và bệnh nhân. - **Lên danh sách và chuẩn bị thuốc:** Lên danh sách và chuẩn bị các thuốc và vật dụng y tế phù hợp với các tiêu chuẩn chấp nhận được để đáp ứng với các nhu cầu đặc biệt của từng bệnh nhân. - **Nghiên cứu sử dụng thuốc:** Các nghiên cứu sử dụng thuốc/nghiên cứu dược dịch tễ học/nghiên cứu kết quả/dược cảnh giác và vật tư y tế cảnh giác : thu thập dữ liệu về điều trị thuốc, giá thành thuốc và kết quả trên bệnh nhân bằng các phương pháp khoa học và được thiết kế tốt. - **Dược động học/ giám sát thuốc điều trị:** Nghiên cứu động học của thuốc và tối ưu hóa liều lượng. - **Thử nghiệm lâm sàng:** Lên kế hoạch, đánh giá và tham gia vào các thử nghiệm lâm sàng. - **Dược kinh tế học:** Dùng các kết quả của thử nghiệm lâm sàng và các nghiên cứu kết quả điều trị trên bệnh nhân để xác định các đánh giá tỷ lệ giá thành-hiệu quả. - **Phân phối và thực hiện thuốc:** Phân phối và thực hiện thuốc và vật dụng y tế : nghiên cứu và triển khai các hệ thống phân phối và thực hiện thuốc và vật dụng y tế sao cho có thể bảo đảm tính an toàn cao hơn khi thực hiện, giảm những tổn thất và giảm nguy cơ sai sót thuốc. - **Giảng dạy và tập huấn:** Giảng dạy trước khi tốt nghiệp và sau khi tốt nghiệp cho các dược sĩ và các nhân viên y tế khác, đồng thời thực hiện các hoạt động để đưa ra các chương trình tập huấn và giáo dục cho các đối tượng trên.
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh

## Chứng chỉ hành nghề dược là gì? Thủ tục xin cấp ra sao

  * **Chứng chỉ hành nghề là gì ?**


Chứng chỉ hành nghề là một trong những giấy tờ được cấp khi cá nhân có đầy đủ trình độ chuyên môn cũng như kinh nghiệm nghề nghiệp nào đó, cơ quan cấp là cơ quan nhà nước có thẩm quyền hoặc hội nghề nghiệp của ngành nghề đó.
  * **Chứng chỉ hành nghề dược là gì?**


Chứng chỉ hành nghề dược là **văn bản cấp cho cá nhân có trình độ chuyên môn liên quan đến ngành dược** , đáp ứng đầy đủ những điều kiện nhất định theo quy định pháp luật, thẩm quyền cấp văn bản này do cơ quan quản lý nhà nước có thẩm quyền.
Trong ngành nghề Dược, bao gồm:
- Người chịu trách nhiệm chuyên môn về dược của cơ sở kinh doanh dược.
- Người phụ trách về bảo đảm chất lượng của cơ sở sản xuất thuốc, nguyên liệu làm thuốc.
- Người phụ trách công tác dược lâm sàng của cơ sở khám bệnh, chữa bệnh.
  * **Điều kiện cấp chứng chỉ hành nghề dược**


Căn cứ theo điều 13, luật số 105/2016/QH13 Luật dược 2016 có quy định rõ các giấy tờ cần có và điều kiện sau đây:
- Có văn bằng, chứng chỉ, giấy chứng nhận chuyên môn đã được cấp, công nhận ở Việt Nam nhưng phải phù hợp với công việc, cơ sở kinh doanh dược.
- Có thời gian thực hành ở các cơ sở kinh doanh dược, cơ sở khám, chữa bệnh, các trường đào tạo của ngành dược đại hoặc nghiên cứu dược, kiểm nghiệm thuốc hay nguyên liệu làm thuốc, cơ quan quản lý dược.
- Giấy khám sức khoẻ do các cơ sở y tế có thẩm quyền cấp
Có văn bằng, chứng chỉ, giấy chứng nhận chuyên môn (văn bằng chuyên môn) được cấp hoặc công nhận tại Việt Nam phù hợp với vị trí công việc và cơ sở kinh doanh dược bao gồm:
- Bằng tốt nghiệp đại học ngành dược (Bằng dược sỹ);
- Bằng tốt nghiệp đại học ngành y đa khoa;
- Bằng tốt nghiệp đại học ngành y học cổ truyền hoặc đại học ngành dược cổ truyền;
- Bằng tốt nghiệp đại học ngành sinh học;
- Bằng tốt nghiệp đại học ngành hóa học;
- Bằng tốt nghiệp cao đẳng ngành dược;
- Bằng tốt nghiệp trung cấp ngành dược;
- Bằng tốt nghiệp cao đẳng, trung cấp ngành y;
- Bằng tốt nghiệp trung cấp y học cổ truyền hoặc dược cổ truyền;
- Văn bằng, chứng chỉ sơ cấp dược;
- Giấy chứng nhận về lương y, giấy chứng nhận về lương dược, giấy chứng nhận bài thuốc gia truyền hoặc văn bằng, chứng chỉ, giấy chứng nhận khác về y dược cổ truyền được cấp trước ngày 01/01/2017.
  * **Các hồ sơ cần làm để xin cấp chứng chỉ hành nghề**


- Đơn đề nghị cấp CCHN theo mẫu số 2, phụ luc I kèm theo nghị định 54/2017/NĐ-CP
- Ảnh chân dung 4x6 ( không quá 6 tháng)
- GIấy khám sức khoẻ theo thông tư 14-BYT
- Photo công chứng bằng tốt nghiêp, CCCD, SHK
- Phiếu lý lịch tư pháp( làm ở sở tư pháp nơi bạn ở, hoặc trung tâm hành chính công)
- GIấy xác nhận thâm niên tại cơ sở thực hành
  * **__Nộp tại Sở y tế__**


_Nếu hồ sơ đủ điều kiện thì 30 ngày kể từ ngày nhận được hồ sơ, yêu cầu cấp CCHN sẽ được giải quyết_

## ️ Phân biệt thuốc brand name và thuốc generic?

  * [Thuốc generic và brand name có chất lượng giống nhau?](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/phan-biet-thuoc-brand-name-va-thuoc-generic#thuc-generic-v-brand-name-c-cht-lng-ging-nhau)
  * [Thuốc generic và brand name: Khác nhau ra sao?](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/phan-biet-thuoc-brand-name-va-thuoc-generic#thuc-generic-v-brand-name-khc-nhau-ra-sao)


**Thuốc brand name (biệt dược)**
✅ Khi một thuốc mới được phát triển, nhà sản xuất sẽ đặt cho loại thuốc đó một cái tên nhằm chỉ ra hoạt chất của thuốc. Tên này được gọi là tên chung hoặc tên hoạt chất. Tổ chức y tế thế giới thường đặt cho thuốc tên chung xem như là tiêu chuẩn được sử dụng trên toàn thế giới.
✅ Ngoài tên chung, thuốc mới cũng được công ty sản xuất đặt một tên biệt dược hay tên độc quyền nhằm mục đích tiếp thị. Tên biệt dược thì thường dễ nói và dễ nhớ hơn tên hoạt chất. Tên của thuốc này sẽ có chữ ® kèm theo, ví dụ Lipitor®, để chứng tỏ thuốc đã đăng ký và được bảo vệ.
**Thuốc generic**
✅ Thuốc Generic là bản sao của thuốc biệt dược với thành phần hoạt chất tương tự nhau. Do đó, thuốc biệt dược và thuốc Generic có tên hoạt chất và hiệu quả điều trị tương tự.
✅ Để có được sự chấp thuận cho đăng ký và bán một loại thuốc, công ty sản xuất cần phải chứng minh rằng thuốc generic có tác dụng tương tự và đáp ứng các tiêu chuẩn cao tương đương thuốc biệt dược. Do đó, quá trình phê duyệt thuốc Generic diễn ra rất nghiêm ngặt.Thuốc brand name (biệt dược)
✅ Khi một thuốc mới được phát triển, nhà sản xuất sẽ đặt cho loại thuốc đó một cái tên nhằm chỉ ra hoạt chất của thuốc. Tên này được gọi là tên chung hoặc tên hoạt chất. Tổ chức y tế thế giới thường đặt cho thuốc tên chung xem như là tiêu chuẩn được sử dụng trên toàn thế giới.
✅ Ngoài tên chung, thuốc mới cũng được công ty sản xuất đặt một tên biệt dược hay tên độc quyền nhằm mục đích tiếp thị. Tên biệt dược thì thường dễ nói và dễ nhớ hơn tên hoạt chất. Tên của thuốc này sẽ có chữ ® kèm theo, ví dụ Lipitor®, để chứng tỏ thuốc đã đăng ký và được bảo vệ.
## **Thuốc generic và brand name có chất lượng giống nhau?**
Các thuốc generic được sản xuất giống với thuốc biệt dược gốc về cả dạng bào chế, tính an toàn, độ mạnh, đường dùng, chất lượng, cơ chế hoạt động và cả mục đích sử dụng. Những yếu tố này đều phải được chứng minh tương đương sinh học. Điều đó có nghĩa là thuốc generic phải hoạt động theo cùng một cách và mang lại lợi ích lâm sàng giống như biệt dược gốc của nó. Do đó, bạn hoàn toàn có thể sử dụng các thuốc này để thay thế cho thuốc biệt dược gốc tương ứng.
Thuốc generic so với thuốc brand name có những đặc điểm như sau:
  * Có cùng thành phần với thuốc brand name
  * Chữa trị cùng một tình trạng bệnh
  * Có cùng nồng độ, công dụng và liều lượng
  * Mức độ hấp thụ thuốc vào máu là tương tự.


## **Thuốc generic và brand name: Khác nhau ra sao?**
Điểm khác biệt giữa thuốc generic và brand name là ở nhà sản xuất. Mặc dù thuốc được đưa ra thị trường đều phải đảm bảo tuân thủ các tiêu chuẩn về sản xuất và kiểm định, tuy nhiên biệt dược gốc thường được nghiên cứu và sản xuất bởi những công ty Dược lớn ở Châu Âu hay Mỹ và phải đảm bảo quy trình sản xuất được kiểm soát nghiêm ngặt trong khi thuốc generic thường được sản xuất bởi những công ty nhỏ hơn.
Khác biệt thứ hai là ở các thành phần không hoạt tính ở thuốc (tá dược). Bởi theo quy định, thuốc generic chỉ cần có cùng loại và liều lượng như nhau với brand name về thành phần hoạt tính, trong khi đó, những thành phần không hoạt tính không cần chịu sự kiểm soát nghiêm ngặt. Vì thế, giữa những loại thuốc có sự khác biệt về thành phần không hoạt tính dẫn đến sự khác nhau về hình dáng, màu sắc và mùi vị của thuốc.
Một điểm khác biệt nữa là những nghiên cứu tiền lâm sàng và lâm sàng để chứng minh hiệu quả và an toàn trên bệnh nhân được thực hiện trực tiếp trên thuốc brand name trong khi thuốc generic chỉ cần nghiên cứu chứng minh tương đương sinh học với thuốc brand name.
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [Thuốc generic và brand name có chất lượng giống nhau?](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/phan-biet-thuoc-brand-name-va-thuoc-generic#thuc-generic-v-brand-name-c-cht-lng-ging-nhau)
  * [Thuốc generic và brand name: Khác nhau ra sao?](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/phan-biet-thuoc-brand-name-va-thuoc-generic#thuc-generic-v-brand-name-khc-nhau-ra-sao)



## ️ Các biện pháp dự phòng lây nhiễm COVID-19 tại nhà thuốc

Thực trạng Covid-19 đang trở nên ngày càng nghiêm trọng khi xuất hiện nhiều ca nhiễm không rõ nguồn lây. Các bệnh nhân nhiễm Covid-19 ở cộng đồng với các triệu chứng đường hô hấp có thể tìm tới nhà thuốc để được tư vấn hoặc mua các thuốc giảm triệu chứng. Điều này cho thấy vai trò quan trọng của các nhà thuốc/quầy thuốc tư nhân trong việc sàng lọc, phát hiện sớm các trường hợp có khả năng nhiễm Covid-19 ở cộng đồng. Bên cạnh đó, việc tiếp xúc với nhiều bệnh nhân cũng tiềm ẩn những nguy cơ lây nhiễm cho chính nhân viên nhà thuốc và cộng đồng. Vì vậy, việc thực hiện các biện pháp dự phòng lây nhiễm cho nhà thuốc là vô cùng quan trọng.
**Thứ nhất, nhà thuốc thời Covid-19 cần được bố trí như thế nào?**
-Có vị trí để dung dịch sát khuẩn tay [4], [5], [6].
-Treo thông báo yêu cầu khách hàng [6]:
  * _Đeo khẩu trang._
  * _Sát trùng tay trước và sau khi vào nhà thuốc [5]._
  * _Đảm bảo giãn cách 2 mét với người xung quanh_  _[1], [2]._
  * _Xếp hàng theo các dấu trên sàn và di chuyển theo lối được chỉ dẫn._
  * _Dùng khăn giấy hoặc khuỷu tay khi ho hoặc hắt hơi [3]._


-Sử dụng các tấm chắn ngăn cách dược sĩ và khách hàng [4].
-Đánh dấu các vị trí đứng của khách hàng cách nhau từ 2 mét bằng sơn hoặc băng dính [4], [6].
-Phân làn lối di chuyển bằng dây hoặc tấm chắn [4].
-Cất bớt và sắp xếp lại các đồ đạc và vật dụng không cần thiết [2], [4], [6].
**Thứ hai, dược sĩ thời Covid-19 cần thực hiện những biện pháp cụ thể gì?**
-Hướng dẫn khách hàng tuân thủ các yêu cầu đã được thông báo trước khi vào nhà thuốc.
-Luôn đeo khẩu trang khi làm việc [6].
-Giữ khoảng cách tối thiểu 2 mét khi nói chuyện với khách hàng, không dùng tay không để nhận đơn hay giao thuốc, nên đeo găng tay hoặc sử dụng khay… [4], [6].
-Sát khuẩn tay bằng dung dịch sát khuẩn sau mỗi lần tiếp bệnh nhân [3], [6].
-Vệ sinh và khử trùng nhà thuốc thường xuyên:
  * _Lau khử trùng các bề mặt tiếp xúc thường xuyên (mặt quầy, tay nắm cửa, công tắc đèn…)_  _hoặc các thiết bị có nhiều người sử dụng (điện thoại, bút…)_  _ít nhất 2 lần/ngày và sau mỗi ca làm việc_  _[4], [5]._
  * _Lau khử trùng các vật dụng sau mỗi lần tiếp xúc với bệnh nhân (nhiệt kế, máy đo huyết áp…)__[6]._
  * _Sử dụng nhật kí vệ sinh để theo dõi công việc làm vệ sinh trong ngày_ _[4]._


-Các dụng cụ bảo hộ cá nhân (khẩu trang, găng tay…), khăn giấy và khăn lau sau khi đã sử dụng cần được bỏ vào trong túi rác buộc kín ít nhất 72 giờ trước khi vứt ra nơi quy định [2].
-Cảnh giác, phát hiện các trường hợp có nguy cơ nhiễm Covid-19 (có ít nhất một trong các triệu chứng  _sốt, ho, khó thở_ _, đau họng_) và yêu cầu bệnh nhân Khai báo y tế.
Cả nước đang chung tay cùng nhau thực hiện tất cả các biện pháp chống lại đại dịch Covid-19, đưa cuộc sống cách ly trở về nhịp sống bình thường. Các cán bộ nhân viên y tế nói chung và các dược sĩ nhà thuốc nói riêng đóng vai trò quan trọng trong việc sàng lọc, phát hiện sớm và ngăn ngừa lây nhiễm Covid-19 trong cộng đồng. Các dược sĩ cần nhận thức đúng vai trò của mình, nâng cao cảnh giác, thực hiện các biện pháp phù hợp để chống lại đại dịch Covid-19.
TÀI LIỆU THAM KHẢO
  1. Bộ Y tế (25/03/2020),  _Hướng dẫn chẩn đoán và điều trị viêm đường hô hấp cấp do SARS-CoV-2 (COVID-19)_ , link: <https://kcb.vn/wp-content/uploads/2020/03/qdb-2020-1344-1.pdf>
  2. NHS England (22/03/2020),  _Novel coronavirus (COVID-19) standard operating procedure – Community_  _Pharmacy_ , link: <https://www.england.nhs.uk/coronavirus/wp-content/uploads/sites/52/2020/03/Novel-coronavirus-COVID-19-standard-operating-procedure-Community-Pharmacy-v2-published-22-March-2020.pdf>
  3. BC Centre for Disease Control (28/03/2020),_COVID-19 Guidance for Community and Hospital Pharmacies_ , link: <http://www.bccdc.ca/Health-Professionals-Site/Documents/COVID-19_Guidance_Community_Hospital_Pharmacies.pdf>
  4. Canadian Pharmacists Association,  _Protecting the Front Line: COVID-19 Day-to-Day Questions_ , link: <https://www.pharmacists.ca/advocacy/covid-19-information-for-pharmacists/guidelines-for-protecting-the-front-line-covid-19-day-to-day-questions/>, ngày truy cập: 10/04/2020
  5. Pharmaceutical Society of Australia,  _Coronavirus disease (COVID-19) information for pharmacists_ , link: <https://www.psa.org.au/coronavirus/?fbclid=IwAR0hkcNnF5O5usdMbXxHWKVAd_kNl2k6jm7XItY0o2rHkIM7ZFc1EjdyjRo#1584494065585-01bdd4b9-0a16>, ngày truy cập: 10/04/2020
  6. FIP (26/03/2020),  _COVID-19: Guidelines for pharmacists and the pharmacy workforce_ , link: <https://www.fip.org/files/content/priority-areas/coronavirus/COVID-19-Guidelines-for-pharmacists-and-the-pharmacy-workforce.pdf>


**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh

## ️ Phân loại vắc xin thường dùng

  * [Vắc xin sống giảm độc lực (LAV)](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/phan-loai-vac-xin-thuong-dung#vc-xin-sng-gim-c-lc-lav)
  * [Phản ứng miễn dịch](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/phan-loai-vac-xin-thuong-dung#phn-ng-min-dch)
  * [Vắc xin kháng nguyên bất hoạt (kháng nguyên đã bị tiêu diệt)](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/phan-loai-vac-xin-thuong-dung#vc-xin-khng-nguyn-bt-hot-khng-nguyn-b-tiu-dit)
  * [Phản ứng miễn dịch](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/phan-loai-vac-xin-thuong-dung#phn-ng-min-dch)
  * [An toàn và ổn định](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/phan-loai-vac-xin-thuong-dung#an-ton-v-n-nh)
  * [Kháng nguyên tiểu đơn vị (subunit)](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/phan-loai-vac-xin-thuong-dung#khng-nguyn-tiu-n-v-subunit)
  * [Đáp ứng miễn dịch](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/phan-loai-vac-xin-thuong-dung#p-ng-min-dch)
  * [Tính an toàn và tính ổn định](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/phan-loai-vac-xin-thuong-dung#tnh-an-ton-v-tnh-n-nh)
  * [Điểm quan trọng](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/phan-loai-vac-xin-thuong-dung#im-quan-trng)
  * [Giải độc tố (độc tố bị bất hoạt)](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/phan-loai-vac-xin-thuong-dung#gii-c-t-c-t-b-bt-hot)
  * [Tính an toàn và tính ổn định](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/phan-loai-vac-xin-thuong-dung#tnh-an-ton-v-tnh-n-nh)


Vắc-xin là chế phẩm sinh học có tính kháng nguyên, có nguồn gốc từ vi sinh vật (có thể toàn thân hoặc một phần hoặc có cấu trúc tương tự) dùng để tạo miễn dịch đặc hiệu chủ động, nhằm tăng sức đề kháng của cơ thể đối với một số tác nhân gây bệnh cụ thể.
Có nhiều loại vắc xin, chúng được phân loại dựa vào dạng của kháng nguyên sử dụng khi tạo ra vắc xin. Thành phần cấu tạo của vắc xin quyết định đến việc chúng được dùng, được bảo quản như thế nào hay được phân phối ra sao. Các loại vắc xin đang được khuyên dùng trên toàn cầu đề cập trong bài này có thể chia làm bốn nhóm chính như bảng dưới đây.
**Vắc xin sống giảm độc lực (LAV)** 1. Lao (BCG) 2. Vắc xin bại liệt đường uống (OPV) 3. Sởi 4. Rotavirus 5. Sốt vàng  
---  
**Vắc xin kháng nguyên bất hoạt (kháng nguyên đã bị tiêu diệt)** 1. Ho gà toàn tế bào (wP) 2. Virus bại liệt bất hoạt (IPV)  
**Kháng nguyên đơn vị (subunit)** 1. Ho gà vô bào (aP) 2. Haemophilius influenzae type b (Hib) 3. Phế cầu (PCV-7, PCV-10, PCV-13) 4. Viêm gan B  
**Giải độc tố (độc tố bị bất hoạt)** 1. Giải độc tố uốn ván 2. Giải độc tố bạch hầu  
## **Vắc xin sống giảm độc lực (LAV)**
Có sẵn từ những năm 1950, vắc xin sống giảm độc lực (LAV) có nguồn gốc từ mầm bệnh gây bệnh (virus hoặc vi khuẩn) đã bị suy yếu trong điều kiện phòng thí nghiệm. Chúng sẽ phát triển trong một cá thể được tiêm chủng, nhưng vì chúng yếu, chúng sẽ không gây ra hoặc gây bệnh rất nhẹ
## **Phản ứng miễn dịch**
Đáp ứng miễn dịch đạt được từ vắc xin sống giảm độc lực hoàn toàn giống với khi mắc bệnh tự nhiên (vắc xin sống giảm độc lực là loại vắc xin tạo đáp ứng miễn dịch hiệu quả nhất). Tuy nhiên một số loại vắc xin cần phải sử dụng liều nhắc lại để củng cố đáp ứng miễn dịch.
Vắc xin sống giảm độc lực có thể xảy ra các phản ứng nghiêm trọng hoặc đe dọa tính mạng, bắt nguồn từ sự nhân lên không kiểm soát của tác nhân có trong vắc xin. Tuy nhiên điều này chỉ gặp khi người sử dụng vắc xin bị suy giảm miễn dịch.
Các vi sinh vật sống cung cấp sự kích thích kháng nguyên liên tục đến khi đủ thời gian để sản xuất tế bào bộ nhớ.
Trong trường hợp virus hoặc vi sinh vật nội bào thường miễn dịch qua trung gian tế bào, các mầm bệnh suy yếu có khả năng sao chép trong tế bào chủ.
## **Vắc xin kháng nguyên bất hoạt (kháng nguyên đã bị tiêu diệt)**
**_Vắc xin bất hoạt_** được chế tạo từ các vi sinh vật (virus, vi khuẩn, các loại khác) đã bị tiêu diệt thông qua các quá trình vật lý hoặc hóa học. Những sinh vật đã chết này không thể gây bệnh.
## **Phản ứng miễn dịch**
  * Vắc xin bất hoạt hoàn toàn có thể không phải lúc nào cũng tạo ra phản ứng miễn dịch và phản ứng có thể không tồn tại lâu.
  * Một số liều vắc xin bất hoạt hoàn toàn có thể được yêu cầu để tạo ra phản ứng miễn dịch đầy đủ.


## **An toàn và ổn định**
  * Vắc xin tế bào bất hoạt toàn tế bào không có nguy cơ gây ra bệnh mà chúng mang vì không chứa các thành phần sống.
  * Chúng được coi là ổn định hơn so với nhóm vắc xin LAV.


## **Kháng nguyên tiểu đơn vị (subunit)**
## **Đáp ứng miễn dịch**
  * Giống như vắc xin bất hoạt toàn tế bào, vắc xin tiểu đơn vị không chứa các thành phần sống của mầm bệnh. Chúng khác so với vắc xin bất hoạt toàn tế bào ở chỗ chỉ chứa các phần kháng nguyên cần thiết của mầm bệnh để tạo ra đáp ứng miễn dịch bảo vệ cơ thể.
  * Độ chính xác này cần phải trả giá đắt, vì tính kháng nguyên của các tiểu đơn vị khác nhau của mầm bệnh phải được kiểm tra chi tiết để xác định sự kết hợp cụ thể nào sẽ tạo ra đáp ứng miễn dịch hiệu quả theo con đường chính xác.
  * Thường thì đáp ứng miễn dịch có thể được tạo ra, nhưng không đảm bảo chắc chắn rằng trí nhớ miễn dịch sẽ được hình thành theo đúng cách.


## **Tính an toàn và tính ổn định**
  * Giống vắc xin bất hoạt, vắc xin tiểu đơn vị không chứa thành phần sống nên được cho là rất an toàn.


## **Điểm quan trọng**
Thay vì đưa vắc xin toàn tế bào (bất hoạt hoặc giảm độc lực) vào hệ thống miễn dịch, vắc xin tiểu đơn vị chỉ chứa một phần của mầm bệnh và tạo ra đáp ứng miễn dịch thích hợp.
## **Giải độc tố (độc tố bị bất hoạt)**
Vắc xin giải độc tố được tạo ra dựa trên độc tố sản sinh bởi vi khuẩn cụ thể (ví dụ vắc xin uốn ván hoặc vắc xin bạch hầu).
Độc tố xâm nhập vào máu và là nguyên nhân chủ yếu gây ra các triệu chứng của bệnh. Độc tố có bản chất protein được cho là vô hại (giải độc tố) và được sử dụng làm kháng nguyên trong vắc xin để tạo miễn dịch. 
Để tăng đáp ứng miễn dịch, giải độc tố được hấp thụ vào muối nhôm hoặc canxi, các chất đóng này đóng vai trò như chất bổ trợ.
## **Tính an toàn và tính ổn định**
Vắc xin giải độc tố an toàn vì chúng không thể gây ra bệnh mà chúng phòng ngừa và không có khả năng đảo ngược độc lực. Các kháng nguyên của vắc xin không tích cực nhân lên và không lây lan sang các cá thể chưa được chủng ngừa. Chúng có tính ổn định, vì ít bị thay đổi bởi nhiệt độ, độ ẩm và ánh sáng.
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [Vắc xin sống giảm độc lực (LAV)](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/phan-loai-vac-xin-thuong-dung#vc-xin-sng-gim-c-lc-lav)
  * [Phản ứng miễn dịch](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/phan-loai-vac-xin-thuong-dung#phn-ng-min-dch)
  * [Vắc xin kháng nguyên bất hoạt (kháng nguyên đã bị tiêu diệt)](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/phan-loai-vac-xin-thuong-dung#vc-xin-khng-nguyn-bt-hot-khng-nguyn-b-tiu-dit)
  * [Phản ứng miễn dịch](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/phan-loai-vac-xin-thuong-dung#phn-ng-min-dch)
  * [An toàn và ổn định](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/phan-loai-vac-xin-thuong-dung#an-ton-v-n-nh)
  * [Kháng nguyên tiểu đơn vị (subunit)](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/phan-loai-vac-xin-thuong-dung#khng-nguyn-tiu-n-v-subunit)
  * [Đáp ứng miễn dịch](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/phan-loai-vac-xin-thuong-dung#p-ng-min-dch)
  * [Tính an toàn và tính ổn định](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/phan-loai-vac-xin-thuong-dung#tnh-an-ton-v-tnh-n-nh)
  * [Điểm quan trọng](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/phan-loai-vac-xin-thuong-dung#im-quan-trng)
  * [Giải độc tố (độc tố bị bất hoạt)](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/phan-loai-vac-xin-thuong-dung#gii-c-t-c-t-b-bt-hot)
  * [Tính an toàn và tính ổn định](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/phan-loai-vac-xin-thuong-dung#tnh-an-ton-v-tnh-n-nh)



## ️ Tổng quan cơ chế hoạt động của kháng sinh

**Thuốc kháng sinh** là thuốc dùng để chống nhiễm trùng do vi khuẩn. Thuốc kháng sinh còn được gọi là thuốc kháng khuẩn. Thuốc điều trị nhiễm trùng bằng cách tiêu diệt hoặc làm giảm sự phát triển của vi khuẩn.
Ngày nay, thuốc kháng sinh vẫn là loại thuốc quan trọng, cứu sống những người bị nhiễm trùng nghiêm trọng và ngăn chặn mức độ lây lan của vi khuẩn trong cơ thể. Có nhiều nhóm kháng sinh khác nhau, mỗi nhóm kháng sinh được sử dụng để điều trị cho các loại nhiễm khuẩn cụ thể khác nhau. Thuốc kháng sinh cũng có nhiều dạng, bao gồm dạng viên uống, chất lỏng, kem, thuốc mỡ.
**Kháng sinh** chống lại nhiễm trùng bằng cách tiêu diệt vi khuẩn hoặc làm chậm và tiêu diệt hoàn toàn vi khuẩn trong cơ thể, bằng cách:
  * Tấn công lớp cấu trúc bảo vệ vi khuẩn
  * Ngăn chặn khả năng sinh sản của vi khuẩn
  * Ngăn chặn sản xuất protein ở vi khuẩn


Thuốc kháng sinh bắt đầu hoạt động ngay sau khi bạn bắt đầu dùng thuốc. Tuy nhiên, bạn có thể vẫn không cảm nhận được sự thay đổi trong 2 - 3 ngày. Điều này phụ thuộc vào loại nhiễm trùng và loại kháng sinh bạn đang điều trị.
Hầu hết các loại **kháng sinh** nên được sử dụng điều trị trong 7 - 14 ngày. Trong một số trường hợp, phương pháp điều trị ngắn hơn cũng có tác dụng. Bác sĩ sẽ quyết định thời gian điều trị tốt nhất và loại kháng sinh chính xác cho bạn.
Sử dụng kháng sinh sẽ làm tình trạng bệnh của bạn tiến triển tốt trong vòng vài ngày, tuy nhiên bạn vẫn nên tuân thủ phác đồ điều trị vì có thể vi khuẩn trong cơ thể vẫn chưa được tiêu diệt hết. Việc tuân thủ thời gian điều trị sẽ giúp ngăn ngừa tình trạng **kháng kháng sinh**.
Tham khảo thêm tài liệu về cơ chế của kháng sinh 
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh

## ️ Các loại vắc xin COVID-19 được phê duyệt tại Việt Nam tính đến tháng 7/2021

Đến 18/7/2021, trong bối cảnh đại dịch Covid-19 đe dọa sức khỏe và tính mạng của hàng triệu người dân Việt Nam đã phê duyệt có điều kiện cho 6 loại vắc-xin COVID-19 bao gồm:
  * **Comirnaty** của Pfizer,
  * **A2D1222** của AstraZeneca
  * **Sputnik-V** của Gamalaya
  * **Vero-Cell** của Sinopharm
  * **Spikevax** (tên khác là: COVID-19 Vaccine Moderna) của ModernaTX
  * **Janssen** của Johnson & Johnson

**TÊN VACCIN** | **CƠ CHẾ TÁC DỤNG** | **SỐ LƯỢNG MŨI TIÊM** | **KHẢ NĂNG CHỐNG CÁC BIẾN THỂ VIRUS** | **TÁC DỤNG PHỤ** | **BẢO QUẢN**  
---|---|---|---|---|---  
**Comirnaty** | Sử dụng mRNA hướng dẫn các tế bào tạo ra protein của virus, kích hoạt hệ thống miễn dịch | 02 mũi, cách nhau 21 ngày | Hiệu quả chưa cao nhưng vẫn có hiệu quả bảo vệ cao đối với người đã tiêm | Sưng, đỏ, đau nhức vùng cánh tay tiêm; ngoài ra còn mệt mỏi, đau đầu, đau cơ, sốt, ớn lạnh, buồn nôn |  -80oC đến -600C  
**A2D1222** | Đưa adenovirus (virus gây ra cảm lạnh hoặc các triệu chứng giống như cúm) có chứa gen của coronavirus vào cơ thể, kích hoạt hệ thống miễn dịch | 02 mũi, cách nhau từ 4 đến 12 tuần | Chống được biến thể Anh (nhà sản xuất sẽ tiếp tục update) |  - Đau vùng tiêm, mệt mỏi, đau đầu, đau cơ, sốt và ớn lạnh. - Hiếm gặp hội chứng rò mao mạch gây giảm tiểu cầu, huyết khối | Tủ lạnh 2- 80C  
**Sputnik-V** | Đưa lần lượt 2 vector adenovirus khác nhau (rAd26 và rAd5) nhằm kích thích hệ thống miễn dịch sinh ra kháng thể | 02 mũi, cách nhau 21 ngày | Hiệu quả cao đối với chủng SARS-CoV-2 | Đau tại chỗ tiêm (58%), tăng thân nhiệt nhẹ (50%), nhức đầu (42%), suy nhược (28%), và đau cơ và khớp (24%) |  <-18oC  
**Vero-Cell** | Vaccine bất hoạt sử dụng các phần tử virus bất hoạt nhằm mục đích kích thích hệ thống miễn dịch sinh ra kháng thể | 02 mũi | Chưa có dữ liệu nhưng vẫn có hiệu quả bảo vệ cao đối với người đã tiêm | Đau, mẩn đỏ, sưng tấy ở vị trí tiêm; ngoài ra còn mệt mỏi, đau đầu, đau cơ, sốt, ớn lạnh, buồn nôn | Tủ lạnh 2- 80C  
**Spikevax** | Tương tự Pfizer | 02 mũi, cách nhau 28 ngày | Tương tự Pfizer |  - Sưng, đỏ, đau nhức vùng cánh tay tiêm; ngoài ra còn mệt mỏi, đau đầu, đau cơ, sốt, ớn lạnh, buồn nôn - “Cánh tay covid”: 1 tác dụng phụ vô hại | -250C đến -15oC  
**Janssen** | Đưa adenovirus (từ một loại virus khác đã được sửa đổi để chứa gen tạo ra protein của coronavirus, kích hoạt hệ thống miễn dịch | 01 mũi | Chưa có dữ liệu nhưng vẫn có hiệu quả bảo vệ cao đối với người đã tiêm |  - Đau tại chỗ tiêm, nhức đầu, mệt mỏi, đau cơ và buồn nôn >1/10 người. - Ho, đau khớp, sốt, ớn lạnh, mẩn đỏ và sưng tấy tại chỗ tiêm: <1/10 người - Quá mẫn (dị ứng) và phát ban ngứa: <1/1000 người - Huyết khối kèm giảm tiểu cầu: <1/10.000 người - Hiếm gặp hội chứng rò rỉ mao mạch | Từ 2-80C  
**MỘT SỐ LƯU Ý VỀ VIỆC DÙNG THUỐC TRƯỚC KHI TIÊM VACCINE**
  * Hầu hết các trường hợp, không khuyến cáo bệnh nhân dừng hoặc trì hoãn các thuốc đang sử dụng quanh thời điểm tiêm vắc-xin COVID-19. Tuy nhiên, nếu bạn đang dùng các thuốc ức chế miễn dịch (cụ thể như Prednisone hay Dexamethasone…) thì nên tham khảo ý kiến bác sĩ của bạn.
  * Việc bạn đang sử dụng thuốc điều trị tăng huyết áp, đái tháo đường hay hen suyễn đều không đáng lo ngại. Nhiều nghiên cứu đã được tiến hành trên nhóm bệnh nhân này và tin mừng cho bạn là họ đều đáp ứng tốt với vắc-xin.
  * Không khuyến cáo việc sử dụng các thuốc giảm đau như ibuprofen, aspirin, hoặc paracetamol trước khi tiêm vắc-xin để tránh các tác dụng phụ do không ai biết được các thuốc này sẽ có ảnh hưởng thế nào tới hiệu quả của vắc-xin. Tuy nhiên, nếu bạn thường xuyên phải sử dụng chúng trước đó vì một lý do khác thì vẫn nên tiếp tục sử dụng.
  * Không khuyến cáo sử dụng thuốc kháng dị ứng (thuốc kháng histamine) trước thời điểm tiêm vắc-xin để tránh các phản ứng dị ứng.


**NHỮNG ĐIỀU BẠN CẦN BIẾT TRƯỚC, TRONG KHI VÀ SAU KHI TIÊM VACCIN COVID-19**
**Trước khi tiêm:**
  * Chủ động tìm hiểu loại vaccin phòng COVID-19 được tiêm, thành phần và số mũi cần tiêm.
  * Chủ động thông báo cho bác sĩ về tình trạng sức khỏe của bản thân nếu có bất kỳ chống chỉ định nào.
  * Nghỉ ngơi, bổ sung nước và ăn uống đầy đủ trước khi tiêm chủng.


**Khi đi tiêm:**
  * Đeo khẩu trang thực hiện các biện pháp phòng chống dịch theo quy định.
  * Chủ động tìm hiểu và hỏi cán bộ y tế về **các tác dụng phụ** có thể xuất hiện sau khi tiêm và **cách xử lý** trong trường hợp khẩn cấp.
  * Bạn sẽ nhận được một giấy xác nhận cho biết bạn đã tiêm loại vắc xin COVID-19 nào, khi nào và ở đâu. Đảm bảo giữ thẻ này vì bạn sẽ cần nó trong tương lai.


**Sau khi tiêm:**
  * Ở lại điểm tiêm chủng 30 phút sau khi tiêm để được cán bộ y tế theo dõi, phát hiện sớm các phản ứng sau tiêm chủng.
  * Bạn có thể sẽ gặp một số dấu hiệu thông thường sau khi tiêm vaccin phòng COVID-19 như sau: **đau nhức cánh tay tại chỗ tiêm, sốt nhẹ, mệt mỏi, nhức đầu, đau nhức cơ hoặc khớp, ớn lạnh, tiêu chảy** … đây là các **phản ứng thông thường sau khi tiêm vaccin** cho biết cơ thể đang tạo ra miễn dịch phòng COVID-19.
  * Các phản ứng nghiêm trọng là hiếm gặp. Tuy nhiên nếu bất kỳ triệu chứng nào **tiếp tục kéo dài hơn một vài ngày** hoặc nếu **bạn gặp phản ứng nghiêm trọng hơn** , hãy **liên hệ ngay đến cơ sở y tế gần nhất** để được khám, chẩn đoán và xử lý kịp thời
  * Tiếp tục thực hiện các biện pháp an toàn để giữ an toàn cho sức khỏe bản thân và người khác.


**CƠ CHẾ HOẠT ĐỘNG CỦA VẮC XIN**
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh

## ️ Các loại Insulin thường gặp trong điều trị bệnh tiểu đường

  * [Dạng insulin nào là tốt nhất cho bệnh tiểu đường của tôi?](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/cac-loai-insulin-thuong-gap-trong-dieu-tri-benh-tieu-duong#dng-insulin-no-l-tt-nht-cho-bnh-tiu-ng-ca-ti)
  * [Thời gian dùng thuốc như thế nào?](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/cac-loai-insulin-thuong-gap-trong-dieu-tri-benh-tieu-duong#thi-giandng-thuc-nh-th-no)
  * [Những ngoại lệ trong sử dụng liều và thời gian insulin](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/cac-loai-insulin-thuong-gap-trong-dieu-tri-benh-tieu-duong#nhng-ngoi-l-trong-s-dng-liu-v-thi-gian-insulin)


**Các dạng insulin bao gồm:**
  * Tác dụng tức thời
  * Tác dụng ngắn
  * Tác dụng trung bình
  * Tác dụng kéo dài
  * Dạng hỗn hợp (pre-mix)


## Dạng insulin nào là tốt nhất cho bệnh tiểu đường của tôi?
Bác sĩ sẽ phối hợp với bạn để kê đơn loại insulin tốt nhất cho bạn và bệnh tiểu đường của bạn. Quyết định dựa vào nhiều yếu tố, gồm:
  * Cơ thể bạn đáp ứng với insulin như thế nào (sự hấp thu của cơ thể, thời gian kéo dài tác dụng có thể thay đổi tùy vào mỗi cá nhân).
  * Lựa chọn lối sống. Dạng thức ăn bạn ăn, lượng đồ uống có cồn bạn sử dụng, hoặc cường độ hoạt động thể lực sẽ ảnh hưởng đến sử dụng insulin của cơ thể bạn.
  * Sự sẵn sàng tiếp nhận mũi tiêm của bạn hằng ngày.
  * Sự thường xuyên kiểm tra đường máu.
  * Tuổi.
  * Mục tiêu trong việc kiểm soát đường máu của bạn.


Bảng dưới đây sẽ nêu lên chi tiết các dạng insulin tiêm. Về thời gian khởi đầu (onset- thời gian trước khi insulin vào máu và bắt đầu tác dụng hạ đường máu), đỉnh( peak- thời gian làm giảm đường máu tốt nhất) và thời gian hoạt động (duration-thời gian insulin tiếp tục tác dụng). Ba khoảng thời gian này có thể rất thay đổi. Cột cuối cùng đề nghị một vài cái nhìn tổng quát tạo ra bởi các dạng insulin khác nhau trong mối liên hệ với thời gian bữa ăn.
## **Thời gian dùng thuốc như thế nào?**
Theo như bảng trên mục thời gian khởi đầu nói về khoảng thời gian bao lâu insulin bắt đầu tác dụng. Bạn sẽ mong muốn rằng nó đồng thời với thời gian bắt đầu tiêu hóa thức ăn. Việc ăn đúng giờ sẽ hạn chế hạ đường máu.
  * Insulin tác dụng tức thời: khoảng 15 phút trước bữa ăn.
  * Insulin tác dụng ngắn: khoảng 30 đến 60 phút trước bữa ăn.
  * Insulin tác dụng trung bình: khoảng 1 tiếng trước bữa ăn.
  * Dạng hỗn hợp: phụ thuộc vào chế phẩm có thể thay đổi từ 10 phút đến 30-45 phút trước bữa ăn.


Trước khi dùng, cần đo nhiều lần và ghi mức độ đường trong máu để bác sĩ biết mà ra toa số lượng cần thiết.
Thường thì người bệnh cần tiêm ít nhất hai lần một ngày, có người cần đến ba bốn lần tiêm mới đủ để kiểm soát đường trong máu.
Ngày tiêm 2 lần với insulin có tác dụng ngắn hạn hoặc trung bình; trước điểm tâm và bữa cơm tối. Insulin ngắn hạn giúp kiểm soát đường vào buổi sáng và chiều tối. Insulin trung bình cho buổi chiều và qua đêm.
Ngày tiêm 3 lần với insulin ngắn hạn cho buổi sáng và trước cơm chiều, insulin trung bình cho ban đêm.
Ngày tiêm nhiều lần với insulin ngắn hạn trước bữa ăn chính và insulin trung bình trước khi đi ngủ.
Hiện nay, có máy bơm insulin (infusion pump) được sử dụng rất phổ biến. Bơm liên tục để đưa vào da một lượng insulin nhỏ đủ để duy trì đường huyết bình thường đồng thời có thể tự điều chỉnh để gia tăng insulin tùy theo nhu cầu, nhờ đó ta có thể ăn uống tự do hơn một chút.
Ngoài ra insulin dạng hít (inhalation) cũng đang được sử dụng và cũng khá công hiệu.
Dùng insulin nhiều thì đường huyết sẽ xuống quá thấp, người bệnh bị phản ứng insulin mà triệu chứng là: nhức đầu, tim đập nhanh, người run rẩy, mệt mỏi, mất định hướng, đổ mồ hôi, buồn nôn, đói bụng, đôi khi bất tỉnh, làm kinh, hôn mê.
Khi mới dùng insulin thì bác sĩ sẽ hướng dẫn bệnh nhân cách thay đổi liều lượng. Sau một thời gian, đã quen với tình trạng bệnh của mình thì bệnh nhân có thể tự tăng giảm thuốc. Thường thường thì gia tăng insulin ngắn hạn khi ăn nhiều hơn thường lệ và ít vận động; giảm insulin này khi ăn ít hơn và làm nhiều việc lao động chân tay.
**Bảo quản**
Nên bảo quản thuốc insulin chính xác theo những bước sau để đảm bảo thuốc có thể hoạt động:
Bảo quản insulin ở những nơi không có ánh sáng và nhiệt. Nếu không bảo quản insulin trong tủ lạnh thì hãy bảo quản nó ở mức độ lạnh vừa đủ (nhiệt độ từ 13,330C và 26,670C);
Không được để insulin đông lạnh. Nếu insulin bị đông thì không được dùng nó, kể cả khi nó được rã đông;
Cần bảo quản chai insulin không sử dụng, hộp đựng và bút tiêm insulin trong tủ lạnh ở nhiệt độ từ 2,220C đến 7,780C. Nếu bảo quản hợp lý, insulin sẽ có tác dụng tốt đến ngày hết hạn in trên chai.
Giữ hộp đựng và bút tiêm insulin đang sử dụng gần đây ở nhiệt độ mát (từ 13,330C và 26,670C).
## **Những ngoại lệ trong sử dụng liều và thời gian insulin**
Insulin tác dụng dài sử dụng không phụ thuộc vào thời gian. Bạn sẽ sử dụng detemir (Levemir) một đến hai lần mỗi ngày không phụ thuộc vào thời gian bạn ăn. Và bạn sẽ sử dụng glargine (Basaglar, Lantus, Toujeo) một lần hàng ngày vào thời gian cố định. Deglutec một lần một ngày nhưng thời gian có thể thay đổi. Một vài người sẽ sử dụng insulin tác dụng dài kèm với một insulin tác dụng ngắn hơn hoặc một loại thuốc khác được sử dụng với bữa ăn.
Insulin tác dụng tức thời có thể sử dụng ngay sau bữa ăn thay vì 15 phút trước bữa ăn. 
Để có thêm thông tin khi nào sử dụng insulin. Bạn nên tham khảo mục “**liều lượng và kiểm soát** ” phần bao bì sản phẩm bạn sử dụng hoặc nói chuyện với bác sĩ của bạn.
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [Dạng insulin nào là tốt nhất cho bệnh tiểu đường của tôi?](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/cac-loai-insulin-thuong-gap-trong-dieu-tri-benh-tieu-duong#dng-insulin-no-l-tt-nht-cho-bnh-tiu-ng-ca-ti)
  * [Thời gian dùng thuốc như thế nào?](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/cac-loai-insulin-thuong-gap-trong-dieu-tri-benh-tieu-duong#thi-giandng-thuc-nh-th-no)
  * [Những ngoại lệ trong sử dụng liều và thời gian insulin](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/cac-loai-insulin-thuong-gap-trong-dieu-tri-benh-tieu-duong#nhng-ngoi-l-trong-s-dng-liu-v-thi-gian-insulin)



## ️ Trào lưu mua “Tylenol” để điều trị Covid-19 tại nhà: Cần hiểu thêm về thuốc giảm đau, hạ sốt

**_Biên dịch: SVD. Nguyễn Huỳnh Thảo Vy 1, TS. Võ Thị Hà1,2_**
**_ĐH Y Khoa Phạm Ngọc Thạch, 2BV Nguyễn Tri Phương_**
**TYLENOL LÀ THUỐC GÌ?**
Tylenol là tên biệt dược của một loại thuốc có chứa hoạt chất chính là paracetamol (hay còn gọi là acetaminophen). Paracetamol là loại thuốc thông dụng nhất để **giảm đau** và **hạ sốt**.
## **BIỆT DƯỢC VÀ HOẠT CHẤT KHÁC NHAU THẾ NÀO?**
Nhiều hãng dược khác nhau có thể sản xuất nhiều sản phẩm khác nhau cùng chứa chung một hoạt chất thuốc. Mỗi sản phẩm đó hãng dược có thể chọn đặt tên riêng hoặc lấy tên hoạt chất làm tên gọi. Ví dụ: các sản phẩm Panadol, Paracetamol, Hapacol, Efferalgan đều là tên biệt dược của các sản phẩm có cùng chung hoạt chất paracetamol do các hãng dược khác nhau sản xuất. Nếu áp dụng cho lĩnh vực thực phẩm thì tên hoạt chất là “nước mắm” còn Chinsu và Kim Ngưu sẽ được gọi là tên biệt dược. 
Các biệt dược khi đưa ra thị trường đã phải trải qua các quá trình kiểm định để bảo đảm chứa cùng loại và hàm lượng hoạt chất thuốc tương tự nhau, tức phải đạt được tương đương về bào chế. Ngoài ra, các chế phẩm còn có thể đòi hỏi phải tiến hành các nghiện cứu đo nồng độ thuốc trong máu sau khi uống các sản phẩm khác nhau để bảo đảm là nồng độ thuốc hấp thu vào máu của các chế phẩm là tương tự nhau. Yêu cầu này được gọi là tương đương về dược động học. 
Do đó, trong nhiều trường hợp, có thể thay thế các biệt dược khác nhau với yêu cầu chứa cùng loại hoạt chất. 
**PARACETAMOL CÓ TÁC DỤNG GÌ?**
Vì Tylenol là biệt dược chứa paracetamol. Nên tác dụng điều trị của nó sẽ giống với các chế phẩm thuốc chứa cùng hoạt chất là paracetamol. 
Paracetamol có tác dụng **giảm đau, hạ sốt** tốt. Do đó, paracetamol được sử dụng để điều trị:
  * Các triệu chứng đau: như đau đầu, đau cơ, viêm khớp, đau lưng, đau răng, đau họng…
  * Hoặc các bệnh có cả triệu chứng đau và sốt như viêm họng, cảm lạnh, cúm, các triệu chứng của nhiễm virus bao gồm cả COVID-19…


**CÓ CÁC SẢN PHẨM NÀO CHỨA PARACETAMOL TRÊN THỊ TRƯỜNG?**
Viên 500mg, 1000mg
Hỗn dịch 80mg/2,5ml 
Gói cốm để pha hỗn dịch 80mg, 125 mg, 250mg, 325 mg
**LIỀU DÙNG CỦA PARACETAMOL LÀ BAO NHIÊU?**
  * **Người lớn** : Liều uống thường dùng là 0,5-1 g/lần, uống cách nhau ít nhất 4-6 giờ một lần; **tối đa là 4 g/ngày. **
  * Tuy nhiên, ở bệnh nhân nghiện rượu, bị bệnh gan, suy dinh dưỡng mạn, bị mất nước thì liều **tối đa là 3 g/ngày. **
  * Liều dùng đường uống đối với **trẻ em** được tính theo **cân nặng hoặc tuổi**. 


  * **Nếu tính liều theo cân nặng** thì liều tương ứng là **10-15mg/kg** cho mỗi lần dùng. Nhắc lại sau ít nhất 4 - 6 giờ nếu cần. Tối đa 75mg/kg/ngày. Ví dụ: trẻ nặng 10kg thì liều sẽ là 100-150mg mỗi lần. Tối đa là 750mg/ngày. 
  * **Nếu tính liều theo tuổi thì dựa vào bảng dưới**


**PARACETAMOL CÓ AN TOÀN KHÔNG?**
Nếu dùng liều phù hợp, paracetamol là một thuốc khá “hiền”, và khá an toàn. Paracetamol ít tác động đến hệ tim mạch và hô hấp, không gây kích ứng, loét hoặc chảy máu dạ dày, không gây rối loạn chất điện giải trong cơ thể bạn.
**LƯU Ý NHẤT KHI DÙNG PARACETAMOL LÀ GÌ?**
Tuy nhiên, nếu dùng **quá liều** paracetamol có thể dẫn đến **hoại tử gan,** thậm chí là **tử vong**. Trong thực tế, không phải thuốc nào uống quá liều cũng có thể gây tử vong. Nhưng riêng với paracetamol thì nếu uống **quá 8g/ngày thì nguy cơ tử vong** là khá cao. 
Hoại tử gan do dùng quá liều paracetamol, dù cố ý hay không cố ý, là **nguyên nhân phổ biến nhất** của **ổn thương gan do thuốc** ở nhiều nước. 
**CÁC NGUYÊN NHÂN NÀO THƯỜNG DẪN ĐẾN QUÁ LIỀU PARACETAMOL?**
Nguyên nhân cố ý là do bệnh nhân cố ý dùng quá liều paracetamol để **tự tử.**
Nguyên nhân khác khá phổ biến là do bệnh nhân **không hiểu rõ và uống nhiều biệt dược khác nhau cùng chứa hoạt chất paracetamol** , gây quá liều tối đa mỗi ngày. Ví dụ: một bệnh nhân uống **Panadol viên nén 500mg x 2 viên x 3 lần/ngày (3g/ngày**) phối hợp với **Efferalgan viên sủi 500mg x 1 viên x 3 lần/ngày (1,5g/ngày).** Như vậy, tổng liều bệnh nhân đã uống là **4,5g paracetamol/ngày**. Liều này đã vượt quá mức liều cho phép mỗi ngày là **4g/ngày**. Điều này đặc biệt nguy hiểm nếu bệnh nhân uống nhiều ngày liên tiếp. 
Các **yếu tố khác làm tăng nguy cơ quá liều** paracetamol gồm:
  * bệnh nhân uống rượu (vì rượu cũng gây độc cho gan và cạnh tranh với paracetamol để được gan thải độc), 
  * tuổi cao (vì chức năng thải độc của gan bị giảm)
  * suy dinh dưỡng
  * bị bệnh gan 
  * dùng kèm một số thuốc khác cũng gây độc trên gan hay cạnh tranh thải độc bởi gan


**CÁC DẤU HIỆU NÀO CHO THẤY BẠN BỊ NGỘ ĐỘC HAY QUÁ LIỀU PARACETAMOL ?**
Các dấu hiệu có thể gồm: 
  * Buồn nôn, đau bụng trên, ngứa, chán ăn.
  * Nước tiểu sẫm màu, phân màu đất sét.
  * Vàng da (vàng da hoặc mắt).


**Nếu bạn có bất kỳ các dấu hiệu trên hoặc nghi ngờ mình quá liều paracetamol, bạn nên gọi hay khám bác sĩ** ngay. Bác sĩ sẽ chỉ định đo nồng độ paracetamol trong máu để khẳng định và cho bạn uống thuốc giải độc đặc hiệu. 
**KẾT LUẬN**
  * Paracetamol là thuốc thông dụng để trị các triệu chứng đau, sốt. Thuốc rất hiệu quả làm giảm nhanh chóng triệu chứng, giúp hết đau, hết sốt. Tuy nhiên, đặc biệt lưu ý là dùng đúng liều và chỉ khi có triệu chứng đau, sốt. Hết sốt, hết đau thì dừng thuốc. Không dùng quá liều, đặc biệt trên các bệnh nhân uống rượu, bệnh gan, suy dinh dưỡng, mất nước…vì nguy cơ hoạt tử gan và có thể dẫn đến tử vong. 
  * Tylenol có tác dụng điều trị tương tự như bao biệt dược khác chứa cùng hoạt chất paracetamol. 


**TÀI LIỆU THAM KHẢO**
  1. Bộ Y tế. Dược thư quốc gia. 
  2. Laura Rotundo, and Nikolaos Pyrsopoulos (2020). Liver injury induced by paracetamol and challenges associated with intentional and unintentional use. 


Xem thêm: [**Những vấn đề cập nhật về thuốc điều trị Covid**](https://bvnguyentriphuong.com.vn/nghien-cuu-duoc-dang-tai-tren-tap-chi-quoc-te/nhung-van-de-cap-nhat-ve-thuoc-dieu-tri-covid)
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh

## ️ Vắc xin gồm những thành phần gì

  * [Một số vắc - xin được làm từ huyết thanh bào thai bò](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/vac-xin-gom-nhung-thanh-phan-gi#mt-s-vc-xin-c-lm-t-huyt-thanh-bo-thai-b)


Ngoài kháng nguyên, chất ổn định, tá dược, kháng sinh và chất bảo quản - vắc xin cũng có thể chứa các sản phẩm phụ còn lại từ quá trình sản xuất. Biết chính xác những gì có trong mỗi loại vắc xin có thể hữu ích khi điều tra các tác dụng phụ sau tiêm chủng (AEFIs) và lựa chọn các sản phẩm thay thế cho những người bị dị ứng hoặc có tác dụng phụ được gây ra hoặc nghi ngờ có liên quan đến thành phần vắc xin.
## **Kháng nguyên**
**Kháng nguyên** là thành phần có nguồn gốc từ cấu trúc của các sinh vật gây bệnh, được hệ thống miễn dịch công nhận là ‘ngoại lai’ và kích hoạt phản ứng miễn dịch bảo vệ khỏi vắc xin.
## **Chất ổn định**
**Chất ổn định** được sử dụng để giúp vắc xin duy trì hiệu quả trong quá trình bảo quản. Sự ổn định của vắc xin là rất cần thiết, đặc biệt khi bảo quản lạnh không đáng tin cậy. Sự không ổn định có thể gây mất tính kháng nguyên và giảm khả năng lây nhiễm của LAV. Các yếu tố ảnh hưởng đến sự ổn định là nhiệt độ và độ axit hoặc độ kiềm của vắc xin (pH Vắc xin vi khuẩn có thể trở nên không ổn định tùy thuộc quá trình thủy phân hay tổng hợp các phân tử protein và carbohydrate. Các chất ổn định bao gồm MgCl2 (đối với OPV), MgSO4 (đối với sởi), lactose-sorbitol và sorbitol-gelatine.
## **Chất bổ trợ**
**Chất bổ trợ** được thêm vào vắc xin để kích thích sản xuất kháng thể chống lại vắc xin, làm cho nó hiệu quả hơn.
Các chất bổ trợ đã được sử dụng trong nhiều thập kỷ để cải thiện phản ứng miễn dịch đối với các kháng nguyên vacine, thường gặp nhất là trong các vắc xin bất hoạt (bị giết). Trong các loại vắc xin thông thường, việc bổ sung tá dược vào công thức vắc xin là nhằm mục đích tăng cường, tăng tốc và kéo dài phản ứng miễn dịch đặc hiệu đối với các kháng nguyên vắc xin.
Các đơn vị vắc xin mới hoặc vắc xin tổng hợp được phát triển bằng cách sử dụng sinh tổng hợp, tái tổ hợp và công nghệ hiện đại khác là các kháng nguyên vắc xin kém và yêu cầu tá dược để kích thích đáp ứng miễn dịch mong muốn.Về mặt hóa học, tá dược là một nhóm hợp chất rất không đồng nhất chỉ có một điểm chung: khả năng tăng cường đáp ứng miễn dịch. Chúng rất khác nhau trong cách tác động đến hệ thống miễn dịch và mức độ nghiêm trọng của các phản ứng bất lợi của chúng, do sự tăng hoạt động của hệ thống miễn dịch.
Ngày nay có hàng trăm loại tá dược khác nhau đang được sử dụng hoặc nghiên cứu trong công nghệ vắc xin.
## **Kháng sinh**
**Thuốc kháng sinh**(với số lượng nhỏ) được sử dụng trong giai đoạn sản xuất để ngăn sự nhiễm khuẩn của các tế bào nuôi cấy mô nơi virus được phát triển. Thông thường chỉ có số lượng ít xuất hiện trong vắc xin, ví dụ, vắc xin MMR và IPV mỗi loại chứa dưới 25 microgam neomycin mỗi liều (dưới 0.000025 g). Những người có dị ứng với neomycin nên được theo dõi chặt chẽ sau khi tiêm vắc xin để bất kỳ phản ứng dị ứng nào xảy ra đều được điều trị ngay lập tức.
## **Chất bảo quản**
**Chất bảo quản** được thêm vào vắc xin đa liều để ngăn chặn sự phát triển của vi khuẩn và nấm. Chúng bao gồm nhiều loại chất, ví dụ như các dẫn xuất Thiomersal, Formaldehyd hoặc Phenol.
_Thiomersal_
  * Chất bảo quản rất dễ sử dụng. Thiomersal là một hợp chất chứa thủy ngân ethyl,
  * Nó đã được sử dụng từ những năm 1930 và không có tác dụng có hại nào được báo cáo đối với các liều sử dụng trong tiêm chủng ngoại trừ các phản ứng nhỏ (ví dụ như đỏ, sưng tại chỗ tiêm),
  * Nó được sử dụng trong các lọ đa liều và cảcác lọ đơn liều ở nhiều quốc gia vì nó giúp giảm yêu cầu /chi phí lưu trữ,
  * Thiomersal từng bị kiểm tra rất gắt gao, vì nó có chứa thủy ngân ethyl. Ủy ban tư vấn toàn cầu về an toàn vắc xin liên tục xem xét các khía cạnh an toàn của Thiomersal. Cho đến nay, không có bằng chứng về độc tính khi tiếp xúc với Thiomersal trong vắc xin. Ngay cả lượng nhỏ thiomersal dường như không có tác động đến sự phát triển thần kinh của trẻ sơ sinh.


_Formaldehyd_
  * Được sử dụng để làm bất hoạt virus (ví dụ: IPV) và để khử độc tố vi khuẩn, chẳng hạn như các độc tố được sử dụng để sản xuất vắc xin bạch hầu và uốn ván,
  * Trong quá trình sản xuất, một quy trình thanh lọc sẽ loại bỏ gần như toàn bộ formaldehyd trong vắc xin,
  * Lượng formaldehyd trong vắc xin thấp hơn hàng trăm lần so với lượng được biết là gây hại cho con người, ngay cả trẻ sơ sinh. Ví dụ, vắc xin DTP-HepB + Hib “5 trong 1” chứa ít hơn 0,02% formaldehyd mỗi liều, hoặc dưới 200 phần triệu.


## **Muối nhôm**
Muối nhôm được tích hợp vào một số công thức vắc - xin như một chất bổ trợ tác dụng. Chất bổ trợ tác dụng là chất được thêm vào **thành phần của vắc - xin** để tăng cường hiệu quả đáp ứng miễn dịch của những người được tiêm chủng. Các muối nhôm được cấp phép sử dụng trong một số vắc - xin là nhôm hydroxit, nhôm phốt-phát, phèn nhôm (kali nhôm sunfat) hoặc muối nhôm hỗn hợp. Ví dụ: muối nhôm được sử dụng trong vắc - xin DTaP, vắc - xin liên hợp phòng ngừa phế cầu khuẩn (PCV13) và **vắc - xin viêm gan B** (HepB).
Nhôm là**thành phần vắc - xin** đã được chứng mình về độ an toàn trong hơn sáu thập kỷ sử dụng và chỉ liên quan đến các phản ứng nghiêm trọng tại một số khu vực. Một nghiên cứu của Cục quản lý Thực phẩm và Dược phẩm Hoa Kỳ (FDA) kết luận rằng nguy cơ phơi nhiễm nhôm đối với trẻ sơ sinh từ tất cả các loại vắc - xin được khuyến nghị chủng ngừa cho trẻ trong năm đầu đời là rất thấp. Nghiên cứu này cung cấp thêm thông tin khoa học xác nhận rằng lợi ích của nhôm trong vắc - xin vượt xa mọi lo ngại về mặt lý thuyết về tác hại tiềm tàng của nhôm đối với trẻ sơ sinh. Hơn nữa, nguồn cung cấp nguyên tố nhôm phổ biến nhất là từ thực phẩm và nước uống.
## **Một số vắc - xin được làm từ huyết thanh bào thai bò**
Trong **bào chế vắc - xin virus** , nguồn virus thường được phát triển trong các tế bào. Những tế bào này cần một nguồn dinh dưỡng để duy trì sự sống. Nhiều trường hợp người ta có thể cung cấp dinh dưỡng cho tế bào bằng huyết thanh từ bào thai bò.
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [Một số vắc - xin được làm từ huyết thanh bào thai bò](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/vac-xin-gom-nhung-thanh-phan-gi#mt-s-vc-xin-c-lm-t-huyt-thanh-bo-thai-b)



## ️ Thông tin cần biết về vắc-xin phòng COVID-19 Hayat - Vax

Vắc-xin vaccine Hayat - Vax do Công ty TNHH Viện Sinh phẩm Bắc Kinh thuộc Tập đoàn Biotec Quốc gia Trung Quốc (CNBG), Trung Quốc, sản xuất bán thành phẩm. Vắc xin này được đóng gói sơ cấp, thứ cấp và xuất xưởng tại Julphar (Gulf Pharmaceutical Industries) - Các tiểu Vương quốc Ả rập thống nhất.
Vaccine Hayat - Vax mỗi liều 0,5 ml chứa 6.5 đơn vị kháng nguyên SARS-CoV-2 (tế bào vero) bất hoạt, bào chế ở dạng hỗn dịch tiêm. Vaccine được đóng gói hộp một lọ chứa một liều 0,5 ml và hộp một lọ chứa 2 liều, mỗi liều 0,5 ml.
Bộ Y tế đã có quyết định phê duyệt có điều kiện cho nhu cầu cấp bách trong phòng, chống dịch bệnh COVID-19 đối với vắc-xin này vào ngày 10/9/2021.
Vắc-xin Hayat-Vax có thể được sử dụng để tiêm mũi 2 cho người đã tiêm mũi 1 là vắc-xin Sinopharm.
Ngoài ra, những người có bệnh lý về máu như giảm tiểu cầu hoặc rối loạn đông máu nên thận trọng khi tiêm vắc xin Hayat-Vax. Người đang điều trị ức chế hệ thống miễn dịch hoặc mắc chứng suy giảm miễn dịch thì phản ứng miễn dịch với vắc xin có thể bị giảm, những người này nên trì hoãn tiêm chủng cho đến khi kết thúc đợt điều trị. Người bị chứng động kinh không kiểm soát và các rối loạn thần kinh tiến triển khác cũng cần thận trọng khi tiêm vắc xin Hayat-Vax.
Về tương tác của vắc xin này với vắc xin khác, hiện chưa có kết quả thử nghiệm lâm sàng vắc xin Hayat-Vax tiêm cùng với các vắc xin khác.
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh

## ️ Quản lý thuốc nguy cơ cao

  * [4- Cách thức xây dựng danh mục thuốc nguy cơ cao tại bệnh viện?](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/quan-ly-thuoc-nguy-co-cao#4-cch-thcxy-dng-danh-mc-thuc-nguy-c-cao-ti-bnh-vin)
  * [5- Biện pháp cụ thể để quản lý TNCC](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/quan-ly-thuoc-nguy-co-cao#5-bin-php-c-th-qun-l-tncc)


**1-_Định nghĩa :_**
Theo nghị định ngày 6/4/2011 về quản lý chất lượng sử dụng thuốc : Thuốc có nguy cơ cao bao gồm những thuốc đòi hỏi tăng cường quản lý để bảo đảm an toàn cao từ việc kê đơn, cấp phát, lưu trữ đến sử dụng thuốc và theo dõi bệnh nhân sau sử dụng, để tránh những sai sót có thể gây ra hậu quả nghiêm trọng cho sức khỏe của người bệnh. Phần lớn là những thuốc có giới hạn điều trị hẹp như : insuline, thuốc chống đông, thuốc chống loạn nhịp digoxine….
Theo « High Alert Medication »: Thuốc có nguy cơ cao là những thuốc có nguy cơ cao nhất gây hậu quả nghiêm trọng cho bệnh nhân nếu không được sử dụng hợp lý. Những thuốc này phải tuân thủ theo một quy trình riêng từ việc kê đơn, cấp phát, lưu trữ đến sử dụng thuốc và theo dõi bệnh nhân sau sử dụng.
Tóm gọn: Thuốc có nguy cơ cao (TNCC) là thuốc có ** _khả năng cao gây tổn hại đáng kể_** cho ** _bệnh nhân_** nếu gặp ** _sai sót_** trong quá trình sử dụng.
**2-_Xây dựng danh mục thuốc có nguy cơ cao:_**
Nguyên tắc chung là mỗi bệnh viện phải có danh mục riêng, phù hợp với hoạt động, đối tượng bệnh nhân chăm sóc của bệnh viện. Mỗi bệnh viện có thể sử dụng các báo cáo sai sót trong sử dụng thuốc ngay tại bệnh viện mình để xây dựng, bổ sung danh sách thuốc có nguy cơ cao. Danh mục phải được thiết lập bởi một hội đồng gồm các thành viên từ các khoa phòng khác nhau, ở các vị trí khác khau và danh mục này được đánh giá lại hàng năm. Danh sách thuốc có nguy cơ cao là các thuốc có nguy cơ cao nói chung có thể dùng để áp dụng xây dựng danh mục riêng phù hợp với từng bệnh viện.
Ngoài **các thuốc** có nguy cơ cao còn có **các tình huống, môi trường và đối tượng bệnh** có nguy cơ cao
Thuốc có nguy cơ cao
  * Thuốc có giới hạn điều trị hẹp, thuốc mới ít được biết đến….


Bệnh nhân có nguy cơ cao
  * Bệnh nhân cao tuổi, đa bệnh, suy thận, suy dinh dưỡng, trẻ em…


Tình huống có nguy cơ cao
  * Đội ngũ y tế tập sự, mới vào làm, khoa cấp cứu, khoa hồi sức tích cực, kê đơn thuốc không được chuẩn hóa, thuốc có bề ngoài giống nhau…


Đường sử dụng thuốc có nguy cơ cao
  * Đường tiêm tĩnh mạch, tiêm trong vỏ, ngoài màng cứng (intrathecal, peridural), thuốc dán ngoài da, thiết bị tiêm truyền có kiểm soát tốc độ…


**3-_Chiến lược để giảm tối đa nguy cơ rủi ro từ các thuốc có nguy cơ cao:_**
Sau khi bệnh viện đã đưa ra danh mục các thuốc có nguy cơ cao của bệnh viện, bước tiếp theo là tìm ra các điểm kiểm soát để đảm bảo an toàn tối đa trong sử dụng các thuốc này (dược sĩ làm việc cùng bác sĩ và điều dưỡng để tìm ra tiếng nói chung). Các biện pháp chung cho quy trình sử dụng thuốc có nguy cơ cao thường là :
– Kê thuốc : thiết lập các **protocole (tạm dịch là phác đồ)** chuẩn (ví dụ : chỉ định, liều mg/kg/ngày, liều tối đa, đường dùng), có thể có cả phần theo dõi tác dụng thuốc, tác dụng phụ (ví dụ : protocole thuốc INSULINE bao gồm quy định về liều UI/ml, kèm theo mục tiêu đường huyết, các dấu hiệu hạ đường huyết, cách khắc phục…)
– Cấp phát thuốc từ khoa dược: đảm bảo duyệt đơn bởi dược sĩ lâm sàng trước khi cấp phát thuốc; tránh sử dụng nhiều biệt dược khác nhau cho cùng một hoạt chất (ví dụ : thuốc INSULINE trong danh mục thuốc của bệnh viện chỉ dùng một loại biệt dược cho một loại insuline tác dụng ngắn, tác dụng trung bình, tác dụng kéo dài…); tránh sử dụng nhiều nồng độ khác nhau cho cùng một hoạt chất (ví dụ : thuốc insuline trên thị trường có 2 nồng độ khác nhau là 100UI/ml và 200UI/ml, ở trong bệnh viện chỉ cho phép dùng một nồng độ là 100UI/ml). Nâng cao chính sách mua thuốc tiêm ở dạng đã pha chế để tránh khâu pha chế cho điều dưỡng.
– Lưu trữ thuốc trên khoa lâm sàng: có bệnh viện thì chọn đánh dấu ngăn đựng thuốc có nguy cơ cao bằng một nhãn có màu riêng, có bệnh viện thì chọn nơi đựng thuốc riêng cho các thuốc này tách biệt các thuốc khác. Mục đích chung là để điều dưỡng có thể nhận biết ngay ra các thuốc có nguy cơ cao khi sử dụng. Tránh trong cùng một khoa lưu trữ nhiều biệt dược có hàm lượng khác nhau, nhất là khi bề ngoài không có nhiều sự khác biệt (ví dụ : MIDAZOLAME 5mg/ml, có ống 1ml, ống 10ml. Hai ống này nếu không đọc kĩ thì bề ngoài giống hệt nhau, các khoa lâm sàng chỉ được lưu trữ ống 1ml, còn lại ống 10ml là dành riêng cho phòng mỗ, phòng phục hồi tích cực…). Tránh tình trạng trao đổi thuốc giữa các khoa lâm sàng.
– Sử dụng thuốc: lập bảng pha chế chuẩn cho các điều dưỡng (dung dịch pha, nồng độ, đường dùng…), kiểm tra 2 lần bởi 2 người khác nhau (double check) khi tính liều, pha chế. Hướng dẫn về dùng các thuốc giải độc nếu có với quy trình sử dụng chuẩn.
Sau khi đã có danh mục thuốc có nguy cơ cao, đã tìm ra các điểm kiểm soát để đảm bảo an toàn tối đa thì việc đưa vào thực hiện, tập huấn cho đội ngũ cán bộ y tế về các biện pháp mới, chính sách mới liên quan đến các thuốc này là quan trọng, vất vả hơn nhiều. Nên lên kế hoạch tập huấn cho đội ngũ y tế hiện tại và những người mới kể cả bác sĩ nội trú. Lên kế hoạch theo dõi đánh giá việc thực hiện đúng quy trình riêng đã đề ra cho các thuốc có nguy cơ cao.
###### **4-_Cách thức xây dựng danh mục thuốc nguy cơ cao tại bệnh viện?_**
Cần dựa vào:
  * Thực tế hoạt động dược
  * Các phản ứng không mong đợi được báo cáo
  * Các sai sót y khoa được báo cáo
  * Dễ nhớ
  * Gây ấn tượng tốt


Ví dụ về danh mục thuốc nguy cơ cao tại BV ĐH Y Dược Huế
###### **5-_Biện pháp cụ thể để quản lý TNCC_**
_**5.1 Quá trình kê đơn**_
  * Xây dựng phác đồ chuẩn đối với các thuốc nguy cơ cao.
  * Không viết tắt, viết rõ ràng tên TNCC khi kê đơn
  * Ghi rõ liều, đường dùng, thời gian tiêm truyền, chẩn đoán.


_Ví dụ: Dopamin 5mcg/kg IV trong 1 phút_
  * Nên kê đơn bằng máy tính để tránh những sai sót khi viết tay.
  * Lưu ý khi kê đơn bằng máy tính có thể gâyra những sai sót mới do dùng phần mềm như: kê đơn nhầm tên thuốc gần giống nhau.
  * Thêm chức năng cảnh báo tự động: phát hiện tương tác thuốc, chống chỉ định, thuốc trùng lặp…


_**5.2 Quá trình bảo quản, lưu trữ**_
  * Đặt ở vị trí riêng biệt và gián nhãn các thuốc dễ gây nhầm lẫn.
  * Đặt ở vị trí riêng biệt và gián nhãn “**THUỐC NGUY CƠ CAO** ” 


_**5.3 Quá trình cung ứng/cấp phát TNCC từ Khoa Dược hay Khoa phòng cho bệnh nhân**_
  * Tránh mua các thuốc dễ ngây nhầm lẫn
  * Xây dựng quy trình cấp phát rõ ràng, cụ thể. Có quy trình cấp phát riêng với những nhóm thuốc đặc biệt.
  * Lưu ý các từ viết tắt, kí hiệu trong đơn thuốc.
  * Hạn chế gây gián đoạn trong quá trình cấp phát.
  * Thực hiện kiểm tra chéo khi cấp phát
  * Chú ý các thuốc LASA (trông giống nhau, nhìn giống nhau) khi cấp phát.


_**5.4 Sử dụng TNCC ở bệnh nhân**_
  * Tư vấn dùng thuốc cho bệnh nhân
  * Phát các tài liệu phát tay
  * Dán nhãn cảnh báo cho từng loại TNCC cho bệnh nhân.


**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [4- Cách thức xây dựng danh mục thuốc nguy cơ cao tại bệnh viện?](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/quan-ly-thuoc-nguy-co-cao#4-cch-thcxy-dng-danh-mc-thuc-nguy-c-cao-ti-bnh-vin)
  * [5- Biện pháp cụ thể để quản lý TNCC](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/quan-ly-thuoc-nguy-co-cao#5-bin-php-c-th-qun-l-tncc)



## ️ Đảm bảo môi trường an toàn cho nhà thuốc trong mùa COVID-19

**Tài liệu dưới đây được tổng hợp từ các khuyến cáo của Úc và Mỹ áp dụng tại các nước đó. Các nhà thuốc Việt Nam nên theo dõi hướng dẫn của BYT, Cục quản lý dược và các quy định của Việt Nam để áp dụng cho phù hợp.**
Cần giảm thiểu tối đa quá trình tiếp xúc giữa bệnh nhân và nhân viên nhà thuốc bằng những chiến lược như sau:
**Các biện pháp chung**
  * **Áp phích** bên ngoài nhà thuốc phải **hiển thị rõ ràng số điện thoại** để những người không khỏe có thể gọi cho nhà thuốc thay vì vào khu vực nhà thuốc.
  * Biển báo bên ngoài nhà thuốc phải cho biết **số lượng khách hành tối đa** được phép có trong khu vực nhà thuốc theo quy định hạn chế của BYT, áp dụng quy tắc 2m2 cho mỗi khách hàng và tính toán số lượng người tối đa (không bao gồm nhân viên nhà thuốc) được phép có mặt cùng một lúc trong nhà thuốc.
  * Các nhà thuốc nên **lưu trữ thông tin liên hệ bệnh nhân** qua phần mềm máy tính hoặc sổ ghi chép. Cung cấp mã QR và luôn sẵn có biểu mẫu bằng giấy để thu thập các thông tin liên hệ của bệnh nhân một cách chi tiết và thuận lợi.
  * Nếu có thể, hãy tạo một lối vào và một lối ra và khuyến khích **lưu thông một chiều** trong khu vực nhà thuốc. Sử dụng bảng chỉ dẫn, rào cản và đánh dấu dưới sàn để hướng dẫn bệnh nhân và chỉ ra khoảng cách 1,5m giữa những người đứng trong hàng đợi. Luôn đảm bảo mọi người đều giữ khoảng cách 1,5m với nhau ở bất cứ nơi nào trong khu vực nhà thuốc.
  * Đối với những bệnh nhân **gọi điện báo trước có các triệu chứng** của đường hô hấp nên được **khuyên không đến****nhà thuốc** và ghi nhận lại thông tin liên hệ, tình trạng bệnh, yếu tố dịch tễ và các thông tin liên quan khác. Sau đó chuyển thông tin này cho các BS hoặc DS hoặc NVYT khác phụ trách tư vấn nhóm bệnh nhân COVID-19. Nên xây dựng biểu mẫu chung để thu thập thông tin đầy đủ, rõ ràng và đồng nhất để thuận lợi cho công tác tư vấn sau đó.
  * Các DS đang cung cấp các dịch vụ quản lý **bệnh****nhân mạn tính không yêu cầu gặp mặt trực tiếp** nên cố gắng sử dụng các dịch vụ tư vấn từ xa **Telephone, Telehealth hoặc Telepharmacy****(qua điện thoại, video call…).**
  * Cách tốt nhất để giảm thiểu nguy cơ lây nhiễm là **vệ sinh tay tốt** bao gồm cả thường xuyên rửa tay bằng nước và xà phòng hoặc nước rửa tay có cồn và tránh tiếp xúc trực tiếp hoặc đứng gần người khác. Nên bố trí dung dịch vệ sinh tay đầy đủ và phù hợp để tất cả mọi người đều có thể sử dụng nước rửa tay dễ dàng và thuận lợi.
  * **Găng tay bảo hộ không được khuyến khích** vì chúng không bảo vệ chống lại sự lây truyền của virus sau khi tiếp xúc với bệnh nhân hoặc bề mặt xung quanh và có thể làm giảm nhu cầu rửa tay thường xuyên. Găng tay bảo hộ được sử dụng khi chạm vào bệnh nhân phải được xử lý sau mỗi lần tiếp xúc với từng bệnh nhân riêng lẻ.
  * Nhân viên nhà thuốc cần thực hiện các quy trình để **làm sạch và khử trùng thường xuyên môi trường làm việc.**
  * Khuyến khích sử dụng các phương thức **thanh toán không tiếp xúc** để giảm thiểu việc xử lý tiền mặt trong nhà thuốc.
  * Nên có dịch vụ **vận chuyển, giao thuốc tại nhà** để thuận lợi cho những ai đang trong khu vực cách ly, khó khăn đi lại hoặc hạn chế ra đường.
  * Trong những khu vực mà sự lây truyền cộng đồng được biết là đang xảy ra:


  * Xem xét phân công nhân viên để phân loại và tư vấn cho bệnh nhân và kiểm soát số người vào nhà thuốc.
  * Xem xét phân bổ **một phòng hoặc một khu vực** trong nhà thuốc nơi có thể giữ lại các bệnh nhân có triệu chứng, không thể đi lại hoặc bệnh nặng trong khi chờ chuyển đi.


**Nguyên tắc dự phòng và kiểm soát nhiễm khuẩn trong nhà thuốc cộng đồng**
  * Thực hiện tốt thao tác vệ sinh khi **ho hoặc hắt hơi, vệ sinh đường hô hấp**


+ **Giữ khoảng cách** với những người có triệu chứng giống cúm nếu có thể.
+ Ho hoặc hắt hơi **vào cánh tay hoặc khăn giấy** dùng một lần.
+ **Vứt bỏ khăn giấy** đã sử dụng vào thùng rác và **rửa tay sạch** sau đó.
  * Thúc đẩy nhân viên và bệnh nhân **vệ sinh tay** thường xuyên và kỹ lưỡng


+ Vệ sinh tay làm giảm đáng kể sự lay lan COVID-19
+ Vệ sinh tay có thể thực hiện bằng **xà phòng và nước** hoặc **nước sát khuẩn chứa cồn** theo áp phích sẵn có.
  * Giữ gìn **môi trường sạch sẽ**


+ Các bề mặt thường xuyên chạm vào như **mặt bàn, tay cầm, bàn phím, điện thoại** ,..nên được vệ sinh bổ sung nhiều lần hơn những nơi khác (mỗi 2h, mỗi 3h, mỗi 4h,..)
  * **Đối với bệnh nhân**


  * Trưng bày **bảng hiệu, áp phích** trong nhà thuốc để khuyến khích bệnh nhân tập vệ sinh tay, nghi thức ho và vệ sinh đường hô hấp.
  * Đặt **các lọ/dung dịch chất khử trùng có cồn** ở những vị trí nổi bật xung quanh nhà thuốc, đặc biệt là tại các quầy nơi có bề mặt thường xuyên chạm vào.
  * Nói chuyện với bệnh nhân từ **một khoảng cách an toàn** để tránh tiếp xúc với các giọt bắn đường hô hấp.


  * **Đối với nhà thuốc**


  * Đảm bảo các dung dịch vệ sinh tay được bố trí thuận tiện và dễ dàng cho nhân viên sử dụng.
  * Nhân viên có triệu chứng về đường hô hấp hoặc sốt thì nên ở nhà.


  * **Giữ khoảng cách nên được áp dụng như sau:**


  * Trong nhà thuốc, cố gắng giữ **khoảng cách 1,5m** giữa tất cả mọi người và đảm bảo giới hạn số người tối đa theo quy định (**2 m 2/1 người**).
  * **Đánh dấu dưới sàn nhà** để chỉ ra khoảng cách thích hợp để phân tách những người đang đứng trong khu vực chờ.
  * Có các **rào cản vật lý/ kính che** giữa nhân viên nhà thuốc và bệnh nhân.
  * Các Dược sĩ đảm nhận các dịch vụ lâm sàng trực tiếp có thể xem xét việc sử dụng thêm các **thiết bị bảo vệ cá nhân** như **khẩu trang, găng tay** khi tiếp xúc với bệnh nhân có nguy cơ.


**Vệ sinh bằng chất tẩy rửa và chất khử trùng**
Vệ sinh môi trường thường xuyên trong nhà thuốc là rất quan trọng để giảm nguy cơ truyền sinh vật gây bệnh.
  * Nhân viên nhà thuốc có thể đảm bảo nhà thuốc được làm sạch và vệ sinh bề mặt bằng chất tẩy rửa và chất khử trùng. Điều này có thể được thực hiện bằng quy trình 2 bước làm sạch bằng chất tẩy rửa, sau đó khử trùng hoặc sử dụng một sản phẩm kết hợp cả 2 bước.
  * Sử dụng **chất tẩy rửa:**


  * Chất tẩy rửa để loại bỏ chất bẩn và chất hữu cơ.
  * Hầu hết các bề mặt cứng bao gồm cả mặt quầy đều có thể được làm sạch đầy đủ bằng nước ấm và chất tẩy rửa trung tính theo hướng dẫn của nhà sản xuất.
  * Để khô các bề mặt đã được làm sạch là một khía cạnh quan trọng trong việc vệ sinh.
  * Nên thường xuyên lau sàn cứng bằng chất tẩy rửa và nước.
  * Khuyến cáo nên sử dụng các **chất khử trùng** có chứa cồn ≥ 70%, amoni bậc 4, hoặc tự pha chế chất tẩy rửa thích hợp phù hợp cho việc sử dụng chống lại virus COVID-19.


**Quản lý chất thải**
  * Đảm bảo các thùng kín được cung cấp để nhân viên và bệnh nhân vứt bỏ chất thải một cách an toàn.
  * Không có biện pháp kiểm soát đặc biệt nào được yêu cầu để xử lý chất thải – tuân theo các quy trình thông thường để xử lý.


**Nguồn:**
  1. Guidance for community pharmacies during the COVID-19 pandemic. Úc. 4/2021
  2. Regulatory advice for community pharmacists during COVID-19. Úc. 4/2021
  3. COVID-19 PANDEMIC – Guidelines for Community Pharmacy. Úc. 3/2020.
  4. Guidance for Pharmacies – Guidance for Pharmacists and Pharmacy Technicians in Community Pharmacies during the COVID-19 Response, CDC Mỹ. 2020.


**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh

## ️ Ảnh hưởng của bệnh gan đối với liều dùng và nguyên tắc điều chỉnh liều của thuốc

Rối loạn chức năng gan có thể ảnh hưởng đến đáp ứng của thuốc và sử dụng thuốc, bằng nhiều đường:
1. Thông qua rối loạn dược động học với tăng khả̉ dụng sinh học do giảm chuyển hóa qua gan bước đầu: hoặc do giảm hoạt hóa bước đầ̀u củ̉a các thuốc tiền thân.
2. Có thể do giảm khả năng gắn kế́t protein và giảm thải trừ thuốc.
3. Có nguy cơ làm thay đổi tác dụng củ̉a thuốc.
4. Có nguy cơ làm tình trạng chuyển hóa của người bệnh xấu đi.
**Rối loạn dược động học của thuốc** có thể là hậu quả của bệnh gan, vì gan là cơ quan quan trọng nhất để loại thải chuyển hóa thuốc. Suy giảm chức năng tế bào gan sẽ làm giảm khả năng thực hiện quá trình chuyển hóa bình thường của gan. Các bệnh có tác động xấu đến tuần hoàn hệ tĩnh mạch cửa cũng có thể ảnh hưởng đến chuyển hóa thuốc do hấp thu thuốc qua đường tĩnh mạch tắt, không cho thuốc đến vị trí chuyển hoá. Cả hai tác động đó đều ảnh hưởng mạnh tới chuyển hóa của thuốc ở người bệnh bị xơ gan nặng. Hiểu rõ được thuốc nào chuyển hóa qua gan bước đầu là rất quan trọng vì bệnh lý hoặc phối hợp thuốc không chuẩn có thể làm giảm chuyển hóa lúc đầu gây nên tương tác chuyển hóa.
Khả dụng sinh học (F) là thuật ngữ dùng để chỉ tỷ lệ phần trăm của một liều thuốc được hấp thu vào hệ tuần hoàn máu. Trong phương trình trên của chúng tôi ký hiệu đó là F và biểu thị tỷ lệ % của liều thuốc đã cho. F có thể là từ 0% - 100%. Sau tiêm tĩnh mạch khả dụng sinh học được coi là hoàn toàn. Sau những liều uống chức năng gan quyết định mức độ khả dụng sinh học của nhiều thuốc thông qua hiệu quả của chuyển hóa qua gan bước đầu. Hiệu quả bước đầu hay chuyển hóa bước đầu là chuyển hóa của thuốc được hấp thu trên đường đi sau khi thuốc hòa tan trong lòng ruột qua gan để vào hệ tuần hoàn. Phần lớn thuốc uống đều được hấp thu từ đoạn ống tiêu hóa được dẫn lưu theo hệ thống tĩnh mạch cửa - gan. Do đó ngay một thuốc được hấp thu tốt cũng phải đi qua và thoát khỏi gan trước khi vào hệ thống tuần hoàn. Đối với các thuốc nhạy cảm với chuyển hóa gan một phần lớn liều uống có thể bị chuyển hóa và biến mất ngay trước khi đến vị trí tác dụng. Ví dụ một số thuốc được thải trừ cao bước đầu bao gồm các thuốc giảm đau: acid acetylsalicylic, morphin, paracetamol, pentazocin, pethidin, các thuốc tim mạch: glyceryl trinitrat, isoprenalin, isosorbid dinitrat, labetalol, lignocain, metoprolol, nifedipin, prazosin, propranolol, verapamil, các thuốc trên hệ thần kinh trung ương: clomethiazol, clorpromazin, imipramin, levodopa, nortriptylin, các thuốc về hô hấp: salbutamol, terbutalin.
Tầm quan trọng của chuyển hóa bước đầu gồm 2 mặt:
1. Chuyển hóa bước đầu là lý do quan trọng nhất để giải thích sự khác nhau về hấp thu thuốc giữa các cá thể. Ngay những người khỏe mạnh cũng có mức độ khả năng chuyển hóa của gan và chuyển hóa bước đầu rất khác nhau.
2. Ở người bị bệnh gan nặng chuyển hóa bước đầu có thể bị giảm mạnh, thường dẫn đến hấp thu một lượng thuốc cao hơn bình thường, hậu quả là bị nhiễm độc và chịu các tác dụng có hại ngay cả với những liều bình thường.
Nếu chuyển hóa bước đầu bị ức chế hoặc giảm sút, ví dụ do bệnh gan, thì hậu quả rõ nét là thuốc thoát khỏi chuyển hóa của gan nhiều hơn vào hệ tuần hoàn và từ đó đi đến vị trí tác dụng. Các ví dụ về hiệu quả của thuốc do ảnh hưởng của sự tăng quá mức khả dụng sinh học do xơ gan bao gồm các thuốc clomethiazol (khả dụng sinh học tăng 1000%), labetalol (khả dụng sinh học tăng 90%), metoprolol (khả dụng sinh học tăng 65%), nicardipin (khả dụng sinh học tăng 500%), paracetamol (khả dụng sịnh học tăng 50%), propra-nolol (khả dụng sinh học tăng 42%), verapamil (khả dụng sinh học tăng 140%). Sự tăng khả dụng sinh học này là trực tiếp do xơ gan gây giảm sự phân hủy thuốc qua chuyển hóa gan xảy ra bình thường khi thuốc đi qua gan. Như vậy xơ gan làm tăng mức hấp thu và do đó nồng độ thuốc trong máu có tỷ lệ cao hơn người khỏe mạnh.
Ngược lại hoạt hóa chuyển hóa bước đầu của thuốc tiền thân thành dạng hoạt động cũng bị ức chế. Điều này ảnh hưởng đến nhiều thuốc ức chế enzym chuyển như enalapril, do đó hiệu quả của thuốc sẽ bị giảm.
**Bệnh gan và sự giảm chuyển hóa ở gan.**
**_Các thuốc có mức chiết xuất cao ở gan_** Gan chuyển hóa những thuốc này với một mức độ rất cao. Do đó khả dụng sinh học của các thuốc này thấp và độ thanh thải phụ thuộc chủ yếu vào mức độ thuốc được tải đến các enzym gan. Do đó độ thanh thải các thuốc này tương đối nhạy cảm với các yếu tố ảnh hưởng đến dòng máu qua gan, ví dụ trong suy tim sung huyết. Tuy nhiên các thuốc này lại tương đối ít nhạy cảm với lượng enzym, hoạt tính của enzym hoặc khả năng gắn kết protein. Ví dụ về các thuốc có chuyển hóa cao ở gan bao gồm alprenolol, desipramin, labetalol, lidocain, metoprolol, morphin, glyceryl trinitrat, pentazocin, propoxyphen, propranolol, pethidin, nortriptylin và verapamil.
**_Các thuốc có mức chiết xuất thấp_****_ở gan_ :** Trong trường hợp này, mức độ chuyển hóa thuốc đủ thấp để độ thanh thải ở gan tương đối ít nhạy cảm với dòng máu qua gan mà chủ yếu phụ thuộc vào các enzym của gan. Ví dụ về loại này bao gồm cloramphenicol, paracetamol và theophylin. Các thuốc trong nhóm này, nhóm có gắn kết nhiều với protein, như carbamazin, diazepam, indomethacin, naproxen, nitrazepam, phe- nobarbital, tolbutamid, phenytoin, procainamid, acid salicylic, theophylin, acid valproic, và warfarin, có độ thanh thải chuyển hóa phụ thuộc cả vào khả năng của các enzym gan và cả vào gắn kết protein và phần tự do của thuốc. Do bệnh gan thường kết hợp với giảm nồng độ albumin huyết thanh nên thường cũng có tăng phần tự do của các thuốc đó thành thử khó mà dự đoán được ảnh hưởng của bệnh gan trên nồng độ toàn phần của thuốc. Do đó phải thận trọng trong việc lý giải mối tương quan giữa nồng độ và hiệu quả của liều thuốc đối với các thuốc có liên kết protein cao như phenytoin.
Ảnh hưởng của bệnh gan đối với thải trừ thuốc cũng phức tạp. Loại bệnh gan có tính quyết định. Trong viêm gan virus cấp, thay đổi chủ yếu là chức năng tế bào gan nhưng khả năng chuyển hóa thuốc của gan thường còn giữ được nguyên vẹn và dòng máu qua gan có thể còn tăng lên. Xơ gan nhẹ và vừa có khuynh hướng gây giảm dòng máu qua gan và có mạch tắt cửa - chủ, còn trong xơ gan nặng thì thường cả chức năng tế bào gan và dòng máu qua gan đều giảm.
Khác với đo độ thanh thải creatinin trong bệnh thận, ở người bệnh gan không có test nào có thể dự đoán được mức độ chuyển hóa thuốc. Tuy nhiên sự giảm albumin huyết thanh, tăng bilirubin máu và kéo dài thời gian prothrombin có thể cho phép đánh giá sơ bộ mức độ bệnh của gan. Trong thực tế, một thuốc được chuyển hóa do gan không nhất thiết có nghĩa là dược động học của thuốc bị rối loạn bởi bệnh gan, do đó không dễ suy đoán từ kết quả của một thuốc này để áp dụng cho một thuốc khác. Điều đó một phần cũng là do chuyển hóa của thuốc có thể được xúc tác bởi nhiều enzym cytochrom P450 khác nhau và những hệ thống enzym liên hợp khác nhau. Nếu trong lâm sàng cần sử dụng một thuốc được thải loại qua chuyển hóa gan cho người bệnh xơ gan thì liều lượng ban đầu phải rất thấp rồi tăng dần từng bước và phải theo dõi cẩn thận, chặt chẽ hiệu quả và tác dụng phụ.
Cũng có một số thuốc ảnh hưởng đến các enzym gan. Việc hiểu rõ loại thuốc nào có thể ức chế các enzym chuyển hóa thuốc của gan là rất quan trọng. Ví dụ như allopurinol, azapropazon, cloramphenicol, cimetidin, ciprofloxacin, disulfiram, erythromycin, và isoniazid đều là những thuốc ức chế mạnh enzym gan: Cimetidin có thể minh chứng điều này về mặt lâm sàng. Cime-tidin ức chế chuyển hóa của theophylin, dẫn đến các tác dụng phụ rất nguy hiểm, bao gồm loạn nhịp tim đe dọa mạng sống của người bệnh.
**Rối loạn tác dụng của thuốc** Bệnh gan ở giai đoạn nặng thường kèm theo những rối loạn chức năng của não và cuối cùng có thể dẫn đến hội chứng bệnh não do gan. Ngay trước khi xuất hiện bệnh não thì não bộ cũng đã rất nhạy cảm với tác dụng của các thuốc có tác dụng trung ương. ở người có bệnh gan nặng sử dụng liều bình thường các thuốc ngủ barbiturat, thuốc phiện cũng có thể dẫn đến hôn mê.
Giảm các yếu tố đông máu cũng là một vấn đề ở người bị bệnh gan. Những người bệnh này tỏ ra tăng nhạy cảm với thuốc chống đông loại uống. Tác dụng của các thuốc này là làm giảm tổng hợp các yếu tố đông máu (II, VII, IX, và X) phụ thuộc vitamin K. Khi việc sản xuất các yếu tố này bị giảm do bệnh gan thì một liều thuốc chống đông uống có hiệu quả nhiều hơn là ở người có chức năng gan bình thường. Cũng cần nhớ rằng ở những người bệnh này nếu dùng quá liều thuốc chống đông coumarin thì có khi không thể chữa trị được bằng vitamin K vì gan ở trạng thái này không đáp ứng với vitamin K để tăng tổng hợp các yếu tố đông máu. Cũng giống như thế, hiệu quả của heparin không như bình thường, do thiếu antithrombin III. Do đó phải xem xét rất cẩn thận ở người bị bệnh gan vì có nguy cơ biến chứng xuất huyết do thuốc có khả năng gây chảy máu.
**Rối loạn tình trạng chuyển hóa do thuốc**
**_Nhiễm kiềm do thuốc_** có thể xảy ra do dùng quá nhiều thuốc lợi tiểu. Từ đó thúc đẩy gây bệnh não. Cơ chế là tình trạng nhiễm kiềm giảm kali, hậu quả là chuyển ion NH4 + thành NH3 dễ dàng đi qua hàng rào máu - não thúc đẩy hoặc làm cho bệnh não nặng thêm.
**_Giữ nước quá mức_** ở người bị bệnh gan giai đoạn nặng thường gây phù và cổ trướng do giảm albumin huyết tương và tăng áp lực tĩnh mạch cửa. Tình trạng này có thể xấu đi do dùng thuốc gây giữ nước như carbenoxolon, antacid có chứa nhiều natri và thuốc giảm đau không steroid. Cần nhớ nên tránh dùng thuốc giảm đau không steroid cho người bị bệnh gan vì ngoài nguy cơ giữ nước quá mức còn có nguy cơ gây xuất huyết tiêu hóa.
**_Thuốc độc cho gan_**
Khi có thuốc thay thế chấp nhận được thì luôn luôn nên tránh dùng các thuốc có thể gây hủy hoại gan như các sulphonamid, rifampicin và dùng nhiều lần thuốc mê họ halogen. Các thuốc gây độc kiểu viêm gan bao gồm halothan, isoniazid, methyldopa, phenelzin và paracetamol. Các thuốc có thể gây ứ mật bao gồm phenothiazin, thuốc chống trầm cảm 3 vòng, thuốc giảm đau không steroid (đặc biệt là phenylbutazon), rifampicin, ethambutol, pyrazinamid, sulfonylurea, sulfonamid, ampicilin, nitrofurantoin, erythromycin estolat. Riêng methotrexat có thể gây xơ gan. Đối với các thuốc có độc tính cao với gan cần xem danh mục thuốc trong Dược thư quốc gia Việt Nam. Các thông tin quốc tế tập hợp được về nguy cơ các tác dụng phụ khác nhau bao gồm nhiễm độc gan được trình bày một cách có hệ thống cho từng thuốc. Cũng cần xem cả biện pháp điều trị đặc hiệu nhiễm độc gan do nhiễm độc paracetamol và do quá liều.
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh

## Tương tác thuốc là gì

  * [Tương tác thuốc - thuốc theo cơ chế dược động học](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/tuong-tac-thuoc-la-gi#tng-tc-thuc-thuc-theo-c-ch-dc-ng-hc)
  * [Tương tác thuốc - thuốc theo cơ chế dược lực học](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/tuong-tac-thuoc-la-gi#tng-tc-thuc-thuc-theo-c-ch-dc-lc-hc)


Thông thường việc sử dụng nhiều thuốc trên một người bệnh trong cùng một thời gian là cần thiết để đạt mục tiêu điều trị mong muốn hoặc để chữa nhiều bệnh cùng một lúc. Tuy nhiên trong nhiều trường hợp, thuốc được phối hợp quá nhiều không cần thiết. 
Trong điều trị tăng huyết áp, nên sử dụng đúng một thuốc lợi tiểu hoặc thuốc chẹn beta, có thể đạt hiệu quả trên 30 - 50% số người bệnh. Trong điều trị suy tim, dùng đồng thời một thuốc lợi tiểu với một thuốc giãn mạch và/hoặc một glycosid trợ tim thường cần thiết để đạt được hiệu suất tim thỏa đáng và giữ cho người bệnh không bị phù. 
Việc sử dụng nhiều thuốc (đa hóa trị liệu) là chuẩn mực trong hóa trị liệu ung thư và trong một số bệnh nhiễm khuẩn. Trong những trường hợp này, mục đích thường là để cải thiện hiệu quả điều trị và làm chậm xuất hiện tế bào ác tính hoặc vi khuẩn kháng với các kháng sinh hiện có. Khi dùng đồng thời nhiều thuốc, người thầy thuốc đứng trước vấn đề không biết cách phối hợp thuốc nào đó ở một người bệnh cụ thể có thể dẫn đến tương tác hay không. Nếu có, thì làm thế nào để tận dụng lợi thế của tương tác nhằm có kết quả điều trị tốt hơn hoặc làm thế nào để tránh các hậu quả của tương tác có hại.
Khái niệm tương tác thuốc tiềm năng là khả năng của một thuốc có thể làm thay đổi cường độ tác dụng dược lý của một thuốc khác khi sử dụng đồng thời. Kết quả cuối cùng có thể là một hoặc cả hai thuốc tăng hoặc giảm tác dụng hoặc xuất hiện một tác dụng mới không thấy có khi dùng riêng từng thuốc.
Ước tính tần suất tương tác thuốc trong lâm sàng khoảng 3 - 5% ở số người bệnh dùng vài thuốc và tới 20% ở người bệnh đang dùng 10 - 20 thuốc. Vì đa số người bệnh nằm viện dùng ít nhất 6 thuốc, nên vấn đề tương tác thuốc là khá quan trọng. Cần có sự hiểu biết kỹ lưỡng về các tác dụng của thuốc khi kê đơn để phát huy các tương tác có lợi và hạn chế các tương tác có hại.
Người thầy thuốc phải có những hiểu biết về cơ chế tương tác thuốc để phân tích các tương tác thuốc một cách hệ thống. Nhiệm vụ của người thầy thuốc là phải hiểu những nguyên lý cơ bản của tương tác thuốc trong việc xây dựng phác đồ điều trị. Những tương tác đó được đề cập ở từng chuyên luận thuốc riêng biệt trong quyển sách này.
Các tương tác có thể là tương tác dược động học (thay đổi hấp thu, phân bố hoặc đào thải của thuốc này hay thuốc khác) hoặc tương tác dược lực học (thí dụ tương tác giữa duy trì và đối kháng ở các thụ thể thuốc). Các tương tác có hại quan trọng nhất thường xảy ra ở những thuốc có độc tính cao hoặc có chỉ số điều trị thấp, vì nồng độ thuốc chỉ thay đổi tương đối nhỏ có thể đã dẫn đến những hậu quả có hại rõ rệt. Ngoài ra, các tương tác thuốc có thể ảnh hướng lớn về mặt lâm sàng trên người bệnh nặng hoặc có thể dẫn đến tử vong nếu điều trị không đủ liều.
## **Tương tác thuốc - thuốc theo cơ chế dược động học**
Thuốc có thể tương tác ở bất cứ thời điểm nào trong suốt quá trình hấp thu, phân bố, chuyển hóa hoặc bài xuất; kết quả là tăng hoặc giảm nồng độ của thuốc ở cơ quan tác dụng.
Thuốc có thể bị thay đổi bởi các tương tác lý hóa xảy ra trước hấp thu trong trường hợp thuốc tiêm và tiêm truyền. Thí dụ, các thuốc có thể tương tác trong một dung dịch tiêm tĩnh mạch để tạo tủa không tan có thể thấy được hoặc không thấy được rõ ràng. Trong ruột, các thuốc có thể tạo phức với ion kim loại hoặc hấp phụ trên các chất nhựa cao phân tử làm thuốc. Ca2+ và các cation kim loại chứa trong các antacid tạo phức hợp với tetracyclin, không hấp thu qua ruột. Cholestyramin hấp phụ và ức chế sự hấp thu của thyroxin, glycosid trợ tim, warfarin, corticosteroid, và cả một số thuốc khác. Tốc độ và đôi khi cả mức độ hấp thu có thể bị ảnh hưởng bởi những thuốc làm thay đổi nhu động của dạ dày, nhưng điều này thường ít có hậu quả lâm sàng. Các tương tác trong ruột có thể gián tiếp và phức tạp. Các kháng sinh làm thay đổi vi khuẩn chí ở ruột có thể làm giảm tốc độ tổng hợp vitamin K của vi khuẩn, làm tăng cường tác dụng của các thuốc uống chống đông (là những chất cạnh tranh với vitamin K). Với một thuốc được chuyển hóa bởi vi sinh vật đường tiêu hoá, điều trị kháng sinh có thể dẫn đến tăng hấp thu thuốc, như đã chứng minh ở một số người bệnh uống digoxin. Nhiều thuốc liên kết mạnh với albumin huyết tương (các thuốc acid) hoặc với glycoprotein acid-alpha1 (các thuốc kiềm). Nói chung, chỉ có các phân tử dược chất tự do không liên kết mới có tác dụng hoặc được phân bố vào các mô. Sự đẩy một thuốc ra khỏi vị trí liên kết bởi một thuốc khác có thể dẫn đến thay đổi tác dụng của thuốc. Mặc dù có những tương tác liên kết/chuyển dịch như vậy, nhưng ít khi các tương tác này có ý nghĩa lâm sàng. Ðó là do thuốc chuyển dịch được phân bố nhanh vào các mô, thể tích phân bố biểu kiến của thuốc càng lớn thì các phân tử nồng độ thuốc tự do trong huyết tương càng thấp. Hơn nữa, sau khi chuyển dịch, lại có thêm thuốc tự do để chuyển hóa và bài xuất. Như vậy, nói chung các quá trình thanh thải của cơ thể làm giảm nồng độ các phân tử thuốc tự do xuống tới nồng độ có từ trước khi xảy ra tương tác chuyển dịch thuốc. Kết quả là, tác dụng của tương tác kiểu như vậy thường thấp, nhất thời và không thấy rõ.
Một vài thuốc chuyển vận tích cực đến vị trí hoạt động. Thí dụ, các thuốc chống tăng huyết áp guanethidin và guanadrel, gây ức chế chức năng hệ thống thần kinh giao cảm sau khi chuyển vào nơron adrenergic bằng cơ chế thu nhập norepinephrin. ức chế hệ thống thu nhập này của nơron bởi các thuốc chống trầm cảm ba vòng và một số amin tác dụng giống thần kinh giao cảm sẽ ức chế sự phong bế giao cảm và giảm tác dụng chống tăng huyết áp của guanethidin và guanadrel.
Tương tác liên quan đến chuyển hóa thuốc có thể làm tăng hoặc giảm lượng thuốc sẵn có để tác dụng tùy theo tương ứng ức chế hoặc cảm ứng chuyển hóa. Tương tác có thể xảy ra giữa các thuốc hoặc giữa thuốc với các chất dinh dưỡng (thí dụ naringenin trong nước ép bưởi (một chất gây ức chế CYP3A4); hoặc với hóa chất khác (thí dụ rượu hoặc dung môi hữu cơ với các chất cảm ứng CYP2EI); khói thuốc lá, biphenyl polyclorinat (các chất gây ức chế CYP1A2). Các tác dụng cảm ứng hoặc ức chế enzym thường thấy rõ nhất đối với thuốc uống, vì toàn bộ hợp chất hấp thu phải qua gan trước khi vào hệ tuần hoàn. Vì vậy, ngay cả những thuốc có độ thanh thải toàn thân phụ thuộc chủ yếu vào lưu lượng máu ở gan (thí dụ propranolol), lượng thuốc thoát không bị chuyển hóa lần đầu qua gan sẽ chịu ảnh hưởng của cảm ứng hoặc ức chế enzym. Các ví dụ về thuốc chịu ảnh hưởng của các chất gây cảm ứng enzym là các thuốc uống chống đông, quinidin, corticosteroid, thuốc tránh thai estrogen liều thấp, theophylin, mexiletin, methadon và một số thuốc chẹn bêta adrenergic. Hiểu biết về cách chuyển hóa đặc trưng của một thuốc và các cơ chế phân tử của cảm ứng enzym có thể giúp ích trong việc hoạch định các nghiên cứu về tương tác thuốc có thể xảy ra. Như vậy, nếu một hợp chất thấy bị CYP3A4 chuyển hóa  _in vitro_ , nên định hướng nghiên cứu các thuốc thường dùng có thể ức chế (thí dụ ketoconazol) hoặc cảm ứng (thí dụ rifampicin) enzym này, do có tiềm năng gây ra tương tác có ý nghĩa lâm sàng. Ví dụ gần đây về loạn nhịp do phối hợp terfenadin và ketoconazol gây ra, đã nhấn mạnh nhu cầu phải có những nghiên cứu như vậy. Trong tương tác này, ketoconazol ức chế chuyển hóa của terfenadin (bởi CYP3A4) thành sản phẩm hoạt tính, dẫn đến tăng cao nồng độ của terfenadin không chuyển hóa có tác dụng độc.
Khả năng một thuốc ức chế sự bài xuất qua thận của một thuốc khác phụ thuộc vào tương tác ở các vị trí chuyển vận tích cực. Nhiều tương tác được thông báo xảy ra ở vị trí chuyển vận anion, thí dụ tại đó probenecid ức chế bài xuất penicilin gây tác dụng mong muốn là tăng cao nồng độ của kháng sinh trong huyết tương và kéo dài nửa đời của thuốc đó. Tương tự như vậy, sự đào thải của methotrexat bị ức chế bởi probenecid, salicylat, và phenylbutazon, nhưng trong trường hợp này độc tính của methotrexat có thể xảy ra từ tương tác này. Về tương tác ở vị trí chuyển vận đối với các thuốc kiềm có thể nêu sự ức chế bài xuất procainamid bởi cimetidin và amiodaron. Tương tác ở một vị trí ống thận chưa biết rõ gây ức chế bài xuất digoxin bởi quinidin, verapamil và amiodaron. Sự bài xuất của Li+ có thể bị ảnh hưởng bởi các thuốc làm thay đổi khả năng tái hấp thu Na+ của ống thận gần. Do vậy, thanh thải Li+ giảm và nồng độ Li+ trong huyết tương tăng bởi các thuốc lợi tiểu gây giảm thể tích và bởi các thuốc chống viêm không steroid gây tăng tái hấp thu Na+ ở ống thận gần.
## **Tương tác thuốc - thuốc theo cơ chế dược lực học**
Có nhiều ví dụ về thuốc tương tác ở một vị trí thụ thể chung hoặc có tác dụng cộng lực hay ức chế do tác động trên các vị trí khác nhau ở một cơ quan. Những tương tác này được mô tả trong tài liệu này. Thí dụ các phenothiazin là các chất đối kháng mạnh alpha-adrenergic; nhiều thuốc kháng histamin và chống trầm cảm ba vòng là những chất đối kháng mạnh ở thụ thể muscarinic. Những tác động "nhỏ" này của thuốc có thể là nguyên nhân tương tác thuốc.
Các tương tác khác thuộc bản chất có vẻ là dược lực học còn ít hiểu biết hoặc tác dụng gián tiếp. Các hydrocarbon halogen hóa, bao gồm nhiều thuốc mê, làm cơ tim nhạy cảm với tác động gây loạn nhịp của catecholamin. Tác dụng này có thể do tác động trên đường dẫn từ thụ thể adrenergic đến bộ phận tác động, nhưng chi tiết chưa rõ. Tương tác nổi bật giữa pethidin và các chất ức chế monoamin oxidase gây co giật và sốt cao có thể liên quan đến lượng quá mức của chất dẫn truyền thần kinh kích thích, nhưng cơ chế chưa được sáng tỏ. Một thuốc có thể làm thay đổi nội môi bình thường, do đó làm tăng hoặc giảm tác dụng của một thuốc khác. Một ví dụ đã biết rõ về kiểu tương tác này là sự tăng độc tính của digoxin do kết quả hạ kali - máu do thuốc lợi tiểu gây ra.
## 
Tương tác thuốc - thuốc chỉ là một trong nhiều yếu tố có thể ảnh hưởng đến đáp ứng của người bệnh với điều trị. Nhiệm vụ chủ yếu của người thầy thuốc là xác định tương tác có xảy ra hay không và mức độ tác dụng của nó. Khi thấy có những tác dụng không mong muốn, phải nghĩ là tương tác thuốc. Ðánh giá cẩn thận toàn bộ tiền sử dùng thuốc của người bệnh là quan trọng, vì họ có thể dùng các thuốc không đơn, hoặc có thể dùng thuốc do nhiều thầy thuốc kê đơn, hoặc có thể dùng thuốc đang được kê đơn cho người bệnh khác. Phải cẩn thận khi có sự thay đổi đáng kể trong phác đồ điều trị bằng thuốc và phải ngừng các thuốc không cần thiết.
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [Tương tác thuốc - thuốc theo cơ chế dược động học](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/tuong-tac-thuoc-la-gi#tng-tc-thuc-thuc-theo-c-ch-dc-ng-hc)
  * [Tương tác thuốc - thuốc theo cơ chế dược lực học](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/tuong-tac-thuoc-la-gi#tng-tc-thuc-thuc-theo-c-ch-dc-lc-hc)



## ️ Phòng ngừa và xử trí phản ứng thuốc có hại và tác dụng phụ (ADR)

  * [Cách báo cáo ADR](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/phong-ngua-va-xu-tri-phan-ung-thuoc-co-hai-va-tac-dung-phu-adr#cch-bo-co-adr)
  * [Trách nhiệm theo dõi ADR](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/phong-ngua-va-xu-tri-phan-ung-thuoc-co-hai-va-tac-dung-phu-adr#trch-nhim-theo-di-adr)
  * [Nhận biết và xử trí các triệu chứng da quan trọng của ADR](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/phong-ngua-va-xu-tri-phan-ung-thuoc-co-hai-va-tac-dung-phu-adr#nhn-bit-v-x-tr-cc-triu-chng-da-quan-trng-ca-adr)


Các thuốc trong Dược thư quốc gia Việt Nam được trình bày kèm với những tác dụng có hại quan trọng nhất nhưng mới chỉ ở mức độ nhất định, vì báo cáo về tác dụng có hại (ADR) cũng không dự kiến được hết các nguy cơ có thể gặp. 
Việc báo cáo các phản ứng có hại là bắt buộc trong các thử nghiệm lâm sàng. Nhưng trong các thử nghiệm lâm sàng chỉ có rất ít người bệnh tiếp xúc với những phản ứng đó, do đó hạn chế khả năng phát hiện những phản ứng hiếm gặp nghiêm trọng có thể xảy ra. Vì vậy việc báo cáo tự nguyện về tác dụng không mong muốn là rất quan trọng sau khi thuốc được bán rộng rãi trên thị trường, đặc biệt điều này đã trở thành nguyên tắc đối với các thuốc mới. Phải báo cáo tất cả những triệu chứng và phản ứng không mong muốn khi phát hiện được và nghi ngờ là tác dụng có hại hoặc tác dụng phụ. Ðiều quan trọng cần nhận rõ là tất cả mọi thuốc đều có tác dụng có hại và phụ. Vấn đề chính không phải là phân chia một cách lý thuyết xem một triệu chứng hoặc phản ứng nào là tác dụng phụ hay là tác dụng có hại. Cả hai loại đều cần được báo cáo và làm rõ. Vấn đề chính là những phản ứng không mong muốn này thực sự là không mong muốn và đôi khi rất nghiêm trọng. Cũng có khi còn có nguy cơ là các tác dụng có hại và tác dụng phụ có thể gây cho người bệnh những bệnh mới, có thể rất nặng, gây tàn tật kéo dài thậm chí tử vong. Do đó điều quan trọng là phải tìm cách hạn chế càng nhiều càng tốt nguy cơ gặp phải những phản ứng này. 
Nguyên tắc chung để hạn chế các tác dụng phụ là sử dụng đúng liều cho từng người bệnh. Nguy cơ về những phản ứng thuốc có hại không phụ thuộc vào liều có thể hạn chế bằng cách để càng ít người càng tốt phải tiếp cận với nguy hiểm của dùng thuốc. Trong thực hành, điều đó có nghĩa là chỉ những người có bệnh mới dùng thuốc, và bệnh nặng tới mức lợi ích của việc dùng thuốc vượt trội so với nguy cơ có thể gặp phải. Vai trò của người thầy thuốc rất quan trọng trong quá trình này, chẩn đoán đúng và kê đơn phù hợp căn cứ vào những hướng dẫn điều trị hợp lý và an toàn.
Do đó báo cáo ADR cũng phải bao gồm cả những điều mà theo lý thuyết có thể được coi là tác dụng phụ. Mục đích chính là nhận ra được các vấn đề đang gây đau đớn và khó chịu không cần thiết cho người bệnh. Khi thay đổi cách sử dụng một thuốc cũ, khi phối hợp với một thuốc khác theo cách mới, hoặc khi sử dụng cho mục đích mới, đều có thể gây những phản ứng không mong muốn mới hoặc hay gặp hơn.
Vì vậy, báo cáo ADR phải nêu những mối liên quan nghi ngờ giữa thuốc và triệu chứng không mong muốn. Chỉ bằng cách này, thì mới có thể phát hiện được những vấn đề mới. Chỉ khi tìm ra vấn đề mới, thì mới xử trí được chúng.
## **Cách báo cáo ADR**
Phải dựa trên cơ sở những tác dụng có hại và tác dụng phụ nghi vấn. Không cần thiết phải xác nhận những triệu chứng nhận xét thấy có thật sự là tác dụng có hại hay phụ không. Ý tưởng tổng quát của việc báo cáo là thu thập dấu hiệu, dựa trên những quan sát nghề nghiệp từ những tình huống mà người bệnh dùng thuốc, thấy có phản ứng và triệu chứng không mong muốn.
Khi những phản ứng này xảy ra, điều quan trọng là phải mô tả kỹ các triệu chứng, thời gian triệu chứng xuất hiện, kết thúc và ghi chép tất cả những thuốc mà người bệnh đã dùng. Cũng cần hỏi người bệnh về tự dùng thuốc và thuốc cổ truyền. Cần thông tin về tình hình bệnh của người bệnh, và thông tin về thời gian của tất cả các thuốc mà người bệnh được cho dùng hoặc đã tự dùng. Theo nguyên tắc, mọi phản ứng nghiêm trọng và đặc biệt tất cả những phản ứng có hại gây chết người hoặc đe dọa tính mạng phải được báo cáo. Trong khi điều trị với thuốc mới, có một nguyên tắc quốc tế là phải báo cáo ngay mọi phản ứng và triệu chứng không mong muốn phát hiện được.
## **Trách nhiệm theo dõi ADR**
Mỗi bác sĩ, cán bộ y tế hoặc dược sĩ có trách nhiệm nghề nghiệp với bệnh nhân của mình, giáo dục và cho lời khuyên nhằm mục đích hạn chế nguy cơ. Mọi cán bộ y tế sau đó có trách nhiệm phải báo cáo về nghi vấn tác dụng không mong muốn nếu triệu chứng xảy ra có thể chỉ ra rằng đó là một tác dụng không mong muốn có hại.
## **_Phòng ngừa ADR_**
Nhiều phản ứng có hại của thuốc, tương tác thuốc và tác dụng phụ có thể phòng ngừa, nếu tuân thủ những nguyên tắc sau đây:
1. Không bao giờ kê đơn bất kỳ thuốc nào mà không có chỉ định rõ ràng biện minh cho việc kê đơn thuốc đó.
2. Nếu người bệnh mang thai, rất hạn chế dùng thuốc.
3. Hỏi người bệnh về dị ứng. Dị ứng mắc trước đó là một yếu tố dự đoán tin cậy về nguy cơ dị ứng với thuốc.
4. Hỏi người bệnh xem trước đó đã dùng bất kỳ thuốc nào chưa, kể cả những thuốc tự dùng. Sử dụng thuốc trước đó cũng có thể gây tương tác thuốc nghiêm trọng và bất ngờ.
5. Tránh những phối hợp thuốc không cần thiết. Hãy dùng càng ít thuốc nếu có thể.
6. Tuổi tác, các bệnh gan hoặc thận có thể ảnh hưởng đến chuyển hóa và khả năng đào thải thuốc. Ở những người bệnh này, cần phải dùng liều thấp hơn bình thường.
7. Cung cấp những chỉ dẫn thật rõ ràng và giáo dục bệnh nhân, cả về bệnh và về cách sử dụng đúng thuốc đã kê đơn.
8. Khi có nguy cơ là các thuốc được kê đơn có thể gây phản ứng có hại, phải giáo dục người bệnh về cách nhận biết các triệu chứng sớm, như vậy vấn đề phản ứng có hại có thể được điều trị sớm ở mức có thể.
## **_Nhận biết và xử trí các triệu chứng da quan trọng của ADR_**
Các phản ứng da với thuốc rất quan trọng cần nhận biết, một mặt vì tính chất nghiêm trọng của chúng, mặt khác đó là sự cảnh báo về những phản ứng thuốc nghiêm trọng hơn thậm chí đe dọa tính mạng.
_Ban đỏ dát sần:_ Phản ứng ngứa và tróc vảy, có thể tự hết nếu ngừng thuốc, chiếm một tỷ lệ lớn trong tất cả những phản ứng da do thuốc.
_**Mày đay/phù mạch:** _Mày đay là một cảnh báo quan trọng vì có mối liên quan rất chặt chẽ với phản ứng phản vệ đầy đủ và hen nặng. Mày đay xuất hiện đột ngột, cùng với ban đỏ ngứa phân tán. Thường dịu đi trong vòng 24 giờ. Ban da bọng nước được tạo thành là do hậu quả giải phóng histamin, có thể do nhiều quá trình gây ra. Ðiều quan trọng cần nhớ: Phản ứng phản vệ là do sự hoạt hóa của các chất trung gian rất giống nhau. Phù mạch khác về mặt hóa sinh, tuy nhiên cũng có thể rất nặng khi liên can đến các niêm mạc đường hô hấp trên. Nó có thể đe dọa tính mạng bằng cách trực tiếp gây tắc nghẽn đường thở. Phù mạch có thể do các thuốc ức chế enzym chuyển angiotensin. Các penicilin và aspirin cũng có thể gây ra phù mạch thông qua sự hoạt hóa bổ thể qua trung gian IgE hoặc IgG. Phản ứng mày đay cũng có thể phát triển do kết quả của cái được gọi là bệnh huyết thanh. Trong trường hợp này, mày đay tồn tại lâu hơn bình thường và phối hợp với các triệu chứng toàn thân. Ðiều trị bằng adrenalin, glucocorticoid và kháng histamin. Ngừng các thuốc nghi vấn, và cẩn thận tránh dùng lại những thuốc đó. Hen được điều trị theo những hướng dẫn chuẩn.
_**Ban cố định do thuốc:** _Phản ứng này có những ranh giới rõ rệt, tổn thương ban đỏ đau ở bàn tay, mặt, cẳng tay và bộ phận sinh dục. Tăng sắc tố cục bộ thường tồn tại sau khi hồi phục. Tiếp xúc lại với thuốc nghi vấn lại gây các ban mới ở cùng nơi. Các thuốc gây phản ứng này bao gồm sulphonamid, tetracyclin, barbiturat, salicylat, dapson.
_**Phản ứng thuốc nhạy cảm ánh sáng:** _Phản ứng này giới hạn ở những vị trí tiếp xúc với ánh sáng mặt trời và có thể do một phản ứng dị ứng ánh sáng qua trung gian miễn dịch thí dụ sau khi dùng clorpromazin, sulphanilamid, amiodaron. Phản ứng cũng có thể trực tiếp độc với ánh sáng và không liên quan đến miễn dịch, thí dụ sau khi dùng tetracyclin, sulphonamid, griseofulvin, naproxen và furosemid liều cao. Viêm da ánh sáng cũng có thể phát triển sau liệu pháp tia X, có thể tăng lên nhiều do một số thuốc. Hạn chế tiếp xúc với ánh sáng mặt trời, nếu vẫn phải tiếp tục điều trị với thuốc.
_**Hồng ban đa dạng và hội chứng Stevens-Johnson:** _Phản ứng này tương đối thường gặp nhưng không phải luôn luôn là do thuốc gây nên. Các triệu chứng gồm: Xuất hiện đột ngột, thương tổn ban cả ở da và niêm mạc; các vị trí ưu tiên hay bị và các thương tổn tách biệt có thể phát triển dáng vẻ hoại tử hoặc dạng "bia bắn". Phản ứng này cũng phối hợp với sốt, khó chịu và viêm họng do liên quan đến niêm mạc (hội chứng Stevens - Johnson). Ðây là một thể bệnh nặng gây hoại tử biểu bì hội lưu. Các thuốc được biết có thể gây phản ứng này là salicylat, sulphonamid, penicilin, sulphonylurê và barbiturat.  _Ðiều trị:_ Ngừng các thuốc nghi vấn, điều trị glucocorticoid và adrenalin và nếu cần để kiềm chế phá hủy mô, dùng các thuốc ức chế miễn dịch khác.
_**Viêm da tróc:** _Phản ứng này thể hiện ban đỏ, và có tư liệu chứng minh rõ ràng là do barbiturat, salicylat, penicilin, sulphonamid và sulphonylurê.
**_Hoại tử biểu bì độc_****(TEN):** Xuất hiện nhanh với ban dạng sởi hoặc hội lưu kèm với hoại tử mụn nước rộng khắp, và nhạy cảm đau ở da "kiểu vết thương bỏng". Cần phân biệt với các mụn nước nguyên vẹn riêng rẽ do bọng nước tự miễn. Có sự chồng lẫn lên nhau giữa TEN, hồng ban đa dạng và hội chứng Stevens - Johnson. Cũng có hai dạng khác nhau cần chú ý xem xét: ở người lớn dạng gây do quá mẫn với thuốc, ở trẻ nhỏ dạng gây do tác dụng hoại tử trực tiếp của độc tố tụ cầu. Loại này có thể do penicilin, sulphonamid, các kháng sinh khác, sản phẩm máu, thuốc chống viêm không steroid hoặc thuốc chống co giật (không có báo cáo với acid valproic).  _Ðiều trị:_ Hỗ trợ cân bằng dịch và điện giải. Dùng kháng sinh chống nguy cơ nhiễm khuẩn. Hỗ trợ chống tác dụng của chảy máu, bao gồm chảy máu đường tiêu hóa. Quan sát nguy cơ phù phổi và hội chứng suy hô hấp cấp ở người lớn. Ðiều trị chống đông dự phòng với heparin tiêm dưới da 5000 đvqt, 3 lần/24 giờ. Giảm đau và thuốc an thần. Ðiều trị sốt cao.
**_Các phản ứng penicilin thông thường:_**
Các phản ứng với penicilin gặp ở 1-10% số bệnh nhân điều trị, nhưng chỉ có 0,04% của số này, nghĩa là khoảng 1/50.000 người điều trị bị phản ứng dị ứng nặng. 10% dị ứng với penicilin cũng dị ứng chéo với cephalosporin. Các phản ứng dị ứng đe dọa tính mạng (typ I) thông qua trung gian IgE, hoặc trong một số trường hợp hiếm gặp qua trung gian IgG có liên quan đến bệnh huyết thanh. Những phản ứng này dẫn tới các phản ứng phản vệ, mày đay và nguy cơ sốc. Hay gặp nhất là phản vệ với penicilin tiêm tĩnh mạch. Yếu tố di truyền dị ứng bẩm sinh, dị ứng khác, atopi là những yếu tố nguy cơ để dự đoán phản ứng.
Ngoại ban kèm hoặc không kèm theo ngứa nhẹ: Tiếp tục điều trị, nhưng phải theo dõi người bệnh. Nếu người bệnh đã có phản ứng ngoại ban không kèm ngứa trong lần điều trị trước với penicilin: Ðiều trị liều đầu tiên phải tiến hành tại bệnh viện, giữ người bệnh để theo dõi và chuẩn bị tốt để xử trí nếu có phản ứng dị ứng.
Mày đay vừa phải hoặc ngoại ban kèm ngứa: Ngừng điều trị, tiêm adrenalin, dùng thuốc kháng histamin, dùng glucocorticoid. Không bao giờ được điều trị lại với penicilin, trừ khi được giải mẫn cảm.
Mày đay nặng hoặc mày đay kèm với sưng khớp và mặt: Ngừng điều trị. Ðiều trị với adrenalin, gluco-corticoid và kháng histamin. Không bao giờ điều trị lại với penicilin.
Phản ứng da niêm mạc hoặc các phản ứng da nặng khác: Ngừng và không bao giờ điều trị lại bằng penicilin.
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [Cách báo cáo ADR](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/phong-ngua-va-xu-tri-phan-ung-thuoc-co-hai-va-tac-dung-phu-adr#cch-bo-co-adr)
  * [Trách nhiệm theo dõi ADR](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/phong-ngua-va-xu-tri-phan-ung-thuoc-co-hai-va-tac-dung-phu-adr#trch-nhim-theo-di-adr)
  * [Nhận biết và xử trí các triệu chứng da quan trọng của ADR](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/phong-ngua-va-xu-tri-phan-ung-thuoc-co-hai-va-tac-dung-phu-adr#nhn-bit-v-x-tr-cc-triu-chng-da-quan-trng-ca-adr)



## Ký hiệu viết tắt về các đường dùng của thuốc (quốc tế)

  * [Các ký hiệu viết tắt các đường dùng thuốc](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/ky-hieu-viet-tat-ve-cac-duong-dung-cua-thuoc#cc-k-hiu-vit-tt-cc-ng-dng-thuc)
  * [Các ký hiệu viết tắt cách dùng thuốc](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/ky-hieu-viet-tat-ve-cac-duong-dung-cua-thuoc#cc-k-hiu-vit-tt-cch-dng-thuc)


## **Các ký hiệu viết tắt các đường dùng thuốc**
  * AAA: Apply to affected area (thuốc dùng cho phần bị ảnh hưởng)
  * AD: Right ear (ký hiệu tai trái); AS: left ear (ký hiệu tai phải); AU: each ear (ký hiệu dùng cho cả hai tai)
  * Garg: Gargle (ký hiệu thuốc súc miệng, họng)
  * ID: Intradermal (ký hiệu tiêm trong da)
  * IJ: Injection (ký hiệu thuốc tiêm)
  * IM: Intramuscular (**ký hiệu tiêm bắp**)
  * IN: Intranasal (ký hiệu thuốc dùng trong mũi)
  * Inf: Infusion (**ký hiệu truyền dịch**)
  * Instill: Instillation (ký hiệu thuốc dùng nhỏ giọt)
  * IP: Intraperitoneal (ký hiệu thuốc dùng trong màng bụng)
  * IV: Intravenous (**ký hiệu tiêm** **tĩnh mạch**)
  * NGT: Nasogastric tube (ký hiệu đường dùng bằng ống thông mũi **dạ dày**)
  * OD: Right eye (mắt phải); OS: Left eye (mắt trái); OU: both eye (cả hai mắt)
  * Per os/ PO: By mouth or orally (**ký hiệu đường uống**)
  * PR: Per the rectum (ký hiệu đường **trực tràng**)
  * PV: Per the vagina (ký hiệu đường **âm đạo**)
  * SL: Sublingual, under the tongue (ký hiệu đường dưới **lưỡi**)
  * SQ/SC: Subcutaneously (ký hiệu **tiêm dưới da**).


## **Các ký hiệu viết tắt cách dùng thuốc**
Trong một y lệnh, ngoài những thông tin về tên thuốc, đường dùng có các thuật ngữ viết tắt thì cách sử dụng thuốc cũng có những cách viết tắt quy ước quốc tế như sau:
  * a.c: Before the meal (dùng trước bữa ăn)
  * b.i.d: Twice a day (dùng hai lần một ngày)
  * gtt: Drops (sử dụng bằng các nhỏ giọt)
  * p.c: After meals (dùng sau bữa ăn)
  * p.o: By mouth, orally (dùng đường uống)
  * q.d: Once a day (dùng một lần mỗi ngày)
  * t.i.d: Three times a day (dùng 3 lần mỗi ngày)
  * q.i.d: Four times a day (dùng 4 lần mỗi ngày)
  * q.h: Every hour (dùng mỗi giờ)
  * q.2h: Every 2 hours (dùng mỗi 2 giờ)
  * q.3h: Every 3 hours (dùng mỗi 3 giờ)
  * q.4h: Every 4 hours (dùng mỗi 4 giờ).


Như vậy có thể thấy rằng sẽ có sự khác nhau cơ bản giữa ký hiệu q và id đó là:
  * q (q.1h. q.2h,...): Là ký hiệu đòi hỏi phải có khoảng cách chính xác về thời gian giữa những lần sử dụng thuốc ví dụ như ở trường hợp **q.6h** nếu thuốc tiêm lần 1 lúc 6 giờ thì bệnh nhân phải được tiêm lần 2 lúc 12 giờ
  * i.d (b.i.d, t.i.d,...): Là ký hiệu không đòi hỏi khoảng cách chính xác về thời gian mà chỉ cần đủ số lần sử dụng thuốc là được như uống thuốc vào các bữa sáng, trưa, chiều, tối.


**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [Các ký hiệu viết tắt các đường dùng thuốc](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/ky-hieu-viet-tat-ve-cac-duong-dung-cua-thuoc#cc-k-hiu-vit-tt-cc-ng-dng-thuc)
  * [Các ký hiệu viết tắt cách dùng thuốc](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/ky-hieu-viet-tat-ve-cac-duong-dung-cua-thuoc#cc-k-hiu-vit-tt-cch-dng-thuc)



## ️ Thuốc giảm đau Ibuprofen sử dụng trong thai kỳ được không?

  * [Ibuprofen là gì và tại sao được chỉ định?](https://bvnguyentriphuong.com.vn/san-phu-khoa/thuoc-giam-dau-ibuprofen-su-dung-trong-thai-ky-duoc-khong#ibuprofenl-g-v-ti-sao-c-ch-nh)
  * [Sử dụng Ibuprofen trong thai kỳ có an toàn?](https://bvnguyentriphuong.com.vn/san-phu-khoa/thuoc-giam-dau-ibuprofen-su-dung-trong-thai-ky-duoc-khong#s-dng-ibuprofen-trong-thai-k-c-an-ton)
  * [Tại sao sử dụng Ibuprofen trong thai kỳ lại không an toàn?](https://bvnguyentriphuong.com.vn/san-phu-khoa/thuoc-giam-dau-ibuprofen-su-dung-trong-thai-ky-duoc-khong#ti-sao-s-dng-ibuprofen-trong-thai-k-li-khng-an-ton)
  * [Phải làm thế nào nếu bạn đã lỡ sử dụng Ibuprofen trong thai kỳ?](https://bvnguyentriphuong.com.vn/san-phu-khoa/thuoc-giam-dau-ibuprofen-su-dung-trong-thai-ky-duoc-khong#phi-lm-th-no-nu-bn-l-s-dng-ibuprofen-trong-thai-k)
  * [Có thuốc thay thế được cho Ibuprofen để sử dụng trong thai kỳ hay không?](https://bvnguyentriphuong.com.vn/san-phu-khoa/thuoc-giam-dau-ibuprofen-su-dung-trong-thai-ky-duoc-khong#c-thuc-thay-th-c-cho-ibuprofen-s-dng-trong-thai-k-hay-khng)
  * [Có thể dùng Ibuprofen dạng gel trong thai kỳ không?](https://bvnguyentriphuong.com.vn/san-phu-khoa/thuoc-giam-dau-ibuprofen-su-dung-trong-thai-ky-duoc-khong#c-th-dng-ibuprofen-dng-gel-trong-thai-k-khng)


**Câu trả lời là không** , phụ nữ có thai cần đặc biệt cẩn trọng trong việc sử dụng các loại dược phẩm nói chung. Bạn không được dùng bất kỳ thuốc nào mà không có chỉ định của bác sĩ, vì một vài loại thuốc có thể gây hại cho thai nhi của bạn. Ở bài viết này sẽ bàn luận về một loại thuốc giảm đau rất thông dụng, Ibuprofen, về việc có nên sử dụng hay không và vì sao thai phụ cần thận trọng với nó.
## **Ibuprofen là gì và tại sao được chỉ định?**
Ibuprofen là thuốc kháng viêm thuộc nhóm non-steroid (NSAID) và có nhiều tên thương mại khác nhau như Nurofen, Ebufac, Rimafen, Arthrofen, Brufen hay Fenbid. Có tác dụng hạ sốt, giảm đau đầu hay đau khớp. Thuốc được bán trực tiếp không cần qua kê đơn của bác sĩ. Đây chính là lý do tại sao bạn cần phải hiểu rõ về Ibuprofen cũng như cân nhắc về tính an toàn của thuốc khi sử dụng trong thai kỳ.
## **Sử dụng Ibuprofen trong thai kỳ có an toàn?**
Không, thai phụ không nên sử dụng Ibuprofen để giảm đau. Dù bạn chỉ sử dụng một liều duy nhất trong suốt thai kỳ và việc này thường không gây ra tác hại đáng kể, tuy nhiên, bạn vẫn cần phải thận trọng. Cục quản lý Thực phẩm và Dược phẩm Hoa Kỳ (USFDA) xếp Ibuprofen vào mức D trong những thuốc có nguy cơ ảnh hưởng lên thai nhi. Mức D có nghĩa là “Có bằng chứng cho rằng thuốc gây hại cho thai nhi, nhưng lợi ích khi sử dụng có thể chấp nhận được so với nguy cơ của thuốc”. Bảng phân loại không xác nhận tính an toàn của Ibuprofen, để biết nguyên do, hãy tiếp tục đọc nhé.
## **Tại sao sử dụng Ibuprofen trong thai kỳ lại không an toàn?**
Dưới đây là một số tác dụng phụ đi kèm khi sử dụng Ibuprofen trong quá trình mang thai. Ở giai đoạn đầu thai kỳ (khoảng 6 tháng đầu): cần tránh sử dụng Ibuprofen ở hai tam cá nguyệt đầu tiên vì đây là khoảng thời gian quan trọng cho sự hình thành các cơ quan trong cơ thể thai nhi, và cũng là giai đoạn trẻ rất nhạy cảm với độc chất cũng như dược phẩm. Những chất này có thể gây dị tật thai nhi, sảy thai và tác động xấu đến thận. Đối với tam cá nguyệt thứ hai, sử dụng Ibuprofen có thể làm cho trẻ sinh ra nhẹ cân so với bình thường.
Giai đoạn cuối thai kỳ (3 tháng cuối): Ở tam cá nguyệt cuối, Ibuprofen ngăn chặn tác dụng của prostaglandins, đây là một hóa chất trung gian giúp hạ sốt, giảm đau, kháng viêm cũng như đảm nhận một số chức năng khác. Trong khoảng thời gian chuẩn bị lâm bồn, nồng độ prostaglandins trong máu được hạ thấp, giúp đóng kín một mạch máu chỉ xuất hiện ở tim thai nhi (hay còn gọi là ống động mạch). Điều này giúp dòng máu chuyển hướng lưu thông đến phổi. Nhưng, nếu có sự xuất hiện của Ibuprofen, thuốc này khiến cho ống động mạch đóng sớm hơn bình thường, dẫn đến tăng áp phổi và cuối cùng là tử vong thai nhi.
Thuốc còn gây chuyển dạ kéo dài, chuyển dạ ngưng tiến, hay xuất huyết ồ ạt trong quá trình sinh nở.
Sử dụng liều cao kéo dài có thể gây giảm thể tích dịch ối (thiểu ối).
Nguy cơ lâu dài:
Nghiên cứu cho thấy những trẻ được sinh ra từ bà mẹ sử dụng Ibuprofen ở hai tam cá nguyệt cuối thường mắc hen suyễn sớm.
Nếu đứa trẻ là nam, thuốc làm tăng khả năng vô sinh và ung thư tinh hoàn cũng như ảnh hưởng lên chất lượng sản sinh testosterone.
Bác sĩ của bạn chỉ kê đơn Ibuprofen khi không còn lựa chọn khác an toàn hơn, và họ hi vọng rằng nguy của cơ thuốc sẽ thấp hơn so với nguy cơ gây ra bởi bệnh lý bạn đang mắc.
Tuy nhiên, vì thuốc thuộc nhóm không kê đơn, bạn thường vô tình sử dụng nó mà chưa có chỉ định của bác sĩ.
## **Phải làm thế nào nếu bạn đã lỡ sử dụng Ibuprofen trong thai kỳ?**
Nếu bạn đã sử dụng Ibuprofen được một thời gian dài, bác sĩ sẽ kiểm tra đánh giá tình hình phát triển của thai nhi.
Nếu bạn mang thai và đang trong liệu trình điều trị thuốc, hãy nói cho bác sĩ của bạn biết. Họ sẽ quyết định xem bạn có nên tiếp tục liệu trình hay phải chuyển sang một phương thức điều trị thay thế.
## **Có thuốc thay thế được cho Ibuprofen để sử dụng trong thai kỳ hay không?**
Acetaminophen đường uống (Tylenol/Paracetamol) là một lựa chọn an toàn hơn để hạ sốt và giảm đau trong thai kỳ. Bạn có thể sử dụng thuốc này ở bất kỳ thời điểm nào trong quá trình mang thai.
## **Có thể dùng Ibuprofen dạng gel trong thai kỳ không?**
Ibuprofen dạng gel vẫn không được khuyến cáo sử dụng trong thai kỳ trừ khi được khuyên dùng bởi bác sĩ. Gel có thể thẩm thấu qua bề mặt da và tác động lên thai nhi. Trước khi sử dụng bất kỳ dược phẩm nào, bạn phải luôn đảm bảo rằng nó đã được thông qua sự đồng ý của bác sĩ. Nếu không chắc chắn, tốt nhất bạn nên đến bác sĩ gia đình của mình để kiểm tra. Trong trường hợp bạn cần phải điều trị thuốc khi đang mang thai, hãy dùng chúng với liều tối thiểu.
Xem thêm: [**Ảnh hưởng của NSAIDs trên bệnh nhân lớn tuổi**](https://bvnguyentriphuong.com.vn/duoc-dien/anh-huong-cua-nsaids-tren-benh-nhan-lon-tuoi)
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [Ibuprofen là gì và tại sao được chỉ định?](https://bvnguyentriphuong.com.vn/san-phu-khoa/thuoc-giam-dau-ibuprofen-su-dung-trong-thai-ky-duoc-khong#ibuprofenl-g-v-ti-sao-c-ch-nh)
  * [Sử dụng Ibuprofen trong thai kỳ có an toàn?](https://bvnguyentriphuong.com.vn/san-phu-khoa/thuoc-giam-dau-ibuprofen-su-dung-trong-thai-ky-duoc-khong#s-dng-ibuprofen-trong-thai-k-c-an-ton)
  * [Tại sao sử dụng Ibuprofen trong thai kỳ lại không an toàn?](https://bvnguyentriphuong.com.vn/san-phu-khoa/thuoc-giam-dau-ibuprofen-su-dung-trong-thai-ky-duoc-khong#ti-sao-s-dng-ibuprofen-trong-thai-k-li-khng-an-ton)
  * [Phải làm thế nào nếu bạn đã lỡ sử dụng Ibuprofen trong thai kỳ?](https://bvnguyentriphuong.com.vn/san-phu-khoa/thuoc-giam-dau-ibuprofen-su-dung-trong-thai-ky-duoc-khong#phi-lm-th-no-nu-bn-l-s-dng-ibuprofen-trong-thai-k)
  * [Có thuốc thay thế được cho Ibuprofen để sử dụng trong thai kỳ hay không?](https://bvnguyentriphuong.com.vn/san-phu-khoa/thuoc-giam-dau-ibuprofen-su-dung-trong-thai-ky-duoc-khong#c-thuc-thay-th-c-cho-ibuprofen-s-dng-trong-thai-k-hay-khng)
  * [Có thể dùng Ibuprofen dạng gel trong thai kỳ không?](https://bvnguyentriphuong.com.vn/san-phu-khoa/thuoc-giam-dau-ibuprofen-su-dung-trong-thai-ky-duoc-khong#c-th-dng-ibuprofen-dng-gel-trong-thai-k-khng)



## ️ Nguyên tắc chung về kê đơn thuốc

Một đơn thuốc tốt phải thể hiện được các yêu cầu: Hiệu quả chữa bệnh cao, an toàn trong dùng thuốc và tiết kiệm. 
Muốn kê đơn thuốc tốt phải tuân theo quy trình sau đây
**1/ Chẩn đoán, xác định đúng bệnh:**
Thầy thuốc cần tìm hiểu hoàn cảnh của người bệnh, phát hiện các dấu hiệu lâm sàng và xét nghiệm phi lâm sàng. Cần tìm hiểu lịch sử dùng thuốc của người bệnh, đã dùng những thuốc gì, kết quả ra sao để ghi vào bệnh án. Như vậy thầy thuốc đã xác định được các vấn đề của người bệnh. Trên cơ sở đó, xác định các mục tiêu điều trị chính, phụ, trước, sau; tập trung giải quyết mục tiêu chính.
**2/ Lựa chọn thuốc phù hợp với người bệnh:**
Thầy thuốc phải tự hỏi xem những thuốc quen dùng theo kinh nghiệm bản thân trước đây liệu có hiệu quả và an toàn đối với từng người bệnh cụ thể. Ðồng thời liệt kê các thứ thuốc mà mình biết có thể điều trị phù hợp cho từng người bệnh. Nên sử dụng các thuốc đã quen dùng. Cần hỏi người bệnh về các phản ứng đã xảy ra khi dùng thuốc trong quá khứ.
Sàng lọc lần lượt các thuốc đó dựa trên các tiêu chí sau:
Thuốc có hiệu quả nhất, an toàn nhất và phù hợp với hoàn cảnh của người bệnh nhất.
Trong những trường hợp bệnh nặng thì hiệu quả là yêu cầu trước tiên. Trong những trường hợp bệnh mạn tính và thể trạng người bệnh yếu thì tiêu chuẩn an toàn phải được đặt lên hàng đầu.
**3/ Kê đơn thuốc khi đã có chỉ định rõ ràng:**
Khi kê đơn, tốt nhất là dùng tên gốc hay tên chung quốc tế kèm theo tên biệt dược đặt trong ngoặc, nếu thấy cần thiết. Phải tránh viết tắt. Khi kê hai thuốc hoặc nhiều thuốc hơn trong cùng một đơn thuốc, thuốc chính ghi đầu tiên. Nên tránh kê quá nhiều thuốc trong một đơn thuốc. Kê đơn càng ít thuốc càng tốt để tránh tương tác thuốc.
Ðơn thuốc phải viết rõ ràng bằng mực, ghi rõ ngày, tháng, năm, họ và tên, tuổi, địa chỉ, số thẻ bảo hiểm y tế của người bệnh (nếu có). Người kê đơn phải ký vào đơn bằng mực và ghi rõ họ tên.
_Các thuốc độc, thuốc hướng tâm thần và thuốc gây nghiện_ phải viết riêng trong một đơn khác, theo quy chế về quản lý thuốc độc, thuốc hướng thần và thuốc gây nghiện do Bộ Y tế ban hành. Tên thuốc, hàm lượng, số lần dùng trong ngày, liều dùng mỗi lần phải ghi rõ bằng chữ và số. Người kê đơn phải ký, đề ngày, tháng, năm và phải viết rõ tên, địa chỉ.
**4/ Hướng dẫn dùng thuốc cho người bệnh:**
Thầy thuốc cần giải thích rõ ràng và ngắn gọn bằng ngôn ngữ thông thường để người bệnh hiểu được cách dùng các thuốc đã kê (số lượng phải dùng, thời gian, số lần dùng và các điều khác như cách pha, cách dùng). Nếu phải dùng đến một dụng cụ để đưa thuốc vào cơ thể, thầy thuốc phải hướng dẫn cụ thể hoặc cùng làm với người bệnh. Thầy thuốc phải luôn luôn cảnh giác để phát hiện quá liều đối với các thuốc tác dụng mạnh kê trong đơn.
Cần dặn dò những điều kiêng cữ đối với người bệnh. Nên hết sức thận trọng khi kê đơn cho những người đang mang thai, đang cho con bú, người có tiền sử bệnh gan, thận, cơ địa dị ứng.
**5/ Thông tin về phản ứng không mong muốn của thuốc:**
Bất cứ thuốc nào cũng có thể gây tác dụng không mong muốn. Cần chú ý theo dõi, phát hiện, ghi chép các tác dụng không mong muốn.
Hướng dẫn người bệnh phát hiện những dấu hiệu của phản ứng không mong muốn, hướng dẫn cách xử trí và báo cáo.
Thầy thuốc phải hẹn ngày khám lại đối với người bệnh.
**6/ Theo dõi hiệu quả điều trị:**
Nếu người bệnh không quay lại thì có thể đơn thuốc đã có hiệu quả, bệnh đã đỡ hơn hoặc khỏi. Nếu đơn thuốc không có hiệu quả thì người bệnh có thể sẽ quay lại. Cần tìm hiểu lý do: Thuốc không hiệu quả; không an toàn, người bệnh không chịu đựng được các phản ứng phụ; không thuận tiện do cách uống, mùi vị...
Trong trường hợp này tùy từng lý do, thầy thuốc lại bắt đầu quy trình khám lại.
  * Không nên kê nhiều thuốc trong một đơn.
  * Nên kê những thuốc một thành phần. Không nên kê những thuốc hỗn hợp nhiều thành phần.
  * Nên kê đơn thuốc theo tên gốc của thuốc. Tên thương mại ghi bên cạnh, trong dấu ngoặc.
  * Nên tranh thủ sự giúp đỡ của dược sĩ để có các thông tin về thuốc.
  * Nên theo dõi những tin tức cập nhật về thuốc ở đơn vị thông tin thuốc.
  * Nên sử dụng Dược thư quốc gia Việt Nam nhằm khai thác các thông tin sử dụng thuốc hiệu quả, hợp lý, an toàn, tiết kiệm.
  * Nên đưa nội dung điều trị bằng thuốc thành chủ đề trong các cuộc họp của Hội đồng thuốc và điều trị của bệnh viện.
  * Nên hết sức thận trọng sử dụng các thông tin về thuốc từ những nguồn thông tin thương mại.
  * Nên phối hợp với dược sĩ sắp xếp các thuốc điều trị cùng nhóm, đánh giá theo 4 tiêu chuẩn: Hiệu quả, an toàn, thích hợp và giá cả. Bảng này cần luôn được cập nhật.
  * Trước khi chấp thuận nhận xét về hiệu quả của những thuốc mới, cần có những số liệu thống kê dịch tễ học về các phản ứng không mong muốn.
  * Trước khi sử dụng thuốc mới, cần có những thử nghiệm lâm sàng ngay tại cơ sở để thu thập những kinh nghiệm thực tế.
  * Ðối với người bệnh nội trú, tốt nhất là kê đơn thuốc hàng ngày.
  * Những thuốc nhiều tác dụng phụ như kháng sinh, corticoid, thuốc chống ung thư, trong đơn hoặc bệnh án nên đánh số để ghi rõ ngày dùng thuốc thứ mấy.
  * Ðể tăng tính chính xác khi sử dụng thuốc, nên sử dụng mã ATC.


**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh

## ️ Ảnh hưởng của bệnh thận đối với liều dùng và nguyên tắc điều chỉnh liều của thuốc

Rối loạn chức năng thận có thể ảnh hưởng đến trị liệu bằng thuốc vì những lý do sau:
1. Dược động học của thuốc có thể bị thay đổi do giảm đào thải các thuốc mà bình thường được thải trừ hoàn toàn hoặc chủ yếu qua thận. Bệnh thận cũng có thể làm giảm gắn kết thuốc với protein và làm thay đổi hoặc giảm chuyển hóa thuốc ở gan.
2. Hiệu quả của thuốc có thể bị thay đổi.
3. Hiện trạng lâm sàng của người bệnh có thể xấu đi.
4. Tác dụng có hại của thuốc có thể tăng lên.
**Thay đổi dược động học**
Thận là một trong những đường thải trừ chủ yếu của thuốc, do đó khi chức năng thận bị giảm thì việc thải trừ thuốc có thể bị ảnh hưởng. Về nguyên tắc, để điều chỉnh liều của thuốc cho người bị bệnh thận, trước hết cần xem loại thuốc đó có thải trừ hoàn toàn qua thận hay không và thuốc có độc hại như thế nào.
Đối với nhiều loại thuốc mà tác dụng phụ chỉ liên quan rất ít hoặc không liên quan đến liều dùng thì thường không phải tính liều điều chỉnh một cách thật chính xác mà chỉ cần một phác đồ giảm liều đơn giản.
Đối với các thuốc độc hại hơn, có khoảng an toàn hẹp thì khi thận suy phải điều chỉnh liều dựa vào mức lọc cầu thận.
Đối với các thuốc mà hiệu lực và độc tính có liên quan chặt chẽ với nồng độ thuốc trong huyết tương thì phác đồ điều trị khuyến cáo chỉ nên coi là một hướng dẫn ban đầu. Trong quá trình điều trị phải thăm dò liều cẩn thận, dựa trên đáp ứng lâm sàng và định lượng nồng độ thuốc trong huyết tương. Như vậy đối với người bị bệnh thận mà phải dùng những thuốc loại này thì cần được điều trị và theo dõi ở các bệnh viện chuyên khoa mà không nên điều trị ở các tuyến khác.
Tổng liều duy trì hàng ngày của mỗi thuốc có thể giảm xuống bằng cách hạ thấp liều dùng hàng ngày hoặc kéo dài khoảng cách giữa các liều. Đối với một số thuốc cần phải giảm liều duy trì nhưng lại muốn có tác dụng ngay thì tốt nhất là cho một liều "nạp" lớn hơn liều đầu duy trì. Bởi vì nếu cho đều đặn liều duy trì đã giảm thì phải mất hơn 5 lần nửa đời thải trừ nồng độ thuốc trong huyết tương mới đạt được trạng thái ổn định. Do nửa đời thải trừ của thuốc kéo dài ở người suy thận cho nên muốn đạt nồng độ thuốc ở trạng thái ổn định trong huyết tương thì phải mất nhiều thời gian hơn. Đối với nhiều loại thuốc, sau khi giảm liều phải mất nhiều ngày mới đạt được nồng độ điều trị trong huyết tương. Theo thường lệ thì liều "nạp" ở người suy thận có thể cho ngang liều ban đầu của người bệnh có chức năng thận bình thường, các liều tiếp theo phải giảm.
Để đánh giá tác động của rối loạn chức năng thận đối với việc sử dụng thuốc, chúng ta có thể tính độ thanh thải (clearance) của thuốc. Thuật ngữ thanh thải có thể biểu thị bằng phương trình đơn giản là clearance = K x Vd, trong đó K là hằng số thải trừ, Vd là thể tích phân bố. Hằng số thải trừ K được tính theo phương trình ln2 chia cho thời gian nửa đời thải trừ của thuốc (ln2 = 0,693), nửa đời của thuốc có ghi trong các chuyên luận thuốc của Dược thư quốc gia Việt Nam. Như vậy K = 0,693/t1/2 (K là hằng số thải trừ của thuốc tức là bằng tổng của nhiều hằng số thải trừ từng phần bao gồm thải trừ qua thận, qua gan, qua các con đường khác: K = k thận + k gan + k khác).
Thể tích phân bố Vd là một thông số biểu thị tỷ lệ thuốc hiện diện trong khoang trung tâm tức là trong huyết tương so với tổng lượng thuốc trong cơ thể và được giới thiệu trong mỗi chuyên luận thuốc của Dược thư quốc gia Việt Nam. Trong mỗi chuyên luận thuốc cũng có ghi tỉ lệ phần trăm (%) của tổng thải trừ được thải trừ qua thận và tỉ lệ được thải trừ qua gan trong điều kiện bình thường. Do đó người ta có thể dễ dàng tính được tác dụng của suy giảm hoàn toàn hoặc suy giảm một phần chức năng thận. Ví dụ nếu bình thường thuốc được thải trừ 50% qua thận và 50% chuyển hóa ở gan thì k thận = 0,5 x K, k gan = 0,5 x K. Trong trường hợp nếu chức năng thận bị giảm hoàn toàn thì có nghĩa là bị mất đi 50% phần đóng góp bình thường đối với tổng liều thải trừ K và thuốc phải chịu một nửa đời thải trừ chậm hơn: t1/2 = 0,693/(0,5 x K). Hằng số K bình thường có thể tính dễ dàng từ t1/2 bình thường có giới thiệu trong mỗi chuyên luận thuốc của Dược thư quốc gia Việt Nam (K = 0,693/t1/2).
Độ thanh thải (clearance) là một thông số biểu thị về thải trừ bao gồm cả thuốc đã được phân bố trong các mô. Người ta có thể sử dụng thông số này để phân tích xem trong suy thận thì việc thải trừ thuốc xảy ra như thế nào.
Nếu do bệnh thận mà chức năng thận (mức lọc cầu thận) bị giảm đi 50% thì phải cho giảm liều đối với một thuốc nào đó bình thường được thải trừ 100% qua thận. Có một sự khác biệt rất lớn giữa việc thuốc có thải trừ hoàn toàn qua thận hay không cho nên phải tính toán. Mặt khác để xác định mức độ điều chỉnh liều còn phải xem xét sự khác biệt về phân bố thuốc trong cơ thể. Nếu ta đơn giản hóa và giả sử thuốc chỉ được phân bố trong huyết tương thì thể tích phân bố Vd = 3 lít, nhưng thể tích phân bố có thể cao hơn nhiều với các thuốc có phân bố vào các mô.
Lấy một ví dụ trong đó thuốc chỉ phân bố trong huyết tương. Trong trường hợp này thể tích phân bố của thuốc bằng thể tích huyết tương nghĩa là bằng 3 lít. Nếu tổng mức thải trừ đối với thuốc phụ thuộc hoàn toàn vào mức lọc cầu thận (bình thường là 125 - 130 ml/phút) thì độ thanh thải tổng số của thuốc là bằng độ thanh lọc của thận tức là mức lọc cầu thận (130 ml/ph) tính theo độ thanh lọc creatinin. ở người bệnh không có tổn thương thận, ta có thể tính dễ dàng nửa đời thải trừ của thuốc như sau:
Độ thanh thải thuốc = K x Vd = K x 3 lít =130 ml/ph. Như vậy hằng số thải trừ K = 130 ml/ph: 3000 ml -> K = 0,043 phút -1. Từ đó ta tính được nửa đời thải trừ t1/2 = 0,693/K = 0,693/0,043 phút-1. Như vậy với thuốc này thì t1/2 = 16 phút nếu chức năng thận là bình thường. Khi chức năng thận (mức lọc cầu thận) giảm đi 50% so với bình thường, nửa đời thải trừ sẽ phải tăng lên 50% và như thế nửa đời thải trừ ở trường hợp này là t1/2 (mới) = 0,693/0,5x 0,043 phút -1nghĩa là t1/2 (mới) = 32 phút. Tuy nhiên nếu thuốc cũng được thải trừ một lượng lớn qua chuyển hóa ở gan thì sự giảm chức năng thận cũng ít ảnh hưởng và nửa đời thải trừ mới tính được sẽ không đến nỗi chậm nhiều như vậy.
Như đã diễn giải ở trên, nếu một thuốc bình thường được lọc thải qua thận thì nửa đời thải trừ sẽ bị kéo dài khi chức năng thận bị suy giảm. Cũng có nghĩa rằng nồng độ thuốc ở trạng thái ổn định trong huyết tương sau liều lặp đi lặp lại sẽ tăng lên theo tỷ lệ tương ứng.
Cần nắm vững điều quan trọng đặc biệt này để đề phòng các tác dụng phụ, nhất là với những thuốc có thang điều trị hẹp.
Nồng độ trung bình của thuốc ở trạng thái ổn định trong huyết tương (ký hiệu Css) sau khi uống nhiều liều liên tiếp có thể tính như sau:
Css = (Fx liều): (Vd x K x T)
Trong đó T là khoảng cách thời gian giữa các liều , F là khả dụng sinh học tức là tỷ lệ % của liều được hấp thu. Như đã thấy qua phương trình trên, nếu khoảng thời gian giữa các liều là ngắn thì nồng độ thuốc trung bình trong máu sẽ cao. Và nếu hằng số thải trừ K giảm đi chỉ còn 50% so với mức bình thường thì nồng độ Css của thuốc trong máu cũng sẽ tăng lên theo tỷ lệ. Trong phương trình trên Vd x K là bằng độ thanh thải của thuốc, do đó phương trình có thể viết lại như sau:
Css = (F x liều) : (độ thanh thải x T)
Độ thanh thải tổng cộng = thanh thải thận + thanh thải chuyển hóa + thanh thải khác.
Qua đó ta có thể thấy được chức năng thận giảm sẽ ảnh hưởng đến nồng độ thuốc ở trạng thái ổn định trong huyết tương đến một mức nào đó với một thuốc bình thường được thải trừ 100% qua thận so với thuốc chỉ được thải trừ 50% qua thận, phần còn lại được thải trừ qua chuyển hoá.
Phương trình Css = (F x liều): (Độ thanh thải x T), chỉ cho ta thấy có hai biện pháp khác nhau để điều chỉnh liều thuốc khi thận suy:
1. Điều chỉnh bằng giảm liều.
2. Điều chỉnh bằng tăng khoảng cách giữa các liều, cho các liều thưa hơn.
Nếu đánh giá được độ thanh thải của một thuốc ở người bệnh thì có thể tính liều duy trì để đạt nồng độ ở trạng thái ổn định trong huyết tương (Css) như sau :
Đối với các liều uống liên tiếp: Liều duy trì = {̀ liều Css cần đạt x độ thanh thải x T }̉ : F (khả dụng sinh học).
Đối với liều tiêm truyền: Tốc độ truyền = Css trung bình cần đạt x độ thanh thải.
Trong việc điều chỉnh liều cần phải chú ý đặc biệt đến độc tính của thuốc. Ví dụ ở các trường hợp sử dụng các kháng sinh nhóm aminoglycosid thì dù chức năng thận giảm rất ít cũng cần điều chỉnh liều. Với penicilin thì khi thận suy nặng, độ thanh lọc creatinin tức mức lọc cầu thận < 10 ml/phút mới phải điều chỉnh liều. Trong mỗi chuyên luận thuốc đều có khuyến cáo cách sử dụng thuốc khi thận suy.
**Giảm gắn kết protein** Sự giảm gắn kết protein sẽ tăng lượng thuốc tự do, gây tăng tác dụng của thuốc và cũng tăng cả tác dụng phụ. Hậu quả của sự gắn kết với albumin tương quan với mức độ suy thận, các thuốc có tính acid ít gắn với albumin huyết thanh. Sự gắn kết của các thuốc kiềm tính với protein (với alpha 1 - acid glycoprotein) không hoặc ít thay đổi khi chức năng thận giảm. Ngoài ra còn có thêm một nguy cơ làm giảm gắn kết protein là các sản phẩm nội sinh cạnh tranh gắn kết albumin với thuốc. Thẩm tách máu không đưa được khả năng gắn kết protein trở về bình thường cho những người suy thận nặng. Trong phần lớn các trường hợp thì sự thay đổi gắn kết với protein của thuốc ít tác động đến tình trạng lâm sàng và không cần điều chỉnh liều. Tuy nhiên cũng có trường hợp sự gắn kết protein lại rất quan trọng như trong điều trị động kinh bằng phenytoin. Thang điều trị của phenytoin thông thường là từ 10 - 20 mg/lít (40 - 80 micromol/lít) bao gồm cả lượng thuốc tự do hoặc có gắn kết protein. ở người suy thận phần thuốc có gắn kết giảm, phần tự do của phenytoin tăng. Do phần tự do của thuốc có tác dụng dược lý nên nồng độ toàn phần để thuốc có tác dụng phải giảm, nói một cách cụ thể thì có nghĩa là ở người suy thận nặng thang điều trị của phenytoin có thể giảm đi 1/2 tức là còn từ 5 - 10 mg/lít (tức là 20 - 40 micromol/lít).
**Chuyển hóa ở gan:** Có thể bị giảm ở một số người suy thận đối với một số thuốc như nicardipin, propranolol.
**Tăng tính nhạy cảm với thuốc:** Thường gặp ở người bệnh suy thận. Các thuốc như thuốc phiện, thuốc an thần nhóm benzodiazepin, thuốc ngủ barbiturat, phe-nothiazin đều tăng tác dụng đối với hệ thần kinh trung ương ở người bị suy thận so với ở người chức năng thận bình thường. Nguyên nhân chưa rõ nhưng cũng có thể do tăng tính thấm của hàng rào máu - não. Các thuốc hạ huyết áp cũng thường gây hạ huyết áp tư thế nhiều hơn ở người suy thận, có thể là do thay đổi cân bằng natri trong máu.
**Bệnh thận nặng lên do thuốc:** Có thể gặp ở người bệnh thận nếu thuốc đó gây rối loạn chức năng thận. Người bệnh đã có tiền sử suy thận thì không nhất thiết phải dùng các thuốc độc cho thận khi có thuốc khác thay thế được. Ví dụ như các aminoglycozid, ampho-tericin, cisplatin, vàng, mesalazin, các kháng viêm không steroid, penicilamin và vancomycin. Cũng có một số thuốc trực tiếp gây giữ nước và do đó có thể gây nặng hơn các biến chứng về tim mạch ở người bị suy thận. Như vậy nên tránh dùng các thuốc gây giữ nước như carbenoxolon và các thuốc kháng viêm không steroid như indomethacin. Điều quan trọng cần phải nói là ở người bệnh suy tim sung huyết, việc tưới máu thận phụ thuộc vào lượng prostaglandin được sản xuất tại thận. Điều trị bằng thuốc kháng viêm không steroid sẽ ức chế tác dụng tại chỗ của prostaglandin đối với thận gây giảm dòng máu qua thận làm xấu thêm chức năng thận đã suy và giữ nước. Do đó nên tuyệt đối tránh dùng thuốc kháng viêm không steroid cho người bệnh suy thận. Một số thuốc cũng gây tăng thêm urê huyết. Tetracyclin (trừ doxycyclin) có tác dụng chống đồng hóa nên không dùng.
**Tăng tác dụng có hại của thuốc:** Như với digoxin chẳng hạn, ở người suy thận nặng, kèm thêm giảm đào thải, có thể gây tác dụng có hại nhiều hơn do nguy cơ rối loạn cân bằng các chất điện giải. Đặc biệt là tăng calci huyết và/hoặc giảm kali huyết sẽ tăng nguy cơ tác dụng phụ của digoxin ở người bệnh có giảm chức năng thận. Do đào thải kali (K+) bị giảm ở người suy thận, nên các thuốc lợi tiểu giữ kali (amilorid, spirono-lacton) có thể gây tăng kali huyết nặng hơn.
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh

## ️ Chiến lược dùng thuốc cho bệnh hen

  * [Khái niệm về hen](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/chien-luoc-dung-thuoc-cho-benh-hen#khai-nim-v-hen)
  * [Cách dùng thuốc điều trị bệnh hen](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/chien-luoc-dung-thuoc-cho-benh-hen#cach-dung-thuc-iu-tri-bnh-hen)


## **Khái niệm về hen**
Y học hiện đại đã cho thấy co thắt đường thở do hen, ngoài cơn cũng như lúc lên cơn hen nặng, đều do viêm. Đường thở người hen thâm nhiễm nhiều tế bào viêm, bao gồm bạch cầu ưa eosin, đại thực bào và lympho bào. Ngay cả ở người hen có chức năng phổi bình thường lúc ngoài cơn và không có cơn hen nào mới xảy ra, cũng có một lượng lớn bạch cầu ưa eosin và các tế bào viêm khác ở đường thở. Điều này đúng với cả hen dị ứng và không do dị ứng. Sau tiếp xúc với dị nguyên, số lượng tế bào viêm gia tăng thêm ở người hen dị ứng.
So sánh với người bình thường, người hen cũng có thành đường thở dày hơn và tế bào viêm tăng hơn ở mô phổi. Cơ chế viêm nói trên còn chưa hoàn toàn sáng tỏ. ở khoảng 50% trẻ em và một tỷ lệ nhỏ hơn nhiều ở người lớn, có thể xác định được dị nguyên tiếp xúc gây ra hen. ở những người bệnh này, tiếp xúc với dị nguyên đã ít nhiều gây viêm trong hen, thông qua phản ứng loại quá mẫn tức thì (týp I). Đại đa số người lớn hen, và khoảng 50% trẻ em bị hen, không xác định được ngay các thành phần dị ứng đối với hen. Tuy nhiên, nghiên cứu dịch tễ học cho thấy có tương quan giữa mức IgE tăng và tỷ lệ mắc bệnh hen, và đại đa số các trường hợp hen thực sự có thể do một thành phần dị ứng tuy không dễ xác định được bằng các test da thông thường.
Hen dị ứng đã được dùng làm mô hình để nghiên cứu chung bệnh hen, một phần vì có thể gây được các cơn hen bằng tiếp xúc với dị nguyên thích hợp. Nghiên cứu kỹ cơ chế hen dị ứng cho phép hiểu thấu đáo cách tiếp cận điều trị hợp lý đối với hen. IgE đặc hiệu đối với dị nguyên gắn vào dưỡng bào thông qua thụ thể Fc. Khi dị nguyên tiếp xúc với IgE, dưỡng bào được hoạt hóa và giải phóng một lượng lớn chất trung gian gây viêm. Cơ chế bao gồm giải phóng các chất chứa trong các hạt của dưỡng bào sản xuất cytokin. Nhiều chất trung gian được giải phóng, mỗi hợp chất đều có một số tác dụng đến viêm đường thở.
Tác dụng bao gồm giãn mạch và tăng tính thấm mạch, và tăng nhiều tế bào viêm hơn vào các mô phổi, chủ yếu lympho bào, bạch cầu ưa eosin và đại thực bào. Một khi các tế bào mới bổ sung thêm này vào tới phổi, các tế bào này cũng lại giải phóng các chất trung gian của bản thân mình, làm tăng thêm tác dụng viêm. Viêm trong hen có đặc tính là tăng tính phản ứng của phế quản, vì vậy khác với viêm trong các bệnh khác, như trong viêm phổi. Kết quả lâu dài là phù nề đường thở, phì đại cơ trơn, tế bào biểu mô bong rụng, và tăng tính phản ứng của phế quản đối với những tác nhân kích thích không đặc hiệu như mùi nặng, không khí lạnh, ô nhiễm và histamin. Viêm đường thở do hen cũng thường gây tăng hẹp phế quản do đối giao cảm.
Cơ chế hen nói trên cho thấy trước rằng một thuốc chỉ tác động đến một chất trung gian, không chắc có lợi ích nhiều, đơn giản là vì có nhiều chất trung gian tham gia. Thí dụ, rõ ràng histamin được giải phóng trong phản ứng hen dị ứng, nhưng thuốc kháng histamin lại không có ích lợi trong hen dị ứng. Thực tế, thuốc kháng histamin có khả năng gây suy hô hấp, nên không thích hợp để dùng điều trị hen.
Điều trị hen, theo mô tả bệnh trên đây, cần sử dụng glucocorticoid để chống lại sự huy động các tế bào viêm. Liệu pháp glucocorticoid được coi như một điều trị dự phòng cần thiết để ngăn ngừa bệnh nặng hơn. Tuy nhiên đối với hen cấp, glucocorticoid có tác dụng rất hạn chế, vì vậy, thuốc đầu tiên được chọn là các thuốc chủ vận thụ thể beta2, như salbutamol. Ngoài ra đối với thành phần cholinergic của co thắt phế quản, ipratropium thường là thuốc điều trị thêm có ích, đặc biệt đối với người dùng salbutamol hoặc terbutalin không đủ tác dụng, khi người đó không thể dung nạp salbutamol hoặc terbutalin liều cao hơn. ở những trường hợp đó, phối hợp salbutamol và ipratropium thường là cách điều trị có ích. Trong y học hiện đại, theophylin không phải là thuốc đầu tiên được chọn. Thuốc này chỉ dành để dùng cho các trường hợp rất nặng, vì thuốc có nguy cơ gây loạn nhịp tim nặng.
## **Cách dùng thuốc điều trị bệnh hen**
Người bệnh phải được hướng dẫn cẩn thận cách dùng bình khí dung dưới áp lực và điều quan trọng phải kiểm tra xem họ có tiếp tục dùng đúng không, vì kỹ thuật không đúng có thể lầm là thuốc không tác dụng. Đặc biệt, phải nhấn mạnh là họ phải hít vào chậm và nhịn thở trong 10 giây sau khi hít. Phần lớn người bệnh được hướng dẫn sử dụng thành công. Nhưng một số người, đặc biệt người cao tuổi, người bệnh khớp, và trẻ nhỏ không thể dùng được bình khí dung; một số người bệnh không thể thở đồng nhịp với lúc làm khí dung. Đối với những người bệnh đó, hiện nay đã có nhiều loại bình khí dung khởi động do thở và phễu để thở. Cách khác, bình hít bột khô được khởi động khi người bệnh hít vào cũng có giá trị; một số bình đôi khi gây ho.
Liều lượng phải được nói rõ ràng bằng số lượng hít mỗi lần, tần số, và số lần tối đa được phép hít trong 24 giờ. Liều cao thuốc kích thích beta2 có thể nguy hiểm đối với một số người bệnh. Dùng quá mức thường chứng tỏ điều trị hen không thỏa đáng và phải dùng thuốc dự phòng như corticosteroid hít. Người bệnh được khuyên đi khám thầy thuốc khi không đạt được mức độ đỡ triệu chứng thường lệ, vì điều này thường chứng tỏ hen nặng lên và có thể đòi hỏi phải dùng thuốc khác. Khi người bị hen không được kiểm soát thoả đáng bằng hít thuốc kích thích beta2 1 hoặc 2 lần mỗi ngày, cần phải xem xét dùng thêm thuốc dự phòng như corticosteroid hít; điều này thuận lợi đối với người bệnh hơn là dùng liều thuốc kích thích beta2 cao hơn và thường cho phép kiểm soát toàn bộ tốt hơn.
Dung dịch salbutamol và terbutalin cho máy thở (hoặc máy phun mù) được dùng để điều trị hen cấp ở cả bệnh viện và trong thực hành chung. ở bệnh viện dùng máy phun mù hoạt động bằng oxygen trong thời gian khoảng 15 phút. Máy nén khí chạy điện là phù hợp nhất để dùng tại nhà nhưng máy đắt tiền. Người có cơn hen nặng phải thở oxygen, nếu có thể, trong khi phun mù vì thuốc kích thích beta2 có thể gây tăng tình trạng giảm oxygen huyết động mạch. Tuy vậy, đối với người bị viêm phế quản mạn và tăng carbon dioxid huyết, oxygen có thể nguy hiểm và máy phun mù phải hoạt động bằng không khí. Liều kê đơn cho máy phun mù cao hơn nhiều so với liều kê đơn cho bình khí dung có liều định lượng. Thí dụ, một ống phun mù Ventolin 2,5 ml chứa 2,5 mg salbutamol là tương đương với 25 xịt của bình khí dung. Do đó, người bệnh cần phải được cảnh báo sẽ nguy hiểm nếu vượt liều quy định và nếu họ không đáp ứng với liều thông thường dung dịch dùng cho máy thở, họ phải đi khám.
**Mang thai và cho con bú:** Điều đặc biệt quan trọng là hen phải được kiểm soát tốt khi mang thai; nếu đạt được thì hen không gây tác hại quan trọng đến thai kỳ, lúc chuyển dạ hoặc thai nhi.
Cho thuốc bằng đường hít trong khi mang thai có lợi đặc biệt vì có thể đạt được tác dụng điều trị mà không cần có nồng độ thuốc trong huyết tương khả dĩ có tác dụng dược lý đến thai nhi.
Cơn hen trầm trọng có thể tác hại đến thai kỳ, phải được điều trị nhanh bằng liệu pháp thông thường, bao gồm corticosteroid uống hoặc tiêm và phun mù thuốc kích thích chọn lọc beta2 adrenergic; corticosteroid uống được ưa thích là prednisolon vì thuốc qua nhau thai chậm hơn so với một vài thuốc khác.
Tuy theophylin đã được dùng, nói chung không gây tác dụng phụ nào trong thai kỳ hoặc trong thời gian cho con bú, nhưng đôi khi cũng có thông báo về độc tính với thai nhi và trẻ mới sinh.
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [Khái niệm về hen](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/chien-luoc-dung-thuoc-cho-benh-hen#khai-nim-v-hen)
  * [Cách dùng thuốc điều trị bệnh hen](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/chien-luoc-dung-thuoc-cho-benh-hen#cach-dung-thuc-iu-tri-bnh-hen)



## ️ Sử dụng các thuốc kháng virus ở người bệnh bị HIV/AIDS

  * [Sử dụng thuốc kháng retrovirus](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/su-dung-cac-thuoc-khang-virus-o-nguoi-benh-bi-hivaids#s-dng-thuc-khang-retrovirus)
  * [Điều trị nhiễm HIV/AIDS](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/su-dung-cac-thuoc-khang-virus-o-nguoi-benh-bi-hivaids#iu-tri-nhim-hivaids)


## **Sử dụng thuốc kháng retrovirus**
Các thuốc hàng đầu điều trị retrovirus là các thuốc loại tương tự nucleosid. Hiện nay, người ta chưa biết lúc nào là lúc tốt nhất để bắt đầu điều trị bằng các thuốc kháng retrovirus. Tuy nhiên, với người mang thai việc dùng thuốc thích hợp có thể ngăn chặn truyền bệnh từ mẹ sang con. Người ta đã thấy nhờ điều trị bằng thuốc kháng retrovirus có thể kéo dài cuộc sống của người bệnh có lượng tế bào CD4 dưới 500 tế bào/mm3 hoặc có số lượng virus lớn hơn 10.000 virus/ml.
Cũng nên điều trị bằng thuốc kháng retrovirus đối với những người nhiễm HIV có số lượng virus trên 30.000/ml huyết tương mà không cần xét đến số lượng tế bào CD4 vì số lượng virus là một chỉ báo độc lập để tiên lượng tiến triển của bệnh. Số lượng virus càng nhiều làm cho số lượng tế bào CD4 giảm càng nhanh. Cần bắt đầu điều trị nhằm mục đích làm giảm số lượng virus tới mức không phát hiện được. Điều trị chuẩn hiện nay gồm hai thuốc kháng retrovirus, loại tương tự nucleosid, kết hợp với một thuốc ức chế protease. Cần kết hợp ít nhất hai thuốc tương tự nucleosid nhằm ngăn ngừa sự phát triển nhanh chóng của các virus kháng thuốc. Để có hiệu quả lâu bền, điều trị một cách linh hoạt là điều quyết định. Nếu người bệnh không đáp ứng với điều trị (lượng virus tăng lên 3 lần hoặc số lượng CD4 giảm hoặc bệnh chuyển sang AIDS) thì phải chuyển sang kết hợp các thuốc nucleosid kháng retrovirus khác. Cần phải lựa chọn kết hợp mới sao cho nguy cơ kháng chéo với điều trị trước đây là tối thiểu. Trong trường hợp này, giống như nguyên tắc điều trị lao, không được dùng chỉ một thứ thuốc vì virus sẽ nhanh chóng kháng lại thuốc kháng virus.
Nếu điều trị không có hiệu quả và cần phải thêm một thuốc mới thì nguyên tắc cũng là không thêm chỉ một thứ thuốc mà là bổ sung kết hợp hai thứ thuốc mới. Cần xem xét nguy cơ do tương tác thuốc khi điều trị bằng các thuốc kháng retrovirus. Xem từng thuốc trong các chuyên luận thuốc.
Thuốc nucleosid ức chế enzym sao chép ngược và các tên viết tắt:
Zidovudin (AZT)
Didanosin (ddI)
Zalcitabin (ddC)
Lamivudin (3TC)
Stavudin (d4T)
Thuốc ức chế enzym sao chép ngược không phải nucleosid:
Nevirapin
Delaviridin
Thuốc ức chế protease:
Saquinavir
Ritonavir
Indinavir
Nelfinavir
**_Các chống chỉ định quan trọng_**
Zidovudin: Thiếu máu và giảm bạch cầu trung tính là các biến chứng tiềm tàng; do đó cần phải xem xét thận trọng khi dùng cho người bệnh mà khả năng tăng hoạt động của tủy xương bị hạn chế.
Didanosin: Không dùng cho người bệnh có tiền sử viêm tụy hay người đã mắc bệnh thần kinh.
Zalcitabin: Không nên dùng cho người bị bệnh thần kinh ngoại biên từ trước.
Lamivudin: Xem chuyên luận.
Stavudin: Cần coi các bệnh về thần kinh là chống chỉ định tương đối giống như đối với zalcitabin.
Delaviridin: Tác dụng không mong muốn thường gặp nhất là nổi mẩn, nhiễm độc gan, nhức đầu, buồn nôn và mệt mỏi. Ngoài ra còn có tăng lipid huyết, rối loạn phân bố mỡ, không dung nạp glucose. Do đó, cần đánh giá cẩn thận các yếu tố đó trước và trong khi dùng thuốc ở các người bệnh bị rối loạn các thông số trên.
Saquinavir: Tương tự như delaviridin và xem thêm ở chuyên luận về thuốc này.
Ritonavir: Tương tự như delaviridin và xem thêm chuyên luận về thuốc này.
Indinavir: Tác dụng không mong muốn hay gặp nhất là sỏi thận bao gồm cả đau, kèm theo hoặc không kèm theo đái ra máu. Cần dặn người bệnh uống nhiều nước, ít nhất 2 lít mỗi ngày để giảm thiểu nguy cơ này. Không dùng thuốc này để điều trị cho người bệnh bị suy giảm chức năng thận và bị suy tim do không điều chỉnh được lượng nước phải uống gắng sức.
(Một số loại thuốc khác cần xem thêm chuyên đề riêng)
## **Điều trị nhiễm HIV/AIDS**
Hiện nay, chúng ta chưa có điều kiện để đo nồng độ virus trong huyết thanh, do đó mọi quyết định điều trị dựa vào các biểu hiện lâm sàng và số lượng tế bào CD4 trong máu.
Bệnh viện (cơ sở điều trị) thực hiện điều trị người bệnh nhiễm HIV/AIDS theo hướng dẫn, đồng thời phối hợp với các cơ quan liên quan để tổ chức theo dõi và quản lý tốt người bệnh nhiễm HIV/AIDS tại cộng đồng.
Phương hướng điều trị:
Điều trị kháng retrovirus (kháng HIV).
Điều trị chống nhiễm khuẩn cơ hội.
Chăm sóc, dinh dưỡng, nâng cao thể trạng.
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [Sử dụng thuốc kháng retrovirus](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/su-dung-cac-thuoc-khang-virus-o-nguoi-benh-bi-hivaids#s-dng-thuc-khang-retrovirus)
  * [Điều trị nhiễm HIV/AIDS](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/su-dung-cac-thuoc-khang-virus-o-nguoi-benh-bi-hivaids#iu-tri-nhim-hivaids)



## ️ Tác dụng không mong muốn của thuốc chữa viêm mũi dị ứng

  * [1. Thuốc chữa viêm mũi dị ứng](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/tac-dung-khong-mong-muon-cua-thuoc-chua-viem-mui-di-ung#1-thuc-cha-vim-mi-d-ng)
  * [2. Tác dụng không mong muốn của thuốc chữa viêm mũi dị ứng](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/tac-dung-khong-mong-muon-cua-thuoc-chua-viem-mui-di-ung#2-tc-dng-khng-mong-mun-ca-thuc-cha-vim-mi-d-ng)
  * [2.1. Tác dụng không mong muốn của nhóm thuốc Corticoid](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/tac-dung-khong-mong-muon-cua-thuoc-chua-viem-mui-di-ung#21-tc-dng-khng-mong-mun-ca-nhm-thuc-corticoid)
  * [2.2. Tác dụng không mong muốn của nhóm thuốc kháng histamine:](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/tac-dung-khong-mong-muon-cua-thuoc-chua-viem-mui-di-ung#22-tc-dng-khng-mong-mun-ca-nhm-thuc-khng-histamine)
  * [2.3. Tác dụng không mong muốn của nhóm thuốc co mạch:](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/tac-dung-khong-mong-muon-cua-thuoc-chua-viem-mui-di-ung#23-tc-dng-khng-mong-mun-ca-nhmthucco-mch)
  * [2.4.Tác dụng không mong muốn của nhóm thuốc kháng sinh:](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/tac-dung-khong-mong-muon-cua-thuoc-chua-viem-mui-di-ung#24tc-dng-khng-mong-mun-ca-nhmthuc-khng-sinh)
  * [2.5. Nhóm thuốc nhỏ rửa mũi:](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/tac-dung-khong-mong-muon-cua-thuoc-chua-viem-mui-di-ung#25-nhm-thuc-nh-ra-mi)


## **1. Thuốc chữa viêm mũi dị ứng**
Như đã nói ở trên, các thuốc chữa viêm mũi dị ứng hiện nay chỉ có tác dụng giảm nhẹ triệu chứng. Các nhóm thuốc dùng trong điều trị viêm mũi dị ứng và tác dụng:
  * Nhóm Corticoid: Tác dụng chống viêm nhanh chóng làm giảm sưng nề, nghẹt, ngứa mũi, chảy nước mũi…
  * Nhóm kháng histamine: Những thuốc này giúp làm giảm các triệu chứng chảy nước mũi, tắc mũi hay khó thở.
  * Nhóm thuốc co mạch: Tác dụng chính của nhóm này giúp giảm sưng, viêm niêm mạc mũi. Nhờ đó cũng giúp ức chế tình trạng nhiễm trùng và giảm các biểu hiện gây khó chịu
  * Nhóm thuốc nhỏ rửa mũi: thường là nước muối sinh lý có thành phần Nacl 0,9% giúp làm sạch, thông thoáng đường thở.
  * Kháng sinh: Điều trị các nhiễm khuẩn kèm theo hoặc bội nhiễm


## **2. Tác dụng không mong muốn của thuốc chữa viêm mũi dị ứng**
Bên cạnh tác dụng chữa bệnh, hầu hết các thuốc đều có những tác dụng không mong muốn. Đặc biệt, các thuốc chữa viêm mũi dị ứng càng có nhiều tác dụng phụ và tác dụng ngoại ý.
### **2.1. Tác dụng không mong muốn của nhóm thuốc Corticoid**
Những thuốc corticoid thường gặp là fluticason, beclomethason, budesonide. Chúng đa phần được bào chế ở dạng thuốc hít. Thuốc vào cơ thể dưới dạng hạt nhỏ li ti, bám vào niêm mạc mũi, tạo ra các tác dụng tại chỗ. Những thuốc dạng này có ưu thế do với dạng uống là chỉ cần một liều nhỏ và tác dụng nhanh chóng. Điều này giúp giảm các nguy cơ gây hại gan, thận so với việc sử dụng thuốc đường uống.
Tuy nhiên, hạn chế là trong nhiều trường hợp nghẹt mũi, thuốc bị ngăn cản tới vị trí cần tác dụng. Những thuốc corticoid nói chung có rất nhiều tác dụng không mong muốn:
  * Corticoid làm chậm lành vết thương. Những trường hợp có tổn thương đường hô hấp (xây xước, rách, mới phẫu thuật) không nên sử dụng thuốc.
  * Corticoid gây ức chế miễn dịch, do đó cần thận trọng khi chỉ định đối với bệnh nhân lao, suy giảm miễn dịch…Cũng vì lý do này, người bệnh sử dụng các thuốc corticoid dạng hít lâu dài có thể có nguy cơ nhiễm nấm Candida.
  * Corticoid cũng có thể làm giảm hiệu lực của kháng sinh. Bởi vậy, cần cân nhắc và tính toán kĩ đối với liều sử dụng nếu kết hợp cả 2 loại thuốc này.
  * Corticoid có thể gây các triệu chứng như đau đầu, viêm họng, hắt hơi, buồn nôn, nôn, chảy máu cam, phát ban da, ngứa, sưng mặt,…
  * Sử dụng các thuốc corticoid dạng hít kéo dài hoặc kết hợp với dạng uống không theo đúng chỉ định có thể gây ra tình trạng ngộ độc toàn thân
  * Các thuốc corticoid điều trị viêm mũi dị ứng đường uống có thể có gây hại cho thai.


### **2.2. Tác dụng không mong muốn của nhóm thuốc kháng histamine:**
Những thuốc kháng histamine thường dùng chữa viêm mũi dị ứng là chlopheniramin, alimemaxin, promethazin, diphenylhydramin, dimenhydrinat hay cinarizin… Những thuốc này đều có đặc điểm dễ gây buồn ngủ, do đó có ảnh hướng tới học tập, lao động và sinh hoạt. Cần cân nhắc khi sử dụng vào ban ngày. Các thuốc thế hệ mới hơn thuộc nhóm này có thể kể để như loratidin, acrivastin hay fexofenadine. Những loại thuốc này cải thiện được nhược điểm của thế hệ cũ. Mặc dù ít gây buồn ngủ hơn, nhưng vẫn có thể khiến người dùng thiếu tỉnh táo.
### **2.3. Tác dụng không mong muốn của nhóm thuốc co mạch:**
Những thuốc co mạch điều trị viêm mũi dị ứng khá phổ biến về hình thức cũng như đường dùng.
  * **Nhóm các thuốc co mạch dạng uống** gồm những thuốc cường giao cảm được dùng riêng lẻ như ephedrine hoặc thuốc được sử dụng trong thành phần của thuốc cảm như pseudoepherein, phenylephrin, phenylpropanolamine… Những thuốc này có tác dụng giảm sung huyết, giảm nghẹt mũi nhanh chóng và rõ rệt. Tuy nhiên, cũng chính tác dụng cường giao cảm mang tới nhiều những tác dụng không mong muốn. Những tác dụng ngoại ý phổ biến nhất như tăng huyết áp, mạch nhanh, trống ngực, đau thắt ngực, đau đầu, choáng váng, khó ngủ, chán ăn, run chân tay hay buồn nôn… Những tác dụng kể trên đặc biệt nguy hiểm, nhất là với người mắc bệnh tăng huyết áp, bệnh mạch vành, đái tháo đường và cường giáp.
  * **Nhóm các thuốc co mạch dạng nhỏ, xịt,** được dùng phổ biến hơn cả. Các thuốc nhóm này gặp nhiều trên thị trường là naphazolin, xylomethazolin,… Tương tự các thuốc bên trên, tác dụng cường giao cảm mang lại hiệu quả co mạch tại chỗ nhanh chóng. Bệnh nhân rất nhanh hết cảm giác phù nề, nghẹt mũi. Tuy nhiên, nếu sử dụng thuốc kéo dài, hiệu quả thuốc giảm dần đến không còn tác dụng.. Thậm chí, nếu sử dụng thuốc trong một thời gian dài có thể gây “phản ứng dội ngược”. Người bệnh có thể bị nghẹt mũi trở lại do dùng thuốc. Nếu sử dụng thuốc liều cao hoặc lâu dài, lượng thuốc tích lũy trong cơ thể có thể gây các tác dụng không mong muốn như nhóm thuốc co mạch dạng uống kể trên.


### **2.4.Tác dụng không mong muốn của nhóm thuốc kháng sinh:**
Đối với những trường hợp viêm mũi dị ứng có nhiễm khuẩn thường được sử dụng thêm kháng sinh bên cạnh các thuốc chữa triệu chứng. Việc sử dụng kháng sinh trong bệnh này cũng có nguy cơ gặp các tác dụng không mong muốn như: sốc phản vệ, phản ứng dị ứng, bội nhiễm kháng thuốc… Ngoài ra, một số kháng sinh có tác dụng phụ tới những cơ quan cụ thể. Ví dụ tác dụng gây rối loạn tiêu hóa (erythromycin), thính giác (aminoglycoside), gây độc hệ tạo máu (cloramphnicol), ảnh hưởng tới xương, răng (tetracyclin)…
### **2.5. Nhóm thuốc nhỏ rửa mũi:**
Nước muối sinh lý được dùng để nhỏ, rửa mũi rất phổ biến. Loại thuốc này khá lành tính và có thể sử dụng cho gần như tất cả đối tượng mà không gây phản ứng phụ.
## **3. Kết luận**
Tóm lại, khi sử dụng bất cứ loại thuốc nào đều cần có sự lựa chọn và cân nhắc thật kỹ, nhất là các thuốc chữa viêm mũi dị ứng. Một số lưu ý khi điều trị viêm mũi dị ứng:
  * Cần sử dụng theo chỉ định của bác sỹ
  * Dùng thuốc sớm khi bệnh còn nhẹ
  * Không dùng thuốc kéo dài.
  * Sử dụng với liều cho phép, trong thời gian vừa đủ
  * Những bệnh nhân mắc bệnh mạch vành, huyết áp, đái tháo đường… không nên sử dụng thuốc co mạch
  * Bệnh nhân mắc các bệnh virus, suy giảm miễn dịch cần cân nhắc khi dùng các thuốc corticoid


Ngoài ra, đối với các bệnh nhân viêm mũi dị ứng, điều quan trọng là hạn chế tiếp xúc các tác nhân gây bệnh, giữ môi trường sống sạch sẽ, khô ráo… để phòng phát bệnh.
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [1. Thuốc chữa viêm mũi dị ứng](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/tac-dung-khong-mong-muon-cua-thuoc-chua-viem-mui-di-ung#1-thuc-cha-vim-mi-d-ng)
  * [2. Tác dụng không mong muốn của thuốc chữa viêm mũi dị ứng](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/tac-dung-khong-mong-muon-cua-thuoc-chua-viem-mui-di-ung#2-tc-dng-khng-mong-mun-ca-thuc-cha-vim-mi-d-ng)
  * [2.1. Tác dụng không mong muốn của nhóm thuốc Corticoid](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/tac-dung-khong-mong-muon-cua-thuoc-chua-viem-mui-di-ung#21-tc-dng-khng-mong-mun-ca-nhm-thuc-corticoid)
  * [2.2. Tác dụng không mong muốn của nhóm thuốc kháng histamine:](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/tac-dung-khong-mong-muon-cua-thuoc-chua-viem-mui-di-ung#22-tc-dng-khng-mong-mun-ca-nhm-thuc-khng-histamine)
  * [2.3. Tác dụng không mong muốn của nhóm thuốc co mạch:](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/tac-dung-khong-mong-muon-cua-thuoc-chua-viem-mui-di-ung#23-tc-dng-khng-mong-mun-ca-nhmthucco-mch)
  * [2.4.Tác dụng không mong muốn của nhóm thuốc kháng sinh:](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/tac-dung-khong-mong-muon-cua-thuoc-chua-viem-mui-di-ung#24tc-dng-khng-mong-mun-ca-nhmthuc-khng-sinh)
  * [2.5. Nhóm thuốc nhỏ rửa mũi:](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/tac-dung-khong-mong-muon-cua-thuoc-chua-viem-mui-di-ung#25-nhm-thuc-nh-ra-mi)



## ️ 20 loại thuốc kháng viêm và những lưu ý chung

1. Floctafenin là loại giảm đau đơn thuần, tức không có tác dụng hạ sốt và kháng viêm. Thường được dùng trong 1 số trường hợp như đau răng, đau đầu do viêm xoang…. 
2. Dị ứng với Paracetamol không có nghĩa là dị ứng với NSAID, dù Paracetamol là dẫn xuất Anilin, một số tài liệu xếp nó vào nhóm NSAID, mặc dù tác dụng kháng viêm của paracetamol là rất ít. Vậy nên, khi dị ứng với Paracetamol có thể giảm đau hạ sốt bằng Ibuprofen. 
3. Các thuốc không chọn lọc trên COX không có nghĩa là không gây hại trên tim mạch. Đã có báo cáo về tác dụng phụ trên tim mạch của Diclofenac và Ibuprofen khi dùng liều cao. Vậy nên, khi sử dụng các loại này cần phải tuân thủ nghiêm ngặt về liều và những bệnh nhân có tiền sử tim mạch.
4. Nguyên tắc dùng giảm đau kháng viêm Non-steroid là dùng ở liều thấp có tác dụng, không nên dùng liều cao ngay từ đầu. 
5. Aspirin hiện nay chủ yếu được dùng liều thấp (dạng viên 81mg) làm thuốc chống đông máu, giảm nguy cơ hình thành cục máu đông trong các bệnh tim mạch hơn là dùng với tác dụng giảm đau hạ sốt. 
6. Diclofenac có 2 gốc muối là Natri và kali, gốc Kali là loại có sự hấp thu và cho tác dụng nhanh, nên thường được dùng để điều trị các triệu chứng như đau răng, đau bụng kinh, Chế phẩm thường dùng là Cataflam. Còn Voltaren là loại có gốc muối Natri, có dạng Voltaren SR, phóng thích kéo dài. 
7. Ngoài tác dụng hạ sốt và kháng viêm, chống kết tập tiểu cầu, Aspirin còn có tác dụng khác là tiêu sừng, nên thường xuất hiện trong các dạng kem bôi chàm, vẩy nến, nấm da. Hoặc các chị em phụ nữ dùng Aspirin như là 1 loại dược chất trong kem trộn, để giúp cho da mỏng ( Acid Acetylsalicylic có tác dụng bào mòn ở nồng độ cao ). Một ứng dụng khác của Aspirin đó là dùng để cắm hoa, tính acid trong aspirin sẽ làm cho hoa tươi lâu hơn. 
8. Các loại chọn lọc trên COX 1 như Mefenamic, Ibuprofen, Diclofenac thường gây hại dạ dày nhiều hơn loại chọn lọc trên COX 2, cần thận trọng khi dùng những loại trên cho bệnh nhân có tiền sử viêm loét dạ dày. 
9. Meloxicam được xem là ít tác dụng phụ trên dạ dày và tim mạch hơn các loại chọn lọc trên COX 2 khác. 
10. Corticoid có 3 tác dụng chính trong điều trị là Kháng viêm, kháng dị ứng, và ức chế miễn dịch. Tuy nhiên, liều ức chế miễn dịch thường cao hơn nhiều so với liều kháng viêm và kháng dị ứng.
11. Methylprednisolon là loại có vị khá là đắng, và rất khó uống, các chế phẩm trên thị trường hiện chưa che được vị này. 
12. Prednisolon cũng có vị đắng, tuy nhiên 1 số chế phẩm đã che bớt vị đắng của loại này, ít ra nó không đắng như Methylprednisolon. 
13. Corticoid nên dùng vào lúc 6-8h sáng, không nên dùng nhiều lần/ngày và kéo dài vì khả năng ảnh hưởng đến tuyến thượng thận. 
14. Corticoid có tác dụng gây thèm ăn, vì tác động trên hệ thần kinh, kích thích gây thèm ăn, và tác dụng trên hệ tiêu hoá gây tăng tiết dịch vị, làm bụng cồn cào và muốn ăn. 
15. Nếu dùng corticoid với liều cao trong dài ngày, khi ngưng thuốc không giảm liều thì nguy cơ suy tuyến thượng thận cấp. 
16. Không kết hợp Corticoid với NSAID, vì nếu nhìn vào sơ đồ viêm, thì corticoid đã ngăn chặn quá trình hình thành Acid arachidonic, chính vì thế sẽ không sinh ra Prostaglandin, NSAID không có vai trò gì khi dùng chung. 
17. Diacerin là loại kháng viêm có tác động thông qua ức chế chất hóa học interleukin-1β, có tác dụng chống viêm, điều trị viêm xương, thoái hóa khớp. 
18. Kháng viêm dạng viêm như Alpha chymotrypsil, Lysozym không có vai trò trên khớp, vậy nên 2 loại này thường dùng trong các trường hợp tụ máu bầm, chấn thương phần mềm. 
19. Kháng viêm dạng men như Alpha chymotrypsil sinh khả dụng đường uống không tốt, nên thường đặt dưới lưỡi để hấp thu tốt hơn. 
20. Bromelain là loại kháng viêm dạng men, tuy nhiên nó có tác dụng trội hơn trong bệnh lý về khớp, nên 1 số thực phẩm chức năng thường có chứa thành phần này
Xem thêm: [**NSAID và bệnh lý dạ dày**](https://bvnguyentriphuong.com.vn/noi-tieu-hoa/nsaid-va-benh-ly-da-day)
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh

## ️ Ngộ độc Paracetamol: Những nguyên nhân thường gặp và cách phòng tránh

  * [Tại sao paracetamol có thể gây độc?](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/ngo-doc-paracetamol#ti-sao-paracetamol-c-th-gy-c)
  * [Lý do nào làm tỷ lệ ngộ độc tăng cao?](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/ngo-doc-paracetamol#l-do-no-lm-t-l-ng-c-tng-cao)
  * [Làm thế nào để tránh ngộ độc?](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/ngo-doc-paracetamol#lm-th-no-trnh-ng-c)


Tuy nhiên khi dùng quá liều có thể gây ngộ độc, chủ yếu là gây hoại tử tế bào gan. Ở Việt Nam, theo thống kê của Trung tâm Chống độc BV Bạch Mai, trong 2 năm 2002 – 2004, tỷ lệ ngộ độc paracetamol đứng hàng thứ 2 trong các trường hợp ngộ độc thuốc.
## **Tại sao paracetamol có thể gây độc?**
Với liều điều trị, sau uống khoảng 1 giờ, thuốc được hấp thu hoàn toàn. Khi dùng quá liều, thuốc được hấp thu hết sau 4 giờ, ngoại trừ khi bệnh nhân uống đồng thời các thuốc làm chậm quá trình rỗng dạ dày và khi thuốc ở dạng giải phóng chậm thì thời gian hấp thu lâu hơn.
Thuốc được chuyển hoá ở gan với một tốc độ đều đặn. Quá trình chuyển hoá thuốc là căn nguyên dẫn đến ngộ độc. Khi qua gan, có khoảng 4% lượng paracetamol chuyển thành N-acetylbenzoquinonimin là chất độc gây hoại tử gan không hồi phục.
Nhờ có glutathion của gan, N-acetylbenzoquinonimin được chuyển hóa thành chất không độc đào thải ra ngoài. Do đó, mỗi lần dùng paracetamol (dù ở liều thông thường), cơ thể sẽ mất một lượng glutathion.
Khi dùng quá liều paracetamol (người lớn 6 – 10g/ngày), gan không đủ lượng glutathion để giải độc, N-acetylbenzoquinonimin tích lại sẽ phân hủy tế bào gan, dẫn đến hoại tử không hồi phục, nhiễm toan chuyển hóa, hôn mê có thể dẫn đến tử vong.
## **Lý do nào làm tỷ lệ ngộ độc tăng cao?**
Có quá nhiều biệt dược: Do có nhiều ưu điểm nên paracetamol đã được các nhà bào chế phối hợp với nhiều dược chất khác tạo ra hàng trăm biệt dược. Có các loại biệt dược: chỉ chứa paracetamol như efferalgan nhưng cũng có loại phối hợp với từ 2 – 7 dược chất khác.
Cần lưu ý đến những biệt dược có thêm thành phần phenobarbital sẽ làm tăng độc tính của paracetamol với gan; những chế phẩm có thêm thành phần phenylpropanolamin, phenylephrin thì không nên dùng cho người có bệnh cường giáp, huyết áp cao, đau thắt ngực, huyết khối, mạch vành, đái tháo đường, tiền sử tai biến mạch máu não.
Có quá nhiều dạng bào chế: thuốc viên (trong thuốc viên lại có quá nhiều loại viên nén thường, viên nén bao phim, viên nén nhai, viên nén giải phóng chậm, viên sủi bọt, viên nang cứng, viên nang mềm), thuốc bột, thuốc cốm, thuốc đạn… Tất cả các loại trên lại có nhiều hàm lượng khác nhau.
Người bệnh tự dùng thuốc: Trong các biệt dược chứa paracetamol, có khoảng 90% là thuốc mua không cần đơn bác sĩ (OTC).
Vì vậy, việc sử dụng quá liều paracetamol do dùng nhiều thuốc có tên biệt dược khác nhau, dạng bào chế khác nhau cho một người bệnh có đau nhức dữ dội, đau nhức triền miên hoặc sốt cao là điều dễ xảy ra, nhất là với những bệnh nhi.
Tai nạn phổ biến hơn cả là việc tự dùng các biệt dược chứa paracetamol để chữa cảm, cúm, ho. Với người bệnh chỉ có hắt hơi sổ mũi, chảy nước chỉ cần dùng thuốc kháng dị ứng là giảm nhẹ, hết các triệu chứng nói trên thì người ta lại uống các loại thuốc chứa từ 500mg paracetamol với liều 1 – 2 viên/ lần x 3 hoặc 4 lần/ngày.
Như vậy, người dùng thuốc phải chịu tác hại một cách không cần thiết của 1.500 – 4.000mg paracetamol/ngày.
Nhân viên y tế không hướng dẫn đầy đủ: Với người bệnh sốt cao hay đau nhức dai dẳng, thầy thuốc thường cho liều cao hoặc dùng paracetamol nhiều ngày, nhưng quên kiểm tra trước đó bệnh nhân đã dùng thuốc có chứa paracetamol hoặc các loại thuốc có tương tác bất lợi với paracetamol. 
Liều paracetamol dùng hàng ngày được khuyến cáo là không quá 60 – 80mg/ kg/ngày và không được quá 4gam/ngày với người lớn, không quá 80mg/kg với trẻ em. Khi dùng với liều cao hơn kéo dài có thể gây ngộ độc.
## **Làm thế nào để tránh ngộ độc?**
Nếu bệnh nhân không đau nhức, không sốt trên 38oC, không dùng thuốc có paracetamol. Trước khi dùng thuốc hạ sốt, giảm đau, cần kiểm tra công thức thuốc, tránh trùng lặp thuốc có paracetamol.
Trong thời gian dùng thuốc chứa paracetamol: không uống nước có cồn (bia, rượu…) hoặc các thuốc làm tăng độc tính của paracetamol như barbiturat, isoniazid, carbamazepin…
Với phụ nữ có thai: Paracetamol là thuốc hạ sốt giảm đau được khuyên dùng ở phụ nữ có thai, người ta chưa thấy có tác dụng gây quái thai của thuốc này. Tuy nhiên, khi quá liều paracetamol có thể gây độc với thai vì thuốc này dễ dàng qua được nhau thai.
Với người nghiện rượu: Những người nghiện rượu khi dùng quá liều paracetamol có nguy cơ ngộ độc cao hơn và một số nghiên cứu cũng thấy tỷ lệ tử vong cao hơn người bình thường.
Với các trường hợp mẫn cảm với paracetamol, người thiếu hụt men G6PD; người say rượu; người có bệnh tim mạch, phổi, thận, gan hoặc thiếu máu thì không được sử dụng paracetamol.
Tóm lại, dù paracetamol là một thuốc khá an toàn và được bán rộng rãi trên thị trường với rất nhiều tên biệt dược khác nhau thì chúng ta cũng không nên tự ý dùng thuốc, nhất là trong những trường hợp đặc biệt như phụ nữ có thai hay người nghiện rượu, trước khi sử dụng, dù trong bất kỳ hoàn cảnh nào cũng nên tham khảo ý kiến của bác sĩ hoặc nhân viên y tế.
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [Tại sao paracetamol có thể gây độc?](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/ngo-doc-paracetamol#ti-sao-paracetamol-c-th-gy-c)
  * [Lý do nào làm tỷ lệ ngộ độc tăng cao?](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/ngo-doc-paracetamol#l-do-no-lm-t-l-ng-c-tng-cao)
  * [Làm thế nào để tránh ngộ độc?](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/ngo-doc-paracetamol#lm-th-no-trnh-ng-c)



## ️ Những câu hỏi thường gặp liên quan tiêm phòng vắc xin ở trẻ

  * [Những điều cần biết về tiêm phòng vắc xin?](https://bvnguyentriphuong.com.vn/khoa-kham-benh/14-van-de-lien-quan-tiem-phong-vac-xin-o-tre#nhng-iu-cn-bit-v-tim-phng-vc-xin)
  * [Điều gì sẽ xảy ra nếu trẻ không được tiêm phòng vắc xin?](https://bvnguyentriphuong.com.vn/khoa-kham-benh/14-van-de-lien-quan-tiem-phong-vac-xin-o-tre#iu-g-s-xy-ra-nu-tr-khng-c-tim-phng-vc-xin)
  * [Các loại vắc xin có thực sự an toàn?](https://bvnguyentriphuong.com.vn/khoa-kham-benh/14-van-de-lien-quan-tiem-phong-vac-xin-o-tre#cc-loi-vc-xin-c-thc-s-an-ton)
  * [Vắc xin có gây bệnh tự kỷ? ](https://bvnguyentriphuong.com.vn/khoa-kham-benh/14-van-de-lien-quan-tiem-phong-vac-xin-o-tre#vc-xin-c-gy-bnh-t-k)
  * [Tiêm phòng vắc xin có phải là phương án bảo vệ tốt nhất?](https://bvnguyentriphuong.com.vn/khoa-kham-benh/14-van-de-lien-quan-tiem-phong-vac-xin-o-tre#tim-phng-vc-xin-c-phi-l-phng-n-bo-v-tt-nht)
  * [Trẻ bú sữa mẹ thì không cần phải tiêm phòng vắc xin?](https://bvnguyentriphuong.com.vn/khoa-kham-benh/14-van-de-lien-quan-tiem-phong-vac-xin-o-tre#tr-b-sa-m-th-khng-cn-phi-tim-phng-vc-xin)
  * [Vì sao việc tiêm phòng vắc xin lại quan trọng?](https://bvnguyentriphuong.com.vn/khoa-kham-benh/14-van-de-lien-quan-tiem-phong-vac-xin-o-tre#v-sao-vic-tim-phng-vc-xin-li-quan-trng)
  * [Các hợp chất như thủy ngân và thimerosol trong vắc xin có gây nguy hại?](https://bvnguyentriphuong.com.vn/khoa-kham-benh/14-van-de-lien-quan-tiem-phong-vac-xin-o-tre#cc-hp-cht-nh-thy-ngn-v-thimerosol-trong-vc-xin-c-gy-nguy-hi)
  * [Cho trẻ nhiễm bệnh tự nhiên để tăng cường sức đề kháng có phải là giải pháp tối ưu?](https://bvnguyentriphuong.com.vn/khoa-kham-benh/14-van-de-lien-quan-tiem-phong-vac-xin-o-tre#cho-tr-nhim-bnh-t-nhin-tng-cng-sc-khng-c-phi-l-gii-php-ti-u)
  * [Khi trẻ ốm có nên tiêm phòng vắc xin?](https://bvnguyentriphuong.com.vn/khoa-kham-benh/14-van-de-lien-quan-tiem-phong-vac-xin-o-tre#khi-tr-m-c-nn-tim-phng-vc-xin)
  * [Trẻ bị dị ứng có thể tiêm phòng vắc xin được không?](https://bvnguyentriphuong.com.vn/khoa-kham-benh/14-van-de-lien-quan-tiem-phong-vac-xin-o-tre#tr-b-d-ng-c-th-tim-phng-vc-xin-c-khng)
  * [Khoảng cách cần tiêm vắc xin bao nhiêu là hợp lý?](https://bvnguyentriphuong.com.vn/khoa-kham-benh/14-van-de-lien-quan-tiem-phong-vac-xin-o-tre#khong-cch-cn-tim-vc-xin-bao-nhiu-l-hp-l)
  * [Việc tiêm vắc xin theo các phương án lựa chọn có tác dụng?](https://bvnguyentriphuong.com.vn/khoa-kham-benh/14-van-de-lien-quan-tiem-phong-vac-xin-o-tre#vic-tim-vc-xin-theo-cc-phng-n-la-chn-c-tc-dng)
  * [Những phản ứng phụ của việc tiêm phòng vắc xin? ](https://bvnguyentriphuong.com.vn/khoa-kham-benh/14-van-de-lien-quan-tiem-phong-vac-xin-o-tre#nhng-phn-ng-ph-ca-vic-tim-phng-vc-xin)


## **Những điều cần biết về tiêm phòng vắc xin?**
Tiêm phòng vắc xin cho trẻ không chỉ là việc làm cần thiết mà nó đã được chứng minh qua các nghiên cứu khoa học. Tuy nhiên, trong thực tế, có những người không nghe theo chuyên môn mà lại nghe những lời đồn đại, không cho con đi tiêm theo đúng lịch chỉ vì lời đồn tiêm vắc xin sẽ gây bệnh tự kỷ hoặc những lời đồn thiếu khoa học khác.
## **Điều gì sẽ xảy ra nếu trẻ không được tiêm phòng vắc xin?**
Trước tiên, việc tiêm phòng vắc xin cho trẻ trong phạm vi cả cộng đồng, cả nước, đồng bộ ở khắp mọi nơi đóng vai trò quan trọng.
Ngược lại, nếu không làm tốt tác dụng phòng ngừa bệnh sẽ kém hiệu quả, thậm chí gây thiệt hại cả về tiền của lẫn sức lực. Ngoài ra còn có một số căn bệnh rất nguy hiểm như bệnh đậu mùa, căn bệnh người ta dự báo sẽ bùng phát trong tương lai gần. Vì vậy nếu tiêm phòng trước sẽ giảm thiểu nỗi lo và nguy cơ gây tử vong.
## **Các loại vắc xin có thực sự an toàn?**
Các nhà khoa học cho rằng các loại vắc xin là sản phẩm an toàn vì nó đã được nghiên cứu kỹ lưỡng. Trước tiên là qua các khâu thử nghiệm lâm sàng, tiếp đến được cơ quan quản lý Dược- Thực phẩm Mỹ (FDA) phê duyệt.
Hơn nữa, FDA còn tiến hành giám sát sản xuất. Ví dụ, mỗi lô vắc xin ra lò các hãng sản xuất phải đệ trình kết quả thử nghiệm chất lượng và tính an toàn, độ thuần để FDA, Trung tâm phòng chống dịch bệnh Mỹ (CDCP) đồng phê duyệt lần cuối.
## **Vắc xin có gây bệnh tự kỷ?**
Tất cả những vấn đề đồn đại có liên quan đến vắc xin và bệnh tự kỷ đã được khoa học nghiên cứu và không hề tìm thấy những chứng cứ khoa học lẫn lâm sàng và như vậy việc tiêm phòng vắc xin không gây bệnh tự kỷ cho trẻ.
Các nhà khoa học biết rằng, lời đồn nói trên có cách đây một thập kỷ khi người ta mới chỉ thực hiện ở một nghiên cứu 12 đứa trẻ tham gia. Nhưng từ đó đến nay đã có rất nhiều nghiên cứu được thực hiện và không hề tìm thấy bất kỳ bằng chứng nào.
## **Tiêm phòng vắc xin có phải là phương án bảo vệ tốt nhất?**
Tiêm phòng vắc xin không phải là giải pháp tuyệt đối bảo vệ trẻ không mắc bệnh mà nó là phương án tốt nhất giảm thiểu các loại bệnh viêm nhiễm. Nói cách khác, tiêm phòng vắc xin giúp trẻ giảm thiểu rủi ro nhiễm bệnh và tử vong so với nhóm không tiêm phòng.
_Tiêm phòng vắc xin giúp bảo vệ trẻ khỏi các vấn đề viêm nhiễm_
## **Trẻ bú sữa mẹ thì không cần phải tiêm phòng vắc xin?**
Nhiều người đọc sách báo cho rằng, sữa mẹ có nhiều thành phần tốt có thể tăng cường sức đề kháng cho hệ miễn dịch trẻ nhỏ.
Đây là điều hoàn toàn đúng nhưng cơ thể trẻ chỉ nhận những chất kháng thể cho những loại bệnh mà nó có thể miễn dịch được và chỉ có tác dụng trong 3-6 tháng tuổi. Vì vậy việc bú sữa mẹ không thể thay thế việc tiêm vắc xin nên vẫn phải tiêm phòng bình thường theo đúng lịch mà chuyên môn quy định.
## **Vì sao việc tiêm phòng vắc xin lại quan trọng?**
Mặc dù một số bệnh đã được con người thanh toán nhưng gần đây, do môi trường ô nhiễm và những tác động khác nên nhiều loại bệnh truyền nhiễm đang có chiều hướng tái phát trở lại, ví dụ như bệnh thủy đậu, sởi và quai bị, hoặc cũng có thể hết ở quốc gia này nhưng lại tồn tại ở quốc gia khác.
Bệnh lan truyền qua con đường ăn uống, con đường du lịch nên việc tiêm phòng là rất cần thiết. Ví dụ như bệnh quai bị bùng phát ở New York và New Jersey Mỹ mới đây, nguyên nhân là do những người đi du lịch từ Anh mang về.
## **Các hợp chất như thủy ngân và thimerosol trong vắc xin có gây nguy hại?**
Ngoài tự kỷ người ta còn nghi ngờ đến chất bảo quản có trong các loại vắc xin đó là chất thimerosol có chứa thủy ngân nhưng nó đã được người ta loại bỏ, nếu có hàm lượng cũng không đáng kể, trừ vắc xin cúm dạng tiêm. Khi sử dụng nên tư vấn bác sĩ hoặc dùng loại không chứa thimerosol. 
## **Cho trẻ nhiễm bệnh tự nhiên để tăng cường sức đề kháng có phải là giải pháp tối ưu?**
Nhiều bậc phụ huynh đã tự cho con mình tiếp cận với những đứa trẻ mắc bệnh thủy đậu trước khi tiêm phòng vắc xin để tăng cường sức đề kháng cho cơ thể. Đây là việc làm gây đau hơn cả tiêm phòng vắc xin, bởi tiêm vắc xin sởi hay thủy đậu hoặc quai bị chỉ gặp những phản ứng phụ rất nhỏ như sốt, đau cục bộ tại vị trí tiêm.
Giải pháp cho trẻ tiếp xúc với những căn bệnh trên trước khi tiêm phòng rất nguy hiểm, dễ gây biến chứng như tê liệt, chậm lớn, điếc…, thậm chí nếu nặng có thể gây tử vong.
## **Khi trẻ ốm có nên tiêm phòng vắc xin?**
Trường hợp trẻ hắt hơi ngạt mũi hoặc sốt nhiệt độ thấp 38 độ C có thể tiêm được. Đây cũng là giai đoạn hệ miễn dịch của trẻ đang kích hoạt chống bệnh cảm lạnh nên tiêm phòng vắc xin sẽ phát huy tác dụng nhưng nếu trẻ sốt cao thì phải chờ đến khi trẻ hồi phục hoặc khi hệ miễn dịch trẻ yếu phải điều trị loại thuốc nào đó cũng không nên tiêm vắc xin, nên tư vấn bác sĩ cụ thể.
## **Trẻ bị dị ứng có thể tiêm phòng vắc xin được không?**
Trường hợp trẻ bị dị ứng protein trứng, đây cũng là thành phần có trong các loại vắc xin cúm thì việc tiêm vắc xin không có vấn đề gì. Trường hợp trẻ bị dị ứng một số loại thuốc, thực phẩm thì khi tiêm vắc xin nên tư vấn bác sĩ cụ thể.
_Trẻ bị dị ứng trước khi tiêm vắc xin cần hỏi ý kiến bác sĩ_
## **Khoảng cách cần tiêm vắc xin bao nhiêu là hợp lý?**
Phải nói ngay rằng trong thực tế có rất nhiều vấn đề có liên quan đến lịch tiêm, nào là trì hoãn chậm, quên, tiêm không đủ liều không đúng chủng loại dẫn đến giảm tính năng của việc ngừa bệnh. Tuy nhiên cũng có loại vắc xin không ảnh hưởng quá nhiều đến tiến độ. Ví dụ như 3 mũi tiêm MMR (sởi, quai bị, rubella). Ngoài việc tiêm đúng lịch trình theo quy định của chuyên môn, việc tiêm nhiều mũi vắc xin trong ngày cũng không ảnh hưởng đến sức khỏe, tạo ra những phản ứng phụ không mong muốn.
## **Việc tiêm vắc xin theo các phương án lựa chọn có tác dụng?**
Giới chuyên môn cảnh báo việc tiêm vắc xin theo các phương án lựa chọn không phải là giải pháp tối ưu vì nó không có cơ sở khoa học, thậm chí nếu tiêm muộn người ta cũng không khẳng định được là có an toàn hay không. Tốt nhất là nên tiêm theo lịch, nếu lỡ quên thì nên tiêm ngay sau đó càng sớm càng tốt.
## **Những phản ứng phụ của việc tiêm phòng vắc xin?**
Như trên đã đề cập, phản ứng phụ thường gặp khi tiêm phòng vắc xin là đỏ, sưng cục bộ ngay tại vị trí chỗ tiêm, sốt nhẹ đây là những hiện tượng bình thường và có thể qua nhanh. Trường hợp sau cần đưa trẻ đi cấp cứu, nhất là khi nó xảy ra trong vòng vài phút cho đến vài giờ sau khi tiêm:
  * Sốt trên 103oF (39,4 oC)
  * Lên cơn tai biến
  * Xuất hiện các nốt đen- xanh hoặc phát ban ở những nơi không tiêm.


**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [Những điều cần biết về tiêm phòng vắc xin?](https://bvnguyentriphuong.com.vn/khoa-kham-benh/14-van-de-lien-quan-tiem-phong-vac-xin-o-tre#nhng-iu-cn-bit-v-tim-phng-vc-xin)
  * [Điều gì sẽ xảy ra nếu trẻ không được tiêm phòng vắc xin?](https://bvnguyentriphuong.com.vn/khoa-kham-benh/14-van-de-lien-quan-tiem-phong-vac-xin-o-tre#iu-g-s-xy-ra-nu-tr-khng-c-tim-phng-vc-xin)
  * [Các loại vắc xin có thực sự an toàn?](https://bvnguyentriphuong.com.vn/khoa-kham-benh/14-van-de-lien-quan-tiem-phong-vac-xin-o-tre#cc-loi-vc-xin-c-thc-s-an-ton)
  * [Vắc xin có gây bệnh tự kỷ? ](https://bvnguyentriphuong.com.vn/khoa-kham-benh/14-van-de-lien-quan-tiem-phong-vac-xin-o-tre#vc-xin-c-gy-bnh-t-k)
  * [Tiêm phòng vắc xin có phải là phương án bảo vệ tốt nhất?](https://bvnguyentriphuong.com.vn/khoa-kham-benh/14-van-de-lien-quan-tiem-phong-vac-xin-o-tre#tim-phng-vc-xin-c-phi-l-phng-n-bo-v-tt-nht)
  * [Trẻ bú sữa mẹ thì không cần phải tiêm phòng vắc xin?](https://bvnguyentriphuong.com.vn/khoa-kham-benh/14-van-de-lien-quan-tiem-phong-vac-xin-o-tre#tr-b-sa-m-th-khng-cn-phi-tim-phng-vc-xin)
  * [Vì sao việc tiêm phòng vắc xin lại quan trọng?](https://bvnguyentriphuong.com.vn/khoa-kham-benh/14-van-de-lien-quan-tiem-phong-vac-xin-o-tre#v-sao-vic-tim-phng-vc-xin-li-quan-trng)
  * [Các hợp chất như thủy ngân và thimerosol trong vắc xin có gây nguy hại?](https://bvnguyentriphuong.com.vn/khoa-kham-benh/14-van-de-lien-quan-tiem-phong-vac-xin-o-tre#cc-hp-cht-nh-thy-ngn-v-thimerosol-trong-vc-xin-c-gy-nguy-hi)
  * [Cho trẻ nhiễm bệnh tự nhiên để tăng cường sức đề kháng có phải là giải pháp tối ưu?](https://bvnguyentriphuong.com.vn/khoa-kham-benh/14-van-de-lien-quan-tiem-phong-vac-xin-o-tre#cho-tr-nhim-bnh-t-nhin-tng-cng-sc-khng-c-phi-l-gii-php-ti-u)
  * [Khi trẻ ốm có nên tiêm phòng vắc xin?](https://bvnguyentriphuong.com.vn/khoa-kham-benh/14-van-de-lien-quan-tiem-phong-vac-xin-o-tre#khi-tr-m-c-nn-tim-phng-vc-xin)
  * [Trẻ bị dị ứng có thể tiêm phòng vắc xin được không?](https://bvnguyentriphuong.com.vn/khoa-kham-benh/14-van-de-lien-quan-tiem-phong-vac-xin-o-tre#tr-b-d-ng-c-th-tim-phng-vc-xin-c-khng)
  * [Khoảng cách cần tiêm vắc xin bao nhiêu là hợp lý?](https://bvnguyentriphuong.com.vn/khoa-kham-benh/14-van-de-lien-quan-tiem-phong-vac-xin-o-tre#khong-cch-cn-tim-vc-xin-bao-nhiu-l-hp-l)
  * [Việc tiêm vắc xin theo các phương án lựa chọn có tác dụng?](https://bvnguyentriphuong.com.vn/khoa-kham-benh/14-van-de-lien-quan-tiem-phong-vac-xin-o-tre#vic-tim-vc-xin-theo-cc-phng-n-la-chn-c-tc-dng)
  * [Những phản ứng phụ của việc tiêm phòng vắc xin? ](https://bvnguyentriphuong.com.vn/khoa-kham-benh/14-van-de-lien-quan-tiem-phong-vac-xin-o-tre#nhng-phn-ng-ph-ca-vic-tim-phng-vc-xin)



## ️ Cơ chế nào giúp vi khuẩn đề kháng thuốc

  * [Kháng thuốc là do “gen”](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/tai-sao-vi-khuan-khang-thuoc#khng-thuc-l-do-gen)
  * [Cách tạo ra gen kháng thuốc](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/tai-sao-vi-khuan-khang-thuoc#cch-to-ra-gen-khng-thuc)
  * [Các gen kháng thuốc chống lại thuốc như nào?](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/tai-sao-vi-khuan-khang-thuoc#cc-gen-khng-thuc-chng-li-thuc-nh-no)


## **Kháng thuốc là do “gen”**
Kháng sinh là thuốc tấn công vào cơ thể vi khuẩn nhằm mục đích tiêu diệt. Nó như một vũ khí ngăn chặn sự sống của loài vi sinh vật này. Nhưng ngày nay, càng có nhiều loại vi khuẩn kháng thuốc và ngày càng có nhiều thuốc bị kháng. Tại sao vi khuẩn lại có khả năng nhận ra thuốc kháng sinh và kháng lại?
Thuốc kháng sinh là một thuốc duy nhất có công hiệu có thể tiêu diệt các vi khuẩn gây bệnh. Nó đã cứu được hàng triệu triệu người trên thế giới. Tuy nhiên, vấn nạn kháng thuốc kháng sinh đang trở thành một vấn đề đau đầu, nhức nhối và thời sự, WHO phải lên tiếng cảnh báo rằng phải hành động ngay hôm nay nếu không ngày mai sẽ không có thuốc.
Kể từ khi xuất hiện một trường hợp kháng thuốc kháng sinh đầu tiên vào năm 1947, nạn vi khuẩn kháng lại kháng sinh đã lan rộng. Sự lan rộng của kháng thuốc kháng sinh không chỉ về mặt địa lý, mà còn cả về mặt chủng loại vi khuẩn và loại thuốc bị kháng.
Hiện tượng kháng thuốc kháng sinh đã lan từ vùng này sang vùng khác, khiến nó trở thành một vấn đề toàn cầu. Không chỉ các quốc gia kém phát triển và vệ sinh nghèo nàn mới có hiện tượng kháng thuốc kháng sinh mà ngay cả các nước phát triển như Anh, Pháp, Đức… cũng có sự kháng lại kháng thuốc kháng sinh.
Ngày càng có nhiều chủng loại vi khuẩn kháng thuốc. Ban đầu chỉ có một loại vi khuẩn kháng thuốc là vi khuẩn tụ cầu vàng Staphylococcus aureus. Nhưng ngày nay đã có nhiều loài vi khuẩn có đặc tính này như trực khuẩn mủ xanh Pseudomonas aeruginosa, vi khuẩn kỵ khí gram dương như Clostridium spp, vi khuẩn viêm màng não Neisseria meningitidis, phế cầu khuẩn…
Sự kháng lại thuốc kháng sinh của vi khuẩn về cơ bản là do gen. Tức là vi khuẩn “tự nhiên” có những gen kháng thuốc trong tế bào. Nhờ có gen kháng thuốc mà vi khuẩn có đủ năng lực chống lại tác dụng của thuốc kháng sinh. Và nhờ đó mà chúng có thể tồn tại và tiếp tục gây bệnh. Vấn đề là ở chỗ, làm thế nào mà vi khuẩn có được gen kháng thuốc này?
## **Cách tạo ra gen kháng thuốc**
Như trên đã nói, sự kháng thuốc có thể nói rằng về cơ bản do xuất hiện các gen kháng thuốc. Nhưng không phải “tự nhiên” mà vi khuẩn có được mẩu gen nguy hại này. Việc có được gen kháng thuốc là do một trong nhiều cách thức sau đây:
Thứ nhất là do đột biến, tức là chính thuốc kháng sinh đã làm đột biến hệ vật chất di truyền của vi khuẩn làm cho hệ vật chất này bị biến đổi. Cụ thể, DNA của vi khuẩn đã bị biến đổi. Sự biến đổi này theo hướng kháng lại thuốc kháng sinh và gen bị biến đổi này được gọi là gen kháng thuốc.
Không phải là dễ dàng mà vi khuẩn có được sự đột biến này. Sự đột biến chỉ xảy ra khi thuốc được dùng với liều lượng không quy chuẩn và vi khuẩn có thể sống sót sau đợt điều trị. Những “con” vi khuẩn sống sót này sẽ nhận biết, cảm hoá và biến đổi DNA để chống lại tác dụng của thuốc kháng sinh. Và thế là gen kháng thuốc được tạo thành. Về cơ bản, đây là cách thức chủ yếu nhất tạo ra kháng thuốc. Tuy nhiên, sự đột biến tự thân của vi khuẩn chưa phải là cách chủ đạo gây ra sự kháng thuốc lan nhanh.
Thứ hai là do sự lai tạo của dòng vi khuẩn động vật với vi khuẩn trên người. Tức là vi khuẩn gây bệnh trên người có được gen kháng thuốc là do tiếp nhận được những gen kháng thuốc từ hệ vi khuẩn trên động vật. Quá trình này diễn ra theo trình tự: Ban đầu, vi khuẩn bám trụ trên động vật kháng thuốc. Sau đó, vì một lý do nào đó, chúng thâm nhập vào cơ thể người.
Những vi khuẩn bị đột biến này sẽ truyền tải gen kháng thuốc theo cơ chế chuyển gen cho vi khuẩn trên người. Vật mang gen kháng thuốc từ vi khuẩn động vật sang vi khuẩn người là một “bán sinh thể sống” có tên gọi là plasmid. Kết quả là vi khuẩn có khả năng kháng thuốc.
Thứ ba là có sự chuyển đổi gen kháng thuốc giữa những vi khuẩn trên lãnh thổ quốc gia này sang lãnh thổ quốc gia khác thông qua những chủ thể người đi du lịch. Ban đầu, những người đi du lịch có những vi khuẩn kháng thuốc. Họ đi sang một quốc gia khác, mang theo luôn cả loại vi khuẩn này.
Những vi khuẩn này sẽ truyền gen kháng thuốc cho những vi khuẩn lành ở quốc gia bị tạp nhiễm. Kết quả cuối cùng là tạo ra một dòng vi khuẩn kháng thuốc ở chính quốc gia thứ hai này và từ đó có thể làm nạn kháng thuốc lan ra toàn cầu.
## **Các gen kháng thuốc chống lại thuốc như nào?**
Xét dưới góc độ tế bào, hạt nhân giúp vi khuẩn kháng thuốc ấy chính là các gen kháng thuốc trong bộ vật chất di truyền DNA. Những gen kháng thuốc sẽ giúp vi khuẩn chống lại thuốc theo một trong 4 phương thức: tránh sự xâm nhập kháng sinh vào tế bào, tổng hợp các enzym bất hoạt hoặc phân huỷ kháng sinh, thay đổi con đường chuyển hoá và bơm thải kháng sinh ra khỏi tế bào.
Một trong các phương thức chủ yếu đó là vi khuẩn tổng hợp ra các enzym bất hoạt hoặc phân huỷ kháng sinh. Khi mà các enzym được tổng hợp ra thì chúng sẽ phân huỷ hoặc biến đổi thuốc kháng sinh thành những “mảnh” không có tác dụng. Ví dụ điển hình là enzym ß-lactamase trong tụ cầu vàng có tác dụng phân huỷ kháng sinh dòng ß-lactamam như penicillin, piperacillin, cefotaxime; enzym chuyển acetyl làm biến đổi thuốc kháng sinh chloramphenicol.
Cơ chế thứ hai khá thông dụng đó là gen kháng thuốc giúp vi khuẩn thay đổi chuyển hoá theo hướng không sử dụng kháng sinh trong sinh trường. Dù có hay không có kháng sinh thì vi khuẩn cũng không bị tiêu diệt. Đây là hiện tượng hay gặp khi vi khuẩn chống lại các kháng sinh dòng sulphonamide, quinolon, macrolid.
Không chỉ có thế, các vi khuẩn còn có khả năng thải trừ kháng sinh ra khỏi tế bào. Sự kháng thuốc kháng sinh của trực khuẩn mủ xanh Pseudomonas aeruginosa là một ví dụ điển hình của hình thức kháng lại kháng sinh theo cơ chế này.
Nghiên cứu về tốc độ kháng thuốc người ta thấy, tỷ lệ kháng thuốc vào cỡ 10-9 vi khuẩn trong cộng đồng vi sinh vật. Tỷ lệ này tương đương với các tỷ lệ đột biến di truyền tự nhiên. Nhưng sự kháng thuốc thì không nhỏ như thế mà nhanh hơn rất rất nhiều lần. Đó là nhờ sự hoạt động của các gen kháng thuốc theo các cơ chế như trên.
Xem thêm: [**Tử vong do kháng thuốc sẽ ngày càng tăng**](https://bvnguyentriphuong.com.vn/khoa-duoc/tu-vong-do-khang-thuoc-se-ngay-cang-tang)
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [Kháng thuốc là do “gen”](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/tai-sao-vi-khuan-khang-thuoc#khng-thuc-l-do-gen)
  * [Cách tạo ra gen kháng thuốc](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/tai-sao-vi-khuan-khang-thuoc#cch-to-ra-gen-khng-thuc)
  * [Các gen kháng thuốc chống lại thuốc như nào?](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/tai-sao-vi-khuan-khang-thuoc#cc-gen-khng-thuc-chng-li-thuc-nh-no)



## ️ Các loại thuốc băng niêm mạc dạ dày và một số lưu ý

  * [1. Thuốc băng niêm mạc dạ dày là gì, có tác dụng như thế nào trong điều trị viêm loét dạ dày?](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/cac-loai-thuoc-boc-niem-mac-da-day-dieu-tri-viem-loet-da-day#1-thuc-bngnim-mc-d-dy-l-g-c-tc-dng-nh-th-no-trong-iu-tr-vim-lot-d-dy)
  * [2. Các thuốc băng niêm mạc dạ dày được dùng trong điều trị viêm loét dạ dày](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/cac-loai-thuoc-boc-niem-mac-da-day-dieu-tri-viem-loet-da-day#2-cc-thuc-bngnim-mc-d-dy-c-dng-trong-iu-tr-vim-lot-d-dy)
  * [2.2. Bismuth subcitrat](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/cac-loai-thuoc-boc-niem-mac-da-day-dieu-tri-viem-loet-da-day#22-bismuth-subcitrat)
  * [2.3. Prostaglandin](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/cac-loai-thuoc-boc-niem-mac-da-day-dieu-tri-viem-loet-da-day#23-prostaglandin)


## **1. Thuốc băng niêm mạc dạ dày là gì, có tác dụng như thế nào trong điều trị viêm loét dạ dày?**
Cơ chế gây bệnh viêm loét dạ dày tá tràng là do mất cân bằng giữa 2 nhóm yếu tố gây bệnh và yếu tố bảo vệ. Trong đó yếu tố gây bệnh bao gồm acid HCl và pepsin dịch vị, vi khuẩn HP (helicobacter pylori), thuốc chống viêm (steroid và không steroid), rượu và thuốc lá. Yếu tố bảo vệ bao gồm chất nhày mucin, bicarbonat, mạng lưới mao mạch của niêm mạc dạ dày cùng sự toàn vẹn lớp tế bào biểu mô dạ dày.
_Cơ chế gây viêm loét dạ dày_
Dựa vào cơ chế này, nguyên tắc điều trị viêm loét dạ dày tá tràng được đặt ra đó là:
  * Làm giảm acid, pepsin ở dịch vị bằng các thuốc ức chế bài tiết acid hoặc thuốc trung hòa acid.
  * Tăng cường các yếu tố bảo vệ niêm mạc dạ dày bằng các thuốc tạo màng che phủ, băng bó ổ loét. Hay kích thích sự tái sinh của tế bào niêm mạc dạ dày, kích thích bài tiết chất nhầy và prostaglandin.
  * Diệt trừ HP bằng các thuốc kháng sinh hoặc một số thuốc khác.
  * Điều trị hỗ trợ, nâng cao sức khỏe người bệnh.


Thuốc băng niêm mạc dạ dày với cơ chế tạo lớp bảo vệ niêm mạc dạ dày, băng bó ổ loét. Từ đó giúp hạn chế sự tấn công của tác nhân gây viêm loét cũng như tạo cơ hội cho dạ dày được phục hồi vết thương qua thời gian. Bên cạnh đó, thuốc bọc niêm mạc dạ dày còn có khả năng ức chế hoạt động của vi khuẩn HP gây ảnh hưởng xấu đến dạ dày.
## **2. Các thuốc băng niêm mạc dạ dày được dùng trong điều trị viêm loét dạ dày**
### **2.1. Sucrafat**
_Sucralfat – một loại thuốc bọc niêm mạc dạ dày được dùng trong điều trị viêm loét dạ dày_
– **Tên biệt dược:** Sucralfate.
– **Tác dụng:** Đây là một loại muối nhôm của sulfat disacarid. Loại này được sử dụng phổ biến vì kết hợp với protein của dịch nhầy một cách chắc chắn, không bị mật phá hủy. Chúng có những tác dụng sau trong điều trị viêm loét dạ dày:
  * Ngăn ngừa hiện tượng tái hấp thu H+
  * Hấp thu pepsin và dịch mật
  * Tăng bài tiết dịch nhày và bicarbonat
  * Tăng tổng hợp prostaglandin nội sinh
  * Tăng tưới máu niêm mạc dạ dày, giúp hồi phục lớp biểu mô bề mặt


– **Chỉ định:**
  * Bệnh loét dạ dày tá tràng
  * Viêm dạ dày mạn tính
  * Loét dạ dày lành tính
  * Bệnh trào ngược dạ dày thực quản
  * Phòng tái phát loét tá tràng, phòng loét do stress.


– **Chống chỉ định:**
  * Quá mẫn với thuốc.
  * Thận trọng ở phụ nữ có thai, cho con bú.
  * Thận trọng với bệnh nhân suy gan suy thận nặng. Do nguy cơ tăng nồng độ nhôm trong máu, nhất là khi dùng dài ngày. Trường hợp suy thận nặng thì nên tránh dùng.


– **Liều dùng và cách dùng:**
  * Sucralfate 1g x 4 lần/ngày.
  * Sucralfat không nên dùng cùng thức ăn. Nên uống vào lúc đói.


– **Tác dụng không mong muốn:** táo bón, rối loạn tiêu hóa. Hiếm gặp hơn là đau đầu, hoa mắt, chóng mặt, buồn ngủ hay phản ứng dị ứng (ngứa, phát ban đỏ…).
### **2.2. Bismuth subcitrat**
Nhóm thuốc muối bismuth gồm các tinh thể muối sẽ gắn chặt với các albumin của dịch rỉ viêm và các glycoprotein. Thuốc này liên kết với pepsin và muối mật phủ lên vùng niêm mạc bị viêm. Chúng tạo thành một màng bọc có tác dụng củng cố hàng rào bảo vệ niêm mạc.
– **Tác dụng trong điều trị viêm loét dạ dày:**
  * Giúp tăng tiết dịch nhày và bicarbonat, ức chế hoạt tính của pepsin.
  * Bao phủ chọn lọc lên đáy ổ loét làm thành hàng rào bảo vệ ổ loét chống lại sự tấn công của acid và pepsin.
  * Diệt vi khuẩn helicobacter pylori.


– **Tác dụng phụ** : Buồn nôn, nôn, đen miệng, đen lưỡi, đi ngoài đen phân (không phải do xuất huyết tiêu hóa)
– **Liều lượng và cách dùng:**
  * Bismuth subcitrat viên 120 mg. Uống mỗi lần 1 viên x 4 lần/ngày trước ăn 30 phút.
  * Hoặc uống ngày 2 lần, mỗi lần 2 viên.


### **2.3. Prostaglandin**
Thuốc này hiện nay ít dùng. Gồm có 2 loại phổ biến là prostaglandin E1 và E2. Chúng ít được áp dụng trong chữa trị viêm loét dạ dày như các loại thuốc khác. Mà thường được dùng để phòng ngừa căn bệnh này.
– **Tên biệt dược:** Misoprostol, cytotec
– **Tác dụng:**
  * Giảm bài tiết dịch vị
  * Tăng bài tiết chất nhầy và bicarbonat
  * Tăng dòng máu tới niêm mạc dạ dày


– **Chỉ định:**
  * Dự phòng loét dạ dày tá tràng do thuốc chống viêm không steroid
  * Dự phòng ở những người bệnh có nguy cơ cao gặp biến chứng loét dạ dày


– **Chống chỉ định:**
Tiền sử dị ứng với prostaglandin và phụ nữ có thai vì tăng nguy cơ sảy thai, đẻ non.
– **Liều lượng và cách dùng:**
Misoprostol (cytotec) 400 mcg – 800 mcg/ngày. Uống vào bữa ăn và uống liều cuối cùng trong ngày vào lúc đi ngủ.
– **Tác dụng không mong muốn:**
  * Rối loạn tiêu hóa như đầy bụng, buồn nôn, nôn, khó tiêu hoặc ỉa chảy
  * Nhức đầu, hạ huyết áp
  * Kích thích tử cung, chảy máu âm đạo bất thường, sảy thai.


Ngoài các thuốc điều trị viêm loét dạ dày như thuốc bọc niêm mạc dạ dày nêu trên, người bệnh viêm loét dạ dày cần tránh dùng các thuốc gây tổn thương cho dạ dày. Như corticoid, thuốc chống viêm không steroid đặc biệt là aspirin.
Hạn chế ăn gia vị chua cay và các chất kích thích (cà phê, rượu, thuốc lá). Thêm vào đó, nên có chế độ nghỉ ngơi hợp lý. Hạn chế thức khuya và tránh tối đa các yếu tố gây stress. Vì chúng sẽ thúc đẩy bệnh viêm loét dạ dày tiến triển nặng hơn.
Xem tiếp: [**Điều trị viêm loét dạ dày: Thuốc kháng acid và thuốc làm giảm tiết acid**](https://bvnguyentriphuong.com.vn/noi-tieu-hoa/dieu-tri-viem-loet-da-day-thuoc-khang-acid-va-thuoc-lam-giam-tiet-acid)
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [1. Thuốc băng niêm mạc dạ dày là gì, có tác dụng như thế nào trong điều trị viêm loét dạ dày?](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/cac-loai-thuoc-boc-niem-mac-da-day-dieu-tri-viem-loet-da-day#1-thuc-bngnim-mc-d-dy-l-g-c-tc-dng-nh-th-no-trong-iu-tr-vim-lot-d-dy)
  * [2. Các thuốc băng niêm mạc dạ dày được dùng trong điều trị viêm loét dạ dày](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/cac-loai-thuoc-boc-niem-mac-da-day-dieu-tri-viem-loet-da-day#2-cc-thuc-bngnim-mc-d-dy-c-dng-trong-iu-tr-vim-lot-d-dy)
  * [2.2. Bismuth subcitrat](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/cac-loai-thuoc-boc-niem-mac-da-day-dieu-tri-viem-loet-da-day#22-bismuth-subcitrat)
  * [2.3. Prostaglandin](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/cac-loai-thuoc-boc-niem-mac-da-day-dieu-tri-viem-loet-da-day#23-prostaglandin)



## ️ Các loại thuốc điều trị tiểu đường

  * [1. Tiểu đường là gì? ](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/cac-loai-thuoc-tieu-duong#1-tiu-ng-l-g)
  * [2. Thuốc điều trị tiểu đường hiệu quả hiện nay ](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/cac-loai-thuoc-tieu-duong#2-thuc-iu-tr-tiu-ng-hiu-qu-hin-nay)
  * [2.2 Sulfonylurea](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/cac-loai-thuoc-tieu-duong#22-sulfonylurea)
  * [2.5 Thiazolidinedione ](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/cac-loai-thuoc-tieu-duong#25-thiazolidinedione)
  * [3. Biện pháp kết hợp làm tăng hiệu quả của thuốc tiểu đường](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/cac-loai-thuoc-tieu-duong#3-bin-php-kt-hp-lm-tng-hiu-qu-ca-thuc-tiu-ng)
  * [Xây dựng chế độ ăn hợp lý](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/cac-loai-thuoc-tieu-duong#xy-dng-ch-n-hp-l)
  * [Tập luyện thể dục thể thao ](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/cac-loai-thuoc-tieu-duong#tp-luyn-th-dc-th-thao)
  * [Hạn chế chất kích thích](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/cac-loai-thuoc-tieu-duong#hn-ch-cht-kch-thch)


Tiểu đường là bệnh lý chuyển hóa khá phổ biến và thường gây nhiều biến chứng nguy hiểm. Các loại thuốc tiểu đường là cách kiểm soát bệnh rất tốt, tuy nhiên có thể gây tác dụng không mong muốn, ảnh hưởng nghiêm trọng đến sức khỏe người dùng. Vì vậy, trong bài viết dưới đây sẽ cung cấp thông tin các loại thuốc tiểu đường hiệu quả hiện nay, bạn đọc tham khảo để sử dụng thuốc hợp lý, ngăn ngừa bệnh tiến triển. 
## **1. Tiểu đường là gì?**
Tiểu đường (hay đái tháo đường) là tình trạng đường máu tăng cao, vượt ngưỡng 7 mmol/L lúc đói (Theo Hiệp hội Đái tháo đường Hoa Kỳ – ADA), nguyên nhân là do thiếu hụt hoặc giảm đáp ứng của cơ thể với hormon Insulin – hormon hạ đường huyết duy nhất của cơ thể. 
Có 4 typ tiểu đường: 
  * Tiểu đường typ 1: Do cơ chế tự miễn dịch phá hủy tế bào tiết Insulin.
  * Tiểu đường typ 2: Tế bào không đáp ứng với Insulin, giảm tiết Insulin. 
  * Tiểu đường thứ phát: Tiểu đường do hậu quả của các bệnh lý khác như bệnh lý nội tiết, u tụy, cắt tụy…)
  * Tiểu đường thai kỳ: Đái tháo đường ở phụ nữ mang thai. 


## **2. Thuốc điều trị tiểu đường hiệu quả hiện nay**
Mỗi loại thuốc có cơ chế, tác dụng khác nhau, được chỉ định phù hợp với từng đối tượng và tình trạng bệnh. Dưới đây là 5 thuốc trị tiểu đường được chỉ định phổ biến hiện nay: 
### **2.1 Insulin**
Thuốc có tác dụng cung cấp Insulin cho cơ thể, giúp vận chuyển đường từ máu vào tế bào, giảm đường huyết nhanh chóng nên thường được sử dụng trong trường hợp cấp cứu. 
  * **Đối tượng sử dụng:**
    * Tiểu đường typ 1: Bắt buộc.
    * Tiểu đường typ 2: Sau khi không đáp ứng với các thuốc điều trị khác. Thông thường, Insulin được chỉ định dùng sau 5 năm dùng thuốc. 
    * Tiểu đường thai kỳ: Bắt buộc
  * **Chống chỉ định:** Người hạ đường huyết, mẫn cảm với thuốc.
  * **Tác dụng không mong muốn:**
    * Quá liều có thể gây hạ đường huyết quá mức với biểu hiện người nhợt nhạt, tụt huyết áp, có thể ngất. 
    * Tăng cân.
  * **Liều dùng:** Theo chỉ định của bác sĩ chuyên khoa 
    * Khởi đầu với tiểu đường typ 1: 0,4 – 0,5UI/ kg/ ngày.
    * Khởi đầu với tiểu đường typ 2: 0,2UI/ kg/ ngày.


### **2.2 Sulfonylurea**
Sulfonylurea có tác dụng kích thích tế bào đảo tụy tiết Insulin để đưa đường từ máu vào tế bào, giảm lượng đường trong máu. 
  * **Đối tượng sử dụng:** Tiểu đường typ 2, khi tế bào đảo tụy vẫn còn khả năng tiết Insulin. 
  * **Chống chỉ định:** Tiểu đường typ 1, tiểu đường thai kỳ và người suy gan, suy thận. 
  * **Tác dụng không mong muốn:**
    * Hạ đường huyết quá mức.
    * Tăng cân.
    * Rối loạn tiêu hóa.
    * Vàng da ứ mật.
  * **Liều dùng (Theo chỉ định của bác sĩ chuyên khoa):** Liều khởi đầu 30-60 mg/ngày. 


### **2.3 Metformin**
Thuốc ức chế hấp thu đường ở ruột, đồng thời tăng vận chuyển đường vào tế bào, ức chế tân tạo đường tại gan, có tác dụng ngăn đường máu tăng cao. Bên cạnh đó, thuốc còn có khả năng làm giảm Lipid máu. 
  * **Đối tượng sử dụng:** Tiểu đường typ 2.
  * **Chống chỉ định:** Tiểu đường thai kỳ, bệnh nhân suy gan, suy thận, suy hô hấp. 
  * **Tác dụng không mong muốn:**
    * Miệng có vị kim loại
    * Rối loạn tiêu hóa: Chán ăn, buồn nôn, tiêu chảy. 
    * Sụt cân nếu dùng kéo dài. 
  * **Liều dùng:** (Theo chỉ định của bác sĩ chuyên khoa) Liều khởi đầu 500 – 800 mg/ngày. 


### **2.4 Acarbose**
Thuốc trị tiểu đường Acarbose có tác dụng ức chế hấp thu đường, chống tăng đường huyết sau ăn. 
  * **Đối tượng sử dụng** : Tiểu đường typ 2.
  * **Chống chỉ định:** Người viêm, loét ruột, bệnh nhân suy gan, tiểu đường thai kỳ. 
  * **Tác dụng không mong muốn:**
    * Rối loạn tiêu hóa. 
    * Rối loạn chức năng gan. 
    * Gây ngứa, phát ban. 
  * **Liều dùng:** (Theo chỉ định của bác sĩ chuyên khoa) Liều khởi đầu 25mg/ lần, ngày 3 lần. 


### **2.5 Thiazolidinedione**
Các thuốc Thiazolidinedione giúp các tế bào đích tăng nhạy cảm với Insulin, tăng cường quá trình vận chuyển đường từ máu vào tế bào để giảm đường huyết. 
  * **Đối tượng sử dụng:** Tiểu đường typ 2. 
  * **Chống chỉ định:** Bệnh nhân suy gan, suy tim hay mắc các bệnh về gan, tim. 
  * **Tác dụng không mong muốn:**
    * Gây phù, tăng cân.
    * Độc trên gan, tim. 
  * **Liều dùng:** (Theo chỉ định của bác sĩ chuyên khoa) Liều khởi đầu 30mg/ ngày. 


Lưu ý khi sử dụng thuốc: 
  * Sử dụng theo chỉ định của bác sĩ hoặc dược sĩ. 
  * Đọc kỹ hướng dẫn sử dụng trước khi dùng. 
  * Không dùng quá liều thuốc hay dừng thuốc đột ngột. 
  * Kết hợp khám sức khỏe định kỳ để kiểm tra đường huyết và tiếp tục chỉ định dùng thuốc. 
  * Kết hợp các biện pháp làm tăng hiệu quả của thuốc tiểu đường. 


## **3. Biện pháp kết hợp làm tăng hiệu quả của thuốc tiểu đường**
Thuốc là con dao hai lưỡi, bên cạnh tác dụng điều trị bệnh luôn có tác dụng không mong muốn đi kèm. Do đó, người bệnh không được lạm dụng thuốc, đồng thời kết hợp với một số biện pháp để tăng hiệu quả của thuốc. Dưới đây là một vài lời khuyên cho bạn: 
### **Xây dựng chế độ ăn hợp lý**
Người bệnh cần duy trì chế độ ăn hạn chế đồ ngọt, thực phẩm giàu tinh bột (tránh đường huyết tăng cao), tránh thực phẩm giàu Lipid (ngăn ngừa biến chứng tim mạch do tiểu đường gây ra). 
Thay vào đó, người bệnh cần bổ sung rau xanh, trái cây và thực hiện chế độ ăn nhiều bữa, đặc biệt không được bỏ bữa sáng. 
### **Tập luyện thể dục thể thao**
Đây là cách nâng cao sức khỏe, ngăn ngừa biến chứng tiểu đường như tăng huyết áp, máu nhiễm mỡ, các bệnh lý tim mạch… 
Người bệnh nên tập thể dục nhẹ nhàng bằng cách đi bộ, chạy bộ, đạp xe hay chơi thể thao, mỗi ngày 30-45 phút để cải thiện bệnh tốt nhất. 
### **Hạn chế chất kích thích**
Rượu, bia, thuốc lá, cafe là các chất kích thích làm giảm tác dụng của thuốc và gây ảnh hưởng xấu đến sức khỏe người bệnh, khiến bệnh tiến triển nhanh hơn và các biến chứng xuất hiện sớm hơn. Do đó, người bệnh cần hạn chế sử dụng, từ bỏ các chất kích thích.
Trên đây là các thuốc điều trị tiểu đường cùng các biện pháp làm tăng hiệu quả sử dụng thuốc. Bạn tham khảo trước khi dùng thuốc và áp dụng để bệnh được cải thiện tốt nhất nhé. 
Xem thêm: [**3 loại xét nghiệm tiểu đường thường gặp**](https://bvnguyentriphuong.com.vn/noi-tiet/3-loai-xet-nghiem-tieu-duong-thuong-gap)
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [1. Tiểu đường là gì? ](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/cac-loai-thuoc-tieu-duong#1-tiu-ng-l-g)
  * [2. Thuốc điều trị tiểu đường hiệu quả hiện nay ](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/cac-loai-thuoc-tieu-duong#2-thuc-iu-tr-tiu-ng-hiu-qu-hin-nay)
  * [2.2 Sulfonylurea](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/cac-loai-thuoc-tieu-duong#22-sulfonylurea)
  * [2.5 Thiazolidinedione ](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/cac-loai-thuoc-tieu-duong#25-thiazolidinedione)
  * [3. Biện pháp kết hợp làm tăng hiệu quả của thuốc tiểu đường](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/cac-loai-thuoc-tieu-duong#3-bin-php-kt-hp-lm-tng-hiu-qu-ca-thuc-tiu-ng)
  * [Xây dựng chế độ ăn hợp lý](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/cac-loai-thuoc-tieu-duong#xy-dng-ch-n-hp-l)
  * [Tập luyện thể dục thể thao ](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/cac-loai-thuoc-tieu-duong#tp-luyn-th-dc-th-thao)
  * [Hạn chế chất kích thích](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/cac-loai-thuoc-tieu-duong#hn-ch-cht-kch-thch)



## ️ Lạm dụng thuốc an thần để chữa mất ngủ – hiểm họa khó lường

  * [1. Những điều cần biết về thuốc an thần](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/lam-dung-thuoc-an-than-de-chua-mat-ngu-hiem-hoa-kho-luong#1-nhng-iu-cn-bit-v-thuc-an-thn)
  * [2. Lạm dụng thuốc an thần tây y để chữa mất ngủ](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/lam-dung-thuoc-an-than-de-chua-mat-ngu-hiem-hoa-kho-luong#2-lm-dng-thuc-an-thn-ty-y-cha-mt-ng)
  * [3. Lạm dụng thuốc an thần tây y để chữa mất ngủ – hiểm họa khó lường](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/lam-dung-thuoc-an-than-de-chua-mat-ngu-hiem-hoa-kho-luong#3-lm-dng-thuc-an-thn-ty-y-cha-mt-ng-him-ha-kh-lng)
  * [Lệ thuộc thuốc, nghiện thuốc](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/lam-dung-thuoc-an-than-de-chua-mat-ngu-hiem-hoa-kho-luong#l-thuc-thuc-nghin-thuc)
  * [Gây rối loạn hoạt động của não bộ](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/lam-dung-thuoc-an-than-de-chua-mat-ngu-hiem-hoa-kho-luong#gy-ri-lon-hot-ng-ca-no-b)
  * [Ảnh hưởng hô hấp, tim mạch](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/lam-dung-thuoc-an-than-de-chua-mat-ngu-hiem-hoa-kho-luong#nh-hng-h-hp-tim-mch)
  * [Không trị được tận gốc của vấn đề](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/lam-dung-thuoc-an-than-de-chua-mat-ngu-hiem-hoa-kho-luong#khng-tr-c-tn-gc-ca-vn-)


## **1. Những điều cần biết về thuốc an thần**
Các thuốc an thần có tác dụng gây ngủ, chống co giật thông qua làm giảm kích thích và giảm hưng phấn vỏ não.
Các thuốc an thần thường được sử dụng phổ biến: Nikethamide, Rotunda, Haloperidol, Phenobarbital, Stilux, Diazepam,… Ngoài ra còn một số loại thuốc được bào chế từ thiên nhiên như: Thuốc Hoàn An Thần, Tâm An Lạc Tiên,…
**_Thuốc an thần tây Y được sử dụng nhiều để chữa mất ngủ_**
Thuốc an thần có thể được chia thành các nhóm:
  * Nhóm thuốc an thần mạnh như clopromazin, haloperidol,.v.v.
  * Nhóm thuốc an thần vừa và nhẹ như diazepam, rotunda,.v.v.
  * Nhóm thuốc có tác dụng gây ngủ như phenobarbital, diazepam,.v.v.
  * Nhóm thuốc có tác dụng chống co giật như phenobarbital, diazepam, carbamazepine,.v.v.


## **2. Lạm dụng thuốc an thần tây y để chữa mất ngủ**
Lạm dụng thuốc an thần là tình trạng sử dụng thuốc không theo chỉ dẫn. Người dân có thể sử dụng với liều cao hơn khuyến cáo hoặc tự ý sử dụng mà không có sự chỉ định của thầy thuốc.
Nếu trước đây, khi bị mất ngủ, người ta thường tìm đến các thực phẩm có tác dụng gây ngủ: lạc tiên, tâm sen trinh nữ, lá vông nem, củ bình vôi,… Nhưng ngày nay, người trẻ bị mất ngủ thường có xu hướng tìm tới các loại thuốc an thần tây y nhanh, tiện. Đặc biệt, hiện nay một số người nghiện Heroin còn sử dụng thêm các thuốc an thần nhẹ như seduxen giúp tăng hiệu quả Heroin. Việc sử dụng thuốc tràn lan hiện nay được xem là hành vi lạm dụng thuốc.
Điều đáng nói là, các loại thuốc an thần đang được bán rất phổ biến. Bất cứ ai cũng dễ dàng mua được những thuốc này tại các hiệu thuốc mà không cần đơn của bác sĩ.
## **3. Lạm dụng thuốc an thần tây y để chữa mất ngủ – hiểm họa khó lường**
### **Nhờn thuốc**
Thuốc an thần có tác dụng ức chế hoạt động thần kinh, gây ra trạng thái buồn ngủ cho cơ thể. Do đó, nhiều người mất ngủ đã tự tìm tới các thuốc này bất chấp những khuyến cáo ảnh hưởng tới não bộ cũng như những hệ lụy khác khi lạm dụng thuốc.
Nhiều người có thói quen tự mua các loại thuốc an thần và tự ý sử dụng không đúng liều lượng. Hành động này không chỉ làm giảm tác dụng của thuốc, mà còn dễ gây ra hiện tượng nhờn thuốc.
Thực tế cho thấy, có nhiều trường hợp sử dụng các loại thuốc an thần trị mất ngủ có tác dụng rõ rệt trong thời gian đầu. Tuy nhiên, sau đó, mất ngủ càng trở nên trầm trọng, thậm chí cả khi đã sử dụng thuốc an thần hay sau khi tăng liều sử dụng.
### **Lệ thuộc thuốc, nghiện thuốc**
Ngoài tác dụng gây ngủ, các thuốc an thần còn giúp thư giãn cơ thể. Tuy nhiên, nếu dùng thuốc không theo chỉ định của bác sỹ, có nguy cơ bị lệ thuộc thuốc.
_**Lạm dụng thuốc an thần chữa mất ngủ gây nhiều hệ lụy**_
Khi sử dụng các thuốc an thần này, đầu tiên, người bệnh sẽ nhận thấy các tác dụng với chỉ một liều thấp. Sau đó, để đạt được cảm giác dễ chịu ban đầu, người ta phải dần dần tăng liều. Hiện tượng này gọi là dung nạp thuốc. Nhiều thuốc nhóm an thần nhẹ có thể gây ra quá trình dung nạp rất sớm. Bởi vậy, người dùng dễ dàng bị lệ thuộc các thuốc này chỉ sau một thời ngắn. Lệ thuộc thuốc an thần làm người dùng luôn luôn có nhu cầu sử dụng thuốc. Việc ngừng sử dụng hoặc kiểm soát liều dùng là rất khó thực hiện. Hậu quả là, người dùng sẽ gặp nhiều vấn đề khác về sức khỏe, tiền bạc, công việc…
### **Gây rối loạn hoạt động của não bộ**
Rõ ràng, các thuốc an thần có tác dụng trực tiếp tới hệ thần kinh gây ra các tác dụng của thuốc. Trong những trường hợp lạm dụng thuốc an thần, hệ thần kinh trung ương có thể bị ức chế, gây ra những rối loạn trong hoạt động của não bộ.
_**Lạm dụng thuốc an thần chữa mất ngủ có thể gây rối loạn hoạt động của não bộ**_
Nếu tiếp tục sử dụng các loại thuốc an thần thường xuyên còn có thể gây ra trạng thái rối loạn cảm xúc. Do đó, người bệnh có thể bị lo âu, căng thẳng kéo dài, thậm chí là trầm cảm.
### **Ảnh hưởng hô hấp, tim mạch**
Ảnh hưởng của việc lạm dụng các thuốc an thần có thể đặc biệt nguy hiểm trong trường hợp người dùng có các vấn đề về hô hấp hay tim mạch.
Nhiều thuốc đã ghi nhận có khả năng ức chế trung tâm hô hấp. Bởi vậy, cần phải sử dụng thuốc theo hướng dẫn của bác sỹ nếu bạn mắc các vấn đề trên.
Nhiều nghiên cứu cũng đã cho thấy, tỷ lệ tử vong do nhồi máu cơ tim trong nhóm những người thường xuyên sử dụng thuốc ngủ cũng cao hơn đáng kể so với nhóm ít hoặc hiếm khi sử dụng những thuốc này. Mặt khác, số nạn nhân của tai biến mạch máu não cũng cao gấp 3 lần trong nhóm người cao huyết áp trước đó có lệ thuộc thuốc an thần so với nhóm không lệ thuộc. Rõ ràng, lạm dụng thuốc an thần gây ngủ cũng làm tăng nguy cơ tai biến mạch não, tử vong.
### **Không trị được tận gốc của vấn đề**
Người mất ngủ cần phải biết rằng, các thuốc an thần chỉ hỗ trợ làm bạn dễ ngủ, chứ không điều trị được tận gốc. Cần phải xác định được nguyên nhân gây mất ngủ để có những biện pháp điều trị phù hợp. Có nhiều nguyên nhân gây ra mất ngủ. Các nguyên nhân chính là trầm cảm, rối loạn tuần hoàn, huyết áp, lo âu,… Thậm chí có những trường hợp mất ngủ do lạm dụng thuốc an thần trước đó. Với từng nguyên nhân sẽ có những hình thức điều trị cụ thể khác nhau.
Tìm hiểu thêm: [**Tổng quan về chứng mất ngủ**](https://bvnguyentriphuong.com.vn/noi-tam-than-kinh/tong-quan-ve-chung-mat-ngu)
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [1. Những điều cần biết về thuốc an thần](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/lam-dung-thuoc-an-than-de-chua-mat-ngu-hiem-hoa-kho-luong#1-nhng-iu-cn-bit-v-thuc-an-thn)
  * [2. Lạm dụng thuốc an thần tây y để chữa mất ngủ](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/lam-dung-thuoc-an-than-de-chua-mat-ngu-hiem-hoa-kho-luong#2-lm-dng-thuc-an-thn-ty-y-cha-mt-ng)
  * [3. Lạm dụng thuốc an thần tây y để chữa mất ngủ – hiểm họa khó lường](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/lam-dung-thuoc-an-than-de-chua-mat-ngu-hiem-hoa-kho-luong#3-lm-dng-thuc-an-thn-ty-y-cha-mt-ng-him-ha-kh-lng)
  * [Lệ thuộc thuốc, nghiện thuốc](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/lam-dung-thuoc-an-than-de-chua-mat-ngu-hiem-hoa-kho-luong#l-thuc-thuc-nghin-thuc)
  * [Gây rối loạn hoạt động của não bộ](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/lam-dung-thuoc-an-than-de-chua-mat-ngu-hiem-hoa-kho-luong#gy-ri-lon-hot-ng-ca-no-b)
  * [Ảnh hưởng hô hấp, tim mạch](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/lam-dung-thuoc-an-than-de-chua-mat-ngu-hiem-hoa-kho-luong#nh-hng-h-hp-tim-mch)
  * [Không trị được tận gốc của vấn đề](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/lam-dung-thuoc-an-than-de-chua-mat-ngu-hiem-hoa-kho-luong#khng-tr-c-tn-gc-ca-vn-)



## ️ Sử dụng nước muối sinh lý hiệu quả tại nhà

  * [Tác dụng của nước muối sinh lý](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/3-cach-su-dung-nuoc-muoi-sinh-ly-hieu-qua#tc-dng-ca-nc-mui-sinh-l)
  * [Cách sử dụng nước muối sinh lý](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/3-cach-su-dung-nuoc-muoi-sinh-ly-hieu-qua#cch-s-dng-nc-mui-sinh-l)
  * [Dùng làm thuốc nhỏ/rửa mắt](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/3-cach-su-dung-nuoc-muoi-sinh-ly-hieu-qua#dng-lm-thuc-nhra-mt)
  * [Dùng làm thuốc nhỏ/rửa mũi](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/3-cach-su-dung-nuoc-muoi-sinh-ly-hieu-qua#dng-lm-thuc-nhra-mi)
  * [Dùng để súc miệng – họng](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/3-cach-su-dung-nuoc-muoi-sinh-ly-hieu-qua#dng-sc-ming-hng)
  * [Dùng làm sạch mặt](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/3-cach-su-dung-nuoc-muoi-sinh-ly-hieu-qua#dng-lm-sch-mt)


## **Tác dụng của nước muối sinh lý**
Nước muối (natri clorid) được pha chế với tỷ lệ 0,9%, tức 1 lít nước với 9g muối tinh khiết, được gọi là nước muối sinh lý và dùng được cho mọi lứa tuổi.
Trong y học, nước muối sinh lý được coi như một loại thuốc có khả năng hấp thu tốt qua đường tiêu hóa và đặc biệt có thể hấp thu rất nhanh bằng đường tiêm truyền tĩnh mạch…
Ngoài việc dùng để cung cấp và bổ sung nước cũng như chất điện giải cho cơ thể (dùng theo đường tiêm truyền theo chỉ định của bác sĩ) thì nước muối sinh lý còn có tác dụng:
  * Dùng để rửa mắt;
  * Dùng để rửa mũi;
  * Dùng súc họng;


_Nước muối sinh lý cần sử dụng đúng cách, đúng loại_
## **Cách sử dụng nước muối sinh lý**
Dưới đây là ba cách sử dụng nước muối sinh lý thường thấy và lưu ý.
### **Dùng làm thuốc nhỏ/rửa mắt**
Nên rửa mắt bằng nước muối sinh lý 0,9% dạng nhỏ mắt hàng ngày. Rửa mắt làm trôi đi mầm bệnh, đẩy rỉ ra ngoài, làm ẩm và an dịu cho bề mặt nhãn cầu.
Lưu ý, cần dùng loại nước muối do các công ty dược sản xuất dùng riêng cho mắt, bên ngoài nhãn của lọ thuốc có hình con mắt, thường đóng lọ 10ml. Không được tự pha nước muối để nhỏ mắt.
_Nước muối sinh lý dùng để nhỏ mắt_
### **Dùng làm thuốc nhỏ/rửa mũi**
Dùng nước muối sinh lý nhỏ trực tiếp hoặc dưới dạng khí dung có tác dụng làm sạch mũi – họng.
Nước muối sinh lý dùng để rửa mũi được pha chế dạng 100ml, 500ml, nhưng cũng có người sử dụng nước muối sinh lý truyền tĩnh mạch hoặc dùng nước nhỏ mắt để rửa mũi. Cần lưu ý, thuốc dùng để nhỏ mắt có thể dùng để nhỏ mũi nhưng thuốc dùng để nhỏ mũi thì không dùng nhỏ mắt.
Mũi là cửa ngõ đầu tiên của cơ quan hô hấp, tiếp xúc với rất nhiều bụi bặm, các hóa chất độc hại và các yếu tố gây bệnh. Khi bị viêm nhiễm, dùng nước muối sinh lý để làm sạch lớp mủ trước khi sử dụng thuốc để thuốc tác dụng trực tiếp vào lớp biểu mô của niêm mạc mũi và phát huy vai trò chữa bệnh.
Nhưng khi mũi hoàn toàn trong trạng thái bình thường, thì không nên sử dụng nước muối thường xuyên để rửa mũi.
Vì việc sử dụng thường xuyên nước muối sinh lý để làm sạch mũi sẽ vô tình làm mất đi lớp thảm nhầy bảo vệ mũi vốn có, mất đi chức năng bảo vệ mũi của lớp thảm này và gây tổn thương niêm mạc mũi.
Chính vì thế mũi lại hay bị viêm hơn. Có thể sử dụng nước muối sinh lý một lần mỗi tuần, đặc biệt là khi làm việc hoặc đi lại ở những vùng nhiều bụi bặm.
_Nước muối sinh lý dùng để súc họng_
### **Dùng để súc miệng – họng**
Để thuận tiện có thể dùng muối ăn (NaCl): 1 thìa cà phê (5g) pha trong 1 cốc nước ấm vừa giúp bảo vệ lớp tế bào niêm mạc họng vừa có tác dụng sát khuẩn. Một số người quan niệm nước muối nồng độ càng cao thì sát khuẩn càng tốt. Điều này là hoàn toàn sai lầm.
Nếu dùng nước muối quá đặc (mặn) để súc miệng – họng rất dễ gây tổn thương các tế bào ở miệng – họng. Nồng độ nước muối phù hợp là 0,9% (tương đương nước canh). Nên dùng nước muối để vệ sinh răng miệng sau đánh răng buổi tối, buổi sáng.
Cách súc họng bằng nước muối sinh lý: Ngậm 1 ngụm nước muối, ngửa cổ, há miệng kêu khà…khà…khà… sau đó ngậm miệng nghỉ một lát, lại ngửa cổ há miệng kêu, làm như vậy vài ba lần rồi nhổ đi. Mỗi lần làm 3 lượt.
Không nên ngậm vào rồi nhổ ra ngay, nên cố gắng ngậm lâu tối đa, súc vài lần, mỗi lần vài ba ngụm không chỉ để sạch các nhày, mủ (nếu có) trong họng mà đảm bảo tác dụng sát khuẩn. Mỗi ngày nên thực hiện súc họng 1 – 3 lần.
## **Dùng làm sạch mặt**
Ngoài các tác dụng nêu trên, nước muối sinh lý còn được dùng để rửa mặt bởi tính sát trùng và kháng khuẩn cao. Dưới đây là một số tác dụng khi **dùng nước muối sinh lý để làm sạch mặt** :
  * Hỗ trợ điều trị **mụn trứng cá** : Tẩy tế bào chết, vệ sinh, làm sạch lỗ chân lông bị tắc nghẽn, loại bỏ những chất không cần thiết, bã nhờn, vi khuẩn, bụi bám trên mặt da
  * Cân bằng độ ẩm cho da: Đặc tính giữ nước của muối giúp ngăn ngừa tình trạng thừa dầu trên bề mặt da, từ đó duy trì độ ẩm cho da, giúp da khỏe mạnh.


Một số lưu ý **dùng nước muối sinh lý để làm sạch mặt** đúng cách và không gây hại cho da:
  * Nên sử dụng miếng vải bông sạch, mềm (bông tẩy trang) nhúng vào dung dịch nước muối sinh lý để thoa lên mặt trong khoảng 2 phút, sau đó rửa sạch da mặt bằng nước ấm.
  * Ngưng dùng nước muối sinh lý khi thấy không phù hợp với da.
  * Sử dụng kem chống nắng khi ra ngoài vì nước muối sinh lý có thể khiến da dễ bị bắt nắng hơn.


Với nồng độ NaCl 0,9%, **nước muối sinh lý** là dung dịch có thể được dùng để rửa sạch mặt vì giúp tẩy tế bào chết và làm sạch da khỏi bụi bặm, vi khuẩn, hạn chế **nhiễm trùng**.
Xem thêm: [**Cấp cứu vết thương mạch máu**](https://bvnguyentriphuong.com.vn/cap-cuu/cap-cuu-vet-thuong-mach-mau)
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [Tác dụng của nước muối sinh lý](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/3-cach-su-dung-nuoc-muoi-sinh-ly-hieu-qua#tc-dng-ca-nc-mui-sinh-l)
  * [Cách sử dụng nước muối sinh lý](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/3-cach-su-dung-nuoc-muoi-sinh-ly-hieu-qua#cch-s-dng-nc-mui-sinh-l)
  * [Dùng làm thuốc nhỏ/rửa mắt](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/3-cach-su-dung-nuoc-muoi-sinh-ly-hieu-qua#dng-lm-thuc-nhra-mt)
  * [Dùng làm thuốc nhỏ/rửa mũi](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/3-cach-su-dung-nuoc-muoi-sinh-ly-hieu-qua#dng-lm-thuc-nhra-mi)
  * [Dùng để súc miệng – họng](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/3-cach-su-dung-nuoc-muoi-sinh-ly-hieu-qua#dng-sc-ming-hng)
  * [Dùng làm sạch mặt](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/3-cach-su-dung-nuoc-muoi-sinh-ly-hieu-qua#dng-lm-sch-mt)



## ️ Lưu ý cần thiết khi dùng thuốc chống nấm ketoconazol

  * [Thuốc chống nấm ketoconazol là gì?](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/can-than-khi-dung-thuoc-chong-nam-ketoconazol#thuc-chng-nm-ketoconazol-l-g)
  * [Một số tác dụng có hại của ketoconazol](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/can-than-khi-dung-thuoc-chong-nam-ketoconazol#mt-s-tc-dng-c-hi-ca-ketoconazol)


## **Thuốc chống nấm ketoconazol là gì?**
Đây là loại thuốc chống nấm tổng hợp giúp ngăn ngừa và chữa trị nhiễm độc nấm nói chung và trên da, nhất là các trường hợp bệnh nhân bị suy giảm miễn dịch như bệnh nhân AIDS. Tuy đã có các thuốc chống nấm mới hơn, ít tác dụng phụ hơn như fluconazol và itraconazol nhưng cơ chế tác dụng cũng tương tự như ketoconazol. Ketoconazol thường có tác dụng kìm hãm nấm nhưng thuốc cũng có thể diệt nấm ở nồng độ cao. Tác dụng diệt nấm của ketoconazol ở nồng độ cao có thể là do tác dụng hóa lý trực tiếp của thuốc trên màng tế bào nấm.
Với Candida albicans, các thuốc chống nấm loại azol ức chế sự biến đổi từ dạng bào tử chồi thành thể sợi có khả năng xâm nhập gây bệnh. Ketoconazol là thuốc chống nấm có phổ rộng, tác dụng trên nhiều loại nấm gây bệnh như Candida, Blastomyces dermatitidis, Coccidioides immitis… Thuốc còn tác dụng trên một vài vi khuẩn gram dương.
_Ketoconazol trị nấm trên da_
Ketoconazol hấp thu nhanh ở đường tiêu hóa, tốt nhất là ở pH acid. Sau khi uống, thuốc hòa tan trong dịch dạ dày và chuyển thành dạng muối hydroclorid rồi được hấp thu ở dạ dày. Sinh khả dụng của thuốc uống phụ thuộc vào pH dạ dày, pH tăng sẽ làm giảm hấp thu thuốc, do đó nếu dùng đồng thời với các thuốc làm tăng pH dạ dày sẽ làm giảm hấp thu ketoconazol.
Ảnh hưởng của thức ăn đối với tốc độ và mức độ hấp thu thuốc ở dạ dày còn chưa được xác định rõ, tuy nhiên nhà sản xuất cho rằng dùng ketoconazol với thức ăn sẽ làm tăng mức độ hấp thu thuốc và làm cho nồng độ thuốc trong huyết tương đậm đặc hơn, đó là do thức ăn làm tăng tốc độ và mức độ hòa tan của thuốc.
Nồng độ thuốc tối đa trong huyết tương đạt được sau khi uống 1 – 2 giờ.
Ketoconazol phân bố vào các dịch khớp bị viêm, nước bọt, mật, nước tiểu, sữa, gân, da, các mô mềm, tinh hoàn…Thuốc qua được nhau thai nhưng không qua được hàng rào máu – não nên chỉ đạt một lượng không đáng kể trong dịch não tủy.
Ketoconazol chuyển hóa một phần ở gan tạo ra các dẫn chất không có hoạt tính qua quá trình oxy hóa và thoái giáng vòng imidazol và piperazin. Con đường chính thải trừ thuốc và các chất chuyển hóa của nó là qua mật rồi vào phân.
Ketoconazol được chỉ định trong bệnh nấm toàn thân, nấm Candida ở da, niêm mạc nặng, mạn tính, nhiễm nấm dai dẳng ở âm đạo, nhiễm nấm miệng, cổ họng và dạ dày, ruột hoặc cơ quan nội tạng khác. Tuỳ theo tình trạng nhiễm nấm của cơ thể mà lựa chọn dạng bào chế thích hợp.
Ketoconazol có thể gây độc cho gan vì thế không nên dùng cho những người đã bị bệnh gan. Biến chứng ở gan thường gặp nhiều hơn ở người cao tuổi, phụ nữ, người nghiện rượu hoặc bị suy chức năng gan do những nguyên nhân khác.
Vì ketoconazol cũng có khả năng ức chế quá trình tổng hợp các steroid và chuyển hóa vitamin D, do đó khi điều trị kéo dài ở trẻ em nên hết sức thận trọng.
Dùng ketoconazol kéo dài nhằm dự phòng các bệnh nấm cho những người suy giảm miễn dịch có thể gây ra những thay đổi hormon nghiêm trọng.
Ketoconazol qua được nhau thai, nhưng còn chưa có những nghiên cứu đầy đủ ở người. Thuốc chỉ dùng cho người mang thai khi lợi ích điều trị xác đáng hơn các nguy cơ có thể gây ra cho thai nhi. Thuốc có thể tiết vào sữa, do đó người mẹ đang điều trị với ketoconazol không nên cho con bú.
_Ketoconazol_
## **Một số tác dụng có hại của ketoconazol**
Tác dụng không mong muốn (ADR) của ketoconazol thường gặp trên hệ tiêu hóa là buồn nôn, nôn, đau bụng, táo bón, đầy hơi, chảy máu đường tiêu hóa, tiêu chảy. Các tác dụng này có liên quan đến liều dùng và có thể giảm thiểu nếu dùng thuốc cùng với thức ăn. Hầu hết, các trường hợp độc với gan đã được ghi nhận ở những người bệnh dùng thuốc trị nấm móng và ở nhiều người khác dùng thuốc trị các bệnh nấm da mạn tính dai dẳng.
Mặc dù tác dụng độc do ketoconazol gây ra với gan thường có thể hồi phục sau khi ngừng thuốc vài tháng nhưng cũng đã xảy ra một số hiếm trường hợp xấu như hoại tử gan cấp, biến đổi mỡ ở gan hoặc tử vong. Nếu phải điều trị kéo dài thì trước khi dùng thuốc, cần xét nghiệm chức năng gan và suốt thời gian điều trị cứ 1 hoặc 2 tháng lại kiểm tra ít nhất một lần, đặc biệt là những người bệnh đang dùng các thuốc khác có độc tính mạnh với gan như thuốc chống lao, kháng sinh. 
Khi kết quả xét nghiệm chức năng gan thay đổi đáng kể, hay không bình thường kéo dài hoặc xấu đi hoặc kèm theo những biểu hiện rối loạn chức năng gan khác, cần ngừng thuốc. Có thể uống ketoconazol trong hoặc sau khi ăn nhằm làm giảm buồn nôn và nôn.
Vì ketoconazol có độc tính cao với gan nên khi người bệnh dùng thuốc chống nấm đồng thời với các thuốc khác cũng có khả năng gây độc cho gan, nên phải theo dõi cẩn thận, nhất là đối với những người cần điều trị kéo dài hoặc đã có tiền sử bị bệnh gan. Tránh để đông lạnh dạng hỗn dịch uống và kem bôi ngoài có ketoconazol.
Dạng xà phòng gội đầu cần tránh ánh sáng. Ketoconazol có nhiều dạng bào chế như thuốc uống, kem bôi, dầu gội đầu, hỗn dịch uống nên phải tuân thủ liều điều trị và không nên sử dụng đồng thời các dạng bào chế khác nhau nhưng cùng chứa hoạt chất này. 
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [Thuốc chống nấm ketoconazol là gì?](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/can-than-khi-dung-thuoc-chong-nam-ketoconazol#thuc-chng-nm-ketoconazol-l-g)
  * [Một số tác dụng có hại của ketoconazol](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/can-than-khi-dung-thuoc-chong-nam-ketoconazol#mt-s-tc-dng-c-hi-ca-ketoconazol)



## ️ Thuốc xịt chữa viêm mũi dị ứng: lưu ý dùng đúng cách

  * [1. Các loại thuốc xịt chữa viêm mũi dị ứng thường dùng](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/dung-thuoc-xit-chua-viem-mui-di-ung-dung-cach#1-cc-loi-thuc-xt-cha-vim-mi-d-ng-thng-dng)
  * [Nước muối NaCl 0.9%](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/dung-thuoc-xit-chua-viem-mui-di-ung-dung-cach#nc-mui-nacl-09)
  * [Thuốc corticosteroid](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/dung-thuoc-xit-chua-viem-mui-di-ung-dung-cach#thuc-corticosteroid)
  * [2. Không nên lạm dụng thuốc nhỏ chữa viêm mũi dị ứng](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/dung-thuoc-xit-chua-viem-mui-di-ung-dung-cach#2-khng-nn-lm-dng-thuc-nh-cha-vim-mi-d-ng)
  * [2.1. Những lưu ý khi sử dụng thuốc xịt mũi chữa viêm mũi dị ứng](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/dung-thuoc-xit-chua-viem-mui-di-ung-dung-cach#21-nhng-lu-khi-s-dng-thuc-xt-mi-cha-vim-mi-d-ng)
  * [2.2. Những tác hại sau bạn có thể gặp phải nếu liên tục quen dùng thuốc xịt để chữa viêm mũi dị ứng](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/dung-thuoc-xit-chua-viem-mui-di-ung-dung-cach#22-nhng-tc-hi-sau-bn-c-th-gp-phi-nu-lin-tc-quen-dng-thuc-xt-cha-vim-mi-d-ng)
  * [Tình trạng nhờn thuốc](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/dung-thuoc-xit-chua-viem-mui-di-ung-dung-cach#tnh-trng-nhn-thuc)
  * [Ảnh hưởng toàn thân](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/dung-thuoc-xit-chua-viem-mui-di-ung-dung-cach#nh-hng-ton-thn)
  * [Suy thượng thận cấp](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/dung-thuoc-xit-chua-viem-mui-di-ung-dung-cach#suy-thng-thn-cp)


## **1. Các loại thuốc xịt chữa viêm mũi dị ứng thường dùng**
### **Nước muối NaCl 0.9%**
_Nước muối NaCl 0.9% chữa viêm mũi dị ứng_
Nước muối NaCl 0.9% có thể dùng cho nhiều đối tượng người bệnh, trong đó có cả trẻ em và người cao tuổi.
Nước muối NaCl 0.9% có tính sát trùng cao và không gây tác dụng phụ. Tuy nhiên, nước muối NaCl 0.9% không có tác dụng với những trường hợp viêm mũi dị ứng nặng.
### **Thuốc co mạch**
Thuốc co mạch có thành phần kháng sinh, giúp tiêu viêm, giảm phù nề nên sẽ có tác dụng rất tốt đối với tình trạng tắc, nghẹt mũi. tuy nhiên, người bệnh cáo không nên quá lạm dụng thuốc để tránh nhờn thuốc.
### **Thuốc corticosteroid**
Thuốc corticosteroid có thể điều trị rất hiệu quả các triệu chứng của bệnh viêm mũi dị ứng, đồng thời ngăn chặn bệnh tái phát về sau. Người bệnh cần sử dụng đúng theo liều lượng của bác sĩ.
## **2. Không nên lạm dụng thuốc nhỏ chữa viêm mũi dị ứng**
### **2.1. Những lưu ý khi sử dụng thuốc xịt mũi chữa viêm mũi dị ứng**
Những chai thuốc xịt với thiết kế nhỏ gọn có thể đem bên mình mỗi ngày nên những người bận rộn vẫn có thể tự mình chữa trị mỗi ngày. Tuy nhiên, người bệnh cần chú ý rằng các loại thuốc xịt đều không được dùng trong thời gian dài. Chỉ nên dùng từ 5-7 ngày cho mỗi đợt điều trị.
### **2.2. Những tác hại sau bạn có thể gặp phải nếu liên tục quen dùng thuốc xịt để chữa viêm mũi dị ứng**
#### **_Tình trạng nhờn thuốc_**
Người bệnh bị phụ thuộc quá nhiều vào loại thuốc đang dùng. Nếu ngưng sử dụng, các triệu chứng của bệnh sẽ lập tức tái phát mạnh mẽ hơn, bệnh tình chuyển biến xấu một cách nhanh chóng.
#### **_Ảnh hưởng toàn thân_**
Thuốc xịt mũi không chỉ tác dụng lên thành niêm mạc mũi mà chúng còn có thể thẩm thấu sâu lẫn vào máu, đi khắp cơ thể. Người dùng có thể gặp các hiện tượng như toát mồ hôi lạnh, run, tụt huyết áp, tim đập nhanh,…
#### **_Suy thượng thận cấp_**
Đây là tình trạng có thể gặp ở những ở những người dùng nhóm thuốc corticoid. Nhóm thuốc này chứa thành phần ngăn chặn các hoạt động ở tuyến thượng thận (do tuyến yên không thể tiết hormone). Về lâu dài, chức năng của tuyến này sẽ suy giảm rồi mất hẳn. Tuy nhiên, rủi ro này ít khi xảy ra đối với người sử dụng thuốc dạng xịt mà thường xảy ra với người sử dụng thuốc dạng uống.
Vì vậy, để đạt hiệu quả điều trị cao và đảm bảo an toàn trong quá trình sử dụng thuốc, người dùng cần nắm được cách sử dụng thuốc hợp lý để tránh nguy hiểm tới sức khỏe.
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [1. Các loại thuốc xịt chữa viêm mũi dị ứng thường dùng](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/dung-thuoc-xit-chua-viem-mui-di-ung-dung-cach#1-cc-loi-thuc-xt-cha-vim-mi-d-ng-thng-dng)
  * [Nước muối NaCl 0.9%](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/dung-thuoc-xit-chua-viem-mui-di-ung-dung-cach#nc-mui-nacl-09)
  * [Thuốc corticosteroid](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/dung-thuoc-xit-chua-viem-mui-di-ung-dung-cach#thuc-corticosteroid)
  * [2. Không nên lạm dụng thuốc nhỏ chữa viêm mũi dị ứng](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/dung-thuoc-xit-chua-viem-mui-di-ung-dung-cach#2-khng-nn-lm-dng-thuc-nh-cha-vim-mi-d-ng)
  * [2.1. Những lưu ý khi sử dụng thuốc xịt mũi chữa viêm mũi dị ứng](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/dung-thuoc-xit-chua-viem-mui-di-ung-dung-cach#21-nhng-lu-khi-s-dng-thuc-xt-mi-cha-vim-mi-d-ng)
  * [2.2. Những tác hại sau bạn có thể gặp phải nếu liên tục quen dùng thuốc xịt để chữa viêm mũi dị ứng](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/dung-thuoc-xit-chua-viem-mui-di-ung-dung-cach#22-nhng-tc-hi-sau-bn-c-th-gp-phi-nu-lin-tc-quen-dng-thuc-xt-cha-vim-mi-d-ng)
  * [Tình trạng nhờn thuốc](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/dung-thuoc-xit-chua-viem-mui-di-ung-dung-cach#tnh-trng-nhn-thuc)
  * [Ảnh hưởng toàn thân](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/dung-thuoc-xit-chua-viem-mui-di-ung-dung-cach#nh-hng-ton-thn)
  * [Suy thượng thận cấp](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/dung-thuoc-xit-chua-viem-mui-di-ung-dung-cach#suy-thng-thn-cp)



## ️ Các thuốc điều trị hạ acid uric

Có rất nhiều thuốc hạ acid uric được chấp thuận trong điều trị và được chia thành 03 nhóm như sau: (1) Nhóm giảm tổng hợp acid uric (ức chế men Xanthine Oxidase); (2) Nhóm tăng thải trừ acid uric; (3) Nhóm tiêu hủy acid uric.
**1. NHÓM THUỐC GIẢM TỔNG HỢP ACID URIC (ỨC CHẾ MEN XANTHINE OXIDASE - XO)**
**_1.1. Allopurinol_** được Cục quản lý thực phẩm và dược phẩm Hoa kỳ (Food and Drug Administration, viết tắt FDA) chấp thuận sử dụng điều trị hạ acid uric ở bệnh gút từ năm 1966 cho tới nay.
Allopurinol là thuốc ức chế men XO và nhanh chóng chuyển hóa thành oxypurinol để thải trừ qua thận. Trên lâm sàng, allopurinol được sử dụng để giảm nồng độ acid uric nhất là do viêm khớp gút và sỏi thận. Những chỉ định khác gồm tăng acid uric máu trong Hội chứng Lesch-Nyhan và trong bệnh đa u tủy xương.
Liều khởi đầu khuyến cáo hiện này của Allopurinol ở Mỹ là 100mg/ ngày và sẽ tăng dần liều sau mỗi 2-4 tuần tới liều 800mg/ ngày (đối với khuyến cáo châu Âu liều tối đa là 900mg/ ngày) cho đến khi đạt được nồng độ acid uric máu mục tiêu <6mg/dl.
Allopurinol khi sử dụng có thể gặp những tác dụng phụ sau: kích ứng dạ dày ruột, ban đỏ và Hội chứng Steven-Johnson. Ngoài ra còn có Hội chứng tăng nhạy cảm với Allopurinol (AHS) mặc dù hiếm gặp nhưng nguy cơ tử vong ở những BN này là 2-8%. Những biến chứng này có thể gặp với tỉ lệ cao hơn nếu BN có tình trạng suy thận, do đó cần chỉnh liều thuốc khi bệnh nhân có suy thận. Khi dùng cùng ampicillin hoặc amoxicillin có thể làm tăng tác dụng phụ của Allopurinol.
**_1.2. Febuxostat_** là một thuốc XO chọn lọc không purine được FDA chấp thuận năm 2009, thuốc được chỉ định điều trị tăng acid uric máu ở bệnh nhân có gút, nhưng không chỉ định cho những trường hợp tăng acid uric máu không triệu chứng, tại Mỹ chấp thuận liều điều trị 40-80 mg/ngày, tại Châu Âu liều dùng của thuốc có thể lên tới 120 mg/ngày và 10-60 mg/ngày ở Nhật Bản để đạt nồng độ acid uric máu dưới 6 mg/dL. Thanh thải febuxostat chủ yếu qua gan và dùng được với những bệnh nhân có suy giảm chức năng thận. Cơn gút cấp xuất hiện trong thời gian điều trị thường hay gặp với febuxostat hơn là allopurinol.
Trong khi febuxostat được chỉ định điều trị hạ acid uric máu khi bệnh nhân dị ứng với allopurinol, nhưng cũng cần thận trọng ở bệnh nhân có bệnh lí tim mạch. Sử dụng febuxostat trên lâm sàng vẫn còn thấp vì giá thành của nó cao hơn nhiều so với allopurinol.
**_1.3. Topiroxostat_** là một thuốc ức chế XO chọn lọc và không purin được chấp huận điều trị tại Nhật Bản từ năm 2013. Thuốc có hàm lượng 20, 40, 60 mg và được khuyến cáo khởi trị với liều 20 mg x 2 lần/ngày và liều tối đa là 80 mg x 2 lần/ngày. Tuy nhiên nhiều nghiên cứu chứng minh thấy liều hiệu quả trên lâm sàng là 120 mg/ngày kiểm soát được nồng độ acid uric mục tiêu. Topiroxostat cho thấy hiệu quả ức chế xanthine oxidase thông qua chuyển hóa hydroxylated 2 – pyridine tạo thành cầu nối molybdenum thông qua oxy và cũng tương tác với các đầu amino acid trong kênh hòa tan.
**2. NHÓM THUỐC TĂNG THẢI ACID URIC**
Nhiều nghiên cứu cho thấy, tăng acid uric máu ở một số bệnh nhân còn có thể là do giảm đào thải acid uric qua thận. Điều này gợi ý tới việc đưa các thuốc thải acid uric vào điều trị hạ acid uric máu. Nhóm thuốc này được lựa chọn như hàng thứ hai để giảm acid uric máu khi không đạt hiệu quả đối với thuốc ức chế men XO. Phối hợp hai nhóm thuốc này cho thấy hiệu quả hạ acid uric máu nhanh và giải quyết được các hạt Tophi. Không chỉ định nhóm thuốc tăng thải acid uric cho những bệnh nhân có sỏi thận.
Các thuốc thuộc nhóm này gồm: probenecid, benzbromarone, lesinurad. Một vài thuốc khác cũng có tác dụng tăng thải acid uric nhưng chưa rõ cơ chế như fenofibrate và losartan… và chưa được chấp thuận.
**_2.1. Probenencid_** là thuốc ức chế men URAT1. Thuốc không có tính chọn lọc và tương tác với nhiều thuốc vì vậy nó chưa được sử dụng nhiều trên lâm sàng.
**_2.1. Benzbromarone_** được đưa ra sử dụng từ những năm 1970, và là thuốc đầu tiên được sản xuất với mục đích hạ acid uric. Cơ chế dược lý cho thấy thuốc có tác dụng ức chế men URAT1 (IC50 22nM).
Thuốc có hiệu quả trong đơn trị liệu hạ acid uric máu ở 92% bệnh nhân gút đạt nồng độ urate 200 mg/ngày. Cũng giống như allopurinol, benzbromarone cần phải chỉnh liều 50 tới 200 mg mỗi ngày đề đạt tới liều điều trị hiệu quả. Có thể chỉ định benzbromarone ở những bệnh nhân có suy chức năng thận. Cần chú ý rằng, các thuốc thải acid uric được sử dụng để tăng đào thải acid uric qua thận, vì vậy cần chú ý với những bệnh nhân có sỏi thận, và những biện pháp kiềm hóa nước tiểu. Tuy nhiên benzbromaronde bị rút khỏi thị trường ở nhiều nước từ năm 2003 do các bằng chứng về độc tính với gan.
**_2.3. Lesinurad (RDEA594)_** là thuốc đào thải acid uric đầu tiên được đưa ra thị trường sau benzbromarone, năm 2015. Cơ chế đầu tiên của lesinurad là khả năng ức chế URAT1, và cả tác dụng trên kênh OAT1, OAT3 và OAT4 giúp tránh tương tác thuốc. Năm 2012, lesinurad được đưa vào thử nghiệm pha 3, điều trị phối hợp với các thuốc ức chế men XO (allopurinol hoặc febuxostat) ở những bệnh nhân gút có hạt Tophi. Điều trị phối hợp thuốc ức chế men XO với 200 mg Lesinurad được FDA chấp thuận ở những bệnh nhân không đạt nồng độ acid uric mong muốn sau khi điều trị thuốc ức chế men XO đơn độc. Chống chỉ định đối với những trường hợp có suy chức năng thận, ghép thận, bệnh nhân lọc máu, bệnh nhân có hội chứng ly giải khối u, hội chứng Lesch Nyhan.
**3. CÁC THUỐC HỦY URAT**
Nhóm thuốc này gồm có Pegloticase và Rasburicase
Ở người, uricase làm biến đổi acid uric thành chất allatonin tan trong nước và được đào thải qua thận. Chính vì vậy biện pháp truyền enzyme uricase tái tổ hợp được sử dụng trong những trường hợp cần hạ nhanh và tức thời acid uric máu đó chính là pegloticase, rasburicase. Thuốc được chấp thuận vào năm 2010 để điều trị gút kháng trị, gút có tophi gây hủy hoại khớp và các biến chứng. Thuốc được truyền 9mg mỗi hai tuần và trong vòng ít nhất 6 tháng. Tuy vậy do tính hạ acid uric máu nhanh, thuốc được biết tới với hệ quả làm tái phát cơn gút nhanh. Thuốc cũng gây kháng thuốc sau một vài tháng điều trị.
Các phản ứng không mong muốn của thuốc gặp ở 26-41% bệnh nhân bao gồm khó thở, đau ngực, bốc hỏa, nặng hơn có thể gặp tan máu, shock phản vệ. Phản ứng xuất hiện nhiều ở nhóm bệnh nhân xuất hiện kháng thể kháng thuốc. Trong các trường hợp này có thể điều trị corticoid, kháng histamine. Tuy nhiên cần thận trọng với bệnh nhân suy tim sung huyết.
Có thể bạn quan tâm: [**Các tiêu chí đánh giá bệnh Gout**](https://bvnguyentriphuong.com.vn/co-xuong-khop/cac-tieu-chi-danh-gia-benh-gout)
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh

## ️ Thuốc điều trị viêm gan B - một số thông tin chung

  * [Tổng quan về phương pháp điều trị thuốc cho bênh nhân viêm gan B](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/danh-sach-thuoc-dieu-tri-viem-gan-b-moi-nhat#tng-quan-v-phng-php-iu-tr-thuc-cho-bnh-nhn-vim-gan-b)
  * [Thuốc điều trị phơi nhiễm](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/danh-sach-thuoc-dieu-tri-viem-gan-b-moi-nhat#thuc-iu-tr-phi-nhim)
  * [Danh sách thuốc điều trị viêm gan B cho người lớn](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/danh-sach-thuoc-dieu-tri-viem-gan-b-moi-nhat#danh-sch-thuc-iu-tr-vim-gan-b-cho-ngi-ln)
  * [Danh sách thuốc điều trị viêm gan B cho trẻ nhỏ](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/danh-sach-thuoc-dieu-tri-viem-gan-b-moi-nhat#danh-sch-thuc-iu-tr-vim-gan-b-cho-tr-nh)
  * [Những lưu ý khi sử dụng thuốc kháng virus viêm gan B](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/danh-sach-thuoc-dieu-tri-viem-gan-b-moi-nhat#nhng-lu-khi-s-dng-thuc-khng-virus-vim-gan-b)


## **Tổng quan về phương pháp điều trị thuốc cho bênh nhân viêm gan B**
Điều trị viêm gan B cấp tính chủ yếu là điều trị triệu chứng để cơ thể tự chống lại nhiễm trùng.
Điều trị viêm gan B mạn tính có thể gồm điều trị triệu chứng và thuốc kháng vi-rút, chống nhiễm trùng hoặc ghép gan trong trường hợp nghiêm trọng hơn.
Hầu hết những người được chẩn đoán bị nhiễm viêm gan B mãn tính cần điều trị trong suốt quãng đời còn lại. Điều trị giúp giảm nguy cơ mắc bệnh gan và ngăn chặn việc truyền bệnh cho người khác.
## **Thuốc điều trị phơi nhiễm**
Bất cứ ai đã từng tiếp xúc với vi-rút viêm gan B đều cần điều trị dự phòng sau khi phơi nhiễm bao gồm tiêm vắc-xin viêm gan B (HBV) và immunoglobin viêm gan B (HBIG). Nhân viên y tế cho điều trị dự phòng sau khi tiếp xúc và trước khi nhiễm trùng cấp tính phát triển.
Việc điều trị dự phòng này không chữa khỏi nếu nhiễm trùng đã phát triển. Tuy nhiên, nó làm giảm tỷ lệ nhiễm trùng cấp tính.
_Điều trị dự phòng phơi nhiễm viêm gan B khi có tiếp xúc_
## **Danh sách thuốc điều trị viêm gan B cho người lớn**
**Interferons điều hòa miễn dịch**
  * Pegylated Interferon (Pegasys): tiêm 1 lần/tuàn thường trong 6 tháng đến 1 năm;


Thuốc có thể gây ra tác dụng phụ như triệu chứng giống cúm và trầm cảm.
  * Interferon Alpha (Intron A): tiêm nhiều lần một tuần thường trong 6 tháng đến 1 năm, nhưng điều trị có thể lâu hơn;


Thuốc có thể gây ra tác dụng phụ như triệu chứng giống cúm, trầm cảm và đau đầu. Đây là một loại thuốc cũ không được sử dụng thường xuyên.
**Thuốc kháng virus**
  * Tenofovir disoproxil (Viread): uống 1 viên/ngày trong ít nhất một năm hoặc lâu hơn, ít tác dụng phụ;
  * Tenofovir alafenamide (Vemlidy): uống 1 viên/ngày trong ít nhất một năm hoặc lâu hơn, ít tác dụng phụ;
  * Entecavir (Baraclude): uống 1 viên/ngày trong ít nhất một năm hoặc lâu hơn, ít tác dụng phụ;
  * Telbivudine (Tyzeka hoặc Sebivo): uống 1 viên/ngày trong ít nhất một năm hoặc lâu hơn, ít tác dụng phụ. Đây được coi là một lựa chọn điều trị dòng thứ hai;
  * Adefovir Dipivoxil (Hepsera): uống 1 viên/ngày trong ít nhất một năm hoặc lâu hơn, ít tác dụng phụ. Đây được coi là một lựa chọn điều trị bậc hai và bệnh nhân phải được theo dõi chức năng thận thường xuyên;
  * Lamivudine (Epivir-HBV, Zeffix hoặc Heptodin): uống 1 viên/ngày trong ít nhất một năm hoặc lâu hơn, ít tác dụng phụ. Thuốc cũ, ít hiệu quả hơn, hầu hết mọi người đều bị kháng thuốc trong vòng một hoặc hai năm.


## **Danh sách thuốc điều trị viêm gan B cho trẻ nhỏ**
Trẻ em nhiễm viêm gan B cần được theo dõi và điều trị bởi bác sĩ chuyên khoa nhi. Việc theo dõi, kiểm tra nên được thực hiện ít nhất 6 tháng/lần hoặc theo chỉ định của bác sĩ.
Một số loại thuốc dành cho trẻ em bị viêm gan B:
  * Entecavir (Baraclude): uống 1 viên/ngày trong ít nhất một năm hoặc lâu hơn, ít tác dụng phụ. Dành cho trẻ em từ 2 tuổi trở lên;
  * Tenofovir disoproxil (Viread) uống 1 viên/ngày trong ít nhất một năm hoặc lâu hơn, ít tác dụng phụ dành cho trẻ em từ 12 tuổi trở lên;
  * Peginterferon alfa-2a (Pegasys): tiêm 1 lần/tuàn thường trong 6 tháng đến 1 năm.


Thuốc có thể gây ra tác dụng phụ như triệu chứng giống cúm và trầm cảm.
Trẻ em phải được theo dõi chặt chẽ bởi một chuyên gia gan với các xét nghiệm máu thường xuyên.
  * Interferon alpha (Intron A): tiêm nhiều lần một tuần thường trong 6 tháng đến 1 năm, nhưng điều trị có thể lâu hơn.


Thuốc có thể gây ra tác dụng phụ như triệu chứng giống cúm, trầm cảm và đau đầu. Đây là một loại thuốc cũ không được sử dụng thường xuyên.
Trẻ phải được theo dõi chặt chẽ bởi một chuyên gia gan với các xét nghiệm máu thường xuyên.
Đây là một loại thuốc cũ ít được sử dụng.
  * Lamivudine (Epivir-HBV, Zeffix, Heptodin): uống 1 viên/ngày trong ít nhất một năm hoặc lâu hơn, ít tác dụng phụ. Thuốc cũ, ít hiệu quả hơn, hầu hết mọi người đều bị kháng thuốc trong vòng một hoặc hai năm.


Không phải mọi trẻ em bị viêm gan B mãn tính cần phải được điều trị. Trẻ cần được theo dõi bởi bác sĩ chuyên khoa gan dành cho nhi để được thăm khám thường xuyên và quyết định ddieuf trị trong trường hợp cần thiết.
_Điều trị viêm gan cần tuân thủ liệu trình điều trị_
## **Những lưu ý khi sử dụng thuốc kháng virus viêm gan B**
Một số người mắc bệnh viêm gan B mạn tính (lâu dài) không phát triển các vấn đề nghiêm trọng và có thể sống tích cực, sống đầy đủ mà không cần điều trị. Nhưng những người khác có thể bị tổn thương gan nghiêm trọng. Nếu điều này xảy ra thì có thể cần ghép gan.
Điều trị có thể không cần thiết cho tất cả những người bị viêm gan B bởi vì thuốc kháng vi-rút tốn kém và có thể không hiệu quả với tất cả mọi người.
Các chuyên gia khuyên dùng thuốc kháng vi-rút nếu bệnh nhân có nồng độ cao cả vi-rut viêm gan B và men gan trong máu ít nhất 6 tháng hoặc nếu bị bệnh gan.
Một số loại thuốc chống vi-rút ngăn chặn hoặc làm chậm sự phát triển của vi-rút viêm gan B có thể có tác dụng phụ nghiêm trọng lâu dài. Và một số có thể làm cho bệnh nhân cảm thấy mệt mỏi trong khi đang điều trị.
Bệnh nhân có thể không cần dùng thuốc kháng vi-rút nếu có mức men gan bình thường hoặc chỉ cao hơn một chút so với bình thường trong máu và sinh thiết cho thấy không có dấu hiệu tổn thương gan.
Những người đã cấy ghép nội tạng hoặc uống quá nhiều rượu hoặc sử dụng thuốc bất hợp pháp có thể không thể dùng được một số loại thuốc kháng vi-rút.
Bệnh nhân uống thuốc có thể sẽ cần phải dùng thuốc trong nhiều năm. Vì vậy, cần phải kiểm tra và xét nghiệm máu thường xuyên để xem vi-rút có còn hoạt động trong cơ thể hay không và để tìm hiểu xem gan hoạt động tốt như thế nào.
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [Tổng quan về phương pháp điều trị thuốc cho bênh nhân viêm gan B](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/danh-sach-thuoc-dieu-tri-viem-gan-b-moi-nhat#tng-quan-v-phng-php-iu-tr-thuc-cho-bnh-nhn-vim-gan-b)
  * [Thuốc điều trị phơi nhiễm](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/danh-sach-thuoc-dieu-tri-viem-gan-b-moi-nhat#thuc-iu-tr-phi-nhim)
  * [Danh sách thuốc điều trị viêm gan B cho người lớn](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/danh-sach-thuoc-dieu-tri-viem-gan-b-moi-nhat#danh-sch-thuc-iu-tr-vim-gan-b-cho-ngi-ln)
  * [Danh sách thuốc điều trị viêm gan B cho trẻ nhỏ](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/danh-sach-thuoc-dieu-tri-viem-gan-b-moi-nhat#danh-sch-thuc-iu-tr-vim-gan-b-cho-tr-nh)
  * [Những lưu ý khi sử dụng thuốc kháng virus viêm gan B](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/danh-sach-thuoc-dieu-tri-viem-gan-b-moi-nhat#nhng-lu-khi-s-dng-thuc-khng-virus-vim-gan-b)



## ️Sử dụng thuốc ngủ: Những vấn đề cần lưu ý

  * [Không được sử dụng rượu khi uống thuốc ngủ](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/8-luu-y-khi-su-dung-thuoc-ngu#khng-c-s-dng-ru-khi-ung-thuc-ng)
  * [Không nên làm tăng stress](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/8-luu-y-khi-su-dung-thuoc-ngu#khng-nn-lm-tng-stress)
  * [Thuốc ngủ có thể tương tác với các loại dược phẩm khác](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/8-luu-y-khi-su-dung-thuoc-ngu#thuc-ng-c-th-tng-tc-vi-cc-loi-dc-phm-khc)
  * [Không nên dùng thuốc ngủ khi đi du lịch qua 2 nơi có múi giờ khác nhau](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/8-luu-y-khi-su-dung-thuoc-ngu#khng-nn-dng-thuc-ng-khi-i-du-lch-qua-2-ni-c-mi-gi-khc-nhau)
  * [Cần biết cụ thể tác dụng của thuốc để đi ngủ và thức dậy đúng giờ](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/8-luu-y-khi-su-dung-thuoc-ngu#cn-bit-c-th-tc-dng-ca-thuc-i-ng-v-thc-dy-ng-gi)
  * [Nên tạo ra môi trường ngủ thân thiện](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/8-luu-y-khi-su-dung-thuoc-ngu#nn-to-ra-mi-trng-ng-thn-thin)
  * [Áp dụng các thói quen tự nhiên](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/8-luu-y-khi-su-dung-thuoc-ngu#p-dng-cc-thi-quen-t-nhin)


## **Không được sử dụng rượu khi uống thuốc ngủ**
Theo khuyến cáo của giới chuyên môn, sử dụng thuốc ngủ không nên uống rượu, tuy nhiên cũng có trường hợp nhiều người không thể bỏ được, nhất là khi nghỉ cuối tuần, phải tiếp khách…
Các chuyên gia ở Trung tâm điều trị bệnh rối loạn giấc ngủ Kettering (SDC) của Mỹ khuyến cáo, trong trường hợp không kiêng được thì chỉ nên uống 1 – 2 chén rượu nhỏ hoặc 2 cốc bia.
Nên uống vào buổi chiều trước khi đi ngủ ít nhất là 6 tiếng. Lý do, cồn có trong đồ uống này là chất kích thích và có thể can thiệp làm tăng tác dụng phụ của thuốc ngủ giống như đối với thuốc giảm đau. Tốt nhất khi đã phải sử dụng thuốc ngủ thì không nên uống rượu.
## **Ăn quá no**
Ăn quá no, nhất là trong trường hợp lễ tết, cuối tuần sẽ làm con người ta cảm thấy khó chịu và tăng khả năng mất ngủ ở nhóm người phải dùng đến thuốc ngủ.
Ăn quá no cho dù vào thời điểm nào trong ngày cũng đều gây bất lợi. Khi lượng đường trong máu tăng cao sẽ làm cho cơ thể có thêm năng lượng dẫn đến khó ngủ.
Với lý do trên những người mắc bệnh khó ngủ chỉ nên ăn khoảng 80% so với mức vừa đủ, không nên ăn quá no vào gần giờ đi ngủ.
## **Không nên làm tăng stress**
Trong trường hợp căng thẳng nếu dùng thuốc ngủ sẽ kém hiệu quả. Đó là kết luận rút ra từ nghiên cứu của các chuyên gia ở SDC đưa ra mới đây sau khi nghiên cứu ở nhóm người mất ngủ phải dùng thuốc.
Trường hợp stress cao mà người ta quen gọi là bồn chồn, lo lắng thì nên tư vấn bác sĩ để thay liều hoặc sử dụng loại thuốc khác có hiệu quả hơn. Ví dụ, có thể áp dụng liệu pháp thôi miên, thậm chí cả thuốc chống trầm cảm cũng sẽ có tác dụng tốt hơn.
## **Thuốc ngủ có thể tương tác với các loại dược phẩm khác**
Vào mùa lạnh, nhất là lúc giao mùa, bệnh cảm, cảm cúm phát triển mạnh, stress tăng cao sẽ làm suy yếu sức khỏe hệ miễn dịch cũng dễ gây mất ngủ.
Trong trường hợp này nếu dùng thuốc ngủ cùng với các loại thuốc không kê đơn (OTC) để chữa cảm cúm cũng dễ dẫn đến tình trạng phản ứng nghịch, gây bất lợi và làm giảm tác dụng của thuốc ngủ.
Ví dụ như hợp chất benadryl có trong diphenhydramine, đây là thuốc có chứa thành phần giảm đau nên giới chuyên môn khuyến cáo không nên uống trước 4 giờ khi đi ngủ.
Nó sẽ làm giảm tác dụng thuốc ngủ, trong trường hợp dùng nhiều loại thuốc với thuốc ngủ thì nên tư vấn kỹ bác sĩ.
## **Không nên dùng thuốc ngủ khi đi du lịch qua 2 nơi có múi giờ khác nhau**
Trường hợp du lịch khác múi giờ việc dùng thuốc ngủ sẽ không có tác dụng. Trong trường hợp này nên dùng melatonin trước 1 giờ khi đi ngủ sẽ có tác dụng hoặc tư vấn bác sĩ trước khi dùng bất kỳ loại thuốc nào để cho phù hợp với điều kiện địa lý cũng như sức khỏe của bản thân.
## **Cần biết cụ thể tác dụng của thuốc để đi ngủ và thức dậy đúng giờ**
Hầu hết các loại thuốc ngủ có hiệu quả trong vòng 8 giờ vì vậy cần tư vấn để dùng thuốc cho đúng tiến độ không nên uống thuốc muộn quá hoặc dậy sớm quá.
Nếu trường hợp không quá bận thì ngủ theo đúng giờ quy định của thuốc, nếu dậy sớm mà vẫn còn trong trạng thái buồn ngủ thì rất nguy hiểm, nhất là khi điều khiển các phương tiện giao thông. Trong trường hợp này nên tư vấn bác sĩ dùng thuốc có tác dụng ngắn hơn.
## **Nên tạo ra môi trường ngủ thân thiện**
Có những người khi dùng thuốc ngủ nhưng do lạ phòng, lạ giường vẫn khó ngủ. Trong trường hợp này giới chuyên môn khuyên nên mang theo vật dụng cá nhân như chăn, gối, mạng che mặt v v…hoặc có thể ngủ riêng theo sở thích hoặc chọn những nơi yên tĩnh để ngủ
## **Áp dụng các thói quen tự nhiên**
Mặc dù thuốc ngủ có thể giúp con người ngủ được nhưng để mang lại lợi ích cao nhất và lâu dài về mặt sức khỏe không nên lệ thuộc vào thuốc ngủ. Nếu cần có thể ngừng thuốc và chuyển sang áp dụng các kỹ thuật mang tính tự nhiên, thân thiện.
Tăng cường luyện tập để giảm stress, ăn uống khoa học, bỏ thuốc lá, rượu bia, giảm cân, tìm các liệu pháp luyện tập như dưỡng sinh, giao tiếp bạn bè tư vấn bác sĩ để tạo ra cuộc sống thoải mái, vô tư từ đó giấc ngủ đến nhanh hơn và chất lượng hơn.
Xem thêm: [**Tư vấn về vấn đề mất ngủ**](https://bvnguyentriphuong.com.vn/danh-sach-video/tu-van-ve-mat-ngu)
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [Không được sử dụng rượu khi uống thuốc ngủ](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/8-luu-y-khi-su-dung-thuoc-ngu#khng-c-s-dng-ru-khi-ung-thuc-ng)
  * [Không nên làm tăng stress](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/8-luu-y-khi-su-dung-thuoc-ngu#khng-nn-lm-tng-stress)
  * [Thuốc ngủ có thể tương tác với các loại dược phẩm khác](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/8-luu-y-khi-su-dung-thuoc-ngu#thuc-ng-c-th-tng-tc-vi-cc-loi-dc-phm-khc)
  * [Không nên dùng thuốc ngủ khi đi du lịch qua 2 nơi có múi giờ khác nhau](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/8-luu-y-khi-su-dung-thuoc-ngu#khng-nn-dng-thuc-ng-khi-i-du-lch-qua-2-ni-c-mi-gi-khc-nhau)
  * [Cần biết cụ thể tác dụng của thuốc để đi ngủ và thức dậy đúng giờ](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/8-luu-y-khi-su-dung-thuoc-ngu#cn-bit-c-th-tc-dng-ca-thuc-i-ng-v-thc-dy-ng-gi)
  * [Nên tạo ra môi trường ngủ thân thiện](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/8-luu-y-khi-su-dung-thuoc-ngu#nn-to-ra-mi-trng-ng-thn-thin)
  * [Áp dụng các thói quen tự nhiên](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/8-luu-y-khi-su-dung-thuoc-ngu#p-dng-cc-thi-quen-t-nhin)



## ️ Chống lại bệnh do nấm

Nấm xuất hiện ở xung quanh chúng ta. Chúng có thể sống trong đất, cũng có thể phát triển trên cơ thể chúng ta. Chúng tạo ra hàng triệu bào tử mà chúng ta hít vào và thở ra trong từng nhịp thở. Trong số hàng triệu loại nấm, chỉ có vài trăm loại có thể lây nhiễm sang người. Và những người có hệ thống miễn dịch khỏe mạnh sẽ dễ dàng chống lại sự lây nhiễm này, điều này làm cho nhiễm nấm toàn thân thường rất hiếm. Tuy nhiên, khi chúng thực sự tấn công được, nhiễm nấm toàn thân sẽ trở nên đặc biệt nguy hiểm, chúng có thể tấn công các cơ quan nội tạng, bao gồm não, tim và phổi. Theo ghi nhận của Quỹ Hành động Toàn cầu về Nhiễm nấm (GAFFI), nhiễm nấm toàn thân có tỷ lệ tử vong cao bất thường, khoảng 15 đến 50%, và giết chết hơn 1 triệu người mỗi năm.
Nhiễm nấm có xu hướng tấn công những người có hệ thống miễn dịch bị tổn thương. Và thực tế, nhóm người này đang ngày càng phổ biến trong các thập kỷ gần đây. Điều này là bởi vì càng ngày càng có nhiều loại thuốc giúp con người kéo dài sự sống, nhưng cái giá phải trả chính là sự suy yếu của hệ thống miễn dịch. Những loại thuốc này thường bao gồm một số liệu pháp hóa trị ung thư và thuốc ngăn cơ thể từ chối cấy ghép nội tạng.
Để điều trị nhiễm nấm, hiện nay các bác sĩ chỉ có bốn loại thuốc ít ỏi để lựa chọn, và nấm đã trở nên nhanh chóng kháng lại tất cả chúng. Chúng ta đang ngày càng mở rộng nhóm bệnh nhân có nguy cơ mắc bệnh nhiễm nấm, nhưng lại không làm được gì để cải thiện các hệ quả mà chúng đem lại. Trong 40 năm qua, không có một mảng y học nào đạt được ít tiến bộ hơn mảng điều trị các bệnh nhiễm do nấm.
Nhiều loại thuốc ngăn chặn sự phát triển của nấm thay vì giết chết chúng. Điều này đồng nghĩa với việc chúng ta đang thực sự cung cấp nhiều lựa chọn phong phú để nấm phát triển sức đề kháng. Với quá ít loại thuốc, các bác sĩ đã lo ngại về sự gia tăng số lượng trường hợp nhiễm nấm kháng thuốc – cả ở người khỏe mạnh cũng như người bệnh.
Việc tạo ra một hợp chất chống nấm hoạt động tốt là rất khó vì người và nấm có quan hệ mật thiết với nhau. Cả hai đều là sinh vật nhân thực và chia sẻ nhiều con đường sinh học giống nhau. Chúng ta có thể dễ dàng tìm thấy các hợp chất chống nấm, vấn đề là chúng sẽ giết chết bệnh nhân trước khi nấm được loại bỏ. Việc khai thác một số điểm khác biệt giữa người và nấm để phát triển thuốc chống nấm cũng đã được thực hiện, chẳng hạn như nấm có thành tế bào, trong khi tế bào người thì không, hay màng tế bào nấm chứa Ergosterol, trong khi màng tế bào người sử dụng Cholesterol. Tuy nhiên, những khác biệt này thường rất nhỏ và thực sự không có nhiều mục tiêu lựa chọn mà có thể khai thác từ góc nhìn phát triển thuốc chống nấm. Đây cũng là lý do chính giải thích cho việc tại sao kho vũ khí thuốc điều trị nhiễm nấm mà chúng ta hiện có vẫn còn rất ít.
Nếu muốn cải thiện kho vũ khí này cũng như khắc phục tình trạng kháng thuốc, chúng ta cần phải tìm kiếm các mục tiêu mới. Nên có các loại thuốc với một số cơ chế hoạt động khác nhau, được sử dụng trong dự phòng hoặc điều trị, hoặc cả hai, để điều trị các bệnh nhiễm nấm.
**Các thách thức phải đối mặt**
Trong khi các bác sĩ và nhà khoa học đang háo hức chờ đợi nhiều loại thuốc chống nấm được chấp thuận hơn, thì các công ty dược phẩm đã lưu ý rằng việc có được một loại thuốc kháng nấm thông qua các thử nghiệm lâm sàng là rất khó khăn và không đảm bảo thành công về mặt thương mại.
Một trong những thách thức lớn nhất đối với các thử nghiệm lâm sàng về thuốc kháng nấm là những người bị nhiễm nấm vốn dĩ đã ốm quá nặng. Họ thường mang nhiều căn bệnh tiềm ẩn do trải qua các đợt điều trị kéo dài và phải nằm trong phòng chăm sóc đặc biệt của bệnh viện. Vì vậy, khó có thể phân biệt được liệu một bệnh nhân chết là do thuốc không có tác dụng kháng nấm hay là do căn bệnh tiềm ẩn đã phát triển quá nặng. Bên cạnh đó, vì bệnh nhân quá ốm nên việc nhận được sự đồng ý của họ để đăng ký thử nghiệm lâm sàng thường rất khó khăn. Ngoài ra, các bác sĩ thường cho bệnh nhân sử dụng thuốc kháng nấm đã được phê duyệt ngay khi họ nghi ngờ bệnh nhân bị nhiễm nấm vì việc trì hoãn điều trị kháng nấm có thể khiến bệnh nhân tăng nguy cơ tử vong. Tuy nhiên, việc thử nghiệm một loại thuốc kháng nấm mới sau khi bệnh nhân sử dụng một loại thuốc đã được phê duyệt trước đó sẽ cho kết quả thiếu chính xác. Thêm nữa, phải mất khoảng 72 giờ để nuôi cấy nấm từ máu. Và cần kết quả của môi trường nuôi cấy đó để đăng ký một người vào thử nghiệm lâm sàng. Kết quả là phải đăng ký một bệnh nhân vào thử nghiệm lâm sàng vào cùng ngày mà kết quả cấy máu cho kết quả dương tính. Điều này là một thách thức về mặt hậu cần nhưng cũng có nghĩa là ứng cử viên thuốc đang được thử nghiệm muộn trong quá trình lây nhiễm.
Yếu tố thương mại cũng kìm hãm sự phát triển của thuốc chống nấm do nhiều nhà đầu tư và công ty không thấy nó mang lại lợi nhuận. Chỉ có một số lượng tương đối nhỏ người cần thuốc kháng nấm và họ thường chỉ dùng thuốc trong một thời gian ngắn, điều này giới hạn số tiền mà một công ty có thể kiếm được.
Nếu không có những nguồn tài trợ, các nhà khoa học lo lắng rằng việc phát triển thuốc chống nấm sẽ không phải là một ưu tiên hàng đầu. Theo Tiến sĩ Dược sĩ Lopez-Ribot tại Đại học Texas, San Antonio: “Đối với chúng tôi, những người đã tham gia vào lĩnh vực bệnh truyền nhiễm, bạn sẽ cảm thấy rằng chúng tôi là những người ít được chú ý”. Ông tự hỏi rằng Liệu đại dịch COVID-19 có thể khiến các công ty dược phẩm, cơ quan tài trợ và công chúng nghĩ lại và đầu tư thêm vào phát triển các liệu pháp điều trị bệnh truyền nhiễm, bao gồm cả nhiễm nấm, hay không? Ông nói: “Chúng ta có cảm giác sai lầm rằng chúng ta đã chiến thắng bệnh truyền nhiễm với kỷ nguyên kháng sinh. Tuy nhiên, đại dịch này lại đang nhắc nhở chúng ta rằng bệnh truyền nhiễm là loại bệnh thực sự có thể quét sạch tất cả.”
**Bệnh viện Nguyễn Tri Phương** - Bệnh viện Đa khoa Hạng I Thành phố Hồ Chí Minh

## ️ Tổng quan về dược chất, dược liệu

  * [1. Dược chất là gì?](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/tong-quan-ve-duoc-chat#1-dc-cht-l-g)
  * [2. Các thuật ngữ liên quan tới lĩnh vực dược.](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/tong-quan-ve-duoc-chat#2-cc-thut-ng-lin-quan-ti-lnh-vc-dc)


## 1. Dược chất là gì?
**Dược chất** là một chất hoặc hỗn hợp các chất dùng để sản xuất ra thuốc, có tác dụng dược lý hoặc có tác dụng để phòng bệnh, chẩn đoán bệnh, chữa bệnh, điều chỉnh chức năng sinh lý cơ thể người, từ đó giúp giảm nhẹ bệnh.
**Thuốc** là chất hoặc hỗn hợp các chất dùng cho con người nhằm lí do phòng bệnh, điều trị bệnh, nhận biết bệnh hoặc điều chỉnh hoạt động sinh lý cơ thể gồm có thuốc thành phẩm, nguyên liệu làm thuốc, vắc xin, sinh phẩm y tế, trừ thực phẩm chức năng.
**Thuốc từ dược chất** là thuốc được sản xuất từ nguyên liệu có nguồn gốc tự nhiên từ động vật, thực vật hoặc khoáng chất.
## 2. Các thuật ngữ liên quan tới lĩnh vực dược.
  * **_Dược liệu_** hay còn gọi là hoạt chất, bao gồm chất hoặc các hỗn hợp chất có mục đích để điều trị, được sử dụng trong **sản xuất thuốc**.
  * _**Nguyên liệu bào chế thuốc**_ là chất tham gia vào thành phần cấu tạo sản phẩm trong quy trình sản xuất thuốc


Thuốc từ **dược chất** là loại thuốc được sản xuất từ các nguyên liệu có nguồn gốc từ tự nhiên, có thể kể đến như: Động vật, thực vật hoặc khoáng chất. Thuốc có hoạt chất cũng được chiết xuất từ dược liệu. Tuy nhiên, thuốc có sự kết hợp của dược liệu với hoạt chất hóa học tổng hợp không được gọi là thuốc từ **dược chất**.
Thuốc Phương Đông cũng được gọi là **dược chất** do tính chất thuốc Phương Đông được bào chế theo phương pháp của y học cổ truyền ở các nước này.
  * **_Thuốc mới_** là thuốc chứa dược chất mới, thuốc có sự hòa quyện mới của các dược chất đã lưu hành.
  * **_Tiền chất_** được dùng làm thuốc là hóa chất không thể thiếu trong quá trình điều chế, sinh sản thuốc gây nghiện, thuốc điều trị liên quan tới tâm thần. Tiền chất là thành phần quan trọng tham gia vào công thức điều chế ra chất gây nghiện, chất hướng đến thần kinh.
  * **_Thuốc cần yếu_** là thuốc phục vụ nhu cầu bồi bổ sức khỏe của mọi người.
  * **_Thuốc ghi toa_** là thuốc cần được kê đơn bởi bác sĩ. Nếu tự ý mua, sử dụng không theo đúng chỉ dẫn của người kê đơn có thể gây nguy hiểm đến tính mạng, sức khoẻ. Người bán thuốc phải bán theo đơn thuốc của bác sĩ kê và được quy định bán thuốc ghi toa trong chuyên mục nhóm thuốc kê đơn.
  * **_Thuốc không kê đơn_** là thuốc khi bán và sử dụng không cần toa thuốc.
  * **_Thuốc gây nghiện_** là thuốc mà người bệnh sử dụng thuốc trong một thời gian dài sẽ có khả năng bị nghiện.
  * **_Thuốc phóng xạ_** là thuốc trong thành phần có chứa một hoặc nhiều chất phóng xạ, dùng trong chẩn đoán hoặc chữa bệnh.
  * **_Nguyên liệu để bào chế thuốc_** là những chất tham gia vào thành phần cấu tạo sản phẩm trong quy trình **sản xuất thuốc**.
  * **_Phản ứng phụ của thuốc_** là những tác dụng ngoài ý muốn, có thể xuất hiện ở liều dùng thông thường. Tùy từng người mới xuất hiện phản ứng phụ do thuốc.
  * **_Hạn sử dụng của thuốc_** là thời gian sử dụng được in rõ trong một lô thuốc mà sau thời gian này không được phép sử dụng thuốc nữa.
  * **_Thuốc giả_** là những loại thuốc không có tác dụng điều trị, người sản xuất tạo ra với mục đích lừa gạt người sử dụng, bao gồm những trường hợp sau đây:


  1. Sản phẩm không có **dược chất.**
  2. Có nguyên liệu, tuy nhiên, dược liệu không đúng so với hàm lượng đã đăng ký.
  3. Có **dược chất** không đúng với thành phần ghi trên bao bì sản phẩm.
  4. Giả mạo tên công ty, mẫu mã của loại thuốc đã đăng ký bảo hộ sở hữu của công ty khác.


**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [1. Dược chất là gì?](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/tong-quan-ve-duoc-chat#1-dc-cht-l-g)
  * [2. Các thuật ngữ liên quan tới lĩnh vực dược.](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/tong-quan-ve-duoc-chat#2-cc-thut-ng-lin-quan-ti-lnh-vc-dc)



## ️ Tìm hiểu những công dụng của Omega 3 đối với sức khỏe

  * [1. Omega 3 là gì và công dụng của Omega 3 đối với cơ thể](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/tim-hieu-nhung-cong-dung-cua-omega-3#1-omega-3-l-g-v-cng-dng-ca-omega-3-i-vi-c-th)
  * [Tìm hiểu về loại dưỡng chất Omega 3](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/tim-hieu-nhung-cong-dung-cua-omega-3#tm-hiu-v-loi-dng-cht-omega-3)
  * [Omega 3 và những lợi ích nổi bật về sức khỏe, sắc đẹp](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/tim-hieu-nhung-cong-dung-cua-omega-3#omega-3-v-nhng-li-ch-ni-bt-v-sc-khe-sc-p)
  * [2. Những loại thực phẩm giàu Omega 3](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/tim-hieu-nhung-cong-dung-cua-omega-3#2-nhng-loi-thc-phm-giu-omega-3)
  * [3. Tác dụng phụ khi sử dụng quá liều Omega 3](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/tim-hieu-nhung-cong-dung-cua-omega-3#3-tc-dng-ph-khi-s-dng-qu-liu-omega-3)


## **1. Omega 3 là gì và công dụng của Omega 3 đối với cơ thể**
Hiểu rõ về hợp chất Omega 3 và công dụng của nó sẽ giúp cho quá trình sử dụng đạt hiệu quả tốt nhất.
### **Tìm hiểu về loại dưỡng chất Omega 3**
Omega 3 là một trong những chất thuộc nhóm Axit béo gốc không no. Qua quá trình nghiên cứu, các chuyên gia nhận định rằng, Axit béo không no có thể tồn tại ở một số dạng phổ biến như: Alpha Lipoic Acid (ALA); Eicosapentaenoic Acid (EPA); Docosahexaenoic Acid (DHA).
Hiện nay, Omega 3 thường khá phổ biến và được nhiều người biết đến và truyền tai nhau về những công dụng nổi bật trong việc bảo vệ, nâng cao sức khỏe và sắc đẹp. Tuy nhiên cơ thể của mỗi chúng ta không thể tự sản sinh ra hàm lượng Omega 3. Do đó, cần chủ động bổ sung chúng thông qua thực đơn ăn uống hàng ngày hoặc viên uống theo chỉ định của bác sĩ để có thể cung cấp đủ lượng cần thiết cho cơ thể. 
Tùy theo từng độ tuổi lượng Omega 3 cần thiết cho cơ thể mỗi ngày sẽ có những mức quy định khác nhau:
  * Đối với người trưởng thành là 5.000 mg/ngày.
  * Đối với trẻ nhỏ là 50 đến 100mg/ngày.


Ngoài ra, để phát huy tốt nhất nhất công dụng của Omega 3, cần tham khảo ý kiến bác sĩ để có được những chỉ định phù hợp nhất, đặc biệt là đối tượng mắc một số bệnh lý như: tim mạch, huyết áp, tiểu đường hoặc đang mang thai.
### **Omega 3 và những lợi ích nổi bật về sức khỏe, sắc đẹp**
Công dụng nổi bật và được nhiều người biết đến khi nhắc đến Omega 3 đó là cải thiện thị lực và tăng cường phát triển não bộ. Ngoài ra, qua quá trình nghiên cứu, các chuyên gia dinh dưỡng còn nhận định rằng việc bổ sung đủ lượng Omega 3 cần thiết cho cơ thể mỗi ngày sẽ đem lại những công dụng nổi bật sau:
  * Hạn chế quá trình sản sinh ra những tác nhân có hại gây nên các bệnh về tim mạch như: rối loạn nhịp tim, suy tim, đột quỵ, nhồi máu cơ tim,...
  * Giúp hỗ trợ hiệu quả trong quá trình ngăn ngừa hình thành những mảng xơ vữa tại động mạch.
  * Omega 3 được nhiều bác sĩ chỉ định sử dụng cho bệnh nhân huyết áp cao nhằm hỗ trợ ổn định chỉ số huyết áp.
  * Omega 3 khi nạp vào cơ thể với lượng phù hợp còn có công dụng ngăn không cho những tiểu huyết cầu kết nối vào nhau, từ đó hạn chế hiệu quả tình trạng hình thành máu đông.
  * Một trong những công dụng của Omega 3 được nhiều người quan tâm nhất hiện nay đó là ngăn ngừa ung thư hiệu quả. Quá trình nghiên cứu đã chỉ ra rằng, những người bổ sung đủ hàm lượng Omega 3 cho cơ thể sẽ giảm 55% nguy cơ bị ung thư ruột, ung thư vú và ung thư tiền tuyến liệt.
  * Đối với người bị gan nhiễm mỡ, việc cung cấp đủ lượng Omega 3 cũng góp phần không nhỏ vào quá trình điều trị bệnh.
  * Trong một số nghiên cứu gần đây về công dụng của Omega 3 còn cho thấy chúng có khả năng điều trị trầm cảm và viêm khớp một cách hiệu quả. 
  * Ngoài những công dụng của Omega 3 được nêu trên, loại chất này còn giúp cải thiện chất lượng giấc ngủ, đẹp da, ngăn ngừa mụn nhờ quá trình kiểm soát lượng dầu thừa của da, làm chậm quá trình lão hóa,...


## **2. Những loại thực phẩm giàu Omega 3**
Những loại thực phẩm giàu Omega 3 được nhiều người chọn mua và chế biến trong khẩu phần ăn hàng ngày như:
  * Cá là một trong các nguồn thực phẩm có chứa hàm lượng Omega 3 cao, đặc biệt là các loại cá béo như: cá hồi, cá ngừ, cá trích,...
  * Dưỡng chất này thường được tìm thấy trong một số loại ngũ cốc và quả hạch như: quả óc chó, hạt bí ngô, hạt chia, ngũ cốc nguyên chất từ hạt,...
  * Rau củ quả không chỉ là nguồn cung cấp chất xơ dồi dào mà còn hỗ trợ hiệu quả trong việc bổ sung Omega 3 cho cơ thể, tiêu biểu là: cải xoăn, súp lơ, rau bó xôi, rau bina,...
  * Dầu được xem là nguồn cung cấp dồi dào Omega 3, đặc biệt là các loại dầu gan cá, dầu hạt lanh, dầu mù tạt, dầu óc chó,...
  * Ngoài ra, nếu cơ thể bị thiếu hụt Omega 3 và cần bổ sung một lượng lớn phù hợp, có thể tham khảo ý kiến để sử dụng các dạng viên uống. Quá trình sử dụng cần tuân thủ chỉ định của bác sĩ có chuyên môn. Đặc biệt, nên mua sản phẩm tại các cơ sở uy tín, chất lượng, tránh việc sử dụng hàng nhái, hàng kém chất lượng gây ảnh hưởng nghiêm trọng đến sức khỏe.


## **3. Tác dụng phụ khi sử dụng quá liều Omega 3**
Với những công dụng nổi bật mà Omega 3 đem lại, không ít đối tượng đã không tìm hiểu và tự ý tiến hành sử dụng. Việc lạm dụng công dụng của Omega 3 có thể gây nên một số hậu quả như:
  * Sử dụng quá mức lượng Omega 3 cho phép sẽ khiến cơ thể kích thích sản sinh ra Glucose gây tăng đường huyết. Do đó, những người bị tiểu đường cần cẩn trọng trong việc sử dụng Omega 3.
  * Một số nghiên cứu đã chỉ ra rằng, việc lạm dụng Omega 3 trong thời gian dài sẽ dẫn đến tình trạng chảy máu cam và chảy máu nướu.
  * Như đã đề cập, Omega 3 có công dụng làm giảm huyết áp cho bệnh nhân huyết áp cao. Do đó, với những người huyết áp thấp nên cẩn trọng trong việc sử dụng Omega 3 để tránh tình trạng bệnh chuyển biến phức tạp hơn.
  * Một trong những biểu hiện cảnh báo việc sử dụng quá liều Omega 3 đó là triệu chứng tiêu chảy, khó tiêu và có thể kèm theo đầy hơi, nôn ói, mỏi mệt,...
  * Những nhóm thực phẩm chứa Omega 3 thường sẽ kèm theo một hàm lượng lớn Vitamin A. Do đó, việc lạm dụng công dụng của Omega 3 có thể làm tăng lượng Vitamin A trong cơ thể, dẫn đến ngộ độc với những biểu hiện như: chóng mặt, hoa mắt, nôn ói, đau nhức khớp, da bị kích ứng,...


Xem thêm: [**Bổ sung omega-3: hai phương diện có tác dụng không đáng kể (nghiên cứu)**](https://bvnguyentriphuong.com.vn/nghien-cuu-duoc-dang-tai-tren-tap-chi-quoc-te/bo-sung-omega-3-hai-phuong-dien-co-tac-dung-khong-dang-ke)
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [1. Omega 3 là gì và công dụng của Omega 3 đối với cơ thể](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/tim-hieu-nhung-cong-dung-cua-omega-3#1-omega-3-l-g-v-cng-dng-ca-omega-3-i-vi-c-th)
  * [Tìm hiểu về loại dưỡng chất Omega 3](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/tim-hieu-nhung-cong-dung-cua-omega-3#tm-hiu-v-loi-dng-cht-omega-3)
  * [Omega 3 và những lợi ích nổi bật về sức khỏe, sắc đẹp](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/tim-hieu-nhung-cong-dung-cua-omega-3#omega-3-v-nhng-li-ch-ni-bt-v-sc-khe-sc-p)
  * [2. Những loại thực phẩm giàu Omega 3](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/tim-hieu-nhung-cong-dung-cua-omega-3#2-nhng-loi-thc-phm-giu-omega-3)
  * [3. Tác dụng phụ khi sử dụng quá liều Omega 3](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/tim-hieu-nhung-cong-dung-cua-omega-3#3-tc-dng-ph-khi-s-dng-qu-liu-omega-3)



## ️ Liệu trình điều trị kháng sinh ngắn cho các bệnh nhiễm trùng thông thường

* ACP: American College of Physicians (ACP ) là một tổ chức quốc gia của bác sĩ nội khoa, chuyên chẩn đoán và điều trị 
Gần một phần ba toa thuốc kê đơn kháng sinh có thời gian điều trị không hợp lý, dài hơn cần thiết dẫn đến các biến cố bất lợi của thuốc có thể xảy ra như phản ứng dị ứng, nhiễm Clostridioides difficile và tình trạng đề kháng kháng sinh – điều này xảy ra với khoảng 20% bênh nhận được kê toa kháng sinh.
Các chuyên gia ACP đưa ra khuyến cáo thực hành dựa trên bằng chứng về liệu trình sử dụng kháng sinh tối ưu cho các bệnh nhân nội trú và ngoại trú mắc các bệnh nhiễm trùng thông thường.
**Khuyến cáo chính:**
  1. Đợt cấp không biến chứng của bệnh phổi tắc nghẽn mạn tính (COPD) được đặc trưng bởi đàm có mủ cộng với khó thở tăng, tăng tiết đàm hoặc cả hai triệu chứng.


  * Vi khuẩn gây bệnh thông thường : Haemophilus influenzae, Streptococcus pneumoniae, Moraxella catarrhalis
  * Kháng sinh khuyến nghị sử dụng: Amoxicillin/ acid clavulanic, Azithromycin hoặc Doxycycline
  * Thời gian khuyến cáo sử dụng: 5 ngày


  1. Viêm phổi mặc phải ở cộng đồng


  * Vi khuẩn gây bệnh thông thường: . S.pneumoniae, influenzae,Mycoplasma pneumoniae (ít phổ biến hơn: Staphylococcus _aureus_ hoặc Legionella sp.)
  * Kháng sinh khuyến cáo sử dụng: Amoxicillin, Doxycycline, hoặc Azithromycin (cho bệnh nhân khoẻ mạnh); hoặc sử dụng kết hợp β-lactam với Macrolide hoặc kháng sinh Fluoquinolone hô hấp (cho các bệnh nhân mắc bệnh kèm)
  * Thời gian khuyến cáo sử dụng: 5 ngày (thời gian điều trị hơn 5 ngày nếu các dấu hiệu sinh tồn và ý thức vẫn trong tình trạng rối loạn)


  1. Nhiễm trùng đường tiểu


  * Viêm bàng quang không biến chứng ở phụ nữ: Nitrofurantoin trong 5 ngày, Trimethoprim-Sulfamethoxazole (TMP-SMZ) trong 3 ngày, hoặc Fosfomycin trong 1 ngày.
  * Viêm thận bể thận không biến chứng ở phụ nữ và nam giới: Fluroquinolone đường tiểu (Ciprofloxacin ….) trong 5 ngày hoặc TMP-SMZ trong 14 ngày. Nên làm kháng sinh đồ và xác định độ nhạy cảm của vi khuẩn để lựa chọn kháng sinh phù hợp.


  1. Viêm mô tế bào không sinh mủ


  * Vi khuẩn gây bệnh thường gặp: Streptococcus sp. hoặc  _aureus_
  * Kháng sinh khuyến cáo sử dụng (ngoại trừ trường hợp bệnh nhân bị chấn thương xuyên thấu hoặc có bằng chứng nhiễm MRSA [hiện tại hoặc trước đó]): Cephalosporin (Cephalexin….), Penicillin kháng tụ cầu (Dicloxacillin, Oxacillin, Nafcillin…) hoặc Clindamycin.
  * Thời gian khuyến cáo sử dụng: 5 ngày (đặc biệt đối với các bệnh nhân có khả năng tự theo dõi và theo dõi chặt chẽ ở các cơ sở chăm sóc ban đầu)


_ACP cho biết 5 ngày điều trị là liệu trình tối ưu_
**Bệnh viện Nguyễn Tri Phương** - Bệnh viện Đa khoa Hạng I Thành phố Hồ Chí Minh

## ️ Biến chứng có thể gặp khi lạm dụng Corticosteoroid

  * [1. Các dạng Steroid được sử dụng ](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/bien-chung-co-the-gap-khi-lam-dung-corticosteoroid#1-cc-dng-steroid-c-s-dng)
  * [2. Biến chứng khi sử dụng corticosteroid](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/bien-chung-co-the-gap-khi-lam-dung-corticosteoroid#2-bin-chng-khi-s-dng-corticosteroid)
  * [2.1. Biến chứng sớm](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/bien-chung-co-the-gap-khi-lam-dung-corticosteoroid#21-bin-chng-sm)
  * [Trên hệ tiêu hóa](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/bien-chung-co-the-gap-khi-lam-dung-corticosteoroid#trn-h-tiu-ha)
  * [Tác dụng trên hệ thần kinh](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/bien-chung-co-the-gap-khi-lam-dung-corticosteoroid#tc-dng-trn-h-thn-kinh)
  * [2.2. Biến chứng muộn](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/bien-chung-co-the-gap-khi-lam-dung-corticosteoroid#22-bin-chng-mun)
  * [Thay đổi trên da niêm, mô mỡ và mô cơ](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/bien-chung-co-the-gap-khi-lam-dung-corticosteoroid#thay-i-trn-da-nim-m-m-v-m-c)
  * [Đối với chuyển hóa](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/bien-chung-co-the-gap-khi-lam-dung-corticosteoroid#i-vi-chuyn-ha)
  * [Biến chứng ở mắt](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/bien-chung-co-the-gap-khi-lam-dung-corticosteoroid#bin-chng-mt)
  * [Các biến chứng khác](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/bien-chung-co-the-gap-khi-lam-dung-corticosteoroid#cc-bin-chng-khc)
  * [3. Biến chứng suy thượng thận sau khi ngưng dùng thuốc](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/bien-chung-co-the-gap-khi-lam-dung-corticosteoroid#3-bin-chng-suy-thng-thn-sau-khi-ngng-dng-thuc)
  * [4. Đánh giá người bệnh khi sử dụng corticosteroid](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/bien-chung-co-the-gap-khi-lam-dung-corticosteoroid#4-nh-gi-ngi-bnh-khi-s-dng-corticosteroid)
  * [4.1. Trước khi điều trị](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/bien-chung-co-the-gap-khi-lam-dung-corticosteoroid#41-trc-khi-iu-tr)
  * [4.2. Theo dõi khi sử dụng steroid](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/bien-chung-co-the-gap-khi-lam-dung-corticosteoroid#42-theo-di-khi-s-dng-steroid)
  * [4.3. Giảm thiểu các tác dụng phụ](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/bien-chung-co-the-gap-khi-lam-dung-corticosteoroid#43-gim-thiu-cc-tc-dng-ph)


## **1. Các dạng Steroid được sử dụng**
Với công dụng chống viêm, chống dị ứng, ức chế miễn dịch và điều trị thay thế, các corticosteroid (có thể gọi tắt là các steroid) ngày càng được ứng dụng rộng rãi trong điều trị. Tuy nhiên, khi bệnh nhân được chỉ định sử dụng các corticosteroid ngày càng nhiều thì việc cảnh báo nguy cơ gia tăng biến chứng khi sử dụng những thuốc này rất cần được lưu ý.
Các steroid được sử dụng dưới bốn dạng chính:
  * Dạng kem thoa thường được chỉ định trong điều trị các bệnh về
  * Dạng thuốc nhỏ mắt.
  * Dạng khí dung hoặc dạng hít: được dùng trong điều trị các bệnh về hen phế quản và bệnh phổi tắc nghẽn mạn tính.
  * Dạng toàn thân: dùng dưới dạng uống hoặc tiêm, truyền. Đây là dạng gây tác dụng phụ nhiều nhất.


## **2. Biến chứng khi sử dụng corticosteroid**
### **2.1. Biế****n chứng sớm**
#### _**Trên hệ tiêu hóa**_
Steroid gây viêm niêm mạc dạ dày, loét dạ dày – tá tràng, đôi khi cả trên niêm mạc đại tràng, nặng hơn có thể gây xuất huyết tiêu hóa. Các biến chứng này thường gặp trên bệnh nhân dùng phối hợp kháng viêm không-steroid. Ngoài ra, cũng có thể gây viêm tụy cấp nhưng hiếm gặp.
#### _**Tác dụng trên hệ thần kinh**_
Chỉ xảy khi dùng steroid liều cao. Triệu chứng thường gặp là rối loạn giấc ngủ, hưng phấn, nói sảng, hoang tưởng, trầm cảm, đôi khi có thể gây loạn thần cấp nếu bệnh nhân có tiền sử bệnh tâm thần.
#### _**Nhiễm trùng**_
Do tình trạng ức chế miễn dịch làm giảm sức đề kháng của cơ thể nên bệnh nhân dễ bị nhiễm trùng cơ hội với các vi trùng thường và có thể gây bùng phát lao tiềm ẩn trước đó. Gây nhiễm nấm candida và .. tình trạng nhiễm virus như thuỷ đậu, zona, herpes trở nên cấp tính.
### **2.2. Biế****n chứng muộn**
#### _**Thay đổi trên da niêm, mô mỡ và mô cơ**_
Khi sử dụng steroid với liều cao trên mức sinh lý (Prednisone 7,5 mg/ngày hoặc Hydrocortisone 30 mg/ngày) trong thời gian dài. Thông thường trên 4 tuần, bệnh nhân sẽ bắt đầu xuất hiện biến chứng mạn thể hiện trên da niêm, mô mỡ và mô cơ gây nên kiểu hình Cushing.
Da mỏng, dễ bị bầm, vết rạn da ở vùng bụng, ngực, mông và đùi, chậm liền sẹo. Ngoài ra, bệnh nhân còn có triệu chứng rậm lông, mụn trứng cá do tình trạng cường androgen. Dị hóa mỡ, tái phân bố mỡ ở các vùng đặc biệt như mặt làm cho mặt tròn như mặt trăng, bướu mỡ vùng sau gáy, vùng trên đòn, kèm theo tình trạng dị hóa đạm teo cơ chân tay.
#### _**Loãng xương**_
Theo một nghiên cứu ở Anh, tỷ lệ bệnh nhân dùng steroid lâu dài chiếm khoảng 0,5%, trong đó phụ nữ trên 55 tuổi chiếm 1,7% và bệnh nhân trên 70 tuổi chiếm 2,5%. Khoảng 30 – 50% bệnh nhân có tăng cortisol (nội sinh + ngoại sinh) có giảm mật độ xương. Đối với bệnh nhân dùng corticoid tổng liều > 30 g Prednisone/năm có thể làm tăng nguy cơ loãng xương 70%, nguy cơ gãy xương 53%.
Loãng xương xảy ra trên bệnh nhân dùng steroid lâu ngày, thường là Prednisone > 5 mg/ngày và > 6 tháng. Mật độ xương giảm nhanh sau vài tháng điều trị steroid và sau một năm mật độ xương giảm 5 – 15%. Tuy nhiên, chỉ có khoảng 4 – 14% bệnh nhân được điều trị loãng xương.
_Chẩn đoán bằng cách đo mật độ xương_ với máy DEXA, nên tầm soát cho bệnh nhân dùng Prednisone > 5 mg/ngày trong thời gian > 6 tháng. Gãy xương thường gặp trên bệnh nhân sử dụng steroid là ở cột sống và cổ xương đùi. Đôi khi gây biến chứng hoại tử chỏm xương đùi.
#### _**Đối với chuyển hóa**_
Gây tăng đường huyết, tăng nguy cơ đái tháo đường, rối loạn lipid-máu
#### _**Tim mạch**_
Gây tăng huyết và làm cho khó kiểm soát huyết áp ở các bệnh nhân cao huyết áp. Tăng nguy cơ xơ vữa mạch máu.
#### _**Biến chứng ở mắt**_
Thường nhất là đục thủy tinh thể dưới bao sau, chiếm khoảng 30% bệnh nhân dùng steroid kéo dài với liều Prednisone 10 – 15 mg/ngày trong thời gian dài. Ngoài ra, còn có thể gây tăng nhãn áp, viêm loét giác mạc do sử dụng steroid tại chỗ trong điều trị bệnh lý viêm kết mạc… Khám mắt định kỳ mỗi 6 – 12 tháng, đo nhãn áp mỗi 6 tháng trên bệnh nhân đang dùng steroid.
#### _**Các biến chứng khác**_
  * Chậm phát triển ở trẻ
  * Rối loạn điện giải: hạ kali-máu và kiềm chuyển hóa.
  * Rối loạn kinh nguyệt..


## **3. Biế****n chứng suy thượng thận sau khi ngưng dùng thuốc**
Thường xảy ra đối với bệnh nhân dùng steroid trên mức sinh lý với thời gian trên 3 tuần.
Triệu chứng lâm sàng thường rất mơ hồ, bệnh nhân có cảm giác mệt, ăn uống kém, buồn nôn và nôn sau ăn…
Sự hồi phục của trục hạ đồi – tuyến yên – tuyến thượng thận cần thời gian dài khoảng 9 – 18 tháng, đôi khi kéo dài trên 2 năm.
_Để giảm bớt tình trạng này:_ khi dùng thuốc liều cao kéo dài cần giảm liều dần dần, liều lớn hơn 7,5 mg/ngày thì giảm 2,5 mg mỗi 3 – 4 ngày, khi liều dùng 5 – 7,5 mg/ngày giảm 1 mg mỗi 2 tuần, có thể chuyển đổi 5 mg Prednisone sang 20 mg Hydrocortisone và giảm liều 2,5 mg/tuần. Khi bệnh nhân đã giảm xuống đến liều thay thế thì kiểm tra test Synacthen mỗi 3 tháng, để đánh giá dự trữ của tuyến thượng thận (Synacthen là biệt dược của Tetracosactide – một chất tổng hợp tương đương gồm 24 acid amin đầu tiên của adrenocorticotropic hormone (ACTH tự nhiên, từ thùy trước tuyến yên) – có vai trò kích thích sản xuất các glucocorticoid của tuyến thượng thận).
## **4. Đánh giá người bệnh khi sử dụng corticosteroid**
### **4.1. T****rước khi điều trị**
  * Cân nhắc kỹ giữa lợi ích của việc sử dụng steroid trên bệnh nhân và tác dụng phụ của thuốc.
  * Lựa chọn phác đồ điều trị steroid phù hợp: liều lượng và dạng thuốc steroid, thời gian sử dụng.


  * Bệnh nhân có các bệnh lý khác đi kèm làm bệnh nặng thêm khi sử dụng steroid: loạn thần, loét dạ dày – tá tràng, tăng huyết áp, nhiễm trùng nặng chưa được khống chế…
  * Các xét nghiệm cần tầm soát trước khi sử dụng steroid liều cao lâu dài: Công thức máu, Ion đồ, X-quang phổi, VS, BUN, Creatinin, AST, ALT, đường-huyết. Đối với bệnh nhân có triệu chứng đau thượng vị, cần nội soi dạ dày – tá tràng.


### **4.2. Theo dõi khi sử dụng steroid**
  * Các triệu chứng của bệnh có giảm không? Nên tăng hay giảm liều steroid? Có thể chuyển đổi sang dùng cách nhật được không?


  * Theo dõi các triệu chứng tiêu hóa, nhiễm trùng, cơ xương, thị lực…


  * Xét nghiệm: Đường huyết, Ion đồ, BUN, Creatinin, bilan lipid máu. Khám mắt bằng đèn khe, đo nhãn áp và mật độ xương 6 tháng/lần trên bệnh nhân dùng steroid lâu ngày.


### **4.3. Giảm thiểu các tác dụng phụ**
  * Nên dùng thuốc liều duy nhất 1 lần/ngày vào buổi sáng, phỏng theo nhịp sinh học của steroid.


  * Uống thuốc trong bữa ăn hay sau khi ăn
  * Hạn chế loãng xương: thay đổi lối sống tĩnh tại bằng cách tập luyện thể dục, kiêng rượu, bổ sung canxi 1500 mg/ngày + vitamin D 400 – 800 IU/ngày.


**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [1. Các dạng Steroid được sử dụng ](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/bien-chung-co-the-gap-khi-lam-dung-corticosteoroid#1-cc-dng-steroid-c-s-dng)
  * [2. Biến chứng khi sử dụng corticosteroid](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/bien-chung-co-the-gap-khi-lam-dung-corticosteoroid#2-bin-chng-khi-s-dng-corticosteroid)
  * [2.1. Biến chứng sớm](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/bien-chung-co-the-gap-khi-lam-dung-corticosteoroid#21-bin-chng-sm)
  * [Trên hệ tiêu hóa](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/bien-chung-co-the-gap-khi-lam-dung-corticosteoroid#trn-h-tiu-ha)
  * [Tác dụng trên hệ thần kinh](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/bien-chung-co-the-gap-khi-lam-dung-corticosteoroid#tc-dng-trn-h-thn-kinh)
  * [2.2. Biến chứng muộn](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/bien-chung-co-the-gap-khi-lam-dung-corticosteoroid#22-bin-chng-mun)
  * [Thay đổi trên da niêm, mô mỡ và mô cơ](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/bien-chung-co-the-gap-khi-lam-dung-corticosteoroid#thay-i-trn-da-nim-m-m-v-m-c)
  * [Đối với chuyển hóa](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/bien-chung-co-the-gap-khi-lam-dung-corticosteoroid#i-vi-chuyn-ha)
  * [Biến chứng ở mắt](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/bien-chung-co-the-gap-khi-lam-dung-corticosteoroid#bin-chng-mt)
  * [Các biến chứng khác](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/bien-chung-co-the-gap-khi-lam-dung-corticosteoroid#cc-bin-chng-khc)
  * [3. Biến chứng suy thượng thận sau khi ngưng dùng thuốc](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/bien-chung-co-the-gap-khi-lam-dung-corticosteoroid#3-bin-chng-suy-thng-thn-sau-khi-ngng-dng-thuc)
  * [4. Đánh giá người bệnh khi sử dụng corticosteroid](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/bien-chung-co-the-gap-khi-lam-dung-corticosteoroid#4-nh-gi-ngi-bnh-khi-s-dng-corticosteroid)
  * [4.1. Trước khi điều trị](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/bien-chung-co-the-gap-khi-lam-dung-corticosteoroid#41-trc-khi-iu-tr)
  * [4.2. Theo dõi khi sử dụng steroid](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/bien-chung-co-the-gap-khi-lam-dung-corticosteoroid#42-theo-di-khi-s-dng-steroid)
  * [4.3. Giảm thiểu các tác dụng phụ](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/bien-chung-co-the-gap-khi-lam-dung-corticosteoroid#43-gim-thiu-cc-tc-dng-ph)



## ️ Thuốc Steroid dùng đường uống

  * [Khi nào bạn được kê toa Steroid đường uống?](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/thuoc-steroid-dung-duong-uong#khi-no-bn-c-k-toa-steroid-ng-ung)
  * [Một số đặc điểm chung về steroid đường uống](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/thuoc-steroid-dung-duong-uong#mt-s-c-im-chung-v-steroid-ng-ung)
  * [Các tác dụng phụ của Steroid đường uống là gì?](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/thuoc-steroid-dung-duong-uong#cc-tc-dng-ph-ca-steroid-ng-ung-l-g)
  * [Ngưng Steroid đường uống](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/thuoc-steroid-dung-duong-uong#ngng-steroid-ng-ung)
  * [Tại sao phải giảm liều dần dần trước khi dừng Steroid đường uống?](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/thuoc-steroid-dung-duong-uong#ti-sao-phi-gim-liu-dn-dn-trc-khi-dng-steroid-ng-ung)
  * [Một số điểm quan trọng khác về steroid đường uống](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/thuoc-steroid-dung-duong-uong#mt-s-im-quan-trng-khc-v-steroid-ng-ung)
  * [Ai không thể sử dụng steroid đường uống?](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/thuoc-steroid-dung-duong-uong#ai-khng-th-s-dng-steroid-ng-ung)
  * [Có thể tự mua steroid đường uống không?](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/thuoc-steroid-dung-duong-uong#cth-t-mua-steroid-ng-ung-khng)


## **Steroid là gì?**
Steroid (còn được gọi là cortisone hoặc corticosteroid) là những chất hóa học tự nhiên (hormones) do cơ thể tự tạo ra, có tác dụng làm giảm viêm, ức chế hệ thống miễn dịch của cơ thể, ngăn chặn giải phóng histamine (một hóa chất trung gian được tạo ra trong phản ứng dị ứng). Người ta tổng hợp và sản xuất ra các thuốc kháng viêm chứa steroid bắt chước hoạt tính kể trên của các steroid tự nhiên.
Các loại steroid dùng trong điều trị được gọi là corticosteroids. Nó không phải là steroid đồng hóa (anabolic steroid) mà một số vận động viên và người tập thể hình sử dụng, steroid đồng hóa có tác dụng rất khác với thuốc kháng viêm chứa steroid. Steroid được đóng gói dưới nhiều dạng: viên nén, viên nén hòa tan, dung dịch, kem, thuốc mỡ, thuốc hít và tiêm.
Steroid đường uống là loại steroid mà bạn có thể dùng bằng đường miệng như viên nén, viên nén hòa tan và dạng dung dịch. Chúng rất đa dạng về chủng loại và có nhiều tên thương mại khác nhau. Prednisolone là một steroid đường uống thông dụng nhất. Bài viết này thảo luận về các tác dụng phụ chính và cung cấp thêm một số thông tin cần thiết liên quan đến việc sử dụng steroid.
## **Khi nào bạn được kê toa Steroid đường uống?**
Steroid đường uống được sử dụng để điều trị rất nhiều bệnh, ví dụ như:
  * Các bệnh viêm đường ruột (như bệnh Crohn, viêm loét đại tràng,…)
  * Bệnh tự miễn (như lupus, hội chứng thận hư nguyên phát, viêm gan tự miễn,…)
  * Bệnh cơ và khớp (như viêm khớp dạng thấp, đau đa cơ do thấp)
  * Dị ứng và hen suyễn.
  * Điều trị thay thế cho những người mà cơ thể không tự tạo được steroid tự nhiên như trong bệnh Addison (một dạng của suy tuyến thượng thận mạn)
  * Chúng cũng được sử dụng để điều trị trong một số bệnh ung thư.


## **Một số đặc điểm chung về steroid đường uống**
Dùng steroid ngắn ngày thường không gây tác dụng phụ. Ví dụ bệnh nhân mắc cơn hen nặng có thể được kê toa steroid trong 1-2 tuần và điều này thường không gây hại gì. Tác dụng phụ sẽ xảy ra nhiều hơn nếu bạn dùng steroid dài ngày (hơn 2-3 tháng), hoặc ngắn ngày nhưng lặp đi lặp lại. Liều càng cao thì nguy cơ bị tác dụng phụ ngày càng cao. Đây là lý do tại sao trong những bệnh cần dùng steroid lâu dài, người ta chỉ dùng với liều thấp nhất vừa đủ để kiểm soát triệu chứng. Một số bệnh cần dùng liều cao hơn so với các bệnh khác, thậm chí cùng mắc bệnh như nhau nhưng liều thuốc cũng khác nhau giữa các bệnh nhân.
Điều trị thông thường sẽ khởi đầu bằng steroid liều cao để kiểm soát triệu chứng nhanh và sau đó giảm liều dần đến liều duy trì để ngăn triệu chứng quay trở lại. Thời gian điều trị thay đổi tùy thuộc vào từng bệnh. Khi bệnh cải thiện có thể giảm liều dần, tuy nhiên cũng có một số trường hợp, không thể ngưng steroid vì nếu ngưng thuốc thì các triệu chứng sẽ bùng phát trở lại.
## **Các tác dụng phụ của Steroid đường uống là gì?**
Đối với một số bệnh, người ta sử dụng steroid vì lợi ích của việc dùng thuốc lớn hơn nguy cơ bị tác dụng phụ. Bạn nên đọc tờ thông tin thuốc đi kèm với hộp thuốc, trong đó có một danh sách các tác dụng phụ có thể xảy ra, bao gồm:
  * Loãng xương. Tuy nhiên, nếu bạn có nguy cơ cao bị loãng xương bạn có thể được kê toa biphosphonate là một thuốc giúp ngăn ngừa sự mất xương.
  * Tăng cân, mặt tròn như mặt trăng.
  * Tăng nguy cơ nhiễm trùng, vì steroid ức chế hệ thống miễn dịch. Đặc biệt, bạn có nguy cơ mắc một dạng nặng của bệnh thủy đậu nếu bạn chưa từng bị thủy đậu trong quá khứ hoặc chưa chích ngừa (vì khi đó bạn chưa có miễn dịch). Đa số mọi người mắc thủy đậu lúc còn nhỏ và đã có miễn dịch với nó. Nếu bạn đang dùng steroid và chưa từng bị thủy đậu thì nên giữ khoảng cách với những người bị bệnh thủy đậu hoặc zona. Báo cho bác sĩ biết nếu bạn vừa tiếp xúc với những người mắc bệnh trên. Ngoài ra, bệnh lao có thể bùng phát trở lại nếu bạn đã từng mắc lao trong quá khứ, thậm chí là nhiều năm trước đây.


  * Tăng huyết áp. Huyết áp nên được kiểm tra thường xuyên và có thể điều trị hạ áp nếu huyết áp tăng cao.
  * Tăng đường huyết. Nếu bạn đã mắc đái tháo đường, steroid sẽ làm cho đường trong máu của bạn cao và khó kiểm soát hơn nên cần điều trị bổ sung. Sử dụng steroid lâu dài còn làm tăng nguy cơ bị đái tháo đường mới mắc, đặc biệt nếu trong gia đình bạn có người mắc đái tháo đường. Trong trường hợp này, bác sĩ sẽ cho bạn kiểm tra đường huyết hằng năm để phát hiện đái tháo đường mới mắc
  * Một số vấn đề về da như chậm lành vết thương, da mỏng, dễ bị bầm, rạn da.
  * Yếu cơ.


  * Thay đổi cảm xúc và hành vi. Một số người thực sự cảm thấy tâm trạng tốt hơn khi họ sử dụng steroid. Tuy nhiên, steroid có thể làm nặng thêm trầm cảm và các vấn đề tâm thần khác, đôi khi có thể gây ra triệu chứng rối loạn tâm thần. Tác dụng phụ này có xu hướng xảy ra trong vòng vài tuần sau khi khởi đầu điều trị và thường liên quan đến liều cao. Một số người thậm chí còn trở nên lẫn lộn, cáu kỉnh, ảo giác và có ý định tự tử. Một người đang điều trị mà bị ngưng thuốc cũng có thể bị tình trạng như trên. Nên hỏi ý kiến bác sĩ nếu bạn bị thay đổi hành vi hay rối loạn lo âu
  * Tăng nguy cơ đục thủy tinh thể.
  * Tăng nguy cơ loét dạ dày, tá tràng. Hãy báo bác sĩ biết nếu bạn bị đau bụng hay khó tiêu trong khi đang dùng thuốc.


Trên đây chỉ là những tác dụng phụ chính có thể ảnh hưởng đến người sử dụng steroid. Thường có một sự cân bằng giữa một bên là nguy cơ bị tác dụng phụ với một bên là các tổn thương cơ quan hoặc triệu chứng nặng nếu bệnh không được điều trị bằng steroid. Một số tác dụng phụ ít gặp hơn không được liệt kê ở trên, nhưng sẽ được liệt kê trong tờ rơi đi kèm với hộp thuốc của bạn.
## **Ngưng Steroid đường uống**
Không được ngưng đột ngột steroid nếu bạn đang dùng chúng trong hơn ba tuần. Sẽ không vấn đề gì nếu bạn quên liều một vài liều xen kẽ. Tuy nhiên, một khi cơ thể bạn đã quen với steroid mà ngưng thuốc đột ngột có thể khiến bạn bị các triệu chứng “cai thuốc” nghiêm trọng. Tình trạng này nặng dần lên trong vòng một vài ngày kể từ lúc ngưng thuốc. Bất kỳ một thay đổi nào về liều dùng cũng cần được giám sát bởi bác sĩ. Việc giảm liều nên được tiến hành từ từ trong vòng vài tuần.
## **Tại sao phải giảm liều dần dần trước khi dừng Steroid đường uống?**
Cơ thể bạn tự tổng hợp được hormone steroid để duy trì hoạt động bình thường của cơ thể. Khi sử dụng thuốc steroid kéo dài, việc tiết hormone steroid tự nhiên của cơ thể bị giảm hoặc ngừng hẳn. Nếu sau đó bạn ngưng steroid đột ngột, cơ thể bạn không có sẵn một chút steroid nào cả, dẫn đến xuất hiện triệu chứng “cai thuốc” cho đến khi cơ thể của bạn phục hồi lại việc sản xuất hormone trong vài tuần. Các triệu chứng cai thuốc có thể nghiêm trọng, thậm chí đe dọa tính mạng. Các biểu hiện thường gặp bao gồm:
  * Yếu cơ.
  * Mệt mỏi.
  * Buồn nôn, nôn.
  * Đau bụng, tiêu chảy.
  * Hạ đường huyết.
  * Tụt huyết áp có thể khiến bạn choáng váng, hay ngất.


Nếu liều thuốc được giảm từ từ thì cơ thể sẽ khôi phục dần khả năng tự sản xuất steroid tự nhiên và triệu chứng “cai thuốc” sẽ không xảy ra.
## **Một số điểm quan trọng khác về steroid đường uống**
  * Không nên dùng kèm thuốc giảm đau chống viêm khác (như ibuprofen) trong khi đang dùng steroid (trừ khi có chỉ định của bác sĩ). Cả hai cùng làm tăng nguy cơ viêm loét dạ dày tá tràng.
  * Ở một số nước, những người sử dụng steroid kéo dài sẽ được cấp một “thẻ steroid” hoặc vòng đeo tay hoặc thứ gì đó tương tự để giúp nhân viên y tế có thể nhận diện họ trong những tình huống khẩn cấp. Trên đó cung cấp chi tiết về liều thuốc, tình trạng bệnh của bạn. Nó rất quan trọng trong những trường hợp cấp cứu ví dụ như bạn bị bất tỉnh trong một vụ tai nạn, “thẻ steroid” sẽ giúp bác sĩ nhận diện được bạn là người đang sử dụng steroid kéo dài và cần dùng thuốc đều đặn.
  * Liều steroid có thể được tăng lên tạm thời trong lúc bạn đang mắc một bệnh cấp tính khác như nhiễm trùng nặng hoặc cần phải phẫu thuật.
  * Hãy đến khám bác sĩ nếu bạn có bất kỳ thắc mắc nào về việc điều trị steroid của bạn.


## **Ai không thể sử dụng steroid đường uống?**
Có rất ít người không thể sử dụng steroid đường uống. Nếu bạn đang mắc một nhiễm trùng nặng (mà chưa được điều trị khống chế nhiễm trùng) thì không nên uống steroid vì nó ức chế hệ thống miễn dịch của bạn.
## **Có thể tự mua steroid đường uống không?**
Bạn không thể tự mua steroid, việc sử dụng thuốc cần có toa của bác sĩ.
Xem thêm: [**Sử dụng Steroid đường tiêm**](https://bvnguyentriphuong.com.vn/khoa-kham-benh/su-dung-steroid-duong-tiem)
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [Khi nào bạn được kê toa Steroid đường uống?](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/thuoc-steroid-dung-duong-uong#khi-no-bn-c-k-toa-steroid-ng-ung)
  * [Một số đặc điểm chung về steroid đường uống](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/thuoc-steroid-dung-duong-uong#mt-s-c-im-chung-v-steroid-ng-ung)
  * [Các tác dụng phụ của Steroid đường uống là gì?](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/thuoc-steroid-dung-duong-uong#cc-tc-dng-ph-ca-steroid-ng-ung-l-g)
  * [Ngưng Steroid đường uống](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/thuoc-steroid-dung-duong-uong#ngng-steroid-ng-ung)
  * [Tại sao phải giảm liều dần dần trước khi dừng Steroid đường uống?](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/thuoc-steroid-dung-duong-uong#ti-sao-phi-gim-liu-dn-dn-trc-khi-dng-steroid-ng-ung)
  * [Một số điểm quan trọng khác về steroid đường uống](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/thuoc-steroid-dung-duong-uong#mt-s-im-quan-trng-khc-v-steroid-ng-ung)
  * [Ai không thể sử dụng steroid đường uống?](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/thuoc-steroid-dung-duong-uong#ai-khng-th-s-dng-steroid-ng-ung)
  * [Có thể tự mua steroid đường uống không?](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/thuoc-steroid-dung-duong-uong#cth-t-mua-steroid-ng-ung-khng)



## ️ Một số nguy cơ có thể gặp khi sử dụng Aspirin

  * [Aspirin có an toàn cho trẻ em không?](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/mot-so-nguy-co-co-the-gap-khi-su-dung-aspirin#aspirin-c-an-ton-cho-tr-em-khng)
  * [Nguy cơ và các biện pháp phòng ngừa](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/mot-so-nguy-co-co-the-gap-khi-su-dung-aspirin#nguy-c-v-cc-bin-php-phng-nga)
  * [Tương tác thuốc](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/mot-so-nguy-co-co-the-gap-khi-su-dung-aspirin#tng-tc-thuc)


[**Xem lại tổng quan về tác dụng của aspirin**](https://bvnguyentriphuong.com.vn/khoa-duoc/tac-dung-cua-aspirin-la-gi)
Aspirin là một loại thuốc phổ biến để giảm đau và hạ sốt. Người ta cũng sử dụng nó như một chất kháng viêm hoặc chống đông.
## **Aspirin có an toàn cho trẻ em không?**
Các bác sĩ không khuyên dùng aspirin cho những người dưới 18 tuổi vì nó có thể làm tăng nguy cơ mắc một tình trạng bệnh lý rất nghiêm trọng gọi là hội chứng Reye, có thể xuất hiện sau khi bị nhiễm virus như cảm lạnh, cúm hoặc thủy đậu. Hội chứng Reye có thể dẫn đến các tổn thương não vĩnh viễn hoặc tử vong.
Tuy nhiên, bác sĩ có thể kê đơn aspirin cho trẻ dưới sự giám sát theo dõi chặt chẽ nếu trẻ đó mắc bệnh Kawasaki hoặc để ngăn hình thành cục máu đông sau khi các phẫu thuật tim. Đối với trẻ em, bác sĩ thường khuyên dùng acetaminophen hoặc ibuprofen với liều lượng thích hợp, thay vì dùng aspirin.
## **Nguy cơ và các biện pháp phòng ngừa**
Những người có các tình trạng sau đây nên thận trọng khi dùng aspirin và chỉ nên dùng như vậy nếu có chỉ định của bác sĩ: 
  * Rối loạn chảy máu, như bệnh máu khó đông Hemophilia;
  * Huyết áp cao không kiểm soát được;
  * Hen suyễn;
  * Loét dạ dày;
  * Bệnh gan hoặc bệnh thận.


Dưới sự giám sát theo dõi của bác sĩ, những người đang mang thai hoặc cho con bú có thể dùng aspirin liều thấp. Các bác sĩ thường không khuyên dùng aspirin liều cao trong thời kỳ mang thai.
Bất kỳ ai bị dị ứng với aspirin hoặc bất kỳ NSAID nào khác, chẳng hạn như ibuprofen, nên tránh những loại thuốc này. Các bác sĩ không dùng aspirin trong khi bị đột quỵ vì không phải tất cả các đột quỵ đều do cục máu đông. Trong một số trường hợp, aspirin có thể làm cho đột quỵ nặng nề hơn. Ngoài ra, bất kỳ ai uống rượu thường xuyên hoặc đang điều trị nha khoa hoặc phẫu thuật, dù nhỏ, nên tham khảo ý kiến bác sĩ trước khi dùng aspirin.
## **Tương tác thuốc**
Tương tác thuốc có thể dẫn đến việc một loại thuốc khác kém hiệu quả hơn hoặc sự kết hợp thuốc này trở nên nguy hiểm. Aspirin có thể tương tác với nhiều loại thuốc. Một số loại thuốc bao gồm:
  * **Thuốc giảm đau kháng viêm:** Ví dụ như diclofenac, ibuprofen và naproxen. Kết hợp với aspirin, những loại thuốc này có thể làm tăng nguy cơ xuất huyết dạ dày.
  * **Các chất ức chế tái hấp thu serotonin có chọn lọc và các thuốc chống trầm cảm khác:** Ví dụ như citalopram, fluoxetine, paroxetine, venlafaxine và sertraline. Kết hợp với aspirin, bất kỳ loại nào trong số các loại này đều có thể làm tăng nguy cơ chảy máu.
  * **Warfarin:** Kết hợp với chất chống đông này, aspirin có thể làm giảm tác dụng chống đông của thuốc và làm tăng nguy cơ chảy máu. Tuy nhiên, có những tình huống, sự kết hợp này có thể có lợi.
  * **Methotrexate:** Kết hợp với thuốc này, được sử dụng trong điều trị ung thư và một số bệnh tự miễn, aspirin có thể làm cho thuốc khó đào thải hơn, có thể dẫn đến tăng nồng độ methotrexate và gây độc.


## **Tác dụng phụ**
Các tác dụng phụ thường gặp nhất của aspirin là:
  * Kích ứng dạ dày hoặc ruột;
  * Khó tiêu;
  * Buồn nôn.


Các tác dụng phụ sau đây ít gặp hơn:
  * Triệu chứng hen suyễn trở nên nặng nề hơn;
  * Nôn ói;
  * Viêm dạ dày;
  * Chảy máu dạ dày;
  * Các vết bầm tím.


Aspirin cũng có thể có các tác dụng phụ rất nghiêm trọng, chẳng hạn như chảy máu trong não hoặc dạ dày hoặc suy thận. Một tác dụng phụ hiếm gặp của aspirin liều thấp hàng ngày là đột quỵ xuất huyết.
## **Tóm lại**
Aspirin có thể giúp ngăn ngừa và điều trị một loạt các vấn đề sức khỏe, nhưng những người dưới 18 tuổi không nên dùng aspirin mà không có các hướng dẫn y khoa.
Aspirin có bán sẵn tại các quầy thuốc hoặc kê theo toa. Luôn làm theo hướng dẫn trên nhãn hoặc chỉ dẫn của bác sĩ. Điều này đặc biệt quan trọng đối với những người có nhiều nguy cơ gặp các tác dụng phụ.
Aspirin không phải an toàn cho tất cả mọi người, đặc biệt là với liều lượng hàng ngày. Các lựa chọn khác để giảm đau trong các cơn đau nhẹ bao gồm các loại NSAID khác, chẳng hạn như ibuprofen và acetaminophen.
Có thể bạn quan tâm: [**Những cập nhật gần đây - Liều thấp ASPIRIN có thể ngăn ngừa nguy cơ ung thư**](https://bvnguyentriphuong.com.vn/san-phu-khoa/nhung-cap-nhat-gan-day-lieu-thap-aspirin-co-the-ngan-ngua-nguy-co-ung-thu)
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [Aspirin có an toàn cho trẻ em không?](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/mot-so-nguy-co-co-the-gap-khi-su-dung-aspirin#aspirin-c-an-ton-cho-tr-em-khng)
  * [Nguy cơ và các biện pháp phòng ngừa](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/mot-so-nguy-co-co-the-gap-khi-su-dung-aspirin#nguy-c-v-cc-bin-php-phng-nga)
  * [Tương tác thuốc](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/mot-so-nguy-co-co-the-gap-khi-su-dung-aspirin#tng-tc-thuc)



## Hướng dẫn về cách đặt thuốc đặt trực tràng

Đường trực tràng là đường đưa thuốc có nhiều ưu điểm và thường sử dụng trong các trường hợp: bệnh nhân co thắt thực quản, hôn mê, không nuốt được, tắc ruột, bệnh nhân dễ bị nôn khi uống (Phụ nữ thai nghén, người già, trẻ em), thuốc có mùi vị khó chịu, thuốc bị mất hoặc giảm tác dụng dưới ảnh hưởng của dịch tiêu hoá.
Hướng dẫn về cách đặt thuốc đặt trực tràng (dạng viên đạn)
**1. Rửa tay kỹ** bằng xà phòng và nước.
**2. Nếu thuốc đạn bị mềm, giữ thuốc trong nước lạnh hoặc đặt vào trong tủ lạnh** trong vài phút để làm thuốc cứng lại trước khi tháo khỏi vỏ thuốc.
**3. Tháo lớp vỏ thuốc** , nếu có.
4. Nếu có chỉ định **sử dụng một nửa viên thuốc, hãy cắt viên thuốc theo chiều dọc** bằng dao (dao lam) sạch.
5. **Mang bao đầu ngón tay hoặc găng tay dùng một lần** , nếu muốn (có bán tại nhà thuốc).
6. **Bôi trơn đầu viên thuốc đạn với một chất bôi trơn tan trong nước** như K-Y Jelly, chứ không phải là dạng mỡ (Vaseline). Nếu bạn không có chất bôi trơn này, hãy làm ẩm vùng trực tràng bằng nước mát.
7. **Nằm nghiêng sang một bên,** chân dưới đặt thẳng ra và chân trên co lên về phía trước bụng.
8. Nhấc phần mông trên để**lộ vùng trực tràng.**
**9. Nhét viên thuốc đạn vào,** đưa phần đầu nhọn vào trước bằng ngón tay của bạn cho đến khi viên thuốc đặt qua cơ vòng của trực tràng. Cơ này thường khoảng 1.2-2.5 cm ở trẻ sơ sinh và 2.5 cm ở người lớn. Nếu không đặt qua cơ vòng này, thuốc đạn có thể bật/trồi ra ngoài.
**10. Giữ chặt 2 mông** với nhau trong một vài giây.
**11. Nằm yên một chỗ trong khoảng 5 phút** để thuốc đạn không bị rơi ra ngoài
**12. Bỏ những vật đã sử dụng (bao tay, vỏ thuốc)** vào thùng rác kín và rửa tay kỹ.
**Cần lưu ý:**
- Thuốc nên bảo quản ở nơi mát mẻ (<30 0C), giữ lạnh nếu nhãn yêu cầu, nếu cảm thấy thuốc đặt quá mềm, cần cho vào ngăn đá tủ lạnh trong khoảng một vài phút trước khi mở vỏ thuốc.
- Đọc kỹ hướng dẫn sử dụng trước khi dùng.
- Không nên đặt quá sâu vì mục tiêu chủ yếu hấp thu thuốc qua tĩnh mạch trực tràng dưới và giữa, không nên đặt quá nông vì dễ làm rơi viên thuốc ra ngoài.Vị trí đặt tốt nhất là đưa thuốc qua hậu môn sâu 2,5 cm (khoảng 1 đốt ngón trỏ) đối với bệnh nhân là người lớn. Đối với bệnh nhân là trẻ em dùng ngón út để đưa thuốc vào 1,5cm (khoảng ½ đốt).
- Nếu trong thuốc có chứa PEG cần nhúng viên thuốc hoặc để dưới vòi nước đang chảy trước khi đặt vào hậu môn do PEG hút nước rất mạnh nên rất dễ làm khô gây kích ứng và đau tại vị trí đặt thuốc.
**Tài liệu tham khảo**
<http://www.safemedication.com/safemed/MedicationTipsTools/HowtoAdminister/HowtoUseRectalSuppositoriesProperly>
**Nguồn biên dịch:[Y học cộng đồng](https://yhoccongdong.com/)**

## Hướng dẫn lấy thuốc dạng lỏng theo liều

  * [1. Dùng cốc đong](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/huong-dan-lay-thuoc-dang-long-theo-lieu#1-dng-cc-ong)
  * [2. Dùng muỗng đong](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/huong-dan-lay-thuoc-dang-long-theo-lieu#2-dng-mung-ong)
  * [3. Dùng ông nhỏ giọt hoặc ống tiêm qua miệng](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/huong-dan-lay-thuoc-dang-long-theo-lieu#3-dng-ng-nh-git-hoc-ng-tim-qua-ming)
  * [Thông tin khác:](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/huong-dan-lay-thuoc-dang-long-theo-lieu#thng-tin-khc)


Hãy sử dụng các dụng cụ đo đi kèm với thuốc. Nếu dụng cụ đo không đi kèm với thuốc, hãy hỏi dược sĩ để được tư vấn chọn dụng cụ đo tốt nhất.
## **1. Dùng cốc đong**
Hãy chắc chắn đo dung dịch ở ngang tầm mắt trên một mặt phẳng (không giữ trên tay).  
---  
Đổ dung dịch thuốc vào cốc đến vạch chính xác để đo đúng liều sử dụng. Để tiện lợi cho bạn hoặc cho dược sỹ hãy đánh dấu chính xác vạch đo cho liều thuốc thường dùng của bạn.  
Tùy thuộc vào liều lượng, một vài ngụm có thể cần thiết để lấy đủ lượng dung dịch thuốc.  
Nếu thuốc đậm đặc hoặc hoặc đặc, bạn có thể cần lấy thêm một ít nước và xoay cốc để có được đủ lượng thuốc.  
Rửa tay sau khi bạn đã lấy thuốc xong và đóng kín các chai thuốc.  
## **2. Dùng muỗng đong**
Hãy chắc chắn đo thuốc ngang tầm mắt và giữ thẳng đứng (không nghiêng).  
---  
Đổ dung dịch thuốc vào muỗng đong tới vạch đo chính xác để đo đúng liều sử dụng. Để tiện lợi cho bạn hoặc cho dược sỹ hãy đánh dấu chính xác vạch đo cho liều thuốc thường dùng của bạn.  
Tùy thuộc vào liều lượng, một vài ngụm có thể cần thiết để lấy đủ lượng dung dịch thuốc.  
Nếu thuốc đậm đặc hoặc hoặc dính, bạn có thể cần lấy thêm một ít nước và xoay cốc để có được đủ lượng thuốc.  
Rửa tay sau khi bạn đã lấy thuốc xong và đóng kín các chai thuốc.  
## **3. Dùng ông nhỏ giọt hoặc ống tiêm qua miệng**
Cẩn thận rút thuốc lên vào ống tiêm tới đúng vạch đánh dấu. Để tiện lợi cho bạn hoặc cho dược sỹ hãy đánh dấu chính xác vạch đo cho liều thuốc thường dùng của bạn.  
---  
Không lấy đầy thuốc vào ống nhỏ giọt hoặc ống tiêm  
Hãy chắc chắn gõ nhẹ đẩy bong bóng khí ra.  
Không bao giờ phun dung dịch thuốc từ ống nhỏ giọt hoặc ống tiêm uống trực tiếp sâu xuống cổ họng của trẻ. Cẩn thận và từ từ đẩy thuốc vào khu vực giữa lưỡi và má với lượng nhỏ. Hãy chắc chắn cho trẻ có khoảng nghỉ để cho trẻ nuốt.  
Rửa tay sau khi bạn đã lấy thuốc xong và đóng kín các chai thuốc.  
## **Thông tin khác:**
  * Không uống kết hợp hai loại thuốc dạng lỏng khác nhau trong cùng một dụng cụ đo cùng một lúc.
  * Chỉ trộn thuốc nước với thức ăn hoặc đồ uống khi bạn có thông tin rằng nó an toàn.
  * Loại bỏ bất kỳ dung dịch thuốc dư thừa nếu bạn cho quá đầy các dụng cụ đo. Không đổ lại bất kỳ thuốc dư thừa vào chai thuốc ban đầu vì có thể làm nhiễm bẩn thuốc còn lại trong chai.
  * Luôn luôn rửa sạch dụng cụ đo sau khi sử dụng. Đảm bảo để khô dụng cụ một cách cẩn thận trước khi sử dụng ở lần sau vì nước còn sót lại sẽ làm cho lượng thuốc đo không chính xác.


  * [1. Dùng cốc đong](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/huong-dan-lay-thuoc-dang-long-theo-lieu#1-dng-cc-ong)
  * [2. Dùng muỗng đong](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/huong-dan-lay-thuoc-dang-long-theo-lieu#2-dng-mung-ong)
  * [3. Dùng ông nhỏ giọt hoặc ống tiêm qua miệng](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/huong-dan-lay-thuoc-dang-long-theo-lieu#3-dng-ng-nh-git-hoc-ng-tim-qua-ming)
  * [Thông tin khác:](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/huong-dan-lay-thuoc-dang-long-theo-lieu#thng-tin-khc)



## ️ Kháng sinh mới có hoạt tính chống lại nhiều loại vi khuẩn

Tổ chức Y tế Thế giới (WHO) đã tuyên bố kháng kháng sinh (AMR) là một trong 10 mối đe dọa sức khỏe cộng đồng toàn cầu chống lại loài người. Người ta ước tính rằng vào năm 2050, các bệnh nhiễm trùng kháng thuốc kháng sinh có thể cướp đi sinh mạng của 10 triệu người mỗi năm và tạo ra gánh nặng tích lũy khoảng 100 nghìn tỷ đô la cho nền kinh tế toàn cầu. Danh sách các vi khuẩn kháng thuốc điều trị với tất cả các lựa chọn kháng sinh hiện có đang ngày càng gia tăng và chỉ có một số ít loại thuốc mới đang được sản xuất, tạo ra nhu cầu bức thiết về các loại kháng sinh mới để ngăn chặn tình trạng khủng hoảng kháng thuốc toàn cầu.
PGS.TS. Farokh Dotiwala, trung tâm Vaccine & Liệu pháp miễn dịch, cho biết: “Chúng tôi đã thực hiện một chiến lược kép sáng tạo để phát triển các phân tử mới có thể tiêu diệt các bệnh nhiễm trùng khó điều trị đồng thời tăng cường phản ứng miễn dịch tự nhiên của vật chủ. Ông cũng là người đứng đầu trong nỗ lực xác định một thế hệ kháng sinh mới được đặt tên là kháng sinh miễn dịch tác dụng kép (DAIA).
Các loại thuốc kháng sinh hiện có nhắm vào các chức năng cần thiết của vi khuẩn, bao gồm tổng hợp axit nucleic, protein, màng tế bào và các quá trình trao đổi chất. Tuy nhiên, vi khuẩn có thể kháng thuốc bằng cách làm biến đổi mục tiêu mà kháng sinh hướng tới, làm bất hoạt thuốc hoặc bơm tống thuốc ra ngoài. Dotiwala cho biết: “Chúng tôi cho rằng rằng việc kích hoạt hệ thống miễn dịch để tấn công đồng thời vi khuẩn trên hai phương diện khác nhau sẽ khiến vi khuẩn khó đề kháng thuốc hơn.”
Ông và các đồng nghiệp đã tập trung vào một quá trình trao đổi chất cần thiết cho hầu hết các vi khuẩn nhưng không có ở người, khiến nó trở thành mục tiêu lý tưởng cho sự phát triển của kháng sinh. Quá trình này, được gọi là methyl-D-erythritol phosphate (MEP) hoặc quá trình non- mevalonate, chịu trách nhiệm sinh tổng hợp isoprenoids – các phân tử cần thiết cho sự tồn tại của tế bào ở hầu hết các vi khuẩn gây bệnh. Nhóm nghiên cứu nhắm đến enzym IspH, một enzym thiết yếu trong sinh tổng hợp isoprenoid, như một cách để ngăn chặn con đường sinh tổng hợp isoprenoid và có tác dụng tiêu diệt vi khuẩn. Với sự hiện diện rộng rãi của IspH trong thế giới vi khuẩn, cách tiếp cận này có thể nhắm mục tiêu đến nhiều loại vi khuẩn khác nhau. Do các chất ức chế IspH có sẵn trước đây không thể xâm nhập vào thành tế bào vi khuẩn, Dotiwala đã hợp tác với GS.TS Joseph Salvino, Trung tâm Ung thư Viện Wistar, để xác định và tổng hợp các chất ức chế IspH mới có thể xâm nhập vào bên trong vi khuẩn.
Nhóm nghiên cứu đã chứng minh rằng các chất ức chế IspH tác dụng kích thích hệ thống miễn dịch với hoạt tính tiêu diệt vi khuẩn mạnh hơn và đặc hiệu hơn so với các kháng sinh tốt nhất hiện nay khi thử nghiệm in vitro trên các chủng vi khuẩn kháng kháng sinh được phân lập lâm sàng, bao gồm một loạt các vi khuẩn gram âm và vi khuẩn gram dương. Trong các mô hình tiền lâm sàng về nhiễm vi khuẩn gram âm, tác dụng diệt khuẩn của các chất ức chế IspH vượt trội hơn so với các kháng sinh truyền thống. Tất cả các hợp chất được thử nghiệm được chứng minh là không độc hại đối với tế bào của con người.
Dotiwala nhấn mạnh: “Chúng tôi tin rằng chiến lược sáng tạo này của DAIA có thể tạo ra một bước ngoặt tiềm năng trong cuộc chiến chống lại AMR của thế giới, tạo ra sức mạnh tổng hợp giữa khả năng tiêu diệt trực tiếp của thuốc kháng sinh và sức mạnh tự nhiên của hệ thống miễn dịch.
*Kumar Sachin Singh, Rishabh Sharma, Poli Adi Narayana Reddy, Prashanthi Vonteddu, Madeline Good, Anjana Sundarrajan, Hyeree Choi, Kar Muthumani, Andrew Kossenkov, Aaron R. Goldman, Hsin-Yao Tang, Maxim Totrov, Joel Cassel, Maureen E. Murphy, Rajasekharan Somasundaram, Meenhard Herlyn, Joseph M. Salvino, Farokh Dotiwala. **IspH inhibitors kill Gram-negative bacteria and mobilize immune clearance**.  _Nature_ , 2020; DOI: [10.1038/s41586-020-03074-x](http://dx.doi.org/10.1038/s41586-020-03074-x)
Tìm hiểu thêm về: [**Kháng kháng sinh**](https://bvnguyentriphuong.com.vn/khoa-duoc/khang-sinh-su-nguy-hiem-cua-viec-lam-dung)
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh

## Hướng dẫn sử dụng thuốc đặt âm đạo, thuốc dạng viên đạn và kem

  * [Ghi nhớ khi sử dụng thuốc đặt âm đạo, thuốc dạng viên đạn và kem](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/huong-dan-su-dung-thuoc-dat-am-dao-thuoc-dang-vien-dan-va-kem#ghi-nh-khi-s-dng-thuc-t-m-o-thuc-dng-vin-n-v-kem)
  * [Tài liệu tham khảo](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/huong-dan-su-dung-thuoc-dat-am-dao-thuoc-dang-vien-dan-va-kem#ti-liu-tham-kho)


**Thời gian đặt**
Nên đặt vào buổi tối trước khi đi ngủ, đặt xong nằm nghỉ luôn. Nếu đặt vào lúc khác thì sau khi đặt phải nằm nghỉ vài tiếng.
Khi sử dụng thuốc đặt âm đạo cần tránh giao hợp trong thời gian dùng thuốc để thuốc phát huy được tác dụng.
Thuốc có thể gây dị ứng, vì vậy nếu nhẹ, tiếp tục liệu trình điều trị. Nếu nặng, cần ngừng dùng thuốc, và hỏi ý kiến bác sĩ để có thể đổi thuốc khác.
Tránh lạm dụng thuốc đặt âm đạo vì sẽ gây nên sự kháng thuốc, làm mất cân bằng sinh thái hệ vi sinh, gây bội nhiễm các tác nhân gây bệnh khác. 
1.Tốt nhất là **sử dụng các sản phẩm này trước khi đi ngủ**. Tư thế nằm giúp thuốc không bị bị chảy ra từ âm đạo so với khi đứng dậy hoặc đi lại.
**2. Rửa nhẹ vùng âm hộ bằng xà phòng, nước và lau khô hoàn toàn.** Nếu sản phẩm đi kèm với một dụng cụ bôi chuyên dùng thì bỏ qua các bước tiếp theo và đến bước 5.
3. Đối với **sản phẩm kem âm đạo:** Gắn thiết bị chuyên dùng để bôi với ống kem đã mở nắp và xoắn cho đến khi gắn chặt. Bóp kem từ ống vào vật dụng bôi cho đến khi nó đạt đến mức chỉ định liều lượng mà bạn được bác sĩ chỉ định. Xoay và gỡ bỏ dụng cụ bôi ra khỏi ống thuốc.
4. Đối với **thuốc viên nén hoặc thuốc dạng viên đạn:** Lấy thuốc ra khỏi vỏ bọc và đặt nó vào phần cuối của dụng cụ đặt thuốc.
5. Nhẹ nhàng đặt dụng cụ đặt thuốc vào âm đạo khi bạn đang ở vị trí đứng hoặc nằm. **Đưa dụng cụ đặt thuốc vào càng sâu càng tốt.** Bạn có thể đứng với chân đưa về trước và đầu gối cong lại.
6. Hoặc **nằm ngửa với đầu gối cong lên và chân hơi đặt ra ngoài.**
**7. Đẩy pít-tông của dụng cụ đặt thuốc cho đến khi không đẩy pít-tông được nữa.** Lấy dụng cụ ra khỏi âm đạo.
8. Nếu sử dụng lại dụng cụ đặt thuốc, **hãy làm sạch nó theo hướng dẫn của nhà sản xuất.** Thông thường, cần tách 2 phần pít-tông và xy-lanh) ra khỏi nhau rồi rửa chúng bằng xà phòng và nước. Hãy bỏ đi dụng cụ đặt thuốc nếu chỉ dùng một lần.
**9. Rửa tay kỹ** bằng xà phòng và nước ấm.
**10.** **Tiếp tục sử dụng thuốc theo chỉ dẫn của bác sĩ hoặc theo hướng dẫn trên sản phẩm.** Sử dụng thuốc liên tục không bỏ ngày nào, ngay cả trong thời kỳ kinh nguyệt. Bạn nên sử dụng băng vệ sinh nếu bạn đang ra kinh trong khi sử dụng thuốc. Không sử dụng băng vệ sinh dạng tampon vì chúng có thể thấm hút thuốc và làm cho việc điều trị kém hiệu quả.
## **Ghi nhớ khi sử dụng thuốc đặt âm đạo, thuốc dạng viên đạn và kem**
  * Thực hiện theo hướng dẫn cẩn thận.
  * Không bỏ liều.
  * Bảo quản thuốc đặt âm đạo dạng viên đạn ở nơi mát và tránh làm nóng chảy thuốc; giữ trong tủ lạnh nếu thuốc có dán nhãn yêu cầu giữ lạnh.
  * Giữ thuốc ngoài tầm với của trẻ em.


## **Tài liệu tham khảo**
<http://www.safemedication.com/safemed/MedicationTipsTools/HowtoAdminister/How-to-Use-Vaginal-Tablets-Suppositories-and-Creams>
**Nguồn biên dịch:[Y học cộng đồng](https://yhoccongdong.com/)**
Chúng tôi cũng có **01 video clip hướng dẫn thêm** về thuốc đặt âm đạo, mời quý độc giả tham khảo nếu cần thiết tại đường link dưới đây
**[https://youtu.be/ECfGIsJmeqw](https://youtu.be/ECfGIsJmeqw)**
  * [Ghi nhớ khi sử dụng thuốc đặt âm đạo, thuốc dạng viên đạn và kem](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/huong-dan-su-dung-thuoc-dat-am-dao-thuoc-dang-vien-dan-va-kem#ghi-nh-khi-s-dng-thuc-t-m-o-thuc-dng-vin-n-v-kem)
  * [Tài liệu tham khảo](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/huong-dan-su-dung-thuoc-dat-am-dao-thuoc-dang-vien-dan-va-kem#ti-liu-tham-kho)



## Hướng dẫn sử dụng bình xịt (hít) định liều không buồng đệm

Bình hít định liều (metered dose inhaler – MDI) là một dụng cụ cung cấp một số lượng thuốc đã định lượng vào phổi bạn. Bạn nhận thuốc này với mỗi nhát bóp khi bạn hít vào. Bình hít định liều sử dụng một chất đẩy thuốc hóa học để tạo ra luồng phun (nhát). Chất đẩy thuốc này mang theo một liều thuốc đã định lượng vào trong phổi bạn. Luồng phun bạn thấy từ bình xịt định liều là cả chất đẩy thuốc và thuốc. Các bình xịt sử dụng bột được gọi là bình xịt bột khô (dry powder inhaler – DPI) và không sử dụng chất đẩy thuốc.
Tham khảo thêm tờ hướng dẫn về cách vệ sinh và sử dụng dụng cụ đính kèm theo sản phẩm.
**Bước 1** : Mở nắp ống thuốc.  
---  
**Bước 2** : Lắc mạnh ống thuốc trong vòng 5 giây.  
**Bước 3** : Giữ ống thuốc bằng 2 ngón tay, ngón trỏ để lên đáy ống và ngón cái đặt dưới nơi xịt thuốc.  
**Bước 4** : Ngồi thẳng hoặc đứng dậy.  
**Bước 5** : Ngửa đầu ra sau một chút.  
**Bước 6** : Thở ra hết sức trước khi hít.  
**Bước 7** : Ngậm ống hít. Nhấn ống và hít vào cùng một lúc. Nên hít một hơi chậm và sâu bằng miệng.  
**Bước 8** : Giữ hơi thở trong 10 giây. Thở ra từ từ qua mũi hoặc miệng.  
**Bước 9** : Lập lại từ bước 2 đến 8 sau 30 giây nếu cần xịt thêm liều khác.Nếu thuốc có thành phần corticosteroid, cần xúc miệng sau khi xịt thuốc.  
**Lưu ý:**
**+****Nhớ súc miệng kỹ sau khi dùng thuốc.**
**+ Đối với trẻ em có những hướng dẫn riêng**

## Hướng dẫn sử dụng thuốc nhỏ tai

**1**.Rửa tay kỹ bằng xà phòng và nước.  
---  
**2.** Nhẹ nhàng làm sạch tai bằng một miếng gạc/khăn ẩm và sau đó lau khô tai.  
**3.** Làm ấm dung dịch thuốc đến gần nhiệt độ của cơ thể gần bằng cách nắm lọ thuốc trong lòng bàn tay trong vài phút.  
**4.** Nếu thuốc ở dạng hỗn dịch (dịch treo), hãy lắc đều lọ thuốc trong 10 giây.  
**5.** Kiểm tra đầu ống nhỏ của lọ thuốc để đảm bảo rằng nó không bị mẻ hoặc nứt.  
**6**. Bóp hoặc dốc ngược lọ thuốc để dung dịch thuốc chảy ra ở đầu ống nhỏ.  
**7.** Nghiêng tai bị bệnh lên phía trên hoặc nằm nghiêng về một bên. Kéo vành tai ra sau và lên trên (nếu nhỏ thuốc cho trẻ nhỏ hơn 3 tuổi, hãy kéo ra sau và xuống dưới) để làm ống tai mở rộng.  
**8.** Nhỏ đúng số giọt thuốc theo chỉ định vào tai. Ấn nhẹ lên bình tai ( “nắp da” nhỏ trên tai) để giúp những giọt thuốc chạy vào trong ống tai.  
**9.** Giữ nguyên vị trí tai nghiêng như vậy trong vài phút. Bạn cũng có thể chèn một cục bông gòn mềm vào tai, tùy theo hướng dẫn của dược sĩ hoặc bác sĩ.  
**10.** Lau sạch đầu lọ thuốc hoặc ống nhỏ bằng cồn y tế (bạn có thể mua cồn y tế ở hiệu thuốc), đóng chặt chặt nắp lọ thuốc ngay sau khi sử dụng. Một số lọ thuốc cho phép bạn thay thế ống nhỏ sau 2-3 lần sử dụng.  
**11.** Rửa tay để loại bỏ dung dịch thuốc.  
**Tài liệu tham khảo** <http://www.safemedication.com/safemed/MedicationTipsTools/HowtoAdminister/HowtoUseEarDropsProperly>
**Nguồn biên dịch:[Y học cộng đồng](https://yhoccongdong.com/)**

## Hướng dẫn sử dụng thuốc nhỏ mũi

Trong điều trị các bệnh ở mũi (như viêm mũi, viêm xoang...) thì nhỏ mũi là đường đưa thuốc thường dùng nhất. Nếu nhỏ thuốc đúng cách sẽ cho hiệu quả điều trị cao.
Việc có người khác giúp đỡ sẽ khiến việc dùng thuốc nhỏ mũi thuận lợi hơn nhiều
**1. Hỉ mũi nhẹ nhàng.**
**2. Rửa tay kỹ** bằng xà phòng và nước.
**3. Kiểm tra đầu ống nhỏ giọt** để đảm bảo không bị sứt mẻ hoặc nứt.
**4. Tránh chạm đầu ống nhỏ giọt vào mũi bạn.**
**5. Ngửa đầu càng về sau càng tốt khi có thể,** hoặc nằm xuống đặt lưng của bạn trên một mặt phẳng (ví dụ như giường) và dốc đầu của bạn tựa lên trên cạnh giường.
6. Nhỏ thuốc **đúng số giọt quy định** vào mũi của bạn.
**7. Cúi đầu nhẹ về phía trước** theo hướng về phía đầu gối của bạn và lắc đầu nhẹ nhàng sang bên trái và phải.
**8. Giữ nguyên ở tư thế này** trong một vài phút.
**9. Lau sạch đầu ống nhỏ giọt bằng nước ấm.** Đậy nắp chai ngay sau khi sử dụng xong.
**10. Rửa tay** để loại bỏ dịch thuốc.
**Một vài lưu ý khác khi nhỏ thuốc mũi**
- Để không làm tổn hại niêm mạc mũi, đảm bảo hoạt động sinh lý của hệ thống lông nhày, các thuốc đưa vào mũi phải đảm bảo pH= 7-9, nhiệt độ trong khoảng từ 23- 40oC, độ nhớt và áp suất thẩm thấu thích hợp.
- Không nên nhỏ kháng sinh hay corticoid với nồng độ quá đậm đặc vì không có tác dụng lại gây hại.
- Không nên nhỏ mũi bằng các hoa lá, thảo mộc tươi... tự chế vì các loại thuốc này không đảm bảo vô khuẩn sẽ gây thêm bệnh hoặc chứa dị nguyên gây nên những phản ứng dị ứng. 
- Đối với các thuốc co mạch, không được nhỏ nhiều lần trong ngày, kéo dài liên tục nhiều ngày vì sẽ gây viêm mũi do thuốc. 
**Tài liệu tham khảo**
<http://www.safemedication.com/safemed/MedicationTipsTools/HowtoAdminister/HowtoUseNoseDropsProperly>
**Nguồn biên dịch:[Y học cộng đồng](https://yhoccongdong.com/)**

## Hướng dẫn sử dụng bơm xịt mũi

**Thuốc xịt mũi** là một dạng thuốc để sử dụng điều trị các bệnh lý đường hô hấp. Thuốc xịt mũi là những loại thuốc được đóng thành lọ, có vòi xịt bắn ra các tia nước rất nhỏ, khi sử dụng thuốc xịt có ưu điểm hơn loại thuốc nhỏ mũi như dễ sử dụng và thuốc được phân chia nhỏ như các hạt nước li ti dễ xâm nhập vào khoang mũi, niêm mạc mũi xoang, nên thuốc có tác dụng nhanh và kéo dài.
**Thuốc xịt mũi** thường là các loại thuốc để điều trị triệu chứng trong các bệnh như: [**Viêm mũi dị ứng**](https://bvnguyentriphuong.com.vn/noi-ho-hap/phan-the-va-dieu-tri-viem-mui-di-ung-1), viêm mũi xoang, [**viêm mũi họng**](https://bvnguyentriphuong.com.vn/tai-mui-hong/viem-xoang-va-viem-hong-man-tinh), nghẹt mũi sau phẫu thuật.
**1. Rửa tay kỹ** bằng xà phòng và nước.
**2. Dùng khăn hỉ mũi nhẹ nhàng** trước khi sử dụng bình xịt mũi.
3. Lắc nhẹ chai thuốc, giữ chai thuốc bằng ngón tay cái đặt phía dưới đáy bình thuốc và dùng hai ngón tay trỏ và giữa đặt ở phía trên ở hai bên của vòi phun. **Mồi thuốc vào bơm bằng cách phun nhẹ vào không khí một vài lần.**
**4. Nghiêng đầu nhẹ về phía trước.** Nhẹ nhàng đưa đầu vòi phun vào một lỗ mũi. Ấn nhẹ vào cánh mũi còn lại bằng một ngón tay để khép kín lỗ mũi đó.
**5. Hít vào thật nhanh** khi đang nén bơm trên bình thuốc xuống một lần.
**6. Lặp lại ở lỗ mũi còn lại.**
**7. Không được hỉ mũi ngay** sau khi sử dụng thuốc xịt mũi.
**8. Rửa tay kỹ** bằng xà phòng và nước.
**Lưu ý:**
Các bệnh lý liên quan tới tình trạng dị ứng thường xảy ra thường xuyên khi thay đổi thời tiết, khi tiếp xúc với dị nguyên nên người bệnh hay sử dụng**thuốc xịt mũi kéo dài**. Các thuốc này có thể làm giảm triệu chứng nhanh nhưng lại có thể gây ra một số tác dụng không mong muốn, khi lạm dụng dùng kéo dài.
**Tài liệu tham khảo**
<http://www.safemedication.com/safemed/MedicationTipsTools/HowtoAdminister/How-to-Use-Nasal-Pump-Sprays-Properly>
**Nguồn biên dịch:[Y học cộng đồng](https://yhoccongdong.com/)**

## ️ Tác dụng của Aspirin là gì?

  * [Ngăn ngừa các biến cố tim mạch](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/tac-dung-cua-aspirin-la-gi#ngn-nga-cc-bin-c-tim-mch)
  * [Điều trị các biến cố mạch vành](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/tac-dung-cua-aspirin-la-gi#iu-tr-cc-bin-c-mch-vnh)
  * [Các công dụng khác](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/tac-dung-cua-aspirin-la-gi#cc-cng-dng-khc)


Aspirin là một loại thuốc phổ biến để giảm đau và hạ sốt. Người ta cũng sử dụng nó như một chất kháng viêm hoặc chống đông.
Aspirin có thể làm giảm nguy cơ mắc các biến cố tim mạch nếu dùng hàng ngày, chẳng hạn như nhồi máu cơ tim hoặc đột quỵ ở những người có nguy cơ cao. Người nhồi máu cơ tim cần được dùng aspirin ngay lập tức để ngăn ngừa hình thành thêm cục máu đông và chết mô cơ tim tiến triển. Bài viết này cung cấp một cái nhìn tổng quan về aspirin, bao gồm cách sử dụng, rủi ro, tương tác và các tác dụng phụ có thể xảy ra.
## **Aspirin là gì?**
Aspirin là một loại thuốc kháng viêm không steroid (NSAID). Đây là loại thuốc đầu tiên được phát hiện trong nhóm này. Aspirin chứa salicylate, một hợp chất được tìm thấy trong các cây như cây liễu và cây tầm ma. Việc sử dụng nó lần đầu tiên được ghi nhận vào khoảng 4.000 năm trước đây.
Hippocrates đã sử dụng vỏ cây liễu để giảm đau và hạ sốt và một số người vẫn sử dụng vỏ cây liễu như một phương thuốc tự nhiên để chữa đau đầu và các cơn đau nhẹ.
NSAID là một nhóm thuốc có tác dụng:
  * Giảm đau;
  * Hạ sốt;
  * Giảm viêm với liều lượng cao hơn.


Những loại thuốc này không phải là steroid. Steroid thường có những lợi ích tương tự như NSAID, nhưng những loại thuốc này không phải phù hợp cho tất cả mọi người và có thể có những tác dụng phụ không mong muốn.
NSAID là thuốc giảm đau không gây nghiện. Do đó, chúng không gây ra tình trạng thay đổi tri giác khi dùng như các loại giảm đau có thành phần opiod.
## **Tác dụng**
Aspirin có nhiều tác dụng, bao gồm giảm đau và giảm sưng nề, kiểm soát các bệnh lý khác nhau và giảm nguy cơ về các tình trạng tim mạch ở những người có nguy cơ cao. Dưới đây sẽ mô tả chi tiết hơn những công dụng của thuốc.
### **Đau và sưng nề**
Aspirin có thể làm giảm đau nhẹ đến trung bình, giảm sưng nề hoặc cả hai do nhiều vấn đề sức khỏe khác nhau gây ra, chẳng hạn như:
  * Đau đầu;
  * Do cảm lạnh hoặc cảm cúm;
  * Bong gân;
  * Đau bụng kinh;
  * Bệnh lý mãn tính như viêm khớp và đau nửa đầu.


Trong đau nặng, bác sĩ có thể sử dụng aspirin cùng với một loại thuốc khác, chẳng hạn như thuốc giảm đau opioid hoặc NSAID khác.
### **Ngăn ngừa các biến cố tim mạch**
Việc sử dụng aspirin liều thấp hàng ngày có thể làm giảm nguy cơ biến cố tim mạch ở một số người - tuy nhiên nó không có nghĩa là an toàn cho tất cả mọi người. Cục Quản lý Thực phẩm và Dược phẩm Hoa Kì (FDA) khuyến cáo chỉ sử dụng aspirin theo cách này dưới sự theo dõi sát của bác sĩ.
Ở những người có nguy cơ cao mắc các biến cố tim mạch, aspirin liều thấp có thể làm giảm nguy cơ bằng cách ngăn ngừa hình thành cục máu đông.
Bác sĩ có thể chỉ định dùng aspirin liều thấp hàng ngày cho những người:
  * Mắc các bệnh về tim hoặc mạch máu;
  * Có bằng chứng về thiểu năng tuần hoàn máu não;
  * Có nồng độ cholesterol trong máu cao;
  * Tăng huyết áp;
  * Đái tháo đường;
  * Hút thuốc lá.


Tuy nhiên với những người không có các yếu tố trên, nguy cơ của việc sử dụng aspirin lâu dài có thể lớn hơn là lợi ích. Một số khuyến cáo năm 2016 của Hoa Kỳ nói rằng người lớn từ 50–59 tuổi có thể dùng aspirin hàng ngày để ngăn ngừa ung thư đại trực tràng, cũng như các bệnh lý tim mạch. Tuy nhiên, hướng dẫn này chỉ áp dụng cho một số đối tượng:
  * Có ít nhất 10% nguy cơ mắc bệnh tim mạch trong 10 năm;
  * Không có nguy cơ chảy máu cao;
  * Có thời gian sống dự kiến hơn 10 năm nữa;
  * Có khả năng dùng thuốc hàng ngày với liều thấp trong ít nhất 10 năm nữa.


## **Điều trị các biến cố mạch vành**
Các bác sĩ có thể cho dùng aspirin ngay lập tức sau khi bị nhồi máu cơ tim, đột quỵ, hoặc một biến cố tim mạch khác để ngăn ngừa sự cục máu đông tiếp tục hình thành và sự chết của cơ tim.
Aspirin cũng nằm trong phác đồ điều trị cho người bệnh:
  * Phẫu thuật tái thông mạch máu, như nong mạch vành hoặc phẫu thuật bắc cầu nối chủ vành.
  * Một cơn đột quỵ nhỏ hoặc cơn thiếu máu cục bộ não thoáng qua.
  * Đột quỵ do thiếu máu cục bộ gây ra bởi cục máu đông.


## **Các công dụng khác**
Aspirin cũng có thể giúp điều trị giảm đau và giảm sưng nề do các bệnh lý mãn tính sau:
  * Tình trạng thấp khớp, bao gồm viêm khớp dạng thấp, viêm xương khớp và các tình trạng viêm khớp khác;
  * Bệnh lupus ban đỏ hệ thống;
  * Viêm màng ngoài tim.


Các bác sĩ có thể khuyên dùng aspirin liều thấp cho những người:
  * Bị tổn thương võng mạc, còn gọi là bệnh võng mạc;
  * Người bị đái tháo đường hơn 10 năm;
  * Đang dùng thuốc hạ huyết áp;
  * Có nguy cơ ung thư đại trực tràng.


Xem thêm: [**Một số nguy cơ có thể gặp khi sử dụng Aspirin**](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/mot-so-nguy-co-co-the-gap-khi-su-dung-aspirin)
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [Ngăn ngừa các biến cố tim mạch](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/tac-dung-cua-aspirin-la-gi#ngn-nga-cc-bin-c-tim-mch)
  * [Điều trị các biến cố mạch vành](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/tac-dung-cua-aspirin-la-gi#iu-tr-cc-bin-c-mch-vnh)
  * [Các công dụng khác](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/tac-dung-cua-aspirin-la-gi#cc-cng-dng-khc)



## Hướng dẫn sử dụng miếng dán trên da

Thuốc ở dạng băng dán xuyên da có 2 loại cho 2 tác dụng. 
  * Một là loại dán lên da cho tác dụng tại chỗ kiểu như dán miếng cao dán Salonpas chỉ có tác dụng giảm đau ở chỗ vùng dán. 
  * Còn loại thứ hai mặc dù dán lên da nhưng cho tác dụng toàn thân, tức là cho tác dụng không khác gì thuốc uống hay tiêm, kiểu như dán thuốc lên da ở ngực nhưng trị được đau thắt ngực, phòng nhồi máu cơ tim.


Người dùng thuốc rất cần biết miếng băng dán dùng thuộc loại nào để có sự thận trọng đúng mực, vì nếu dùng loại cho tác dụng toàn thân nhưng dùng không đúng có thể gây tác dụng phụ nguy hiểm. Hoặc không bị đánh lừa, dùng nhầm thuốc chỉ cho tác dụng tại chỗ trong khi cứ đinh ninh đã mua miếng băng dán cho tác dụng toàn thân như uống hoặc tiêm với giá rất đắt.
**1. Đọc kỹ các thông tin hướng dẫn sử dụng trước khi dùng.** Mỗi sản phẩm sẽ có hướng dẫn cụ thể về cách sử dụng.
**2. Rửa sạch tay.**
**3. Chọn vùng da để dán miếng dán**. Hãy làm theo các hướng dẫn cụ thể của bác sĩ hoặc theo hướng dẫn ghi trên sản phẩm để chọn vị trí dán đúng. Vệ sinh sạch sẽ vùng da cần dán và chắc rằng nó không bị dính bột phấn, dầu và kem dưỡng da.
**4. Mở bao bì sản phẩm cẩn thận.** Nếu dùng kéo, cẩn thận để không cắt lẹm vào miếng dán. Đừng sử dụng miếng dán đã bị cắt hoặc bị hư trong bất kỳ trường hợp nào.
**5. Tháo miếng lót bảo vệ theo hướng dẫn trên sản phẩm.** Đừng chạm hẳn ngón tay vào mặt dính của miếng dán. Một số miếng bảo vệ cần được tháo bỏ theo 2 phần. Nếu vậy, hãy đặt một nửa phần dính của miếng dán lên vùng da và nhẹ nhàng bóc lớp bảo vệ còn lại.
**6. Ấn chặt miếng dán** bằng lòng bàn tay của bạn.
**7. Ấn xung quanh các cạnh miếng dán bằng ngón tay của bạn để miếng dán dính lên da.** Hãy chắc chắn rằng miếng dán được dán phẳng trên da (không nên có các vùng nhăn hoặc các nếp gấp trên miếng dán).
8. Bỏ bao bì và miếng lót bảo vệ vào **thùng rác đậy kín.**
**9. Rửa sạch tay.**
10. Khi đến lúc gỡ bỏ miếng dán đã dán trước đó, **hãy dùng ngón tay để bóc nó ra từ từ**. Gấp miếng dán làm đôi và ấn chặt để bịt kín nó lại.
11. **Bỏ miếng dán đã sử dụng vào thùng rác kín**. Miếng dán đã sử dụng vẫn có thể chứa thuốc và có thể gây nguy hiểm cho trẻ em, vật nuôi, hoặc người lớn.
**12. Rửa sạch tay.**
**13. Hãy hỏi bác sĩ xem cần làm gì nếu miếng dán lỏng ra hoặc rơi ra trước khi đến thời gian thay thế.** Nói chung, bạn nên cố gắng nhấn miếng dán trở lại chỗ cần dán bằng ngón tay của bạn. Nếu miếng dán không thể dán lại được, hãy bỏ nó đi và sử dụng một miếng mới lên một vùng khác. Thay miếng dán mới theo đúng thời gian quy định.
**Tài liệu tham khảo**
<http://www.safemedication.com/safemed/MedicationTipsTools/HowtoAdminister/How-to-Use-Transdermal-Patches>
**Nguồn biên dịch:[Y học cộng đồng](https://yhoccongdong.com/)**

## ️ Glucosamine trong điều trị đau xương khớp - Những điều còn tranh cãi

  * [Nguồn gốc của GLUCOSAMINE](https://bvnguyentriphuong.com.vn/co-xuong-khop/glucosamine-trong-dieu-tri-dau-xuong-khop-nhung-dieu-con-tranh-cai#ngun-gc-ca-glucosamine)
  * [Tính hiệu quả trong điều trị viêm xương khớp của glucosamin](https://bvnguyentriphuong.com.vn/co-xuong-khop/glucosamine-trong-dieu-tri-dau-xuong-khop-nhung-dieu-con-tranh-cai#tnh-hiu-qu-trong-iu-tr-vim-xng-khp-ca-glucosamin)
  * [Một số chú ý khi sử dụng glucosamin](https://bvnguyentriphuong.com.vn/co-xuong-khop/glucosamine-trong-dieu-tri-dau-xuong-khop-nhung-dieu-con-tranh-cai#mt-s-ch-khi-s-dng-glucosamin)


## **Nguồn gốc của GLUCOSAMINE**
Glucosamin là một amino – mono – saccharid có nguồn gốc nội sinh, là một thành phần giúp tổng hợp glycosaminoglycan cấu tạo nên mô sụn trong cơ thể _._
lucosamin được tổng hợp bởi cơ thể nhưng khả năng đó giảm đi theo tuổi tác. Glucosamin trên thị truờng có nguồn gốc từ vỏ tôm cua, động vật biển và có 3 dạng glucosamin dùng trong điều trị là glucosamin sulfat, glucosamin hydrochorid và N-Acetylglucosamin, trong đó dạng muối sulfat được cho là có hiệu quả nhất. Dược điển Mỹ 32 có chuyên luận glucosamin sulfat natri clorid
Chondroitin sulfat là hợp chất hữu cơ thuộc nhóm mucopolysaccharid hay còn gọi là nhóm proteoglycan, được cấu tạo bởi chuỗi dài gồm nhiều đơn vị kết hợp đuờng và protein. Trong cơ thể, chondroitin sunfat là thành phần tìm thấy ở sụn khớp, xương, da, giác mạc mắt và thành các động mạch. Để dùng làm thuốc, chondroitin sulfat được lấy từ sụn súc vật là lợn, bò, sụn cá mập (shark cartilage).
## **Tính hiệu quả trong điều trị viêm xương khớp của glucosamin**
Glucosamin và các muối của nó được dùng khá rộng rãi nhu là các sản phẩm được cấp phép hoặc chất hỗ trợ sức khoẻ (health supplements) trong các bệnh viêm xương khớp. Trên thị truờng có nhiều chế phẩm kết hợp glucosamin với các thành phần khác như chondroitin, các vitamin, khoáng chất và các dược liệu.
Việc glucosamin và các chế phẩm kết hợp của nó được sử dụng khá rộng rãi là do trước đây đã có những nghiên cứu cho rằng sử dụng glucosamin an toàn và có hiệu quả làm giảm đau và cải thiện chức năng trong bệnh viêm khớp xương mãn tính.
Tuy vậy, qua các phân tích gộp (phân tích meta) về các nghiên cứu có đối chứng placebo (giả dược) ngẫu nhiên đã kết luận: sở dĩ có nhận định về tác dụng của glucosamin như trên là do có thiếu sót về phương pháp thiết kế nghiên cứu và đôi khi là sự thiên vị trong công bố kết quả đã dẫn đến sự thổi phồng về những lợi ích tiềm năng của glucosamin
Từ truớc đến nay có nhiều nghiên cứu đưa ra những kết luận trái chiều nhau về tính hiệu quả trong điều trị viêm xương khớp của glucosamin. Năm 2007, các nhà khoa học của Đại học Y khoa Boston (Mỹ) đã tiến hành một nghiên cứu để tìm lý do khiến cho kết quả của các nghiên cứu về glucosamin lại khác biệt nhau như vậy. Và họ nhận ra rằng phần lớn các nghiên cứu đưa ra kết quả tích cực về glucosamin được tài trợ bởi các nhà sản xuất các chế phẩm glucosamin, trong khi đa số các nghiên cứu được các nhà khoa học trung lập tiến hành thì đều không tìm thấy hiệu quả chữa bệnh của hoạt chất này.
Một loạt các nghiên cứu mới đây, trong đó có nghiên cứu GAIT (The Glucosamine/chondroitin Arthritis Intervention Trial (GAIT)) (2006) thực hiện trên 1583 bệnh nhân có tuổi trung bình 59 với 64% là phụ nữ, được cho là nghiên cứu có thiết kế tốt, đã đưa ra kết luận là glucosamin và chondroitin sulfat dùng một mình hay kết hợp không có hiệu quả giảm đau trong bệnh viêm khớp gối tốt hơn đáng kể so với giả dược.
Kết quả nghiên cứu của Sawitzke và cộng sự (2008) đánh giá hiệu quả của glucosamin và chondroitin sulfat trên tình trạng mất dần bề rộng khoang khớp (JSW) trên 572 bệnh nhân bị viêm khớp gối đã đi đến kết luận: không có sự khác nhau có ý nghia thống kê về sự giảm JSW trung bình đã ghi nhận được ở bất kỳ nhóm điều trị nào so với nhóm giả dược sau 24 tháng dùng thuốc.
Một nghiên cứu khác của Rozendaal và cộng sự (2008) thực hiện trên 222 bệnh nhân viêm khớp háng đã không nhận thấy ích lợi của việc dùng glucosamin trong 2 năm so với giả dược. Các phân tích gộp (phân tích meta) và tổng quan hệ thống gần đây về các nghiên cứu có đối chứng khi dùng chondroitin sulfat đối với viêm khớp gối hoặc khớp háng đã kết luận là chondroitin chỉ đem lại lợi ích rất nhỏ hoặc không đem lại lợi ích gì so với nhóm dùng đối chứng giả dược.
Từ đó có thể thấy các nghiên cứu được thiết kế tương đối bài bản nhất đã đưa ra kết quả không thừa nhận tác dụng của glucosamin và chondroitin sulfat (dùng một mình hay kết hợp cả hai) trên các bệnh nhân viêm xương khớp.
Do các kết quả nghiên cứu về hiệu quả của glucosamin trong điều trị các bệnh viêm xương khớp chưa có đủ bằng chứng thuyết phục nên các chế phẩm glucosamin lưu hành tại Mỹ và Australia chỉ với tư cách là “thực phẩm chức năng” (dietary supplementation). Ngay cả khi chỉ là thực phẩm chức năng với nhiều nới lỏng trong quản lý mức độ hiệu quả và chất lượng của chế phẩm, năm 2004, công ty dược phẩm Rotta (Rottapharm) đề nghị FDA cho phép chính thức công bố thông tin _“Bổ sung chế độ ăn hàng ngày với glucosamin sulfat kết tinh làm giảm nguy cơ thoái hoá trong viêm khớp, cũng như đau trong viêm khớp và suy giảm chức năng – Daily dietary supplementation with crystalline glucosamine sulfate reduces the risk of osteoarthritis, joint structure deterioration and related joint pain and limitation of function”_ đã không được Hội đồng các chuyên gia của FDA chấp nhận do chưa có đủ bằng chứng khoa học ủng hộ cho công bố đó.
FDA đề nghị công ty thay đổi ngôn ngữ công bố là “Bổ sung chế độ ăn với glucosamin sulfat kết tinh làm giảm nguy cơ viêm xương khớp – Dietary supplementation ofcrystalline glucosamine sulfate reduces the risk of osteoarthritis”
## **Một số chú ý khi sử dụng glucosamin**
**a. Tính đa dạng của chế phẩm của glucosamin:**
Glucosamin trên thị truờng có 3 dạng chính: glucosamin sulfat, glucosamin hydrochorid và N-acetylglucosamin.
Trong đó chỉ có dạng muối sulfat được sử dụng nhiều nhất trong các nghiên cứu và được cho là mang lại tác dụng tích cực. Điều này chưa chắc đã đúng với 2 dạng còn lại của glucosamin nên cán bộ y tế và người tiêu dùng phải chú ý đến thông tin này trên nhãn của sản phẩm.
**b. Hàm lượng:**
Trên thị truờng có nhiều loại glucosamin với hàm lượng rất khác nhau. Trong hầu hết các nghiên cứu, người ta sử dụng tổng liều 1200 – 1500 mg glucosamin thuờng chia 3 lần/ngày. Ngoài ra, nếu kết hợp với chondroitin thì liều được khuyên dùng là 1200mg chia 3 lần/ngày. Nếu sau từ 2 đến 3 tháng không thấy cải thiện tình trạng bệnh thì bệnh nhân nên ngừng thuốc và hỏi ý kiến bác si (dược thư Anh – BNF 59).
**c. Nguồn gốc:**
Những chế phẩm glucosamin đang lưu hành trên thị truờng có nhiều nguồn gốc khác nhau, do đó chất lượng của chúng cũng khác nhau. Ở Mỹ, glucosamin chỉ được coi là thực phẩm chức năng nên ít bị kiểm duyệt chặt chẽ về mặt chất lượng. Ngoài ra, ít có các nghiên cứu về tác dụng và hiệu quả cũng như chất lượng của sản phẩm được tiến hành với các chế phẩm glucosamin có nguồn gốc từ Hàn Quốc, Ấn Độ, Đài Loan, Malaysia – vốn đang có mặt rộng rãi trên thị truờng Việt Nam.
## **Kết luận**
Những tác dụng điều trị của glucosamin trên bệnh nhân viêm xương khớp chưa có được những bằng chứng thực sự rõ ràng và vẫn còn là một vấn đề gây tranh cãi. Khi sử dụng glucosamin cần phải chú ý đến các thông tin về dạng bào chế của glucosamin, về hàm lượng và nguồn gốc của sản phẩm.
Việc dùng glucosamin đủ liều và đủ thời gian cũng rất quan trọng để có thể đem lại những biến chuyển tốt. Khi sử dụng các chế phẩm có chứa glucosamin, người kê đơn cũng như bệnh nhân nên cân nhắc tất cả các yếu tố, nhất là giữa lợi ích kinh tế và hiệu quả chữa bệnh chưa rõ ràng của glucosamin hiện nay.
**Bệnh viện Nguyễn Tri Phương -** Đa khoa Hạng I Thành phố Hồ Chí Minh
[youtube.com/bvntp](http://youtube.com/bvntp)
  * [Nguồn gốc của GLUCOSAMINE](https://bvnguyentriphuong.com.vn/co-xuong-khop/glucosamine-trong-dieu-tri-dau-xuong-khop-nhung-dieu-con-tranh-cai#ngun-gc-ca-glucosamine)
  * [Tính hiệu quả trong điều trị viêm xương khớp của glucosamin](https://bvnguyentriphuong.com.vn/co-xuong-khop/glucosamine-trong-dieu-tri-dau-xuong-khop-nhung-dieu-con-tranh-cai#tnh-hiu-qu-trong-iu-tr-vim-xng-khp-ca-glucosamin)
  * [Một số chú ý khi sử dụng glucosamin](https://bvnguyentriphuong.com.vn/co-xuong-khop/glucosamine-trong-dieu-tri-dau-xuong-khop-nhung-dieu-con-tranh-cai#mt-s-ch-khi-s-dng-glucosamin)



## ️ Tazorac (tazarotene)

  * [Hoạt chất của Tazorac và loại thuốc](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/tazorac-tazarotene#hot-cht-ca-tazorac-v-loi-thuc)
  * [Thuốc generic Tazorac ](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/tazorac-tazarotene#thuc-generic-tazorac)
  * [Tazorac cho mụn trứng cá](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/tazorac-tazarotene#tazorac-cho-mn-trng-c)
  * [Tác dụng phụ và nguy cơ](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/tazorac-tazarotene#tc-dng-ph-v-nguy-c)
  * [Tác dụng phụ nhẹ](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/tazorac-tazarotene#tc-dng-ph-nh)
  * [Tác dụng phụ nghiêm trọng](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/tazorac-tazarotene#tc-dng-ph-nghim-trng)


## **Tazorac là gì?**
Tazorac là một loại thuốc kê đơn đã được FDA chấp thuận để điều trị một số dạng sau:
  * Bệnh vẩy nến thể mảng: các mảng vảy hình thành trên da. Bệnh vẩy nến thể mảng là một trong những loại bệnh vẩy nến.
  * Mụn, một tên gọi khác là mụn trứng cá.


Tazorac có dạng kem và gel.
### **Kem Tazorac**
Kem Tazorac được chấp thuận để điều trị mụn trứng cá ở người lớn cũng như trẻ em từ 12 tuổi trở lên. Dạng kem cũng được phê duyệt để điều trị bệnh vẩy nến mảng bám ở người lớn.
Kem Tazorac có hai hàm lượng: 0,05% và 0,1%. Những hàm lượng khác nhau của kem Tazorac được sử dụng cho:
  * Bệnh vẩy nến thể mảng (0,05% và 0,1%)
  * Mụn trứng cá (chỉ 0,1%)


Bôi kem lên da mỗi ngày một lần vào buổi tối.
### **Gel Tazorac**
Gel Tazorac được phê duyệt để điều trị bệnh vẩy nến thể mảng và mụn trứng cá ở người lớn cũng như trẻ em từ 12 tuổi trở lên.
Gel Tazorac có hai hàm lượng: 0,05% và 0,1%. Những hàm lượng khác nhau của gel Tazorac được sử dụng cho:
  * Bệnh vẩy nến thể mảng ảnh hưởng đến dưới 20% diện tích bề mặt cơ thể (0,05% và 0,1%)
  * Mụn trứng cá nhẹ đến trung bình ảnh hưởng đến khuôn mặt (chỉ 0,1%)


Dùng gel bôi lên da mỗi ngày một lần vào buổi tối.
### **Hoạt chất của Tazorac và loại thuốc**
Tazorac chứa hoạt chất tazarotene. Điều này có nghĩa là tazarotene là thành phần làm cho Tazorac hoạt động.
Tazorac là một loại thuốc gọi là retinoid. Retinoids thì liên quan đến Vitamin A.
### **Thuốc generic Tazorac**
Tazorac có thuốc generic gọi là tazarotene. Một thuốc generic là một bản sao chính xác của thuốc trong một loại biệt dược gốc. Thuốc generic được coi là an toàn và hiệu quả như thuốc phát minh. Generics có xu hướng chi phí ít hơn so với biệt dược gốc.
Trong một số trường hợp, thuốc phát minh và thuốc generic có thể có các dạng thuốc và hàm lượng khác nhau.
Tazorac chứa hoạt chất tazarotene. Các loại thuốc biệt dược khác có chứa tazarotene cũng có sẵn, ví dụ Fabior và Arazlo.
### **Tazorac cho mụn trứng cá**
Cơ quan Quản lý Thực phẩm và Dược phẩm Hoa Kỳ (FDA) phê duyệt các loại thuốc kê đơn như Tazorac để điều trị một số bệnh. Tazorac cũng có thể được sử dụng off-label cho các tình trạng khác. Sử dụng off-label là khi một loại thuốc được phê duyệt để điều trị cho một tình trạng bệnh lý khác.
Kem Tazorac 0,1% và gel 0,1% được FDA phê duyệt để điều trị một số dạng mụn trứng cá ở người lớn cũng như trẻ em từ 12 tuổi trở lên. Tazorac 0,1% gel chỉ được sử dụng cho mụn trứng cá nhẹ đến trung bình ảnh hưởng đến khuôn mặt
## **Tác dụng phụ và nguy cơ**
Tazorac và Retin-A đều chứa retinoid. Do đó, những loại thuốc này có thể gây ra tác dụng phụ rất giống nhau. Dưới đây là ví dụ về các tác dụng phụ.
### **Tác dụng phụ nhẹ**
Danh sách này chứa tới 10 tác dụng phụ nhẹ phổ biến nhất có thể xảy ra với cả Tazorac và Retin-A (khi được sử dụng riêng lẻ):
  * Da khô;
  * Ngứa;
  * Đỏ da;
  * Da có cảm giác như bị đốt cháy hay châm chích;
  * Lột da.


### **Tác dụng phụ nghiêm trọng**
Dưới đây là các ví dụ về các tác dụng phụ nghiêm trọng có thể xảy ra với Tazorac, với Retin-A hoặc với cả hai loại thuốc (khi được sử dụng riêng lẻ).
  * Có thể xảy ra với Tazorac: phản ứng dị ứng da;
  * Có thể xảy ra với Retin-A: một vài tác dụng phụ nghiêm trọng;
  * Có thể xảy ra với cả Tazorac và Retin-A: kích ứng da nghiêm trọng, nhạy cảm với ánh nắng mặt trời và nguy cơ bị cháy nắng;


Xem thêm: [**Các câu hỏi thường gặp về Tazorac**](https://bvnguyentriphuong.com.vn/khoa-duoc/cac-cau-hoi-thuong-gap-ve-tazorac)
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [Hoạt chất của Tazorac và loại thuốc](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/tazorac-tazarotene#hot-cht-ca-tazorac-v-loi-thuc)
  * [Thuốc generic Tazorac ](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/tazorac-tazarotene#thuc-generic-tazorac)
  * [Tazorac cho mụn trứng cá](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/tazorac-tazarotene#tazorac-cho-mn-trng-c)
  * [Tác dụng phụ và nguy cơ](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/tazorac-tazarotene#tc-dng-ph-v-nguy-c)
  * [Tác dụng phụ nhẹ](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/tazorac-tazarotene#tc-dng-ph-nh)
  * [Tác dụng phụ nghiêm trọng](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/tazorac-tazarotene#tc-dng-ph-nghim-trng)



## Hướng dẫn sử dụng viên đặt âm đạo

**Bệnh viện Nguyễn Tri Phương** - Bệnh viện Đa khoa Hạng I Thành phố Hồ Chí Minh
  * 468 Nguyễn Trãi, Phường 8, Quận 5, Tp. Hồ Chí Minh
  * Hotline: (84-028) 39234332
  * Mạng xã hội **Facebook** : [**Bệnh viện Nguyễn Tri Phương**](https://www.facebook.com/BVNTP/)
  * Đăng ký (Subcribe) kênh **Youtube** : [https://youtube.com/bvntp](https://youtube.com/bvntp?fbclid=IwAR3q_UvPI4OZAebT1uQGPKKwk3RmCzAFLkBJm9lb7EwIz0EHtgiLhKM5bxU)
  * Quan tâm Zalo Official: [zalo.me/1744466261097093886](https://zalo.me/1744466261097093886?fbclid=IwAR3E-fLqdh-x1cYSvuDY6E5Eyxfjo5ZSs4p0hDWAyBG-ROlTkxXkXvdEWAY)



## ️ Lưu ý khi cho trẻ nhỏ uống thuốc

  * [Tại sao trẻ nhỏ dễ nhạy cảm với thuốc?](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/luu-y-khi-cho-tre-nho-uong-thuoc#ti-sao-tr-nh-d-nhy-cm-vi-thuc)
  * [Các lưu ý khi sử dụng thuốc ở trẻ em](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/luu-y-khi-cho-tre-nho-uong-thuoc#cc-lu-khi-s-dng-thuc-tr-em)
  * [Liều lượng thuốc](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/luu-y-khi-cho-tre-nho-uong-thuoc#liu-lng-thuc)
  * [Cách dùng thuốc](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/luu-y-khi-cho-tre-nho-uong-thuoc#cch-dng-thuc)


## **Tại sao trẻ nhỏ dễ nhạy cảm với thuốc?**
Câu trả lời chính là do cơ thể trẻ vẫn chưa phát triển đầy đủ cả về cấu trúc lẫn chức năng như người lớn. Một số cơ quan chính ảnh hưởng đáng kể đến quá trình tác động thuốc trong cơ thể bao gồm:
  * **Hệ tiêu hóa:** Chưa phát triển hoàn thiện, đặc biệt trong 3 năm đầu đời. Do đó khi dùng các thuốc đường uống, quá trình hấp thu thuốc dễ bị thất thường. Một ví dụ cho trường hợp này là lượng acid trong dạ dày của trẻ được tiết ra ít hơn so với người lớn. Điều này ảnh hưởng đến độ pH trong dạ dày, đây lại là yếu tố quan trọng cho việc hấp thu thuốc. Khi pH dạ dày thay đổi, một số thuốc có thể được hấp thu vào máu nhiều hơn, một số khác lại ít hơn khiến cho tác dụng thuốc trở nên khó kiểm soát.
  * **Cấu trúc da:** Da trẻ mỏng hơn và tính thấm cao nên rất nhạy cảm với thuốc. Thuốc có thể gây dị ứng, gây độc khi bôi lên da. Ngoài ra, khi bôi một lượng quá nhiều, thuốc sẽ dễ dàng thấm vào máu gây nhiều tác dụng phụ khác, đặc biệt với các kem bôi ngoài da chứa corticoid.
  * **Chức năng gan và thận:** Chưa phát triển toàn diện. Đây lại là 2 cơ quan cần thiết cho sự chuyển hóa và thải trừ thuốc trong cơ thể. Chính vì thế, một số thuốc dùng ở trẻ nhỏ có nguy cơ bị thải trừ chậm, tích lũy lại và gây ra các tác dụng không mong muốn.
  * **Hàng rào máu - não:** Ở trẻ sơ sinh, chức năng của hàng rào máu - não chưa được hoàn thiện nên một số thuốc có thể đi qua dễ dàng hơn so với người lớn. Do đó, giai đoạn này, trẻ rất nhạy cảm với các thuốc ức chế thần kinh trung ương.


## **Các lưu ý khi sử dụng thuốc ở trẻ em**
Theo Dược thư Quốc gia Việt Nam II, cần hết sức thận trọng trong việc lựa chọn và sử dụng thuốc ở trẻ nhỏ không chỉ ở các bậc cha mẹ mà còn ở cả nhân viên y tế, cụ thể như sau:
### **Liều lượng thuốc**
  * Liều lượng thuốc ở trẻ em cần phải được điều chỉnh theo đặc tính của riêng từng thuốc, theo tuổi (yếu tố quyết định chính), tình trạng bệnh, giới tính (đặc biệt thời kỳ dậy thì) và theo mức độ trầm trọng của bệnh. 
  * Cách thông thường được sử dụng nhiều chính là liều tính theo cân nặng cơ thể (mg/kg) hoặc theo lớp tuổi như phân loại phía trên. Với trẻ em béo phì, không được sử dụng số cân thực tế của trẻ mà phải tính theo cân nặng lý tưởng thông qua chiều cao để tránh dùng thuốc quá liều.


### **Cách dùng thuốc**
  * Vì trẻ còn nhỏ tuổi, việc dùng các thuốc dạng viên uống có thể gặp khó khăn, vì vậy nên ưu tiên các thuốc dạng lỏng như siro, cốm, bột pha hỗn dịch uống…
  * Khi dùng thuốc dạng lỏng cho trẻ, nên chú ý sử dụng đúng các dụng cụ chia liều có kèm trong bao bì thuốc. Không nên tự ý nhắm chừng lượng thuốc bằng muỗng hay ly tách khác tại nhà. 
  * Thuốc bột hay cốm sau khi pha thành dạng lỏng cần chú ý hạn dùng (thường là trong ngày hoặc một vài ngày); phần không dùng hết phải bỏ đi cho dù hạn dùng ghi trên bao bì chưa hết.
  * Không được tự ý thêm sữa, nước trái cây hoặc thuốc khác vào dạng thuốc lỏng đã pha để tránh tương tác bất lợi gây giảm tác dụng thuốc. 
  * Cần lưu ý khi chọn giờ cho trẻ uống thuốc: Nên tránh đánh thức trẻ về đêm để trẻ ngủ được đủ giấc. Ngoài ra, nên tránh giờ trẻ phải uống thuốc ở trường vì khó bảo đảm tuân thủ do trẻ quên hoặc mặc cảm với bạn bè không dám uống.
  * Trong bảo quản thuốc, cần lưu ý không để thuốc ở tầm tay của trẻ em. Trước khi dùng thuốc, cần kiểm tra lại hạn sử dụng, đặc biệt với những thuốc dự trữ tại nhà.


**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh
[youtube.com/bvntp](http://youtube.com/bvntp)
  * [Tại sao trẻ nhỏ dễ nhạy cảm với thuốc?](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/luu-y-khi-cho-tre-nho-uong-thuoc#ti-sao-tr-nh-d-nhy-cm-vi-thuc)
  * [Các lưu ý khi sử dụng thuốc ở trẻ em](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/luu-y-khi-cho-tre-nho-uong-thuoc#cc-lu-khi-s-dng-thuc-tr-em)
  * [Liều lượng thuốc](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/luu-y-khi-cho-tre-nho-uong-thuoc#liu-lng-thuc)
  * [Cách dùng thuốc](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/luu-y-khi-cho-tre-nho-uong-thuoc#cch-dng-thuc)



## Thật bất ngờ : Thuốc giảm đau nhóm opiods có thể làm tăng nguy cơ đau mãn tính

  * [ĐAU SAU PHẪU THUẬT VÀ THỬ NGHIỆM VỚI OPIOIDS ](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/thuoc-giam-dau-nhom-opioids-co-the-lam-tang-nguy-co-dau-man-tinh#au-sau-phu-thut-v-th-nghim-vi-opioids)
  * [TẠI SAO MORPHINE LẠI LÀM ĐAU SAU PHẪU THUẬT NHIỀU HƠN?](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/thuoc-giam-dau-nhom-opioids-co-the-lam-tang-nguy-co-dau-man-tinh#ti-sao-morphine-li-lm-au-sau-phu-thut-nhiu-hn)


_Sau cuộc phẫu thuật, thuốc giảm đau nhóm opioids – như morphine – thường được dùng để giảm đau. Tuy nhiên, theo nghiên cứu mới nhất, nhóm thuốc này có thể tăng khả năng bị đau mãn tính._
Thuốc giảm đau nhóm opioids gây ra nhiều vấn đề rất lớn. Hơn 100 người chết vì sử dụng quá liều opioid mỗi ngày ở Mỹ. Ngoài việc có thể gây nghiện, một khía cạnh khác của việc sử dụng opioid mà hiếm khi được đặt câu hỏi là: chức năng chính của chúng – giảm đau - có hiệu quả thực sự không?
Được sử dụng dưới nhiều hình thức trong nhiều thiên niên kỷ, thuốc opioids dập tắt cơn đau một cách nhanh chóng, làm cho bệnh nhân thoải mái hơn. Nghiên cứu mới nhất, được thực hiện tại Đại học Colorado Boulder, đưa khái niệm vững chắc này lên trang đầu.
Giáo sư cao cấp Linda Watkins, đến từ Khoa Tâm lý học và Thần kinh học, đề cập: điều đáng ngại là _“[…] có một mặt tối khác của thuốc opioids mà nhiều người không để ý tới”._
Trong trường hợp này, gây nghiện không phải là điều mà Giáo sư Watkins đang đề cập mà vấn đề nghịch lý là opioids có thể làm kéo dài cơn đau sau phẫu thuật. Kết quả được công bố gần đây trên tạp chí [Anesthesia and Analgesia](https://journals.lww.com/anesthesia-analgesia/Abstract/publishahead/Repeated_Morphine_Prolongs_Postoperative_Pain_in.96846.aspx).
## **ĐAU SAU PHẪU THUẬT VÀ THỬ NGHIỆM VỚI OPIOIDS**
Để nghiên cứu, Giáo sư Watkins và cộng sự Peter Grace, thuộc Trung tâm Ung thư MD Anderson ở Houston, TX, đã tiến hành phẫu thuật mở bụng trên hàng chục ngàn con chuột đực mỗi năm.
“ _Thuốc giảm đau nhóm opioids thực sự hiệu quả để giảm đau cấp tính. Không có thuốc nào làm tốt hơn. Nhưng rất ít nghiên cứu thực hiện để xem xét những gì xảy ra sau vài tuần đến vài tháng không còn sử dụng chúng.”_ _-_ _Peter Grace_
Sau phẫu thuật, một nhóm chuột được dùng một liều morphine vừa phải giống nhau trong 7 ngày tiếp theo, trong khi một nhóm khác dùng morphine trong 8 ngày và liều lượng giảm dần vào ngày thứ 10.
Một nhóm khác được cho dùng morphine trong 10 ngày, sau đó ngưng thuốc đột ngột. Một nhóm cuối cùng được tiêm nước muối thay vì morphine.
Trong một thí nghiệm khác, một nhóm chuột được thực hiện một liệu trình morphine 7 ngày và kết thúc 1 tuần trước khi làm phẫu thuật. Trước khi liệu trình morphin bắt đầu, và sau khi chúng được hoàn thành, người ta đo độ nhạy cảm đau của chuột, cũng như hoạt động của các gen liên quan đến hiện tượng viêm ở tủy sống.
So với những con chuột chỉ dùng nước muối, những con được dùng morphine phải chịu đựng cơn đau sau phẫu thuật nhiều hơn trên 3 tuần. Ngoài ra, những con chuột sử dụng morphine càng lâu thì cơn đau của chúng càng kéo dài.
Nghiên cứu cũng cho thấy việc giảm liều morphine không có sự khác biệt. Theo Grace giải thích, _“Điều này cho chúng ta biết hiện tượng này không liên quan đến việc ngưng dùng opioid, thứ mà chúng ta nghĩ có thể gây ra đau đớn. Một chuyện gì đó khác đang diễn ra ở đây.”_
## **TẠI SAO MORPHINE LẠI LÀM ĐAU SAU PHẪU THUẬT NHIỀU HƠN?**
Tất nhiên, câu hỏi tiếp theo cần đặt ra là điều gì gây ra chuyện vô lý này. Giáo sư Watkins gọi đó là kết quả của hai cuộc “tấn công” trên các tế bào thần kinh đệm.
Trong não, các tế bào thần kinh đệm có số lượng nhiều hơn tế bào thần kinh nơron. Chúng bảo vệ và hỗ trợ các tế bào thần kinh, như một phần vai trò là người bảo vệ, chúng điều khiển phản ứng miễn dịch của não, bao gồm cả hiện tượng viêm.
Lần “tấn công” đầu tiên xảy ra khi cuộc phẫu thuật kích hoạt sự cảnh báo của các tế bào thần kinh đệm, như thụ thể 4 (TLR4). Những thụ thể này giúp phối hợp các phản ứng viêm với nhau.
Lần “tấn công” thứ hai là morphine, cũng kích thích TLR4. Giáo sư Watkins giải thích: “ _Với lần đánh thứ hai này, các tế bào thần kinh đệm có phản ứng nhanh hơn, mạnh hơn và lâu hơn trước, gây ra tình trạng viêm lâu dài hơn và đôi khi gây tổn thương mô cục bộ.”_
Mặc dù nghiên cứu này thực hiện trên một mô hình động vật và sẽ cần nghiên cứu thêm ở người, nhưng nó phù hợp với những phát hiện trước đó.
Ví dụ: vào năm 2016, các nhà khoa học đã công bố một nghiên cứu khác trên động vật, cho thấy một vài ngày điều trị đau dây thần kinh ngoại biên bằng thuốc opioids làm đau nặng và kéo dài thêm. Trong nghiên cứu đó, việc kích hoạt viêm cũng có liên quan.
_“Một số lượng người cao bất thường không còn đau mãn tính sau phẫu thuật”,_ Giáo sư Watkins nói. Trên thực tế, hàng triệu người dân Hoa Kỳ phải chịu đựng cơn đau mãn tính. _“Nghiên cứu mới này cho thấy cái nhìn sâu sắc để giải thích cho điều đó.”_
Điều thú vị là những con chuột dùng một liệu trình morphine kết thúc một tuần trước khi phẫu thuật không trải qua cơn đau hậu phẫu kéo dài, khiến các tác giả nghiên cứu kết luận rằng có một giai đoạn “cửa sổ” quan trọng hiệu quả hơn khi dùng morphine giảm đau. Bởi vì thuốc opioids hiện được coi là cách tốt nhất để giảm đau sau phẫu thuật, nếu những kết quả này được công nhận ở con người, nó sẽ khiến y học rơi vào tình trạng khó khăn.
Đây là lý do tại sao Giáo sư Watkins đang tập trung hết sức vào việc thiết kế các loại thuốc có thể được dùng cùng với opioid để giảm phản ứng viêm. Bà cũng đang nghiên cứu các loại thuốc giảm đau thay thế khác, như cannabinoids.
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [ĐAU SAU PHẪU THUẬT VÀ THỬ NGHIỆM VỚI OPIOIDS ](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/thuoc-giam-dau-nhom-opioids-co-the-lam-tang-nguy-co-dau-man-tinh#au-sau-phu-thut-v-th-nghim-vi-opioids)
  * [TẠI SAO MORPHINE LẠI LÀM ĐAU SAU PHẪU THUẬT NHIỀU HƠN?](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/thuoc-giam-dau-nhom-opioids-co-the-lam-tang-nguy-co-dau-man-tinh#ti-sao-morphine-li-lm-au-sau-phu-thut-nhiu-hn)



## CHƯƠNG TRÌNH THỰC TẬP VỀ DƯỢC LÂM SÀNG

**Lợi ích khi tham gia chương trình**
  * Rèn luyện kỹ năng thực hành trực tiếp 
  * Xây dựng mối quan hệ nghề nghiệp 
  * Tiếp nhận kinh nghiệm, tài liệu hữu ích
  * Có chứng nhận 


**Nội dung: xem thêm chi tiết** được trình bày ở Bảng 1 bên dưới.
(Lưu ý: Nội dung chương trình có thể điều chỉnh, thay đổi để phù hợp với nhu cầu của học viên.)
**Module 1 (1 tuần từ thứ 2 đến thứ 6, giờ hành chính)**
Tuần 1 cung cấp cho các học viên cơ hội tham quan, kiến tập và thực hiện các hoạt động dược lâm sàng cơ bản tại Bệnh viện Nguyễn Tri Phương. 
**Mục tiêu tuần 1**
**Sau khi tham gia thực tập Tuần 1, học viên có thể:**
  * Trình bày được các hoạt động dược lâm sàng tại bệnh viện 
  * Trình bày được vai trò của dược sĩ khi duyệt đơn cho bệnh nhân ngoại trú
  * Thực hiện được hoạt động tư vấn cho bệnh nhân ngoại trú
  * Thực hiện được hoạt động phân tích bệnh án nội trú
  * Trình bày được quy trình, kinh nghiệm và các nguồn tài liệu phục vụ cho hoạt động thông tin thuốc
  * Trình bày được quy trình và kinh nghiệm khi quản lý phản ứng có hại tại bệnh viện
  * Trình bày được quy trình và kinh nghiệm triển khai hoạt động dược lâm sàng khi đi bệnh phòng và hội chẩn cùng bác sĩ. 


**Module 2 (1 tuần từ thứ 2 đến thứ 6, giờ hành chính)**
Tuần 2 cung cấp cho các học viên cơ hội tham quan, kiến tập và thực hiện các hoạt động cảnh giác dược tại Bệnh viện Nguyễn Tri Phương. 
**Mục tiêu tuần 2**
Sau khi tham gia thực tập Tuần 1, học viên có thể:
  * Diễn giải được các dấu hiệu lâm sàng và cận lâm sàng 
  * Xử lý được các tình huống dị ứng liên quan kháng sinh, hội chứng người đỏ, suy thận, tăng thải thận, ADR trên huyết học do thuốc
  * Trình bày được quy trình và kinh nghiệm triển khai hoạt động dược lâm sàng tại phòng tư vấn và khi đi bệnh phòng và hội chẩn cùng bác sĩ. 


**Module 3 (1 tuần từ thứ 2 đến thứ 6, giờ hành chính)**
Tuần 3 cung cấp cho các học viên cơ hội tham quan, kiến tập và thực hiện các hoạt động quản lý kháng sinh tại Bệnh viện Nguyễn Tri Phương. 
**Mục tiêu tuần 3**
Sau khi tham gia thực tập Tuần 3, học viên có thể:
  * Trình bày được các kinh nghiệm triển khai chương trình quản lý kháng sinh tại bệnh viện
  * Thực hiện được tư vấn sử dụng kháng sinh vancomycin và colistin 
  * Thực hiện được tư vấn sử dụng kháng sinh điều trị nhiễm khuẩn Gram âm. Gram dương
  * Xử lý được các tình huống ADR liên quan kháng sinh 
  * Trình bày được quy trình và kinh nghiệm triển khai hoạt động dược lâm sàng tại phòng tư vấn và khi đi bệnh phòng và hội chẩn cùng bác sĩ. 


**Bảng 1. Nội dung của các module đào tạo dược lâm sàng tại BV Nguyễn Tri Phương**
NỘI DUNG  
---  
**TUẦN 1** Tổng quan Hoạt động DLS |  Tìm hiểu các hoạt động DLS tại bệnh viện  
Tham quan hoạt động DLS tại phòng phát thuốc BHYT  
Kiến tập hoạt động tư vấn thuốc cho bệnh nhân ngoại trú  
Tìm hiểu quy trình phân tích bệnh án nội trú  
Tìm hiểu quy trình hoạt động thông tin thuốc  
Tìm hiểu quy trình quản lý phản ứng có hại của thuố  
Kiến tập hoạt động DLS tại bệnh phòng  
Tham gia hội chẩn trên khoa lâm sàng  
**TUẦN 2** **Cảnh giác dược** |  Kỹ năng đánh giá các dấu hiệu lâm sàng và chỉ số cận lâm sàng  
Dị ứng kháng sinh từ góc nhìn can thiệp dược  
Hội chứng người đỏ khi sử dụng Vancomycin  
Suy thận trên bệnh nhân dùng colistin và vancomycin   
ADR trên huyết học  
Tăng thanh thải thận và việc dùng thuốc  
Kiến tập hoạt động DLS tại phòng tư vấn và bệnh phòng  
Tham gia hội chẩn trên khoa lâm sàng  
**TUẦN 3** Kháng sinh |  Chương trình quản lý kháng sinh tại bệnh viện  
Hướng dẫn dùng vancomycin và colistin - ca lâm sàng thực tế  
Ca lâm sàng nhiễm khuẩn Gram âm, Gram dương  
Ca lâm sàng ADR liên quan kháng sinh  
Kiến tập hoạt động DLS tại phòng tư vấn và bệnh phòng  
Tham gia hội chẩn trên khoa lâm sàng  
**Kinh phí: 1.000.000đ/tuần/học viên**(Học viên tự túc chi phí ăn, ở. Chi phí chưa bao gồm tài liệu)
**Cách thức đăng ký:** chiêu sinh liên tục với lựa chọn thời gian theo nhu cầu từng học viên
**Kết thúc khóa** có cấp chứng nhận thời gian tham gia 
**Liên hệ:**
- Phòng Quản lý chất lượng, lầu 1, khu A, bệnh viện Nguyễn Tri Phương
- Cần thêm thông tin xin thể liên hệ: BS Minh - 0983848985

## Những tương tác với thuốc cần lưu ý trong thực hành dinh dưỡng trên lâm sàng

  * [TƯƠNG TÁC GIỮA DINH DƯỠNG NGOÀI ĐƯỜNG TIÊU HOÁ VỚI THUỐC](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/nhung-tuong-tac-voi-thuoc-can-luu-y-trong-thuc-hanh-dinh-duong-tren-lam-sang#tng-tc-gia-dinh-dng-ngoi-ng-tiu-ho-vi-thuc)
  * [Ảnh hưởng do công thức PN đến tính chất dược lý của thuốc](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/nhung-tuong-tac-voi-thuoc-can-luu-y-trong-thuc-hanh-dinh-duong-tren-lam-sang#nh-hng-do-cng-thc-pn-n-tnh-cht-dc-l-ca-thuc)
  * [Chú ý khi dùng catheter tĩnh mạch](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/nhung-tuong-tac-voi-thuoc-can-luu-y-trong-thuc-hanh-dinh-duong-tren-lam-sang#ch-khi-dng-catheter-tnh-mch)
  * [Tương hợp của thuốc giữa các loại PN](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/nhung-tuong-tac-voi-thuoc-can-luu-y-trong-thuc-hanh-dinh-duong-tren-lam-sang#tng-hp-ca-thuc-gia-cc-loi-pn)
  * [Tác động của thành phần nhũ tương Lipid trong PN](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/nhung-tuong-tac-voi-thuoc-can-luu-y-trong-thuc-hanh-dinh-duong-tren-lam-sang#tc-ng-ca-thnh-phn-nh-tng-lipid-trong-pn)
  * [Chú ý trong việc sử dụng phương pháp truyền PN](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/nhung-tuong-tac-voi-thuoc-can-luu-y-trong-thuc-hanh-dinh-duong-tren-lam-sang#ch-trong-vic-s-dng-phng-php-truyn-pn)
  * [Dinh dưỡng tĩnh mạch với việc dùng thuốc an toàn](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/nhung-tuong-tac-voi-thuoc-can-luu-y-trong-thuc-hanh-dinh-duong-tren-lam-sang#dinh-dng-tnh-mch-vi-vic-dng-thuc-an-ton)
  * [TƯƠNG TÁC GIỮA DINH DƯỠNG ĐƯỜNG TIÊU HÓA (EN) VÀ THUỐC](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/nhung-tuong-tac-voi-thuoc-can-luu-y-trong-thuc-hanh-dinh-duong-tren-lam-sang#tng-tc-gia-dinh-dng-ng-tiu-ha-en-v-thuc)
  * [Ảnh hưởng của cách dùng EN](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/nhung-tuong-tac-voi-thuoc-can-luu-y-trong-thuc-hanh-dinh-duong-tren-lam-sang#nh-hng-ca-cch-dng-en)
  * [Ảnh hưởng của kích cỡ và vị trí đặt sonde cho ăn](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/nhung-tuong-tac-voi-thuoc-can-luu-y-trong-thuc-hanh-dinh-duong-tren-lam-sang#nh-hng-ca-kch-c-v-v-tr-t-sonde-cho-n)
  * [Thêm một thuốc vào dung dịch dinh dưỡng đường ruột](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/nhung-tuong-tac-voi-thuoc-can-luu-y-trong-thuc-hanh-dinh-duong-tren-lam-sang#thm-mt-thuc-vo-dung-dch-dinh-dng-ng-rut)


## **TỔNG QUAN**
Tương tác giữa các chất dinh dưỡng với thuốc có thể làm thay đổi nồng độ của chúng trong máu cũng như các đặc tính tác dụng, tính chất vật lý hay độ ổn định. Những thay đổi này sẽ dẫn đến việc ảnh hưởng người bệnh khi chúng ta cho người bệnh sử dụng thuốc và dinh dưỡng như tác dụng phụ hoặc có thể là một sự cố y khoa đáng tiếc. Các vấn đề về sự không tương hợp giữa thuốc và dinh dưỡng đường tĩnh mạch hay dinh dưỡng đường tiêu hoá gây mất hiệu quả điều trị và các biến chứng nặng khác của cả 2 đối với người bệnh. Vì vậy, khi thực hành dinh dưỡng lâm sàng có dùng thuốc trên người bệnh luôn luôn phải đảm bảo sự tương hợp giữa thuốc và dinh dưỡng. Nếu phải dùng các loại không tương hợp thì phải sử dụng các biện pháp để hạn chế và tránh né chúng gặp nhau trong cơ thể người bệnh nhằm hạn chế tối đa các tác dụng không mong muốn xảy ra. Mặc dù tại nhiều nơi, dược sĩ lâm sàng đã cung cấp các loại hình thông tin thuốc về mảng này tuy nhiên đây là một mảng lớn và còn rất nhiều yếu tố khác tham gia dẫn đến thay đổi rất đáng kể giữa thực tế so với y văn.
Thực tế, trên lâm sàng đã có nhiều biện pháp can thiệp tuy nhiên chưa thực sự có cở sở khoa học đầy đủ nào để cung cấp hoàn thiện các giải pháp trong tất cả trường hợp. Việc hạ bậc từ dinh dưỡng tĩnh mạch xuống đường tiêu hoá qua ống thông rồi xuống đường miệng đã góp phần giảm tải các ảnh hưởng xâm lấn và tương tác bất lợi trên lâm sàng. Tuy nhiên, trong từng biện pháp can thiệp ở từng giai đoạn dinh dưỡng đều cần có những chú ý nhất định để việc dùng thuốc cũng như dinh dưỡng được an toàn, hiệu quả và hợp lí.
Từ khi dược lâm sàng xuất hiện những dược sĩ với kiến thức và tâm huyết lớn về chuyên môn thuốc, họ đã trở thành người có năng lực nhất trong việc cung cấp các thông tin, tư vấn hay thậm chí là can thiệp trong việc dùng thuốc. Mục tiêu là phát hiện, phòng ngừa và ngăn chặn các bất lợi cho bệnh nhân. Việc có dược sĩ lâm sàng tham gia như là một chân trong kiềng ba chân Bác sĩ – Dược sĩ – Điều dưỡng làm cho công tác điều trị được vững chắc và hoàn hảo.
## **TƯƠNG TÁC GIỮA DINH DƯỠNG NGOÀI ĐƯỜNG TIÊU HOÁ VỚI THUỐC**
Hiện nay trên thị trường dược phẩm có nhiều loại **dinh dưỡng tĩnh mạch** (viết tắt PN) mới như các hỗn hợp 2 trong 1 hay tất cả trong 1 túi. Trong đó có thêm nhiều chất đa lượng, vi lượng và có khi có cả **nhũ tương lipid** khiến chúng trở thành một hỗn hợp nhiều thành phần và việc xác định tương tác giữa chúng với thuốc là rất phức tạp.
Tuy nhiên, trên thực hành lâm sàng luôn luôn tồn tại nhu cầu thêm thuốc vào trong dịch truyền dinh dưỡng do nó có nhiều lợi ích bao gồm giảm lượng dịnh truyền vào bệnh nhân phải hạn chế dịch, giảm số lượng catheter tĩnh mạch và tiết kiệm vein cũng như thời gian hơn (4, 5). Tuy nhiên, vấn đề nguy cơ về độ ổn định và tương kỵ là rất cao do sự hiện diện của nhiều chất trong hỗn hợp PN (nhũ tương Lipid, các axit amin, đường, nguyên tố vi lượng, các vitamin, điện giải), do đó việc thêm thuốc vào dung dịch PN thường quy không được khuyến cáo.
Việc thêm các thuốc có tính thân dầu vào PN tạo nên công thức thuốc mới không giống ban đầu làm lệch đi nhiều về các chỉ số dược động học, dược lực học cũng như tính ổn định của thuốc so với dạng ban đầu. Thuốc có thể bị bất hoạt bởi sự thay đổi pH của hỗn hợp, phản ứng oxi hóa khử và sự tạo phức. Một vài phản ứng tương kỵ có thể nhận biết được (thay đổi màu, hình thành kết tủa hoặc bọt khí), nhưng một số thay đổi lại không thể nhận biết bằng cảm quan dẫn đến một số vấn đề trong thực hành lâm sàng (6). Thay đổi này dẫn tới hình thành kết tủa hay các gốc tự do gây giảm hiệu quả của cả thuốc lẫn dinh dưỡng và trực tiếp gây hại trên bệnh nhân (5).
Đa số các dịch truyền nuôi dưỡng trên thị trường đều bị nhiễm các nguyên tố vi lượng crom và nhôm. Ion crom làm giảm mức lọc cầu thận ở bệnh nhi dẫn đến giảm thanh thải thuốc. Ngoài ra, việc tích luỹ ion nhôm trong cơ thể có thể dẫn tới độc tính trên xương và thần kinh ở trẻ em sử dụng dài ngày. Do đó, khi dùng PN nên tránh thêm các nguyên tố crom và nhôm ở những trẻ có nuôi dưỡng đường tĩnh mạch dài ngày (3).
Khi không có sự thay thế nào khác và việc bổ sung một thuốc là không thể tránh khỏi, xem xét các vấn đề sau để quyết định có cho thêm thuốc vào PN hay không:
  * Độ ổn định của hỗn hợp trong 24 giờ;
  * Sự tương hợp của thuốc trong dung dịch nuôi dưỡng ngoài đường tiêu hóa;
  * Thuốc có thích hợp để truyền liên tục như dịch truyền hay không;
  * Độ ổn định của thuốc ở tốc độ truyền của dung dịch PN.


Một trong những vấn đề đã gặp trong thực hành lâm sàng là xuất hiện tình trạng tăng đường huyết do dùng PN. Lúc này có thể xem xét thêm **Insulin** vào dịch truyền để giảm thiểu nguy cơ này. Trong tất cả các loại insulin chỉ có Insulin Regular là tương hợp với dung dịch nuôi dưỡng ngoài đường tiêu hóa (1). Tuy nhiên, chú ý có tới 35% hàm lượng insulin bị hấp thụ vào nhựa túi dịch trong 24 giờ. Việc truyền dịch nuôi dưỡng ngoài đường tiêu hóa ở một tốc độ cố định có thể gây ra vấn đề là hàm lượng Insulin sẽ giảm dần theo thời gian. Vì thế hiệu chỉnh tốc độ truyền insulin có thể được yêu cầu dựa trên việc theo dõi nồng độ đường huyết của bệnh nhân (8).
Truyền liên tục **thuốc kháng H2** ở bệnh nhân phải nhập khoa ICU đã được chứng minh là có hiệu quả hơn trong việc điều chỉnh pH của dạ dày, do đó việc thêm loại thuốc này vào hỗn hợp nuôi dưỡng ngoài đường tiêu hóa được chấp thuận rộng rãi trong thực hành lâm sàng. Nói chung, nếu thuốc kháng H2 được thêm vào trong hỗn hợp nuôi dưỡng ngoài đường tiêu hóa, dung dịnh nuôi dưỡng nên được bảo quản không quá 24 giờ trong tủ lạnh trước khi sử dụng (9). Tuy nhiên, thất bại trong việc thực hiện liệu pháp kháng H2 tối ưu có thể xảy ra do sự gián đoạn tạm thời của PN và việc không có sẵn cổng tiêm tĩnh mạch. Hơn thế nữa, kê đơn trùng lắp một thuốc bảo vệ dạ dày khác có thể xảy ra do không để ý rằng đã có thuốc kháng H2 thêm vào trong dung dịch nuôi dưỡng ngoài đường tiêu hóa (10).
Việc bất cẩn và không chính xác khi thêm một thuốc vào trong hỗn hợp nuôi dưỡng ngoài đường tiêu hóa có thể gây ra những hậu quả nghiêm trọng. Trong một vài ca được lưu lại, đã có báo cáo trường hợp tình cờ trộn insulin thay vì heparin vào trong hỗn hợp nuôi dưỡng ngoài đường tiêu hóa và gây hạ đường huyết nghiêm trọng (11).
### **Ảnh hưởng do công thức PN đến tính chất dược lý của thuốc**
Các công thức PN có lipid thì kèm theo đó có cả **vitamin K** tan trong nó. Nhũ tương lipid trên thị trường được lấy từ tự nhiên có chứa vitamin K. Nếu lipid từ dầu đậu nành thì hàm lượng vitamin K cao nhất (150-300 microgam/100g). Ở những bệnh nhân dùng **Warfarin** có dùng PN cần chú ý phải tăng liều Warfarin lên cao hơn để đạt mục tiêu điều trị INR. Nếu bệnh nhân chuyển viện cần phải có sự điều soát thuốc chặt chẽ để đảm bảo không có sự thiếu sót trong dùng thuốc (12).
PN có thể làm tổn thương gan. Tổn thương này cũng có thể ảnh hưởng đến việc chuyển hóa qua gan của thuốc. Việc sử dụng PN làm tăng cường các cytokine tiền viêm và ức chế hoạt động của các enzyme cytochrome (CYP) P450 (7). Cơ chế tác dụng của PN trên hệ thống enzyme ở gan vẫn chưa được hiểu đầy đủ 13. Khi thêm glutamin vào trong hỗn hợp PN thì CYP3A và CYP2C bị ức chế, và khi thêm choline thì hoạt động CYP2E1 được tăng cường (7).
Dung dịch PN cũng có thể làm thay đổi thể tích phân bố của thuốc trong cơ thể vì nó là một dung dịch siêu phân tử. Chúng có thể tác động lên toàn bộ thể tích nội bào và thể tích dịch ngoại bào trong cơ thể. Vì vậy tất cả các thuốc có thể bị ảnh hưởng và bị thay đổi các tác dụng dược lý (7).
### **Chú ý khi dùng catheter tĩnh mạch**
Phương pháp lý tưởng để ngăn ngừa vấn đề không tương thích là sử dụng các ống thông riêng biệt cho việc dùng thuốc đường tĩnh mạch khi có thể. Nếu không có sẵn catheter riêng biệt, việc sử dụng catheter tĩnh mạch trung tâm đa nòng với một nòng được sử dụng riêng cho PN được khuyến cáo. Nếu chỉ có sẵn catheter tĩnh mạch trung tâm một nòng và việc thiết lập đường truyền ngoại vi riêng để tiêm truyền thuốc là không thích hợp, một dự định sử dụng thuốc có thông tin tương hợp/tương kỵ với PN nên được tham vấn bởi dược sĩ (2).
Các thuốc dùng đường tĩnh mạch thường được dùng bằng cách truyền tĩnh mạch nhanh ở bệnh nhân người lớn, vì thế thời gian tiếp xúc với PN và của thuốc được dùng cùng một catheter là ngắn, tuy nhiên ở bệnh nhi, việc dùng thuốc đường truyền tĩnh mạch chậm làm tăng thời gian tiếp xúc. Kéo dài thời gian tiếp xúc có thể làm tăng nguy cơ không tương thích với thuốc (7).
### **Tương hợp của thuốc giữa các loại PN**
Các hỗn hợp PN kiểu “tất cả trong một” dùng tiêm tĩnh mạch có chứa nhũ tương lipid, đây là nguyên nhân vì sao một số thuốc tương hợp với hỗn hợp loại “hai trong một” có thể không tương thích với hỗn hợp loại “tất cả trong một” (3).
Tương kỵ với hỗn hợp loại “hai trong một” dẫn đến tạo thành vón cục hoặc kết tủa màu vàng gây nên hiện tượng mờ và mất màu. Mặc khác, tương kỵ với loại “tất cả trong một” gây ra bởi tổn hại các cấu trúc của nhũ tương, kết quả tạo thành chất béo tự do và kết tủa không nhìn thấy được do hiệu ứng bao phủ của thành phần lipid.
Nhà sản xuất thuốc khác nhau thì có thể dẫn đến sản phẩm thuốc sẽ có sự khác nhau, cho dù chúng có cùng công thức về thành phần các phân tử thì sẽ có sự khác nhau về pH của thuốc và các đặc tính khác và điều này có thể liên quan đến một tác động đáng kể trong việc tương hợp hay không tương hợp. Điều này giải thích được câu hỏi vì sao khả năng tương thích của thuốc với hỗn hợp nuôi dưỡng ngoài đường tiêu hóa có thể không bao giờ được đảm bảo và việc phân tích các tài liệu có thể đánh lừa lâm sàng. 
### **Tác động của thành phần nhũ tương Lipid trong PN**
Nhờ sự hiện diện của các nhũ tương lipid trong các hỗn hợp ‘tất cả trong một’, các chất dinh dưỡng nhạy cảm với ánh sáng như retinol trong các hỗn hợp PN được bảo vệ để chống lại quá trình quang phân. Tuy nhiên, các nhũ tương lipid lại che lấp đi kết tủa được hình thành từ quá trình phá vỡ tính ổn định của hỗn hợp (3).
Tính ổn định của nhũ tương được duy trì bởi việc phòng ngừa các giọt dầu tiếp cận với nhau do sự tạo thành điện tích âm trên các giọt dầu bằng cách thêm các chất nhũ hóa vào trong nhũ thương lipid tĩnh mạch. Việc giảm pH của môi trường hay việc giảm điện tích âm trên bề mặt của các giọt dầu do việc thêm các chất điện giải vào dẫn đến các giọt dầu tụ lại và hình thành những giọt dầu lớn hơn. Do đó làm giảm độ ổn định. Giọt dầu lớn hơn làm tăng nguy cơ thuyên tắc phổi, do đó lâm sàng sử dụng nhũ tương lipid với độ ổn định kém là không an toàn. Trong trường hợp thêm một thuốc vào trong hỗn hợp nuôi dưỡng ngoài đường tiêu hóa, độ ổn định có thể bị phá với theo một cách tương tự (3).
Công thức propofol được sử dụng để an thần có chứa 10% nhũ tương lipid, nó cung cấp thêm 1,1 kcal năng lượng cho người bệnh mỗi 1 ml khi truyền. Khi propofol được dùng cho bệnh nhân có hỗ trợ dinh dưỡng đường tĩnh mạch, nó góp thêm lượng calo nhập vào hàng ngày và nên được xem xét và nên tránh việc dùng thêm calo. Hơn thế nữa, những bệnh nhân này nên được theo dõi sát ảnh hưởng tăng triglycerid máu. Điều này đã được đề xuất là nên giảm lượng lipid của hỗn hợp nuôi dưỡng tĩnh mạch dựa theo tính toán lượng lipid trong propofol được dùng (3).
Liposom amphotericin B chứa dầu phosphatydylglycerol, phức hợp lipid amphotericin B chứa dầu dimyris phosphatydylcholine và phosphatydylglycerol. Những sản phẩm này không chứa các acid béo thiết yếu vì chúng không chứa bất kì linoleic hay alpha-linoleic acid nào, nên chúng cung cấp ít calo (< 150 kcal/ngày) (3).
### **Chú ý trong việc sử dụng phương pháp truyền PN**
Có nhiều phương pháp truyền thuốc khác nhau dành cho từng trường hợp cụ thể khi thuốc tương hợp, không tương hợp hay không có thông tin gì về sự tương hợp với PN. Phương pháp ưu tiên khi có tương kỵ hoặc không có thông tin về tương hợp giữa PN và thuốc được lựa chọn theo thứ tự ưu tiên từ trên xuống dưới theo điều kiện thực tế (7):
  * Dành riêng 1 nòng trong catheter đa nòng cho PN
  * Truyền gián đoạn PN để dùng thuốc trong lúc không dùng PN


Ở bệnh nhân dùng dinh dưỡng tĩnh mạch bằng cách truyền liên tục mà không thể được thay thể bằng cách khác, đường truyền dinh dưỡng nên được tạm ngưng để dùng thuốc và tốc độ truyền dinh dưỡng cần được điều chỉnh lại để đáp ứng nhu cầu dinh dưỡng hàng ngày (7).
### **Dinh dưỡng tĩnh mạch với việc dùng thuốc an toàn**
Chìa khóa để đánh giá sử dụng thuốc ở bệnh nhân được nhận hỗ trợ dinh dưỡng tĩnh mạch được liệt kê như sau (1, 4, 5, 7):
  * Catheter tĩnh mạch đa nòng nên được thiết lập cho việc dùng thuốc ở bệnh nhân được hỗ trợ dinh dưỡng tĩnh mạch.
  * Khi thiếu vắng các thông tin về tính tương hợp, thuốc nên được dùng thông qua một catheter riêng biệt với dung dịch nuôi dưỡng tĩnh mạch. Quy tắc “Nếu nghi ngờ thì không dùng chung” được áp dụng.
  * Các thông tin về tính tương hợp có sẵn thì nên được đánh giá theo nồng độ của thuốc sử dụng và thành phần của công thức dinh dưỡng (hai trong một hay tất cả trong một).
  * Trong trường hợp sử dụng đồng thời hỗn hợp nuôi dưỡng tĩnh mạch và các thuốc bởi cùng 1 catheter, giám sát bộ truyền dịch được yêu cầu do nguy cơ phản ứng tương kỵ.
  * Tiếp nhận thông tin về độ ổn định và tương kỵ nên dựa trên những nguồn đáng tin cậy hoặc khuyến cáo từ nhà sản xuất.
  * Loại “tất cả trong một” là hỗn hợp phức tạp và mang một nguy cơ cao gặp các tương tác; vì thế nên tránh việc thêm thuốc vào trong hỗn hợp này.
  * Thuốc có cùng hoạt chất có thể có pH hoặc tính chất khác nhau do khác nhà sản xuất, vì thế ảnh hưởng của nó trên tính tương kỵ phải được xem xét.
  * Tính an toàn khi thêm hoặc truyền đồng thời một thuốc vào túi nuôi dưỡng ngoài đường tiêu hóa có thể ảnh hưởng đến sự ổn định/tương kỵ, nên được đánh giá và chấp thuận bởi dược sĩ.


## **TƯƠNG TÁC GIỮA DINH DƯỠNG ĐƯỜNG TIÊU HÓA (EN) VÀ THUỐC**
Tương tác giữa thuốc và EN có thể được xác định bằng cách xem xét tương tác giữa thuốc với các thành phần của EN. Có thể định nghĩa rộng hơn tương tác có thể chia ra làm nhiều loại khác nhau được chia ở bảng 2. Những loại tương tác này không loại trừ lẫn nhau và một loại tương tác có thể liên quan đến loại tương tác khác. Ví dụ, tương tác vật lý làm kết tủa thuốc có thể dẫn đến tương tác thay đổi sự hấp thu là tương tác dược động học. Nhiều tương tác dược động học thực tế là kết quả của những kiểu tương tác khác. Các phần tử xây dựng nên nhiều loại tương tác có thể tổ chức thành những nhóm với nhau dựa vào liệu trình EN sử dụng (bảng 3). Những nhóm này phục vụ cho cơ sở biện giải và đánh giá các tương tương thuốc-dinh dưỡng ở bệnh nhân dùng EN, tuy nhiên có sự trùng lặp đáng kể giữa các nhóm.
Không giống dinh dưỡng tĩnh mạch, việc kiểm tra tương tác khi dùng EN cho bệnh nhân không được chú ý bằng (16). Các nghiên cứu báo cáo rằng 5-43% người hành nghề thực hành súc rửa ống thông cho ăn trước và sau khi dùng thuốc cho người bệnh, 32-51% dùng thuốc riêng biệt, 44-64% pha loãng thuốc nước và 75-85% dành sự chú ý cho việc không được bẻ những viên thuốc giải phóng có kiểm soát (17). Mặt khác, người ta đã chứng minh rằng 74% người hành nghề mắc ít nhất 2 lỗi khi sử dụng thuốc qua ống thông cho ăn (18).
Trong quá trình dùng thuốc qua ống cho ăn, thuốc có thể tương tác với những thuốc khác cũng như với các sản phẩm dinh dưỡng đường ruột trong các quá trình dược động học (hấp thu, phân bố, chuyển hóa, thải trừ) và/hoặc trong các quá trình dược lực học (hoạt động hiệp đồng hay đối kháng). Để ngăn chặn các tương tác và tối thiểu ảnh hưởng của các tác dụng không mong muốn cho bệnh nhân, cơ sở của sự tương tác và các yếu tố kích hoạt của nó cần được đánh giá kỹ lưỡng.
Để giảm thiểu và ngăn chặn các tương tác giữa dinh dưỡng đường ruột và thuốc, việc thay đổi kế hoạch dùng thuốc để tránh dùng cùng lúc các thuốc, giảm số lượng thuốc và/hoặc tạm ngưng những thuốc không cần gấp là một số các biện pháp được thực hiện. Thay đổi dạng bào chế hoặc đường dùng hoặc dùng nhóm khác nhưng vẫn có cùng tác dụng điều trị cũng nên được xem xét như là một biện pháp thay thế.
Việc sử dụng cùng một ống cho dùng thuốc và dinh dưỡng đường ruột gây ra các vấn đề như sinh khả dụng, tương kỵ, biến chứng và tương tác. Tuy nhiên, biến chứng phát sinh từ việc dùng đồng thời các thuốc ở dạng bào chế và công thức thường được giải thích là do sự không dung nạp của dinh dưỡng đường ruột (19). Biến chứng thời giặp nhất được báo cáo là tiêu chảy (45%) (20).
### **Ảnh hưởng của cách dùng EN**
Khi dinh dưỡng đường ruột được dùng gián đoạn (khoảng 8-20 giờ), thường trong buổi tối, thời gian không dùng dinh dưỡng đường ruột trở thành thời gian lí tưởng cho việc dùng thuốc thông qua ống cho ăn (24).
Ở bệnh nhân được dùng dinh dưỡng đường ruột liên tục, khoảng thời gian trống có thể cần phải thiết lập trước và sau khi dùng thuốc (23). Để tránh làm giảm tình trạng dinh dưỡng của bệnh nhân, thời gian gián đoạn dinh dưỡng nên được tối thiểu. Những thuốc chỉ cần dùng 1 đến 2 liều mỗi ngày nên được ưu tiên lựa chọn. Khi dùng một liều trên ngày được ưu tiên, lượng dinh dưỡng nhập vào giảm từ 12.5-17%, và tỉ lệ giảm là 25-33% khi dùng hai lần một ngày (21).
### **Ảnh hưởng của kích cỡ và vị trí đặt sonde cho ăn**
Ống sond có đường kính to và chiều dài vừa phải hoặc ngắn có thể tối ưu trong việc giảm thiểu biến cố bất lợi khi dùng thuốc. Ống sond cỡ nhỏ (5-12 đơn vị French) (1 đơn vị French = 0.33 mm) giúp duy trì chức năng cơ thắt thực quản dưới, nhưng chúng có thể dễ dàng bị tắc với việc dùng thuốc hay thức ăn đặc, dày và xơ do đường kính nhỏ của chúng. Việc dùng thuốc hay các sản phẩm dinh dưỡng đường ruột có tính nhớt với một ống thông dạ dày lớn hơn có rủi ro tắc nghẽn thấp hơn nhiều (19, 21). Sự tắc nghẽn ở ống thông cho ăn nhỏ thường xảy ra ở 15% bệnh nhân và có xu hướng tăng cùng với số lượng thuốc được sử dụng (21).
Vị trí đặt đầu cuối của sond cho ăn cũng rất quan trọng. Phải xem xét phía đầu cuối của ống thông cho ăn khi sử dụng thuốc qua nó. Một dạng bào chế tác dụng tức thì thường phân tán và rã ra trong dạ dày, sau đó hòa tan và hấp thụ trong ruột. Đi qua dạ dày thông qua ống cho ăn ảnh hưởng đến việc hòa tan và hấp thụ của nhiều thuốc 17. Các thuốc đậm đặc và ưu trương cao có thể được dung nạp tốt hơn ở dạ dày so với ruột. Hơn thế nữa, một số thuốc cần phải có tác động đặc biệt từ trong dạ dày hoặc cần phải được đi vào trong dạ dày (16, 17, 19, 22, 23) như sau:
  * Các thuốc kháng acid (Antacids) dùng để trung hòa acid dạ dày tiết ra nên không có bất kì lợi ích nào ở ruột non do việc tiết bicarbonate từ tụy.
  * Sucrafate và bismuth tác dụng bởi việc hình thành một lớp bảo vệ ở dạ dày, nhưng chỉ có một lợi ích tối thiểu ở ruột non, vì thế chỉ dùng ở dạ dày được ưa chọn.
  * Các thuốc như ketoconazole và itraconazole cần môi trường acid để hoạt hóa, nếu không đi vào dạ dày, sinh khả dụng bị giảm, và tác dụng mong muốn của thuốc sẽ không có.
  * Các thuốc như opioid, chống trầm cảm 3 vòng, các beta – blocker, và các nitrate trải qua quá trình chuyển hóa lần đầu ở gan với tỉ lệ cao, đưa thuốc vào ruột tăng độ hấp thu của chúng và làm tăng tác dụng toàn thân.
  * Các chế phẩm sắt thường được hấp thu ở tá tràng một khi đã tan trong dạ dày; việc đưa chúng đến hỗng tràng có thể dẫn đến sinh khả dụng thấp.
  * Warfarin được hấp thụ cao ở gần ruột non, khi dùng thông qua ống thông hỗng tràng sinh khả dụng có thể bị giảm.
  * Nếu đầu xa của ống thông là ở dạ dày, dinh dưỡng có thể nên được tạm dừng 30 phút trước và sau khi dùng thuốc như ketoconazole, các penicillin và các tetracycline vì những thuốc này nên dùng khi đói. Tuy nhiên, nếu đầu xa của ống thông là ở hỗng tràng, việc tạm ngưng cho ăn là không cần thiết, chỉ cần súc rửa ống với nước cất trước và sau khi dùng thuốc là đủ.


### **Thêm một thuốc vào dung dịch dinh dưỡng đường ruột**
Rất ít nghiên cứu đã được tiến hành có liên quan đến tính tương hợp của các sản phẩm dinh dưỡng đường ruột với thuốc. Các yếu tố liên quan đến dinh dưỡng đường ruột (loại và nồng độ của protein, khoáng chất và hàm lượng chất xơ của công thức), và các đặc điểm liên quan đến thuốc (như pH, độ nhớt, độ thẩm thấu và thành phần khoáng chất trong dung dịch thuốc) được xem xét như là một yếu tố gây ra tương kỵ. Độ ổn định của dinh dưỡng đường ruột chỉ được đánh giá trong một vài nghiên cứu. Đánh giá thường bao gồm kiểm tra trực quan và thay đổi các đặc tính hóa học (như pH) hay vật lý (như độ thẩm thấu). Việc tắc nghẽn ống thông cho ăn được báo cáo trong 95% hỗn hợp có tương kỵ (24-26).
Việc thêm các thuốc vào túi dinh dưỡng đường ruột có thể gây ra tắc ống thông, thay đổi sinh khả dụng của chất dinh dưỡng hoặc thuốc, hoặc thay đổi chức năng đường tiêu hóa bởi các tương tác của thuốc-chế phẩm đường ruột. Trong một nghiên cứu, người ta đã phát hiện 23/24 tương kỵ thuốc-sản phẩm đường ruột khác nhau trộn lẫn dẫn đến tắc nghẽn (16).
Các chế phẩm có tính acid như xi-rô, khi kết hợp trong công thức của dinh dưỡng đường ruột, có thể thường xuyên dẫn đến vấn đề như tắc nghẽn hoặc ứ trệ ống thông tiêu hóa. Tính tương hợp giữa các protein thủy phân hoặc các sản phẩm dinh dưỡng đường ruột có chứa các amino acid tự do và thuốc có vẻ cao hơn nhiều so với các sản phẩm chỉ chứa protein. Chất xơ trong các sản phẩm đa số không tương hợp với thuốc (3).
Khi thiếu thông tin trong việc thêm thuốc vào túi dinh dưỡng đường ruột nguyên tắc chung là không thêm thuốc vào EN. Khi có sẵn thông tin về tương hợp hoặc độ ổn định của thuốc với sản phẩm dinh dưỡng đường ruột thì không nên đánh đồng cho tất cả các chế phẩm dinh dưỡng đường ruột khác hoặc cho thuốc khác trong cùng nhóm. Thực tế, nên nhớ rằng các điều kiện tương hợp và độ ổn định có thể thay đổi với những công thức khác nhau của cùng một thuốc (17).
Bảng 7: Tóm tắt các khuyến cáo và mức độ bằng chứng của ASPEN và trong việc dùng thuốc thông qua ống thông cho ăn
**Khuyến cáo** | **Mức độ bằng chứng**  
---|---  
Không thêm thuốc trực tiếp vào công thức dinh dưỡng đường tiêu hóa (B)  
Tránh trộn lẫn các thuốc dự định dùng thông qua ống thông cho ăn đường ruột có nguy cơ gây tương kỵ vật lý và hóa học, tắc ống, hay thay đổi đáp ứng điều trị của thuốc  
Mỗi thuốc nên được dùng riêng lẻ thông qua một đường phù hợp. Các dạng bào chế lỏng nên được dùng khi có sẵn và nếu phù hợp. Chỉ dạng bào chế giải phóng tức thì rắn có thể thay thế. Nghiền nén đơn giản cho tới khi thành bột mịn sau đó trộn với nước cất. Các viên nang cứng cần dùng sau khi mở nang và trộn chúng với nước cất.  
Trước khi dùng thuốc, dừng cho ăn và xả tráng ống thông với ít nhất 15mL nước. Pha loãng thuốc rắn hay lỏng một cách thích hợp và dùng thuốc bằng xi-lanh sạch (kích cỡ ≥ 30ml). Bơm nước cất lần nữa với ít nhất 15 mL và xem xét tình trạng thể tích dịch của bệnh nhân. Lặp lại quá trình này cho một thuốc khác. Cuối cùng, xả ống thông lần nữa với ít nhất 15 mL nước. Lượng pha loãng hay bơm nên giảm ở bệnh nhi hoặc những bệnh nhân hạn chế dịch.  
Khởi động lại việc cho ăn kịp thời để tránh làm ảnh hưởng đến tình trạng dinh dưỡng. Chỉ tạm hoãn việc cho ăn khoảng 30 phút hay hơn trước khi dùng thuốc nếu yêu cầu dùng cách biệt với thức ăn được chỉ định để tránh thay đổi sinh khả dụng của thuốc.  
Chỉ sử dụng xi-lanh có nhãn cho ăn/đường ruột với từ “chỉ dành dành đường miệng” để đong và dùng thuốc qua ống thông cho ăn đường ruột.  
Tham vấn một dược sĩ chuyên nhi hay người lớn cho những bệnh nhân dùng thuốc đồng thời với dinh dưỡng đường ruột.  
## **Kết luận**
Khi thực hành dinh dưỡng cho bệnh nhân cần đánh giá sử dụng thuốc dùng đồng thời để xác định các vấn đề nếu có và đưa ra hướng giải quyết phù hợp. Mục tiêu luôn luôn là vì sự an toàn người bệnh. Dinh dưỡng đường tiêu hoá cũng quan trọng như dinh dưỡng đường tĩnh mạch, không nên xem nhẹ và không đánh giá khi dùng thuốc vì có thể lợi bất cập hại có khi nặng hơn cả đường tĩnh mạch. Việc sử dụng thuốc đường tiêu hoá dẫn đến việc nghiền bẻ các dạng thuốc, trong đó có các dạng thuốc khi nghiền bẻ sẽ dẫn tới độc tính nặng và đã được liệt kê là cấm nghiền bẻ. Vì thế, khi cần dùng chú ý việc đổi sang dạng bào chế khác phù hợp.
Kê toa dây chuyền cần hạn chế, nếu có sự tương tác bất lợi cần loại bỏ hoặc trì hoãn những thuốc chưa thực sự cần thiết cho bệnh nhân và có thể dùng sau khi kết thúc điều trị bằng những thuốc cần thiết.
Nên tránh việc thêm thuốc và dịch truyền tĩnh mạch hay tiêu hoá thường quy mà không có sự cân nhắc, đánh giá sử dụng thuốc trước khi quyết định dùng. Tổ dinh dưỡng ở các bệnh viện là đơn vị có chức năng nhiệm vụ phù hợp để quản lí việc này. Trong đó, dược sĩ là một thành phần không thể thiếu của tổ. Khi có sử dụng đồng thời hoặc trộn chung thuốc và dinh dưỡng ở bất kì trường hợp nào, đặc biệt là khi có tương kỵ hoặc không có thông tin thì việc tham vấn ý kiến dược lâm sàng là tối cần thiết.
**Bệnh viện Nguyễn Tri Phương** - Bệnh viện Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [TƯƠNG TÁC GIỮA DINH DƯỠNG NGOÀI ĐƯỜNG TIÊU HOÁ VỚI THUỐC](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/nhung-tuong-tac-voi-thuoc-can-luu-y-trong-thuc-hanh-dinh-duong-tren-lam-sang#tng-tc-gia-dinh-dng-ngoi-ng-tiu-ho-vi-thuc)
  * [Ảnh hưởng do công thức PN đến tính chất dược lý của thuốc](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/nhung-tuong-tac-voi-thuoc-can-luu-y-trong-thuc-hanh-dinh-duong-tren-lam-sang#nh-hng-do-cng-thc-pn-n-tnh-cht-dc-l-ca-thuc)
  * [Chú ý khi dùng catheter tĩnh mạch](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/nhung-tuong-tac-voi-thuoc-can-luu-y-trong-thuc-hanh-dinh-duong-tren-lam-sang#ch-khi-dng-catheter-tnh-mch)
  * [Tương hợp của thuốc giữa các loại PN](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/nhung-tuong-tac-voi-thuoc-can-luu-y-trong-thuc-hanh-dinh-duong-tren-lam-sang#tng-hp-ca-thuc-gia-cc-loi-pn)
  * [Tác động của thành phần nhũ tương Lipid trong PN](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/nhung-tuong-tac-voi-thuoc-can-luu-y-trong-thuc-hanh-dinh-duong-tren-lam-sang#tc-ng-ca-thnh-phn-nh-tng-lipid-trong-pn)
  * [Chú ý trong việc sử dụng phương pháp truyền PN](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/nhung-tuong-tac-voi-thuoc-can-luu-y-trong-thuc-hanh-dinh-duong-tren-lam-sang#ch-trong-vic-s-dng-phng-php-truyn-pn)
  * [Dinh dưỡng tĩnh mạch với việc dùng thuốc an toàn](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/nhung-tuong-tac-voi-thuoc-can-luu-y-trong-thuc-hanh-dinh-duong-tren-lam-sang#dinh-dng-tnh-mch-vi-vic-dng-thuc-an-ton)
  * [TƯƠNG TÁC GIỮA DINH DƯỠNG ĐƯỜNG TIÊU HÓA (EN) VÀ THUỐC](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/nhung-tuong-tac-voi-thuoc-can-luu-y-trong-thuc-hanh-dinh-duong-tren-lam-sang#tng-tc-gia-dinh-dng-ng-tiu-ha-en-v-thuc)
  * [Ảnh hưởng của cách dùng EN](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/nhung-tuong-tac-voi-thuoc-can-luu-y-trong-thuc-hanh-dinh-duong-tren-lam-sang#nh-hng-ca-cch-dng-en)
  * [Ảnh hưởng của kích cỡ và vị trí đặt sonde cho ăn](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/nhung-tuong-tac-voi-thuoc-can-luu-y-trong-thuc-hanh-dinh-duong-tren-lam-sang#nh-hng-ca-kch-c-v-v-tr-t-sonde-cho-n)
  * [Thêm một thuốc vào dung dịch dinh dưỡng đường ruột](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/nhung-tuong-tac-voi-thuoc-can-luu-y-trong-thuc-hanh-dinh-duong-tren-lam-sang#thm-mt-thuc-vo-dung-dch-dinh-dng-ng-rut)



## ️ Các câu hỏi thường gặp về Tazorac

  * [Điều gì làm nên sự khác biệt giữa hai dạng Tazorac: cream và gel?](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/cac-cau-hoi-thuong-gap-ve-tazorac#iu-g-lm-nn-s-khc-bit-gia-hai-dng-tazorac-cream-v-gel)
  * [Tazorac là một steroid?](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/cac-cau-hoi-thuong-gap-ve-tazorac#tazorac-l-mt-steroid)
  * [Tại sao tôi cần bảo vệ bản thân khỏi ánh nắng mặt trời trong khi sử dụng Tazorac?](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/cac-cau-hoi-thuong-gap-ve-tazorac#ti-sao-ti-cn-bo-v-bn-thn-khi-nh-nng-mt-tri-trong-khi-s-dng-tazorac)
  * [Tôi có thể sử dụng Tazorac cho bệnh chàm?](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/cac-cau-hoi-thuong-gap-ve-tazorac#ti-c-th-s-dng-tazorac-cho-bnh-chm)
  * [Các lựa chọn thay thế cho Tazorac](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/cac-cau-hoi-thuong-gap-ve-tazorac#cc-la-chn-thay-th-cho-tazorac)
  * [Lựa chọn thay thế cho mụn trứng cá](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/cac-cau-hoi-thuong-gap-ve-tazorac#la-chn-thay-th-cho-mn-trng-c)
  * [Các lựa chọn thay thế cho bệnh vẩy nến mảng bám](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/cac-cau-hoi-thuong-gap-ve-tazorac#cc-la-chn-thay-th-cho-bnh-vy-nn-mng-bm)
  * [Tazorac và thai kỳ](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/cac-cau-hoi-thuong-gap-ve-tazorac#tazorac-v-thai-k)
  * [Tazorac và ngừa thai](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/cac-cau-hoi-thuong-gap-ve-tazorac#tazorac-v-nga-thai)
  * [Tazorac và cho con bú](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/cac-cau-hoi-thuong-gap-ve-tazorac#tazorac-v-cho-con-b)
  * [Tương tác Tazorac](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/cac-cau-hoi-thuong-gap-ve-tazorac#tng-tc-tazorac)
  * [Tazorac và các loại thuốc khác](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/cac-cau-hoi-thuong-gap-ve-tazorac#tazorac-v-cc-loi-thuc-khc)
  * [Tazorac và thuốc làm tăng độ nhạy cảm với ánh sáng mặt trời](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/cac-cau-hoi-thuong-gap-ve-tazorac#tazorac-v-thuc-lm-tng-nhy-cm-vi-nh-sng-mt-tri)
  * [Tazorac và các loại thuốc gây khô da](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/cac-cau-hoi-thuong-gap-ve-tazorac#tazorac-v-cc-loi-thuc-gy-kh-da)
  * [Tazorac và các loại thảo mộc và thực phẩm bổ sung](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/cac-cau-hoi-thuong-gap-ve-tazorac#tazorac-v-cc-loi-tho-mc-v-thc-phm-b-sung)
  * [Tazorac và thực phẩm](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/cac-cau-hoi-thuong-gap-ve-tazorac#tazorac-v-thc-phm)
  * [Tazorac và rượu](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/cac-cau-hoi-thuong-gap-ve-tazorac#tazorac-v-ru)


## **Điều gì làm nên sự khác biệt giữa hai dạng Tazorac: cream và gel?**
Gel Tazorac là một loại gel nền nước trong suốt. Kem Tazorac là một loại kem nền dầu, trắng. Gel nhẹ hơn và dễ dàng hấp thụ hơn so với kem. Do đó, kích ứng da phổ biến hơn một chút so với gel Tazorac. Kem có thể thích hợp hơn để điều trị cho da khô hoặc nhạy cảm.
Để tìm ra dạng Tazorac nào có thể phù hợp với bạn, hãy nói chuyện với bác sĩ của bạn.
## **Tazorac là một steroid?**
Không, Tazorac không phải là một steroid. Nó là một loại thuốc gọi là retinoid, có liên quan đến vitamin A.
Steroid là thuốc làm giảm viêm (sưng và đỏ). Chúng còn được gọi là corticosteroid. Corticosteroid tại chỗ được bôi lên da và có ở dạng kem, gel và thuốc mỡ. Những loại thuốc này thường được sử dụng để điều trị một loại bệnh da gọi là bệnh chàm, cũng như dị ứng da. Nhưng corticosteroid tại chỗ đôi khi cũng được sử dụng cho bệnh vẩy nến mảng bám.
Ví dụ về corticosteroid tại chỗ bao gồm:
  * hydrocortison (Ala-Cort, Locoid)
  * betamethasone (Diprolene, Beta-Val, Derm.us)
  * clobetasol (Cormax, Clobex, Embeline)


Tazorac cũng làm giảm viêm, nhưng nó hoạt động theo một cách khác so với steroid. Tác động chính của Tazorac là làm chậm quá trình sản xuất tế bào da. Tazorac không liên quan đến các tác dụng phụ tương tự như steroid, chẳng hạn như làm mỏng da.
## **Tại sao tôi cần bảo vệ bản thân khỏi ánh nắng mặt trời trong khi sử dụng Tazorac?**
Tazorac có thể làm cho làn da của bạn nhạy cảm hơn với ánh sáng mặt trời. Điều này có nghĩa là bạn có khả năng bị cháy nắng khi bạn sử dụng thuốc. Vì vậy, đây là điều quan trọng để bảo vệ làn da của bạn khỏi ánh nắng mặt trời để tránh bị cháy nắng nghiêm trọng. Đội mũ có vành và quần áo che phủ làn da của bạn. Ngoài ra, thoa kem chống nắng cho vùng da mà không được che bởi quần áo.
## **Tôi có thể sử dụng Tazorac cho bệnh chàm?**
Không, bạn không nên sử dụng Tazorac cho tình trạng da được gọi là bệnh chàm. Tazorac có thể gây kích ứng da nghiêm trọng nếu bạn áp dụng nó cho bệnh chàm.
Nếu bạn bị bệnh chàm, hãy nói chuyện với bác sĩ về các cách để điều trị nó.
## **Các lựa chọn thay thế cho Tazorac**
Tazorac là một loại thuốc retinoid tại chỗ (bôi lên da) để điều trị mụn trứng cá và bệnh vẩy nến mảng bám.
Các loại thuốc khác có thể điều trị tình trạng của bạn. Một số có thể phù hợp với bạn hơn những người khác. Nếu bạn quan tâm đến việc tìm kiếm một sự thay thế cho Tazorac, hãy nói chuyện với bác sĩ của bạn. Họ có thể cho bạn biết về các loại thuốc khác có thể có hiệu quả tốt cho bạn.
## **Lựa chọn thay thế cho mụn trứng cá**
Ví dụ về các loại thuốc khác có thể được sử dụng để điều trị mụn trứng cá bao gồm:
  * dapsone tại chỗ (Aczone)
  * retinoids tại chỗ khác, chẳng hạn như:
    * tazarotene (Fabior, Arazlo)
    * tretinoin (Avita, Renova, Retin-A, Altreno, Atralin)
    * adapalene (Differin)
    * adapalene / benzoyl peroxide (Epiduo, Epiduo Forte)
  * kháng sinh tại chỗ, chẳng hạn như:
    * erythromycin (Erygel)
    * erythromycin / benzoyl peroxide (Benzamycin)
    * clindamycin (Evoclin, Cleocin T, Clindagel)
    * clindamycin / tretinoin (Veltin, Ziana)
    * clindamycin / benzoyl peroxide (Acanya, Benzaclin, Duac, Onexton)
  * thuốc kháng sinh uống, như:
    * Doxycycline (Vibramycin, Doryx, Acticlate)
    * Tetracycline
    * Minocycline (Solodyn, Minolira, Ximino, những người khác)
  * thuốc tránh thai cho phụ nữ, như:
    * Drospirenone / ethinyl estradiol / levomeoliate canxi (Beyaz)
    * Drospirenone / ethinyl estradiol (Yaz)
    * Ethinyl estradiol / norgestimate (Ortho Tri-Cyclen)


## **Các lựa chọn thay thế cho bệnh vẩy nến mảng bám**
Ví dụ về các loại thuốc khác có thể được sử dụng để điều trị bệnh vẩy nến mảng bám bao gồm:
  * Than đá (Psoriatar, Scytera, Cutar, Eucutasol)
  * Corticosteroid tại chỗ, chẳng hạn như:
    * Clobetasol (Olux, Clobex)
    * Betamethasone (Diprolene)
    * Fluocinolone (Synalar)
    * Halobetasol / tazarotene (Duobrii)
  * Chất tương tự vitamin D tại chỗ (dạng vitamin D nhân tạo), như:
  * Calcitriol (Vectical)
  * Calcipotriene (Dovonex, Sorilux)
  * Calcipotriene / betamethasone (Enstilar, Taclonex)


## **Tazorac và thai kỳ**
Tazorac có thể gây dị tật bẩm sinh nếu được sử dụng trong thai kỳ. Không sử dụng Tazorac nếu bạn mang thai hoặc nghĩ rằng bạn có thể mang thai.
Tazorac chưa được nghiên cứu ở phụ nữ có thai. Tuy nhiên, thuốc gọi là retinoids được biết là gây hại cho thai nhi khi sử dụng trong thai kỳ. Tazorac là một loại retinoid. Các nghiên cứu trên động vật cho thấy tazarotene (hoạt chất trong Tazorac) gây ra tác hại cho thai nhi khi nó được sử dụng ở phụ nữ có thai.
Để chắc chắn rằng bạn không mang thai, bác sĩ sẽ muốn bạn thử thai trong khung thời gian 2 tuần trước khi bạn bắt đầu sử dụng Tazorac.
Nếu bạn sử dụng Tazorac và nghĩ rằng bạn có thể có thai, hãy báo cho bác sĩ ngay lập tức.
## **Tazorac và ngừa thai**
Tazorac có thể gây dị tật bẩm sinh nếu được sử dụng trong thai kỳ. Nếu bạn có hoạt động tình dục và bạn hoặc bạn tình của bạn có thể mang thai, bạn nên sử dụng biện pháp tránh thai hiệu quả trong khi sử dụng Tazorac. Tham khảo ý kiến bác sĩ về các phương pháp ngừa thai phù hợp.
Để biết thêm thông tin về việc sử dụng Tazorac khi mang thai, hãy xem phần “Tazorac và thai kỳ” ở trên.
## **Tazorac và cho con bú**
Vẫn chưa biết được liệu Tazorac có đi vào sữa mẹ hay không. Nếu bạn cho con bú hoặc dự định cho con bú, hãy nói chuyện với bác sĩ về những rủi ro và lợi ích của việc sử dụng Tazorac.
### **Tương tác Tazorac**
Tazorac có thể tương tác với một số loại thuốc khác. Các tương tác khác nhau có thể gây ra hiệu ứng khác nhau. Ví dụ, một số tương tác có thể can thiệp vào việc thuốc hoạt động tốt như thế nào. Các tương tác khác có thể làm tăng tác dụng phụ hoặc làm cho chúng nghiêm trọng hơn.
## **Tazorac và các loại thuốc khác**
Dưới đây là một số loại thuốc có thể tương tác với Tazorac. Phần này không chứa tất cả các loại thuốc có thể tương tác với Tazorac.
Trước khi sử dụng Tazorac, hãy nói chuyện với bác sĩ và dược sĩ của bạn. Nói với họ về tất cả các loại thuốc kê đơn, không kê đơn và các loại thuốc khác mà bạn dùng. Cũng nói với họ về bất kỳ vitamin, thảo dược và chất bổ sung bạn sử dụng. Chia sẻ thông tin này có thể giúp bạn tránh các tương tác tiềm tàng.
Nếu bạn có thắc mắc về tương tác thuốc có thể ảnh hưởng đến bạn, hãy hỏi bác sĩ hoặc dược sĩ của bạn.
## **Tazorac và thuốc làm tăng độ nhạy cảm với ánh sáng mặt trời**
Tazorac có thể làm cho làn da của bạn nhạy cảm hơn với ánh nắng mặt trời. Một số loại thuốc khác cũng có thể có tác dụng này. Nếu bạn sử dụng Tazorac với một trong số chúng, bạn có thể có nguy cơ bị cháy nắng nghiêm trọng hơn.
Ví dụ về các loại thuốc có thể làm tăng nguy cơ bị cháy nắng với Tazorac bao gồm:
  * thuốc lợi tiểu thiazide, chẳng hạn như bendroflumethiazide (Corzide)
  * kháng sinh tetracycline, như doxycycline (Vibramycin, Acticlate, Doryx) và minocycline (Solodyn, Minolira, Ximino, các loại khác)
  * kháng sinh fluoroquinolone, như ciprofloxacin (Cipro)
  * kháng sinh sulfonamid, như sulfamethoxazole (Septra, Bactrim)
  * phenothiazin, như promethazine (Promethegan) hoặc prochlorperazine (Procomp)


Nếu bạn sử dụng một trong những loại thuốc này với Tazorac, hãy cẩn thận hơn để bảo vệ làn da của bạn khỏi ánh sáng mặt trời. Nếu bạn cần ra ngoài nắng, hãy đội mũ và quần áo che da. Và thoa kem chống nắng cho làn da mà không che phủ quần áo.
## **Tazorac và các loại thuốc gây khô da**
Tazorac có thể gây kích ứng da và khô da. Nếu bạn sử dụng Tazorac với các loại thuốc khác có tác dụng này, da của bạn có thể trở nên rất khô và bị kích ứng.
Ví dụ về các loại thuốc có thể làm tăng nguy cơ kích ứng và khô da với Tazorac bao gồm:
  * Benzoyl peroxide;
  * Than đá (Psoriatar, Scytera, Cutar, Eucutasol);
  * Axit salicylic;
  * Calcipotriene (Dovonex, Sorilux).


Nếu bạn sử dụng Tazorac, hãy nói chuyện với bác sĩ trước khi thử bất kỳ loại thuốc nào có chứa các thành phần này.
## **Tazorac và các loại thảo mộc và thực phẩm bổ sung**
Chưa có bất kỳ loại thảo mộc hoặc chất bổ sung nào được báo cáo cụ thể về tương tác với Tazorac. Tuy nhiên, bạn vẫn nên kiểm tra với bác sĩ hoặc dược sĩ trước khi sử dụng bất kỳ sản phẩm nào trong số này với Tazorac.
## **Tazorac và thực phẩm**
Chưa có bất kỳ thực phẩm được báo cáo cụ thể về tương tác với Tazorac. Nếu bạn có bất kỳ câu hỏi nào về việc ăn một số loại thực phẩm với Tazorac, hãy nói chuyện với bác sĩ của bạn.
## **Tazorac và rượu**
Tương tác giữa Tazorac và rượu vẫn chưa được biết đến.
Tuy nhiên, uống rượu có thể kích hoạt bệnh vẩy nến ở một số người. Theo Học viện Da liễu Hoa Kỳ, điều trị bệnh vẩy nến có thể kém hiệu quả hơn nếu bạn thường xuyên uống rượu.
Uống rượu có thể đóng một phần trong việc kích hoạt mụn trứng cá. Đồ uống có cồn thường có lượng đường cao và có thể khiến lượng đường trong máu của bạn tăng nhanh. Tăng đột biến lượng đường trong máu có thể dẫn đến:
  * Viêm (sưng và đỏ) trên khắp cơ thể;
  * Tăng sản xuất bã nhờn (dầu) trong da;
  * Nồng độ cao của hormone testosterone.


Tất cả những yếu tố này có thể gây ra và làm xấu đi tình trạng mụn trứng cá.
Một số nghiên cứu đã phát hiện ra rằng mụn trứng cá cải thiện ở những người tuân theo chế độ ăn có chỉ số đường huyết thấp. Loại chế độ ăn kiêng này liên quan đến việc loại bỏ các loại thực phẩm và đồ uống khiến lượng đường trong máu của bạn tăng nhanh, bao gồm cả đồ uống có đường.
Nếu bạn uống rượu, hãy nói chuyện với bác sĩ về cách điều này có thể ảnh hưởng đến làn da của bạn. Tránh uống rượu nếu nó làm cho tình trạng da của bạn bùng lên.
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh
[youtube.com/bvntp](http://youtube.com/bvntp)
  * [Điều gì làm nên sự khác biệt giữa hai dạng Tazorac: cream và gel?](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/cac-cau-hoi-thuong-gap-ve-tazorac#iu-g-lm-nn-s-khc-bit-gia-hai-dng-tazorac-cream-v-gel)
  * [Tazorac là một steroid?](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/cac-cau-hoi-thuong-gap-ve-tazorac#tazorac-l-mt-steroid)
  * [Tại sao tôi cần bảo vệ bản thân khỏi ánh nắng mặt trời trong khi sử dụng Tazorac?](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/cac-cau-hoi-thuong-gap-ve-tazorac#ti-sao-ti-cn-bo-v-bn-thn-khi-nh-nng-mt-tri-trong-khi-s-dng-tazorac)
  * [Tôi có thể sử dụng Tazorac cho bệnh chàm?](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/cac-cau-hoi-thuong-gap-ve-tazorac#ti-c-th-s-dng-tazorac-cho-bnh-chm)
  * [Các lựa chọn thay thế cho Tazorac](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/cac-cau-hoi-thuong-gap-ve-tazorac#cc-la-chn-thay-th-cho-tazorac)
  * [Lựa chọn thay thế cho mụn trứng cá](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/cac-cau-hoi-thuong-gap-ve-tazorac#la-chn-thay-th-cho-mn-trng-c)
  * [Các lựa chọn thay thế cho bệnh vẩy nến mảng bám](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/cac-cau-hoi-thuong-gap-ve-tazorac#cc-la-chn-thay-th-cho-bnh-vy-nn-mng-bm)
  * [Tazorac và thai kỳ](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/cac-cau-hoi-thuong-gap-ve-tazorac#tazorac-v-thai-k)
  * [Tazorac và ngừa thai](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/cac-cau-hoi-thuong-gap-ve-tazorac#tazorac-v-nga-thai)
  * [Tazorac và cho con bú](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/cac-cau-hoi-thuong-gap-ve-tazorac#tazorac-v-cho-con-b)
  * [Tương tác Tazorac](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/cac-cau-hoi-thuong-gap-ve-tazorac#tng-tc-tazorac)
  * [Tazorac và các loại thuốc khác](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/cac-cau-hoi-thuong-gap-ve-tazorac#tazorac-v-cc-loi-thuc-khc)
  * [Tazorac và thuốc làm tăng độ nhạy cảm với ánh sáng mặt trời](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/cac-cau-hoi-thuong-gap-ve-tazorac#tazorac-v-thuc-lm-tng-nhy-cm-vi-nh-sng-mt-tri)
  * [Tazorac và các loại thuốc gây khô da](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/cac-cau-hoi-thuong-gap-ve-tazorac#tazorac-v-cc-loi-thuc-gy-kh-da)
  * [Tazorac và các loại thảo mộc và thực phẩm bổ sung](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/cac-cau-hoi-thuong-gap-ve-tazorac#tazorac-v-cc-loi-tho-mc-v-thc-phm-b-sung)
  * [Tazorac và thực phẩm](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/cac-cau-hoi-thuong-gap-ve-tazorac#tazorac-v-thc-phm)
  * [Tazorac và rượu](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/cac-cau-hoi-thuong-gap-ve-tazorac#tazorac-v-ru)



## Các thời điểm sử dụng thuốc

**Bệnh viện Nguyễn Tri Phương** - Bệnh viện Đa khoa Hạng I Thành phố Hồ Chí Minh
  * 468 Nguyễn Trãi, Phường 8, Quận 5, Tp. Hồ Chí Minh
  * Hotline: (84-028) 39234332
  * Mạng xã hội **Facebook** :[**Bệnh viện Nguyễn Tri Phương**](https://www.facebook.com/BVNTP/)
  * Đăng ký (Subcribe) kênh **Youtube** : [https://youtube.com/bvntp](https://youtube.com/bvntp?fbclid=IwAR3q_UvPI4OZAebT1uQGPKKwk3RmCzAFLkBJm9lb7EwIz0EHtgiLhKM5bxU)
  * Quan tâm Zalo Official: [zalo.me/1744466261097093886](https://zalo.me/1744466261097093886?fbclid=IwAR3E-fLqdh-x1cYSvuDY6E5Eyxfjo5ZSs4p0hDWAyBG-ROlTkxXkXvdEWAY)



## ️ Endorphin: Tác dụng và cách nào để tăng nồng độ endorphin

  * [Endorphin là gì?](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/endorphin-tac-dung-va-cach-nao-de-tang-nong-do-endorphin#endorphin-l-g)
  * [Tăng cường mức độ endorphin](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/endorphin-tac-dung-va-cach-nao-de-tang-nong-do-endorphin#tng-cng-mc-endorphin)
  * [Tập thể dục thường xuyên](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/endorphin-tac-dung-va-cach-nao-de-tang-nong-do-endorphin#tp-th-dc-thng-xuyn)
  * [Endorphin thấp và các tình trạng sức khỏe ](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/endorphin-tac-dung-va-cach-nao-de-tang-nong-do-endorphin#endorphin-thp-v-cc-tnh-trng-sc-khe)
  * [Đau đầu mạn tính](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/endorphin-tac-dung-va-cach-nao-de-tang-nong-do-endorphin#au-u-mn-tnh)


## **Endorphin là gì?**
Endorphin là hóa chất được cơ thể sản xuất để giảm căng thẳng và cơn đau. Chúng có cơ chế hoạt động tương tự như opioids.
Opioids giúp giảm đau và có thể tạo cảm giác hưng phấn. Loại thuốc này đôi khi được dùng để sử dụng trong thời gian ngắn sau phẫu thuật hoặc để giảm đau.
Vào những năm 1980, các nhà khoa học đã nghiên cứu cách thức và lý do opioids hoạt động. Họ phát hiện ra rằng cơ thể có các thụ thể đặc biệt liên kết với opioid để chặn tín hiệu đau. Các nhà khoa học sau đó nhận ra rằng một số hóa chất trong cơ thể hoạt động tương tự như thuốc opioid tự nhiên có khả năng liên kết với các thụ thể tương tự. Những hóa chất này là endorphin.
Cái tên endorphin xuất phát từ “endogenous” có nghĩa là từ cơ thể và “morphine” - một loại thuốc giảm đau opioid. Một số loại thuốc opioid phổ biến bao gồm:
  * Oxycodone;
  * Hydrocodone;
  * Codein;
  * Morphin;
  * Fentanyl.


Một số loại thuốc bị cấm chẳng hạn như **heroin** cũng là opioid. Cả thuốc opioid hợp pháp và bất hợp pháp đều có nguy cơ gây nghiện, có nguy cơ tử vong khi sử dụng quá liều.
Viện quốc gia về lạm dụng ma túy nói rằng 90 người chết mỗi ngày tại Hoa Kỳ do dùng quá liều opioid. Nhiều trong số này là hậu quả của quá liều hoặc lạm dụng opioids theo toa.
Endorphin tự nhiên hoạt động tương tự như thuốc giảm đau opioid, nhưng tác dụng của chúng có thể không nhiều như thuốc. Tuy nhiên, endorphin có thể vừa tạo ra cảm giác hưng phấn vừa tốt cho sức khỏe, an toàn, không có nguy cơ gây nghiện và quá liều.
## **Tăng cường mức độ endorphin**
Các hoạt động sau đây có thể giúp tăng endorphin một cách tự nhiên. Tuy nhiên, mức độ endorphin ở mỗi người là không giống nhau, do đó kết quả cũng sẽ khác nhau.
### **Tập thể dục thường xuyên**
Trong nhiều năm, các nhà nghiên cứu cho rằng endorphin gây ra cảm giác hưng phấn sau khi hoạt động thể chất. Tuy nhiên, việc đo mức độ endorphin ở người chưa thể thực hiện cho đến năm 2008. Các nhà nghiên cứu đã sử dụng chụp **cắt lớp phát xạ positron** (PET) để khảo sát bộ não của vận động viên trước và sau khi tập luyện. Họ tìm thấy sự gia tăng giải phóng endorphin sau khi tập thể dục.
Tập thể dục làm hưng phấn và tăng endorphin, một số bác sĩ khuyến nghị bệnh nhân thể dục thường xuyên như một phương pháp điều trị trầm cảm và tình trạng lo âu mức độ nhẹ đến trung bình.
Tập thể dục có thể được kết hợp với các phương pháp điều trị như thuốc hoặc liệu pháp điều trị khác hoặc được sử dụng như một phương pháp độc lập. Một nghiên cứu cho biết rằng tập thể dục có thể cải thiện một số triệu chứng có hiệu quả như thuốc chống trầm cảm.
### **Cho đi**
Tình nguyện, quyên góp và giúp đỡ người khác cũng có thể khiến một người cảm thấy tốt hơn. Các nhà nghiên cứu tại Viện Y tế Quốc gia nhận thấy rằng những người quyên góp từ thiện có thể giúp gia tăng mức độ endorphin.
### **Yoga và thiền**
Thiền và yoga được biết đến với tác dụng giảm căng thẳng và thư giãn. Điều này có thể một phần do sự gia tăng mức độ của endorphin.
### **Thức ăn cay**
Những người thưởng thức đồ ăn cay có thể thấy tăng sự hưng phấn từ các món ăn yêu thích của họ. Một số nghiên cứu cho thấy các thành phần trong ớt cay và các loại thực phẩm tương tự có thể gây ra cảm giác đau trong miệng, điều này thúc đẩy sự gia tăng endorphin.
### **Chocolate đen**
Nghiên cứu từ năm 2013 cho thấy rằng ăn chocolate đen có thể tăng mức endorphin. Bột ca cao và chocolate chứa flavonoid có lợi cho não. Một đánh giá năm 2017 cho thấy ăn chocolate có thể giúp tăng cường endorphin. Tuy nhiên, nhiều sản phẩm chocolate thương mại chỉ chứa một lượng nhỏ ca cao thật và thường chứa nhiều đường và chất béo.
Những người muốn sử dụng chocolate để cải thiện mức độ endorphin và tâm trạng nên tìm các sản phẩm có chứa ít nhất 70% ca cao và dùng chocolate với mức độ phù hợp.
### 
Rất nhiều nghiên cứu đã đề cập về lợi ích sức khỏe của tiếng cười trong đó cười làm tăng nồng độ endorphin.
## **Endorphin thấp và các tình trạng sức khỏe**
Khi nồng độ endorphin quá thấp, sức khỏe có thể bị ảnh hưởng tiêu cực. Một số nghiên cứu đã chỉ ra mối liên hệ có thể có giữa các tình trạng sức khỏe sau đây và mức endorphin thấp:
### **Phiền muộn**
Khi không có đủ endorphin, một người dễ bị rơi vào trạng thái trầm cảm. Một bài báo trên Tạp chí Tâm thần học Hoa Kỳ thảo luận về việc sử dụng lâu dài các phương pháp điều trị opioid cho trầm cảm, đặc biệt trong trường hợp các phương pháp điều trị khác không hiệu quả.
### **Đau cơ xơ hóa**
Các triệu chứng phổ biến của đau cơ xơ hóa bao gồm:
  * Các cơn đau dai dẳng ở khắp cơ thể;
  * Đau khi chạm vào;
  * Cơ bắp căng cứng;
  * Mệt mỏi, uể oải;
  * Rối loạn giấc ngủ.


Những người bị đau cơ xơ hóa có thể có mức endorphin bình thường. Tuy nhiên, một nghiên cứu cho thấy những người bị đau cơ xơ hóa có mức độ endorphin thấp hơn so với những người không mắc bệnh này, ngay cả trước và sau khi tập thể dục.
Một nghiên cứu khác cho thấy sự gia tăng mức endorphin có liên quan đến giảm đau ở những người bị đau cơ xơ hóa. Người bị đau cơ xơ hóa có thể nên thực hiện một số hoạt động nhất định để tăng cường nồng độ endorphin như tập thể dục, gặp gỡ với người khác và các hoạt động giảm căng thẳng như thiền hoặc yoga. Ngoài ra, có thể kết hợp với thuốc kê đơn để kiểm soát các triệu chứng.
### **Đau đầu mạn tính**
Một nguyên nhân có thể gây đau đầu liên tục là mức endorphin không bình thường. Qua các nghiên cứu cho thấy sự mất cân bằng endorphin góp phần gây nên trầm cảm cũng xuất hiện ở những người bị đau đầu mạn tính.
## **Tóm tắt**
Hiện các nhà khoa học vẫn đang tìm hiểu thêm về tác động của endorphin đối với cơ thể con người Những người có triệu chứng trầm cảm, đau cơ xơ hóa hoặc đau đầu mãn tính nên trao đổi với bác sĩ về mức độ endorphin và cách có thể tăng nồng độ của chúng kết hợp với các phương pháp điều trị khác.
Mặc dù endorphin không phải là thuốc chữa bách bệnh hay giúp đảm bảo sức khỏe tốt, tuy nhiên việc tăng cường nồng độ endorphin có thể là cách hiệu quả để tăng sức khỏe toàn diện.
Tập thể dục thường xuyên, giảm căng thẳng và giúp đỡ những người khác là những hoạt động bổ ích giúp một người có cuộc sống khỏe mạnh và hạnh phúc hơn.
Có thể bạn quan tâm: [**Thật bất ngờ - Thuốc giảm đau nhóm opiods có thể làm tăng nguy cơ đau mãn tính**](https://bvnguyentriphuong.com.vn/khoa-duoc/that-bat-ngo-thuoc-giam-dau-nhom-opioids-co-the-lam-tang-nguy-co-dau-man-tinh)
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh
[youtube.com/bvntp](http://youtube.com/bvntp)
  * [Endorphin là gì?](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/endorphin-tac-dung-va-cach-nao-de-tang-nong-do-endorphin#endorphin-l-g)
  * [Tăng cường mức độ endorphin](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/endorphin-tac-dung-va-cach-nao-de-tang-nong-do-endorphin#tng-cng-mc-endorphin)
  * [Tập thể dục thường xuyên](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/endorphin-tac-dung-va-cach-nao-de-tang-nong-do-endorphin#tp-th-dc-thng-xuyn)
  * [Endorphin thấp và các tình trạng sức khỏe ](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/endorphin-tac-dung-va-cach-nao-de-tang-nong-do-endorphin#endorphin-thp-v-cc-tnh-trng-sc-khe)
  * [Đau đầu mạn tính](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/endorphin-tac-dung-va-cach-nao-de-tang-nong-do-endorphin#au-u-mn-tnh)



## ️ Dị ứng Penicillin và các phản ứng miễn dịch liên quan

  * [I. Penicillin là một hapten. Vậy hapten là gì?](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/di-ung-penicillin-va-cac-phan-ung-mien-dich-lien-quan#i-penicillin-l-mt-hapten-vy-hapten-l-g)
  * [ II. Cấu trúc hoá học và dị ứng: ](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/di-ung-penicillin-va-cac-phan-ung-mien-dich-lien-quan#ii-cu-trc-ho-hc-v-d-ng)
  * [ III. Các phản ứng miễn dịch phân loại theo Gell-Coombs](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/di-ung-penicillin-va-cac-phan-ung-mien-dich-lien-quan#iii-cc-phn-ng-min-dch-phn-loi-theo-gellcoombs)
  * [1. Các phản ứng trung gian miễn dịch do penicillin là qua trung gian kháng thể:](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/di-ung-penicillin-va-cac-phan-ung-mien-dich-lien-quan#1-cc-phn-ng-trung-gian-min-dch-do-penicillin-l-qua-trung-gian-khng-th)
  * [ 2. Các phản ứng qua trung gian tế bào T-cell: ](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/di-ung-penicillin-va-cac-phan-ung-mien-dich-lien-quan#2-cc-phn-ng-qua-trung-gian-t-bo-tcell)


## **I. Penicillin là một hapten. Vậy hapten là gì?**
Hapten là một chất mà tự nó không sinh được đáp ứng miễn dịch nhưng có thể phản ứng với các sản phẩm của một phản ứng miễn dịch đặc hiệu. Các hapten là những phân tử nhỏ mà không bao giờ có thể gây ra một đáp ứng miễn dịch khi được đưa vào cơ thể bởi riêng chúng, nhưng có thể gây đáp ứng miễn dịch khi chúng kết hợp với phân tử mang nó. Tuy nhiên, hapten tự do có thể phản ứng với các sản phẩm của đáp ứng miễn dịch sau khi sản phẩm đó đã được sinh ra bởi phức hợp happten-chất mang. Hapten có đặc tính kháng nguyên nhưng không có tính sinh miễn dịch.
Vậy penicillin lần đầu tiên vào cơ thể bản thân nó không sinh ra đáp ứng miễn dịch. Nhưng khi vào cơ thể, penicillin gắn với các protein huyết tương hoặc protein bám màng tế bào. Các protein này đóng vai trò là một chất mang (carrier) và phức hợp happten (penicillin)-chất mang này có khả năng sinh miễn dịch. Và sau đó penicillin tự do được dùng ở lần thứ 2 có thể phản ứng với các kháng thể đã được tạo ra bởi phức hợp penicillin-chất mang lần đầu.
##  **II. Cấu trúc hoá học và dị ứng:**
Penicilin là các phân tử nhỏ, có khả năng cộng hoá trị với các protein trong huyết tương và tạo nên các phức hợp mang hapten. Sự hình thành phức hợp này xảy ra khi vòng beta-lactam mở ra một cách tự phát để hình thành peniciloyl. Sau đó, peniciloyl sẽ liên kết với các gốc lysin trong các phân tử protein huyết của vật chủ, tạo nên một phức hợp polylysine, các epitope Penicillin polylysine này chính là một yếu tố quyết định kháng nguyên chính (the major antigenic determinant) "Penicilloyl polylysine". Sự hapten hoá (haptenation) từ các liên kết đồng hoá trị vào các gốc carboxyl và thiol dẫn đến việc tạo ra một số yếu tố quyết định kháng nguyên phụ (the minor determinant). *Một số tác dụng không mong muốn: Penicillin ức chế tổng hợp vách vi khuẩn và nhắm vào các vi khuẩn một cách đặc hiệu, do các tế bào nhân thực không có vách tế bào. Penicillin còn tác động vào hệ vi sinh và dẫn đến sự tăng trưởng quá mức của một số loại như Clostridioides difficile gây viêm đại tràng, nhiễm Candida ở miệng.
##  **III. Các phản ứng miễn dịch phân loại theo Gell-Coombs**
### **1. Các phản ứng trung gian miễn dịch do penicillin là qua trung gian kháng thể:**
**_a. Phản ứng quá mẫn type I, phản ứng tức thì (qua trung gian IgE)_**
  * Ở lần tiếp xúc đầu tiên, các tế bào tua gắn vào và trung hoà các protein gắn penicillin. Sau đó các tế bào tua thông qua MHC lớp II sẽ trình diện kháng nguyên với các CD4+ T cell (type 0 helper T cell).
  * Với sự xuất hiện của interleukin-4, naive T cell phát triển thành type 2 helper T cell (Th2 cell) đặc hiệu với penicillin, loại Th2 cell này sau đó sản xuất interleukin-4 và interleukin-13, thúc đẩy sự biệt hoá của B cell thành plasma cell. - Plasma cell tiết ra IgE đặc hiệu với penicillin, kháng thể này gắn vào các Fc ε receptor ở bề mặt basophil và mast cell.
  * Ở lần tiếp xúc tiếp theo, liên kết chéo penicillin đa hoá trị của các Fc ε receptor sẽ gắn vào các kháng thể IgE, làm mast cell phóng hạt và giải phóng các hoá chất trung gian gây viêm như tryptase, histamin, prostaglandin và leukotriene dẫn đến các biểu hiện lâm sàng của phản vệ (anaphylaxis).


_**b. Ở các phản ứng quá mẫn type II (các phản ứng độc tế bào):**_ Kháng thể hoặc phức hợp miễn dịch gắn vào các cấu trúc màng tế bào của hồng cầu, bạch cầu và tiểu cầu dẫn đến phá huỷ tế bài, gây thiếu máu tán huyết, giảm tiểu cầu. _**c. Ở các phản ứng quá mẫn type III (phản ứng phức hợp miễn dịch)**_ Các kháng thể được hình thành trong 4-10 ngày, sau đó sẽ tương tác với các phức hợp penicillin hapten-chất mang, tạo nên các phức hợp miễn dịch hoà tan. Sự hoạt hoá bổ thể và lắng đọng ở các mạch máu nhỏ dẫn đến huy động neutrophil bởi Fc-IgG receptor, việc này làm giải phóng các enzyme phân giải protein và gây ra tổn thương mô và viêm mạch tại chỗ.
##  **2. Các phản ứng qua trung gian tế bào T-cell:**
Các phản ứng này diễn ra lớn hơn 6 giờ sau khi dùng penicillin hoặc có thể trong khi điều trị nếu đã tiếp xúc nhiều lần. Tế bào trình diện kháng nguyên sẽ xử lý thuốc và trình diện các peptide (peptide có nguồn gốc từ penicillin) thông qua HLA-1. Các peptide này được nhận diện thông qua T-cell receptor ở CD4+ hoặc CD8+ T cell, làm hoạt hoá T cell và giải phóng các cytokine và chemokine. Phản ứng do thuốc kèm tăng eosinophil và các triệu chứng toàn thân (Drug reaction with eosinophilia and systemic symptoms, DRESS) điển hình diễn ra 2-8 tuần sau khi dùng penicillin và liên quan đến sốt, bệnh tuyến lympho, tăng eosinophil, tăng số lượng tế bào lympho không điển hình và có sự xâm nhập eosinophil, CD4+,CD8+ T cell vào da, các cơ quan (gan, thận, phổi, tim,...) *Một số ví dụ tổn thương cơ quan do các phản ứng qua trung gian T cell:
  * Có thể gặp các trường hợp tổn thương gan do thuốc và viêm thận mô kẽ liên quan đến penicillin.
  * Hội chứng Stevens–Johnson và hoại tử biểu bì nhiễm độc (the Stevens-Johnson syndrome and toxic epidermal necrolysis, SJS-TEN) có tổn thương da đặc trưng dạng mụn nước và bọng nước diễn ra 4-28 ngày sau khi dùng thuốc.
  * Hội chứng ngoại ban mủ toàn thân cấp tính (Acute generalized exanthematous pustulosis, AGEP) thường xảy ra trong 24-72 giờ sau khi tiếp xúc với penicillin, biểu hiện sốt, tăng neutrophil, mụn mủ vô trùng trên nền hồng ban lan rộng.


Xem thêm: [**Dị ứng latex có thể phòng ngừa như thế nào?**](https://bvnguyentriphuong.com.vn/kham-da-lieu-chuyen-sau/di-ung-latex-co-the-phong-ngua-nhu-the-nao)
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [I. Penicillin là một hapten. Vậy hapten là gì?](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/di-ung-penicillin-va-cac-phan-ung-mien-dich-lien-quan#i-penicillin-l-mt-hapten-vy-hapten-l-g)
  * [ II. Cấu trúc hoá học và dị ứng: ](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/di-ung-penicillin-va-cac-phan-ung-mien-dich-lien-quan#ii-cu-trc-ho-hc-v-d-ng)
  * [ III. Các phản ứng miễn dịch phân loại theo Gell-Coombs](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/di-ung-penicillin-va-cac-phan-ung-mien-dich-lien-quan#iii-cc-phn-ng-min-dch-phn-loi-theo-gellcoombs)
  * [1. Các phản ứng trung gian miễn dịch do penicillin là qua trung gian kháng thể:](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/di-ung-penicillin-va-cac-phan-ung-mien-dich-lien-quan#1-cc-phn-ng-trung-gian-min-dch-do-penicillin-l-qua-trung-gian-khng-th)
  * [ 2. Các phản ứng qua trung gian tế bào T-cell: ](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/di-ung-penicillin-va-cac-phan-ung-mien-dich-lien-quan#2-cc-phn-ng-qua-trung-gian-t-bo-tcell)



## ️ Đừng duy trì thói quen xấu: Tự mua thuốc!!!

  * [Lây nhiễm do thói quen ho, sốt tự mua thuốc uống](https://bvnguyentriphuong.com.vn/khoa-kham-benh/dung-duy-tri-thoi-quen-xau-tu-mua-thuoc#ly-nhim-dothi-quen-ho-stt-mua-thuc-ung)
  * [Sai lầm khi tự ý dùng thuốc](https://bvnguyentriphuong.com.vn/khoa-kham-benh/dung-duy-tri-thoi-quen-xau-tu-mua-thuoc#sai-lm-khi-t-dng-thuc)
  * [Nhiều hậu quả khác](https://bvnguyentriphuong.com.vn/khoa-kham-benh/dung-duy-tri-thoi-quen-xau-tu-mua-thuoc#nhiu-hu-qu-khc)


## **Lây nhiễm do thói quen ho, sốt tự mua thuốc uống**
Ngày 13-4, Chủ tịch UBND TP Hà Nội Nguyễn Đức Chung yêu cầu Sở Y tế Hà Nội phải thông tin tới 7.000 hiệu thuốc trên địa bàn về nhiệm vụ tham gia phòng chống dịch COVID-19. Theo đó, ngành y tế phải yêu cầu tất cả các hiệu thuốc khi bán cho những trường hợp mua thuốc cảm, sốt, ho phải có khai báo y tế và báo ngay cho y tế của phường tổ chức lấy mẫu xét nghiệm với COVID-19.
Tất cả các phòng khám tư nhân, các trạm y tế, các bác sĩ tư nhân, cơ sở khám chữa bệnh cũng phải yêu cầu khai báo y tế với những bệnh nhân ho, sốt, khó thở đến khám, sau đó phải thông báo để lấy mẫu xét nghiệm toàn bộ.
Yêu cầu này xuất phát từ diễn biến ca bệnh của bệnh nhân 243. Qua kiểm tra dịch tễ cho thấy bệnh nhân 243 có biểu hiện ho, sốt đã tự đi mua thuốc điều trị tại một nhà thuốc gần nhà. Sau khi tự uống thuốc, bệnh nhân có biểu hiện bình thường và đã đi lại khắp nơi (như chợ hoa, Bệnh viện Phụ sản Hà Nội, Bệnh viện Đa khoa Phúc Yên, Vĩnh Phúc)… 
Thói quen hơi bị cảm sốt là tự ra ngoài, đến nhà thuốc mua thuốc về uống là việc lâu nay của người dân , điều này dẫn đến khó kiểm soát nhiều ca bệnh có nguy cơ mắc COVID-19.
Nếu hiệu thuốc nào mà có những người sốt, ho đến mua thuốc mà để sót các trường hợp này, thì sẽ xử lý theo đúng quy định của pháp luật. Vì đây là nhiệm vụ tham gia công tác phòng chống dịch, số người này là quan trọng, những người này không khai báo y tế, không báo cho y tế của phường thì sau này có thể tước giấy phép vĩnh viễn (theo chỉ đạo của Chủ tịch UBND Thành phố Hà Nội)
## **Sai lầm khi tự ý dùng thuốc**
Nhiều người “tự làm bác sĩ”, tức là tự mua thuốc về điều trị hoặc điều trị theo mách bảo của người xung quanh, thậm chí sử dụng đơn thuốc của người khác. Thói quen xấu này đã dẫn đến vô vàn hậu quả: vi khuẩn gây bệnh kháng lại kháng sinh, làm số ngày điều trị tăng, chi phí tăng và tử vong tăng. Chính từ thói quen này đã dẫn đến nhiều trường hợp bị ngộ độc thuốc.
Người bệnh mua vài liều uống, thấy giảm các triệu chứng là ngưng uống thuốc luôn. Nhiều lần như vậy, thấy bệnh tình hoặc tình trạng khó chịu có thể giảm, thậm chí khỏi, nên họ coi đó là chuyện bình thường. Nhưng nhiều trường hợp không khỏi mà có khi bệnh còn nặng hơn, thậm chí tai biến nguy hiểm đến tính mạng sau khi dùng thuốc, đã được các nhà chuyên môn cảnh báo nhiều lần.
Có bệnh nhân sau khi uống thuốc ngoài hoài không hết, mới chịu đi khám, đem bọc thuốc cho bác sĩ xem thì bác sĩ có khi cũng không biết đó là thuốc gì, vì đã được lột bỏ vỏ hộp. Với trẻ em, khi điều trị kháng sinh không hợp lý, không đủ liều, không đúng bệnh sẽ dẫn tới không ít trường hợp bị nhiễm vi khuẩn kháng thuốc.
Đối với những bệnh lý phức tạp, việc tự ý dùng thuốc bừa bãi có thể làm khuất lấp triệu chứng nhưng bệnh vẫn phát triển, dẫn đến khó trị.
Trong một số trường hợp, nguy cơ bệnh nhân bị tử vong do sốc phản vệ hoặc dị ứng trầm trọng không hồi phục xảy ra ở một số nơi đã báo động về việc dùng thuốc tùy tiện.
## **Nhiều hậu quả khác**
Tự ý sử dụng thuốc còn dẫn đến hậu quả là nghiện thuốc. Tai hại càng tăng thêm khi người sử dụng thuốc không hiểu được sự tương tác giữa thuốc này với thuốc kia, sự tương tác giữa dược phẩm với thực phẩm, rượu bia... Đã có trường hợp một bệnh nhân uống thuốc Aspirin khi bụng đói, hậu quả là xuất huyết bao tử nếu cấp cứu không kịp dễ tử vong.
Những dạng thuốc khác thường được người sử dụng tự ý mua dùng là các loại kem thoa da và lotion. Đừng nghĩ rằng thuốc bôi ngoài da là vô hại bởi vì thuốc sẽ ngấm qua da và đi vào hệ tuần hoàn máu. Trong các loại kem thoa da và lotion có chứa rất nhiều hóa chất vốn là “bạn” ở da người này nhưng lại là “thù” ở da người khác.
Khi có bệnh, cần tập thói quen đi khám bác sĩ để được hướng dẫn dùng thuốc. Cũng cần nên giáo dục con cái về tác hại của việc tự ý sử dụng thuốc, không uống thuốc theo kiểu “truyền tai” từ bạn bè.
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [Lây nhiễm do thói quen ho, sốt tự mua thuốc uống](https://bvnguyentriphuong.com.vn/khoa-kham-benh/dung-duy-tri-thoi-quen-xau-tu-mua-thuoc#ly-nhim-dothi-quen-ho-stt-mua-thuc-ung)
  * [Sai lầm khi tự ý dùng thuốc](https://bvnguyentriphuong.com.vn/khoa-kham-benh/dung-duy-tri-thoi-quen-xau-tu-mua-thuoc#sai-lm-khi-t-dng-thuc)
  * [Nhiều hậu quả khác](https://bvnguyentriphuong.com.vn/khoa-kham-benh/dung-duy-tri-thoi-quen-xau-tu-mua-thuoc#nhiu-hu-qu-khc)



## ️ Penicillin hoạt động như thế nào

  * [Chức năng của Penicillin](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/penicillin-hoat-dong-nhu-the-nao#chc-nng-ca-penicillin)
  * [Vấn đề kháng kháng sinh](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/penicillin-hoat-dong-nhu-the-nao#vn-khng-khng-sinh)
  * [Phản ứng phụ của thuốc](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/penicillin-hoat-dong-nhu-the-nao#phn-ng-ph-ca-thuc)
  * [Nguy cơ khi sử dụng penicillin](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/penicillin-hoat-dong-nhu-the-nao#nguy-c-khi-s-dng-penicillin)
  * [Dị ứng Penicillin](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/penicillin-hoat-dong-nhu-the-nao#d-ng-penicillin)


Penicillins là một nhóm thuốc kháng khuẩn tấn công nhiều loại vi khuẩn. Đây là những loại thuốc đầu tiên thuộc loại này được áp dụng trong điều trị y tế. Việc phát hiện và sản xuất penicillin đã thay đổi bộ mặt của y học và đã cứu sống hàng triệu người trong suốt quá trình lịch sử.
Nấm Penicillium là nguồn cung cấp penicillin - có thể dùng đường uống hoặc tiêm. Hiện nay, penicillin đang được sử dụng rộng rãi để điều trị nhiễm trùng và một số tình trạng có liên quan.
## **Chức năng của Penicillin**
Thuốc trong nhóm penicillin hoạt động bằng cách gián tiếp phá vỡ các thành tế bào vi khuẩn bằng cách tác động lên **peptidoglycans** - có vai trò cấu trúc thiết yếu trong tế bào vi khuẩn.
Peptidoglycans tạo ra một cấu trúc mạng lưới xung quanh màng plasma của tế bào vi khuẩn, làm tăng sức mạnh của thành tế bào và ngăn dịch từ bên ngoài và các hạt xâm nhập vào tế bào.
Khi một vi khuẩn nhân lên, các lỗ nhỏ mở ra trong thành tế bào của nó khi các tế bào phân chia. Peptidoglycans mới được sản xuất sau đó lấp đầy các lỗ này để tạo thành các vách ngăn.
Penicillins giúp chặn protein liên kết các peptidoglycan với nhau. Điều này ngăn vi khuẩn đóng kín thành tế bào. Khi nồng độ nước của dịch xung quanh cao hơn so với bên trong vi khuẩn, nước sẽ chảy qua các lỗ vào tế bào và giết chết vi khuẩn.
## **Lịch sử**
Mọi người thường nhắc đến công lao của việc phát hiện ra penicillin cho Alexander Fleming. Câu chuyện kể rằng ông trở lại phòng thí nghiệm của mình vào một ngày vào tháng 9 năm 1928 để tìm một đĩa Petri có chứa vi khuẩn Staphylococcus bị mất nắp.
Ông tìm được đĩa bị bao phủ với một lớp mốc màu xanh lam được gọi là Penicillium notatum. Fleming nhận thấy rằng có một vòng tròn ở xung quanh nấm mốc nơi vi khuẩn không thể phát triển.
Bằng cách khám phá lớp mốc này và nhận ra công dụng của nó, Fleming đã đánh dấu một cột mốc mới, tạo ra một trong những loại thuốc hữu ích nhất trong lịch sử y tế.
Vào tháng 3 năm 1942, Anne Miller trở thành thường dân đầu tiên được điều trị thành công bằng penicillin. Cô tránh được cái chết khi bị nhiễm trùng nặng sau khi sảy thai.
Mặc dù Fleming về mặt kỹ thuật đã phát hiện ra loại kháng sinh đầu tiên, các thế hệ nhà khoa học sau đó đã phải thực hiện rất nhiều việc trước khi penicillin có thể được sử dụng phổ biến. Các nhà khoa học với các thiết bị hỗ trợ nghiên cứu vượt trội và có những hiểu biết sâu sắc hơn về hóa học so với Fleming đã thực hiện phần lớn công việc còn lại. Howard Florey, Norman Heatley và Ernst Chain đã thực hiện các nghiên cứu chuyên sâu và tập trung đầu tiên về loại thuốc này.
Trong bài phát biểu nhận giải thưởng Fleming, ông đã cảnh báo rằng việc lạm dụng penicillin một ngày nào đó sẽ dẫn đến tình trạng kháng vi khuẩn. Và hiện này, điều này đã trở thành một vấn đề gây đau đầu các chuyên gia y tế.
## **Vấn đề kháng kháng sinh**
Trái với quan điểm phổ thông, đó không phải là con người phát triển sự đề kháng với penicillin mà là chính vi khuẩn.
Vi khuẩn đã tồn tại hàng tỷ năm. Trong suốt thời gian đó, chúng đã chịu đựng được môi trường khắc nghiệt và kết quả là có khả năng thích nghi cao. Chúng cũng tái sinh rất nhanh, tạo ra những thay đổi di truyền tương đối nhanh trên toàn bộ dân số.
Có 3 cách phổ biến để vi khuẩn có thể phát triển khả năng miễn dịch với penicillin:
  * **Penicillinase:** Vi khuẩn đôi khi có thể sản xuất penicillinase, một loại enzyme làm suy giảm penicillin. Khả năng này có thể nhân rộng khắp quần thể vi khuẩn thông qua một vòng DNA nhỏ trong một quá trình gọi là liên hợp. Đây là vi khuẩn tương đương với sinh sản hữu tính.
  * **Cấu trúc vi khuẩn bị thay đổi:** Một số vi khuẩn có thể thay đổi một cách linh hoạt định dạng của protein gắn penicillin trong thành peptidoglycan của chúng để loại bỏ liên kết với penicillin.
  * **Loại bỏ Penicillin:** Các vi khuẩn khác phát triển hệ thống để loại bỏ penicillin. Vi khuẩn có cơ chế bơm thoát dòng mà chúng sử dụng để giải phóng các chất ra khỏi tế bào. Việc tái sử dụng một số cơ chế này có thể cho phép tế bào thải bỏ penicillin.


## **Phản ứng phụ của thuốc**
Các tác dụng phụ thường gặp nhất khi dùng penicillin bao gồm:
  * Tiêu chảy;
  * Buồn nôn;
  * Đau đầu;
  * Phát ban da và nổi mề đay.


Tác dụng phụ ít phổ biến hơn bao gồm:
  * Khó thở hoặc thở không đều;
  * Đau khớp;
  * Chóng mặt và ngất xỉu;
  * Bọng mắt và ửng đỏ ở mặt;
  * Xuất hiện vảy, đỏ da;
  * Ngứa âm đạo và tiết dịch, do nhiễm trùng nấm men hoặc viêm âm đạo do vi khuẩn;
  * Đau miệng và lưỡi, đôi khi có những mảng trắng;
  * Đau, chuột rút, có thắt vùng bụng.


Tác dụng phụ hiếm gặp bao gồm:
  * Lo lắng, sợ hãi, cảm giác lâng lâng hoặc lú lẫn;
  * Xuất hiện ảo giác;
  * Vàng mắt và da;
  * Đau họng;
  * Chảy máu bất thường;
  * Tiêu chảy và giảm đi tiểu;
  * Co giật.


## **Nguy cơ khi sử dụng penicillin**
Mặc dù việc sử dụng penicillin hiện này rất phổ biến tuy nhiên, vẫn có lưu ý cho một số tình trạng hoặc chống chỉ định tương tự như với bất kỳ loại thuốc nào:
  * **Nuôi con bằng sữa mẹ:** Những người đang cho con bú có thể truyền một lượng nhỏ penicillin cho trẻ. Điều này có thể dẫn đến việc trẻ gặp phải phản ứng dị ứng, tiêu chảy, nhiễm nấm và phát ban da.
  * **Tương tác thuốc:** Một số loại thuốc khác có thể tương tác với penicillin. Vì vậy việc tham khảo ý kiến của bác sĩ trước khi dùng một lúc nhiều loại thuốc là rất quan trọng.
  * **Các vấn đề về chảy máu:** Một số loại penicillin, như carbenicillin, piperacillin và ticarcillin, có thể làm cho các tình trạng chảy máu trước đó trở nên nghiêm trọng hơn.
  * **Thuốc tránh thai đường uống:** Penicillin có thể ảnh hưởng đến hiệu quả của thuốc tránh thai, làm tăng nguy cơ mang thai ngoài ý muốn.
  * **Xơ nang:** Những người bị xơ nang dễ bị sốt và nổi mẩn da khi dùng piperacillin.
  * **Bệnh thận:** Những người mắc bệnh thận có nguy cơ mắc các tác dụng phụ.
  * **Methotrexate:** Methotrexate giúp làm gián đoạn sự phát triển của tế bào và có thể điều trị một số bệnh, bao gồm **bệnh bạch cầu** và một số **bệnh tự miễn**. Penicillins ngăn cơ thể thải bỏ loại thuốc này có khả năng dẫn đến các biến chứng nghiêm trọng.
  * **Phenylketon niệu:** Một kháng sinh như amoxicillin mạnh hơn có chứa hàm lượng aspartame cao mà cơ thể chuyển thành phenylalanine. Điều này rất nguy hiểm cho bất cứ ai bị phenylketon niệu.
  * **Các vấn đề về đường tiêu hóa:** Bệnh nhân có tiền sử loét dạ dày hoặc các bệnh đường ruột khác có thể dễ bị **viêm đại tràng** khi dùng penicillin.​


## **Dị ứng Penicillin**
Một số người bị dị ứng với penicillin. Phản ứng dị ứng với penicillin thường dẫn đến **phát ban, thở khò khè và sưng phù** đặc biệt là ở mặt.
Tại Hoa Kỳ, khoảng 10% số người báo cáo dị ứng với penicillin nhưng con số thực chỉ gần 1% và chỉ khoảng 0,03% xuất hiện phản ứng dị ứng đe dọa tính mạng.
**Rượu và penicillin**
Một số loại kháng sinh, như **metronidazole** và **tinidazole** , có phản ứng mạnh với rượu. Tuy nhiên, vấn đề này không gặp phải với penicillin.
## **Tổng kết**
Penicillins đã cứu sống vô số người trong suốt lịch sử sử dụng trong y học. Tuy nhiên, nhiều chuyên gia hiện đang lo lắng về sự gia tăng kháng kháng sinh.
Và rồi tương lai sẽ ra sao? Chỉ có thời gian mới cho biết nhân loại sẽ vượt qua rào cản này như thế nào.
Xem thêm: [**Đừng duy trì thói quen xấu - Tự mua thuốc!!!**](https://bvnguyentriphuong.com.vn/khoa-kham-benh/dung-duy-tri-thoi-quen-xau-tu-mua-thuoc)
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [Chức năng của Penicillin](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/penicillin-hoat-dong-nhu-the-nao#chc-nng-ca-penicillin)
  * [Vấn đề kháng kháng sinh](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/penicillin-hoat-dong-nhu-the-nao#vn-khng-khng-sinh)
  * [Phản ứng phụ của thuốc](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/penicillin-hoat-dong-nhu-the-nao#phn-ng-ph-ca-thuc)
  * [Nguy cơ khi sử dụng penicillin](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/penicillin-hoat-dong-nhu-the-nao#nguy-c-khi-s-dng-penicillin)
  * [Dị ứng Penicillin](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/penicillin-hoat-dong-nhu-the-nao#d-ng-penicillin)



## ️ Paracetamol - Sử dụng thế nào cho an toàn?

  * [Chỉ định dùng Paracetamol](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/paracetamol-su-dung-the-nao-cho-an-toan#ch-nh-dng-paracetamol)
  * [Không thoải mái](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/paracetamol-su-dung-the-nao-cho-an-toan#khng-thoi-mi)
  * [Dị ứng kháng nguyên vacxin 3 trong 1](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/paracetamol-su-dung-the-nao-cho-an-toan#d-ng-khng-nguyn-vacxin-3-trong-1)
  * [ Đau sau phẫu thuật](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/paracetamol-su-dung-the-nao-cho-an-toan#au-sau-phu-thut)
  * [Thuốc hạ sốt có thể có hại](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/paracetamol-su-dung-the-nao-cho-an-toan#thuc-h-st-c-th-c-hi)
  * [Độc tính trực tiếp](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/paracetamol-su-dung-the-nao-cho-an-toan#c-tnh-trc-tip)


## **Chỉ định dùng Paracetamol**
### 
  * Ở những bệnh nhân bị suy tim hoặc suy hô hấp có thể sử dụng Paracetamol để giảm lượng tiêu thụ oxy, giảm sản xuất carbon dioxide và giảm cung lượng tim.
  * Tuy nhiên, ở những bệnh nhân không mắc bệnh tim hoặc phổi, sốt chỉ gây nguy hiểm ở nhiệt độ trên 400C gây ra bởi say nắng hoặc chấn thương não, do đó chúng không đáp ứng với Paracetamol hoặc Aspirin.


### **Co giật do sốt**
  * Không có bằng chứng cho thấy thuốc hạ sốt ngăn ngừa co giật do sốt.
  * Các cơn co giật xảy ra là do nhiệt độ tăng nhanh thường xảy ra khi bắt đầu bệnh.
  * Trong một thử nghiệm kiểm soát cơn co giật do sốt ở trẻ em, trẻ dùng Paracetamol 15-20 mg / kg sau 4 giờ cũng có khả năng bị co giật khác khi trẻ chỉ dùng Paracetamol khi nhiệt độ trực tràng của chúng vượt quá 37,90C


### **Không thoải mái**
  * Nên dùng Paracetamol để giảm các triệu chứng sưng nóng do nhiễm trùng cấp tính nhẹ. Tuy nhiên, Paracetamol không có tác dụng rõ rệt: một thử nghiệm được kiểm soát gần đây cho thấy Paracetamol chỉ có tác dụng khiêm tốn ở trẻ bị nhiễm trùng cấp tính và không có sự cải thiện đáng kể về tâm trạng, sự thoải mái, thèm ăn, khát nước.


## **Dị ứng kháng nguyên vacxin 3 trong 1**
  * Một số nghiên cứu đã chỉ ra rằng Paracetamol làm giảm sốt ở trẻ em đã tiêm vacxin. Một nghiên cứu khác cho thấy Paracetamol không có tác dụng đáng kể, nhưng chỉ một liều 10 mg /kg paracetamol được tiêm 4 giờ sau khi chủng ngừa được khảo sát ở nghiên cứu này.


### **Đau sau phẫu thuật**
  * Có rất ít nghiên cứu có hệ thống về việc sử dụng Paracetamol để giảm đau sau phẫu thuật, nhưng các thử nghiệm kiểm soát thuốc chống viêm không steroid và kinh nghiệm với Paracetamol cho thấy Paracetamol cung cấp giảm đau đầy đủ cho phẫu thuật nhỏ và cho phép giảm liều phong bế đau sau phẫu thuật lớn. Paracetamol có lẽ nên được sử dụng chủ động trong phẫu thuật, thay vì chờ cơn đau phát triển sau phẫu thuật.


**Liều paracetamol**
  * Trong khi một liều duy nhất 5 mg/kg Paracetamol có tác dụng giảm nhiệt độ ở trẻ bị sốt hiệu quả hơn nhiều so với liều 10 mg/kg và thậm chí thời gian hiệu quả kéo dài hơn với liều 20 mg/kg.
  * Liều duy trì Paracetamol ở trẻ em là 10-15 mg/kg 4 giờ, tối đa 100 mg/kg/ngày và không vượt quá liều hơn 4g/ngày.
  * Liều ban đầu 20 mg/kg có thể được kê nếu cần có hiệu quả tối đa một cách nhanh chóng.
  * Tối đa 30 mg/kg 8 giờ cho liều hiệu quả trong phạm vi điều trị.
  * Một liều duy nhất 30 mg/kg Paracetamol khi đi ngủ có tác dụng an thần khi trẻ bị nhiễm trùng cấp tính nhẹ, nhưng tránh việc lạm dụng và cần tham vấn bác sĩ khi sử dụng liều lượng lớn thường xuyên.


## **Thuốc hạ sốt có thể có hại**
### **Miễn dịch**
  * Các bậc cha mẹ thưỡng lo lắng khi trẻ bị sốt do nhiễm trùng. Trên thực tế, sốt thường là phản ứng có lợi của cơ thể đối với nhiễm trùng và sốt vừa phải giúp cải thiện khả năng miễn dịch. Do đó, không phải trường hợp nào cũng dùng thuốc để hạ sốt.
  * Kết quả của 9 thử nghiệm đối chứng ở động vật có vú về tác dụng của Paracetamol và aspirin đối với tỷ lệ tử vong và tiêu diệt virus. Bốn thử nghiệm cho thấy aspirin làm tăng tỷ lệ tử vong trong nhiễm trùng do vi khuẩn hoặc virus.
  * Một nghiên cứu cho thấy việc sản xuất kháng thể bị suy yếu bởi cả Paracetamol và Aspirin. Điều này cho thấy rằng Aspirin và Paracetamol làm tăng tỷ lệ tử vong trong nhiễm trùng nặng, và chúng có thể kéo dài sự nhiễm trùng đồng thời làm giảm phản ứng kháng thể trong bệnh nhẹ.


### **Độc tính trực tiếp**
  * Mặc dù hàng triệu trẻ em được điều trị bằng Paracetamol nhưng có rất ít tác dụng độc tính nghiêm trọng được ghi nhận.
  * Các báo cáo về 7 trường hợp tử vong và 11 trường hợp nhiễm độc gan liên quan đến Paracetamol ở trẻ em. Những ca tử vong do liều lượng hơn 300 mg/kg/ngày kéo dài trong 1-6 ngày.
  * Những ca bị nhiễm độc gan nhưng sống sót đều có liều lượng trên 150 mg/kg/ngày trong 2-8 ngày.
  * Các trường hợp ngộ độc Paracetamol khác ở trẻ em xảy nhiều nhưng chưa được phát hiện và ghi nhận nhưng bằng chứng cho thấy độc tính từ Paracetamol rất hiếm khi xảy ra với liều dưới 150mg/kg/ngày. Liều Paracetamol không được vượt quá 100mg/kg/ngày ở trẻ em và không bệnh nhân nào nên dùng quá 4g/ngày.


**Phần kết luận**
  * Tác dụng hạ sốt của Paracetamol rất hữu ích ở bệnh nhân sốt do suy tim hoặc suy hô hấp.
  * Tác dụng giảm trong nhiễm trùng cấp tính nhẹ, cho đau sau phẫu thuật và sau khi tiêm vắc-xin 3 trong 1.
  * Không khuyến khích ưu tiên việc sử dụng Paracetamol để điều trị sốt ở bệnh nhân không mắc bệnh tim, phổi, hoặc để ngăn ngừa co giật do sốt (cân nhắc thêm các lựa chọn khác để hạ sốt). 
  * Paracetamol có thể làm giảm phản ứng kháng thể với nhiễm trùng, tăng tỷ lệ mắc bệnh và tử vong trong nhiễm trùng nặng.
  * Các bậc phụ huynh cần nhận ra rằng sốt là một phản ứng hữu ích đối với nhiễm trùng và Paracetamol nên được sử dụng nhằm giảm bớt sự khó chịu, nhưng không phải để chống lại sốt.


**Bệnh viện Nguyễn Tri Phương** - Bệnh viện Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [Chỉ định dùng Paracetamol](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/paracetamol-su-dung-the-nao-cho-an-toan#ch-nh-dng-paracetamol)
  * [Không thoải mái](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/paracetamol-su-dung-the-nao-cho-an-toan#khng-thoi-mi)
  * [Dị ứng kháng nguyên vacxin 3 trong 1](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/paracetamol-su-dung-the-nao-cho-an-toan#d-ng-khng-nguyn-vacxin-3-trong-1)
  * [ Đau sau phẫu thuật](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/paracetamol-su-dung-the-nao-cho-an-toan#au-sau-phu-thut)
  * [Thuốc hạ sốt có thể có hại](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/paracetamol-su-dung-the-nao-cho-an-toan#thuc-h-st-c-th-c-hi)
  * [Độc tính trực tiếp](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/paracetamol-su-dung-the-nao-cho-an-toan#c-tnh-trc-tip)



## Sử dụng kháng sinh bừa bãi và hậu quả

  * [1. Lạm dụng kháng sinh trong chăn nuôi](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/su-dung-khang-sinh-bua-bai-va-hau-qua#1-lam-dung-khang-sinh-trong-chn-nui)
  * [1.1. Thực trạng lạm dụng kháng sinh trong chăn nuôi](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/su-dung-khang-sinh-bua-bai-va-hau-qua#11-thc-trng-lam-dung-khang-sinh-trong-chn-nui)
  * [1.2. Tác hại của việc lạm dụng kháng sinh trong chăn nuôi ](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/su-dung-khang-sinh-bua-bai-va-hau-qua#12-tc-hi-ca-vic-lm-dng-khng-sinh-trong-chn-nui)
  * [Vi khuẩn kháng thuốc ](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/su-dung-khang-sinh-bua-bai-va-hau-qua#vi-khun-khng-thuc)
  * [Gây ảnh hưởng trực tiếp tới sức khỏe của con người ](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/su-dung-khang-sinh-bua-bai-va-hau-qua#gy-nh-hng-trc-tip-ti-sc-khe-ca-con-ngi)
  * [2. Lạm dụng kháng sinh trong điều trị](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/su-dung-khang-sinh-bua-bai-va-hau-qua#2-lam-dung-khang-sinh-trong-iu-tri)
  * [2.1. Dùng kháng sinh cho các bệnh không do vi khuẩn](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/su-dung-khang-sinh-bua-bai-va-hau-qua#21-dung-khang-sinh-cho-cac-bnh-khng-do-vi-khun)
  * [2.2. Việc mua và sử dụng kháng sinh quá dễ dàng](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/su-dung-khang-sinh-bua-bai-va-hau-qua#22-vic-mua-v-s-dng-khng-sinh-qu-d-dng)
  * [Từ phía bệnh nhân](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/su-dung-khang-sinh-bua-bai-va-hau-qua#t-pha-bnh-nhn)
  * [Từ phía nhân viên y tế](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/su-dung-khang-sinh-bua-bai-va-hau-qua#t-pha-nhn-vin-y-t)
  * [2.3. Trong thực tế hàng ngày, việc sử dụng kháng sinh của thầy thuốc cũng rất rộng rãi](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/su-dung-khang-sinh-bua-bai-va-hau-qua#23-trong-thc-t-hng-ngy-vic-s-dng-khng-sinh-ca-thy-thuc-cng-rt-rng-ri)
  * [3. Hậu quả của việc sử dụng kháng sinh bừa bãi ](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/su-dung-khang-sinh-bua-bai-va-hau-qua#3-hu-qu-ca-vic-s-dng-khng-sinh-ba-bi)
  * [3.1. Gây lãng phí](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/su-dung-khang-sinh-bua-bai-va-hau-qua#31gy-lng-ph)
  * [3.2. Không khỏi bệnh](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/su-dung-khang-sinh-bua-bai-va-hau-qua#32khng-khi-bnh)
  * [3.3. Chậm chẩn đoán](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/su-dung-khang-sinh-bua-bai-va-hau-qua#33chm-chn-on)
  * [3.4. Tác dụng độc hại](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/su-dung-khang-sinh-bua-bai-va-hau-qua#34tc-dng-c-hi)
  * [3.5. Tăng khả năng kháng thuốc của vi khuẩn](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/su-dung-khang-sinh-bua-bai-va-hau-qua#35tng-kh-nng-khng-thuc-ca-vi-khun)
  * [Vi khuẩn nhờn thuốc](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/su-dung-khang-sinh-bua-bai-va-hau-qua#vi-khun-nhn-thuc)


## **1. Lạm dụng kháng sinh trong chăn nuôi**
### **1.1. Thực trạng lạm dụng kháng sinh trong chăn nuôi**
Để kích thích vật nuôi tăng trưởng nhanh, giảm thấp tiêu hao thức ăn, vật nuôi có bề ngoài bắt mắt, tăng lợi nhuận, nhiều trang trại sử dụng lượng lớn thuốc kháng sinh trộn thẳng vào thức ăn mà không cần quan tâm tới sức khỏe người tiêu dùng.  _Salbutamol, Clenbuterol, Ractopamin_ có thể giúp vật nuôi mau lớn, chuyển hóa làm tiêu mỡ, tăng khối lượng cơ, làm màu thịt đỏ tươi hơn nhưng gây ra tác hại khó lường với sức khỏe con người.
Ngoài những chất tạo nạc trên, người nuôi còn sử dụng một số các loại kháng sinh tăng trọng có thể gây ung thư, đã bị cấm như Epstadiol, hay những kháng sinh có khả năng giảm mật độ tinh trùng, tăng hiện tượng đồng tính luyến ái, gây ung thư hoặc các bệnh nghiêm trọng khác trong gan, thần kinh, hệ tiêu hóa, tim và có khả năng gây đột biến như Dexametazon, Tetaciline.
_**Sử dụng kháng sinh bừa bãi trong chăn nuôi gây nhiều hệ lụy tới sức khỏe**_
Hiện nay, người nuôi thường sử dụng kháng sinh bổ sung vào thức ăn, nước uống để phòng ngừa bệnh thường gặp như đường ruột, hô hấKháng thuốc kháng sinh đang được coi là một cuộc khủng hoảng toàn cầu, trong đó thế giới đang phải đối mặt với kỷ nguyên hậu kháng sinh – khi mà những bệnh rất bình thường cũng có thể gây tử vong cho con người.p. Thậm chí là sử dụng những kháng sinh cấm, kháng sinh hạn chế sử dụng trong chăn nuôi theo quy định của Bộ NN&PTNT, điển hình như:  _Oxytetracyline, Enrofloxacine, Sunphadiazine,…_ Với mục đích phòng bệnh thường sử dụng với liều lượng thấp, không đủ để tiêu diệt vi khuẩn nên rất dễ tạo ra các dòng kháng lại kháng sinh. Điều này khá nguy hại vì nếu vật nuôi bị bệnh, khi bị kháng thuốc, những bệnh này sẽ không khỏi mà có nguy cơ trầm trọng hơn.
### **1.2. Tác hại của việc lạm dụng kháng sinh trong chăn nuôi**
#### _**Vi khuẩn kháng thuốc** _
Hậu quả của việc lạm dụng kháng sinh trong chăn nuôi có thể phá vỡ cân bằng tự nhiên của hệ vi sinh vật đường ruột gây rối loạn quá trình tiêu hóa. Mối nguy chính của lạm dụng kháng sinh trong chăn nuôi chính là sự đề kháng kháng sinh của vi khuẩn. Bất cứ kháng sinh nào dùng để chữa bệnh cho người và động vật, nếu còn tồn dư một lượng dù nhỏ nhất cũng có thể gây kháng thuốc của E.Coli. Khi E.Coli đã kháng thuốc thì nó có thể truyền plasmid kháng thuốc của nó cho các loại vi khuẩn gây bệnh khác sống trong đường ruột.
#### **_Gây ảnh hưởng trực tiếp tới sức khỏe của con người_**
Việc lạm dụng kháng sinh trong phòng và trị bệnh sẽ gây tồn dư với lượng quá mức cho phép và ảnh hưởng đến sức khỏe người tiêu dùng. Điển hình có  _Cloramphenicol_ là loại kháng sinh cấm sử dụng trên thế giới do gây thiếu máu suy tủy, ở những cá thể đặc ứng do di truyền có thể dẫn đến tử vong.
_**Sử dụng kháng sinh bừa bãi dẫn tới tồn dư kháng sinh**_
Sự tồn dư kháng sinh có trong thực phẩm không chỉ ảnh hưởng trước tiên đến vật nuôi mà còn gây nguy hại cho sức khỏe người tiêu dùng khi tiêu thụ thực phẩm. Nó gây ảnh hưởng ngay lập tức sau khi tiêu thụ sản phẩm như xảy ra phản ứng quá mẫn cảm đối với người nhạy cảm kháng sinh, gây dị ứng sau khi tiêu thụ thịt tồn dư kháng sinh… Bên cạnh đó, nó ảnh hưởng muộn hơn khi tiêu thụ thịt tồn dư kháng sinh như tạo ra thể vi sinh vật kháng thuốc, gây khó khăn cho công tác điều trị nhiễm khuẩn, làm giảm sự đáp ứng miễn dịch của cơ thể. Đặc biệt, một số kháng sinh, hóa dược có thể gây ung thư cho người tiêu thụ.
## **2. Lạm dụng kháng sinh trong điều trị**
### **2.1. Dùng kháng sinh cho các bệnh không do vi khuẩn**
Bởi hiện nay nhiều tiệm thuốc dễ dàng bán thuốc kháng sinh cho người bệnh mà không cần toa thuốc của bác sĩ. Điều này khiến cho thuốc không những không trị được bệnh, mà còn làm cơ thể sản sinh ra các vi khuẩn kháng thuốc gây nguy hiểm cho người bệnh. Có 5 nhóm bệnh chính gồm bệnh lý nhiễm trùng, bệnh lý chuyển hóa, bệnh lý ngộ độc, bẩm sinh và bệnh lý miễn dịch. Trong 5 bệnh lý trên chỉ có một phần trong bệnh lý nhiễm trùng là có chỉ định sử dụng thuốc kháng sinh. Đa phần các bệnh lý nhiễm trùng do vi khuẩn thì mới nên sử dụng kháng sinh.
_**Dùng kháng sinh cho các bệnh không do vi khuẩn**_
Hầu hết các trường hợp sốt virus, viêm họng, viêm thanh quản, viêm phế quản, tiêu chảy… thì không nên dùng kháng sinh trong điều trị. Tuy nhiên, nhiều người thường lạm dụng thuốc kháng sinh để trị bất cứ bệnh gì với mong muốn nhanh chóng khỏi bệnh. Điều này gây ra mối nguy hiểm khôn lường bởi thuốc kháng sinh ngoài tiêu diệt vi khuẩn gây bệnh thì còn tiêu diệt cả những vi khuẩn có lợi. Chính vì vậy, sử dụng kháng sinh bừa bãi thì cơ thể sẽ dễ bị các bệnh nhiễm khuẩn hơn.
### **2.2. Việc mua và sử dụng kháng sinh quá dễ dàng**
#### **_Từ phía bệnh nhân_**
Việc mua và sử dụng kháng sinh quá dễ dàng nên chỉ cần xuất hiện vài biểu hiện bất thường về sức khỏe như sốt, ho, sổ mũi là mọi người tự ý đến hiệu thuốc để mua kháng sinh, hay các bậc cha mẹ tự ý mua kháng sinh cho con mình sử dụng mà không cần biết con mình có nhiễm khuẩn hay không, trẻ em thì có phải uống liều như người lớn không và uống trong thời gian bao lâu là hợp lý.
#### **_Từ phía nhân viên y tế_**
Bên cạnh đó, các hiệu thuốc dễ dàng tự ý bán thuốc kháng sinh cho bệnh nhân mà không quan tâm bệnh nhân có toa của bác sĩ hay không, hay thậm chí bệnh nhân chỉ cần mang toa thuốc cũ, toa thuốc của người quen, hoặc chỉ cần bảo muốn mua thuốc kháng sinh là được.
Không phải lúc nào vi khuẩn cũng gây hại cho cơ thể, có những loại vi khuẩn gây bệnh cũng có những loại vi khuẩn thường trú có lợi. Khi sử dụng kháng sinh bừa bãi, vi khuẩn có lợi cũng bị tiêu diệt, ví dụ như các vi khuẩn thường trú trong đường tiêu hóa, khi đó sẽ gây ra các triệu chứng rối loạn tiêu hóa như tiêu chảy, đau bụng, buồn nôn, v.v…
Đối với các bệnh nhân hen suyễn dị ứng, kháng sinh cũng là một tác nhân kích thích. Nếu sử dụng kháng sinh quá bừa bãi có thể làm bệnh nhân, đặc biệt là trẻ nhỏ lên cơn hen cấp tính. Nhiều trường hợp trẻ em bị hen cấp tính vì bố mẹ lạm dụng thuốc kháng sinh cho con quá nhiều. Kháng sinh sau khi uống vào cơ thể sẽ được chuyển hóa qua gan hoặc qua thận, nếu sử dụng quá mức có thể gây ảnh hưởng xấu đến các cơ quan này, thậm chí dẫn đến suy gan, suy thận.
### **2.3. Trong thực tế hàng ngày, việc sử dụng kháng sinh của thầy thuốc cũng rất rộng rãi**
Trong thực tế hàng ngày, việc sử dụng kháng sinh của thầy thuốc cũng rất rộng rãi, nhiều khi tuy biết rằng không có chỉ định nhưng bác sĩ vẫn viết đơn thuốc có kháng sinh vì chẩn đoán không rõ ràng, vì thiếu phương tiện chẩn đoán vi sinh học nên dùng kháng sinh, nhất là loại có kháng sinh phổ rộng để điều trị bao vây, hoặc ghi đơn theo đòi hỏi của bệnh nhân (vì sợ mất thân chủ).
## **3. Hậu quả của việc sử dụng kháng sinh bừa bãi**
Việc lạm dụng thuốc kháng sinh gây nhiều hậu quả, trong đó có thể tóm tắt bằng 5 hậu quả sau:
### **3.1. Gây lãng phí**
Nhiều bệnh nhiễm trùng do vi rút thì không cần điều trị bằng kháng sinh, nếu dùng kháng sinh không có tác dụng sẽ là gây lãng phí. Nhiều thầy thuốc vẫn giải thích rằng dùng kháng sinh trong trường hợp này là nhằm đề phòng bội nhiễm vi khuẩn, nhưng cách giải thích đó vẫn là một kiểu nguỵ biện.
### **3.2. Không khỏi bệnh**
Sử dụng kháng sinh không đúng chỉ định gây lãng phí đồng thời còn không chữa khỏi bệnh cho bệnh nhân, thí dụ bệnh nhân bị lao phổi mà lại được chữa bằng ampicillin.
### **3.3. Chậm chẩn đoán**
Sử dụng kháng sinh sớm và không đúng chỉ định có khi gây khó khăn cho chẩn đoán bệnh, ví dụ bệnh nhân bị viêm ruột thừa cấp mà dùng kháng sinh làm lu mờ các triệu chứng của bệnh gây trở ngại cho chẩn đoán bệnh, làm sai lạc chẩn đoán.
### **3.4. Tác dụng độc hại**
Sử dụng kháng sinh khi không cần thiết hoặc không đúng chỉ định có khi dễ bị gây phản ứng dị ứng, mẫn cảm, có khi bị phản ứng phản vệ nguy hiểm có thể chết người. Nhiều loại kháng sinh có tác dụng phụ nguy hiểm nếu sử dụng liều cao hoặc kéo dài, ví dụ sử dụng Chloramphenicol ở trẻ em… có khả năng gây suy tuỷ. Một số kháng sinh như Streptomycine, Kanamycin dùng liều cao, hoặc kéo dài có thể gây điếc và suy thận….
### **3.5. Tăng khả năng kháng thuốc của vi khuẩn**
#### **_Vi khuẩn nhờn thuốc_**
Lạm dụng kháng sinh dễ làm cho vi khuẩn nhờn thuốc, do đó làm giảm tác dụng chữa bệnh của thuốc, là hậu quả tai hại, rộng lớn và lâu dài cho toàn xã hội.. Sự kháng thuốc kháng sinh ở vi khuẩn xảy ra chủ yếu do sự hình thành những gen kháng thuốc ở nhiễm sắc thể hoặc tiếp nhận một plasmid kháng thuốc từ vi khuẩn khác truyền cho hoặc vi khuẩn ở một vài trạng thái sinh lý đặc biệt như vi khuẩn ở trạng thái ngủ nghĩa là không nhân lên có thể không chịu tác động của thuốc như vi khuẩn lao.
Hình thức mất vách của một số tế bào vi khuẩn (dạng L) sẽ không bị ảnh hưởng bởi các thuốc ức chế tạo thành vách như penicillin sau thời gian dùng thuốc các vi khuẩn này có thể lấy lại cấu trúc nguyên vẹn…Trong đó cơ chế vi khuẩn kháng thuốc do đột biến nhiễm sắc thể là cơ chế quan trọng làm phát sinh sự kháng thuốc của một biến chủng vi khuẩn. Một quần thể vi khuẩn có thể chứa những biến chủng đề kháng với một loại kháng sinh. Sự hiện diện của thuốc kháng sinh như thế chỉ chọn lọc cho phép các chủng đề kháng sống sót.
#### **_Hậu quả_**
Vai trò của thuốc kháng sinh là một yếu tố chọn lọc biến chủng kháng thuốc. Một khi có sự hiện diện của biến chủng vi khuẩn kháng thuốc thì biến chủng này có thể truyền tính kháng thuốc này đến những vi khuẩn khác bằng nhiều cơ chế khác nhau: Chuyển thể, chuyển nạp, giao phối và như vậy sẽ lây lan tính kháng thuốc từ vi khuẩn này sang vi khuẩn khác. Do vậy việc lạm dụng thuốc kháng sinh tạo nguy cơ lớn để chọn lọc càng nhiều biến chủng vi khuẩn kháng thuốc.
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh
[youtube.com/bvntp](http://youtube.com/bvntp)
  * [1. Lạm dụng kháng sinh trong chăn nuôi](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/su-dung-khang-sinh-bua-bai-va-hau-qua#1-lam-dung-khang-sinh-trong-chn-nui)
  * [1.1. Thực trạng lạm dụng kháng sinh trong chăn nuôi](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/su-dung-khang-sinh-bua-bai-va-hau-qua#11-thc-trng-lam-dung-khang-sinh-trong-chn-nui)
  * [1.2. Tác hại của việc lạm dụng kháng sinh trong chăn nuôi ](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/su-dung-khang-sinh-bua-bai-va-hau-qua#12-tc-hi-ca-vic-lm-dng-khng-sinh-trong-chn-nui)
  * [Vi khuẩn kháng thuốc ](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/su-dung-khang-sinh-bua-bai-va-hau-qua#vi-khun-khng-thuc)
  * [Gây ảnh hưởng trực tiếp tới sức khỏe của con người ](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/su-dung-khang-sinh-bua-bai-va-hau-qua#gy-nh-hng-trc-tip-ti-sc-khe-ca-con-ngi)
  * [2. Lạm dụng kháng sinh trong điều trị](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/su-dung-khang-sinh-bua-bai-va-hau-qua#2-lam-dung-khang-sinh-trong-iu-tri)
  * [2.1. Dùng kháng sinh cho các bệnh không do vi khuẩn](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/su-dung-khang-sinh-bua-bai-va-hau-qua#21-dung-khang-sinh-cho-cac-bnh-khng-do-vi-khun)
  * [2.2. Việc mua và sử dụng kháng sinh quá dễ dàng](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/su-dung-khang-sinh-bua-bai-va-hau-qua#22-vic-mua-v-s-dng-khng-sinh-qu-d-dng)
  * [Từ phía bệnh nhân](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/su-dung-khang-sinh-bua-bai-va-hau-qua#t-pha-bnh-nhn)
  * [Từ phía nhân viên y tế](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/su-dung-khang-sinh-bua-bai-va-hau-qua#t-pha-nhn-vin-y-t)
  * [2.3. Trong thực tế hàng ngày, việc sử dụng kháng sinh của thầy thuốc cũng rất rộng rãi](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/su-dung-khang-sinh-bua-bai-va-hau-qua#23-trong-thc-t-hng-ngy-vic-s-dng-khng-sinh-ca-thy-thuc-cng-rt-rng-ri)
  * [3. Hậu quả của việc sử dụng kháng sinh bừa bãi ](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/su-dung-khang-sinh-bua-bai-va-hau-qua#3-hu-qu-ca-vic-s-dng-khng-sinh-ba-bi)
  * [3.1. Gây lãng phí](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/su-dung-khang-sinh-bua-bai-va-hau-qua#31gy-lng-ph)
  * [3.2. Không khỏi bệnh](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/su-dung-khang-sinh-bua-bai-va-hau-qua#32khng-khi-bnh)
  * [3.3. Chậm chẩn đoán](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/su-dung-khang-sinh-bua-bai-va-hau-qua#33chm-chn-on)
  * [3.4. Tác dụng độc hại](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/su-dung-khang-sinh-bua-bai-va-hau-qua#34tc-dng-c-hi)
  * [3.5. Tăng khả năng kháng thuốc của vi khuẩn](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/su-dung-khang-sinh-bua-bai-va-hau-qua#35tng-kh-nng-khng-thuc-ca-vi-khun)
  * [Vi khuẩn nhờn thuốc](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/su-dung-khang-sinh-bua-bai-va-hau-qua#vi-khun-nhn-thuc)



## Tử vong do kháng thuốc sẽ ngày càng tăng

  * [1. Cuộc chiến với vi khuẩn kháng thuốc bắt đầu ngay từ khi kháng sinh ](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/tu-vong-do-khang-thuoc-se-ngay-cang-tang#1-cuc-chin-vi-vi-khun-khng-thuc-bt-u-ngay-t-khi-khng-sinh)
  * [2. Kháng kháng sinh là mối đe dọa lớn nhất trên toàn cầu](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/tu-vong-do-khang-thuoc-se-ngay-cang-tang#2-khng-khng-sinh-l-mi-e-da-ln-nht-trn-ton-cu)


## **1. Cuộc chiến với vi khuẩn kháng thuốc bắt đầu ngay từ khi kháng sinh**
Ngay từ khi loại kháng sinh đầu tiên penicillin ra đời cách đây gần 1 thế kỉ, cuộc chiến với vi khuẩn kháng thuốc đã bắt đầu. Thực tế cho thấy, một loại thuốc mới được nghiên cứu ra sẽ nhanh chóng bị vi khuẩn kháng lại. Gần đây, tốc độ kháng kháng sinh của vi khuẩn quá nhanh, thuốc mới chỉ có mặt trên thị trường 2 – 3 năm đã bị kháng. Các nhà khoa học đang gấp rút tìm những liệu pháp mới có thể diệt vi khuẩn mà không cần dùng thuốc kháng sinh. Trong lúc này, 2 nguyên tắc quan trọng nhất được nhiều chuyên gia y tế khuyên dùng để kháng sinh phát huy tác dụng là dùng đúng và đủ.
## **2. Kháng kháng sinh là mối đe dọa lớn nhất trên toàn cầu**
Theo Tổ chức Y tế thế giới (WHO), với sự phát triển của thương mại và du lịch toàn cầu, các vi sinh vật kháng thuốc có thể lây lan nhanh chóng đến bất kỳ nơi nào trên thế giới. Nếu không có hành động hiệu quả đối phó với tình trạng này, Tổ chức Y tế Thế giới cảnh báo: đến một ngày nào đó, nhiều bệnh truyền nhiễm sẽ trở nên không kiểm soát được, 10 triệu người có thể tử vong mỗi năm do vi khuẩn kháng thuốc. Con số này cao hơn cả số người tử vong do ung thư hàng năm.
Theo Tổ chức Y tế thế giới (WHO), cảnh báo đề kháng kháng sinh là một trong những mối đe dọa lớn nhất đối với sức khỏe, an ninh lương thực và sự phát triển của toàn cầu. Đề kháng kháng sinh có thể ảnh hưởng đến bất kỳ ai, ở mọi lứa tuổi, ở bất kỳ quốc gia nào. Kháng thuốc xảy ra một cách tự nhiên, nhưng lạm dụng thuốc kháng sinh ở người và động vật đang đẩy nhanh tiến trình này. Số lượng các bệnh nhiễm trùng ngày càng tăng, như viêm phổi, lao, lậu và nhiễm khuẩn salmonella đang trở nên khó điều trị hơn khi các loại thuốc kháng sinh được sử dụng để điều trị chúng trở nên kém hiệu quả hơn.
Thực tế, tình trạng kháng kháng sinh đang là nỗi lo chung của cả thế giới. Tốc độ nghiên cứu và bào chế thuốc kháng sinh thế hệ mới hiện không kịp so với mức độ gia tăng của các vi khuẩn kháng thuốc. Trong hơn 5 năm (từ 1983 đến 1987), cơ quan Quản lý Dược và thực phẩm Mỹ chỉ cấp giấy chứng nhận sử dụng cho 18 loại kháng sinh. Từ năm 2008 đến nay không có thêm kháng sinh mới nào được tìm ra.
Tình trạng kháng thuốc không chỉ trì hoãn việc điều trị cho bệnh nhân bằng kháng sinh phù hợp mà còn gây mất hiệu quả trong chống nhiễm trùng, mất hiệu quả của kháng sinh dự phòng trong các thủ thuật y khoa và phẫu thuật. Hậu quả là tăng tỷ lệ bệnh nhân tử vong, tăng thời gian điều trị nội trú và tốn kém chi phí điều trị.
## **3. Khuyến cáo**
Đề kháng kháng sinh dẫn đến thời gian nằm viện lâu hơn, chi phí y tế cao hơn và làm tăng tỷ lệ tử vong. Do đó, bác sĩ khuyến cáo:
**3.1. Đối với mỗi cá nhân trong cộng đồng:**
  * Chỉ sử dụng kháng sinh khi được bác sĩ kê toa
  * Không bao giờ yêu cầu thuốc kháng sinh nếu bác sĩ nói rằng không cần chúng.
  * Luôn luôn làm theo lời khuyên của nhân viên y tế khi sử dụng thuốc kháng sinh.
  * Không bao giờ chia sẻ hoặc sử dụng thuốc kháng sinh dư thừa của người khác.
  * Ngăn ngừa nhiễm trùng bằng cách thường xuyên rửa tay, chuẩn bị thức ăn hợp vệ sinh, tránh tiếp xúc gần gũi với người bệnh, quan hệ tình dục an toàn và tiêm chủng vắc xin đúng lịch.
  * Chuẩn bị thức ăn hợp vệ sinh, tuân thủ các nguyên tắc an toàn thực phẩm bao gồm: giữ sạch, tách riêng nguyên liệu sống và chín, nấu kỹ, giữ thức ăn ở nhiệt độ an toàn, sử dụng nước sạch và nguyên liệu tươi sống; và chọn thực phẩm đã được sản xuất mà không sử dụng kháng sinh để thúc đẩy tăng trưởng hoặc phòng ngừa bệnh ở động vật khỏe mạnh.


**3.2. Trong môi trường các cơ sở y tế**
  * Ngăn ngừa nhiễm trùng bằng cách rửa tay, dụng cụ và môi trường sạch sẽ.
  * Chỉ kê đơn và phân phối kháng sinh khi cần thiết, theo phác đồ hiện hành.
  * Báo cáo tình trạng vi khuẩn đề kháng kháng sinh cho nhóm giám sát.
  * Cố gắng thống nhất với bệnh nhân về cách sử dụng kháng sinh đúng cách, hậu quả đề kháng kháng sinh và nguy cơ lạm dụng thuốc.
  * Thông tin rõ về việc phòng ngừa nhiễm trùng như tiêm chủng, rửa tay, quan hệ tình dục an toàn, che mũi và miệng khi hắt hơi.


**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [1. Cuộc chiến với vi khuẩn kháng thuốc bắt đầu ngay từ khi kháng sinh ](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/tu-vong-do-khang-thuoc-se-ngay-cang-tang#1-cuc-chin-vi-vi-khun-khng-thuc-bt-u-ngay-t-khi-khng-sinh)
  * [2. Kháng kháng sinh là mối đe dọa lớn nhất trên toàn cầu](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/tu-vong-do-khang-thuoc-se-ngay-cang-tang#2-khng-khng-sinh-l-mi-e-da-ln-nht-trn-ton-cu)



## Hoạt động dược lâm sàng: cảnh báo phản ứng có hại của thuốc

Chương trình giám sát thuốc của tổ chức y tế thế giới đưa ra một định nghĩa về phản ứng có hại của thuốc như sau (WHO, 1972): “ Phản ứng có hại của thuốc là phản ứng độc hại, không được định trước, xuất hiện ở liều thường dùng cho người để phòng bệnh, chẩn đoán hay chữa bệnh hoặc nhằm thay đổi một chức năng sinh lý. Định nghĩa này không bao gồm các trường hợp thất bại trị liệu, quá liều, lạm dụng thuốc, không tuân thủ và sai sót trong trị liệu ”
Việc kiểm soát được những phản ứng có hại của thuốc là rất quan trọng trong hoạt động lâm sàng ở mỗi bệnh viện, đòi hỏi sự đầu tư tìm hiểu nghiêm túc và chu đáo
Tại [BV Nguyễn Tri Phương](https://www.facebook.com/BVNTP), chủ đề này đã được đưa ra thảo luận sôi nổi và tạo ra nhiều giá trị tích cực
Nội dung chi tiết của báo cáo có thể tham khảo [tại đây](https://drive.google.com/open?id=1evw7oontjqz1Th5oQFGe-arzvtUvcTpd).
BS Lương Công Minh, phòng Quản Lý Chất Lượng
**Bệnh viện Nguyễn Tri Phương** - Bệnh viện Đa khoa Hạng I Thành phố Hồ Chí Minh
  * 468 Nguyễn Trãi, Phường 8, Quận 5, Tp. Hồ Chí Minh
  * Hotline: (84-028) 39234332
  * Mạng xã hội **Facebook** : [**Bệnh viện Nguyễn Tri Phương**](https://www.facebook.com/BVNTP/)
  * Đăng ký (Subcribe) kênh **Youtube** : [https://youtube.com/bvntp](https://youtube.com/bvntp?fbclid=IwAR3q_UvPI4OZAebT1uQGPKKwk3RmCzAFLkBJm9lb7EwIz0EHtgiLhKM5bxU)
  * Quan tâm Zalo Official: [zalo.me/1744466261097093886](https://zalo.me/1744466261097093886?fbclid=IwAR3E-fLqdh-x1cYSvuDY6E5Eyxfjo5ZSs4p0hDWAyBG-ROlTkxXkXvdEWAY)



## ️ Kháng sinh: Sự nguy hiểm của việc lạm dụng

  * [Nguyên nhân kháng kháng sinh](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/khang-sinh-su-nguy-hiem-cua-viec-lam-dung#nguyn-nhn-khng-khng-sinh)
  * [Lạm dụng kháng sinh](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/khang-sinh-su-nguy-hiem-cua-viec-lam-dung#lm-dng-khng-sinh)
  * [Hậu quả của kháng kháng sinh ](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/khang-sinh-su-nguy-hiem-cua-viec-lam-dung#hu-qu-ca-khng-khng-sinh)
  * [Việc sử dụng kháng sinh đúng theo phác đồ sẽ giúp cho:](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/khang-sinh-su-nguy-hiem-cua-viec-lam-dung#vic-s-dng-khng-sinh-ng-theo-phc-s-gip-cho)
  * [Để giảm sự phát triển của vi khuẩn kháng kháng sinh, mỗi người chúng ta cần:](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/khang-sinh-su-nguy-hiem-cua-viec-lam-dung#-gim-s-pht-trin-ca-vi-khun-khng-khng-sinh-mi-ngi-chng-ta-cn)


Thuốc kháng sinh là loại thuốc quan trọng giúp ngăn ngừa sự tiến triển của bệnh lý gây ra bởi vi khuẩn (nhiễm trùng), giảm các triệu chứng và biến chứng nghiêm trọng của bệnh. Tuy nhiên việc lạm dụng quá mức khiến những loại kháng sinh đã sử dụng trước đây ít hiệu quả hoặc không có hiệu quả trong việc điều trị các nhiễm trùng do vi khuẩn về sau. Đây là một trong những vấn đề nhức nhối của các tổ chức y tế trên thế giới.
## **Nguyên nhân kháng kháng sinh**
Kháng thuốc kháng sinh (kháng kháng sinh) là khả năng của vi khuẩn hoặc các tác nhân gây bệnh dạng vi khuẩn kháng lại các hiệu quả của thuốc kháng sinh. Khi đó, vi khuẩn sẽ thay đổi theo một cách mới để làm giảm hoặc loại bỏ hiệu quả của thuốc, hóa chất hoặc các tác nhân khác được dùng để chữa bệnh.
Bất kì vi khuẩn nào sống sót sau khi điều trị kháng sinh đều có thể nhân lên và truyền các đặc tính của nó cho các thế hệ sau.
Ngoài ra, một số vi khuẩn có thể chuyển các đặc tính kháng thuốc của chúng sang các vi khuẩn khác, điều này làm gia tăng số lượng chủng loại vi khuẩn kháng thuốc kháng sinh ngày càng nhiều hơn.
## **Lạm dụng kháng sinh**
Việc lạm dụng kháng sinh, đặc biệt là dùng kháng sinh ngay cả khi chưa thật sự cần thiết hoặc dùng kháng sinh khi chưa phải là phương pháp điều trị thích hợp (thông thường được nhắc đến là điều trị bao vây) làm gia tăng tình trạng kháng kháng sinh. Theo nghiên cứu của trung tâm kiểm soát và phòng ngừa dịch bệnh Hoa Kì có từ 30 đến 50% trường hợp sử dụng kháng sinh ở người là không phù hợp.
Một số bệnh mắc phải do virus như: cảm lạnh, cúm, viêm phế quản và một số bệnh nhiễm trùng tai, xoang thường bị kê kháng sinh không đúng cách. Việc sử dụng kháng sinh trong những trường hợp này không những khó chữa khỏi nhiễm trùng, viêm mà còn có thể gây ra nhiều tác dụng phụ khác; ví dụ như tiêu diệt các vi khuẩn có lợi hoặc ít nhất là không gây bệnh. Điều này tạo điều kiện thúc đẩy các đặc tính kháng kháng sinh ở các vi khuẩn vô hại có thể chia sẻ với các loại vi khuẩn khác hoặc tạo điều kiện cho các vi khuẩn có hại sinh sôi phát triển, lấn át vi khuẩn có lợi.
Thông thường người bệnh hay tự ý ngưng sử dụng thuốc kháng sinh khi cơ thể thấy khỏe hơn, tuy nhiên việc điều trị đúng và đủ liều là cần thiết để tiêu diệt hoàn toàn vi khuẩn gây bệnh.
## **Hậu quả của kháng kháng sinh**
Tình trạng kháng kháng sinh ngày càng gia tăng, nhưng nhân loại chưa tìm ra được loại kháng sinh nào hoàn toàn mới để thay thế những thuốc hiện dùng, điều này gây ra nhiều lo ngại trong công cuộc chăm sóc sức khỏe y tế cho cộng đồng.
Các hậu quả của nhiễm trùng kháng thuốc có thể bao gồm:
  * Bệnh nặng hơn, thời gian phục hồi lâu hơn.
  * Bệnh tái đi tái lại thường xuyên
  * Phương pháp và chi phí điều trị cao hơn.
  * Tử vong khi không có thuốc hiệu quả điều trị


## **Việc sử dụng kháng sinh đúng theo phác đồ sẽ giúp cho:**
  * Giữ nguyên tính hiệu quả của kháng sinh hiện tại
  * Bảo vệ bản thân khỏi nhiễm trùng kháng kháng sinh.
  * Tránh các tác dụng phụ của việc sử dụng kháng sinh không đúng phác đồ.


## **Để giảm sự phát triển của vi khuẩn kháng kháng sinh, mỗi người chúng ta cần:**
  * Chỉ sử dụng kháng sinh khi thật sự bị nhiễm khuẩn.
  * Cung cấp đơn thuốc kháng sinh đã uống trong các lần bệnh trước.
  * Thực hành vệ sinh, ăn uống tốt tránh nhiễm khuẩn.
  * Tiêm phòng đầy các bệnh có thể ngừa bằng vắc xin.
  * Sử dụng kháng sinh đủ liều và theo chỉ định của Bác sĩ.
  * Không sử dụng kháng sinh lẻ hay kháng sinh của người khác khi bị bệnh.


**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [Nguyên nhân kháng kháng sinh](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/khang-sinh-su-nguy-hiem-cua-viec-lam-dung#nguyn-nhn-khng-khng-sinh)
  * [Lạm dụng kháng sinh](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/khang-sinh-su-nguy-hiem-cua-viec-lam-dung#lm-dng-khng-sinh)
  * [Hậu quả của kháng kháng sinh ](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/khang-sinh-su-nguy-hiem-cua-viec-lam-dung#hu-qu-ca-khng-khng-sinh)
  * [Việc sử dụng kháng sinh đúng theo phác đồ sẽ giúp cho:](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/khang-sinh-su-nguy-hiem-cua-viec-lam-dung#vic-s-dng-khng-sinh-ng-theo-phc-s-gip-cho)
  * [Để giảm sự phát triển của vi khuẩn kháng kháng sinh, mỗi người chúng ta cần:](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/khang-sinh-su-nguy-hiem-cua-viec-lam-dung#-gim-s-pht-trin-ca-vi-khun-khng-khng-sinh-mi-ngi-chng-ta-cn)



## ️ Vai trò của vitamin A đối với cơ thể

  * [Lợi ích của vitamin A](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/vai-tro-cua-vitamin-a-doi-voi-co-the#li-ch-ca-vitamin-a)
  * [Tránh bệnh quáng gà và hiện tượng suy giảm thị lực theo tuổi tác.](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/vai-tro-cua-vitamin-a-doi-voi-co-the#trnh-bnh-qung-g-v-hin-tng-suy-gim-th-lc-theo-tui-tc)
  * [Hỗ trợ hệ thống miễn dịch](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/vai-tro-cua-vitamin-a-doi-voi-co-the#h-tr-h-thng-min-dch)
  * [Hỗ trợ sản xuất các tế bào bạch cầu.](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/vai-tro-cua-vitamin-a-doi-voi-co-the#h-tr-sn-xut-cc-t-bo-bch-cu)
  * [Giảm nguy cơ tử vong ở trẻ em do bệnh sởi, sốt rét gây ra.](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/vai-tro-cua-vitamin-a-doi-voi-co-the#gim-nguy-c-t-vong-tr-em-do-bnh-si-st-rt-gy-ra)
  * [Hỗ trợ sức khỏe xương khớp](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/vai-tro-cua-vitamin-a-doi-voi-co-the#h-tr-sc-khe-xng-khp)
  * [Duy trì hệ thống sinh sản khỏe mạnh, đảm bảo sự phát triển bình thường của phôi thai.](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/vai-tro-cua-vitamin-a-doi-voi-co-the#duy-tr-h-thng-sinh-sn-khe-mnh-m-bo-s-pht-trin-bnh-thng-ca-phi-thai)


Các hợp chất vitamin A được tìm thấy trong thức ăn động vật, thực vật và các thực phẩm bổ sung. Nguồn cấp vitamin A trực tiếp có trong các thực phẩm như thịt, cá, trứng, sữa và các thực phẩm có chứa hợp chất retinol, retinal và axi retinoic. Các chất được cơ thể hấp thụ sau đó chuyển hóa thành vitamin A như α-carotene, β-carotene, β-cryptoxanthin có nhiều ở các thực phẩm nguồn gốc thực vật.
## **Lợi ích của vitamin A**
### **Tránh bệnh quáng gà và hiện tượng suy giảm thị lực theo tuổi tác.**
Bệnh quáng gà xảy ra ở những người thiếu vitamin A- thành phần chính của rhodopsin được tìm thấy trong võng mạc mắt và cực kì nhạy cảm với ánh sáng. Nghiên cứu về các bệnh mắt liên quan đến tuổi tác cho thấy rằng, việc bổ sung chất chống oxy hóa như -carotene giúp giảm 25% ngăn chặn quá trình thoái hóa điểm vàng ở mắt.
Một số công bố chưa chính thức gần đây cho thấy việc bổ sung các thực phẩm có nguồn gốc thực vật giàu vitamin A giúp giảm nguy cơ mắc các bệnh ung thư như ung thư hạch Hodgkin, ung thư cổ tử cung, phổi và bàng quang.
### **Hỗ trợ hệ thống miễn dịch**
Vitamin A đóng vai trò quan trọng trong hệ thống hàng rào miễn dịch của cơ thể bao các dịch nhầy ở mắt, phổi, ruột và cơ quan sinh dục giúp ngăn chặn sự xâm nhậm của vi khuẩn và các tác nhân lây nhiễm khác.
### **Hỗ trợ sản xuất các tế bào bạch cầu.**
### **Giảm nguy cơ tử vong ở trẻ em do bệnh sởi, sốt rét gây ra.**
### **Hỗ trợ sức khỏe xương khớp**
Các chất dinh dưỡng quan trọng để duy trì xương chắc khỏe như protein, canxi và vitamin D. Vitamin A đóng vai trò quan trọng trong hỗ trợ phát triển xương. Theo một nghiên cứu cho thấy người bổ sung đủ vitamin A giúp giảm được 6% nguy cơ gãy xương.
### **Duy trì hệ thống sinh sản khỏe mạnh, đảm bảo sự phát triển bình thường của phôi thai.**
Thiếu hụt vitamin A ngăn cản sự phát triển của các tế bào tinh trùng dẫn đến vô sinh ở nam và giảm chất lượng trứng ở phụ nữ.
Tham gia vào sự phát triển cấu trúc của các cơ quan ở thai nhi như hệ thần kinh, tim, thận, mắt, phổi, tuyến tụy…tuy nhiên việc thiếu hay dư thừa vitamin A trong thời kì mang thai có thể dẫn đến các dị tật bẩm sinh ở thai nhi.
Chế độ ăn lành mạnh và phong phú sẽ cung cấp đủ lượng vitamin A cần thiết cho cơ thể. Đối với những người biếng ăn hoặc cơ thể hấp thu kém hay mắc phải một số bệnh khiến nhu cầu vitamin A của cơ thể tăng cao hơn bình thường (bệnh tuyến tụy, mắt, bệnh sởi) thì việc bổ sung vitamin A đường uống là cần thiết. Tuy nhiên bổ sung vitamin A bằng thực phẩm vẫn là lựa chọn tốt nhất. Lượng vitamin A được khuyến cáo sử dụng hằng ngày ở người trưởng thành là 900mcg đối với nam giới và 700mcg đối với phụ nữ.
## **Lưu ý:**
Nếu cơ thể dung nạp cùng một lúc hơn 200.000mcg có thể xuất hiện các triệu chứng như buồn nôn, chóng mặt, tầm nhìn kém hoặc có thể tử vong.
Cơ thể có sự cân bằng trong chuyển hóa các tiền tố vitamin A thành vitamin A chính thức, vì vậy các nguồn cung cấp vitamin A ở thực vật ít có rủi ro gây thừa vitamin A hơn các nguồn cấp từ động vật hay thực phẩm bổ sung.
Uống quá 10.000mcg vitamin A hằng ngày có thể gây các tổn thương cho cơ thể: xương mỏng, tổn thương gan, đau đầu tiêu chảy, buồn nôn, kích ứng da, đau xương khớp.
Phụ nữ đang mang thai hoặc người đang điều trị kết hợp các loại thuốc cần tham vấn bác sĩ trước khi sử dụng vitamin A.
Xem thêm: [**Thóp phồng, đau đầu, buồn nôn sau uống Vitamin A liều cao**](https://bvnguyentriphuong.com.vn/khoa-nhi/thop-phong-dau-dau-buon-non-sau-uong-vitamin-a-lieu-cao)
**Bệnh viện Nguyễn Tri Phương** - Bệnh viện Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [Lợi ích của vitamin A](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/vai-tro-cua-vitamin-a-doi-voi-co-the#li-ch-ca-vitamin-a)
  * [Tránh bệnh quáng gà và hiện tượng suy giảm thị lực theo tuổi tác.](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/vai-tro-cua-vitamin-a-doi-voi-co-the#trnh-bnh-qung-g-v-hin-tng-suy-gim-th-lc-theo-tui-tc)
  * [Hỗ trợ hệ thống miễn dịch](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/vai-tro-cua-vitamin-a-doi-voi-co-the#h-tr-h-thng-min-dch)
  * [Hỗ trợ sản xuất các tế bào bạch cầu.](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/vai-tro-cua-vitamin-a-doi-voi-co-the#h-tr-sn-xut-cc-t-bo-bch-cu)
  * [Giảm nguy cơ tử vong ở trẻ em do bệnh sởi, sốt rét gây ra.](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/vai-tro-cua-vitamin-a-doi-voi-co-the#gim-nguy-c-t-vong-tr-em-do-bnh-si-st-rt-gy-ra)
  * [Hỗ trợ sức khỏe xương khớp](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/vai-tro-cua-vitamin-a-doi-voi-co-the#h-tr-sc-khe-xng-khp)
  * [Duy trì hệ thống sinh sản khỏe mạnh, đảm bảo sự phát triển bình thường của phôi thai.](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/vai-tro-cua-vitamin-a-doi-voi-co-the#duy-tr-h-thng-sinh-sn-khe-mnh-m-bo-s-pht-trin-bnh-thng-ca-phi-thai)



## ️ Dị ứng thuốc

  * [Triệu chứng và Chẩn đoán](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/di-ung-thuoc#triu-chng-v-chn-on)
  * [Điều trị & Xử trí](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/di-ung-thuoc#iu-tr-x-tr)


## **Tổng quan**
Phản ứng phụ của thuốc là thường gặp, nhưng mỗi người phản ứng một cách khác nhau. Người này có thể phát ban hoặc các phản ứng khác khi dùng một loại thuốc nào đó, trong khi người khác không hề có phản ứng phụ nào.
Khoảng 5% đến 10% các phản ứng này là do dị ứng với thuốc.
Một phản ứng dị ứng xảy ra khi hệ thống miễn dịch phản ứng quá mức với một chất vô hại, trong trường hợp này là một loại thuốc, gây ra phản ứng dị ứng. Nhạy cảm với thuốc có thể gây ra các triệu chứng tương tự, nhưng không liên quan đến hệ miễn dịch.
Một số loại thuốc nhiều khả năng gây dị ứng hơn các loại thuốc khác. Thường gặp nhất là:
  * Kháng sinh, như penicillin
  * Aspirin và thuốc chống viêm không steroid, như ibuprofen
  * Thuốc chống co giật
  * Liệu pháp kháng thể đơn dòng
  * Hóa trị


Khả năng phát sinh dị ứng cao hơn khi bạn thường xuyên dùng thuốc hoặc khi thuốc được chà xát lên da hoặc khi được tiêm, thay vì uống.
## **Triệu chứng và Chẩn đoán**
**_Triệu chứng_**
Phản ứng phụ của thuốc thay đổi, từ nôn mửa và rụng tóc với hóa trị ung thư đến đau dạ dày do aspirin hoặc tiêu chảy do kháng sinh. Nếu bạn dùng thuốc ức chế men chuyển angiotensin (angiotensin converting enzyme - ACE) để điều trị tăng huyết áp, bạn có thể bị ho hoặc sưng mặt sưng lưỡi.
Trong nhiều trường hợp, có thể khó xác định xem phản ứng có phải do thuốc hay do thứ gì khác không. Bởi vì các triệu chứng của bạn có thể tương tự nhau dù do các tình trạng khác nhau.
Các loại triệu chứng dị ứng đối với thuốc thường gặp nhất là:
  * Phát ban da, đặc biệt nổi mẫn
  *   * Hô hấp có vấn đề
  * Sưng, như sưng mặt


Sốc phản vệ là một phản ứng dị ứng nghiêm trọng, thường bao gồm sưng, nổi mẫn, hạ huyết áp, và sốc trong những trường hợp nặng. Nếu sốc phản vệ không được điều trị ngay lập tức, nó có thể gây tử vong.
Một sự khác biệt lớn giữa sốc phản vệ và các phản ứng dị ứng khác là sốc phản vệ thường liên quan đến nhiều hệ thống trong cơ thể.
Sốc phản vệ đòi hỏi phải chăm sóc y tế ngay lập tức vì có thể gây tử vong.
Nếu bạn nghĩ rằng bạn có thể bị dị ứng với một loại thuốc được bác sĩ kê đơn, hãy gọi cho bác sĩ trước khi bạn thay đổi hoặc ngừng sử dụng thuốc.
### **_Chẩn đoán_**
Bác sĩ của bạn sẽ muốn biết:
  * Khi nào bắt đầu có triệu chứng
  * Mô tả các triệu chứng của bạn
  * Các triệu chứng kéo dài trong bao lâu
  * Bất kỳ loại thuốc nào khác được sử dụng trong thời gian này, kể cả thuốc không bán theo toa


Nếu bạn có tiền sử phản ứng với các loại thuốc khác nhau, hoặc nếu bạn có phản ứng nghiêm trọng với một loại thuốc, một nhà dị ứng / miễn dịch học, thường được gọi là chuyên gia dị ứng, được đào tạo chuyên sâu và có kinh nghiệm sẽ chẩn đoán vấn đề và giúp bạn lập kế hoạch bảo vệ trong tương lai.
## **Điều trị & Xử trí**
Nếu bạn có các tác dụng phụ khiến bạn lo ngại, hoặc bạn nghi ngờ dị ứng thuốc đã xảy ra, hãy gọi cho bác sĩ. Nếu các triệu chứng của bạn nặng, hãy tìm sự trợ giúp y tế ngay lập tức. Một phản ứng phản vệ nghiêm trọng cần được chăm sóc y tế ngay lập tức vì có thể gây tử vong.
Trong hầu hết các trường hợp phản ứng phụ, bác sĩ có thể cho thay thế thuốc. Đối với các phản ứng nghiêm trọng, bác sĩ có thể cho thuốc kháng histamine, corticosteroid hoặc epinephrine.
Thử nghiệm dị ứng tiêu chuẩn đối với penicillin hiện có sẵn và có thể theo sau bằng một lần uống thử trong phòng khám. Thử nghiệm như vậy có thể bảo đảm ở mức độ cao rằng penicillin và các thuốc tương tự có thể được dung nạp trong tương lai.
Khi thuốc này là cần thiết và không có thuốc thay thế, nên tiến hành thủ thuật giải mẫn cảm với thuốc, bằng cách đưa vào những liều thuốc nhỏ cho đến khi đạt được liều điều trị.
Hãy chắc chắn rằng bác sĩ, nha sĩ và hiệu thuốc của bạn biết được tình trạng dị ứng thuốc của bạn hiện tại, giúp xác định loại thuốc nào nên tránh.
**Nguồn: American Academy of Allergy, Asthma & Immunology**
[https://www.aaaai.org/conditions-and-treatments/allergies/drug-allergy](https://www.aaaai.org/conditions-and-treatments/allergies/drug-allergy)
**Bệnh viện Nguyễn Tri Phương** - Đa khoa Hạng I Thành phố Hồ Chí Minh
  * [Triệu chứng và Chẩn đoán](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/di-ung-thuoc#triu-chng-v-chn-on)
  * [Điều trị & Xử trí](https://bvnguyentriphuong.com.vn/hoat-dong-duoc/di-ung-thuoc#iu-tr-x-tr)



